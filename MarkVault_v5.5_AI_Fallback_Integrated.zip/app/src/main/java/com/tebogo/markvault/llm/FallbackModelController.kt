package com.tebogo.markvault.llm

/**
 * v5.5 AI resilience layer.
 * Chooses a smaller model when the primary model is unsafe for current memory.
 */
object FallbackModelController {

    fun selectModel(availableMemoryMb: Long): String {
        return if (availableMemoryMb < 1200) {
            "smollm2_135m"
        } else {
            "qwen3_0_6b"
        }
    }

    fun shouldFallback(error: Throwable): Boolean {
        return error is OutOfMemoryError ||
                error.cause is OutOfMemoryError
    }
}