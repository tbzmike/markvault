package com.tebogo.markvault.llm

data class ModelMemoryPolicy(
    val primaryModel: String = "qwen3_0_6b",
    val fallbackModel: String = "smollm2_135m",
    val minimumFreeMemoryMb: Long = 1200
)