package com.tebogo.markvault.data

import android.content.Context
import android.net.Uri
import android.provider.DocumentsContract
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

data class IndexProgress(
    val running: Boolean = false,
    val phase: String = "",
    val done: Int = 0,
    val total: Int = 0
)

data class ScannedFile(
    val docId: String,
    val name: String,
    val relPath: String,
    val lastModified: Long,
    val size: Long
)

class Indexer(private val context: Context, private val dao: NoteDao) {

    suspend fun sync(treeUriString: String, onProgress: (IndexProgress) -> Unit) =
        withContext(Dispatchers.IO) {
            val treeUri = Uri.parse(treeUriString)
            onProgress(IndexProgress(true, "Scanning library\u2026", 0, 0))

            val files = ArrayList<ScannedFile>(2048)
            val rootId = DocumentsContract.getTreeDocumentId(treeUri)
            scanFolder(treeUri, rootId, "", files)

            val existing = dao.syncInfo().associateBy { it.uri }
            val seenIds = HashSet<Long>(files.size)
            var done = 0
            val total = files.size
            onProgress(IndexProgress(true, "Indexing\u2026", 0, total))

            for (f in files) {
                val fileUri =
                    DocumentsContract.buildDocumentUriUsingTree(treeUri, f.docId).toString()
                val old = existing[fileUri]
                if (old != null && old.lastModified == f.lastModified && old.size == f.size) {
                    seenIds.add(old.id)
                    done++
                    if (done % 100 == 0) onProgress(IndexProgress(true, "Indexing\u2026", done, total))
                    continue
                }
                val text = readText(fileUri) ?: ""
                val title = extractTitle(text, f.name)
                val folder = f.relPath.substringBeforeLast('/', "")
                val newId = dao.upsert(
                    Note(
                        id = 0,
                        uri = fileUri,
                        relPath = f.relPath,
                        name = f.name,
                        title = title,
                        folder = folder,
                        content = text,
                        lastModified = f.lastModified,
                        size = f.size,
                        lastOpened = old?.lastOpened ?: 0
                    )
                )
                seenIds.add(newId)
                done++
                if (done % 25 == 0 || done == total) {
                    onProgress(IndexProgress(true, "Indexing\u2026", done, total))
                }
            }

            val toDelete = existing.values.asSequence()
                .filter { it.id !in seenIds }
                .map { it.id }
                .toList()
            if (toDelete.isNotEmpty()) {
                toDelete.chunked(500).forEach { dao.deleteByIds(it) }
            }

            onProgress(IndexProgress(false, "Done", total, total))
        }

    private fun scanFolder(
        treeUri: Uri,
        parentDocId: String,
        parentPath: String,
        out: MutableList<ScannedFile>
    ) {
        val childrenUri =
            DocumentsContract.buildChildDocumentsUriUsingTree(treeUri, parentDocId)
        val projection = arrayOf(
            DocumentsContract.Document.COLUMN_DOCUMENT_ID,
            DocumentsContract.Document.COLUMN_DISPLAY_NAME,
            DocumentsContract.Document.COLUMN_MIME_TYPE,
            DocumentsContract.Document.COLUMN_LAST_MODIFIED,
            DocumentsContract.Document.COLUMN_SIZE
        )
        try {
            context.contentResolver.query(childrenUri, projection, null, null, null)?.use { c ->
                while (c.moveToNext()) {
                    val docId = c.getString(0) ?: continue
                    val name = c.getString(1) ?: continue
                    val mime = if (c.isNull(2)) "" else c.getString(2)
                    val lastMod = if (c.isNull(3)) 0L else c.getLong(3)
                    val size = if (c.isNull(4)) 0L else c.getLong(4)
                    val path = if (parentPath.isEmpty()) name else "$parentPath/$name"
                    if (mime == DocumentsContract.Document.MIME_TYPE_DIR) {
                        scanFolder(treeUri, docId, path, out)
                    } else if (
                        name.endsWith(".md", ignoreCase = true) ||
                        name.endsWith(".markdown", ignoreCase = true)
                    ) {
                        out.add(ScannedFile(docId, name, path, lastMod, size))
                    }
                }
            }
        } catch (_: Exception) {
            // Folder unreadable; skip it rather than crash the whole index.
        }
    }

    private fun readText(uriString: String): String? = try {
        context.contentResolver.openInputStream(Uri.parse(uriString))?.use {
            it.bufferedReader(Charsets.UTF_8).readText()
        }
    } catch (_: Exception) {
        null
    }

    companion object {
        fun extractTitle(text: String, fileName: String): String {
            for (line in text.lineSequence().take(40)) {
                val t = line.trim()
                if (t.startsWith("#")) {
                    val title = t.trimStart('#').trim()
                    if (title.isNotEmpty()) return title
                }
            }
            return fileName
                .removeSuffix(".md").removeSuffix(".MD")
                .removeSuffix(".markdown").removeSuffix(".MARKDOWN")
        }
    }
}
