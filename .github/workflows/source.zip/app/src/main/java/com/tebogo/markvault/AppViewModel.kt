package com.tebogo.markvault

import android.app.Application
import android.content.Intent
import android.net.Uri
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.tebogo.markvault.data.IndexProgress
import com.tebogo.markvault.data.Indexer
import com.tebogo.markvault.data.Note
import com.tebogo.markvault.data.NoteMeta
import com.tebogo.markvault.data.Prefs
import com.tebogo.markvault.data.SearchHit
import com.tebogo.markvault.data.VaultDb
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.FlowPreview
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.debounce
import kotlinx.coroutines.flow.distinctUntilChanged
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.flowOn
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

@OptIn(FlowPreview::class)
class AppViewModel(app: Application) : AndroidViewModel(app) {

    private val db = VaultDb.get(app)
    private val dao = db.notes()
    private val prefs = Prefs(app)
    private val indexer = Indexer(app, dao)

    val libraryUri: StateFlow<String?> =
        prefs.libraryUri.stateIn(viewModelScope, SharingStarted.Eagerly, null)

    val fontScale: StateFlow<Float> =
        prefs.fontScale.stateIn(viewModelScope, SharingStarted.Eagerly, 1.0f)

    private val _progress = MutableStateFlow(IndexProgress())
    val progress: StateFlow<IndexProgress> = _progress

    private val _notes = MutableStateFlow<List<NoteMeta>>(emptyList())
    val notes: StateFlow<List<NoteMeta>> = _notes

    val query = MutableStateFlow("")

    val results: StateFlow<List<SearchHit>> = query
        .debounce(250)
        .map { it.trim() }
        .distinctUntilChanged()
        .map { q ->
            if (q.length < 2) emptyList()
            else runCatching { dao.search(toMatch(q)) }.getOrElse { emptyList() }
        }
        .flowOn(Dispatchers.IO)
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    init {
        viewModelScope.launch {
            refreshNotes()
            val uri = prefs.libraryUri.first()
            if (uri != null) startSync(uri)
        }
    }

    fun setLibrary(uri: Uri) {
        val app = getApplication<Application>()
        try {
            app.contentResolver.takePersistableUriPermission(
                uri,
                Intent.FLAG_GRANT_READ_URI_PERMISSION
            )
        } catch (_: Exception) {
        }
        viewModelScope.launch(Dispatchers.IO) {
            dao.clearAll()
            prefs.setLibraryUri(uri.toString())
            refreshNotes()
            startSync(uri.toString())
        }
    }

    fun reindex() {
        val uri = libraryUri.value ?: return
        startSync(uri)
    }

    private fun startSync(uri: String) {
        if (_progress.value.running) return
        _progress.value = IndexProgress(true, "Starting\u2026", 0, 0)
        viewModelScope.launch(Dispatchers.IO) {
            try {
                indexer.sync(uri) { p -> _progress.value = p }
            } catch (e: Exception) {
                _progress.value = IndexProgress(false, "Error: ${e.message}", 0, 0)
            }
            refreshNotes()
        }
    }

    private suspend fun refreshNotes() {
        _notes.value = runCatching { dao.allMeta() }.getOrElse { emptyList() }
    }

    suspend fun loadNote(id: Long): Note? {
        val n = dao.byId(id)
        if (n != null) {
            runCatching { dao.touch(id, System.currentTimeMillis()) }
        }
        return n
    }

    fun setFontScale(v: Float) {
        viewModelScope.launch { prefs.setFontScale(v) }
    }

    companion object {
        /** Turn what the user typed into a safe FTS MATCH expression. */
        fun toMatch(raw: String): String {
            if (raw.contains('"')) return raw
            val cleaned = raw.replace(Regex("[^\\p{L}\\p{N}\\s]"), " ")
            val tokens = cleaned.split(Regex("\\s+")).filter { it.isNotBlank() }
            if (tokens.isEmpty()) return "\"\""
            return tokens.joinToString(" ") { "$it*" }
        }
    }
}
