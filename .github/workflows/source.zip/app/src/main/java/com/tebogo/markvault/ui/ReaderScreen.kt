package com.tebogo.markvault.ui

import android.text.method.LinkMovementMethod
import android.widget.TextView
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.navigation.NavController
import com.tebogo.markvault.AppViewModel
import com.tebogo.markvault.data.Note
import io.noties.markwon.Markwon
import io.noties.markwon.ext.strikethrough.StrikethroughPlugin
import io.noties.markwon.ext.tables.TablePlugin
import io.noties.markwon.ext.tasklist.TaskListPlugin
import io.noties.markwon.html.HtmlPlugin
import io.noties.markwon.linkify.LinkifyPlugin

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ReaderScreen(vm: AppViewModel, nav: NavController, id: Long) {
    var note by remember { mutableStateOf<Note?>(null) }
    LaunchedEffect(id) { note = vm.loadNote(id) }

    val fontScale by vm.fontScale.collectAsStateWithLifecycle()
    val ctx = LocalContext.current

    val markwon = remember {
        Markwon.builder(ctx)
            .usePlugin(HtmlPlugin.create())
            .usePlugin(TablePlugin.create(ctx))
            .usePlugin(StrikethroughPlugin.create())
            .usePlugin(TaskListPlugin.create(ctx))
            .usePlugin(LinkifyPlugin.create())
            .build()
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Text(
                        note?.title ?: "\u2026",
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                },
                navigationIcon = {
                    IconButton(onClick = { nav.popBackStack() }) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back")
                    }
                },
                actions = {
                    TextButton(
                        onClick = { vm.setFontScale((fontScale - 0.1f).coerceIn(0.7f, 2.0f)) }
                    ) { Text("A\u2212") }
                    TextButton(
                        onClick = { vm.setFontScale((fontScale + 0.1f).coerceIn(0.7f, 2.0f)) }
                    ) { Text("A+") }
                }
            )
        }
    ) { pad ->
        Column(
            Modifier
                .padding(pad)
                .verticalScroll(rememberScrollState())
                .padding(horizontal = 16.dp, vertical = 8.dp)
        ) {
            val content = note?.content
            if (content == null) {
                Text("Loading\u2026")
            } else {
                AndroidView(
                    modifier = Modifier.fillMaxWidth(),
                    factory = { c ->
                        TextView(c).apply {
                            setTextIsSelectable(true)
                            movementMethod = LinkMovementMethod.getInstance()
                            setTextColor(0xFFE6E6E6.toInt())
                            setLinkTextColor(0xFF8AB4F8.toInt())
                        }
                    },
                    update = { tv ->
                        tv.textSize = 16f * fontScale
                        markwon.setMarkdown(tv, content)
                    }
                )
                Spacer(Modifier.height(48.dp))
            }
        }
    }
}
