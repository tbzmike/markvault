# MarkVault 5.5.52 — Portable backup with SAF filename collisions

Baseline: 5.5.51 (version code 500). New version: 5.5.52 (code 501).

## Fixed

- **Backup failure: `Library has duplicate relative paths`.** SAF document providers may list two distinct document IDs with the same display name and folder path; they may also repeat one ID. The old backup aborted unconditionally for both scenarios.
- A deterministic portable-path allocator now distinguishes different documents with collision-safe names such as `Esau (MarkVault copy 2).md`, preserving extensions. It reserves pre-existing names so the suffix cannot overwrite a real source file. Case-insensitive name collisions are also handled. Repeated rows for the **same document ID** are deduplicated.
- This disambiguation also applies to colliding folder names, including nested files. **Only archive/target-device filenames change:** the original library on the source phone is never renamed or deleted.
- During backup, each indexed article's archived `relPath`, name, and folder are matched to the correct source document ID and rewritten to its portable path when necessary. This prevents two same-named articles from being restored against the wrong article or embedding.
- If a note cannot be safely matched to one source file, preflight reports an explicit error rather than silently creating a damaged/incomplete backup. Preflight happens before opening the output stream, protecting an existing backup from being truncated on this class of failure.
- Cross-device library scanning and target-folder matching now use the same collision-aware path assignment rather than overwriting duplicate relative-path map entries.
- Settings explanation corrected: version 5.5.51 already backed up articles, folders, all-model embeddings, ANN indexes, application files, settings, and model assets; the prior on-screen description was stale.

## Compatibility and preservation

- Portable backup ZIP format **remains v7**, database schema **remains 24**. Backup entries and checksum verification are unchanged. Compatible 5.5.51+ installations can read v7 archives; the destination must grant access to a writable SAF library folder. Restore rebinds note URIs to the destination phone.
- Existing checksummed streams for notes, topics, links, all-model note embeddings, media embeddings, other Room tables, settings, ANN files, app files, and model assets are preserved.
- Search/Question Awareness, reranking, HNSW/IVF engines, embedding synchronization, manual highlight navigation and overlay, battery safeguards, and model controls are not edited.
- **No extra timers, services, scheduled processes, or background workers** added.
- Filesystem collision resolution is stable for a given provider document-ID set. On a second phone, synthetic archive filenames become ordinary unique filenames.

## Limits / precautions

- Backup/restore across real devices requires adequate storage, stable access to all selected library files and a writable target SAF folder. If the destination provider unexpectedly renames created files, restore stops rather than falsely reporting success.
- A real cross-device test with the user's 61,368-file library and a complete Android APK build are not available in this environment. Tests use an in-memory SAF provider and a Kotlin host compiler; these do not replace physical-device validation.
- On the destination phone, select an empty writable folder before restore for the cleanest transfer. Retain an independent copy of the library and any previous verified backups until the new backup has been restored successfully.
