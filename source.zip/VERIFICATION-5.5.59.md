# Verification — 5.5.59

Host tests performed against the modified source (Android APIs stubbed where needed):

- `portable_restore_5_5_57_test.sh`: PASS, including interrupted library transfer/retry (missing files only), provider-renamed documents, identity collision safeguards, shared Obsidian vault, 65,540-entry ZIP64, selected extraction and stream fallback, checksum/copy checks, compression round trip. Backup engine and helper Kotlin compiled with host stubs after ANN changes.
- `restore_resume_schema_5_5_57_test.sh`: PASS, name-based migrated/fresh media_items column order, true mismatch rejection, component dependencies, pause gate and eight-table round trip with binary media embeddings.
- `BackupControls559Test.kt`: PASS for nine model asset groups, storage-budget calculation and ENOSPC classification, pause/resume, stop while paused, journal/operation-state recovery for Complete, Partial, Running (Interrupted), Stopped and Failed. Runner included. This is not a physical low-storage or Android service lifecycle test.
- Highlight navigation/controller, offline HTML scripture scroll routing, FTS search accuracy, model isolation, HNSW SQL, card separation, query embedding preservation and source archive checks: PASS.
- Database ownership and fast-search SQL scripts timed out at the short test budget. Two historical assertions refer to behavior/version superseded by 5.5.49 (search lifecycle delay / hard-coded version); not counted as passes.
- Settings -> service -> manager model selection and Stop/Pause/Resume wiring inspected. Android service and Compose runtime behavior not exercised in the host tests. No full Android build, end-to-end cross-phone restore, actual storage exhaustion, abrupt model install process-death recovery, battery or device runtime benchmarks verified.

Do not treat host simulations or byte-identical source preservation as a proof of all runtime behavior. Keep the existing backup until restoration is independently verified on a device. See change report for retry and model-selection semantics.
