# MarkVault 5.5.35 — investigate and reduce complete search latency

Version code 484. This update starts from the exact delivered 5.5.34 source.

The phone's latest report shows 11 seconds with reranking and 9.4 seconds without it. In the latter, query embedding takes 1.62 seconds, the HNSW graph 2,187.85 ms, vector scoring 1.13 seconds and unclassified work 4.44 seconds. The previous host kernel improvement did not establish the requested phone speed. This update addresses a verified database inefficiency and makes the remaining cost visible. It does not claim that 10 ms phone HNSW or a one-second complete search has been achieved.

## Database fix

Every completed search queries the first 20,000 note IDs to assign the existing first/second-library badges. The same partition query is also used by scoped retrieval. Its unchanged SQL is:

```sql
SELECT id FROM notes
ORDER BY lastModified DESC, id DESC
LIMIT :limit OFFSET :offset
```

Previously the notes table had no index matching this order. SQLite scanned the table and constructed a temporary sort. Because lastModified follows the content field in the note record, this query can traverse a large article table despite returning only IDs.

A new covering index on notes(lastModified, id) lets SQLite scan the index backward for the same descending order. The Room schema moves from 23 to 24 through an explicit additive migration. It creates one index, retains all columns and rows, and leaves every existing DAO query unchanged. SQLite maintains the index automatically on insert/update/delete. No embedding or HNSW/IVF rebuild is needed. The first database opening after upgrade creates the index once; that one-time migration cost is separate from later searches.

The exact production migration was tested on 42,507 notes with the frozen actual Room-generated v23 Note schema. The test verifies unchanged content hashes, identical partition IDs and ties, empty/out-of-range pages, edits, deletion, rollback, reopen, idempotent index creation and database integrity. The query plan changes from a table scan plus temporary B-tree to a covering-index scan. One regular host fixture took 59.58 ms versus 5.81 ms. A separate 16 KiB-body fixture took 153.24 ms versus 4.37 ms. These are host query timings; they do not identify how much of the phone's 4.44 seconds this query caused.

## Diagnostic changes

- Search setup measures initial metadata/detector setup.
- Index validation measures the existing HNSW header, embedding-count and watermark checks.
- Result fusion measures the existing hybrid preparation and ranking before optional reranking.
- Result labels measures existing final provenance and library-badge preparation.
- HNSW CPU displays graph-thread CPU time alongside elapsed HNSW graph time. A large elapsed-versus-CPU gap suggests scheduling or mapped-file waits; similarly large CPU and elapsed times indicate substantial active computation. This identifies the next investigation rather than proving a particular cause.

Other retrieval remains the residual outside the measured interval union. Nested CPU time is displayed as detail and is not subtracted or added again. Existing parallel stages still report overlap. The internal JNI response moves to version 3 to carry CPU nanoseconds; stored HNSW snapshots remain format version 2, with unchanged embeddings and keys.

## Behavior retained

HNSW graph traversal, M=16, construction settings, 4,800 exploration budget, candidate limits, scope rules, recovery, distance arithmetic and final FP32 scoring are unchanged from 5.5.34. The CPU clock does not cap, terminate or change a search. All original IVF code, embedding backends, reranker engines, Markdown/HTML readers, UI layouts, blue toggle, model synchronization, provenance and saved-search storage are retained. No accuracy reduction or delayed result work is used to reduce the displayed total.

The preservation guard restores eleven reviewed code/version/test deltas to exact 5.5.34 bytes before applying the earlier guards. It independently pins the new SQL fixture and test. This includes the original 5.5.24 checks for 563 method/policy blocks and 106 DAO queries. See VERIFICATION-5.5.35.md for the completed checks and build results.

After installing, the new timing card can identify whether remaining latency is active HNSW computation, waiting, model inference, fusion, database validation or result labels. Device measurements are still required to verify the requested total speed.
