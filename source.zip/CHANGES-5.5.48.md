# MarkVault 5.5.48 — Search recall and Question Awareness accuracy

Based on the installed GitHub-successful 5.5.47 source (versionCode 496). New versionCode 497.

## Confirmed source-level issues and corrections

1. **Over-strict FTS4 natural-language queries.** `Topics.literalPrefixQuery()` previously required filler words such as *who*, *were*, *the*, and *of*, and split a stray apostrophe in `e'sau` into separate tokens. Added a conservative, model-free `KeywordRecallPlanner` that uses the existing Question Awareness classifier for confidence and preserves the relationship/content terms. For `Who were the sons of e'sau?` the FTS query becomes `sons* esau*`. Negation remains; nonquestions retain their previous handling; exact quoted phrases bypass rewriting.
2. **First 500 FTS4 hits can hide a direct answer.** The existing Room SQL `MATCH :query LIMIT 500` does not sort by relevance. When a non-exact question fills that entire pool, a single focused `NEAR/8` query retrieves an additional bounded pool before the existing scorer/RRF. There is no extra retrieval query unless the primary pool is saturated. The original 500-hit results remain available.
3. **Question Awareness WHO-family templates were too generic.** `Who were the sons of Esau?` produced `the sons of Esau were`, `identity of the sons of Esau`, etc. For relationship-member questions, QA 2.0 now produces `sons of Esau`, `Esau sons`, `Esau children` (and equivalent daughters/children forms); both `sons of Esau` and `Esau's sons` constructions are supported. Other WHO categories are unchanged.
4. **Question Awareness could replace the semantic embedding query with an incomplete answer phrase.** Now primary semantic/HNSW retrieval embeds the *original* question. QA variants remain visible, weighted and searchable in the existing keyword/reciprocal-rank-fusion path. This avoids query-intent drift without a second expensive semantic inference.
5. **Exact search remains strict.** No additional proximity probe for quoted queries; matching is still restricted to exact FTS candidates in hybrid mode; exact phrase scoring does not use normalized question tokens.

## Preservation scope

- Untouched: HNSW/IVF index implementations, candidate rescoring, embedding models and chunking, model control, reranker, expansion engines/quotas, user-facing query provenance/color indicators, saved searches/backups, UI themes/cards, notifications.
- Added two Kotlin regression tests and one SQLite FTS4 integration test.
- No embedding or ANN index rebuild is required by this patch; it changes query construction and retrieval only.

## Limitations

These are verified code-level recall weaknesses, **not** proof that they explain every inaccurate search on the device. The actual user article corpus, local embeddings, HNSW index state and relevance outcomes cannot be measured from the GitHub source archive alone. Full Android Gradle compilation and on-device measurement remain necessary after upload.
