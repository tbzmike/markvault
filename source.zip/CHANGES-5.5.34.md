# MarkVault 5.5.34 (version code 483)

This update optimizes the native blue HNSW distance kernel. It retains the complete 5.5.33 source, including the previous query, reranker, scrolling, saved-search and build fixes, except for the five explicitly pinned native-kernel/version/test deltas. All Kotlin, JNI, database, IVF, Markdown and UI code is byte-identical to 5.5.33.

## Changes

- ARM64 sibling calculations load eight FP16 values at once, then perform the same low-half and high-half FP32 FMA operations. Each accumulator retains its original lane sequence and reduction order. This uses ARMv8-A conversion instructions; ARMv8.2 FP16 arithmetic is not required.
- Supported x86 CPUs transpose four siblings' products in registers and accumulate across siblings. The original per-vector addition order is retained, avoiding the explicit 32-product memory spill. AVX/F16C remains guarded by the existing runtime CPU check.
- Four cosine normalizations use SIMD square root and division. The original zero-vector, signed-zero, infinity, NaN and clamp behavior is retained. Unsupported architectures use the original scalar formula. No approximate reciprocal, fast-math, precision reduction or smaller search budget is introduced.
- Scalar FP16 reads use memcpy into an aligned value. This fixes undefined behavior when snapshot payloads begin at an odd byte offset, including dimension tails and recovery scoring.

M=16, efConstruction=128, the 4,800 exploration budget, candidate limits, graph edges, scope rules, traversal/admission order and exhaustive recovery are unchanged. Native index construction, persistence, mutation and search policy code is byte-identical. Persisted index format and internal JNI packets remain version 2. Existing embeddings and snapshots are compatible; this update requires no re-embedding or index rebuild.

## Measurement

The warm Linux x86_64 comparison uses GCC 13, -O3 and -ffp-contract=off on the same deterministic synthetic fixture: 42,000 articles, 210,000 chunks, 768 dimensions. The frozen 5.5.33 kernel is compared with the current kernel in alternating execution order. Both kernels receive the same queries, scopes and existing graph. Initialization is reported separately. The two timed rounds provide 48 full-library samples and 96 partition samples; a third round warms the fixture. All 360 ordered candidate/coverage/frontier/distance-count comparisons pass.

| Warm stage | 5.5.33 median | 5.5.34 median | 5.5.33 p95 | 5.5.34 p95 |
| --- | ---: | ---: | ---: | ---: |
| Complete ANN lookup | 9.05 ms | 8.17 ms | 11.12 ms | 10.76 ms |
| HNSW graph | 8.75 ms | 7.90 ms | 10.66 ms | 10.34 ms |
| Partition ANN lookup | 16.19 ms | 15.33 ms | 33.94 ms | 32.04 ms |

The full-library graph median improved by approximately 9.7%. Preparation was 209.63 ms versus 203.93 ms. Full-library graph ranges were 5.91–11.80 ms versus 6.45–13.14 ms, so not every latency statistic improved. A smaller 21,000-chunk, 128-dimension fixture did not show a meaningful median gain. These are host results, not Android phone measurements. The 10 ms phone graph target and one-second total search target are not verified. Total search also includes embedding, retrieval, full-precision scoring, optional reranking and result preparation; overlapping stage times must not be added together.

## Verification

- Native property checks pass: 22,720 fused/scalar distances; 324 bit-exact normalization edge cases; 1,152 norm/cosine cases; 300,000 dense/hash visits; 256 scope sets; 80,000 frontier updates. They also pass in an actual static Android ARM64 binary under QEMU and on an emulated x86 CPU without AVX/F16C. Emulator times are not performance evidence.
- AddressSanitizer and UndefinedBehaviorSanitizer pass for a 500-vector, 103-dimension snapshot at the existing odd payload offset, including mapping, filtering, updates, deletion and persistence. LeakSanitizer inspection is disabled in this container.
- Production JNI exports and actual Kotlin/JNI manager tests pass for model isolation, freshness, scope handling, updates, deletion, cancellation and atomic rebuild failures. Native full-precision scores match the Kotlin scorer bit-for-bit in 7,872 comparisons.
- Original IVF build/search/accuracy/model/edit/delete/reopen/failed-and-cancelled rebuild regression checks pass. Room ownership, WAL concurrency, database integrity, query projection and model-isolated/keyset query checks pass.
- Frozen 5.5.24 retrieval checks pass for 630 passages, 4,500 keyword hits and 118 chunk selections. Keyword/highlight checks cover 32 cases; toolbar/scroll behavior covers 20,000 events.
- Saved-search checks pass for backward-compatible timing metadata, 214 sessions with 347 hits each, exact report/count/order restoration, v1–v6 defaults, provenance, edits, deletion, retention and cancellation.
- Original-source guards pass for 264 byte-identical 5.5.24 files plus two reviewed changes, 563 protected original method/policy blocks and 106 DAO queries. All previous preservation layers pass. The new layer inversely restores each of the five reviewed changes to the exact 5.5.33 bytes and pins the frozen benchmark oracle. Embedding and reranker model inference is unchanged and was not rerun with model assets in this update.
- Source archive checks cover fixed past timestamps, time zones, reproducibility, executable permissions and cache exclusions. Packaging validates ZIP integrity and every archived source byte.

Run bash tools/run-hnsw-checks.sh for native/source checks. Its existing optional JNI/Kotlin, saved-search and model fixture variables enable their respective suites. tools/tests/hnsw_speed_benchmark.cpp now compares against the exact frozen 5.5.33 kernel. See VERIFICATION-5.5.34.md for the final Android build and archive results.
