# MarkVault 5.5.45 — CPU and Thermal Guardrails

Baseline: exact `source.zip` Git blob `01cafe1ac1ec71cdfaa4594c264caa757a0da182`, corresponding to the latest successful GitHub Actions release build for 5.5.44 (October 15, 2026). No source removals.

## Verified code-path findings

- `AppViewModel` previously reacted to the *initial* `EmbeddingProgressBus.isRunning=false` StateFlow emission as a finished build; it refreshed counts, invalidated index caches, and bumped the HNSW revision even though no embedding work had ended.
- HNSW automatic maintenance enumerated installed models and could start a foreground embedding job immediately after ViewModel initialization (if the snapshots needed attention).
- The selected-model ANN/HNSW self-healing paths could also start automatic embedding work at launch.
- Graph prewarming loaded HNSW on startup, even when the phone was on battery or in thermal/power-saving conditions.
- Automatic media embedding work could process 25 media entries every 30 seconds while the app was visible and charging; it did not check thermal throttling.
- On the media player screen, subtitle/transcript content was re-read from disk every 1.5 seconds while no complete transcript was available, including if the screen was not foregrounded. Two playback clocks also polled frequently when playback was paused.

## Targeted changes

1. Discard the initial embedding-state emission for completion processing (`drop(1)`), preserving genuine later `true → false` service completions.
2. Defer cold-start HNSW automatic maintenance by 60 seconds; run only when the app is visible, power saver off, charging, no competing search/embedding work, and thermal status below `THERMAL_STATUS_MODERATE`. Explicit user-initiated model changes and manual builds still start immediately.
3. Postpone optional HNSW prewarming by 15 seconds; cancel stale warmup delays when model/preferences change. Skip when on battery, thermally warm, busy, in power saver, or hidden. Direct search still loads its index on demand.
4. Reduce automatic media-embedding batch size from 25 to 8, extend the interval between batches from 30 to 90 seconds, and move app-start scheduling from 10 to 90 seconds. Subsequent media-cache scheduling uses a 60-second delay. Add thermal and embedding-service conflict checks before and during each batch.
5. Scope media-player polling to the visible lifecycle. Keep 350/400 ms position refreshes while actively playing, but reduce paused polling to 1500 ms. Move transcript file reads off the UI thread and back off incomplete-transcript checks to 8 seconds after two fast attempts. Stop polling once the full transcript is available.

7. Reduce the startup URL-harvest Room projection from complete article bodies to their first 4096 characters, matching the original extractor’s existing prefix limit. This preserves which rows are selected and what URLs can be extracted, while dramatically reducing how much article text is allocated and copied.

## Intentionally preserved

- Manual embedding/index builds, searching and ranking, the HNSW index and its native C++ implementation, rerankers, T5, LLM, synonyms, Question Awareness 2.0, search-result colors and numbering, card borders, saved search persistence, media playback and transcription, and emergency memory cleanup.
- Automatic maintenance is *deferred* rather than permanently disabled, but maintenance skipped because the phone is on battery/hot will require a later eligible app launch or an explicit build request to be retried. The auto-index policy is intentionally conservative to minimize thermals.

## Limits

These are source-verified optimizations, not on-device CPU-temperature measurements. An Android compile and CPU/thermal profiling on the device are still needed. Model inference and genuinely user-requested indexing can legitimately use significant CPU; this update does not throttle user-requested work.
