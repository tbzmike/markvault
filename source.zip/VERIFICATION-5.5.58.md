# Verification: MarkVault 5.5.58

## Executed checks

- `html_scripture_scroll_5_5_58_test.py`: PASS. Extracted actual Kotlin link-handler and scroll-capture functions compiled and ran against fake Android/VM routing interfaces. Verified repeated identical and different popup URLs, JW Library installed/fallback, detected offline chapter and online verse, external routing, resource URL passthrough and unchanged native position. Real lexical and semantic auto-scroll callbacks executed in Node: normal initial auto-scroll allowed, suppressed after a link tap, existing manual-navigation and cancellation guards retained. Saveable position and native restore checked at source level.
- `restore_resume_schema_5_5_57_test.sh`: PASS. Named column mapping (including changed physical column order), true mismatch rejected, binary vector data, selection dependency rules, pause gate, eight-table portable state round trip.
- `portable_restore_5_5_57_test.sh`: PASS. Actual backup Kotlin components compiled using host stubs. Interrupted retry reuses identical data, provider MIME/renaming, file/folder conflicts, shared Obsidian, ZIP64 (65,540 entries), selective/streaming extraction and level-9 lossless compression.
- `highlight_navigation_5_5_51_test.py`, `highlight_controller_5_5_50_test.py`, `search_accuracy_5_5_48_sql_test.py`, `model_isolation_5_5_46_test.py`, `hnsw_sql_test.py`, `search_result_card_separation_test.py`, `source_archive_test.py`: PASS.
- Inspected Settings selection calls, selection passed as service extras, pause/resume event handling, final SQLite/settings validation and cold-start restore application. Entire backup/restore code and tests retained byte-for-byte. This is wiring inspection in addition to host regression tests; not a real Android UI test.
- Verified baseline ZIP Git blob against the successful GitHub run; exact source archive comparison after packaging and ZIP byte integrity check.

## Limits

No Android SDK or Gradle installation available. The full 5.5.58 Android build, actual WebView scrolling/focus and navigation-back behavior on Android, and a real large-library cross-device restore remain unverified. Fake router and JS tests cannot model all Android lifecycle/rendering behavior. The existing 5.5.57 APK build succeeded; that does not verify this new version. No claim that the 5.5.57 backup/restore works on every provider or device. Recommended device test: scroll far down in offline HTML, open and close several different/same scripture links (floating popup and full screen), check current position, manually navigate highlights, and run a selective backup/restore and retry on the same archive without deleting the original library.
