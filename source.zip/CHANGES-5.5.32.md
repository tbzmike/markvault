# MarkVault 5.5.32 (version code 481)

## Faster blue HNSW

This update accelerates the secondary HNSW lookup while preserving its candidate coverage and full-precision article scoring. The existing IVF engine, blue toggle, mutual exclusion, library/embedding synchronization and all installed model support remain intact.

- A query-only maximum heap replaces repeated shifts through the 4,800-entry sorted passage frontier. Distance radii, admission conditions, graph visitation order, scope predicates and exploration budget remain the same. The ordinary search wrapper and graph construction keep their original sorted-buffer behavior. Stored graph format and connectivity/efConstruction remain unchanged.
- Immutable mapped indexes cache each FP16 vector's FP32 squared norm once, using the original arithmetic order on each ABI. Query evaluation reuses these norms instead of recalculating them for every comparison. Mutable builders retain the original calculation, and mutations/opening invalidate cached data.
- Native query observation, article aggregation and ranking reuse per-handle buffers. Epochs keep previous queries and scopes separate. Index/model/generation changes reset the data.
- Sorted scope IDs are represented by exact contiguous ranges. Large library partitions avoid binary-searching tens of thousands of IDs for each admitted passage. Random, sparse, duplicate and boundary memberships retain identical behavior.
- On supported x86 devices, hardware FP16 conversion and vector multiplication retain the original scalar addition order. Runtime CPUID and OS-aware AVX checks gate this path. ARMv8-A keeps its existing NEON arithmetic; no newer ARM instruction requirement is introduced.
- The selected model's read-only index is prepared on an IO worker after startup, model selection or snapshot publication, subject to the existing measured memory policy. Preparation pays the mapping/norm/page-read cost once. Every lookup still checks the current file generation and the existing DB count/watermark freshness checks. Emergency cleanup continues to unload it.
- Search reports retain the full ANN lookup duration and add nested **HNSW graph** and, when applicable, **HNSW recovery** timings in milliseconds. These native substage times are measured with a monotonic clock. They are not subtracted twice from the search total. Cold preparation and scheduling/waiting remain included in the full lookup duration when they occur during search.

## Measurements and limits

A deterministic synthetic fixture contains **42,000 articles, 210,000 chunks and 768-dimensional vectors**, with M=16 and efConstruction=128. Both versions search the same stored graph. Twenty-four queries include stored-vector samples and unrelated vectors; each runs across all notes, both library partitions, sparse and empty scopes for three rounds. All **360 comparisons** preserve the exact ordered article candidates, recovery flag, frontier and computed-distance count from delivered 5.5.31.

One host run using Android NDK Clang 18.0.3, targeting the Linux x86_64 host on an AMD EPYC 9V74, measured:

| Warm full-library stage | Minimum | Median | 95th percentile |
| --- | ---: | ---: | ---: |
| 5.5.31 complete ANN lookup | 13.61 ms | 19.00 ms | 32.71 ms |
| 5.5.32 complete ANN lookup | 8.76 ms | 12.63 ms | 16.34 ms |
| 5.5.32 native graph traversal | 8.47 ms | 12.09 ms | 15.86 ms |

Preparation was measured separately: approximately 237 ms for 5.5.32 in this run. These figures demonstrate individual warm HNSW queries below 10 ms on the test host. They do not establish a 10 ms median, maximum, phone result, or complete Deep Thinking search. Query embedding, Room scoring, reranking, keyword/media retrieval and rendering retain their own costs. A fresh phone search is required to measure the installed version; saved searches keep their original durations.

Smaller fixed exploration budgets were tested and rejected because they missed strong matches on some unrelated/scoped queries. The shipped version keeps the previous coverage rather than exchanging accuracy for the requested speed.

## Verification

Passed regression checks include:

- 1,152 cosine comparisons against the original metric, including cached norm slots, vector-address boundaries, dimension tails and query boundaries; 256 scope sets and 80,000 heap-frontier updates. The same checks also pass as an AArch64 Linux-musl binary under QEMU; emulator timing is not used as a performance measurement. An x86_64 run emulating a CPU without AVX/F16C also passes the scalar-fallback checks.
- Existing 80-case native graph comparison against 5.5.26 on all/first/remaining/sparse/empty scopes, plus the 360 comparisons against 5.5.31 at both test scales. Article-oracle recall checks continue to pass.
- Actual Kotlin/JNI manager tests for preparation, warm lookup, model switching, generation changes, same-count edits, deletion/insertion, cancelled/failed atomic rebuilds and scopes. The internal JNI candidate packet is version 2 to carry native timing fields; persisted HNSW file/header version remains 2.
- Original IVF build/search/probes, same-count edits, deletion, model separation, reopening and failed/cancelled rebuilds. AnnIndex.kt and original IVF logic are unchanged.
- 7,872 bit-identical FP32 scoring comparisons; frozen keyword/chunk-ranking behavior; Room-owned vector reads, concurrent WAL checkpoints/writes and integrity; 13 matching native JNI exports with no independent SQLite engine.
- Original result keyword/highlight behavior on 32 cases, original toolbar behavior on 20,000 scroll events, and saved-search timing/backward compatibility. The 214-session/347-result saved-report fixture preserves counts, metadata, ordering and exact full restoration.
- Original 5.5.24 guards: 264 byte-identical files plus two reviewed UI changes, all 563 protected original method/policy blocks and 106 original DAO queries. Exact inverse-delta guards cover eight HNSW/telemetry/preparation source files and four amended test files against 5.5.31. Markdown/HTML readers, navigation, backups, settings, library indexing, model inference and existing UI fixes remain protected.
- Reproducible ZIP integrity, exact source bytes, executable permissions, excluded build caches and fixed past timestamps.

## Build and use

Install 5.5.32 over the existing app and run a new search with blue HNSW enabled. Existing embeddings and HNSW/IVF indexes are compatible; rebuilding or re-embedding is unnecessary. Preparation is automatic for the selected blue model when memory permits.

Run `bash tools/run-hnsw-checks.sh` for the included checks. Kotlin/JNI tests use the existing compiler/JNI environment variables; saved-report tests additionally require JSON.org and Gson 2.11.0. `tools/tests/hnsw_speed_benchmark.cpp` compares against the frozen 5.5.31 algorithm; provide an article fixture created by the existing native article benchmark.

Both `:app:assembleDebug` and `:app:assembleRelease` completed successfully using Gradle 8.7, Java 17, SDK 35, NDK 27.2.12479018 and CMake 3.22.1. APK inspection confirms version 5.5.32/code 481, valid signatures and arm64-v8a/armeabi-v7a/x86/x86_64 HNSW libraries. The actual packaged release libraries expose the same 13 JNI methods. Local validation ran the two variants sequentially with a 2 GiB Gradle heap and in-process Kotlin compilation after an initial concurrent validation run exceeded the workspace memory limit. Those are validation-command options; the project's existing build and app memory settings remain intact. Compiler/deprecation and original Room query warnings remain warnings.
