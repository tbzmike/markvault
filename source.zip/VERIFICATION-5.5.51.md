# MarkVault 5.5.51 — Verification

## Passed locally

- Verified 5.5.50 source ZIP as starting baseline; no original source paths deleted.
- Standalone Kotlin compilation of `BackupManager.kt`, `PortableBackupState.kt`, `PortableBackupFiles.kt` against Android and SQLite interface stubs: **PASS** (catches Kotlin syntax/type errors in these files; it is NOT the full Android build).
- Functional Kotlin streaming round trip for all eight extra Room tables (including media vector BLOBs, nullable and floating fields), article UI state, and corrupt-header rejection: **PASS**.
- Node.js simulated WebView DOM navigation across nested marks and complete DOM replacement: **PASS**. Consecutive taps move one highlight at a time; manual/cancel flow prevents extra scrolls.
- Native JavaScript syntax check for `render.js`: **PASS**.
- `portable_backup_5_5_51_test.py`: source-level backup coverage, validation, scope and no-extra-worker guards: **PASS**.
- Previous model isolation/synchronization controls, HNSW SQL, Esau retrieval recall, and search-result card separation tests: **PASS**.
- Final source ZIP: integrity, build version, archive contents, no duplicates and no unsafe paths checked by packaging script.

## Not verified

- Full Android `assembleRelease` compilation (Android SDK/Gradle toolchain unavailable here).
- Real phone WebView arrow navigation following all types of highlights.
- Real SAF file-provider restore and multi-GB backup/restore across two Android phones.
- Native HNSW index binary portability between different CPUs/Android versions.
- Restore failure recovery from sudden device shutdown or storage loss in the interval between database commit and all file installations. Individual file and DB stages have their own checks/rollback, but the entire cross-store operation is not one atomic transaction.

## Maintenance

- The older version-locked historical test scripts still check original versionName/versionCode and will reject current versions; they are retained unchanged. New tests use 5.5.51.
- No search, HNSW ranking, embedding algorithms, model catalog, chunking, or battery management logic changed outside the scoped backup-vs-embedding-service conflict guard.
