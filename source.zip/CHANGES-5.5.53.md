# MarkVault 5.5.53 — Fast portable-backup recognition and visible validation

Baseline: 5.5.52 (version code 501). New version: 5.5.53 (code 502).

## Root cause

In 5.5.52, selecting **Restore…** called `BackupManager.readManifest()`.
For every v4–v7 portable backup it first called `validateV4Archive()`, which
**decompressed and hashed every file, model asset and embedding stream** just
to display the confirmation dialog. A large 61,000+-article archive therefore
appeared unresponsive before the user saw “validating.” The same archive was
then scanned again when restoration began. No original data was damaged by
the delay itself.

## Changes

1. For seekable Android `content://` documents, `readManifest` opens a temporary
   read-only file descriptor and uses `ZipFile`'s central directory to locate
   `manifest.json` directly, even when the manifest is at the end. Only the
   manifest is decompressed; the library and all embedding/model payloads are
   *not* decompressed during selection. The descriptor and ZIP are closed.
2. The quick preview checks the MarkVault format, schema, mandatory streams,
   allowed entry names, duplicate paths, declared sizes, checksum-table shape,
   and protected-entry counts. Preview is not treated as verified contents.
3. The **full original SHA-256 verification is retained** after the user
   confirms Restore and before the library or database is replaced. Progress
   reports the number of verified entries and an indicative stage percentage,
   throttled to at most approximately twice per second without adding timers.
4. `applyBackup` avoids an unnecessary preliminary full streaming extraction
   when the seekable manifest preview is available.
5. The Settings page immediately displays “Reading backup information…” and
   an indeterminate activity bar after a ZIP is selected. Errors are visible,
   and duplicate restore-picker interactions are blocked during inspection.
6. If the provider exposes only a non-seekable pipe (common with cloud files),
   MarkVault falls back to the existing streaming validation path. The activity
   bar remains visible; the full scan can still take significant time.

## Compatibility and preservation

- **No change** to portable backup format v7, database schema 24, output entry
  names or checksums. Backups already created by 5.5.51 and 5.5.52 remain
  supported; **no new backup is required** for this UI/inspection fix.
- Legacy v1–v6 restore and the full portable restore path remain available.
- Original files and folders, model assets, all-model article/media embeddings,
  chunk metadata, settings, and HNSW/IVF files are untouched by this patch.
- No search, Question Awareness, highlight, battery, embedding sync, or model
  management code changed. No background services, workers or polling added.

## Verification limitations

The central-directory preview function was type-checked using the available
Kotlin host compiler and Android interface stubs, and a synthetic ZIP test
verified seeking directly to the last manifest entry. It has not yet been
measured against the user's real archive or on their specific Android content
provider. Complete Android compilation is unavailable in this environment;
GitHub Actions must confirm a green APK build before installation.

The currently running validation on 5.5.52 is unaffected by this source update.
