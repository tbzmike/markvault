# MarkVault 5.5.49 — Verification

## Preservation audit against source.zip 5.5.48

- Original files: 433
- Byte-identical: 428
- Modified: 5
- Removed: 0
- New regression script: `tools/tests/idle_completion_5_5_49_test.py`
- Original ANN / HNSW / IVF / data storage / backup / model files unchanged byte-for-byte.
- Modified: app/build.gradle.kts, app/src/main/java/com/tebogo/markvault/AppViewModel.kt, app/src/main/java/com/tebogo/markvault/MainActivity.kt, app/src/main/java/com/tebogo/markvault/service/BackgroundWorkService.kt, app/src/main/java/com/tebogo/markvault/ui/SearchScreen.kt

## Passed targeted host-level checks

- `idle_completion_5_5_49_test.py`: single conditional completion GC, manual memory path, no idle timer, no startup index warmup, durable save order, foreground-only media task.
- `search_accuracy_5_5_48_sql_test.py`: 500-hit retrieval fallback and quoted exact search.
- `model_isolation_5_5_46_test.py`: embedding model selection/disable/deletion isolation.
- `search_result_card_separation_test.py` and `search_result_card_visual_test.py`: card readability.
- `fast_search_sql_test.py`, `hnsw_sql_test.py`, `database_ownership_test.py`, `idle_url_harvest_5_5_45_test.py`: DB, ANN, and memory-reduction compatibility.

## Historical scripts

The following historical tests hard-code their version number and therefore fail the version assertion on later releases: `idle_cpu_5_5_45_test.py`, `Integrity547Test.py`. They were not silently marked passed or modified to suppress the assertions.

## Unverified

Full Android Gradle compile unavailable locally; GitHub workflow still required. No on-device CPU, battery, temperature, OOM, or wake-lock measurements.
