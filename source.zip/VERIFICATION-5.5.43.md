# MarkVault 5.5.43 verification report

- **Baseline archive:** `/mnt/data/source.zip` as supplied for 5.5.42 build fix.
- **Archive comparison:** 408 baseline files; 404 unchanged byte-for-byte; 4 existing files modified (application version, AppViewModel, SearchScreen, and a version-aware card test); zero deleted.
- **New files:** 1 standalone memory policy, 1 Kotlin policy regression, 1 source-lifecycle regression, and 2 update/verification notes.
- **Kotlin runtime test:** 11 safety scenarios PASS, including LLM/T5 residency, Java-heap pressure, low Android memory, low available memory, and native PSS over budget.
- **Search lifecycle source test:** PASS; routine-teardown skip/cancellation timing; emergency paths; scope membership validation; media calls; saved-search persistence; expansion indicators.
- **Existing regression tests:** Card separation and 20-theme contrast PASS, 42.5k-note scope SQL PASS, HNSW SQL PASS, fast search SQL PASS, keyword revisions PASS, query embedding preservation PASS, database ownership PASS, archive reproducibility PASS.
- **ZIP integrity and content preservation:** Verified by packaging and independent archive comparison.
- **Android compile:** NOT verified. This environment lacks the Android SDK and Gradle; GitHub Actions `assembleRelease` is necessary before the user installs an APK.
- **On-device performance/lag:** NOT measured; the new logcat tag `MarkVaultPerf` records routine teardown decisions, release time and saved-search persistence time.
