# MarkVault 5.5.40 — Faster LLM query-expansion search

**Baseline:** Complete MarkVault 5.5.39 source, including restored multi-source query-expansion colors and provenance. Version code 489.

## Cause of the delay

The LLM search expander used a chat-style prompt and waited for `LlmManager.generate(...).toList()` to reach the model's natural end of output, even after the requested number of valid search-query lines had already been emitted. The old non-memory-optimized path also permitted **120 s to load + 180 s to generate** before falling back. HNSW runs only AFTER this synchronous generation, so even a 7 s HNSW search could appear to take 30–60 s. HNSW disabled can additionally invoke the preexisting full-vector-scan path, which is independently expensive.

## Changes

1. **Early-stop streamed expansion**: a bounded `LlmStreamAccumulator` validates complete lines as the LLM streams and ends output collection once the user's chosen number of relevant, deduplicated paraphrases is available. Early termination uses the existing LiteRT-LM Flow lifecycle and its native callback-thread drain, then unloads the model.
2. **Keep completed partial results**: if a generation deadline is hit, use only **fully delivered, validated** query lines. Never turn an unfinished stream fragment into an FTS query. No change to the original query, query weighting, user-controlled expansion count, or provenance source labels.
3. **Shorter search prompt**: preserve the query topic and key names without long instructions intended for chat. Reduces prefill work for slow CPU models.
4. **Bound search-only generation**: non-memory-optimized model load capped at **35 seconds**, generate capped at **28 seconds**, instead of 120 and 180 seconds; memory-optimized behavior remains 15 s / 5 s. Actual runtime may exceed these bounds if a native JNI call does not cooperate with cancellation or unload; no hard real-time guarantee.
5. **Do not reuse failed empty expansions as successes**: zero-query LLM outputs are left in history for diagnostics, but not reused as a permanent result cache. Nonempty, model-matched expansions retain the existing fast cache path.
6. **Profile the expensive stage**: record separate `Model expansion` timing in the existing search timing trace for submits, making the source of the slowdown more visible.
7. **Cancellation cleanup**: guarantee the usual unload attempt on a noncancellable coroutine context after early flow termination, timeouts, and user cancellation.

## Preserved

- HNSW / IVF / full-scan choice, ANN index and graph files, scope filtering, semantic embeddings, ranking/RRF, cross-encoder reranking and accurate search.
- LLM master on/off setting, `0` expansion budget, exact query budget, T5-base and built-in synonym selection, fallback settings, question-awareness, user query history and caching by model.
- Existing source-specific color indicators and expandable generated-query legend in result cards and saved searches.
- All other note, document, media, highlight, workspace, backup and UI features unchanged.

## Caveat

This is a targeted source update. Pure Kotlin/JVM regression tests and a type check of the edited expander run in this environment. The Android SDK/Gradle/native LiteRT-LM runtime and actual on-device model are unavailable here, so a full APK build and measured Android latency are **not** claimed. Cold model loads and HNSW-disabled full-library scans can remain slow; better/worse wall times depend on the selected model and device.
