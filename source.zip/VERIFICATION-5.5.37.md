# MarkVault 5.5.37 verification

## Build and identity

- The working source was restored from the delivered 5.5.36 ZIP, SHA-256 `3bb57853b193a935e1c069f79e473fa173f3de02d1ab1f34df62f6cf24765dda`. The preserved copy supplies the independent graph oracle and every reviewed inverse delta.
- Version 5.5.37 / code 486; Room schema 24. HNSW snapshot format 3, with format-2 reading and conversion retained. Candidate packet version 4; the same 13 JNI entry points.
- `:app:assembleDebug :app:assembleRelease`: BUILD SUCCESSFUL in 14m 43s; 102 tasks executed. Gradle 8.7, Java 17, SDK 35, NDK 27.2.12479018 and CMake 3.22.1. A final incremental invocation verifies the completed source.
- Both APKs contain arm64-v8a, armeabi-v7a, x86 and x86_64 native libraries. Signature, version, JNI-export count, ELF machine and minimum 16-KiB LOAD alignment are checked. ARM64 binaries contain SDOT functions; runtime capability gating is exercised separately below. APKs and caches are excluded from source.zip.
- The actual generated debug/release Room implementations retain Room-owned vector cursors and the `notes(lastModified,id)` covering index. No schema or DAO query changes were made in this version.

## Compact graph and compatibility

- Frozen 5.5.36 writer versus new converter: graph/link/key/slot bytes after the vector metadata are identical. The vector matrix is exactly half the FP16 size. A genuine tombstone is included; present-key counts are checked through a mutable key lookup.
- Read-only and mutable reopening, insertion/deletion, persistence, byte-identical repeated SQ8 saves, exhaustive sparse/empty scopes, zero vectors, finite extreme/subnormal encoding, invalid input and truncated snapshots: PASS.
- 3,520 signed-integer scalar/SIMD comparisons per run, dimensions 1–2048 including odd tails and -128 products: PASS. Reciprocal normalization and four-vector finishing match reference cosine within 4e-7. Integer sums remain within their declared range.
- Actual Android NDK ARM64 binaries under QEMU: SDOT backend on `max` and widening-NEON backend on `cortex-a53`, including complete conversion/mapping/delta/scope/corruption tests: PASS. ARM32 scalar backend with the same complete tests: PASS. Host x86_64 without AVX/F16C, using SSE2: PASS. Emulator timing is not used as phone-performance evidence.
- The actual Kotlin manager and JNI bridge open an index produced by the frozen 5.5.36 writer. Automatic format conversion, unchanged dimension/count/watermark, model separation, reuse without reconversion, restored format-2 backups, injected atomic-rename failure and FP16 fallback: PASS. The fallback releases the failed compact handle before reopening FP16.
- A model builder holds its writer mutex while yielding to an active search. Legacy queries defer conversion and complete without waiting for that mutex; conversion succeeds after the builder is cancelled: PASS. This tests the search/background-builder deadlock boundary.
- Existing Kotlin/JNI fresh builds, freshness checks, same-count edits, deletion/insertion, model synchronization, scope filtering, reopen, failed/cancelled builds and complete atomic snapshots: PASS. New builds and incremental saves use compact snapshots.
- AddressSanitizer/UndefinedBehaviorSanitizer on odd-offset snapshots, conversion, reciprocal math, update/delete, persistence and corrupted payloads: PASS. LeakSanitizer inspection disabled.

## Full-scale speed and quality

The fixture contains 42,000 generated articles with five chunks each: 210,000 vectors at 768 dimensions. The frozen 5.5.36 implementation builds one FP16 graph. The new writer converts that same graph, preserving all edges. Queries include 12 sampled passages and 12 unrelated random vectors, with full, first-20,000, second-22,000, sparse and empty scopes. Three alternating old/new trials yield 360 breadth/coverage/scope comparisons; timing excludes the first warm-up round. Recall compares each candidate pool with an exhaustive FP32 best-passage article oracle. No candidate budget is reduced.

| Graph measurement | 5.5.36 FP16 | 5.5.37 SQ8 |
|---|---:|---:|
| Full-library median | 8.100 ms | 5.237 ms |
| Full-library p95 | 11.404 ms | 7.429 ms |
| Full-library thread CPU median | 8.098 ms | 5.234 ms |
| Partition median | 15.347 ms | 10.235 ms |
| Partition p95 | 34.560 ms | 22.774 ms |
| Native index file bytes | 353,750,413 | 192,470,413 |

Median full-library graph latency decreases about 35%; the index file decreases about 46%. FP16-to-SQ8 conversion takes 882 ms on this host, separately from graph timing. On-device conversion may take longer and occurs once per legacy snapshot.

| Mean candidate recall, 72 FP32-oracle trials | FP16 | SQ8 |
|---|---:|---:|
| Top 10 | 85.139% | 87.778% |
| Top 50 | 85.361% | 87.861% |
| Top 200 | 85.326% | 87.528% |

These are approximate candidate pools before exact scoring. Mean recall improves, but individual candidate lists can worsen: one unrelated full-scope random query falls from 10/50 to 8/50 and 75/200 to 65/200. The benchmark prints these declines. Its aggregate guard requires recall at each tested size to remain within 0.5 percentage points of the old graph. The small 21,000-chunk/128-dimension fixture retains 100% mean recall at all three sizes. Neither fixture establishes accuracy on the user's embeddings.

Reproduce the full comparison by compiling `tools/tests/hnsw_sq8_benchmark.cpp` with the same C++17, `-O3`, `-ffp-contract=off`, pthread and project/vendor includes used by `tools/run-hnsw-checks.sh`, then running the executable with `42000 768 /path/to/fixture-directory`. Existing fixture files are reused. Fixture construction, conversion and mapped preparation are separate from timed traversal.

## Preserved features and packaging

- The full native/source/Kotlin/JNI/Room/IVF/keyword/UI/saved-search suite passes. Legacy FP16 behavior still matches the prior oracle over 360 exact candidate/coverage/frontier/distance-count cases; SQ8 has its separate approximate-recall checks.
- Exact FP32 result scoring remains unchanged from 5.5.36. JNI grouped/tail/invalid score comparisons and 7,872 native-versus-Kotlin bit comparisons pass. The actual ViewModel method matches the frozen 5.5.35 rankings, scores, ties, model isolation, Stop Search boundary, cursor-error fallback and cancellation/closure behavior with native scoring available and absent.
- Original IVF build/search/accuracy probes, same-count edits/deletion, model separation, reopen, failed/cancelled atomic rebuilds: PASS. Its source, projection reads and scalar scoring route are retained.
- All previous preservation layers, the reviewed 5.5.36 inverse deltas and new graph/test pins: PASS. The guard checks 563 protected original method/policy blocks and 106 original DAO queries. Original Markdown/reader/library/backup/UI code is retained. Query and reranker inference code is byte-identical to 5.5.36.
- Original keyword/filter/highlighting tests, 630 coherent passages, 4,500 keyword hits and 118 chunk choices: PASS. Original toolbar behavior over 20,000 scroll events: PASS.
- Saved timing roundtrip/v5 compatibility, 214 sessions with 347 hits each, exact report metadata/counts/order, unchanged complete files, v1–v6 defaults, provenance, edits/deletion, retention and cancellation: PASS.
- Source ZIP fixed timestamps, timezone safety, permissions, cache exclusion and reproducibility: PASS. Packaging checks every member against the working source, retains every baseline file, and reruns the preservation guard from the extracted archive.

No phone was connected for end-to-end speed or live UI testing. Real ONNX inference was not rerun; its code and assets were not changed. The one-second total-search and 10-ms on-device graph targets remain unverified. Host graph measurements do not establish phone latency or complete-search speed.
