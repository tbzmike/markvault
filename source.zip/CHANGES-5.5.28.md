# MarkVault 5.5.28 (version code 477)

The supplied phone report measured a completed 6.1-second search over 42,505 notes: L12 reranking 3.35 s, keyword retrieval 1.55 s, query embedding 1.23 s, HNSW lookup 0.40 s, and vector scoring 0.56 s. Stages overlap. This update targets the expensive work outside the graph as well as vector transfer.

## Changes

- Blue HNSW reranks the same selected L12 or L6 model through up to four independent ONNX sessions. Each session has exactly one inference owner, retains the existing 256-token cap, and receives the same unpadded query/document pair. No reduction to the 30-document window or replacement of L12 with L6. Default optimization and memory patterns remain unchanged. The original serial engine is retained for IVF and for insufficient memory or failed worker preparation.
- Prepare the blue reranker concurrently with query/keyword retrieval. Warm workers are reused when the existing measured-memory policy permits. Worker allocation checks available memory, heap pressure, low-memory status, and CPU count. Explicit free-memory actions, navigation cleanup, engine/model changes, cancellation retirement, and emergency teardown release the workers safely. Native sessions are never closed in the middle of their inference.
- Score stored FP32 passage vectors directly in a short-lived read-only SQLite/WAL reader. Only article IDs, winning chunk indices, and exact score bits cross JNI. The original Room/vector-scoring path remains the fallback. Room continues to own note and embedding writes and migrations; model IDs and chunking are unchanged. The separate keyword-cache revision triggers are described below.
- Compile coherent-passage and keyword ranking expressions once per query. Reconstruct only the winning 350-word chunk rather than allocating every chunk in each reranked article. Preserve the original phrase/intent scoring, tie order, snippets, 150-keyword-hit cap, and final relevance calibration.
- Reuse exact keyword queries for up to three minutes in an eight-entry cache. Notes insert/update/delete triggers increment a small auxiliary revision atomically with each write, preventing stale results after library changes. No replacement FTS index or FTS query semantics. IVF continues to use its original keyword path.
- Read existing exact reranker-cache entries before starting workers, so the cache's coalescing mutex does not serialize independent inference. Preserve model-asset revision checks and cancellation behavior.
- Include overlapping reranker preparation in the saved-search timing report. Completed-search timing still includes final reranking.

## Verified

- Real catalog L12 and L6 ONNX models, using the app's ONNX Runtime 1.19.2: production worker scores have zero logit difference and identical ranking to the original production serial engine across five queries and 30 documents per query, including 256-token truncation, count questions, non-English text, and punctuation. In-flight unload/cancellation, model/revision reload, missing models, and empty inputs pass.
- Isolated short-document L12 profile: default serial 30-pair inference approximately 255 ms; four independent single-thread sessions approximately 78 ms (about 3.3 times faster). This is a desktop inference benchmark, not a phone search promise.
- Frozen 5.5.24 differential: 630 coherent passages, 4,500 keyword hits, and 118 winning-chunk/invalid-index cases match exactly.
- Native SQLite rescoring: 4,200 bit-exact article maxima and winning chunks across dimensions 1, 4, 100, 384, 768, 1024, and 2048. Committed WAL edits/deletions, model separation, invalid vector lengths, missing databases, empty scopes, and locked-database fallback pass. Production Kotlin/JNI packet decoding and SQL parameter binding also pass. The synthetic 3,000-vector, 600-article, 768-dimension native read/scoring pass took approximately 7.5 ms on the desktop.
- Full native/Kotlin/SQL regression suite passes: original IVF build/search/accuracy/edit/delete/reopen/cancellation, HNSW sync/model/scope/atomic snapshots, keyset media and metadata queries, exact FP32 arithmetic, cache TTL/LRU/copy/invalidation/coalescing, work priority, and saved-search compatibility.
- 268 files remain byte-identical to 5.5.24, including the IVF engine and Markdown/render/export/viewer assets. All 563 pinned original method/policy blocks and 106 original DAO queries pass the preservation guard; only explicit additive blue lifecycle/cache hooks are normalized for the original-block comparison. 312 delivered 5.5.27 files remain byte-identical, including embedding/index synchronization and the blue exclusive toggle UI.
- Actual Android ARM64 native build passes with NDK 27.2.12479018, CMake 3.22.1, API 26. All 14 JNI exports exist and ELF load segments have 16 KB alignment. A second Ninja build reports no work, with no repeated CMake regeneration.
- Source packaging verifies every archived byte, past timestamps, executable permissions, reproducibility across time zones, and exclusion of build caches.

The complete Android APK build did not finish: this environment blocked access to required dependency downloads before app Kotlin compilation. The Android ARM64 native build and the extracted-source regression suite passed, but a successful complete APK build and device UI run are not claimed. Android build configuration and existing dependencies remain unchanged apart from the app version.

Subsecond completed searches on the user's phone are not yet measured. First-use model loading, different query lengths, hardware, library updates, and memory pressure affect latency. Repeated unchanged queries can reuse embeddings, keyword retrieval, and reranker scores; new queries still perform the configured model inference and full reranking.

## Use and checks

Install the APK built from this source and keep the existing blue HNSW toggle selected. Existing embeddings and graphs remain compatible; no re-embedding or graph rebuild is required. Existing reranker, expansion, media, scope, and Markdown settings remain effective.

Run `bash tools/run-hnsw-checks.sh`. Set `MARKVAULT_JNI_INCLUDE`, `MARKVAULT_KOTLIN_COMPILER_CP`, and optionally `MARKVAULT_JSON_CP` for the Kotlin/JNI/saved-search checks. Set `MARKVAULT_ORT_CP` to the ONNX Runtime 1.19.2 desktop JAR and `MARKVAULT_MODEL_FIXTURE_DIR` to a directory containing `reranker-l12.onnx`, `reranker-l6.onnx`, and `reranker-vocab.txt` to run the actual production model differential tests. Model weights, SDKs, local paths, and build outputs are not bundled in the source archive.
