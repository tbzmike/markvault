# MarkVault 5.5.25 (474)

Based on the supplied MarkVault 5.5.24 (473) source.

- Added secondary native HNSW using pinned USearch v2.26.3, alongside existing IVF.
- Added a blue H toggle to the search bar and a Blue HNSW card under Settings → Search & Retrieval → Fast Search. Selecting either ANN switches off the other search toggle; both indexes remain maintained.
- Added build/rebuild, cancel, delete, progress, and automatic creation for all installed embedding models. Enable blue HNSW or build it once to enable automatic graph creation. Deleting a graph excludes that model until it is enabled or built again.
- Library indexing now delta-embeds every installed embedding model, active model first. Existing IVF and HNSW indexes synchronize even while their search toggles are off. Interrupted automatic HNSW work resumes when needed after restarting the app.
- HNSW stores FP16 passage vectors with stable article/chunk keys in separate per-model files. It uses bounded article candidates and the existing full precision SQLite scoring, keyword fusion, query provenance and optional reranking. Invalid, stale or sparse indexes fall back to exact search.
- Added transactional file replacement, metadata-only delta checks, deleted-chunk pruning, model isolation, cancellation protection and memory-mapped search snapshots.
- Added a non-destructive Room 22 → 23 migration for fast embedding freshness checks.
- Backup format 6 includes both ANN engines. Restore continues to accept old backup formats. Saved searches record HNSW enabled/actually used and show the blue label, with old sessions remaining readable.
- Retained the supplied 5.5.24 fixes for zero expansion budgets, the master expansion switch, title retrieval and reader highlights, as well as existing per-result query provenance, graceful stop and saved search behavior.

## Validation

- CMake builds the native shared library on the Linux host; all 11 JNI entry points are exported, with 16 KB ELF segment alignment.
- JNI create, vector validation, snapshot mapping, scope filtering, removal and replacement tests pass.
- The actual Kotlin HNSW manager compiled with Kotlin language version 2.2 and passed build, same-count edits, deletion/insertion, scope, model isolation, failed/cancelled rebuild and atomic snapshot tests using host Android/DAO stubs.
- The complete JNI translation unit cross-compiles for AArch64, including the ARMv8-A NEON FP16 cosine implementation.
- Actual new Room SQL queries pass model isolation, keyset paging, changed-note paging and freshness-index checks against SQLite.
- Changed app Kotlin and Gradle sources pass syntax parsing. Vendored header Git blob hashes match the pinned upstream release.

Synthetic CPU benchmark: 200,000 chunks, 42,000 article identities, 384 dimensions, 12 query vectors, up to 4,800 passage candidates. Median candidate lookup 24.87 ms; maximum 31.39 ms. The exact top 10 passages were present in the candidate pool for these synthetic queries. Index payload: 183,305,396 bytes (about 175 MiB). Host build time: 385 seconds. These are host measurements of candidate lookup, not a phone benchmark or a general recall guarantee.

The 1–2 second complete-search target remains unverified on Android. Query model loading/embedding, media retrieval, expansions, full precision candidate scoring and reranking also contribute to latency. First index construction is slower than querying.

No full Android APK build or device UI test was performed: this environment has no Android SDK/NDK. Build with the existing Android project toolchain, Android SDK 35, NDK 27.2.12479018 and CMake 3.22.1. The existing AGP/Kotlin dependency versions are unchanged. Native source and license are vendored; no extra ANN Maven dependency is required.

Host checks can be rerun with `bash tools/run-hnsw-checks.sh`; pass `200000` for the scale benchmark. Optional Kotlin/JNI checks accept `MARKVAULT_JNI_INCLUDE` and `MARKVAULT_KOTLIN_COMPILER_CP` pointing to an installed JDK's include directory and a Kotlin compiler/coroutines classpath.
