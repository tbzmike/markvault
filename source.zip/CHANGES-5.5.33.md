# MarkVault 5.5.33 (version code 482)

This update further accelerates blue HNSW and its reranker. It keeps the existing IVF engine, search coverage, model support, embedding/index synchronization, blue toggle and mutual exclusion. Existing embeddings and index files remain compatible; no rebuild or re-embedding is required for these changes.

## What changed

- Wide blue queries use a reusable direct bitmap for visited graph slots. At 210,000 chunks this takes approximately 26 KiB, avoiding the hashing and probing used by the previous query visit set. The bitmap is cleared between searches and restored to the original hash-set mode before graph construction or ordinary queries use that context.
- Query traversal prefetches the first two cache lines of each unvisited neighbor's vector before evaluating the adjacency list. Graph construction and the ordinary search wrapper retain their previous behavior.
- On ARM64 and supported x86 CPUs, four neighboring FP16 vector distances are calculated together. The query values are loaded once for the four independent accumulators. Each vector retains its original multiplication/addition order, including ARM FMA operations, reduction, dimension tails and zero-vector handling. Results are consumed in the original sequential graph order. Runtime CPU checks, unsupported dimensions, mutable vectors and other ineligible batches fall back to the existing metric.
- The blue reranker encodes the same query/document pairs once, then starts the longest sequences first. Workers still use the same shared model session, inputs, 256-token limit, concurrency/memory policy and scoring method. Scores are written to their original result positions. This reduces the chance that one long passage keeps running after the other workers finish.

The HNSW exploration budget remains 4,800. Connectivity, construction settings, graph edges, scope predicates, candidate limits, recovery rules and final FP32 article scoring are unchanged. Persisted HNSW format and the internal JNI candidate packet remain version 2. No newer ARM instruction requirement was introduced.

## Measurements

The reported phone searches took 3.0–8.1 seconds. Their native HNSW graph stage ranged from approximately 409 to 2,152 ms, and reranking from 1.57 to 3.31 seconds. Those stages motivated this update. Stage timings overlap, so they must not be added together to infer the search total.

The table below compares separately compiled 5.5.32 and 5.5.33 on the same deterministic synthetic graph: **42,000 articles, 210,000 chunks, 768 dimensions, M=16 and efConstruction=128**. These are warm Linux x86_64 host measurements, using GCC 13 with optimization and floating-point contraction disabled. Each benchmark also checks 360 ordered candidate/coverage/frontier/distance-count comparisons against the frozen 5.5.31 behavior, covering all notes, both library partitions, sparse and empty scopes.

| Warm full-library stage | Minimum | Median | 95th percentile | Maximum |
| --- | ---: | ---: | ---: | ---: |
| 5.5.32 complete ANN lookup | 8.83 ms | 13.15 ms | 16.91 ms | 21.00 ms |
| 5.5.33 complete ANN lookup | 6.28 ms | 9.00 ms | 11.65 ms | 13.12 ms |
| 5.5.32 native HNSW graph | 8.52 ms | 12.75 ms | 16.44 ms | 20.49 ms |
| 5.5.33 native HNSW graph | 6.01 ms | 8.66 ms | 11.26 ms | 12.62 ms |

The graph median improved by approximately **32%** in this comparison. Preparation was measured separately at approximately 225 ms for 5.5.32 and 235 ms for 5.5.33. The warm medians exclude that preparation cost; the app's complete lookup report still includes preparation when it occurs during a search.

Actual MiniLM-L12 and MiniLM-L6 ONNX tests compare longest-first scheduling with the delivered 5.5.32 shared-session scheduler. On a 30-pair fixture with mixed lengths and two long passages, a separate four-worker L12 run reduced three query times from 117.80/115.36/103.37 ms to 89.01/86.38/76.89 ms. All logits and rankings were identical. Scheduling gains vary: some one- and two-worker rounds were slower, so this is not a guarantee for every workload or device.

The **8.66 ms graph median is a host result**, not a measured phone result or a 10 ms maximum. Full search still includes query embedding, keyword/media retrieval, Room vector scoring, reranking and other work. Neither 10 ms HNSW on the user's phone nor a one-second complete search has been established by this validation. Run a fresh search after installing 5.5.33 to measure it; existing saved searches retain their original timings.

## Verification completed

- 22,720 fused/scalar neighbor-distance comparisons against the frozen original metric, with exact float equality. Cases cover 1–2,049 dimensions, batches of 1–65 neighbors, random/reversed consumption, zeros, tails, query boundaries and unsupported-batch fallbacks. Precomputation preserves the sequential metric-observation counter.
- 300,000 bitmap/hash visit operations covering membership, duplicates, counts, clear, growth, move operations and restoration to graph-building behavior. The previous 1,152 norm-cache/cosine cases, 256 scope sets and 80,000 frontier checks also pass.
- The same native property checks pass in an AArch64 Linux-musl binary under QEMU and on an emulated x86 CPU without AVX/F16C. Emulator timings are not performance measurements. Host AddressSanitizer and UndefinedBehaviorSanitizer checks pass; leak detection was disabled because the container prevents LeakSanitizer's process inspection.
- Exact graph/candidate comparisons pass at both the smaller and 210,000-chunk fixture sizes. Existing article-oracle recall and 80-case comparison with 5.5.26 pass. Search coverage was not reduced to obtain the timing results.
- Actual Kotlin/JNI manager checks pass for warm preparation, freshness, same-count edits, inserts/deletes, model/generation changes, scopes, cancellation and atomic failed/cancelled rebuilds. Native FP32 rescoring passes 7,872 bit-identical comparisons with the existing Kotlin scorer.
- Original IVF build/search/accuracy probes, same-count edits, deletes, model isolation, reopening and failed/cancelled rebuild checks pass. AnnIndex.kt and the original IVF implementation are unchanged.
- Room model-isolated/keyset queries, 42,000-article metadata projection and 200,000 media rows pass. Room-owned reads preserve WAL locks through concurrent writes/checkpoints and cursor iteration; database integrity passes. The native library does not introduce a separate SQLite engine.
- Frozen 5.5.24 retrieval checks pass for 630 coherent passages, 4,500 keyword hits and 118 chunk selections. Original keyword/highlight parity passes 32 cases, and original toolbar behavior passes 20,000 scroll events.
- Actual L12/L6 reranker tests pass with identical logits/ranking, original result positions, blank-input handling, progress counts, cancellation, in-flight retirement, revision reload, model switching, missing-model fallback and shared-session memory guards. Actual changed ViewModel helpers compile and their memo/session/fallback checks pass.
- Saved-search timing/backward-compatibility checks and the 214-session × 347-hit fixture pass, preserving metadata, counts, ordering and full result restoration. Existing retention, edits, deletion, unknown-field handling and cancellation checks pass.
- The preservation guard passes: 264 byte-identical original 5.5.24 files plus two reviewed changes, 563 protected original method/policy blocks and 106 original DAO queries. Previous delivered 5.5.27, 5.5.30, 5.5.31 and 5.5.32 inverse-delta guards also pass. The new layer verifies nine reviewed source/test deltas against 5.5.32. Markdown/HTML readers, backups, navigation, settings, library indexing, query preprocessing/pooling, MediaPipe routing and existing UI fixes remain protected. Actual BGE/MiniLM embedding-model inference was not rerun in this update; those production paths are unchanged and their original-source guards pass.
- Final `:app:assembleDebug` and `:app:assembleRelease` both succeed with Gradle 8.7, Java 17, SDK 35, NDK 27.2.12479018 and CMake 3.22.1. APK inspection confirms 5.5.33/code 482, valid signatures and arm64-v8a/armeabi-v7a/x86/x86_64 libraries. Each packaged library exposes the same 13 expected JNI methods. Existing compiler/Room/deprecation warnings remain warnings.
- Source archive tests pass for reproducible bytes, fixed past timestamps across time zones, executable permissions and build-cache exclusions. Packaging also verifies archive integrity and every archived source byte.

## Included checks

Run `bash tools/run-hnsw-checks.sh` for the source checks. Kotlin/JNI tests use the existing compiler/JNI environment variables. Real reranker checks require `MARKVAULT_ORT_CP` and `MARKVAULT_MODEL_FIXTURE_DIR`; saved-report checks require the existing JSON.org/Gson variables. `tools/tests/hnsw_speed_benchmark.cpp` compares the current query path with the frozen 5.5.31 algorithm on a fixture produced by the existing native article benchmark. The new `BlueRerankSchedulingTest.kt` compares with the exact delivered 5.5.32 shared-session engine, retained under a test-only class name.
