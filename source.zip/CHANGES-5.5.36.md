# MarkVault 5.5.36

This update targets the vector-scoring stage of Blue HNSW search. The latest phone reports show 2.6–5.4 seconds total, 0.78–1.06 seconds for vector scoring, and 0.01–0.03 seconds for result labels. The graph's elapsed time also exceeds its thread CPU time. That gap does not by itself identify the cause of the waiting.

## Changes

- Blue HNSW reads the existing `noteId, vector` projection through a Room-owned cursor and scores batches of 128 vectors. It no longer retains a whole candidate page as Kotlin projection objects and BLOB arrays before starting to score it. For 4,500 BGE passages at 768 dimensions, the previous BLOB copies alone occupied 13,824,000 bytes; 128 vectors occupy 393,216 bytes. Cursor windows, small score maps and native buffers are additional memory.
- The native FP32 scorer computes four vectors together. SIMD lanes represent separate vectors, and each vector's products are still added in the original dimension order. No floating-point reassociation, reduced precision or changed score clamp is introduced.
- The original 900-note query boundary and Stop Search behavior remain. The cursor closes on success, error and coroutine cancellation. A failed cursor page is discarded and retried through the previous Room projection reader. A missing or failed native scorer uses the original Kotlin arithmetic.
- Version 5.5.36, version code 485.

## Compatibility

The graph algorithm, M=16, construction effort, candidate/frontier limits, scopes, exact recovery and per-article best-passage scoring are retained. FP32 scores, tied result order and model filtering are checked against the delivered 5.5.35 method. No results are removed to shorten the reported search time.

Original IVF keeps its existing projection reader and scalar scoring path. The blue toggle, automatic embedding and index synchronization for installed models, query/reranker inference, saved reports, Markdown readers, other UI features and backup behavior are retained. The Room schema remains version 24, stored HNSW format remains version 2, and its JNI candidate packet remains version 3. An existing valid index does not need rebuilding or re-embedding for this update.

The host arithmetic benchmark is evidence for the new scorer, not a measurement of complete Android search. A phone measurement is still required to establish any change to total time or the HNSW elapsed/CPU gap. The one-second total and 10-ms graph targets have not been established by this build.

See `VERIFICATION-5.5.36.md` for the completed checks and their limits.
