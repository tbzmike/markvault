# MarkVault 5.5.26 (475)

This update keeps the blue secondary HNSW engine and the existing IVF engine. Only one search engine is selected at a time; installed per-model indexes remain synchronized. Existing embeddings and HNSW snapshots are compatible, so this update does not require re-embedding or rebuilding a valid graph.

## Performance changes

- Replaced repeated 1,200/2,400/4,800-passage graph searches with one traversal. Native code groups admitted passages into ranked unique article candidates.
- Converts the query's quantized vector and computes its norm once per lookup. Stored FP16 vectors still use cosine distance with FP32 accumulation, including the existing ARMv8-A NEON path. Final candidate articles retain full precision SQLite scoring across all their persisted chunks.
- Preserves scope filtering during graph traversal. Post-filtering an unrestricted traversal was rejected after measured recall regressions.
- Sparse scopes recover candidates in native code, then use the existing full precision scoring. A successfully exhausted small scope no longer triggers a redundant full SQLite scan. Invalid, missing, stale, or incompatible indexes still use the existing exact fallback.
- Bulk embedding and HNSW synchronization yield at checkpoints during an interactive search and resume afterwards. Automatic embedding for every installed model and library indexing hooks remain enabled.
- Saved search details now show timings for query embedding, media search, ANN lookup, full vector fallback, vector scoring, reranking, and other retrieval work. This distinguishes fast graph lookup from the remaining complete-search costs.
- Keeps the source archive timestamp correction for the earlier Ninja manifest failure.

## Verification

Synthetic host fixture: 42,000 articles, 210,000 chunks, five related chunks per article, 768-dimensional vectors, 12 query/scope combinations. Both implementations query the same persisted graph. An exhaustive full precision article scorer supplies the recall reference.

| Scope | Previous median candidate lookup | Updated median candidate lookup |
| --- | ---: | ---: |
| Entire library | 49.92 ms | 19.52 ms |
| First 20,000 articles | 64.75 ms | 23.78 ms |
| Remaining 22,000 articles | 130.00 ms | 55.09 ms |

Updated candidate recall was equal to or higher than the previous implementation at ranks 10, 50, and 200 in all 36 comparison checks. The entire-library queries included all reference top-200 articles. This fixture is not a universal recall guarantee or a phone benchmark.

Native tests cover query cache invalidation, identical cached/uncached cosine distances, zero and odd-dimensional vectors, sparse scopes, deleted articles, and snapshot reloads. JNI packet validation and actual Kotlin manager tests cover model isolation, same-count edits, insertion/deletion, cancellation, atomic graph replacement, and searches during a paused rebuild. Saved timing metadata passes roundtrip and backward compatibility checks using host adapters. Existing Room SQL and archive reproducibility tests also pass.

The native shared library builds with CMake 3.22.1/Ninja 1.11.1. The complete JNI translation unit cross-compiles for AArch64. Changed Kotlin and Gradle source grammar checks pass. Verification is repeated from the final extracted source archive; a second Ninja build must report no work.

**No complete Android APK build or phone timing was performed for this update:** this environment has no Android SDK/NDK. The 1–2 second complete-search goal remains unverified. Model loading, inference, expansions, media retrieval, and a 30-article cross-encoder rerank can contribute substantial time independently of HNSW. The update preserves those existing search settings and records their actual elapsed stages.

## Use and rerun checks

Install an APK built from this source, select an embedding model with a completed blue HNSW graph, and enable the blue H search toggle. Existing valid graphs can be reused. The saved search details report whether blue HNSW was actually used and show the timing breakdown after the search.

Run `bash tools/run-hnsw-checks.sh` for native, article-recall, and SQL checks. Optional JNI/Kotlin checks use `MARKVAULT_JNI_INCLUDE` and `MARKVAULT_KOTLIN_COMPILER_CP`; saved-session encoding checks additionally use `MARKVAULT_JSON_CP` for an org.json classpath. The host Android/DAO adapters are test-only.

The article benchmark can separately run at full scale by compiling `tools/tests/hnsw_article_benchmark.cpp` with the same native include paths and passing `42000 768 /path/to/fixture.bin`. Its optional fourth argument `reuse` queries an existing fixture without rebuilding it.

Create future archives using `python3 tools/package-source.py /path/to/source.zip`; run `python3 tools/tests/source_archive_test.py` for timestamp, timezone, mode, cache exclusion, and reproducibility checks.
