# MarkVault 5.5.41 — Clear numbered search results

**Baseline:** MarkVault 5.5.40 (`source.zip`), versionCode 489.
**New version:** 5.5.41, versionCode 490.

## Search-result readability

- Each article result now shows a bold numbered rank (`#1`, `#2`, `#3` …), computed from the currently displayed, filtered or reranked list. The number is not a database ID, and automatically follows reordering.
- Adjacent result cards alternate between **two distinct, opaque background shades**. Shades derive from the active Material color scheme, rather than fixed light/dark hex values or source-specific expansion colors.
- Consistent card padding, clearer separation, and native `Surface` outline borders make start/end boundaries identifiable at a glance.
- Existing **query-expansion accents remain the border color** for results with a primary expansion match. Results without such a match receive a neutral, theme-derived border.
- Color blending keeps body text and metadata legible in light, dark, AMOLED, themed-artifact and custom-color modes. Legacy low-contrast foreground/surface combinations receive a local, card-only correction. Muted metadata switches to the theme's high-contrast body text where needed.

## Preserved behavior

- No changes to result ordering, relevance scores, filtering, keyword/semantic retrieval, HNSW/IVF indexing, query expansion generation, saved search contents, snippet highlights, or the reader tap/long-press actions.
- The source-specific color-coded query expansion display and its LLM/synonym/T5/Question Awareness provenance remain intact.
- Only the SearchScreen Compose result-card presentation and the app version configuration were edited among pre-existing source files.

## Validation

- `python tools/tests/search_result_card_visual_test.py`: PASS; rank wiring, expansion display, 20 built-in theme WCAG-AA foreground contrast checks.
- `kotlinc ... QueryExpansionPresentationTest.kt` + `java -jar ...`: PASS; saved/query expansion provenance and multi-match cases.
- ZIP CRC and unchanged-file audit: see `VERIFICATION-5.5.41.md`.

**Limitations:** Full Android Gradle APK compilation, device visual inspection, and timing benchmarks could not be run here (Android SDK/Gradle build dependencies unavailable). Upload `source.zip` to GitHub for your existing green-build workflow and test both themes on-device.
