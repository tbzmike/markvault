# MarkVault 5.5.48 — Verification record

## Tests executed

- **Kotlin planner tests**: apostrophe/misspelling handling, question-grammar removal, negation preservation, quoted exact phrase, ordinary prose false positives, proximity construction — PASS.
- **Question Awareness 2.0 regression**: subject-first Caleb, WHY, AGE, COUNT, WHEN, neutral YES/NO, false positives, language fallback, expansion quotas — PASS.
- **Focused genealogy test**: `Who were the sons of Esau?`, `Who were Esau's sons?`, `Who were the sons of e'sau?` — PASS.
- **SQLite FTS4 saturation test**: with 500 earlier records matching `sons* esau*`, a later direct answer is absent from the first `LIMIT 500` but present in the second bounded `sons* NEAR/8 esau*` pool; quoted phrase remains exact — PASS.
- **Expansion provenance**: original/synonym/T5/LLM/QA colors and saved-search provenance — PASS.
- **Original query embedding/pooling preservation** — PASS.
- **20dp card spacing/3dp borders/rank labels preservation** — PASS.
- **Keyword memo revision, HNSW/IVF database SQL/model isolation** — PASS.
- **Search lifecycle, emergency cleanup, saved-session durability** — PASS.
- **Full Android APK compilation** — NOT RUN in this local environment (no Android Gradle toolchain); requires the GitHub Actions build.
- **Real vault accuracy / device HNSW recall** — NOT MEASURED; requires on-device tests with indexed data.

## Changed-file audit relative to original 5.5.47

Only `app/build.gradle.kts`, `AppViewModel.kt`, `data/Topics.kt`, and `search/QuestionAwareness.kt` are modified, plus `search/KeywordRecallPlanner.kt` and regression tests added. All other original project files are byte-identical. No deletions.
