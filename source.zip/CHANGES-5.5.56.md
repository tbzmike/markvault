# MarkVault 5.5.56 (505) — portable restoration across providers

Baseline: version 5.5.55. Backup format v7, Room schema, standard level-9 compression, manifest validation, selective ZIP reader, and legacy restore paths remain unchanged.

## Confirmed failure
`PortableBackupFiles.verifyCreatedName` rejected every provider-generated display name different from the requested name, after creating the document. Markdown files were requested as `text/plain`; some Android document providers append a `.txt` suffix. Providers may also normalize names or append collision suffixes. The screenshot identifies the requested name `2026-.md`, not the actual name the other phone returned.

## Fix
- Restore uses safe actual provider names and document IDs, not an exact-string comparison with requested filenames. Indexed extensions are preserved: Markdown uses extension-preserving generic MIME first, with `text/markdown` as an alternate. Other indexed types use their appropriate MIME or a generic fallback. If a provider will not create a recognizable indexed extension, restoration fails safely rather than silently installing an article that would disappear on re-indexing.
- Actual folder paths stay separate from logical archive paths, including normalized and renamed folders. The archive-to-document-ID map is passed to the existing database remap, which records the actual URI, filename/path, and current metadata. Embedding/chunk and ANN record identity is unchanged.
- For normal case, punctuation normalization and numbered collision suffixes, existing candidates are indexed once per operation; files are reused only after full SHA-256 comparison and a one-to-one document-ID check. Separately named backup members cannot claim the same destination document. A file conflicting with a folder name is preserved alongside a distinct restored directory.
- Refuse a provider returning an existing document ID as a new file. Remove only documents created during this attempt on failure; never write into or delete a pre-existing destination file. The previous shared Obsidian conflict handling is retained.
- Restore summary reports provider-adjusted names. No backup format change, extra foreground/background service, polling, decompression worker, or search changes.

## Scope/limits
This corrects the existing strict filename check and handles the tested naming variations. The exact rename performed by the reported device is not known, and its actual Android storage provider has not been tested here. Unusual provider behavior, inaccessible or full storage, invalid archives or irreconcilable indexed file types remain legitimate errors. Arbitrary provider-specific rename schemes are not guaranteed to be recognized on subsequent restores. Keep the original backup ZIP and library until a complete device restore is verified.
