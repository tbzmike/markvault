MarkVault AI fallback upgrade

Integrated into the original source.zip structure.

Added:
- RAM-aware model selection layer
- fallback controller
- SmolLM2 135M emergency model support

The original project structure is preserved:
- app/
- gradle/
- .github/
- build files

Next integration point:
Connect ModelMemoryPolicy and FallbackModelController into LlmManager.load().