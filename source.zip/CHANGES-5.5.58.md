# MarkVault 5.5.58 (507)

Baseline: exact source.zip from successful GitHub Actions run 44242707069, Git blob dcefa756186ad1d8f3b35ee286b8d27d72a3c8a8.

- Offline HTML/MHTML reader: opening a scripture or JW web popup no longer clears the source WebView cache/history or schedules a full HTML reload. The navigation callback continues to consume the request and route it using the existing JW Library, WebViewer, offline Bible chapter, or system-browser branch. The explicit Refresh and Load Online actions remain available.
- Preserve the native reading position before routing links, including popup links from long-press, selected text, and the article passage popup. Per-entry saveable current scroll is used before the asynchronously persisted Room value if the reader is recreated. Initial positioning uses native WebView pixels rather than mixing native and CSS pixels; transient load scroll callbacks cannot overwrite the saved position before the initial restore. One existing delayed initial-scroll callback is guarded against a replaced WebView or link tap.
- Deferred lexical and semantic highlight auto-scroll callbacks respect a separate link-open suppression flag. Highlight rendering, the existing cancel button, and manual next/previous navigation are unchanged. No additional service, timer, thread, or background worker.
- No changes to 5.5.57 selective backup/restore, retry, schema migration compatibility, pause/resume, verification, search, models, storage formats or indexes. Only HtmlReaderScreen.kt and build version metadata changed; regression test and reports added.
