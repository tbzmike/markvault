# MarkVault 5.5.42 — Strong Search Result Separation

**Baseline:** 5.5.41 `source.zip`, versionCode 490.
**Update:** 5.5.42, versionCode 491.

## Search result cards

- Use a **3 dp native Surface border** around each search result, including results matched only by the original query.
- Retain the existing expansion-accent border when contrast to the tile background is at least **3:1**; otherwise use the active theme's legible `onSurface` color. All individual synonym/LLM/T5/Question Awareness chips retain their own coloring.
- Give each result its own outer **20 dp bottom gutter** and a small additional top gap; the spacing sits *outside* the card's painted bounds, not in its internal text padding.
- Remove the full-width `HistoryBoldDivider()` previously drawn beneath *each article result*, which visually joined cards into a continuous list. The divider for recent searches and other screens is unchanged.
- Reduce shadow elevation to **2 dp** so shadows do not bridge the gutters.
- Preserve the alternating opaque card shades, dynamically visible `#1`, `#2`, etc. rank badges, readable body and metadata text, title/snippet highlighting, and gestures.

## Scope

Only `SearchScreen.kt` and `app/build.gradle.kts` changed among the baseline's existing **application** files. `tools/tests/search_result_card_visual_test.py` was updated to verify the new border behavior. Search ranking, retrieval, HNSW/IVF, LLM expansion, embedding models, saved searches, highlighting engine, and search data models were **not changed**.

The source tests are not a substitute for an Android APK build or on-device visual inspection. Upload `source.zip` to GitHub and wait for the build workflow to pass before installing.
