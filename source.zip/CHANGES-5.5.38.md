# MarkVault 5.5.38 — article graph traversal

Version code 487. Starts from the delivered 5.5.37 source. Only the blue secondary HNSW candidate traversal, its diagnostics, tests and version change.

## Larger structural change

The old search keeps a 4,800-passage frontier, where several chunks of the same article compete for slots and repeat graph work. The new runtime overlay contracts those passages into article vertices and unions their existing neighbor edges. Its distance is the best SQ8 cosine over **all** of an article's chunks, using fused four-row integer kernels. It does not use a centroid or just the first chunk. Deleted passage nodes remain available for routing and cannot appear in candidates.

For a typical five-chunk article collection and a 200-result search, the frontier contains 600 articles. The candidate pool remains 600 articles, and the original final scoring still examines **all persisted FP32 chunks** of every candidate. Reranking, result limits and keyword settings retain their existing behavior.

The frontier widens automatically for eligible collections averaging four to five chunks per article. Collections averaging fewer than four chunks retain the original SQ8 passage traversal; testing showed that contracting those graphs with a narrow article beam could reduce recall. Allocation failure during overlay creation also retains the original passage path.

## Automatic activation and compatibility

No embedding rebuild or index-file migration is required for existing format-3 SQ8 indexes. The overlay is built once when a model's snapshot is opened, reuses its mapped SQ8 matrix, and is invalidated when the snapshot changes or unloads. It follows the existing model synchronization, embedding completion and atomic snapshot lifecycle. The legacy format-2 conversion remains unchanged.

The search report identifies the new path as **HNSW SQ8 article graph**. Existing fallback paths keep their previous labels. Log diagnostics include the actual article/passage frontier, vector measurements and overlay memory. Snapshot format remains 3; the internal JNI candidate packet is version 5, with matching native/Kotlin validation.

## Preservation and measured limits

The original IVF implementation, Markdown/HTML readers and highlighting, library indexing, model inference, backups, Room schema, DAO queries, search controls and saved-session format are retained. The included preservation guard checks every 5.5.37 file plus the older 5.5.24 feature guards.

On the 210,000-chunk/768-dimension synthetic host comparison, full-library median graph time fell from 4.573 ms to 2.390 ms, and partition median from 10.221 ms to 4.999 ms. These are graph measurements on this host, not phone timings or total-search times. Mean recall passed the declared guard; individual approximate candidate lists can still regress. See VERIFICATION-5.5.38.md for evidence and limitations.

Cold model opening includes overlay construction. Warm queries reuse it. Embedding, keyword retrieval, FP32 scoring and reranking still contribute to total latency. No on-device 10-ms graph or one-second total-search claim is made.
