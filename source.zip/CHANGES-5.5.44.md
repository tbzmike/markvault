# MarkVault 5.5.44 — Question Awareness 2.0

**Baseline:** full 5.5.43 `source.zip` (code 492). **Output:** 5.5.44 (code 493).

## Enhancements

- **Subject-first grammar**: recognize `Caleb who was he` with or without question mark, `Moses why did he flee Egypt`, `Job what happened to him`, `David how old was he when he became king`, `Jerusalem where is it`, `Jesus when was he born`, and `Paul how many letters did he write`. Resolve pronouns only in constrained, high-confidence patterns to avoid false positives with relative clauses.
- **More question intents**: additional `WHAT / event` answer shape for `what happened to …`.
- **Neutral YES/NO rewrites**: use relationship and evidence-oriented phrases, not an assertion that the answer is yes or no. Preserve the original user's query separately.
- **Safe inflections and natural dates**: `When did Jesus die` now returns `date of Jesus' death` rather than `date of Jesus died`. Small, targeted morphology dictionary avoids stem changes to proper names or negations.
- **Confidence gates**: detection confidence and rewrite confidence are distinct from query ranking weights. Unsupported grammar and punctuation-only statements use the literal input rather than speculative rewrites.
- **Language modularity**: `QuestionDetector` interface with conservative Sepedi and isiZulu intent recognition. These languages are currently detection-only; they do **not** generate English rewrites. A dedicated multilingual query builder can be added later.
- **Strict, shared expansion budget**: the original user query does not consume the slider's budget. QA, synonyms, T5 and LLM now share its value in both semantic-on and semantic-off paths; keep capacity for selected T5/LLM where possible. When no confident QA variants exist, slots remain available to the selected engine. Never secretly substitute synonym expansions for an absent T5/LLM output unless fallback settings permit it.
- **Query provenance**: preserved Question Awareness, LLM, T5 and Synonym source classifications and saved-search records. The list of QA queries saved per search is the list actually selected for retrieval, not up to four unused variants.

## Unchanged functionality

- HNSW/IVF indexes, ranking and reranking, query embedding, highlighting and result numbering, alternate card backgrounds, card gaps and outlines, saved search persistence, and memory safety code are unchanged.
- No download, model inference, or database access is introduced in the deterministic Question Awareness detector.

## Limitations

This is a lightweight, deterministic on-device question detector, not a semantic QA model. Subject-first rewrites intentionally cover only unambiguous pronoun and interrogative patterns; unusual word order and multilingual rewriting need future extensions. The chosen query budget can include fewer variants than requested when models fail, candidate texts duplicate, or confidence is too low. Full Android APK compilation requires the GitHub Actions environment and was not run in this workspace; see `VERIFICATION-5.5.44.md`.
