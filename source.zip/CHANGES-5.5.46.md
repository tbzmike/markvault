# MarkVault 5.5.46 — Embedding model control and safe synchronization

Baseline: complete 5.5.45 source archive.

## Added
- Independent persisted Enable/Disable toggle for all four embedding models. Disabled models stay installed, but become non-selectable and are excluded from automatic multi-model article synchronization and ANN/HNSW maintenance. Previously generated embeddings remain intact when disabling.
- Model-availability changes trigger cancellation and rebuilding of the active multi-model sync plan, so the newly disabled model is not processed by the replacement worker. Extra checks at model, article, chunk and before database commit help prevent further writes for a disabled model.
- Model-specific Delete data action with explicit confirmation. The foreground service waits for the indexing coroutine to cancel/join before deleting matching article and media embeddings, IVF/HNSW index files and model-specific weights/vocab files. Other models are not cleared. Deletion disables the model, and refuses to delete a currently selected model before switching to another enabled model.
- Foreground notification and in-app Pause/Resume/Stop actions for the **actual embedding coroutine**, including retained progress and committed embeddings. Pause releases the CPU wake lock; Stop cancels the worker but does not delete completed embeddings.
- Service operation messages for model deletion success/failure.
- Version 5.5.46 (code 495).

## Preserved
- Multiple installed models can synchronize even when not the active search model, as long as they are enabled.
- Model-specific embedding data remains untouched by a Disable action.
- Query Awareness 2.0, expansion colors, ranking, card borders, saved results, HNSW/IVF retrieval, LLM/T5 source and other existing functionality remain unchanged.

## Safeguards and limitations
- To avoid leaving MarkVault without a functional active embedding model, disabling/deleting the final enabled model is blocked. Enable an alternative first.
- Existing native model inference can be in flight at the exact moment Pause/Stop/Disable is clicked; pause or cancellation takes effect at safe coroutine boundaries. The worker is joined before model data is deleted.
- Auto-sync service still runs for enabled installed models; there is no model-specific pause independent of the global synchronization pause.
- On Android, a long-running paused foreground service may be subject to system-level foreground-service time limits. This is not yet an on-device tested behavior.
- Verification requires successful GitHub Android workflow build and actual-device action tests; code-level checks do not replace those tests.
