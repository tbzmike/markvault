# MarkVault 5.5.52 — Verification report

## Local results (2026-11-16)

1. Kotlin type-check of `BackupManager.kt`, `PortableBackupFiles.kt`, `PortableBackupState.kt`, and new `PortableLibraryPaths.kt` against Android/Room/coroutine host stubs: **PASS** (no compiler errors).
2. In-memory SAF integration: repeated provider entries for the same document ID, distinct IDs with identical filenames, duplicate folder display names, reserved synthetic filename collision, ZIP creation, restoration to a new empty provider, byte-for-byte file/content mapping, safe repeated restore, and refusal to overwrite altered files: **PASS**.
3. Stress test: 1,200 distinct document IDs all claiming `duplicate.md`, produces 1,200 unique portable filenames: **PASS**.
4. Existing eight-remaining-Room-tables streaming round trip including binary media embeddings, floating/null fields, UI state, corrupt-header rejection: **PASS**.
5. Previous 5.5.51 sequential highlight regression: **PASS**.
6. Existing FTS4 Esau search recall regression: **PASS**.
7. HNSW model-specific SQL invariants: **PASS**.
8. Disabled-model/embedding-isolation checks: **PASS**.
9. Search-card layout/ranking/provenance regression: **PASS**.
10. Archive comparison with original 5.5.51 ZIP, file preservation/ZIP integrity/target version: **checked at package time**.

## Unverified

- Full Android Gradle/APK build: **NOT RUN**. Android SDK/Gradle toolchain is unavailable in the working container. Upload the verified `source.zip` to GitHub to build and install.
- Backup and restore on the user's actual device and a second real Android phone: **NOT RUN**. The simulated SAF round trip confirms code behavior with representative collisions, not provider-specific behavior of all phones.
- Complete end-to-end all-model indexed-data backup and restore with hundreds of thousands of embeddings: **NOT RUN**. The existing database and model-asset serializers were preserved and checked with targeted tests.

## Scope

Changed app source only: `BackupManager.kt`, `PortableBackupFiles.kt`, `SettingsScreen.kt`, `app/build.gradle.kts`.
New app source: `PortableLibraryPaths.kt`.
New tests: `portable_backup_5_5_52_test.py` and `tools/tests/stubs_552/`.
No original source files removed.
