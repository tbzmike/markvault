# MarkVault 5.5.29 (version code 478)

## Crash evidence and correction

The supplied log records a native `SIGBUS / BUS_ADRERR` at 22:35:01.211 inside Android's `libsqlite.so/getPageNormal`, with Room's `NoteDao_Impl.notesForUrlHarvest` in the stack. The preceding HNSW search reached vector scoring. This is a native database-reader failure; a Kotlin exception handler cannot recover the process from this signal.

The 5.5.28 vector reader linked a separate SQLite engine into the HNSW library and opened Room's live database directly. SQLite documents that independently linked engines cannot coordinate their per-process file-lock bookkeeping: closing one engine's connection can remove another engine's locks. See [SQLite's explanation](https://www.sqlite.org/howtocorrupt.html#multiple_copies_of_sqlite_linked_into_the_same_application).

A laboratory reproduction used the actual 5.5.28 native reader alongside a second SQLite engine. With a read snapshot still active, an external WAL truncate checkpoint changed from blocked (`[1,19,11]`) to successful (`[0,0,0]`) after the native reader closed. A same-engine read/close and a Room-like read followed by native vector math both kept the checkpoint blocked. The lock-loss defect is reproduced; its involvement in this particular device SIGBUS is inferred from the stack and timing. The corrected update still requires confirmation on the phone.

5.5.29 removes the independent SQLite engine, database-opening JNI API, and their source files. Candidate vectors and rerank passage vectors now come through the existing Room DAO queries. JNI computes full-precision vector scores from those bytes and never opens the live note database.

The HNSW CMake configuration, C++ JNI implementation, and Kotlin JNI declarations are byte-identical to the tested 5.5.27 versions. Candidate rescoring is also restored byte-for-byte to its 5.5.27 Room-owned implementation. Blue rerank passage selection retains native FP32 scoring, strict first-winner tie behavior, and the existing scalar fallback.

## Retained and verified

- HNSW graph/search/model synchronization, parallel L12/L6 reranker workers, fast coherent-passage selection, keyword ranking/cache revisions, and timing reports remain unchanged from 5.5.28. Existing embeddings and graph files remain compatible; no re-embedding is required.
- New database ownership check: Room-like reads plus 512 calls to the actual native dot-product kernel keep WAL locks during concurrent writes/checkpoints and continued cursor iteration. Database integrity passes afterward. The compiled native binary has exactly 13 matching JNI exports and no independent SQLite implementation.
- The actual changed ViewModel passage method and actual production DTO declarations compile in the Kotlin host fixture and pass JNI-backed checks for model separation, winning chunks and ties, invalid vector rows, missing notes, blank content, empty inputs, and soft Room-read failure. Passage text matches the frozen original oracle.
- The native/Kotlin/SQL regression suite passes: IVF build/search/accuracy/edit/delete/model/reopen/failed and canceled rebuilds; HNSW scopes/sync/deltas/atomic snapshots; 7,872 bit-identical FP32 comparisons; priority/cancellation; cache freshness/coalescing; saved-search backward compatibility; and frozen passage/keyword/chunk comparisons.
- 5.5.24 preservation checks pass for 268 byte-identical files, 563 protected original method/policy blocks (only existing additive blue hooks normalized), and 106 original DAO queries. All 312 pinned 5.5.27 files still match. Markdown/render/export assets, UI, primary IVF, Room schema/queries, backup, URL harvesting, model catalog, and indexing/synchronization code were not edited for this update.

The complete Android APK build, device UI, and subsecond completed-search latency have not been verified here. The previously completed L12/L6 model checks apply to unchanged worker code; model profiling was not repeated for this database correction.

## Build and use

Build the updated source and install 5.5.29 over the existing app. Select the existing blue HNSW toggle to use the secondary ANN engine. The version code is incremented to 478. Existing models, notes, search settings, and stored indexes remain usable.

Run `bash tools/run-hnsw-checks.sh`. Supply `MARKVAULT_JNI_INCLUDE` and `MARKVAULT_KOTLIN_COMPILER_CP` for actual Kotlin/JNI checks, and `MARKVAULT_JSON_CP` for saved-search checks. The same optional ONNX model fixtures described in `CHANGES-5.5.28.md` remain supported. Model weights, SDKs, build outputs, and local paths are excluded from source.zip.
