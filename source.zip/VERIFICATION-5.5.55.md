# 5.5.55 verification

- PASS: actual `BackupManager`, `BackupZipIO`, `PortableBackupFiles`, `PortableBackupState` and `PortableLibraryPaths` compile together under host Kotlin with Android/Room interface stubs. This is a type check, not Android compilation.
- PASS: actual `BackupZipIO` test: 65,540-entry ZIP64 (OpenJDK), standard maximum compression, byte-identical selected/streaming extraction, SHA-256 formatting for all byte values, corruption rejection, partial-consumer verification, progress advancement and no retry after consumer failure.
- PASS: actual portable library helper with simulated SAF provider: cross-device path remapping, duplicate filenames/directories, 1,200 collision cases, shared Obsidian bookmarks conflict, existing-file reuse and repeat restoration.
- PASS: Java level-1/level-9 lossless mixed-payload archive test. Fixture 2,169,708 vs 2,109,594 bytes. Not a real-library benchmark.
- PASS: highlight navigation, FTS4 search recall regression, model isolation, HNSW SQL, result-card separation checks.
- Reproducible host test: `tools/tests/backup_progress_restore_5_5_55_test.sh`. Existing historical version-specific scripts retained without alteration; they may assert historical version numbers or old implementation strings.
- No Android SDK/Gradle build available; actual phone storage provider seekability, maximum-scale device speed, thermal behavior and successful two-phone restore remain unverified. User must obtain a green CI build and test an actual backup before discarding any original data.
