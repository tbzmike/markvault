# MarkVault 5.5.31 (version code 480)

## UI work and memory allocations

This update addresses specific sources of scrolling work and retained saved-search payloads found in the source. It preserves the 5.5.30 search engines and their original candidates, models, reranking, and scoring.

- Search toolbar auto-collapse observes list position through `snapshotFlow`. Per-gesture counters live outside Compose state, and only an actual toolbar visibility transition updates the screen. The original 24-pixel downward threshold, 18-pixel upward threshold, and 320-millisecond layout-settling guard remain.
- Query tokens, LLM highlight terms, and the consecutive-word keyword filter are calculated once per changed query/result/filter/paraphrase input. Each visible snippet reuses its original highlighted `AnnotatedString` until its text, terms, or theme highlight color changes. The original filter and highlighting computations remain intact.
- Saved-search history and calendar cards load report metadata and counts with a streaming Gson 2.11 reader. They skip result snippets and retain neither full hit objects nor per-result scope/provenance maps. Opening a saved search still uses the unchanged full decoder and restores the exact saved result order, scopes, scores, and query provenance. No saved-file format, metadata version, retention policy, or index migration changes.
- One report read populates history and calendar metadata together. Deletion refreshes those lists after the file is deleted, avoiding independent refreshes racing the deletion.
- The memory overlay's process-PSS sampling runs on `Dispatchers.IO`, with the original lifecycle gating and refresh intervals.
- Search-result entrance animations now follow the existing UI animation toggle and speed setting. Disabling animations immediately shows complete rows. Home-list entrance animations also snap to their visible state when disabled; already-shown items do not replay when the preference changes.

## Evidence and verification

The supplied logcat contains 23 MarkVault garbage collections over approximately 30.5 seconds, reclaiming about 1,031 MiB. Summed reported pauses are approximately 270 milliseconds; concurrent collector runtime is not equivalent to blocked UI time. The recording contains no MarkVault frame trace or completed-search stage trace, so it cannot establish which individual frame or search stage caused the reported slowdown.

The production saved-search store was compared against a frozen 5.5.30 loader on a **214-session history with 347 full results per session**, including long escaped/Unicode snippets, scope maps, provenance, and execution metadata. JVM thread-allocation counters reported 2,918,763,136 bytes for the old full history loader and 119,690,128 bytes for report loading: **96% fewer temporary allocated bytes** in that host test. This is an allocation measurement, not a claim of 96% faster phone scrolling or search. Report objects retain no full result payloads.

Passed checks:

- Exact report/header fields, counts, order, calendar metadata, recent-list limits, and unchanged files; v1–v6 defaults, timing compatibility, duplicate provenance, unknown fields, edits under an existing ID, deletion, six-month expiry, malformed files, cancellation, and exact full-result restoration.
- Frozen original keyword/highlight-token behavior on 32 cases and original toolbar direction/threshold/settling behavior on 20,000 seeded scroll events. The snippet-highlighting computation matches the original body exactly after the caching wrapper is removed.
- Native/Kotlin/SQL regression suite: original IVF build, search, probes, edits, deletion, model isolation, reopening, failed/cancelled rebuilds; HNSW synchronization, deltas, scopes and atomic snapshots; 7,872 bit-identical FP32 scoring comparisons; keyword freshness and caches; Room rerank reads; and saved-search compatibility.
- Database ownership checks: Room owns live vector reads, the native binary exports 13 matching JNI methods and has no independent SQLite engine; concurrent WAL writes/checkpoints and integrity checks pass.
- Original-feature preservation: 264 files remain byte-identical to 5.5.24, with two explicitly reviewed UI deltas normalized to that baseline. All 563 protected original method/policy blocks and 106 DAO queries pass the original guards. The six edited UI/report source files have exact inverse-delta guards against delivered 5.5.30. Original saved-session models and full codec, Markdown/HTML readers, navigation, backups, settings, embedding/library indexing, primary IVF, blue HNSW graph/synchronization, exclusive ANN toggles, and search engine computations remain protected.
- Source-archive integrity, exact source bytes, executable permissions, build-cache exclusions, reproducibility, and safe past timestamps pass.

Both `:app:assembleDebug` and `:app:assembleRelease` pass with Gradle 8.7, Java 17, Android SDK 35, NDK 27.2.12479018, and CMake 3.22.1. Release and debug Kotlin/Java compilation, resource processing, DEX, native builds for arm64-v8a/armeabi-v7a/x86/x86_64, and signed APK packaging complete successfully. APK metadata confirms 5.5.31 / version code 480. Existing compiler/deprecation and Room query warnings remain warnings.

On-device frame timing and completed-search latency have not been measured for this update; a subsecond complete search is not established by the host checks.

## Build and use

Install 5.5.31 over the existing app. Existing embeddings, IVF indexes, blue HNSW indexes, saved searches, and preferences remain compatible; no re-embedding or index rebuild is required. Saved searches continue to show their original execution durations. Run a new search to measure the installed version.

Run `bash tools/run-hnsw-checks.sh`. Kotlin/JNI checks use `MARKVAULT_JNI_INCLUDE` and `MARKVAULT_KOTLIN_COMPILER_CP`. Saved-history checks additionally use `MARKVAULT_JSON_CP` and `MARKVAULT_GSON_CP` pointing to Gson 2.11.0. The existing optional real-model checks and their fixture variables remain available. SDKs, downloaded model weights, build products, and local build caches are excluded from the source ZIP.
