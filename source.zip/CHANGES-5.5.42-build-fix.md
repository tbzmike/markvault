# MarkVault 5.5.42 — GitHub Kotlin Build Hotfix

**Baseline:** the exact previously delivered 5.5.42 `source.zip` (versionCode 491). The app version is unchanged: this is a corrected upload of the same release, not a new feature release.

## Confirmed failure
GitHub Actions run `38417556319`, job `115365927065`, failed at `:app:compileReleaseKotlin`:

`app/src/main/java/com/tebogo/markvault/ui/SearchScreen.kt:1860:34` — no matching Compose `Modifier.padding()` overload for simultaneous `horizontal`, `top`, and `bottom` named arguments.

## Exact repair
Use the supported four-side named overload:

```kotlin
.padding(start = 14.dp, top = if (index == 0) 8.dp else 3.dp, end = 14.dp, bottom = 20.dp)
```

The layout dimensions and search-result appearance are unchanged. The visual regression test now explicitly requires the supported call.

**No HNSW, IVF, LLM, synonym/T5 expansion, reranker, result ordering, highlighting, saved searches, or unrelated app code was modified.**

## Verification scope
- GitHub Actions failure log inspected, and the sole compiler diagnostic traced to the exact expression above.
- Query-result separation and contrast tests passed.
- Original source ZIP compared file-by-file with this corrected ZIP.
- ZIP integrity and byte-for-byte inclusion verified.
- A complete Android APK build **has not been rerun or confirmed green** in this execution environment; that requires the GitHub Actions build after upload.
