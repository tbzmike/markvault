# MarkVault 5.5.37

Blue HNSW now uses a compact SQ8 vector matrix and integer SIMD for graph traversal. This replaces the graph's FP16 distance calculations; 5.5.36 only changed the later FP32 scoring stage.

- Each graph vector is scaled by its own largest absolute component and encoded as signed 8-bit values. Cosine distance accounts for each encoded vector's norm. Norm reciprocals are cached on immutable snapshots, and the query reciprocal is computed once per traversal, removing square roots and divisions from the mapped graph's distance loop.
- ARM64 uses SDOT only when the operating system reports dot-product support. Older ARM64 processors use widening NEON operations. x86 uses SSE2; other targets retain scalar operations. Four neighbors share each query load. Integer products and sums are checked against a scalar reference, including extreme signed values and odd dimensions.
- Existing format-2 indexes convert automatically when the selected model is prepared or first queried. Conversion reuses the embeddings and preserves every graph link, slot, key and tombstone. It writes and syncs a temporary snapshot, validates its native payload, then atomically replaces the file. A failed replacement keeps the complete FP16 snapshot usable. Conversion defers when a background builder holds the model lock, so an active search can continue without deadlocking that builder.
- New snapshots use file format 3. The native candidate packet is version 4 and reports the actual graph precision and selected kernel. Saved timing labels distinguish `HNSW SQ8 graph` from an FP16 fallback. The blue toggle remains the existing toggle.
- Version 5.5.37 / code 486. Room remains version 24.

M=16, construction effort 128, the 4,800-passage frontier, article limits, scope filtering, sparse-scope recovery and all-passage FP32 result scoring remain. Fresh construction retains the FP16 graph-building metric and compacts the vector matrix when saving. Incremental updates support compact snapshots. No candidate limit is reduced for speed.

SQ8 changes approximate candidate geometry, so candidate lists are not guaranteed to match FP16. In the synthetic 42,000-article / 210,000-chunk / 768-dimension host comparison, mean top-200 candidate recall against an exact FP32 oracle rose from 85.33% to 87.53%. One unrelated random query decreased from 75/200 to 65/200; the benchmark reports this decline rather than hiding it. These measurements do not establish recall on the user's library.

In that same host comparison, median full-library graph time fell from 8.10 ms to 5.24 ms; partition graph time fell from 15.35 ms to 10.23 ms. The native index payload fell from 353,750,413 to 192,470,413 bytes, with the vector matrix halved. These are graph-only host measurements. A one-time conversion took about 0.88 seconds on the host and may take longer on a phone.

Original IVF, exact FP32 arithmetic, Room ownership, embedding/reranker inference, automatic embedding and model synchronization, Markdown readers, library management, saved searches, other UI features and backup paths are retained and protected by the regression checks. Existing format-2 backups remain supported.

No phone was connected. Ten-millisecond graph latency and one-second complete search remain unverified on the phone; query embedding, keyword work, reranking and display work also contribute to total search time. The converted index is reused on later searches, without another conversion or re-embedding.

See `VERIFICATION-5.5.37.md` for the completed checks and their limits.
