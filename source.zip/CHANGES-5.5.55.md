# MarkVault 5.5.55 (504) — backup and restore performance

Baseline: 5.5.54. Backup format v7, stream schema and Room schema remain unchanged. Level 9 standard lossless ZIP DEFLATE remains enabled.

## Confirmed progress issue
The earlier backup reported the entire library-file transfer at a fixed 97%, with a counter containing already-completed database rows. Index snapshots, model files and final verification also used fixed percentages and misleading counters. This did not prove that the operation was deadlocked.

## Changes
- Backups now reserve separate progress ranges for the database (0–48%), settings, ANN snapshots (50–57%), library files (57–82%), app/model data (82–91%), manifest/finalization (92–93%) and integrity verification (94–99%). Library and model stages report actual completed files and uncompressed MiB. The total percentage is phase-weighted, not an elapsed-time prediction. Completion remains 100% only after verification.
- Reduce avoidable CPU, allocations and I/O: use a shared per-operation copy buffer, inexpensive SHA-256 hex formatting, batched database stream writes/reads, compact manifest and no redundant output flush for each article. The library scanner uses a set for file/directory collision checks. Level 9 still costs CPU while backing up.
- Restore uses selected-entry reads from a seekable ZIP with the standard ZipFile API. Settings, database, library, models and ANN stages no longer inflate unrelated payloads on this path. If a provider cannot open a seekable descriptor, standard streamed ZIP reads remain supported. Fallback occurs only before entry processing; a failed write is never retried through the fallback path.
- Full archive SHA-256 and size validation still precedes restore. The selected install streams are checked against verified manifest hashes as they are read; library files retain their content-hash matching/copy verification. No data format, embedding model, chunking, or search algorithm changes.
- Progress reports actual file counts and bytes, identifies model staging, ANN restoration, database/index rebuild and integrity checks. Model-space preflight is moved before library file restoration. No new permanent services or polling timers; callbacks are throttled by actual work.
- Previous shared Obsidian vault conflict handling, existing-file protection, duplicate-path mapping, database transaction and staged index replacement remain. Existing v4–v7 verification and v1–v3 legacy restore branches remain.

## Limits
A provider which cannot seek still requires sequential scanning of ZIP entries; storage speeds, maximum compression and very large models/SQL integrity checks can take substantial time. Restore is not globally atomic across all library, DB and app-file stages; preserve the original backup and library until successful testing. No Android APK compilation or real-device timing/restore was performed here.
