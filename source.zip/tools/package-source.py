#!/usr/bin/env python3
"""Create a reproducible source ZIP whose timestamps are safe for Ninja after unzip."""

import argparse
import stat
from pathlib import Path
from zipfile import ZIP_DEFLATED, ZipFile, ZipInfo

# ZIP's DOS timestamp has no timezone. Packing with local mtimes can turn files
# into future-dated inputs on another machine and make Ninja rerun CMake forever.
# A fixed nonzero past timestamp also makes identical source produce identical ZIPs.
ARCHIVE_TIMESTAMP = (2020, 1, 1, 0, 0, 0)
EXCLUDED_ROOTS = (".git", ".gradle", ".cxx", "build", "app/.cxx", "app/build")


def source_files(root: Path, output: Path):
    for path in sorted(root.rglob("*")):
        if not path.is_file() or path.resolve() == output.resolve():
            continue
        relative = path.relative_to(root).as_posix()
        if "__pycache__" in path.relative_to(root).parts:
            continue
        if any(relative == prefix or relative.startswith(prefix + "/") for prefix in EXCLUDED_ROOTS):
            continue
        yield path, relative


def package(root: Path, output: Path) -> int:
    files = list(source_files(root, output))
    output.parent.mkdir(parents=True, exist_ok=True)
    with ZipFile(output, "w", ZIP_DEFLATED, compresslevel=6) as archive:
        for path, relative in files:
            info = ZipInfo(relative, ARCHIVE_TIMESTAMP)
            info.create_system = 3
            info.external_attr = (stat.S_IFREG | stat.S_IMODE(path.stat().st_mode)) << 16
            info.compress_type = ZIP_DEFLATED
            archive.writestr(info, path.read_bytes(), compresslevel=6)
    with ZipFile(output) as archive:
        if archive.testzip() is not None:
            raise RuntimeError("ZIP integrity validation failed")
        for path, relative in files:
            if archive.read(relative) != path.read_bytes():
                raise RuntimeError(f"Archive content mismatch: {relative}")
            if archive.getinfo(relative).date_time != ARCHIVE_TIMESTAMP:
                raise RuntimeError(f"Unsafe archive timestamp: {relative}")
    return len(files)


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("output", type=Path)
    args = parser.parse_args()
    root = Path(__file__).resolve().parents[1]
    count = package(root, args.output.resolve())
    print(f"Created {args.output}: {count} files; bytes and archive timestamps verified")
