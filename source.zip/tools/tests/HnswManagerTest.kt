package com.tebogo.markvault.search

import android.content.Context
import com.tebogo.markvault.data.*
import kotlinx.coroutines.*
import java.io.File
import java.nio.ByteBuffer
import java.nio.ByteOrder
import java.nio.file.Files
import java.security.MessageDigest
import kotlin.math.sqrt
import kotlin.random.Random

private data class Row(val model: String, val note: Long, val chunk: Int, val bytes: ByteArray, val created: Long)
private class FakeDao : NoteDao {
    val rows = ArrayList<Row>()
    private fun selected(model: String) = rows.filter { it.model == model }.sortedWith(compareBy<Row> { it.note }.thenBy { it.chunk })
    override suspend fun embeddingCount(model: String) = selected(model).size
    override suspend fun latestEmbeddingCreatedAt(model: String) = selected(model).maxOfOrNull { it.created } ?: 0L
    override suspend fun loadHnswVectorsPage(model: String, afterNote: Long, afterChunk: Int, limit: Int) =
        selected(model).filter { it.note > afterNote || (it.note == afterNote && it.chunk > afterChunk) }.take(limit)
            .map { HnswVectorProjection(it.note, it.chunk, it.bytes) }
    override suspend fun loadHnswMetadataPage(model: String, afterNote: Long, afterChunk: Int, limit: Int) =
        selected(model).filter { it.note > afterNote || (it.note == afterNote && it.chunk > afterChunk) }.take(limit)
            .map { HnswMetadataProjection(it.note, it.chunk, it.created) }
    override suspend fun loadHnswChangedVectorsPage(model: String, notes: List<Long>, limit: Int, offset: Int) =
        selected(model).filter { it.note in notes }.drop(offset).take(limit).map { HnswVectorProjection(it.note, it.chunk, it.bytes) }
}
private fun blob(vector: FloatArray): ByteArray = ByteBuffer.allocate(vector.size * 4).order(ByteOrder.LITTLE_ENDIAN)
    .apply { vector.forEach { putFloat(it) } }.array()
private fun hash(file: File) = MessageDigest.getInstance("SHA-256").digest(file.readBytes()).toList()

fun main() = runBlocking {
    checkSearchWork()
    val directory = Files.createTempDirectory("markvault_hnsw_manager").toFile()
    val dao = FakeDao()
    val manager = HnswIndex(Context(directory))
    val reader = HnswIndex(Context(directory))
    val random = Random(473)
    val model = "test-model.v1"
    val dim = 16
    val vectors = (1..1001).associate { note ->
        val v = FloatArray(dim) { random.nextFloat() * 2 - 1 }
        val norm = sqrt(v.sumOf { (it * it).toDouble() }).toFloat()
        note.toLong() to v.map { it / norm }.toFloatArray()
    }
    try {
        for (note in 1L..1000L) for (chunk in 0..1) dao.rows.add(Row(model, note, chunk, blob(vectors.getValue(note)), 100))
        val first = manager.synchronizeModel(dao, model, dim)
        check(first.numVectors == 2000 && first.embeddingWatermark == 100L)
        val snapshot = File(directory, HnswIndex.fileName(model))
        check(manager.isAvailable(model) && snapshot.length() == first.payloadLength + first.payloadOffset)
        check(reader.prepare(model))
        val allowed = (1L..500L).toSet()
        val found = reader.findCandidates(vectors.getValue(101), model, 200, allowed)!!
        check(101L in found && found.all { it in allowed })
        val warm = reader.findCandidatesDetailed(vectors.getValue(101), model, 200, allowed)!!
        check(warm.preparationMs == 0L && warm.graphNs > 0 && warm.recoveryNs == 0L && warm.ids == found)
        check(reader.findCandidates(FloatArray(dim - 1), model, 200, null) == null)
        check(reader.findCandidates(vectors.getValue(101), model, 200, emptySet())!!.isEmpty())
        val sparse = reader.findCandidatesDetailed(vectors.getValue(101), model, 600, setOf(101,102,103))!!
        check(sparse.exhaustiveRecovery && sparse.ids == setOf(101L,102L,103L) && sparse.scoredVectors > 0)
        check(sparse.graphNs > 0 && sparse.recoveryNs > 0)

        // A bulk rebuild yields while searches keep using the complete snapshot.
        val lease = SearchWorkPriority.begin()
        val paused = async { manager.synchronizeModel(dao, model, dim, rebuild = true) }
        try {
            delay(30)
            check(!paused.isCompleted)
            check(101L in withTimeout(2000) { reader.findCandidates(vectors.getValue(101), model, 200, allowed)!! })
        } finally { lease.close() }
        withTimeout(10000) { paused.await() }

        // An edit with exactly the same row count must refresh the snapshot.
        dao.rows.removeAll { it.model == model && it.note == 101L }
        for (chunk in 0..1) dao.rows.add(Row(model, 101, chunk, blob(vectors.getValue(1001)), 101))
        val edited = manager.synchronizeModel(dao, model, dim, setOf(101))
        check(edited.generation != first.generation && edited.numVectors == first.numVectors)
        check(101L in reader.findCandidates(vectors.getValue(1001), model, 200, null)!!)

        // Deletion plus insertion has the same count, but a different stable key set.
        dao.rows.removeAll { it.model == model && it.note == 2L }
        for (chunk in 0..1) dao.rows.add(Row(model, 1001, chunk, blob(vectors.getValue(2)), 102))
        manager.synchronizeModel(dao, model, dim)
        val replacement = reader.findCandidates(vectors.getValue(2), model, 200, null)!!
        check(2L !in replacement && 1001L in replacement)
        val current = manager.stats(model)!!
        val native = NativeHnswBridge.create(dim, 0, true)
        try {
            NativeHnswBridge.open(native, snapshot.absolutePath, current.payloadOffset, true)
            val keys = NativeHnswBridge.keys(native).toSet()
            check(HnswIndex.passageKey(2, 0) !in keys && HnswIndex.passageKey(1001, 1) in keys)
        } finally { NativeHnswBridge.close(native) }

        // Failed and cancelled rebuilds must keep the only complete snapshot.
        val before = hash(snapshot)
        dao.rows.add(Row(model, 2000, 0, ByteArray(8), 103))
        check(runCatching { manager.synchronizeModel(dao, model, dim, rebuild = true) }.isFailure)
        check(hash(snapshot) == before)
        dao.rows.removeAll { it.note == 2000L }
        val cancelled = launch {
            manager.synchronizeModel(dao, model, dim, rebuild = true) { progress, _ -> if (progress > 0.1f) cancel() }
        }
        cancelled.join()
        check(cancelled.isCancelled && hash(snapshot) == before && !manager.isBuilding)

        // Each installed model gets a separate snapshot. Parallel writers share a lock.
        val other = "second-model.v1"
        for (note in 1L..600L) dao.rows.add(Row(other, note, 0, blob(vectors.getValue(note)), 200))
        manager.synchronizeModel(dao, other, dim)
        check(manager.stats(model)!!.numVectors == 2000 && manager.stats(other)!!.numVectors == 600)
        check(reader.prepare(other))
        check(101L in reader.findCandidates(vectors.getValue(1001), model, 200, allowed)!!)
        reader.unload()
        check(reader.prepare(model))
        coroutineScope { listOf(manager, reader).map { m -> async { m.synchronizeModel(dao, model, dim) } }.awaitAll() }
        val bad = File(directory, "wrong.bin").apply { writeBytes(snapshot.readBytes()) }
        check(HnswIndex.readStatsFile(bad) == null)
        bad.writeBytes(byteArrayOf(0,0,0,2))
        check(HnswIndex.readStatsFile(bad) == null)
        manager.delete(other)
        check(!manager.isAvailable(other) && manager.isAvailable(model))
        check(!reader.prepare(other) && !reader.prepare("missing-model"))
        println("Kotlin/JNI manager build/freshness/delta/delete/scope/model/cancellation/atomic snapshot checks=PASS")
    } finally {
        reader.unload(); manager.unload(); directory.deleteRecursively()
    }
}
