package com.tebogo.markvault.search

import android.content.Context
import com.tebogo.markvault.data.SearchHit
import com.sun.management.ThreadMXBean
import kotlinx.coroutines.*
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.lang.management.ManagementFactory
import java.nio.file.Files
import java.security.MessageDigest

fun main() = runBlocking {
    val directory = Files.createTempDirectory("markvault_reports").toFile()
    val context = Context(directory)
    try {
        val provenance = ResultQueryProvenance("original", listOf(QueryContribution(
            queryId = "original", queryText = "who is the queen of sheba", source = ResultQuerySource.ORIGINAL,
            keyword = true, semantic = true, contribution = 0.8, queryWeight = 1.0
        )))
        val hits = (1L..347L).map { id ->
            SearchHit(id, "folder/$id.md", "Article $id", "A long saved passage with quotations \"text\" and Unicode 🌍. ".repeat(30), "md", id.toFloat() / 347)
        }
        val saved = LegacySavedSearchStore.save(
            context, "who is the queen of sheba", 12400, "all", true, true, "Deep", true, "Selected LLM",
            listOf("Sheba queen", "queen visited Solomon"), hits.associate { it.id to "all" },
            hitProvenance = hits.associate { it.id to provenance },
            stopped = true, stoppedAtPercent = 73, stoppedAtDone = 30000, stoppedAtTotal = 42505,
            semanticEnabled = true, accurateSearchUsed = false, annEnabled = false, annUsed = false,
            hnswEnabled = true, hnswUsed = true, timingSummary = "Keyword retrieval 2.18s · ANN lookup 1.83s · Stages overlap",
            rerankApplied = true, rerankerEngine = "MiniLM-L12 reranker", scopeNoteCount = 42505, totalNoteCount = 42505,
            questionAwarenessEnabled = true, queryDetectedAsQuestion = true, questionAwarenessUsed = true,
            questionType = "WHO / identity", questionAwareQueries = listOf("the queen of Sheba was"), hits = hits
        )
        val folder = File(directory, "saved_search_results")
        val originalFile = File(folder, "${saved.id}.json")
        val template = JSONObject(originalFile.readText())
        val now = System.currentTimeMillis()
        // 214 history cards at the user's reported scale, with full payloads on disk.
        for (index in 1..213) {
            val time = now - index * 60000L
            val id = "${time}_fixture_$index"
            val obj = JSONObject(template.toString()).put("id", id).put("createdAt", time).put("query", "Saved query $index")
            File(folder, "$id.json").writeText(obj.toString())
        }
        val fingerprints = folder.listFiles()!!.associate { it.name to hash(it.readBytes()) }
        val bean = ManagementFactory.getThreadMXBean() as ThreadMXBean
        bean.isThreadAllocatedMemoryEnabled = true
        fun allocated() = bean.getThreadAllocatedBytes(bean.allThreadIds).filter { it >= 0 }.sum()
        var before = allocated()
        val full = LegacySavedSearchStore.listAll(context)
        val fullAllocated = allocated() - before
        before = allocated()
        val reports = SavedSearchStore.listReports(context)
        val reportsAllocated = allocated() - before
        check(full.size == 214 && reports.size == 214)
        for ((old, report) in full.zip(reports)) {
            check(report == SavedSearchReport.from(old)) { "Report fields/counts differ for ${old.id}" }
            check(report.session.hits.isEmpty() && report.session.hitProvenance.isEmpty() && report.session.hitScopes.isEmpty())
        }
        check(SavedSearchStore.listMeta(context) == LegacySavedSearchStore.listMeta(context))
        for (limit in listOf(0, 1, 7, 50, 100)) {
            check(SavedSearchStore.listReports(context, limit) == LegacySavedSearchStore.list(context, limit).map(SavedSearchReport::from))
        }
        check(SavedSearchStore.load(context, saved.id) == saved) { "Opening must restore exact hits/scopes/provenance/order" }
        check(folder.listFiles()!!.associate { it.name to hash(it.readBytes()) } == fingerprints) { "Browsing changed saved files" }
        check(reportsAllocated < fullAllocated * 0.4) { "Report allocations were not sufficiently reduced: $reportsAllocated vs $fullAllocated" }
        println("214 sessions × 347 hits: exact report/metadata/counts/order and unchanged files=PASS")
        println("Actual store allocation bytes: full=$fullAllocated reports=$reportsAllocated reduction=${100 - reportsAllocated * 100 / fullAllocated}%")

        // Legacy defaults, missing/unknown fields, duplicate hit IDs and invalid provenance.
        val edge = JSONObject(template.toString()).put("id", "${now}_edge").put("createdAt", now)
        edge.put("hits", JSONArray().put(JSONObject().put("id", 7).put("snippet", "first")
            .put("queryProvenance", JSONObject().put("contributions", JSONArray().put(JSONObject().put("queryText", " valid ")))))
            .put(JSONObject().put("id", 7).put("snippet", "second").put("queryProvenance", JSONObject().put("contributions", JSONArray())))
            .put(JSONObject().put("id", 8).put("queryProvenance", JSONObject().put("contributions", JSONArray().put(JSONObject().put("queryText", " "))))))
        edge.put("futureUnknownField", JSONObject().put("large", "discarded".repeat(100000)))
        val edgeFile = File(folder, "${edge.getString("id")}.json")
        for (version in 1..6) {
            val obj = JSONObject(edge.toString()).put("version", version)
            if (version < 6) obj.remove("timingSummary")
            if (version < 3) for (key in listOf("questionAwarenessEnabled", "queryDetectedAsQuestion", "questionAwarenessUsed", "questionType", "questionAwareQueries")) obj.remove(key)
            edgeFile.writeText(obj.toString())
            val old = LegacySavedSearchStore.load(context, edge.getString("id"))!!
            val actual = SavedSearchStore.listReports(context).first { it.id == old.id }
            check(actual == SavedSearchReport.from(old)) { "Legacy v$version differs" }
            check(actual.hitCount == 3 && actual.provenanceCount == 1)
        }
        edge.put("query", "Modified without a new session ID")
        edgeFile.writeText(edge.toString())
        check(SavedSearchStore.listReports(context).first { it.id == edge.getString("id") }.query == edge.getString("query"))
        val expired = "${now - 190L * 24 * 60 * 60 * 1000}_expired"
        File(folder, "$expired.json").writeText(JSONObject(template.toString()).put("id", expired).toString())
        SavedSearchStore.listReports(context)
        check(!File(folder, "$expired.json").exists())
        SavedSearchStore.delete(context, edge.getString("id"))
        check(SavedSearchStore.listReports(context).none { it.id == edge.getString("id") })
        File(folder, "${now}_broken.json").writeText("{bad JSON")
        check(SavedSearchStore.listReports(context).size == 214)
        val request = launch(Dispatchers.Default) { SavedSearchStore.listReports(context) }
        delay(5)
        request.cancelAndJoin()
        check(request.isCancelled)
        println("v1–v6 defaults, duplicate provenance counts, unknown fields, edits, deletion, six-month retention and cancellation=PASS")
    } finally { directory.deleteRecursively() }
}

private fun hash(bytes: ByteArray): String = MessageDigest.getInstance("SHA-256")
    .digest(bytes).joinToString("") { "%02x".format(it) }
