package android.content
import android.net.Uri
import android.database.Cursor
import java.io.File
import java.io.InputStream
import java.io.OutputStream

open class Context {
    open val cacheDir: File get() = File("/tmp/mv555_cache")
    open fun getDatabasePath(name: String): File = File(cacheDir,name)
    open val applicationContext: Context get() = this
    open val filesDir: File get() = File("/tmp/mv552_test_files")
    open val contentResolver: ContentResolver get() = ContentResolver()
    open val applicationInfo: ApplicationInfo get() = ApplicationInfo()
}
class ApplicationInfo { val dataDir: String = "/tmp/mv552_test_data" }
class Descriptor: java.io.Closeable { val fd=0; override fun close() {} }
open class ContentResolver {
    open fun openFileDescriptor(uri: Uri, mode: String): Descriptor? = null
    open fun query(uri: Uri, projection: Array<String>, selection: String?, args: Array<String>?, order: String?): Cursor? = null
    open fun openInputStream(uri: Uri): InputStream? = null
    open fun openOutputStream(uri: Uri, mode: String): OutputStream? = null
}
