package org.json
class JSONArray {
    private val parts: List<String>
    constructor(c: Collection<String>) { parts = c.toList() }
    constructor(s: String) { parts = Regex("\\\"([^\\\"]*)\\\"").findAll(s).map { it.groupValues[1] }.toList() }
    fun length() = parts.size
    fun getString(i: Int) = parts[i]
    override fun toString() = parts.joinToString(prefix = "[", postfix = "]") { "\"$it\"" }
}

class JSONObject {
 constructor(); constructor(s:String)
 fun put(k:String,v:Any?):JSONObject=this
 fun getString(k:String):String=""
 fun optString(k:String,d:String=""):String=d
 fun optLong(k:String,d:Long=0):Long=d
 fun optInt(k:String,d:Int=0):Int=d
 fun optJSONObject(k:String):JSONObject?=JSONObject()
 fun length():Int=0
 fun keys():MutableIterator<String> = mutableListOf<String>().iterator()
 fun has(k:String):Boolean=false
 fun toString(n:Int):String="{}"
}
