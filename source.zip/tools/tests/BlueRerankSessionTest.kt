package com.tebogo.markvault.search

import kotlinx.coroutines.*
import java.io.File
import java.nio.file.Files
import kotlin.math.abs

private fun budgetChecks() {
    val mb = 1024L * 1024L
    fun budget(avail: Long = 4096, heap: Long = 100, max: Long = 768, loaded: Int = 0,
               cores: Int = 8, lowRam: Boolean = false, low: Boolean = false) =
        FastSearchMemoryPolicy.rerankWorkers(lowRam, low, avail * mb, heap * mb, max * mb,
                                            110, 150, loaded, cores)
    check(budget() == 4 && budget(cores = 2) == 2 && budget(cores = 1) == 1)
    check(budget(cores = 0) == 0 && budget(low = true) == 0 && budget(lowRam = true) == 1)
    check(budget(heap = 538) == 0 && budget(max = 0) == 0 && budget(heap = -1) == 0)
    check(budget(avail = 811) == 0 && budget(avail = 812) == 1)
    check(budget(avail = 962) == 2 && budget(avail = 1262) == 4)
    check(budget(avail = 662, loaded = 1) == 1)
    check(budget(avail = 662, loaded = 4) == 1) // Only one set of weights is credited.
    println("Shared-session memory budget: pressure/one-worker/processor/boundary checks=PASS")
}

/** Actual ORT 1.19.2 CPU sessions and unchanged L12/L6 catalog weights, without memo hits. */
fun main(args: Array<String>) = runBlocking {
    budgetChecks()
    val assets = File(args[0])
    val dir = Files.createTempDirectory("shared-rerank-models").toFile()
    val blue = BlueRerankEngine(dir)
    val legacy = LegacyBlueRerankEngine(dir)
    try {
        for ((model, descriptor) in listOf("l12" to RerankerCatalog.MS_MARCO_MINI_LM_L12,
                                         "l6" to RerankerCatalog.MS_MARCO_MINI_LM_L6)) {
            Files.createSymbolicLink(descriptor.modelFileIn(dir).toPath(), File(assets, "reranker-$model.onnx").toPath())
            Files.createSymbolicLink(descriptor.vocabFileIn(dir).toPath(), File(assets, "reranker-vocab.txt").toPath())
            val docs = List(30) { i -> when (i % 6) {
                0 -> "The queen of Sheba visited Solomon and tested his wisdom. Article $i."
                1 -> ("Faith, hope, love and kindness. " ).repeat(85) + "Article $i."
                2 -> "Adam and Eve had sons and daughters. Cain and Abel are mentioned. Article $i."
                3 -> ("A long journey; the history of Jerusalem. " ).repeat(70) + "Article $i."
                4 -> "école αβγ 中文. \u2028 chapter $i?"
                else -> "Why? A question with a short answer. Article $i."
            } }
            var legacyPrepare = 0.0
            var newPrepare = 0.0
            var legacyScore = 0.0
            var newScore = 0.0
            val before = blue.sessionLoads
            for ((iteration, workers) in listOf(4, 2, 3, 1, 4, 2).withIndex()) {
                val query = listOf("who is the queen of sheba", "how many children did Adam and Eve have",
                    "faith hope love", "école αβγ 2026", "why?", "history of Jerusalem")[iteration]
                var started = System.nanoTime()
                check(legacy.prepare(descriptor, model, workers))
                val oldPrepareMs = (System.nanoTime() - started) / 1e6
                legacyPrepare += oldPrepareMs
                started = System.nanoTime()
                check(blue.prepare(descriptor, model, workers))
                val newPrepareMs = (System.nanoTime() - started) / 1e6
                newPrepare += newPrepareMs
                check(blue.loadedSessions == 1 && blue.loadedWorkers == workers)
                check(blue.sessionLoads == before + 1) { "Worker budget reloaded model weights" }
                started = System.nanoTime()
                val expected = legacy.scoreBatch(descriptor, model, workers, query, docs)!!
                val oldMs = (System.nanoTime() - started) / 1e6
                legacyScore += oldMs
                val progress = ArrayList<Int>()
                started = System.nanoTime()
                val actual = blue.scoreBatch(descriptor, model, workers, query, docs) { progress += it }!!
                val newMs = (System.nanoTime() - started) / 1e6
                newScore += newMs
                check(progress == (1..docs.size).toList())
                check(actual.all { it.isFinite() })
                val difference = actual.indices.maxOf { abs(actual[it] - expected[it]) }
                check(difference <= 0.0001f) { "$model shared-session difference $difference" }
                check(actual.indices.sortedByDescending { actual[it] } == expected.indices.sortedByDescending { expected[it] })
                println("$model workers=$workers model_prepare_ms=${"%.2f".format(oldPrepareMs)}->${"%.2f".format(newPrepareMs)} " +
                    "30_uncached_pairs_ms=${"%.2f".format(oldMs)}->${"%.2f".format(newMs)} max_diff=$difference exact_ranking=PASS")
            }
            println("$model six-worker-budgets preparation_ms=${"%.2f".format(legacyPrepare)}->${"%.2f".format(newPrepare)} " +
                "inference_ms=${"%.2f".format(legacyScore)}->${"%.2f".format(newScore)} new_session_loads=1")
            val entered = CompletableDeferred<Unit>()
            val job = launch(Dispatchers.IO) {
                blue.scoreBatch(descriptor, model, 4, "test", List(500) { docs[it % docs.size] }) { entered.complete(Unit) }
            }
            entered.await()
            blue.unload()
            job.cancelAndJoin()
            check(blue.loadedSessions == 0 && blue.loadedWorkers == 0)
            check(blue.prepare(descriptor, "$model-new-revision", 2))
            check(blue.loadedSessions == 1 && blue.sessionLoads == before + 2)
            val empty = blue.scoreBatch(descriptor, "$model-new-revision", 1, "test", listOf("", "faith"))!!
            check(empty[0].isNaN() && empty[1].isFinite() && blue.sessionLoads == before + 2)
            blue.unload(); legacy.unload()
            println("$model shared concurrent Run, cancellation/in-flight retirement/revision/empty input=PASS")
        }
    } finally {
        blue.unload(); legacy.unload()
        dir.listFiles()?.forEach { it.delete() }; dir.delete()
    }
}
