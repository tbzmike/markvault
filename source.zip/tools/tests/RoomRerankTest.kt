package com.tebogo.markvault.search

import com.tebogo.markvault.data.NoteEmbedding
import com.tebogo.markvault.data.NoteText
import java.nio.ByteBuffer
import java.nio.ByteOrder
import kotlinx.coroutines.runBlocking

fun main() = runBlocking {
    check(NativeHnswBridge.available)
    fun row(id: Long, chunk: Int, first: Float, model: String = "model") = NoteEmbedding(
        id, model, chunk, 4,
        ByteBuffer.allocate(16).order(ByteOrder.LITTLE_ENDIAN).putFloat(first).putFloat(0f).putFloat(0f).putFloat(0f).array(),
        0L, 1L
    )
    val text = List(1000) { "word$it" }.joinToString(" ")
    val notes = mapOf(
        1L to NoteText(1, "First", text),
        2L to NoteText(2, "Second", text),
        3L to NoteText(3, "Out of range", text),
        4L to NoteText(4, "", " "),
        5L to NoteText(5, "Title only", "")
    )
    val rows = listOf(
        row(1, 0, .1f), row(1, 1, .9f), row(1, 2, .9f),
        row(2, 1, 1f, "other model"), row(2, 1, 1f).copy(vector = byteArrayOf(1, 2, 3)),
        row(3, 0, .1f), row(3, 999, .8f), row(6, 1, 1f)
    )
    val originalChunks = buildOverlappingChunks(text, 350, 70, 30)
    for (query in listOf("word450", "who is the queen of sheba", "how many children", "", "école 中文")) {
        val prepared = BluePassages(query, informativeQueryTerms(query), isCountIntent(query)) { countAnswerStrength(query, it) }
        val dao = RoomRerankDao(rows)
        val actual = RoomRerankFixture(dao).buildBlueSemanticRerankDocuments(
            listOf(1, 2, 3, 4, 5, 99).map { it.toLong() }, notes, floatArrayOf(1f, 0f, 0f, 0f), "model", query, prepared
        )
        fun expected(id: Long, broad: String): String {
            val passage = selectCoherentRerankPassage(query, broad)
            return listOf(notes.getValue(id).title, passage).filter { it.isNotBlank() }.joinToString("\n\n")
        }
        check(dao.calls == 1)
        check(actual == mapOf(
            1L to expected(1, originalChunks[1].text),
            2L to expected(2, originalChunks[0].text),
            3L to expected(3, text),
            5L to "Title only"
        )) { "Room/native passage selection changed for $query" }
        val failed = RoomRerankDao(rows, fail = true)
        val fallback = RoomRerankFixture(failed).buildBlueSemanticRerankDocuments(
            listOf(1L), notes, floatArrayOf(1f, 0f, 0f, 0f), "model", query, prepared
        )
        check(fallback == mapOf(1L to expected(1, originalChunks[0].text)))
        val empty = RoomRerankDao(rows)
        val fixture = RoomRerankFixture(empty)
        check(fixture.buildBlueSemanticRerankDocuments(emptyList(), notes, floatArrayOf(1f), "model", query, prepared).isEmpty())
        check(fixture.buildBlueSemanticRerankDocuments(listOf(1L), notes, floatArrayOf(), "model", query, prepared).isEmpty())
        check(empty.calls == 0)
    }
    println("Actual changed ViewModel method and production DTOs compile; Room/native winner ties/model/invalid rows/missing notes/blank content/read fallback/empty queries match frozen passage oracle=PASS")
}
