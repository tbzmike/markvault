package com.tebogo.markvault.search
// Frozen 5.5.24 ranking and passage oracle, extracted from the supplied source.
import com.tebogo.markvault.data.SearchHit
fun informativeQueryTerms(query: String): Set<String> = query
        .lowercase()
        .split(Regex("[^\\p{L}\\p{N}]+"))
        .map { it.trim() }
        .filter { token ->
            token.length >= 3 &&
                !com.tebogo.markvault.search.QueryExpander.isFunctionWord(token) &&
                token !in setOf("many", "much", "number", "total")
        }
        .toSet()

fun isCountIntent(query: String): Boolean {
        val q = query.lowercase().replace(Regex("\\s+"), " ").trim()
        return Regex("\\bhow\\s+(many|much)\\b").containsMatchIn(q) ||
            Regex("\\b(number|total)\\s+of\\b").containsMatchIn(q)
    }

fun countAnswerStrength(query: String, rawText: String): Float {
        if (!isCountIntent(query)) return 1f
        if (rawText.isBlank()) return 0.35f

        val text = rawText
            .replace(Regex("(?m)^\\s*\\d{1,3}[.)]?\\s+"), " ")
            .replace(Regex("\\s+"), " ")
            .lowercase()

        // Explicit "unknown / not stated" answers are fully responsive to a
        // how-many question even though they contain no numerical quantity.
        val unknownAnswer = listOf(
            "does not say how many", "doesn't say how many", "do not know how many",
            "don't know how many", "number is not stated", "number was not stated",
            "exact number is not", "exact number was not", "not recorded how many",
            "not reveal how many", "does not reveal how many", "scriptures do not say",
            "bible does not say", "bible doesn't say", "no exact number"
        ).any { it in text }
        if (unknownAnswer) return 1f

        val terms = informativeQueryTerms(query)
        val targets = countTargetTerms(query)
        val countNouns = buildSet {
            addAll(targets)
            // Family-count synonyms are useful only when the requested target
            // is itself a child/descendant term; do not let an unrelated number
            // next to "Adam" (for example his age) masquerade as child-count evidence.
            if (targets.any { it in setOf("child", "children", "son", "sons", "daughter", "daughters", "offspring") }) {
                addAll(listOf("child", "children", "son", "sons", "daughter", "daughters", "offspring"))
            }
        }
        val nounPattern = countNouns
            .filter { it.length >= 3 }
            .sortedByDescending { it.length }
            .joinToString("|") { Regex.escape(it) }

        val numberWord = "(?:zero|one|two|three|four|five|six|seven|eight|nine|ten|eleven|twelve|" +
            "thirteen|fourteen|fifteen|sixteen|seventeen|eighteen|nineteen|twenty|thirty|forty|" +
            "fifty|sixty|seventy|eighty|ninety|hundred|thousand|dozen|\\d{1,4})"
        if (nounPattern.isNotBlank()) {
            val quantityNearNoun = Regex(
                "\\b$numberWord\\b(?:\\s+\\w+){0,3}\\s+\\b(?:$nounPattern)\\b"
            ).containsMatchIn(text) || Regex(
                "\\b(?:$nounPattern)\\b(?:\\s+\\w+){0,4}\\s+\\b$numberWord\\b"
            ).containsMatchIn(text)
            if (quantityNearNoun) return 1f
        }

        // Strong non-numeric quantity wording. Keep family-specific phrases
        // gated to family-count questions so "sons and daughters" cannot satisfy
        // an unrelated query such as "how many branch offices".
        val familyTarget = targets.any {
            it in setOf("child", "children", "son", "sons", "daughter", "daughters", "offspring")
        }
        if (familyTarget) {
            val quantifiedFamily = listOf(
                "sons and daughters", "other sons and daughters", "other children",
                "many children", "several children", "numerous children", "few children",
                "number of children", "total number", "how many children"
            ).any { it in text }
            if (quantifiedFamily) return 0.88f
        }
        if (nounPattern.isNotBlank()) {
            val genericQuantifier = Regex(
                "\\b(?:many|several|numerous|few|some|dozens? of)\\b(?:\\s+\\w+){0,2}\\s+\\b(?:$nounPattern)\\b"
            ).containsMatchIn(text)
            if (genericQuantifier) return 0.82f
        }

        // A local how-many formulation that also contains the query's content
        // terms is responsive, but weaker than an actual answer statement.
        val coverage = if (terms.isEmpty()) 0f else {
            terms.count { Regex("\\b${Regex.escape(it)}\\w*\\b").containsMatchIn(text) }
                .toFloat() / terms.size.toFloat()
        }
        if (Regex("\\bhow\\s+(many|much)\\b").containsMatchIn(text) && coverage >= 0.5f) {
            return 0.72f
        }

        // It may mention the right people/topic but it does not answer the count
        // intent. Keep it eligible (semantic models can still know synonyms),
        // but make the stronger reranker prefer genuinely answer-bearing text.
        return if (coverage >= 0.75f) 0.42f else 0.32f
    }

fun selectCoherentRerankPassage(query: String, rawPassage: String): String {
        val passage = rawPassage.trim()
        if (passage.isBlank()) return ""

        val sentences = passage
            .split(Regex("(?<=[.!?])\\s+|[\\r\\n]+"))
            .map { it.trim() }
            .filter { it.isNotBlank() }
        if (sentences.size <= 1) return passage.take(1_800)

        val terms = informativeQueryTerms(query)
        val countIntent = isCountIntent(query)
        val normalizedQuery = query.lowercase().replace(Regex("\\s+"), " ").trim()

        data class Window(val text: String, val score: Double)
        var best: Window? = null
        for (start in sentences.indices) {
            for (width in 1..3) {
                val end = (start + width).coerceAtMost(sentences.size)
                if (end <= start) continue
                val text = sentences.subList(start, end).joinToString(" ").take(1_800)
                val lower = text.lowercase().replace(Regex("\\s+"), " ")
                val words = lower.split(Regex("\\s+")).filter { it.isNotBlank() }
                if (words.isEmpty()) continue

                val covered = if (terms.isEmpty()) 0 else terms.count { term ->
                    Regex("\\b${Regex.escape(term)}\\w*\\b").containsMatchIn(lower)
                }
                val coverage = if (terms.isEmpty()) 0.0 else covered.toDouble() / terms.size.toDouble()
                val exactPhrase = normalizedQuery.isNotBlank() && normalizedQuery in lower
                val intent = if (countIntent) countAnswerStrength(query, text).toDouble() else 1.0
                val density = covered.toDouble() / words.size.coerceAtLeast(1).toDouble()

                // Coverage dominates; answer intent breaks the exact failure in
                // which "how many" occurred in one sentence and Adam/Eve/children
                // occurred in another unrelated sentence of the same big chunk.
                val score = coverage * 8.0 + intent * (if (countIntent) 3.0 else 0.5) +
                    density * 3.0 + if (exactPhrase) 2.5 else 0.0
                if (best == null || score > best!!.score) best = Window(text, score)
            }
        }
        return (best?.text ?: passage).take(1_800)
    }

fun originalKeywordRanking(ftsHits: List<SearchHit>, originalRaw: String): List<SearchHit> {
        // The original (un-quoted) phrase from the user, used for scoring + display.
        val phrase = originalRaw.trim()
            .removeSurrounding("\"")
            .lowercase()
        val tokens = phrase.split(Regex("\\s+"))
            .map { it.replace(Regex("[^\\p{L}\\p{N}]"), "") }
            .filter { it.length >= 2 }
        val tokensLower = tokens.toSet()
        val isMultiWord = tokensLower.size > 1

        data class Scored(val hit: SearchHit, val score: Int)
        val scored = ftsHits.mapNotNull { h ->
            val title = h.title.lowercase()
            val snippet = h.snippet.lowercase()

            // Match-marker count tells us how many distinct hits appeared in the snippet
            // (the FTS snippet() function wraps each match in ⟦…⟧).
            val markerCount = h.snippet.count { it == '\u27E6' }

            val titleHasPhrase = title.contains(phrase)
            val snippetHasPhrase = snippet.contains(phrase)
            val titleTokenHits = tokensLower.count { title.contains(it) }
            val snippetTokenHits = tokensLower.count { snippet.contains(it) }

            // Adjacency: are all the query tokens within a ~10-word window of each other?
            val adjacencyBonus = if (isMultiWord && snippetTokenHits == tokensLower.size) {
                val words = snippet.split(Regex("\\s+"))
                var found = false
                if (words.size >= tokensLower.size) {
                    for (i in 0..(words.size - tokensLower.size)) {
                        val end = minOf(i + 10, words.size)
                        val window = words.subList(i, end).joinToString(" ")
                        if (tokensLower.all { window.contains(it) }) { found = true; break }
                    }
                }
                if (found) 800 else 0
            } else 0

            // Word boundary bonus: phrase appears at a word boundary in the title
            val titleBoundaryBonus = if (isMultiWord && phrase.length >= 3 &&
                Regex("\\b" + Regex.escape(phrase) + "\\b").containsMatchIn(title)) 2_000 else 0

            val score = when {
                titleHasPhrase -> 10_000 + titleBoundaryBonus + markerCount * 50
                snippetHasPhrase -> 5_000 + titleTokenHits * 200 + markerCount * 100 + adjacencyBonus
                isMultiWord && titleTokenHits == tokensLower.size -> 3_500 + adjacencyBonus + markerCount * 50
                isMultiWord && snippetTokenHits == tokensLower.size -> 1_800 + adjacencyBonus + titleTokenHits * 150 + markerCount * 30
                else -> {
                    val total = titleTokenHits + snippetTokenHits
                    // Discard sparse matches — e.g. "ar" matching "art history" when only
                    // one of two query tokens appears.
                    if (isMultiWord && total < (tokensLower.size + 1) / 2) return@mapNotNull null
                    100 + titleTokenHits * 40 + snippetTokenHits * 10 + markerCount * 5
                }
            }
            Scored(h, score)
        }
        return scored
            .sortedByDescending { it.score }
            .take(150)
            .map { it.hit }
    }
fun countTargetTerms(query: String): Set<String> {
        val tokens = query.lowercase()
            .split(Regex("[^\\p{L}\\p{N}]+"))
            .filter { it.isNotBlank() }
        if (tokens.isEmpty()) return emptySet()

        var start = -1
        for (i in 0 until tokens.lastIndex) {
            if (tokens[i] == "how" && (tokens[i + 1] == "many" || tokens[i + 1] == "much")) {
                start = i + 2
                break
            }
            if ((tokens[i] == "number" || tokens[i] == "total") && tokens[i + 1] == "of") {
                start = i + 2
                break
            }
        }
        if (start !in tokens.indices) return emptySet()

        val hardStops = setOf(
            "do", "does", "did", "is", "are", "was", "were", "be", "been",
            "have", "has", "had", "can", "could", "will", "would", "shall",
            "should", "may", "might", "must", "who", "which", "where", "when",
            "why", "that", "from", "with", "into", "about"
        )
        val out = LinkedHashSet<String>()
        for (i in start until tokens.size) {
            val token = tokens[i]
            if (token in hardStops) break
            if (token in setOf("and", "or", "the", "a", "an")) continue
            if (token.length >= 2) out += token
            if (out.size >= 3) break
        }
        return out
    }
