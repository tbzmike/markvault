package com.tebogo.markvault.search

import kotlinx.coroutines.*
import java.io.File
import java.nio.file.Files
import kotlin.math.abs

/** Identical weights, inputs and shared CPU session; only dispatch order differs. */
fun main(args: Array<String>) = runBlocking {
    val assets = File(args[0])
    val dir = Files.createTempDirectory("rerank-scheduling").toFile()
    val old = LegacySharedBlueRerankEngine(dir)
    val current = BlueRerankEngine(dir)
    try {
        for ((model, descriptor) in listOf("l12" to RerankerCatalog.MS_MARCO_MINI_LM_L12,
                                         "l6" to RerankerCatalog.MS_MARCO_MINI_LM_L6)) {
            Files.createSymbolicLink(descriptor.modelFileIn(dir).toPath(), File(assets, "reranker-$model.onnx").toPath())
            Files.createSymbolicLink(descriptor.vocabFileIn(dir).toPath(), File(assets, "reranker-vocab.txt").toPath())
            val docs = List(30) { i -> when (i) {
                27 -> "The queen of Sheba tested Solomon's wisdom. ".repeat(45)
                29 -> "Faith, hope, love, kindness and wisdom. ".repeat(85)
                else -> "Article $i describes faith and wisdom."
            } }
            for (workers in listOf(1, 2, 4)) {
                check(old.prepare(descriptor, model, workers))
                check(current.prepare(descriptor, model, workers))
                for (round in 0..2) {
                    val query = "who is the queen of sheba $round"
                    var started = System.nanoTime()
                    val expected = old.scoreBatch(descriptor, model, workers, query, docs)!!
                    val before = (System.nanoTime() - started) / 1e6
                    val progress = ArrayList<Int>()
                    started = System.nanoTime()
                    val actual = current.scoreBatch(descriptor, model, workers, query, docs) { progress += it }!!
                    val after = (System.nanoTime() - started) / 1e6
                    check(progress == (1..docs.size).toList())
                    val difference = actual.indices.maxOf { abs(actual[it] - expected[it]) }
                    check(difference <= 0.0001f)
                    check(actual.indices.sortedByDescending { actual[it] } == expected.indices.sortedByDescending { expected[it] })
                    println("$model workers=$workers round=$round old_ms=${"%.2f".format(before)} new_ms=${"%.2f".format(after)} max_diff=$difference original_result_order=PASS")
                }
                val empty = current.scoreBatch(descriptor, model, workers, "faith", listOf("", "wisdom", "  "))!!
                check(empty[0].isNaN() && empty[1].isFinite() && empty[2].isNaN())
            }
            old.unload(); current.unload()
        }
    } finally {
        old.unload(); current.unload()
        dir.listFiles()?.forEach { it.delete() }; dir.delete()
    }
}
