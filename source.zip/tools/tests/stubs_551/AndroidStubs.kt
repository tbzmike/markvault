package android.content
import android.net.Uri
import android.database.Cursor
import java.io.File
import java.io.InputStream
import java.io.OutputStream
open class Context {
    open val filesDir:File get()=File("/tmp")
    open val cacheDir:File get()=File("/tmp")
    open fun getDatabasePath(name:String):File=File("/tmp",name)
    open val applicationContext:Context get()=this
    open val contentResolver:ContentResolver get()=ContentResolver()
    open val applicationInfo:ApplicationInfo get()=ApplicationInfo()
}
class ApplicationInfo {val dataDir:String="/tmp"}
open class ContentResolver {
    open fun query(uri:Uri, projection:Array<String>, selection:String?, selectionArgs:Array<String>?, sortOrder:String?):Cursor?=null
    open fun openInputStream(uri:Uri):InputStream?=null
    open fun openOutputStream(uri:Uri, mode:String):OutputStream?=null
}
