package android.database
interface Cursor:AutoCloseable {
  companion object { const val FIELD_TYPE_NULL=0; const val FIELD_TYPE_INTEGER=1; const val FIELD_TYPE_FLOAT=2; const val FIELD_TYPE_STRING=3; const val FIELD_TYPE_BLOB=4 }
  fun moveToFirst():Boolean
  fun moveToNext():Boolean
  fun getLong(col:Int):Long
  fun getInt(col:Int):Int
  fun getDouble(col:Int):Double
  fun getString(col:Int):String
  fun getBlob(col:Int):ByteArray
  fun getColumnIndex(name:String):Int=0
  fun getColumnIndexOrThrow(name:String):Int=0
  fun getType(col:Int):Int
  fun isNull(col:Int):Boolean
  override fun close(){}
}
