import com.tebogo.markvault.data.PortableBackupState
import android.database.Cursor
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteStatement
import androidx.sqlite.db.SupportSQLiteDatabase
import java.io.ByteArrayOutputStream
import java.io.ByteArrayInputStream

class FakeCursor(private val rows:List<List<Any?>>):Cursor {
    private var at = -1
    override fun moveToFirst():Boolean { at=0;return rows.isNotEmpty() }
    override fun moveToNext():Boolean { at++;return at < rows.size }
    override fun getLong(col:Int)= (rows[at][col] as Number).toLong()
    override fun getInt(col:Int)=(rows[at][col] as Number).toInt()
    override fun getDouble(col:Int)=(rows[at][col] as Number).toDouble()
    override fun getString(col:Int)=rows[at][col] as String
    override fun getBlob(col:Int)=rows[at][col] as ByteArray
    override fun getType(col:Int):Int=when(val v=rows[at][col]){
        null -> Cursor.FIELD_TYPE_NULL
        is ByteArray -> Cursor.FIELD_TYPE_BLOB
        is Float,is Double -> Cursor.FIELD_TYPE_FLOAT
        is Number -> Cursor.FIELD_TYPE_INTEGER
        is String -> Cursor.FIELD_TYPE_STRING
        else -> error("Bad type $v")
    }
    override fun isNull(col:Int)=rows[at][col] == null
}
val names=listOf("media_items","media_embeddings","playlists","pdf_page_text","pdf_annotations","pdf_history","web_bookmarks","web_history")
val schemas=names.associateWith{ t -> if(t=="media_embeddings") listOf("mediaId","modelVersion","dim","vector","sourceFingerprint","createdAt") else listOf("id","data","extra") }
val dbRows=names.associateWith {t ->
    if(t=="media_embeddings") listOf(listOf(21L,"bge-base::chunked-v1",768,byteArrayOf(1,2,3,4),"fp",123L))
    else listOf(listOf(1L,"$t-record", if(t=="pdf_page_text") null else 17.25))
}
class SourceDb: SupportSQLiteDatabase {
    override fun query(sql:String):Cursor {
        val table=names.firstOrNull{sql.contains(it)}
        if(sql.startsWith("PRAGMA"))return FakeCursor(schemas[table]!!.map{ listOf(0,it) })
        if(sql.startsWith("SELECT COUNT")&&table!=null)return FakeCursor(listOf(listOf(dbRows[table]!!.size.toLong())))
        if(sql.startsWith("SELECT *")&&table!=null)return FakeCursor(dbRows[table]!!)
        if(sql=="SELECT COUNT(*) FROM notes")return FakeCursor(listOf(listOf(2L)))
        if(sql.startsWith("SELECT id,lastOpened"))return FakeCursor(listOf(listOf(4L,99L,123,1), listOf(6L,31L,0,0)))
        error(sql)
    }
    override fun execSQL(sql:String){}
    override fun beginTransaction(){}
    override fun setTransactionSuccessful(){}
    override fun endTransaction(){}
}
class DestDb: SQLiteDatabase() {
    val written=linkedMapOf<String,MutableList<List<Any?>>>()
    val ui=mutableListOf<List<Any?>>()
    override fun rawQuery(sql:String,args:Array<String>?):Cursor {
        if(sql.startsWith("PRAGMA"))return FakeCursor(schemas[names.first{sql.contains(it)}]!!.map{listOf(0,it)})
        error(sql)
    }
    override fun execSQL(sql:String) {if(sql.startsWith("DELETE FROM ")) written[sql.substringAfter("DELETE FROM ")]= mutableListOf() }
    override fun compileStatement(sql:String):SQLiteStatement=object:SQLiteStatement() {
        val params=linkedMapOf<Int,Any?>()
        override fun clearBindings(){params.clear()}
        override fun bindLong(pos:Int,value:Long){params[pos]=value}
        override fun bindDouble(pos:Int,value:Double){params[pos]=value}
        override fun bindString(pos:Int,value:String){params[pos]=value}
        override fun bindBlob(pos:Int,value:ByteArray){params[pos]=value}
        override fun bindNull(pos:Int){params[pos]=null}
        override fun executeInsert():Long {
            val table=names.first{sql.contains("INTO $it ")}
            written.getOrPut(table){ mutableListOf() }.add(params.entries.sortedBy{it.key}.map{it.value})
            return 1
        }
        override fun executeUpdateDelete():Int {ui.add(params.entries.sortedBy{it.key}.map{it.value});return 1}
    }
}
fun main(){
    val src=SourceDb();val dest=DestDb()
    val out=ByteArrayOutputStream(); PortableBackupState.writeExtras(src,out)
    PortableBackupState.restoreExtras(dest,ByteArrayInputStream(out.toByteArray()))
    for(t in names){
        val original=dbRows[t]!!
        val restored=dest.written[t]!!
        check(original.size==restored.size)
        for(i in original.indices)for(c in original[i].indices){
            val a=original[i][c];val b=restored[i][c]
            check(if(a is ByteArray && b is ByteArray) a.contentEquals(b) else if(a is Number && b is Number) a.toDouble()==b.toDouble() else java.util.Objects.equals(a,b)){"$t field $c"}
        }
    }
    val ui=ByteArrayOutputStream();PortableBackupState.writeNoteUi(src,ui)
    PortableBackupState.restoreNoteUi(dest,ByteArrayInputStream(ui.toByteArray()))
    check(dest.ui==listOf(listOf(99L,123L,1L,4L),listOf(31L,0L,0L,6L)))
    val corrupted=out.toByteArray().clone();corrupted[0]=0
    check(runCatching { PortableBackupState.restoreExtras(DestDb(),ByteArrayInputStream(corrupted)) }.isFailure)
    println("PASS Kotlin portable state round-trip: all 8 extra tables, media embedding blob, null, float, note state, corrupt-header rejection")
}
