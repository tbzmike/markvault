package android.provider
import android.net.Uri
import android.content.ContentResolver
object DocumentsContract {
  object Document {
    const val COLUMN_DOCUMENT_ID = "id"
    const val COLUMN_DISPLAY_NAME = "name"
    const val COLUMN_MIME_TYPE = "mime"
    const val COLUMN_SIZE = "size"
    const val COLUMN_LAST_MODIFIED = "modified"
    const val MIME_TYPE_DIR = "vnd.android.document/directory"
  }
  fun getTreeDocumentId(uri:Uri):String="root"
  fun buildChildDocumentsUriUsingTree(uri:Uri,id:String):Uri=Uri()
  fun buildDocumentUriUsingTree(uri:Uri,id:String):Uri=Uri()
  fun getDocumentId(uri:Uri):String="id"
  fun createDocument(cr:ContentResolver,parent:Uri,mime:String,name:String):Uri?=Uri()
  fun deleteDocument(cr:ContentResolver,uri:Uri):Boolean=true
}
