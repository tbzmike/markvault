package android.util
object Log {
 fun e(tag:String,msg:String,t:Throwable?=null):Int=0
 fun i(tag:String,msg:String):Int=0
 fun w(tag:String,msg:String,t:Throwable?=null):Int=0
}
