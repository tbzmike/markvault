package androidx.sqlite.db
import android.database.Cursor
interface SupportSQLiteDatabase { fun query(sql:String):Cursor; fun execSQL(sql:String);fun beginTransaction();fun setTransactionSuccessful();fun endTransaction() }
