package android.database.sqlite
import android.database.Cursor
open class SQLiteDatabase:AutoCloseable {
 companion object { const val OPEN_READWRITE=0;const val OPEN_READONLY=1;fun openDatabase(path:String,factory:Any?,flags:Int):SQLiteDatabase=SQLiteDatabase() }
 fun beginTransaction(){}
 fun setTransactionSuccessful(){}
 fun endTransaction(){}
 override fun close(){}
 open fun rawQuery(sql:String,args:Array<String>?):Cursor=TODO()
 open fun execSQL(sql:String){}
 open fun compileStatement(sql:String):SQLiteStatement=SQLiteStatement()
}
open class SQLiteStatement {
 open fun clearBindings(){}
 open fun bindLong(pos:Int,value:Long){}
 open fun bindDouble(pos:Int,value:Double){}
 open fun bindString(pos:Int,value:String){}
 open fun bindBlob(pos:Int,value:ByteArray){}
 open fun bindNull(pos:Int){}
 open fun executeInsert():Long=1
 open fun executeUpdateDelete():Int=1
}
