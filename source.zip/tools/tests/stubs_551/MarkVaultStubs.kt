package com.tebogo.markvault.data
import android.content.Context
import androidx.sqlite.db.SupportSQLiteDatabase
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.flowOf
class Prefs(ctx:Context) {
 val libraryUri:Flow<String?> get() = flowOf(null)
 suspend fun clearLibraryUri(){}
 suspend fun setLibraryUri(uri:String){}
}
class Helper {val writableDatabase:SupportSQLiteDatabase get()=TODO()}
class VaultDb {val openHelper:Helper get()=Helper()
 companion object {fun get(ctx:Context)=VaultDb();fun closeForRestore(){} }
}
