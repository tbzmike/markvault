package org.json
class JSONArray { constructor(c:Collection<String>);constructor(s:String)
fun length():Int=0
fun getString(i:Int):String=""
override fun toString():String="[]" }

class JSONObject {
 constructor(); constructor(s:String)
 fun put(k:String,v:Any?):JSONObject=this
 fun optString(k:String,d:String=""):String=d
 fun optLong(k:String,d:Long=0):Long=d
 fun optInt(k:String,d:Int=0):Int=d
 fun optJSONObject(k:String):JSONObject?=JSONObject()
 fun length():Int=0
 fun keys():MutableIterator<String> = mutableListOf<String>().iterator()
 fun has(k:String):Boolean=false
 fun toString(n:Int):String="{}"
}