package com.tebogo.markvault.search
import java.io.File
object HnswIndex { fun readStatsFile(f:File):Any?=null }
object EmbeddingProgressBus {val isRunning:Holder=Holder();class Holder {val value:Boolean=false}}
