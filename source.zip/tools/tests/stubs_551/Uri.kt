package android.net
open class Uri { companion object { fun parse(s:String):Uri=Uri() } }
