"""Compile the actual changed ViewModel method and actual DTOs in host checks."""
from pathlib import Path
import re
import sys

project, output = map(Path, sys.argv[1:])
vm = (project / "app/src/main/java/com/tebogo/markvault/AppViewModel.kt").read_text()
db = (project / "app/src/main/java/com/tebogo/markvault/data/Db.kt").read_text()

def method(name):
    matches = re.findall(r"^    private (?:suspend )?fun " + name + r"\([\s\S]*?^    \}\n", vm, re.M)
    assert len(matches) == 1, name
    return matches[0]

note = re.search(r"^data class NoteText\([^\n]*\)$", db, re.M)
embedding = re.search(r"^data class NoteEmbedding\([\s\S]*?^\}", db, re.M)
assert note is not None and embedding is not None
assert "suspend fun loadEmbeddingsForNotes(modelVersion: String, noteIds: List<Long>): List<NoteEmbedding>" in db
(output / "RoomRerankData.kt").write_text("package com.tebogo.markvault.data\n" + note[0] + "\n" + embedding[0] + "\n")
header = '''package com.tebogo.markvault.search
import com.tebogo.markvault.data.NoteEmbedding
class RoomRerankDao(private val rows: List<NoteEmbedding>, private val fail: Boolean = false) {
    var calls = 0
    suspend fun loadEmbeddingsForNotes(modelVersion: String, noteIds: List<Long>): List<NoteEmbedding> {
        calls++
        if (fail) throw IllegalStateException("fixture Room read failure")
        return rows.filter { it.modelVersion == modelVersion && it.noteId in noteIds }
    }
}
class RoomRerankFixture(val dao: RoomRerankDao) {
'''
body = method("normalizedEmbeddingDot") + method("buildBlueSemanticRerankDocuments").replace("private suspend fun", "suspend fun", 1)
(output / "RoomRerankFixture.kt").write_text(header + body + "}\n")
log = (project / "tools/tests/host-stubs/Log.kt").read_text()
close = log.rindex("}")
warning = '\nfun w(tag: String, message: String, error: Throwable): Int { System.err.println("$tag: $message: ${error.message}"); return 0 }\n'
(output / "RoomRerankLog.kt").write_text(log[:close] + warning + log[close:])
