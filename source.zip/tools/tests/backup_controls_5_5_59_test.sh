#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")/../.."
SRC=app/src/main/java/com/tebogo/markvault
TMP=$(mktemp -d)
trap 'rm -rf "$TMP"' EXIT
KOTLIN_HOME=$(dirname "$(dirname "$(readlink -f "$(command -v kotlinc)")")")
COR="$KOTLIN_HOME/lib/kotlinx-coroutines-core-jvm.jar"
kotlinc "$SRC/data/BackupSelection.kt" "$SRC/service/BackupJobJournal.kt" "$SRC/service/BackupRestoreOperationState.kt" "$SRC/service/RestorePauseGate.kt" tools/tests/BackupControls559Test.kt -cp "$COR" -include-runtime -d "$TMP/verify.jar"
for status in Complete Partial Running Stopped Failed; do
  java -cp "$TMP/verify.jar:$COR" com.tebogo.markvault.service.BackupControls559TestKt "$status"
done
