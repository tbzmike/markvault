package com.tebogo.markvault.ui
// Frozen 5.5.30 scroll-effect body, using plain fields and explicit inputs for differential testing.
class LegacyScrollTracker(initialIndex: Int, initialOffset: Int) {
    private var lastScrollIndex = initialIndex
    private var lastScrollOffset = initialOffset
    private var downwardScrollAccum = 0
    private var upwardScrollAccum = 0
    fun update(index: Int, offset: Int, expandedInput: Boolean, toolbarVisibilityChangedAt: Long, now: Long): Boolean? {
        var expanded = expandedInput
        var changed: Boolean? = null
        val idx = index
        val off = offset
        val atTop = idx == 0 && off < 4

        val downDelta = when {
            idx > lastScrollIndex -> 32
            idx == lastScrollIndex && off > lastScrollOffset -> off - lastScrollOffset
            else -> 0
        }
        val upDelta = when {
            idx < lastScrollIndex -> 32
            idx == lastScrollIndex && off < lastScrollOffset -> lastScrollOffset - off
            else -> 0
        }

        if (true) {

            val inLayoutSettleWindow = now - toolbarVisibilityChangedAt < 320L
            when {
                atTop -> {
                    downwardScrollAccum = 0
                    upwardScrollAccum = 0
                    if (!expanded && !inLayoutSettleWindow) {
                        expanded = true
                        changed = expanded
                        changed = expanded
                    }
                }
                inLayoutSettleWindow -> {
                    downwardScrollAccum = 0
                    upwardScrollAccum = 0
                }
                downDelta > 0 -> {
                    downwardScrollAccum = (downwardScrollAccum + downDelta).coerceAtMost(96)
                    upwardScrollAccum = 0
                    if (downwardScrollAccum >= 24 && expanded) {
                        expanded = false
                        changed = expanded
                        downwardScrollAccum = 0
                        changed = expanded
                    }
                }
                upDelta > 0 -> {
                    upwardScrollAccum = (upwardScrollAccum + upDelta).coerceAtMost(96)
                    downwardScrollAccum = 0
                    if (upwardScrollAccum >= 18 && !expanded) {
                        expanded = true
                        changed = expanded
                        upwardScrollAccum = 0
                        changed = expanded
                    }
                }
            }
        } else {
            expanded = true
            changed = expanded
            downwardScrollAccum = 0
            upwardScrollAccum = 0
        }

        lastScrollIndex = idx
        lastScrollOffset = off
        return changed
    }
}
