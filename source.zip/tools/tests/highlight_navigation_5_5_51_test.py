#!/usr/bin/env python3
"""v5.5.51: DOM replacement, nested distinct marks, no skip on one tap, no timers."""
import json,re,subprocess
from pathlib import Path
root=Path(__file__).resolve().parents[2]
ui=root/'app/src/main/java/com/tebogo/markvault/ui'
s=(ui/'ArticleHighlightNavigation.kt').read_text()
helper=re.search(r'private fun highlightNodesJs\(safeSelector: String\): String = """(.*?)"""\.trimIndent\(\)',s,re.S).group(1).replace('$safeSelector',json.dumps('.hit'))
def script(name, step=1):
    m=re.search(r'internal fun '+name+r'\(.*?return """(.*?)"""\.trimIndent\(\)',s,re.S)
    assert m,name
    return m.group(1).replace('${highlightNodesJs(safeSelector)}',helper).replace('$step',str(step))
c=script('articleHighlightCountJs');n=script('articleHighlightNavigateJs',1);p=script('articleHighlightNavigateJs',-1)
js='''
const vm = require('vm'); const assert=require('assert');
let nodes=[], scrolls=[];
const window={innerHeight:800,pageYOffset:0,scrollTo:(x,y)=>scrolls.push([x,y])};
const document={documentElement:{scrollTop:0}, querySelectorAll:()=>nodes};
function make(id, children=[]) { let style={outline:'',outlineOffset:''};return {id,isConnected:true,
  getClientRects:()=>[{}],getBoundingClientRect:()=>({top:id*180,height:20}),
  querySelector:()=>children.length?children[0]:null,style}; }
const ctx=vm.createContext({window,document,Math,isFinite,Array});
const run=t=>vm.runInContext(t,ctx);
const a=make(1), sub=make(2), parent=make(20,[sub]), c=make(3), d=make(4),e=make(5);
nodes=[a,parent,sub,c,d,e];
assert.equal(run(COUNT),5); assert.equal(window.__mvHighlightNavIndex,-1);
run(NEXT); assert.equal(window.__mvHighlightNavTarget,a);
run(NEXT); assert.equal(window.__mvHighlightNavTarget,sub); // do not skip nested real match
run(COUNT); assert.equal(window.__mvHighlightNavIndex,1);
run(NEXT); assert.equal(window.__mvHighlightNavTarget,c);
// DOM rebuild replaces every marker. Same ordinal must survive the count probe.
const replacement=nodes.map(t=>make(t.id));
replacement[1].querySelector=()=>replacement[2]; nodes=replacement;
assert.equal(run(COUNT),5); assert.equal(window.__mvHighlightNavIndex,2);
run(NEXT); assert.equal(window.__mvHighlightNavIndex,3);
assert.equal(window.__mvHighlightNavTarget,nodes[4]);
run(PREV); assert.equal(window.__mvHighlightNavIndex,2);
run(NEXT); run(NEXT); assert.equal(window.__mvHighlightNavTarget,nodes[5]);
run(NEXT); assert.equal(window.__mvHighlightNavTarget,nodes[0]);
assert.equal(scrolls.length,8); assert(scrolls.every(v=>v.length===2 && Number.isFinite(v[1])));
assert.equal(window.__mvHighlightNavTarget.style.outline,'3px solid #FFB300');
window.__mvHighlightCancelled=true; assert.equal(run(NEXT),0);assert.equal(scrolls.length,8);
console.log('PASS distinct leaf matches, one press one step, initial first hit, nested passages, rerender ordinal, wrap, cancellation, no async scroll');
'''
js='const COUNT='+json.dumps(c)+';\nconst NEXT='+json.dumps(n)+';\nconst PREV='+json.dumps(p)+';\n'+js
r=subprocess.run(['node','-e',js],text=True,capture_output=True,timeout=15)
if r.returncode: raise AssertionError(r.stderr)
print(r.stdout.strip())
for source in ('ReaderScreen.kt','HtmlReaderScreen.kt'):
    t=(ui/source).read_text()
    assert 'articleHighlightNavigateJs' in t and 'HighlightLoadingIndicator' in t
    assert '__mvHighlightNavIndex=-1' in t and '__mvHighlightNavDecoratedTarget=null' in t
render=(root/'app/src/main/assets/render.js').read_text()
assert 'if (!window.__mvHighlightNavManual) window.__mvHighlightNavTarget = first' in render
print('PASS both readers share navigation; no new service or worker')
