#include "stored_vectors.hpp"
#include <cassert>
#include <chrono>
#include <iostream>
#include <random>
#include <cstdio>

static void exec(sqlite3* db, char const* sql) { assert(sqlite3_exec(db,sql,nullptr,nullptr,nullptr)==SQLITE_OK); }
static std::uint32_t bits(float f) { std::uint32_t b;std::memcpy(&b,&f,sizeof(b));return b; }
int main(int argc,char** argv) {
    assert(argc==2);char const* path=argv[1];std::remove(path);
    sqlite3* db=nullptr;assert(sqlite3_open(path,&db)==SQLITE_OK);
    exec(db,"PRAGMA journal_mode=WAL; CREATE TABLE notes(id INTEGER PRIMARY KEY,title TEXT,content TEXT); CREATE VIRTUAL TABLE notes_fts USING fts4(title,content,content='notes',tokenize=unicode61); CREATE TABLE note_embeddings(noteId INTEGER,chunkIndex INTEGER,modelVersion TEXT,vector BLOB,PRIMARY KEY(noteId,chunkIndex,modelVersion)); CREATE INDEX index_vectors ON note_embeddings(modelVersion,noteId);");
    std::mt19937 rng(528);std::uniform_real_distribution<float> sample(-0.1f,0.1f);
    int checked=0;
    for (int dim: {1,4,100,384,768,1024,2048}) {
        exec(db,"DELETE FROM note_embeddings; BEGIN;");
        std::vector<float> query(dim);for(auto& q:query)q=sample(rng);
        sqlite3_stmt* insert=nullptr;
        assert(sqlite3_prepare_v2(db,"INSERT INTO note_embeddings VALUES(?,?,?,?)",-1,&insert,nullptr)==SQLITE_OK);
        std::vector<std::int64_t> ids;std::vector<markvault::StoredScore> expected;
        for(int id=1;id<=600;++id) {
            ids.push_back(id);float best=0;int winner=-1;
            for(int chunk=0;chunk<5;++chunk) {
                std::vector<float> vector(dim);for(auto& v:vector)v=sample(rng);
                float sum=0;for(int d=0;d<dim;++d)sum+=query[d]*vector[d];sum=std::clamp(sum,-1.f,1.f);
                if(winner<0||sum>best){best=sum;winner=chunk;}
                sqlite3_bind_int(insert,1,id);sqlite3_bind_int(insert,2,chunk);sqlite3_bind_text(insert,3,"model-A",-1,SQLITE_STATIC);
                sqlite3_bind_blob(insert,4,vector.data(),dim*4,SQLITE_TRANSIENT);assert(sqlite3_step(insert)==SQLITE_DONE);sqlite3_reset(insert);
            }
            expected.push_back({id,winner,best});
        }
        sqlite3_finalize(insert);exec(db,"COMMIT;");
        auto start=std::chrono::steady_clock::now();
        auto result=markvault::score_stored_vectors(path,"model-A",query.data(),dim,ids);
        double ms=std::chrono::duration<double,std::milli>(std::chrono::steady_clock::now()-start).count();
        assert(result.size()==expected.size());
        for(std::size_t i=0;i<result.size();++i) {
            assert(result[i].id==expected[i].id && result[i].chunk==expected[i].chunk && bits(result[i].score)==bits(expected[i].score));++checked;
        }
        assert(markvault::score_stored_vectors(path,"model-B",query.data(),dim,ids).empty());
        // Latest committed updates are visible through WAL, not an old graph/vector snapshot.
        exec(db,"BEGIN;DELETE FROM note_embeddings WHERE noteId=1;");
        assert(markvault::score_stored_vectors(path,"model-A",query.data(),dim,{1}).size()==1);
        exec(db,"COMMIT;");
        assert(markvault::score_stored_vectors(path,"model-A",query.data(),dim,{1}).empty());
        std::cout<<"Stored FP32 dim="<<dim<<" rows=3000 articles=600 native_ms="<<ms<<" exact_bits/winner/model/WAL=PASS\n";
    }
    exec(db,"INSERT INTO note_embeddings VALUES(9999,0,'model-A',X'00');");
    float query=1;
    assert(markvault::score_stored_vectors(path,"model-A",&query,1,{9999}).empty());
    assert(markvault::score_stored_vectors(path,"model-A",&query,1,{}).empty());
    bool failed=false;try{markvault::score_stored_vectors("/nonexistent/markvault.db","model-A",&query,1,{1});}catch(...){failed=true;}assert(failed);
    // An unavailable rollback-journal database fails quickly for the caller's Room fallback.
    exec(db,"PRAGMA journal_mode=DELETE;BEGIN EXCLUSIVE;");
    failed=false;try{markvault::score_stored_vectors(path,"model-A",&query,1,{1});}catch(...){failed=true;}assert(failed);
    exec(db,"ROLLBACK;");sqlite3_close(db);
    std::cout<<checked<<" bit-exact article maxima; invalid lengths, empty scope, missing DB, lock fallback=PASS\n";
}
