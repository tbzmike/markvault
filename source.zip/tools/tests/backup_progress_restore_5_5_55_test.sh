#!/usr/bin/env bash
# Host JVM checks of the production Kotlin backup/restore sources; not an Android APK build.
set -euo pipefail
cd "$(dirname "$0")/../.."
DATA=app/src/main/java/com/tebogo/markvault/data
TMP=$(mktemp -d)
trap 'rm -rf "$TMP"' EXIT
KOTLIN_HOME=$(dirname "$(dirname "$(readlink -f "$(command -v kotlinc)")")")
COROUTINES="$KOTLIN_HOME/lib/kotlinx-coroutines-core-jvm.jar"
kotlinc "$DATA/BackupManager.kt" "$DATA/BackupZipIO.kt" "$DATA/PortableBackupFiles.kt" "$DATA/PortableBackupState.kt" "$DATA/PortableLibraryPaths.kt" \
  tools/tests/stubs_551/{Db,SQLite,Support,HnswStub,Log,MarkVaultStubs}.kt \
  tools/tests/stubs_552/{Documents,Uri,Test}.kt tools/tests/stubs_555/{Android,Json}.kt \
  tools/tests/BackupZipIO555Test.kt -cp "$COROUTINES" -include-runtime -d "$TMP/verify.jar"
java -cp "$TMP/verify.jar" com.tebogo.markvault.data.BackupZipIO555TestKt
java -cp "$TMP/verify.jar" com.tebogo.markvault.data.TestKt
java tools/tests/BackupCompression554Test.java
