"""Compile actual production scoring and compare it with the frozen delivered 5.5.35 method."""
from pathlib import Path
import re
import sys

project, output = map(Path, sys.argv[1:])
vm = (project / 'app/src/main/java/com/tebogo/markvault/AppViewModel.kt').read_text()
db = (project / 'app/src/main/java/com/tebogo/markvault/data/Db.kt').read_text()
def method(name):
    matches = re.findall(r'^    private (?:suspend )?fun ' + name + r'\([\s\S]*?^    \}\n', vm, re.M)
    assert len(matches) == 1, name
    return matches[0]
projection = re.search(r'^data class EmbeddingVectorProjection\([^\n]*\)$', db, re.M)
assert projection is not None
(output / 'BlueVectorData.kt').write_text('package com.tebogo.markvault.data\n'+projection[0]+'\n')
legacy = (project / 'tools/tests/reference/semantic_rerank_v35.kt').read_text()
header = '''package com.tebogo.markvault.search
import kotlinx.coroutines.currentCoroutineContext
import kotlinx.coroutines.ensureActive
import kotlinx.coroutines.flow.MutableStateFlow
class BlueVectorVmFixture(val dao: VectorFixtureDao) {
    data class Trace(val hnswEnabled: Boolean)
    var activeSearchTrace: Trace? = null
    val hnswSearchEnabled = MutableStateFlow(true)
    var stopped: () -> Boolean = { false }
    private fun gracefulSearchStopRequested() = stopped()
'''
current = method('semanticRerankCandidates').replace('private suspend fun', 'suspend fun', 1)
legacy = legacy.replace('private suspend fun semanticRerankCandidates', 'suspend fun legacySemanticRerankCandidates', 1)
(output / 'BlueVectorVmFixture.kt').write_text(header+method('normalizedEmbeddingDot')+current+legacy+'}\n')
