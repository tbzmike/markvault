#include "hnsw_core.hpp"
#include <chrono>
#include <fstream>
#include <iostream>
#include <numeric>
#include <random>
#include <set>
#include <sys/resource.h>

using Clock = std::chrono::steady_clock;
double ms(Clock::time_point start) { return std::chrono::duration<double, std::milli>(Clock::now() - start).count(); }
void require(bool value, char const* message) { if (!value) throw std::runtime_error(message); }
std::uint64_t key(std::size_t i) { return ((i % 42000 + 1) << 32) | (i / 42000); }

int main(int argc, char** argv) {
    try {
        std::size_t count = argc > 1 ? std::stoull(argv[1]) : 2000;
        std::size_t dim = argc > 2 ? std::stoull(argv[2]) : 384;
        std::string path = argc > 3 ? argv[3] : "/tmp/markvault_hnsw_test.bin";
        constexpr std::size_t offset = 73;
        std::mt19937 random(4725);
        std::normal_distribution<float> normal;
        std::vector<float> centers(128 * dim), vectors(count * dim);
        for (auto& v : centers) v = normal(random);
        for (std::size_t i = 0; i < count; ++i) {
            auto v = vectors.data() + i * dim;
            float norm = 0;
            for (std::size_t j = 0; j < dim; ++j) {
                v[j] = centers[((i % 42000) % 128) * dim + j] + normal(random) * 0.5f;
                norm += v[j] * v[j];
            }
            norm = std::sqrt(norm);
            for (std::size_t j = 0; j < dim; ++j) v[j] /= norm;
        }
        auto started = Clock::now();
        auto graph = std::make_unique<markvault::Hnsw>(dim, count);
        for (std::size_t i = 0; i < count; ++i) {
            graph->add(key(i), vectors.data() + i * dim, dim);
            if ((i + 1) % 25000 == 0) std::cout << "built=" << i + 1 << " elapsed_ms=" << ms(started) << std::endl;
        }
        std::cout << "build_ms=" << ms(started) << " count=" << graph->size() << " dimensions=" << dim << std::endl;
        auto existing = graph->keys();
        require(std::set<std::uint64_t>(existing.begin(), existing.end()).size() == count, "Duplicate keys");
        bool rejected = false;
        try { graph->add(key(count), vectors.data(), dim - 1); } catch (std::invalid_argument const&) { rejected = true; }
        require(rejected, "Dimension guard failed");
        rejected = false;
        float bad = std::numeric_limits<float>::quiet_NaN(), saved = vectors[0]; vectors[0] = bad;
        try { graph->add(key(count), vectors.data(), dim); } catch (std::invalid_argument const&) { rejected = true; }
        vectors[0] = saved;
        require(rejected, "Finite guard failed");

        { std::ofstream file(path, std::ios::binary); std::vector<char> header(offset, 'M'); file.write(header.data(), header.size()); }
        graph->append(path.c_str());
        std::ifstream file(path, std::ios::binary | std::ios::ate);
        require(static_cast<std::size_t>(file.tellg()) == graph->serialized_length() + offset, "Payload length mismatch");
        std::cout << "payload_bytes=" << graph->serialized_length() << std::endl;
        graph.reset();
        started = Clock::now();
        markvault::Hnsw mapped(dim, 0, false);
        mapped.open(path.c_str(), offset, false);
        require(mapped.size() == count, "Mapped count mismatch");
        std::cout << "map_open_ms=" << ms(started) << std::endl;
        std::vector<double> timings;
        double recall = 0;
        for (std::size_t q = 0; q < 12; ++q) {
            auto query = vectors.data() + (q * 7919 % count) * dim;
            started = Clock::now();
            auto results = mapped.search(query, dim, std::min<std::size_t>(4800, count));
            timings.push_back(ms(started));
            require(!results.empty() && results.front() == key(q * 7919 % count), "Self retrieval failed");
            std::vector<std::pair<float, std::uint64_t>> exact;
            exact.reserve(count);
            for (std::size_t i = 0; i < count; ++i) {
                float dot = 0;
                for (std::size_t j = 0; j < dim; ++j) dot += query[j] * vectors[i * dim + j];
                exact.emplace_back(-dot, key(i));
            }
            auto top = std::min<std::size_t>(10, count);
            std::partial_sort(exact.begin(), exact.begin() + top, exact.end());
            std::set<std::uint64_t> candidateSet(results.begin(), results.end());
            for (std::size_t i = 0; i < top; ++i) recall += candidateSet.count(exact[i].second) / double(top * 12);
        }
        std::sort(timings.begin(), timings.end());
        std::cout << "candidate_query_median_ms=" << timings[timings.size()/2]
            << " candidate_query_max_ms=" << timings.back() << " top10_in_candidate_pool=" << recall << std::endl;
        std::vector<std::uint64_t> allowed;
        for (std::uint64_t i = 1; i <= std::min<std::size_t>(10000, count); ++i) allowed.push_back(i);
        auto filtered = mapped.search(vectors.data(), dim, std::min<std::size_t>(200, count), &allowed);
        for (auto k : filtered) require(std::binary_search(allowed.begin(), allowed.end(), k >> 32), "Scope leakage");
        std::vector<std::uint64_t> none;
        require(mapped.search(vectors.data(), dim, 10, &none).empty(), "Empty scope leakage");

        // Mutable load, deleted passages, replacement at the same key, and persistence.
        markvault::Hnsw changed(dim, 0, true);
        changed.open(path.c_str(), offset, true);
        changed.remove(key(0));
        require(changed.size() == count - 1, "Remove count mismatch");
        changed.add(key(0), vectors.data() + dim, dim);
        require(changed.size() == count, "Replacement count mismatch");
        changed.remove(key(count - 1));
        auto after = changed.keys();
        require(std::find(after.begin(), after.end(), key(count - 1)) == after.end(), "Deleted key survived");
        auto updatedPath = path + ".updated";
        { std::ofstream out(updatedPath, std::ios::binary); std::vector<char> header(offset, 'M'); out.write(header.data(), offset); }
        changed.append(updatedPath.c_str());
        markvault::Hnsw reopened(dim, 0, false);
        reopened.open(updatedPath.c_str(), offset, false);
        require(reopened.size() == count - 1, "Updated snapshot mismatch");
        struct rusage memory {}; getrusage(RUSAGE_SELF, &memory);
        std::cout << "peak_rss_kb=" << memory.ru_maxrss << " checks=PASS" << std::endl;
        std::remove(path.c_str()); std::remove(updatedPath.c_str());
        return 0;
    } catch (std::exception const& e) { std::cerr << e.what() << std::endl; return 1; }
}
