package com.tebogo.markvault.search

import kotlinx.coroutines.*
import java.nio.ByteBuffer
import java.nio.ByteOrder
import java.util.concurrent.atomic.AtomicInteger
import kotlin.math.sqrt
import kotlin.random.Random

private suspend fun checkMemo() = coroutineScope {
    var clock = 0L
    val memo = SearchMemo<String, FloatArray>(2, 100, { it.copyOf() }, { clock })
    var calls = 0
    suspend fun get(key: String) = memo.getOrCompute(key) { calls++; floatArrayOf(calls.toFloat()) }!!
    val first = get("model-a:query")
    check(memo.get("model-a:query")!!.single() == 1f)
    check(memo.get("absent") == null)
    check(memo.get("model-a:query", canReuse = { false }) == null)
    first[0] = 999f
    check(get("model-a:query").single() == 1f && calls == 1)
    get("model-b:query")
    get("model-a:query") // A is most recently used.
    get("model-c:query")
    get("model-b:query")
    check(calls == 4)
    clock = 100
    check(memo.get("model-b:query") == null)
    get("model-b:query")
    check(calls == 5)
    clock = 90 // A clock reversal cannot extend the lifetime.
    get("model-b:query")
    check(calls == 6)
    repeat(2) { memo.getOrCompute("invalidated", canReuse = { false }) { calls++; floatArrayOf(1f) } }
    check(calls == 8)
    repeat(2) { check(memo.getOrCompute("missing") { calls++; null } == null) }
    check(calls == 10)
    check(runCatching { memo.getOrCompute("failure") { error("inference failed") } }.isFailure)
    check(memo.getOrCompute("failure") { floatArrayOf(7f) }!!.single() == 7f)
    val entered = CompletableDeferred<Unit>()
    val cancelled = launch {
        memo.getOrCompute("cancelled") { entered.complete(Unit); awaitCancellation() }
    }
    entered.await(); cancelled.cancelAndJoin()
    check(memo.getOrCompute("cancelled") { floatArrayOf(8f) }!!.single() == 8f)
    memo.clear()
    check(memo.getOrCompute("failure") { floatArrayOf(9f) }!!.single() == 9f)

    val concurrent = SearchMemo<String, Int>(4, 1000, { it })
    val count = AtomicInteger()
    val gate = CompletableDeferred<Unit>()
    val started = CompletableDeferred<Unit>()
    val jobs = List(40) { async(Dispatchers.Default) {
        concurrent.getOrCompute("same model and exact input") {
            count.incrementAndGet(); started.complete(Unit); gate.await(); 42
        }
    } }
    started.await(); gate.complete(Unit)
    check(jobs.awaitAll().all { it == 42 } && count.get() == 1)
    var validRevision = true
    concurrent.getOrCompute("asset changed during inference", canReuse = { validRevision }) {
        validRevision = false; 1
    }
    validRevision = true
    check(concurrent.getOrCompute("asset changed during inference") { 2 } == 2)
}

private suspend fun checkScopeMemo() = coroutineScope {
    val scopes = SearchScopeMemo()
    val count = AtomicInteger()
    val original = mutableSetOf(1L, 2L)
    val answers = List(20) { async(Dispatchers.Default) {
        scopes.get("first20k") { count.incrementAndGet(); original }
    } }.awaitAll()
    original.add(3L)
    check(count.get() == 1 && answers.all { it == setOf(1L, 2L) })
    check(scopes.get("second20k") { setOf(4L) } == setOf(4L))
    check(runCatching { scopes.get("failed") { error("DAO failure") } }.isFailure)
    check(scopes.get("failed") { setOf(7L) } == setOf(7L))
    val entered = CompletableDeferred<Unit>()
    val cancelled = launch { scopes.get("cancelled") { entered.complete(Unit); awaitCancellation() } }
    entered.await(); cancelled.cancelAndJoin()
    check(scopes.get("cancelled") { setOf(8L) } == setOf(8L))
}

private suspend fun checkParallelPipeline() = coroutineScope {
    val semanticStarted = CompletableDeferred<Unit>()
    val keywordStarted = CompletableDeferred<Unit>()
    val result = withTimeout(2000) {
        BlueSearchPipeline.retrieve(true,
            semantic = { semanticStarted.complete(Unit); keywordStarted.await(); 41 },
            keywordsAndFusion = { pending -> keywordStarted.complete(Unit); semanticStarted.await(); pending!!.await() + 1 })
    }
    check(result == 42)
    check(BlueSearchPipeline.retrieve(false, semantic = { error("IVF must stay sequential") }) { check(it == null); 7 } == 7)
    var finished = false
    BlueSearchPipeline.retrieve(true, semantic = { yield(); finished = true; 1 }) { 2 }
    check(finished) // A child may never outlive its search, even without await().
    supervisorScope {
        val entered = CompletableDeferred<Unit>()
        var released = false
        val failure = runCatching {
            BlueSearchPipeline.retrieve(true,
                semantic = { try { entered.complete(Unit); awaitCancellation() } finally { released = true } },
                keywordsAndFusion = { entered.await(); error("keyword failure") })
        }
        check(failure.isFailure && released)
    }
    val entered = CompletableDeferred<Unit>()
    var released = false
    val cancelled = launch {
        BlueSearchPipeline.retrieve(true,
            semantic = { try { entered.complete(Unit); awaitCancellation() } finally { released = true } },
            keywordsAndFusion = { it!!.await() })
    }
    entered.await(); cancelled.cancelAndJoin()
    check(released)
}

private fun checkMemoryPolicy() {
    val mb = 1024L * 1024L
    fun retain(blue: Boolean = true, lowRam: Boolean = false, lowMemory: Boolean = false,
               avail: Long = 4096 * mb, heap: Long = 200 * mb, max: Long = 512 * mb,
               pss: Long = 300 * mb, embed: Int = 110, rerank: Int = 150) =
        FastSearchMemoryPolicy.canRetain(blue, lowRam, lowMemory, avail, heap, max, pss, embed, rerank)
    for (embed in listOf(25, 23, 110, 340)) for (rerank in listOf(0, 75, 150)) check(retain(embed = embed, rerank = rerank))
    check(!retain(blue = false) && !retain(lowRam = true) && !retain(lowMemory = true))
    check(!retain(heap = 512 * mb * 70 / 100) && retain(heap = 512 * mb * 70 / 100 - 1))
    check(!retain(avail = 1024 * mb - 1) && retain(avail = 1024 * mb))
    check(!retain(avail = 1024 * mb, pss = 1024 * mb) && retain(avail = 1024 * mb, pss = 1024 * mb - 1))
    check(retain(pss = 700 * mb)) // 200k-passage graph + BGE + reranker may exceed 512 MB.
    check(!retain(avail = 1469 * mb, embed = 340, rerank = 150))
    check(retain(avail = 1470 * mb, embed = 340, rerank = 150))
    check(!retain(pss = 0) && !retain(avail = 0) && !retain(max = 0) && !retain(heap = -1))
    check(!retain(embed = 0) && !retain(rerank = -1))
}

// The existing packed Kotlin scorer is the compatibility oracle for JNI.
private fun originalPackedDot(query: FloatArray, bytes: ByteArray): Float {
    var dot = 0f
    var index = 0
    for (value in query) {
        val bits = (bytes[index].toInt() and 255) or
            ((bytes[index + 1].toInt() and 255) shl 8) or
            ((bytes[index + 2].toInt() and 255) shl 16) or
            ((bytes[index + 3].toInt() and 255) shl 24)
        dot += value * Float.fromBits(bits)
        index += 4
    }
    return dot.coerceIn(-1f, 1f)
}

private fun vectorBlob(v: FloatArray) = ByteBuffer.allocate(v.size * 4).order(ByteOrder.LITTLE_ENDIAN)
    .apply { v.forEach { putFloat(it) } }.array()

private fun normalized(random: Random, dim: Int): FloatArray {
    val v = FloatArray(dim) { random.nextFloat() * 2 - 1 }
    val norm = sqrt(v.sumOf { (it * it).toDouble() }).toFloat()
    return FloatArray(dim) { v[it] / norm }
}

private fun checkExactScoring() {
    check(NativeHnswBridge.available)
    val random = Random(476)
    var comparisons = 0
    for (dim in listOf(1, 4, 100, 103, 384, 768, 1024, 2048)) repeat(12) {
        val q = normalized(random, dim)
        val rows = Array(80) { vectorBlob(normalized(random, dim)) } + arrayOf(vectorBlob(q), ByteArray(dim * 4))
        val scores = ExactVectorScorer.score(q, rows)!!
        rows.forEachIndexed { i, blob ->
            check(scores[i].toRawBits() == originalPackedDot(q, blob).toRawBits()) { "FP32 score changed: dim=$dim row=$i" }
            comparisons++
        }
    }
    check(ExactVectorScorer.score(floatArrayOf(Float.NaN), arrayOf(ByteArray(4))) == null)
    println("Native full-precision scores bit-identical to existing Kotlin scorer: $comparisons comparisons=PASS")

    val q = normalized(random, 768)
    val rows = Array(3000) { vectorBlob(normalized(random, 768)) }
    val scalar = ArrayList<Double>(); val native = ArrayList<Double>()
    repeat(12) { round ->
        var started = System.nanoTime()
        val before = FloatArray(rows.size) { originalPackedDot(q, rows[it]) }
        val scalarMs = (System.nanoTime() - started) / 1e6
        started = System.nanoTime()
        val after = ExactVectorScorer.score(q, rows)!!
        val nativeMs = (System.nanoTime() - started) / 1e6
        check(before.contentEquals(after))
        if (round >= 3) { scalar.add(scalarMs); native.add(nativeMs) }
    }
    scalar.sort(); native.sort()
    println("Host FP32 rescoring 3000 x 768: Kotlin median_ms=${scalar[scalar.size / 2]} native median_ms=${native[native.size / 2]}")
}

fun main() = runBlocking {
    withTimeout(15000) { checkMemo(); checkScopeMemo(); checkParallelPipeline() }
    checkMemoryPolicy()
    checkExactScoring()
    val timings = SearchTimings()
    timings.add("ANN", 100, 1000); timings.add("Media", 100, 1050); timings.add("Rerank", 50, 1200)
    check(timings.summary(300).endsWith("Other retrieval 0.10s · Stages overlap"))
    val nested = SearchTimings()
    nested.add("Long", 200, 0); nested.add("Inside", 50, 100)
    check(nested.summary(250).endsWith("Other retrieval 0.05s · Stages overlap"))
    val native = SearchTimings()
    native.add("ANN lookup", 110, 0)
    native.detail("HNSW graph", 6_123_456)
    native.detail("HNSW graph", 4_000_000)
    native.detail("HNSW recovery", 80_000_000)
    check(native.summary(200) == "ANN lookup 0.11s · HNSW graph 10.12ms · HNSW recovery 80.00ms · Other retrieval 0.09s")
    println("Exact-input TTL/LRU/revision/cancellation/cache coalescing, scope snapshots, parallel ownership, memory guards and overlapping timing checks=PASS")
}
