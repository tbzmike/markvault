import java.io.*;
import java.util.*;
import java.util.zip.*;

/** Standard ZIP level 9 must preserve all payload bytes, including raw vectors. */
class BackupCompression554Test {
    static byte[] zip(Map<String, byte[]> entries, int level) throws IOException {
        var buffer = new ByteArrayOutputStream();
        try (var out = new ZipOutputStream(buffer)) {
            out.setLevel(level);
            for (var entry : entries.entrySet()) {
                out.putNextEntry(new ZipEntry(entry.getKey()));
                out.write(entry.getValue());
                out.closeEntry();
            }
        }
        return buffer.toByteArray();
    }
    static void verify(byte[] archive, Map<String,byte[]> expected) throws IOException {
        var seen = new HashSet<String>();
        try (var in = new ZipInputStream(new ByteArrayInputStream(archive))) {
            for (ZipEntry e; (e = in.getNextEntry()) != null;) {
                if (e.getMethod()!=ZipEntry.DEFLATED || !seen.add(e.getName()) ||
                    !Arrays.equals(expected.get(e.getName()),in.readAllBytes()))
                    throw new AssertionError("Incorrect payload: " + e.getName());
            }
        }
        if (!seen.equals(expected.keySet())) throw new AssertionError("Missing entries");
    }
    public static void main(String[] args) throws Exception {
        var entries = new LinkedHashMap<String,byte[]>();
        var article = new StringBuilder();
        for (int i=0;i<10000;i++) article.append("# Article ").append(i%29).append("\nOverlapping text and repeated article metadata. ").append(i%13).append('\n');
        entries.put("library/files/article.md", article.toString().getBytes(java.nio.charset.StandardCharsets.UTF_8));
        byte[] vectors = new byte[1024*1024]; new Random(554).nextBytes(vectors);
        entries.put("note_embeddings.bin",vectors);
        entries.put("search/ann/graph.bin",article.toString().getBytes(java.nio.charset.StandardCharsets.UTF_8));
        entries.put("app/models/example.bin",vectors.clone());
        entries.put("manifest.json","{\"format_version\":7}".getBytes(java.nio.charset.StandardCharsets.UTF_8));
        byte[] speed=zip(entries,Deflater.BEST_SPEED), max=zip(entries,Deflater.BEST_COMPRESSION);
        verify(speed,entries); verify(max,entries);
        if(max.length>=speed.length) throw new AssertionError("Expected savings on fixture");
        System.out.printf("PASS lossless standard ZIP round trip; mixed sample level 1: %,d bytes, level 9: %,d bytes%n",speed.length,max.length);
    }
}
