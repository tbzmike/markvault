"""Execute the production revision DDL with real FTS4 and independent WAL connections."""
import re, sqlite3, tempfile
from pathlib import Path

root = Path(__file__).resolve().parents[2]
source = (root / 'app/src/main/java/com/tebogo/markvault/search/BlueKeywordRevision.kt').read_text()
ddl = re.findall(r'db.execSQL\("([^"\n]+)"\)', source)
assert len(ddl) == 3
with tempfile.TemporaryDirectory() as tmp:
    path = str(Path(tmp) / 'notes.db')
    writer = sqlite3.connect(path)
    reader = sqlite3.connect(path)
    writer.executescript("PRAGMA journal_mode=WAL; CREATE TABLE notes(id INTEGER PRIMARY KEY,title TEXT,content TEXT,relPath TEXT,fileType TEXT); CREATE VIRTUAL TABLE notes_fts USING fts4(title,content,content='notes',tokenize=unicode61);")
    for sql in ddl[:2]: writer.execute(sql)
    for operation in ['INSERT','UPDATE','DELETE']:
        writer.execute(ddl[2].replace('${operation.lowercase()}',operation.lower()).replace('$operation',operation))
    writer.commit()
    def revision(): return reader.execute('SELECT revision FROM markvault_blue_keyword_revision WHERE id=1').fetchone()[0]
    assert revision() == 0
    writer.execute("INSERT INTO notes VALUES(1,'Queen of Sheba','She visited Solomon.','1.md','md')")
    assert revision() == 0
    writer.commit(); assert revision() == 1
    writer.execute("UPDATE notes SET title='Solomon' WHERE id=1"); writer.commit(); assert revision() == 2
    writer.execute("UPDATE notes SET content='A new passage' WHERE id=1"); writer.rollback(); assert revision() == 2
    writer.execute("UPDATE notes SET relPath='renamed.md',fileType='txt' WHERE id=1"); writer.commit(); assert revision() == 3
    writer.execute('DELETE FROM notes WHERE id=1'); writer.commit(); assert revision() == 4
    writer.close(); reader.close()
    assert sqlite3.connect(path).execute('SELECT revision FROM markvault_blue_keyword_revision').fetchone()[0] == 4
print('Production keyword revision: insert/update/delete/rename/rollback/reopen/WAL visibility=PASS')
