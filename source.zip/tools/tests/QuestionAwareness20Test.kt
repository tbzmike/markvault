import com.tebogo.markvault.search.QuestionAwareness as QA

fun assertType(question: String, type: QA.QuestionType, fragments: List<String> = emptyList()) {
    val a = QA.analyze(question)
    check(a.isQuestion && a.type == type) { "Wrong detection [$question] ${a.type}" }
    check(a.detectionConfidence >= 0.72) { "Low detection confidence: $question" }
    for (fragment in fragments) check(a.answerQueries.any { fragment in it.text }) {
        "Missing '$fragment' in [$question]: ${a.answerQueries.map { it.text }}"
    }
}
fun main() {
    assertType("Caleb who was he ?", QA.QuestionType.PERSON_IDENTITY, listOf("identity of Caleb", "background of Caleb"))
    assertType("Caleb who was he", QA.QuestionType.PERSON_IDENTITY)
    assertType("Who was Caleb?", QA.QuestionType.PERSON_IDENTITY)
    assertType("Moses why did he flee Egypt?", QA.QuestionType.WHY_REASON, listOf("Moses fled Egypt"))
    assertType("Job what happened to him?", QA.QuestionType.EVENT_OCCURRENCE, listOf("events involving Job"))
    assertType("David how old was he when he became king?", QA.QuestionType.AGE)
    assertType("Jerusalem where is it?", QA.QuestionType.LOCATION, listOf("Jerusalem is in"))
    assertType("Jesus when was he born?", QA.QuestionType.TIME_DATE, listOf("Jesus was born in"))
    assertType("Paul how many letters did he write?", QA.QuestionType.COUNT, listOf("Paul wrote letters"))
    assertType("When did Jesus die?", QA.QuestionType.TIME_DATE, listOf("date of Jesus' death"))
    assertType("Is Jesus God?", QA.QuestionType.YES_NO, listOf("Jesus God", "relationship between Jesus and God"))
    assertType("Did David kill Goliath?", QA.QuestionType.YES_NO, listOf("whether David killed Goliath"))
    assertType("Why was Jesus killed?", QA.QuestionType.WHY_REASON, listOf("Jesus died for"))
    assertType("What is Gehenna?", QA.QuestionType.DEFINITION_MEANING)
    assertType("How many children did Jacob have?", QA.QuestionType.COUNT)
    for (q in listOf("men who abuse their wives", "who magazine", "when articles", "how old testament prophecies", "site:who magazine?", "https://example.com/page?id=3?", "")) {
        check(!QA.analyze(q).isQuestion) { "False positive: '$q'" }
    }
    val unsafe = QA.analyze("What is he doing?")
    check(unsafe.isQuestion && unsafe.answerQueries.isEmpty())
    val punctuationOnly = QA.analyze("Jesus was born in Bethlehem?")
    check(punctuationOnly.isQuestion && punctuationOnly.answerQueries.isEmpty())
    for (q in listOf("Ke mang Kalebe?", "Ngubani uKalebi?")) {
        val a = QA.analyze(q)
        check(a.isQuestion && a.type == QA.QuestionType.PERSON_IDENTITY && a.answerQueries.isEmpty())
    }
    val yesNo = QA.analyze("Is Jesus God?").answerQueries.map { it.text.lowercase() }
    check("jesus is god" !in yesNo && "jesus is not god" !in yesNo) {"Bias: $yesNo"}
    for (limit in 0..10) for (modelOn in listOf(true, false)) {
        val qaSlots = QA.questionSlots(limit, modelOn)
        check(qaSlots in 0..limit)
        check(qaSlots + (limit - qaSlots) == limit)
        if (limit == 0) check(qaSlots == 0)
        if (limit == 1 && modelOn) check(qaSlots == 0)
    }
    val started = System.nanoTime()
    repeat(2500) { QA.analyze("Caleb who was he?") }
    val milliseconds = (System.nanoTime() - started) / 1_000_000L
    check(milliseconds < 6000) {"Detector overhead regression $milliseconds ms / 2500"}
    println("PASS: identity, AGE, COUNT, event, date, WHY, yes-no neutrality, false positives, multilingual fallbacks, 22 quota cases")
    println("Performance: 2500 subject-first detections in ${milliseconds}ms")
}
