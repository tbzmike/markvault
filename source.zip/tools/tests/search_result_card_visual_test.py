#!/usr/bin/env python3
"""MarkVault 5.5.41 presentation-only regressions; no Android SDK needed.

Reads the Compose call site to guard against accidental removal of the
rank/alternating-color wiring, then computes the WCAG contrast of all explicit
built-in Material color schemes using the same shade/correction coefficients.
Does not substitute for a real Android Compose build or screenshot testing.
"""
from pathlib import Path
import re

root = Path(__file__).resolve().parents[2]
screen = (root / "app/src/main/java/com/tebogo/markvault/ui/SearchScreen.kt").read_text()
activity = (root / "app/src/main/java/com/tebogo/markvault/MainActivity.kt").read_text()

assert 'itemsIndexed(filteredResults, key = { _, item -> item.id }) { index, hit ->' in screen
assert 'text = "#${index + 1}"' in screen
assert 'text = "Search result"' in screen
assert 'if (index % 2 == 0)' in screen
assert 'color = resultSurfaceColor' in screen
assert 'contentColor = resultColors.onSurface' in screen
assert 'border = androidx.compose.foundation.BorderStroke(' in screen
assert 'color = expansionPalette?.accent' in screen
assert 'resultSecondaryTextColor' in screen
assert 'SearchResultProvenanceBlock(' in screen
assert 'QueryExpansionLegend(' in screen
assert 'resultQueryProvenanceById[hit.id]' in screen
assert 'onLongPress = {' in screen and 'onTap = {' in screen

# A filtered/reranked result list is renumbered from the *visible order*,
# regardless of gaps in the original ranking or arbitrary database IDs.
visible_ids = [92004, 8, 533, 290]
assert [idx + 1 for idx, _ in enumerate(visible_ids)] == [1, 2, 3, 4]


def rgb(hex6):
    return tuple(int(hex6[i:i + 2], 16) for i in (0, 2, 4))


def luma(color):
    cs = [c / 255 for c in color]
    linear = [((c + .055) / 1.055) ** 2.4 if c > .04045 else c / 12.92 for c in cs]
    return sum(c * factor for c, factor in zip(linear, (.2126, .7152, .0722)))


def contrast(a, b):
    left, right = luma(a), luma(b)
    return (max(left, right) + .05) / (min(left, right) + .05)


def mix(a, b, portion):
    return tuple(round((1 - portion) * x + portion * y) for x, y in zip(a, b))


schemes = []
pat = r'private val (\w+)\s*=\s*(?:androidx\.compose\.material3\.)?(?:lightColorScheme|darkColorScheme)\('
for match in re.finditer(pat, activity):
    block = activity[match.end():activity.find('\n)', match.end())]
    values = {
        name: re.search(r'\b' + name + r'\s*=\s*Color\(0xFF([0-9A-Fa-f]{6})\)', block)
        for name in ('surface', 'onSurface', 'onSurfaceVariant')
    }
    if not all(values.values()):
        continue
    background, text, muted = [rgb(values[name].group(1)) for name in values]
    if contrast(text, background) < 5.3:
        goal = (0, 0, 0) if luma(text) > luma(background) else (255, 255, 255)
        background = mix(background, goal, .55)
    is_dark_tile = luma(background) < .45
    a = mix(background, text, .035 if is_dark_tile else .020)
    b = mix(background, text, .145 if is_dark_tile else .095)
    assert a != b, match.group(1)
    for tile in (a, b):
        assert contrast(text, tile) >= 4.5, (match.group(1), 'body', contrast(text, tile))
        metadata_color = muted if contrast(muted, tile) >= 4.5 else text
        assert contrast(metadata_color, tile) >= 4.5, (match.group(1), 'metadata')
    schemes.append(match.group(1))

assert len(schemes) >= 20, schemes
assert 'ObsidianColors' in schemes and 'LightColors' in schemes and 'AmoledColors' in schemes
print(f'PASS: alternating opaque cards and sequential rank; WCAG AA text contrast in {len(schemes)} built-in themes; preserved expansion chips/tap routing')
