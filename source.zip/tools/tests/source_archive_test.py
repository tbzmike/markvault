"""Verify content, permissions, timezone safety and build-cache exclusions."""

import hashlib
import importlib.util
import os
import stat
import tempfile
import time
from pathlib import Path
from zipfile import ZipFile

path = Path(__file__).resolve().parents[1] / "package-source.py"
spec = importlib.util.spec_from_file_location("markvault_package_source", path)
module = importlib.util.module_from_spec(spec)
spec.loader.exec_module(module)

with tempfile.TemporaryDirectory() as temporary:
    root = Path(temporary) / "project"
    cmake = root / "app/src/main/cpp/CMakeLists.txt"
    cmake.parent.mkdir(parents=True)
    cmake.write_text("cmake_minimum_required(VERSION 3.22.1)\n")
    # A future source mtime must never leak into the produced ZIP.
    os.utime(cmake, (time.time() + 3600 * 24, time.time() + 3600 * 24))
    script = root / "tools/check.sh"
    script.parent.mkdir()
    script.write_bytes(b"#!/bin/sh\nexit 0\n")
    script.chmod(0o755)
    ignored = root / "app/.cxx/cache.bin"
    ignored.parent.mkdir(parents=True)
    ignored.write_bytes(b"build cache")
    first, second = Path(temporary) / "one.zip", Path(temporary) / "two.zip"
    old_zone = os.environ.get("TZ")
    try:
        for zone, destination in (("UTC", first), ("Asia/Qyzylorda", second)):
            os.environ["TZ"] = zone
            time.tzset()
            assert module.package(root, destination) == 2
        assert hashlib.sha256(first.read_bytes()).digest() == hashlib.sha256(second.read_bytes()).digest()
        with ZipFile(first) as archive:
            assert set(archive.namelist()) == {"app/src/main/cpp/CMakeLists.txt", "tools/check.sh"}
            assert archive.read("tools/check.sh") == script.read_bytes()
            assert stat.S_IMODE(archive.getinfo("tools/check.sh").external_attr >> 16) == 0o755
            for zone in ("UTC", "Pacific/Kiritimati", "America/Los_Angeles", "Africa/Johannesburg"):
                os.environ["TZ"] = zone
                time.tzset()
                for info in archive.infolist():
                    stamp = time.mktime((*info.date_time, 0, 0, -1))
                    assert 0 < stamp < time.time() - 24 * 3600
    finally:
        if old_zone is None:
            os.environ.pop("TZ", None)
        else:
            os.environ["TZ"] = old_zone
        time.tzset()
print("Source ZIP future-mtime/timezone/reproducibility/permissions/exclusion checks=PASS")
