"""Pin the original computations and default-path options after adding blue query threading."""
from pathlib import Path
import hashlib
import json
import re

root = Path(__file__).resolve().parents[2]
name = "app/src/main/java/com/tebogo/markvault/search/OnnxBertEmbedderBackend.kt"
original = (root / name).read_text()
manifest = json.loads((Path(__file__).parent / "query-embedding-preservation-5.5.29.json").read_text())
start = original.index("            val ids = tok.encode(sliced, maxLength = 512)")
end = original.index("}.getOrNull()", start)
forward = re.sub(r"\s+", "", original[start:end])
assert hashlib.sha256(forward.encode()).hexdigest() == manifest["forward_sha256"]
legacy = (root / "tools/tests/LegacyOnnxBertEmbedderBackend.kt").read_text().split("\n", 1)[1].replace("internal class LegacyOnnxBertEmbedderBackend(", "internal class OnnxBertEmbedderBackend(")
assert hashlib.sha256(legacy.encode()).hexdigest() == manifest["base_model_hash"]
assert "embedConfigured(text, 0)" in original
assert "minOf(2, Runtime.getRuntime().availableProcessors()).coerceAtLeast(1)" in original
assert "if (threads > 0) {\n                    opts.setIntraOpNumThreads(threads)" in original
assert "poolAndNormalize(hidden[0], attentionMask)" in original
assert "if (inferenceBusy) retireAfterInference = true else releaseSession()" in original

protected = re.sub(r"\n    private var inferenceBusy = false[\s\S]*?    internal val isLoaded: Boolean get\(\) = session != null\n", "", original)
patterns = [
    r"    override suspend fun embed\(text: String\): FloatArray\? = embedConfigured\(text, 0\)[\s\S]*?(?=    /\*\*\n     \* Reduce per-token)",
    r"    @Synchronized\n    override fun close\(\) \{[\s\S]*?(?=    /\*\*\n     \* Initialise)",
    r"    @Synchronized\n    private fun ensureLoaded\(threads: Int\): Boolean \{[\s\S]*?\n    \}\n",
]
for pattern in patterns:
    protected, matches = re.subn(pattern, "", protected, flags=re.M)
    assert matches == 1, pattern
assert hashlib.sha256(protected.encode()).hexdigest() == manifest["unchanged_outer_sha256"]

facade = (root / "app/src/main/java/com/tebogo/markvault/search/Embedder.kt").read_text()
facade, matches = re.subn(r"    /\*\* Blue HNSW queries use bounded CPU threads; IVF/indexing retain the original options\. \*/\n    suspend fun embedFastQuery\(text: String\): FloatArray\? =\n        if \(backend is OnnxBertEmbedderBackend\) backend.embedForSearch\(text\) else backend.embed\(text\)\n\n", "", facade)
assert matches == 1
assert hashlib.sha256(facade.encode()).hexdigest() == "440d06fb010f45dde9ed9a30c187955e905e0f381230332e90e0f3be2664b40e"
vm = (root / "app/src/main/java/com/tebogo/markvault/AppViewModel.kt").read_text()
assert "}) { searchEmbedder.embedFastQuery(queryForEmbedding) }\n        } else searchEmbedder.embed(queryForEmbedding))" in vm
assert "prepareBlueReranker()" not in vm
print("Original query preprocessing/forward/pooling/normalization, default IVF/indexing options and MediaPipe routing=PASS")
