package com.tebogo.markvault.search

import android.content.Context
import com.tebogo.markvault.data.SearchHit
import kotlinx.coroutines.runBlocking
import org.json.JSONObject
import java.io.File
import java.nio.file.Files

fun main() = runBlocking {
    val directory = Files.createTempDirectory("markvault_saved_timing").toFile()
    try {
        val context = Context(directory)
        val summary = "Query embedding 0.45s · ANN lookup 0.08s · Reranking 4.50s · Other retrieval 0.12s"
        val hit = SearchHit(7, "seven.md", "Seven", "A match", "md", 0.9f)
        val session = SavedSearchStore.save(
            context, "query", 5150, "all", false, true, "Deep", false, "", emptyList(), emptyMap(),
            hnswEnabled = true, hnswUsed = true, timingSummary = summary, hits = listOf(hit)
        )
        val loaded = SavedSearchStore.load(context, session.id)!!
        check(loaded.metadataVersion == 6 && loaded.timingSummary == summary)
        check(loaded.hnswUsed && loaded.hnswEnabled && loaded.hits == listOf(hit))
        check(SavedSearchStore.list(context).single().timingSummary == summary)

        val file = File(directory, "saved_search_results/${session.id}.json")
        val legacy = JSONObject(file.readText()).put("version", 5)
        legacy.remove("timingSummary")
        file.writeText(legacy.toString())
        val previous = SavedSearchStore.load(context, session.id)!!
        check(previous.metadataVersion == 5 && previous.timingSummary.isEmpty())
        check(previous.hnswUsed && previous.hits == listOf(hit))
        println("Saved timing metadata roundtrip and v5 backward compatibility checks=PASS")
    } finally { directory.deleteRecursively() }
}
