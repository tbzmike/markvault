#include "hnsw_core.hpp"
#include "reference/hnsw_v36.hpp"
#include <chrono>
#include <filesystem>
#include <fstream>
#include <iostream>
#include <random>
#include <set>

using Clock=std::chrono::steady_clock;
double ms(Clock::time_point start) {return std::chrono::duration<double,std::milli>(Clock::now()-start).count();}
void report(char const* label,std::vector<double> values) {
    std::sort(values.begin(),values.end());
    std::cout<<label<<" median_ms="<<values[values.size()/2]<<" p95_ms="<<values[(values.size()-1)*95/100]
             <<" min_ms="<<values.front()<<" max_ms="<<values.back()<<std::endl;
}
int main(int argc,char** argv) {
    auto articles=argc>1?std::stoull(argv[1]):4200,dim=argc>2?std::stoull(argv[2]):128;
    auto root=argc>3?std::string(argv[3]):"/tmp/markvault_sq8_benchmark";
    std::filesystem::create_directories(root);
    auto old_path=root+"/fp16.bin",new_path=root+"/sq8.bin";
    constexpr std::size_t chunks=5;
    auto count=articles*chunks,split=articles*20/42;
    std::mt19937 rng(55126);std::normal_distribution<float> normal;
    std::vector<float> centers(128*dim),vectors(count*dim),prototype(dim);
    for(auto& v:centers)v=normal(rng);
    for(std::size_t n=0;n<articles;++n) {
        auto topic=n%64+(n>=split?64:0);
        for(std::size_t d=0;d<dim;++d)prototype[d]=centers[topic*dim+d]+.35f*normal(rng);
        for(std::size_t c=0;c<chunks;++c) {
            auto v=vectors.data()+(n*chunks+c)*dim;float norm=0;
            for(std::size_t d=0;d<dim;++d){v[d]=prototype[d]+.07f*normal(rng);norm+=v[d]*v[d];}
            for(std::size_t d=0;d<dim;++d)v[d]/=std::sqrt(norm);
        }
    }
    auto start=Clock::now();
    if(!std::filesystem::exists(old_path)) {
        markvault_v36::Hnsw build(dim,count);
        for(std::size_t n=0;n<articles;++n) {
            for(std::size_t c=0;c<chunks;++c)build.add((std::uint64_t(n+1)<<32)|c,vectors.data()+(n*chunks+c)*dim,dim);
            if((n+1)%5000==0)std::cout<<"built_articles="<<n+1<<" elapsed_ms="<<ms(start)<<std::endl;
        }
        {std::ofstream f(old_path,std::ios::binary);f.put('M');}build.append(old_path.c_str());
        std::cout<<"FP16 build_ms="<<ms(start)<<std::endl;
    }
    {
        markvault::Hnsw convert(dim,0,false,true);convert.open(old_path.c_str(),1,false);
        start=Clock::now();{std::ofstream f(new_path,std::ios::binary);f.put('M');}convert.append(new_path.c_str());
        std::cout<<"conversion_ms="<<ms(start)<<" vectors="<<count<<" dim="<<dim
                 <<" FP16_bytes="<<std::filesystem::file_size(old_path)<<" SQ8_bytes="<<std::filesystem::file_size(new_path)<<std::endl;
    }
    markvault_v36::Hnsw previous(dim,0,false);markvault::Hnsw current(dim,0,false,true);
    previous.open(old_path.c_str(),1,false);current.open(new_path.c_str(),1,false);
    std::vector<std::uint64_t> first,second,sparse{1,3,7},empty;
    for(std::size_t n=1;n<=articles;++n)(n<=split?first:second).push_back(n);
    std::vector<std::vector<float>> queries;
    for(std::size_t i=0;i<24;++i) {
        std::vector<float> q(dim);
        if(i<12)std::copy_n(vectors.data()+((i*7919)%articles)*chunks*dim,dim,q.data());
        else {float norm=0;for(auto& v:q){v=normal(rng);norm+=v*v;}for(auto& v:q)v/=std::sqrt(norm);}
        queries.push_back(std::move(q));
    }
    std::vector<double> old_all,new_all,old_cpu,new_cpu,old_scoped,new_scoped;
    double old_hits[3]{},new_hits[3]{};std::size_t trials=0,comparisons=0;
    for(auto const& q:queries) for(auto allowed:std::array<std::vector<std::uint64_t> const*,5>{nullptr,&first,&second,&sparse,&empty}) {
        std::vector<std::pair<float,std::uint64_t>> oracle;
        for(std::size_t n=0;n<articles;++n) {
            if(allowed&&!std::binary_search(allowed->begin(),allowed->end(),n+1))continue;
            float best=-1;
            for(std::size_t c=0;c<chunks;++c) {
                float dot=0;auto v=vectors.data()+(n*chunks+c)*dim;
                for(std::size_t d=0;d<dim;++d)dot+=q[d]*v[d];
                best=std::max(best,dot);
            }
            oracle.emplace_back(-best,n+1);
        }
        std::sort(oracle.begin(),oracle.end());
        for(int round=0;round<3;++round) {
            markvault_v36::Hnsw::ArticleCandidates before;markvault::Hnsw::ArticleCandidates after;
            auto old_run=[&]{before=previous.article_candidates(q.data(),dim,600,200,allowed);};
            auto new_run=[&]{after=current.article_candidates(q.data(),dim,600,200,allowed);};
            if(comparisons%2){new_run();old_run();}else{old_run();new_run();}
            ++comparisons;
            if(after.articles.size()!=before.articles.size()||after.passages!=before.passages||after.exhaustive!=before.exhaustive||after.scalar_bits!=8)
                throw std::runtime_error("Candidate breadth/coverage changed");
            for(auto id:after.articles)if(allowed&&!std::binary_search(allowed->begin(),allowed->end(),id))throw std::runtime_error("SQ8 scope leak");
            if(round&& !allowed){old_all.push_back(before.graph_ns/1e6);new_all.push_back(after.graph_ns/1e6);old_cpu.push_back(before.graph_cpu_ns/1e6);new_cpu.push_back(after.graph_cpu_ns/1e6);}
            else if(round&&allowed&&allowed->size()>10){old_scoped.push_back(before.graph_ns/1e6);new_scoped.push_back(after.graph_ns/1e6);}
            if(round==0&&!oracle.empty()&&(!allowed||allowed->size()>10)) {
                std::set<std::uint64_t> a(before.articles.begin(),before.articles.end()),b(after.articles.begin(),after.articles.end());
                int limits[]{10,50,200};
                for(int k=0;k<3;++k) {
                    auto limit=std::min<std::size_t>(limits[k],oracle.size());double oa=0,nb=0;
                    for(std::size_t i=0;i<limit;++i){oa+=a.count(oracle[i].second);nb+=b.count(oracle[i].second);}
                    old_hits[k]+=oa/limit;new_hits[k]+=nb/limit;
                    if(nb+.02*limit<oa) {
                        std::cerr<<"individual recall decrease trial="<<trials<<" scope="<<(allowed?allowed->size():articles)
                                 <<" k="<<limit<<" FP16_hits="<<oa<<" SQ8_hits="<<nb<<std::endl;
                    }
                }
                ++trials;
            }
        }
    }
    std::cout<<"comparisons="<<comparisons<<" recall_trials="<<trials<<" kernel="<<markvault::sq8::kernel()<<std::endl;
    // Quantized candidates need not be identical. Retain breadth and require mean
    // FP32-oracle recall to stay within 0.5 percentage points of the old graph,
    // reporting individual declines as well as aggregate gains.
    for(int k=0;k<3;++k) {
        std::cout<<"recall@"<<std::array<int,3>{10,50,200}[k]<<" FP16="<<old_hits[k]/trials<<" SQ8="<<new_hits[k]/trials<<std::endl;
        if(new_hits[k]/trials+.005<old_hits[k]/trials)
            throw std::runtime_error("SQ8 mean candidate recall loses over 0.5 percentage points");
    }
    report("5.5.36 full graph",old_all);report("5.5.37 full graph",new_all);
    report("5.5.36 graph CPU",old_cpu);report("5.5.37 graph CPU",new_cpu);
    report("5.5.36 partition graph",old_scoped);report("5.5.37 partition graph",new_scoped);
    std::cout<<"FP32-oracle/SQ8 breadth/scope/recall checks PASS (synthetic host benchmark, not phone latency)"<<std::endl;
}
