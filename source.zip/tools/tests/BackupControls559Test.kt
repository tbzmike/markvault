package com.tebogo.markvault.service

import com.tebogo.markvault.data.BackupModelSelection
import com.tebogo.markvault.data.BackupOperationStoppedException
import java.io.File
import java.io.IOException
import java.nio.file.Files
import java.util.concurrent.CountDownLatch
import java.util.concurrent.TimeUnit
import java.util.concurrent.atomic.AtomicInteger

fun main(args: Array<String>) {
    val selections = BackupModelSelection
    val prefix = "app/files/"
    val entries = selections.groups.flatMap { group -> group.paths.map { prefix + it } } +
        listOf(prefix + "models/t5-base/encoder_model.onnx", prefix + "saved/search.json")
    check(selections.available(entries) == selections.ALL)
    for (group in selections.groups) {
        val chosen = entries.filter { selections.includes(group.flag, it) }
        check(chosen.isNotEmpty())
        check(chosen.all { selections.groupFor(it) == group.flag })
        check(entries.filterNot { it in chosen }.none { selections.includes(group.flag, it) })
    }
    check(entries.none { selections.includes(0, it) })
    check(!selections.valid(-1) && !selections.valid(1024))
    val mb = 1048576L
    check(!selections.fits(200 * mb, 250 * mb))
    check(selections.fits(50 * mb, 250 * mb))
    check(selections.fits(200 * mb, 250 * mb, 1))
    check(!selections.fits(Long.MAX_VALUE, 250 * mb))
    check(selections.isNoSpace(IOException("write failed", IOException("ENOSPC"))))
    check(!selections.isNoSpace(IOException("permission denied")))
    println("PASS nine individual model groups + saved data, storage budget and ENOSPC classification")
    val gate = RestorePauseGate()
    val paused = CountDownLatch(1)
    val stopped = CountDownLatch(1)
    val steps = AtomicInteger(0)
    gate.request(true)
    val worker = Thread {
        try { gate.checkpoint({ paused.countDown() }, {}); steps.incrementAndGet() }
        catch (_: BackupOperationStoppedException) { stopped.countDown() }
    }
    worker.start()
    check(paused.await(3, TimeUnit.SECONDS))
    gate.close()
    check(stopped.await(3, TimeUnit.SECONDS))
    worker.join(3000)
    check(steps.get() == 0)
    check(runCatching { gate.checkpoint({}, {}) }.exceptionOrNull() is BackupOperationStoppedException)
    val resume = RestorePauseGate(); val at = CountDownLatch(1); val done = CountDownLatch(1)
    resume.request(true)
    val worker2 = Thread { resume.checkpoint({ at.countDown() }, {}); steps.incrementAndGet(); done.countDown() }
    worker2.start(); check(at.await(3, TimeUnit.SECONDS)); resume.request(false)
    check(done.await(3, TimeUnit.SECONDS)); worker2.join(3000); check(steps.get() == 1)
    println("PASS pause releases on resume; Stop wakes paused worker and prevents further work")
    val directory = Files.createTempDirectory("mv559-journal").toFile()
    try {
        val journal = File(directory, "state/job.properties")
        val status = args.firstOrNull() ?: "Complete"
        val record = BackupJobJournal.Record("request-001", "RESTORE", status, "Previous result")
        BackupJobJournal.write(journal, BackupJobJournal.Record("request-001", "RESTORE", "Running", "Started"))
        BackupJobJournal.write(journal, record)
        check(BackupJobJournal.read(journal) == record)
        BackupRestoreOperationState.recover(journal)
        val recovered = BackupRestoreOperationState.state.value
        check(!recovered.running)
        check(recovered.stage == if (status == "Running") "Interrupted" else status)
        check(recovered.percent == if (status == "Complete" || status == "Partial") 100 else 0)
        check(recovered.message?.isNotBlank() == true)
        println("PASS durable $status status recovered without starting work")
    } finally { directory.deleteRecursively() }
}
