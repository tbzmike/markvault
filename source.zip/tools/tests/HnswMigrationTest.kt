package com.tebogo.markvault.search

import android.content.Context
import android.system.Os
import com.tebogo.markvault.data.*
import kotlinx.coroutines.*
import java.io.DataOutputStream
import java.io.File
import java.nio.file.Files

private fun installLegacy(directory: File, payload: ByteArray, model: String): File =
    File(directory, HnswIndex.fileName(model)).apply {
        DataOutputStream(outputStream()).use { out ->
            out.writeInt(2); out.writeUTF(model); out.writeInt(16); out.writeInt(16)
            out.writeInt(1000); out.writeLong(123); out.writeInt(1000); out.writeLong(456)
            out.writeLong(789); out.writeLong(payload.size.toLong()); out.write(payload)
        }
    }

fun main(args: Array<String>) = runBlocking {
    val payload = File(args.single()).readBytes()
    val directory = Files.createTempDirectory("markvault_legacy_migration").toFile()
    val manager = HnswIndex(Context(directory))
    val writer = HnswIndex(Context(directory))
    val model = "legacy-model.v1"
    val query = FloatArray(16) { kotlin.math.sin((101 * (it + 1)).toFloat() * .013f) }
    try {
        val snapshot = installLegacy(directory, payload, model)
        val old = manager.stats(model)!!
        check(old.formatVersion == 2)
        check(manager.prepare(model))
        val updated = manager.stats(model)!!
        check(updated.formatVersion == 3 && updated.generation != old.generation && updated.dim == old.dim &&
            updated.numVectors == old.numVectors && updated.embeddingWatermark == old.embeddingWatermark &&
            updated.embeddingCountAtBuild == old.embeddingCountAtBuild && snapshot.length() < old.payloadLength + old.payloadOffset)
        val result = manager.findCandidatesDetailed(query, model, 600, null)!!
        check(result.sq8 && result.graphKernel in 0..3 && 101L in result.ids)
        val stored = snapshot.readBytes()
        check(manager.prepare(model) && snapshot.readBytes().contentEquals(stored))
        check(manager.findCandidatesDetailed(query, model, 600, null)!!.preparationMs == 0L)

        // Fail the atomic replacement after the compact payload has been mapped and validated.
        manager.unload(); installLegacy(directory, payload, model)
        val original = snapshot.readBytes()
        Os.failNextRename = true
        check(manager.prepare(model)) // Original complete FP16 remains usable.
        check(manager.stats(model)!!.formatVersion == 2 && snapshot.readBytes().contentEquals(original))
        check(directory.listFiles()!!.none { it.name.startsWith("hnsw_sq8_") })
        check(manager.findCandidatesDetailed(query, model, 600, null)!!.sq8) // Retry completes conversion.

        // A builder can hold the model mutex while yielding to an active search.
        // Migration must defer, not wait for that mutex and deadlock the query.
        manager.unload(); installLegacy(directory, payload, model)
        val noReads = object : NoteDao {
            override suspend fun embeddingCount(model: String): Int = error("Paused builder must not read Room")
            override suspend fun latestEmbeddingCreatedAt(model: String): Long = error("No Room read")
            override suspend fun loadHnswVectorsPage(model: String, afterNote: Long, afterChunk: Int, limit: Int): List<HnswVectorProjection> = error("No Room read")
            override suspend fun loadHnswMetadataPage(model: String, afterNote: Long, afterChunk: Int, limit: Int): List<HnswMetadataProjection> = error("No Room read")
            override suspend fun loadHnswChangedVectorsPage(model: String, notes: List<Long>, limit: Int, offset: Int): List<HnswVectorProjection> = error("No Room read")
        }
        val lease = SearchWorkPriority.begin()
        val paused = async { writer.synchronizeModel(noReads, model, 16, rebuild = true) }
        try {
            withTimeout(2000) { while (!writer.isBuilding) delay(1) }
            val deferred = withTimeout(2000) { manager.findCandidatesDetailed(query, model, 600, null)!! }
            check(!deferred.sq8 && 101L in deferred.ids && manager.stats(model)!!.formatVersion == 2)
            paused.cancelAndJoin()
        } finally { paused.cancel(); lease.close() }
        check(manager.findCandidatesDetailed(query, model, 600, null)!!.sq8)
        val other = "legacy-second-model.v1"
        installLegacy(directory, payload, other)
        check(manager.prepare(other) && manager.stats(other)!!.formatVersion == 3)
        check(manager.stats(model)!!.formatVersion == 3)
        manager.unload(); installLegacy(directory, payload, model) // Restored format-2 backups remain supported.
        check(manager.prepare(model) && manager.stats(model)!!.formatVersion == 3)
        println("Actual 5.5.36 payload: auto SQ8 conversion/watermark/model separation/restore/atomic failure/FP16 fallback/paused-builder concurrency=PASS")
    } finally {
        manager.unload(); writer.unload(); directory.deleteRecursively()
    }
}
