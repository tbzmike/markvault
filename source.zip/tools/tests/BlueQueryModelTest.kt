package com.tebogo.markvault.search

import android.content.Context
import kotlinx.coroutines.*
import java.io.File
import java.nio.file.Files
import kotlin.math.abs

/** Compare actual original/default/blue ONNX outputs, model switches and native session lifetime. */
fun main(args: Array<String>) = runBlocking {
    val assets = File(args[0])
    val dir = Files.createTempDirectory("blue-query-models").toFile()
    var compared = 0
    try {
        for ((name, descriptor) in listOf("minilm" to ModelCatalog.MINI_LM_L6_V2,
            "bge-base" to ModelCatalog.BGE_BASE_EN_V15, "bge-large" to ModelCatalog.BGE_LARGE_EN_V15)) {
            Files.createSymbolicLink(File(dir, descriptor.localFilename).toPath(), File(assets, "$name.onnx").toPath())
            Files.createSymbolicLink(File(dir, descriptor.extraFiles[0].localFilename).toPath(), File(assets, "$name-vocab.txt").toPath())
            val queries = listOf("who is the queen of sheba", "how many children did Adam and Eve have", "faith hope love",
                "école αβγ 2026", "  why?  ", ("This is a deliberately long query about research, wisdom and faith. ").repeat(60))
                .map { if (descriptor.poolingStrategy == PoolingStrategy.CLS) "Represent this sentence for searching relevant passages: $it" else it }
            val original = LegacyOnnxBertEmbedderBackend(Context(dir), descriptor)
            val current = OnnxBertEmbedderBackend(Context(dir), descriptor)
            val facade = Embedder(Context(dir), descriptor)
            try {
                val expected = queries.map { original.embed(it) ?: error("Original $name failed") }
                original.close()
                for ((i, q) in queries.withIndex()) {
                    val actual = current.embed(q) ?: error("Default $name failed")
                    val diff = actual.indices.maxOf { abs(actual[it] - expected[i][it]) }
                    check(diff <= 0.00001f) { "IVF/indexing output changed: $name $diff" }
                    check(current.configuredThreads == 0 && current.sessionLoads == 1L)
                    compared += actual.size
                }
                val durations = ArrayList<Double>()
                for ((i, q) in queries.withIndex()) {
                    val started = System.nanoTime()
                    val actual = current.embedForSearch(q) ?: error("Blue $name failed")
                    val elapsed = (System.nanoTime() - started) / 1e6
                    durations += elapsed
                    val diff = actual.indices.maxOf { abs(actual[it] - expected[i][it]) }
                    check(diff <= 0.00001f) { "Blue output changed: $name $diff" }
                    check(actual.size == descriptor.embeddingDim)
                    check(current.configuredThreads == minOf(2, Runtime.getRuntime().availableProcessors()).coerceAtLeast(1))
                    check(current.sessionLoads == 2L) { "Same-mode query reloaded the model" }
                    compared += actual.size
                    if (i < 5) println("$name blue_query=$i ms=${"%.2f".format(elapsed)} max_vector_diff=$diff default/blue model space=PASS")
                }
                // Re-entering IVF/indexing explicitly restores the original defaults once.
                val restored = current.embed(queries[0])!!
                check(current.configuredThreads == 0 && current.sessionLoads == 3L)
                check(restored.indices.all { abs(restored[it] - expected[0][it]) <= 0.00001f })
                check(current.embed("   ") == null && current.embedForSearch("") == null)
                val actualFacade = facade.embedFastQuery(queries[0])!!
                check(actualFacade.indices.all { abs(actualFacade[it] - expected[0][it]) <= 0.00001f })
                check(facade.modelVersion == "${descriptor.id}::chunked-v1")
                facade.close()
                // Simultaneous default/blue callers serialize session transitions and remain correct.
                val concurrent = List(8) { i -> async(Dispatchers.IO) {
                    val q = queries[i % 5]
                    val vector = if (i % 2 == 0) current.embed(q) else current.embedForSearch(q)
                    check(vector != null)
                    check(vector.indices.all { abs(vector[it] - expected[i % 5][it]) <= 0.00001f })
                } }
                concurrent.awaitAll()
                val entered = CompletableDeferred<Unit>()
                val inference = launch(Dispatchers.IO) {
                    entered.complete(Unit)
                    current.embedForSearch(queries.last())
                }
                entered.await()
                withTimeout(30_000) { while (!current.inferenceInFlight) yield() }
                repeat(20) { current.close(); yield() }
                inference.cancelAndJoin()
                check(!current.isLoaded)
                check(current.embedForSearch(queries[0]) != null)
                println("$name production default/blue/restore/long-input/facade/concurrent switching/unload/cancellation=PASS")
            } finally { current.close(); original.close(); facade.close() }
        }
        val missing = OnnxBertEmbedderBackend(Context(dir), ModelCatalog.BGE_BASE_EN_V15.copy(localFilename = "missing.onnx"))
        check(missing.embedForSearch("faith") == null && missing.embed("faith") == null)
        missing.close()
        val use = Embedder(Context(dir), ModelCatalog.USE_LITE_V1)
        check(use.embedFastQuery("faith")!!.contentEquals(use.embed("faith")!!))
        check(use.embedFastQuery("") == null)
        println("$compared original/default/blue vector elements; missing model and actual MediaPipe facade routing=PASS")
    } finally { dir.listFiles()?.forEach { it.delete() }; dir.delete() }
}
