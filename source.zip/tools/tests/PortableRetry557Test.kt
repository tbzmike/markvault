package com.tebogo.markvault.data
import java.io.ByteArrayOutputStream
import java.security.MessageDigest
import java.util.zip.ZipEntry
import java.util.zip.ZipOutputStream

fun main() {
    FakeDocs.reset()
    val files = linkedMapOf("Good.md" to "Completed", "Bad.pdf" to "PDF data")
    val output = ByteArrayOutputStream()
    ZipOutputStream(output).use { zip ->
        zip.putNextEntry(ZipEntry(PortableBackupFiles.DIRECTORIES_ENTRY)); zip.write("[]".toByteArray()); zip.closeEntry()
        for ((path, data) in files) { zip.putNextEntry(ZipEntry(PortableBackupFiles.LIBRARY_PREFIX + path)); zip.write(data.toByteArray()); zip.closeEntry() }
    }
    FakeDocs.zipBytes = output.toByteArray()
    val hashes = files.mapValues { (_, text) -> BackupZipIO.hex(MessageDigest.getInstance("SHA-256").digest(text.toByteArray())) }
    val ctx = FakeContext()
    val root = "content://fake/library/root"
    FakeDocs.createName = { name, _ -> if (name.endsWith(".pdf")) "$name.txt" else name }
    check(runCatching { PortableBackupFiles.restoreLibrary(ctx, FakeDocs.zip, root, hashes, keepCompletedOnFailure = true) }.isFailure)
    val completed = FakeDocs.docs.values.single { it.name == "Good.md" }
    check(String(completed.bytes) == "Completed" && FakeDocs.docs.values.none { it.name.endsWith(".txt") })
    FakeDocs.createName = { name, _ -> name }
    val result = PortableBackupFiles.restoreLibrary(ctx, FakeDocs.zip, root, hashes, keepCompletedOnFailure = true)
    check(result.installed == 1 && result.documentIds["Good.md"] == completed.id)
    check(FakeDocs.docs.values.count { it.name == "Good.md" } == 1)
    val again = PortableBackupFiles.restoreLibrary(ctx, FakeDocs.zip, root, hashes, keepCompletedOnFailure = true)
    check(again.installed == 0 && again.documentIds == result.documentIds)
    println("PASS failed library pass retains verified file, retry writes only missing file, subsequent retry writes zero")
}
