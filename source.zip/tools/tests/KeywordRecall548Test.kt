import com.tebogo.markvault.search.KeywordRecallPlanner as R

fun main() {
    val cases = mapOf(
        "Who were the sons of e'sau?" to "sons* esau*",
        "Who were Esau's sons?" to "esau* sons*",
        "who were the sons of Esau" to "sons* esau*",
        "Who was Caleb?" to "caleb*",
        "How many children did Jacob have?" to "many* children* jacob*",
        "Is Jesus God?" to "jesus* god*",
        "Who was NOT among Esau's sons?" to "not* among* esau* sons*",
        "Where was Jesus born?" to "jesus* born*"
    )
    for ((q, expected) in cases) {
        val actual = R.coreQuery(q)
        check(actual == expected) { "Query [$q] expected [$expected] but got [$actual]" }
    }
    for (q in listOf("who magazine", "how old testament prophecies", "not worship of god", "whoever believes", "whereabouts of Esau")) {
        check(R.coreQuery(q) == null) { "False rewriting of [$q]: ${R.coreQuery(q)}" }
    }
    check(R.coreQuery("\"sons of Esau\"") == null)
    check(R.proximityQuery("Who were the sons of e'sau?") == "sons* NEAR/8 esau*")
    check(R.proximityQuery("\"sons of Esau\"") == null)
    println("PASS: 8 question normalizations, 5 no-rewrite cases, exact-phrase safety and FTS4 proximity")
}
