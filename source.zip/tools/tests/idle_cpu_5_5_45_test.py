#!/usr/bin/env python3
"""5.5.45 source-level thermals/idle test. Not a device profiler or APK build."""
from pathlib import Path
r=Path(__file__).resolve().parents[2]
vm=(r/'app/src/main/java/com/tebogo/markvault/AppViewModel.kt').read_text()
media=(r/'app/src/main/java/com/tebogo/markvault/ui/MediaPlayerScreen.kt').read_text()
build=(r/'app/build.gradle.kts').read_text()
assert 'versionCode = 494' in build and 'versionName = "5.5.45"' in build
assert 'private const val MEDIA_SEMANTIC_INDEX_BATCH_SIZE = 8' in vm
assert 'private const val MEDIA_SEMANTIC_INDEX_NEXT_BATCH_DELAY_MS = 90_000L' in vm
assert 'scheduleMediaSemanticIndexing(90_000L)' in vm
assert 'scheduleMediaSemanticIndexing(delayMs: Long = 60_000L)' in vm
assert 'PowerManager.THERMAL_STATUS_MODERATE' in vm
assert 'isThermallySafeForMaintenance(power)' in vm
assert 'EmbeddingProgressBus.isRunning.value' in vm
assert 'canStartAutomaticHnswMaintenance()' in vm
assert 'val automaticColdStart = initialModelEmission' in vm
assert '(!automaticColdStart || canStartAutomaticHnswMaintenance())' in vm
assert 'delay(AUTO_HNSW_MAINTENANCE_DELAY_MS)' in vm
assert 'EmbeddingProgressBus.isRunning.drop(1).collect' in vm
assert 'distinctUntilChanged().collectLatest' in vm
assert 'context.getSystemService(BatteryManager::class.java)?.isCharging == true' in vm
assert 'lifecycleOwner.lifecycle.repeatOnLifecycle(Lifecycle.State.STARTED)' in media
assert media.count('delay(if (c.isPlaying)') == 2
assert '8_000L' in media and 'Dispatchers.IO' in media
for preserved in ('fun buildAllEmbeddings(', 'fun hardResetMemory()',
                  'fun searchMedia(', 'private suspend fun forceReleaseSearchMemory('):
    assert preserved in vm, preserved
print('PASS: startup HNSW wakeup/thermal/charging guard, no spurious initial completion, media batch throttle, lifecycle-scoped playback polling, manual build preserved')
