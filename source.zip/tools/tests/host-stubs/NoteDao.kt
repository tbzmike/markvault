package com.tebogo.markvault.data
data class HnswVectorProjection(val noteId: Long, val chunkIndex: Int, val vector: ByteArray)
data class HnswMetadataProjection(val noteId: Long, val chunkIndex: Int, val createdAt: Long)
interface NoteDao {
    suspend fun embeddingCount(model: String): Int
    suspend fun latestEmbeddingCreatedAt(model: String): Long
    suspend fun loadHnswVectorsPage(model: String, afterNote: Long, afterChunk: Int, limit: Int): List<HnswVectorProjection>
    suspend fun loadHnswMetadataPage(model: String, afterNote: Long, afterChunk: Int, limit: Int): List<HnswMetadataProjection>
    suspend fun loadHnswChangedVectorsPage(model: String, notes: List<Long>, limit: Int, offset: Int): List<HnswVectorProjection>
}
