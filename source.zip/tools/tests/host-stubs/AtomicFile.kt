package android.util

import java.io.File
import java.io.FileOutputStream

// Host file-writing adapter; Android supplies its own AtomicFile in the APK.
class AtomicFile(private val file: File) {
    fun startWrite(): FileOutputStream = FileOutputStream(file)
    fun finishWrite(stream: FileOutputStream) = stream.close()
    fun failWrite(stream: FileOutputStream) = stream.close()
}
