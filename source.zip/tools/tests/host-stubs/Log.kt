package android.util
object Log { fun e(tag: String, message: String, error: Throwable): Int {
    System.err.println("$tag: $message: ${error.message}"); return 0
} }
