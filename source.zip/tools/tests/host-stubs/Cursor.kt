package android.database

interface Cursor : java.io.Closeable {
    fun getColumnIndexOrThrow(name: String): Int
    fun moveToNext(): Boolean
    fun getBlob(column: Int): ByteArray
    fun getLong(column: Int): Long
}
