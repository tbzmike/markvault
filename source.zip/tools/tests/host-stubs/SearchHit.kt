package com.tebogo.markvault.data

data class SearchHit(
    val id: Long,
    val relPath: String,
    val title: String,
    val snippet: String,
    val fileType: String,
    val score: Float? = null
)
