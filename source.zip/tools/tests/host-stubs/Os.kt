package android.system
import java.nio.file.Files
import java.nio.file.Path
import java.nio.file.StandardCopyOption
object Os { fun rename(from: String, to: String) {
    Files.move(Path.of(from), Path.of(to), StandardCopyOption.ATOMIC_MOVE, StandardCopyOption.REPLACE_EXISTING)
} }
