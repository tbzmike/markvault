package android.system
import java.nio.file.Files
import java.nio.file.Path
import java.nio.file.StandardCopyOption
object Os {
    @Volatile var failNextRename = false
    fun rename(from: String, to: String) {
    if (failNextRename) { failNextRename = false; throw java.io.IOException("Injected atomic rename failure") }
    Files.move(Path.of(from), Path.of(to), StandardCopyOption.ATOMIC_MOVE, StandardCopyOption.REPLACE_EXISTING)
} }
