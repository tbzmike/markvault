CREATE TABLE IF NOT EXISTS `notes` (`id` INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL, `uri` TEXT NOT NULL, `relPath` TEXT NOT NULL, `name` TEXT NOT NULL, `title` TEXT NOT NULL, `folder` TEXT NOT NULL, `content` TEXT NOT NULL, `lastModified` INTEGER NOT NULL, `size` INTEGER NOT NULL, `lastOpened` INTEGER NOT NULL, `lastScroll` INTEGER NOT NULL, `favourite` INTEGER NOT NULL, `fileType` TEXT NOT NULL);
CREATE UNIQUE INDEX IF NOT EXISTS `index_notes_uri` ON `notes` (`uri`);
CREATE INDEX IF NOT EXISTS `index_notes_relPath` ON `notes` (`relPath`);
