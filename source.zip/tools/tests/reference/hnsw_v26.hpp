// Frozen 5.5.26 comparison oracle. Only the enclosing namespace is renamed.
// Original SHA256: 6943eb2e6ec1688c5db387ddeef8d60176084be7c379915ae2ec70d184b03e61
#pragma once

#include <usearch/index_dense.hpp>
#include <algorithm>
#include <cmath>
#include <cstdio>
#include <memory>
#include <stdexcept>
#include <unordered_map>
#include <vector>
#if defined(__aarch64__)
#include <arm_neon.h>
#endif

namespace markvault_v26 {
namespace us = unum::usearch;

struct QueryMetricCache {
    bool active = false;
    void const* query = nullptr;
    std::size_t dim = 0;
    alignas(16) float values[2048];
    float norm = 0;
    void const* last_vector = nullptr;
    float last_distance = 0;
};
inline thread_local QueryMetricCache query_metric_cache;

class QueryMetricGuard {
public:
    QueryMetricGuard() {
        if (query_metric_cache.active) throw std::logic_error("Nested HNSW query");
        query_metric_cache.active = true;
        query_metric_cache.query = nullptr;
    }
    ~QueryMetricGuard() { query_metric_cache.active = false; }
};

// ARMv8-A FP16 conversion + FP32 accumulation; no ARMv8.2-only instructions.
inline float cosine_half(void const* a_ptr, void const* b_ptr, std::size_t dim) {
    auto a = static_cast<us::f16_t const*>(a_ptr);
    auto b = static_cast<us::f16_t const*>(b_ptr);
    auto& cache = query_metric_cache;
    bool cached = cache.active && dim <= 2048;
    if (cached && (cache.query != a_ptr || cache.dim != dim)) {
        cache.query = a_ptr; cache.dim = dim; cache.norm = 0;
        std::size_t at = 0;
#if defined(__aarch64__)
        float32x4_t norm = vdupq_n_f32(0);
        for (; at + 4 <= dim; at += 4) {
            auto q = vcvt_f32_f16(vreinterpret_f16_u16(vld1_u16(reinterpret_cast<std::uint16_t const*>(a + at))));
            vst1q_f32(cache.values + at, q);
            norm = vfmaq_f32(norm, q, q);
        }
        cache.norm = vaddvq_f32(norm);
#endif
        for (; at < dim; ++at) { float q = float(a[at]); cache.values[at] = q; cache.norm += q * q; }
    }
    float ab = 0, aa = cached ? cache.norm : 0, bb = 0;
    std::size_t i = 0;
#if defined(__aarch64__)
    float32x4_t vab = vdupq_n_f32(0), vaa = vab, vbb = vab;
    for (; i + 4 <= dim; i += 4) {
        auto av = cached ? vld1q_f32(cache.values + i) :
            vcvt_f32_f16(vreinterpret_f16_u16(vld1_u16(reinterpret_cast<std::uint16_t const*>(a + i))));
        auto bv = vcvt_f32_f16(vreinterpret_f16_u16(vld1_u16(reinterpret_cast<std::uint16_t const*>(b + i))));
        vab = vfmaq_f32(vab, av, bv);
        if (!cached) vaa = vfmaq_f32(vaa, av, av);
        vbb = vfmaq_f32(vbb, bv, bv);
    }
    ab = vaddvq_f32(vab); if (!cached) aa = vaddvq_f32(vaa); bb = vaddvq_f32(vbb);
#endif
    for (; i < dim; ++i) {
        float av = cached ? cache.values[i] : float(a[i]), bv = float(b[i]);
        ab += av * bv; if (!cached) aa += av * av; bb += bv * bv;
    }
    float distance = aa == 0 || bb == 0 ? (aa == bb ? 0.0f : 1.0f) :
        std::max(0.0f, std::min(2.0f, 1.0f - ab / std::sqrt(aa * bb)));
    if (cached) { cache.last_vector = b_ptr; cache.last_distance = distance; }
    return distance;
}

inline us::metric_punned_t metric(std::size_t dim) {
    return {dim, reinterpret_cast<std::uintptr_t>(&cosine_half),
            us::metric_punned_signature_t::array_array_size_k,
            us::metric_kind_t::cos_k, us::scalar_kind_t::f16_k};
}

template <typename Result> inline void checked(Result& result) {
    if (!result) throw std::runtime_error(result.error.release());
}

class Hnsw {
    us::index_dense_t index_;
    using QueryVector = std::pair<std::uint64_t, us::f16_t const*>;
    std::vector<QueryVector> query_vectors_;

    void prepare_query_vectors() {
        if (!query_vectors_.empty()) return;
        us::index_dense_t::values_proxy_t values(index_);
        query_vectors_.reserve(size());
        for (auto it = index_.cbegin(); it != index_.cend(); ++it) {
            auto key = static_cast<std::uint64_t>((*it).key);
            if (key != index_.free_key())
                query_vectors_.emplace_back(key, reinterpret_cast<us::f16_t const*>(values[it]));
        }
        std::sort(query_vectors_.begin(), query_vectors_.end(),
                  [](QueryVector const& a, QueryVector const& b) { return a.first < b.first; });
    }

    // Candidate selection still uses quantized vectors. Final article scoring
    // uses the existing full precision Room vectors in AppViewModel.
    static float query_distance(float const* query, us::f16_t const* vector,
                                std::size_t dim, float query_norm) {
        float dot = 0, norm = 0;
        std::size_t i = 0;
#if defined(__aarch64__)
        float32x4_t dots = vdupq_n_f32(0), norms = dots;
        for (; i + 4 <= dim; i += 4) {
            auto v = vcvt_f32_f16(vreinterpret_f16_u16(vld1_u16(reinterpret_cast<std::uint16_t const*>(vector + i))));
            dots = vfmaq_f32(dots, vld1q_f32(query + i), v);
            norms = vfmaq_f32(norms, v, v);
        }
        dot = vaddvq_f32(dots); norm = vaddvq_f32(norms);
#endif
        for (; i < dim; ++i) { float v = float(vector[i]); dot += query[i] * v; norm += v * v; }
        if (query_norm == 0 || norm == 0) return query_norm == norm ? 0.0f : 1.0f;
        return std::max(0.0f, std::min(2.0f, 1.0f - dot / std::sqrt(query_norm * norm)));
    }
public:
    struct ArticleCandidates {
        std::vector<std::uint64_t> articles;
        bool exhaustive = false;
        std::size_t passages = 0;
        std::size_t scored = 0;
    };
    Hnsw(int dim, std::size_t capacity, bool lookups = true) {
        if (dim < 1 || dim > 2048) throw std::invalid_argument("Invalid vector dimension");
        us::index_dense_config_t config;
        config.connectivity = 16;
        config.expansion_add = 128;
        config.expansion_search = 256;
        config.enable_key_lookups = lookups;
        auto made = us::index_dense_t::make(metric(dim), config,
            us::default_free_value<us::index_dense_t::vector_key_t>(), us::index_limits_t(capacity, 1));
        checked(made);
        index_ = std::move(made.index);
    }
    std::size_t size() const { return index_.size(); }
    std::size_t dimensions() const { return index_.dimensions(); }
    std::size_t serialized_length() const { return index_.serialized_length(); }
    void reserve(std::size_t capacity) {
        if (!index_.try_reserve(us::index_limits_t(capacity, 1))) throw std::bad_alloc();
    }
    void add(std::uint64_t key, float const* vector, std::size_t dim) {
        if (dim != dimensions()) throw std::invalid_argument("Vector dimension mismatch");
        for (std::size_t i = 0; i < dim; ++i)
            if (!std::isfinite(vector[i])) throw std::invalid_argument("Non-finite embedding");
        auto result = index_.add(key, vector);
        checked(result);
        query_vectors_.clear();
    }
    void remove(std::uint64_t key) {
        auto result = index_.remove(key);
        checked(result);
        query_vectors_.clear();
    }
    std::vector<std::uint64_t> keys() const {
        std::vector<std::uint64_t> result(size());
        index_.export_keys(result.data(), 0, result.size());
        return result;
    }
    void open(char const* path, std::size_t offset, bool mutable_index) {
        query_vectors_.clear();
        auto result = mutable_index
            ? index_.load(us::memory_mapped_file_t(path), offset)
            : index_.view(us::memory_mapped_file_t(path), offset);
        checked(result);
        if (dimensions() < 1 || dimensions() > 2048 || index_.scalar_kind() != us::scalar_kind_t::f16_k)
            throw std::runtime_error("Incompatible HNSW vector format");
        index_.change_metric(metric(dimensions()));
        reserve(index_.capacity());
    }
    void append(char const* path) const {
        std::unique_ptr<std::FILE, decltype(&std::fclose)> file(std::fopen(path, "ab"), &std::fclose);
        if (!file) throw std::runtime_error("Could not open HNSW snapshot");
        auto result = index_.save_to_stream([&](void const* data, std::size_t size) {
            return std::fwrite(data, 1, size, file.get()) == size;
        });
        checked(result);
        if (std::fflush(file.get()) != 0) throw std::runtime_error("Could not flush HNSW snapshot");
    }
    std::vector<std::uint64_t> search(float const* query, std::size_t dim, std::size_t wanted,
                                    std::vector<std::uint64_t> const* allowed = nullptr) {
        if (dim != dimensions()) throw std::invalid_argument("Query dimension mismatch");
        for (std::size_t i = 0; i < dim; ++i)
            if (!std::isfinite(query[i])) throw std::invalid_argument("Non-finite query");
        wanted = std::min(wanted, size());
        if (!wanted) return {};
        // Returning hundreds of unique articles requires a wider frontier than top-10 search.
        index_.change_expansion_search(std::max<std::size_t>(256, wanted));
        auto result = index_.filtered_search(query, wanted, [&](std::uint64_t key) {
            return !allowed || std::binary_search(allowed->begin(), allowed->end(), key >> 32);
        });
        checked(result);
        std::vector<std::uint64_t> keys;
        keys.reserve(result.size());
        for (std::size_t i = 0; i < result.size(); ++i) keys.push_back(result.at(i).member.key);
        return keys;
    }

    ArticleCandidates article_candidates(float const* query, std::size_t dim, std::size_t article_limit,
                                         std::size_t minimum_articles,
                                         std::vector<std::uint64_t> const* allowed = nullptr) {
        if (dim != dimensions()) throw std::invalid_argument("Query dimension mismatch");
        if (!article_limit || article_limit > 1200 || minimum_articles > article_limit)
            throw std::invalid_argument("Invalid article candidate limit");
        float query_norm = 0;
        for (std::size_t i = 0; i < dim; ++i) {
            if (!std::isfinite(query[i])) throw std::invalid_argument("Non-finite query");
            query_norm += query[i] * query[i];
        }
        ArticleCandidates output;
        if (!size() || (allowed && allowed->empty())) { output.exhaustive = true; return output; }
        prepare_query_vectors();
        std::unordered_map<std::uint64_t, float> best;
        best.reserve(article_limit * 4);
        auto accept = [&](QueryVector const& item, float const* measured = nullptr) {
            auto note = item.first >> 32;
            if (allowed && !std::binary_search(allowed->begin(), allowed->end(), note)) return;
            float distance = measured ? *measured : query_distance(query, item.second, dim, query_norm);
            if (!measured) ++output.scored;
            auto at = best.find(note);
            if (at == best.end()) best.emplace(note, distance);
            else at->second = std::min(at->second, distance);
        };
        // One traversal replaces the old 1,200 -> 2,400 -> 4,800 retries.
        // Keep the original scope predicate: post-filtering an unrestricted
        // graph walk loses strong matches in a distant selected partition.
        // Retain every admitted article, including passages evicted from top-K.
        auto coverage = article_limit;
        {
            constexpr std::size_t budget = 4800;
            struct Observed { std::uint64_t key; void const* vector; float distance; };
            std::vector<Observed> observed;
            // The pinned graph visits each slot at most once. Allocate outside
            // its noexcept predicate so allocation failure remains catchable.
            observed.reserve(size());
            output.passages = std::min(budget, size());
            index_.change_expansion_search(output.passages);
            {
                QueryMetricGuard guard;
                auto result = index_.filtered_search(query, output.passages, [&](std::uint64_t key) {
                    if (allowed && !std::binary_search(allowed->begin(), allowed->end(), key >> 32))
                        return false;
                    if (observed.size() < observed.capacity())
                        observed.push_back({key, query_metric_cache.last_vector, query_metric_cache.last_distance});
                    return true;
                });
                checked(result);
                output.scored += result.computed_distances;
            }
            for (auto const& item : observed) {
                auto at = std::lower_bound(query_vectors_.begin(), query_vectors_.end(), item.key,
                    [](QueryVector const& item, std::uint64_t value) { return item.first < value; });
                if (at != query_vectors_.end() && at->first == item.key)
                    accept(*at, at->second == item.vector ? &item.distance : nullptr);
            }
        }
        if (best.size() < coverage) {
            // Sparse/diverse scopes recover through a contiguous native FP16
            // candidate scan, rather than streaming 200k full precision BLOBs
            // through Room/ART. Every selected article is still rescored from
            // ALL of its full precision persisted chunks afterwards.
            output.exhaustive = true;
            best.clear();
            for (auto const& item : query_vectors_) accept(item);
        }
        std::vector<std::pair<float, std::uint64_t>> ranked;
        ranked.reserve(best.size());
        for (auto const& item : best) ranked.emplace_back(item.second, item.first);
        auto wanted = std::min(article_limit, ranked.size());
        std::partial_sort(ranked.begin(), ranked.begin() + wanted, ranked.end());
        output.articles.reserve(wanted);
        for (std::size_t i = 0; i < wanted; ++i) output.articles.push_back(ranked[i].second);
        return output;
    }
};
}
