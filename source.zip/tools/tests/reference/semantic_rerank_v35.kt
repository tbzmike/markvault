    private suspend fun semanticRerankCandidates(
        qVec: FloatArray,
        candidateIds: Collection<Long>,
        topK: Int,
        modelVersion: String
    ): List<Pair<Long, Float>> {
        if (candidateIds.isEmpty() || qVec.isEmpty()) return emptyList()
        return try {
            // v5.5.9 — The query was already embedded before ANN cluster probing.
            // The old ANN path embedded the SAME query a second time here, which
            // doubled ONNX query inference and disproportionately hurt BGE models.
            // Reuse qVec and stream lightweight DB projections page-by-page instead.
            val bestScore = HashMap<Long, Float>(candidateIds.size)
            for (chunk in candidateIds.toList().chunked(900)) {
                currentCoroutineContext().ensureActive()
                // v5.5.14 — After Stop Search, finish no new ANN vector batch;
                // whatever has already been rescored proceeds to final reranking.
                if (gracefulSearchStopRequested() && bestScore.isNotEmpty()) break
                val rows = try {
                    dao.loadEmbeddingVectorsForNotes(modelVersion, chunk)
                } catch (ce: kotlinx.coroutines.CancellationException) {
                    throw ce
                } catch (_: Throwable) {
                    emptyList()
                }
                val nativeScores = if (activeSearchTrace?.hnswEnabled ?: hnswSearchEnabled.value) {
                    com.tebogo.markvault.search.ExactVectorScorer.score(qVec, rows.map { it.vector }.toTypedArray())
                } else null
                for ((index, row) in rows.withIndex()) {
                    if (row.vector.size != qVec.size * 4) continue
                    val score = nativeScores?.get(index) ?: normalizedEmbeddingDot(qVec, row.vector)
                    val existing = bestScore[row.noteId]
                    if (existing == null || score > existing) bestScore[row.noteId] = score
                }
                if (gracefulSearchStopRequested()) break
            }
            bestScore.entries.sortedByDescending { it.value }.take(topK)
                .map { it.key to it.value }
        } catch (t: Throwable) {
            if (t is kotlinx.coroutines.CancellationException) throw t
            android.util.Log.e("MarkVault", "semanticRerankCandidates failed", t)
            emptyList()
        }
    }
