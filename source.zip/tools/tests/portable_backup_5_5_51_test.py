#!/usr/bin/env python3
"""v5.5.51 source invariants: portability and no unrelated search/index modifications."""
from pathlib import Path
root=Path(__file__).resolve().parents[2]
data=(root/'app/src/main/java/com/tebogo/markvault/data')
backup=(data/'BackupManager.kt').read_text()
files=(data/'PortableBackupFiles.kt').read_text()
extras=(data/'PortableBackupState.kt').read_text()
ui=(root/'app/src/main/java/com/tebogo/markvault/ui/SettingsScreen.kt').read_text()
embedding=(root/'app/src/main/java/com/tebogo/markvault/search/EmbeddingService.kt').read_text()
build=(root/'app/build.gradle.kts').read_text()
assert 'versionCode = 500' in build and 'versionName = "5.5.51"' in build
assert 'FORMAT_VERSION = 7' in backup and 'archiveVersion !in 4..FORMAT_VERSION' in backup
assert 'PortableBackupFiles.scanLibrary(ctx, libraryUri)' in backup
assert 'PortableBackupFiles.directoryBytes(libraryTree)' in backup
assert 'PortableBackupState.writeExtras' in backup and 'PortableBackupState.restoreExtras' in backup
assert 'PortableBackupState.writeNoteUi' in backup and 'PortableBackupState.restoreNoteUi' in backup
assert 'PortableBackupFiles.restoreLibrary' in backup and 'PortableBackupFiles.restoreAppFiles' in backup
assert 'PortableBackupFiles.installAppFiles' in backup and 'PortableBackupFiles.applyPendingSharedPrefs' in backup
assert 'matchedNotes == expectedNotes' in backup
assert 'db.beginTransaction()' in backup and 'db.setTransactionSuccessful()' in backup
assert 'UPDATE pdf_history SET uri=' in backup
assert 'Duplicate backup entry:' in backup and 'checksums' in backup and 'sizes' in backup
assert 'ctx.cacheDir.usableSpace' in backup and 'Save the backup outside' in backup
assert 'No readable article files found' in backup
assert 'BackupRestoreOperationState.state.value.running' in embedding
assert 'action != ACTION_STOP && action != ACTION_PAUSE' in embedding
assert all(t in extras for t in ('media_items','media_embeddings','pdf_page_text','pdf_annotations','pdf_history','web_history','web_bookmarks','playlists'))
assert 'FIELD_TYPE_BLOB' in extras and 'sourceFingerprint' not in extras # dynamic schema preserved
assert 'sourceFingerprint' in (data/'Db.kt').read_text()
assert 'DocumentsContract.createDocument' in files and 'DocumentsContract.deleteDocument' in files
assert 'verifyCreatedName' in files and 'existingFiles[path]' in files
assert 'actual.equals(expected' in files and 'ZipInputStream' in files
assert 'shared_prefs' in files and 'datastore/' in files and 'saved' in files
assert 'Restoration can require considerable free storage' in ui
assert 'Choose restore destination folder' in ui
# no additional polling, worker or service in the two new backup helpers
assert 'CoroutineScope' not in extras+files and 'Service()' not in extras+files
print('PASS v5.5.51 portable backup: all-model article/media embeddings, original library tree, model assets, ANN, settings, legacy format, URI remap, rollback guards, no new worker')
