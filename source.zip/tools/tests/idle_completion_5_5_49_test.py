"""Source-lifecycle checks for v5.5.49. No Android device claims are made."""
from pathlib import Path
root=Path(__file__).resolve().parents[2]
vm=(root/'app/src/main/java/com/tebogo/markvault/AppViewModel.kt').read_text()
ui=(root/'app/src/main/java/com/tebogo/markvault/ui/SearchScreen.kt').read_text()
activity=(root/'app/src/main/java/com/tebogo/markvault/MainActivity.kt').read_text()
service=(root/'app/src/main/java/com/tebogo/markvault/service/BackgroundWorkService.kt').read_text()
assert 'versionName = "5.5.49"' in (root/'app/build.gradle.kts').read_text()
assert 'schedulePostSearchCleanup()' not in vm
assert '_idleCleanupJob' not in vm
settle=vm[vm.index('private suspend fun settleSearchAtCompletion('):vm.index('suspend fun awaitSearchPostCleanup()')]
assert 'System.gc()' in settle
assert settle.count('System.gc()') == 1
assert 'rerankApplied && autoFreeMemory.value' in settle
assert 'blueRerankEngine.unload(); reranker.unload()' in settle
assert 't5Engine?.close()' in settle and 'LlmManager.unload()' in settle
assert '_chatIsGenerating.value' in settle
assert 'annIndex.unload()' not in settle and 'hnswIndex.unload()' not in settle
search_finally=vm[vm.index('} finally {\n                    searchLease.close()'):vm.index('// Cache non-empty results for the cancel handler')]
assert 'settleSearchAtCompletion(' in search_finally
assert search_finally.index('settleSearchAtCompletion(')<search_finally.index('_searchBusy.value = false')
assert 'executionTrace.rerankApplied' in search_finally
assert vm.index('SavedSearchStore.save(')<vm.index('} finally {\n                    searchLease.close()')
manual=vm[vm.index('fun manuallyRerankCurrentResults()'):vm.index('val rerankerModelId:')]
assert 'manualRerankCompleted = true' in manual and 'settleSearchAtCompletion(rerankApplied = manualRerankCompleted)' in manual
assert 'scheduleMemoryClearAfterNavigation()' not in activity
assert 'vm.resetHomeState()' in activity
reset=vm[vm.index('fun resetHomeState()'):vm.index('private suspend fun checkMemoryPressureAndPause(',vm.index('fun resetHomeState()'))]
assert 'System.gc()' not in reset and 'settleAndDoubleGc()' not in reset
assert 'query.value = ""' in reset
assert 'System.gc()' in vm[vm.index('fun freeMemory()'):vm.index('fun freeMemoryAuto()')]
assert 'fun freeMemoryAuto()' in vm and 'checkMemoryPressureAndPause(' in vm
assert 'scheduleMediaSemanticIndexing(90_000L)' not in vm
assert 'hnswIndex.prepare(embedder.modelVersion)' not in vm[vm.index('// v5.5.49 — No optional HNSW index prewarming'):vm.index('// v4.15.0 — When the foreground embedding service finishes')]
assert 'if (needsSelfHeal && !automaticColdStart)' in vm
assert 'scheduleMediaSemanticIndexing(delayMs = 60_000L)' not in vm
assert 'scheduleMediaSemanticIndexing()' in vm
assert 'LaunchedEffect(query, isSearchBusy, searchMediaVisible)' in ui
assert 'if (!searchMediaVisible)' in ui
assert 'animating = isSearchBusy' in ui
assert 'if (!active || !animating)' in ui
assert 'awaitSearchPostCleanup()' in service
assert 'com.tebogo.markvault.search.SavedSearchStore.save(' in vm
print('PASS idle completion: durable results then single conditional rerank GC, manual controls, emergency safeguards, no delayed teardown/startup prewarm, UI lifecycle, indexing retained')
