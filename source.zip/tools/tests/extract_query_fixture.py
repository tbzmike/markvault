"""Compile the actual facade/base types; only the unrelated MediaPipe native binding is stubbed."""
from pathlib import Path
import sys

project, output = map(Path, sys.argv[1:])
source = (project / "app/src/main/java/com/tebogo/markvault/search/Embedder.kt").read_text()
start = source.index("class Embedder(")
end = source.index("/**", source.index("internal abstract class EmbedderBackend("))
actual = source[start:end]
header = "package com.tebogo.markvault.search\nimport android.content.Context\nimport java.io.File\n"
stub = '''
internal class MediaPipeEmbedderBackend(context: Context, descriptor: ModelDescriptor) : EmbedderBackend(context, descriptor) {
    override suspend fun downloadModel(onProgress: (Float) -> Unit): Result<Unit> = Result.success(Unit)
    override suspend fun embed(text: String): FloatArray? = if (text.isBlank()) null else floatArrayOf(1f, 0f)
    override fun close() {}
}
'''
(output / "ActualQueryFacade.kt").write_text(header + actual + stub)
