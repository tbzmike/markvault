#!/usr/bin/env python3
"""5.5.42 card separation source regression (not an Android screenshot test)."""
from pathlib import Path
import re

root = Path(__file__).resolve().parents[2]
s = (root / 'app/src/main/java/com/tebogo/markvault/ui/SearchScreen.kt').read_text()
card = s.split('itemsIndexed(filteredResults, key = { _, item -> item.id }) { index, hit ->', 1)[1]
card = card.split('item { Spacer(Modifier.height(24.dp)) }', 1)[0]

# Every result has a thick native border independent of rank/source type.
assert 'border = androidx.compose.foundation.BorderStroke(\n                                width = 3.dp,\n                                color = resultBorderColor' in card
assert 'resultCardContrast(it, resultSurfaceColor) >= 3f' in card
assert '?: resultColors.onSurface' in card

# Full physical gutter outside the Surface (not text padding within the tile).
assert '.padding(horizontal = 14.dp, top = if (index == 0) 8.dp else 3.dp, bottom = 20.dp)' in card
assert 'shadowElevation = 2.dp' in card
assert not re.search(r'^\s*HistoryBoldDivider\(\)\s*$', card, re.M), 'full-width divider visually joins tiles'

# The original features and event handlers must survive.
for expression in (
    'text = "#${index + 1}"',
    'if (index % 2 == 0)',
    'SearchResultProvenanceBlock(',
    'resultExpansionPalette(it)',
    'onTap = {',
    'onLongPress = {',
    'highlightSentences(hit.snippet, highlightTokens, llmHighlightTokens)',
):
    assert expression in card, expression
assert 'QueryExpansionLegend(' in s
assert 'itemsIndexed(filteredResults, key = { _, item -> item.id })' in s
build = (root / 'app/build.gradle.kts').read_text()
assert 'versionCode = 491' in build and 'versionName = "5.5.42"' in build
print('PASS: true 20dp outside-card gutters; 3dp outlines; accent contrast fallback; no full-width result divider; rankings/provenance/gestures unchanged')
