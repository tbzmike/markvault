package com.tebogo.markvault.ui

import com.tebogo.markvault.data.SearchHit
import kotlin.random.Random

fun main() {
    val queries = listOf("", "a", "who is god", "\"who is god\"", " God's   love? ", "Jehovah—God", "café école", "🌍 peace")
    val results = (1L..400L).map { id ->
        SearchHit(id, "$id.md", if (id % 2L == 0L) "Who is God" else "God's love", when (id % 4L) {
            0L -> "⟦Who⟧ ⟦is⟧ God. A second sentence."
            1L -> "café école, God's love and Jehovah—God"
            2L -> "The words WHO and GOD are far apart."
            else -> "🌍 peace and friendship"
        }, "md", id.toFloat() / 400)
    }
    var checked = 0
    for (query in queries) for (filter in listOf(false, true)) for (paraphrases in listOf(emptyList(), listOf("who is Jehovah", "Friendship friendship", "God"))) {
        val actual = searchResultPresentation(query.trim(), results, filter, paraphrases)
        val expected = legacySearchResultPresentation(query.trim(), results, filter, paraphrases)
        check(actual == expected) { "Filtering or highlight tokens changed: $query / $filter" }
        checked++
    }
    check(searchResultPresentation("word", results, false, emptyList()).filteredResults === results)
    check(searchResultPresentation("word", results, true, emptyList()).filteredResults === results)
    val random = Random(5524)
    var cases = 0
    repeat(40) {
        var index = 0
        var offset = 0
        var expanded = true
        var changedAt = 0L
        var now = 1000L
        val tracker = SearchScrollTracker(index, offset)
        val legacy = LegacyScrollTracker(index, offset)
        repeat(500) {
            if (random.nextInt(5) == 0) index = (index + random.nextInt(-1, 2)).coerceIn(0, 30)
            offset = (offset + random.nextInt(-20, 30)).coerceIn(0, 500)
            now += random.nextLong(5, 50)
            val actual = tracker.update(index, offset, expanded, changedAt, now)
            val expected = legacy.update(index, offset, expanded, changedAt, now)
            check(actual == expected) { "Collapse changed at $index/$offset: $actual vs $expected" }
            if (actual != null) { expanded = actual; changedAt = now }
            cases++
        }
    }
    val tracker = SearchScrollTracker(0, 0)
    check(tracker.update(0, 10, true, 0, 1000) == null)
    check(tracker.update(0, 23, true, 0, 1010) == null)
    check(tracker.update(0, 24, true, 0, 1020) == false)
    check(tracker.update(0, 1, false, 1020, 1030) == null) // Ignore the bar's layout movement.
    check(tracker.update(0, 0, false, 1020, 1400) == true)
    println("Original keyword filtering/highlight token parity: $checked cases=PASS")
    println("Original toolbar thresholds/direction/settling parity: $cases scroll events=PASS")
}
