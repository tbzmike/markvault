#!/usr/bin/env python3
"""Execute the actual offline link router + position function with JVM stubs;
exercise its real lexical/semantic auto-scroll guards in Node. Not a WebView UI test."""
import json, re, subprocess, tempfile
from pathlib import Path
root=Path(__file__).resolve().parents[2]
ui=root/'app/src/main/java/com/tebogo/markvault/ui'
s=(ui/'HtmlReaderScreen.kt').read_text()
helper=s[s.index('    fun preservePositionForLink('):s.index('    // v5.4.155cc — scroll-to-hide toolbar')]
route=s[s.index('                                override fun shouldOverrideUrlLoading('):s.index('                                override fun onPageFinished(')]
assert route.count('preservePositionForLink(view)')==2
assert 'needsReload' not in route and 'clearHistory' not in route and 'clearCache' not in route
assert s.count('needsReload = true')==1 # explicit Load Online only
assert 'rememberSaveable(id) { mutableStateOf(-1) }' in s
assert 'latestScroll.value.takeIf { it >= 0 } ?: note.lastScroll' in s
assert 'webViewRef === view && !scrollRestored' in s
assert s.count('if (!scrollRestored) return@setOnScrollChangeListener')==2
assert 'window.scrollTo(0, $toRestore)' not in s
assert 'view.scrollTo(0, toRestore)' in s
assert 'nav.navigate("htmlReader/$noteId")' in route
assert 'linkReturnScroll = null' in s
assert 'if (returningFromLink && view != null)' in s
assert 'HighlightLoadingIndicator(' in s and 'articleHighlightNavigateJs(' in s
# Actual logic, fake Android/VM/Nav. Route functions are kept identical.
with tempfile.TemporaryDirectory() as d:
    p=Path(d)
    (p/'Util.kt').write_text('''package com.tebogo.markvault.util
import fixture.*
object ScriptureDetector {
 fun parseScriptureUri(u: Uri): Triple<Int,Int,String>? = if(u.scheme=="markvault") Triple(43,3,"16") else null
 fun buildVerseAnchors(bn:Int,ch:Int,v:String)=listOf("v$v")
 fun firstVerseOf(v:String)=v.toInt()
}
enum class LinkTarget { JW_LIBRARY_APP, IN_APP_WEBVIEW, SYSTEM_BROWSER }
fun routeLink(u:Uri)=when(u.kind){"jw"->LinkTarget.JW_LIBRARY_APP; "popup"->LinkTarget.IN_APP_WEBVIEW; else->LinkTarget.SYSTEM_BROWSER}
fun openInJwLibrary(ctx:Context,u:Uri,onFallback:()->Unit){if(ctx.jwInstalled) ctx.external.add(u.toString()) else onFallback()}
fun openExternally(ctx:Context,u:Uri){ctx.external.add(u.toString())}
''')
    (p/'Main.kt').write_text('''package fixture
class Uri(val scheme:String?,val kind:String, val url:String){override fun toString()=url}
class WebResourceRequest(val url:Uri?)
class WebView(var scrollY:Int){val scripts=mutableListOf<String>();fun evaluateJavascript(s:String,c:Any?){scripts.add(s)}}
class Context(var jwInstalled:Boolean=false){val external=mutableListOf<String>()}
class Scope{fun launch(block:()->Unit){block()}}
class Nav{val routes=mutableListOf<String>();fun navigate(s:String){routes.add(s)}}
class VM{val popups=mutableListOf<String>();var noteId:Long?=null;var anchor="";fun findNwtNoteId(bn:Int,ch:Int)=noteId;fun setPendingScriptureAnchor(s:String){anchor=s};fun requestWebPopup(s:String){popups.add(s)}}
class State(var value:Int)
open class Base {open fun shouldOverrideUrlLoading(view:WebView?,request:WebResourceRequest?):Boolean=false}
class Reader:Base(){val latestScroll=State(-1);var linkReturnScroll:Int?=null;var initialScrollToApply:Int?=99;var scrollRestored=false;val ctx=Context();val htmlScope=Scope();val vm=VM();val nav=Nav()
'''+helper+route+'''
}
fun main(){val r=Reader();val w=WebView(9107)
 fun tap(s:String?,kind:String,url:String)=r.shouldOverrideUrlLoading(w,WebResourceRequest(Uri(s,kind,url)))
 // Popup, repeat same URL, and another URL with a changed reading position.
 check(tap("https","popup","https://wol.jw.org/a"));check(r.latestScroll.value==9107 && w.scrollY==9107 && r.linkReturnScroll==9107 && r.scrollRestored && r.initialScrollToApply==null)
 check(tap("https","popup","https://wol.jw.org/a"));check(r.vm.popups.size==2)
 w.scrollY=19204;check(tap("https","jw","https://www.jw.org/finder?bible=43003016"));check(r.vm.popups.size==3 && r.latestScroll.value==19204 && w.scrollY==19204)
 r.ctx.jwInstalled=true;check(tap("https","jw","installed"));check(r.ctx.external==listOf("installed"));check(r.vm.popups.size==3)
 check(tap("markvault","","detected"));check(r.vm.popups.last().contains("bible=43003016"))
 r.vm.noteId=123;check(tap("markvault","","local"));check(r.nav.routes==listOf("htmlReader/123") && r.vm.anchor=="v16")
 check(tap("https","other","outside"));check(r.ctx.external.last()=="outside")
 val n=w.scripts.size; for(s in listOf("file","data","cid","blob","about")) check(!tap(s,"","resource"));check(w.scripts.size==n)
 check(w.scripts.all{it=="window.__mvHighlightAutoScrollSuppressed=true;"});check(w.scrollY==19204)
 println("PASS actual offline link router: repeated popup taps, JW fallback/installed, detected local/web verse, external routing, local resource passthrough, exact current scroll captured")
}''')
    run=subprocess.run(['kotlinc',str(p/'Main.kt'),str(p/'Util.kt'),'-include-runtime','-d',str(p/'test.jar')],capture_output=True,text=True,timeout=45)
    if run.returncode: raise AssertionError(run.stderr)
    subprocess.run(['java','-jar',str(p/'test.jar')],check=True,timeout=10)
lex=re.search(r'function doScroll\(el\) \{.*?\n            \}',s,re.S).group(0)
sem=re.search(r'requestAnimationFrame\(function\(\)\{requestAnimationFrame\(function\(\)\{\s*if \(window\.__mvHighlightCancelled.*?\}\);\}\);',s,re.S).group(0)
js='''const assert=require('assert');let count=0;let window={};const first={scrollIntoView:()=>count++};const requestAnimationFrame=f=>f();\n'''+lex+'\nfunction semantic(){'+sem+'}\n'+'''doScroll(first);semantic();assert.equal(count,2);window.__mvHighlightAutoScrollSuppressed=true;doScroll(first);semantic();assert.equal(count,2);window.__mvHighlightAutoScrollSuppressed=false;window.__mvHighlightNavManual=true;doScroll(first);semantic();assert.equal(count,2);window.__mvHighlightNavManual=false;window.__mvHighlightCancelled=true;doScroll(first);semantic();assert.equal(count,2);console.log('PASS both real automatic highlight scroll callbacks suppressed after opening link; normal initial scroll and legacy manual/cancel guards retained');'''
subprocess.run(['node','-e',js],check=True,timeout=10)
print('PASS saveable per-entry scroll fallback, native pixel restore and no link-triggered reload source wiring')
