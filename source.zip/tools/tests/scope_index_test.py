"""Execute the exact additive migration and unchanged Room partition SQL."""
import ast
import hashlib
import re
import sqlite3
import tempfile
import time
from pathlib import Path

root = Path(__file__).resolve().parents[2]
source = (root / "app/src/main/java/com/tebogo/markvault/data/Db.kt").read_text()
query = re.search(r'@Query\(("[^\n]+")\)\s*suspend fun getSearchScopeNoteIdPage', source)
assert query
sql = ast.literal_eval(query[1])
start = source.index("private val MIGRATION_23_24 =")
end = source.index("\n        }", start)
body = source[start:end]
assert body.count("db.execSQL(") == 1
statements = ["".join(ast.literal_eval(s) for s in re.findall(r'"(?:\\.|[^"\\])*"', body))]
assert statements == ["CREATE INDEX IF NOT EXISTS `index_notes_lastModified_id` ON `notes` (`lastModified`, `id`)"]
assert 'Index(value = ["lastModified", "id"])' in source and "version = 24," in source
assert "MIGRATION_22_23, MIGRATION_23_24)" in source

with tempfile.TemporaryDirectory() as tmp:
    path = Path(tmp) / "scope.db"
    db = sqlite3.connect(path)
    db.execute("PRAGMA journal_mode=WAL")
    db.execute("PRAGMA cache_size=-8192")
    db.executescript((root / "tools/tests/reference/notes_v23.sql").read_text())
    db.execute("PRAGMA user_version=23")
    db.executemany("INSERT INTO notes VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?)", (
        (n, f"uri{n}", f"folder/{n}.md", "name", f"title {n}", "folder", "article body " * 171,
         n % 311, 2223, n % 17, n % 29, n % 2, "html" if n % 3 else "md")
        for n in range(1, 42508)))
    db.commit()
    def contents():
        digest = hashlib.sha256()
        for row in db.execute("SELECT * FROM notes ORDER BY id"):
            digest.update(repr(row).encode())
        return digest.hexdigest()
    before_hash = contents()
    pages = [(20000, 0), (2147483647, 20000), (7, 3), (0, 0), (5, 50000)]
    before = [db.execute(sql, dict(limit=n, offset=offset)).fetchall() for n, offset in pages]
    plan_before = db.execute("EXPLAIN QUERY PLAN " + sql, dict(limit=20000, offset=0)).fetchall()
    assert any("TEMP B-TREE" in p[3] for p in plan_before)
    t = time.perf_counter(); db.execute(sql, dict(limit=20000, offset=0)).fetchall()
    old_ms = (time.perf_counter() - t) * 1000
    for statement in statements: db.execute(statement)
    db.execute("PRAGMA user_version=24"); db.commit()
    for statement in statements: db.execute(statement)  # idempotent index install
    assert contents() == before_hash
    after = [db.execute(sql, dict(limit=n, offset=offset)).fetchall() for n, offset in pages]
    assert before == after and len(before[0]) == 20000 and len(before[1]) == 22507
    assert not (set(before[0]) & set(before[1]))
    plan_after = db.execute("EXPLAIN QUERY PLAN " + sql, dict(limit=20000, offset=0)).fetchall()
    assert any("COVERING INDEX index_notes_lastModified_id" in p[3] for p in plan_after)
    assert not any("TEMP B-TREE" in p[3] for p in plan_after)
    t = time.perf_counter(); db.execute(sql, dict(limit=20000, offset=0)).fetchall()
    new_ms = (time.perf_counter() - t) * 1000
    baseline = after[0]
    db.execute("UPDATE notes SET lastModified=10000 WHERE id=1")
    assert db.execute(sql, dict(limit=20000, offset=0)).fetchone()[0] == 1
    db.rollback(); assert db.execute(sql, dict(limit=20000, offset=0)).fetchall() == baseline
    db.execute("UPDATE notes SET lastModified=10000 WHERE id=1"); db.commit()
    db.execute("DELETE FROM notes WHERE id=1"); db.commit()
    assert 1 not in {r[0] for r in db.execute(sql, dict(limit=20000, offset=0))}
    assert db.execute("PRAGMA integrity_check").fetchone()[0] == "ok"
    db.close(); db = sqlite3.connect(path)
    assert db.execute("PRAGMA user_version").fetchone()[0] == 24
    assert db.execute("PRAGMA integrity_check").fetchone()[0] == "ok"
    db.close()
    print(f"42,507-note additive migration/content hash/exact partition order/ties/update/delete/rollback/reopen/integrity=PASS; "
          f"table+sort_ms={old_ms:.2f} covering_index_ms={new_ms:.2f}; host timings only")
