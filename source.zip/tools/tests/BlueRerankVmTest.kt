package com.tebogo.markvault.search
import android.app.Application
import kotlinx.coroutines.*
import java.io.File
import java.nio.file.Files

fun main(args: Array<String>) = runBlocking {
    val dir = Files.createTempDirectory("blue-vm-rerank").toFile()
    val app = Application(dir)
    val fixture = BlueRerankVmFixture(app)
    val assets = File(args[0])
    try {
        for ((name, descriptor) in listOf("l12" to RerankerCatalog.MS_MARCO_MINI_LM_L12,
                                          "l6" to RerankerCatalog.MS_MARCO_MINI_LM_L6)) {
            Files.createSymbolicLink(descriptor.modelFileIn(dir).toPath(), File(assets, "reranker-$name.onnx").toPath())
            Files.createSymbolicLink(descriptor.vocabFileIn(dir).toPath(), File(assets, "reranker-vocab.txt").toPath())
        }
        val docs = List(30) { "The queen of Sheba visited Solomon and tested his wisdom. Article $it." }
        val first = fixture.scoreBlueRerankDocuments("who is the queen of sheba", docs)!!
        val loads = fixture.blueRerankEngine.sessionLoads
        check(loads == 1L && fixture.blueRerankEngine.loadedSessions == 1)
        val repeat = fixture.scoreBlueRerankDocuments("who is the queen of sheba", docs)!!
        check(first.contentEquals(repeat) && fixture.blueRerankEngine.sessionLoads == loads)
        val changed = fixture.scoreBlueRerankDocuments("who is the queen of sheba", docs.mapIndexed { i, s -> if (i == 5) "A changed document about a journey." else s })!!
        check(first.indices.all { it == 5 || first[it].toRawBits() == changed[it].toRawBits() })
        check(fixture.blueRerankEngine.sessionLoads == loads)
        // At lower headroom, one worker retains the same session and all exact memo hits.
        app.activity.availableBytes = 662L * 1024 * 1024
        check(fixture.scoreBlueRerankDocuments("who is the queen of sheba", docs)!!.contentEquals(first))
        check(fixture.blueRerankEngine.sessionLoads == loads)
        app.activity.lowMemory = true
        check(fixture.scoreBlueRerankDocuments("who is the queen of sheba", docs) == null)
        check(fixture.blueRerankEngine.loadedSessions == 0)
        app.activity.lowMemory = false
        app.activity.availableBytes = 4096L * 1024 * 1024
        // Cached scores remain usable without recreating an unloaded model.
        check(fixture.scoreBlueRerankDocuments("who is the queen of sheba", docs)!!.contentEquals(first))
        check(fixture.blueRerankEngine.sessionLoads == loads)
        fixture.reranker.setDescriptor(RerankerCatalog.MS_MARCO_MINI_LM_L6)
        check(fixture.scoreBlueRerankDocuments("who is the queen of sheba", docs)!!.all { it.isFinite() })
        check(fixture.blueRerankEngine.sessionLoads == loads + 1)
        println("Actual ViewModel helpers compile: memo hits/missing document/one-worker/session reuse/memory fallback/model switch=PASS")
    } finally {
        fixture.blueRerankEngine.unload(); fixture.reranker.unload()
        dir.listFiles()?.forEach { it.delete() }; dir.delete()
    }
}
