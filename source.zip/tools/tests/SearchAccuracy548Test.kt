import com.tebogo.markvault.data.Topics
import com.tebogo.markvault.search.KeywordRecallPlanner
import com.tebogo.markvault.search.QuestionAwareness

fun main() {
    // The actual reported failure: filler words and stray apostrophe must not block scripture.
    check(Topics.literalPrefixQuery("who were the sons of e'sau?") == "sons* esau*")
    check(Topics.literalPrefixQuery("Who were the sons of Esau?") == "sons* esau*")
    check(KeywordRecallPlanner.proximityQuery("Who were the sons of Esau?") == "sons* NEAR/8 esau*")
    // QA 2.0 retains provenance and produces useful relationship variants.
    val analysis = QuestionAwareness.analyze("Who were the sons of Esau?")
    check(analysis.isQuestion && analysis.type == QuestionAwareness.QuestionType.PERSON_IDENTITY)
    val variants = analysis.answerQueries.map { it.text.lowercase() }
    check("sons of esau" in variants && "esau sons" in variants) { variants }
    check(variants.none { it.startsWith("identity of the sons") || it.endsWith("were") })
    val possessive = QuestionAwareness.analyze("Who were Esau's sons?")
    check(possessive.answerQueries.any { it.text == "sons of Esau" })
    val typo = QuestionAwareness.analyze("Who were the sons of e'sau?")
    check(typo.isQuestion && typo.answerQueries.isNotEmpty())
    // Existing question functionality and neutrality.
    val caleb = QuestionAwareness.analyze("Caleb who was he?")
    check(caleb.isQuestion && caleb.answerQueries.any { "identity of Caleb" in it.text })
    val jesus = QuestionAwareness.analyze("Is Jesus God?")
    check(jesus.answerQueries.none { it.text.equals("Jesus is God", true) || it.text.equals("Jesus is not God", true) })
    check(!QuestionAwareness.analyze("men who abuse their wives").isQuestion)
    check(!QuestionAwareness.analyze("who magazine").isQuestion)
    // Exact mode always returns literal original phrases, no lexical simplification.
    check(Topics.literalPrefixQuery("\"who were the sons of Esau\"") == "\"who were the sons of Esau\"")
    check(KeywordRecallPlanner.coreQuery("\"who were the sons of Esau\"") == null)
    check(KeywordRecallPlanner.proximityQuery("\"who were the sons of Esau\"") == null)
    // Non-question topics and meaningful negatives must not be stripped.
    check(Topics.literalPrefixQuery("men who abuse their wives") == "men* who* abuse* their* wives*")
    check(Topics.literalPrefixQuery("Did Jesus not die?") == "jesus* not* die*")
    check(Topics.literalPrefixQuery("sons and daughters of Esau") == "sons* and* daughters* of* esau*")
    for (limit in 0..10) {
        for (engineOn in listOf(true, false)) {
            val slots = QuestionAwareness.questionSlots(limit, engineOn)
            check(slots in 0..limit && (limit - slots) >= 0)
        }
    }
    println("PASS: Esau recall, misspelling, QA genealogy, Caleb, neutrality, exact-mode, negation, original prose, 22 expansion budgets")
}
