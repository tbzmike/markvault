package com.tebogo.markvault.search

import android.content.Context
import kotlinx.coroutines.*
import java.nio.ByteBuffer
import java.nio.ByteOrder
import java.nio.file.Files
import java.security.MessageDigest
import kotlin.math.sqrt
import kotlin.random.Random

fun main() = runBlocking {
    val dir = Files.createTempDirectory("markvault_original_ivf").toFile()
    val index = AnnIndex(Context(dir))
    val random = Random(473)
    val vectors = (1L..2001L).associateWith {
        val v = FloatArray(16) { random.nextFloat() * 2 - 1 }
        val norm = sqrt(v.sumOf { (it * it).toDouble() }).toFloat()
        FloatArray(16) { v[it] / norm }
    }
    fun bytes(id: Long) = ByteBuffer.allocate(64).order(ByteOrder.LITTLE_ENDIAN)
        .apply { vectors.getValue(id).forEach { putFloat(it) } }.array()
    val rows = (1L..2000L).map { it to bytes(it) }.toMutableList()
    suspend fun page(limit: Int, offset: Int) = rows.drop(offset).take(limit)
    try {
        val built = index.build(::page, "model-a", 16, rows.size) { _, _ -> }.getOrThrow()
        check(index.isAvailable("model-a") && !index.isAvailable("missing"))
        check(built.numVectors == rows.size && index.indexedNoteIds("model-a") == rows.map { it.first }.toSet())
        check(index.recommendedAccuracyNprobe("model-a") in 1..minOf(64, built.numClusters))
        check(index.findCandidates(vectors.getValue(101), "model-a", built.numClusters) == rows.map { it.first }.toSet())
        check(101L in index.findCandidates(vectors.getValue(101), "model-a", index.recommendedAccuracyNprobe("model-a"))!!)
        check(index.findCandidates(FloatArray(15), "model-a") == null)
        check(index.findCandidates(vectors.getValue(101), "missing") == null)
        rows.removeAll { it.first == 2L }
        rows.add(2001L to bytes(2L))
        rows[100] = rows[100].first to bytes(2001L)
        val updatedId = rows[100].first
        val delta = index.synchronizeModel(::page, "model-a", setOf(updatedId), true, 300)
        check(delta.removedNotes == 1 && delta.updatedNotes >= 2 && delta.embeddingCount == 2000)
        val expected = rows.map { it.first }.toSet()
        check(index.indexedNoteIds("model-a") == expected)
        index.unload()
        val reader = AnnIndex(Context(dir))
        check(reader.indexedNoteIds("model-a") == expected)
        check(reader.stats("model-a")!!.embeddingCountAtBuild == rows.size)
        val snapshot = dir.listFiles()!!.single { it.name.startsWith("ann_ivf_") && it.name.endsWith(".bin") }
        fun hash() = MessageDigest.getInstance("SHA-256").digest(snapshot.readBytes()).toList()
        val before = hash()
        check(index.build({ _, _ -> error("SQLite read failed") }, "model-a", 16, 2000) { _, _ -> }.isFailure)
        check(hash() == before && !index.isBuilding)
        val cancelled = launch {
            index.build(::page, "model-a", 16, 2000) { progress, _ -> if (progress > 0.1f) cancel() }
        }
        cancelled.join()
        check(cancelled.isCancelled && hash() == before && !index.isBuilding)
        check(index.build(::page, "model-b", 16, 2000) { _, _ -> }.isSuccess)
        check(index.stats("model-a")!!.modelVersion == "model-a" && index.stats("model-b")!!.modelVersion == "model-b")
        index.delete("model-b")
        check(!index.isAvailable("model-b") && index.isAvailable("model-a"))
        check(index.indexedNoteIds("model-a") == expected)
        println("Original IVF build/search/accuracy probes/same-count edit/delete/model separation/reopen/failed and cancelled atomic rebuild checks=PASS")
    } finally { index.unload(); dir.deleteRecursively() }
}
