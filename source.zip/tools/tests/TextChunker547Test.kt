package com.tebogo.markvault.search

/** No Android dependencies: run against the production shared chunker. */
object TextChunker547Test {
    private fun previous(text: String, targetWords: Int, overlapWords: Int, minWords: Int): List<TextChunk> {
        val words: List<String> = text.split(Regex("\\s+")).filter { it.isNotEmpty() }
        if (words.size < minWords) return emptyList()
        if (words.size <= targetWords) return listOf(TextChunk(words.joinToString(" "), 0))
        val step = (targetWords - overlapWords).coerceAtLeast(1)
        val chunks = mutableListOf<TextChunk>()
        var i = 0
        while (i < words.size) {
            val end = minOf(i + targetWords, words.size)
            chunks.add(TextChunk(words.subList(i, end).joinToString(" "), i))
            if (end >= words.size) break
            i += step
        }
        return chunks
    }
    @JvmStatic fun main(args: Array<String>) {
        var tested = 0
        val patterns = listOf(" ", " \n ", "\t \n", "  \t", " \u00a0 ")
        for (count in listOf(0, 1, 2, 29, 30, 31, 179, 180, 181, 349, 350, 351, 352, 559, 560, 629, 630, 631, 1000, 10001)) {
            for (separator in patterns) {
                val note = (1..count).joinToString(separator) { "word$it" }
                for ((target, overlap, min) in listOf(Triple(350,70,30),Triple(180,45,30))) {
                    val expected = previous(note, target, overlap, min)
                    val actual = buildOverlappingChunks(note, target, overlap, min)
                    check(expected == actual) { "Chunk mismatch count=$count sep=${separator.length} target=$target" }
                    check(actual.all { it.startWordIdx >= 0 && it.text.isNotBlank() })
                    tested++
                }
            }
        }
        println("PASS: $tested exact legacy-vs-current chunking checks; all boundaries and overlap unchanged")
    }
}
