#include "hnsw_core.hpp"
#include <cassert>
#include <chrono>
#include <iostream>
#include <limits>
#include <random>

static bool identical(float a, float b) {
    std::uint32_t x, y;
    std::memcpy(&x, &a, sizeof(x)); std::memcpy(&y, &b, sizeof(y));
    return x == y || (std::isnan(a) && std::isnan(b));
}

int main(int argc, char**) {
    std::mt19937 random(20261006);
    std::uniform_real_distribution<float> value(-2.f, 2.f);
    std::size_t comparisons = 0;
    for (std::size_t dim : {1, 3, 4, 7, 32, 103, 128, 256, 257, 384, 512, 768, 769, 1024, 2048}) {
        std::vector<float> query(dim);
        std::array<std::vector<float>, 4> rows;
        for (auto& row : rows) row.resize(dim);
        for (int trial = 0; trial < 100; ++trial) {
            for (auto& x : query) x = value(random);
            for (auto& row : rows) for (auto& x : row) x = value(random);
            if (trial == 0) std::fill(query.begin(), query.end(), 0.f);
            if (trial == 1) rows[0][dim / 2] = std::numeric_limits<float>::quiet_NaN();
            if (trial == 2) rows[1][dim / 2] = std::numeric_limits<float>::infinity();
            if (trial == 3) rows[2][dim / 2] = -std::numeric_limits<float>::infinity();
            if (trial == 4) std::fill(rows[3].begin(), rows[3].end(), -0.f);
            if (trial == 5) for (std::size_t i = 0; i < dim; ++i) {
                query[i] = (i & 1) ? -1.f : 1.f;
                for (auto& row : rows) row[i] = (i % 3) ? .000001f : 1e8f;
            }
            auto scores = markvault::exact_dot4(query.data(),
                {rows[0].data(), rows[1].data(), rows[2].data(), rows[3].data()}, dim);
            for (std::size_t i = 0; i < 4; ++i) {
                float expected = markvault::exact_dot(query.data(), rows[i].data(), dim);
                assert(identical(scores[i], expected));
                assert(identical(std::clamp(scores[i], -1.f, 1.f), std::clamp(expected, -1.f, 1.f)));
                ++comparisons;
            }
        }
    }
    std::cout << "Exact FP32 four-vector/scalar scores and clamps: " << comparisons
              << " comparisons including odd dimensions, cancellation, zero, NaN/Inf = PASS\n";
    if (argc > 1) return 0;

    constexpr std::size_t dim = 768, count = 24000;
    std::vector<float> query(dim), rows(count * dim);
    for (auto& x : query) x = value(random) / dim;
    for (auto& x : rows) x = value(random);
    volatile float sink = 0;
    std::vector<double> scalar, batched;
    auto run = [&](bool four) {
        auto start = std::chrono::steady_clock::now();
        for (std::size_t i = 0; i < count; i += 4) {
            if (four) {
                auto s = markvault::exact_dot4(query.data(), {rows.data()+i*dim,
                    rows.data()+(i+1)*dim, rows.data()+(i+2)*dim, rows.data()+(i+3)*dim}, dim);
                for (auto x : s) sink += x;
            } else {
                for (std::size_t v = 0; v < 4; ++v)
                    sink += markvault::exact_dot(query.data(), rows.data()+(i+v)*dim, dim);
            }
        }
        return std::chrono::duration<double,std::milli>(std::chrono::steady_clock::now()-start).count();
    };
    run(false); run(true);
    for (int trial = 0; trial < 9; ++trial) {
        if (trial & 1) {batched.push_back(run(true)); scalar.push_back(run(false));}
        else {scalar.push_back(run(false)); batched.push_back(run(true));}
    }
    std::sort(scalar.begin(),scalar.end()); std::sort(batched.begin(),batched.end());
    std::cout << "Host-only 24000 x 768 FP32 math median: serial=" << scalar[4]
              << "ms four-vector=" << batched[4] << "ms (not Android search latency)\n";
}
