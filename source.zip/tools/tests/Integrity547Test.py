#!/usr/bin/env python3
"""MarkVault 5.5.47 source-contract checks. Complements JVM chunk unit tests.
Not a substitute for an instrumented Android backup/restore or battery test.
"""
from pathlib import Path
import re
r = Path(__file__).resolve().parents[2]
read = lambda rel: (r / rel).read_text()
score = read('app/src/main/java/com/tebogo/markvault/ui/SearchScreen.kt')
embed = read('app/src/main/java/com/tebogo/markvault/search/EmbeddingService.kt')
backup = read('app/src/main/java/com/tebogo/markvault/data/BackupManager.kt')
db = read('app/src/main/java/com/tebogo/markvault/data/Db.kt')
splitter = read('app/src/main/java/com/tebogo/markvault/search/TextChunker.kt')
version = read('app/build.gradle.kts')
assert 'versionCode = 496' in version and 'versionName = "5.5.47"' in version
assert 'private val CHUNK_WHITESPACE = Regex("\\\\s+")' in splitter
assert 'text.split(CHUNK_WHITESPACE)' in splitter
assert 'targetWords = 350' in embed and 'overlapWords = 70' in embed and 'minWords = 30' in embed
assert 'primaryKeys = ["noteId", "modelVersion", "chunkIndex"]' in db
assert '@Transaction\n    suspend fun replaceNoteEmbeddings' in db
assert 'chunkInferenceFailed || noteEmbeddings.size != chunkTexts.size' in embed
assert embed.index('if (chunkInferenceFailed || noteEmbeddings.size != chunkTexts.size)') < embed.index('dao.replaceNoteEmbeddings(')
assert 'vec == null || vec.size != descriptor.embeddingDim' in embed
assert 'runCatching { System.gc() }' in embed  # memory-pressure safeguard retained
assert 'usedAfterModel >= rtAfterModel.maxMemory().coerceAtLeast(1L) * 85L / 100L' in embed
assert 'NOTIFICATION_UPDATE_INTERVAL_MS' in embed
# Color contrast is independent of alternating card backgrounds (solid opaque chip).
assert 'Color(0xFF176B37)' in score and 'Color(0xFF245B8F)' in score
assert 'pct >= 75 -> androidx.compose.ui.graphics.Color.White' in score
assert 'pct >= 55 -> androidx.compose.ui.graphics.Color.White' in score

def lum(hexrgb):
    v=[int(hexrgb[i:i+2],16)/255 for i in (0,2,4)]
    v=[c/12.92 if c<=.04045 else ((c+.055)/1.055)**2.4 for c in v]
    return v[0]*.2126+v[1]*.7152+v[2]*.0722
for bg in ('176B37','245B8F'):
    contrast=1.05/(lum(bg)+.05)
    assert contrast>=4.5, (bg,contrast)
assert 'FROM note_embeddings ORDER BY noteId, modelVersion, chunkIndex' in backup
assert 'data.writeInt(c.getInt(2))' in backup  # chunk index serialized
assert 'stmt.bindLong(3, chunkIndex.toLong())' in backup  # chunk index restored
assert 'settings/settings.preferences_pb' in backup
assert 'ann_(?:ivf|hnsw)_' in backup
assert 'validateAnnSnapshotFile(candidate)' in backup
assert 'require(found == expectedCount)' in backup
assert 'val moved = ArrayList<Pair<File, File>>()' in backup
assert 'old.renameTo(saved)' in backup
assert 'saved.renameTo(original)' in backup
assert 'if (!preserveRecoveryCopies) staged.deleteRecursively()' in backup
assert 'installed.add(dst)' in backup and 'validateAnnSnapshotFile(dst)' in backup
print('PASS: chunk storage/atomicity, backup all-model vectors/settings/ANN, restore rollback, score contrast, battery GC guards')
