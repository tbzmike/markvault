package com.tebogo.markvault.data

import android.provider.DocumentsContract
import java.io.ByteArrayOutputStream
import java.security.MessageDigest
import java.util.zip.ZipEntry
import java.util.zip.ZipOutputStream

private val root = "content://fake/library/root"
private val context = FakeContext()
private fun archive(files: Map<String, String>, dirs: List<String> = emptyList()): Map<String, String> {
    val output = ByteArrayOutputStream()
    ZipOutputStream(output).use { zip ->
        zip.putNextEntry(ZipEntry(PortableBackupFiles.DIRECTORIES_ENTRY))
        zip.write(org.json.JSONArray(dirs).toString().toByteArray()); zip.closeEntry()
        files.forEach { (path, text) ->
            zip.putNextEntry(ZipEntry(PortableBackupFiles.LIBRARY_PREFIX + path))
            zip.write(text.toByteArray()); zip.closeEntry()
        }
    }
    FakeDocs.zipBytes = output.toByteArray()
    return files.mapValues { (_, value) -> BackupZipIO.hex(MessageDigest.getInstance("SHA-256").digest(value.toByteArray())) }
}
private fun checkContent(result: PortableBackupFiles.LibraryRestoreResult, files: Map<String, String>) {
    check(result.documentIds.keys == files.keys)
    check(result.documentIds.values.toSet().size == files.size)
    files.forEach { (path, text) ->
        val doc = FakeDocs.docs.getValue(result.documentIds.getValue(path))
        check(String(doc.bytes) == text) { "wrong restored content for $path" }
    }
}
fun main() {
    val files = linkedMapOf("2026-.md" to "A unique note", "Study:notes/Caleb.md" to "Caleb", "Study:notes/Esau.md" to "Esau", "Study:notes/2026-.md" to "In folder")
    val expected = archive(files, listOf("Study:notes"))
    FakeDocs.reset()
    FakeDocs.createName = { name, mime ->
        when {
            mime == "text/plain" && name.endsWith(".md") -> "$name.txt"
            name == "Study:notes" -> "Study_notes"
            name == "2026-.md" -> "2026- (1).md"
            else -> name
        }
    }
    val result = PortableBackupFiles.restoreLibrary(context, FakeDocs.zip, root, expected)
    checkContent(result, files)
    val restoredTree = PortableBackupFiles.scanLibrary(context, root)
    check(result.installed == files.size && result.providerRenames == 3)
    check(restoredTree.files.all { it.relativePath.endsWith(".md") })
    check(restoredTree.files.any { it.sourceRelativePath == "Study_notes/Caleb.md" })
    val before = FakeDocs.docs.size
    val again = PortableBackupFiles.restoreLibrary(context, FakeDocs.zip, root, expected)
    checkContent(again, files)
    check(again.documentIds == result.documentIds && again.installed == 0 && FakeDocs.docs.size == before)
    println("PASS older-provider MIME extension, renamed filenames and folder, actual-ID mapping, retry reuses all documents")

    FakeDocs.reset()
    val fallbackFiles = mapOf("Fallback.md" to "Retain type")
    val fallbackHashes = archive(fallbackFiles)
    FakeDocs.createName = { name, mime -> if (mime == "application/octet-stream") "$name.bin" else name }
    val fallback = PortableBackupFiles.restoreLibrary(context, FakeDocs.zip, root, fallbackHashes)
    checkContent(fallback, fallbackFiles)
    check(FakeDocs.docs.values.none { it.name.endsWith(".bin") })
    check(FakeDocs.docs.getValue(fallback.documentIds.getValue("Fallback.md")).name == "Fallback.md")
    println("PASS MIME fallback deletes only its own empty incorrectly suffixed document")

    FakeDocs.reset()
    FakeDocs.add("root", "existing-id", "Existing.md", bytes = "Keep this original")
    val unsafe = archive(mapOf("New.md" to "Incoming"))
    FakeDocs.existingResult = { _, _, _ -> "existing-id" }
    val error = runCatching { PortableBackupFiles.restoreLibrary(context, FakeDocs.zip, root, unsafe) }.exceptionOrNull()
    check(error?.message?.contains("existing document") == true)
    check(String(FakeDocs.docs.getValue("existing-id").bytes) == "Keep this original")
    check(FakeDocs.docs.size == 2)
    println("PASS provider existing-ID error cannot overwrite or delete destination contents")

    FakeDocs.reset()
    FakeDocs.add("root", "file-clash", "Study", bytes = "Original file with conflicting folder name")
    val clashFiles = linkedMapOf("Study/One.md" to "First", "Study/Two.md" to "Second")
    val clashHashes = archive(clashFiles, listOf("Study"))
    val clash = PortableBackupFiles.restoreLibrary(context, FakeDocs.zip, root, clashHashes)
    checkContent(clash, clashFiles)
    check(String(FakeDocs.docs.getValue("file-clash").bytes) == "Original file with conflicting folder name")
    check(PortableBackupFiles.scanLibrary(context, root).files.count { it.relativePath.startsWith("Study (MarkVault restored folder)/") } == 2)
    val clashRetry = PortableBackupFiles.restoreLibrary(context, FakeDocs.zip, root, clashHashes)
    check(clashRetry.documentIds == clash.documentIds && clashRetry.installed == 0)
    println("PASS file-versus-folder collision and repeat restore")

    FakeDocs.reset()
    val sameNames = linkedMapOf("Alpha.md" to "same", "Alpha (1).md" to "same")
    val sameHashes = archive(sameNames)
    FakeDocs.createName = { name, _ -> if (name == "Alpha.md") "Alpha (1).md" else "Alpha (2).md" }
    val same = PortableBackupFiles.restoreLibrary(context, FakeDocs.zip, root, sameHashes)
    checkContent(same, sameNames)
    println("PASS separate archive members cannot share destination identity even with equal content and colliding provider names")

    FakeDocs.reset()
    val unsupported = archive(mapOf("Good.md" to "Good", "Wrong.pdf" to "PDF content"))
    FakeDocs.createName = { name, _ -> if (name.endsWith(".pdf")) "$name.txt" else name }
    val invalid = runCatching { PortableBackupFiles.restoreLibrary(context, FakeDocs.zip, root, unsupported) }.exceptionOrNull()
    check(invalid?.message?.contains("original file type") == true)
    check(FakeDocs.docs.size == 1) // rollback, no orphaned .txt nor earlier good file
    println("PASS unsupported file type fails safely and rolls back created documents")
}
