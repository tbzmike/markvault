#include "hnsw_core.hpp"
#include "reference/hnsw_v26.hpp"
#include <chrono>
#include <iostream>
#include <random>

int main(int argc, char** argv) {
    if (argc != 4) throw std::invalid_argument("Expected: graph_path dimensions articles");
    auto dim = std::stoull(argv[2]), count = std::stoull(argv[3]);
    markvault_v26::Hnsw previous(dim, 0, false);
    markvault::Hnsw current(dim, 0, false);
    previous.open(argv[1], 1, false); current.open(argv[1], 1, false);
    if (previous.size() != count * 5 || current.size() != count * 5)
        throw std::runtime_error("Graph fixture mismatch");
    std::vector<std::uint64_t> first, second, sparse{1, 3, 7}, empty;
    for (std::size_t n = 1; n <= count; ++n) (n <= count * 20 / 42 ? first : second).push_back(n);
    std::mt19937 random(476);
    std::normal_distribution<float> normal;
    std::vector<float> query(dim);
    std::vector<double> old_times, new_times;
    std::size_t checked = 0;
    for (int q = 0; q < 16; ++q) {
        float norm = 0;
        for (auto& value : query) { value = normal(random); norm += value * value; }
        norm = std::sqrt(norm);
        for (auto& value : query) value /= norm;
        for (auto allowed : std::array<std::vector<std::uint64_t> const*, 5>{nullptr, &first, &second, &sparse, &empty}) {
            auto start = std::chrono::steady_clock::now();
            auto a = previous.article_candidates(query.data(), dim, 600, 200, allowed);
            auto old_ms = std::chrono::duration<double, std::milli>(std::chrono::steady_clock::now() - start).count();
            start = std::chrono::steady_clock::now();
            auto b = current.article_candidates(query.data(), dim, 600, 200, allowed);
            auto new_ms = std::chrono::duration<double, std::milli>(std::chrono::steady_clock::now() - start).count();
            if (a.articles != b.articles || a.exhaustive != b.exhaustive || a.passages != b.passages || a.scored != b.scored)
                throw std::runtime_error("5.5.26 candidate order/coverage/distance count changed");
            if (!allowed || allowed->size() > 10) { old_times.push_back(old_ms); new_times.push_back(new_ms); }
            ++checked;
        }
    }
    std::sort(old_times.begin(), old_times.end()); std::sort(new_times.begin(), new_times.end());
    std::cout << "5.5.26 vs 5.5.27: " << checked << " candidate lists exactly identical (all/first20k/second22k/sparse/empty) on "
              << count * 5 << " chunks x " << dim << " dimensions=PASS; host median_ms="
              << old_times[old_times.size() / 2] << " -> " << new_times[new_times.size() / 2] << std::endl;
}
