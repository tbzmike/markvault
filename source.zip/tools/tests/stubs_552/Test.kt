package com.tebogo.markvault.data

import android.content.ContentResolver
import android.content.Context
import android.database.Cursor
import android.net.Uri
import android.provider.DocumentsContract
import java.io.ByteArrayInputStream
import java.io.ByteArrayOutputStream
import java.io.OutputStream
import java.security.MessageDigest
import java.util.zip.ZipEntry
import java.util.zip.ZipOutputStream

object FakeDocs {
    data class Doc(val id: String, val name: String, val mime: String, var bytes: ByteArray = byteArrayOf(), val children: MutableList<String> = mutableListOf())
    val docs = linkedMapOf<String, Doc>()
    var nextId = 0
    val zip = Uri("zip:portable")
    var zipBytes = byteArrayOf()
    fun reset() { docs.clear(); nextId = 0; docs["root"] = Doc("root", "root", DocumentsContract.Document.MIME_TYPE_DIR) }
    fun add(parent: String, id: String, name: String, mime: String = "text/plain", bytes: String = ""): Doc {
        val result = Doc(id, name, mime, bytes.toByteArray())
        docs[id] = result
        docs[parent]!!.children.add(id)
        return result
    }
    fun create(parent: String, name: String, mime: String): Uri {
        val id = "new-${++nextId}"
        add(parent, id, name, mime)
        return Uri("doc:$id")
    }
    fun delete(id: String): Boolean {
        docs.values.forEach { it.children.remove(id) }
        return docs.remove(id) != null
    }
    internal fun scanSnapshot(tree: PortableBackupFiles.LibraryTree): Map<String,String> =
        tree.files.associate { it.relativePath to String(docs[it.uri.value.substringAfter(':')]!!.bytes) }
}

class FakeCursor(private val rows: List<List<Any?>>): Cursor {
    private var at = -1
    override fun moveToFirst(): Boolean { at = 0; return rows.isNotEmpty() }
    override fun moveToNext(): Boolean { at++; return at < rows.size }
    override fun getLong(col: Int) = (rows[at][col] as Number).toLong()
    override fun getInt(col: Int) = (rows[at][col] as Number).toInt()
    override fun getDouble(col: Int) = (rows[at][col] as Number).toDouble()
    override fun getString(col: Int) = rows[at][col] as String
    override fun getBlob(col: Int) = rows[at][col] as ByteArray
    override fun getType(col: Int) = when (rows[at][col]) {
        null -> Cursor.FIELD_TYPE_NULL; is ByteArray -> Cursor.FIELD_TYPE_BLOB
        is Number -> Cursor.FIELD_TYPE_INTEGER; else -> Cursor.FIELD_TYPE_STRING
    }
    override fun isNull(col: Int) = rows[at][col] == null
}
class FakeResolver: ContentResolver() {
    override fun query(uri: Uri, projection: Array<String>, selection: String?, args: Array<String>?, order: String?): Cursor {
        val rows = when {
            uri.value.startsWith("children:") -> FakeDocs.docs[uri.value.substringAfter(':')]!!.children.map { id ->
                val d = FakeDocs.docs[id]!!
                listOf(d.id, d.name, d.mime, d.bytes.size.toLong(), 123L)
            }
            uri.value.startsWith("doc:") -> {
                val d = FakeDocs.docs[uri.value.substringAfter(':')]!!
                listOf(listOf(d.id, d.name, d.mime, d.bytes.size.toLong(), 123L))
            }
            else -> emptyList()
        }
        val full = listOf("id", "name", "mime", "size", "modified")
        return FakeCursor(rows.map { row -> projection.map { field -> row[full.indexOf(field)] } })
    }
    override fun openInputStream(uri: Uri) = when {
        uri == FakeDocs.zip -> ByteArrayInputStream(FakeDocs.zipBytes)
        else -> ByteArrayInputStream(FakeDocs.docs[uri.value.substringAfter(':')]!!.bytes)
    }
    override fun openOutputStream(uri: Uri, mode: String): OutputStream {
        val id = uri.value.substringAfter(':')
        return object: ByteArrayOutputStream() {
            override fun close() { super.close(); FakeDocs.docs[id]!!.bytes = toByteArray() }
        }
    }
}
class FakeContext: Context() { override val contentResolver: ContentResolver = FakeResolver() }

fun main() {
    val treeUri = "content://fake/library/root"
    val context = FakeContext()
    FakeDocs.reset()
    val dir = DocumentsContract.Document.MIME_TYPE_DIR
    FakeDocs.add("root", "folder-A", "Articles", dir)
    FakeDocs.add("root", "folder-B", "Articles", dir)
    FakeDocs.add("folder-A", "a-file", "test.md", bytes = "First folder's article")
    FakeDocs.add("folder-B", "b-file", "test.md", bytes = "Second folder's article")
    FakeDocs.add("root", "original-1", "Esau.md", bytes = "First Esau content")
    FakeDocs.add("root", "original-2", "Esau.md", bytes = "Second Esau content")
    FakeDocs.add("root", "already-copy", "Esau (MarkVault copy 2).md", bytes = "Actual named copy")
    FakeDocs.docs["root"]!!.children.add("original-1") // provider reports same document ID twice
    val original = PortableBackupFiles.scanLibrary(context, treeUri)
    check(original.files.size == 5) { "Documents lost: ${original.files}" }
    check(original.directories.size == 2)
    check(original.files.map { it.relativePath }.toSet().size == 5)
    check(original.files.map { it.relativePath }.any { it.contains("MarkVault copy 3") })
    check(original.directories.any { it.contains("MarkVault copy 2") })
    val expected = FakeDocs.scanSnapshot(original)
    check(original.files.count { it.sourceRelativePath == "Esau.md" } == 2)
    val firstEsau = original.files.first { it.uri.value == "doc:original-1" }
    val secondEsau = original.files.first { it.uri.value == "doc:original-2" }
    check(firstEsau.relativePath != secondEsau.relativePath)
    check(firstEsau.sourceRelativePath == secondEsau.sourceRelativePath)
    val buffer = ByteArrayOutputStream()
    ZipOutputStream(buffer).use { zip ->
        zip.putNextEntry(ZipEntry(PortableBackupFiles.DIRECTORIES_ENTRY))
        zip.write(PortableBackupFiles.directoryBytes(original));zip.closeEntry()
        for (file in original.files) {
            zip.putNextEntry(ZipEntry(PortableBackupFiles.LIBRARY_PREFIX + file.relativePath))
            zip.write(FakeDocs.docs[file.uri.value.substringAfter(':')]!!.bytes)
            zip.closeEntry()
        }
    }
    val expectedHashes = expected.mapValues { (_, text) ->
        MessageDigest.getInstance("SHA-256").digest(text.toByteArray()).joinToString("") { "%02x".format(it) }
    }
    FakeDocs.zipBytes = buffer.toByteArray()
    FakeDocs.reset() // completely different device with no original IDs/URIs
    check(PortableBackupFiles.restoreLibrary(context, FakeDocs.zip, treeUri, expectedHashes).installed == 5)
    val restored = PortableBackupFiles.scanLibrary(context, treeUri)
    check(FakeDocs.scanSnapshot(restored) == expected) { "Cross-device file/content mapping changed" }
    check(PortableBackupFiles.restoreLibrary(context, FakeDocs.zip, treeUri, expectedHashes).installed == 0)
    val fileId = restored.files.first { it.relativePath == "Esau.md" }.uri.value.substringAfter(':')
    FakeDocs.docs[fileId]!!.bytes = "different user file".toByteArray()
    val conflicting = PortableBackupFiles.restoreLibrary(context, FakeDocs.zip, treeUri, expectedHashes)
    check(conflicting.installed == 1 && conflicting.conflicts == 1)
    check(String(FakeDocs.docs[fileId]!!.bytes) == "different user file")
    check(conflicting.documentIds["Esau.md"] != fileId)
    check(String(FakeDocs.docs[conflicting.documentIds["Esau.md"]]!!.bytes) == expected["Esau.md"])
    val retry = PortableBackupFiles.restoreLibrary(context, FakeDocs.zip, treeUri, expectedHashes)
    check(retry.installed == 0 && retry.documentIds == conflicting.documentIds)
    FakeDocs.reset()
    FakeDocs.add("root", "obsidian", ".obsidian", dir)
    FakeDocs.add("obsidian", "bookmarks-source", "bookmarks.json", "application/json", "source bookmarks")
    FakeDocs.add("obsidian", "app-source", "app.json", "application/json", "same config")
    FakeDocs.add("root", "article-source", "Article.md", bytes = "indexed article content")
    val sharedTree = PortableBackupFiles.scanLibrary(context, treeUri)
    val sharedExpected = FakeDocs.scanSnapshot(sharedTree)
    val sharedHashes = sharedExpected.mapValues { (_, text) ->
        MessageDigest.getInstance("SHA-256").digest(text.toByteArray()).joinToString("") { "%02x".format(it) }
    }
    val sharedBuffer = ByteArrayOutputStream()
    ZipOutputStream(sharedBuffer).use { zip ->
        zip.setLevel(java.util.zip.Deflater.BEST_COMPRESSION)
        zip.putNextEntry(ZipEntry(PortableBackupFiles.DIRECTORIES_ENTRY))
        zip.write(PortableBackupFiles.directoryBytes(sharedTree)); zip.closeEntry()
        for (file in sharedTree.files) {
            zip.putNextEntry(ZipEntry(PortableBackupFiles.LIBRARY_PREFIX + file.relativePath))
            zip.write(FakeDocs.docs[file.uri.value.substringAfter(':')]!!.bytes); zip.closeEntry()
        }
    }
    FakeDocs.zipBytes = sharedBuffer.toByteArray()
    FakeDocs.reset()
    FakeDocs.add("root", "local-obsidian", ".obsidian", dir)
    FakeDocs.add("local-obsidian", "local-bookmarks", "bookmarks.json", "application/json", "local bookmarks")
    FakeDocs.add("local-obsidian", "local-app", "app.json", "application/json", "same config")
    FakeDocs.add("root", "local-article", "Article.md", bytes = "indexed article content")
    val sharedResult = PortableBackupFiles.restoreLibrary(context, FakeDocs.zip, treeUri, sharedHashes)
    check(sharedResult.installed == 1 && sharedResult.conflicts == 1)
    check(sharedResult.documentIds["Article.md"] == "local-article")
    check(sharedResult.documentIds[".obsidian/app.json"] == "local-app")
    check(String(FakeDocs.docs["local-bookmarks"]!!.bytes) == "local bookmarks")
    check(String(FakeDocs.docs[sharedResult.documentIds[".obsidian/bookmarks.json"]]!!.bytes) == "source bookmarks")
    val sharedSnapshot = FakeDocs.scanSnapshot(PortableBackupFiles.scanLibrary(context, treeUri))
    check(sharedSnapshot[".obsidian/bookmarks.json"] == "local bookmarks")
    check(sharedSnapshot.any { (path, data) -> path.startsWith(".markvault-restore-conflicts/") && data == "source bookmarks" })
    val sharedRetry = PortableBackupFiles.restoreLibrary(context, FakeDocs.zip, treeUri, sharedHashes)
    check(sharedRetry.installed == 0 && sharedRetry.documentIds == sharedResult.documentIds)
    println("PASS shared Obsidian vault: changed bookmarks preserved separately, identical files reused, retries stable")
    val cases = (1..1200).map { PortableLibraryPaths.Child("$it", "duplicate.md") }
    val assigned = PortableLibraryPaths.assign(cases)
    check(assigned.size == 1200 && assigned.map { it.archiveName }.toSet().size == 1200)
    println("PASS portable backup: repeated SAF rows, distinct colliding filenames and folders, reserved collision names, cross-device restore, idempotent restore and overwrite protection")
}
