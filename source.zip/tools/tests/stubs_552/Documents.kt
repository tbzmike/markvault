package android.provider
import android.content.ContentResolver
import android.net.Uri
import com.tebogo.markvault.data.FakeDocs

object DocumentsContract {
    object Document {
        const val COLUMN_DOCUMENT_ID = "id"
        const val COLUMN_DISPLAY_NAME = "name"
        const val COLUMN_MIME_TYPE = "mime"
        const val COLUMN_SIZE = "size"
        const val COLUMN_LAST_MODIFIED = "modified"
        const val MIME_TYPE_DIR = "vnd.android.document/directory"
    }
    fun getTreeDocumentId(tree: Uri): String = "root"
    fun buildChildDocumentsUriUsingTree(tree: Uri, id: String) = Uri("children:$id")
    fun buildDocumentUriUsingTree(tree: Uri, id: String) = Uri("doc:$id")
    fun getDocumentId(uri: Uri) = uri.value.substringAfter(':')
    fun createDocument(cr: ContentResolver, parent: Uri, mime: String, name: String): Uri? =
        FakeDocs.create(parent.value.substringAfter(':'), name, mime)
    fun deleteDocument(cr: ContentResolver, uri: Uri): Boolean = FakeDocs.delete(uri.value.substringAfter(':'))
}
