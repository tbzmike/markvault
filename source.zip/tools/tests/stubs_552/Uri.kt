package android.net

data class Uri(val value: String) {
    val authority: String? get() = value.removePrefix("content://").substringBefore('/').takeIf { value.startsWith("content://") }
    companion object { fun parse(s: String) = Uri(s) }
    override fun toString() = value
}
