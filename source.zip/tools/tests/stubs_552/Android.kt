package android.content
import android.net.Uri
import android.database.Cursor
import java.io.File
import java.io.InputStream
import java.io.OutputStream

open class Context {
    open val filesDir: File get() = File("/tmp/mv552_test_files")
    open val contentResolver: ContentResolver get() = ContentResolver()
    open val applicationInfo: ApplicationInfo get() = ApplicationInfo()
}
class ApplicationInfo { val dataDir: String = "/tmp/mv552_test_data" }
open class ContentResolver {
    open fun query(uri: Uri, projection: Array<String>, selection: String?, args: Array<String>?, order: String?): Cursor? = null
    open fun openInputStream(uri: Uri): InputStream? = null
    open fun openOutputStream(uri: Uri, mode: String): OutputStream? = null
}
