package org.json
class JSONArray {
    private val parts: List<String>
    constructor(c: Collection<String>) { parts = c.toList() }
    constructor(s: String) { parts = Regex("\\\"([^\\\"]*)\\\"").findAll(s).map { it.groupValues[1] }.toList() }
    fun length() = parts.size
    fun getString(i: Int) = parts[i]
    override fun toString() = parts.joinToString(prefix = "[", postfix = "]") { "\"$it\"" }
}
