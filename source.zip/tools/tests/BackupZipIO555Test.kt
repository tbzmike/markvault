package com.tebogo.markvault.data

import java.io.ByteArrayInputStream
import java.io.ByteArrayOutputStream
import java.io.File
import java.io.InputStream
import java.security.MessageDigest
import java.util.zip.Deflater
import java.util.zip.ZipEntry
import java.util.zip.ZipFile
import java.util.zip.ZipOutputStream

fun main() {
    val payload = ByteArray(2 * 1024 * 1024) { ((it * 37) xor (it ushr 5)).toByte() }
    val digest = MessageDigest.getInstance("SHA-256").digest(payload)
    val expected = digest.joinToString("") { "%02x".format(it) }
    check(BackupZipIO.hex(digest) == expected)
    check(BackupZipIO.hex(ByteArray(256) { it.toByte() }) == (0..255).joinToString("") { "%02x".format(it) })
    val bytes = ByteArrayOutputStream()
    var copied = 0L
    BackupZipIO.copy(ByteArrayInputStream(payload), bytes, ByteArray(8192)) { copied += it }
    check(copied == payload.size.toLong() && bytes.toByteArray().contentEquals(payload))
    check(BackupZipIO.checked(ByteArrayInputStream(payload), expected) { it.readBytes() }.contentEquals(payload))
    check(runCatching { BackupZipIO.checked(ByteArrayInputStream(payload), "0".repeat(64)) { it.readBytes() } }.isFailure)
    // Partial consumer reads: all bytes still hashed and verified once.
    check(BackupZipIO.checked(ByteArrayInputStream(payload), expected) { it.read() } == (payload[0].toInt() and 255))
    // Progress remains bound to this stage's files and bytes, not the prior database rows.
    val reports = mutableListOf<Triple<Long,Long,Int>>()
    val stage = BackupZipIO.Stage("Library", 57, 82, 2, 2048) { _, done, total, percent -> reports += Triple(done,total,percent) }
    stage.report(true); stage.bytes(1024); stage.item(); stage.report(true); stage.bytes(1024); stage.item(); stage.report(true)
    check(reports.first() == Triple(0L,2L,57) && Triple(1L,2L,69) in reports && reports.last() == Triple(2L,2L,82))
    check(BackupZipIO.percent(24,48,30_000,60_000)==36)
    check(BackupZipIO.percent(94,99,Long.MAX_VALUE/2,Long.MAX_VALUE)==96)
    // 65,540 total members forces ZIP64 entry-count handling on OpenJDK.
    val file = File.createTempFile("mv555-zip64", ".zip")
    try {
        ZipOutputStream(file.outputStream().buffered()).use { zip ->
            zip.setLevel(Deflater.BEST_COMPRESSION)
            zip.putNextEntry(ZipEntry("database/large.bin")); zip.write(payload); zip.closeEntry()
            repeat(65537) { index ->
                zip.putNextEntry(ZipEntry("library/files/f${index}.md")); zip.write("# $index\n".toByteArray()); zip.closeEntry()
            }
            zip.putNextEntry(ZipEntry("settings/settings.preferences_pb")); zip.write(byteArrayOf(1,2,3)); zip.closeEntry()
            zip.putNextEntry(ZipEntry("manifest.json")); zip.write("{}".toByteArray()); zip.closeEntry()
        }
        val selected = setOf("database/large.bin", "settings/settings.preferences_pb")
        val results = linkedMapOf<String,ByteArray>()
        ZipFile(file).use { zip ->
            check(zip.size() == 65540)
            BackupZipIO.visitSeekable(zip, { it.name in selected }) { entry,input -> results[entry.name] = input.readBytes() }
        }
        check(results.keys == selected && results["database/large.bin"]!!.contentEquals(payload))
        check(results["settings/settings.preferences_pb"]!!.contentEquals(byteArrayOf(1,2,3)))
        val streamed = linkedMapOf<String,ByteArray>()
        file.inputStream().use { raw -> BackupZipIO.visitStreaming(raw, { it.name in selected }) { entry,input -> streamed[entry.name] = input.readBytes() } }
        check(streamed.keys == results.keys && streamed.all { (key,value) -> value.contentEquals(results[key]!!) })
        var callbacks = 0
        ZipFile(file).use { zip ->
            check(runCatching { BackupZipIO.visitSeekable(zip, { it.name in selected }) { _, _ -> callbacks++; error("simulated destination failure") } }.isFailure)
        }
        check(callbacks == 1)
        println("PASS: ZIP64 65540 entries, selective/streaming restoration, copied bytes and checksums identical, progress advances, failed consumer not retried")
    } finally { file.delete() }
}
