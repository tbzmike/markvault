"""Compile the actual ViewModel worker selection, memo and rerank helpers against their real engines."""
from pathlib import Path
import re
import sys

project, output = map(Path, sys.argv[1:])
source = (project / "app/src/main/java/com/tebogo/markvault/AppViewModel.kt").read_text()
def method(name):
    match = re.findall(r"^    private (?:suspend )?fun " + name + r"\([\s\S]*?^    \}(?:\.getOrDefault\(0\))?\n", source, re.M)
    assert len(match) == 1, name
    return match[0]

key = re.search(r"^    private data class RerankInferenceKey[^\n]*", source, re.M)[0]
memo = re.search(r"^    private val hnswRerankMemo[^\n]*", source, re.M)[0]
header = '''package com.tebogo.markvault.search
import android.app.Application
import kotlinx.coroutines.*
import kotlinx.coroutines.flow.MutableStateFlow
class BlueRerankVmFixture(val application: Application) {
    private val embedder = object { val descriptor = ModelCatalog.BGE_BASE_EN_V15 }
    val reranker = Reranker(application)
    val blueRerankEngine = BlueRerankEngine(application.filesDir)
    private val _rerankProgress = MutableStateFlow<Float?>(null)
    private fun usedHeapBytes() = 100L * 1024 * 1024
    @Suppress("UNCHECKED_CAST") private fun <T> getApplication(): T = application as T
'''
body = key + "\n" + memo + "\n" + method("blueRerankWorkerCount") + method("inferenceFilesRevision")
body += method("scoreBlueRerankDocuments").replace("private suspend fun", "suspend fun", 1)
(output / "BlueRerankVmFixture.kt").write_text(header + body + "}\n")
(output / "VmContext.kt").write_text('''package android.content
import java.io.File
open class Context(val filesDir: File) {
    val applicationContext: Context get() = this
    open fun getSystemService(name: String): Any? = null
    companion object { const val ACTIVITY_SERVICE = "activity" }
}
''')
(output / "VmApplication.kt").write_text('''package android.app
import android.content.Context
import java.io.File
class ActivityManager {
    var isLowRamDevice = false
    var availableBytes = 4096L * 1024 * 1024
    var lowMemory = false
    class MemoryInfo { var availMem = 0L; var lowMemory = false }
    fun getMemoryInfo(info: MemoryInfo) { info.availMem = availableBytes; info.lowMemory = lowMemory }
}
class Application(dir: File) : Context(dir) {
    val activity = ActivityManager()
    override fun getSystemService(name: String): Any? = activity
}
''')
(output / "VmLog.kt").write_text('''package android.util
object Log { fun i(tag: String, message: String): Int { println("$tag: $message"); return 0 } }
''')
(output / "VmClock.kt").write_text('''package android.os
object SystemClock { fun elapsedRealtime(): Long = System.nanoTime() / 1_000_000L }
''')
