"""Model-isolation, sync gating, command wiring and deletion safety smoke tests."""
from pathlib import Path
import sqlite3, re
root=Path(__file__).resolve().parents[2]
s=lambda p:(root/'app/src/main/java/com/tebogo/markvault'/p).read_text()
service=s('search/EmbeddingService.kt')
prefs=s('data/Prefs.kt')
vm=s('AppViewModel.kt')
ui=s('ui/SettingsScreen.kt')
db=s('data/Db.kt')
media=s('data/MediaItem.kt')
bus=s('search/EmbeddingProgressBus.kt')
# This is a persistent user setting; default is all enabled (backward compatible).
assert 'disabled_embedding_models_v1' in prefs
assert 'disabledEmbeddingModels: Flow<Set<String>>' in prefs
assert 'setEmbeddingModelDisabled(id: String, disabled: Boolean)' in prefs
assert '.filter { it.enabled && it.id !in disabledModels }' in service
assert 'if (descriptor.id in prefs.disabledEmbeddingModels.first()) break' in service
assert 'if (descriptor.id in prefs.disabledEmbeddingModels.first()) continue' in service
assert service.index('if (descriptor.id in prefs.disabledEmbeddingModels.first()) break',service.index('for ((chunkIdx')) < service.index('dao.replaceNoteEmbeddings(')
assert 'ACTION_MODEL_SETTINGS_CHANGED' in service and 'old.cancel()' in service and 'old.join()' in service
assert 'ACTION_MODEL_SETTINGS_CHANGED' in vm
assert 'if (!target.enabled || id in disabledEmbeddingModels.value) return' in vm
assert 'if (id in prefs.disabledEmbeddingModels.first()) return@launch' in vm
assert 'isClickable = model.enabled && !isActive && !userDisabled' in ui
assert 'Switch(checked = !userDisabled' in ui
# Both notification and settings control the foreground worker.
for action in ('ACTION_PAUSE','ACTION_RESUME','ACTION_STOP','ACTION_DELETE_MODEL'):
 assert action in service
 assert action in vm or action in ('ACTION_PAUSE','ACTION_RESUME','ACTION_STOP')
for op in ('awaitUnpaused()', 'releaseWakeLock()', 'acquireWakeLock()', 'cancel()', 'old?.join()'):
 assert op in service
assert 'builder.addAction(primaryIcon' in service
assert 'builder.addAction(android.R.drawable.ic_menu_close_clear_cancel' in service
assert 'EmbeddingProgressBus.pause(' in service
assert 'modelId?.let { ModelCatalog.byId(it) }' in service
assert service.index('old?.join() // never delete') < service.index('deleteSelectedModel(descriptor)',service.index('old?.join() // never delete'))
assert 'check(prefs.activeModelId.first() != descriptor.id)' in service
assert 'ann.delete(modelVersion)' in service and 'hnsw.delete(modelVersion)' in service
assert 'otherModelFiles' in service and 'check(name !in otherModelFiles)' in service
assert 'clearAllEmbeddings()' not in service and 'clearAllMediaEmbeddings()' not in service
assert 'deleteModelEmbeddings(descriptor.id)' in service and 'deleteModelMediaEmbeddings(descriptor.id)' in service
assert 'Delete this model' in ui and 'pendingModelDeletion' in ui
assert 'val operationStatus: StateFlow' in bus
# SQLite modelVersion SQL (including legacy generation tags) only deletes selected rows.
def statement(src, fun):
 m = re.search(r'@Query\("(DELETE FROM [^"\\]+)"\)\s*suspend fun '+fun+r'\(', src)
 assert m,fun
 return m.group(1)
con=sqlite3.connect(':memory:')
con.execute('CREATE TABLE note_embeddings (noteId INTEGER, modelVersion TEXT, vector BLOB)')
con.execute('CREATE TABLE media_embeddings (mediaId INTEGER, modelVersion TEXT, vector BLOB)')
owner='onnx-bge-base-en-v15'
other=('onnx-minilm-l6-v2','onnx-bge-large-en-v15','mediapipe-use-lite-v1','onnx-bge-base-en-v15x')
for tbl, idcol in (('note_embeddings','noteId'),('media_embeddings','mediaId')):
 for i,model in enumerate((owner,)+other):
  for suffix in ('','::chunked-v1','::tok512'):
   con.execute(f'INSERT INTO {tbl} VALUES (?,?,?)',(i,model+suffix,b'data'))
 con.execute(statement(db if tbl=='note_embeddings' else media, 'deleteModelEmbeddings' if tbl=='note_embeddings' else 'deleteModelMediaEmbeddings'),{'modelId':owner})
 remaining=[x[0] for x in con.execute(f'SELECT modelVersion FROM {tbl}').fetchall()]
 assert len(remaining)==len(other)*3,(tbl,remaining)
 assert all(x not in (owner,owner+'::chunked-v1',owner+'::tok512') for x in remaining)
print('PASS: disabled model excluded from sync and selection, independent model deletion, service notification and settings controls, scoped article/media SQL (30 vectors checked)')
