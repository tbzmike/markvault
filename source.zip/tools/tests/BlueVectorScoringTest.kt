package com.tebogo.markvault.search

import android.database.Cursor
import com.tebogo.markvault.data.EmbeddingVectorProjection
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.CoroutineStart
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.launch
import kotlinx.coroutines.runBlocking
import java.nio.ByteBuffer
import java.nio.ByteOrder
import java.lang.ref.WeakReference

data class VectorFixtureRow(val model: String, val noteId: Long, val vector: ByteArray)

class VectorFixtureCursor(
    private val rows: List<VectorFixtureRow>, private val owner: VectorFixtureDao
) : Cursor {
    private var position = -1
    var closed = false
    override fun getColumnIndexOrThrow(name: String): Int {
        if (owner.badColumns) throw IllegalArgumentException("fixture missing column")
        return when (name) { "noteId" -> 0; "vector" -> 1; else -> error(name) }
    }
    override fun moveToNext(): Boolean {
        check(!closed)
        position++
        if (owner.trackRetention && position % 127 == 0) {
            System.gc()
            owner.maxLiveCopies = maxOf(owner.maxLiveCopies, owner.copies.count { it.get() != null })
        }
        if (position == owner.failAt) throw IllegalStateException("fixture cursor failed after a completed batch")
        if (position == owner.cancelAt) throw CancellationException("fixture cancelled after a completed batch")
        return position < rows.size
    }
    override fun getBlob(column: Int): ByteArray {
        check(column == 1 && !closed)
        owner.reads++
        owner.onRead?.invoke(owner.reads)
        return rows[position].vector.copyOf().also {
            if (owner.trackRetention) owner.copies += WeakReference(it)
        }
    }
    override fun getLong(column: Int): Long { check(column == 0 && !closed); return rows[position].noteId }
    override fun close() { closed = true }
}

class VectorFixtureDao(val rows: List<VectorFixtureRow>) {
    var projectionCalls = 0
    var cursorCalls = 0
    var reads = 0
    var failAt = -1
    var cancelAt = -1
    var badColumns = false
    var trackRetention = false
    var maxLiveCopies = 0
    var onRead: ((Int) -> Unit)? = null
    val copies = ArrayList<WeakReference<ByteArray>>()
    val cursors = ArrayList<VectorFixtureCursor>()
    val pageSizes = ArrayList<Int>()
    private fun selected(model: String, noteIds: List<Long>): List<VectorFixtureRow> {
        check(noteIds.size <= 900)
        val ids = noteIds.toSet()
        return rows.filter { it.model == model && it.noteId in ids }
    }
    suspend fun loadEmbeddingVectorsForNotes(modelVersion: String, noteIds: List<Long>): List<EmbeddingVectorProjection> {
        projectionCalls++; pageSizes += noteIds.size
        return selected(modelVersion, noteIds).map { EmbeddingVectorProjection(it.noteId, it.vector.copyOf()) }
    }
    fun loadEmbeddingVectorCursorForNotes(modelVersion: String, noteIds: List<Long>): Cursor {
        cursorCalls++; pageSizes += noteIds.size
        return VectorFixtureCursor(selected(modelVersion, noteIds), this).also { cursors += it }
    }
}

private fun vectorBlob(vararg values: Float): ByteArray = ByteBuffer.allocate(values.size * 4)
    .order(ByteOrder.LITTLE_ENDIAN).also { b -> values.forEach { b.putFloat(it) } }.array()

private fun scalarDot(query: FloatArray, blob: ByteArray): Float {
    val buffer = ByteBuffer.wrap(blob).order(ByteOrder.LITTLE_ENDIAN)
    var score = 0f
    for (q in query) score += q * buffer.float
    return score.coerceIn(-1f, 1f)
}

private fun sameScores(actual: List<Pair<Long, Float>>, expected: List<Pair<Long, Float>>) {
    check(actual.map { it.first } == expected.map { it.first }) { "Candidate order changed" }
    check(actual.size == expected.size)
    for (i in actual.indices) check(actual[i].second.toRawBits() == expected[i].second.toRawBits() ||
        actual[i].second.isNaN() && expected[i].second.isNaN()) { "Score changed at $i" }
}

fun main(args: Array<String>) = runBlocking {
    val fallback = args.firstOrNull() == "fallback"
    check(NativeHnswBridge.available != fallback)
    val query = floatArrayOf(1f, 0f, -.5f, .25f)
    val ids = (0 until 1100).map { 1L + it * 4096L } // Deliberate HashMap bucket collisions and tied scores.
    val rows = ids.flatMapIndexed { index, id -> listOf(
        VectorFixtureRow("model", id, vectorBlob((index % 13) * .01f, .2f, -.1f, .3f)),
        VectorFixtureRow("model", id, vectorBlob(.125f, 0f, 0f, 0f))
    ) } + listOf(
        VectorFixtureRow("model", ids[0], vectorBlob(Float.NaN, 0f, 0f, 0f)),
        VectorFixtureRow("model", ids[1], vectorBlob(99f, 0f, 0f, 0f)),
        VectorFixtureRow("model", ids[2], ByteArray(3)),
        VectorFixtureRow("other-model", ids[3], vectorBlob(99f, 0f, 0f, 0f))
    )
    for (blue in listOf(false, true)) for (top in listOf(1, 200, 1200)) {
        val oldDao = VectorFixtureDao(rows)
        val newDao = VectorFixtureDao(rows)
        val oldVm = BlueVectorVmFixture(oldDao).also { it.hnswSearchEnabled.value = blue }
        val newVm = BlueVectorVmFixture(newDao).also { it.hnswSearchEnabled.value = blue }
        sameScores(newVm.semanticRerankCandidates(query, ids, top, "model"),
            oldVm.legacySemanticRerankCandidates(query, ids, top, "model"))
        check(newDao.pageSizes == listOf(900, 200))
        if (blue) {
            check(newDao.cursorCalls == 2 && newDao.projectionCalls == 0)
            check(newDao.cursors.all { it.closed })
        } else check(newDao.cursorCalls == 0 && newDao.projectionCalls == 2)
    }
    // Trace captures the engine even when the next search toggle has changed.
    val traceDao = VectorFixtureDao(rows)
    val traced = BlueVectorVmFixture(traceDao).also {
        it.hnswSearchEnabled.value = false; it.activeSearchTrace = BlueVectorVmFixture.Trace(true)
    }
    traced.semanticRerankCandidates(query, ids, 200, "model")
    check(traceDao.cursorCalls == 2 && traceDao.projectionCalls == 0)

    for (failure in listOf("late", "columns")) {
        val badDao = VectorFixtureDao(rows).also { if (failure == "late") it.failAt = 129 else it.badColumns = true }
        val vm = BlueVectorVmFixture(badDao)
        sameScores(vm.semanticRerankCandidates(query, ids, 1200, "model"),
            BlueVectorVmFixture(VectorFixtureDao(rows)).legacySemanticRerankCandidates(query, ids, 1200, "model"))
        check(badDao.projectionCalls == 2 && badDao.cursors.all { it.closed })
    }
    val cancelledDao = VectorFixtureDao(rows).also { it.cancelAt = 129 }
    var cancelled = false
    try { BlueVectorVmFixture(cancelledDao).semanticRerankCandidates(query, ids, 200, "model") }
    catch (_: CancellationException) { cancelled = true }
    check(cancelled && cancelledDao.projectionCalls == 0 && cancelledDao.cursors.single().closed)

    for (initialStop in listOf(true, false)) {
        val newDao = VectorFixtureDao(rows)
        val oldDao = VectorFixtureDao(rows)
        val newVm = BlueVectorVmFixture(newDao).also { it.stopped = { initialStop || newDao.reads >= 129 } }
        val oldVm = BlueVectorVmFixture(oldDao).also { it.stopped = { initialStop || oldDao.projectionCalls > 0 } }
        sameScores(newVm.semanticRerankCandidates(query, ids, 1200, "model"),
            oldVm.legacySemanticRerankCandidates(query, ids, 1200, "model"))
        check(newDao.cursorCalls == 1 && newDao.projectionCalls == 0)
        check(newDao.cursors.single().closed)
    }
    val prior = linkedMapOf(ids[0] to Float.NaN, ids[1] to .8f)
    val priorBits = prior.mapValues { it.value.toRawBits() }
    val directDao = VectorFixtureDao(rows)
    var scalarCalls = 0
    val streamed = BlueVectorScoring.score(query,
        { directDao.loadEmbeddingVectorCursorForNotes("model", ids.take(900)) }, prior) {
        scalarCalls++; scalarDot(query, it)
    }
    val expected = LinkedHashMap(prior)
    for (row in rows.filter { it.model == "model" && it.noteId in ids.take(900) }) {
        if (row.vector.size != query.size * 4) continue
        val score = scalarDot(query, row.vector)
        val old = expected[row.noteId]
        if (old == null || score > old) expected[row.noteId] = score
    }
    sameScores(streamed.entries.map { it.key to it.value }, expected.entries.map { it.key to it.value })
    check(prior.mapValues { it.value.toRawBits() } == priorBits)
    check(if (fallback) scalarCalls > 0 else scalarCalls == 0)
    val failedDirect = VectorFixtureDao(rows).also { it.failAt = 129 }
    try { BlueVectorScoring.score(query, { failedDirect.loadEmbeddingVectorCursorForNotes("model", ids.take(900)) }, prior) {
        scalarDot(query, it)
    }; error("Expected fixture failure") } catch (_: IllegalStateException) { }
    check(prior.mapValues { it.value.toRawBits() } == priorBits && failedDirect.cursors.single().closed)
    coroutineScope {
        val jobDao = VectorFixtureDao(rows)
        val job = launch(start = CoroutineStart.LAZY) {
            BlueVectorScoring.score(query,
                { jobDao.loadEmbeddingVectorCursorForNotes("model", ids.take(900)) }, prior) {
                scalarDot(query, it)
            }
            error("Cancelled scoring published a result")
        }
        jobDao.onRead = { if (it == 129) job.cancel() }
        job.start(); job.join()
        check(job.isCancelled && jobDao.cursors.single().closed)
        check(prior.mapValues { it.value.toRawBits() } == priorBits)
    }

    val emptyDao = VectorFixtureDao(rows)
    val emptyVm = BlueVectorVmFixture(emptyDao)
    check(emptyVm.semanticRerankCandidates(query, emptyList(), 200, "model").isEmpty())
    check(emptyVm.semanticRerankCandidates(floatArrayOf(), ids, 200, "model").isEmpty())
    check(emptyDao.cursorCalls == 0 && emptyDao.projectionCalls == 0)
    check(emptyVm.semanticRerankCandidates(query, ids, 200, "missing-model").isEmpty())
    check(emptyDao.cursors.all { it.closed })
    // GC is a host test probe only: verify the actual production reader releases
    // batches rather than accumulating a 4500-passage BGE page in managed memory.
    val largeQuery = FloatArray(768) { 1f / 768 }
    val largeBlob = vectorBlob(*FloatArray(768) { .25f })
    val largeRows = (0 until 4500).map { VectorFixtureRow("model", (it / 5).toLong(), largeBlob) }
    val largeIds = (0L until 900L).toList()
    val retentionDao = VectorFixtureDao(largeRows).also { it.trackRetention = true }
    BlueVectorScoring.score(largeQuery,
        { retentionDao.loadEmbeddingVectorCursorForNotes("model", largeIds) }, emptyMap()) {
        scalarDot(largeQuery, it)
    }
    check(retentionDao.reads == 4500 && retentionDao.maxLiveCopies in 1..129)
    check(retentionDao.cursors.single().closed)
    val oldCopies = VectorFixtureDao(largeRows).loadEmbeddingVectorsForNotes("model", largeIds)
    val oldRefs = oldCopies.map { WeakReference(it.vector) }
    System.gc()
    check(oldRefs.count { it.get() != null } == 4500)
    check(oldCopies.sumOf { it.vector.size } == 13_824_000)
    println("4500 x 768 cursor retention probe: old=4500 live BLOB copies, streamed<=${retentionDao.maxLiveCopies}; full scores and page retained=PASS")
    println("Actual ViewModel vs frozen 5.5.35: exact rankings/ties, 900-note Stop boundary, model isolation, cursor errors/cancellation/closure, unchanged IVF; native=${!fallback}=PASS")
}
