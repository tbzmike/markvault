package com.tebogo.markvault.search

import android.content.Context
import kotlinx.coroutines.*
import java.io.File
import java.nio.file.Files
import kotlin.math.abs

/** Runs the actual production engines and downloaded catalog models with ONNX Runtime 1.19.2. */
fun main(args: Array<String>) = runBlocking {
    val assets = File(args[0])
    val dir = Files.createTempDirectory("blue-rerank-models").toFile()
    val blue = BlueRerankEngine(dir)
    val old = Reranker(Context(dir))
    try {
        for ((model, descriptor) in listOf("l12" to RerankerCatalog.MS_MARCO_MINI_LM_L12, "l6" to RerankerCatalog.MS_MARCO_MINI_LM_L6)) {
            Files.createSymbolicLink(descriptor.modelFileIn(dir).toPath(), File(assets, "reranker-$model.onnx").toPath())
            Files.createSymbolicLink(descriptor.vocabFileIn(dir).toPath(), File(assets, "reranker-vocab.txt").toPath())
            old.setDescriptor(descriptor)
            for (query in listOf("who is the queen of sheba", "how many children did Adam and Eve have", "faith hope love", "école \u03b1\u03b2\u03b3 2026", "why?")) {
                val docs = List(30) { i -> when (i % 4) {
                    0 -> "The queen of Sheba visited Solomon. She came to test his wisdom. Article $i."
                    1 -> "Faith, hope, and love. Kindness is a quality that everyone can develop. Article $i."
                    2 -> ("Adam and Eve had sons and daughters. Cain and Abel are mentioned. " ).repeat(35) + "Article $i."
                    else -> "école \u03b1\u03b2\u03b3 中文. \u2028 A long journey: chapter $i?"
                } }
                val expected = docs.map { old.score(query, it) ?: error("Original model failed") }.toFloatArray()
                check(blue.prepare(descriptor, model, 4))
                val start = System.nanoTime()
                val actual = blue.scoreBatch(descriptor, model, 4, query, docs) ?: error("Blue model failed")
                val elapsed = (System.nanoTime() - start) / 1e6
                val difference = expected.indices.maxOf { abs(actual[it] - expected[it]) }
                check(difference <= 0.0001f) { "$model $query score difference $difference" }
                check(actual.indices.sortedByDescending { actual[it] } == expected.indices.sortedByDescending { expected[it] })
                println("Production $model query='$query' 30 pairs=${"%.2f".format(elapsed)}ms max_logit_diff=$difference exact_ranking=PASS")
            }
            val entered = CompletableDeferred<Unit>()
            val job = launch(Dispatchers.IO) {
                blue.scoreBatch(descriptor, model, 4, "test", List(500) { "A document about a test of faith." }) { entered.complete(Unit) }
            }
            entered.await()
            blue.unload() // While native sessions are in use; retirement waits until their owners finish.
            job.cancelAndJoin()
            check(blue.loadedWorkers == 0)
            check(blue.prepare(descriptor, "$model-new-revision", 2))
            check(blue.loadedWorkers == 2)
            val empty = blue.scoreBatch(descriptor, "$model-new-revision", 2, "test", listOf("", "faith"))!!
            check(empty[0].isNaN() && empty[1].isFinite())
            blue.unload()
            println("Production $model cancellation, in-flight unload, revision reload, empty input=PASS")
        }
        val missing = RerankerCatalog.default.copy(modelFilename = "missing.onnx")
        check(!blue.prepare(missing, "missing", 4))
        check(blue.scoreBatch(missing, "missing", 4, "test", listOf("faith")) == null)
        println("Production missing-model fallback=PASS")
    } finally {
        blue.unload(); old.unload()
        dir.listFiles()?.forEach { it.delete() }; dir.delete()
    }
}
