package com.tebogo.markvault.search

import com.tebogo.markvault.data.SearchHit
import kotlin.random.Random

fun main() {
    val queries = listOf("who is the queen of sheba", "how many children did Adam and Eve have", "total of branch offices", "", "faith love", "École 中文", "[a-z]+?", "the the", "queen's palace")
    val snippets = listOf("The queen of Sheba visited Solomon.", "Adam and Eve had sons and daughters.", "The Bible does not say how many children.", "1. A paragraph about faith. Love matters!", "Seven branch offices were opened.", "École 中文.\nText!", " ", "200k chunks in 42k notes?")
    val random = Random(528)
    var windows = 0
    for (query in queries) {
        val prepared = BluePassages(query, informativeQueryTerms(query), isCountIntent(query)) { countAnswerStrength(query, it) }
        repeat(70) {
            val passage = List(random.nextInt(0, 24)) { snippets.random(random) }.joinToString(if (it % 2 == 0) "\n\n" else " ")
            check(prepared.select(passage) == selectCoherentRerankPassage(query, passage)) { "$query passage differs" }
            windows++
        }
        val hits = List(500) { i -> SearchHit(i.toLong(), "path/$i.md", snippets.random(random), snippets.random(random).replace("queen", "⟦queen⟧"), "md") }
        check(BlueKeywordRanking.rank(hits, query) == originalKeywordRanking(hits, query)) { "$query keyword ranking differs" }
    }
    val prepared = BluePassages("test", emptyList(), false) { 1f }
    var chunks = 0
    for (length in listOf(0, 1, 29, 30, 349, 350, 351, 629, 630, 631, 910, 911, 2000, 10_000)) {
        val text = List(length) { i -> "word$i" + if (i % 2 == 0) "." else "?" }.joinToString("\t\r\n ")
        val original = buildOverlappingChunks(text, 350, 70, 30)
        for (index in -1..original.size + 2) {
            val expected = original.getOrNull(index)?.text ?: text
            check(prepared.chunkOrContent(text, index) == expected) { "$length words index $index differs" }
            chunks++
        }
    }
    println("Frozen 5.5.24 differential: $windows coherent passages, ${queries.size * 500} keyword hits, $chunks chunk selections=PASS")
}
