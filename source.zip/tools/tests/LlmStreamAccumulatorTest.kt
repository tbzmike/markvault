import com.tebogo.markvault.llm.LlmStreamAccumulator

private fun parses(text: String): List<String> = text.lines()
    .map { it.trim() }.filter { it.isNotBlank() && !it.startsWith("Intro:") }
    .distinct()

fun main() {
    // Immediate early termination after all three COMPLETE validated lines.
    val full = LlmStreamAccumulator(3, ::parses)
    check(full.appendAndContinue("Intro:\nAbraham and faith\n"))
    check(full.appendAndContinue("God and promises\n"))
    check(!full.appendAndContinue("Jehovah and covenant\nExtra line that must not be needed\n"))
    check(full.results(completedNormally = true).size >= 3)

    // Timeout keeps only completed lines, never a half-written query.
    val partial = LlmStreamAccumulator(4, ::parses)
    check(partial.appendAndContinue("God promises\nJesus spoke abou"))
    check(partial.results(completedNormally = false) == listOf("God promises"))
    check(partial.results(completedNormally = true).size == 2)

    // Repeated variants do not satisfy the requested target.
    val dedupe = LlmStreamAccumulator(2, ::parses)
    check(dedupe.appendAndContinue("Kingdom rule\nKingdom rule\n"))
    check(!dedupe.appendAndContinue("Future hope\n"))

    // A missing terminating newline still counts when generation ended normally.
    val eof = LlmStreamAccumulator(1, ::parses)
    check(eof.appendAndContinue("After resurrection"))
    check(eof.results(completedNormally = false).isEmpty())
    check(eof.results(completedNormally = true) == listOf("After resurrection"))

    // Oversize stream is bounded and stops safely.
    val capped = LlmStreamAccumulator(3, ::parses, maxOutputChars = 8)
    check(!capped.appendAndContinue("abcdefghi"))
    println("LlmStreamAccumulator: 5 regression scenarios PASS")
}
