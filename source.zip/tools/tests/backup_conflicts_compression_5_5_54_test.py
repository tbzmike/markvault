#!/usr/bin/env python3
"""Guard source wiring and run normal ZIP round-trip at max compression."""
from pathlib import Path
import subprocess, shutil
root = Path(__file__).resolve().parents[2]
data = root/'app/src/main/java/com/tebogo/markvault/data'
backup = (data/'BackupManager.kt').read_text()
files = (data/'PortableBackupFiles.kt').read_text()
ui = (root/'app/src/main/java/com/tebogo/markvault/ui/SettingsScreen.kt').read_text()
build=(root/'app/build.gradle.kts').read_text()
assert 'versionCode = 503' in build and 'versionName = "5.5.54"' in build
assert 'zip.setLevel(Deflater.BEST_COMPRESSION)' in backup and 'zip.setLevel(Deflater.BEST_SPEED)' not in backup
assert 'FORMAT_VERSION = 7' in backup
assert 'val verified = validateV4Archive(ctx, srcUri)' in backup
assert 'restored.documentIds.mapValues' in backup and 'byId[documentId]' in backup
assert 'current!!.relPath else relPath' in backup
assert 'matches(current, expected, path)' in files and 'conflictPath(path, expected)' in files
assert '.markvault-restore-conflicts' in files and 'DocumentsContract.deleteDocument' in files
assert 'maximum standard ZIP compression (lossless)' in ui
assert 'CoroutineScope(' not in files and 'WorkManager' not in files
if not shutil.which('java'): raise RuntimeError('Java runtime required')
subprocess.run(['java',str(root/'tools/tests/BackupCompression554Test.java')],check=True,timeout=30)
print('PASS production wiring, unchanged v7 format, conflict mapping, max compression and no new worker')
