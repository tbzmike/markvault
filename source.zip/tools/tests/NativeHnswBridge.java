package com.tebogo.markvault.search;

import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.Arrays;

// Host-only JNI integration test; mirrors the instance methods of the Kotlin object.
public final class NativeHnswBridge {
    static float[] vector(long i) {
        return new float[]{(float)Math.cos(i * 0.01), (float)Math.sin(i * 0.01),
            (float)Math.cos(i * 0.013), (float)Math.sin(i * 0.013)};
    }
    static byte[] blob(float[] vector) {
        var buffer = ByteBuffer.allocate(vector.length * 4).order(ByteOrder.LITTLE_ENDIAN);
        for (float v : vector) buffer.putFloat(v);
        return buffer.array();
    }
    native long create(int dimension, int capacity, boolean mutableIndex);
    native void close(long handle);
    native void open(long handle, String path, long offset, boolean mutableIndex);
    native void reserve(long handle, int capacity);
    native void add(long handle, long key, byte[] blob);
    native void remove(long handle, long key);
    native long size(long handle);
    native long serializedLength(long handle);
    native void append(long handle, String path);
    native long[] keys(long handle);
    native long[] search(long handle, float[] query, int wanted, long[] allowed);
    native long[] findArticles(long handle, float[] query, int wanted, int minimum, long[] allowed);
    native float[] scoreVectors(float[] query, byte[][] vectors);

    public static void main(String[] args) throws Exception {
        System.load(args[0]);
        var bridge = new NativeHnswBridge();
        if (bridge.scoreVectors(new float[]{1,0,0,0}, new byte[0][]).length != 0)
            throw new AssertionError("Empty exact score batch");
        var scores = bridge.scoreVectors(new float[]{1,0,0,0}, new byte[][]{blob(new float[]{2,0,0,0}), new byte[3], null, blob(new float[]{-2,0,0,0})});
        if (scores.length != 4 || scores[0] != 1 || !Float.isNaN(scores[1]) || !Float.isNaN(scores[2]) || scores[3] != -1)
            throw new AssertionError("Exact score clamp/invalid rows");
        int scoreComparisons = 0;
        for (int dim : new int[]{1,3,4,7,103,128,256,384,512,768,1024,2048}) {
            var query = new float[dim];
            for (int d = 0; d < dim; d++) query[d] = (float)Math.sin(d * .13) / dim;
            var batch = new byte[131][];
            var expected = new float[batch.length];
            for (int i = 0; i < batch.length; i++) {
                var row = new float[dim];
                float sum = 0;
                for (int d = 0; d < dim; d++) {
                    row[d] = (float)Math.cos((i+1) * (d+1) * .019);
                    sum += query[d] * row[d];
                }
                batch[i] = blob(row);
                expected[i] = Math.max(-1f, Math.min(1f, sum));
                if (i % 17 == 0) { batch[i] = null; expected[i] = Float.NaN; }
                else if (i % 19 == 0) { batch[i] = new byte[3]; expected[i] = Float.NaN; }
                else if (i % 23 == 0) { row[dim/2] = Float.NaN; batch[i] = blob(row); expected[i] = Float.NaN; }
            }
            var actual = bridge.scoreVectors(query, batch);
            if (actual.length != expected.length) throw new AssertionError("Exact batch size changed");
            for (int i = 0; i < expected.length; i++) {
                if (Float.floatToRawIntBits(actual[i]) != Float.floatToRawIntBits(expected[i]) &&
                        !(Float.isNaN(actual[i]) && Float.isNaN(expected[i])))
                    throw new AssertionError("Batched JNI score changed at dimension " + dim + " row " + i);
                scoreComparisons++;
            }
        }
        System.out.println("JNI grouped/tail/invalid FP32 scores: " + scoreComparisons + " = PASS");
        for (float[] invalid : new float[][]{new float[0], new float[2049], new float[]{Float.NaN}, new float[]{Float.POSITIVE_INFINITY}}) {
            boolean rejectedQuery = false;
            try { bridge.scoreVectors(invalid, new byte[0][]); } catch (IllegalStateException e) { rejectedQuery = true; }
            if (!rejectedQuery) throw new AssertionError("Invalid exact query accepted");
        }
        var path = Files.createTempFile("markvault_jni_", ".bin");
        long handle = bridge.create(4, 1000, true), view = 0, mutable = 0;
        try {
            byte[] blob = blob(vector(1001));
            for (long i = 1; i <= 1000; i++) bridge.add(handle, i << 32, blob(vector(i)));
            if (bridge.size(handle) != 1000 || bridge.keys(handle).length != 1000) throw new AssertionError("JNI count");
            boolean rejected = false;
            try { bridge.add(handle, 1001L << 32, new byte[8]); } catch (IllegalStateException e) { rejected = true; }
            if (!rejected) throw new AssertionError("Invalid BLOB accepted");
            long offset = 73;
            Files.write(path, new byte[(int)offset]);
            bridge.append(handle, path.toString());
            if (Files.size(path) != offset + bridge.serializedLength(handle)) throw new AssertionError("JNI length");
            view = bridge.create(4, 0, false);
            bridge.open(view, path.toString(), offset, false);
            var found = bridge.search(view, vector(501), 200, new long[]{501, 502, 503});
            if (found.length != 3 || Arrays.stream(found).anyMatch(k -> (k >>> 32) < 501 || (k >>> 32) > 503))
                throw new AssertionError("JNI scope");
            if (bridge.search(view, new float[]{1,0,0,0}, 10, new long[0]).length != 0) throw new AssertionError("Empty JNI scope");
            var packet = bridge.findArticles(view, vector(501), 600, 200, new long[]{503,501,502});
            if (packet.length != 12 || packet[0] != 4 || packet[1] != 1 || packet[2] != 1000 || packet[3] < 3 ||
                    packet[4] <= 0 || packet[5] <= 0 || packet[6] <= 0 || packet[6] > packet[4] || packet[7] != 8 || packet[8] < 0 || packet[8] > 3 || packet[9] != 501 || Arrays.stream(packet, 9, packet.length).anyMatch(k -> k < 501 || k > 503))
                throw new AssertionError("JNI article packet/recovery/scope");
            var emptyPacket = bridge.findArticles(view, vector(501), 600, 200, new long[0]);
            if (!Arrays.equals(emptyPacket, new long[]{4,1,0,0,0,0,0,8,packet[8]})) throw new AssertionError("Empty article packet");
            rejected = false;
            try { bridge.findArticles(view, new float[]{1}, 600, 200, null); } catch (IllegalStateException e) { rejected = true; }
            if (!rejected) throw new AssertionError("Query dimension accepted");
            mutable = bridge.create(4, 0, true);
            bridge.open(mutable, path.toString(), offset, true);
            bridge.remove(mutable, 501L << 32);
            bridge.reserve(mutable, 1100);
            bridge.add(mutable, 1001L << 32, blob);
            if (bridge.size(mutable) != 1000) throw new AssertionError("JNI delta");
            System.out.println("JNI create/add/map/filter/update/error checks=PASS");
        } finally {
            if (mutable != 0) bridge.close(mutable);
            if (view != 0) bridge.close(view);
            bridge.close(handle); Files.deleteIfExists(path);
        }
    }
}
