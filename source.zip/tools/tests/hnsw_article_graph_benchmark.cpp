#include "hnsw_core.hpp"
#include "reference/hnsw_v37.hpp"
#include <chrono>
#include <filesystem>
#include <fstream>
#include <iostream>
#include <random>
#include <set>

using Clock=std::chrono::steady_clock;
double ms(Clock::time_point start) {return std::chrono::duration<double,std::milli>(Clock::now()-start).count();}
void report(char const* label,std::vector<double> values) {
    std::sort(values.begin(),values.end());
    std::cout<<label<<" median_ms="<<values[values.size()/2]<<" p95_ms="<<values[(values.size()-1)*95/100]
             <<" min_ms="<<values.front()<<" max_ms="<<values.back()<<std::endl;
}
int main(int argc,char** argv) {
    auto articles=argc>1?std::stoull(argv[1]):4200,dim=argc>2?std::stoull(argv[2]):128;
    auto root=argc>3?std::string(argv[3]):"/tmp/markvault_sq8_benchmark";
    std::filesystem::create_directories(root);
    auto old_path=root+"/fp16.bin",new_path=root+"/sq8.bin";
    bool heterogeneous = argc>4 && std::string(argv[4])=="heterogeneous";
    bool single = argc>4 && std::string(argv[4])=="single";
    auto uniform = argc>4 && std::string(argv[4])=="two" ? 2 : argc>4 && std::string(argv[4])=="three" ? 3 : argc>4 && std::string(argv[4])=="four" ? 4 : 5;
    std::vector<std::size_t> offsets(articles+1);
    for(std::size_t n=0;n<articles;++n)
        offsets[n+1]=offsets[n]+(single ? 1 : heterogeneous ? std::array<std::size_t,5>{1,4,5,17,33}[n%5] : uniform);
    auto count=offsets.back(); auto split=articles*20/42;
    std::mt19937 rng(55126);std::normal_distribution<float> normal;
    std::vector<float> centers(128*dim),vectors(count*dim),prototype(dim);
    for(auto& v:centers)v=normal(rng);
    for(std::size_t n=0;n<articles;++n) {
        auto topic=n%64+(n>=split?64:0);
        for(std::size_t d=0;d<dim;++d)prototype[d]=centers[topic*dim+d]+.35f*normal(rng);
        for(std::size_t c=0;c<offsets[n+1]-offsets[n];++c) {
            auto v=vectors.data()+(offsets[n]+c)*dim;float norm=0;
            if(heterogeneous) {
                auto chunk_topic=(n*13+c*17)%128;
                for(std::size_t d=0;d<dim;++d)prototype[d]=centers[chunk_topic*dim+d]+.35f*normal(rng);
            }
            for(std::size_t d=0;d<dim;++d){v[d]=prototype[d]+.07f*normal(rng);norm+=v[d]*v[d];}
            for(std::size_t d=0;d<dim;++d)v[d]/=std::sqrt(norm);
        }
    }
    auto start=Clock::now();
    if(!std::filesystem::exists(old_path)) {
        markvault_v37::Hnsw build(dim,count);
        for(std::size_t n=0;n<articles;++n) {
            for(std::size_t c=0;c<offsets[n+1]-offsets[n];++c)build.add((std::uint64_t(n+1)<<32)|c,vectors.data()+(offsets[n]+c)*dim,dim);
            if((n+1)%5000==0)std::cout<<"built_articles="<<n+1<<" elapsed_ms="<<ms(start)<<std::endl;
        }
        {std::ofstream f(old_path,std::ios::binary);f.put('M');}build.append(old_path.c_str());
        std::cout<<"FP16 build_ms="<<ms(start)<<std::endl;
    }
    {
        markvault::Hnsw convert(dim,0,false,true);convert.open(old_path.c_str(),1,false);
        start=Clock::now();{std::ofstream f(new_path,std::ios::binary);f.put('M');}convert.append(new_path.c_str());
        std::cout<<"conversion_ms="<<ms(start)<<" vectors="<<count<<" dim="<<dim
                 <<" FP16_bytes="<<std::filesystem::file_size(old_path)<<" SQ8_bytes="<<std::filesystem::file_size(new_path)<<std::endl;
    }
    markvault_v37::Hnsw previous(dim,0,false,true);markvault::Hnsw current(dim,0,false,true);
    previous.open(new_path.c_str(),1,false);current.open(new_path.c_str(),1,false);
    std::vector<std::uint64_t> first,second,sparse{1,3,7},empty;
    for(std::size_t n=1;n<=articles;++n)(n<=split?first:second).push_back(n);
    std::vector<std::vector<float>> queries;
    for(std::size_t i=0;i<24;++i) {
        std::vector<float> q(dim);
        if(i<12)std::copy_n(vectors.data()+(offsets[(i*7919)%articles+1]-1)*dim,dim,q.data());
        else {float norm=0;for(auto& v:q){v=normal(rng);norm+=v*v;}for(auto& v:q)v/=std::sqrt(norm);}
        queries.push_back(std::move(q));
    }
    std::vector<double> old_all,new_all,old_cpu,new_cpu,old_scoped,new_scoped;
    std::uint64_t old_work=0,new_work=0; std::size_t overlay_bytes=0;
    double old_hits[3]{},new_hits[3]{};std::size_t trials=0,comparisons=0;
    for(auto const& q:queries) for(auto allowed:std::array<std::vector<std::uint64_t> const*,5>{nullptr,&first,&second,&sparse,&empty}) {
        std::vector<std::pair<float,std::uint64_t>> oracle;
        for(std::size_t n=0;n<articles;++n) {
            if(allowed&&!std::binary_search(allowed->begin(),allowed->end(),n+1))continue;
            float best=-1;
            for(std::size_t c=offsets[n];c<offsets[n+1];++c) {
                float dot=0;auto v=vectors.data()+c*dim;
                for(std::size_t d=0;d<dim;++d)dot+=q[d]*v[d];
                best=std::max(best,dot);
            }
            oracle.emplace_back(-best,n+1);
        }
        std::sort(oracle.begin(),oracle.end());
        for(int round=0;round<3;++round) {
            markvault_v37::Hnsw::ArticleCandidates before;markvault::Hnsw::ArticleCandidates after;
            auto old_run=[&]{before=previous.article_candidates(q.data(),dim,600,200,allowed);};
            auto new_run=[&]{after=current.article_candidates(q.data(),dim,600,200,allowed);};
            if(comparisons%2){new_run();old_run();}else{old_run();new_run();}
            ++comparisons; old_work+=before.scored; new_work+=after.scored; overlay_bytes=std::max(overlay_bytes,after.graph_memory_bytes);
            auto expected_beam=std::max<std::size_t>(600,(600*5*articles+count-1)/count);
            bool fallback=count/articles<4;
            if(after.articles.size()!=before.articles.size()||after.exhaustive!=before.exhaustive||after.scalar_bits!=8||
               (!allowed && (fallback ? after.article_graph || after.passages!=before.passages || after.articles!=before.articles
                : !after.article_graph || after.article_frontier!=expected_beam || after.passages!=0 || after.graph_memory_bytes==0)))
                throw std::runtime_error("Candidate breadth/coverage changed");
            if(fallback && (after.articles!=before.articles || after.passages!=before.passages || after.scored!=before.scored))
                throw std::runtime_error("Short-article passage behavior changed");
            for(auto id:after.articles)if(allowed&&!std::binary_search(allowed->begin(),allowed->end(),id))throw std::runtime_error("SQ8 scope leak");
            if(round&& !allowed){old_all.push_back(before.graph_ns/1e6);new_all.push_back(after.graph_ns/1e6);old_cpu.push_back(before.graph_cpu_ns/1e6);new_cpu.push_back(after.graph_cpu_ns/1e6);}
            else if(round&&allowed&&allowed->size()>10){old_scoped.push_back(before.graph_ns/1e6);new_scoped.push_back(after.graph_ns/1e6);}
            if(round==0&&!oracle.empty()&&(!allowed||allowed->size()>10)) {
                std::set<std::uint64_t> a(before.articles.begin(),before.articles.end()),b(after.articles.begin(),after.articles.end());
                int limits[]{10,50,200};
                for(int k=0;k<3;++k) {
                    auto limit=std::min<std::size_t>(limits[k],oracle.size());double oa=0,nb=0;
                    for(std::size_t i=0;i<limit;++i){oa+=a.count(oracle[i].second);nb+=b.count(oracle[i].second);}
                    old_hits[k]+=oa/limit;new_hits[k]+=nb/limit;
                    if(nb+.02*limit<oa) {
                        std::cerr<<"individual recall decrease trial="<<trials<<" scope="<<(allowed?allowed->size():articles)
                                 <<" k="<<limit<<" SQ8_hits="<<oa<<" article_hits="<<nb<<std::endl;
                    }
                }
                ++trials;
            }
        }
    }
    std::cout<<"heterogeneous="<<heterogeneous<<" vectors="<<count<<" overlay_bytes="<<overlay_bytes<<" measured_old="<<old_work<<" measured_new="<<new_work<<" comparisons="<<comparisons<<" recall_trials="<<trials<<" kernel="<<markvault::sq8::kernel()<<std::endl;
    // Quantized candidates need not be identical. Retain breadth and require mean
    // FP32-oracle recall to stay within 0.5 percentage points of the old graph,
    // reporting individual declines as well as aggregate gains.
    for(int k=0;k<3;++k) {
        std::cout<<"recall@"<<std::array<int,3>{10,50,200}[k]<<" passage_SQ8="<<old_hits[k]/trials<<" article_SQ8="<<new_hits[k]/trials<<std::endl;
        if(new_hits[k]/trials+.005<old_hits[k]/trials)
            throw std::runtime_error("Article graph mean candidate recall loses over 0.5 percentage points");
    }
    report("5.5.37 full graph",old_all);report("5.5.38 full graph",new_all);
    report("5.5.37 graph CPU",old_cpu);report("5.5.38 graph CPU",new_cpu);
    report("5.5.37 partition graph",old_scoped);report("5.5.38 partition graph",new_scoped);
    std::cout<<"FP32-oracle/article graph breadth/scope/recall checks PASS (synthetic host benchmark, not phone latency)"<<std::endl;
}
