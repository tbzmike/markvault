#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")/../.."
ROOT=app/src/main/java/com/tebogo/markvault
TMP=$(mktemp -d)
trap 'rm -rf "$TMP"' EXIT
kotlinc "$ROOT/data/BackupSelection.kt" "$ROOT/data/PortableBackupState.kt" "$ROOT/service/RestorePauseGate.kt" \
  tools/tests/stubs_551/{Db,SQLite,Support,PortableRoundTripTest}.kt tools/tests/RestoreResume557Test.kt \
  -include-runtime -d "$TMP/test.jar"
java -cp "$TMP/test.jar" RestoreResume557TestKt
java -cp "$TMP/test.jar" PortableRoundTripTestKt
