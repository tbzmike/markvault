"""Original feature guard with exact, reviewed UI/report changes normalized to 5.5.30."""
import hashlib
import json
from pathlib import Path

root = Path(__file__).resolve().parents[2]
manifest = json.loads((Path(__file__).parent / "preservation-5.5.24.json").read_text())


def digest(data):
    return hashlib.sha256(data).hexdigest()


ui_changes = json.loads((Path(__file__).parent / "ui-preservation-5.5.30.json").read_text())["files"]
hnsw_changes = json.loads((Path(__file__).parent / "hnsw-preservation-5.5.31.json").read_text())["files"]
kernel_changes = json.loads((Path(__file__).parent / "speed-preservation-5.5.33.json").read_text())["files"]

speed_changes = json.loads((Path(__file__).parent / "speed-preservation-5.5.32.json").read_text())["files"]
legacy_shared = (Path(__file__).parent / "LegacySharedBlueRerankEngine.kt").read_text().replace(
    "class LegacySharedBlueRerankEngine(", "class BlueRerankEngine(", 1)
assert digest(legacy_shared.encode()) == speed_changes[
    "app/src/main/java/com/tebogo/markvault/search/BlueRerankEngine.kt"]["baseline_sha256"], "5.5.32 rerank oracle drifted"
reference = (Path(__file__).parent / "reference/hnsw_v31.hpp").read_text()
reference = reference[reference.index("#pragma once"):].replace("namespace markvault_v31 {", "namespace markvault {", 1)
assert digest(reference.encode()) == hnsw_changes["app/src/main/cpp/hnsw_core.hpp"]["baseline_sha256"], "5.5.31 benchmark oracle drifted"


def preserved_bytes(name):
    data = (root / name).read_bytes()
    if name in kernel_changes:
        change = kernel_changes[name]
        assert digest(data) == change["reviewed_sha256"], f"Unreviewed 5.5.34 edit: {name}"
        for hunk in change["inverse_hunks"]:
            current, original = hunk["current"].encode(), hunk["original"].encode()
            assert data.count(current) == 1, f"Ambiguous kernel hunk: {name}"
            data = data.replace(current, original, 1)
        assert digest(data) == change["baseline_sha256"], f"Unrelated 5.5.33 bytes changed: {name}"
    if name in speed_changes:
        change = speed_changes[name]
        assert digest(data) == change["reviewed_sha256"], f"Unreviewed 5.5.33 edit: {name}"
        for hunk in change["inverse_hunks"]:
            current, original = hunk["current"].encode(), hunk["original"].encode()
            assert data.count(current) == 1, f"Ambiguous speed hunk: {name}"
            data = data.replace(current, original, 1)
        assert digest(data) == change["baseline_sha256"], f"Unrelated 5.5.32 bytes changed: {name}"
    if name in hnsw_changes:
        change = hnsw_changes[name]
        assert digest(data) == change["reviewed_sha256"], f"Unreviewed HNSW edit: {name}"
        for hunk in change["inverse_hunks"]:
            current, original = hunk["current"].encode(), hunk["original"].encode()
            assert data.count(current) == 1, f"Ambiguous HNSW hunk: {name}"
            data = data.replace(current, original, 1)
        assert digest(data) == change["baseline_sha256"], f"Unrelated 5.5.31 bytes changed: {name}"
    if name not in ui_changes:
        return data
    change = ui_changes[name]
    assert digest(data) == change["reviewed_sha256"], f"Unreviewed UI/report edit: {name}"
    for hunk in change["inverse_hunks"]:
        current, original = hunk["current"].encode(), hunk["original"].encode()
        assert data.count(current) == 1, f"Ambiguous UI/report hunk: {name}"
        data = data.replace(current, original, 1)
    assert digest(data) == change["baseline_sha256"], f"Unrelated UI/report bytes changed: {name}"
    return data


# Pin the frozen 5.5.33 oracle independently of the current kernel.
reference33 = (Path(__file__).parent / "reference/hnsw_v33.hpp").read_text().replace(
    "namespace markvault_v33 {", "namespace markvault {", 1)
assert digest(reference33.encode()) == kernel_changes["app/src/main/cpp/hnsw_core.hpp"]["baseline_sha256"]
for name, expected in json.loads((Path(__file__).parent / "speed-preservation-5.5.33.json").read_text())["new_files"].items():
    assert digest((root / name).read_bytes()) == expected, f"New kernel oracle drifted: {name}"
for name in kernel_changes:
    preserved_bytes(name)

# Validate every changed file even if an older manifest only protects its methods.
for name in ui_changes:
    preserved_bytes(name)
for name in hnsw_changes:
    preserved_bytes(name)
for name in speed_changes:
    preserved_bytes(name)


store_name = "app/src/main/java/com/tebogo/markvault/search/SavedSearchStore.kt"
original_store = preserved_bytes(store_name).decode()
actual_store = (root / store_name).read_text()
models_start = "data class SavedSearchSession("
models_end = "object SavedSearchStore {"
assert (actual_store[actual_store.index(models_start):actual_store.index(models_end)] ==
        original_store[original_store.index(models_start):original_store.index(models_end)])
legacy_store = (root / "tools/tests/LegacySavedSearchStore.kt").read_text()
assert legacy_store[legacy_store.index("object LegacySavedSearchStore {"):].replace(
    "object LegacySavedSearchStore {", "object SavedSearchStore {", 1
) == original_store[original_store.index(models_end):], "Saved report oracle drifted from 5.5.30"

screen_name = "app/src/main/java/com/tebogo/markvault/ui/SearchScreen.kt"
old_screen = preserved_bytes(screen_name).decode()
new_screen = (root / screen_name).read_text()


def top_level_body(source, prefix):
    start = source.index("{", source.index(prefix))
    end = source.index("\n}", start) + 2
    return source[start:end]


# Caching changes the lifetime of the original AnnotatedString, never the highlighting algorithm.
old_highlighting = top_level_body(old_screen, "private fun highlightSentences(").replace(
    "    val highlightBg = androidx.compose.material3.MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.55f)\n", "", 1
)
assert old_highlighting == top_level_body(new_screen, "private fun buildHighlightedSentences(")
print("Original saved-session model/full-codec oracle and snippet-highlighting computation=PASS")


query_files = {"app/src/main/java/com/tebogo/markvault/search/Embedder.kt",
               "app/src/main/java/com/tebogo/markvault/search/OnnxBertEmbedderBackend.kt"}
# The two intentional query runtime changes have separate original-byte/math pins and real-model checks.
import runpy
runpy.run_path(str(Path(__file__).parent / "query_embedding_preservation_test.py"))
for field in ("unchanged_files", "unchanged_from_previous"):
    for name, expected in manifest[field].items():
        if name in query_files: continue
        assert digest(preserved_bytes(name)) == expected, f"Protected file changed: {name}"

previous = json.loads((Path(__file__).parent / "preservation-5.5.27.json").read_text())
for name, expected in previous.items():
    if name in query_files: continue
    data = preserved_bytes(name)
    if name == "app/src/main/java/com/tebogo/markvault/search/FastSearchMemoryPolicy.kt":
        # Only the additive shared-session worker budget is new; retain the original warm policy hash.
        start = data.index(b"    /** One shared weight set")
        end = data.index(b"    fun canRetain(", start)
        data = data[:start] + data[end:]
    assert digest(data) == expected, f"Unrelated 5.5.27 file changed: {name}"

vm = preserved_bytes("app/src/main/java/com/tebogo/markvault/AppViewModel.kt")
# Normalize only additive blue cleanup hooks before verifying the original method hashes.
original_vm = vm
vm = vm.replace(b"blueRerankEngine.unload(); reranker.unload()", b"reranker.unload()")
import re
vm = re.sub(rb"^[ \t]*blueRerankEngine\.unload\(\)\n", b"", vm, flags=re.M)
vm = re.sub(rb"^[ \t]*if \((?:!v|v|!enabled)\) blueRerankEngine\.unload\(\)\n", b"", vm, flags=re.M)
start = vm.index(b"        val blue = activeSearchTrace?.hnswEnabled ?: hnswSearchEnabled.value", vm.index(b"    private suspend fun rankedContentSearch("))
end_marker = b"        if (blue) return com.tebogo.markvault.search.BlueKeywordRanking.rank(ftsHits, originalRaw)"
end = vm.index(end_marker, start) + len(end_marker)
vm = vm[:start] + b"        val ftsHits = dao.search(dbQuery)" + vm[end:]
for block in manifest["protected_methods"]:
    prefix = block["prefix"].encode()
    assert vm.count(prefix) == 1, f"Protected method missing/ambiguous: {block['name']}"
    start = vm.index(prefix)
    assert digest(vm[start:start + block["length"]]) == block["sha256"], f"Protected method changed: {block['name']}"

for block in manifest["unchanged_queries"]:
    data = (root / block["file"]).read_bytes()
    prefix = block["prefix"].encode()
    starts, at = [], 0
    while True:
        at = data.find(prefix, at)
        if at < 0:
            break
        starts.append(at)
        at += 1
    assert any(digest(data[s:s + block["length"]]) == block["sha256"] for s in starts), f"Original Room query changed: {block['name']}"

text = original_vm.decode()
start = text.index("    private suspend fun expandedContentSearch(")
end = text.index("    /**\n     * v5.4.81cc — Reciprocal Rank Fusion.", start)
content = text[start:end]
assert text.count("BlueSearchPipeline.retrieve(") == 1 and "BlueSearchPipeline.retrieve(" in content
assert "precomputedSemantic = prefetchedSemantic?.await()" in content
assert "requireKeywordCandidate = exactPhrase" in content
assert "scopeAtStart = scopeAtStart, dualAtStart = dualAtStart" in content
assert "enabled = blueRetrieval" in content
assert "pendingMedia?.let { publishMedia(it.await()) }" in text
assert "-ffp-contract=off" in (root / "app/src/main/cpp/CMakeLists.txt").read_text()
build = (root / "app/build.gradle.kts").read_text()
assert 'versionName = "5.5.34"' in build and "versionCode = 483" in build
assert 'implementation("com.google.code.gson:gson:2.11.0")' in build
base_count = len(manifest['unchanged_files']) - len(query_files)
reviewed_names = ui_changes.keys() | hnsw_changes.keys()
base_normalized = len(set(manifest['unchanged_files']) & reviewed_names)
previous_count = len(manifest['unchanged_from_previous']) - len(query_files)
previous_normalized = len(set(manifest['unchanged_from_previous']) & reviewed_names)
print(f"5.5.24 preservation: {base_count - base_normalized} byte-identical files plus {base_normalized} reviewed changes, "
      f"{len(manifest['protected_methods'])} protected original method/policy blocks (additive blue cleanup/cache hooks normalized), "
      f"{len(manifest['unchanged_queries'])} original DAO queries=PASS; "
      f"{previous_count - previous_normalized} files unchanged from 5.5.26 plus {previous_normalized} reviewed changes")
previous_normalized = len(set(previous) & reviewed_names)
print(f"Delivered 5.5.27 preservation: {len(previous) - len(query_files) - 1 - previous_normalized} byte-identical files, "
      f"{previous_normalized} reviewed changes plus original warm policy=PASS")
ui_count = sum(name.startswith("app/") for name in ui_changes)
print(f"Delivered 5.5.30 preservation: {ui_count} exact reviewed UI/report deltas and "
      f"{len(ui_changes) - ui_count} archive-tool deltas; all other bytes retained=PASS")
print(f"Delivered 5.5.31 preservation: {len(hnsw_changes)} exact reviewed HNSW/telemetry/preparation/test deltas=PASS")
print(f"Delivered 5.5.32 preservation: {len(speed_changes)} exact reviewed query-visitation/prefetch/rerank/test deltas=PASS")

print(f"Delivered 5.5.33 preservation: {len(kernel_changes)} exact reviewed native-kernel/version/test deltas; Kotlin, JNI, database, IVF and UI byte-identical=PASS")
