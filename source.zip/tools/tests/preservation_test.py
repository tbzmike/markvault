"""Source regression guard pinned to the supplied 5.5.24 and delivered 5.5.26 archives."""
import hashlib
import json
from pathlib import Path

root = Path(__file__).resolve().parents[2]
manifest = json.loads((Path(__file__).parent / "preservation-5.5.24.json").read_text())


def digest(data):
    return hashlib.sha256(data).hexdigest()


for field in ("unchanged_files", "unchanged_from_previous"):
    for name, expected in manifest[field].items():
        assert digest((root / name).read_bytes()) == expected, f"Protected file changed: {name}"

vm = (root / "app/src/main/java/com/tebogo/markvault/AppViewModel.kt").read_bytes()
for block in manifest["protected_methods"]:
    prefix = block["prefix"].encode()
    assert vm.count(prefix) == 1, f"Protected method missing/ambiguous: {block['name']}"
    start = vm.index(prefix)
    assert digest(vm[start:start + block["length"]]) == block["sha256"], f"Protected method changed: {block['name']}"

for block in manifest["unchanged_queries"]:
    data = (root / block["file"]).read_bytes()
    prefix = block["prefix"].encode()
    starts, at = [], 0
    while True:
        at = data.find(prefix, at)
        if at < 0:
            break
        starts.append(at)
        at += 1
    assert any(digest(data[s:s + block["length"]]) == block["sha256"] for s in starts), f"Original Room query changed: {block['name']}"

text = vm.decode()
start = text.index("    private suspend fun expandedContentSearch(")
end = text.index("    /**\n     * v5.4.81cc — Reciprocal Rank Fusion.", start)
content = text[start:end]
assert text.count("BlueSearchPipeline.retrieve(") == 1 and "BlueSearchPipeline.retrieve(" in content
assert "precomputedSemantic = prefetchedSemantic?.await()" in content
assert "requireKeywordCandidate = exactPhrase" in content
assert "scopeAtStart = scopeAtStart, dualAtStart = dualAtStart" in content
assert "enabled = blueRetrieval" in content
assert "pendingMedia?.let { publishMedia(it.await()) }" in text
assert "-ffp-contract=off" in (root / "app/src/main/cpp/CMakeLists.txt").read_text()
build = (root / "app/build.gradle.kts").read_text()
assert 'versionName = "5.5.27"' in build and "versionCode = 476" in build
print(f"5.5.24 preservation: {len(manifest['unchanged_files'])} byte-identical files, "
      f"{len(manifest['protected_methods'])} protected method/policy blocks, "
      f"{len(manifest['unchanged_queries'])} original DAO queries=PASS; "
      f"{len(manifest['unchanged_from_previous'])} files unchanged from 5.5.26")
