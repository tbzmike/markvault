"""Source regression guard pinned to the supplied 5.5.24 and delivered 5.5.26 archives."""
import hashlib
import json
from pathlib import Path

root = Path(__file__).resolve().parents[2]
manifest = json.loads((Path(__file__).parent / "preservation-5.5.24.json").read_text())


def digest(data):
    return hashlib.sha256(data).hexdigest()


for field in ("unchanged_files", "unchanged_from_previous"):
    for name, expected in manifest[field].items():
        assert digest((root / name).read_bytes()) == expected, f"Protected file changed: {name}"

previous = json.loads((Path(__file__).parent / "preservation-5.5.27.json").read_text())
for name, expected in previous.items():
    assert digest((root / name).read_bytes()) == expected, f"Unrelated 5.5.27 file changed: {name}"

vm = (root / "app/src/main/java/com/tebogo/markvault/AppViewModel.kt").read_bytes()
# Normalize only additive blue cleanup hooks before verifying the original method hashes.
original_vm = vm
vm = vm.replace(b"blueRerankEngine.unload(); reranker.unload()", b"reranker.unload()")
import re
vm = re.sub(rb"^[ \t]*blueRerankEngine\.unload\(\)\n", b"", vm, flags=re.M)
vm = re.sub(rb"^[ \t]*if \((?:!v|v|!enabled)\) blueRerankEngine\.unload\(\)\n", b"", vm, flags=re.M)
start = vm.index(b"        val blue = activeSearchTrace?.hnswEnabled ?: hnswSearchEnabled.value", vm.index(b"    private suspend fun rankedContentSearch("))
end_marker = b"        if (blue) return com.tebogo.markvault.search.BlueKeywordRanking.rank(ftsHits, originalRaw)"
end = vm.index(end_marker, start) + len(end_marker)
vm = vm[:start] + b"        val ftsHits = dao.search(dbQuery)" + vm[end:]
for block in manifest["protected_methods"]:
    prefix = block["prefix"].encode()
    assert vm.count(prefix) == 1, f"Protected method missing/ambiguous: {block['name']}"
    start = vm.index(prefix)
    assert digest(vm[start:start + block["length"]]) == block["sha256"], f"Protected method changed: {block['name']}"

for block in manifest["unchanged_queries"]:
    data = (root / block["file"]).read_bytes()
    prefix = block["prefix"].encode()
    starts, at = [], 0
    while True:
        at = data.find(prefix, at)
        if at < 0:
            break
        starts.append(at)
        at += 1
    assert any(digest(data[s:s + block["length"]]) == block["sha256"] for s in starts), f"Original Room query changed: {block['name']}"

text = original_vm.decode()
start = text.index("    private suspend fun expandedContentSearch(")
end = text.index("    /**\n     * v5.4.81cc — Reciprocal Rank Fusion.", start)
content = text[start:end]
assert text.count("BlueSearchPipeline.retrieve(") == 1 and "BlueSearchPipeline.retrieve(" in content
assert "precomputedSemantic = prefetchedSemantic?.await()" in content
assert "requireKeywordCandidate = exactPhrase" in content
assert "scopeAtStart = scopeAtStart, dualAtStart = dualAtStart" in content
assert "enabled = blueRetrieval" in content
assert "pendingMedia?.let { publishMedia(it.await()) }" in text
assert "-ffp-contract=off" in (root / "app/src/main/cpp/CMakeLists.txt").read_text()
build = (root / "app/build.gradle.kts").read_text()
assert 'versionName = "5.5.28"' in build and "versionCode = 477" in build
print(f"5.5.24 preservation: {len(manifest['unchanged_files'])} byte-identical files, "
      f"{len(manifest['protected_methods'])} protected original method/policy blocks (additive blue cleanup/cache hooks normalized), "
      f"{len(manifest['unchanged_queries'])} original DAO queries=PASS; "
      f"{len(manifest['unchanged_from_previous'])} files unchanged from 5.5.26")
print(f"Delivered 5.5.27 preservation: {len(previous)} byte-identical files=PASS")
