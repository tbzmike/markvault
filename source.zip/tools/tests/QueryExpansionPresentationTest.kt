import com.tebogo.markvault.search.QueryExpansionPresentation
import com.tebogo.markvault.search.QueryContribution
import com.tebogo.markvault.search.ResultQueryProvenance
import com.tebogo.markvault.search.ResultQuerySource

fun main() {
    val q = QueryExpansionPresentation


    check(q.fromPlan(listOf("original" to ResultQuerySource.ORIGINAL)).isEmpty())
    check(q.fromPlan(emptyList()).isEmpty())
    val variants = q.fromPlan(listOf(
        "Does God force people?" to ResultQuerySource.ORIGINAL,
        "people have free will" to ResultQuerySource.SYNONYM,
        "Does Jehovah allow choice?" to ResultQuerySource.LLM,
        "Why is worship voluntary?" to ResultQuerySource.T5,
        "What shows Jehovah's patience?" to ResultQuerySource.QUESTION_AWARENESS
    ))
    check(variants.size == 4)
    check(variants.map { it.number } == listOf(1, 2, 3, 4))
    check(variants.map { it.source } == listOf(ResultQuerySource.SYNONYM, ResultQuerySource.LLM, ResultQuerySource.T5, ResultQuerySource.QUESTION_AWARENESS))
    check(q.fromPlan(listOf(
        "x" to ResultQuerySource.ORIGINAL, "  A  " to ResultQuerySource.LLM, "a" to ResultQuerySource.LLM
    )).size == 1)

    fun contribution(n: Int, text: String, source: ResultQuerySource) = QueryContribution(
        queryId = "expansion:$n", queryText = text, source = source,
        expansionNumber = n, keyword = true, contribution = 0.4
    )
    val hit1 = ResultQueryProvenance(
        "original", listOf(
            QueryContribution("original", "original", ResultQuerySource.ORIGINAL, keyword = true),
            contribution(2, "T5 matches here", ResultQuerySource.T5),
            contribution(1, "Synonym matches here", ResultQuerySource.SYNONYM)
        )
    )
    val hit2 = ResultQueryProvenance("expansion:2", listOf(
        contribution(2, "T5 matches here", ResultQuerySource.T5)
    ))
    val saved = q.fromSaved(
        listOf(hit1, hit2),
        savedExpansions = listOf("T5 matches here", "An LLM expansion without returned hits"),
        questionAwareQueries = listOf("An answer-shaped query without returned hits")
    )
    check(saved.size == 4)
    check(saved.map { it.number } == listOf(1, 2, null, null))
    check(saved[0].source == ResultQuerySource.SYNONYM && saved[1].source == ResultQuerySource.T5)
    check(saved[2].source == ResultQuerySource.QUESTION_AWARENESS)
    check(saved[3].source == null) // Cannot falsely identify old saved expansion engine.
    println("Query expansion regression tests PASS: 0-budget, LLM, synonym, T5, question awareness, stable colors, multi-match, saved restore")
}
