#!/usr/bin/env python3
"""5.5.53: fast structural preview, visible status, and intact full-restore verification."""
from pathlib import Path
from zipfile import ZipFile, ZipInfo, ZIP_DEFLATED
import json, tempfile, time, subprocess, shutil
root=Path(__file__).resolve().parents[2]
backup=(root/'app/src/main/java/com/tebogo/markvault/data/BackupManager.kt').read_text()
ui=(root/'app/src/main/java/com/tebogo/markvault/ui/SettingsScreen.kt').read_text()
version=(root/'app/build.gradle.kts').read_text()
assert 'versionCode = 502' in version and 'versionName = "5.5.53"' in version
assert 'FORMAT_VERSION = 7' in backup
assert 'readSeekableManifestPreview(ctx, srcUri)?.let { return@withContext it }' in backup
assert 'ZipFile(File("/proc/self/fd/${descriptor.fd}"))' in backup
assert 'val verified = validateV4Archive(ctx, srcUri) { checked ->' in backup
assert '?: extractRecognisedEntries(ctx, srcUri, staging)' in backup
assert 'restoreAnnIndexes(ctx, srcUri, verified)' in backup
assert 'PortableBackupFiles.restoreLibrary(ctx, srcUri, currentLibraryUri)' in backup
assert 'stageDatastoreForNextStart(ctx, streamedDs, currentLibraryUri)' in backup
assert 'isAllowedV4Entry(entry.name)' in backup
assert 'onEntriesChecked?.invoke(entriesChecked)' in backup
assert 'inspectingRestore = true' in ui and 'inspectingRestore = false' in ui
assert 'Reading backup information…' in ui
assert 'LinearProgressIndicator(Modifier.fillMaxWidth())' in ui
assert 'enabled = !backupRestoreState.running && !inspectingRestore' in ui
assert 'newCachedThreadPool' not in backup and 'CoroutineScope(' not in backup
# A representative v7 archive where the manifest is written LAST after articles,
# the exact property causing the initial detection delay in 5.5.52.
with tempfile.TemporaryDirectory(prefix='mv553_') as td:
    p=Path(td)/'library.zip'; count=2400
    checksums={}; sizes={}
    import hashlib
    with ZipFile(p,'w',ZIP_DEFLATED, compresslevel=6) as z:
        for i in range(count):
            name=f'library/files/folder_{i//100:03d}/article_{i:05d}.md'
            data=(f'# Article {i}\n'+'Esau and the family tree. '*40).encode()
            z.writestr(name,data)
            sizes[name]=len(data);checksums[name]=hashlib.sha256(data).hexdigest()
        manifest={'app':'MarkVault','format_version':7,'stream_schema_version':1,'version':'5.5.52',
          'database_schema':24,'library_files':count,'checksums':checksums,'sizes':sizes}
        z.writestr('manifest.json',json.dumps(manifest))
    with ZipFile(p) as z:
        assert z.namelist()[-1]=='manifest.json'
        t0=time.monotonic(); m=json.loads(z.read('manifest.json'))
        meta={x.filename:x.file_size for x in z.infolist() if x.filename!='manifest.json'}
        assert set(meta)==set(m['checksums'])==set(m['sizes'])
        assert all(meta[k]==m['sizes'][k] for k in meta)
        assert m['library_files']==count
        elapsed=time.monotonic()-t0
        assert elapsed<5, elapsed
    print(f'PASS: v7 manifest at END, {count} article entries, direct central-directory preview {elapsed:.3f}s')

# Kotlin type-check of the actual preview function, transplanted as-is into
# tiny Android interfaces (no Android SDK/Gradle available on this host).
if shutil.which('kotlinc'):
    start=backup.index('    private fun readSeekableManifestPreview(')
    end=backup.index('    /** Return a safe preview;',start)
    snippet=backup[start:end]
    with tempfile.TemporaryDirectory(prefix='mv553_kotlin_') as td:
        kt=Path(td)/'Preview.kt'
        kt.write_text('''package com.tebogo.markvault.data
import java.io.File
import java.io.ByteArrayOutputStream
import java.util.zip.ZipFile
import android.content.Context
import android.net.Uri
import android.util.Log
import org.json.JSONObject
object PortableBackupState { const val EXTRA_ENTRY="extra"; const val UI_ENTRY="ui" }
object PortableBackupFiles { const val DIRECTORIES_ENTRY="dirs" }
object BackupManager {
    private const val TAG="MV"
    private const val FORMAT_VERSION=7
    private const val STREAM_SCHEMA_VERSION=1
    private const val MANIFEST_ENTRY="manifest.json"
    private const val NOTES_ENTRY="n";private const val TOPICS_ENTRY="t"
    private const val LINKS_ENTRY="l";private const val EMBEDDINGS_ENTRY="e"
    private const val DS_ENTRY="d";private const val ANN_PREFIX="search/ann/"
    private fun isAllowedV4Entry(name:String)=true
'''+snippet+'}\n')
        (Path(td)/'Stubs.kt').write_text('''package org.json
class JSONObject(val json:String="") {
    fun optString(name:String):String="MarkVault"
    fun optInt(name:String,def:Int=0):Int=7
    fun optJSONObject(name:String):JSONObject?=this
    fun length():Int=0
    fun optLong(name:String,def:Long=0):Long=0
}
''')
        (Path(td)/'Android.kt').write_text('''package android.content
import android.net.Uri
import java.io.Closeable
class ContentResolver { fun openFileDescriptor(uri:Uri,mode:String): Descriptor?=null }
class Descriptor : Closeable {val fd:Int=0; override fun close(){} }
class Context {val contentResolver=ContentResolver()}
''')
        (Path(td)/'Uri.kt').write_text('package android.net\nclass Uri\n')
        (Path(td)/'Log.kt').write_text('package android.util\nobject Log {fun w(tag:String,msg:String,e:Exception):Int=0}\n')
        cmd=['kotlinc',str(kt),str(Path(td)/'Stubs.kt'),str(Path(td)/'Android.kt'),
             str(Path(td)/'Uri.kt'),str(Path(td)/'Log.kt'),'-d',str(Path(td)/'out.jar')]
        x=subprocess.run(cmd, capture_output=True,text=True,timeout=45)
        assert x.returncode==0, x.stderr[-5000:]
        print('PASS: real Kotlin seekable-preview implementation type-checks with Android interface stubs')
print('PASS: full integrity validation retained after confirmation; older archive fallback and UI progress preserved')
