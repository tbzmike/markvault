"""Run the actual new Room queries against SQLite, including cross-model paging."""
import ast
import re
import sqlite3
from pathlib import Path

root = Path(__file__).resolve().parents[2]
source = (root / "app/src/main/java/com/tebogo/markvault/data/Db.kt").read_text()
queries = {}
for match in re.finditer(r'@Query\((.*?)\)\s*suspend fun (\w+)\(', source, re.S):
    if match.group(2).startswith("loadHnsw") or match.group(2) == "latestEmbeddingCreatedAt":
        queries[match.group(2)] = "".join(ast.literal_eval(s) for s in re.findall(r'"(?:\\.|[^"\\])*"', match.group(1)))
db = sqlite3.connect(":memory:")
db.execute("CREATE TABLE note_embeddings (noteId INTEGER, modelVersion TEXT, chunkIndex INTEGER, vector BLOB, createdAt INTEGER, PRIMARY KEY(noteId, modelVersion, chunkIndex))")
db.execute("CREATE INDEX index_note_embeddings_modelVersion_noteId_chunkIndex ON note_embeddings(modelVersion,noteId,chunkIndex)")
db.execute("CREATE INDEX index_note_embeddings_modelVersion_createdAt ON note_embeddings(modelVersion,createdAt)")
for model in ("a", "b"):
    for note in range(1, 301):
        for chunk in range(note % 7 + 1):
            db.execute("INSERT INTO note_embeddings VALUES(?,?,?,?,?)", (note, model, chunk, model.encode(), note))
for query_name in ("loadHnswVectorsPage", "loadHnswMetadataPage"):
    collected = []
    after_note, after_chunk = 0, -1
    while True:
        page = db.execute(queries[query_name], dict(mv="a", afterNote=after_note, afterChunk=after_chunk, limit=13)).fetchall()
        if not page:
            break
        collected.extend((r[0], r[1]) for r in page)
        after_note, after_chunk = page[-1][:2]
    expected = db.execute("SELECT noteId,chunkIndex FROM note_embeddings WHERE modelVersion='a' ORDER BY noteId,chunkIndex").fetchall()
    assert collected == expected and len(set(collected)) == len(collected)
changed = queries["loadHnswChangedVectorsPage"].replace("IN (:noteIds)", "IN (1,7,300)")
got = []
for offset in range(0, 30, 4):
    got.extend(db.execute(changed, dict(mv="a", limit=4, offset=offset)).fetchall())
assert all(row[0] in (1, 7, 300) and row[2] == b"a" for row in got)
assert len(got) == db.execute("SELECT COUNT(*) FROM note_embeddings WHERE modelVersion='a' AND noteId IN (1,7,300)").fetchone()[0]
assert db.execute(queries["latestEmbeddingCreatedAt"], dict(modelVersion="a")).fetchone()[0] == 300
plan = db.execute("EXPLAIN QUERY PLAN " + queries["latestEmbeddingCreatedAt"], dict(modelVersion="a")).fetchall()
assert any("modelVersion_createdAt" in row[3] for row in plan)
print("Room SQL model isolation/keyset/chunk pages/changed-note pages/freshness index checks=PASS")
