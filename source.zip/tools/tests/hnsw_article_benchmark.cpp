#include "hnsw_core.hpp"
#include <chrono>
#include <fstream>
#include <iostream>
#include <random>
#include <set>
#include <unordered_map>

using Clock = std::chrono::steady_clock;
double millis(Clock::time_point start) {
    return std::chrono::duration<double, std::milli>(Clock::now() - start).count();
}
std::uint64_t passage_key(std::size_t note, std::size_t chunk) { return (note << 32) | chunk; }

int main(int argc, char** argv) {
    std::size_t articles = argc > 1 ? std::stoull(argv[1]) : 4200;
    std::size_t dim = argc > 2 ? std::stoull(argv[2]) : 128;
    std::string path = argc > 3 ? argv[3] : "/tmp/markvault_article_benchmark.bin";
    constexpr std::size_t chunks = 5;
    std::size_t count = articles * chunks, split = articles * 20 / 42;
    std::mt19937 rng(55126);
    std::normal_distribution<float> normal;
    std::vector<float> centers(128 * dim), vectors(count * dim), prototype(dim);
    for (auto& v : centers) v = normal(rng);
    for (std::size_t n = 0; n < articles; ++n) {
        std::size_t topic = n % 64 + (n >= split ? 64 : 0);
        for (std::size_t d = 0; d < dim; ++d)
            prototype[d] = centers[topic * dim + d] + 0.35f * normal(rng);
        for (std::size_t c = 0; c < chunks; ++c) {
            float norm = 0;
            auto v = vectors.data() + (n * chunks + c) * dim;
            for (std::size_t d = 0; d < dim; ++d) { v[d] = prototype[d] + 0.07f * normal(rng); norm += v[d] * v[d]; }
            norm = std::sqrt(norm);
            for (std::size_t d = 0; d < dim; ++d) v[d] /= norm;
        }
    }
    auto started = Clock::now();
    if (argc < 5 || std::string(argv[4]) != "reuse") {
        auto graph = std::make_unique<markvault::Hnsw>(dim, count);
        for (std::size_t n = 0; n < articles; ++n) {
            for (std::size_t c = 0; c < chunks; ++c)
                graph->add(passage_key(n + 1, c), vectors.data() + (n * chunks + c) * dim, dim);
            if ((n + 1) % 5000 == 0) std::cout << "built_articles=" << n + 1 << " build_ms=" << millis(started) << std::endl;
        }
        { std::ofstream output(path, std::ios::binary); output.write("M", 1); }
        graph->append(path.c_str());
        std::cout << "build_ms=" << millis(started) << std::endl;
    }
    std::cout << "articles=" << articles << " chunks=" << count << " dim=" << dim << std::endl;
    markvault::Hnsw mapped(dim, 0, false);
    mapped.open(path.c_str(), 1, false);
    if (mapped.dimensions() != dim || mapped.size() != count) throw std::runtime_error("Fixture mismatch");
    std::vector<std::uint64_t> first, second;
    for (std::size_t n = 1; n <= articles; ++n) (n <= split ? first : second).push_back(n);
    for (std::size_t q : {std::size_t(0), split / 2, split + 17, articles - 1}) {
        auto vector = vectors.data() + q * chunks * dim;
        for (int scope = 0; scope < 3; ++scope) {
            auto allowed = scope == 1 ? &first : scope == 2 ? &second : nullptr;
            started = Clock::now();
            std::size_t wanted = std::min<std::size_t>(1200, count), passes = 0;
            std::set<std::uint64_t> found;
            while (true) {
                auto keys = mapped.search(vector, dim, wanted, allowed);
                ++passes;found.clear();
                for (auto key : keys) { found.insert(key >> 32); if (found.size() >= 600) break; }
                if (found.size() >= 600 || wanted >= std::min<std::size_t>(4800, count) || keys.size() < wanted) break;
                wanted = std::min<std::size_t>(wanted * 2, std::min<std::size_t>(4800, count));
            }
            auto old_ms = millis(started);
            std::cout << "query_note=" << q + 1 << " scope=" << scope << " old_ms=" << old_ms << " old_articles=" << found.size() << " old_passes=" << passes;
#ifndef ONLY_BASELINE
            started = Clock::now();
            auto improved = mapped.article_candidates(vector, dim, 600, 200, allowed);
            std::cout << " new_ms=" << millis(started) << " new_articles=" << improved.articles.size()
                << " exhaustive=" << improved.exhaustive << " graph_passages=" << improved.passages
                << " distances=" << improved.scored;
            std::unordered_map<std::uint64_t, float> best;
            for (std::size_t n = 0; n < articles; ++n) {
                if (allowed && !std::binary_search(allowed->begin(), allowed->end(), n + 1)) continue;
                float score = -1;
                for (std::size_t c = 0; c < chunks; ++c) {
                    float dot = 0;auto v = vectors.data() + (n * chunks + c) * dim;
                    for (std::size_t d = 0; d < dim; ++d) dot += vector[d] * v[d];
                    score = std::max(score, dot);
                }
                best[n + 1] = score;
            }
            std::vector<std::pair<float,std::uint64_t>> oracle;
            for (auto item : best) oracle.emplace_back(-item.second, item.first);
            std::sort(oracle.begin(),oracle.end());
            std::set<std::uint64_t> pool(improved.articles.begin(), improved.articles.end());
            for (auto limit : {10u,50u,200u}) {
                std::size_t hit_old = 0, hit_new = 0, upto = std::min<std::size_t>(limit, oracle.size());
                for (std::size_t i = 0; i < upto; ++i) { hit_old += found.count(oracle[i].second); hit_new += pool.count(oracle[i].second); }
                std::cout << " old_recall" << limit << "=" << float(hit_old)/upto << " new_recall" << limit << "=" << float(hit_new)/upto;
                if (hit_new < hit_old) throw std::runtime_error("Article candidate recall regressed");
            }
            for (auto note : improved.articles)
                if (allowed && !std::binary_search(allowed->begin(),allowed->end(),note)) throw std::runtime_error("Scope leak");
#endif
            std::cout << std::endl;
        }
    }
    return 0;
}
