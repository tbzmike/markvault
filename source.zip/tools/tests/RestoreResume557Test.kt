import com.tebogo.markvault.data.BackupSelection
import com.tebogo.markvault.data.PortableBackupState
import com.tebogo.markvault.service.RestorePauseGate
import android.database.Cursor
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteStatement
import androidx.sqlite.db.SupportSQLiteDatabase
import java.io.ByteArrayInputStream
import java.io.ByteArrayOutputStream
import java.io.DataInputStream
import java.security.DigestInputStream
import java.security.MessageDigest
import java.util.concurrent.CountDownLatch
import java.util.concurrent.TimeUnit
import java.util.concurrent.atomic.AtomicInteger

private val tableNames = listOf("media_items", "media_embeddings", "playlists", "pdf_page_text", "pdf_annotations", "pdf_history", "web_bookmarks", "web_history")
private val migrated = listOf("id", "title", "description", "durationMs", "thumbnailUrl", "streamUrl", "localPath", "mediaType", "mimeType", "jwKey", "scriptureRefs", "category", "source", "cachedAt", "lastPlayedAt", "resumePositionMs", "qualityOptions", "uploadDate", "isFavourite", "subtitleUrl", "subtitleLanguage", "contentLanguage")
private val fresh = migrated.filter { it != "isFavourite" } + "isFavourite"
private val sourceColumns = tableNames.associateWith { if (it == "media_items") migrated else listOf("id", "data") }
private val destColumns = sourceColumns + ("media_items" to fresh)
private val largeBlob = ByteArray(400_000) { (it % 251).toByte() }
private val rowsByTable: Map<String, List<Any?>> = tableNames.associateWith { table -> sourceColumns.getValue(table).mapIndexed { i, column -> if (table == "media_embeddings" && column == "data") largeBlob else if (column == "id") 1L else "$table:$i:$column" } }
private class SchemaDb(private val columns: Map<String, List<String>>, private val source: Boolean): SupportSQLiteDatabase {
    override fun query(sql: String): Cursor {
        val table = tableNames.first { sql.contains(it) }
        return when {
            sql.startsWith("PRAGMA") -> FakeCursor(columns.getValue(table).map { listOf(0, it) })
            sql.startsWith("SELECT COUNT") -> FakeCursor(listOf(listOf(1L)))
            sql.startsWith("SELECT *") && source -> FakeCursor(listOf(rowsByTable.getValue(table)))
            else -> error(sql)
        }
    }
    override fun execSQL(sql: String) { error("Preflight attempted mutation: $sql") }
    override fun beginTransaction() {}
    override fun setTransactionSuccessful() {}
    override fun endTransaction() {}
}
private class ReorderedDest: SQLiteDatabase() {
    val values = mutableMapOf<String, Map<String, Any?>>()
    override fun rawQuery(sql: String, args: Array<String>?): Cursor = FakeCursor(destColumns.getValue(tableNames.first { sql.contains(it) }).map { listOf(0, it) })
    override fun execSQL(sql: String) {}
    override fun compileStatement(sql: String): SQLiteStatement {
        val table = tableNames.first { sql.contains("INTO $it ") }
        val fields = Regex("`([^`]+)`").findAll(sql).map { it.groupValues[1] }.toList()
        check(fields.toSet() == destColumns.getValue(table).toSet())
        return object: SQLiteStatement() {
            val params = mutableMapOf<Int, Any?>()
            override fun clearBindings() { params.clear() }
            override fun bindLong(pos: Int, value: Long) { params[pos] = value }
            override fun bindString(pos: Int, value: String) { params[pos] = value }
            override fun bindBlob(pos: Int, value: ByteArray) { params[pos] = value }
            override fun executeInsert(): Long { values[table] = fields.mapIndexed { i, name -> name to params[i+1] }.toMap(); return 1L }
        }
    }
}
fun main() {
    check(migrated != fresh && migrated.toSet() == fresh.toSet())
    val stream = ByteArrayOutputStream()
    PortableBackupState.writeExtras(SchemaDb(sourceColumns, true), stream)
    val archive = stream.toByteArray()
    val hash = MessageDigest.getInstance("SHA-256")
    PortableBackupState.validateExtrasSchema(SchemaDb(destColumns, false), DigestInputStream(ByteArrayInputStream(archive), hash).buffered())
    check(hash.digest().contentEquals(MessageDigest.getInstance("SHA-256").digest(archive)))
    val dest = ReorderedDest()
    PortableBackupState.restoreExtras(dest, ByteArrayInputStream(archive))
    for (table in tableNames) for ((i, col) in sourceColumns.getValue(table).withIndex()) {
        val a = rowsByTable.getValue(table)[i]
        val b = dest.values.getValue(table).getValue(col)
        check(if (a is ByteArray && b is ByteArray) a.contentEquals(b) else java.util.Objects.equals(a, b)) { "$table.$col" }
    }
    val incompatible = destColumns + ("media_items" to fresh.filter { it != "isFavourite" })
    check(runCatching { PortableBackupState.validateExtrasSchema(SchemaDb(incompatible, false), ByteArrayInputStream(archive)) }.exceptionOrNull()?.message?.contains("isFavourite") == true)
    println("PASS migrated-vs-fresh media_items order, all values by named column, 400KB BLOB digest, true mismatch rejected before writes")
    for (mask in 0..31) for ((flag, _) in BackupSelection.choices) for (enabled in listOf(false, true)) {
        if (mask != 0 && !BackupSelection.valid(mask)) continue
        val next = BackupSelection.toggle(mask, flag, enabled)
        check(next == 0 || BackupSelection.valid(next))
        check(BackupSelection.has(next, flag) == enabled)
    }
    check(BackupSelection.toggle(0, BackupSelection.ANN, true) == 7)
    check(BackupSelection.toggle(31, BackupSelection.FILES, false) == 24)
    println("PASS every valid selection toggle, cascading dependencies, settings-only and files-only")
    val gate = RestorePauseGate()
    val paused = CountDownLatch(1)
    val resumed = CountDownLatch(1)
    val work = AtomicInteger(0)
    gate.request(true)
    val worker = Thread { gate.checkpoint({ paused.countDown() }, { resumed.countDown() }); work.incrementAndGet() }
    worker.start()
    check(paused.await(2, TimeUnit.SECONDS)); check(work.get() == 0)
    gate.request(false)
    check(resumed.await(2, TimeUnit.SECONDS)); worker.join(2000); check(work.get() == 1)
    val interruptedGate = RestorePauseGate(); val atCheckpoint = CountDownLatch(1); val stopped = CountDownLatch(1)
    interruptedGate.request(true)
    val interrupted = Thread { check(runCatching { interruptedGate.checkpoint({ atCheckpoint.countDown() }, {}) }.isFailure); stopped.countDown() }
    interrupted.start(); check(atCheckpoint.await(2, TimeUnit.SECONDS)); interruptedGate.close(); check(stopped.await(2, TimeUnit.SECONDS)); interrupted.join()
    println("PASS pause blocks actual worker, resumes once, close releases paused worker")
}
