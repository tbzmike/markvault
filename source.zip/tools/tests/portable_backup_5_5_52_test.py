#!/usr/bin/env python3
"""Regression guard for portable backups with colliding SAF relative paths."""
from pathlib import Path
import re
import shutil
import subprocess
import tempfile

root = Path(__file__).resolve().parents[2]
data = root / 'app/src/main/java/com/tebogo/markvault/data'
backup = (data / 'BackupManager.kt').read_text()
files = (data / 'PortableBackupFiles.kt').read_text()
paths = (data / 'PortableLibraryPaths.kt').read_text()
ui = (root / 'app/src/main/java/com/tebogo/markvault/ui/SettingsScreen.kt').read_text()
build = (root / 'app/build.gradle.kts').read_text()

assert 'versionCode = 501' in build and 'versionName = "5.5.52"' in build
assert 'FORMAT_VERSION = 7' in backup, 'Keep previous portable v7 archives compatible'
assert 'archiveVersion !in 4..FORMAT_VERSION' in backup
assert 'sourceRelativePath' in files and 'PortableLibraryPaths.assign' in files
assert 'Library has duplicate relative paths' not in files
assert 'distinctBy { it.documentId }' in paths
assert 'MarkVault copy $suffix' in paths
assert 'filesById' in backup and 'archiveFileForNote' in backup
assert 'DocumentsContract.getDocumentId(it)' in backup
assert 'portableNotePaths[c.getLong(0)]' in backup
assert 'matchedNotes == expectedNotes' in backup
assert 'PortableBackupFiles.scanLibrary(ctx, treeUriString)' in backup
assert backup.index('val portableNotePaths') < backup.index('val out = ctx.contentResolver.openOutputStream')
assert 'require(missing == 0L)' in backup
assert 'PortableBackupState.writeExtras' in backup and 'PortableBackupState.restoreExtras' in backup
assert 'PortableBackupFiles.restoreAppFiles' in backup
assert 'restoreAnnIndexes(ctx, srcUri, verified)' in backup
assert 'Portable backup stopped to protect embeddings' in backup
assert 'Creates a portable archive containing original library files' in ui
assert 'Article files, browser/PDF history' not in ui
assert not re.search(r'CoroutineScope|Service\(\)|WorkManager|Handler\(', paths + files)

kotlinc = shutil.which('kotlinc')
kotlin = shutil.which('kotlin')
if kotlinc and kotlin:
    with tempfile.TemporaryDirectory(prefix='mv552_') as tmp:
        jar = str(Path(tmp) / 'saf.jar')
        cmd = [kotlinc, str(data / 'PortableBackupFiles.kt'), str(data / 'PortableLibraryPaths.kt'),
               str(root / 'tools/tests/stubs_551/Db.kt'),
               *map(str, sorted((root / 'tools/tests/stubs_552').glob('*.kt'))),
               '-include-runtime', '-d', jar]
        subprocess.run(cmd, check=True, stdout=subprocess.PIPE, stderr=subprocess.PIPE, timeout=70)
        subprocess.run([kotlin, '-classpath', jar, 'com.tebogo.markvault.data.TestKt'],
                       check=True, timeout=25)
else:
    print('Standalone Kotlin SAF simulation skipped: Kotlin compiler/runtime unavailable')
print('PASS MarkVault 5.5.52: duplicate document IDs, distinct colliding paths, stable note mapping, compatible v7 structure, no new workers')
