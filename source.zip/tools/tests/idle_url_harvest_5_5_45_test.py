#!/usr/bin/env python3
"""Regression for full-content scan avoidance in the startup URL-harvest query."""
from pathlib import Path
import sqlite3
r = Path(__file__).resolve().parents[2]
s=(r/'app/src/main/java/com/tebogo/markvault/data/Db.kt').read_text()
assert 'substr(content, 1, 4096) AS content' in s
assert 'fun notesForUrlHarvest()' in s
assert 'if (content.length > 4096) content.substring(0, 4096)' in (r/'app/src/main/java/com/tebogo/markvault/AppViewModel.kt').read_text()
db=sqlite3.connect(':memory:')
db.execute('CREATE TABLE notes (id INTEGER, uri TEXT, content TEXT, fileType TEXT)')
for i,typ,body in [(1,'md','source: https://example.test/article\n'+'a'*500_000),
                    (2,'md','\n'*5000+'Source: https://example.test/later'),
                    (3,'html','<h1>Title</h1>'+'x'*500_000),
                    (4,'md','An article without a source')]:
 db.execute('INSERT INTO notes VALUES (?,?,?,?)',(i,str(i),body,typ))
old=db.execute("SELECT id,uri,content,fileType FROM notes WHERE (fileType='md' AND (content LIKE '%source:%' OR content LIKE '%Source:%')) OR fileType IN ('html','htm','mhtml','mht')").fetchall()
new=db.execute("SELECT id,uri,substr(content,1,4096) AS content,fileType FROM notes WHERE (fileType='md' AND (content LIKE '%source:%' OR content LIKE '%Source:%')) OR fileType IN ('html','htm','mhtml','mht')").fetchall()
assert [x[0] for x in old]==[x[0] for x in new]
assert all(a[2][:4096]==b[2] for a,b in zip(old,new))
assert all(len(b[2])<=4096 for b in new)
print('PASS: identical selected rows and extracted 4096-character prefixes; no 500K article bodies materialized')
