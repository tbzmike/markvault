#!/usr/bin/env python3
"""Targeted non-Android regressions for 5.5.43 performance/source wiring."""
from pathlib import Path
r=Path(__file__).resolve().parents[2]
vm=(r/'app/src/main/java/com/tebogo/markvault/AppViewModel.kt').read_text()
ui=(r/'app/src/main/java/com/tebogo/markvault/ui/SearchScreen.kt').read_text()
policy=(r/'app/src/main/java/com/tebogo/markvault/search/SearchCleanupPolicy.kt').read_text()
assert 'val quickCheckDelayMs = 350L' in vm
assert 'kotlinx.coroutines.delay(POST_SEARCH_CLEANUP_DELAY_MS - quickCheckDelayMs)' in vm
assert 'if (canSkipRoutineSearchRelease()) {' in vm
assert 'return@launch' in vm[vm.index('if (canSkipRoutineSearchRelease())'):vm.index('kotlinx.coroutines.withContext(kotlinx.coroutines.NonCancellable) {', vm.index('if (canSkipRoutineSearchRelease())'))]
assert 'cancelMediaSemanticIndexing()' in vm[vm.index('kotlinx.coroutines.withContext(kotlinx.coroutines.NonCancellable) {', vm.index('if (canSkipRoutineSearchRelease())')):][:200]
assert 'forceReleaseSearchMemory(preserveFastSearchWarmState = true)' in vm
assert 'com.tebogo.markvault.search.SearchCleanupPolicy.canSkipRoutineRelease(' in vm
for critical_guard in ('llmLoaded || t5Loaded', 'systemLowMemory', 'heapMax * 60L / 100L', 'processPssBytes < availableBytes'):
    assert critical_guard in policy, critical_guard
for preserved in ('private suspend fun checkMemoryPressureAndPause(', 'fun hardResetMemory()', 'private suspend fun freeMemoryForNavigationInternal()', 'private suspend fun forceReleaseSearchMemory(', 'com.tebogo.markvault.search.SavedSearchStore.save(', 'snapshotResultQueryProvenance('):
    assert preserved in vm, preserved
assert 'knownSingleScope != null' in vm and 'val allowedFinalIds = scopeMembershipIds(req.scope, false).orEmpty()' in vm
assert 'dao.getSearchScopeNoteIdPage(SCOPE_SLICE, 0).toHashSet()' in vm
assert 'Saved-search persistence:' in vm and 'executionTrace.timings.add("Saved results"' in vm
assert 'delay(2_300L)' in ui and 'vm.searchCaptionVideos(q)' in ui and 'vm.searchMedia(q)' in ui
assert 'itemsIndexed(filteredResults, key = { _, item -> item.id })' in ui
assert 'SearchResultProvenanceBlock(' in ui and 'QueryExpansionLegend(' in ui
print('PASS: normal cleanup safety, emergency paths, saved-search durability, scope filtering, media search, result UI preserved')
