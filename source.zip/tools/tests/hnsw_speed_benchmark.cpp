#include "hnsw_core.hpp"
#include "reference/hnsw_v33.hpp"
#include <chrono>
#include <fstream>
#include <iostream>
#include <random>

using Clock = std::chrono::steady_clock;
double ms(Clock::time_point start) {
    return std::chrono::duration<double, std::milli>(Clock::now() - start).count();
}
void report(char const* name, std::vector<double> values) {
    std::sort(values.begin(), values.end());
    std::cout << name << " min=" << values.front() << " median=" << values[values.size()/2]
              << " p95=" << values[(values.size()-1)*95/100] << " max=" << values.back() << "ms\n";
}

int main(int argc, char** argv) {
    if (argc != 4) throw std::invalid_argument("Expected: graph_path dimensions articles");
    auto dim = std::stoull(argv[2]), notes = std::stoull(argv[3]);
    markvault_v33::Hnsw previous(dim, 0, false);
    markvault::Hnsw current(dim, 0, false);
    auto start = Clock::now(); previous.open(argv[1], 1, false); auto old_open = ms(start);
    start = Clock::now(); current.open(argv[1], 1, false); auto new_open = ms(start);
    if (current.size() != notes * 5 || current.dimensions() != dim || previous.size() != current.size())
        throw std::runtime_error("Graph fixture mismatch");
    std::cout << "Fixture=" << notes << " articles/" << current.size() << " chunks/" << dim
              << " dimensions; prep=" << old_open << " -> " << new_open << "ms\n";
    // Sample the deterministic article fixture's original stored FP16 matrix,
    // plus unrelated queries. Construction and preparation are reported separately.
    std::ifstream fixture(argv[1], std::ios::binary);
    std::uint32_t shape[2]; fixture.seekg(1); fixture.read(reinterpret_cast<char*>(shape), sizeof(shape));
    if (shape[0] != notes*5 || shape[1] != dim*2) throw std::runtime_error("Unexpected fixture matrix");
    std::mt19937 random(476); std::normal_distribution<float> normal;
    std::vector<markvault::us::f16_t> stored(dim);
    std::vector<std::vector<float>> queries;
    for (std::size_t i=0; i<24; ++i) {
        std::vector<float> query(dim);
        if (i<12) {
            fixture.seekg(9 + ((i*7919)%notes)*5*dim*2);
            fixture.read(reinterpret_cast<char*>(stored.data()), dim*2);
            if (!fixture) throw std::runtime_error("Truncated fixture");
            for (std::size_t d=0; d<dim; ++d) query[d]=float(stored[d]);
        } else {
            float norm=0; for(auto& v:query) { v=normal(random); norm+=v*v; }
            for(auto& v:query) v/=std::sqrt(norm);
        }
        queries.push_back(std::move(query));
    }
    std::vector<std::uint64_t> first, second, sparse{1,3,7}, empty;
    for(std::size_t n=1;n<=notes;++n) (n<=notes*20/42?first:second).push_back(n);
    std::vector<double> old_all, new_all, old_graph_all, graph_all, old_scoped, new_scoped;
    std::size_t comparisons=0;
    for (int round=0; round<3; ++round) for(auto const& query:queries) {
        for(auto allowed:std::array<std::vector<std::uint64_t> const*,5>{nullptr,&first,&second,&sparse,&empty}) {
            markvault_v33::Hnsw::ArticleCandidates before;
            markvault::Hnsw::ArticleCandidates after;
            double a, b;
            auto run_old = [&] { start=Clock::now(); before=previous.article_candidates(query.data(),dim,600,200,allowed); a=ms(start); };
            auto run_new = [&] { start=Clock::now(); after=current.article_candidates(query.data(),dim,600,200,allowed); b=ms(start); };
            if (comparisons % 2) { run_new(); run_old(); } else { run_old(); run_new(); }
            if(before.articles!=after.articles || before.exhaustive!=after.exhaustive ||
               before.passages!=after.passages || before.scored!=after.scored)
                throw std::runtime_error("Ranked candidate order/coverage/traversal changed from 5.5.33");
            if(round && !allowed) { old_all.push_back(a);new_all.push_back(b);old_graph_all.push_back(before.graph_ns/1e6);graph_all.push_back(after.graph_ns/1e6); }
            else if(round && allowed && allowed->size()>10) { old_scoped.push_back(a);new_scoped.push_back(b); }
            ++comparisons;
        }
    }
    std::cout << comparisons << " exact candidate/coverage/frontier/distance-count comparisons=PASS\n";
    report("5.5.33 full-library lookup",old_all);report("5.5.34 full-library lookup",new_all);
    report("5.5.33 full-library graph",old_graph_all);
    report("5.5.34 full-library graph",graph_all);
    report("5.5.33 partition lookup",old_scoped);report("5.5.34 partition lookup",new_scoped);
}
