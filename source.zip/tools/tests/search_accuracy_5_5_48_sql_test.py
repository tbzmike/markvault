"""SQLite FTS4 regression for the reported genealogy retrieval failure and saturated pools."""
import sqlite3
from pathlib import Path

root = Path(__file__).resolve().parents[2]
vm = (root / 'app/src/main/java/com/tebogo/markvault/AppViewModel.kt').read_text()
planner = (root / 'app/src/main/java/com/tebogo/markvault/search/KeywordRecallPlanner.kt').read_text()
assert 'val exactQuery =' in vm and 'if (!exactQuery && ftsHits.size >= 500)' in vm
assert 'query = originalRaw,' in vm and 'semanticProvenanceQuery = originalIssuedQuery(originalRaw)' in vm
assert 'val scoringQuery = if (exactQuery ||' in vm
assert 'val questionAwareQueries = questionAnalysis?.answerQueries' in vm
assert 'requireKeywordCandidate = exactPhrase' in vm
assert 'keywordRankScores = keywordRankScores' in vm
assert 'proximityQuery(originalRaw)' in vm
assert 'addAll(scopedKeywordHits.keys)' in vm

connection = sqlite3.connect(':memory:')
connection.execute('CREATE VIRTUAL TABLE notes_fts USING fts4(content)')
# Simulate 500 irrelevant-looking earlier records containing the key words but far apart.
# Normal first-500 selection can hide a later *direct answer*.
for i in range(500):
    connection.execute('INSERT INTO notes_fts(content) VALUES (?)', (
        f'Esau and his descendants are discussed here. ' + 'unrelated genealogy ' * 16 + ' sons of a different family',))
connection.execute('INSERT INTO notes_fts(content) VALUES (?)', (
    'The sons of Esau were Eliphaz, Reuel, Jeush, Jalam, and Korah.',))
connection.commit()
plain = [i[0] for i in connection.execute('SELECT rowid FROM notes_fts WHERE notes_fts MATCH ? LIMIT 500',('sons* esau*',))]
prox = [i[0] for i in connection.execute('SELECT rowid FROM notes_fts WHERE notes_fts MATCH ? LIMIT 500',('sons* NEAR/8 esau*',))]
assert len(plain) == 500 and 501 not in plain
assert 501 in prox, prox
assert connection.execute('SELECT count(*) FROM notes_fts WHERE notes_fts MATCH ?',('"sons of Esau"',)).fetchone()[0] == 1
print(f'PASS: FTS4 saturated 500-hit pool excludes answer initially; proximity rescue includes answer (pool={len(prox)}), quoted exact preserved')
