package com.tebogo.markvault.search

import kotlinx.coroutines.*
import java.util.Locale

suspend fun checkSearchWork() = coroutineScope {
    val first = SearchWorkPriority.begin()
    val second = SearchWorkPriority.begin()
    val waiting = async(start = CoroutineStart.UNDISPATCHED) {
        SearchWorkPriority.awaitIdle()
        true
    }
    check(!waiting.isCompleted)
    first.close()
    first.close()
    yield()
    check(!waiting.isCompleted)
    second.close()
    check(withTimeout(2000) { waiting.await() })

    val lease = SearchWorkPriority.begin()
    val cancelled = launch(start = CoroutineStart.UNDISPATCHED) { SearchWorkPriority.awaitIdle() }
    cancelled.cancelAndJoin()
    check(cancelled.isCancelled)
    lease.close()
    withTimeout(2000) { SearchWorkPriority.awaitIdle() }

    val originalLocale = Locale.getDefault()
    try {
        Locale.setDefault(Locale.FRANCE)
        val timings = SearchTimings()
        check(timings.summary(500).isEmpty())
        timings.add("ANN lookup", 70)
        timings.add("ANN lookup", 30)
        timings.add("Vector scoring", -10)
        check(timings.summary(1000) == "ANN lookup 0.10s · Vector scoring 0.00s · Other retrieval 0.90s")
        check(timings.summary(50).endsWith("Other retrieval 0.00s"))
    } finally { Locale.setDefault(originalLocale) }
    println("Interactive priority, cancellation, lease release and timing checks=PASS")
}
