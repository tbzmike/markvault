#include "hnsw_core.hpp"
#include "reference/hnsw_v36.hpp"
#include <filesystem>
#include <fstream>
#include <iostream>
#include <random>
#include <set>

void require(bool condition, char const* message) { if (!condition) throw std::runtime_error(message); }
std::vector<char> bytes(std::string const& path) {
    std::ifstream f(path, std::ios::binary); return {std::istreambuf_iterator<char>(f), {}};
}
template <typename Index> void save(Index const& index, std::string const& path) {
    { std::ofstream f(path, std::ios::binary); std::string prefix(73, 'M'); f.write(prefix.data(), prefix.size()); }
    index.append(path.c_str());
    require(std::filesystem::file_size(path) == 73 + index.serialized_length(), "Serialized length mismatch");
}

int main(int argc, char** argv) {
    std::mt19937 rng(486);
    std::size_t comparisons = 0;
    for (std::size_t dim : {1,3,7,103,128,256,384,512,768,1024,2048}) {
        std::vector<markvault::sq8::Scalar> q(dim), rows(4*dim);
        markvault::sq8::Scalar const* pointers[4];
        for (int run=0; run<80; ++run) {
            for (auto& v:q) v = static_cast<std::int8_t>(rng()%256 - 128);
            for (auto& v:rows) v = static_cast<std::int8_t>(rng()%256 - 128);
            for (int i=0; i<4; ++i) pointers[i] = rows.data() + i*dim;
            std::int32_t result[4]; markvault::sq8::dot4(q.data(), pointers, dim, result);
            float inverses[4], float_dots[4], distances[4];
            auto query_norm = float(markvault::sq8::norm(q.data(),dim));
            for (int i=0; i<4; ++i) {
                auto scalar = markvault::sq8::scalar_dot(q.data(), pointers[i], dim);
                require(result[i] == scalar && markvault::sq8::dot(q.data(), pointers[i], dim) == scalar,
                        "Integer SIMD/tail differs from scalar");
                ++comparisons;
                auto row_norm = float(markvault::sq8::norm(pointers[i],dim));
                inverses[i] = markvault::sq8::inverse_norm(row_norm);float_dots[i] = float(scalar);
                auto reference = query_norm && row_norm ? std::clamp(1.f-float(scalar)/std::sqrt(query_norm*row_norm),0.f,2.f)
                                                       : query_norm==row_norm?0.f:1.f;
                require(std::abs(markvault::sq8::distance(q.data(),pointers[i],dim,query_norm)-reference)<4e-7f,"SQ8 inverse cosine error");
            }
            markvault::sq8::finish_inverse4(markvault::sq8::inverse_norm(query_norm),inverses,float_dots,distances);
            for(int i=0;i<4;++i)require(std::abs(distances[i]-markvault::sq8::distance(q.data(),pointers[i],dim,query_norm))<4e-7f,"SQ8 fused inverse cosine error");
        }
        std::fill(q.begin(),q.end(),-128); std::fill(rows.begin(),rows.end(),-128);
        require(markvault::sq8::dot(q.data(),rows.data(),dim) == std::int32_t(dim*16384), "Integer overflow");
    }
    float extremes[]{std::numeric_limits<float>::max(), -std::numeric_limits<float>::max(),0};
    markvault::sq8::Scalar encoded[3]; markvault::sq8::quantize(extremes,encoded,3);
    require(encoded[0]==127 && encoded[1]==-127 && encoded[2]==0,"Max finite encoding");
    float tiny[]{std::numeric_limits<float>::denorm_min(),-std::numeric_limits<float>::denorm_min(),0};
    markvault::sq8::quantize(tiny,encoded,3); require(encoded[0]==127 && encoded[1]==-127,"Subnormal encoding");
    float zero[3]{}; markvault::sq8::quantize(zero,encoded,3);
    require(markvault::sq8::distance(encoded,encoded,3,0)==0,"Zero cosine");
    extremes[0]=std::numeric_limits<float>::infinity();
    bool rejected=false; try { markvault::sq8::quantize(extremes,encoded,3); } catch(std::invalid_argument const&) { rejected=true; }
    require(rejected,"Non-finite encoding accepted");
    if (argc > 1 && std::string(argv[1]) == "kernel-only") {
        std::cout << "SQ8 kernel=" << markvault::sq8::kernel() << " integer comparisons=" << comparisons << " PASS\n";
        return 0;
    }
    auto root = argc>1 ? std::string(argv[1]) : "/tmp/markvault_sq8_test";
    std::filesystem::create_directories(root);
    auto old_path=root+"/legacy.bin", compact_path=root+"/compact.bin", repeat_path=root+"/repeat.bin";
    constexpr std::size_t dim=103, count=2000;
    std::vector<float> vectors(count*dim); std::normal_distribution<float> normal;
    for(auto& v:vectors) v=normal(rng)*.05f;
    markvault_v36::Hnsw original(dim,count);
    for(std::size_t i=0;i<count;++i) original.add((std::uint64_t(i/2+1)<<32)|(i%2),vectors.data()+i*dim,dim);
    original.remove(7ULL<<32); // Keep a real tombstone in the converted graph.
    save(original,old_path);
    markvault::Hnsw converter(dim,0,false,true); converter.open(old_path.c_str(),73,false);
    require(!converter.quantized(),"Legacy FP16 reader"); save(converter,compact_path);
    auto before=bytes(old_path), after=bytes(compact_path);
    auto head_bytes=sizeof(markvault::us::index_dense_head_buffer_t);
    auto old_graph=73+8+count*dim*2+head_bytes, new_graph=73+8+count*dim+head_bytes;
    require(before.size()-after.size()==count*dim,"SQ8 matrix did not halve FP16 bytes");
    require(std::equal(before.begin()+old_graph,before.end(),after.begin()+new_graph,after.end()),"Graph links/keys/slots changed");
    markvault::Hnsw mapped(dim,0,false,true); mapped.open(compact_path.c_str(),73,false);
    require(mapped.quantized() && mapped.size()==count-1,"Compact open/count");
    markvault::Hnsw key_reader(dim,0,true,true); key_reader.open(compact_path.c_str(),73,true);
    auto old_keys=original.keys(),new_keys=key_reader.keys(); std::sort(old_keys.begin(),old_keys.end());std::sort(new_keys.begin(),new_keys.end());
    require(old_keys==new_keys,"Keys changed during conversion");
    save(mapped,repeat_path); require(bytes(repeat_path)==after,"Repeated compaction changed SQ8 vectors");
    std::vector<std::uint64_t> scope{1,8,10};
    auto result=mapped.article_candidates(vectors.data(),dim,600,200,&scope);
    require(result.scalar_bits==8 && result.exhaustive && std::set<std::uint64_t>(result.articles.begin(),result.articles.end())==std::set<std::uint64_t>(scope.begin(),scope.end()),"SQ8 exhaustive scoped recovery");
    markvault::Hnsw mutable_index(dim,0,true,true); mutable_index.open(compact_path.c_str(),73,true);
    mutable_index.remove(8ULL<<32); mutable_index.add(1001ULL<<32,vectors.data(),dim); save(mutable_index,repeat_path);
    key_reader.open(repeat_path.c_str(),73,true); auto keys=key_reader.keys();
    require(std::find(keys.begin(),keys.end(),8ULL<<32)==keys.end() && std::find(keys.begin(),keys.end(),1001ULL<<32)!=keys.end(),"SQ8 delta keys");
    for(std::size_t length : {std::size_t(80),after.size()/2,after.size()-1}) {
        auto corrupt=root+"/corrupt.bin"; {std::ofstream f(corrupt,std::ios::binary);f.write(after.data(),length);}
        markvault::Hnsw invalid(dim,0,false,true);rejected=false;
        try { invalid.open(corrupt.c_str(),73,false); } catch(std::exception const&) { rejected=true; }
        require(rejected,"Truncated SQ8 accepted");
    }
    // Host manager migration fixture is produced by the frozen 5.5.36 writer, not the new bridge.
    constexpr std::size_t migration_dim=16,migration_count=1000;
    markvault_v36::Hnsw migration(migration_dim,migration_count);
    std::vector<float> row(migration_dim);
    for(std::size_t i=1;i<=migration_count;++i) {
        for(std::size_t d=0;d<migration_dim;++d) row[d]=std::sin(float(i*(d+1))*.013f);
        migration.add(std::uint64_t(i)<<32,row.data(),migration_dim);
    }
    auto migration_path=root+"/legacy-manager-payload.bin"; {std::ofstream f(migration_path,std::ios::binary);}
    migration.append(migration_path.c_str());
    std::cout<<"SQ8 kernel="<<markvault::sq8::kernel()<<" integer comparisons="<<comparisons
             <<" graph-byte identity/tombstones/legacy/open/delta/scope/idempotence/corruption PASS\n";
}
