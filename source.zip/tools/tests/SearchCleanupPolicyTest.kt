package com.tebogo.markvault.search

private val MB = 1024L * 1024L

private fun permits(
    llm: Boolean = false, t5: Boolean = false, used: Long = 300L * MB,
    max: Long = 768L * MB, reusable: Boolean = true,
    lowMemory: Boolean = false, available: Long = 1800L * MB,
    pss: Long = 520L * MB
): Boolean = SearchCleanupPolicy.canSkipRoutineRelease(
    llmLoaded = llm, t5Loaded = t5, heapUsed = used, heapMax = max,
    reusableSearchStack = reusable, systemLowMemory = lowMemory,
    availableBytes = available, processPssBytes = pss
)

fun main() {
    check(permits()) { "Healthy HNSW search should avoid repeated teardown" }
    check(!permits(llm = true)) { "LLM must always receive normal unload" }
    check(!permits(t5 = true)) { "T5 must always receive normal unload" }
    check(!permits(used = 500L * MB)) { "High Java heap must clean" }
    check(!permits(used = 600L * MB)) { "Severe Java heap pressure must clean" }
    check(!permits(reusable = false)) { "Heavy stack must use existing teardown" }
    check(!permits(lowMemory = true)) { "Android low memory must clean" }
    check(!permits(available = 400L * MB)) { "Low system headroom must clean" }
    check(!permits(available = 700L * MB, pss = 850L * MB)) { "Native-heavy PSS must clean" }
    check(!permits(max = 0)) { "Unknown heap cap must fail closed" }
    check(!permits(pss = 0)) { "Unknown process PSS must fail closed" }
    println("PASS: 11 memory-safety scenarios; normal cleanup skipped only when safely reusable")
}
