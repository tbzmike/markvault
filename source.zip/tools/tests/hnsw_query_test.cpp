#include "hnsw_core.hpp"
#include "reference/hnsw_v31.hpp"
#include <cstring>
#include <iostream>
#include <random>

void require(bool value, char const* message) { if (!value) throw std::runtime_error(message); }
int main() {
    std::mt19937 rng(481);
    std::uniform_real_distribution<float> value(-1,1);
    std::size_t checked=0;
    for (std::size_t dim:{1u,4u,8u,16u,103u,384u,768u,1024u,2048u}) for(int repeat=0;repeat<128;++repeat) {
        std::vector<markvault::us::f16_t> q(dim),b(dim*2);
        for(auto& v:q) v=value(rng);
        for(auto& v:b) v=value(rng);
        float old=markvault_v31::cosine_half(q.data(),b.data(),dim);
        require(markvault::cosine_half(q.data(),b.data(),dim)==old,"Uncached cosine rounding changed");
        markvault::VectorNorms norms;
        norms.base=reinterpret_cast<std::uintptr_t>(b.data());norms.stride=dim*2;
        norms.values={markvault::half_norm(b.data(),dim),markvault::half_norm(b.data()+dim,dim)};
        {
            markvault::QueryMetricGuard guard(&norms);
            require(markvault::cosine_half(q.data(),b.data(),dim)==old,"Cached vector norm changed cosine");
            require(markvault::cosine_half(q.data(),b.data()+dim,dim)==
                markvault_v31::cosine_half(q.data(),b.data()+dim,dim),"Second norm slot changed cosine");
            require(markvault::cosine_half(q.data(),q.data(),dim)==
                markvault_v31::cosine_half(q.data(),q.data(),dim),"Outside-cache vector changed cosine");
        }
        float norm=0;
        require(!norms.find(b.data(),dim+1,norm),"Norm dimension mismatch accepted");
        require(!norms.find(reinterpret_cast<char*>(b.data())+1,dim,norm),"Unaligned norm accepted");
        require(!norms.find(b.data()+b.size(),dim,norm),"Out-of-range norm accepted");
        ++checked;
    }
    std::size_t scopes=0;
    std::size_t fused=0;
    for(std::size_t dim:{1u,3u,4u,8u,103u,384u,768u,1024u,2048u,2049u})
        for(std::size_t count:{1u,3u,4u,5u,16u,31u,32u,63u,64u,65u}) for(int repeat=0;repeat<8;++repeat) {
            std::vector<markvault::us::f16_t> q(dim),matrix(dim*count);
            for(auto& v:q) v=repeat==0?0:value(rng);
            for(auto& v:matrix) v=repeat==1?0:value(rng);
            markvault::VectorNorms norms;
            norms.base=reinterpret_cast<std::uintptr_t>(matrix.data());norms.stride=dim*2;
            std::vector<void const*> pointers;
            for(std::size_t n=0;n<count;++n) {
                auto p=matrix.data()+n*dim;
                pointers.push_back(p);norms.values.push_back(markvault::half_norm(p,dim));
            }
            {
                markvault::QueryMetricGuard guard(&norms);
                auto before=markvault::query_metric_cache.measurements;
                markvault::precompute_cosine_half(q.data(),pointers.data(),count,dim);
                require(markvault::query_metric_cache.measurements==before,"Batch priming changed predicate measurement binding");
                for(std::size_t n=count;n-->0;) {
                    auto expected=markvault_v31::cosine_half(q.data(),pointers[n],dim);
                    auto actual=markvault::cosine_half(q.data(),pointers[n],dim);
                    require(actual==expected,"Fused neighbor arithmetic changed original distance");
                    require(markvault::query_metric_cache.last_vector==pointers[n]||dim>2048,"Batch metric binding changed");
                    ++fused;
                }
                require(markvault::cosine_half(q.data(),q.data(),dim)==markvault_v31::cosine_half(q.data(),q.data(),dim),"Batch cache admitted outside vector");
                markvault::precompute_cosine_half(q.data(),nullptr,0,dim);
                require(markvault::query_metric_cache.batch_size==0,"Empty adjacency retained batch cache");
            }
        }
    std::cout<<fused<<" fused/scalar neighbor distances, tails/zeros/fallback/order/query boundaries=PASS\n";
    // Dense query visitation must be indistinguishable from the original hash
    // set, including duplicate slots, clearing, growth and returning to builds.
    using Visits=markvault::us::growing_hash_set_gt<std::uint32_t>;
    Visits sparse,dense;
    for(auto capacity:{1u,64u,210000u}) {
        sparse.clear();require(dense.begin_direct_slots(capacity),"Dense visit allocation failed");
        std::size_t unique=0;
        for(std::size_t i=0;i<100000;++i) {
            auto slot=rng()%capacity;
            require(sparse.reserve(sparse.size()+1)&&dense.reserve(dense.size()+32),"Visit reserve failed");
            bool prior=sparse.set(slot);
            require(dense.set(slot)==prior,"Dense visit duplicate changed");
            unique+=!prior;
            require(dense.test(slot)&&dense.size()==unique&&sparse.size()==unique,"Dense visit membership/count changed");
        }
        dense.clear();require(dense.size()==0,"Dense visits retained query count");
        for(std::size_t slot=0;slot<capacity;++slot) require(!dense.test(slot),"Dense query leaked visited slot");
        Visits moved(std::move(dense));
        require(bool(moved),"Dense visits failed move construction");
        require(!moved.set(capacity-1)&&moved.test(capacity-1),"Moved dense visits lost last slot");
        dense=std::move(moved);
        require(dense.test(capacity-1),"Dense visits failed move assignment");
        dense.end_direct_slots();require(dense.size()==0,"Dense guard did not restore hash mode");
        require(dense.reserve(2)&&!dense.set(900000)&&dense.set(900000),"Original sparse visit mode not restored");
    }
    std::cout<<"300,000 dense/hash visit operations, clear/growth/move/build restoration=PASS\n";
    for(int test=0;test<256;++test) {
        std::vector<std::uint64_t> allowed;
        for(std::uint64_t n=0;n<2048;++n) if(rng()%7<4) allowed.push_back(n);
        allowed.push_back(UINT64_MAX-1);allowed.push_back(UINT64_MAX);
        markvault::ArticleScope scope(&allowed);
        for(std::uint64_t n=0;n<2300;++n)
            require(scope.contains(n)==std::binary_search(allowed.begin(),allowed.end(),n),"Scope membership changed");
        require(scope.contains(UINT64_MAX),"Scope boundary overflow");++scopes;
    }
    std::vector<std::uint64_t> empty,duplicates{1,1,2,3,3,10};
    require(markvault::ArticleScope(nullptr).contains(7),"Unrestricted scope rejected");
    require(!markvault::ArticleScope(&empty).contains(7),"Empty scope admitted");
    for(std::uint64_t n=0;n<12;++n)
        require(markvault::ArticleScope(&duplicates).contains(n)==std::binary_search(duplicates.begin(),duplicates.end(),n),"Duplicate scope changed");
    using Item=std::pair<float,std::uint64_t>;
    for(auto limit:{1u,16u,128u,4800u}) {
        markvault::us::sorted_buffer_gt<Item> sorted,heap;
        require(sorted.reserve(limit)&&heap.reserve(limit),"Frontier allocation failed");
        for(std::uint64_t n=0;n<20000;++n) {
            Item item{float(rng()%512),n};
            if(sorted.size()<limit || item.first<sorted.top().first) {
                auto copy=item;sorted.insert(std::move(copy),limit);heap.insert_heap(std::move(item),limit);
            }
            require(sorted.size()==heap.size()&&sorted.top()==heap.heap_top(),"Heap changed frontier radius");
        }
        heap.finish_heap();
        require(std::equal(sorted.data(),sorted.data()+sorted.size(),heap.data()),"Heap changed sorted frontier");
    }
    std::cout<<checked<<" original/cached/norm-slot cosine cases, "<<scopes
             <<" scope sets and 80,000 frontier updates=PASS\n";
}
