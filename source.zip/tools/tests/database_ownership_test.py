"""Protect Room's WAL reader locks while native code performs vector math."""
import ctypes
import json
from pathlib import Path
import re
import sqlite3
import struct
import subprocess
import sys
import tempfile

project = Path(__file__).resolve().parents[2]
cpp = project / "app/src/main/cpp"
cmake = (cpp / "CMakeLists.txt").read_text()
assert "sqlite3" not in cmake.lower()
assert not (cpp / "vendor/sqlite").exists() or not any((cpp / "vendor/sqlite").iterdir())
for source in cpp.rglob("*"):
    if source.is_file() and source.suffix in (".c", ".cpp", ".h", ".hpp"):
        assert not re.search(r"\bsqlite3_(?:open|close|prepare|step)\b", source.read_text()), source
vm = (project / "app/src/main/java/com/tebogo/markvault/AppViewModel.kt").read_text()
for name, end, dao in (
    ("buildBlueSemanticRerankDocuments", "private suspend fun applyRerankInner", "dao.loadEmbeddingsForNotes"),
    ("semanticRerankCandidates", "private data class SemanticSearchOutcome", "dao.loadEmbeddingVectorsForNotes"),
):
    start = vm.index("private suspend fun " + name + "(")
    method = vm[start:vm.index(end, start)]
    assert dao in method and "ExactVectorScorer.score(" in method
    assert "writableDatabase.path" not in method and "StoredVectorScorer" not in method
assert "scoreStoredVectors" not in (project / "app/src/main/java/com/tebogo/markvault/search/NativeHnswBridge.kt").read_text()

if len(sys.argv) > 1:
    binary = Path(sys.argv[1])
    symbols = subprocess.check_output(["nm", "--defined-only", str(binary)], text=True)
    assert not re.search(r"\bsqlite3_\w+", symbols)
    assert "scoreStoredVectors" not in symbols
    exported = subprocess.check_output(["nm", "-D", "--defined-only", str(binary)], text=True)
    actual = set(re.findall(r"Java_com_tebogo_markvault_search_NativeHnswBridge_(\w+)", exported))
    bridge = (project / "app/src/main/java/com/tebogo/markvault/search/NativeHnswBridge.kt").read_text()
    expected = set(re.findall(r"external fun (\w+)\(", bridge))
    assert actual == expected and len(actual) == 13, (actual, expected)
    print("Production native binary: 13 matching JNI exports; no independent SQLite engine=PASS")
if "--binary-only" in sys.argv:
    sys.exit(0)

def checkpoint(path):
    code = 'import sqlite3,sys,json; c=sqlite3.connect(sys.argv[1],timeout=0); print(json.dumps(c.execute("PRAGMA wal_checkpoint(TRUNCATE)").fetchone())); c.close()'
    result = subprocess.run([sys.executable, "-c", code, str(path)], check=True, capture_output=True, text=True)
    return json.loads(result.stdout)

with tempfile.TemporaryDirectory() as directory:
    work = Path(directory)
    wrapper = work / "math.cpp"
    wrapper.write_text('#include "hnsw_core.hpp"\nextern "C" float score(float const* q, float const* v) { return markvault::exact_dot(q,v,4); }\n')
    subprocess.run(["g++", "-std=c++17", "-O3", "-ffp-contract=off", "-shared", "-fPIC", "-pthread",
                    "-I" + str(cpp), "-I" + str(cpp / "vendor/include"), str(wrapper), "-o", str(work / "math.so")], check=True)
    native = ctypes.CDLL(str(work / "math.so"))
    native.score.argtypes = [ctypes.POINTER(ctypes.c_float), ctypes.POINTER(ctypes.c_float)]
    native.score.restype = ctypes.c_float
    floats = ctypes.c_float * 4
    path = work / "room.db"
    writer = sqlite3.connect(path)
    writer.execute("PRAGMA journal_mode=WAL")
    writer.execute("PRAGMA wal_autocheckpoint=0")
    writer.executescript("CREATE TABLE notes(id INTEGER PRIMARY KEY,content TEXT); CREATE TABLE note_embeddings(noteId INTEGER,chunkIndex INTEGER,modelVersion TEXT,vector BLOB);")
    writer.executemany("INSERT INTO notes VALUES(?,?)", [(i, "note " + str(i) + "x" * 4000) for i in range(100)])
    writer.execute("INSERT INTO note_embeddings VALUES(1,0,'model',?)", (struct.pack("<4f", .5,.25,0,-.5),))
    writer.commit()
    reader = sqlite3.connect(path)
    reader.execute("BEGIN")
    cursor = reader.execute("SELECT id,content FROM notes ORDER BY id")
    assert cursor.fetchone()[0] == 0
    for iteration in range(8):
        writer.execute("UPDATE notes SET content=? WHERE id=99", ("updated " + str(iteration),))
        writer.commit()
        blob = reader.execute("SELECT vector FROM note_embeddings WHERE modelVersion=? AND noteId IN (?)", ("model", 1)).fetchone()[0]
        vector = floats(*struct.unpack("<4f", blob))
        for _ in range(64):
            assert native.score(floats(1,0,0,0), vector) == .5
        assert checkpoint(path)[0] == 1, "WAL truncated while Room-like reader was active"
    assert [row[0] for row in cursor.fetchall()] == list(range(1, 100))
    reader.close()
    assert checkpoint(path)[0] == 0
    assert writer.execute("PRAGMA integrity_check").fetchone()[0] == "ok"
    writer.close()
print("Room-owned reads plus 512 native scores preserve WAL locks during concurrent writes/checkpoints and cursor iteration; integrity=PASS")
