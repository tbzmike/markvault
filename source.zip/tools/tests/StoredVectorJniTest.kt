package com.tebogo.markvault.search

fun main(args: Array<String>) {
    val scores = StoredVectorScorer.score(args[0], "model", floatArrayOf(1f, 0f, 0f, 0f), listOf(4L, 3L, 2L, 1L))!!
    check(scores == listOf(StoredVectorScorer.Score(1, 1, 0.6f), StoredVectorScorer.Score(2, 0, -0.8f)))
    check(StoredVectorScorer.score(args[0], "model", floatArrayOf(1f,0f,0f,0f), emptyList())!!.isEmpty())
    check(StoredVectorScorer.score(args[0], "model' OR 1=1--", floatArrayOf(1f,0f,0f,0f), listOf(1L))!!.isEmpty())
    check(StoredVectorScorer.score("/missing/db", "model", floatArrayOf(1f), listOf(1L)) == null)
    check(StoredVectorScorer.score(args[0], "model", floatArrayOf(Float.NaN), listOf(1L)) == null)
    println("Production Kotlin/JNI stored-vector packet, chunk selection, model binding, dimensions, empty, missing DB=PASS")
}
