package com.tebogo.markvault.ui
import com.tebogo.markvault.data.SearchHit
// Frozen 5.5.30 list-builder calculation; only caller/local names are adapted.
fun legacySearchResultPresentation(query: String, results: List<SearchHit>, keywordFilterOn: Boolean, paraphrases: List<String>): SearchResultPresentation {
                    val cleanedQuery = query.removeSurrounding("\"").trim()
                    val highlightTokens = cleanedQuery.split(Regex("\\s+"))
                        .map { it.trim() }.filter { it.isNotEmpty() }.take(6)

                    // v5.4.76cc — LLM paraphrase terms for THIS query,
                    // if the on-device expander has recorded any. Feed
                    // them into the snippet renderer so words the LLM
                    // surfaced pick up a softer lavender background,
                    // mirroring the article-body `.llm-hit` treatment.
                    // Empty when the toggle is off, the model isn't
                    // installed, the query hasn't been submitted yet
                    // in this session, or the expander returned
                    // nothing.
                    val llmHighlightTokens: List<String> = paraphrases
                        .flatMap { it.split(Regex("\\s+")) }
                        .map { it.trim() }.filter { it.length >= 3 }
                        .distinctBy { it.lowercase() }.take(24)

                    // v5.4.14 — Keyword filter, redefined.
                    //
                    // What the user actually meant by "keyword filter"
                    // all along: a result must contain at least one
                    // consecutive 2-word PHRASE from the query — not
                    // just any 2 distinct query words scattered through
                    // the document. The previous "2 distinct words"
                    // rule let results pass that had "abraham" in one
                    // paragraph and "covenant" in a totally unrelated
                    // section, which is the noise the user wanted gone.
                    //
                    // Algorithm: take consecutive bigrams from the
                    // (cleaned, non-stopword-filtered) query tokens, and
                    // require any one to appear as a literal substring
                    // in the result's title or snippet. The snippet's
                    // FTS marker characters (⟦…⟧) are stripped before
                    // the substring check so they don't break matches.
                    //
                    // Single-word queries: filter is a no-op (nothing to
                    // form a bigram with).
                    val filterTokens = highlightTokens
                        .map { it.lowercase().replace(Regex("[^\\p{L}\\p{N}]"), "") }
                        .filter { it.isNotEmpty() }
                    val bigrams = if (filterTokens.size >= 2) {
                        (0 until filterTokens.size - 1).map { i ->
                            "${filterTokens[i]} ${filterTokens[i + 1]}"
                        }
                    } else emptyList()
                    val filteredResults = if (!keywordFilterOn || bigrams.isEmpty()) {
                        results
                    } else {
                        results.filter { hit ->
                            val haystack = (hit.title + " " + hit.snippet)
                                .replace("\u27E6", "")
                                .replace("\u27E7", "")
                                .lowercase()
                            bigrams.any { bg -> haystack.contains(bg) }
                        }
                    }
                    val hiddenCount = results.size - filteredResults.size

    return SearchResultPresentation(highlightTokens, llmHighlightTokens, filteredResults, hiddenCount)
}
