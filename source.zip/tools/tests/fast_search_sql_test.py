"""Execute production Room projections and compare blue pages with existing IVF pages."""
import ast
import re
import sqlite3
import time
from pathlib import Path

root = Path(__file__).resolve().parents[2]


def query(file, name):
    source = (root / "app/src/main/java/com/tebogo/markvault/data" / file).read_text()
    for match in re.finditer(r'@Query\((.*?)\)\s*suspend fun (\w+)\(', source, re.S):
        if match.group(2) == name:
            return "".join(ast.literal_eval(s) for s in re.findall(r'"(?:\\.|[^"\\])*"', match.group(1)))
    raise AssertionError(name)


db = sqlite3.connect(":memory:")
db.execute("CREATE TABLE notes(id INTEGER PRIMARY KEY, relPath TEXT, title TEXT, content TEXT, fileType TEXT)")
db.executemany("INSERT INTO notes VALUES(?,?,?,?,?)", (
    (i, f"folder/{i}.md", f"Article {i}", (f"Markdown article {i}\n" * 100), "md" if i % 2 else "html")
    for i in range(1, 42001)
))
ids = list(range(1, 42001, 210)) + [999999]
metadata_sql = query("Db.kt", "semanticSearchHitsByIds").replace("IN (:ids)", f"IN ({','.join('?' for _ in ids)})")
rows = db.execute(metadata_sql, ids).fetchall()
expected = [(i, f"folder/{i}.md", f"Article {i}", "", "md" if i % 2 else "html", None) for i in ids if i <= 42000]
assert sorted(rows) == expected
assert [c[0] for c in db.execute(metadata_sql, ids).description] == ["id", "relPath", "title", "snippet", "fileType", "score"]
assert "content" not in metadata_sql.lower()
db.execute("DELETE FROM notes WHERE id = ?", (ids[0],))
assert ids[0] not in {r[0] for r in db.execute(metadata_sql, ids)}

db.execute("CREATE TABLE media_embeddings(mediaId INTEGER, modelVersion TEXT, vector BLOB, PRIMARY KEY(mediaId,modelVersion))")
db.execute("CREATE INDEX index_media_embeddings_modelVersion_mediaId ON media_embeddings(modelVersion,mediaId)")
db.executemany("INSERT INTO media_embeddings VALUES(?,?,?)", ((i * 2, "a", i.to_bytes(8, "little")) for i in range(200000)))
db.executemany("INSERT INTO media_embeddings VALUES(?,?,?)", ((i * 2, "b", b"other-model") for i in range(300)))
old_sql = query("MediaItem.kt", "mediaEmbeddingPage")
new_sql = query("MediaItem.kt", "mediaEmbeddingAfter")
old, new = [], []
started = time.perf_counter()
for offset in range(0, 200000, 100):
    old.extend(db.execute(old_sql, dict(modelVersion="a", limit=100, offset=offset)).fetchall())
old_ms = (time.perf_counter() - started) * 1000
started = time.perf_counter()
after = -(2**63)
while True:
    page = db.execute(new_sql, dict(modelVersion="a", limit=1024, afterId=after)).fetchall()
    if not page:
        break
    new.extend(page)
    after = page[-1][0]
new_ms = (time.perf_counter() - started) * 1000
assert old == new and len(new) == 200000 and len({r[0] for r in new}) == 200000
assert db.execute(new_sql, dict(modelVersion="missing", limit=1024, afterId=-1)).fetchall() == []
assert db.execute(new_sql, dict(modelVersion="b", limit=1024, afterId=-1)).fetchall() == [(i * 2, b"other-model") for i in range(300)]
plan = db.execute("EXPLAIN QUERY PLAN " + new_sql, dict(modelVersion="a", limit=1024, afterId=0)).fetchall()
assert any("modelVersion_mediaId" in r[3] and "mediaId>?" in r[3] for r in plan)
assert not any("TEMP B-TREE" in r[3] for r in plan)
print(f"Room 42k article metadata projection and 200k media rows: identical rows/model isolation/indexed keyset=PASS; host OFFSET_ms={old_ms:.2f} keyset_ms={new_ms:.2f}")
