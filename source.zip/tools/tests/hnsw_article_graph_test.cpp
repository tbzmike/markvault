#include "hnsw_core.hpp"
#include <filesystem>
#include <fstream>
#include <iostream>
#include <map>
#include <random>
#include <set>

void require(bool value, char const* message) { if (!value) throw std::runtime_error(message); }
int main(int argc, char** argv) {
    auto root=argc>1?std::string(argv[1]):"/tmp/markvault_article_graph_test";
    std::filesystem::create_directories(root);
    std::mt19937 rng(487); std::normal_distribution<float> normal;
    std::size_t checks=0;
    for(std::size_t dim : {1,7,103,128,768}) {
        auto path=root+"/graph-"+std::to_string(dim)+".bin";
        std::vector<std::pair<std::uint64_t,std::vector<float>>> rows;
        for(std::uint64_t article=1; article<=90; ++article) {
            auto chunks=std::array<std::size_t,5>{1,4,5,17,33}[article%5];
            for(std::size_t c=0;c<chunks;++c) {
                std::vector<float> row(dim);
                for(auto& value:row) value=normal(rng);
                if(article==90) std::fill(row.begin(),row.end(),0);
                rows.emplace_back((article<<32)|c,std::move(row));
            }
        }
        markvault::Hnsw writer(dim,rows.size(),true,true);
        for(auto const& row:rows) writer.add(row.first,row.second.data(),dim);
        writer.remove(7ULL<<32); // Keep routing through a physical tombstone.
        {std::ofstream f(path,std::ios::binary);f.write("1234567",7);} writer.append(path.c_str());
        markvault::Hnsw managed(dim,0,false,true); managed.open(path.c_str(),7,false);
        markvault::us::index_dense_config_t config; config.enable_key_lookups=false;
        auto made=markvault::us::index_dense_t::make(markvault::sq8::metric(dim),config);
        markvault::checked(made); auto& index=made.index;
        auto opened=index.view(markvault::us::memory_mapped_file_t(path.c_str()),7); markvault::checked(opened);
        markvault::us::index_dense_t::values_proxy_t values(index);
        markvault::VectorNorms norms; norms.base=reinterpret_cast<std::uintptr_t>(values[index.cbegin()]);
        norms.stride=dim;norms.scalar_bytes=1;norms.inverse=true;
        for(auto it=index.cbegin();it!=index.cend();++it)
            norms.values.push_back(markvault::sq8::inverse_norm(float(markvault::sq8::norm(
                reinterpret_cast<markvault::sq8::Scalar const*>(values[it]),dim))));
        markvault::ArticleGraph graph(index,norms);
        std::vector<std::uint64_t> selected{2,7,29,90},empty;
        for(auto scope:std::array<std::vector<std::uint64_t> const*,3>{nullptr,&selected,&empty})
            for(int run=0;run<6;++run) {
                auto const& query=rows[(run*17+rows.size()-1)%rows.size()].second;
                std::vector<markvault::sq8::Scalar> encoded(dim);markvault::sq8::quantize(query.data(),encoded.data(),dim);
                auto inverse=markvault::sq8::inverse_norm(float(markvault::sq8::norm(encoded.data(),dim)));
                std::map<std::uint64_t,float> expected,observed;
                for(auto it=index.cbegin();it!=index.cend();++it) {
                    auto key=std::uint64_t((*it).key); if(key==index.free_key())continue;
                    auto article=key>>32; if(scope&&!std::binary_search(scope->begin(),scope->end(),article))continue;
                    auto d=markvault::sq8::distance_inverse(encoded.data(),reinterpret_cast<markvault::sq8::Scalar const*>(values[it]),dim,inverse,&norms);
                    auto found=expected.emplace(article,d);if(!found.second)found.first->second=std::min(found.first->second,d);
                }
                std::size_t scored=0;
                graph.search(encoded.data(),inverse,markvault::ArticleScope(scope),1000,
                    [&](std::uint64_t article,float distance){require(observed.emplace(article,distance).second,"Article measured twice");},scored);
                // Degenerate one-dimensional cosine ties can leave components
                // disconnected in the original directed HNSW. Check every
                // observed maximum, then require the manager's native recovery
                // to restore the entire selected scope, including those nodes.
                require(observed.size()<=expected.size(),"Article graph leaked a scope/tombstone");
                for(auto item:observed) {require(std::abs(expected.at(item.first)-item.second)<4e-7f,"Article graph omitted a chunk or changed SQ8 maximum");++checks;}
                auto actual=managed.article_candidates(query.data(),dim,600,200,scope);
                require(actual.exhaustive && actual.articles.size()==expected.size(),"Small-scope recovery lost an article");
                std::vector<std::pair<float,std::uint64_t>> ranked;
                for(auto item:expected)ranked.emplace_back(item.second,item.first);
                std::sort(ranked.begin(),ranked.end());
                for(std::size_t i=0;i<ranked.size();++i)require(actual.articles[i]==ranked[i].second,"Recovery changed complete article ranking");
                if(!expected.empty())require(actual.article_graph&&actual.article_frontier==600&&actual.passages==0&&actual.graph_memory_bytes>0,"Article mode telemetry missing");
            }
        auto invalid=norms;invalid.values.clear();bool rejected=false;
        try{markvault::ArticleGraph broken(index,invalid);}catch(std::invalid_argument const&){rejected=true;}
        require(rejected,"Invalid matrix accepted");
    }
    std::cout<<"Article graph all-chunk maximum/tails/zeros/tombstones/physical slots/repeated queries/scope/telemetry checks="<<checks<<" PASS\n";
}
