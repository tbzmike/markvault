import com.tebogo.markvault.llm.LlmStreamAccumulator
import kotlinx.coroutines.flow.flow
import kotlinx.coroutines.flow.takeWhile
import kotlinx.coroutines.flow.collect
import kotlinx.coroutines.runBlocking
import kotlinx.coroutines.delay
import kotlinx.coroutines.withTimeoutOrNull

fun main() = runBlocking {
    var sent = 0
    val accumulator = LlmStreamAccumulator(2, { text ->
        text.lines().map { it.trim() }.filter { it.length >= 3 }.distinct()
    })
    flow {
        for (chunk in listOf("God created life\n", "Why worship Jehovah\n", "unwanted generations\n")) {
            sent++
            emit(chunk)
        }
    }.takeWhile { accumulator.appendAndContinue(it) }.collect()
    check(sent == 2) { "Native-generator source kept running after desired 2 results: $sent" }
    check(accumulator.results(completedNormally = true).size == 2)

    val partial = LlmStreamAccumulator(3, { text ->
        text.lines().filter { it.isNotBlank() }
    })
    val timed = withTimeoutOrNull(60) {
        flow {
            emit("God makes promises\n")
            delay(400)
            emit("not reached\n")
        }.takeWhile { partial.appendAndContinue(it) }.collect()
        true
    }
    check(timed == null)
    check(partial.results(completedNormally = false) == listOf("God makes promises"))
    println("LLM streaming Flow early-stop and partial-timeout tests: PASS")
}
