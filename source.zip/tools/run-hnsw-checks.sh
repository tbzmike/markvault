#!/usr/bin/env bash
set -euo pipefail
project_dir="$(cd "$(dirname "$0")/.." && pwd)"
check_dir="$(mktemp -d)"
trap 'rm -rf "$check_dir"' EXIT

g++ -std=c++17 -O3 -ffp-contract=off -pthread \
  -I"$project_dir/app/src/main/cpp" \
  -I"$project_dir/app/src/main/cpp/vendor/include" \
  "$project_dir/tools/tests/hnsw_native_test.cpp" -o "$check_dir/native_test"
"$check_dir/native_test" "${1:-2000}" 384 "$check_dir/test.bin"
g++ -std=c++17 -O3 -ffp-contract=off -pthread \
  -I"$project_dir/app/src/main/cpp" -I"$project_dir/app/src/main/cpp/vendor/include" \
  "$project_dir/tools/tests/hnsw_query_test.cpp" -o "$check_dir/query_test"
"$check_dir/query_test"
python3 "$project_dir/tools/tests/hnsw_sql_test.py"
python3 "$project_dir/tools/tests/fast_search_sql_test.py"
python3 "$project_dir/tools/tests/blue_keyword_revision_test.py"
python3 "$project_dir/tools/tests/preservation_test.py"
python3 "$project_dir/tools/tests/database_ownership_test.py"
g++ -std=c++17 -O3 -ffp-contract=off -pthread \
  -I"$project_dir/app/src/main/cpp" \
  -I"$project_dir/app/src/main/cpp/vendor/include" \
  "$project_dir/tools/tests/hnsw_article_benchmark.cpp" -o "$check_dir/article_test"
"$check_dir/article_test" 4200 128 "$check_dir/articles.bin"
g++ -std=c++17 -O3 -ffp-contract=off -pthread \
  -I"$project_dir/app/src/main/cpp" \
  -I"$project_dir/app/src/main/cpp/vendor/include" \
  "$project_dir/tools/tests/hnsw_v26_comparison.cpp" -o "$check_dir/comparison_test"
"$check_dir/comparison_test" "$check_dir/articles.bin" 128 4200
g++ -std=c++17 -O3 -ffp-contract=off -pthread \
  -I"$project_dir/app/src/main/cpp" -I"$project_dir/app/src/main/cpp/vendor/include" \
  "$project_dir/tools/tests/hnsw_speed_benchmark.cpp" -o "$check_dir/speed_test"
"$check_dir/speed_test" "$check_dir/articles.bin" 128 4200

# Optional actual Kotlin/JNI manager checks. Supply installed JDK/Kotlin compiler paths.
if [[ -n "${MARKVAULT_JNI_INCLUDE:-}" && -n "${MARKVAULT_KOTLIN_COMPILER_CP:-}" ]]; then
  g++ -std=c++17 -O3 -ffp-contract=off -pthread -shared -fPIC \
    -I"$MARKVAULT_JNI_INCLUDE" -I"$MARKVAULT_JNI_INCLUDE/linux" \
    -I"$project_dir/app/src/main/cpp/vendor/include" \
    "$project_dir/app/src/main/cpp/hnsw_jni.cpp" -o "$check_dir/libmarkvault_hnsw.so"
  python3 "$project_dir/tools/tests/database_ownership_test.py" "$check_dir/libmarkvault_hnsw.so" --binary-only
  java com.sun.tools.javac.Main -d "$check_dir/jni-java" "$project_dir/tools/tests/NativeHnswBridge.java"
  java -cp "$check_dir/jni-java" com.tebogo.markvault.search.NativeHnswBridge "$check_dir/libmarkvault_hnsw.so"
  # Compile the actual standalone conversion from Embedder.kt without Android/ONNX dependencies.
  python3 - "$project_dir/app/src/main/java/com/tebogo/markvault/search/Embedder.kt" "$check_dir/EmbeddingConversion.kt" <<'PY'
import re, sys
from pathlib import Path
source = Path(sys.argv[1]).read_text()
method = re.search(r'^fun bytesToFloatArray\(.*?\n\}', source, re.M | re.S)
assert method is not None
Path(sys.argv[2]).write_text('package com.tebogo.markvault.search\nimport java.nio.ByteBuffer\nimport java.nio.ByteOrder\n' + method.group(0) + '\n')
PY
  python3 "$project_dir/tools/tests/extract_room_rerank_fixture.py" "$project_dir" "$check_dir"
  host_stubs=()
  for stub in "$project_dir/tools/tests/host-stubs/"*.kt; do
    if [[ "$stub" != */Log.kt ]]; then host_stubs+=("$stub"); fi
  done
  java -cp "$MARKVAULT_KOTLIN_COMPILER_CP" org.jetbrains.kotlin.cli.jvm.K2JVMCompiler \
    -no-stdlib -no-reflect -language-version 2.2 -jvm-target 17 \
    -cp "$MARKVAULT_KOTLIN_COMPILER_CP" -d "$check_dir/classes" \
    "${host_stubs[@]}" \
    "$check_dir/RoomRerankLog.kt" \
    "$check_dir/EmbeddingConversion.kt" \
    "$check_dir/RoomRerankData.kt" \
    "$check_dir/RoomRerankFixture.kt" \
    "$project_dir/tools/tests/HnswManagerTest.kt" \
    "$project_dir/tools/tests/SearchWorkTest.kt" \
    "$project_dir/tools/tests/FastSearchTest.kt" \
    "$project_dir/tools/tests/BluePassageKeywordTest.kt" \
    "$project_dir/tools/tests/RoomRerankTest.kt" \
    "$project_dir/tools/tests/OriginalPassageRanking.kt" \
    "$project_dir/tools/tests/IvfRegressionTest.kt" \
    "$project_dir/app/src/main/java/com/tebogo/markvault/search/AnnIndex.kt" \
    "$project_dir/app/src/main/java/com/tebogo/markvault/search/HnswIndex.kt" \
    "$project_dir/app/src/main/java/com/tebogo/markvault/search/SearchWorkPriority.kt" \
    "$project_dir/app/src/main/java/com/tebogo/markvault/search/SearchTimings.kt" \
    "$project_dir/app/src/main/java/com/tebogo/markvault/search/SearchMemo.kt" \
    "$project_dir/app/src/main/java/com/tebogo/markvault/search/SearchScopeMemo.kt" \
    "$project_dir/app/src/main/java/com/tebogo/markvault/search/FastSearchMemoryPolicy.kt" \
    "$project_dir/app/src/main/java/com/tebogo/markvault/search/BlueSearchPipeline.kt" \
    "$project_dir/app/src/main/java/com/tebogo/markvault/search/ExactVectorScorer.kt" \
    "$project_dir/app/src/main/java/com/tebogo/markvault/search/BluePassages.kt" \
    "$project_dir/app/src/main/java/com/tebogo/markvault/search/BlueKeywordRanking.kt" \
    "$project_dir/app/src/main/java/com/tebogo/markvault/search/TextChunker.kt" \
    "$project_dir/app/src/main/java/com/tebogo/markvault/search/QueryExpander.kt" \
    "$project_dir/app/src/main/java/com/tebogo/markvault/search/NativeHnswBridge.kt"
  java -Djava.library.path="$check_dir" -cp "$check_dir/classes:$MARKVAULT_KOTLIN_COMPILER_CP" \
    com.tebogo.markvault.search.HnswManagerTestKt
  java -Djava.library.path="$check_dir" -cp "$check_dir/classes:$MARKVAULT_KOTLIN_COMPILER_CP" \
    com.tebogo.markvault.search.FastSearchTestKt
  java -cp "$check_dir/classes:$MARKVAULT_KOTLIN_COMPILER_CP" \
    com.tebogo.markvault.search.IvfRegressionTestKt
  java -cp "$check_dir/classes:$MARKVAULT_KOTLIN_COMPILER_CP" \
    com.tebogo.markvault.search.BluePassageKeywordTestKt
  java -Djava.library.path="$check_dir" -cp "$check_dir/classes:$MARKVAULT_KOTLIN_COMPILER_CP" \
    com.tebogo.markvault.search.RoomRerankTestKt
  # Compare result presentation and scroll thresholds with frozen 5.5.30 behavior.
  java -cp "$MARKVAULT_KOTLIN_COMPILER_CP" org.jetbrains.kotlin.cli.jvm.K2JVMCompiler \
    -no-stdlib -no-reflect -language-version 2.2 -jvm-target 17 \
    -cp "$MARKVAULT_KOTLIN_COMPILER_CP" -d "$check_dir/ui-classes" \
    "$project_dir/tools/tests/host-stubs/SearchHit.kt" \
    "$project_dir/tools/tests/LegacyUiSearchPresentation.kt" \
    "$project_dir/tools/tests/LegacyScrollTracker.kt" \
    "$project_dir/tools/tests/UiSearchPresentationTest.kt" \
    "$project_dir/app/src/main/java/com/tebogo/markvault/ui/SearchScrollTracker.kt" \
    "$project_dir/app/src/main/java/com/tebogo/markvault/ui/SearchResultPresentation.kt"
  java -cp "$check_dir/ui-classes:$MARKVAULT_KOTLIN_COMPILER_CP" \
    com.tebogo.markvault.ui.UiSearchPresentationTestKt
  if [[ -n "${MARKVAULT_ORT_CP:-}" && -n "${MARKVAULT_MODEL_FIXTURE_DIR:-}" ]]; then
    java -cp "$MARKVAULT_KOTLIN_COMPILER_CP" org.jetbrains.kotlin.cli.jvm.K2JVMCompiler \
      -no-stdlib -no-reflect -language-version 2.2 -jvm-target 17 \
      -cp "$MARKVAULT_KOTLIN_COMPILER_CP:$MARKVAULT_ORT_CP" -d "$check_dir/model-classes" \
      "$project_dir/tools/tests/host-stubs/Android.kt" \
      "$project_dir/tools/tests/BlueRerankModelTest.kt" \
      "$project_dir/tools/tests/BlueRerankSessionTest.kt" \
      "$project_dir/tools/tests/LegacyBlueRerankEngine.kt" \
      "$project_dir/app/src/main/java/com/tebogo/markvault/search/FastSearchMemoryPolicy.kt" \
      "$project_dir/app/src/main/java/com/tebogo/markvault/search/BertTokenizer.kt" \
      "$project_dir/app/src/main/java/com/tebogo/markvault/search/RerankerCatalog.kt" \
      "$project_dir/app/src/main/java/com/tebogo/markvault/search/Reranker.kt" \
      "$project_dir/app/src/main/java/com/tebogo/markvault/search/BlueRerankEngine.kt"
    java -cp "$check_dir/model-classes:$MARKVAULT_KOTLIN_COMPILER_CP:$MARKVAULT_ORT_CP" \
      com.tebogo.markvault.search.BlueRerankModelTestKt "$MARKVAULT_MODEL_FIXTURE_DIR"
    java -cp "$check_dir/model-classes:$MARKVAULT_KOTLIN_COMPILER_CP:$MARKVAULT_ORT_CP" \
      com.tebogo.markvault.search.BlueRerankSessionTestKt "$MARKVAULT_MODEL_FIXTURE_DIR"
    python3 "$project_dir/tools/tests/extract_blue_rerank_fixture.py" "$project_dir" "$check_dir"
    java -cp "$MARKVAULT_KOTLIN_COMPILER_CP" org.jetbrains.kotlin.cli.jvm.K2JVMCompiler \
      -no-stdlib -no-reflect -language-version 2.2 -jvm-target 17 \
      -cp "$MARKVAULT_KOTLIN_COMPILER_CP:$MARKVAULT_ORT_CP" -d "$check_dir/vm-classes" \
      "$check_dir/BlueRerankVmFixture.kt" "$check_dir/VmContext.kt" \
      "$check_dir/VmApplication.kt" "$check_dir/VmLog.kt" "$check_dir/VmClock.kt" \
      "$project_dir/tools/tests/BlueRerankVmTest.kt" \
      "$project_dir/app/src/main/java/com/tebogo/markvault/search/BlueRerankEngine.kt" \
      "$project_dir/app/src/main/java/com/tebogo/markvault/search/Reranker.kt" \
      "$project_dir/app/src/main/java/com/tebogo/markvault/search/RerankerCatalog.kt" \
      "$project_dir/app/src/main/java/com/tebogo/markvault/search/ModelCatalog.kt" \
      "$project_dir/app/src/main/java/com/tebogo/markvault/search/BertTokenizer.kt" \
      "$project_dir/app/src/main/java/com/tebogo/markvault/search/FastSearchMemoryPolicy.kt" \
      "$project_dir/app/src/main/java/com/tebogo/markvault/search/SearchMemo.kt"
    java -cp "$check_dir/vm-classes:$MARKVAULT_KOTLIN_COMPILER_CP:$MARKVAULT_ORT_CP" \
      com.tebogo.markvault.search.BlueRerankVmTestKt "$MARKVAULT_MODEL_FIXTURE_DIR"
    if [[ -f "$MARKVAULT_MODEL_FIXTURE_DIR/bge-base.onnx" && -f "$MARKVAULT_MODEL_FIXTURE_DIR/bge-large.onnx" && -f "$MARKVAULT_MODEL_FIXTURE_DIR/minilm.onnx" ]]; then
      python3 "$project_dir/tools/tests/extract_query_fixture.py" "$project_dir" "$check_dir"
      java -cp "$MARKVAULT_KOTLIN_COMPILER_CP" org.jetbrains.kotlin.cli.jvm.K2JVMCompiler \
        -no-stdlib -no-reflect -language-version 2.2 -jvm-target 17 \
        -cp "$MARKVAULT_KOTLIN_COMPILER_CP:$MARKVAULT_ORT_CP" -d "$check_dir/query-classes" \
        "$check_dir/ActualQueryFacade.kt" \
        "$project_dir/tools/tests/host-stubs/Android.kt" \
        "$project_dir/tools/tests/BlueQueryModelTest.kt" \
        "$project_dir/tools/tests/LegacyOnnxBertEmbedderBackend.kt" \
        "$project_dir/app/src/main/java/com/tebogo/markvault/search/OnnxBertEmbedderBackend.kt" \
        "$project_dir/app/src/main/java/com/tebogo/markvault/search/ModelCatalog.kt" \
        "$project_dir/app/src/main/java/com/tebogo/markvault/search/BertTokenizer.kt"
      java -cp "$check_dir/query-classes:$MARKVAULT_KOTLIN_COMPILER_CP:$MARKVAULT_ORT_CP" \
        com.tebogo.markvault.search.BlueQueryModelTestKt "$MARKVAULT_MODEL_FIXTURE_DIR"
    fi
  fi
  if [[ -n "${MARKVAULT_JSON_CP:-}" && -n "${MARKVAULT_GSON_CP:-}" ]]; then
    java -cp "$MARKVAULT_KOTLIN_COMPILER_CP" org.jetbrains.kotlin.cli.jvm.K2JVMCompiler \
      -no-stdlib -no-reflect -language-version 2.2 -jvm-target 17 \
      -cp "$MARKVAULT_KOTLIN_COMPILER_CP:$MARKVAULT_JSON_CP:$MARKVAULT_GSON_CP" -d "$check_dir/saved-classes" \
      "$project_dir/tools/tests/host-stubs/"*.kt \
      "$project_dir/tools/tests/SavedSearchTimingTest.kt" \
      "$project_dir/tools/tests/SavedSearchReportTest.kt" \
      "$project_dir/tools/tests/LegacySavedSearchStore.kt" \
      "$project_dir/app/src/main/java/com/tebogo/markvault/search/SavedSearchStore.kt" \
      "$project_dir/app/src/main/java/com/tebogo/markvault/search/SavedSearchReport.kt" \
      "$project_dir/app/src/main/java/com/tebogo/markvault/search/ResultQueryProvenance.kt"
    java -cp "$check_dir/saved-classes:$MARKVAULT_KOTLIN_COMPILER_CP:$MARKVAULT_JSON_CP:$MARKVAULT_GSON_CP" \
      com.tebogo.markvault.search.SavedSearchTimingTestKt
    java -Xmx1400m -cp "$check_dir/saved-classes:$MARKVAULT_KOTLIN_COMPILER_CP:$MARKVAULT_JSON_CP:$MARKVAULT_GSON_CP" \
      com.tebogo.markvault.search.SavedSearchReportTestKt
  fi
fi
