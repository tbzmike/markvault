#!/usr/bin/env bash
set -euo pipefail
project_dir="$(cd "$(dirname "$0")/.." && pwd)"
check_dir="$(mktemp -d)"
trap 'rm -rf "$check_dir"' EXIT

g++ -std=c++17 -O3 -ffp-contract=off -pthread \
  -I"$project_dir/app/src/main/cpp" \
  -I"$project_dir/app/src/main/cpp/vendor/include" \
  "$project_dir/tools/tests/hnsw_native_test.cpp" -o "$check_dir/native_test"
"$check_dir/native_test" "${1:-2000}" 384 "$check_dir/test.bin"
python3 "$project_dir/tools/tests/hnsw_sql_test.py"
python3 "$project_dir/tools/tests/fast_search_sql_test.py"
python3 "$project_dir/tools/tests/blue_keyword_revision_test.py"
python3 "$project_dir/tools/tests/preservation_test.py"
gcc -O3 -fPIC -DSQLITE_ENABLE_FTS4=1 -DSQLITE_THREADSAFE=2 -DSQLITE_OMIT_LOAD_EXTENSION=1 -DSQLITE_DEFAULT_MEMSTATUS=0 \
  -c "$project_dir/app/src/main/cpp/vendor/sqlite/sqlite3.c" -o "$check_dir/sqlite3.o"
g++ -std=c++17 -O3 -ffp-contract=off -pthread \
  -I"$project_dir/app/src/main/cpp" -I"$project_dir/app/src/main/cpp/vendor/include" \
  "$project_dir/tools/tests/stored_vector_test.cpp" "$check_dir/sqlite3.o" -o "$check_dir/stored_test"
"$check_dir/stored_test" "$check_dir/vectors.db"
g++ -std=c++17 -O3 -ffp-contract=off -pthread \
  -I"$project_dir/app/src/main/cpp" \
  -I"$project_dir/app/src/main/cpp/vendor/include" \
  "$project_dir/tools/tests/hnsw_article_benchmark.cpp" -o "$check_dir/article_test"
"$check_dir/article_test" 4200 128 "$check_dir/articles.bin"
g++ -std=c++17 -O3 -ffp-contract=off -pthread \
  -I"$project_dir/app/src/main/cpp" \
  -I"$project_dir/app/src/main/cpp/vendor/include" \
  "$project_dir/tools/tests/hnsw_v26_comparison.cpp" -o "$check_dir/comparison_test"
"$check_dir/comparison_test" "$check_dir/articles.bin" 128 4200

# Optional actual Kotlin/JNI manager checks. Supply installed JDK/Kotlin compiler paths.
if [[ -n "${MARKVAULT_JNI_INCLUDE:-}" && -n "${MARKVAULT_KOTLIN_COMPILER_CP:-}" ]]; then
  g++ -std=c++17 -O3 -ffp-contract=off -pthread -shared -fPIC \
    -I"$MARKVAULT_JNI_INCLUDE" -I"$MARKVAULT_JNI_INCLUDE/linux" \
    -I"$project_dir/app/src/main/cpp/vendor/include" \
    "$project_dir/app/src/main/cpp/hnsw_jni.cpp" "$check_dir/sqlite3.o" -o "$check_dir/libmarkvault_hnsw.so"
  java com.sun.tools.javac.Main -d "$check_dir/jni-java" "$project_dir/tools/tests/NativeHnswBridge.java"
  java -cp "$check_dir/jni-java" com.tebogo.markvault.search.NativeHnswBridge "$check_dir/libmarkvault_hnsw.so"
  # Compile the actual standalone conversion from Embedder.kt without Android/ONNX dependencies.
  python3 - "$project_dir/app/src/main/java/com/tebogo/markvault/search/Embedder.kt" "$check_dir/EmbeddingConversion.kt" <<'PY'
import re, sys
from pathlib import Path
source = Path(sys.argv[1]).read_text()
method = re.search(r'^fun bytesToFloatArray\(.*?\n\}', source, re.M | re.S)
assert method is not None
Path(sys.argv[2]).write_text('package com.tebogo.markvault.search\nimport java.nio.ByteBuffer\nimport java.nio.ByteOrder\n' + method.group(0) + '\n')
PY
  java -cp "$MARKVAULT_KOTLIN_COMPILER_CP" org.jetbrains.kotlin.cli.jvm.K2JVMCompiler \
    -no-stdlib -no-reflect -language-version 2.2 -jvm-target 17 \
    -cp "$MARKVAULT_KOTLIN_COMPILER_CP" -d "$check_dir/classes" \
    "$project_dir/tools/tests/host-stubs/"*.kt \
    "$check_dir/EmbeddingConversion.kt" \
    "$project_dir/tools/tests/HnswManagerTest.kt" \
    "$project_dir/tools/tests/SearchWorkTest.kt" \
    "$project_dir/tools/tests/FastSearchTest.kt" \
    "$project_dir/tools/tests/StoredVectorJniTest.kt" \
    "$project_dir/tools/tests/BluePassageKeywordTest.kt" \
    "$project_dir/tools/tests/OriginalPassageRanking.kt" \
    "$project_dir/tools/tests/IvfRegressionTest.kt" \
    "$project_dir/app/src/main/java/com/tebogo/markvault/search/AnnIndex.kt" \
    "$project_dir/app/src/main/java/com/tebogo/markvault/search/HnswIndex.kt" \
    "$project_dir/app/src/main/java/com/tebogo/markvault/search/SearchWorkPriority.kt" \
    "$project_dir/app/src/main/java/com/tebogo/markvault/search/SearchTimings.kt" \
    "$project_dir/app/src/main/java/com/tebogo/markvault/search/SearchMemo.kt" \
    "$project_dir/app/src/main/java/com/tebogo/markvault/search/SearchScopeMemo.kt" \
    "$project_dir/app/src/main/java/com/tebogo/markvault/search/FastSearchMemoryPolicy.kt" \
    "$project_dir/app/src/main/java/com/tebogo/markvault/search/BlueSearchPipeline.kt" \
    "$project_dir/app/src/main/java/com/tebogo/markvault/search/ExactVectorScorer.kt" \
    "$project_dir/app/src/main/java/com/tebogo/markvault/search/BluePassages.kt" \
    "$project_dir/app/src/main/java/com/tebogo/markvault/search/BlueKeywordRanking.kt" \
    "$project_dir/app/src/main/java/com/tebogo/markvault/search/TextChunker.kt" \
    "$project_dir/app/src/main/java/com/tebogo/markvault/search/QueryExpander.kt" \
    "$project_dir/app/src/main/java/com/tebogo/markvault/search/StoredVectorScorer.kt" \
    "$project_dir/app/src/main/java/com/tebogo/markvault/search/NativeHnswBridge.kt"
  java -Djava.library.path="$check_dir" -cp "$check_dir/classes:$MARKVAULT_KOTLIN_COMPILER_CP" \
    com.tebogo.markvault.search.HnswManagerTestKt
  java -Djava.library.path="$check_dir" -cp "$check_dir/classes:$MARKVAULT_KOTLIN_COMPILER_CP" \
    com.tebogo.markvault.search.FastSearchTestKt
  java -cp "$check_dir/classes:$MARKVAULT_KOTLIN_COMPILER_CP" \
    com.tebogo.markvault.search.IvfRegressionTestKt
  java -cp "$check_dir/classes:$MARKVAULT_KOTLIN_COMPILER_CP" \
    com.tebogo.markvault.search.BluePassageKeywordTestKt
  python3 - "$check_dir/fixture.db" <<'PY'
import sqlite3, struct, sys
c = sqlite3.connect(sys.argv[1])
c.executescript("PRAGMA journal_mode=WAL; CREATE TABLE notes(id INTEGER PRIMARY KEY,title TEXT,content TEXT); CREATE VIRTUAL TABLE notes_fts USING fts4(title,content,content='notes',tokenize=unicode61); CREATE TABLE note_embeddings(noteId INTEGER,chunkIndex INTEGER,modelVersion TEXT,vector BLOB,PRIMARY KEY(noteId,chunkIndex,modelVersion)); CREATE INDEX vectors_idx ON note_embeddings(modelVersion,noteId);")
for row in [(1,0,'model',struct.pack('<4f',.1,.2,.3,.4)),(1,1,'model',struct.pack('<4f',.6,.2,.3,.4)),(2,0,'model',struct.pack('<4f',-.8,.2,.3,.4)),(3,0,'model',b'x'),(4,0,'other',struct.pack('<4f',1,.2,.3,.4))]:
    c.execute('INSERT INTO note_embeddings VALUES(?,?,?,?)',row)
c.commit(); c.close()
PY
  java -Djava.library.path="$check_dir" -cp "$check_dir/classes:$MARKVAULT_KOTLIN_COMPILER_CP" \
    com.tebogo.markvault.search.StoredVectorJniTestKt "$check_dir/fixture.db"
  if [[ -n "${MARKVAULT_ORT_CP:-}" && -n "${MARKVAULT_MODEL_FIXTURE_DIR:-}" ]]; then
    java -cp "$MARKVAULT_KOTLIN_COMPILER_CP" org.jetbrains.kotlin.cli.jvm.K2JVMCompiler \
      -no-stdlib -no-reflect -language-version 2.2 -jvm-target 17 \
      -cp "$MARKVAULT_KOTLIN_COMPILER_CP:$MARKVAULT_ORT_CP" -d "$check_dir/model-classes" \
      "$project_dir/tools/tests/host-stubs/Android.kt" \
      "$project_dir/tools/tests/BlueRerankModelTest.kt" \
      "$project_dir/app/src/main/java/com/tebogo/markvault/search/BertTokenizer.kt" \
      "$project_dir/app/src/main/java/com/tebogo/markvault/search/RerankerCatalog.kt" \
      "$project_dir/app/src/main/java/com/tebogo/markvault/search/Reranker.kt" \
      "$project_dir/app/src/main/java/com/tebogo/markvault/search/BlueRerankEngine.kt"
    java -cp "$check_dir/model-classes:$MARKVAULT_KOTLIN_COMPILER_CP:$MARKVAULT_ORT_CP" \
      com.tebogo.markvault.search.BlueRerankModelTestKt "$MARKVAULT_MODEL_FIXTURE_DIR"
  fi
  if [[ -n "${MARKVAULT_JSON_CP:-}" ]]; then
    java -cp "$MARKVAULT_KOTLIN_COMPILER_CP" org.jetbrains.kotlin.cli.jvm.K2JVMCompiler \
      -no-stdlib -no-reflect -language-version 2.2 -jvm-target 17 \
      -cp "$MARKVAULT_KOTLIN_COMPILER_CP:$MARKVAULT_JSON_CP" -d "$check_dir/saved-classes" \
      "$project_dir/tools/tests/host-stubs/"*.kt \
      "$project_dir/tools/tests/SavedSearchTimingTest.kt" \
      "$project_dir/app/src/main/java/com/tebogo/markvault/search/SavedSearchStore.kt" \
      "$project_dir/app/src/main/java/com/tebogo/markvault/search/ResultQueryProvenance.kt"
    java -cp "$check_dir/saved-classes:$MARKVAULT_KOTLIN_COMPILER_CP:$MARKVAULT_JSON_CP" \
      com.tebogo.markvault.search.SavedSearchTimingTestKt
  fi
fi
