#!/usr/bin/env bash
set -euo pipefail
project_dir="$(cd "$(dirname "$0")/.." && pwd)"
check_dir="$(mktemp -d)"
trap 'rm -rf "$check_dir"' EXIT

g++ -std=c++17 -O3 -pthread \
  -I"$project_dir/app/src/main/cpp" \
  -I"$project_dir/app/src/main/cpp/vendor/include" \
  "$project_dir/tools/tests/hnsw_native_test.cpp" -o "$check_dir/native_test"
"$check_dir/native_test" "${1:-2000}" 384 "$check_dir/test.bin"
python3 "$project_dir/tools/tests/hnsw_sql_test.py"

# Optional actual Kotlin/JNI manager checks. Supply installed JDK/Kotlin compiler paths.
if [[ -n "${MARKVAULT_JNI_INCLUDE:-}" && -n "${MARKVAULT_KOTLIN_COMPILER_CP:-}" ]]; then
  g++ -std=c++17 -O3 -pthread -shared -fPIC \
    -I"$MARKVAULT_JNI_INCLUDE" -I"$MARKVAULT_JNI_INCLUDE/linux" \
    -I"$project_dir/app/src/main/cpp/vendor/include" \
    "$project_dir/app/src/main/cpp/hnsw_jni.cpp" -o "$check_dir/libmarkvault_hnsw.so"
  java -cp "$MARKVAULT_KOTLIN_COMPILER_CP" org.jetbrains.kotlin.cli.jvm.K2JVMCompiler \
    -no-stdlib -no-reflect -language-version 2.2 -jvm-target 17 \
    -cp "$MARKVAULT_KOTLIN_COMPILER_CP" -d "$check_dir/classes" \
    "$project_dir/tools/tests/host-stubs/"*.kt \
    "$project_dir/tools/tests/HnswManagerTest.kt" \
    "$project_dir/app/src/main/java/com/tebogo/markvault/search/HnswIndex.kt" \
    "$project_dir/app/src/main/java/com/tebogo/markvault/search/NativeHnswBridge.kt"
  java -Djava.library.path="$check_dir" -cp "$check_dir/classes:$MARKVAULT_KOTLIN_COMPILER_CP" \
    com.tebogo.markvault.search.HnswManagerTestKt
fi
