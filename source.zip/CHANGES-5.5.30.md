# MarkVault 5.5.30 (version code 479)

## Search latency and variability

5.5.29 created up to four separate copies of the selected reranker model. The pool identity included its worker count, so a change in available memory could discard the complete pool and reload every model copy. Its speculative preparation also ran alongside query embedding, even when the final rerank scores were already cached. These are verified sources of avoidable latency in the previous implementation; the specific 14-second phone search has not been profiled here.

5.5.30 changes the blue HNSW execution path:

- One CPU ONNX session shares its immutable model weights between up to four concurrent batch-one Run calls. Each call owns its input tensors and output result. Worker-count changes reuse the session; model/asset revisions replace it. A work queue distributes remaining passages instead of assigning a fixed document stride to each worker.
- The worker budget accounts for one resident model and conservative per-call workspace, with a 512 MiB minimum reserve that grows with the embedding model. Low-memory and Java-heap guards remain active. Low-RAM devices can use one bounded worker when this budget permits it.
- Speculative reranker preparation no longer runs alongside query embedding. Fully memoized reranking can finish without loading an unloaded reranker.
- ONNX queries issued by blue HNSW use at most two intra-op CPU threads and disable idle spinning. The original IVF/indexing entry point explicitly retains the original default options. Switching between these modes serializes inference and session replacement. Memory cleanup retires a busy query session after its native call completes.
- Exact-input blue query and rerank memo limits increase to 64 vectors and 512 scores with a 30-minute lifetime. Keys still include the selected embedding-engine identity or reranker/model-asset revision and the exact query/document; changed input does not reuse an old score. Notes/keyword freshness remains governed by its unchanged database revision.
- Performance logs record blue reranker workers, uncached pairs, resident sessions, model loads, and elapsed time.

The selected reranker, all 30 rerank candidates, individual sequence lengths, 256-token rerank limit, 512-token query limit, preprocessing, pooling, normalization, HNSW candidate budget, and FP32 vector rescoring remain intact. No model substitution, candidate/window reduction, or early completion is used.

ONNX Runtime's [architecture documentation](https://onnxruntime.ai/docs/reference/high-level-design.html#key-design-decisions) supports concurrent Run calls on one session. This implementation uses its CPU provider, and the actual L12/L6 catalog models were tested with ONNX Runtime 1.19.2.

## Measurements and verification

These are **host CPU measurements, not phone search times**. All inference comparisons below used actual production Kotlin methods and downloaded catalog models. The reranker comparisons issued distinct queries and did not use inference memo hits.

| Measurement | 5.5.29 | 5.5.30 |
| --- | ---: | ---: |
| L12 model preparation across six worker-budget changes | 1,568 ms | 102 ms |
| L6 model preparation across six worker-budget changes | 636 ms | 46 ms |
| L12 inference across the six 30-document requests | 3,072 ms | 2,292 ms |
| L6 inference across the six 30-document requests | 1,475 ms | 1,102 ms |
| Model loads in the new six-budget sequence | Pool replaced on every count change | One session load |

Warm blue BGE-base query inference was 8–12 ms in the final short-query host cases; the first query included a roughly 150 ms model load. These stage measurements do not establish the completed search time on an Android phone.

Passed checks:

- Shared-session L12/L6 comparison against frozen 5.5.29: all 360 tested scores had zero observed difference and identical order. The original default reranker comparison also passed 300 pairs. Cancellation, retirement during in-flight work, revision changes, empty documents and missing models passed.
- Actual original/default/blue query comparison: 26,112 vector-element comparisons across MiniLM, BGE-base and BGE-large passed a 0.00001 tolerance. Short-query cases reported zero difference. Long input, default-option restoration, repeated warm queries, concurrent mode switches, in-flight unload, cancellation, missing models and the actual facade's MediaPipe routing passed. MediaPipe's native runtime was not executed in the host fixture.
- The actual ViewModel worker/memo/scoring helpers compile and pass checks for complete memo reuse, one changed document, one-worker headroom, pressure fallback, reuse after an unloaded session, and model switching. A completely cached rerank does not reload the model.
- The complete native/Kotlin/SQL suite passes: original IVF build/search/probes/edit/delete/model isolation/reopen/failed and cancelled rebuilds; HNSW scopes, synchronization, deltas and atomic snapshots; all 7,872 FP32 scorer comparisons; keyword revisions; cache/coalescing and request cancellation; frozen passage/keyword/chunk selection; Room rerank reads; and saved-search backward compatibility.
- The 5.5.29 database correction remains intact: live vector reads belong to Room, the native binary has 13 matching JNI exports and no independent SQLite engine, and WAL locks/database integrity pass concurrent-write/checkpoint tests.
- The 5.5.24 guard verifies 266 byte-identical files, 563 protected original ViewModel method/policy blocks, and 106 original DAO queries. The two intentional embedding-runtime changes have separate original-code and mathematical-forward pins. 309 pinned 5.5.27 files and the original warm-retention policy remain unchanged.

Markdown, HTML rendering, highlighting, reader/navigation UI, primary IVF implementation, database schema and DAO queries, model catalog, embedding/library-indexing service, HNSW graph files/synchronization, backup/restore, expansion/LLM controls, blue/exclusive ANN toggles, media and saved-search formats were not edited.

The full Android APK build could not be completed because the Google SDK/Android Gradle dependency endpoints timed out in this environment. The changed production engines, facade and ViewModel helpers were compiled and exercised in the host fixtures. Device UI, completed phone-search latency and a subsecond target still require on-device measurement. Cold model loading, operating-system memory pressure, ongoing indexing or exact-scan fallback can still add time; the app keeps its correctness and memory safeguards.

## Build and use

Build and install 5.5.30 over the existing version and use the existing blue HNSW toggle. Existing embeddings and HNSW indexes remain compatible; this update requires no re-embedding or index rebuild. Perform a new search to measure the update; restored saved-search cards retain the duration of their original execution.

Run `bash tools/run-hnsw-checks.sh`. Actual Kotlin/JNI checks use `MARKVAULT_JNI_INCLUDE` and `MARKVAULT_KOTLIN_COMPILER_CP`; saved-search checks also use `MARKVAULT_JSON_CP`. Real-model checks use `MARKVAULT_ORT_CP` and `MARKVAULT_MODEL_FIXTURE_DIR` containing `reranker-l12.onnx`, `reranker-l6.onnx`, and `reranker-vocab.txt`. Query model checks additionally use `minilm.onnx`, `bge-base.onnx`, `bge-large.onnx` and their corresponding `*-vocab.txt` files, sourced from the unchanged catalog URLs. The source archive excludes model weights, SDKs and build products and retains the verified past timestamps needed to avoid the earlier Ninja regeneration failure.
