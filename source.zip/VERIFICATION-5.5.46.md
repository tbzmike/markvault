# MarkVault 5.5.46 — Verification

- Baseline: 5.5.45 source.zip, 2,112,080 bytes, 420 files.
- Source preservation: 412 unchanged; 8 modified by this feature; 0 removed; 3 new test/report files. No unrelated source files modified.
- Model isolation regression: PASS (model-scoped article and media SQL, UI and background sync gating, notification action wiring, scoped index/file deletion, service worker cancellation/join).
- Existing search card separation regression: PASS.
- Existing larger native/database regression command: TIMED OUT without complete results; do not count as pass.
- Kotlin/Android Gradle build: NOT AVAILABLE in this container (no Android SDK/Gradle runtime configured). Requires a green GitHub Actions workflow.
- On-device thermal, multi-model sync, notification controls, and actual deletion: NOT TESTED.

## Critical manual checks after GitHub compiles
1. Keep BGE-base enabled and selected. Disable MiniLM while its synchronization is active; its model must stop receiving embeddings, while BGE-base still synchronizes.
2. Disable an idle installed model and make a library edit; verify no synchronization pass for that disabled model.
3. Re-enable MiniLM and confirm existing MiniLM embeddings are still available, then new changes synchronize.
4. Pause an in-progress pass from notification; verify CPU drops, progress is retained and a Resume action appears. Resume, and confirm no duplicate work. Stop, then restart and confirm previously saved note embeddings are reused.
5. Delete only MiniLM, confirming the warning. Verify its weights, note/media vectors and IVF/HNSW indexes are deleted; other models' counts and files must remain unchanged.
6. Restart app; verify disabled model setting persists and cannot be selected.
7. Confirm no regressions in keyword search, HNSW/IVF, question awareness, saved search, expansion indicators, dark/light cards.
