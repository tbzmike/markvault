# MarkVault 5.5.43 — Less search-lifecycle overhead

Baseline: the corrected, source-verified 5.5.42 archive (versionCode 491).

## Changes

1. **Conditional routine memory cleanup:** Shortly after completed searches, sample Java heap plus Android system/PSS memory and decide whether routine teardown can safely be skipped. The new small pure-Kotlin `SearchCleanupPolicy` requires all conditions: no resident LLM or T5 engine, reusable lightweight/HNSW session, Java heap below 60% of its limit, no system low-memory flag, at least 512 MiB system available, and process PSS below available RAM.
2. **Keep safety-critical cleanup:** Memory-pressure and explicit reset cleanup are unchanged. When safe reuse is not verified, ordinary post-search cleanup continues to use the prior exhaustive behavior and 1.5-second grace period. LiteRT-LM and T5 are *not* kept resident through this optimization because of their large native memory consumption.
3. **Earlier completion for safe searches:** On a safe-skip search, the post-search completion handshake finishes after a 350 ms check rather than waiting for the full 1500 ms teardown window.
4. **Avoid redundant scope-label DB reads:** For a validated deep single-scope search, label the finished hits using the already-verified selected partition; don't read and hash all 20,000 first-scope IDs again. Dual/all/shallow search retains the full membership lookup.
5. **Deconflict media work:** Existing caption, cached-media, and JW media search is still performed, but is started 2.3 seconds after the foreground article search is idle instead of 360 ms, avoiding competition with initial result rendering and most post-search cleanup.
6. **Persisted-search diagnostics:** Log time spent on saved-result serialization/storage and include the stage in in-memory search timings. Persistence remains synchronous-to-the-search-result publication and durable; saved results and source provenance are unchanged.
7. **Version:** 5.5.43, code 492.

## Deliberately unchanged

Native HNSW and IVF search, query embedding/reranking and fusion, search-result ordering, query expansion and color legends, highlighting, card spacing/borders/numbering, background search saving semantics, on-demand media results, explicit memory reset, 95% emergency pause/release, and navigation memory cleanup.

## Risks and verification limits

The 2.3-second idle media delay is a deliberate latency/scrolling-smoothness tradeoff. No benchmark of Android on-device wall time or full release APK compile was possible without the Android SDK/Gradle. Results must be tested on device after GitHub Actions gives a green build. Repeated search and navigation under memory pressure deserve special testing.
