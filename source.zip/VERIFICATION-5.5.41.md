# MarkVault 5.5.41 verification

This source archive is derived from the provided MarkVault 5.5.40 `source.zip`.

- Increment `app/build.gradle.kts` to versionName `5.5.41`, versionCode `490`.
- Change `SearchScreen.kt` only in the result-card styles, native borders, rank badge, and contrast-related presentation. Existing ranking and engine code is unmodified.
- Add `CHANGES-5.5.41.md`, `VERIFICATION-5.5.41.md`, and `tools/tests/search_result_card_visual_test.py`.
- All other existing source and artifact files must compare **byte-identically** to the previous 5.5.40 archive.
- `tools/tests/QueryExpansionPresentationTest.kt` must continue to pass.
- `tools/tests/search_result_card_visual_test.py` must pass with a minimum 4.5:1 text-to-card-background contrast for all parsed built-in schemes.
- All ZIP entries must pass CRC integrity testing.

The test of color calculations uses Python equivalents of Compose `lerp` and `Color.luminance()` to exercise representative built-in palettes; it does **not** replace Android rendering, compile or interaction testing.

**Release build not verified locally.** GitHub CI is required for Android compilation and a device is required for actual look-and-feel checks.
