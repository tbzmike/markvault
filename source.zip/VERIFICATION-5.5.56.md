# MarkVault 5.5.56 verification

- PASS: host Kotlin compilation of the actual backup manager, portable file/state helpers and ZIP reader with Android/Room interface stubs; not an Android APK build.
- PASS: simulated provider appending `.txt` for `text/plain` Markdown, numbered filenames, a normalized folder name, actual-ID mapping, preserved Markdown suffixes and stable retry.
- PASS: generic MIME appending a wrong suffix is retried using Markdown MIME; only the newly created empty document is deleted.
- PASS: provider returning a pre-existing ID cannot overwrite or delete the existing file.
- PASS: file/folder name clashes and repeat restoration, same-content distinct archive entries with colliding provider names, unsupported indexed suffix fails safely with file-stage rollback.
- PASS: existing 5.5.52/54 simulated duplicate names/folders, same-document duplicate listing, shared Obsidian conflict handling, idempotent repeats, 1,200 collision cases.
- PASS: 65,540-entry ZIP64, selective/streaming reads, checksums, failed consumer not retried, level-9 lossless ZIP round trip.
- PASS: highlight navigation, saturated FTS4 search accuracy, model isolation, HNSW SQL, and result-card separation regression checks.
- Preservation: version 5.5.55 baseline has 480 original entries; four modified (three production files and one test stub), none deleted. 457/457 entries from 5.5.51 retained. The only files changed relative to 5.5.51 are version metadata, BackupManager, PortableBackupFiles, and the SettingsScreen backup-description updates already introduced in later versions. Search engines, both readers, embedding and ANN code, app/background services, and database/schema implementation unchanged in this update.
- Reproduce: `bash tools/tests/portable_provider_rename_5_5_56_test.sh`. Historical tests that assert exact older version numbers/obsolete method names are retained as historical tests.
- No full Android SDK build or physical two-phone restore was performed. The previous GitHub build (run 44132776922) is successful; this does not verify the new archive. Obtain a successful CI build before installing. A real restore must verify files, note mapping, embeddings and ANN reuse before relying on the backup as the only copy.
