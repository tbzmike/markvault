# MarkVault 5.5.49 — Search idle CPU & heap policy

Baseline: 5.5.48, version code 497. New: 5.5.49, code 498.

## Changes

- A completed search now finishes model teardown in its search lifecycle, after reranking and durable saved-session persistence, and **before** publishing `searchBusy=false`. The delayed 350/1500 ms post-search model/GC job is removed. The background search service completes normally without a pending cleanup timer.
- Heap GC is requested **once** in the normal completion path only if reranking really occurred and Auto Free Memory is enabled. Manual Free Memory remains unchanged. The existing high-memory/low-memory emergency safeguards remain active even without reranking.
- Finished searches unload T5 and LLM query-expansion native sessions, except that LLM teardown is suppressed while the separate Chat assistant is generating. HNSW/IVF mapped indexes and stored embeddings are untouched and remain available.
- Removed routine forced GC calls between exact-vector search partitions, before automatic rerank, and during manual rerank embedding. Manual rerank also finalizes its own inference before marking its operation complete.
- Home navigation resets UI query/results without triggering a native-model unload/GC. Ordinary navigation no longer schedules routine memory clears. Navigation-triggered media preparation releases native resources only under significant heap pressure.
- Search-bar AI brain pulse now animates **only during an active search**, not while open and idle. Delayed media searches are cancelled when the Search screen is backgrounded; passive online media results no longer schedule semantic-media embedding jobs 60 seconds afterward.
- Deferred optional HNSW graph prewarming, app-launch index self-healing builds, and app-launch media semantic indexing. Manual model switching/embedding synchronization, model disable and Pause/Resume/Stop remain intact. Model indexing can be resumed explicitly; stale snapshots remain subject to existing exact-vector fallback. Explicit media-cache operations continue to schedule maintenance with existing thermal and charging guards.

## Trade-offs and limits

- The first HNSW search after launch may take longer because optional prewarming was removed. If an index requires reconstruction, use existing manual embedding/index synchronization; automatic startup repair no longer wakes the device.
- Manual embedding synchronization, active media playback, user-triggered media caching and other explicitly enabled features can still consume CPU. Android OS low-memory callbacks and the 95% heap safety guard are preserved.
- Search-result media lookup remains available while the Search screen is **visible**; it is a finite user-facing media search and is cancelled when backgrounded. This update does not guarantee zero CPU use by Android or every app service.
- Full Android APK compilation and phone-temperature measurements have not been performed in this environment. Use GitHub Actions and device profiling to verify real-world performance.
