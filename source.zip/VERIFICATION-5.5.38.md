# MarkVault 5.5.38 verification

## Identity, builds and preservation

The authoritative baseline is the delivered 5.5.37 ZIP, SHA-256 `006a267d65983746817219767b89f3408a95022f30ff1cf26601a83fe50d1fc4`, containing 391 source files. Version 5.5.38 uses version code 487. Room schema remains 24, HNSW snapshot format remains 3, and format-2 compatibility remains available. The native candidate packet changes from version 4 to version 5; Kotlin and Java/JNI checks validate the same 11-field header. The 13 native entry points are unchanged.

The source preservation guard checks all 391 baseline files, including exact inverse deltas for 11 reviewed files. All other baseline files remain byte-identical. Earlier guards still check 563 protected original method/policy blocks and 106 original DAO queries, including the 5.5.24 Markdown/HTML/reader/library/backup/UI features. Query inference, reranker inference, embedding preprocessing, final FP32 scoring, Room schema/queries and the original IVF implementation are unchanged.

Both `:app:assembleDebug` and `:app:assembleRelease` pass. The clean verification build completed in 8m25s; completed source recompilation passed in 3m15s, and the final native safety adjustment passed in 1m06s. Toolchain: Java 17, Gradle 8.7, SDK 35, NDK 27.2.12479018 and CMake 3.22.1. Final APK checks validate signatures, version 5.5.38/code487, all four ABIs, 13 matching JNI exports and at least 16-KiB ELF LOAD alignment. APKs, toolchains and build caches are excluded from source.zip.

Generated debug and release Room code still uses Room-owned vector cursors and the `notes(lastModified,id)` covering index. The native library does not open an independent SQLite engine.

## New article traversal

The read-only runtime graph groups every live passage by its article ID. Each article retains all SQ8 row references and the union of its persisted passage edges at every graph level. Distances take the best cosine over all chunks; no centroid or first-chunk substitute is used. Four-row integer kernels reuse query loads, with correct scalar tails. Deleted passage nodes remain as routing vertices and never enter candidates.

The original 4,800-passage frontier is replaced by an article frontier in collections averaging at least four live chunks per article. For five chunks per article and 600 requested candidates, it uses a 600-article frontier. For four chunks, it widens to 750 articles. Candidate count stays 600 in both cases; final scoring still reads all persisted FP32 chunks for those candidates. Collections averaging fewer than four chunks keep the original passage traversal. Tests exposed recall regressions when those collections used a narrow article beam, so that configuration is not shipped.

The overlay reuses the mapped SQ8 matrix and is constructed once per loaded snapshot. Opening a changed generation, unloading a model or modifying a mutable index invalidates it. Its estimated additional allocated storage in the 210,000-chunk fixture is 14,223,084 bytes (about 13.6 MiB). It does not persist extra matrices or require re-embedding. A `bad_alloc` during overlay construction leaves the original passage path available. Index corruption and invalid input still fail through the existing native/Kotlin fallback handling.

The saved report shows **HNSW SQ8 article graph** when the new traversal actually runs. The unchanged SQ8 and FP16 fallback labels identify their own paths. Diagnostic logs contain the article/passage frontier and overlay bytes.

## Full-scale speed and recall

The primary fixture contains 42,000 generated articles, five chunks each: 210,000 vectors at 768 dimensions. A frozen, independently pinned 5.5.37 implementation reads the same SQ8 snapshot as the new implementation. Twenty-four queries include 12 sampled passages and 12 unrelated random vectors. Full, first-20,000, second-22,000, sparse and empty scopes, with three alternating old/new trials, yield 360 comparisons. Timing excludes the first warm-up round and excludes snapshot preparation. Recall uses an exhaustive FP32 best-chunk article oracle over 72 nontrivial query/scope trials.

| Graph measurement | 5.5.37 passage graph | 5.5.38 article graph |
|---|---:|---:|
| Full-library median | 4.573 ms | 2.390 ms |
| Full-library p95 | 7.121 ms | 3.915 ms |
| Full-library thread CPU median | 4.572 ms | 2.389 ms |
| Partition median | 10.221 ms | 4.999 ms |
| Partition p95 | 21.743 ms | 9.839 ms |

Full-library median decreases about 48%, and partition median about 51%. Smaller 21,000-chunk/128-dimension trials show roughly fourfold improvement. These are host graph benchmarks, not device or total-search timings.

| Mean candidate recall | Passage graph | Article graph |
|---|---:|---:|
| Top 10 | 87.500% | 89.444% |
| Top 50 | 87.417% | 88.667% |
| Top 200 | 87.271% | 87.896% |

Candidate count, scope membership and exhaustive-recovery coverage pass. Mean recall passes the declared gate at each size: no loss exceeding 0.5 percentage points against the frozen baseline. Individual approximate candidate lists can worsen despite those aggregate gains. For example, an unrelated random full-scope query loses 13/50 to 4/50 and 61/200 to 33/200; these declines are printed rather than hidden. The synthetic checks do not establish accuracy on the user's embeddings.

Additional comparisons:

- 42,000 articles with four chunks each, 168,000 vectors at 768 dimensions: full median 4.794→2.688ms; top-200 mean recall 85.861→96.243%; candidate/coverage/scope gates pass.
- Heterogeneous 4,200-article fixture, 50,400 vectors at 128 dimensions, with 1/4/5/17/33 unrelated-topic chunks per article: mean recall reaches 100% at all three tested sizes. It passes the same breadth/scope gates. Whole-article maximum scoring includes late chunks.
- Full 42,000-article fixtures with one, two and three chunks, at 768 dimensions: the preserved passage fallback produces identical candidate lists, passage frontiers and measured-vector counts against 5.5.37 in every scope. Small corresponding fixtures also pass.

Reproduce with the C++17/O3/`-ffp-contract=off`/pthread settings in `tools/run-hnsw-checks.sh`. Compile `tools/tests/hnsw_article_graph_benchmark.cpp`, then run with `42000 768 /fresh/fixture/directory` for five chunks, or append `four`, `three`, `two`, `single` or `heterogeneous`. Use a distinct fixture directory for each geometry. Snapshot construction, conversion and preparation are separate from traversal timing.

## Compatibility, kernels and regression checks

- Article graph direct checks: all-chunk maximum cosine, odd dimensions, scalar tails, zeros, physical-slot lookup with key lookups disabled, tombstone routing, repeat-query cache boundaries, exact sparse-scope recovery ranking and telemetry pass. Degenerate one-dimensional directed components are restored by the existing native recovery path.
- Final actual Android NDK binaries under QEMU: ARM64 SDOT-capable `max`, ARM64 NEON-only `cortex-a53`, and ARM32 scalar `cortex-a15` article tests pass. The unchanged SQ8 kernel additionally passes 3,520 scalar/SIMD integer comparisons on each backend, plus complete conversion/map/update/scope/truncation tests. Host x86_64 without AVX/F16C passes with SSE2. Emulator timing is not phone-performance evidence.
- Final AddressSanitizer/UndefinedBehaviorSanitizer article tests pass with odd-offset snapshots and varied dimensions; leak inspection is disabled. The grouped-row bound uses subtraction to avoid an unsigned `row+4` overflow.
- Actual Kotlin/JNI manager tests pass for model synchronization, freshness, same-count edits, insertion/deletion, reopen, failed/cancelled atomic builds, empty/sparse scopes and background-work leases. An added 4,500-vector dense model checks article-mode activation, a matching last chunk, 600 candidates, warm reuse, sparse recovery, generation changes and preservation of the other model files.
- An actual frozen 5.5.36 payload still converts automatically to SQ8. Watermarks, model separation, restored backups, injected atomic-rename failure, FP16 fallback and paused-builder concurrency pass.
- Original IVF build/search/accuracy probes, edit/deletion, model separation, reopening and failed/cancelled rebuild checks pass. Legacy FP16 behavior retains 360 exact candidate/frontier/coverage/distance-count comparisons against its frozen oracle.
- Full-precision JNI scoring passes 1,572 grouped/tail/invalid comparisons and 7,872 native-versus-Kotlin bit checks. Production ViewModel ranking, ties, model isolation, 900-note Stop boundary, cursor failure/cancellation and native-absent fallback match the previous oracle.
- Original keyword/filter/highlighting checks pass: 630 coherent passages, 4,500 keyword hits, 118 chunk selections, and toolbar behavior over 20,000 scroll events.
- Saved reports pass 214 sessions ×347 hits, metadata/count/order/file identity, timing roundtrip, v1–v6 defaults, provenance, edits/deletion, retention and cancellation. Their persisted model/codec is unchanged.
- Source packaging verifies all members against the working tree, retains every baseline file, excludes local SDK configuration and caches, uses fixed timezone-safe timestamps, checks reproducibility and reruns preservation from the extracted archive.

No phone is connected for end-to-end speed or live UI testing. Real ONNX inference was not rerun; inference code and assets are byte-identical to 5.5.37. Cold opening includes new overlay preparation; warm searches reuse it. Embedding, keyword retrieval, FP32 scoring and reranking still contribute to total time. A 10-ms on-device graph or one-second total search remains unverified.
