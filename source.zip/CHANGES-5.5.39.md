# MarkVault 5.5.39 — Restore complete search expansion provenance

**Baseline:** Exactly the verified 5.5.37 source (SHA-256 of original ZIP: `006a267d65983746817219767b89f3408a95022f30ff1cf26601a83fe50d1fc4`). This release deliberately does **not** include the 5.5.38 article-graph traversal, which the user found slower on-device. Android version 5.5.39 / code 488.

## Restored

- A tap-to-expand **Query expansions (N)** line immediately above search results, accessible even when the search toolbar auto-hides. Shows the complete generated text and a source label for **LLM**, **T5-base**, **offline synonym expansion**, and **Question Awareness**, in the same order as the original retrieval plan.
- Reuses the existing v5.5.23 theme-aware golden-angle expansion palette, with one color per expansion **number** regardless of which engine produced it. This is a display-only change; no new color or provenance policy is introduced into search ranking.
- Search cards retain their original-query normal look, primary expansion border, retrieval details, and collapsible provenance list. **All additional matching expansions now appear as colored, labeled rows**, even if the original query is strongest.
- Saved searches restore evidenced expansion colors/numbers from their stored hit provenance. Generated queries without persisted evidence are still listed neutrally; their source is shown as unknown when the old saved format cannot prove it. No metadata migration needed.
- Hide old-query color labels while a new search is in progress without clearing the last-completed provenance. Cancelling the new search therefore preserves the previous result set and its recorded colors.
- Zero-budget searches show no query-expansion legend or empty per-result “Expansions (0)” control. The original-query explanation remains available.

## Scope and preservation

Only `SearchScreen.kt` changes among existing production Kotlin classes. `AppViewModel.kt` remains byte-identical to 5.5.37. `app/build.gradle.kts` changes version metadata. A small pure-Kotlin presentation helper is added with an isolated JVM regression test; both leave Room, HNSW, IVF, retrieval, keyword matching, AI inference, embedding models, reranker, saved-session persistence, article reading, highlighting, media, and backup/restore untouched.

This update fixes labels and visibility, not search speed. It does not modify HNSW graph topology, embedding inference, retrieval candidate count, semantic scoring, RRF or reranking.

See `VERIFICATION-5.5.39.md` for local test scope and limitations.
