# MarkVault 5.5.47 — Verification

## Completed

- Current source derived from the corrected 5.5.46 attached archive; last GitHub build of that baseline was successful (October 27, 2026).
- **200 Kotlin/JVM comparisons** of old and current chunker outputs across whitespace patterns, note lengths, 350/70 and 180/45 configurations: passed. No forced embedding migration.
- New `tools/tests/Integrity547Test.py`: passed source invariants covering per-model chunk IDs, incomplete-vector write suppression, backup+restore fields, rollback logic, color contrast and pressure-only GC.
- Search card separation, search card visual (20 themes), model isolation, Room ownership, HNSW SQL, search lifecycle, query embedding preservation, archive-source hygiene: passed.
- White-on-opaque-green score chip contrast: ~6.57:1; white-on-opaque-blue: ~7.08:1.
- ZIP integrity and original source-file inventory preservation: verified during packaging.

## Unverified / exclusions

- Full Android/Gradle release compilation not available in this runtime; must run the GitHub workflow.
- Device-level battery/thermal profiling, full backup-to-restore round-trip, power interruption and disk-full fault injection not performed.
- Older `idle_cpu_5_5_45_test.py` is pinned to version 5.5.45 and is not applicable to 5.5.47; its preserved safeguards were reviewed. One legacy SQL test exceeded its execution timeout; not counted as passing.
- Backup format version remains 6; no destructive data migrations, and no changed model embedding version.
