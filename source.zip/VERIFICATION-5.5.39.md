# MarkVault 5.5.39 verification

- The original 5.5.37 baseline ZIP was reconstructed from the 5.5.38 preservation manifest, reversing all 11 reviewed changes and excluding all 5.5.38-only files. The rebuilt **391-file archive** matched the pinned baseline SHA-256 exactly: `006a267d65983746817219767b89f3408a95022f30ff1cf26601a83fe50d1fc4`.
- Local Kotlin regression suite `tools/tests/QueryExpansionPresentationTest.kt` exercises original-only (slider=0), four distinct expansion sources, issued-order numbering, duplicate removal, multi-match provenance, saved-session provenance and unknown-source fallback. Run with:

  ```sh
  kotlinc app/src/main/java/com/tebogo/markvault/search/ResultQueryProvenance.kt \
    app/src/main/java/com/tebogo/markvault/search/QueryExpansionPresentation.kt \
    tools/tests/QueryExpansionPresentationTest.kt -include-runtime -d /tmp/qe-test.jar
  java -jar /tmp/qe-test.jar
  ```

- Code preservation compares each original production file against the exact 5.5.37 baseline, allowing only `app/build.gradle.kts` and `SearchScreen.kt`; all other original files must be byte-identical. New code is additive and isolated.
- The retrieval engine still populates `QueryPlanHistory` for keyword and semantic paths, and records actual per-result `QueryContribution` in `SearchExecutionTrace`. The restored UI consumes those records instead of LLM-only paraphrase history. The existing source-specific and rank-specific audit data remains authoritative.
- The UI only displays verified saved-source labels. Older saved records without a source get a neutral description rather than a false LLM, synonym, or T5 claim.

**Limitations:** This runtime does not have the project's Android Gradle/SDK/NDK build dependencies. A full Android Compose compilation, release APK build and device-based UI/performance verification were not performed here. Source ZIP and pure JVM presentation logic have been validated; an Android CI build is still needed before treating the update as installation-tested.
