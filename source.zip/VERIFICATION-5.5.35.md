# MarkVault 5.5.35 verification

- Version 5.5.35, version code 484; Room schema 24.
- :app:assembleDebug and :app:assembleRelease: BUILD SUCCESSFUL in 4m 2s.
- Gradle 8.7, Java 17, SDK 35, NDK 27.2.12479018, CMake 3.22.1.
- Both APKs: signatures and version verified; arm64-v8a, armeabi-v7a, x86 and x86_64 libraries; 13 expected JNI exports per library; LOAD alignment at least 16 KiB. APKs are excluded from the source archive.
- Actual generated debug/release Room schema includes the exact index created by the migration. No DAO SQL was changed.
- New index fixture: 42,507-note additive migration/content hash/exact partition order/ties/update/delete/rollback/reopen/integrity=PASS; table+sort_ms=66.88 covering_index_ms=9.48; host timings only
- Full native/source/Kotlin/JNI/IVF/Room/keyword/UI/saved-search suite: PASS.
- JNI version 3 packet, positive graph CPU time bounded by graph elapsed time, empty/sparse scopes and stored format 2 compatibility: PASS.
- Native property checks in the Android ARM64 static binary under QEMU and x86 without AVX/F16C: PASS. Emulator times are not performance evidence.
- AddressSanitizer/UndefinedBehaviorSanitizer odd-offset snapshot/update/delete/persistence checks: PASS; LeakSanitizer inspection disabled.
- All previous preservation layers and eleven reviewed 5.5.34 inverse deltas: PASS.
- Reproducible ZIP/timestamp/timezone/permission/cache-exclusion fixture: PASS. Final packaging checks all source bytes, member permissions and ZIP integrity; the extracted ZIP reruns the preservation guard.
- Actual phone timing of this update and real model inference were not tested. Original embedding and reranker inference code is unchanged.

The following synthetic 42,000-article/210,000-chunk/768-dimension host comparison checks unchanged candidate behavior with the additional CPU clock. It does not establish phone speed:

```
Fixture=42000 articles/210000 chunks/768 dimensions; prep=234.348 -> 208.267ms
360 exact candidate/coverage/frontier/distance-count comparisons=PASS
5.5.33 full-library lookup min=6.46613 median=9.11311 p95=11.5213 max=12.1216ms
5.5.35 full-library lookup min=5.91352 median=8.29116 p95=11.4411 max=12.7017ms
5.5.33 full-library graph min=6.25645 median=8.77726 p95=11.1691 max=11.6385ms
5.5.35 full-library graph min=5.63837 median=7.91791 p95=11.0535 max=12.1235ms
5.5.33 partition lookup min=6.31735 median=15.5824 p95=35.4503 max=39.1452ms
5.5.35 partition lookup min=5.95173 median=15.096 p95=31.0544 max=37.9278ms
```

See CHANGES-5.5.35.md for the screenshot diagnosis, measured scope-query improvement, compatibility and new diagnostic labels.
