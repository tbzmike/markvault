# MarkVault 5.5.51 — Sequential Highlights and Portable Full Backup

**Version:** 5.5.51, Android versionCode 500. Built from the complete 5.5.50 `source.zip` baseline.

## Highlight navigation

- Corrected distinct-hit navigation: visible **leaf** highlights are navigated in DOM order, rather than a broad highlighted ancestor hiding multiple marked passages.
- Count/probe callbacks preserve the current ordinal if a WebView rerender replaces its DOM nodes. Each arrow tap advances **one** entry, with wraparound.
- The active highlight gains a persistent amber focus outline. Immediate two-argument WebView `scrollTo` avoids overlapping smooth-scroll animations and delayed scroll jobs.
- A first-highlight autoscroll cannot overwrite the manually selected target once the user presses an arrow.
- Applied to Markdown and offline HTML readers. Existing centered highlight loader and X cancellation remain.
- No new service, polling loop, coroutine, or background job.

## Portable full backup v7

New backup exports:

1. Original user-selected SAF library files **and their relative directory tree**, including empty directories.
2. Note records, full article text, topics, links, per-chunk **note embeddings for all models**, and saved note reading/favourite state.
3. Additional Room tables: media items, **media embeddings**, playlists, cached PDF text, PDF annotations/history, web bookmarks/history.
4. All compatible model-specific **IVF/HNSW** snapshots already created, with checksums.
5. DataStore settings, app SharedPreferences XML, and app-private data files, including installed embedding models, T5/reranking/LLM assets, saved searches, themes and transcript data. Incomplete `.part`/`.tmp`/`.bak` and transient update/cache/restore files are excluded.

Each entry is protected by SHA-256 and an exact size in the archive manifest. Backup refuses to start if required library files cannot be found or embedding synchronization is active. It refuses to include its own destination ZIP inside the library. The database is read inside one existing SQLite transaction.

## Restore to another phone

- Install MarkVault and **select a writable destination library folder** through Android's folder picker. This is required because old Android SAF access grants and `content://` identifiers cannot transfer between phones.
- Restore original files into that tree. Existing files are verified against backup data; different files are never silently overwritten. Newly created files/folders are rolled back if the library-transfer step fails.
- Re-map restored notes to new-device document URIs by relative path and file size, and match **all** indexed articles before committing database changes. Relink library PDF-history entries.
- Restore all other Room tables in the same database transaction; rebuild deterministic FTS from restored article text. Retain the source note IDs, model versions and chunk indices so completed embeddings remain reusable.
- Stage app-private assets with per-file rollback and stage SharedPreferences/DataStore for cold-start application. Require enough free space for staging and installation.
- Prevent embedding service starts, resumes, model deletion or model-switch workers during a backup/restore operation. STOP and PAUSE remain available.
- Existing v1–v6 backup restoration logic remains available.

**Important:** This is a **new backup format**, so create a fresh backup with 5.5.51 before transferring to a different phone. A v5/v6 archive does **not** contain article files, media vectors, or downloaded models.

## Practical limits and safeguards

- Backups can be many GB and may contain personal data. Keep them secure.
- The destination needs adequate space and a working Android Documents Provider. Backup files cannot transfer Android's persisted SAF permissions.
- Portability is limited by app schema compatibility and native ANN implementation. On an incompatible phone, a native index might require rebuilding from transferred **embeddings**, without re-embedding the article collection.
- External files/URIs outside the selected library tree and app-private files cannot be assumed portable. Their stale external references may require choosing those files again.
- Device-level backup/restore tests and full Android APK compilation are still required before claiming a verified cross-device migration.
