plugins {
    id("com.android.application") version "8.5.2" apply false
    // v4.19.0 — bumped 2.0.20 → 2.2.0. Required by litertlm-android (the
    // on-device chat LLM library, Stage 1 of the chat/RAG project) — its
    // compiled Kotlin metadata needs 2.2.0+. KSP must move in lockstep
    // (it's version-locked to the Kotlin version it was built against).
    id("org.jetbrains.kotlin.android") version "2.2.0" apply false
    id("org.jetbrains.kotlin.plugin.compose") version "2.2.0" apply false
    id("com.google.devtools.ksp") version "2.2.0-2.0.2" apply false
}
