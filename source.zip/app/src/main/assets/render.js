/* MarkVault render engine v2 — Obsidian/Claude-grade, fully offline */
/*
 * v4.18.0 — markdown-it removed; parsing now happens in Kotlin via
 * flexmark-java (see MarkdownEngine.kt). This file is now a thin
 * post-processor that runs after the pre-rendered HTML lands in the DOM:
 *   - transformCallouts:  > [!info] → styled callouts (uses ICONS / ALIAS)
 *   - transformTasks:     - [ ] / - [x] → checkboxes
 *   - transformWikilinks: safety-net for stray [[…]] flexmark didn't catch
 *   - setupHeadings:      heading anchors
 *   - cleanOrphanHtmlFragments: scrub leaked attribute fragments
 *   - applyContrast / setTheme / highlightTerm
 *
 * The custom `==highlight==`, `~_underline_~`, and `[^footnote]` syntaxes
 * that used to be markdown-it plugins are not yet ported — they were
 * Obsidian extensions of varying usage. Raw `<u>` and `<mark>` HTML
 * still work because flexmark passes inline HTML through.
 */

var ICONS = {
  note:'\uD83D\uDCDD', info:'\u2139\uFE0F', tip:'\uD83D\uDCA1', success:'\u2705',
  warning:'\u26A0\uFE0F', caution:'\uD83D\uDD25', danger:'\u26D4', error:'\u274C',
  quote:'\uD83D\uDCAC', question:'\u2753', example:'\uD83D\uDD0E', abstract:'\uD83D\uDCCB'
};
var ALIAS = {
  summary:'abstract', tldr:'abstract', hint:'tip', important:'tip', check:'success',
  done:'success', fail:'error', bug:'error', faq:'question', help:'question',
  todo:'info', attention:'warning', cite:'quote'
};

function transformCallouts(root) {
  root.querySelectorAll('blockquote').forEach(function (bq) {
    var first = bq.querySelector('p');
    if (!first) return;
    var m = first.innerHTML.match(/^\s*\[!(\w+)\]([+-]?)\s*([\s\S]*)/i);
    if (!m) return;
    var type = m[1].toLowerCase(); type = ALIAS[type] || type;
    if (!ICONS[type]) type = 'note';
    var sign = m[2], rest = m[3];
    var foldable = sign === '+' || sign === '-';
    var collapsed = sign === '-';

    var div = document.createElement('div');
    div.className = 'callout cl-' + type + (foldable ? ' foldable' : '') + (collapsed ? ' collapsed' : '');

    var splitFirst = rest.split(/<br\s*\/?>([\s\S]*)/i);
    var titleText = (splitFirst[0] || '').trim() || (type.charAt(0).toUpperCase() + type.slice(1));

    var title = document.createElement('div');
    title.className = 'callout-title';
    title.innerHTML =
      (foldable ? '<span class="chevron">\u25B8</span>' : '') +
      '<span class="ic">' + ICONS[type] + '</span><span class="ct">' + titleText + '</span>';
    div.appendChild(title);

    var body = document.createElement('div');
    body.className = 'callout-body';
    if (splitFirst[1]) { var p = document.createElement('p'); p.innerHTML = splitFirst[1]; body.appendChild(p); }
    var sib = first.nextElementSibling;
    while (sib) { var next = sib.nextElementSibling; body.appendChild(sib); sib = next; }
    div.appendChild(body);

    if (foldable) {
      title.addEventListener('click', function () { div.classList.toggle('collapsed'); });
    }
    bq.parentNode.replaceChild(div, bq);
  });
}

function transformTasks(root) {
  root.querySelectorAll('li').forEach(function (li) {
    var m = li.innerHTML.match(/^\s*\[([ xX])\]\s+([\s\S]*)/);
    if (!m) return;
    li.classList.add('task');
    if (m[1].toLowerCase() === 'x') li.classList.add('done');
    li.innerHTML = '<span class="box"></span><span class="label">' + m[2] + '</span>';
  });
}

function transformWikilinks(root) {
  var pending = [];
  (function rec(n) {
    for (var i = 0; i < n.childNodes.length; i++) {
      var c = n.childNodes[i];
      if (c.nodeType === 3) { if (/\[\[/.test(c.nodeValue)) pending.push(c); }
      else if (c.nodeType === 1) {
        var t = c.tagName.toLowerCase();
        if (t !== 'code' && t !== 'pre' && t !== 'a') rec(c);
      }
    }
  })(root);
  pending.forEach(function (tn) {
    var span = document.createElement('span');
    // [[Target]]   or   [[Target|Alias]]   or   [[Target#section]]   or   [[Target^block]]
    span.innerHTML = tn.nodeValue.replace(
      /\[\[([^\[\]\n|#^]+)(?:#[^\[\]\n|]*)?(?:\^[^\[\]\n|]*)?(?:\|([^\[\]\n]+))?\]\]/g,
      function (_, target, alias) {
        var label = (alias || target).replace(/</g, '&lt;').replace(/>/g, '&gt;');
        var href = 'mv://wiki/' + encodeURIComponent(target.trim());
        return '<a class="wikilink" href="' + href + '">' + label + '</a>';
      }
    );
    tn.parentNode.replaceChild(span, tn);
  });
}

/* Outline anchors + collapsible headings (top-level only) */
function setupHeadings(root) {
  var hs = root.querySelectorAll('#content > h1, #content > h2, #content > h3, #content > h4, #content > h5, #content > h6');
  hs.forEach(function (h, i) {
    h.id = 'sec-' + i;
    h.classList.add('foldable-h');
    h.addEventListener('click', function () {
      var lvl = parseInt(h.tagName.substring(1), 10);
      var collapsed = h.classList.toggle('h-collapsed');
      var sib = h.nextElementSibling;
      while (sib) {
        if (/^H[1-6]$/.test(sib.tagName) && parseInt(sib.tagName.substring(1), 10) <= lvl) break;
        sib.style.display = collapsed ? 'none' : '';
        sib = sib.nextElementSibling;
      }
    });
  });
}

function renderMarkdown(src, scale, theme, smartStylingAll, contrast) {
  // v4.18.0 — `src` is now PRE-RENDERED HTML produced by Kotlin's flexmark
  // engine (MarkdownEngine.kt), not raw markdown. markdown-it is no longer
  // loaded. We still keep the same function name and signature so every
  // caller (ReaderScreen, SplitReaderScreen, ExternalReaderActivity) works
  // unchanged.
  //
  // The `smartStylingAll` parameter is now ignored — smart-styling was the
  // source of the `"sm-num">1513` leak in articles and the user asked for it
  // removed entirely. The parameter stays in the signature for back-compat
  // with the existing call sites; new code can pass anything.
  document.documentElement.style.fontSize = (17 * (scale || 1)) + 'px';
  if (theme) setTheme(theme);
  applyContrast(contrast);
  var el = document.getElementById('content');
  el.innerHTML = src || '';
  // Post-processors that operate on the already-rendered DOM. flexmark has
  // already produced wikilink anchors with the correct `mv://wiki/<encoded>`
  // href, so `transformWikilinks` here is just a safety net for any literal
  // `[[…]]` that survived (e.g. inside HTML attributes that flexmark left
  // alone).
  try { transformCallouts(el); } catch (e) {}
  try { transformTasks(el); } catch (e) {}
  try { transformWikilinks(el); } catch (e) {}
  try { setupHeadings(el); } catch (e) {}
  // Last-resort scrub for any historically broken articles whose .md still
  // has orphan attribute fragments after sanitize.
  try { cleanOrphanHtmlFragments(el); } catch (e) {}
  // v5.4.60 extensions (each guarded by its own enabled flag)
  try { renderMermaidDiagrams(el); } catch (e) {}
  try { autoLinkScriptures(el); } catch (e) {}
  // NOTE: scheduleSmartStyling() is intentionally NOT called. Smart styling
  // is removed in v4.18.0 — it was producing the `"sm-num">…` artefacts
  // visible in the article body when the wrapper-rewrite path failed.
  window.scrollTo(0, 0);
}

/**
 * Clean up text content that looks like an orphaned HTML attribute fragment.
 * Patterns matched (and removed) within plain-text nodes only:
 *   "sm-ref">       — class attribute fragment leaked from a broken <a> tag
 *   "name">         — same shape, any unknown class name
 *   class="...">    — full class attribute leak
 *   href="...">     — href leak
 * Skips nodes inside <code>, <pre>, <a>, <textarea>, <script>, <style>.
 */
function cleanOrphanHtmlFragments(root) {
  if (!root) return;
  var SKIP = { CODE:1, PRE:1, A:1, SCRIPT:1, STYLE:1, TEXTAREA:1, INPUT:1, BUTTON:1 };
  var stack = [root];
  while (stack.length) {
    var node = stack.pop();
    if (node.nodeType === 1) {
      if (SKIP[node.tagName]) continue;
      // Walk children in reverse so we can stack them
      for (var i = node.childNodes.length - 1; i >= 0; i--) {
        stack.push(node.childNodes[i]);
      }
      continue;
    }
    if (node.nodeType !== 3) continue;   // TEXT_NODE
    var t = node.nodeValue;
    if (!t || t.length < 4) continue;
    // Only run regex if the text actually contains the suspicious pattern
    if (t.indexOf('">') < 0 && t.indexOf('class=') < 0 && t.indexOf('href=') < 0) continue;
    var cleaned = t
      // class="something"> at start or anywhere
      .replace(/\bclass\s*=\s*"[^"]*"\s*>/gi, '')
      .replace(/\bclass\s*=\s*'[^']*'\s*>/gi, '')
      // href="something">
      .replace(/\bhref\s*=\s*"[^"]*"\s*>/gi, '')
      .replace(/\bhref\s*=\s*'[^']*'\s*>/gi, '')
      // Bare attribute-value leak like "sm-ref">  or  "anything-or-other">
      .replace(/"([a-zA-Z][\w \-]{0,40})"\s*>/g, '')
      .replace(/'([a-zA-Z][\w \-]{0,40})'\s*>/g, '')
      // Collapse double spaces left behind
      .replace(/  +/g, ' ');
    if (cleaned !== t) node.nodeValue = cleaned;
  }
}

/* ════════════════════════════════════════════════════════════════════════
 *  SMART STYLING — chunked + idle-deferred
 *
 *  Strategy:
 *    1. Question-line classification is a cheap CSS-only tag — runs immediately.
 *    2. The inline-wrap pass (numbers, refs, percentages, "quotes", ALL-CAPS)
 *       creates MANY small DOM mutations on long articles. Deferred via
 *       requestIdleCallback so the article shows + scrolls first, then styling
 *       fills in when the browser is idle.
 *    3. The walker processes blocks in chunks of ~25, yielding back to the
 *       browser between chunks so scrolling stays responsive even on huge docs.
 *    4. A token aborts in-flight styling if the user navigates away —
 *       renderMarkdown bumps the token, old workers see the change and stop.
 * ════════════════════════════════════════════════════════════════════════ */

var SMART_SKIP_TAGS = { CODE:1, PRE:1, A:1, SCRIPT:1, STYLE:1, MARK:1, BUTTON:1, INPUT:1, TEXTAREA:1, H1:1, H2:1, H3:1, H4:1, H5:1, H6:1 };
var SMART_RUN_TOKEN = 0;

function scheduleSmartStyling(root, allDocs) {
  if (!root) return;
  // Bump token to cancel any in-flight styling from a previous article
  SMART_RUN_TOKEN++;
  var myToken = SMART_RUN_TOKEN;
  // Phase 1 — fast, immediate: tag question-lines (CSS-only, no spans)
  classifyQuestionLines(root);
  // Phase 2 — deferred inline wrapping. Skip for huge docs unless the user
  // opted in via Settings → Performance → Smart styling on all documents.
  var totalText = (root.textContent || '').length;
  if (!allDocs && totalText > 60000) return;
  var deferred = function () {
    if (myToken !== SMART_RUN_TOKEN) return;   // aborted (article changed)
    processChunked(root, myToken);
  };
  if (typeof window.requestIdleCallback === 'function') {
    window.requestIdleCallback(deferred, { timeout: 1500 });
  } else {
    // Older Android WebView lacks requestIdleCallback — fall back to a small
    // setTimeout so the first paint completes before styling begins.
    setTimeout(deferred, 350);
  }
}

function classifyQuestionLines(root) {
  var paragraphs = root.querySelectorAll('p');
  for (var i = 0; i < paragraphs.length; i++) {
    var p = paragraphs[i];
    var txt = (p.textContent || '').trim();
    if (txt.length > 8 && txt.length < 300 && /[?][\s]*$/.test(txt) &&
        !p.classList.contains('callout-body') && p.children.length < 4) {
      p.classList.add('sm-question-line');
    }
  }
}

function processChunked(root, myToken) {
  var blocks = root.querySelectorAll('p, li, td, blockquote');
  var i = 0;
  var CHUNK = 25;
  var step = function () {
    if (myToken !== SMART_RUN_TOKEN) return;   // aborted
    var end = Math.min(i + CHUNK, blocks.length);
    for (var j = i; j < end; j++) {
      try { walkAndWrap(blocks[j]); } catch (e) {}
    }
    i = end;
    if (i < blocks.length) {
      if (typeof window.requestIdleCallback === 'function') {
        window.requestIdleCallback(step, { timeout: 600 });
      } else {
        setTimeout(step, 16);
      }
    }
  };
  step();
}

// Backwards-compat shim
function applySmartStyling(root, allDocs) { scheduleSmartStyling(root, !!allDocs); }

function walkAndWrap(node) {
  if (!node) return;
  if (node.nodeType === 1) {
    if (SMART_SKIP_TAGS[node.tagName]) return;
    // Skip if a parent is already a smart class (avoid double-wrap)
    if (node.classList && (
      node.classList.contains('sm-key') ||
      node.classList.contains('sm-num') ||
      node.classList.contains('sm-ref') ||
      node.classList.contains('sm-pct')
    )) return;
    var kids = Array.prototype.slice.call(node.childNodes);
    for (var i = 0; i < kids.length; i++) walkAndWrap(kids[i]);
    return;
  }
  if (node.nodeType !== 3) return;          // 3 = TEXT_NODE
  var t = node.nodeValue;
  if (!t || t.length < 2) return;
  // SAFETY: a previous buggy render may have written literal `"sm-X">` characters
  // into this text node (visible to the user as `"sm-ref">"sm-ref">Surah 7:54`).
  // Strip those leaked attribute fragments BEFORE doing any matching so that
  // (a) the artifacts disappear from the rendered output and (b) the regex below
  // doesn't accidentally re-wrap them again. Idempotent — safe on clean text.
  var cleaned = t.replace(/[\u201C\u201D\u2018\u2019"']?sm-(?:ref|num|pct|acronym|quotechar|key|date|cap)[\u201C\u201D\u2018\u2019"']?>+/g, '');
  if (cleaned !== t) {
    t = cleaned;
    node.nodeValue = t;
  }
  // Combined pass: build replacement HTML
  var html = escapeHtml(t)
    // Bible-style refs: "John 3:16", "1 Cor 13:4-7", "Genesis 1:1-3" etc
    .replace(/\b([1-3]\s*)?(?:[A-Z][a-z]+|[A-Z][a-z]+\s[A-Z][a-z]+)\s\d{1,3}:\d{1,3}(?:[-\u2013]\d{1,3})?\b/g,
      function (m) { return '<span class="sm-ref">' + m + '</span>'; })
    // Percentages
    .replace(/\b\d{1,3}(?:\.\d+)?\s?%/g,
      function (m) { return '<span class="sm-pct">' + m + '</span>'; })
    // Years and longer numbers (≥3 digits, may include commas/decimals)
    .replace(/\b\d{1,3}(?:,\d{3})+(?:\.\d+)?\b|\b\d{3,}\b/g,
      function (m) { return '<span class="sm-num">' + m + '</span>'; })
    // ALL-CAPS acronyms (2-6 letters, surrounded by word boundaries)
    .replace(/\b[A-Z]{2,6}(?:s)?\b/g,
      function (m) { return '<span class="sm-acronym">' + m + '</span>'; })
    // "Quoted phrases" (curly or straight, 3-80 chars)
    .replace(/[\u201C\u201D"]([^"\u201C\u201D\n]{3,80})[\u201C\u201D"]/g,
      function (m, inner) { return '<span class="sm-quotechar">\u201C' + inner + '\u201D</span>'; });
  if (html === escapeHtml(t)) return;       // no changes
  var span = document.createElement('span');
  span.innerHTML = html;
  if (node.parentNode) node.parentNode.replaceChild(span, node);
}

function escapeHtml(s) {
  return s.replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;');
}

function setFontScale(scale) { document.documentElement.style.fontSize = (17 * (scale || 1)) + 'px'; }
function setTheme(name) {
  document.body.className = 'theme-' + (name || 'dark');
}

/**
 * v5.4.33 — Apply a custom theme by setting CSS custom properties directly on the body.
 * Called from Kotlin with a JSON string of var→value pairs.
 * Example: setCustomTheme('{"--bg":"#1e1e1e","--fg":"#dcddde",...}')
 */
function setCustomTheme(jsonStr) {
  document.body.className = 'theme-custom';
  try {
    var vars = JSON.parse(jsonStr);
    for (var key in vars) {
      if (vars.hasOwnProperty(key) && key.startsWith('--')) {
        document.body.style.setProperty(key, vars[key]);
      }
    }
  } catch(e) { /* silently ignore bad JSON */ }
}

/**
 * Strip leaked smart-styling artefacts from raw markdown.
 *
 * History: an earlier build of MarkVault wrote rendered HTML chunks back into
 * the source text on certain code paths (e.g. paste from the renderer back to
 * the source via copy actions). That left literal strings like
 *
 *      ("sm-ref">"sm-ref">"sm-ref">Surah 7:54)
 *
 * embedded in the .md files on disk. This helper removes those fragments AND
 * the orphan opening tags (e.g. `<span class="sm-ref">` with no matching close)
 * before the markdown renderer sees the text. Safe to apply repeatedly.
 */
function sanitizeMarkVaultArtifacts(src) {
  if (!src) return '';
  var s = String(src);
  // 1. Bare attribute-value fragments: "sm-ref">, "sm-num">, etc.
  //    Curly-quote and straight-quote variants are both handled.
  s = s.replace(/[\u201C\u201D\u2018\u2019"']?sm-(?:ref|num|pct|acronym|quotechar|key|date|cap)[\u201C\u201D\u2018\u2019"']?>+/g, '');
  // 2. Full leaked spans: <span class="sm-X">...</span>  →  ...
  s = s.replace(/<span\s+class\s*=\s*["']sm-[a-z]+["']\s*>([\s\S]*?)<\/span>/gi, '$1');
  // 3. Orphan opening tags left behind by interrupted renders.
  s = s.replace(/<span\s+class\s*=\s*["']sm-[a-z]+["']\s*>/gi, '');
  return s;
}

/**
 * Apply a contrast multiplier (1.0 .. 2.0) to the article body via a CSS filter.
 * Cheap, works on every WebView since Android 5. The slider in Settings just
 * bumps this value; renderMarkdown re-applies whenever a fresh article loads.
 */
function applyContrast(multiplier) {
  var m = parseFloat(multiplier) || 1.0;
  if (m < 1) m = 1;
  if (m > 2) m = 2;
  document.body.style.filter = (m > 1.01)
    ? ('contrast(' + m.toFixed(2) + ') saturate(' + Math.min(1.3, m).toFixed(2) + ')')
    : '';
}
function collapseAllCallouts() {
  document.querySelectorAll('.callout.foldable').forEach(function (c) { c.classList.add('collapsed'); });
}
function expandAllCallouts() {
  document.querySelectorAll('.callout.foldable').forEach(function (c) { c.classList.remove('collapsed'); });
}
function getScroll() { return window.scrollY || 0; }
function restoreScroll(y) { window.scrollTo(0, y || 0); }

/* ===== Jump-to-match (from full-text search) =====
   Behaviour:
   1. Tries the *whole phrase* first (case-insensitive, whitespace-tolerant).
   2. If the phrase isn't present, falls back to the longest content word
      from the query that does exist in the article.
   3. Wraps every occurrence in <span class="term-hit">, scrolls the first
      one into view, and flashes them briefly.
   Stopwords are only stripped from the *fallback* word pool, never used
   to reject the original phrase. */

function clearTermHighlights() {
  var hits = document.querySelectorAll('span.term-hit, mark.term-hit');
  for (var i = 0; i < hits.length; i++) {
    var h = hits[i];
    if (h.parentNode) {
      h.parentNode.replaceChild(document.createTextNode(h.textContent), h);
      h.parentNode.normalize && h.parentNode.normalize();
    }
  }
}

function wrapMatches(root, termLower) {
  var first = null, count = 0;
  var walker = document.createTreeWalker(root, NodeFilter.SHOW_TEXT, {
    acceptNode: function (node) {
      if (!node.nodeValue) return NodeFilter.FILTER_REJECT;
      var p = node.parentNode;
      if (!p) return NodeFilter.FILTER_REJECT;
      var tag = p.tagName;
      if (tag === 'SCRIPT' || tag === 'STYLE') return NodeFilter.FILTER_REJECT;
      return node.nodeValue.toLowerCase().indexOf(termLower) >= 0
        ? NodeFilter.FILTER_ACCEPT : NodeFilter.FILTER_REJECT;
    }
  });
  var nodes = [], n;
  while ((n = walker.nextNode())) { nodes.push(n); if (nodes.length > 500) break; }
  for (var i = 0; i < nodes.length; i++) {
    var node = nodes[i], text = node.nodeValue, lower = text.toLowerCase();
    var frag = document.createDocumentFragment(), idx = 0, pos;
    while ((pos = lower.indexOf(termLower, idx)) >= 0) {
      if (pos > idx) frag.appendChild(document.createTextNode(text.slice(idx, pos)));
      var span = document.createElement('span');
      span.className = 'term-hit';
      span.textContent = text.slice(pos, pos + termLower.length);
      frag.appendChild(span);
      if (!first) first = span;
      idx = pos + termLower.length;
      count++;
      if (count > 500) break;
    }
    if (idx < text.length) frag.appendChild(document.createTextNode(text.slice(idx)));
    if (node.parentNode) node.parentNode.replaceChild(frag, node);
    if (count > 500) break;
  }
  return first;
}

/* Words to skip ONLY when picking the fallback single word — never used to
   reject the user's full phrase. */
var FALLBACK_STOPWORDS = {
  the:1, is:1, a:1, an:1, of:1, to:1, and:1, in:1, on:1, for:1, at:1, by:1,
  are:1, was:1, were:1, be:1, been:1, being:1, it:1, its:1, this:1, that:1,
  these:1, those:1, with:1, from:1, as:1, or:1, but:1, if:1, so:1, do:1,
  does:1, did:1, has:1, have:1, had:1, will:1, would:1, can:1, could:1
};

function pickHighlightTerm(raw, bodyLower) {
  if (!raw) return null;
  var phrase = ('' + raw).trim();
  if (!phrase) return null;

  // Quoted phrase → strict
  if (phrase.length >= 2 && phrase.charAt(0) === '"' && phrase.charAt(phrase.length - 1) === '"') {
    var inner = phrase.slice(1, -1).toLowerCase().trim();
    return (inner && bodyLower.indexOf(inner) >= 0) ? inner : null;
  }

  // Normalise whitespace so "who   is" matches "who is"
  var normalised = phrase.toLowerCase().replace(/\s+/g, ' ').trim();
  if (!normalised) return null;

  // 1. Try the entire phrase
  if (bodyLower.indexOf(normalised) >= 0) return normalised;

  // 2. Try the phrase minus the trailing question mark / punctuation
  var stripped = normalised.replace(/[?!.,;:]+$/g, '').trim();
  if (stripped && stripped !== normalised && bodyLower.indexOf(stripped) >= 0) return stripped;

  // 3. Fallback: pick the longest meaningful word that exists in the body
  var words = normalised.split(/[^a-z0-9']+/i).filter(function (w) {
    return w && w.length >= 2;
  });
  // Prefer the longest non-stopword that actually appears
  words.sort(function (a, b) { return b.length - a.length; });
  for (var i = 0; i < words.length; i++) {
    var w = words[i];
    if (FALLBACK_STOPWORDS[w]) continue;
    if (bodyLower.indexOf(w) >= 0) return w;
  }
  // 4. Last resort: any word (including stopwords) that's present
  for (var j = 0; j < words.length; j++) {
    if (bodyLower.indexOf(words[j]) >= 0) return words[j];
  }
  return null;
}

/* v5.3.0 — Sentence-level highlight.
   Extract distinctive query terms from the input, walk text nodes, and
   wrap WHOLE SENTENCES that contain 1+ query term. This replaces the
   previous single-word picker so users can spot the matching passage
   immediately instead of hunting for a yellow word inside the paragraph.

   Same .term-hit class so the flash animation still applies.            */
var HL_STOPWORDS = {
  the:1, is:1, a:1, an:1, of:1, to:1, and:1, in:1, on:1, "for":1, at:1,
  by:1, are:1, was:1, were:1, be:1, been:1, being:1, it:1, its:1, this:1,
  that:1, these:1, those:1, with:1, from:1, as:1, or:1, but:1, "if":1,
  so:1, "do":1, does:1, did:1, has:1, have:1, had:1, will:1, would:1,
  can:1, could:1, what:1, who:1, why:1, how:1, when:1, where:1, which:1,
  about:1, not:1, no:1, also:1, more:1, some:1, any:1, all:1, one:1,
  two:1, you:1, your:1, my:1, we:1, our:1, us:1, me:1, he:1, she:1,
  they:1, them:1, their:1, his:1, her:1, "i":1
};

function extractQueryTerms(raw) {
  if (!raw) return [];
  var lower = ('' + raw).toLowerCase()
    .replace(/\[\[/g, ' ')
    .replace(/\]\]/g, ' ')
    .replace(/\.\.\./g, ' ')
    .replace(/[^a-z0-9'\s]/g, ' ')
    .replace(/\s+/g, ' ')
    .trim();
  var pieces = lower.split(' ');
  var seen = {};
  var out = [];
  for (var i = 0; i < pieces.length; i++) {
    var w = pieces[i];
    // v5.4.9 — bumped min length 3→4 to filter weak matches like
    // "and", "for", "the" that snuck past the stopwords list.
    if (w.length >= 4 && !HL_STOPWORDS[w] && !seen[w]) {
      seen[w] = 1;
      out.push(w);
    }
  }
  return out;
}

function highlightSentencesIn(root, terms, markClass) {
  if (!root || terms.length === 0) return null;
  var walker = document.createTreeWalker(
    root, NodeFilter.SHOW_TEXT,
    { acceptNode: function (node) {
        if (!node.nodeValue || !node.nodeValue.trim()) return NodeFilter.FILTER_REJECT;
        var p = node.parentElement;
        if (!p) return NodeFilter.FILTER_REJECT;
        var tag = (p.tagName || '').toLowerCase();
        if (tag === 'script' || tag === 'style' || tag === 'mark') return NodeFilter.FILTER_REJECT;
        // v5.4.9 — Skip headings entirely. Highlighting the whole
        // article title or section heading in yellow is overwhelming
        // and adds no information — the user already navigated to
        // this article from a search result, they don't need the
        // title shouting at them. Keyword-level highlighting via
        // wrapMatchesAllTerms still applies inside headings.
        if (tag === 'h1' || tag === 'h2' || tag === 'h3' ||
            tag === 'h4' || tag === 'h5' || tag === 'h6') {
          return NodeFilter.FILTER_REJECT;
        }
        // Walk up: also reject if any ancestor is a heading
        var ancestor = p.parentElement;
        while (ancestor && ancestor !== root) {
          var atag = (ancestor.tagName || '').toLowerCase();
          if (atag === 'h1' || atag === 'h2' || atag === 'h3' ||
              atag === 'h4' || atag === 'h5' || atag === 'h6') {
            return NodeFilter.FILTER_REJECT;
          }
          ancestor = ancestor.parentElement;
        }
        if (p.classList && (p.classList.contains(markClass) || p.classList.contains('term-hit')))
          return NodeFilter.FILTER_REJECT;
        return NodeFilter.FILTER_ACCEPT;
      } }, false);
  var nodes = [];
  while (walker.nextNode()) nodes.push(walker.currentNode);
  var firstMark = null;
  var totalHighlights = 0;
  var MAX = 40;
  // v5.4.16 — Threshold lowered to 1 (was 2 when terms.length >= 2).
  // The 2-term threshold, combined with v5.4.15's removal of the
  // word-level backfill, caused nothing to highlight when a doc had
  // query terms spread across separate sentences instead of co-
  // occurring. That's the "sometimes it highlights, sometimes it
  // doesn't" bug — now any sentence containing ANY query term gets
  // the full-sentence wrap.
  var MIN_HITS_FOR_SENTENCE = 1;
  for (var n = 0; n < nodes.length && totalHighlights < MAX; n++) {
    var node = nodes[n];
    var text = node.nodeValue;
    var sentenceRe = /[^.!?\n]+(?:[.!?]+|$)/g;
    var ranges = [];
    var m;
    while ((m = sentenceRe.exec(text)) !== null) {
      var sentence = m[0];
      var sentTrim = sentence.replace(/^\s+|\s+$/g, '');
      if (sentTrim.length < 8) continue;
      var sentLower = sentence.toLowerCase();
      var hits = 0;
      // Track DISTINCT term matches so the same term repeated in
      // a sentence still counts as 1.
      var matchedTerms = {};
      for (var ti = 0; ti < terms.length; ti++) {
        if (!matchedTerms[terms[ti]] && sentLower.indexOf(terms[ti]) >= 0) {
          matchedTerms[terms[ti]] = 1;
          hits++;
        }
      }
      if (hits >= MIN_HITS_FOR_SENTENCE) {
        var s = m.index;
        var e = s + sentence.length;
        while (s < e && /\s/.test(text.charAt(s))) s++;
        if (s < e) ranges.push({ s: s, e: e });
      }
    }
    if (ranges.length === 0) continue;
    var parent = node.parentNode;
    var cursor = 0;
    var frag = document.createDocumentFragment();
    for (var r = 0; r < ranges.length && totalHighlights < MAX; r++) {
      var range = ranges[r];
      if (range.s > cursor) {
        frag.appendChild(document.createTextNode(text.substring(cursor, range.s)));
      }
      var mk = document.createElement('mark');
      mk.className = markClass;
      mk.textContent = text.substring(range.s, range.e);
      frag.appendChild(mk);
      if (!firstMark) firstMark = mk;
      cursor = range.e;
      totalHighlights++;
    }
    if (cursor < text.length) {
      frag.appendChild(document.createTextNode(text.substring(cursor)));
    }
    parent.replaceChild(frag, node);
  }
  return firstMark;
}

/* v5.4.9 — Keyword-level highlighter. Wraps every occurrence of every
   query term in <mark.term-hit>, without sentence wrapping. Used as
   the entire highlight pass in "keyword" mode, and as a complement
   to highlightSentencesIn in "smart" mode (so terms inside headings
   still get a small mark). */
function wrapMatchesAllTerms(root, terms) {
  if (!root || !terms || terms.length === 0) return null;
  var firstMark = null;
  var totalHighlights = 0;
  var MAX = 200;
  for (var ti = 0; ti < terms.length && totalHighlights < MAX; ti++) {
    var term = terms[ti];
    if (!term) continue;
    var got = wrapMatches(root, term);
    if (got && !firstMark) firstMark = got;
    totalHighlights += 1;
  }
  return firstMark;
}

function highlightTerm(raw, mode, isPhrase, snippetText) {
  try {
    var content = document.getElementById('content');
    if (!content) return;
    clearTermHighlights();
    snippetText = snippetText || '';

    // ---- Strategy 1: Snippet match (most precise) ----
    // The FTS snippet is literal article text the search engine already
    // matched — best possible needle for finding the exact passage.
    if (snippetText.length >= 6) {
      var snipClean = snippetText.replace(/\s+/g, ' ').trim();
      var found = wrapMatches(content, snipClean);
      if (found) { doScrollAndFlash(found); return; }
      // Try each sentence-ish chunk of the snippet
      var snipSentences = snipClean.split(/[.!?\n]+/).filter(function(s){
        return s.trim().length >= 10;
      });
      for (var si = 0; si < snipSentences.length; si++) {
        clearTermHighlights();
        found = wrapMatches(content, snipSentences[si].trim());
        if (found) { doScrollAndFlash(found); return; }
      }
      // Try the longer half of the snippet
      if (snipClean.length >= 20) {
        var mid = Math.floor(snipClean.length / 2);
        var sp = snipClean.indexOf(' ', mid);
        if (sp < 0 || sp > mid + 15) sp = mid;
        var halves = [snipClean.substring(0, sp).trim(),
                      snipClean.substring(sp).trim()];
        halves.sort(function(a,b){return b.length - a.length;});
        for (var hi = 0; hi < halves.length; hi++) {
          if (halves[hi].length < 8) continue;
          clearTermHighlights();
          found = wrapMatches(content, halves[hi]);
          if (found) { doScrollAndFlash(found); return; }
        }
      }
      clearTermHighlights();
    }

    // ---- Strategy 2: Full query as phrase ----
    if (isPhrase === true || raw.length >= 6) {
      var phrase = ('' + raw).replace(/^"+|"+$/g, '')
                             .replace(/^'+|'+$/g, '').trim();
      if (phrase.length >= 4) {
        var phraseFirst = wrapMatches(content, phrase);
        if (phraseFirst) { doScrollAndFlash(phraseFirst); return; }
        clearTermHighlights();
      }
    }

    // ---- Strategy 3: Sentence-level smart match ----
    var terms = extractQueryTerms(raw);
    var effectiveMode = (mode === 'keyword') ? 'keyword' : 'smart';
    if (effectiveMode === 'smart' && terms.length > 0) {
      var sentFirst = highlightSentencesIn(content, terms, 'term-hit');
      if (sentFirst) { doScrollAndFlash(sentFirst); return; }
      clearTermHighlights();
    }

    // ---- Strategy 4: Word-level keyword match ----
    if (terms.length > 0) {
      var wordFirst = (effectiveMode === 'keyword')
        ? wrapMatchesAllTerms(content, terms)
        : wrapMatchesAllTerms(content, terms);
      if (wordFirst) { doScrollAndFlash(wordFirst); return; }
      clearTermHighlights();
    }

    // ---- Strategy 5: Single best word fallback ----
    var bodyLower = content.textContent.toLowerCase();
    var chosen = pickHighlightTerm(raw, bodyLower);
    if (chosen) {
      var lastFirst = wrapMatches(content, chosen);
      if (lastFirst) { doScrollAndFlash(lastFirst); return; }
    }
  } catch (e) {}
}

function doScrollAndFlash(first) {
  var doScroll = function () {
    try { first.scrollIntoView({ block: 'center' }); }
    catch (e) { try { first.scrollIntoView(); } catch (_) {} }
    var hits = document.querySelectorAll('.term-hit, mark.term-hit');
    for (var j = 0; j < hits.length; j++) hits[j].classList.add('flash');
    setTimeout(function () {
      var h2 = document.querySelectorAll('.term-hit.flash, mark.term-hit.flash');
      for (var k = 0; k < h2.length; k++) h2[k].classList.remove('flash');
    }, 2400);
  };
  if (window.requestAnimationFrame) {
    window.requestAnimationFrame(function () {
      window.requestAnimationFrame(doScroll);
    });
  } else {
    setTimeout(doScroll, 50);
  }
}

/* ════════════════════════════════════════════════════════════════════════
 *  v5.4.60 — EXTENSION: MERMAID DIAGRAM RENDERER
 *
 *  Kotlin's MermaidProcessor.preprocess() converts ```mermaid fenced
 *  blocks to:
 *    <div class="mermaid" data-raw="1">...HTML-escaped diagram source...</div>
 *
 *  renderMermaidDiagrams() finds those divs and either:
 *    (a) Calls window.mermaid.init() if Mermaid.js is loaded (bundle
 *        mermaid.min.js in assets and add a <script> tag to viewer.html
 *        to enable fully offline diagram rendering), OR
 *    (b) Falls back to a styled <pre class="mermaid-source"> block so
 *        the diagram source is always readable even without Mermaid.js.
 *
 *  The feature can be disabled at runtime by setting MERMAID_ENABLED=false.
 * ════════════════════════════════════════════════════════════════════════ */
var MERMAID_ENABLED = true;

function renderMermaidDiagrams(root) {
  if (!MERMAID_ENABLED) return;
  var divs = root.querySelectorAll('div.mermaid[data-raw]');
  if (!divs.length) return;

  if (typeof window.mermaid !== 'undefined') {
    // Mermaid.js is available — decode HTML entities first, then render.
    for (var i = 0; i < divs.length; i++) {
      try {
        var div = divs[i];
        var src = div.textContent || div.innerText || '';
        // Decode the entities that MermaidProcessor encoded
        src = src.replace(/&lt;/g, '<').replace(/&gt;/g, '>').replace(/&amp;/g, '&');
        div.textContent = src;
        div.removeAttribute('data-raw');
      } catch (e) {}
    }
    try {
      window.mermaid.initialize({ startOnLoad: false, theme: 'dark' });
      window.mermaid.init(undefined, root.querySelectorAll('div.mermaid:not([data-raw])'));
    } catch (e) {
      // mermaid.init failed — fall back to source display for all divs
      var remaining = root.querySelectorAll('div.mermaid');
      for (var j = 0; j < remaining.length; j++) { _mermaidFallback(remaining[j]); }
    }
  } else {
    // Mermaid.js not loaded — show a styled code block with the source
    for (var k = 0; k < divs.length; k++) { _mermaidFallback(divs[k]); }
  }
}

function _mermaidFallback(div) {
  // Decode the HTML-escaped source (MermaidProcessor.preprocess encoded it)
  var src = (div.textContent || div.innerText || '')
    .replace(/&lt;/g, '<').replace(/&gt;/g, '>').replace(/&amp;/g, '&');
  var pre  = document.createElement('pre');
  pre.className = 'mermaid-source';
  var code = document.createElement('code');
  code.className = 'language-mermaid';
  code.textContent = src;
  pre.appendChild(code);
  if (div.parentNode) div.parentNode.replaceChild(pre, div);
}

/* ════════════════════════════════════════════════════════════════════════
 *  v5.4.60 — EXTENSION: AUTOMATIC SCRIPTURE DETECTION & LINKING
 *
 *  Walks rendered text nodes and converts plain-text scripture references
 *  into tappable <a class="scripture-link"> elements that open in the
 *  JW Library app via the jw.org/finder deep-link scheme.
 *
 *  ReaderScreen / JwLibraryLinks.routeLink() already routes these URLs to
 *  JW_LIBRARY_APP — no Kotlin-side changes needed.
 *
 *  Patterns detected:
 *    John 3:16        Matthew 24:45-47    1 Cor 13:4
 *    Genesis 1:1      Rev 21:4            Psalm 83:18
 *
 *  Skipped nodes: <a>, <code>, <pre>, <script>, <style> and their children.
 *  The feature can be disabled by setting SCRIPTURE_DETECTION_ENABLED=false.
 * ════════════════════════════════════════════════════════════════════════ */
var SCRIPTURE_DETECTION_ENABLED = true;

/* NWT book name / abbreviation → book number (1-66).
 * For numbered books (1/2 Samuel, 1/2 Kings …) the value is the FIRST
 * book's number; the numbered-book resolver adds (prefix-1) to it. */
var BOOK_NUM_MAP = {
  genesis:1, gen:1,
  exodus:2, ex:2, exod:2,
  leviticus:3, lev:3,
  numbers:4, num:4,
  deuteronomy:5, deut:5,
  joshua:6, josh:6, jos:6,
  judges:7, judg:7, jdg:7,
  ruth:8,
  samuel:9, sam:9,      /* 1=9, 2=10 */
  kings:11, king:11,    /* 1=11, 2=12 */
  chronicles:13, chron:13, chr:13, /* 1=13, 2=14 */
  ezra:15,
  nehemiah:16, neh:16,
  esther:17, esth:17,
  job:18,
  psalms:19, psalm:19, ps:19,
  proverbs:20, prov:20, pr:20,
  ecclesiastes:21, eccl:21, ecc:21,
  song:22, songs:22,
  isaiah:23, isa:23,
  jeremiah:24, jer:24,
  lamentations:25, lam:25,
  ezekiel:26, ezek:26, eze:26,
  daniel:27, dan:27,
  hosea:28, hos:28,
  joel:29,
  amos:30,
  obadiah:31, obad:31,
  jonah:32,
  micah:33, mic:33,
  nahum:34, nah:34,
  habakkuk:35, hab:35,
  zephaniah:36, zeph:36,
  haggai:37, hag:37,
  zechariah:38, zech:38,
  malachi:39, mal:39,
  matthew:40, matt:40, mat:40, mt:40,
  mark:41, mk:41,
  luke:42, luk:42, lk:42,
  john:43, joh:43, jn:43,  /* 2 John=63, 3 John=64 via prefix */
  acts:44,
  romans:45, rom:45,
  corinthians:46, cor:46,  /* 1=46, 2=47 */
  galatians:48, gal:48,
  ephesians:49, eph:49,
  philippians:50, phil:50,
  colossians:51, col:51,
  thessalonians:52, thess:52, thes:52, /* 1=52, 2=53 */
  timothy:54, tim:54, /* 1=54, 2=55 */
  titus:56, tit:56,
  philemon:57, philem:57,
  hebrews:58, heb:58,
  james:59, jas:59,
  peter:60, pet:60,  /* 1=60, 2=61 */
  jude:65,
  revelation:66, rev:66, re:66
};

/* Numbered-book adjustment: for books whose map value is the FIRST
 * book's number, add (prefix - 1) to get the right number. */
var NUMBERED_BOOKS = {
  samuel:1, sam:1, kings:1, king:1, chronicles:1, chron:1, chr:1,
  corinthians:1, cor:1, thessalonians:1, thess:1, thes:1,
  timothy:1, tim:1, peter:1, pet:1
};
/* John is special: 1 John stays at 62, 2 John=63, 3 John=64 */
var JOHN_KEYS = { john:1, joh:1, jn:1 };

function _resolveBookNum(prefix, bookKey) {
  var base = BOOK_NUM_MAP[bookKey];
  if (base === undefined) return null;
  var n = prefix ? parseInt(prefix, 10) : 0;
  if (!n) return base;
  if (NUMBERED_BOOKS[bookKey]) return base + (n - 1);
  if (JOHN_KEYS[bookKey])      return n > 1 ? 61 + n : base;  /* 2=63, 3=64 */
  return base;
}

function _buildFinderUrl(bookNum, chapter, verse) {
  var bk = ('0' + bookNum).slice(-2);
  var ch = ('00' + chapter).slice(-3);
  var vs = ('00' + verse).slice(-3);
  return 'https://www.jw.org/finder?srcid=jwlshare&wtlocale=E&prefer=lang' +
         '&bible=' + bk + ch + vs + '&pub=nwtsty';
}

/* Regex that matches scripture references inside a text node.
 * Capture groups: 1=optional prefix (1/2/3), 2=book name, 3=chapter, 4=verse, 5=end verse.
 * No lookbehind — intentionally omitted for broad Android WebView compatibility
 * (lookbehind landed in Chrome 62; older WebView builds lack it). False positives
 * are filtered by checking the book name against BOOK_NUM_MAP. */
var SCRIPTURE_TEXT_RE = /(?:(1|2|3)\s+)?([A-Z][a-zA-Z]+(?:\s+[A-Z][a-zA-Z]+)?)\s+(\d{1,3}):(\d{1,3})(?:[-\u2013](\d{1,3}))?/g;

function autoLinkScriptures(root) {
  if (!SCRIPTURE_DETECTION_ENABLED) return;
  var SKIP = { A:1, CODE:1, PRE:1, SCRIPT:1, STYLE:1, MARK:1, TEXTAREA:1 };
  // Collect text nodes first (avoid live DOM modification during walk)
  var pending = [];
  (function walk(n) {
    if (n.nodeType === 1) {
      if (SKIP[n.tagName]) return;
      // Don't process inside scripture links we already created
      if (n.tagName === 'A' && n.classList.contains('scripture-link')) return;
      for (var i = 0; i < n.childNodes.length; i++) walk(n.childNodes[i]);
    } else if (n.nodeType === 3) {
      // Only bother with text that contains a colon (chapter:verse pattern)
      if (n.nodeValue && n.nodeValue.indexOf(':') >= 0) pending.push(n);
    }
  })(root);

  for (var p = 0; p < pending.length; p++) {
    var tn = pending[p];
    if (!tn.parentNode) continue;  // may have been removed by earlier iteration
    var text = tn.nodeValue;
    SCRIPTURE_TEXT_RE.lastIndex = 0;
    var hasMatch = SCRIPTURE_TEXT_RE.test(text);
    SCRIPTURE_TEXT_RE.lastIndex = 0;
    if (!hasMatch) continue;

    var frag = document.createDocumentFragment();
    var last = 0, m;
    while ((m = SCRIPTURE_TEXT_RE.exec(text)) !== null) {
      var prefix  = m[1] || '';
      var bookRaw = m[2] || '';
      var bookKey = bookRaw.toLowerCase().replace(/\s+/g, '');
      // Also try the multi-word form (e.g. "Song of Solomon" → key "songofsolomon")
      // For now try the first word as a fallback
      var bookNum = _resolveBookNum(prefix, bookKey)
                 || _resolveBookNum(prefix, bookRaw.split(' ')[0].toLowerCase());
      if (!bookNum) continue;

      var chapter = parseInt(m[3], 10);
      var verse   = parseInt(m[4], 10);
      var url     = _buildFinderUrl(bookNum, chapter, verse);

      // Text before the match
      if (m.index > last) {
        frag.appendChild(document.createTextNode(text.substring(last, m.index)));
      }
      var a = document.createElement('a');
      a.className = 'scripture-link';
      a.href = url;
      a.textContent = m[0];
      frag.appendChild(a);
      last = m.index + m[0].length;
    }
    if (last === 0) continue;  // no matches were actually turned into links
    if (last < text.length) {
      frag.appendChild(document.createTextNode(text.substring(last)));
    }
    tn.parentNode.replaceChild(frag, tn);
  }
}

window.renderMarkdown = renderMarkdown;
window.highlightTerm = highlightTerm;
window.setFontScale = setFontScale;
window.setTheme = setTheme;
window.collapseAllCallouts = collapseAllCallouts;
window.expandAllCallouts = expandAllCallouts;
window.getScroll = getScroll;
window.restoreScroll = restoreScroll;
window.renderMermaidDiagrams = renderMermaidDiagrams;
window.autoLinkScriptures = autoLinkScriptures;
