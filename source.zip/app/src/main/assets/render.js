/* MarkVault render engine v2 — Obsidian/Claude-grade, fully offline */
/*
 * v4.18.0 — markdown-it removed; parsing now happens in Kotlin via
 * flexmark-java (see MarkdownEngine.kt). This file is now a thin
 * post-processor that runs after the pre-rendered HTML lands in the DOM:
 *   - transformCallouts:  > [!info] → styled callouts (uses ICONS / ALIAS)
 *   - transformTasks:     - [ ] / - [x] → checkboxes
 *   - transformWikilinks: safety-net for stray [[…]] flexmark didn't catch
 *   - setupHeadings:      heading anchors
 *   - cleanOrphanHtmlFragments: scrub leaked attribute fragments
 *   - applyContrast / setTheme / highlightTerm
 *
 * v5.4.124cc — transformCallouts now actually receives real
 * `<blockquote>` elements: a Kotlin-side preprocessor used to intercept
 * `> [!TYPE]` text and rewrite it into a plain div before flexmark ever
 * ran, which meant this function's icon/fold/title/alias logic never got
 * anything to operate on. That interception is gone now, so everything
 * below (already fully built) actually runs.
 *
 * `==highlight==`, `[^footnote]`, `x^sup^`/`H~sub~`, and definition lists
 * are handled Kotlin-side now (MarkdownEngine.kt preprocessors), not
 * here — mentioned only so this file isn't mistaken for the place to add
 * them. Raw `<u>` and `<mark>` HTML still work because flexmark passes
 * inline HTML through.
 */

var ICONS = {
  note:'\uD83D\uDCDD', info:'\u2139\uFE0F', tip:'\uD83D\uDCA1', success:'\u2705',
  warning:'\u26A0\uFE0F', caution:'\uD83D\uDD25', danger:'\u26D4', error:'\u274C',
  quote:'\uD83D\uDCAC', question:'\u2753', example:'\uD83D\uDD0E', abstract:'\uD83D\uDCCB'
};
var ALIAS = {
  summary:'abstract', tldr:'abstract', hint:'tip', important:'tip', check:'success',
  done:'success', fail:'error', failure:'error', missing:'error', bug:'error',
  faq:'question', help:'question', todo:'info', attention:'warning', cite:'quote'
};


/**
 * v5.4.125cc — KaTeX math typesetting.
 *
 * MarkdownEngine.kt's preprocessMath wraps `$inline$`, `$$block$$`,
 * `\(inline\)`, and `\[block\]` LaTeX source in `.math-inline` /
 * `.math-block` containers holding the raw (HTML-escaped-then-restored)
 * LaTeX as text content. This function typesets them client-side via
 * KaTeX -- chosen over MathJax for being substantially faster to render
 * and lighter to bundle, which matters more on mobile, and over a native
 * Compose renderer because it would mean a second rendering pipeline
 * outside the WebView this app already renders everything through.
 *
 * KaTeX's JS/CSS/font assets are NOT bundled in this repo snapshot --
 * see app/src/main/assets/katex/README.md for exactly what to add and
 * where. Until they are, `typeof katex === 'undefined'` below is true and
 * this function is a no-op: math source stays visible as plain text
 * (what already happened before this feature existed) instead of the
 * page crashing or rendering blank.
 */
function typesetMath(root) {
  if (typeof katex === 'undefined') return;
  root.querySelectorAll('.math-block').forEach(function (el) {
    var tex = el.textContent;
    try {
      katex.render(tex, el, { displayMode: true, throwOnError: false });
    } catch (e) {
      // Leave the raw LaTeX text visible rather than an empty element.
    }
  });
  root.querySelectorAll('.math-inline').forEach(function (el) {
    var tex = el.textContent;
    try {
      katex.render(tex, el, { displayMode: false, throwOnError: false });
    } catch (e) {}
  });
}

function transformEmbedPlaceholders(root) {
  root.querySelectorAll('.markdown-embed[data-note]').forEach(function (el) {
    var note = el.getAttribute('data-note') || '';
    el.className = 'markdown-embed-placeholder';
    el.innerHTML = '<div class="embed-title">Embedded note</div><a class="wikilink" href="mv://wiki/' +
      encodeURIComponent(note) + '">' + note.replace(/</g, '&lt;').replace(/>/g, '&gt;') +
      '</a>';
  });
}

function transformCallouts(root) {
  root.querySelectorAll('blockquote').forEach(function (bq) {
    var first = bq.querySelector('p');
    if (!first) return;
    var m = first.innerHTML.match(/^\s*\[!(\w+)\]([+-]?)\s*([\s\S]*)/i);
    if (!m) return;
    var type = m[1].toLowerCase(); type = ALIAS[type] || type;
    if (!ICONS[type]) type = 'note';
    var sign = m[2], rest = m[3];
    var foldable = sign === '+' || sign === '-';
    var collapsed = sign === '-';

    var div = document.createElement('div');
    div.className = 'callout cl-' + type + (foldable ? ' foldable' : '') + (collapsed ? ' collapsed' : '');

    var splitFirst = rest.split(/<br\s*\/?>([\s\S]*)/i);
    var titleText = (splitFirst[0] || '').trim() || (type.charAt(0).toUpperCase() + type.slice(1));

    var title = document.createElement('div');
    title.className = 'callout-title';
    title.innerHTML =
      (foldable ? '<span class="chevron">\u25B8</span>' : '') +
      '<span class="ic">' + ICONS[type] + '</span><span class="ct">' + titleText + '</span>';
    div.appendChild(title);

    var body = document.createElement('div');
    body.className = 'callout-body';
    if (splitFirst[1]) { var p = document.createElement('p'); p.innerHTML = splitFirst[1]; body.appendChild(p); }
    var sib = first.nextElementSibling;
    while (sib) { var next = sib.nextElementSibling; body.appendChild(sib); sib = next; }
    div.appendChild(body);

    if (foldable) {
      title.addEventListener('click', function () { div.classList.toggle('collapsed'); });
    }
    bq.parentNode.replaceChild(div, bq);
  });
}

function transformTasks(root) {
  root.querySelectorAll('li').forEach(function (li) {
    var m = li.innerHTML.match(/^\s*\[([ xX])\]\s+([\s\S]*)/);
    if (!m) return;
    li.classList.add('task');
    if (m[1].toLowerCase() === 'x') li.classList.add('done');
    li.innerHTML = '<span class="box"></span><span class="label">' + m[2] + '</span>';
  });
}

function transformWikilinks(root) {
  var pending = [];
  (function rec(n) {
    for (var i = 0; i < n.childNodes.length; i++) {
      var c = n.childNodes[i];
      if (c.nodeType === 3) { if (/\[\[/.test(c.nodeValue)) pending.push(c); }
      else if (c.nodeType === 1) {
        var t = c.tagName.toLowerCase();
        if (t !== 'code' && t !== 'pre' && t !== 'a') rec(c);
      }
    }
  })(root);
  pending.forEach(function (tn) {
    var span = document.createElement('span');
    // [[Target]]   or   [[Target|Alias]]   or   [[Target#section]]   or   [[Target^block]]
    span.innerHTML = tn.nodeValue.replace(
      /\[\[([^\[\]\n|#^]+)(?:#[^\[\]\n|]*)?(?:\^[^\[\]\n|]*)?(?:\|([^\[\]\n]+))?\]\]/g,
      function (_, target, alias) {
        var label = (alias || target).replace(/</g, '&lt;').replace(/>/g, '&gt;');
        var href = 'mv://wiki/' + encodeURIComponent(target.trim());
        return '<a class="wikilink" href="' + href + '">' + label + '</a>';
      }
    );
    tn.parentNode.replaceChild(span, tn);
  });
}

/* Outline anchors + collapsible headings (top-level only) */
function setupHeadings(root) {
  var hs = root.querySelectorAll('#content > h1, #content > h2, #content > h3, #content > h4, #content > h5, #content > h6');
  hs.forEach(function (h, i) {
    h.id = 'sec-' + i;
    h.classList.add('foldable-h');
    h.addEventListener('click', function () {
      var lvl = parseInt(h.tagName.substring(1), 10);
      var collapsed = h.classList.toggle('h-collapsed');
      var sib = h.nextElementSibling;
      while (sib) {
        if (/^H[1-6]$/.test(sib.tagName) && parseInt(sib.tagName.substring(1), 10) <= lvl) break;
        sib.style.display = collapsed ? 'none' : '';
        sib = sib.nextElementSibling;
      }
    });
  });
}

function renderMarkdown(src, scale, theme, smartStylingAll, contrast) {
  // v4.18.0 — `src` is now PRE-RENDERED HTML produced by Kotlin's flexmark
  // engine (MarkdownEngine.kt), not raw markdown. markdown-it is no longer
  // loaded. We still keep the same function name and signature so every
  // caller (ReaderScreen, SplitReaderScreen, ExternalReaderActivity) works
  // unchanged.
  //
  // The `smartStylingAll` parameter is now ignored — smart-styling was the
  // source of the `"sm-num">1513` leak in articles and the user asked for it
  // removed entirely. The parameter stays in the signature for back-compat
  // with the existing call sites; new code can pass anything.
  document.documentElement.style.fontSize = (17 * (scale || 1)) + 'px';
  if (theme) setTheme(theme);
  applyContrast(contrast);
  var el = document.getElementById('content');
  el.innerHTML = src || '';
  // Post-processors that operate on the already-rendered DOM. flexmark has
  // already produced wikilink anchors with the correct `mv://wiki/<encoded>`
  // href, so `transformWikilinks` here is just a safety net for any literal
  // `[[…]]` that survived (e.g. inside HTML attributes that flexmark left
  // alone).
  try { transformCallouts(el); } catch (e) {}
  try { transformTasks(el); } catch (e) {}
  try { transformWikilinks(el); } catch (e) {}
  try { typesetMath(el); } catch (e) {}
  try { setupHeadings(el); } catch (e) {}
  // Last-resort scrub for any historically broken articles whose .md still
  // has orphan attribute fragments after sanitize.
  try { cleanOrphanHtmlFragments(el); } catch (e) {}
  // NOTE: scheduleSmartStyling() is intentionally NOT called. Smart styling
  // is removed in v4.18.0 — it was producing the `"sm-num">…` artefacts
  // visible in the article body when the wrapper-rewrite path failed.
  window.scrollTo(0, 0);
}

/**
 * Clean up text content that looks like an orphaned HTML attribute fragment.
 * Patterns matched (and removed) within plain-text nodes only:
 *   "sm-ref">       — class attribute fragment leaked from a broken <a> tag
 *   "name">         — same shape, any unknown class name
 *   class="...">    — full class attribute leak
 *   href="...">     — href leak
 * Skips nodes inside <code>, <pre>, <a>, <textarea>, <script>, <style>.
 */
function cleanOrphanHtmlFragments(root) {
  if (!root) return;
  var SKIP = { CODE:1, PRE:1, A:1, SCRIPT:1, STYLE:1, TEXTAREA:1, INPUT:1, BUTTON:1 };
  var stack = [root];
  while (stack.length) {
    var node = stack.pop();
    if (node.nodeType === 1) {
      if (SKIP[node.tagName]) continue;
      // Walk children in reverse so we can stack them
      for (var i = node.childNodes.length - 1; i >= 0; i--) {
        stack.push(node.childNodes[i]);
      }
      continue;
    }
    if (node.nodeType !== 3) continue;   // TEXT_NODE
    var t = node.nodeValue;
    if (!t || t.length < 4) continue;
    // Only run regex if the text actually contains the suspicious pattern
    if (t.indexOf('">') < 0 && t.indexOf('class=') < 0 && t.indexOf('href=') < 0) continue;
    var cleaned = t
      // class="something"> at start or anywhere
      .replace(/\bclass\s*=\s*"[^"]*"\s*>/gi, '')
      .replace(/\bclass\s*=\s*'[^']*'\s*>/gi, '')
      // href="something">
      .replace(/\bhref\s*=\s*"[^"]*"\s*>/gi, '')
      .replace(/\bhref\s*=\s*'[^']*'\s*>/gi, '')
      // Bare attribute-value leak like "sm-ref">  or  "anything-or-other">
      .replace(/"([a-zA-Z][\w \-]{0,40})"\s*>/g, '')
      .replace(/'([a-zA-Z][\w \-]{0,40})'\s*>/g, '')
      // Collapse double spaces left behind
      .replace(/  +/g, ' ');
    if (cleaned !== t) node.nodeValue = cleaned;
  }
}

/* ════════════════════════════════════════════════════════════════════════
 *  SMART STYLING — chunked + idle-deferred
 *
 *  Strategy:
 *    1. Question-line classification is a cheap CSS-only tag — runs immediately.
 *    2. The inline-wrap pass (numbers, refs, percentages, "quotes", ALL-CAPS)
 *       creates MANY small DOM mutations on long articles. Deferred via
 *       requestIdleCallback so the article shows + scrolls first, then styling
 *       fills in when the browser is idle.
 *    3. The walker processes blocks in chunks of ~25, yielding back to the
 *       browser between chunks so scrolling stays responsive even on huge docs.
 *    4. A token aborts in-flight styling if the user navigates away —
 *       renderMarkdown bumps the token, old workers see the change and stop.
 * ════════════════════════════════════════════════════════════════════════ */

var SMART_SKIP_TAGS = { CODE:1, PRE:1, A:1, SCRIPT:1, STYLE:1, MARK:1, BUTTON:1, INPUT:1, TEXTAREA:1, H1:1, H2:1, H3:1, H4:1, H5:1, H6:1 };
var SMART_RUN_TOKEN = 0;

function scheduleSmartStyling(root, allDocs) {
  if (!root) return;
  // Bump token to cancel any in-flight styling from a previous article
  SMART_RUN_TOKEN++;
  var myToken = SMART_RUN_TOKEN;
  // Phase 1 — fast, immediate: tag question-lines (CSS-only, no spans)
  classifyQuestionLines(root);
  // Phase 2 — deferred inline wrapping. Skip for huge docs unless the user
  // opted in via Settings → Performance → Smart styling on all documents.
  var totalText = (root.textContent || '').length;
  if (!allDocs && totalText > 60000) return;
  var deferred = function () {
    if (myToken !== SMART_RUN_TOKEN) return;   // aborted (article changed)
    processChunked(root, myToken);
  };
  if (typeof window.requestIdleCallback === 'function') {
    window.requestIdleCallback(deferred, { timeout: 1500 });
  } else {
    // Older Android WebView lacks requestIdleCallback — fall back to a small
    // setTimeout so the first paint completes before styling begins.
    setTimeout(deferred, 350);
  }
}

function classifyQuestionLines(root) {
  var paragraphs = root.querySelectorAll('p');
  for (var i = 0; i < paragraphs.length; i++) {
    var p = paragraphs[i];
    var txt = (p.textContent || '').trim();
    if (txt.length > 8 && txt.length < 300 && /[?][\s]*$/.test(txt) &&
        !p.classList.contains('callout-body') && p.children.length < 4) {
      p.classList.add('sm-question-line');
    }
  }
}

function processChunked(root, myToken) {
  var blocks = root.querySelectorAll('p, li, td, blockquote');
  var i = 0;
  var CHUNK = 25;
  var step = function () {
    if (myToken !== SMART_RUN_TOKEN) return;   // aborted
    var end = Math.min(i + CHUNK, blocks.length);
    for (var j = i; j < end; j++) {
      try { walkAndWrap(blocks[j]); } catch (e) {}
    }
    i = end;
    if (i < blocks.length) {
      if (typeof window.requestIdleCallback === 'function') {
        window.requestIdleCallback(step, { timeout: 600 });
      } else {
        setTimeout(step, 16);
      }
    }
  };
  step();
}

// Backwards-compat shim
function applySmartStyling(root, allDocs) { scheduleSmartStyling(root, !!allDocs); }

function walkAndWrap(node) {
  if (!node) return;
  if (node.nodeType === 1) {
    if (SMART_SKIP_TAGS[node.tagName]) return;
    // Skip if a parent is already a smart class (avoid double-wrap)
    if (node.classList && (
      node.classList.contains('sm-key') ||
      node.classList.contains('sm-num') ||
      node.classList.contains('sm-ref') ||
      node.classList.contains('sm-pct')
    )) return;
    var kids = Array.prototype.slice.call(node.childNodes);
    for (var i = 0; i < kids.length; i++) walkAndWrap(kids[i]);
    return;
  }
  if (node.nodeType !== 3) return;          // 3 = TEXT_NODE
  var t = node.nodeValue;
  if (!t || t.length < 2) return;
  // SAFETY: a previous buggy render may have written literal `"sm-X">` characters
  // into this text node (visible to the user as `"sm-ref">"sm-ref">Surah 7:54`).
  // Strip those leaked attribute fragments BEFORE doing any matching so that
  // (a) the artifacts disappear from the rendered output and (b) the regex below
  // doesn't accidentally re-wrap them again. Idempotent — safe on clean text.
  var cleaned = t.replace(/[\u201C\u201D\u2018\u2019"']?sm-(?:ref|num|pct|acronym|quotechar|key|date|cap)[\u201C\u201D\u2018\u2019"']?>+/g, '');
  if (cleaned !== t) {
    t = cleaned;
    node.nodeValue = t;
  }
  // Combined pass: build replacement HTML
  var html = escapeHtml(t)
    // Bible-style refs: "John 3:16", "1 Cor 13:4-7", "Genesis 1:1-3" etc
    .replace(/\b([1-3]\s*)?(?:[A-Z][a-z]+|[A-Z][a-z]+\s[A-Z][a-z]+)\s\d{1,3}:\d{1,3}(?:[-\u2013]\d{1,3})?\b/g,
      function (m) { return '<span class="sm-ref">' + m + '</span>'; })
    // Percentages
    .replace(/\b\d{1,3}(?:\.\d+)?\s?%/g,
      function (m) { return '<span class="sm-pct">' + m + '</span>'; })
    // Years and longer numbers (≥3 digits, may include commas/decimals)
    .replace(/\b\d{1,3}(?:,\d{3})+(?:\.\d+)?\b|\b\d{3,}\b/g,
      function (m) { return '<span class="sm-num">' + m + '</span>'; })
    // ALL-CAPS acronyms (2-6 letters, surrounded by word boundaries)
    .replace(/\b[A-Z]{2,6}(?:s)?\b/g,
      function (m) { return '<span class="sm-acronym">' + m + '</span>'; })
    // "Quoted phrases" (curly or straight, 3-80 chars)
    .replace(/[\u201C\u201D"]([^"\u201C\u201D\n]{3,80})[\u201C\u201D"]/g,
      function (m, inner) { return '<span class="sm-quotechar">\u201C' + inner + '\u201D</span>'; });
  if (html === escapeHtml(t)) return;       // no changes
  var span = document.createElement('span');
  span.innerHTML = html;
  if (node.parentNode) node.parentNode.replaceChild(span, node);
}

function escapeHtml(s) {
  return s.replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;');
}

function setFontScale(scale) { document.documentElement.style.fontSize = (17 * (scale || 1)) + 'px'; }
function setTheme(name) {
  document.body.className = 'theme-' + (name || 'dark');
}

/**
 * v5.4.33 — Apply a custom theme by setting CSS custom properties directly on the body.
 * Called from Kotlin with a JSON string of var→value pairs.
 * Example: setCustomTheme('{"--bg":"#1e1e1e","--fg":"#dcddde",...}')
 */
function setCustomTheme(jsonStr) {
  document.body.className = 'theme-custom';
  try {
    var vars = JSON.parse(jsonStr);
    for (var key in vars) {
      if (vars.hasOwnProperty(key) && key.startsWith('--')) {
        document.body.style.setProperty(key, vars[key]);
      }
    }
  } catch(e) { /* silently ignore bad JSON */ }
}

/**
 * Strip leaked smart-styling artefacts from raw markdown.
 *
 * History: an earlier build of MarkVault wrote rendered HTML chunks back into
 * the source text on certain code paths (e.g. paste from the renderer back to
 * the source via copy actions). That left literal strings like
 *
 *      ("sm-ref">"sm-ref">"sm-ref">Surah 7:54)
 *
 * embedded in the .md files on disk. This helper removes those fragments AND
 * the orphan opening tags (e.g. `<span class="sm-ref">` with no matching close)
 * before the markdown renderer sees the text. Safe to apply repeatedly.
 */
function sanitizeMarkVaultArtifacts(src) {
  if (!src) return '';
  var s = String(src);
  // 1. Bare attribute-value fragments: "sm-ref">, "sm-num">, etc.
  //    Curly-quote and straight-quote variants are both handled.
  s = s.replace(/[\u201C\u201D\u2018\u2019"']?sm-(?:ref|num|pct|acronym|quotechar|key|date|cap)[\u201C\u201D\u2018\u2019"']?>+/g, '');
  // 2. Full leaked spans: <span class="sm-X">...</span>  →  ...
  s = s.replace(/<span\s+class\s*=\s*["']sm-[a-z]+["']\s*>([\s\S]*?)<\/span>/gi, '$1');
  // 3. Orphan opening tags left behind by interrupted renders.
  s = s.replace(/<span\s+class\s*=\s*["']sm-[a-z]+["']\s*>/gi, '');
  return s;
}

/**
 * Apply a contrast multiplier (1.0 .. 2.0) to the article body via a CSS filter.
 * Cheap, works on every WebView since Android 5. The slider in Settings just
 * bumps this value; renderMarkdown re-applies whenever a fresh article loads.
 */
function applyContrast(multiplier) {
  var m = parseFloat(multiplier) || 1.0;
  if (m < 1) m = 1;
  if (m > 2) m = 2;
  document.body.style.filter = (m > 1.01)
    ? ('contrast(' + m.toFixed(2) + ') saturate(' + Math.min(1.3, m).toFixed(2) + ')')
    : '';
}
function collapseAllCallouts() {
  document.querySelectorAll('.callout.foldable').forEach(function (c) { c.classList.add('collapsed'); });
}
function expandAllCallouts() {
  document.querySelectorAll('.callout.foldable').forEach(function (c) { c.classList.remove('collapsed'); });
}
function getScroll() { return window.scrollY || 0; }
function restoreScroll(y) { window.scrollTo(0, y || 0); }

/* ===== Jump-to-match (from full-text search) =====
   Behaviour:
   1. Tries the *whole phrase* first (case-insensitive, whitespace-tolerant).
   2. If the phrase isn't present, falls back to the longest content word
      from the query that does exist in the article.
   3. Wraps every occurrence in <span class="term-hit">, scrolls the first
      one into view, and flashes them briefly.
   Stopwords are only stripped from the *fallback* word pool, never used
   to reject the original phrase. */

function clearTermHighlights() {
  var hits = document.querySelectorAll('span.term-hit, mark.term-hit');
  for (var i = 0; i < hits.length; i++) {
    var h = hits[i];
    if (h.parentNode) {
      h.parentNode.replaceChild(document.createTextNode(h.textContent), h);
      h.parentNode.normalize && h.parentNode.normalize();
    }
  }
}

function wrapMatches(root, termLower) {
  var first = null, count = 0;
  var walker = document.createTreeWalker(root, NodeFilter.SHOW_TEXT, {
    acceptNode: function (node) {
      if (!node.nodeValue) return NodeFilter.FILTER_REJECT;
      var p = node.parentNode;
      if (!p) return NodeFilter.FILTER_REJECT;
      var tag = p.tagName;
      if (tag === 'SCRIPT' || tag === 'STYLE') return NodeFilter.FILTER_REJECT;
      return node.nodeValue.toLowerCase().indexOf(termLower) >= 0
        ? NodeFilter.FILTER_ACCEPT : NodeFilter.FILTER_REJECT;
    }
  });
  var nodes = [], n;
  while ((n = walker.nextNode())) { nodes.push(n); if (nodes.length > 500) break; }
  for (var i = 0; i < nodes.length; i++) {
    var node = nodes[i], text = node.nodeValue, lower = text.toLowerCase();
    var frag = document.createDocumentFragment(), idx = 0, pos;
    while ((pos = lower.indexOf(termLower, idx)) >= 0) {
      if (pos > idx) frag.appendChild(document.createTextNode(text.slice(idx, pos)));
      var span = document.createElement('span');
      span.className = 'term-hit';
      span.textContent = text.slice(pos, pos + termLower.length);
      frag.appendChild(span);
      if (!first) first = span;
      idx = pos + termLower.length;
      count++;
      if (count > 500) break;
    }
    if (idx < text.length) frag.appendChild(document.createTextNode(text.slice(idx)));
    if (node.parentNode) node.parentNode.replaceChild(frag, node);
    if (count > 500) break;
  }
  return first;
}

/* Words to skip ONLY when picking the fallback single word — never used to
   reject the user's full phrase. */
var FALLBACK_STOPWORDS = {
  the:1, is:1, a:1, an:1, of:1, to:1, and:1, in:1, on:1, for:1, at:1, by:1,
  are:1, was:1, were:1, be:1, been:1, being:1, it:1, its:1, this:1, that:1,
  these:1, those:1, with:1, from:1, as:1, or:1, but:1, if:1, so:1, do:1,
  does:1, did:1, has:1, have:1, had:1, will:1, would:1, can:1, could:1
};

function pickHighlightTerm(raw, bodyLower) {
  if (!raw) return null;
  var phrase = ('' + raw).trim();
  if (!phrase) return null;

  // Quoted phrase → strict
  if (phrase.length >= 2 && phrase.charAt(0) === '"' && phrase.charAt(phrase.length - 1) === '"') {
    var inner = phrase.slice(1, -1).toLowerCase().trim();
    return (inner && bodyLower.indexOf(inner) >= 0) ? inner : null;
  }

  // Normalise whitespace so "who   is" matches "who is"
  var normalised = phrase.toLowerCase().replace(/\s+/g, ' ').trim();
  if (!normalised) return null;

  // 1. Try the entire phrase
  if (bodyLower.indexOf(normalised) >= 0) return normalised;

  // 2. Try the phrase minus the trailing question mark / punctuation
  var stripped = normalised.replace(/[?!.,;:]+$/g, '').trim();
  if (stripped && stripped !== normalised && bodyLower.indexOf(stripped) >= 0) return stripped;

  // 3. Fallback: pick the longest meaningful word that exists in the body
  var words = normalised.split(/[^a-z0-9']+/i).filter(function (w) {
    return w && w.length >= 2;
  });
  // Prefer the longest non-stopword that actually appears
  words.sort(function (a, b) { return b.length - a.length; });
  for (var i = 0; i < words.length; i++) {
    var w = words[i];
    if (FALLBACK_STOPWORDS[w]) continue;
    if (bodyLower.indexOf(w) >= 0) return w;
  }
  // 4. Last resort: any word (including stopwords) that's present
  for (var j = 0; j < words.length; j++) {
    if (bodyLower.indexOf(words[j]) >= 0) return words[j];
  }
  return null;
}

/* v5.3.0 — Sentence-level highlight.
   Extract distinctive query terms from the input, walk text nodes, and
   wrap WHOLE SENTENCES that contain 1+ query term. This replaces the
   previous single-word picker so users can spot the matching passage
   immediately instead of hunting for a yellow word inside the paragraph.

   Same .term-hit class so the flash animation still applies.            */
var HL_STOPWORDS = {
  the:1, is:1, a:1, an:1, of:1, to:1, and:1, in:1, on:1, "for":1, at:1,
  by:1, are:1, was:1, were:1, be:1, been:1, being:1, it:1, its:1, this:1,
  that:1, these:1, those:1, with:1, from:1, as:1, or:1, but:1, "if":1,
  so:1, "do":1, does:1, did:1, has:1, have:1, had:1, will:1, would:1,
  can:1, could:1, what:1, who:1, why:1, how:1, when:1, where:1, which:1,
  about:1, not:1, no:1, also:1, more:1, some:1, any:1, all:1, one:1,
  two:1, you:1, your:1, my:1, we:1, our:1, us:1, me:1, he:1, she:1,
  they:1, them:1, their:1, his:1, her:1, "i":1
};

function extractQueryTerms(raw) {
  if (!raw) return [];
  var lower = ('' + raw).toLowerCase()
    .replace(/\[\[/g, ' ')
    .replace(/\]\]/g, ' ')
    .replace(/\.\.\./g, ' ')
    .replace(/[^a-z0-9'\s]/g, ' ')
    .replace(/\s+/g, ' ')
    .trim();
  var pieces = lower.split(' ');
  var seen = {};
  var out = [];
  for (var i = 0; i < pieces.length; i++) {
    var w = pieces[i];
    // v5.4.9 — bumped min length 3→4 to filter weak matches like
    // "and", "for", "the" that snuck past the stopwords list.
    if (w.length >= 4 && !HL_STOPWORDS[w] && !seen[w]) {
      seen[w] = 1;
      out.push(w);
    }
  }
  return out;
}

function highlightSentencesIn(root, terms, markClass) {
  if (!root || terms.length === 0) return null;
  var walker = document.createTreeWalker(
    root, NodeFilter.SHOW_TEXT,
    { acceptNode: function (node) {
        if (!node.nodeValue || !node.nodeValue.trim()) return NodeFilter.FILTER_REJECT;
        var p = node.parentElement;
        if (!p) return NodeFilter.FILTER_REJECT;
        var tag = (p.tagName || '').toLowerCase();
        if (tag === 'script' || tag === 'style' || tag === 'mark') return NodeFilter.FILTER_REJECT;
        // v5.4.9 — Skip headings entirely. Highlighting the whole
        // article title or section heading in yellow is overwhelming
        // and adds no information — the user already navigated to
        // this article from a search result, they don't need the
        // title shouting at them. Keyword-level highlighting via
        // wrapMatchesAllTerms still applies inside headings.
        if (tag === 'h1' || tag === 'h2' || tag === 'h3' ||
            tag === 'h4' || tag === 'h5' || tag === 'h6') {
          return NodeFilter.FILTER_REJECT;
        }
        // Walk up: also reject if any ancestor is a heading
        var ancestor = p.parentElement;
        while (ancestor && ancestor !== root) {
          var atag = (ancestor.tagName || '').toLowerCase();
          if (atag === 'h1' || atag === 'h2' || atag === 'h3' ||
              atag === 'h4' || atag === 'h5' || atag === 'h6') {
            return NodeFilter.FILTER_REJECT;
          }
          ancestor = ancestor.parentElement;
        }
        if (p.classList && (p.classList.contains(markClass) || p.classList.contains('term-hit')))
          return NodeFilter.FILTER_REJECT;
        return NodeFilter.FILTER_ACCEPT;
      } }, false);
  var nodes = [];
  while (walker.nextNode()) nodes.push(walker.currentNode);
  var firstMark = null;
  var totalHighlights = 0;
  var MAX = 40;
  // v5.4.16 — Threshold lowered to 1 (was 2 when terms.length >= 2).
  // The 2-term threshold, combined with v5.4.15's removal of the
  // word-level backfill, caused nothing to highlight when a doc had
  // query terms spread across separate sentences instead of co-
  // occurring. That's the "sometimes it highlights, sometimes it
  // doesn't" bug — now any sentence containing ANY query term gets
  // the full-sentence wrap.
  var MIN_HITS_FOR_SENTENCE = 1;
  for (var n = 0; n < nodes.length && totalHighlights < MAX; n++) {
    var node = nodes[n];
    var text = node.nodeValue;
    var sentenceRe = /[^.!?\n]+(?:[.!?]+|$)/g;
    var ranges = [];
    var m;
    while ((m = sentenceRe.exec(text)) !== null) {
      var sentence = m[0];
      var sentTrim = sentence.replace(/^\s+|\s+$/g, '');
      if (sentTrim.length < 8) continue;
      var sentLower = sentence.toLowerCase();
      var hits = 0;
      // Track DISTINCT term matches so the same term repeated in
      // a sentence still counts as 1.
      var matchedTerms = {};
      for (var ti = 0; ti < terms.length; ti++) {
        if (!matchedTerms[terms[ti]] && sentLower.indexOf(terms[ti]) >= 0) {
          matchedTerms[terms[ti]] = 1;
          hits++;
        }
      }
      if (hits >= MIN_HITS_FOR_SENTENCE) {
        var s = m.index;
        var e = s + sentence.length;
        while (s < e && /\s/.test(text.charAt(s))) s++;
        if (s < e) ranges.push({ s: s, e: e });
      }
    }
    if (ranges.length === 0) continue;
    var parent = node.parentNode;
    var cursor = 0;
    var frag = document.createDocumentFragment();
    for (var r = 0; r < ranges.length && totalHighlights < MAX; r++) {
      var range = ranges[r];
      if (range.s > cursor) {
        frag.appendChild(document.createTextNode(text.substring(cursor, range.s)));
      }
      var mk = document.createElement('mark');
      mk.className = markClass;
      mk.textContent = text.substring(range.s, range.e);
      frag.appendChild(mk);
      if (!firstMark) firstMark = mk;
      cursor = range.e;
      totalHighlights++;
    }
    if (cursor < text.length) {
      frag.appendChild(document.createTextNode(text.substring(cursor)));
    }
    parent.replaceChild(frag, node);
  }
  return firstMark;
}

/* v5.4.9 — Keyword-level highlighter. Wraps every occurrence of every
   query term in <mark.term-hit>, without sentence wrapping. Used as
   the entire highlight pass in "keyword" mode, and as a complement
   to highlightSentencesIn in "smart" mode (so terms inside headings
   still get a small mark). */
function wrapMatchesAllTerms(root, terms) {
  if (!root || !terms || terms.length === 0) return null;
  var firstMark = null;
  var totalHighlights = 0;
  var MAX = 200;
  for (var ti = 0; ti < terms.length && totalHighlights < MAX; ti++) {
    var term = terms[ti];
    if (!term) continue;
    var got = wrapMatches(root, term);
    if (got && !firstMark) firstMark = got;
    totalHighlights += 1;
  }
  return firstMark;
}

function highlightTerm(raw, mode, isPhrase, snippetText) {
  try {
    var content = document.getElementById('content');
    if (!content) return;
    clearTermHighlights();
    snippetText = snippetText || '';

    // ---- Strategy 1: Snippet match (most precise) ----
    // The FTS snippet is literal article text the search engine already
    // matched — best possible needle for finding the exact passage.
    if (snippetText.length >= 6) {
      var snipClean = snippetText.replace(/\s+/g, ' ').trim();
      var found = wrapMatches(content, snipClean);
      if (found) { doScrollAndFlash(found); return; }
      // Try each sentence-ish chunk of the snippet
      var snipSentences = snipClean.split(/[.!?\n]+/).filter(function(s){
        return s.trim().length >= 10;
      });
      for (var si = 0; si < snipSentences.length; si++) {
        clearTermHighlights();
        found = wrapMatches(content, snipSentences[si].trim());
        if (found) { doScrollAndFlash(found); return; }
      }
      // Try the longer half of the snippet
      if (snipClean.length >= 20) {
        var mid = Math.floor(snipClean.length / 2);
        var sp = snipClean.indexOf(' ', mid);
        if (sp < 0 || sp > mid + 15) sp = mid;
        var halves = [snipClean.substring(0, sp).trim(),
                      snipClean.substring(sp).trim()];
        halves.sort(function(a,b){return b.length - a.length;});
        for (var hi = 0; hi < halves.length; hi++) {
          if (halves[hi].length < 8) continue;
          clearTermHighlights();
          found = wrapMatches(content, halves[hi]);
          if (found) { doScrollAndFlash(found); return; }
        }
      }
      clearTermHighlights();
    }

    // ---- Strategy 2: Full query as phrase ----
    if (isPhrase === true || raw.length >= 6) {
      var phrase = ('' + raw).replace(/^"+|"+$/g, '')
                             .replace(/^'+|'+$/g, '').trim();
      if (phrase.length >= 4) {
        var phraseFirst = wrapMatches(content, phrase);
        if (phraseFirst) { doScrollAndFlash(phraseFirst); return; }
        clearTermHighlights();
      }
    }

    // ---- Strategy 3: Sentence-level smart match ----
    var terms = extractQueryTerms(raw);
    var effectiveMode = (mode === 'keyword') ? 'keyword' : 'smart';
    if (effectiveMode === 'smart' && terms.length > 0) {
      var sentFirst = highlightSentencesIn(content, terms, 'term-hit');
      if (sentFirst) { doScrollAndFlash(sentFirst); return; }
      clearTermHighlights();
    }

    // ---- Strategy 4: Word-level keyword match ----
    if (terms.length > 0) {
      var wordFirst = (effectiveMode === 'keyword')
        ? wrapMatchesAllTerms(content, terms)
        : wrapMatchesAllTerms(content, terms);
      if (wordFirst) { doScrollAndFlash(wordFirst); return; }
      clearTermHighlights();
    }

    // ---- Strategy 5: Single best word fallback ----
    var bodyLower = content.textContent.toLowerCase();
    var chosen = pickHighlightTerm(raw, bodyLower);
    if (chosen) {
      var lastFirst = wrapMatches(content, chosen);
      if (lastFirst) { doScrollAndFlash(lastFirst); return; }
    }
  } catch (e) {}
}

function doScrollAndFlash(first) {
  var doScroll = function () {
    try { first.scrollIntoView({ block: 'center' }); }
    catch (e) { try { first.scrollIntoView(); } catch (_) {} }
    var hits = document.querySelectorAll('.term-hit, mark.term-hit');
    for (var j = 0; j < hits.length; j++) hits[j].classList.add('flash');
    setTimeout(function () {
      var h2 = document.querySelectorAll('.term-hit.flash, mark.term-hit.flash');
      for (var k = 0; k < h2.length; k++) h2[k].classList.remove('flash');
    }, 2400);
  };
  if (window.requestAnimationFrame) {
    window.requestAnimationFrame(function () {
      window.requestAnimationFrame(doScroll);
    });
  } else {
    setTimeout(doScroll, 50);
  }
}

/* ── v5.4.76cc — LLM-trace overlay ────────────────────────────────────
 *
 * Runs AFTER `highlightTerm` has done its yellow-flash pass on the
 * user's original query. Wraps each paraphrase term from the Phi-4-mini
 * expander in <span class="llm-hit">, which viewer.css paints with a
 * soft lavender background (no flash, low alpha for readability). Nodes
 * that are already inside a `.term-hit` (the yellow highlight) or
 * <script>/<style>/<head> are skipped so we never clobber the primary
 * highlight or inject into non-visible chrome.
 *
 * The function is defensively idempotent — repeat calls first strip
 * any prior .llm-hit spans, so re-issuing after a scroll or re-render
 * doesn't compound wrapping. Wrapping is capped at MAX_LLM_HITS to
 * bound the cost on a 30,000-word article.
 */
var MAX_LLM_HITS = 400;

function clearLlmHighlights() {
  var hits = document.querySelectorAll('span.llm-hit');
  for (var i = 0; i < hits.length; i++) {
    var h = hits[i];
    if (h.parentNode) {
      h.parentNode.replaceChild(document.createTextNode(h.textContent), h);
      h.parentNode.normalize && h.parentNode.normalize();
    }
  }
}

function wrapLlmMatches(root, termLower, budgetLeft) {
  if (!root || !termLower || termLower.length < 3 || budgetLeft <= 0) return 0;
  var count = 0;
  var walker = document.createTreeWalker(root, NodeFilter.SHOW_TEXT, {
    acceptNode: function (node) {
      if (!node.nodeValue) return NodeFilter.FILTER_REJECT;
      var p = node.parentNode;
      if (!p) return NodeFilter.FILTER_REJECT;
      var tag = p.tagName;
      if (tag === 'SCRIPT' || tag === 'STYLE' ||
          tag === 'HEAD'   || tag === 'NOSCRIPT') return NodeFilter.FILTER_REJECT;
      // Skip if any ancestor is already a term-hit (yellow) or llm-hit
      // (lavender) — don't double-wrap or override the primary highlight.
      var a = p;
      while (a && a !== document.body) {
        if (a.classList && (a.classList.contains('term-hit') ||
                            a.classList.contains('llm-hit'))) {
          return NodeFilter.FILTER_REJECT;
        }
        a = a.parentNode;
      }
      return node.nodeValue.toLowerCase().indexOf(termLower) >= 0
        ? NodeFilter.FILTER_ACCEPT : NodeFilter.FILTER_REJECT;
    }
  });
  var nodes = [], n;
  while ((n = walker.nextNode())) { nodes.push(n); if (nodes.length > 2000) break; }
  for (var i = 0; i < nodes.length && count < budgetLeft; i++) {
    var node = nodes[i], text = node.nodeValue, lower = text.toLowerCase();
    var frag = document.createDocumentFragment(), idx = 0, pos;
    var mutated = false;
    while ((pos = lower.indexOf(termLower, idx)) >= 0) {
      if (pos > idx) frag.appendChild(document.createTextNode(text.slice(idx, pos)));
      var span = document.createElement('span');
      span.className = 'llm-hit';
      span.textContent = text.slice(pos, pos + termLower.length);
      frag.appendChild(span);
      idx = pos + termLower.length;
      count++;
      mutated = true;
      if (count >= budgetLeft) break;
    }
    if (mutated) {
      if (idx < text.length) frag.appendChild(document.createTextNode(text.slice(idx)));
      if (node.parentNode) node.parentNode.replaceChild(frag, node);
    }
  }
  return count;
}

function highlightLlmTerms(termsArray) {
  try {
    var content = document.getElementById('content');
    if (!content) return;
    if (!termsArray || !termsArray.length) return;
    clearLlmHighlights();
    // Longest paraphrase first so "friendship with God" wraps before
    // "friendship" and multi-word matches survive.
    var terms = termsArray.slice(0).map(function(t){ return ('' + t).toLowerCase().trim(); })
                                   .filter(function(t){ return t.length >= 3; });
    terms.sort(function(a, b){ return b.length - a.length; });
    var budget = MAX_LLM_HITS;
    for (var ti = 0; ti < terms.length && budget > 0; ti++) {
      var used = wrapLlmMatches(content, terms[ti], budget);
      budget -= used;
    }
  } catch (e) {
    try { console.log('mv-llm-highlight error: ' + e); } catch(_){}
  }
}

window.renderMarkdown = renderMarkdown;
window.highlightTerm = highlightTerm;
window.highlightLlmTerms = highlightLlmTerms;
window.setFontScale = setFontScale;
window.setTheme = setTheme;
window.collapseAllCallouts = collapseAllCallouts;
window.expandAllCallouts = expandAllCallouts;
window.getScroll = getScroll;
window.restoreScroll = restoreScroll;
