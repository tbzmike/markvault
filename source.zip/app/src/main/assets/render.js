/* MarkVault render engine v2 — Obsidian/Claude-grade, fully offline */

var md = window.markdownit({
  html: true, linkify: true, breaks: false, typographer: true,
  highlight: function (code, lang) {
    try {
      if (lang && window.hljs && hljs.getLanguage(lang)) {
        return '<pre><code class="hljs language-' + lang + '">' +
          hljs.highlight(code, { language: lang, ignoreIllegals: true }).value + '</code></pre>';
      }
      if (window.hljs) return '<pre><code class="hljs">' + hljs.highlightAuto(code).value + '</code></pre>';
    } catch (e) {}
    return '<pre><code class="hljs">' + md.utils.escapeHtml(code) + '</code></pre>';
  }
});

var ICONS = {
  note:'\uD83D\uDCDD', info:'\u2139\uFE0F', tip:'\uD83D\uDCA1', success:'\u2705',
  warning:'\u26A0\uFE0F', caution:'\uD83D\uDD25', danger:'\u26D4', error:'\u274C',
  quote:'\uD83D\uDCAC', question:'\u2753', example:'\uD83D\uDD0E', abstract:'\uD83D\uDCCB'
};
var ALIAS = {
  summary:'abstract', tldr:'abstract', hint:'tip', important:'tip', check:'success',
  done:'success', fail:'error', bug:'error', faq:'question', help:'question',
  todo:'info', attention:'warning', cite:'quote'
};

/* ==highlight== inline rule */
function markRule(state, silent) {
  var start = state.pos;
  if (state.src.charCodeAt(start) !== 0x3D || state.src.charCodeAt(start + 1) !== 0x3D) return false;
  var idx = state.src.slice(start + 2).indexOf('==');
  if (idx < 0) return false;
  var content = state.src.slice(start + 2, start + 2 + idx);
  if (!silent) {
    state.push('mark_open', 'mark', 1);
    var t = state.push('text', '', 0); t.content = content;
    state.push('mark_close', 'mark', -1);
  }
  state.pos = start + 4 + idx;
  return true;
}
md.inline.ruler.before('emphasis', 'mark', markRule);

function transformCallouts(root) {
  root.querySelectorAll('blockquote').forEach(function (bq) {
    var first = bq.querySelector('p');
    if (!first) return;
    var m = first.innerHTML.match(/^\s*\[!(\w+)\]([+-]?)\s*([\s\S]*)/i);
    if (!m) return;
    var type = m[1].toLowerCase(); type = ALIAS[type] || type;
    if (!ICONS[type]) type = 'note';
    var sign = m[2], rest = m[3];
    var foldable = sign === '+' || sign === '-';
    var collapsed = sign === '-';

    var div = document.createElement('div');
    div.className = 'callout cl-' + type + (foldable ? ' foldable' : '') + (collapsed ? ' collapsed' : '');

    var splitFirst = rest.split(/<br\s*\/?>([\s\S]*)/i);
    var titleText = (splitFirst[0] || '').trim() || (type.charAt(0).toUpperCase() + type.slice(1));

    var title = document.createElement('div');
    title.className = 'callout-title';
    title.innerHTML =
      (foldable ? '<span class="chevron">\u25B8</span>' : '') +
      '<span class="ic">' + ICONS[type] + '</span><span class="ct">' + titleText + '</span>';
    div.appendChild(title);

    var body = document.createElement('div');
    body.className = 'callout-body';
    if (splitFirst[1]) { var p = document.createElement('p'); p.innerHTML = splitFirst[1]; body.appendChild(p); }
    var sib = first.nextElementSibling;
    while (sib) { var next = sib.nextElementSibling; body.appendChild(sib); sib = next; }
    div.appendChild(body);

    if (foldable) {
      title.addEventListener('click', function () { div.classList.toggle('collapsed'); });
    }
    bq.parentNode.replaceChild(div, bq);
  });
}

function transformTasks(root) {
  root.querySelectorAll('li').forEach(function (li) {
    var m = li.innerHTML.match(/^\s*\[([ xX])\]\s+([\s\S]*)/);
    if (!m) return;
    li.classList.add('task');
    if (m[1].toLowerCase() === 'x') li.classList.add('done');
    li.innerHTML = '<span class="box"></span><span class="label">' + m[2] + '</span>';
  });
}

function transformWikilinks(root) {
  var pending = [];
  (function rec(n) {
    for (var i = 0; i < n.childNodes.length; i++) {
      var c = n.childNodes[i];
      if (c.nodeType === 3) { if (/\[\[/.test(c.nodeValue)) pending.push(c); }
      else if (c.nodeType === 1) {
        var t = c.tagName.toLowerCase();
        if (t !== 'code' && t !== 'pre' && t !== 'a') rec(c);
      }
    }
  })(root);
  pending.forEach(function (tn) {
    var span = document.createElement('span');
    // [[Target]]   or   [[Target|Alias]]   or   [[Target#section]]   or   [[Target^block]]
    span.innerHTML = tn.nodeValue.replace(
      /\[\[([^\[\]\n|#^]+)(?:#[^\[\]\n|]*)?(?:\^[^\[\]\n|]*)?(?:\|([^\[\]\n]+))?\]\]/g,
      function (_, target, alias) {
        var label = (alias || target).replace(/</g, '&lt;').replace(/>/g, '&gt;');
        var href = 'mv://wiki/' + encodeURIComponent(target.trim());
        return '<a class="wikilink" href="' + href + '">' + label + '</a>';
      }
    );
    tn.parentNode.replaceChild(span, tn);
  });
}

/* Outline anchors + collapsible headings (top-level only) */
function setupHeadings(root) {
  var hs = root.querySelectorAll('#content > h1, #content > h2, #content > h3, #content > h4, #content > h5, #content > h6');
  hs.forEach(function (h, i) {
    h.id = 'sec-' + i;
    h.classList.add('foldable-h');
    h.addEventListener('click', function () {
      var lvl = parseInt(h.tagName.substring(1), 10);
      var collapsed = h.classList.toggle('h-collapsed');
      var sib = h.nextElementSibling;
      while (sib) {
        if (/^H[1-6]$/.test(sib.tagName) && parseInt(sib.tagName.substring(1), 10) <= lvl) break;
        sib.style.display = collapsed ? 'none' : '';
        sib = sib.nextElementSibling;
      }
    });
  });
}

function renderMarkdown(src, scale, theme, smartStylingAll, contrast) {
  document.documentElement.style.fontSize = (17 * (scale || 1)) + 'px';
  if (theme) setTheme(theme);
  applyContrast(contrast);
  var el = document.getElementById('content');
  el.innerHTML = md.render(src || '');
  try { transformCallouts(el); } catch (e) {}
  try { transformTasks(el); } catch (e) {}
  try { transformWikilinks(el); } catch (e) {}
  try { setupHeadings(el); } catch (e) {}
  // Defensive: clean up orphaned HTML attribute fragments that can appear when
  // a malformed link from the source markdown got partially rendered.
  // Symptoms include text like ("sm-ref">1 Peter 2:13–17) showing in articles.
  try { cleanOrphanHtmlFragments(el); } catch (e) {}
  // Smart styling is DEFERRED — the article shows + scrolls instantly, then
  // styling fills in during idle time. See scheduleSmartStyling.
  try { scheduleSmartStyling(el, !!smartStylingAll); } catch (e) {}
  window.scrollTo(0, 0);
}

/**
 * Clean up text content that looks like an orphaned HTML attribute fragment.
 * Patterns matched (and removed) within plain-text nodes only:
 *   "sm-ref">       — class attribute fragment leaked from a broken <a> tag
 *   "name">         — same shape, any unknown class name
 *   class="...">    — full class attribute leak
 *   href="...">     — href leak
 * Skips nodes inside <code>, <pre>, <a>, <textarea>, <script>, <style>.
 */
function cleanOrphanHtmlFragments(root) {
  if (!root) return;
  var SKIP = { CODE:1, PRE:1, A:1, SCRIPT:1, STYLE:1, TEXTAREA:1, INPUT:1, BUTTON:1 };
  var stack = [root];
  while (stack.length) {
    var node = stack.pop();
    if (node.nodeType === 1) {
      if (SKIP[node.tagName]) continue;
      // Walk children in reverse so we can stack them
      for (var i = node.childNodes.length - 1; i >= 0; i--) {
        stack.push(node.childNodes[i]);
      }
      continue;
    }
    if (node.nodeType !== 3) continue;   // TEXT_NODE
    var t = node.nodeValue;
    if (!t || t.length < 4) continue;
    // Only run regex if the text actually contains the suspicious pattern
    if (t.indexOf('">') < 0 && t.indexOf('class=') < 0 && t.indexOf('href=') < 0) continue;
    var cleaned = t
      // class="something"> at start or anywhere
      .replace(/\bclass\s*=\s*"[^"]*"\s*>/gi, '')
      .replace(/\bclass\s*=\s*'[^']*'\s*>/gi, '')
      // href="something">
      .replace(/\bhref\s*=\s*"[^"]*"\s*>/gi, '')
      .replace(/\bhref\s*=\s*'[^']*'\s*>/gi, '')
      // Bare attribute-value leak like "sm-ref">  or  "anything-or-other">
      .replace(/"([a-zA-Z][\w \-]{0,40})"\s*>/g, '')
      .replace(/'([a-zA-Z][\w \-]{0,40})'\s*>/g, '')
      // Collapse double spaces left behind
      .replace(/  +/g, ' ');
    if (cleaned !== t) node.nodeValue = cleaned;
  }
}

/* ════════════════════════════════════════════════════════════════════════
 *  SMART STYLING — chunked + idle-deferred
 *
 *  Strategy:
 *    1. Question-line classification is a cheap CSS-only tag — runs immediately.
 *    2. The inline-wrap pass (numbers, refs, percentages, "quotes", ALL-CAPS)
 *       creates MANY small DOM mutations on long articles. Deferred via
 *       requestIdleCallback so the article shows + scrolls first, then styling
 *       fills in when the browser is idle.
 *    3. The walker processes blocks in chunks of ~25, yielding back to the
 *       browser between chunks so scrolling stays responsive even on huge docs.
 *    4. A token aborts in-flight styling if the user navigates away —
 *       renderMarkdown bumps the token, old workers see the change and stop.
 * ════════════════════════════════════════════════════════════════════════ */

var SMART_SKIP_TAGS = { CODE:1, PRE:1, A:1, SCRIPT:1, STYLE:1, MARK:1, BUTTON:1, INPUT:1, TEXTAREA:1, H1:1, H2:1, H3:1, H4:1, H5:1, H6:1 };
var SMART_RUN_TOKEN = 0;

function scheduleSmartStyling(root, allDocs) {
  if (!root) return;
  // Bump token to cancel any in-flight styling from a previous article
  SMART_RUN_TOKEN++;
  var myToken = SMART_RUN_TOKEN;
  // Phase 1 — fast, immediate: tag question-lines (CSS-only, no spans)
  classifyQuestionLines(root);
  // Phase 2 — deferred inline wrapping. Skip for huge docs unless the user
  // opted in via Settings → Performance → Smart styling on all documents.
  var totalText = (root.textContent || '').length;
  if (!allDocs && totalText > 60000) return;
  var deferred = function () {
    if (myToken !== SMART_RUN_TOKEN) return;   // aborted (article changed)
    processChunked(root, myToken);
  };
  if (typeof window.requestIdleCallback === 'function') {
    window.requestIdleCallback(deferred, { timeout: 1500 });
  } else {
    // Older Android WebView lacks requestIdleCallback — fall back to a small
    // setTimeout so the first paint completes before styling begins.
    setTimeout(deferred, 350);
  }
}

function classifyQuestionLines(root) {
  var paragraphs = root.querySelectorAll('p');
  for (var i = 0; i < paragraphs.length; i++) {
    var p = paragraphs[i];
    var txt = (p.textContent || '').trim();
    if (txt.length > 8 && txt.length < 300 && /[?][\s]*$/.test(txt) &&
        !p.classList.contains('callout-body') && p.children.length < 4) {
      p.classList.add('sm-question-line');
    }
  }
}

function processChunked(root, myToken) {
  var blocks = root.querySelectorAll('p, li, td, blockquote');
  var i = 0;
  var CHUNK = 25;
  var step = function () {
    if (myToken !== SMART_RUN_TOKEN) return;   // aborted
    var end = Math.min(i + CHUNK, blocks.length);
    for (var j = i; j < end; j++) {
      try { walkAndWrap(blocks[j]); } catch (e) {}
    }
    i = end;
    if (i < blocks.length) {
      if (typeof window.requestIdleCallback === 'function') {
        window.requestIdleCallback(step, { timeout: 600 });
      } else {
        setTimeout(step, 16);
      }
    }
  };
  step();
}

// Backwards-compat shim
function applySmartStyling(root, allDocs) { scheduleSmartStyling(root, !!allDocs); }

function walkAndWrap(node) {
  if (!node) return;
  if (node.nodeType === 1) {
    if (SMART_SKIP_TAGS[node.tagName]) return;
    // Skip if a parent is already a smart class (avoid double-wrap)
    if (node.classList && (
      node.classList.contains('sm-key') ||
      node.classList.contains('sm-num') ||
      node.classList.contains('sm-ref') ||
      node.classList.contains('sm-pct')
    )) return;
    var kids = Array.prototype.slice.call(node.childNodes);
    for (var i = 0; i < kids.length; i++) walkAndWrap(kids[i]);
    return;
  }
  if (node.nodeType !== 3) return;          // 3 = TEXT_NODE
  var t = node.nodeValue;
  if (!t || t.length < 2) return;
  // Combined pass: build replacement HTML
  var html = escapeHtml(t)
    // Bible-style refs: "John 3:16", "1 Cor 13:4-7", "Genesis 1:1-3" etc
    .replace(/\b([1-3]\s*)?(?:[A-Z][a-z]+|[A-Z][a-z]+\s[A-Z][a-z]+)\s\d{1,3}:\d{1,3}(?:[-\u2013]\d{1,3})?\b/g,
      function (m) { return '<span class="sm-ref">' + m + '</span>'; })
    // Percentages
    .replace(/\b\d{1,3}(?:\.\d+)?\s?%/g,
      function (m) { return '<span class="sm-pct">' + m + '</span>'; })
    // Years and longer numbers (≥3 digits, may include commas/decimals)
    .replace(/\b\d{1,3}(?:,\d{3})+(?:\.\d+)?\b|\b\d{3,}\b/g,
      function (m) { return '<span class="sm-num">' + m + '</span>'; })
    // ALL-CAPS acronyms (2-6 letters, surrounded by word boundaries)
    .replace(/\b[A-Z]{2,6}(?:s)?\b/g,
      function (m) { return '<span class="sm-acronym">' + m + '</span>'; })
    // "Quoted phrases" (curly or straight, 3-80 chars)
    .replace(/[\u201C\u201D"]([^"\u201C\u201D\n]{3,80})[\u201C\u201D"]/g,
      function (m, inner) { return '<span class="sm-quotechar">\u201C' + inner + '\u201D</span>'; });
  if (html === escapeHtml(t)) return;       // no changes
  var span = document.createElement('span');
  span.innerHTML = html;
  if (node.parentNode) node.parentNode.replaceChild(span, node);
}

function escapeHtml(s) {
  return s.replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;');
}

function setFontScale(scale) { document.documentElement.style.fontSize = (17 * (scale || 1)) + 'px'; }
function setTheme(name) {
  document.body.className = 'theme-' + (name || 'dark');
}

/**
 * Apply a contrast multiplier (1.0 .. 2.0) to the article body via a CSS filter.
 * Cheap, works on every WebView since Android 5. The slider in Settings just
 * bumps this value; renderMarkdown re-applies whenever a fresh article loads.
 */
function applyContrast(multiplier) {
  var m = parseFloat(multiplier) || 1.0;
  if (m < 1) m = 1;
  if (m > 2) m = 2;
  document.body.style.filter = (m > 1.01)
    ? ('contrast(' + m.toFixed(2) + ') saturate(' + Math.min(1.3, m).toFixed(2) + ')')
    : '';
}
function collapseAllCallouts() {
  document.querySelectorAll('.callout.foldable').forEach(function (c) { c.classList.add('collapsed'); });
}
function expandAllCallouts() {
  document.querySelectorAll('.callout.foldable').forEach(function (c) { c.classList.remove('collapsed'); });
}
function getScroll() { return window.scrollY || 0; }
function restoreScroll(y) { window.scrollTo(0, y || 0); }

/* ===== Jump-to-match (from full-text search) =====
   Behaviour:
   1. Tries the *whole phrase* first (case-insensitive, whitespace-tolerant).
   2. If the phrase isn't present, falls back to the longest content word
      from the query that does exist in the article.
   3. Wraps every occurrence in <span class="term-hit">, scrolls the first
      one into view, and flashes them briefly.
   Stopwords are only stripped from the *fallback* word pool, never used
   to reject the original phrase. */

function clearTermHighlights() {
  var hits = document.querySelectorAll('span.term-hit');
  for (var i = 0; i < hits.length; i++) {
    var h = hits[i];
    if (h.parentNode) {
      h.parentNode.replaceChild(document.createTextNode(h.textContent), h);
      h.parentNode.normalize && h.parentNode.normalize();
    }
  }
}

function wrapMatches(root, termLower) {
  var first = null, count = 0;
  var walker = document.createTreeWalker(root, NodeFilter.SHOW_TEXT, {
    acceptNode: function (node) {
      if (!node.nodeValue) return NodeFilter.FILTER_REJECT;
      var p = node.parentNode;
      if (!p) return NodeFilter.FILTER_REJECT;
      var tag = p.tagName;
      if (tag === 'SCRIPT' || tag === 'STYLE') return NodeFilter.FILTER_REJECT;
      return node.nodeValue.toLowerCase().indexOf(termLower) >= 0
        ? NodeFilter.FILTER_ACCEPT : NodeFilter.FILTER_REJECT;
    }
  });
  var nodes = [], n;
  while ((n = walker.nextNode())) { nodes.push(n); if (nodes.length > 500) break; }
  for (var i = 0; i < nodes.length; i++) {
    var node = nodes[i], text = node.nodeValue, lower = text.toLowerCase();
    var frag = document.createDocumentFragment(), idx = 0, pos;
    while ((pos = lower.indexOf(termLower, idx)) >= 0) {
      if (pos > idx) frag.appendChild(document.createTextNode(text.slice(idx, pos)));
      var span = document.createElement('span');
      span.className = 'term-hit';
      span.textContent = text.slice(pos, pos + termLower.length);
      frag.appendChild(span);
      if (!first) first = span;
      idx = pos + termLower.length;
      count++;
      if (count > 500) break;
    }
    if (idx < text.length) frag.appendChild(document.createTextNode(text.slice(idx)));
    if (node.parentNode) node.parentNode.replaceChild(frag, node);
    if (count > 500) break;
  }
  return first;
}

/* Words to skip ONLY when picking the fallback single word — never used to
   reject the user's full phrase. */
var FALLBACK_STOPWORDS = {
  the:1, is:1, a:1, an:1, of:1, to:1, and:1, in:1, on:1, for:1, at:1, by:1,
  are:1, was:1, were:1, be:1, been:1, being:1, it:1, its:1, this:1, that:1,
  these:1, those:1, with:1, from:1, as:1, or:1, but:1, if:1, so:1, do:1,
  does:1, did:1, has:1, have:1, had:1, will:1, would:1, can:1, could:1
};

function pickHighlightTerm(raw, bodyLower) {
  if (!raw) return null;
  var phrase = ('' + raw).trim();
  if (!phrase) return null;

  // Quoted phrase → strict
  if (phrase.length >= 2 && phrase.charAt(0) === '"' && phrase.charAt(phrase.length - 1) === '"') {
    var inner = phrase.slice(1, -1).toLowerCase().trim();
    return (inner && bodyLower.indexOf(inner) >= 0) ? inner : null;
  }

  // Normalise whitespace so "who   is" matches "who is"
  var normalised = phrase.toLowerCase().replace(/\s+/g, ' ').trim();
  if (!normalised) return null;

  // 1. Try the entire phrase
  if (bodyLower.indexOf(normalised) >= 0) return normalised;

  // 2. Try the phrase minus the trailing question mark / punctuation
  var stripped = normalised.replace(/[?!.,;:]+$/g, '').trim();
  if (stripped && stripped !== normalised && bodyLower.indexOf(stripped) >= 0) return stripped;

  // 3. Fallback: pick the longest meaningful word that exists in the body
  var words = normalised.split(/[^a-z0-9']+/i).filter(function (w) {
    return w && w.length >= 2;
  });
  // Prefer the longest non-stopword that actually appears
  words.sort(function (a, b) { return b.length - a.length; });
  for (var i = 0; i < words.length; i++) {
    var w = words[i];
    if (FALLBACK_STOPWORDS[w]) continue;
    if (bodyLower.indexOf(w) >= 0) return w;
  }
  // 4. Last resort: any word (including stopwords) that's present
  for (var j = 0; j < words.length; j++) {
    if (bodyLower.indexOf(words[j]) >= 0) return words[j];
  }
  return null;
}

function highlightTerm(raw) {
  try {
    var content = document.getElementById('content');
    if (!content) return;
    clearTermHighlights();
    var bodyLower = content.textContent.toLowerCase();
    var chosen = pickHighlightTerm(raw, bodyLower);
    if (!chosen) return;
    var first = wrapMatches(content, chosen);
    if (!first) return;
    // Wait for layout to settle before scrolling, then flash
    var doScroll = function () {
      try { first.scrollIntoView({ block: 'center' }); }
      catch (e) { try { first.scrollIntoView(); } catch (_) {} }
      var hits = document.querySelectorAll('.term-hit');
      for (var j = 0; j < hits.length; j++) hits[j].classList.add('flash');
      setTimeout(function () {
        var h2 = document.querySelectorAll('.term-hit.flash');
        for (var k = 0; k < h2.length; k++) h2[k].classList.remove('flash');
      }, 2400);
    };
    if (window.requestAnimationFrame) {
      window.requestAnimationFrame(function () {
        window.requestAnimationFrame(doScroll);
      });
    } else {
      setTimeout(doScroll, 50);
    }
  } catch (e) {}
}

window.renderMarkdown = renderMarkdown;
window.highlightTerm = highlightTerm;
window.setFontScale = setFontScale;
window.setTheme = setTheme;
window.collapseAllCallouts = collapseAllCallouts;
window.expandAllCallouts = expandAllCallouts;
window.getScroll = getScroll;
window.restoreScroll = restoreScroll;
