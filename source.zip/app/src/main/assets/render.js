/* MarkVault render engine v2 — Obsidian/Claude-grade, fully offline */

var md = window.markdownit({
  html: true, linkify: true, breaks: false, typographer: true,
  highlight: function (code, lang) {
    try {
      if (lang && window.hljs && hljs.getLanguage(lang)) {
        return '<pre><code class="hljs language-' + lang + '">' +
          hljs.highlight(code, { language: lang, ignoreIllegals: true }).value + '</code></pre>';
      }
      if (window.hljs) return '<pre><code class="hljs">' + hljs.highlightAuto(code).value + '</code></pre>';
    } catch (e) {}
    return '<pre><code class="hljs">' + md.utils.escapeHtml(code) + '</code></pre>';
  }
});

var ICONS = {
  note:'\uD83D\uDCDD', info:'\u2139\uFE0F', tip:'\uD83D\uDCA1', success:'\u2705',
  warning:'\u26A0\uFE0F', caution:'\uD83D\uDD25', danger:'\u26D4', error:'\u274C',
  quote:'\uD83D\uDCAC', question:'\u2753', example:'\uD83D\uDD0E', abstract:'\uD83D\uDCCB'
};
var ALIAS = {
  summary:'abstract', tldr:'abstract', hint:'tip', important:'tip', check:'success',
  done:'success', fail:'error', bug:'error', faq:'question', help:'question',
  todo:'info', attention:'warning', cite:'quote'
};

/* ==highlight== inline rule */
function markRule(state, silent) {
  var start = state.pos;
  if (state.src.charCodeAt(start) !== 0x3D || state.src.charCodeAt(start + 1) !== 0x3D) return false;
  var idx = state.src.slice(start + 2).indexOf('==');
  if (idx < 0) return false;
  var content = state.src.slice(start + 2, start + 2 + idx);
  if (!silent) {
    state.push('mark_open', 'mark', 1);
    var t = state.push('text', '', 0); t.content = content;
    state.push('mark_close', 'mark', -1);
  }
  state.pos = start + 4 + idx;
  return true;
}
md.inline.ruler.before('emphasis', 'mark', markRule);

function transformCallouts(root) {
  root.querySelectorAll('blockquote').forEach(function (bq) {
    var first = bq.querySelector('p');
    if (!first) return;
    var m = first.innerHTML.match(/^\s*\[!(\w+)\]([+-]?)\s*([\s\S]*)/i);
    if (!m) return;
    var type = m[1].toLowerCase(); type = ALIAS[type] || type;
    if (!ICONS[type]) type = 'note';
    var sign = m[2], rest = m[3];
    var foldable = sign === '+' || sign === '-';
    var collapsed = sign === '-';

    var div = document.createElement('div');
    div.className = 'callout cl-' + type + (foldable ? ' foldable' : '') + (collapsed ? ' collapsed' : '');

    var splitFirst = rest.split(/<br\s*\/?>([\s\S]*)/i);
    var titleText = (splitFirst[0] || '').trim() || (type.charAt(0).toUpperCase() + type.slice(1));

    var title = document.createElement('div');
    title.className = 'callout-title';
    title.innerHTML =
      (foldable ? '<span class="chevron">\u25B8</span>' : '') +
      '<span class="ic">' + ICONS[type] + '</span><span class="ct">' + titleText + '</span>';
    div.appendChild(title);

    var body = document.createElement('div');
    body.className = 'callout-body';
    if (splitFirst[1]) { var p = document.createElement('p'); p.innerHTML = splitFirst[1]; body.appendChild(p); }
    var sib = first.nextElementSibling;
    while (sib) { var next = sib.nextElementSibling; body.appendChild(sib); sib = next; }
    div.appendChild(body);

    if (foldable) {
      title.addEventListener('click', function () { div.classList.toggle('collapsed'); });
    }
    bq.parentNode.replaceChild(div, bq);
  });
}

function transformTasks(root) {
  root.querySelectorAll('li').forEach(function (li) {
    var m = li.innerHTML.match(/^\s*\[([ xX])\]\s+([\s\S]*)/);
    if (!m) return;
    li.classList.add('task');
    if (m[1].toLowerCase() === 'x') li.classList.add('done');
    li.innerHTML = '<span class="box"></span><span class="label">' + m[2] + '</span>';
  });
}

function transformWikilinks(root) {
  var pending = [];
  (function rec(n) {
    for (var i = 0; i < n.childNodes.length; i++) {
      var c = n.childNodes[i];
      if (c.nodeType === 3) { if (/\[\[/.test(c.nodeValue)) pending.push(c); }
      else if (c.nodeType === 1) {
        var t = c.tagName.toLowerCase();
        if (t !== 'code' && t !== 'pre' && t !== 'a') rec(c);
      }
    }
  })(root);
  pending.forEach(function (tn) {
    var span = document.createElement('span');
    span.innerHTML = tn.nodeValue.replace(/\[\[([^\]|]+)(?:\|([^\]]+))?\]\]/g,
      function (_, target, alias) { return '<span class="wikilink">' + (alias || target) + '</span>'; });
    tn.parentNode.replaceChild(span, tn);
  });
}

/* Outline anchors + collapsible headings (top-level only) */
function setupHeadings(root) {
  var hs = root.querySelectorAll('#content > h1, #content > h2, #content > h3, #content > h4, #content > h5, #content > h6');
  hs.forEach(function (h, i) {
    h.id = 'sec-' + i;
    h.classList.add('foldable-h');
    h.addEventListener('click', function () {
      var lvl = parseInt(h.tagName.substring(1), 10);
      var collapsed = h.classList.toggle('h-collapsed');
      var sib = h.nextElementSibling;
      while (sib) {
        if (/^H[1-6]$/.test(sib.tagName) && parseInt(sib.tagName.substring(1), 10) <= lvl) break;
        sib.style.display = collapsed ? 'none' : '';
        sib = sib.nextElementSibling;
      }
    });
  });
}

function renderMarkdown(src, scale, theme) {
  document.documentElement.style.fontSize = (17 * (scale || 1)) + 'px';
  if (theme) setTheme(theme);
  var el = document.getElementById('content');
  el.innerHTML = md.render(src || '');
  try { transformCallouts(el); } catch (e) {}
  try { transformTasks(el); } catch (e) {}
  try { transformWikilinks(el); } catch (e) {}
  try { setupHeadings(el); } catch (e) {}
  window.scrollTo(0, 0);
}

function setFontScale(scale) { document.documentElement.style.fontSize = (17 * (scale || 1)) + 'px'; }
function setTheme(name) { document.body.className = 'theme-' + (name || 'dark'); }
function collapseAllCallouts() {
  document.querySelectorAll('.callout.foldable').forEach(function (c) { c.classList.add('collapsed'); });
}
function expandAllCallouts() {
  document.querySelectorAll('.callout.foldable').forEach(function (c) { c.classList.remove('collapsed'); });
}
function getScroll() { return window.scrollY || 0; }
function restoreScroll(y) { window.scrollTo(0, y || 0); }

window.renderMarkdown = renderMarkdown;
window.setFontScale = setFontScale;
window.setTheme = setTheme;
window.collapseAllCallouts = collapseAllCallouts;
window.expandAllCallouts = expandAllCallouts;
window.getScroll = getScroll;
window.restoreScroll = restoreScroll;
