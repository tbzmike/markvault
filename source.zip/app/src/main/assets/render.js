/* MarkVault render engine — Obsidian/Claude-style markdown rendering, fully offline */

var md = window.markdownit({
  html: true,
  linkify: true,
  breaks: false,
  typographer: true,
  highlight: function (code, lang) {
    try {
      if (lang && window.hljs && hljs.getLanguage(lang)) {
        return '<pre><code class="hljs language-' + lang + '">' +
          hljs.highlight(code, { language: lang, ignoreIllegals: true }).value +
          '</code></pre>';
      }
      if (window.hljs) {
        return '<pre><code class="hljs">' + hljs.highlightAuto(code).value + '</code></pre>';
      }
    } catch (e) {}
    return '<pre><code class="hljs">' + md.utils.escapeHtml(code) + '</code></pre>';
  }
});

var ICONS = {
  note: '\uD83D\uDCDD', info: '\u2139\uFE0F', tip: '\uD83D\uDCA1', success: '\u2705',
  warning: '\u26A0\uFE0F', caution: '\uD83D\uDD25', danger: '\u26D4', error: '\u274C',
  quote: '\uD83D\uDCAC', question: '\u2753', example: '\uD83D\uDD0E', abstract: '\uD83D\uDCCB'
};
var ALIAS = {
  abstract: 'note', summary: 'note', tldr: 'note', hint: 'tip', important: 'tip',
  check: 'success', done: 'success', fail: 'error', bug: 'error', faq: 'question',
  help: 'question', todo: 'info', attention: 'warning'
};

/* ==highlight== inline rule */
function markRule(state, silent) {
  var start = state.pos, marker = state.src.charCodeAt(start);
  if (marker !== 0x3D /* = */) return false;
  if (state.src.charCodeAt(start + 1) !== 0x3D) return false;
  var match = state.src.slice(start + 2).indexOf('==');
  if (match < 0) return false;
  var content = state.src.slice(start + 2, start + 2 + match);
  if (!silent) {
    var tOpen = state.push('mark_open', 'mark', 1);
    var tText = state.push('text', '', 0); tText.content = content;
    state.push('mark_close', 'mark', -1);
  }
  state.pos = start + 4 + match;
  return true;
}
md.inline.ruler.before('emphasis', 'mark', markRule);

function transformCallouts(root) {
  var quotes = root.querySelectorAll('blockquote');
  quotes.forEach(function (bq) {
    var first = bq.querySelector('p');
    if (!first) return;
    var m = first.innerHTML.match(/^\s*\[!(\w+)\]([+-]?)\s*(.*)/is);
    if (!m) return;
    var type = m[1].toLowerCase();
    type = ALIAS[type] || type;
    if (!ICONS[type]) type = 'note';
    var rest = m[3];
    var div = document.createElement('div');
    div.className = 'callout cl-' + type;
    var title = document.createElement('div');
    title.className = 'callout-title';
    var firstLine = rest.split(/<br\s*\/?>(.*)/is);
    title.innerHTML = '<span class="ic">' + ICONS[type] + '</span><span>' +
      (firstLine[0].trim() || type.charAt(0).toUpperCase() + type.slice(1)) + '</span>';
    div.appendChild(title);
    var body = document.createElement('div');
    body.className = 'callout-body';
    if (firstLine[1]) { var p = document.createElement('p'); p.innerHTML = firstLine[1]; body.appendChild(p); }
    var sib = first.nextElementSibling;
    while (sib) { var next = sib.nextElementSibling; body.appendChild(sib); sib = next; }
    div.appendChild(body);
    bq.parentNode.replaceChild(div, bq);
  });
}

function transformTasks(root) {
  root.querySelectorAll('li').forEach(function (li) {
    var html = li.innerHTML;
    var m = html.match(/^\s*\[([ xX])\]\s+(.*)/s);
    if (!m) return;
    var done = m[1].toLowerCase() === 'x';
    li.classList.add('task');
    if (done) li.classList.add('done');
    li.innerHTML = '<span class="box"></span><span class="label">' + m[2] + '</span>';
  });
}

function transformWikilinks(root) {
  walkText(root, function (text) {
    return text.replace(/\[\[([^\]|]+)(?:\|([^\]]+))?\]\]/g, function (_, target, alias) {
      return '<span class="wikilink">' + (alias || target) + '</span>';
    });
  });
}

/* Walk text nodes, skip code/pre, apply replacer returning HTML */
function walkText(node, replacer) {
  var pending = [];
  (function rec(n) {
    for (var i = 0; i < n.childNodes.length; i++) {
      var c = n.childNodes[i];
      if (c.nodeType === 3) {
        if (/\[\[/.test(c.nodeValue)) pending.push(c);
      } else if (c.nodeType === 1) {
        var tag = c.tagName.toLowerCase();
        if (tag !== 'code' && tag !== 'pre' && tag !== 'a') rec(c);
      }
    }
  })(node);
  pending.forEach(function (tn) {
    var span = document.createElement('span');
    span.innerHTML = replacer(tn.nodeValue);
    tn.parentNode.replaceChild(span, tn);
  });
}

function renderMarkdown(src, scale) {
  document.documentElement.style.fontSize = (17 * (scale || 1)) + 'px';
  var el = document.getElementById('content');
  el.innerHTML = md.render(src || '');
  try { transformCallouts(el); } catch (e) {}
  try { transformTasks(el); } catch (e) {}
  try { transformWikilinks(el); } catch (e) {}
  window.scrollTo(0, 0);
}

function setFontScale(scale) {
  document.documentElement.style.fontSize = (17 * (scale || 1)) + 'px';
}

window.renderMarkdown = renderMarkdown;
window.setFontScale = setFontScale;
