/*
 * MarkVault HTML → Markdown converter
 * ===================================
 * Runs inside the import WebView after the user's URL has loaded.
 * Walks the rendered DOM and emits markdown.
 *
 * Public entry: MV.extract() returns { title, url, markdown, warning }
 *
 * Strategy:
 *   1. Try to find the article container in this order:
 *      <article>, <main>, [role=main], #content, .post, .article — first match wins.
 *      If none match, fall back to <body> minus chrome (header/footer/nav/aside/script/style).
 *   2. Walk the chosen subtree, emitting markdown per node type.
 *   3. Title from <h1> inside the article, else <meta property="og:title">, else <title>.
 */
(function (root) {
  'use strict';

  // ---- Public entry ----------------------------------------------------------
  function extract() {
    var url = location.href || '';
    var rootEl = pickContentRoot();
    var title = pickTitle(rootEl);
    var md = '';
    var warning = null;
    try {
      md = walk(rootEl).replace(/\n{3,}/g, '\n\n').trim();
    } catch (e) {
      warning = 'Conversion error: ' + (e && e.message ? e.message : e);
    }
    if (!md || md.length < 40) {
      warning = (warning ? warning + ' \u00B7 ' : '') +
        'Page yielded little content. It may rely on JavaScript or auth.';
    }
    // Prepend a front-matter-ish source line so the user always sees the origin
    var header = '# ' + title + '\n\n' +
      '*Source: ' + url + '*\n' +
      '*Imported: ' + new Date().toISOString().substring(0, 10) + '*\n\n---\n\n';
    return { title: title, url: url, markdown: header + md, warning: warning };
  }

  // ---- Content-root detection ------------------------------------------------
  function pickContentRoot() {
    var candidates = [
      'article',
      'main',
      '[role="main"]',
      '.article-body', '.article-content', '.article__body',
      '.post-body', '.post-content', '.entry-content',
      '#article', '#content', '#main', '#main-content',
      '.markdown-body', '.prose'
    ];
    for (var i = 0; i < candidates.length; i++) {
      var el = document.querySelector(candidates[i]);
      if (el && textLength(el) > 200) return el;
    }
    // Fallback: largest <div> by visible text, but only if it's beefy enough
    var best = null, bestLen = 0;
    var divs = document.querySelectorAll('div, section');
    for (var j = 0; j < divs.length; j++) {
      var d = divs[j];
      if (isChrome(d)) continue;
      var t = textLength(d);
      if (t > bestLen) { bestLen = t; best = d; }
    }
    if (best && bestLen > 400) return best;
    return document.body;
  }

  function pickTitle(rootEl) {
    var h1 = rootEl ? rootEl.querySelector('h1') : null;
    if (h1 && h1.textContent && h1.textContent.trim()) return clean(h1.textContent);
    var og = document.querySelector('meta[property="og:title"]');
    if (og && og.getAttribute('content')) return clean(og.getAttribute('content'));
    if (document.title) return clean(document.title);
    return 'Untitled';
  }

  function textLength(el) {
    // Cheap proxy for "how much article-like content here"
    var t = el ? (el.textContent || '') : '';
    return t.length;
  }

  function isChrome(el) {
    if (!el) return true;
    var tag = (el.tagName || '').toLowerCase();
    if (tag === 'header' || tag === 'footer' || tag === 'nav' || tag === 'aside') return true;
    var cls = (el.className && typeof el.className === 'string') ? el.className.toLowerCase() : '';
    if (/\b(nav|header|footer|sidebar|menu|ad|advert|promo|cookie|banner|share|social|related|comments?)\b/.test(cls)) {
      return true;
    }
    var id = (el.id || '').toLowerCase();
    if (/\b(nav|header|footer|sidebar|menu|ad|advert|promo|cookie|banner|share|social|related|comments?)\b/.test(id)) {
      return true;
    }
    return false;
  }

  // ---- Walker ----------------------------------------------------------------
  // Each block emits its own surrounding blank lines so we never end up with
  // run-together paragraphs. Inline elements return inline strings.
  function walk(node, state) {
    if (!state) state = { listDepth: 0, ordered: [], inPre: false };
    if (!node) return '';
    if (node.nodeType === 3) {
      // Text node
      if (state.inPre) return node.nodeValue || '';
      return inlineText(node.nodeValue || '');
    }
    if (node.nodeType !== 1) return '';

    var tag = (node.tagName || '').toLowerCase();
    // Drop noisy elements outright
    if (tag === 'script' || tag === 'style' || tag === 'noscript' || tag === 'svg' ||
        tag === 'iframe' || tag === 'form' || tag === 'button' || tag === 'input' ||
        tag === 'select' || tag === 'textarea' || tag === 'video' || tag === 'audio') {
      return '';
    }
    // Strip nav/footer/sidebar chrome unconditionally
    if (isChrome(node)) return '';
    // Hidden elements
    var style = node.ownerDocument && node.ownerDocument.defaultView ?
      node.ownerDocument.defaultView.getComputedStyle(node) : null;
    if (style && (style.display === 'none' || style.visibility === 'hidden')) return '';

    switch (tag) {
      case 'h1': case 'h2': case 'h3': case 'h4': case 'h5': case 'h6':
        var level = parseInt(tag.charAt(1), 10);
        var hText = collectInline(node, state).trim();
        if (!hText) return '';
        return '\n\n' + repeat('#', level) + ' ' + hText + '\n\n';

      case 'p':
        var pText = collectInline(node, state).trim();
        if (!pText) return '';
        return '\n\n' + pText + '\n\n';

      case 'br':
        return '  \n';

      case 'hr':
        return '\n\n---\n\n';

      case 'strong': case 'b':
        return '**' + collectInline(node, state) + '**';

      case 'em': case 'i':
        return '*' + collectInline(node, state) + '*';

      case 'del': case 's': case 'strike':
        return '~~' + collectInline(node, state) + '~~';

      case 'code':
        if (state.inPre) return node.textContent || '';
        var c = (node.textContent || '').replace(/`/g, '\u200B`');
        return '`' + c + '`';

      case 'pre':
        var pre = node.textContent || '';
        // Detect a language from a child <code> with class="language-xxx"
        var lang = '';
        var cc = node.querySelector('code');
        if (cc && cc.className) {
          var m = cc.className.match(/language-([\w-]+)/);
          if (m) lang = m[1];
        }
        return '\n\n```' + lang + '\n' + pre.replace(/\n+$/, '') + '\n```\n\n';

      case 'a':
        var href = node.getAttribute('href') || '';
        var label = collectInline(node, state).trim();
        if (!href || href.charAt(0) === '#' || href.indexOf('javascript:') === 0) {
          return label;
        }
        href = absolutize(href);
        if (!label) label = href;
        return '[' + label + '](' + href + ')';

      case 'img':
        var src = node.getAttribute('src') || node.getAttribute('data-src') || '';
        if (!src) return '';
        var alt = (node.getAttribute('alt') || '').replace(/[\[\]]/g, '');
        return '![' + alt + '](' + absolutize(src) + ')';

      case 'blockquote':
        var bq = collectChildren(node, state).trim();
        if (!bq) return '';
        return '\n\n' + bq.split('\n').map(function (l) { return '> ' + l; }).join('\n') + '\n\n';

      case 'ul':
        return renderList(node, state, false);
      case 'ol':
        return renderList(node, state, true);
      case 'li':
        // Bare <li> outside a list — emit as bullet
        return '- ' + collectChildren(node, state).trim() + '\n';

      case 'table':
        return renderTable(node, state);

      case 'figure':
        return collectChildren(node, state);
      case 'figcaption':
        var cap = collectInline(node, state).trim();
        if (!cap) return '';
        return '\n*' + cap + '*\n';

      // Inline-ish containers — pass through
      case 'span': case 'small': case 'cite': case 'abbr': case 'mark':
      case 'time': case 'sup': case 'sub':
        return collectInline(node, state);

      // Block-ish containers — pass through
      default:
        return collectChildren(node, state);
    }
  }

  function collectChildren(node, state) {
    var out = '';
    var kids = node.childNodes;
    for (var i = 0; i < kids.length; i++) {
      out += walk(kids[i], state);
    }
    return out;
  }

  function collectInline(node, state) {
    // For inline contexts, collapse internal whitespace less aggressively
    return collectChildren(node, state).replace(/[ \t]+/g, ' ');
  }

  function renderList(listNode, state, ordered) {
    state.listDepth++;
    var indent = repeat('  ', state.listDepth - 1);
    var out = '\n';
    var idx = 1;
    var items = listNode.children;
    for (var i = 0; i < items.length; i++) {
      var li = items[i];
      if ((li.tagName || '').toLowerCase() !== 'li') continue;
      var prefix = ordered ? (idx++) + '. ' : '- ';
      // Render children of <li>: extract inline content first, then nested lists at the end
      var inline = '';
      var nested = '';
      var kids = li.childNodes;
      for (var k = 0; k < kids.length; k++) {
        var kid = kids[k];
        var kTag = kid.nodeType === 1 ? (kid.tagName || '').toLowerCase() : '';
        if (kTag === 'ul' || kTag === 'ol') {
          nested += walk(kid, state);
        } else {
          inline += walk(kid, state);
        }
      }
      inline = inline.replace(/^\s+|\s+$/g, '');
      if (!inline && !nested) continue;
      out += indent + prefix + inline + '\n';
      if (nested) {
        // Nested list output already includes its own indentation
        out += nested.replace(/^\n+/, '').replace(/\n+$/, '\n');
      }
    }
    state.listDepth--;
    return out + (state.listDepth === 0 ? '\n' : '');
  }

  function renderTable(tableNode, state) {
    var rows = [];
    var trs = tableNode.querySelectorAll('tr');
    if (!trs.length) return '';
    for (var r = 0; r < trs.length; r++) {
      var tr = trs[r];
      var cells = tr.querySelectorAll('th, td');
      var rowCells = [];
      for (var c = 0; c < cells.length; c++) {
        var cell = collectInline(cells[c], state).trim();
        rowCells.push(cell.replace(/\|/g, '\\|').replace(/\n/g, ' '));
      }
      if (rowCells.length) rows.push(rowCells);
    }
    if (!rows.length) return '';
    var cols = rows.reduce(function (m, r) { return Math.max(m, r.length); }, 0);
    // Pad rows to equal width
    rows.forEach(function (r) {
      while (r.length < cols) r.push('');
    });
    var out = '\n\n';
    out += '| ' + rows[0].join(' | ') + ' |\n';
    out += '| ' + rows[0].map(function () { return '---'; }).join(' | ') + ' |\n';
    for (var i = 1; i < rows.length; i++) {
      out += '| ' + rows[i].join(' | ') + ' |\n';
    }
    return out + '\n';
  }

  // ---- Utilities -------------------------------------------------------------
  function inlineText(s) {
    return s.replace(/\s+/g, ' ');
  }
  function clean(s) {
    return s.replace(/\s+/g, ' ').trim();
  }
  function repeat(s, n) {
    var out = '';
    for (var i = 0; i < n; i++) out += s;
    return out;
  }
  function absolutize(href) {
    try {
      return new URL(href, location.href).href;
    } catch (e) {
      return href;
    }
  }

  root.MV = root.MV || {};
  root.MV.extract = extract;
})(window);
