/*
 * MarkVault HTML → Markdown converter (engine v2)
 * ================================================
 * Uses Mozilla Readability for article detection and Turndown for HTML→Markdown.
 * Both libraries must be loaded into the page *before* this script runs.
 *
 * Public entry: MV.extract() returns a JSON-stringifiable object:
 *   {
 *     ok:        true | false,
 *     title:     "...",
 *     url:       "...",
 *     siteName:  "...",
 *     byline:    "...",
 *     excerpt:   "...",
 *     body:      "...markdown of the article...",
 *     warning:   "..." | null,
 *     error:     "..." | null
 *   }
 *
 * The CALLER (Kotlin) assembles the final markdown by combining title + URL line +
 * excerpt + body according to the user's toggles. Keeping assembly on the Kotlin
 * side lets us re-render instantly when the user flips a toggle, without re-loading
 * the page.
 */
(function (root) {
  'use strict';

  function extract() {
    var url = (root.location && root.location.href) || '';
    if (typeof root.Readability !== 'function') {
      return JSON.stringify({ ok: false, error: 'Readability library not loaded.' });
    }
    if (typeof root.TurndownService !== 'function') {
      return JSON.stringify({ ok: false, error: 'Turndown library not loaded.' });
    }

    // Readability mutates the document, so clone first.
    var doc;
    try {
      doc = document.cloneNode(true);
    } catch (e) {
      return JSON.stringify({
        ok: false,
        error: 'Could not clone document: ' + (e && e.message ? e.message : e)
      });
    }

    var article;
    try {
      article = new Readability(doc, {
        keepClasses: false,
        disableJSONLD: true,
        charThreshold: 200
      }).parse();
    } catch (e) {
      return JSON.stringify({
        ok: false,
        error: 'Readability failed: ' + (e && e.message ? e.message : e)
      });
    }

    if (!article || !article.content) {
      return JSON.stringify({
        ok: false,
        error: 'No readable content found. Page may require login or be a non-article URL.'
      });
    }

    // Configure Turndown for clean, Obsidian-friendly markdown output.
    var td;
    try {
      td = new TurndownService({
        headingStyle: 'atx',
        hr: '---',
        bulletListMarker: '-',
        codeBlockStyle: 'fenced',
        fence: '```',
        emDelimiter: '*',
        strongDelimiter: '**',
        linkStyle: 'inlined',
        linkReferenceStyle: 'full'
      });
      td.remove(['script', 'style', 'iframe', 'form', 'button', 'input']);

      td.addRule('tables', {
        filter: 'table',
        replacement: function (content, node) { return tableToMarkdown(node); }
      });

      td.addRule('absoluteImages', {
        filter: 'img',
        replacement: function (content, node) {
          var src = node.getAttribute('src') ||
                    node.getAttribute('data-src') ||
                    node.getAttribute('data-img-url') || '';
          if (!src) return '';
          var alt = (node.getAttribute('alt') || '').replace(/[\[\]]/g, '');
          return '![' + alt + '](' + absolutize(src, url) + ')';
        }
      });

      td.addRule('absoluteLinks', {
        filter: function (node) {
          return node.nodeName === 'A' && node.getAttribute('href');
        },
        replacement: function (content, node) {
          var href = node.getAttribute('href');
          if (!href || href.charAt(0) === '#' || href.indexOf('javascript:') === 0) {
            return content;
          }
          var label = (content || '').trim();
          if (!label) label = href;
          return '[' + label + '](' + absolutize(href, url) + ')';
        }
      });
    } catch (e) {
      return JSON.stringify({
        ok: false,
        error: 'Turndown setup failed: ' + (e && e.message ? e.message : e)
      });
    }

    var body;
    try {
      body = td.turndown(article.content);
      body = body.replace(/\n{3,}/g, '\n\n').trim();
    } catch (e) {
      return JSON.stringify({
        ok: false,
        error: 'Markdown conversion failed: ' + (e && e.message ? e.message : e)
      });
    }

    var warning = null;
    if (!body || body.length < 80) {
      warning = 'Conversion yielded little body content. The page may rely on login or interactive JS.';
    }

    return JSON.stringify({
      ok: true,
      title: article.title || document.title || 'Untitled',
      url: url,
      siteName: article.siteName || '',
      byline: article.byline || '',
      excerpt: article.excerpt || '',
      body: body,
      warning: warning,
      error: null
    });
  }

  function absolutize(href, base) {
    try {
      return new URL(href, base || root.location.href).href;
    } catch (e) {
      return href;
    }
  }

  function tableToMarkdown(node) {
    var rows = [];
    var trs = node.querySelectorAll('tr');
    if (!trs.length) return '';
    for (var r = 0; r < trs.length; r++) {
      var cells = trs[r].querySelectorAll('th, td');
      var rowCells = [];
      for (var c = 0; c < cells.length; c++) {
        var cellText = (cells[c].textContent || '').trim()
          .replace(/\|/g, '\\|')
          .replace(/\n+/g, ' ');
        rowCells.push(cellText);
      }
      if (rowCells.length) rows.push(rowCells);
    }
    if (!rows.length) return '';
    var cols = rows.reduce(function (m, r) { return Math.max(m, r.length); }, 0);
    rows.forEach(function (r) { while (r.length < cols) r.push(''); });
    var out = '\n\n| ' + rows[0].join(' | ') + ' |\n';
    out += '| ' + rows[0].map(function () { return '---'; }).join(' | ') + ' |\n';
    for (var i = 1; i < rows.length; i++) {
      out += '| ' + rows[i].join(' | ') + ' |\n';
    }
    return out + '\n';
  }

  root.MV = root.MV || {};
  root.MV.extract = extract;
})(window);
