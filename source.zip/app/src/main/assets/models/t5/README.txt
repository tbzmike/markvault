T5-base paraphraser model directory.

Expected runtime files:
- t5-base-paraphrase.tflite
- spiece.model
- config.json

The directory is reserved for the local T5 expansion model.
