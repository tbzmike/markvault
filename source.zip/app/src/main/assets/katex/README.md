# KaTeX assets — not bundled in this repo snapshot

Math rendering (`$inline$`, `$$block$$`, `\(inline\)`, `\[block\]`) is fully
wired on the Kotlin and JS side — `MarkdownEngine.kt`'s `preprocessMath`
already wraps LaTeX source in `.math-inline` / `.math-block` containers, and
`render.js`'s `typesetMath()` already calls KaTeX on them. What's missing is
the KaTeX library itself: I don't have network access in the environment I
edited this repo in, so I couldn't fetch and verify real binary/JS assets to
place here. Rather than fabricate placeholder files that would silently not
work, I left this as a documented gap — the app runs fine without them
(`typesetMath` checks `typeof katex === 'undefined'` and no-ops), math source
just stays visible as plain text instead of being typeset.

## What to add

From the official KaTeX distribution (MIT licensed — https://katex.org /
https://github.com/KaTeX/KaTeX/releases, or `npm install katex` and use its
`dist/` folder), copy into this `katex/` folder:

- `katex.min.css`
- `katex.min.js`
- the `fonts/` subfolder (all `KaTeX_*.woff2` / `.woff` / `.ttf` files —
  `katex.min.css` `@font-face`-references these by relative path, so math
  will render with wrong/fallback glyphs for many symbols without them)

Do **not** need `contrib/auto-render.min.js` — this app calls KaTeX's core
`katex.render()` directly on each already-located `.math-inline` /
`.math-block` element (see `render.js`), so the auto-render extension (which
scans raw text for delimiters itself) would be redundant.

Final layout:
```
app/src/main/assets/katex/
  katex.min.css
  katex.min.js
  fonts/
    KaTeX_Main-Regular.woff2
    ... (rest of the official font set)
```

`viewer.html` already references `katex/katex.min.css` and
`katex/katex.min.js` at the correct relative paths — once the files above are
in place, no further code changes should be needed.
