package com.tebogo.markvault.ai

enum class T5ModelInstallState { NOT_INSTALLED, DOWNLOADING, VERIFYING, LOADING, READY, FAILED }

object T5ModelInstallStateStore {
    private var state = T5ModelInstallState.NOT_INSTALLED
    fun set(value: T5ModelInstallState) { state = value }
    fun get(): T5ModelInstallState = state
}
