package com.tebogo.markvault.ui

import android.graphics.Paint
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.gestures.detectTransformGestures
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.nativeCanvas
import androidx.compose.ui.graphics.toArgb
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.navigation.NavController
import com.tebogo.markvault.AppViewModel
import kotlinx.coroutines.launch
import org.json.JSONObject

private data class CanvasNodeView(
    val id: String,
    val type: String,
    val x: Float,
    val y: Float,
    val width: Float,
    val height: Float,
    val label: String,
    val file: String,
    val link: String
)

private data class CanvasEdgeView(val from: String, val to: String)

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun CanvasViewerScreen(vm: AppViewModel, nav: NavController, noteId: Long) {
    var title by remember { mutableStateOf("Canvas") }
    var nodes by remember { mutableStateOf<List<CanvasNodeView>>(emptyList()) }
    var edges by remember { mutableStateOf<List<CanvasEdgeView>>(emptyList()) }
    var error by remember { mutableStateOf<String?>(null) }
    var showNodes by remember { mutableStateOf(false) }
    var scale by remember { mutableFloatStateOf(0.75f) }
    var panX by remember { mutableFloatStateOf(30f) }
    var panY by remember { mutableFloatStateOf(30f) }
    val scope = rememberCoroutineScope()

    LaunchedEffect(noteId) {
        val note = vm.loadNote(noteId)
        if (note == null) {
            error = "Canvas file is no longer in the indexed library."
            return@LaunchedEffect
        }
        title = note.title.ifBlank { note.name }
        runCatching {
            val root = JSONObject(note.content)
            val nArr = root.optJSONArray("nodes")
            val parsedNodes = ArrayList<CanvasNodeView>()
            if (nArr != null) {
                for (i in 0 until nArr.length()) {
                    val o = nArr.optJSONObject(i) ?: continue
                    val type = o.optString("type", "text")
                    val file = o.optString("file")
                    val link = o.optString("url").ifBlank { o.optString("link") }
                    val text = o.optString("text")
                    val label = when {
                        text.isNotBlank() -> text.lineSequence().firstOrNull().orEmpty().take(120)
                        file.isNotBlank() -> file.substringAfterLast('/')
                        link.isNotBlank() -> link
                        else -> type
                    }
                    parsedNodes += CanvasNodeView(
                        id = o.optString("id", "node_$i"),
                        type = type,
                        x = o.optDouble("x", 0.0).toFloat(),
                        y = o.optDouble("y", 0.0).toFloat(),
                        width = o.optDouble("width", 300.0).toFloat().coerceAtLeast(80f),
                        height = o.optDouble("height", 160.0).toFloat().coerceAtLeast(50f),
                        label = label,
                        file = file,
                        link = link
                    )
                }
            }
            val eArr = root.optJSONArray("edges")
            val parsedEdges = ArrayList<CanvasEdgeView>()
            if (eArr != null) {
                for (i in 0 until eArr.length()) {
                    val o = eArr.optJSONObject(i) ?: continue
                    val from = o.optString("fromNode")
                    val to = o.optString("toNode")
                    if (from.isNotBlank() && to.isNotBlank()) parsedEdges += CanvasEdgeView(from, to)
                }
            }
            nodes = parsedNodes
            edges = parsedEdges
        }.onFailure {
            error = "This .canvas file could not be parsed: ${it.message ?: "invalid JSON"}"
        }
    }

    fun openCanvasNode(node: CanvasNodeView) {
        when {
            node.file.isNotBlank() -> scope.launch {
                val linked = vm.resolveWikilink(node.file) ?: return@launch
                val note = vm.noteById(linked.id) ?: return@launch
                vm.openArticle(note.id, note.title.ifBlank { note.name }, fileType = note.fileType)
                val route = when (note.fileType.lowercase()) {
                    "pdf" -> "pdfReader/${note.id}"
                    "html", "htm", "mhtml", "mht" -> "htmlReader/${note.id}"
                    "canvas" -> "canvas/${note.id}"
                    else -> "reader"
                }
                nav.navigate(route) { launchSingleTop = true }
            }
            node.link.startsWith("http://") || node.link.startsWith("https://") -> vm.requestWebPopup(node.link)
        }
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text(title, maxLines = 1) },
                navigationIcon = {
                    IconButton(onClick = { nav.popBackStack() }) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back")
                    }
                },
                actions = {
                    TextButton(onClick = { showNodes = true }) { Text("Nodes") }
                    TextButton(onClick = { scale = 0.75f; panX = 30f; panY = 30f }) { Text("Reset") }
                }
            )
        }
    ) { pad ->
        Box(Modifier.fillMaxSize().padding(pad)) {
            val nodeColor = MaterialTheme.colorScheme.surfaceVariant
            val borderColor = MaterialTheme.colorScheme.outline
            val edgeColor = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.55f)
            val textColor = MaterialTheme.colorScheme.onSurface
            val background = MaterialTheme.colorScheme.background

            Canvas(
                Modifier.fillMaxSize().pointerInput(nodes, edges) {
                    detectTransformGestures { _, pan, zoom, _ ->
                        scale = (scale * zoom).coerceIn(0.25f, 2.5f)
                        panX += pan.x
                        panY += pan.y
                    }
                }
            ) {
                drawRect(background)
                val byId = nodes.associateBy { it.id }
                edges.forEach { edge ->
                    val a = byId[edge.from] ?: return@forEach
                    val b = byId[edge.to] ?: return@forEach
                    val start = Offset(
                        panX + (a.x + a.width / 2f) * scale,
                        panY + (a.y + a.height / 2f) * scale
                    )
                    val end = Offset(
                        panX + (b.x + b.width / 2f) * scale,
                        panY + (b.y + b.height / 2f) * scale
                    )
                    drawLine(edgeColor, start, end, strokeWidth = (2f * scale).coerceAtLeast(1f))
                }
                val paint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                    color = textColor.toArgb()
                    textSize = (14f * density * scale).coerceIn(10f, 28f)
                }
                nodes.forEach { node ->
                    val left = panX + node.x * scale
                    val top = panY + node.y * scale
                    val w = node.width * scale
                    val h = node.height * scale
                    drawRoundRect(
                        color = nodeColor,
                        topLeft = Offset(left, top),
                        size = Size(w, h),
                        cornerRadius = androidx.compose.ui.geometry.CornerRadius(12f * scale, 12f * scale)
                    )
                    drawRoundRect(
                        color = borderColor,
                        topLeft = Offset(left, top),
                        size = Size(w, h),
                        cornerRadius = androidx.compose.ui.geometry.CornerRadius(12f * scale, 12f * scale),
                        style = androidx.compose.ui.graphics.drawscope.Stroke(width = (1.5f * scale).coerceAtLeast(1f))
                    )
                    drawContext.canvas.nativeCanvas.drawText(
                        node.label.take(90),
                        left + 10f * scale,
                        top + 24f * scale,
                        paint
                    )
                }
            }

            error?.let {
                Text(
                    it,
                    color = MaterialTheme.colorScheme.error,
                    modifier = Modifier.padding(20.dp)
                )
            }
        }
    }

    if (showNodes) {
        ModalBottomSheet(onDismissRequest = { showNodes = false }) {
            Column(Modifier.fillMaxWidth().padding(horizontal = 12.dp)) {
                Text("Canvas nodes", fontWeight = FontWeight.Bold)
                LazyColumn(Modifier.fillMaxWidth()) {
                    items(nodes, key = { it.id }) { node ->
                        TextButton(
                            onClick = {
                                showNodes = false
                                openCanvasNode(node)
                            },
                            enabled = node.file.isNotBlank() || node.link.isNotBlank(),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Column(Modifier.fillMaxWidth()) {
                                Text(node.label.ifBlank { node.type }, fontWeight = FontWeight.Medium)
                                Text(
                                    when {
                                        node.file.isNotBlank() -> node.file
                                        node.link.isNotBlank() -> node.link
                                        else -> node.type
                                    },
                                    style = MaterialTheme.typography.labelSmall,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }
                        }
                    }
                }
            }
        }
    }
}
