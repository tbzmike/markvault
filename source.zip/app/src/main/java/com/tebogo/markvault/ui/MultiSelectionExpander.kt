package com.tebogo.markvault.ui

import android.annotation.SuppressLint
import android.content.Context
import android.webkit.WebResourceError
import android.webkit.WebResourceRequest
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.size
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.compose.ui.viewinterop.AndroidView
import com.tebogo.markvault.AppViewModel
import kotlinx.coroutines.suspendCancellableCoroutine
import kotlinx.coroutines.withTimeoutOrNull
import kotlin.coroutines.resume

/**
 * v5.4.99cc — Multi Selection Mode head expander.
 *
 * When the user long-presses a "head" link (e.g. a monthly Watchtower
 * listing) in Multi Selection Mode, the URL is queued on
 * [AppViewModel.headExpansionQueue]. The [HiddenHeadExpander]
 * composable — hoisted at MainActivity level so it survives navigation
 * between screens — observes that queue, loads each head on a hidden
 * 1dp WebView (attached to the layout so onPageFinished fires
 * reliably), extracts every article-like link inside, and pushes the
 * result back to the VM.
 *
 * Why a WebView and not OkHttp: jw.org is behind Cloudflare, and
 * v5.4.88cc's HttpURLConnection batch fetch was blocked by bot
 * challenges. Sharing Chromium's TLS session + cookie jar via a
 * WebView is what unblocked the batch save in v5.4.89cc; the same
 * reasoning applies here.
 *
 * Body-link filter rules (applied in [parseExtractedLinks]):
 *   • Same host as the head URL — no wandering to external sites.
 *   • Not an anchor-only URL (`#foo`) — same-page bookmarks aren't
 *     articles.
 *   • Not the head URL itself.
 *   • Non-empty href.
 *
 * The 10KB minimum size filter is NOT applied here — it happens in
 * HiddenBatchSaver at save time, once the actual HTML is downloaded.
 * Applying it here would require an extra fetch per link just to
 * measure size, which is wasteful when we already have to download
 * for the save.
 */

private const val EXPANDER_TIMEOUT_MS = 25_000L
private const val EXPANDER_SETTLE_MS = 1200L

/**
 * Hidden 1dp WebView that drains the head-expansion queue. Serial —
 * processes one head at a time so a slow load doesn't block the
 * others behind an out-of-order response. The single WebView is
 * remembered across the composable's lifetime; between requests it
 * navigates to `about:blank` to release the previous page's memory
 * without tearing down the Chromium session state.
 *
 * Hoisted at MainActivity level (see MainActivity.kt) so navigating
 * between screens in MarkVault mid-expansion doesn't dispose the
 * WebView and interrupt the load.
 */
@SuppressLint("SetJavaScriptEnabled")
@Composable
internal fun HiddenHeadExpander(vm: AppViewModel) {
    val queue by vm.headExpansionQueue.collectAsState()
    val ctx = LocalContext.current

    // v5.4.99cc — Always call `remember` unconditionally so the
    // WebView persists across "queue empty" gaps between bursts of
    // expansion requests. Positional-memoisation gotcha in Compose:
    // if remember is skipped by an early-return in one recomposition
    // and reached again on the next, the slot may get re-initialised
    // and a stale WebView leaked. Always-call keeps the same
    // instance for the composable's lifetime.
    val webView = remember { buildExpanderWebView(ctx) }
    val current = queue.firstOrNull() ?: return

    // v5.4.112cc — Ensure the foreground service is running while
    // expansion is in progress so the "Expanding selections…"
    // notification appears (and survives backgrounding). The service
    // reads AppViewModel.opProgress, which onHeadExpansion* keeps
    // updated. Safe to call repeatedly — startForegroundService is
    // idempotent when the service is already up.
    LaunchedEffect(Unit) {
        runCatching { vm.startBatchSaveService(ctx) }
    }

    Box(Modifier.size(1.dp)) {
        AndroidView(
            modifier = Modifier.size(1.dp),
            factory = { webView }
        )
    }

    LaunchedEffect(current.id) {
        val bodyLinks = loadHeadAndExtractLinks(
            webView = webView,
            headUrl = current.url,
            timeoutMs = EXPANDER_TIMEOUT_MS
        )
        if (bodyLinks == null) {
            vm.onHeadExpansionFailed(current, "timeout or network error")
        } else {
            // Mark every body link as `expanded = true` so the batch
            // saver applies the 10KB minimum size filter.
            vm.onHeadExpansionCompleted(
                current,
                bodyLinks.map { it.copy(expanded = true) }
            )
        }
        // Release the loaded head so its memory can be GC'd before
        // the next head navigates in. runCatching guards against the
        // Box being disposed mid-load (harmless no-op on a detached
        // WebView, but errors still propagate).
        runCatching { webView.loadUrl("about:blank") }
    }
}

/**
 * Navigate [webView] to [headUrl], wait for onPageFinished, then
 * extract every article-like anchor from the DOM. Returns `null` on
 * timeout / navigation error / empty page, otherwise a list of
 * [AppViewModel.WebSelectionItem]s ready to be added to the basket.
 */
private suspend fun loadHeadAndExtractLinks(
    webView: WebView,
    headUrl: String,
    timeoutMs: Long
): List<AppViewModel.WebSelectionItem>? = withTimeoutOrNull(timeoutMs) {
    suspendCancellableCoroutine<List<AppViewModel.WebSelectionItem>?> { cont ->
        var consumed = false
        webView.webViewClient = object : WebViewClient() {
            override fun onPageFinished(view: WebView?, finishedUrl: String?) {
                if (view == null || consumed) return
                consumed = true
                // Settle delay lets late-arriving JS render article
                // cards; jw.org listings sometimes shuffle content
                // into place after DOMContentLoaded.
                view.postDelayed({
                    view.evaluateJavascript(EXTRACT_LINKS_JS) { raw ->
                        if (!cont.isActive) return@evaluateJavascript
                        val decoded = decodeJsSelectionPublic(raw)
                        val parsed = parseExtractedLinks(decoded, headUrl)
                        cont.resume(parsed)
                    }
                }, EXPANDER_SETTLE_MS)
            }

            override fun onReceivedError(
                view: WebView?,
                request: WebResourceRequest?,
                error: WebResourceError?
            ) {
                if (request?.isForMainFrame != true || consumed) return
                consumed = true
                if (cont.isActive) cont.resume(null)
            }

            @Suppress("DEPRECATION")
            override fun onReceivedError(
                view: WebView?,
                errorCode: Int,
                description: String?,
                failingUrl: String?
            ) {
                if (consumed) return
                consumed = true
                if (cont.isActive) cont.resume(null)
            }
        }
        cont.invokeOnCancellation {
            runCatching { webView.stopLoading() }
        }
        webView.loadUrl(headUrl)
    }
}

/**
 * DOM extraction payload. Walks every `<a href>` on the page, keeps
 * href + trimmed text, dedupes by href, joins entries with U+0002 and
 * the (href, text) pair with U+0001 — same encoding
 * [SelectionWebView.resolveAnchorAtLastTouch] uses so we can reuse
 * [decodeJsSelectionPublic] for the round-trip.
 */
private const val EXTRACT_LINKS_JS = "(function(){" +
    "var out=[];" +
    "var seen={};" +
    "var anchors=document.querySelectorAll('a[href]');" +
    "for(var i=0;i<anchors.length;i++){" +
    "  var a=anchors[i];" +
    "  var href=a.href;" +
    "  if(!href)continue;" +
    "  if(seen[href])continue;" +
    "  seen[href]=true;" +
    "  var t=(a.innerText||a.textContent||'').replace(/\\s+/g,' ').trim();" +
    "  out.push(href+'\\u0001'+t);" +
    "}" +
    "return out.join('\\u0002');" +
    "})();"

/**
 * Parse the encoded JS output back into a list of selection items.
 * Applies the body-link filter rules (see file-header docstring).
 */
private fun parseExtractedLinks(
    decoded: String,
    headUrl: String
): List<AppViewModel.WebSelectionItem> {
    if (decoded.isBlank()) return emptyList()
    val headHost = try {
        java.net.URI(headUrl).host?.lowercase() ?: ""
    } catch (_: Exception) {
        ""
    }
    val out = ArrayList<AppViewModel.WebSelectionItem>()
    for (entry in decoded.split('\u0002')) {
        if (entry.isBlank()) continue
        val sep = entry.indexOf('\u0001')
        val href = if (sep < 0) entry.trim() else entry.substring(0, sep).trim()
        val text = if (sep < 0) href else entry.substring(sep + 1).trim()
        if (href.isBlank()) continue
        if (href == headUrl) continue
        // No anchor-only bookmarks
        if (href.startsWith("#")) continue
        // Same-host filter — never wander off the origin
        if (headHost.isNotBlank()) {
            val linkHost = try {
                java.net.URI(href).host?.lowercase() ?: ""
            } catch (_: Exception) {
                continue
            }
            if (linkHost != headHost) continue
        }
        // Skip common non-article URL schemes
        val lower = href.lowercase()
        if (lower.startsWith("javascript:")) continue
        if (lower.startsWith("mailto:")) continue
        if (lower.startsWith("tel:")) continue
        out.add(
            AppViewModel.WebSelectionItem(
                url = href,
                title = text.ifBlank { href }
            )
        )
    }
    return out
}

/**
 * WebView tuned for head-expansion loads. Same knobs as
 * `buildBatchWebView` in WebViewerArticleSaver.kt — JS enabled,
 * mobile UA (so mobile jw.org markup is delivered), compatibility
 * mixed-content mode.
 */
@SuppressLint("SetJavaScriptEnabled")
private fun buildExpanderWebView(ctx: Context): WebView =
    WebView(ctx).apply {
        settings.javaScriptEnabled = true
        settings.domStorageEnabled = true
        settings.loadsImagesAutomatically = false
        settings.mediaPlaybackRequiresUserGesture = true
        settings.mixedContentMode = WebSettings.MIXED_CONTENT_COMPATIBILITY_MODE
        val defaultUa = settings.userAgentString
        settings.userAgentString = if (defaultUa.isNullOrBlank()) {
            "Mozilla/5.0 (Linux; Android 14) AppleWebKit/537.36 " +
                "(KHTML, like Gecko) Chrome/120.0.0.0 Mobile Safari/537.36"
        } else {
            defaultUa.replace("; wv)", ")")
        }
    }
