package com.tebogo.markvault.ai

import android.content.Context
import androidx.datastore.preferences.core.booleanPreferencesKey
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.intPreferencesKey
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import kotlinx.coroutines.flow.first

private val Context.aiDataStore by preferencesDataStore(name = "ai_settings")

/**
 * v5.4.73 — Persistent AI settings.
 */
object AiPreferenceStore {

    private val MODEL = stringPreferencesKey("retrieval_model")
    private val ENABLED = booleanPreferencesKey("ai_search_enabled")
    private val QUERY_COUNT = intPreferencesKey("query_expansion_count")

    suspend fun saveModel(context: Context, model: String) {
        context.aiDataStore.edit { it[MODEL] = model }
    }

    suspend fun loadModel(context: Context): String {
        return context.aiDataStore.data.first()[MODEL] ?: "QWEN3_0_6B"
    }

    suspend fun saveEnabled(context: Context, enabled: Boolean) {
        context.aiDataStore.edit { it[ENABLED] = enabled }
    }

    suspend fun loadEnabled(context: Context): Boolean {
        return context.aiDataStore.data.first()[ENABLED] ?: true
    }

    suspend fun saveQueryCount(context: Context, count: Int) {
        context.aiDataStore.edit { it[QUERY_COUNT] = count.coerceIn(0, 10) }
    }

    suspend fun loadQueryCount(context: Context): Int {
        return context.aiDataStore.data.first()[QUERY_COUNT] ?: 3
    }
}
