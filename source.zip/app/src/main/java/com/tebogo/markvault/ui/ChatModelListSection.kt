package com.tebogo.markvault.ui

import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.foundation.layout.Column
import com.tebogo.markvault.llm.ChatModelCatalog

@Composable
fun ChatModelListSection() {
    Column {
        Text("Local AI Models")
        ChatModelCatalog.all.forEach { model ->
            Text(model.displayName)
        }
    }
}
