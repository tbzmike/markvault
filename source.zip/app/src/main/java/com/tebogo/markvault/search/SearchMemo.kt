package com.tebogo.markvault.search

import kotlinx.coroutines.currentCoroutineContext
import kotlinx.coroutines.ensureActive
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock

/** Bounded exact-input inference reuse; failed/cancelled computations are never cached. */
class SearchMemo<K, V>(
    private val capacity: Int,
    private val maxAgeMs: Long,
    private val copy: (V) -> V,
    private val nowMs: () -> Long = { System.nanoTime() / 1_000_000 }
) {
    private data class Entry<V>(val value: V, val at: Long)
    private val entries = LinkedHashMap<K, Entry<V>>(capacity, 0.75f, true)
    private val lock = Mutex()

    init { require(capacity > 0 && maxAgeMs > 0) }

    suspend fun get(key: K, canReuse: () -> Boolean = { true }): V? = lock.withLock {
        currentCoroutineContext().ensureActive()
        if (!canReuse()) return@withLock null
        val entry = entries[key] ?: return@withLock null
        val age = nowMs() - entry.at
        if (age !in 0 until maxAgeMs) { entries.remove(key); return@withLock null }
        copy(entry.value)
    }

    suspend fun getOrCompute(key: K, canReuse: () -> Boolean = { true }, compute: suspend () -> V?): V? = lock.withLock {
        currentCoroutineContext().ensureActive()
        if (canReuse()) entries[key]?.let { entry ->
            val age = nowMs() - entry.at
            if (age in 0 until maxAgeMs) return@withLock copy(entry.value)
            entries.remove(key)
        }
        val value = compute() ?: return@withLock null
        currentCoroutineContext().ensureActive()
        if (canReuse()) entries[key] = Entry(copy(value), nowMs())
        while (entries.size > capacity) entries.entries.iterator().apply { next(); remove() }
        copy(value)
    }

    suspend fun clear() = lock.withLock { entries.clear() }
}
