package com.tebogo.markvault.markdown

object TagExtractor {
    fun extract(source:String):List<String> =
        Regex("""(?m)^tags:\s*([\s\S]*?)(?=^\S|\z)""").find(source)
            ?.value?.lines()?.drop(1)?.map{it.trim().removePrefix("-").trim()} ?: emptyList()
}
