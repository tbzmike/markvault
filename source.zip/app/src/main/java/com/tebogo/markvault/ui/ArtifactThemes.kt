package com.tebogo.markvault.ui

import androidx.compose.foundation.background
import androidx.compose.ui.draw.drawBehind
import androidx.compose.material3.ColorScheme
import androidx.compose.material3.Shapes
import androidx.compose.material3.lightColorScheme
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.ui.unit.dp
import androidx.compose.runtime.staticCompositionLocalOf

/**
 * v5.4.312cc — Physical-material theme family.
 *
 * These themes deliberately separate two jobs:
 *  1) Material3 colors for the whole Compose application.
 *  2) A richer semantic ink palette for rendered documents (see [artifactArticleCss]).
 *
 * Keeping document inks separate is what lets one article use several coordinated
 * colors at once without turning the surrounding app into a rainbow.
 */
private data class ArtifactInkPalette(
    val paper: String,
    val paper2: String,
    val ink: String,
    val muted: String,
    val h1: String,
    val h2: String,
    val h3: String,
    val h4: String,
    val h5: String,
    val h6: String,
    val link: String,
    val scripture: String,
    val bold: String,
    val italic: String,
    val ruleA: String,
    val ruleB: String,
    val quote: String,
    val quoteBg: String,
    val tableHead: String,
    val tableHeadInk: String,
    val tableOdd: String,
    val tableEven: String,
    val tableBorder: String,
    val tableAccent: String,
    val codeBg: String,
    val codeInk: String,
    val markBg: String,
    val markInk: String,
    val note: String,
    val info: String,
    val tip: String,
    val warning: String,
    val danger: String,
    val question: String,
    val example: String,
    val texture: String
)

val LocalArtifactThemeName = staticCompositionLocalOf<String?> { null }

fun isArtifactTheme(themeName: String?): Boolean = themeName in setOf(
    "artifact_parchment",
    "artifact_vellum",
    "artifact_stone",
    "artifact_papyrus",
    "artifact_marble"
)

val ArtifactThemeShapes = Shapes(
    extraSmall = RoundedCornerShape(7.dp),
    small = RoundedCornerShape(11.dp),
    medium = RoundedCornerShape(15.dp),
    large = RoundedCornerShape(19.dp),
    extraLarge = RoundedCornerShape(24.dp)
)

fun artifactColorScheme(themeName: String?): ColorScheme? = when (themeName) {
    "artifact_parchment" -> lightColorScheme(
        primary = Color(0xFF6A3427), onPrimary = Color.White,
        primaryContainer = Color(0xFFF0D3B0), onPrimaryContainer = Color(0xFF32140D),
        secondary = Color(0xFF2F665D), onSecondary = Color.White,
        secondaryContainer = Color(0xFFCFE7DE), onSecondaryContainer = Color(0xFF0C2A23),
        tertiary = Color(0xFF4E4F88), onTertiary = Color.White,
        tertiaryContainer = Color(0xFFDADBF1), onTertiaryContainer = Color(0xFF17183E),
        background = Color(0xFFF1DFC0), onBackground = Color(0xFF241C14),
        surface = Color(0xFFFFF4D9), onSurface = Color(0xFF241C14),
        surfaceVariant = Color(0xFFE7CC9F), onSurfaceVariant = Color(0xFF514131),
        outline = Color(0xFF8D7152), outlineVariant = Color(0xFFC8AA7D)
    )
    "artifact_vellum" -> lightColorScheme(
        primary = Color(0xFF384F75), onPrimary = Color.White,
        primaryContainer = Color(0xFFD9E3F4), onPrimaryContainer = Color(0xFF10233C),
        secondary = Color(0xFF7B3F58), onSecondary = Color.White,
        secondaryContainer = Color(0xFFF0D6DE), onSecondaryContainer = Color(0xFF32111F),
        tertiary = Color(0xFF4F6A43), onTertiary = Color.White,
        tertiaryContainer = Color(0xFFD9E8CF), onTertiaryContainer = Color(0xFF172A10),
        background = Color(0xFFF0EADF), onBackground = Color(0xFF24201B),
        surface = Color(0xFFFCF8EF), onSurface = Color(0xFF24201B),
        surfaceVariant = Color(0xFFE4DACC), onSurfaceVariant = Color(0xFF514A40),
        outline = Color(0xFF837667), outlineVariant = Color(0xFFC7B9A7)
    )
    "artifact_stone" -> lightColorScheme(
        primary = Color(0xFF355C72), onPrimary = Color.White,
        primaryContainer = Color(0xFFD0E4EF), onPrimaryContainer = Color(0xFF0C2938),
        secondary = Color(0xFF8B4D34), onSecondary = Color.White,
        secondaryContainer = Color(0xFFF0D5C8), onSecondaryContainer = Color(0xFF37160B),
        tertiary = Color(0xFF59683B), onTertiary = Color.White,
        tertiaryContainer = Color(0xFFDDE6C8), onTertiaryContainer = Color(0xFF1D290D),
        background = Color(0xFFDAD9D2), onBackground = Color(0xFF202322),
        surface = Color(0xFFF0EEE8), onSurface = Color(0xFF202322),
        surfaceVariant = Color(0xFFC9CBC6), onSurfaceVariant = Color(0xFF454A48),
        outline = Color(0xFF737A77), outlineVariant = Color(0xFFAAB0AD)
    )
    "artifact_papyrus" -> lightColorScheme(
        primary = Color(0xFF5C4512), onPrimary = Color.White,
        primaryContainer = Color(0xFFE8D28A), onPrimaryContainer = Color(0xFF261B02),
        secondary = Color(0xFF315F55), onSecondary = Color.White,
        secondaryContainer = Color(0xFFCCE1D9), onSecondaryContainer = Color(0xFF0C2822),
        tertiary = Color(0xFF9A4928), onTertiary = Color.White,
        tertiaryContainer = Color(0xFFF0D0C1), onTertiaryContainer = Color(0xFF381308),
        background = Color(0xFFE5D29B), onBackground = Color(0xFF282211),
        surface = Color(0xFFF5E6B5), onSurface = Color(0xFF282211),
        surfaceVariant = Color(0xFFD7C17F), onSurfaceVariant = Color(0xFF514728),
        outline = Color(0xFF827343), outlineVariant = Color(0xFFB7A264)
    )
    "artifact_marble" -> lightColorScheme(
        primary = Color(0xFF314F70), onPrimary = Color.White,
        primaryContainer = Color(0xFFD7E5F4), onPrimaryContainer = Color(0xFF0E263C),
        secondary = Color(0xFF77552D), onSecondary = Color.White,
        secondaryContainer = Color(0xFFECDCC4), onSecondaryContainer = Color(0xFF2F1D07),
        tertiary = Color(0xFF6D4668), onTertiary = Color.White,
        tertiaryContainer = Color(0xFFEBD7E7), onTertiaryContainer = Color(0xFF2C132A),
        background = Color(0xFFE9ECEB), onBackground = Color(0xFF202527),
        surface = Color(0xFFFAFBF8), onSurface = Color(0xFF202527),
        surfaceVariant = Color(0xFFDCE2E0), onSurfaceVariant = Color(0xFF475052),
        outline = Color(0xFF788183), outlineVariant = Color(0xFFB8C1C0)
    )
    else -> null
}

/** Pastel container rotation for global cards/results while keeping dark text readable. */
fun artifactSurfaceColor(themeName: String?, scheme: ColorScheme, index: Int): Color {
    if (!isArtifactTheme(themeName)) return scheme.surfaceVariant
    return when (Math.floorMod(index, 6)) {
        0 -> scheme.surface
        1 -> scheme.primaryContainer.copy(alpha = 0.72f)
        2 -> scheme.secondaryContainer.copy(alpha = 0.68f)
        3 -> scheme.tertiaryContainer.copy(alpha = 0.66f)
        4 -> scheme.surfaceVariant.copy(alpha = 0.78f)
        else -> scheme.surface.copy(alpha = 0.92f)
    }
}

/**
 * Physical-material backdrop for the whole Compose hierarchy.  It is intentionally
 * subtle: texture creates depth, while controls remain readable Material surfaces.
 */
fun Modifier.artifactThemeBackdrop(themeName: String?, scheme: ColorScheme): Modifier {
    if (!isArtifactTheme(themeName)) return this
    val base = this.background(
        Brush.verticalGradient(
            listOf(
                scheme.surface,
                scheme.background,
                scheme.surfaceVariant.copy(alpha = 0.62f),
                scheme.background,
                scheme.surface
            )
        )
    )
    return base.drawBehind {
        when (themeName) {
            "artifact_parchment", "artifact_vellum", "artifact_papyrus" -> {
                val fiber = scheme.outline.copy(alpha = if (themeName == "artifact_papyrus") 0.13f else 0.075f)
                var y = 10f
                while (y < size.height) {
                    drawLine(fiber, Offset(0f, y), Offset(size.width, y + ((y.toInt() / 19) % 3 - 1)), 0.7f)
                    y += if (themeName == "artifact_papyrus") 16f else 23f
                }
                var x = 31f
                while (x < size.width) {
                    drawLine(fiber.copy(alpha = fiber.alpha * 0.55f), Offset(x, 0f), Offset(x + 8f, size.height), 0.55f)
                    x += 67f
                }
            }
            "artifact_stone" -> {
                val vein = scheme.outline.copy(alpha = 0.09f)
                repeat(9) { i ->
                    val y = size.height * (i + 1) / 10f
                    drawLine(vein, Offset(0f, y), Offset(size.width, y + if (i % 2 == 0) 7f else -5f), 1.1f)
                }
                repeat(7) { i ->
                    val x = size.width * (i + 1) / 8f
                    drawLine(vein.copy(alpha = 0.055f), Offset(x, 0f), Offset(x - 12f, size.height), 0.8f)
                }
            }
            "artifact_marble" -> {
                val vein = scheme.primary.copy(alpha = 0.055f)
                repeat(7) { i ->
                    val startY = size.height * i / 7f
                    drawLine(vein, Offset(-30f, startY), Offset(size.width + 50f, startY + size.height * 0.17f), if (i % 2 == 0) 1.5f else 0.8f)
                    drawLine(scheme.secondary.copy(alpha = 0.035f), Offset(size.width * .15f, startY + 22f), Offset(size.width * .78f, startY - 38f), 0.7f)
                }
            }
        }
    }
}

private fun artifactInk(themeName: String?): ArtifactInkPalette? = when (themeName) {
    "artifact_parchment" -> ArtifactInkPalette(
        "#F1DFC0","#FFF4D9","#241C14","#665441",
        "#6A3427","#2F665D","#4E4F88","#9A5B20","#6B4777","#3B6874",
        "#2F6486","#8A2F36","#5A2A20","#406052","#9B6B2F","#2F665D",
        "#8A2F36","#F7E8D0","#704214","#FFF8E8","#E8D0AA","#F7E9CC","#EEDBBE","#B99568",
        "#3A2C22","#F7F0E2","#F0D56F","#34260E","#4E6F91","#2F7A68","#4B7D4B","#B17B16","#B84B42","#75518D","#6F4D8B","parchment"
    )
    "artifact_vellum" -> ArtifactInkPalette(
        "#F0EADF","#FCF8EF","#24201B","#686159",
        "#384F75","#7B3F58","#4F6A43","#8A642D","#66528C","#427078",
        "#315F82","#8B314A","#433A31","#6E4A5D","#8F7450","#657A72",
        "#7B3F58","#F8F1E5","#43566F","#FBF8F0","#E4E9F1","#F8F4EA","#EEE8DE","#AFA394",
        "#313943","#F3F5F5","#EEDB81","#2D281B","#4D7294","#3C786F","#5B7D49","#A67821","#B6534F","#76578F","#73538D","vellum"
    )
    "artifact_stone" -> ArtifactInkPalette(
        "#DAD9D2","#F0EEE8","#202322","#5D6260",
        "#355C72","#8B4D34","#59683B","#866A2F","#634E78","#3E6D6C",
        "#2E607C","#8F3B31","#39413F","#735348","#8F7B52","#5C7772",
        "#8B4D34","#E7E4DD","#425C69","#F4F2EC","#CDD9DE","#E9E9E4","#DCDDDA","#8C9490",
        "#2D383C","#EDF1F1","#E3C968","#2E2918","#416C86","#3F766B","#627B45","#A57720","#A94F43","#6D5584","#705486","stone"
    )
    "artifact_papyrus" -> ArtifactInkPalette(
        "#E5D29B","#F5E6B5","#282211","#665A35",
        "#5C4512","#315F55","#9A4928","#3E5676","#704C79","#6C6A2A",
        "#315C7A","#922F2A","#4F3615","#496449","#8B6D25","#486860",
        "#9A4928","#EFE0AE","#5C4512","#FFF0BD","#D9C178","#F0DDA2","#E6CF91","#A28B51",
        "#3B3217","#F2E9CB","#E8CF5A","#33290A","#456D8C","#357363","#5E7A3D","#A87213","#AC493A","#72518B","#76528B","papyrus"
    )
    "artifact_marble" -> ArtifactInkPalette(
        "#E9ECEB","#FAFBF8","#202527","#5E686A",
        "#314F70","#77552D","#6D4668","#3E6A62","#86612F","#506B7A",
        "#315F86","#7E334A","#343E45","#5D536D","#A07D42","#54736D",
        "#6D4668","#F0F3F1","#36566F","#FFFFFF","#DCE6EC","#F6F8F5","#E8ECE9","#AEB8B6",
        "#293942","#F5F8F8","#E8D16E","#2B2717","#486F94","#3E7A70","#5A7A48","#A57922","#B6534D","#73538B","#76538E","marble"
    )
    else -> null
}

/** Obsidian-style semantic document styling for the physical-material themes. */
fun artifactArticleCss(themeName: String?, scheme: ColorScheme): String {
    val p = artifactInk(themeName) ?: return ""
    val textureCss = when (p.texture) {
        "parchment" -> "radial-gradient(circle at 14% 18%,rgba(126,82,37,.055) 0 1px,transparent 2px),repeating-linear-gradient(2deg,rgba(95,62,28,.025) 0 1px,transparent 1px 5px)"
        "vellum" -> "repeating-linear-gradient(0deg,rgba(70,65,56,.022) 0 1px,transparent 1px 6px),linear-gradient(90deg,rgba(92,58,57,.025),transparent 12%,transparent 88%,rgba(92,58,57,.025))"
        "stone" -> "linear-gradient(115deg,transparent 0 34%,rgba(70,82,80,.035) 35%,transparent 36% 67%,rgba(80,72,62,.028) 68%,transparent 69%),repeating-linear-gradient(0deg,rgba(60,67,65,.018) 0 1px,transparent 1px 8px)"
        "papyrus" -> "repeating-linear-gradient(0deg,rgba(91,72,24,.055) 0 1px,transparent 1px 7px),repeating-linear-gradient(90deg,rgba(91,72,24,.025) 0 1px,transparent 1px 19px)"
        else -> "linear-gradient(128deg,transparent 0 28%,rgba(49,79,112,.035) 29%,transparent 30% 66%,rgba(119,85,45,.028) 67%,transparent 68%),linear-gradient(12deg,transparent 0 54%,rgba(109,70,104,.025) 55%,transparent 56%)"
    }
    return """
        html,body{background-color:${p.paper}!important;background-image:$textureCss!important;background-attachment:fixed!important;color:${p.ink}!important;}
        body,p,li,dd,dt,td{color:${p.ink}!important;text-rendering:optimizeLegibility!important;letter-spacing:.004em!important;}
        h1{color:${p.h1}!important;border-bottom:3px solid ${p.ruleA}!important;text-shadow:0 1px rgba(255,255,255,.72)!important;}
        h2{color:${p.h2}!important;border-bottom:2px solid ${p.ruleB}!important;text-shadow:0 1px rgba(255,255,255,.62)!important;}
        h3{color:${p.h3}!important;} h4{color:${p.h4}!important;} h5{color:${p.h5}!important;} h6{color:${p.h6}!important;}
        strong,b{color:${p.bold}!important;} em,i{color:${p.italic}!important;}
        a,a:visited{color:${p.link}!important;text-decoration-color:${p.ruleB}!important;text-decoration-thickness:1.5px!important;}
        a[href*="jw.org/finder"],a[href*="bible="],a[href*="jwlibrary"],a[href*="wol.jw.org"]{color:${p.scripture}!important;font-weight:700!important;text-decoration-color:${p.scripture}!important;}
        .wikilink{color:${p.h3}!important;border-bottom-color:${p.h3}!important;}
        li::marker{color:${p.h2}!important;font-weight:700!important;}
        hr{height:2px!important;border:0!important;background:linear-gradient(90deg,transparent,${p.ruleA} 18%,${p.ruleB} 52%,${p.ruleA} 82%,transparent)!important;opacity:.9!important;}
        blockquote{color:${p.ink}!important;border:1px solid ${p.tableBorder}!important;border-left:6px solid ${p.quote}!important;background:linear-gradient(135deg,${p.quoteBg},${p.paper2})!important;border-radius:5px 14px 14px 5px!important;box-shadow:0 8px 18px rgba(46,37,24,.12),inset 0 1px rgba(255,255,255,.72)!important;}
        table{background:${p.paper2}!important;border:2px solid ${p.tableBorder}!important;border-radius:10px!important;box-shadow:0 8px 20px rgba(45,40,31,.10)!important;}
        th{background:linear-gradient(180deg,${p.tableHead},color-mix(in srgb,${p.tableHead} 76%,${p.paper2}))!important;color:${p.tableHeadInk}!important;border-color:${p.tableBorder}!important;border-bottom:3px solid ${p.tableAccent}!important;}
        td{border-color:${p.tableBorder}!important;} tr:nth-child(odd) td{background:${p.tableOdd}!important;} tr:nth-child(even) td{background:${p.tableEven}!important;}
        pre{background:${p.codeBg}!important;color:${p.codeInk}!important;border:1px solid ${p.tableBorder}!important;box-shadow:0 8px 18px rgba(45,40,31,.11),inset 0 1px rgba(255,255,255,.5)!important;}
        pre code{color:${p.codeInk}!important;} :not(pre)>code{background:color-mix(in srgb,${p.codeBg} 84%,${p.paper})!important;color:${p.h4}!important;border:1px solid ${p.tableBorder}!important;}
        mark{background:${p.markBg}!important;color:${p.markInk}!important;box-shadow:inset 0 -1px rgba(0,0,0,.10)!important;}
        details,.markdown-embed{background:linear-gradient(145deg,${p.paper2},${p.tableEven})!important;border:1px solid ${p.tableBorder}!important;border-left:4px solid ${p.h3}!important;box-shadow:0 7px 16px rgba(45,40,31,.09)!important;}
        details>summary,.markdown-embed-title{color:${p.h3}!important;}
        .callout{background:color-mix(in srgb,var(--cl-accent) 9%,${p.paper2})!important;border-color:color-mix(in srgb,var(--cl-accent) 56%,${p.tableBorder})!important;box-shadow:0 7px 16px rgba(45,40,31,.09),inset 0 1px rgba(255,255,255,.58)!important;}
        .cl-note{--cl-accent:${p.note}!important}.cl-info{--cl-accent:${p.info}!important}.cl-tip,.cl-success{--cl-accent:${p.tip}!important}.cl-warning,.cl-caution{--cl-accent:${p.warning}!important}.cl-danger,.cl-error{--cl-accent:${p.danger}!important}.cl-question{--cl-accent:${p.question}!important}.cl-example{--cl-accent:${p.example}!important}.cl-quote{--cl-accent:${p.quote}!important}
        .callout-title{color:var(--cl-accent)!important;}
        .footnotes{border-top:2px solid ${p.ruleB}!important;color:${p.muted}!important;}
        sup[id^="fnref"] a{background:color-mix(in srgb,${p.link} 12%,${p.paper2})!important;color:${p.link}!important;}
        img{border:1px solid ${p.tableBorder}!important;border-radius:9px!important;box-shadow:0 11px 24px rgba(45,40,31,.15)!important;}
    """.trimIndent()
}
