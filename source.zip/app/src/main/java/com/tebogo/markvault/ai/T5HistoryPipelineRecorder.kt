package com.tebogo.markvault.ai

/** Records final expansion pipeline details. */
object T5HistoryPipelineRecorder {
    private var last: T5QueryTrace? = null

    fun record(trace: T5QueryTrace) { last = trace }
    fun getLast(): T5QueryTrace? = last
}
