package com.tebogo.markvault.ai

/** RAM protection rules for local models. */
object AiModelPolicy {
    const val DEFAULT_MODEL = "SmolLM2-135M"
    const val TIMEOUT_MS = 1200L

    fun allowModelLoad(availableMemoryMb: Long): Boolean = availableMemoryMb > 700
}
