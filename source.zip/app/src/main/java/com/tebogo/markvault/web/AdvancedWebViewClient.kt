package com.tebogo.markvault.web

import android.graphics.Bitmap
import android.webkit.WebResourceRequest
import android.webkit.WebView
import android.webkit.WebViewClient

/**
 * v5.4.78 — Stable browser client.
 *
 * Handles blank renderer failures by retrying failed page loads once.
 */
class AdvancedWebViewClient : WebViewClient() {

    private var retry = false

    override fun onPageStarted(
        view: WebView?,
        url: String?,
        favicon: Bitmap?
    ) {
        retry = false
    }

    override fun onReceivedError(
        view: WebView?,
        request: WebResourceRequest?,
        error: android.webkit.WebResourceError?
    ) {
        if (!retry && request?.isForMainFrame == true) {
            retry = true
            view?.reload()
        }
    }
}
