package com.tebogo.markvault.ai

object T5SearchModeResolver {
    fun resolve(): T5ExpansionMode {
        return when (T5ExpansionPreferenceStore.get()) {
            T5ExpansionPreference.T5_BASE -> T5ExpansionMode.T5_BASE
            else -> T5ExpansionMode.BUILTIN
        }
    }
}
