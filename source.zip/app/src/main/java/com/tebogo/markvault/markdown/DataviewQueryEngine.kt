package com.tebogo.markvault.markdown

/**
 * Lightweight Dataview-style query foundation.
 * Converts simple query blocks into structured requests.
 * Does not trigger indexing or change vault scanning behaviour.
 */
object DataviewQueryEngine {

    data class Query(
        val fields: List<String>,
        val source: String?
    )

    fun parse(block: String): Query? {
        if (!block.trimStart().startsWith("TABLE")) return null
        val lines = block.lines()
        val fields = lines.firstOrNull()
            ?.removePrefix("TABLE")
            ?.split(",")
            ?.map { it.trim() }
            ?.filter { it.isNotEmpty() }
            ?: emptyList()

        val source = lines.firstOrNull { it.trim().startsWith("FROM") }
            ?.removePrefix("FROM")
            ?.trim()

        return Query(fields, source)
    }
}
