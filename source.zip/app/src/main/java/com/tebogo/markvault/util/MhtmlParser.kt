package com.tebogo.markvault.util

/**
 * Parse a `.mhtml` web archive in pure Kotlin — extracts the HTML root part as
 * a self-contained string that can be fed to `WebView.loadDataWithBaseURL`.
 *
 * Why this exists: Android System WebView (which IS Chromium on every modern
 * device) has a built-in MHTML parser, but it crashes on malformed envelopes,
 * unusual boundary patterns, or files with unexpected line endings. Crashes
 * happen in NATIVE code via JNI, so they can take the whole renderer process
 * with them. By parsing the MIME framing ourselves and handing the WebView
 * only plain HTML, we eliminate the crash class entirely.
 *
 * Trade-offs:
 *   • Images stored as separate MIME parts won't render (their `cid:` references
 *     don't resolve without an inline-resource pass). The user can still read
 *     all the text — which is the whole point of a saved scripture article.
 *   • A future enhancement could inline images as `data:` URIs. Not now.
 */
object MhtmlParser {

    /**
     * Extract the root `text/html` part as a UTF-8 string, ready to feed to
     * `WebView.loadDataWithBaseURL(..., "text/html", "utf-8", ...)`.
     *
     * @return the decoded HTML body, or null if the file isn't a recognisable
     *         MHTML envelope (caller should treat as plain HTML or surface an error).
     */
    fun extractHtmlContent(bytes: ByteArray): String? {
        return try {
            // ISO-8859-1 is a 1:1 byte mapping — we use it to do textual regex
            // scanning over what is technically a mix of ASCII headers and
            // potentially binary part bodies. We re-decode using the proper
            // charset (declared in the HTML part's headers) at the end.
            val text = String(bytes, Charsets.ISO_8859_1)

            val boundary = findBoundary(text) ?: return null
            val parts = text.split("--$boundary")

            // First text/html part is the page root.
            val htmlPart = parts.firstOrNull { part ->
                Regex("(?im)^content-type:\\s*text/html").containsMatchIn(part)
            } ?: return null

            val (headers, body) = splitHeadersAndBody(htmlPart) ?: return null

            val encoding = Regex("(?im)content-transfer-encoding:\\s*(\\S+)")
                .find(headers)?.groupValues?.get(1)?.lowercase()?.trim()

            val decoded = when (encoding) {
                "quoted-printable" -> decodeQuotedPrintable(body)
                "base64" -> decodeBase64(body)
                else -> body
            }

            val charset = Regex("""(?im)content-type:[^\r\n]*charset="?([^";\s\r\n]+)"?""")
                .find(headers)?.groupValues?.get(1)?.trim() ?: "utf-8"

            // Re-encode through the declared charset. We currently hold a
            // String that was built from raw bytes via ISO-8859-1, so writing
            // it back to bytes preserves the bytes; decoding via the page's
            // declared charset then gives us proper Unicode.
            try {
                String(
                    decoded.toByteArray(Charsets.ISO_8859_1),
                    java.nio.charset.Charset.forName(charset)
                )
            } catch (_: Exception) {
                // Unknown charset — fall back to the ISO string as-is.
                decoded
            }
        } catch (_: Exception) {
            null
        }
    }

    /**
     * Look at the first 8 KB of the file to find the root HTML part's
     * Content-Location — that's the URL of the page when it was originally
     * saved. Used as the base href so relative URLs in the page resolve to the
     * right origin (e.g. `/en/library/...` resolves to jw.org/en/library/...).
     */
    fun extractBaseUrl(bytes: ByteArray): String? {
        val head = String(
            bytes.copyOf(minOf(bytes.size, 8192)),
            Charsets.ISO_8859_1
        )
        return Regex("""(?im)^content-location:\s*(\S+)""")
            .find(head)?.groupValues?.get(1)?.trim()
    }

    // --- helpers -----------------------------------------------------------

    private fun findBoundary(text: String): String? {
        // RFC 2046: boundary parameter, optionally quoted, value is a token of
        // printable ASCII with no whitespace.
        val m = Regex("""(?im)boundary\s*=\s*"?([^";\s\r\n]+)"?""").find(
            text.take(8192)  // boundary is always declared in the top-level headers
        )
        return m?.groupValues?.get(1)?.trim()
    }

    /**
     * Split a MIME part into (headers, body) at the first blank line. Handles
     * both CRLF (correct per RFC) and LF (some browsers and editors).
     */
    private fun splitHeadersAndBody(part: String): Pair<String, String>? {
        val crlfIdx = part.indexOf("\r\n\r\n")
        if (crlfIdx >= 0) {
            return part.substring(0, crlfIdx) to part.substring(crlfIdx + 4)
        }
        val lfIdx = part.indexOf("\n\n")
        if (lfIdx >= 0) {
            return part.substring(0, lfIdx) to part.substring(lfIdx + 2)
        }
        return null
    }

    private fun decodeQuotedPrintable(text: String): String {
        var out = text
        // Soft line breaks: `=` at end of line + line terminator → join.
        out = out.replace(Regex("=\\r?\\n"), "")
        // `=XX` hex byte escapes.
        out = out.replace(Regex("=([0-9A-Fa-f]{2})")) { m ->
            try {
                m.groupValues[1].toInt(16).toChar().toString()
            } catch (_: Exception) {
                m.value
            }
        }
        return out
    }

    private fun decodeBase64(text: String): String {
        return try {
            val clean = text.replace(Regex("\\s"), "")
            val raw = android.util.Base64.decode(clean, android.util.Base64.DEFAULT)
            // Re-wrap as ISO-8859-1 so the caller's downstream charset
            // re-decode step works.
            String(raw, Charsets.ISO_8859_1)
        } catch (_: Exception) {
            ""
        }
    }
}
