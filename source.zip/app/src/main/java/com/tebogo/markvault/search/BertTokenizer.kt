package com.tebogo.markvault.search

/**
 * Pure-Kotlin WordPiece BERT tokenizer for uncased models like
 * all-MiniLM-L6-v2.
 *
 * This is a faithful re-implementation of the Hugging Face / Google BERT
 * `BasicTokenizer` + `WordpieceTokenizer` pipeline. The pipeline:
 *
 *   1. **Basic tokenization** — lowercases, splits on whitespace and
 *      punctuation. Punctuation characters become their own tokens.
 *   2. **WordPiece tokenization** — greedy longest-match against the vocab.
 *      Continuation pieces are prefixed with `##`. Words longer than
 *      [MAX_INPUT_CHARS_PER_WORD] characters are emitted as `[UNK]` to
 *      avoid pathological scanning.
 *   3. **Special tokens** — `[CLS]` is prepended and `[SEP]` appended to
 *      the final sequence so the model knows where the input begins and
 *      ends. The result is truncated to `maxLength` tokens.
 *
 * The vocabulary is supplied at construction time as a `Map<String, Int>`
 * where the value is the BERT vocab ID (the line number in `vocab.txt`,
 * 0-indexed). For all-MiniLM-L6-v2 the IDs are the standard BERT-base
 * uncased ones — `[PAD]=0`, `[UNK]=100`, `[CLS]=101`, `[SEP]=102`,
 * `[MASK]=103`.
 *
 * v4.10.0 — introduced alongside the ONNX BERT backend.
 */
internal class BertTokenizer(
    private val vocab: Map<String, Int>,
) {
    /** Token ID looked up once at construction so [encode] doesn't repeat the map lookup. */
    private val clsId: Int = vocab[CLS_TOKEN] ?: 101
    private val sepId: Int = vocab[SEP_TOKEN] ?: 102
    private val unkId: Int = vocab[UNK_TOKEN] ?: 100

    /**
     * Tokenise [text] and convert to BERT vocab IDs. The output begins with
     * `[CLS]`, ends with `[SEP]`, and is truncated to at most [maxLength]
     * IDs in total. Unknown tokens become `[UNK]`.
     */
    fun encode(text: String, maxLength: Int = 256): IntArray {
        if (maxLength < 2) return intArrayOf(clsId, sepId)
        val budget = maxLength - 2  // reserve room for CLS and SEP
        val ids = ArrayList<Int>(maxLength)
        ids.add(clsId)
        var emitted = 0
        for (word in basicTokenize(text)) {
            if (emitted >= budget) break
            val pieces = wordpieceTokenize(word)
            for (p in pieces) {
                if (emitted >= budget) break
                ids.add(vocab[p] ?: unkId)
                emitted++
            }
        }
        ids.add(sepId)
        return ids.toIntArray()
    }

    /**
     * v4.23.0 — Cross-encoder pair encoding for the reranker.
     *
     * Produces three parallel arrays from a (query, document) pair:
     *
     *   - **input_ids**:        `[CLS] q_tok... [SEP] d_tok... [SEP]`
     *   - **attention_mask**:   all 1s of the same length
     *   - **token_type_ids**:   0 for `[CLS] q_tok... [SEP]`,
     *                            1 for `d_tok... [SEP]`
     *
     * Truncation strategy when over [maxLength]: keep the entire query
     * (queries are short) and truncate the document. This matches BERT's
     * standard "longest_first"/"only_second" pattern from Hugging Face,
     * applied to the reranker use case where the query is the cheap
     * thing to keep intact.
     *
     * Returns a [PairEncoding] holding all three arrays — same length.
     */
    fun encodePair(query: String, doc: String, maxLength: Int = 512): PairEncoding {
        // Reserve room for 3 special tokens: [CLS] q [SEP] d [SEP]
        if (maxLength < 4) {
            return PairEncoding(
                inputIds = intArrayOf(clsId, sepId, sepId),
                attentionMask = intArrayOf(1, 1, 1),
                tokenTypeIds = intArrayOf(0, 0, 1)
            )
        }

        // Tokenize query first — small, keep intact.
        val qPieces = ArrayList<Int>(32)
        for (word in basicTokenize(query)) {
            for (p in wordpieceTokenize(word)) {
                qPieces.add(vocab[p] ?: unkId)
            }
        }
        // Cap query alone at half the budget so a pathologically long
        // query can never starve the document of room entirely.
        val qBudget = (maxLength - 3) / 2  // -3 = CLS + SEP + SEP
        val q = if (qPieces.size > qBudget) qPieces.subList(0, qBudget) else qPieces

        val docBudget = maxLength - 3 - q.size

        val dPieces = ArrayList<Int>(maxLength)
        if (docBudget > 0) {
            outer@ for (word in basicTokenize(doc)) {
                for (p in wordpieceTokenize(word)) {
                    dPieces.add(vocab[p] ?: unkId)
                    if (dPieces.size >= docBudget) break@outer
                }
            }
        }

        val total = 1 + q.size + 1 + dPieces.size + 1  // CLS + q + SEP + d + SEP
        val inputIds = IntArray(total)
        val tokenTypeIds = IntArray(total)
        val attentionMask = IntArray(total) { 1 }

        var i = 0
        inputIds[i] = clsId
        tokenTypeIds[i] = 0
        i++
        for (id in q) {
            inputIds[i] = id; tokenTypeIds[i] = 0; i++
        }
        inputIds[i] = sepId
        tokenTypeIds[i] = 0
        i++
        for (id in dPieces) {
            inputIds[i] = id; tokenTypeIds[i] = 1; i++
        }
        inputIds[i] = sepId
        tokenTypeIds[i] = 1

        return PairEncoding(inputIds, attentionMask, tokenTypeIds)
    }

    /** Result of [encodePair]. All three arrays have identical length. */
    data class PairEncoding(
        val inputIds: IntArray,
        val attentionMask: IntArray,
        val tokenTypeIds: IntArray
    )

    /**
     * Step 1 of BERT tokenisation. Lowercases (uncased model assumption),
     * splits on whitespace, and treats every punctuation character as its
     * own token. Mirrors `BasicTokenizer.tokenize` from the reference
     * implementation, minus the Chinese/Japanese/Korean character splitting
     * (which the user's library doesn't need).
     */
    private fun basicTokenize(text: String): List<String> {
        if (text.isEmpty()) return emptyList()
        val lower = text.lowercase()
        val out = ArrayList<String>(lower.length / 4 + 1)
        val buf = StringBuilder()
        for (ch in lower) {
            when {
                ch.isWhitespace() -> {
                    if (buf.isNotEmpty()) {
                        out.add(buf.toString()); buf.setLength(0)
                    }
                }
                isPunctuation(ch) -> {
                    if (buf.isNotEmpty()) {
                        out.add(buf.toString()); buf.setLength(0)
                    }
                    out.add(ch.toString())
                }
                isControl(ch) -> {
                    // Skip control characters (\u0000-\u001f minus tab/newline,
                    // \u007f-\u009f). They appear in raw text occasionally and
                    // BERT's reference tokenizer drops them silently.
                }
                else -> buf.append(ch)
            }
        }
        if (buf.isNotEmpty()) out.add(buf.toString())
        return out
    }

    /**
     * Step 2 of BERT tokenisation. Greedy longest-match: try to consume the
     * largest prefix of [word] that's in the vocab; non-prefix continuations
     * are scored as `##piece`. If no prefix matches at any point, the entire
     * word becomes `[UNK]`. This matches Hugging Face's behaviour exactly.
     */
    private fun wordpieceTokenize(word: String): List<String> {
        if (word.length > MAX_INPUT_CHARS_PER_WORD) return listOf(UNK_TOKEN)
        val pieces = ArrayList<String>(4)
        var start = 0
        while (start < word.length) {
            var end = word.length
            var matched: String? = null
            while (start < end) {
                val piece = if (start == 0) word.substring(start, end)
                else "##" + word.substring(start, end)
                if (piece in vocab) {
                    matched = piece
                    break
                }
                end--
            }
            if (matched == null) return listOf(UNK_TOKEN)
            pieces.add(matched)
            start = end
        }
        return pieces
    }

    /** ASCII punctuation + Unicode punctuation categories. Matches BERT exactly. */
    private fun isPunctuation(ch: Char): Boolean {
        val code = ch.code
        if (code in 33..47 || code in 58..64 || code in 91..96 || code in 123..126) {
            return true
        }
        return ch.category in PUNCT_CATEGORIES
    }

    /** Control / formatting characters that BERT's BasicTokenizer drops. */
    private fun isControl(ch: Char): Boolean {
        if (ch == '\t' || ch == '\n' || ch == '\r') return false  // treated as whitespace upstream
        if (ch.code in 0..31 || ch.code in 127..159) return true
        return ch.category in CONTROL_CATEGORIES
    }

    companion object {
        const val PAD_TOKEN = "[PAD]"
        const val UNK_TOKEN = "[UNK]"
        const val CLS_TOKEN = "[CLS]"
        const val SEP_TOKEN = "[SEP]"
        const val MASK_TOKEN = "[MASK]"

        /** Words longer than this become `[UNK]` outright (pathological scan guard). */
        const val MAX_INPUT_CHARS_PER_WORD = 100

        private val PUNCT_CATEGORIES = setOf(
            CharCategory.CONNECTOR_PUNCTUATION,
            CharCategory.DASH_PUNCTUATION,
            CharCategory.START_PUNCTUATION,
            CharCategory.END_PUNCTUATION,
            CharCategory.INITIAL_QUOTE_PUNCTUATION,
            CharCategory.FINAL_QUOTE_PUNCTUATION,
            CharCategory.OTHER_PUNCTUATION,
        )

        private val CONTROL_CATEGORIES = setOf(
            CharCategory.CONTROL,
            CharCategory.FORMAT,
        )

        /**
         * Build the vocabulary [Map] from the raw `vocab.txt` lines. Each line
         * is one token; the token's ID is its 0-indexed line number. Empty
         * lines (rare but possible at EOF) are skipped without shifting IDs —
         * BERT vocabs don't normally contain blanks, so the assignment is
         * accurate.
         */
        fun buildVocabMap(lines: List<String>): Map<String, Int> {
            val out = HashMap<String, Int>(lines.size * 2)
            for ((idx, raw) in lines.withIndex()) {
                val token = raw.trim()
                if (token.isNotEmpty()) out[token] = idx
            }
            return out
        }

        /**
         * Sanity check that a [vocab] map has the special tokens we need to
         * encode anything. Returns true when it's safe to use; false suggests
         * a corrupt download or wrong vocab.txt file.
         */
        fun isVocabUsable(vocab: Map<String, Int>): Boolean {
            return CLS_TOKEN in vocab && SEP_TOKEN in vocab && UNK_TOKEN in vocab
        }
    }
}
