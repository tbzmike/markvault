package com.tebogo.markvault.ai

enum class T5PersistentMode { BUILTIN, T5_BASE }

object T5PersistentModeStore {
    private var mode = T5PersistentMode.BUILTIN

    fun save(value: T5PersistentMode) { mode = value }
    fun load(): T5PersistentMode = mode
}
