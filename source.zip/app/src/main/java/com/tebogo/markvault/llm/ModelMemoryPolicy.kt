package com.tebogo.markvault.llm

import android.app.ActivityManager
import android.content.Context

object ModelMemoryPolicy {
    fun chooseModel(context: Context): ChatModelDescriptor {
        val am = context.getSystemService(Context.ACTIVITY_SERVICE) as ActivityManager
        val info = ActivityManager.MemoryInfo()
        am.getMemoryInfo(info)

        val availableMb = info.availMem / (1024 * 1024)

        return if (availableMb < 1200) {
            ChatModelCatalog.SMOLLM2_135M_INSTRUCT
        } else {
            ChatModelCatalog.default
        }
    }
}