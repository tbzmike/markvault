package com.tebogo.markvault.ai

/** Final safety checks before enabling T5 runtime. */
object T5FinalSafetyChecks {
    fun canRun(): Boolean {
        return T5ExpansionAvailability.isAvailable()
    }

    fun fallbackMode(): T5ExpansionMode {
        return T5ExpansionMode.BUILTIN
    }
}
