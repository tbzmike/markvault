package com.tebogo.markvault.search

import kotlinx.coroutines.currentCoroutineContext
import kotlinx.coroutines.ensureActive
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.first
import java.util.concurrent.atomic.AtomicBoolean

/** Bulk embedding/index work yields at checkpoints while an interactive search runs. */
object SearchWorkPriority {
    private val searches = MutableStateFlow(0)

    class Lease internal constructor() : AutoCloseable {
        private val closed = AtomicBoolean(false)
        override fun close() {
            if (closed.compareAndSet(false, true)) leave()
        }
    }

    @Synchronized fun begin(): Lease {
        searches.value += 1
        return Lease()
    }

    @Synchronized private fun leave() { searches.value -= 1 }

    suspend fun awaitIdle() {
        currentCoroutineContext().ensureActive()
        if (searches.value != 0) searches.first { it == 0 }
    }
}
