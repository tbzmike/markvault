package com.tebogo.markvault.ui

import android.graphics.Color as AndroidColor
import android.webkit.WebView
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.staticCompositionLocalOf
import androidx.webkit.WebSettingsCompat
import androidx.webkit.WebViewFeature

const val APP_APPEARANCE_SYSTEM = "system"
const val APP_APPEARANCE_LIGHT = "light"
const val APP_APPEARANCE_DARK = "dark"

fun normalizeAppAppearanceMode(value: String?): String = when (value?.lowercase()) {
    APP_APPEARANCE_LIGHT -> APP_APPEARANCE_LIGHT
    APP_APPEARANCE_DARK -> APP_APPEARANCE_DARK
    else -> APP_APPEARANCE_SYSTEM
}

fun resolveAppDark(appearanceMode: String, systemDark: Boolean): Boolean = when (
    normalizeAppAppearanceMode(appearanceMode)
) {
    APP_APPEARANCE_LIGHT -> false
    APP_APPEARANCE_DARK -> true
    else -> systemDark
}

@Composable
fun resolveAppDark(appearanceMode: String): Boolean =
    resolveAppDark(appearanceMode, isSystemInDarkTheme())

/** Effective app-wide appearance. Every document renderer reads this same value. */
val LocalMarkVaultDarkMode = staticCompositionLocalOf { true }

/**
 * Applies MarkVault's universal appearance to arbitrary online HTML without
 * changing document geometry. Algorithmic darkening is feature-detected, then a
 * small DOM bridge guarantees the root page cannot remain white in dark mode
 * (or black in forced light mode). The bridge only rewrites extreme light/dark
 * computed colours and tags its own inline overrides so switching modes can
 * cleanly undo them without deleting site-authored styles.
 */
fun applyUniversalWebAppearance(webView: WebView, dark: Boolean, allowAlgorithmic: Boolean = true) {
    if (allowAlgorithmic) runCatching {
        if (WebViewFeature.isFeatureSupported(WebViewFeature.ALGORITHMIC_DARKENING)) {
            WebSettingsCompat.setAlgorithmicDarkeningAllowed(webView.settings, dark)
        } else if (WebViewFeature.isFeatureSupported(WebViewFeature.FORCE_DARK)) {
            @Suppress("DEPRECATION")
            WebSettingsCompat.setForceDark(
                webView.settings,
                if (dark) WebSettingsCompat.FORCE_DARK_ON else WebSettingsCompat.FORCE_DARK_OFF
            )
        }
    }
    webView.setBackgroundColor(if (dark) AndroidColor.rgb(28, 32, 38) else AndroidColor.WHITE)
    webView.evaluateJavascript(universalWebAppearanceJs(dark), null)
}

fun universalWebAppearanceJs(dark: Boolean): String {
    val mode = if (dark) "dark" else "light"
    val bg = if (dark) "#1c2026" else "#ffffff"
    val fg = if (dark) "#e2e6ec" else "#202124"
    val replaceBgTest = if (dark) "lum(bg)>0.88" else "lum(bg)<0.12"
    val replaceFgTest = if (dark) "lum(fg)<0.20" else "lum(fg)>0.82"
    return """
(function(){
  try {
    var DARK=${if (dark) "true" else "false"};
    var MODE='$mode', BG='$bg', FG='$fg';
    var root=document.documentElement, body=document.body;
    if(!root) return;
    function rgb(v){
      var m=(v||'').match(/rgba?\(\s*([0-9.]+)[, ]+\s*([0-9.]+)[, ]+\s*([0-9.]+)(?:[, /]+\s*([0-9.]+))?/i);
      if(!m)return null; return [+m[1]/255,+m[2]/255,+m[3]/255,m[4]===undefined?1:+m[4]];
    }
    function lum(c){ if(!c)return -1; function f(x){return x<=.03928?x/12.92:Math.pow((x+.055)/1.055,2.4);} return .2126*f(c[0])+.7152*f(c[1])+.0722*f(c[2]); }
    function clear(n){
      if(!n||!n.dataset)return;
      if(n.dataset.mvAppearanceBg==='1'){n.style.removeProperty('background-color');delete n.dataset.mvAppearanceBg;}
      if(n.dataset.mvAppearanceFg==='1'){n.style.removeProperty('color');delete n.dataset.mvAppearanceFg;}
    }
    function paint(n){
      if(!n||n.nodeType!==1)return;
      clear(n);
      var tag=(n.tagName||'').toUpperCase();
      if(tag==='IMG'||tag==='VIDEO'||tag==='CANVAS'||tag==='SVG'||tag==='IFRAME'||tag==='PICTURE'||tag==='SOURCE')return;
      var cs=getComputedStyle(n), bg=rgb(cs.backgroundColor), fg=rgb(cs.color);
      if(bg&&bg[3]>.80&&($replaceBgTest)){
        n.style.setProperty('background-color',BG,'important');n.dataset.mvAppearanceBg='1';
      }
      var textTag=/^(P|SPAN|LI|TD|TH|DD|DT|LABEL|BLOCKQUOTE|H1|H2|H3|H4|H5|H6|A|BUTTON|SUMMARY|CAPTION|FIGCAPTION|CODE|PRE)$/i.test(tag);
      if(textTag&&fg&&($replaceFgTest)){
        n.style.setProperty('color',FG,'important');n.dataset.mvAppearanceFg='1';
      }
    }
    root.classList.remove('theme-dark','theme-light');root.classList.add('theme-'+MODE);
    root.style.setProperty('color-scheme',MODE,'important');
    if(body){body.classList.remove('theme-dark','theme-light');body.classList.add('theme-'+MODE);}
    var s=document.getElementById('mv-universal-appearance');
    if(!s){s=document.createElement('style');s.id='mv-universal-appearance';(document.head||root).appendChild(s);}
    s.textContent='html,body{background-color:'+BG+' !important;color:'+FG+' !important;color-scheme:'+MODE+' !important;}';
    if(body){paint(body);var all=body.querySelectorAll('*');for(var i=0;i<all.length;i++)paint(all[i]);}
    if(window.__mvAppearanceObserver){try{window.__mvAppearanceObserver.disconnect();}catch(e){}}
    if(body&&window.MutationObserver){
      window.__mvAppearanceObserver=new MutationObserver(function(ms){
        ms.forEach(function(m){
          for(var i=0;i<m.addedNodes.length;i++){
            var n=m.addedNodes[i];
            if(n.nodeType===1){
              paint(n);
              var q=n.querySelectorAll?n.querySelectorAll('*'):[];
              for(var j=0;j<q.length;j++){paint(q[j]);}
            }
          }
        });
      });
      window.__mvAppearanceObserver.observe(body,{childList:true,subtree:true});
    }
  }catch(e){}
})();
""".trimIndent()
}
