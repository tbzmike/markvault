package com.tebogo.markvault.ai

/**
 * T5-base retrieval expansion model metadata.
 *
 * Keeps T5 separate from chat LLM models.
 * Runtime loading will consume this descriptor.
 */
data class T5ModelDescriptor(
    val id: String = "t5-base-paraphrase",
    val displayName: String = "T5-base Paraphraser",
    val modelFileName: String = "t5-base-paraphrase.tflite",
    val tokenizerFileName: String = "spiece.model"
)
