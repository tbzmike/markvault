package com.tebogo.markvault.markdown

object MermaidProcessor {
    private val regex=Regex("""```mermaid\s*([\s\S]*?)```""")
    fun process(source:String):String =
        regex.replace(source){ "<div class=\"mermaid\">\n${it.groupValues[1].trim()}\n</div>" }
}
