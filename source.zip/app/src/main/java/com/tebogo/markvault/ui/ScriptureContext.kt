package com.tebogo.markvault.ui

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

/**
 * One row in the Scripture Context Panel: the Bible reference itself,
 * plus the snippet of text that preceded it in the article so the user
 * remembers *why* that scripture was cited.
 */
data class ScriptureContextItem(
    /** Cleaned context — the 80–100 chars that came right before the reference. */
    val context: String,
    /** Normalised reference, e.g. "Matthew 24:14" or "1 Corinthians 15:33". */
    val reference: String,
    /** The original raw string as it appeared (used for hyperlinking back). */
    val raw: String
)

/**
 * The Bible-book names this extractor recognises. Covers the protestant canon plus
 * the alternate spellings most likely to appear in a typical study note. To keep
 * the regex compact we list them once and join them as alternation below.
 */
private val BIBLE_BOOKS = listOf(
    // Old Testament
    "Genesis", "Exodus", "Leviticus", "Numbers", "Deuteronomy",
    "Joshua", "Judges", "Ruth",
    "1 Samuel", "2 Samuel", "1 Kings", "2 Kings",
    "1 Chronicles", "2 Chronicles",
    "Ezra", "Nehemiah", "Esther", "Job", "Psalms?", "Proverbs",
    "Ecclesiastes", "Song of Solomon", "Song of Songs",
    "Isaiah", "Jeremiah", "Lamentations", "Ezekiel", "Daniel",
    "Hosea", "Joel", "Amos", "Obadiah", "Jonah", "Micah",
    "Nahum", "Habakkuk", "Zephaniah", "Haggai", "Zechariah", "Malachi",
    // New Testament
    "Matthew", "Mark", "Luke", "John",
    "Acts", "Romans",
    "1 Corinthians", "2 Corinthians",
    "Galatians", "Ephesians", "Philippians", "Colossians",
    "1 Thessalonians", "2 Thessalonians",
    "1 Timothy", "2 Timothy",
    "Titus", "Philemon", "Hebrews", "James",
    "1 Peter", "2 Peter",
    "1 John", "2 John", "3 John",
    "Jude", "Revelation"
)

/**
 * Regex to match Bible references like:
 *   Matthew 24:14
 *   1 Corinthians 15:33-58
 *   Psalm 23
 *   Romans 8:28, 31
 *
 * Groups: (1) book (2) chapter (3) optional verse(s)
 */
private val BIBLE_REGEX: Regex by lazy {
    val books = BIBLE_BOOKS.joinToString("|") {
        // Escape the digit-prefix-space combo for "1 Samuel" etc.
        Regex.escape(it).replace("\\?", "?")
    }
    Regex(
        // Word boundary, then book, then a space + chapter (digits),
        // optionally :verse(s) with ranges and comma-separated chains.
        """\b($books)\s+(\d{1,3})(?::(\d{1,3}(?:[-\u2013\u2014,\s]\d{1,3})*))?""",
        RegexOption.IGNORE_CASE
    )
}

/**
 * Pull every Bible reference out of [markdown] together with up to ~100 chars
 * of cleaned preceding text as a "context clue" so the user remembers what was
 * being said when each scripture was cited.
 *
 * The cleaner strips common markdown syntax characters from the context so the
 * preview reads naturally — no leading `**`, `#`, leftover URL parts, etc.
 */
fun extractScriptureContexts(markdown: String): List<ScriptureContextItem> {
    if (markdown.isBlank()) return emptyList()
    val out = mutableListOf<ScriptureContextItem>()
    val seen = mutableSetOf<Pair<Int, String>>()   // de-dupe by (position, ref)

    BIBLE_REGEX.findAll(markdown).forEach { match ->
        val ref = match.value.trim()
        val book = match.groupValues[1]
        val chapter = match.groupValues[2]
        val verse = match.groupValues.getOrNull(3).orEmpty()
        val normalisedRef = if (verse.isBlank()) "$book $chapter" else "$book $chapter:$verse"

        // De-duplicate matches that come from overlapping regex passes
        val key = match.range.first to normalisedRef
        if (!seen.add(key)) return@forEach

        // Grab the ~240 chars immediately before this match — that's roughly
        // three lines on a typical phone screen. The user previously saw the
        // context as a single short clipped line; widening it to three lines
        // gives them enough surrounding sentence to recall why the scripture
        // was cited.
        val start = (match.range.first - 240).coerceAtLeast(0)
        var ctx = markdown.substring(start, match.range.first)
        ctx = cleanMarkdownForContext(ctx)

        // Prefer a context that starts at a sentence boundary if possible
        val sentenceStart = ctx.lastIndexOfAny(charArrayOf('.', '!', '?', '\n'))
        if (sentenceStart in 0 until ctx.length - 6) {
            ctx = ctx.substring(sentenceStart + 1)
        }
        ctx = ctx.trim()
        if (ctx.length > 240) ctx = "\u2026" + ctx.takeLast(240).trimStart()
        if (ctx.isBlank()) ctx = "(no preceding text)"

        out += ScriptureContextItem(context = ctx, reference = normalisedRef, raw = ref)
    }
    return out
}

/**
 * Strip the most common markdown / HTML syntax noise from a snippet so it
 * reads as plain prose in the context preview.
 */
private fun cleanMarkdownForContext(s: String): String {
    var out = s
    // Code spans
    out = out.replace(Regex("`[^`]*`"), "")
    // Wikilinks → keep just the label
    out = out.replace(Regex("""\[\[([^\]|]+)(?:\|([^\]]+))?\]\]""")) {
        it.groupValues[2].ifBlank { it.groupValues[1] }
    }
    // Markdown links → keep just the label
    out = out.replace(Regex("""\[([^\]]+)\]\([^)]+\)""")) { it.groupValues[1] }
    // HTML anchor tags → keep just inner text (do this BEFORE generic tag strip
    // so we keep the label text rather than empty out the anchor entirely).
    out = out.replace(Regex("""(?is)<a[^>]*>(.*?)</a>""")) { it.groupValues[1] }
    // Smart-styling leftover artefacts — strip BEFORE other passes so they
    // don't pollute the cleaned preview text. (v4.2 fix.)
    out = out.replace(
        Regex("""["\u201C\u201D\u2018\u2019']?sm-(?:ref|num|pct|acronym|quotechar|key|date|cap)["\u201C\u201D\u2018\u2019']?>+"""),
        ""
    )
    // Heading hashes, bold/italic markers
    out = out.replace(Regex("""(?m)^#{1,6}\s+"""), "")
    out = out.replace(Regex("""\*{1,3}|_{1,3}|~~"""), "")
    // Blockquote arrows, list bullets, table pipes
    out = out.replace(Regex("""(?m)^>\s?"""), "")
    out = out.replace(Regex("""(?m)^[-*+]\s+"""), "")
    out = out.replace(Regex("""\|"""), " ")
    // Stray HTML tags
    out = out.replace(Regex("""<[^>]+>"""), "")
    // Collapse whitespace
    out = out.replace(Regex("""\s+"""), " ")
    return out
}

/**
 * Translate a normalised reference like "Matthew 24:14" into the jw.org Bible
 * finder URL Tebogo prefers. Format: BBCCCVVV where BB=book number (1-66),
 * CCC=chapter zero-padded to 3, VVV=verse zero-padded to 3.
 */
fun buildJwScriptureUrl(reference: String): String {
    val m = Regex("""([1-3]?\s*[A-Za-z]+(?:\s+of\s+[A-Za-z]+)?)\s+(\d{1,3})(?::(\d{1,3}))?""")
        .find(reference) ?: return "https://www.jw.org/en/search/?q=" +
        java.net.URLEncoder.encode(reference, "UTF-8")
    val book = m.groupValues[1].trim()
    val chapter = m.groupValues[2].toIntOrNull() ?: 1
    val verse = m.groupValues.getOrNull(3)?.toIntOrNull() ?: 1
    val bookNum = bookNumber(book) ?: return "https://www.jw.org/en/search/?q=" +
        java.net.URLEncoder.encode(reference, "UTF-8")
    val code = "%02d%03d%03d".format(bookNum, chapter, verse)
    return "https://www.jw.org/finder?srcid=jwlshare&wtlocale=E&prefer=lang&bible=$code&pub=nwtsty"
}

/**
 * TASK 1 (revised): derive a wol.jw.org search query for a long-pressed link.
 *
 * Priority order (changed v4.0 → v4.1 based on user feedback):
 *   1. The visible link text — this is what the user sees and expects to be
 *      searched. "It's supposed to search the text, not the link."
 *   2. If the link text is missing or just a single-character footnote marker
 *      ("a", "b", "c"), reverse a `?bible=BBCCCVVV` URL param back into a
 *      readable "Book Chapter:Verse" string.
 *   3. If even that fails, use whatever link text is present (even 1 char).
 *      Never search the raw URL — that's what was producing the gibberish
 *      results page the user reported.
 */
fun extractScriptureQueryForWol(url: String, linkText: String): String {
    val cleaned = linkText.trim()

    // 1. Prefer the visible text. The user sees "1 Peter 3:12" on the page;
    //    that's exactly what they want searched on wol.jw.org. A length > 1
    //    filter excludes "a" / "b" / "c" footnote-marker links where the
    //    visible text isn't useful as a search query.
    if (cleaned.length > 1) return cleaned

    // 2. No useful text — try to reverse a finder URL's bible= param.
    val parsedUri = runCatching { android.net.Uri.parse(url) }.getOrNull()
    val bibleParam = parsedUri?.getQueryParameter("bible")
        ?: Regex("[?&]bible=(\\d+)").find(url)?.groupValues?.get(1)
    if (!bibleParam.isNullOrBlank() && bibleParam.all { it.isDigit() }) {
        val padded = bibleParam.padStart(8, '0').take(8)
        val book = padded.substring(0, 2).toIntOrNull() ?: 0
        val chap = padded.substring(2, 5).toIntOrNull() ?: 0
        val verse = padded.substring(5, 8).toIntOrNull() ?: 0
        val bookName = BOOK_NUMBERS.entries.firstOrNull { it.value == book }?.key
        if (bookName != null) {
            // Capitalise multi-word names properly ("1 corinthians" → "1 Corinthians")
            val pretty = bookName.split(' ').joinToString(" ") { part ->
                if (part.all { it.isDigit() }) part
                else part.replaceFirstChar { it.uppercase() }
            }
            return when {
                chap == 0 -> pretty
                verse == 0 -> "$pretty $chap"
                else -> "$pretty $chap:$verse"
            }
        }
    }

    // 3. Even a 1-char footnote marker is better than a URL — wol.jw.org will
    //    just return zero results rather than a confused "URL as text" page.
    if (cleaned.isNotEmpty()) return cleaned

    // 4. Genuine last resort — nothing usable. Return an empty string and let
    //    the wol search page show its own "no results" UI instead of trying
    //    to search for the raw jw.org URL (which produces the gibberish page
    //    the user saw before this fix).
    return ""
}

/** Map a book name to its 1-66 canonical number in the NWT order. */
private fun bookNumber(book: String): Int? {
    val key = book.trim().lowercase()
        .replace(Regex("\\s+"), " ")
        .replace("psalms", "psalm")
        .replace("song of songs", "song of solomon")
    return BOOK_NUMBERS[key]
}

private val BOOK_NUMBERS: Map<String, Int> = mapOf(
    "genesis" to 1, "exodus" to 2, "leviticus" to 3, "numbers" to 4, "deuteronomy" to 5,
    "joshua" to 6, "judges" to 7, "ruth" to 8,
    "1 samuel" to 9, "2 samuel" to 10, "1 kings" to 11, "2 kings" to 12,
    "1 chronicles" to 13, "2 chronicles" to 14,
    "ezra" to 15, "nehemiah" to 16, "esther" to 17, "job" to 18, "psalm" to 19, "proverbs" to 20,
    "ecclesiastes" to 21, "song of solomon" to 22,
    "isaiah" to 23, "jeremiah" to 24, "lamentations" to 25, "ezekiel" to 26, "daniel" to 27,
    "hosea" to 28, "joel" to 29, "amos" to 30, "obadiah" to 31, "jonah" to 32, "micah" to 33,
    "nahum" to 34, "habakkuk" to 35, "zephaniah" to 36, "haggai" to 37, "zechariah" to 38, "malachi" to 39,
    "matthew" to 40, "mark" to 41, "luke" to 42, "john" to 43,
    "acts" to 44, "romans" to 45, "1 corinthians" to 46, "2 corinthians" to 47,
    "galatians" to 48, "ephesians" to 49, "philippians" to 50, "colossians" to 51,
    "1 thessalonians" to 52, "2 thessalonians" to 53,
    "1 timothy" to 54, "2 timothy" to 55,
    "titus" to 56, "philemon" to 57, "hebrews" to 58, "james" to 59,
    "1 peter" to 60, "2 peter" to 61,
    "1 john" to 62, "2 john" to 63, "3 john" to 64,
    "jude" to 65, "revelation" to 66
)

/**
 * Build a ~1500-char cleaned preview of [content] for the Peek bottom sheet.
 * Strips frontmatter + the common markdown syntax characters so the preview
 * reads as flowing prose rather than raw markdown.
 */
fun buildPeekPreview(content: String): String {
    if (content.isBlank()) return ""
    // Drop the YAML frontmatter block at the top (--- ... ---) so the preview
    // doesn't open with config noise.
    var body = content.trimStart()
    if (body.startsWith("---")) {
        val end = body.indexOf("\n---", startIndex = 3)
        if (end > 0) body = body.substring(end + 4).trimStart()
    }
    // Reuse the same cleaner the Scripture context panel uses
    val cleaned = cleanMarkdownForContextPublic(body)
    return if (cleaned.length <= 1500) cleaned else cleaned.substring(0, 1500)
}

/** Public passthrough so other files can use the same cleaner. */
fun cleanMarkdownForContextPublic(s: String): String = cleanMarkdownForContext(s)

/**
 * Modal dialog that shows the Scripture Context Panel for the active note.
 * Tap any row to open that scripture in the WebPopup (via the supplied callback).
 */
@Composable
fun ScriptureContextDialog(
    items: List<ScriptureContextItem>,
    onDismiss: () -> Unit,
    onScriptureTap: (reference: String) -> Unit
) {
    AlertDialog(
        onDismissRequest = onDismiss,
        title = {
            Text(
                "\uD83D\uDCD6 Scripture Context",
                fontWeight = FontWeight.Bold
            )
        },
        text = {
            if (items.isEmpty()) {
                Box(
                    Modifier.fillMaxWidth().heightIn(min = 120.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        "No Bible references found in this note.",
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        fontSize = 13.sp
                    )
                }
            } else {
                Column(Modifier.heightIn(max = 480.dp)) {
                    Text(
                        "${items.size} reference${if (items.size == 1) "" else "s"} \u00B7 tap to open",
                        fontSize = 11.sp,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        modifier = Modifier.padding(bottom = 8.dp)
                    )
                    LazyColumn {
                        items(items, key = { "${it.reference}-${it.context.hashCode()}" }) { item ->
                            Surface(
                                color = MaterialTheme.colorScheme.surfaceVariant,
                                shape = RoundedCornerShape(10.dp),
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(vertical = 4.dp)
                                    .clickable { onScriptureTap(item.reference) }
                            ) {
                                Column(Modifier.padding(12.dp)) {
                                    // Context clue — italic + dimmed, reads like a quote.
                                    // 5 maxLines lets the 3-line preview breathe.
                                    Text(
                                        "\u201C${item.context}\u201D",
                                        fontSize = 13.sp,
                                        fontStyle = FontStyle.Italic,
                                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                                        maxLines = 5,
                                        overflow = TextOverflow.Ellipsis,
                                        lineHeight = 18.sp
                                    )
                                    Spacer(Modifier.height(4.dp))
                                    // The reference itself — bold, accent-coloured
                                    Text(
                                        "\uD83D\uDCD6 ${item.reference}",
                                        fontSize = 14.sp,
                                        fontWeight = FontWeight.SemiBold,
                                        color = MaterialTheme.colorScheme.primary
                                    )
                                }
                            }
                        }
                    }
                }
            }
        },
        confirmButton = {
            TextButton(onClick = onDismiss) { Text("Close") }
        }
    )
}
