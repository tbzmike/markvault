package com.tebogo.markvault.ai

data class T5InferenceResult(
    val inputQuery: String,
    val generatedQueries: List<String>,
    val inferenceTimeMs: Long,
    val fallbackReason: String? = null
)
