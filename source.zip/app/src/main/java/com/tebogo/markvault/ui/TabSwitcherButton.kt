package com.tebogo.markvault.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.navigation.NavController
import com.tebogo.markvault.AppViewModel

/**
 * Drop-in tab-switcher: a button that opens a bottom sheet listing every open
 * tab (markdown, PDF, html, mhtml) with the right icon for each file type.
 * Tapping a row navigates to that file's reader route — works from any screen
 * in the app, not just the reader screens. This satisfies the user's
 * requirement that "the tabs switcher button must be in all screens".
 *
 * Hidden when there are no tabs open (avoids cluttering screens before the user
 * has actually opened anything).
 */
@androidx.compose.material3.ExperimentalMaterial3Api
@Composable
fun TabSwitcherButton(vm: AppViewModel, nav: NavController) {
    val tabs by vm.tabs.collectAsState()
    if (tabs.isEmpty()) return
    var sheetOpen by remember { mutableStateOf(false) }

    IconButton(onClick = { sheetOpen = true }) {
        // Stacked-rectangles glyph — same as ☰ in markdown reader's existing
        // tab grid button so the UI stays consistent across screens.
        Text("\u2630", fontSize = 18.sp)
    }

    if (sheetOpen) {
        ModalBottomSheet(onDismissRequest = { sheetOpen = false }) {
            Column(Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 8.dp)) {
                Row(
                    modifier = Modifier.fillMaxWidth().padding(bottom = 8.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        "\uD83D\uDCDA  Open tabs",
                        fontSize = 17.sp,
                        fontWeight = FontWeight.SemiBold
                    )
                    Spacer(Modifier.weight(1f))
                    Text(
                        "${tabs.size}",
                        fontSize = 13.sp,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
                HorizontalDivider()
                LazyColumn(modifier = Modifier.fillMaxWidth()) {
                    items(tabs, key = { it.id }) { tab ->
                        val icon = when (tab.fileType) {
                            "pdf" -> "\uD83D\uDCD5"   // 📕
                            "html", "mhtml" -> "\uD83C\uDF10"  // 🌐
                            else -> "\uD83D\uDCDD"    // 📝
                        }
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clickable {
                                    sheetOpen = false
                                    // Route to the right viewer based on file type.
                                    when (tab.fileType) {
                                        "pdf" -> nav.navigate("pdfReader/${tab.id}")
                                        "html", "mhtml" -> nav.navigate("htmlReader/${tab.id}")
                                        else -> {
                                            vm.openArticle(tab.id, tab.title, fileType = tab.fileType)
                                            nav.navigate("reader") { launchSingleTop = true }
                                        }
                                    }
                                }
                                .padding(vertical = 10.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(icon, fontSize = 18.sp)
                            Spacer(Modifier.width(12.dp))
                            Text(
                                tab.title,
                                fontSize = 14.sp,
                                fontWeight = FontWeight.Medium,
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis,
                                modifier = Modifier.weight(1f)
                            )
                        }
                        HorizontalDivider()
                    }
                }
                Spacer(Modifier.height(16.dp))
            }
        }
    }
}
