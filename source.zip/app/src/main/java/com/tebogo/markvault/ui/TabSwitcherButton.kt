/*
 * v5.4.0 — Article tabs button + Chrome-style preview dialog.
 *
 * The "burger" / three-line button in the bottom toolbar that opens a
 * preview of every currently-open article tab. Cards are laid out
 * exactly like Chrome's mobile tab switcher: a coloured header with a
 * large file-type emoji, the article title, the folder path, and a
 * close (✕) button per card. Tapping a card switches the active tab
 * and navigates to the right reader for that file type.
 *
 * Visible on EVERY screen that uses MarkVaultBottomBar, regardless of
 * whether the user has any tabs open yet. When there are zero tabs the
 * dialog shows an empty state with a "+ Browse library" call to action.
 *
 * Layout respects the user's `tabsPreviewOrientation` preference —
 * shared with the floating browser-tabs button — so vertical/horizontal
 * choice in Settings applies to BOTH tab pickers.
 */
package com.tebogo.markvault.ui

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.produceState
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.navigation.NavController
import com.tebogo.markvault.AppViewModel
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

@Composable
fun TabSwitcherButton(vm: AppViewModel, nav: NavController) {
    val tabs by vm.tabs.collectAsStateWithLifecycle()
    var open by remember { mutableStateOf(false) }

    // The burger button itself — visible always (no longer hidden when
    // the user has zero open tabs). Shows a tiny count badge when at
    // least one tab is open so the user knows how many sessions are
    // alive without having to open the dialog.
    Box {
        IconButton(onClick = { open = true }) {
            Text("\u2630", fontSize = 18.sp)
        }
        if (tabs.isNotEmpty()) {
            Surface(
                color = MaterialTheme.colorScheme.primary,
                shape = RoundedCornerShape(percent = 50),
                modifier = Modifier
                    .size(16.dp)
                    .padding(0.dp)
            ) {
                Box(contentAlignment = Alignment.Center, modifier = Modifier.fillMaxSize()) {
                    Text(
                        "${tabs.size}",
                        fontSize = 9.sp,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.onPrimary
                    )
                }
            }
        }
    }

    if (open) {
        ArticleTabsPreviewDialog(
            vm = vm,
            nav = nav,
            onDismiss = { open = false }
        )
    }
}

/**
 * Full-screen dialog showing article tabs as a grid of Chrome-style
 * preview cards. Layout respects [AppViewModel.tabsPreviewOrientation].
 */
@Composable
fun ArticleTabsPreviewDialog(
    vm: AppViewModel,
    nav: NavController,
    onDismiss: () -> Unit
) {
    val tabs by vm.tabs.collectAsStateWithLifecycle()
    val activeId by vm.activeTab.collectAsStateWithLifecycle()
    val orientation by vm.tabsPreviewOrientation.collectAsStateWithLifecycle()

    androidx.compose.ui.window.Dialog(
        onDismissRequest = onDismiss,
        properties = androidx.compose.ui.window.DialogProperties(
            usePlatformDefaultWidth = false
        )
    ) {
        Surface(
            color = MaterialTheme.colorScheme.surface,
            modifier = Modifier
                .fillMaxSize()
                .padding(8.dp),
            shape = RoundedCornerShape(16.dp)
        ) {
            Column(Modifier.fillMaxSize()) {
                // Header: "📚 N open tabs" + close
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 16.dp, vertical = 10.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        "\uD83D\uDCDA  ${tabs.size} open ${if (tabs.size == 1) "tab" else "tabs"}",
                        fontSize = 17.sp,
                        fontWeight = FontWeight.Bold,
                        modifier = Modifier.weight(1f)
                    )
                    IconButton(onClick = onDismiss) {
                        Text("\u2715", fontSize = 18.sp)
                    }
                }
                HorizontalDivider()
                Box(
                    modifier = Modifier
                        .weight(1f)
                        .fillMaxWidth()
                ) {
                    if (tabs.isEmpty()) {
                        // Empty state — no articles open yet. Friendly
                        // CTA so the user has somewhere to go without
                        // backing out of the dialog first.
                        Column(
                            modifier = Modifier
                                .fillMaxSize()
                                .padding(28.dp),
                            verticalArrangement = Arrangement.Center,
                            horizontalAlignment = Alignment.CenterHorizontally
                        ) {
                            Text("\uD83D\uDCDA", fontSize = 64.sp)
                            Spacer(Modifier.height(14.dp))
                            Text(
                                "No articles open",
                                fontSize = 17.sp,
                                fontWeight = FontWeight.SemiBold
                            )
                            Spacer(Modifier.height(6.dp))
                            Text(
                                "Open an article from your library to see it appear here.",
                                fontSize = 13.sp,
                                color = MaterialTheme.colorScheme.onSurfaceVariant,
                                textAlign = androidx.compose.ui.text.style.TextAlign.Center
                            )
                            Spacer(Modifier.height(20.dp))
                            androidx.compose.material3.Button(onClick = {
                                onDismiss()
                                nav.navigate("browse") { launchSingleTop = true }
                            }) {
                                Text("\uD83D\uDCC1  Browse library")
                            }
                        }
                    } else if (orientation == "horizontal") {
                        ArticleTabsHorizontal(vm, nav, tabs, activeId, onDismiss)
                    } else {
                        ArticleTabsVertical(vm, nav, tabs, activeId, onDismiss)
                    }
                }
                HorizontalDivider()
                Row(
                    modifier = Modifier.fillMaxWidth().padding(8.dp),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    TextButton(
                        onClick = {
                            onDismiss()
                            nav.navigate("browse") { launchSingleTop = true }
                        },
                        modifier = Modifier.weight(1f)
                    ) { Text("\u2795  Open article") }
                    if (tabs.isNotEmpty()) {
                        TextButton(
                            onClick = {
                                vm.closeAllTabs()
                                onDismiss()
                            },
                            modifier = Modifier.weight(1f)
                        ) { Text("\u2716  Close all") }
                    }
                }
            }
        }
    }
}

@Composable
private fun ArticleTabsVertical(
    vm: AppViewModel,
    nav: NavController,
    tabs: List<com.tebogo.markvault.TabInfo>,
    activeId: Long?,
    onDismiss: () -> Unit
) {
    val pairs = remember(tabs.size) {
        val out = mutableListOf<Pair<Int, Int?>>()
        var i = 0
        while (i < tabs.size) {
            out.add(i to if (i + 1 < tabs.size) i + 1 else null)
            i += 2
        }
        out
    }
    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(10.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        items(pairs) { (a, b) ->
            Row(
                Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                ArticleTabCard(
                    vm = vm, nav = nav,
                    tab = tabs[a],
                    isActive = tabs[a].id == activeId,
                    onDismiss = onDismiss,
                    modifier = Modifier.weight(1f)
                )
                if (b != null) {
                    ArticleTabCard(
                        vm = vm, nav = nav,
                        tab = tabs[b],
                        isActive = tabs[b].id == activeId,
                        onDismiss = onDismiss,
                        modifier = Modifier.weight(1f)
                    )
                } else {
                    Spacer(Modifier.weight(1f))
                }
            }
        }
    }
}

@Composable
private fun ArticleTabsHorizontal(
    vm: AppViewModel,
    nav: NavController,
    tabs: List<com.tebogo.markvault.TabInfo>,
    activeId: Long?,
    onDismiss: () -> Unit
) {
    LazyRow(
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(10.dp),
        horizontalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        itemsIndexed(tabs, key = { _, t -> t.id }) { _, tab ->
            ArticleTabCard(
                vm = vm, nav = nav,
                tab = tab,
                isActive = tab.id == activeId,
                onDismiss = onDismiss,
                modifier = Modifier
                    .width(260.dp)
                    .fillMaxHeight()
            )
        }
    }
}

@Composable
private fun ArticleTabCard(
    vm: AppViewModel,
    nav: NavController,
    tab: com.tebogo.markvault.TabInfo,
    isActive: Boolean,
    onDismiss: () -> Unit,
    modifier: Modifier = Modifier
) {
    val emoji = when (tab.fileType) {
        "pdf" -> "\uD83D\uDCD5"
        "html", "mhtml" -> "\uD83C\uDF10"
        else -> "\uD83D\uDCDD"
    }
    // Deterministic header colour from the tab id so each card has a
    // stable visual fingerprint between sessions.
    val hue = remember(tab.id) { ((tab.id.toInt() and 0x7fffffff) % 360).toFloat() }
    val headerColor = Color.hsv(hue, 0.45f, 0.55f)

    // Lazily fetch the first paragraph of the article as a preview
    // snippet. Cached per tab id so this only runs once even if the
    // dialog is opened repeatedly during a session.
    val preview by produceState<String?>(initialValue = null, tab.id) {
        value = withContext(Dispatchers.IO) {
            runCatching {
                val note = vm.openSync(tab.id) ?: return@runCatching null
                note.content
                    .lineSequence()
                    .map { it.trim() }
                    .firstOrNull { it.isNotEmpty() && !it.startsWith("#") && !it.startsWith("---") }
                    ?.take(160)
            }.getOrNull()
        }
    }

    Surface(
        color = MaterialTheme.colorScheme.surfaceVariant,
        shape = RoundedCornerShape(12.dp),
        tonalElevation = if (isActive) 6.dp else 2.dp,
        shadowElevation = if (isActive) 8.dp else 3.dp,
        border = if (isActive)
            BorderStroke(2.dp, MaterialTheme.colorScheme.primary)
        else null,
        modifier = modifier
    ) {
        Column(Modifier.fillMaxWidth()) {
            // Header: coloured block with file-type emoji.
            Box(
                Modifier
                    .fillMaxWidth()
                    .height(110.dp)
                    .background(headerColor)
                    .clickable {
                        onDismiss()
                        // Save scroll for current tab before switching, then
                        // route to the right reader.
                        vm.setActiveTab(tab.id)
                        when (tab.fileType.lowercase()) {
                            "pdf" -> nav.navigate("pdfReader/${tab.id}") { launchSingleTop = true }
                            "html", "htm", "mhtml", "mht" -> nav.navigate("htmlReader/${tab.id}") { launchSingleTop = true }
                            "canvas" -> nav.navigate("canvas/${tab.id}") { launchSingleTop = true }
                            else -> {
                                vm.openArticle(tab.id, tab.title, fileType = tab.fileType)
                                nav.navigate("reader") { launchSingleTop = true }
                            }
                        }
                    },
                contentAlignment = Alignment.Center
            ) {
                Text(emoji, fontSize = 42.sp)
            }
            // Footer: title + first-paragraph snippet + close.
            Row(
                Modifier
                    .fillMaxWidth()
                    .padding(start = 10.dp, end = 4.dp, top = 6.dp, bottom = 6.dp),
                verticalAlignment = Alignment.Top
            ) {
                Column(Modifier.weight(1f)) {
                    Text(
                        tab.title,
                        fontSize = 13.sp,
                        fontWeight = FontWeight.SemiBold,
                        maxLines = 2,
                        overflow = TextOverflow.Ellipsis,
                        lineHeight = 16.sp,
                        color = MaterialTheme.colorScheme.onSurface
                    )
                    val previewText = preview
                    if (!previewText.isNullOrBlank()) {
                        Spacer(Modifier.height(2.dp))
                        Text(
                            previewText,
                            fontSize = 10.sp,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                            maxLines = 3,
                            overflow = TextOverflow.Ellipsis,
                            lineHeight = 12.sp
                        )
                    }
                }
                IconButton(
                    onClick = { vm.closeTab(tab.id) },
                    modifier = Modifier.size(32.dp)
                ) {
                    Text("\u2715", fontSize = 14.sp)
                }
            }
        }
    }
}
