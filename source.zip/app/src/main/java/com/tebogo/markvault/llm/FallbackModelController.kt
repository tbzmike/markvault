package com.tebogo.markvault.llm

object FallbackModelController {

    fun shouldFallback(error: Throwable): Boolean {
        return error is OutOfMemoryError ||
            error.message?.contains("memory", ignoreCase = true) == true
    }

    fun fallbackModel(): ChatModelDescriptor {
        return ChatModelCatalog.SMOLLM2_135M_INSTRUCT
    }
}