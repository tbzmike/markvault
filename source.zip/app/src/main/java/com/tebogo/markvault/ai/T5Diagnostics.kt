package com.tebogo.markvault.ai

data class T5Diagnostics(
    val method: String = "Built-in",
    val generatedQueries: List<String> = emptyList(),
    val inferenceTimeMs: Long = 0,
    val fallbackReason: String? = null
)
