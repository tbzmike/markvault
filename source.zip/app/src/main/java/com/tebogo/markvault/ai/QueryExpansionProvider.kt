package com.tebogo.markvault.ai

/**
 * Common contract for retrieval query expansion engines.
 * Implementations can be rule based or model based.
 */
interface QueryExpansionProvider {
    suspend fun expandQuery(query: String): List<String>
    fun modelName(): String
}
