package com.tebogo.markvault.ai

/** Runtime state passed into retrieval execution. */
data class T5RetrievalExecutionState(
    val mode: T5ExpansionMode,
    val expandedQueries: List<String> = emptyList()
)
