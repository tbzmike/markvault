package com.tebogo.markvault.ai

/** Data stored for query treatment history. */
data class T5HistoryDiagnosticEntry(
    val method: String,
    val generatedQueries: List<String>,
    val inferenceTimeMs: Long,
    val fallbackReason: String? = null
)
