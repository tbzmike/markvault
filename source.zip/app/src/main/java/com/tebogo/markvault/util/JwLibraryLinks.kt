package com.tebogo.markvault.util

import android.content.Context
import android.content.Intent
import android.net.Uri
import android.widget.Toast

/**
 * v5.4.37 — Shared JW Library link-routing utilities.
 *
 * Moved out of ReaderScreen so HtmlReaderScreen, WebSearchScreen, and
 * any future reader surface can reuse the same routing logic.
 *
 * ## Link routing philosophy
 *
 * The JW Library app registers intent-filters for `jw.org/finder` URLs.
 * MarkVault should never intercept those — they belong in JW Library.
 * WOL bible URLs (`wol.jw.org/.../nwt/BB/CCC`) can be converted to
 * finder format so they also open in JW Library instead of a browser.
 *
 * Everything else on jw.org/wol.jw.org stays in the in-app WebView.
 * Non-JW links go to the system browser.
 */

enum class LinkTarget {
    /** Hand off to JW Library app via ACTION_VIEW intent. */
    JW_LIBRARY_APP,
    /** Show inside MarkVault's in-app WebView popup / browser. */
    IN_APP_WEBVIEW,
    /** Open in the system's default browser. */
    SYSTEM_BROWSER
}

/** Hosts we recognise as JW ecosystem. */
private val JW_DOMAIN_SUFFIXES = listOf(
    "jw.org", "wol.jw.org", "tv.jw.org", "jw-cdn.org", "akamaihd.net"
)

fun isJwHost(uri: Uri): Boolean {
    val host = uri.host?.lowercase() ?: return false
    return JW_DOMAIN_SUFFIXES.any { host == it || host.endsWith(".$it") }
}

/**
 * Decide where a tapped link should be opened.
 *
 * JW Library deep links:
 *   - `jw.org/finder` with a `bible=` or `pub=` parameter (any srcid)
 *   - `jw.org/finder` with `srcid=jwlshare` (backward compat)
 *   - WOL bible chapter URLs: `wol.jw.org/.../nwt/BB/CCC` (will be
 *     converted to finder format by [toJwLibraryUri])
 *
 * Everything else on jw.org/wol.jw.org → in-app WebView.
 * Non-JW links → system browser.
 */
fun routeLink(uri: Uri): LinkTarget {
    val host = uri.host?.lowercase() ?: return LinkTarget.SYSTEM_BROWSER
    if (!isJwHost(uri)) return LinkTarget.SYSTEM_BROWSER

    val path = uri.path?.lowercase() ?: ""

    // ── jw.org/finder links ──
    // JW Library handles ANY /finder URL that has bible= or pub= params.
    // Don't require srcid=jwlshare — that was overly strict.
    if ((host == "jw.org" || host == "www.jw.org") && path == "/finder") {
        val hasBible = uri.getQueryParameter("bible") != null
        val hasPub = uri.getQueryParameter("pub") != null
        val hasSrcId = uri.getQueryParameter("srcid")
            ?.lowercase() == "jwlshare"
        if (hasBible || hasPub || hasSrcId) {
            return LinkTarget.JW_LIBRARY_APP
        }
    }

    // ── WOL bible chapter URLs ──
    // Pattern: wol.jw.org/{locale}/wol/b/{reader}/{lang}/{translation}/{book}/{chapter}
    // Example: wol.jw.org/en/wol/b/r1/lp-e/nwt/46/1
    //          wol.jw.org/zib/wol/b/r403/lp-zsl/nwt/46/
    if (host == "wol.jw.org" || host.endsWith(".wol.jw.org")) {
        if (path.contains("/wol/b/") && path.contains("/nwt/")) {
            return LinkTarget.JW_LIBRARY_APP
        }
    }

    // Other JW hosts → in-app WebView
    return LinkTarget.IN_APP_WEBVIEW
}

/**
 * Convert any recognised JW link into a JW Library deep-link URI.
 *
 * - Already a `/finder` URL → return as-is (maybe add srcid).
 * - WOL bible chapter URL → parse book + chapter into finder format.
 * - Anything else → return as-is (JW Library will try its best).
 */
fun toJwLibraryUri(uri: Uri): Uri {
    val host = uri.host?.lowercase() ?: return uri
    val path = uri.path ?: return uri

    // Already a finder URL — ensure srcid=jwlshare is present
    if ((host == "jw.org" || host == "www.jw.org") &&
        path.lowercase() == "/finder") {
        if (uri.getQueryParameter("srcid") == null) {
            return uri.buildUpon()
                .appendQueryParameter("srcid", "jwlshare")
                .build()
        }
        return uri
    }

    // WOL bible URL → finder URL
    // Path pattern: /{locale}/wol/b/{reader}/{lang}/nwt/{book}/{chapter}
    // The book number is the NWT book code (1-66), chapter is 1-based.
    if ((host == "wol.jw.org" || host.endsWith(".wol.jw.org")) &&
        path.contains("/wol/b/") && path.contains("/nwt/")) {
        val nwtIdx = path.indexOf("/nwt/")
        if (nwtIdx >= 0) {
            val after = path.substring(nwtIdx + 5).trimEnd('/')
            val parts = after.split("/")
            if (parts.isNotEmpty()) {
                val bookNum = parts[0].toIntOrNull()
                val chapter = if (parts.size > 1) parts[1].toIntOrNull() else 1
                if (bookNum != null && bookNum in 1..66) {
                    val ch = chapter ?: 1
                    // Bible code: BB CCC VVV (zero-padded)
                    // For chapter-level links, verse=001
                    val bible = String.format("%02d%03d%03d", bookNum, ch, 1)
                    // Detect locale from the WOL URL's reader/lang path
                    val locale = extractWolLocale(path) ?: "E"
                    return Uri.parse(
                        "https://www.jw.org/finder?" +
                        "srcid=jwlshare&wtlocale=$locale&" +
                        "prefer=lang&bible=$bible&pub=nwtsty"
                    )
                }
            }
        }
    }

    return uri
}

/**
 * Extract the WOL locale code from a path like
 * `/en/wol/b/r1/lp-e/nwt/46/1` → "E" (from "lp-e").
 *
 * The `lp-XX` segment is the language parameter. We map the most
 * common ones to JW Library locale codes; unknown ones fall back to "E".
 */
private fun extractWolLocale(path: String): String? {
    // Find the lp-XXX segment
    val regex = Regex("/lp-([a-zA-Z]+)/")
    val match = regex.find(path) ?: return null
    val lpCode = match.groupValues[1].lowercase()
    // Map common WOL lp codes to JW Library wtlocale codes
    return WOL_TO_LOCALE[lpCode] ?: lpCode.uppercase()
}

private val WOL_TO_LOCALE = mapOf(
    "e" to "E",       // English
    "af" to "AF",      // Afrikaans
    "zsl" to "NS",     // Sepedi / Northern Sotho
    "x" to "X",        // Xhosa
    "zu" to "ZU",      // Zulu
    "ts" to "TS",      // Tsonga
    "tn" to "TN",      // Tswana
    "st" to "ST",      // Sesotho
    "ss" to "SS",      // Swati
    "nr" to "NR",      // Ndebele (South)
    "ve" to "VE",      // Venda
    "f" to "F",        // French
    "s" to "S",        // Spanish
    "p" to "P",        // Portuguese
    "t" to "T",        // Italian
    "d" to "D",        // German
    "chs" to "CHS",    // Chinese Simplified
    "j" to "J",        // Japanese
    "ko" to "KO",      // Korean
    "r" to "R",        // Russian
)

/**
 * Hand the URL off to JW Library directly. Converts the URI to the
 * best deep-link format first (via [toJwLibraryUri]), then tries the
 * known JW Library package names. Falls back to a generic ACTION_VIEW
 * intent (Android may show a chooser), or calls [onFallback] if no
 * handler is installed at all.
 */
fun openInJwLibrary(ctx: Context, uri: Uri, onFallback: () -> Unit) {
    val deepLink = toJwLibraryUri(uri)
    val packages = listOf(
        "org.jw.jwlibrary.mobile",   // JW Library (Play Store)
        "org.jw.jwlpub.mobile"       // JW Library alternate
    )
    for (pkg in packages) {
        try {
            val intent = Intent(Intent.ACTION_VIEW, deepLink)
                .setPackage(pkg)
                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            ctx.startActivity(intent)
            return
        } catch (_: Exception) { /* try next */ }
    }
    // Generic ACTION_VIEW — Android shows a chooser if multiple apps match
    try {
        val anyHandler = Intent(Intent.ACTION_VIEW, deepLink)
            .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        val resolved = ctx.packageManager.resolveActivity(anyHandler, 0) != null
        if (resolved) {
            ctx.startActivity(anyHandler)
        } else {
            onFallback()
        }
    } catch (_: Exception) {
        onFallback()
    }
}

/** Open a link in the system's default browser. */
fun openExternally(ctx: Context, uri: Uri) {
    try {
        ctx.startActivity(
            Intent(Intent.ACTION_VIEW, uri)
                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        )
    } catch (_: Exception) {
        Toast.makeText(ctx, "No app can open this link", Toast.LENGTH_SHORT).show()
    }
}

/**
 * Build a JW Library deep-link URI for a scripture reference.
 *
 * @param bookNum NWT book number (1–66)
 * @param chapter 1-based chapter
 * @param verse   1-based verse (default 1)
 * @param locale  JW Library locale code (default "E")
 */
fun jwLibraryScriptureUri(
    bookNum: Int,
    chapter: Int,
    verse: Int = 1,
    locale: String = "E"
): Uri {
    val bible = String.format("%02d%03d%03d", bookNum, chapter, verse)
    return Uri.parse(
        "https://www.jw.org/finder?" +
        "srcid=jwlshare&wtlocale=$locale&" +
        "prefer=lang&bible=$bible&pub=nwtsty"
    )
}
