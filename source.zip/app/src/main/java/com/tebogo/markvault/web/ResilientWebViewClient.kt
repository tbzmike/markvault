package com.tebogo.markvault.web

import android.webkit.RenderProcessGoneDetail
import android.webkit.WebView
import android.webkit.WebViewClient

/**
 * v5.4.79 — Web renderer crash recovery.
 */
class ResilientWebViewClient : AdvancedWebViewClient() {

    override fun onRenderProcessGone(
        view: WebView,
        detail: RenderProcessGoneDetail
    ): Boolean {
        view.destroy()
        return true
    }
}
