package com.tebogo.markvault.ai

object MultiQueryPreference {
    private var count = 0

    fun setCount(value: Int) {
        count = value.coerceIn(0, 10)
    }

    fun getCount(): Int = count
}
