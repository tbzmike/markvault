package com.tebogo.markvault.data

import androidx.room.*

/**
 * v5.4.255cc — Named, persisted collection of media items (video/audio).
 * Distinct from the ephemeral "now playing queue" (AppViewModel's
 * _currentQueue) — a playlist is something the user curates and comes
 * back to; the queue is whatever's loaded into the player right now
 * (which CAN be "play this playlist," but doesn't have to be).
 *
 * mediaIds is a comma-separated list of media_items.id values, in
 * playlist order — same "structured text in one column" style already
 * used for MediaItem.qualityOptions, avoiding a join table for what's
 * expected to stay a small, personal collection.
 */
@Entity(tableName = "playlists")
data class Playlist(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val name: String = "",
    val createdAt: Long = System.currentTimeMillis(),
    val mediaIds: String = ""
) {
    /** Parsed, in order, empty-string-safe. */
    fun idList(): List<Long> =
        if (mediaIds.isBlank()) emptyList()
        else mediaIds.split(",").mapNotNull { it.trim().toLongOrNull() }

    companion object {
        fun joinIds(ids: List<Long>): String = ids.joinToString(",")
    }
}

@Dao
interface PlaylistDao {

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsert(playlist: Playlist): Long

    @Query("SELECT * FROM playlists ORDER BY name")
    suspend fun getAll(): List<Playlist>

    @Query("SELECT * FROM playlists WHERE id = :id")
    suspend fun getById(id: Long): Playlist?

    @Query("DELETE FROM playlists WHERE id = :id")
    suspend fun delete(id: Long)
}
