package com.tebogo.markvault.ai

object T5DownloadController {
    fun start(): Boolean {
        T5ModelInstallStateStore.set(T5ModelInstallState.DOWNLOADING)
        return true
    }
}
