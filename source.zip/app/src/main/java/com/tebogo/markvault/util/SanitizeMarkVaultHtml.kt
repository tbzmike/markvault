package com.tebogo.markvault.util

/**
 * Strips smart-styling leakage artefacts from any text before we persist it.
 *
 * Background: an earlier release of MarkVault wrote rendered HTML back into
 * the markdown source on certain copy/paste / save paths. That left literal
 * strings like:
 *
 *      ("sm-ref">"sm-ref">"sm-ref">Surah 7:54)
 *      "sm-num">"sm-num">256
 *      <span class="sm-ref">Matthew 24:14
 *
 * embedded in note content. Once persisted, each subsequent render compounded
 * the pollution further. This extension fixes both the historical pollution
 * (cleanup) and prevents future re-introduction (sanitize before save / index).
 *
 * Idempotent — safe to apply repeatedly on clean text (no-op when there is
 * nothing to remove).
 *
 * Apply this:
 *   1. On every import (URL import, share intent, convert-to-markdown).
 *   2. On every read of a note's content from disk, before handing to the renderer.
 *   3. Before writing FTS index entries so corrupted text never reaches the
 *      search index.
 *   4. As a one-shot pass when re-indexing the library.
 */
fun String.sanitizeMarkVaultHtml(): String {
    if (isBlank()) return this
    var s = this

    // 1. Bare attribute-value fragments leaked from interrupted span tags.
    //    Matches: `"sm-ref">`, `"sm-num">`, `sm-pct">`, etc, with curly or
    //    straight quotes (or no leading quote at all). The trailing `>+` accepts
    //    accidental run-on chains.
    s = s.replace(
        Regex("""["\u201C\u201D\u2018\u2019']?sm-(?:ref|num|pct|acronym|quotechar|key|date|cap)["\u201C\u201D\u2018\u2019']?>+"""),
        ""
    )

    // 2. Complete leaked spans: `<span class="sm-X">content</span>`  →  content
    s = s.replace(
        Regex(
            """<span\s+class\s*=\s*["']sm-[a-z]+["']\s*>([\s\S]*?)</span>""",
            RegexOption.IGNORE_CASE
        )
    ) { it.groupValues[1] }

    // 3. Orphan opening tags left over from a render that crashed mid-pass.
    s = s.replace(
        Regex(
            """<span\s+class\s*=\s*["']sm-[a-z]+["']\s*>""",
            RegexOption.IGNORE_CASE
        ),
        ""
    )

    return s
}
