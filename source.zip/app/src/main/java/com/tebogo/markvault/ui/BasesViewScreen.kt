package com.tebogo.markvault.ui

import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material3.Card
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.navigation.NavController
import com.tebogo.markvault.AppViewModel
import com.tebogo.markvault.data.NoteMeta
import java.text.DateFormat
import java.util.Date

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun BasesViewScreen(vm: AppViewModel, nav: NavController) {
    val notes by vm.notes.collectAsStateWithLifecycle()
    val persistedView by vm.workspaceBasesView.collectAsStateWithLifecycle()
    var query by remember { mutableStateOf("") }
    var typeFilter by remember { mutableStateOf("all") }
    var sort by remember { mutableStateOf("title") }

    val filtered = remember(notes, query, typeFilter, sort) {
        val q = query.trim()
        val base = notes.asSequence().filter { n ->
            val typeOk = typeFilter == "all" || n.fileType.equals(typeFilter, true)
            val textOk = q.isBlank() || n.title.contains(q, true) ||
                n.folder.contains(q, true) || n.relPath.contains(q, true)
            typeOk && textOk
        }
        when (sort) {
            "newest" -> base.sortedByDescending { it.lastModified }.take(2000).toList()
            "folder" -> base.sortedWith(compareBy<NoteMeta> { it.folder.lowercase() }.thenBy { it.title.lowercase() }).take(2000).toList()
            else -> base.sortedBy { it.title.lowercase() }.take(2000).toList()
        }
    }

    fun open(n: NoteMeta) {
        vm.openArticle(n.id, n.title, fileType = n.fileType)
        val route = when (n.fileType.lowercase()) {
            "pdf" -> "pdfReader/${n.id}"
            "html", "htm", "mhtml", "mht" -> "htmlReader/${n.id}"
            "canvas" -> "canvas/${n.id}"
            else -> "reader"
        }
        nav.navigate(route) { launchSingleTop = true }
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Data views") },
                navigationIcon = {
                    IconButton(onClick = { nav.popBackStack() }) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back")
                    }
                }
            )
        }
    ) { pad ->
        Column(Modifier.fillMaxSize().padding(pad)) {
            OutlinedTextField(
                value = query,
                onValueChange = { query = it },
                modifier = Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 6.dp),
                singleLine = true,
                label = { Text("Filter indexed metadata") },
                placeholder = { Text("Title, folder or path") }
            )
            Row(
                Modifier.fillMaxWidth().horizontalScroll(rememberScrollState())
                    .padding(horizontal = 10.dp, vertical = 4.dp),
                horizontalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                listOf("all" to "All", "md" to "Markdown", "html" to "HTML", "pdf" to "PDF", "canvas" to "Canvas").forEach { (key, label) ->
                    FilterChip(selected = typeFilter == key, onClick = { typeFilter = key }, label = { Text(label) })
                }
                FilterChip(selected = sort == "title", onClick = { sort = "title" }, label = { Text("A→Z") })
                FilterChip(selected = sort == "newest", onClick = { sort = "newest" }, label = { Text("Newest") })
                FilterChip(selected = sort == "folder", onClick = { sort = "folder" }, label = { Text("Folder") })
                FilterChip(selected = persistedView == "table", onClick = { vm.setWorkspaceBasesView("table") }, label = { Text("Table") })
                FilterChip(selected = persistedView == "cards", onClick = { vm.setWorkspaceBasesView("cards") }, label = { Text("Cards") })
            }
            Text(
                "${filtered.size} shown · view is read-only",
                style = MaterialTheme.typography.labelSmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                modifier = Modifier.padding(horizontal = 14.dp, vertical = 4.dp)
            )
            LazyColumn(Modifier.fillMaxSize()) {
                items(filtered, key = { it.id }) { n ->
                    if (persistedView == "cards") {
                        Card(
                            Modifier.fillMaxWidth().padding(horizontal = 10.dp, vertical = 4.dp)
                                .clickable { open(n) }
                        ) {
                            Column(Modifier.padding(12.dp)) {
                                Text(n.title, fontWeight = FontWeight.SemiBold, maxLines = 2, overflow = TextOverflow.Ellipsis)
                                Text(n.folder.ifBlank { "Vault root" }, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                Text("${n.fileType.uppercase()} · ${formatIndexedSize(n.size)} · ${DateFormat.getDateInstance(DateFormat.SHORT).format(Date(n.lastModified))}", style = MaterialTheme.typography.labelSmall)
                            }
                        }
                    } else {
                        Row(
                            Modifier.fillMaxWidth().clickable { open(n) }
                                .padding(horizontal = 12.dp, vertical = 9.dp)
                        ) {
                            Text(n.title, Modifier.weight(1.6f), maxLines = 1, overflow = TextOverflow.Ellipsis)
                            Text(n.folder.substringAfterLast('/').ifBlank { "—" }, Modifier.weight(0.8f), maxLines = 1, overflow = TextOverflow.Ellipsis, color = MaterialTheme.colorScheme.onSurfaceVariant)
                            Text(n.fileType.uppercase(), Modifier.weight(0.45f), style = MaterialTheme.typography.labelSmall)
                        }
                    }
                }
                item { Spacer(Modifier.height(24.dp)) }
            }
        }
    }
}

private fun formatIndexedSize(bytes: Long): String = when {
    bytes < 1024L -> "$bytes B"
    bytes < 1024L * 1024L -> "${bytes / 1024L} KB"
    else -> String.format("%.1f MB", bytes.toDouble() / (1024.0 * 1024.0))
}
