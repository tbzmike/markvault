package com.tebogo.markvault.ai

enum class T5ExpansionMode { BUILTIN, T5_BASE }
