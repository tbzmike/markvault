package com.tebogo.markvault.ai

object T5InstallerStatusMapper {
    fun label(state: T5DownloadState): String = when(state) {
        T5DownloadState.NOT_INSTALLED -> "Not installed"
        T5DownloadState.DOWNLOADING -> "Downloading"
        T5DownloadState.VERIFYING -> "Verifying"
        T5DownloadState.LOADING -> "Loading"
        T5DownloadState.READY -> "Ready"
        T5DownloadState.FAILED -> "Failed"
    }
}
