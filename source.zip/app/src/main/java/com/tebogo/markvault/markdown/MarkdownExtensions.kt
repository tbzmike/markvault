package com.tebogo.markvault.markdown

/**
 * v5.4.60 — Optional modular rendering extensions for MarkdownEngine.
 *
 * Each extension object exposes an `enabled` flag. Set it to `false` to
 * bypass the extension entirely — the render pipeline and all existing
 * behaviour remain 100 % intact.
 *
 * These are **pre/post-processors** that sit around the core flexmark
 * pipeline. They never touch flexmark's internal parse or render chain.
 *
 * Extensions
 * ──────────
 * 1. [YamlFrontMatterProcessor] — strips `---…---` YAML front matter
 *    before flexmark sees the source (front matter upsets the parser).
 *
 * 2. [MermaidProcessor] — converts ` ```mermaid ` fenced blocks to
 *    `<div class="mermaid">` placeholders before flexmark parses.
 *    render.js picks them up and renders them via Mermaid.js if available,
 *    or falls back to a styled code block.
 *
 * 3. [TagsExtractor] — collects Obsidian-style `#hashtags` from the raw
 *    markdown without modifying the source. Tags are NOT stripped from the
 *    rendered output so they appear naturally as plain text.
 *
 * 4. [ScriptureDetector] — identifies Bible scripture references in
 *    rendered HTML and records them as [ScriptureRef] objects with
 *    ready-made JW-Library finder URLs. The actual click-linking is
 *    handled in render.js (autoLinkScriptures).
 *
 * Combined result: [renderWithExtensions] returns an [ExtendedRenderResult]
 * that bundles the HTML with all extracted metadata.
 */

// ── 1. YAML Front Matter ─────────────────────────────────────────────────

/**
 * Strips and parses an Obsidian / Jekyll-style YAML front matter block:
 *
 * ```
 * ---
 * title: My Note
 * tags: theology, jw
 * date: 2026-07-13
 * ---
 * … rest of note …
 * ```
 *
 * Supports simple `key: value` pairs. Nested YAML objects and YAML lists
 * are NOT parsed — values that look like YAML lists are left as strings.
 * Single- and double-quoted values have their outer quotes stripped.
 */
object YamlFrontMatterProcessor {

    /** Set to false to skip this extension entirely. */
    var enabled: Boolean = true

    /**
     * Holds the parse result: extracted fields + the markdown content
     * with the front matter block removed.
     */
    data class FrontMatter(
        val fields: Map<String, String>,
        /** Source markdown with the `---…---` block stripped. */
        val strippedContent: String
    )

    // The front matter block must be at the very start of the file.
    // Allow both \n and \r\n line endings.
    private val FRONT_MATTER_RE = Regex(
        """^---[ \t]*\r?\n([\s\S]*?)\r?\n---[ \t]*(?:\r?\n|$)""",
        RegexOption.MULTILINE
    )

    /**
     * Process [markdown]: strip the front matter block and parse its fields.
     *
     * If [enabled] is false, or no front matter is present, returns
     * `FrontMatter(emptyMap(), markdown)` — the original source unchanged.
     */
    fun process(markdown: String): FrontMatter {
        if (!enabled) return FrontMatter(emptyMap(), markdown)
        val match = FRONT_MATTER_RE.find(markdown)
            ?: return FrontMatter(emptyMap(), markdown)
        val yamlBlock = match.groupValues[1]
        val fields = parseSimpleYaml(yamlBlock)
        // Strip the matched block from the start; keep everything after it.
        val stripped = markdown.substring(match.range.last + 1)
        return FrontMatter(fields, stripped)
    }

    /** Parse simple `key: value` lines from a YAML block. */
    private fun parseSimpleYaml(yaml: String): Map<String, String> {
        val result = LinkedHashMap<String, String>()
        for (line in yaml.lineSequence()) {
            val colonIdx = line.indexOf(':')
            if (colonIdx < 1) continue
            val key = line.substring(0, colonIdx).trim()
            val rawVal = line.substring(colonIdx + 1).trim()
            // Strip outer quotes (single or double)
            val value = rawVal
                .removeSurrounding("\"")
                .removeSurrounding("'")
            if (key.isNotEmpty()) result[key] = value
        }
        return result
    }
}

// ── 2. Mermaid Diagram Pre-processor ────────────────────────────────────

/**
 * Converts ` ```mermaid ` fenced code blocks into `<div class="mermaid">`
 * placeholder elements **before** flexmark parses the source.
 *
 * Why pre-process? flexmark would render ` ```mermaid ` as a plain
 * `<pre><code class="language-mermaid">…</code></pre>` block. That format
 * is valid code highlighting but loses the semantic "diagram" intent.
 * By converting to `<div class="mermaid">` first, render.js can hand the
 * content to Mermaid.js for proper SVG rendering.
 *
 * render.js behaviour when it finds a `.mermaid[data-raw]` element:
 *   - If `window.mermaid` is defined → calls `mermaid.init()` on the div.
 *   - Otherwise → replaces the div with a styled `<pre>` fallback so the
 *     diagram source is still readable.
 *
 * Offline rendering: bundle `mermaid.min.js` in the app's assets and add
 * a `<script src="mermaid.min.js">` to viewer.html to enable fully offline
 * diagram support.
 */
object MermaidProcessor {

    /** Set to false to skip this extension; ` ```mermaid ` blocks will be
     *  rendered as plain code by flexmark. */
    var enabled: Boolean = true

    // Match ```mermaid ... ``` (case-insensitive, across multiple lines).
    // The DOTALL option makes `.` match newlines too.
    private val MERMAID_FENCE_RE = Regex(
        """```mermaid[ \t]*\r?\n([\s\S]*?)```""",
        setOf(RegexOption.IGNORE_CASE)
    )

    /**
     * Replace every ` ```mermaid … ``` ` block in [markdown] with a
     * `<div class="mermaid" data-raw="1">…</div>` element whose text
     * content is the diagram source with `<`, `>`, `&` HTML-escaped
     * (render.js decodes them before passing to Mermaid.js).
     *
     * The `data-raw="1"` attribute lets render.js distinguish divs that
     * still need Mermaid initialisation from ones already processed.
     *
     * Fast path: returns [markdown] unchanged when [enabled] is false or
     * when the source contains no ` ```mermaid ` (avoids regex overhead).
     */
    fun preprocess(markdown: String): String {
        if (!enabled) return markdown
        if (!markdown.contains("```mermaid", ignoreCase = true)) return markdown
        return markdown.replace(MERMAID_FENCE_RE) { m ->
            val src = m.groupValues[1]
                .trim()
                .replace("&", "&amp;")
                .replace("<", "&lt;")
                .replace(">", "&gt;")
            "<div class=\"mermaid\" data-raw=\"1\">$src</div>"
        }
    }
}

// ── 3. Tags Extractor ────────────────────────────────────────────────────

/**
 * Extracts Obsidian-style `#hashtags` from raw markdown.
 *
 * Rules (matching Obsidian behaviour):
 *   - Must start with `#` followed immediately by a letter.
 *   - Body may contain letters, digits, `_`, `-`, `/` (nested tags).
 *   - Must NOT be preceded by `&` (HTML entity guard) or another word char.
 *   - Must NOT be followed by a word char or another `#`.
 *   - Headings (`# Heading`) are excluded: they have a space after `#`.
 *
 * Tags are returned lowercase, deduplicated, and sorted.
 */
object TagsExtractor {

    /** Set to false to return an empty list without scanning. */
    var enabled: Boolean = true

    // Negative lookbehind: not preceded by & or word char.
    // #[letter][letter/digit/_/-/]* not followed by word char or #.
    private val TAG_RE = Regex(
        """(?<![&\w])#([A-Za-z][A-Za-z0-9_/\-]*)(?![\w#])"""
    )

    /**
     * Return all unique `#tags` found in [markdown], lowercase, sorted.
     * Returns an empty list when [enabled] is false.
     */
    fun extract(markdown: String): List<String> {
        if (!enabled) return emptyList()
        return TAG_RE.findAll(markdown)
            .map { it.groupValues[1].lowercase() }
            .distinct()
            .sorted()
            .toList()
    }
}

// ── 4. Scripture Detector ────────────────────────────────────────────────

/**
 * Identifies Bible scripture references in rendered HTML and records them
 * as [ScriptureRef] objects with ready-made JW-Library deep-link URLs.
 *
 * The Kotlin-side detector is used for **metadata extraction** (e.g. to
 * populate a "scriptures in this note" panel). The actual **HTML linking**
 * (converting plain-text references to `<a>` elements) is handled in
 * render.js via `autoLinkScriptures()` — keeping the JS and Kotlin sides
 * symmetric but independent.
 *
 * Recognised patterns
 * ───────────────────
 *   John 3:16          (single verse)
 *   John 3:16-18       (verse range)
 *   1 Cor 13:4-7       (numbered book + verse range)
 *   Genesis 1:1        (full book name)
 *   Rev 21:4           (abbreviation)
 *
 * A scripture is only recorded if its book name (or abbreviation) appears
 * in the internal [BOOK_MAP]. Unknown book-like strings are ignored.
 */
object ScriptureDetector {

    /** Set to false to return an empty list without scanning. */
    var enabled: Boolean = true

    // Matches: optional leading number (1/2/3), a capitalised book name
    // (optionally two words), chapter:verse (optionally -endVerse).
    private val SCRIPTURE_RE = Regex(
        """(?<!\w)(?:(1|2|3)\s+)?([A-Z][a-zA-Z]+(?:\s+[A-Z][a-zA-Z]+)?)\s+(\d{1,3}):(\d{1,3})(?:[-\u2013](\d{1,3}))?(?!\w)"""
    )

    /**
     * Extract all scripture references from [html] (the rendered output
     * of [MarkdownEngine.render]).
     *
     * Returns an empty list when [enabled] is false.
     */
    fun extractReferences(html: String): List<ScriptureRef> {
        if (!enabled) return emptyList()
        val found = mutableListOf<ScriptureRef>()
        SCRIPTURE_RE.findAll(html).forEach { m ->
            val prefix  = m.groupValues[1].trim()          // "1", "2", "3" or ""
            val book    = m.groupValues[2].trim()
            val chapter = m.groupValues[3].toIntOrNull() ?: return@forEach
            val verse   = m.groupValues[4].toIntOrNull() ?: return@forEach
            val endVerse = m.groupValues[5].toIntOrNull()

            val bookNum = resolveBook(prefix, book) ?: return@forEach
            found.add(ScriptureRef(m.value, bookNum, chapter, verse, endVerse))
        }
        return found
    }

    /** Resolve a (possibly numbered) book name / abbreviation to its NWT book number. */
    private fun resolveBook(prefix: String, book: String): Int? {
        val n = prefix.toIntOrNull() ?: 0
        val key = book.lowercase()
        val base = BOOK_MAP[key] ?: return null
        // Adjust the base number for numbered-book variants
        return when (key) {
            "samuel", "sam"                    -> if (n > 0) 8 + n  else base   // 1=9, 2=10
            "kings", "king"                    -> if (n > 0) 10 + n else base   // 1=11, 2=12
            "chronicles", "chron", "chr"       -> if (n > 0) 12 + n else base   // 1=13, 2=14
            "corinthians", "cor"               -> if (n > 0) 45 + n else base   // 1=46, 2=47
            "thessalonians", "thess", "thes"   -> if (n > 0) 51 + n else base   // 1=52, 2=53
            "timothy", "tim"                   -> if (n > 0) 53 + n else base   // 1=54, 2=55
            "peter", "pet"                     -> if (n > 0) 59 + n else base   // 1=60, 2=61
            "john", "joh", "jn"               -> if (n > 1) 61 + n else base   // 2=63, 3=64
            else -> if (n > 0) base + n - 1 else base  // safe default
        }
    }

    // ── Book name / abbreviation → base NWT book number ──
    //
    // For numbered books (1/2 Samuel, 1/2 Kings, etc.) this map holds
    // the FIRST book's number; resolveBook() adjusts it by the prefix.
    private val BOOK_MAP: Map<String, Int> = mapOf(
        "genesis" to 1,  "gen" to 1,
        "exodus" to 2,   "ex" to 2,    "exod" to 2,
        "leviticus" to 3, "lev" to 3,
        "numbers" to 4,  "num" to 4,
        "deuteronomy" to 5, "deut" to 5, "dt" to 5,
        "joshua" to 6,   "josh" to 6,  "jos" to 6,
        "judges" to 7,   "judg" to 7,  "jdg" to 7,
        "ruth" to 8,
        "samuel" to 9,   "sam" to 9,   // 1 Sam=9, 2 Sam=10
        "kings" to 11,   "king" to 11, // 1 Kgs=11, 2 Kgs=12
        "chronicles" to 13, "chron" to 13, "chr" to 13, // 1=13, 2=14
        "ezra" to 15,
        "nehemiah" to 16, "neh" to 16,
        "esther" to 17,  "esth" to 17,
        "job" to 18,
        "psalms" to 19,  "psalm" to 19, "ps" to 19,
        "proverbs" to 20, "prov" to 20, "pr" to 20,
        "ecclesiastes" to 21, "eccl" to 21, "ecc" to 21,
        "song" to 22,   "songs" to 22,
        "isaiah" to 23,  "isa" to 23,
        "jeremiah" to 24, "jer" to 24,
        "lamentations" to 25, "lam" to 25,
        "ezekiel" to 26, "ezek" to 26, "eze" to 26,
        "daniel" to 27,  "dan" to 27,
        "hosea" to 28,   "hos" to 28,
        "joel" to 29,
        "amos" to 30,
        "obadiah" to 31, "obad" to 31,
        "jonah" to 32,
        "micah" to 33,   "mic" to 33,
        "nahum" to 34,   "nah" to 34,
        "habakkuk" to 35, "hab" to 35,
        "zephaniah" to 36, "zeph" to 36,
        "haggai" to 37,  "hag" to 37,
        "zechariah" to 38, "zech" to 38,
        "malachi" to 39, "mal" to 39,
        "matthew" to 40, "matt" to 40, "mat" to 40, "mt" to 40,
        "mark" to 41,    "mk" to 41,
        "luke" to 42,    "luk" to 42,  "lk" to 42,
        "john" to 43,    "joh" to 43,  "jn" to 43, // 2 John=63, 3 John=64
        "acts" to 44,
        "romans" to 45,  "rom" to 45,
        "corinthians" to 46, "cor" to 46, // 1=46, 2=47
        "galatians" to 48, "gal" to 48,
        "ephesians" to 49, "eph" to 49,
        "philippians" to 50, "phil" to 50,
        "colossians" to 51, "col" to 51,
        "thessalonians" to 52, "thess" to 52, "thes" to 52, // 1=52, 2=53
        "timothy" to 54, "tim" to 54, // 1=54, 2=55
        "titus" to 56,   "tit" to 56,
        "philemon" to 57, "philem" to 57,
        "hebrews" to 58, "heb" to 58,
        "james" to 59,   "jas" to 59,
        "peter" to 60,   "pet" to 60, // 1=60, 2=61
        "jude" to 65,
        "revelation" to 66, "rev" to 66, "re" to 66
    )
}

// ── Scripture reference value type ───────────────────────────────────────

/**
 * A single resolved scripture reference found in a rendered note.
 *
 * @property raw       Original matched text, e.g. `"1 Cor 13:4-7"`.
 * @property bookNumber NWT book number (1–66).
 * @property chapter  1-based chapter number.
 * @property verse    1-based starting verse number.
 * @property endVerse Optional end verse for a range (e.g. 7 in `4-7`).
 * @property jwLibraryUrl  Ready-made JW Library deep-link URL.
 */
data class ScriptureRef(
    val raw: String,
    val bookNumber: Int,
    val chapter: Int,
    val verse: Int,
    val endVerse: Int? = null
) {
    /**
     * JW Library / jw.org finder deep-link for this reference.
     *
     * Format: `https://www.jw.org/finder?srcid=jwlshare&wtlocale=E&prefer=lang&bible=BBCCCVVV&pub=nwtsty`
     * The ReaderScreen / JwLibraryLinks.routeLink() routes these to JW Library.
     */
    val jwLibraryUrl: String get() {
        val bk = bookNumber.toString().padStart(2, '0')
        val ch = chapter.toString().padStart(3, '0')
        val vs = verse.toString().padStart(3, '0')
        return "https://www.jw.org/finder?srcid=jwlshare&wtlocale=E&prefer=lang" +
               "&bible=$bk$ch$vs&pub=nwtsty"
    }
}

// ── Combined result ───────────────────────────────────────────────────────

/**
 * Result from [MarkdownEngine.renderWithExtensions].
 *
 * @property html        Fully rendered HTML, ready for WebView injection.
 * @property frontMatter Parsed YAML front matter fields (empty if absent or disabled).
 * @property tags        Unique `#hashtags` found in the source (empty if disabled).
 * @property scriptures  Detected scripture references with JW-finder URLs
 *                       (empty if disabled).
 */
data class ExtendedRenderResult(
    val html: String,
    val frontMatter: Map<String, String>,
    val tags: List<String>,
    val scriptures: List<ScriptureRef>
)
