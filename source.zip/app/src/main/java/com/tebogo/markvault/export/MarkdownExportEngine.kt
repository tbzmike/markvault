package com.tebogo.markvault.export

/**
 * Export foundation for future HTML/EPUB/PDF exporters.
 */
object MarkdownExportEngine {
    fun toHtml(markdownHtml: String): String = markdownHtml

    fun prepareDocument(title: String, body: String): String {
        return "<html><head><title>$title</title></head><body>$body</body></html>"
    }
}
