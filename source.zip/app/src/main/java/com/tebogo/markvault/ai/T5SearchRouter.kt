package com.tebogo.markvault.ai

object T5SearchRouter {
    fun route(mode: T5ExpansionMode, t5Available: Boolean): T5ExpansionMode {
        return if (mode == T5ExpansionMode.T5_BASE && t5Available) mode else T5ExpansionMode.BUILTIN
    }
}
