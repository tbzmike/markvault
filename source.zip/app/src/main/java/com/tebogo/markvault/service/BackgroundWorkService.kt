package com.tebogo.markvault.service

import android.app.ActivityManager
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.os.Build
import android.os.IBinder
import android.os.PowerManager
import androidx.core.app.NotificationCompat
import com.tebogo.markvault.MainActivity
import com.tebogo.markvault.MarkVaultApp
import com.tebogo.markvault.R
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.delay
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch

/**
 * Keeps user-started in-process work alive while MarkVault is backgrounded or
 * the display is off. Heavy operations that already own a dedicated foreground
 * service (embedding pass, chat-model download, batch save, media playback) are
 * deliberately left on their existing services.
 *
 * This service protects:
 *  - submitted library searches (including semantic scan + rerank)
 *  - library indexing/re-indexing
 *  - embedding-model, T5, and reranker downloads that still run in AppViewModel
 *
 * A partial wake lock prevents CPU sleep while protected work is active. The
 * foreground notification keeps process priority appropriate for an explicit
 * user operation. Search completion posts a separate notification only when
 * MarkVault is not visibly in the foreground or the screen is off.
 */
class BackgroundWorkService : Service() {
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Default)
    private val taskTokens = LinkedHashSet<String>()
    private var searchMonitor: Job? = null
    private var searchActive = false
    private var searchQuery = ""
    private var wakeLock: PowerManager.WakeLock? = null

    override fun onCreate() {
        super.onCreate()
        createChannels()
        val pm = getSystemService(Context.POWER_SERVICE) as PowerManager
        wakeLock = pm.newWakeLock(
            PowerManager.PARTIAL_WAKE_LOCK,
            "MarkVault:BackgroundWork"
        ).apply { setReferenceCounted(false) }
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_START_SEARCH -> {
                searchQuery = intent.getStringExtra(EXTRA_QUERY).orEmpty()
                searchActive = true
                ensureForeground("Searching your vault…", null)
                ensureWakeLock()
                startSearchMonitor()
            }
            ACTION_CANCEL_SEARCH -> {
                ensureForeground("Finishing background work…", null)
                searchActive = false
                searchMonitor?.cancel()
                searchMonitor = null
                maybeStop()
            }
            ACTION_START_TASK -> {
                val token = intent.getStringExtra(EXTRA_TOKEN).orEmpty()
                if (token.isNotBlank()) taskTokens += token
                val label = intent.getStringExtra(EXTRA_LABEL).orEmpty()
                    .ifBlank { "Working in background…" }
                ensureForeground(label, null)
                ensureWakeLock()
            }
            ACTION_STOP_TASK -> {
                ensureForeground("Finishing background work…", null)
                val token = intent.getStringExtra(EXTRA_TOKEN).orEmpty()
                if (token.isNotBlank()) taskTokens -= token
                maybeStop()
            }
        }
        return START_NOT_STICKY
    }

    private fun startSearchMonitor() {
        searchMonitor?.cancel()
        searchMonitor = scope.launch {
            var sawBusy = false
            var idleTicksBeforeStart = 0
            while (isActive && searchActive) {
                val vm = (application as? MarkVaultApp)?.sharedVm
                if (vm == null) {
                    delay(500L)
                    continue
                }

                val busy = vm.searchBusy.value
                if (busy) sawBusy = true

                val progress = vm.searchWorkProgress.value
                val done = vm.searchWorkDone.value
                val total = vm.searchWorkTotal.value
                val stage = vm.searchWorkStage.value
                val percent = progress?.let { (it * 100f).toInt().coerceIn(0, 100) }
                val detail = when {
                    total > 0 -> "$stage  $done / $total"
                    else -> stage
                }
                updateForeground(detail, percent)

                if (sawBusy && !busy) {
                    // The StateFlow that exposes final results updates immediately
                    // after the mapper returns; give it one main-loop beat after
                    // searchBusy is cleared in the mapper's finally block.
                    delay(250L)
                    val count = vm.results.value.size
                    if (count > 0 && shouldNotifyCompletion()) {
                        postSearchComplete(searchQuery, count)
                    }
                    searchActive = false
                    maybeStop()
                    break
                }

                // Defensive guard for a start request that never becomes a real
                // search (blank/invalid query or immediate cancellation).
                if (!sawBusy && !busy) {
                    idleTicksBeforeStart++
                    if (idleTicksBeforeStart > 12) {
                        searchActive = false
                        maybeStop()
                        break
                    }
                }
                // v5.4.365cc — Notification/progress polling at 4 Hz caused
                // needless CPU wakeups and NotificationManager churn during long
                // searches. One update per second is still responsive while much
                // cheaper thermally.
                delay(1_000L)
            }
        }
    }

    private fun ensureForeground(text: String, percent: Int?) {
        startForeground(NOTIFICATION_ID_WORK, buildProgressNotification(text, percent))
    }

    private fun updateForeground(text: String, percent: Int?) {
        val nm = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        nm.notify(NOTIFICATION_ID_WORK, buildProgressNotification(text, percent))
    }

    private fun buildProgressNotification(text: String, percent: Int?): Notification {
        val tapPi = PendingIntent.getActivity(
            this,
            0,
            Intent(this, MainActivity::class.java).apply {
                flags = Intent.FLAG_ACTIVITY_SINGLE_TOP or Intent.FLAG_ACTIVITY_CLEAR_TOP
            },
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        return NotificationCompat.Builder(this, CHANNEL_WORK)
            .setSmallIcon(R.mipmap.ic_launcher)
            .setContentTitle("MarkVault is working")
            .setContentText(text)
            .setContentIntent(tapPi)
            .setOngoing(true)
            .setOnlyAlertOnce(true)
            .setPriority(NotificationCompat.PRIORITY_LOW)
            .setCategory(NotificationCompat.CATEGORY_PROGRESS)
            .apply {
                if (percent != null) setProgress(100, percent, false)
                else setProgress(0, 0, true)
            }
            .build()
    }

    private fun postSearchComplete(query: String, count: Int) {
        val nm = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        val tapPi = PendingIntent.getActivity(
            this,
            1,
            Intent(this, MainActivity::class.java).apply {
                flags = Intent.FLAG_ACTIVITY_SINGLE_TOP or Intent.FLAG_ACTIVITY_CLEAR_TOP
            },
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        val notification = NotificationCompat.Builder(this, CHANNEL_SEARCH_READY)
            .setSmallIcon(R.mipmap.ic_launcher)
            .setContentTitle("🔍 Search results ready")
            .setContentText("$count result${if (count == 1) "" else "s"} for “$query”")
            .setContentIntent(tapPi)
            .setAutoCancel(true)
            .setPriority(NotificationCompat.PRIORITY_DEFAULT)
            .build()
        nm.notify(NOTIFICATION_ID_SEARCH_READY, notification)
    }

    private fun shouldNotifyCompletion(): Boolean {
        val pm = getSystemService(Context.POWER_SERVICE) as PowerManager
        if (!pm.isInteractive) return true

        val am = getSystemService(Context.ACTIVITY_SERVICE) as ActivityManager
        val processes = am.runningAppProcesses ?: return true
        val mine = processes.firstOrNull { it.pid == android.os.Process.myPid() } ?: return true
        return mine.importance > ActivityManager.RunningAppProcessInfo.IMPORTANCE_FOREGROUND
    }

    private fun ensureWakeLock() {
        val lock = wakeLock ?: return
        if (!lock.isHeld) lock.acquire(12 * 60 * 60 * 1000L)
    }

    private fun maybeStop() {
        if (searchActive || taskTokens.isNotEmpty()) return
        if (wakeLock?.isHeld == true) runCatching { wakeLock?.release() }
        stopForeground(STOP_FOREGROUND_REMOVE)
        stopSelf()
    }

    private fun createChannels() {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.O) return
        val nm = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        nm.createNotificationChannel(
            NotificationChannel(
                CHANNEL_WORK,
                "Background work",
                NotificationManager.IMPORTANCE_LOW
            ).apply {
                description = "Progress for searches, indexing, and model downloads"
            }
        )
        nm.createNotificationChannel(
            NotificationChannel(
                CHANNEL_SEARCH_READY,
                "Search results ready",
                NotificationManager.IMPORTANCE_DEFAULT
            ).apply {
                description = "Notifies when a background search finishes"
                setShowBadge(true)
            }
        )
    }

    override fun onDestroy() {
        searchMonitor?.cancel()
        scope.cancel()
        if (wakeLock?.isHeld == true) runCatching { wakeLock?.release() }
        wakeLock = null
        super.onDestroy()
    }

    override fun onBind(intent: Intent?): IBinder? = null

    companion object {
        const val ACTION_START_SEARCH = "com.tebogo.markvault.action.START_SEARCH"
        const val ACTION_CANCEL_SEARCH = "com.tebogo.markvault.action.CANCEL_SEARCH"
        const val ACTION_START_TASK = "com.tebogo.markvault.action.START_BACKGROUND_TASK"
        const val ACTION_STOP_TASK = "com.tebogo.markvault.action.STOP_BACKGROUND_TASK"
        const val EXTRA_QUERY = "query"
        const val EXTRA_TOKEN = "token"
        const val EXTRA_LABEL = "label"

        private const val CHANNEL_WORK = "markvault_background_work"
        private const val CHANNEL_SEARCH_READY = "markvault_search_ready"
        private const val NOTIFICATION_ID_WORK = 4822
        private const val NOTIFICATION_ID_SEARCH_READY = 4821
    }
}
