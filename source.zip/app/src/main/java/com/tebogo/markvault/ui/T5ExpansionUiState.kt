package com.tebogo.markvault.ui

/** UI state for switching between built-in and T5 expansion. */
data class T5ExpansionUiState(
    val mode: String = "BUILT_IN",
    val t5Available: Boolean = false,
    val installed: Boolean = false
)
