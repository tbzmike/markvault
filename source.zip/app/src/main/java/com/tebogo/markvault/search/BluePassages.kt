package com.tebogo.markvault.search

/** Compile query expressions once, while preserving the original passage scores and tie order. */
class BluePassages(
    query: String,
    terms: Collection<String>,
    private val countIntent: Boolean,
    private val countAnswer: (String) -> Float
) {
    private val whitespace = Regex("\\s+")
    private val sentences = Regex("(?<=[.!?])\\s+|[\\r\\n]+")
    private val termPatterns = terms.map { Regex("\\b${Regex.escape(it)}\\w*\\b") }
    private val normalizedQuery = query.lowercase().replace(whitespace, " ").trim()

    fun select(raw: String): String {
        val passage = raw.trim()
        if (passage.isBlank()) return ""
        val parts = passage.split(sentences).map { it.trim() }.filter { it.isNotBlank() }
        if (parts.size <= 1) return passage.take(1_800)
        var best: String? = null
        var bestScore = Double.NEGATIVE_INFINITY
        for (start in parts.indices) for (width in 1..3) {
            val end = (start + width).coerceAtMost(parts.size)
            if (end <= start) continue
            val text = parts.subList(start, end).joinToString(" ").take(1_800)
            val lower = text.lowercase().replace(whitespace, " ")
            val words = lower.split(whitespace).filter { it.isNotBlank() }
            if (words.isEmpty()) continue
            val covered = termPatterns.count { it.containsMatchIn(lower) }
            val coverage = if (termPatterns.isEmpty()) 0.0 else covered.toDouble() / termPatterns.size
            val exactPhrase = normalizedQuery.isNotBlank() && normalizedQuery in lower
            val intent = if (countIntent) countAnswer(text).toDouble() else 1.0
            val density = covered.toDouble() / words.size.coerceAtLeast(1)
            val score = coverage * 8.0 + intent * (if (countIntent) 3.0 else 0.5) +
                density * 3.0 + if (exactPhrase) 2.5 else 0.0
            if (best == null || score > bestScore) { best = text; bestScore = score }
        }
        return (best ?: passage).take(1_800)
    }

    /** Reconstruct just the stored winning chunk, rather than allocating every article chunk. */
    fun chunkOrContent(content: String, index: Int): String {
        val words = content.split(whitespace).filter { it.isNotEmpty() }
        if (words.size < 30 || index < 0) return content
        val last = if (words.size <= 350) 0 else (words.size - 350 + 279) / 280
        if (index > last) return content
        val start = index * 280
        return words.subList(start, minOf(start + 350, words.size)).joinToString(" ")
    }
}
