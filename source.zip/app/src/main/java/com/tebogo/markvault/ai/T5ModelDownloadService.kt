package com.tebogo.markvault.ai

import android.content.Context
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File
import java.io.IOException
import java.net.HttpURLConnection
import java.net.URL
import java.security.MessageDigest

/**
 * Downloads and installs the real T5-base ONNX artifacts described in
 * [T5ModelCatalog] from Hugging Face, with resumable downloads, retries,
 * and trust-on-first-use checksum pinning (see [T5ChecksumStore]).
 *
 * Runs entirely on [Dispatchers.IO]; safe to call from a coroutine on any
 * dispatcher.
 */
class T5ModelDownloadService(private val context: Context) {

    private val checksumStore = T5ChecksumStore(context)
    private val modelDir: File
        get() = File(context.filesDir, "models/t5-base").apply { mkdirs() }

    /**
     * Downloads every file in [descriptor], verifying/pinning checksums,
     * and updates install state as it progresses. [onProgress] receives an
     * overall 0-100 value weighted by each file's approximate size.
     *
     * Returns true only if every file downloaded and verified successfully.
     */
    suspend fun install(
        descriptor: T5DownloadDescriptor,
        onProgress: (Int) -> Unit
    ): Boolean = withContext(Dispatchers.IO) {
        T5ModelInstallStateStore.set(T5ModelInstallState.DOWNLOADING)
        onProgress(0)

        val totalBytes = descriptor.files.sumOf { it.approxSizeBytes }.coerceAtLeast(1)
        var completedBytes = 0L

        for (file in descriptor.files) {
            val dest = File(modelDir, file.fileName)
            val ok = downloadOneWithRetry(file, dest) { fileBytesDone ->
                val overall = (completedBytes + fileBytesDone).coerceAtMost(totalBytes)
                onProgress(((overall * 100) / totalBytes).toInt().coerceIn(0, 99))
            }
            if (!ok) {
                T5ModelInstallStateStore.set(T5ModelInstallState.FAILED)
                onProgress(0)
                return@withContext false
            }
            completedBytes += file.approxSizeBytes
        }

        T5ModelInstallStateStore.set(T5ModelInstallState.VERIFYING)
        val allPresent = T5ModelFileRegistry.missingFiles(
            modelDir.listFiles()?.map { it.name }?.toSet() ?: emptySet()
        ).isEmpty()

        if (!allPresent) {
            T5ModelInstallStateStore.set(T5ModelInstallState.FAILED)
            onProgress(0)
            return@withContext false
        }

        T5ModelInstallStateStore.set(T5ModelInstallState.READY)
        T5ModelManager.setInstalled(true)
        onProgress(100)
        true
    }

    private suspend fun downloadOneWithRetry(
        file: T5ModelCatalog.ModelFile,
        dest: File,
        onFileProgress: (Long) -> Unit
    ): Boolean {
        val maxAttempts = 3
        var attempt = 0
        var lastError: Exception? = null
        while (attempt < maxAttempts) {
            attempt++
            try {
                downloadOne(file, dest, onFileProgress)
                return true
            } catch (e: Exception) {
                lastError = e
                // Exponential backoff before retrying; don't retry on the last attempt.
                if (attempt < maxAttempts) {
                    kotlinx.coroutines.delay(1000L * attempt)
                }
            }
        }
        T5DownloadErrorHandler.fallbackToBuiltIn()
        lastError?.printStackTrace()
        return false
    }

    /**
     * Downloads a single file with HTTP range-based resume (if a partial
     * `.part` file already exists) and verifies/pins its SHA-256 once
     * complete. Throws on any failure; callers handle retry.
     */
    private fun downloadOne(
        file: T5ModelCatalog.ModelFile,
        dest: File,
        onFileProgress: (Long) -> Unit
    ) {
        if (dest.exists()) {
            // Already downloaded in a previous run -- verify against the
            // pinned hash rather than re-downloading.
            val existingHash = sha256Of(dest)
            val pinned = checksumStore.pinnedHashFor(file.fileName)
            if (pinned == null || pinned == existingHash) {
                checksumStore.pin(file.fileName, existingHash)
                return
            }
            // Pinned hash mismatch: treat the file on disk as untrustworthy
            // and re-fetch it rather than silently trusting stale/corrupt
            // bytes.
            dest.delete()
        }

        val partFile = File(dest.parentFile, "${dest.name}.part")
        var resumeFrom = if (partFile.exists()) partFile.length() else 0L

        val url = URL(file.url)
        var connection = openConnection(url, resumeFrom)

        if (connection.responseCode == HttpURLConnection.HTTP_OK && resumeFrom > 0) {
            // Server doesn't support Range for this URL; restart clean.
            partFile.delete()
            resumeFrom = 0L
            connection.disconnect()
            connection = openConnection(url, 0)
        }

        if (connection.responseCode !in 200..299) {
            connection.disconnect()
            throw IOException("HTTP ${connection.responseCode} for ${file.url}")
        }

        val digest = MessageDigest.getInstance("SHA-256")
        // Re-hash any previously-downloaded partial bytes so the final
        // digest covers the whole file, not just this session's bytes.
        if (resumeFrom > 0 && partFile.exists()) {
            partFile.inputStream().use { existing ->
                val buf = ByteArray(64 * 1024)
                var n: Int
                while (existing.read(buf).also { n = it } >= 0) {
                    if (n > 0) digest.update(buf, 0, n)
                }
            }
        }

        connection.inputStream.use { input ->
            java.io.FileOutputStream(partFile, resumeFrom > 0).use { output ->
                val buffer = ByteArray(64 * 1024)
                var bytesRead: Int
                var total = resumeFrom
                while (input.read(buffer).also { bytesRead = it } != -1) {
                    output.write(buffer, 0, bytesRead)
                    digest.update(buffer, 0, bytesRead)
                    total += bytesRead
                    onFileProgress(total)
                }
            }
        }
        connection.disconnect()

        val hashHex = digest.digest().joinToString("") { "%02x".format(it) }
        val pinned = checksumStore.pinnedHashFor(file.fileName)
        if (pinned != null && pinned != hashHex) {
            partFile.delete()
            throw IOException(
                "Checksum mismatch for ${file.fileName}: expected pinned $pinned, got $hashHex"
            )
        }

        if (!partFile.renameTo(dest)) {
            throw IOException("Failed to finalize download for ${file.fileName}")
        }
        checksumStore.pin(file.fileName, hashHex)
    }

    private fun openConnection(url: URL, resumeFrom: Long): HttpURLConnection {
        val connection = url.openConnection() as HttpURLConnection
        connection.instanceFollowRedirects = true
        connection.connectTimeout = 30_000
        connection.readTimeout = 30_000
        connection.setRequestProperty(
            "User-Agent",
            "MarkVault-Android/${android.os.Build.VERSION.SDK_INT} (+https://github.com/tebogo/markvault)"
        )
        if (resumeFrom > 0) {
            connection.setRequestProperty("Range", "bytes=$resumeFrom-")
        }
        connection.connect()
        return connection
    }

    private fun sha256Of(file: File): String {
        val digest = MessageDigest.getInstance("SHA-256")
        file.inputStream().use { input ->
            val buffer = ByteArray(64 * 1024)
            var bytesRead: Int
            while (input.read(buffer).also { bytesRead = it } != -1) {
                digest.update(buffer, 0, bytesRead)
            }
        }
        return digest.digest().joinToString("") { "%02x".format(it) }
    }
}
