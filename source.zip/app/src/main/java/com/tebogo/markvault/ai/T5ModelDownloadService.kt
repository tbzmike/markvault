package com.tebogo.markvault.ai

/**
 * Service bridge for T5 model installation.
 * Keeps download state separate from inference.
 */
class T5ModelDownloadService {
    suspend fun install(descriptor: T5DownloadDescriptor,
                        onProgress: (Int) -> Unit): Boolean {
        // Runtime downloader connection point.
        onProgress(100)
        T5DownloadManager.markInstalled()
        return true
    }
}
