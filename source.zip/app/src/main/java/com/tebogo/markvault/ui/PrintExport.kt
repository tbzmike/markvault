package com.tebogo.markvault.ui

import android.content.Context
import android.print.PrintAttributes
import android.print.PrintManager
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Button
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

/** Options the user picks before exporting. */
data class PrintOptions(
    val paper: PaperSize = PaperSize.A4,
    val orientation: Orientation = Orientation.PORTRAIT,
    val margin: MarginPreset = MarginPreset.NORMAL,
    val darkMode: Boolean = false
)

enum class PaperSize(val label: String, val attrs: PrintAttributes.MediaSize) {
    A3("A3", PrintAttributes.MediaSize.ISO_A3),
    A4("A4", PrintAttributes.MediaSize.ISO_A4),
    A5("A5", PrintAttributes.MediaSize.ISO_A5),
    LETTER("US Letter", PrintAttributes.MediaSize.NA_LETTER),
    LEGAL("US Legal", PrintAttributes.MediaSize.NA_LEGAL)
}

enum class Orientation(val label: String) {
    PORTRAIT("Portrait"),
    LANDSCAPE("Landscape");

    fun toMediaSize(base: PrintAttributes.MediaSize): PrintAttributes.MediaSize =
        if (this == LANDSCAPE) base.asLandscape() else base.asPortrait()
}

enum class MarginPreset(val label: String, val css: String) {
    COMPACT("Compact", "0.4in"),
    NORMAL("Normal", "0.75in"),
    WIDE("Wide", "1.2in")
}

/**
 * Bottom-sheet body for picking print options. Place inside a ColumnScope (e.g. ModalBottomSheet
 * content). Calls [onConfirm] when the user taps Print.
 */
@Composable
fun ColumnScope.PrintOptionsSheet(
    noteTitle: String,
    onConfirm: (PrintOptions) -> Unit,
    onCancel: () -> Unit
) {
    var paper by remember { mutableStateOf(PaperSize.A4) }
    var orient by remember { mutableStateOf(Orientation.PORTRAIT) }
    var margin by remember { mutableStateOf(MarginPreset.NORMAL) }
    var dark by remember { mutableStateOf(false) }

    Column(Modifier.fillMaxWidth().padding(horizontal = 20.dp)) {
        Text(
            "\uD83D\uDDA8\uFE0F  Print / PDF",
            fontWeight = FontWeight.SemiBold, fontSize = 17.sp
        )
        Spacer(Modifier.height(2.dp))
        Text(noteTitle, fontSize = 13.sp,
            color = MaterialTheme.colorScheme.onSurfaceVariant)
        Spacer(Modifier.height(14.dp))

        OptionGroup("Paper size") {
            ChipRow(PaperSize.values().toList(), paper, { it.label }) { paper = it }
        }
        Spacer(Modifier.height(10.dp))
        OptionGroup("Orientation") {
            ChipRow(Orientation.values().toList(), orient, { it.label }) { orient = it }
        }
        Spacer(Modifier.height(10.dp))
        OptionGroup("Margins") {
            ChipRow(MarginPreset.values().toList(), margin, { it.label }) { margin = it }
        }
        Spacer(Modifier.height(10.dp))
        OptionGroup("Theme") {
            ChipRow(
                listOf(false, true), dark,
                { if (it) "\uD83C\uDF19 Dark" else "\u2600\uFE0F Light" }
            ) { dark = it }
        }

        Spacer(Modifier.height(20.dp))
        HorizontalDivider(color = MaterialTheme.colorScheme.surfaceVariant)
        Spacer(Modifier.height(12.dp))
        Row(
            Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.End
        ) {
            Surface(
                color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.3f),
                shape = RoundedCornerShape(10.dp),
                modifier = Modifier
                    .clickable(onClick = onCancel)
                    .padding(0.dp)
            ) {
                Text("Cancel", Modifier.padding(horizontal = 18.dp, vertical = 11.dp), fontSize = 14.sp)
            }
            Spacer(Modifier.width(10.dp))
            Button(onClick = {
                onConfirm(PrintOptions(paper, orient, margin, dark))
            }) {
                Text("Print")
            }
        }
        Spacer(Modifier.height(20.dp))
    }
}

@Composable
private fun OptionGroup(label: String, content: @Composable () -> Unit) {
    Text(label, fontSize = 12.sp, fontWeight = FontWeight.Medium,
        color = MaterialTheme.colorScheme.onSurfaceVariant)
    Spacer(Modifier.height(6.dp))
    content()
}

@Composable
private fun <T> ChipRow(
    items: List<T>,
    selected: T,
    label: (T) -> String,
    onClick: (T) -> Unit
) {
    Row(
        Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.spacedBy(6.dp)
    ) {
        items.forEach { item ->
            val isSel = item == selected
            Surface(
                color = if (isSel) MaterialTheme.colorScheme.primary
                else MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.45f),
                shape = RoundedCornerShape(8.dp),
                modifier = Modifier.clickable { onClick(item) }
            ) {
                Text(
                    label(item),
                    Modifier.padding(horizontal = 12.dp, vertical = 8.dp),
                    fontSize = 12.sp,
                    color = if (isSel) MaterialTheme.colorScheme.onPrimary
                    else MaterialTheme.colorScheme.onSurface,
                    fontWeight = if (isSel) FontWeight.SemiBold else FontWeight.Normal
                )
            }
        }
    }
}

private fun escapeHtml(s: String): String = s
    .replace("&", "&amp;")
    .replace("<", "&lt;")
    .replace(">", "&gt;")
    .replace("\"", "&quot;")

/**
 * Fire an Android print job for an HTML string. The PrintManager dialog lets the user pick
 * a real printer or "Save as PDF" — we don't have to handle that decision ourselves.
 *
 * Implementation note: we render the HTML in a transient WebView, wait for its onPageFinished,
 * then call createPrintDocumentAdapter(). This is the standard pattern from the Android docs.
 * We pin a reference to the WebView in [pinHolder] so it isn't garbage-collected before the
 * print framework finishes with the adapter.
 */
fun startPrintJob(
    ctx: Context,
    title: String,
    html: String,
    options: PrintOptions,
    pinHolder: PinHolder
) {
    val webView = WebView(ctx)
    webView.settings.javaScriptEnabled = false
    webView.webViewClient = object : WebViewClient() {
        override fun onPageFinished(view: WebView?, url: String?) {
            val mgr = ctx.getSystemService(Context.PRINT_SERVICE) as? PrintManager ?: return
            val mediaSize = options.orientation.toMediaSize(options.paper.attrs)
            val attrs = PrintAttributes.Builder()
                .setMediaSize(mediaSize)
                // We use the smallest hardware margins and let CSS @page set the visual margin.
                // That gives precise control across paper sizes — the print framework's own
                // margin attributes are coarser (only MM/IN presets).
                .setMinMargins(PrintAttributes.Margins.NO_MARGINS)
                .build()
            val safeName = title.replace(Regex("[^\\w\\-. ]+"), "_").take(60).ifBlank { "MarkVault" }
            val adapter = webView.createPrintDocumentAdapter(safeName)
            mgr.print(safeName, adapter, attrs)
            // Keep the WebView alive until the adapter is done with it
            pinHolder.pinned = webView
        }
    }
    webView.loadDataWithBaseURL(null, html, "text/html", "utf-8", null)
}

/** Holds a strong reference to the transient WebView so it survives the print job. */
class PinHolder { var pinned: Any? = null }

/**
 * Wrap a markdown article in a print-friendly HTML page. The CSS @page rule honours the
 * user's margin choice; the body styling honours their light/dark choice.
 */
fun buildPrintHtml(title: String, markdownToHtml: String, options: PrintOptions): String {
    val bg = if (options.darkMode) "#0e0e0e" else "#ffffff"
    val fg = if (options.darkMode) "#e0e0e0" else "#1a1a1a"
    val linkColor = if (options.darkMode) "#8ab4f8" else "#1a5fc0"
    val quoteBorder = if (options.darkMode) "#3a3a3a" else "#cccccc"
    val codeBg = if (options.darkMode) "#1c1c1c" else "#f4f4f4"
    val tableBorder = if (options.darkMode) "#3a3a3a" else "#cccccc"
    return """
<!doctype html>
<html><head><meta charset="utf-8">
<title>${escapeHtml(title)}</title>
<style>
  @page { size: auto; margin: ${options.margin.css}; }
  html, body { background: $bg; color: $fg; }
  body {
    font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto,
                 "Helvetica Neue", Arial, sans-serif;
    font-size: 11pt; line-height: 1.55;
    margin: 0; padding: 0;
    -webkit-print-color-adjust: exact;
    print-color-adjust: exact;
  }
  h1, h2, h3, h4, h5, h6 {
    font-weight: 600; line-height: 1.25; margin: 1.2em 0 0.5em;
    page-break-after: avoid; break-after: avoid;
  }
  h1 { font-size: 1.7em; }
  h2 { font-size: 1.4em; border-bottom: 1px solid $tableBorder; padding-bottom: 0.2em; }
  h3 { font-size: 1.2em; }
  p { margin: 0.7em 0; orphans: 2; widows: 2; }
  a { color: $linkColor; text-decoration: underline; word-break: break-word; }
  blockquote {
    margin: 0.8em 0; padding: 0.4em 1em; border-left: 3px solid $quoteBorder;
    color: ${if (options.darkMode) "#b0b0b0" else "#555555"};
  }
  pre, code {
    font-family: "SF Mono", Consolas, Menlo, Monaco, "Courier New", monospace;
    font-size: 0.92em;
  }
  pre {
    background: $codeBg; padding: 0.7em 1em; border-radius: 4px;
    overflow-x: auto; white-space: pre-wrap; word-wrap: break-word;
    page-break-inside: avoid; break-inside: avoid;
  }
  code { background: $codeBg; padding: 0.1em 0.35em; border-radius: 3px; }
  pre code { background: none; padding: 0; border-radius: 0; }
  ul, ol { padding-left: 1.6em; margin: 0.5em 0; }
  li { margin: 0.25em 0; }
  img { max-width: 100%; height: auto; page-break-inside: avoid; break-inside: avoid; }
  table {
    border-collapse: collapse; width: 100%; margin: 0.8em 0;
    page-break-inside: avoid; break-inside: avoid;
  }
  th, td { border: 1px solid $tableBorder; padding: 0.5em 0.75em; text-align: left; }
  th { background: $codeBg; font-weight: 600; }
  hr { border: 0; border-top: 1px solid $tableBorder; margin: 1.5em 0; }
  .mv-title { font-size: 1.8em; font-weight: 700; margin: 0 0 1em; }
</style>
</head><body>
<div class="mv-title">${escapeHtml(title)}</div>
$markdownToHtml
</body></html>
""".trimIndent()
}
