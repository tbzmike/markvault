package com.tebogo.markvault.ui

import android.provider.Settings
import androidx.compose.animation.core.AnimationSpec
import androidx.compose.animation.core.FiniteAnimationSpec
import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.Immutable
import androidx.compose.runtime.ProvidableCompositionLocal
import androidx.compose.runtime.ReadOnlyComposable
import androidx.compose.runtime.remember
import androidx.compose.runtime.staticCompositionLocalOf
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.IntOffset

/**
 * MarkVault — Expressive Motion Engine (opt-in plugin)
 * ====================================================
 *
 * A self-contained animation layer that any composable can read to get
 * spring-based motion physics. It is entirely OPT-IN:
 *
 *   • When the user's "Expressive motion" toggle is OFF (the default),
 *     [ProvideAppMotion] installs the [MotionProfile.OFF] specs, which
 *     are effectively no-ops. Nothing about the app's behaviour
 *     changes — existing animations keep whatever they already do, and
 *     the custom animated wrappers ([ExpressiveDialog], etc.) fall back
 *     to plain, instant rendering.
 *
 *   • When ON, components read the chosen profile's spring specs.
 *
 * Deliberately dependency-light: no MotionScheme / MaterialExpressive-
 * Theme (those live only in the pre-release material3 alpha). The specs
 * mirror the published Expressive tokens as plain AnimationSpecs, so
 * this compiles against the stable material3 the app already ships.
 *
 * No separate DataStore: the profile + enabled flag come from the
 * app's existing Prefs via AppViewModel. This file only holds the
 * in-composition state + the spec math.
 */

enum class MotionProfile(val label: String, val description: String) {
    /**
     * Plugin disabled. Specs are near-instant tweens so any component
     * that happens to read them still renders without visible motion —
     * i.e. the app looks and behaves as it did before the plugin.
     */
    OFF(
        label = "Off",
        description = "No added animation — the app's default behaviour"
    ),
    EXPRESSIVE(
        label = "Expressive",
        description = "Playful spring physics with a subtle bounce"
    ),
    STANDARD(
        label = "Standard",
        description = "Smooth, clean transitions with no bounce"
    ),
    REDUCED(
        label = "Reduced motion",
        description = "Near-instant transitions for speed and accessibility"
    );

    companion object {
        /** Parse a stored name safely; unknown/blank → OFF. */
        fun fromName(name: String?): MotionProfile =
            runCatching { valueOf(name ?: "") }.getOrDefault(OFF)
    }
}

/**
 * Resolved animation specs for the active profile. [Immutable] so
 * Compose skips recomposing consumers when the same profile is
 * re-provided.
 */
@Immutable
data class MotionSpecs(
    val profile: MotionProfile,
    /** Whether the plugin is actually adding motion (profile != OFF). */
    val enabled: Boolean,
    val spatialOffsetSpec: FiniteAnimationSpec<IntOffset>,
    val spatialFloatSpec: FiniteAnimationSpec<Float>,
    val effectsFloatSpec: FiniteAnimationSpec<Float>,
    val spatialGenericSpec: AnimationSpec<Float>,
    // v5.4.161cc — Added for the theme-switch color-crossfade feature.
    // Plain tweens (never spring) deliberately: a bouncy spring on a
    // Color animation can transiently push a channel outside its normal
    // range as it overshoots, which can read as a brief, odd color flash.
    // Duration mirrors each profile's entranceDurationMs for consistency.
    val colorSpec: FiniteAnimationSpec<Color>,
    val entranceDurationMs: Int,
    val exitDurationMs: Int
) {
    companion object {
        fun forProfile(profile: MotionProfile): MotionSpecs = when (profile) {
            MotionProfile.OFF -> MotionSpecs(
                profile = profile,
                enabled = false,
                spatialOffsetSpec = tween(0),
                spatialFloatSpec = tween(0),
                effectsFloatSpec = tween(0),
                spatialGenericSpec = tween(0),
                colorSpec = tween(0),
                entranceDurationMs = 0,
                exitDurationMs = 0
            )
            MotionProfile.EXPRESSIVE -> MotionSpecs(
                profile = profile,
                enabled = true,
                spatialOffsetSpec = spring(
                    dampingRatio = 0.55f,
                    stiffness = Spring.StiffnessMediumLow
                ),
                spatialFloatSpec = spring(
                    dampingRatio = 0.55f,
                    stiffness = Spring.StiffnessMediumLow
                ),
                effectsFloatSpec = spring(
                    dampingRatio = Spring.DampingRatioNoBouncy,
                    stiffness = Spring.StiffnessMedium
                ),
                spatialGenericSpec = spring(
                    dampingRatio = 0.55f,
                    stiffness = Spring.StiffnessMediumLow
                ),
                colorSpec = tween(500),
                entranceDurationMs = 500,
                exitDurationMs = 200
            )
            MotionProfile.STANDARD -> MotionSpecs(
                profile = profile,
                enabled = true,
                spatialOffsetSpec = spring(
                    dampingRatio = Spring.DampingRatioNoBouncy,
                    stiffness = Spring.StiffnessMediumLow
                ),
                spatialFloatSpec = spring(
                    dampingRatio = Spring.DampingRatioNoBouncy,
                    stiffness = Spring.StiffnessMediumLow
                ),
                effectsFloatSpec = tween(durationMillis = 200),
                spatialGenericSpec = spring(
                    dampingRatio = Spring.DampingRatioNoBouncy,
                    stiffness = Spring.StiffnessMediumLow
                ),
                colorSpec = tween(300),
                entranceDurationMs = 300,
                exitDurationMs = 150
            )
            MotionProfile.REDUCED -> MotionSpecs(
                profile = profile,
                enabled = true,
                spatialOffsetSpec = tween(durationMillis = 40),
                spatialFloatSpec = tween(durationMillis = 40),
                effectsFloatSpec = tween(durationMillis = 40),
                spatialGenericSpec = tween(durationMillis = 40),
                colorSpec = tween(40),
                entranceDurationMs = 40,
                exitDurationMs = 30
            )
        }
    }
}

/**
 * Active specs for the subtree. Default is OFF so an un-provided
 * subtree (or a preview) behaves like the plugin is disabled.
 */
val LocalAppMotion: ProvidableCompositionLocal<MotionSpecs> =
    staticCompositionLocalOf { MotionSpecs.forProfile(MotionProfile.OFF) }

object AppMotion {
    val specs: MotionSpecs
        @Composable
        @ReadOnlyComposable
        get() = LocalAppMotion.current
    val profile: MotionProfile
        @Composable
        @ReadOnlyComposable
        get() = LocalAppMotion.current.profile
}

/**
 * v5.4.161cc — Extracted from [ProvideAppMotion] so a second call site
 * (MainActivity's theme-switch color animation, which needs the resolved
 * spec BEFORE MaterialTheme/ProvideAppMotion are installed) can resolve
 * the exact same effective profile without duplicating this logic.
 * Behaviourally identical to what [ProvideAppMotion] always computed
 * internally — this is a pure relocation, not a logic change.
 *
 * Accessibility: even when the user enabled the plugin, if the OS
 * "remove animations" setting is on (ANIMATOR_DURATION_SCALE == 0),
 * this downgrades to REDUCED. A user who told the OS they can't
 * tolerate motion is never overridden by an app setting.
 */
@Composable
fun rememberEffectiveMotionProfile(enabled: Boolean, profileName: String): MotionProfile {
    val context = LocalContext.current
    return if (!enabled) {
        MotionProfile.OFF
    } else {
        val chosen = MotionProfile.fromName(profileName)
        val osAnimationsOff = remember(profileName, enabled) {
            val scale = runCatching {
                Settings.Global.getFloat(
                    context.contentResolver,
                    Settings.Global.ANIMATOR_DURATION_SCALE,
                    1f
                )
            }.getOrDefault(1f)
            scale == 0f
        }
        if (osAnimationsOff && chosen != MotionProfile.OFF) MotionProfile.REDUCED else chosen
    }
}

/**
 * Install the motion system.
 *
 * @param enabled the master toggle from Settings. When false, forces
 *        [MotionProfile.OFF] regardless of [profileName] — the plugin
 *        contributes nothing.
 * @param profileName the stored MotionProfile.name; used only when
 *        [enabled] is true.
 */
@Composable
fun ProvideAppMotion(
    enabled: Boolean,
    profileName: String,
    content: @Composable () -> Unit
) {
    val effective = rememberEffectiveMotionProfile(enabled, profileName)
    val specs = remember(effective) { MotionSpecs.forProfile(effective) }
    CompositionLocalProvider(LocalAppMotion provides specs, content = content)
}
