package com.tebogo.markvault.web

import android.webkit.WebSettings
import android.webkit.WebView

/**
 * v5.4.78 — Advanced WebView configuration.
 *
 * Optimised for dynamic sites such as jw.org and wol.jw.org.
 */
object WebViewConfigurator {

    fun apply(webView: WebView) {
        val s = webView.settings

        s.javaScriptEnabled = true
        s.domStorageEnabled = true
        s.databaseEnabled = true
        s.loadsImagesAutomatically = true
        s.mediaPlaybackRequiresUserGesture = true
        s.useWideViewPort = true
        s.loadWithOverviewMode = true

        s.setSupportZoom(true)
        s.builtInZoomControls = true
        s.displayZoomControls = false

        s.mixedContentMode =
            WebSettings.MIXED_CONTENT_COMPATIBILITY_MODE

        s.userAgentString =
            s.userAgentString + " MarkVault/5.4.78"

        WebView.setWebContentsDebuggingEnabled(false)
    }
}
