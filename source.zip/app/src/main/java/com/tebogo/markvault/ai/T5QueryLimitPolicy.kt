package com.tebogo.markvault.ai

/** Controls generated query limits. */
object T5QueryLimitPolicy {
    fun limit(queries: List<String>): List<String> {
        return queries.distinct().take(5)
    }
}
