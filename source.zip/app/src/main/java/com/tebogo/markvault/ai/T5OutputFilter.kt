package com.tebogo.markvault.ai

/** Cleans T5 generated paraphrases before retrieval. */
object T5OutputFilter {
    fun filter(input: List<String>, maxItems: Int = 5): List<String> {
        return input
            .map { it.trim() }
            .filter { it.length >= 3 }
            .distinctBy { it.lowercase() }
            .take(maxItems)
    }
}
