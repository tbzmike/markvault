package com.tebogo.markvault.search

import kotlinx.coroutines.Deferred
import kotlinx.coroutines.async
import kotlinx.coroutines.coroutineScope

/** Parallel blue retrieval stays owned by the request, including hard cancellation. */
object BlueSearchPipeline {
    suspend fun <S, R> retrieve(
        enabled: Boolean,
        semantic: suspend () -> S,
        keywordsAndFusion: suspend (Deferred<S>?) -> R
    ): R = coroutineScope {
        val prefetched = if (enabled) async { semantic() } else null
        keywordsAndFusion(prefetched)
    }
}
