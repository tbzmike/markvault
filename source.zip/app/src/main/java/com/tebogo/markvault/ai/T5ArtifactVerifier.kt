package com.tebogo.markvault.ai

/** Verifies required T5 artifact presence before enabling T5 expansion. */
object T5ArtifactVerifier {
    private val requiredFiles = listOf(
        "model",
        "tokenizer"
    )

    fun isReady(existingFiles: Set<String>): Boolean {
        return requiredFiles.all { existingFiles.contains(it) }
    }
}
