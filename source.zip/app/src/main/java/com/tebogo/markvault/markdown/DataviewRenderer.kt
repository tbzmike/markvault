package com.tebogo.markvault.markdown

/**
 * Dataview-style rendering foundation.
 * Turns query results into simple markdown tables.
 */
object DataviewRenderer {
    fun renderTable(headers: List<String>, rows: List<List<String>>): String {
        if (headers.isEmpty()) return ""
        val out = StringBuilder()
        out.append("| ").append(headers.joinToString(" | ")).append(" |\n")
        out.append("| ").append(headers.map { "---" }.joinToString(" | ")).append(" |\n")
        rows.forEach { row ->
            out.append("| ").append(row.joinToString(" | ")).append(" |\n")
        }
        return out.toString()
    }
}
