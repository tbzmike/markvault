package com.tebogo.markvault.ui

import android.annotation.SuppressLint
import android.net.Uri
import android.webkit.WebResourceRequest
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.navigation.NavController
import com.tebogo.markvault.AppViewModel
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

/**
 * v5.4.106cc — Side-by-side "live web page ↔ found library article"
 * viewer, opened from the LibraryCheckOverlay's Split-view button.
 *
 * Layout: vertical split (WebView on top, library preview on bottom)
 * with a fixed 50/50 weight for now. A future revision can add a
 * draggable divider; the current split is enough to confirm-by-eye
 * whether the surfaced match is the article on screen.
 *
 * Top pane — a fresh WebView loading [liveUrl]. Deliberately
 * lightweight (JS on, but no sharing of the main WebViewer's tab
 * pool) because this view is a preview, not a long-lived tab. Uses
 * the same UA sanitisation as [buildBatchWebView] so jw.org serves
 * mobile markup and Cloudflare doesn't flag it as `wv` (webview).
 *
 * Bottom pane — a compact preview of the library note. Renders three
 * kinds of notes:
 *   • **Markdown / plain text** — reads the raw file via
 *     ContentResolver (first 32 KB, more than enough for a
 *     preview), shows title + first paragraphs in monospaced text
 *     so the user can eyeball the content. Full formatting isn't
 *     necessary for the "is this the right article?" check.
 *   • **HTML / MHTML** — loads the local file URI directly in a
 *     WebView. Same setup as HtmlReaderScreen but stripped of the
 *     TOC / theme / scroll-restore machinery.
 *   • **PDF** — not previewable inline; shows a "Tap to open
 *     fullscreen" button which routes into pdfReader/{id}.
 *
 * Both panes have a small top-right expand button so the user can
 * bail out of split view into whichever pane they prefer at
 * fullscreen. Back button pops the split view.
 */
@SuppressLint("SetJavaScriptEnabled")
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun WebSplitScreen(
    vm: AppViewModel,
    nav: NavController,
    liveUrl: String,
    noteId: Long,
    fileType: String
) {
    val ctx = LocalContext.current
    val appDark = LocalMarkVaultDarkMode.current
    val ft = fileType.lowercase()

    // Load the note metadata + raw content once.
    var noteTitle by remember { mutableStateOf("Loading…") }
    var noteUri by remember { mutableStateOf<String?>(null) }
    var previewText by remember { mutableStateOf<String?>(null) }
    var loadError by remember { mutableStateOf<String?>(null) }

    LaunchedEffect(noteId, ft) {
        val note = withContext(Dispatchers.IO) {
            runCatching { vm.noteById(noteId) }.getOrNull()
        }
        if (note == null) {
            loadError = "Note not found (id=$noteId)."
            return@LaunchedEffect
        }
        noteTitle = note.title.ifBlank { note.name }
        noteUri = note.uri
        // For markdown / text notes, prefetch the first 32 KB so the
        // bottom pane can show a text preview. HTML/MHTML/PDF handle
        // themselves inside the pane's own composable.
        if (ft == "md" || ft == "txt") {
            val preview = withContext(Dispatchers.IO) {
                runCatching {
                    ctx.contentResolver.openInputStream(Uri.parse(note.uri))
                        ?.use { input ->
                            val buf = ByteArray(32 * 1024)
                            var offset = 0
                            while (offset < buf.size) {
                                val r = input.read(buf, offset, buf.size - offset)
                                if (r <= 0) break
                                offset += r
                            }
                            String(buf, 0, offset, Charsets.UTF_8)
                        }
                }.getOrNull()
            }
            previewText = preview.orEmpty()
        }
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Text(
                        "Split view",
                        fontWeight = FontWeight.SemiBold,
                        maxLines = 1
                    )
                },
                navigationIcon = {
                    IconButton(onClick = { nav.popBackStack() }) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back")
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = MaterialTheme.colorScheme.surface
                )
            )
        }
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
        ) {
            // ─── Top pane: live WebView on the URL being confirmed ───
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .weight(1f, fill = true)
            ) {
                AndroidView(
                    modifier = Modifier.fillMaxSize(),
                    factory = { c ->
                        WebView(c).apply {
                            settings.javaScriptEnabled = true
                            settings.domStorageEnabled = true
                            settings.loadsImagesAutomatically = true
                            settings.mixedContentMode =
                                WebSettings.MIXED_CONTENT_COMPATIBILITY_MODE
                            val defaultUa = settings.userAgentString
                            settings.userAgentString =
                                if (defaultUa.isNullOrBlank()) {
                                    "Mozilla/5.0 (Linux; Android 14) " +
                                        "AppleWebKit/537.36 (KHTML, like Gecko) " +
                                        "Chrome/120.0.0.0 Mobile Safari/537.36"
                                } else {
                                    defaultUa.replace("; wv)", ")")
                                }
                            webViewClient = object : WebViewClient() {
                                override fun shouldOverrideUrlLoading(
                                    view: WebView?,
                                    request: WebResourceRequest?
                                ): Boolean = false  // let all URLs load in-pane
                                override fun onPageFinished(view: WebView?, url: String?) {
                                    if (view != null) applyUniversalWebAppearance(view, appDark)
                                }
                            }
                            loadUrl(liveUrl.ifBlank { "about:blank" })
                        }
                    },
                    update = { applyUniversalWebAppearance(it, appDark) }
                )
                // Small "expand this pane" button top-right of the
                // live pane.
                IconButton(
                    onClick = {
                        val enc = runCatching {
                            java.net.URLEncoder.encode(liveUrl, "UTF-8")
                        }.getOrElse { liveUrl }
                        val label = runCatching {
                            java.net.URLEncoder.encode(
                                Uri.parse(liveUrl).host ?: "Web",
                                "UTF-8"
                            )
                        }.getOrElse { "Web" }
                        nav.navigate("web/$enc/$label")
                    },
                    modifier = Modifier
                        .align(Alignment.TopEnd)
                        .padding(4.dp)
                        .background(
                            MaterialTheme.colorScheme.surface.copy(alpha = 0.85f),
                            androidx.compose.foundation.shape.RoundedCornerShape(50)
                        )
                        .size(36.dp)
                ) {
                    Text("⤢", fontSize = 18.sp, color = MaterialTheme.colorScheme.onSurface)
                }
            }

            HorizontalDivider(
                thickness = 2.dp,
                color = MaterialTheme.colorScheme.primary.copy(alpha = 0.4f)
            )

            // ─── Bottom pane: library note preview ───
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .weight(1f, fill = true)
            ) {
                when {
                    loadError != null -> {
                        Text(
                            loadError.orEmpty(),
                            modifier = Modifier
                                .fillMaxSize()
                                .padding(16.dp),
                            color = MaterialTheme.colorScheme.error
                        )
                    }
                    ft == "html" || ft == "htm" || ft == "mhtml" || ft == "mht" -> {
                        val uri = noteUri
                        if (uri.isNullOrBlank()) {
                            LoadingBox()
                        } else {
                            AndroidView(
                                modifier = Modifier.fillMaxSize(),
                                factory = { c ->
                                    WebView(c).apply {
                                        settings.javaScriptEnabled = false
                                        settings.allowFileAccess = true
                                        settings.allowContentAccess = true
                                        settings.domStorageEnabled = false
                                        settings.loadsImagesAutomatically = true
                                        webViewClient = object : WebViewClient() {
                                            override fun onPageFinished(view: WebView?, url: String?) {
                                                if (view != null) applyUniversalWebAppearance(view, appDark)
                                            }
                                        }
                                        loadUrl(uri)
                                    }
                                },
                                update = { applyUniversalWebAppearance(it, appDark) }
                            )
                        }
                    }
                    ft == "pdf" -> {
                        Column(
                            modifier = Modifier
                                .fillMaxSize()
                                .padding(24.dp),
                            verticalArrangement = Arrangement.Center,
                            horizontalAlignment = Alignment.CenterHorizontally
                        ) {
                            Text(
                                noteTitle,
                                fontWeight = FontWeight.Bold,
                                fontSize = 16.sp,
                                textAlign = androidx.compose.ui.text.style.TextAlign.Center
                            )
                            Spacer(Modifier.height(12.dp))
                            Text(
                                "\uD83D\uDCC4 PDF preview isn't available in split view.",
                                textAlign = androidx.compose.ui.text.style.TextAlign.Center,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                            Spacer(Modifier.height(16.dp))
                            androidx.compose.material3.FilledTonalButton(
                                onClick = { nav.navigate("pdfReader/$noteId") }
                            ) { Text("Open PDF fullscreen") }
                        }
                    }
                    // Default: markdown / txt — text preview.
                    else -> {
                        val text = previewText
                        if (text == null) {
                            LoadingBox()
                        } else {
                            Column(
                                modifier = Modifier
                                    .fillMaxSize()
                                    .verticalScroll(rememberScrollState())
                                    .padding(
                                        horizontal = 16.dp,
                                        vertical = 12.dp
                                    )
                            ) {
                                Text(
                                    noteTitle,
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 17.sp,
                                    color = MaterialTheme.colorScheme.onSurface
                                )
                                Spacer(Modifier.height(8.dp))
                                Text(
                                    text.ifBlank { "(empty file)" },
                                    fontSize = 13.sp,
                                    lineHeight = 19.sp,
                                    color = MaterialTheme.colorScheme.onSurface,
                                    fontFamily = FontFamily.Monospace
                                )
                                Spacer(Modifier.height(24.dp))
                                androidx.compose.material3.FilledTonalButton(
                                    onClick = { nav.navigate("reader") }
                                ) { Text("Open article fullscreen") }
                            }
                        }
                    }
                }
                // Expand button for the library pane. Routes to the
                // correct reader by fileType.
                IconButton(
                    onClick = {
                        vm.openArticle(
                            id = noteId,
                            title = noteTitle,
                            fileType = ft
                        )
                        when (ft) {
                            "pdf" -> nav.navigate("pdfReader/$noteId")
                            "html", "htm", "mhtml", "mht" ->
                                nav.navigate("htmlReader/$noteId")
                            else -> nav.navigate("reader")
                        }
                    },
                    modifier = Modifier
                        .align(Alignment.TopEnd)
                        .padding(4.dp)
                        .background(
                            MaterialTheme.colorScheme.surface.copy(alpha = 0.85f),
                            androidx.compose.foundation.shape.RoundedCornerShape(50)
                        )
                        .size(36.dp)
                ) {
                    Text("⤢", fontSize = 18.sp, color = MaterialTheme.colorScheme.onSurface)
                }
            }
        }
    }
}

@Composable
private fun LoadingBox() {
    Box(
        modifier = Modifier.fillMaxSize(),
        contentAlignment = Alignment.Center
    ) {
        CircularProgressIndicator(strokeWidth = 2.dp)
    }
}
