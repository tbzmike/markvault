package com.tebogo.markvault.search

/**
 * View-only legend for the queries already recorded by retrieval. This class is
 * deliberately independent of Android/Room and never generates or runs a query.
 * A missing saved-session source/number stays unknown rather than receiving a
 * misleading synonym, LLM, or T5 label.
 */
data class VisibleExpansionQuery(
    val number: Int?,
    val text: String,
    val source: ResultQuerySource?
)

object QueryExpansionPresentation {
    /** Uses the exact issued-order numbering used by issuedRetrievalQueries. */
    fun fromPlan(queries: List<Pair<String, ResultQuerySource>>): List<VisibleExpansionQuery> {
        val seen = HashSet<String>()
        val result = ArrayList<VisibleExpansionQuery>()
        for ((textRaw, source) in queries) {
            val query = textRaw.trim()
            if (query.isEmpty() || source == ResultQuerySource.ORIGINAL) continue
            if (!seen.add("${source.name}:${query.lowercase()}")) continue
            result += VisibleExpansionQuery(result.size + 1, query, source)
        }
        return result
    }

    /** Saved results keep exact evidenced colors even after the in-memory plan is lost. */
    fun fromSaved(
        provenance: Collection<ResultQueryProvenance>,
        savedExpansions: List<String>,
        questionAwareQueries: List<String>
    ): List<VisibleExpansionQuery> {
        val evidenced = provenance.asSequence()
            .flatMap { it.contributions.asSequence() }
            .filter { !it.isOriginal && it.expansionNumber != null && it.expansionNumber > 0 }
            .groupBy { it.expansionNumber!! }
            .toSortedMap()
            .mapNotNull { (number, contributions) ->
                val item = contributions.firstOrNull { it.queryText.isNotBlank() }
                    ?: return@mapNotNull null
                VisibleExpansionQuery(number, item.queryText.trim(), item.source)
            }
        val known = evidenced.mapTo(HashSet()) { it.text.lowercase() }
        val extras = buildList {
            for (query in questionAwareQueries) {
                val text = query.trim()
                if (text.isNotEmpty() && known.add(text.lowercase())) {
                    add(VisibleExpansionQuery(null, text, ResultQuerySource.QUESTION_AWARENESS))
                }
            }
            for (query in savedExpansions) {
                val text = query.trim()
                if (text.isNotEmpty() && known.add(text.lowercase())) {
                    add(VisibleExpansionQuery(null, text, null))
                }
            }
        }
        return evidenced + extras
    }
}
