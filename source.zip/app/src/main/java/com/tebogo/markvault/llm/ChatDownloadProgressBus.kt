package com.tebogo.markvault.llm

import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow

/**
 * v4.21.0 — Process-level progress bus for chat model downloads.
 *
 * Mirror of [com.tebogo.markvault.search.EmbeddingProgressBus] but for the
 * 530 MB chat-LLM download instead of the embedding pass.
 *
 * The foreground [ChatModelDownloadService] writes here; the
 * [com.tebogo.markvault.AppViewModel] reads from here; the Settings UI
 * observes through the VM. All three live in the same Android process so
 * a single in-memory StateFlow is sufficient — no need for IPC.
 *
 * Lifecycle in [progress] values:
 *   - `null`               — idle (no download running, or finished)
 *   - `(0, totalMb)`       — connecting / preparing
 *   - `(doneMb, totalMb)`  — actively downloading
 *
 * [isRunning] is the boolean shortcut UI uses to decide whether to show
 * the progress bar / Cancel button.
 *
 * [lastError] captures the most recent download failure (if any). The
 * Settings UI displays this until the user retries or dismisses, so they
 * know *why* the download failed rather than just seeing it stop.
 * Cleared on the next [start].
 */
object ChatDownloadProgressBus {

    private val _progress = MutableStateFlow<Pair<Int, Int>?>(null)
    val progress: StateFlow<Pair<Int, Int>?> = _progress

    private val _isRunning = MutableStateFlow(false)
    val isRunning: StateFlow<Boolean> = _isRunning

    private val _lastError = MutableStateFlow<String?>(null)
    val lastError: StateFlow<String?> = _lastError

    /** Called by the service when the download starts. */
    fun start() {
        _isRunning.value = true
        _progress.value = 0 to 0
        _lastError.value = null
    }

    /** Called as bytes stream in. */
    fun updateProgress(doneMb: Int, totalMb: Int) {
        _progress.value = doneMb to totalMb
    }

    /** Called by the service after a successful download. */
    fun complete() {
        _progress.value = null
        _isRunning.value = false
        _lastError.value = null
    }

    /** Called when the download fails. The error message persists for UI. */
    fun fail(message: String) {
        _progress.value = null
        _isRunning.value = false
        _lastError.value = message
    }

    /** Called on service tear-down without success (cancelled / killed). */
    fun idle() {
        _progress.value = null
        _isRunning.value = false
    }

    /** UI calls this to dismiss a stale error after the user has acknowledged it. */
    fun clearError() {
        _lastError.value = null
    }
}
