package com.tebogo.markvault.llm

import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow

/**
 * v5.4.72 — Process-level progress bus for chat model downloads.
 *
 * ## States
 *
 * ```
 *   IDLE         isRunning=false  isPaused=false  progress=null  lastError=null
 *   DOWNLOADING  isRunning=true   isPaused=false  progress=(x,y) lastError=null
 *   PAUSED       isRunning=false  isPaused=true   progress=(x,y) lastError=null
 *   FAILED       isRunning=false  isPaused=false  progress=null  lastError=msg
 *   INSTALLED    (bus stays IDLE; the model file is the source of truth)
 * ```
 *
 * ## Thread safety
 *
 * All StateFlows are backed by [MutableStateFlow] which is thread-safe. The
 * service, VM, and Compose observe from different threads; no extra locking
 * needed.
 */
object ChatDownloadProgressBus {

    private val _progress = MutableStateFlow<Pair<Int, Int>?>(null)
    val progress: StateFlow<Pair<Int, Int>?> = _progress

    private val _isRunning = MutableStateFlow(false)
    val isRunning: StateFlow<Boolean> = _isRunning

    /** True when the user explicitly paused a download in progress. */
    private val _isPaused = MutableStateFlow(false)
    val isPaused: StateFlow<Boolean> = _isPaused

    private val _lastError = MutableStateFlow<String?>(null)
    val lastError: StateFlow<String?> = _lastError

    /** Called by the service when a download (or resume) begins. */
    fun start() {
        _isPaused.value = false
        _isRunning.value = true
        _progress.value = 0 to 0
        _lastError.value = null
    }

    /** Called as bytes stream in. [doneMb] and [totalMb] are in megabytes. */
    fun updateProgress(doneMb: Int, totalMb: Int) {
        _progress.value = doneMb to totalMb
    }

    /** Called by the service after a successful download. */
    fun complete() {
        _isPaused.value = false
        _isRunning.value = false
        _progress.value = null
        _lastError.value = null
    }

    /**
     * Called when the user pauses the download. [doneMb] / [totalMb] are
     * preserved so the Settings UI can show "Paused at X / Y MB" and
     * display the progress bar at the right position.
     */
    fun pause(doneMb: Int, totalMb: Int) {
        _isRunning.value = false
        _isPaused.value = true
        _progress.value = doneMb to totalMb  // keep for display
        _lastError.value = null
    }

    /**
     * Called when the download fails. The error message persists for UI
     * display until the user retries or dismisses. The [progress] is
     * cleared because a failed download has no meaningful position to show.
     */
    fun fail(message: String) {
        _isPaused.value = false
        _isRunning.value = false
        _progress.value = null
        _lastError.value = message
    }

    /**
     * Called on service tear-down without success (user cancelled, system
     * killed). Resets everything including paused state — the caller is
     * responsible for calling [pause] instead if they want to retain the
     * paused state before calling [idle].
     */
    fun idle() {
        _isPaused.value = false
        _isRunning.value = false
        _progress.value = null
    }

    /** UI calls this to dismiss a stale error after the user has seen it. */
    fun clearError() {
        _lastError.value = null
    }
}
