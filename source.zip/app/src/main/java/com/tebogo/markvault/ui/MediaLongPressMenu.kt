package com.tebogo.markvault.ui

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.tebogo.markvault.AppViewModel
import com.tebogo.markvault.data.MediaItem

/**
 * v5.4.255cc — Long-press context menu for a single media item:
 * Favourite toggle + Add to Playlist. Meant to be triggered from
 * Modifier.combinedClickable's onLongClick wherever a media card
 * appears (MediaResultCard, MediaSearchCard) — "long press from all
 * interfaces where media appears."
 */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun MediaLongPressMenu(vm: AppViewModel, item: MediaItem, onDismiss: () -> Unit) {
    var showPlaylistPicker by remember { mutableStateOf(false) }

    ModalBottomSheet(onDismissRequest = onDismiss) {
        Column(modifier = Modifier.fillMaxWidth().padding(bottom = 24.dp)) {
            Text(
                item.title,
                fontWeight = FontWeight.Bold,
                fontSize = 14.sp,
                maxLines = 2,
                overflow = TextOverflow.Ellipsis,
                modifier = Modifier.padding(horizontal = 16.dp, vertical = 8.dp)
            )
            if (item.description.startsWith(com.tebogo.markvault.data.VideoTranscriptStore.RESULT_PREFIX)) {
                val trigger = item.description.substringAfter('\n', "").trim()
                if (trigger.isNotBlank()) {
                    Surface(
                        modifier = Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 8.dp),
                        color = MaterialTheme.colorScheme.primaryContainer,
                        shape = MaterialTheme.shapes.medium
                    ) {
                        Column(Modifier.padding(12.dp)) {
                            Text(
                                "Why this video matched",
                                fontSize = 12.sp,
                                fontWeight = FontWeight.Bold,
                                color = MaterialTheme.colorScheme.onPrimaryContainer
                            )
                            Spacer(Modifier.height(4.dp))
                            Text(
                                trigger,
                                fontSize = 13.sp,
                                color = MaterialTheme.colorScheme.onPrimaryContainer,
                                maxLines = 8,
                                overflow = TextOverflow.Ellipsis
                            )
                        }
                    }
                }
            }
            HorizontalDivider()
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .clickable {
                        vm.toggleMediaFavourite(item)
                        onDismiss()
                    }
                    .padding(16.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(if (item.isFavourite == 1) "\u2B50" else "\u2606", fontSize = 20.sp)
                Spacer(Modifier.width(14.dp))
                Text(
                    if (item.isFavourite == 1) "Remove from Favourites" else "Add to Favourites",
                    fontSize = 14.sp
                )
            }
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .clickable { showPlaylistPicker = true }
                    .padding(16.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text("\u2795", fontSize = 20.sp)
                Spacer(Modifier.width(14.dp))
                Text("Add to Playlist", fontSize = 14.sp)
            }
        }
    }

    if (showPlaylistPicker) {
        AddToPlaylistDialog(
            vm = vm,
            items = listOf(item),
            onDismiss = {
                showPlaylistPicker = false
                onDismiss()
            }
        )
    }
}

/**
 * v5.4.255cc — Pick an existing playlist (or create a new one) to add
 * [items] to. Shared by the single-item long-press menu above and
 * JwVideoBrowseScreen's multi-select "Add to Playlist" action.
 */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AddToPlaylistDialog(vm: AppViewModel, items: List<MediaItem>, onDismiss: () -> Unit) {
    val playlists by vm.playlists.collectAsStateWithLifecycle()
    var newName by remember { mutableStateOf("") }
    LaunchedEffect(Unit) { vm.loadPlaylists() }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Add to Playlist" + if (items.size > 1) " (${items.size})" else "") },
        text = {
            Column {
                if (playlists.isNotEmpty()) {
                    playlists.forEach { pl ->
                        Text(
                            pl.name,
                            fontSize = 14.sp,
                            modifier = Modifier
                                .fillMaxWidth()
                                .clickable {
                                    vm.addToPlaylist(pl.id, items)
                                    onDismiss()
                                }
                                .padding(vertical = 10.dp)
                        )
                    }
                    Spacer(Modifier.height(8.dp))
                    HorizontalDivider()
                    Spacer(Modifier.height(8.dp))
                } else {
                    Text(
                        "No playlists yet.",
                        fontSize = 13.sp,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                    Spacer(Modifier.height(8.dp))
                }
                OutlinedTextField(
                    value = newName,
                    onValueChange = { newName = it },
                    label = { Text("New playlist name") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )
            }
        },
        confirmButton = {
            TextButton(
                onClick = {
                    if (newName.isNotBlank()) {
                        vm.createPlaylist(newName.trim(), items)
                        onDismiss()
                    }
                },
                enabled = newName.isNotBlank()
            ) { Text("Create & Add") }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) { Text("Cancel") }
        }
    )
}
