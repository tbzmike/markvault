package com.tebogo.markvault.ui

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.navigation.NavController
import com.tebogo.markvault.AppViewModel
import com.tebogo.markvault.data.WebHistoryEntry
import java.net.URLEncoder
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/**
 * In-app browser history. Each entry shows in 3 lines: title, URL, then timestamp
 * in a distinct accent colour. Bolder dividers between entries make the list
 * easier to scan than the default M3 thin lines.
 */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun WebHistoryScreen(vm: AppViewModel, nav: NavController) {
    var entries by remember { mutableStateOf<List<WebHistoryEntry>>(emptyList()) }
    var loading by remember { mutableStateOf(true) }
    var confirmClear by remember { mutableStateOf(false) }
    var reloadCounter by remember { mutableStateOf(0) }

    LaunchedEffect(reloadCounter) {
        loading = true
        entries = vm.loadWebHistory(limit = 300)
        loading = false
    }

    Scaffold(
        topBar = { TopAppBar(title = { Text("\uD83D\uDD52 Web history") }) },
        bottomBar = {
            MarkVaultBottomBar(
                nav = nav, vm = vm,
                extraActions = {
                    if (entries.isNotEmpty()) {
                        IconButton(onClick = { confirmClear = true }) {
                            Icon(Icons.Default.Delete, contentDescription = "Clear all history")
                        }
                    }
                }
            )
        }
    ) { pad ->
        when {
            loading -> Box(Modifier.padding(pad).fillMaxSize(), contentAlignment = Alignment.Center) {
                Text("Loading\u2026", color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
            entries.isEmpty() -> Box(Modifier.padding(pad).fillMaxSize(), contentAlignment = Alignment.Center) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Text("\uD83D\uDD52", fontSize = 36.sp)
                    Spacer(Modifier.height(8.dp))
                    Text("No web pages visited yet.", color = MaterialTheme.colorScheme.onSurfaceVariant)
                    Text(
                        "Open a scripture link or a JW.org page in the\nin-app browser and it will appear here.",
                        textAlign = androidx.compose.ui.text.style.TextAlign.Center,
                        fontSize = 12.sp,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        modifier = Modifier.padding(top = 4.dp)
                    )
                }
            }
            else -> LazyColumn(Modifier.padding(pad).fillMaxSize()) {
                items(entries, key = { it.id }) { entry ->
                    WebHistoryRow(
                        entry = entry,
                        onTap = {
                            // v4.12.0 — register the URL via pendingWebOpen so
                            // the browser consumes it on next composition,
                            // bypassing the no-op ensureBrowserSession path
                            // that previously ate history taps when tabs
                            // already existed.
                            vm.requestWebOpen(
                                entry.url,
                                entry.title.ifBlank { entry.host }
                            )
                            val encUrl = URLEncoder.encode(entry.url, "UTF-8")
                            val encLabel = URLEncoder.encode(entry.title.ifBlank { entry.host }, "UTF-8")
                            nav.navigate("web/$encUrl/$encLabel")
                        },
                        onDelete = {
                            vm.deleteWebHistoryEntry(entry.id)
                            reloadCounter++
                        }
                    )
                    HistoryBoldDivider()
                }
                item { Spacer(Modifier.height(40.dp)) }
            }
        }
    }

    if (confirmClear) {
        AlertDialog(
            onDismissRequest = { confirmClear = false },
            title = { Text("Clear web history?") },
            text = { Text("This removes every entry from web history. Browser data on the device is not affected.") },
            confirmButton = {
                Button(onClick = {
                    vm.clearWebHistory()
                    confirmClear = false
                    reloadCounter++
                }) { Text("Clear all") }
            },
            dismissButton = { TextButton(onClick = { confirmClear = false }) { Text("Cancel") } }
        )
    }
}

@Composable
private fun WebHistoryRow(
    entry: WebHistoryEntry,
    onTap: () -> Unit,
    onDelete: () -> Unit
) {
    // v4.12.0 — richer details. Title • host (medium) • path (small, italic) •
    // timestamp (accent). Visit pathway is one line less ambiguous than
    // "title + host + when" alone.
    val pathSnippet = remember(entry.url) {
        runCatching {
            val u = java.net.URI(entry.url)
            buildString {
                u.rawPath?.takeIf { it.isNotEmpty() && it != "/" }?.let { append(it) }
                u.rawQuery?.let { append("?").append(it) }
            }
        }.getOrElse { "" }
    }
    Row(
        Modifier.fillMaxWidth().clickable { onTap() }
            .padding(horizontal = 18.dp, vertical = 12.dp),
        verticalAlignment = Alignment.Top
    ) {
        Text("\uD83C\uDF10", fontSize = 20.sp, modifier = Modifier.padding(top = 2.dp))
        Spacer(Modifier.width(12.dp))
        Column(Modifier.weight(1f)) {
            // Line 1: title
            Text(
                entry.title.ifBlank { entry.url },
                fontSize = 14.sp,
                fontWeight = FontWeight.SemiBold,
                maxLines = 2, overflow = TextOverflow.Ellipsis
            )
            Spacer(Modifier.height(2.dp))
            // Line 2: host
            Text(
                entry.host.ifBlank { entry.url },
                fontSize = 12.sp,
                fontWeight = FontWeight.Medium,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                maxLines = 1, overflow = TextOverflow.Ellipsis
            )
            // Line 3: URL path / query — only shown when there's anything
            // beyond the bare host, so single-page roots like "jw.org/" don't
            // get a pointless empty line.
            if (pathSnippet.isNotBlank()) {
                Spacer(Modifier.height(1.dp))
                Text(
                    pathSnippet,
                    fontSize = 10.sp,
                    fontStyle = androidx.compose.ui.text.font.FontStyle.Italic,
                    color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.75f),
                    maxLines = 2, overflow = TextOverflow.Ellipsis,
                    lineHeight = 13.sp
                )
            }
            Spacer(Modifier.height(4.dp))
            // Line 4: timestamp in accent colour
            Text(
                formatHistoryTime(entry.openedAt),
                fontSize = 11.sp,
                fontWeight = FontWeight.Medium,
                color = MaterialTheme.colorScheme.primary
            )
        }
        IconButton(onClick = onDelete, modifier = Modifier.size(36.dp)) {
            Icon(
                Icons.Default.Delete,
                contentDescription = "Remove",
                tint = MaterialTheme.colorScheme.onSurfaceVariant
            )
        }
    }
}

/**
 * A clearly visible divider between list rows.
 * v4.12.0 — bumped from 1.5 dp / outline-variant to 3 dp / primary 35 % so the
 * separation between search-result rows and history rows is obvious at a glance.
 */
@Composable
fun HistoryBoldDivider() {
    HorizontalDivider(
        thickness = 3.dp,
        color = MaterialTheme.colorScheme.primary.copy(alpha = 0.35f)
    )
}

/**
 * Multi-format relative + absolute timestamp.
 * Today/yesterday show time; older shows full date with time.
 */
fun formatHistoryTime(ts: Long): String {
    val now = System.currentTimeMillis()
    val diff = now - ts
    val mins = diff / 60_000
    val hours = mins / 60
    val days = hours / 24
    val timeOnly = SimpleDateFormat("HH:mm", Locale.getDefault()).format(Date(ts))
    return when {
        mins < 1 -> "just now"
        mins < 60 -> "$mins min ago \u00B7 $timeOnly"
        hours < 24 -> "today \u00B7 $timeOnly"
        days == 1L -> "yesterday \u00B7 $timeOnly"
        days < 7 -> "$days days ago \u00B7 $timeOnly"
        else -> SimpleDateFormat("d MMM yyyy \u00B7 HH:mm", Locale.getDefault()).format(Date(ts))
    }
}
