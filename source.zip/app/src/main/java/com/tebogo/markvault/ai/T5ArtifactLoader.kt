package com.tebogo.markvault.ai

import android.content.Context
import java.io.File

/** Final T5 artifact validation and loading bridge. */
class T5ArtifactLoader(private val context: Context) {

    private val modelDir: File
        get() = File(context.filesDir, "models/t5-base")

    fun verifyFiles(files: Set<String>): Boolean =
        T5ModelFileRegistry.missingFiles(files).isEmpty()

    /** Verifies files actually present on disk, not a caller-supplied set. */
    fun verifyInstalledFiles(): Boolean {
        val present = modelDir.listFiles()?.map { it.name }?.toSet() ?: emptySet()
        return verifyFiles(present)
    }

    fun loadTokenizer(): Boolean {
        val tokenizerFile = File(modelDir, T5ModelCatalog.TOKENIZER.fileName)
        val spieceFile = File(modelDir, T5ModelCatalog.SPIECE.fileName)
        if (!tokenizerFile.exists() || !spieceFile.exists()) return false
        return try {
            T5Tokenizer(context).load()
            true
        } catch (e: Exception) {
            false
        }
    }

    fun initializeInference(): Boolean {
        if (!verifyInstalledFiles()) return false
        return loadTokenizer()
    }
}
