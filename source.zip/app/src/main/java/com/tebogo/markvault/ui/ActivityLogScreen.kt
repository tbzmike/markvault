package com.tebogo.markvault.ui

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.widget.Toast
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.navigation.NavController
import com.tebogo.markvault.MarkVaultApp
import com.tebogo.markvault.data.ActivityLog

/**
 * v5.4.94cc — Activity log viewer.
 *
 * Renders every entry from [ActivityLog.entries] as a scrollable list,
 * newest-first, with filter chips across the top for the six categories
 * plus "All". Each entry has a copy button (drops the entry into the
 * clipboard). A "Clear" button in the top bar wipes both the in-memory
 * cache and the persistent file after a confirmation dialog.
 *
 * The design intentionally mirrors what the user would see if they
 * grepped the JSONL file directly, so the visual model matches the
 * on-disk representation: timestamp, category, message, key/value
 * metadata pairs.
 */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ActivityLogScreen(vm: com.tebogo.markvault.AppViewModel, nav: NavController) {
    val ctx = LocalContext.current
    val log = remember { (ctx.applicationContext as MarkVaultApp).activityLog }
    val entries by log.entries.collectAsState()

    var activeCategory by remember { mutableStateOf<ActivityLog.Category?>(null) }
    var showClearConfirm by remember { mutableStateOf(false) }

    val filtered = remember(entries, activeCategory) {
        if (activeCategory == null) entries
        else entries.filter { it.category == activeCategory }
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text("\uD83D\uDCCB Activity log", fontWeight = FontWeight.SemiBold)
                        Spacer(Modifier.width(8.dp))
                        Text(
                            "(${filtered.size})",
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                            fontSize = 14.sp
                        )
                    }
                },
                navigationIcon = {
                    IconButton(onClick = { nav.popBackStack() }) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back")
                    }
                },
                actions = {
                    if (filtered.isNotEmpty()) {
                        TextButton(onClick = { copyAll(ctx, filtered) }) {
                            Text("\uD83D\uDCCB Copy all", fontSize = 13.sp)
                        }
                    }
                    if (entries.isNotEmpty()) {
                        TextButton(onClick = { showClearConfirm = true }) {
                            Text(
                                "\uD83D\uDDD1\uFE0F Clear",
                                color = MaterialTheme.colorScheme.error,
                                fontSize = 13.sp
                            )
                        }
                    }
                }
            )
        }
    ) { pad ->
        Column(
            Modifier
                .padding(pad)
                .fillMaxSize()
        ) {
            // Filter chips row — horizontally scrollable so all 7 chips
            // ("All" + 6 categories) fit regardless of screen width.
            Row(
                Modifier
                    .fillMaxWidth()
                    .horizontalScroll(rememberScrollState())
                    .padding(horizontal = 12.dp, vertical = 8.dp),
                horizontalArrangement = Arrangement.spacedBy(8.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                FilterChip(
                    selected = activeCategory == null,
                    onClick = { activeCategory = null },
                    label = { Text("All ${entries.size}", fontSize = 12.sp) }
                )
                for (cat in ActivityLog.Category.values()) {
                    val count = entries.count { it.category == cat }
                    if (count == 0) continue
                    FilterChip(
                        selected = activeCategory == cat,
                        onClick = {
                            activeCategory = if (activeCategory == cat) null else cat
                        },
                        label = {
                            Text("${cat.emoji} ${cat.label} $count", fontSize = 12.sp)
                        },
                        colors = FilterChipDefaults.filterChipColors(
                            selectedContainerColor =
                                MaterialTheme.colorScheme.secondaryContainer
                        )
                    )
                }
            }

            HorizontalDivider()

            if (filtered.isEmpty()) {
                Box(
                    Modifier.fillMaxSize(),
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        "\uD83D\uDCED  No activity yet",
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        fontSize = 14.sp
                    )
                }
            } else {
                LazyColumn(
                    Modifier.fillMaxSize(),
                    contentPadding = androidx.compose.foundation.layout.PaddingValues(
                        vertical = 8.dp
                    )
                ) {
                    items(filtered, key = { it.timestamp.toString() + it.message }) { entry ->
                        LogEntryRow(
                            entry,
                            onUrlClick = { url ->
                                // Log URLs are link activations; honor the global
                                // WebViewer popup/full-screen presentation setting.
                                vm.requestWebPopup(url)
                            }
                        ) { copySingle(ctx, entry) }
                        HorizontalDivider(
                            color = MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.3f)
                        )
                    }
                }
            }
        }
    }

    if (showClearConfirm) {
        AlertDialog(
            onDismissRequest = { showClearConfirm = false },
            title = { Text("Clear activity log?") },
            text = {
                Text(
                    "Removes ${entries.size} entries. Cannot be undone.",
                    fontSize = 14.sp
                )
            },
            confirmButton = {
                TextButton(onClick = {
                    log.clear()
                    showClearConfirm = false
                    Toast.makeText(
                        ctx, "Activity log cleared", Toast.LENGTH_SHORT
                    ).show()
                }) {
                    Text(
                        "Clear",
                        color = MaterialTheme.colorScheme.error
                    )
                }
            },
            dismissButton = {
                TextButton(onClick = { showClearConfirm = false }) { Text("Cancel") }
            }
        )
    }
}

@Composable
private fun LogEntryRow(
    entry: ActivityLog.Entry,
    onUrlClick: (String) -> Unit,
    onCopy: () -> Unit
) {
    Row(
        Modifier
            .fillMaxWidth()
            .padding(horizontal = 16.dp, vertical = 10.dp),
        verticalAlignment = Alignment.Top
    ) {
        Column(Modifier.weight(1f)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(
                    entry.category.emoji,
                    fontSize = 14.sp
                )
                Spacer(Modifier.width(6.dp))
                Text(
                    entry.category.label,
                    fontSize = 11.sp,
                    fontWeight = FontWeight.SemiBold,
                    color = MaterialTheme.colorScheme.primary
                )
                Spacer(Modifier.width(10.dp))
                Text(
                    ActivityLog.FMT_LONG.format(java.util.Date(entry.timestamp)),
                    fontSize = 11.sp,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    fontFamily = FontFamily.Monospace
                )
            }
            Spacer(Modifier.size(4.dp))
            Text(
                entry.message,
                fontSize = 14.sp,
                color = MaterialTheme.colorScheme.onSurface
            )
            if (entry.metadata.isNotEmpty()) {
                Spacer(Modifier.size(4.dp))
                for ((k, v) in entry.metadata) {
                    // v5.4.113cc — If the metadata value is a URL, render
                    // it as a full clickable link (opens in WebViewer)
                    // so the user can verify dupe-skip URLs. Non-URL
                    // values render as before.
                    val isUrl = v.startsWith("http://") || v.startsWith("https://")
                    Row(Modifier.padding(top = 2.dp)) {
                        Text(
                            "$k",
                            fontSize = 11.sp,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                            fontFamily = FontFamily.Monospace,
                            fontWeight = FontWeight.Medium
                        )
                        Text(" · ", fontSize = 11.sp,
                            color = MaterialTheme.colorScheme.onSurfaceVariant)
                        if (isUrl) {
                            Text(
                                v,
                                fontSize = 11.sp,
                                color = androidx.compose.ui.graphics.Color(0xFF1565C0),
                                fontFamily = FontFamily.Monospace,
                                textDecoration = androidx.compose.ui.text.style
                                    .TextDecoration.Underline,
                                modifier = Modifier.clickable { onUrlClick(v) }
                            )
                        } else {
                            Text(
                                v,
                                fontSize = 11.sp,
                                color = MaterialTheme.colorScheme.onSurface,
                                fontFamily = FontFamily.Monospace
                            )
                        }
                    }
                }
            }
        }
        IconButton(onClick = onCopy, modifier = Modifier.size(32.dp)) {
            Text("\uD83D\uDCCB", fontSize = 14.sp)
        }
    }
}

private fun copySingle(ctx: Context, entry: ActivityLog.Entry) {
    val cm = ctx.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
    cm.setPrimaryClip(
        ClipData.newPlainText("MarkVault log entry", entry.formatCopy())
    )
    Toast.makeText(ctx, "Copied", Toast.LENGTH_SHORT).show()
}

private fun copyAll(ctx: Context, entries: List<ActivityLog.Entry>) {
    val cm = ctx.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
    val sb = StringBuilder()
    sb.append("MarkVault activity log — ")
        .append(entries.size).append(" entries\n\n")
    for (e in entries) sb.append(e.formatCopy()).append('\n')
    cm.setPrimaryClip(ClipData.newPlainText("MarkVault activity log", sb.toString()))
    Toast.makeText(
        ctx, "Copied ${entries.size} entries", Toast.LENGTH_SHORT
    ).show()
}
