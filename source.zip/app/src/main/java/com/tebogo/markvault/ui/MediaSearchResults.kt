package com.tebogo.markvault.ui

import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.background
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import com.tebogo.markvault.data.MediaItem

/**
 * v5.4.251cc — Compact media result surfaces for MarkVault's main
 * (note-text) search screen.
 *
 * Deliberately a SEPARATE, self-contained file rather than adding ~150
 * lines inline into SearchScreen.kt (already 3000+ lines) or editing
 * MediaResultCard.kt (the row-style card JwVideoBrowseScreen already uses
 * and relies on unchanged) — isolating this addition means it cannot
 * regress either of those already-verified files.
 *
 * Two presentations of the SAME compact card, per the requested design:
 *   • [MediaSearchCarousel]  — horizontal LazyRow, appears BELOW the note
 *     search results (phone + tablet).
 *   • [MediaSearchSidePanel] — thin vertical LazyColumn, appears NEXT TO
 *     the search results (tablet width only — mirrors the existing
 *     SearchTabletRecentsPanel pattern already in SearchScreen.kt, just on
 *     the opposite side and much narrower).
 * Tapping either calls the same onItemClick — SearchScreen wires this to
 * vm.requestMediaPopup(item), which starts playback AND opens the already-
 * existing FloatingMediaPopup (movable, maximizable, back-closes it —
 * unchanged, nothing about that component needed modification).
 */

/** Format ms → "12 Aug" (short form — these cards are narrow). */
private fun formatMediaSearchDate(ms: Long): String {
    if (ms <= 0) return ""
    return runCatching {
        java.time.Instant.ofEpochMilli(ms)
            .atZone(java.time.ZoneId.systemDefault())
            .toLocalDate()
            .format(java.time.format.DateTimeFormatter.ofPattern("d MMM"))
    }.getOrDefault("")
}

/**
 * v5.4.253cc — No longer private: reused by HomeScreen's "Recently
 * Played"/"Recently Searched" sections when the user's existing
 * horizontal/vertical home-layout preference (vm.homeScrollVertical,
 * the same one Favourites/Suggested already respect) is set to
 * horizontal — one card design, not a duplicate built for HomeScreen.
 *
 * v5.4.255cc — onLongPress, nullable-default, same pattern as
 * MediaResultCard's — screens wire this to MediaLongPressMenu.
 */
@OptIn(ExperimentalFoundationApi::class)
@Composable
fun MediaSearchCard(
    item: MediaItem,
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
    onLongPress: (() -> Unit)? = null
) {
    Card(
        modifier = modifier.combinedClickable(onClick = onClick, onLongClick = onLongPress),
        shape = RoundedCornerShape(10.dp),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
    ) {
        Column {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .aspectRatio(16f / 9f)
            ) {
                if (item.thumbnailUrl.isNotBlank()) {
                    AsyncImage(
                        model = item.thumbnailUrl,
                        contentDescription = null,
                        contentScale = ContentScale.Crop,
                        modifier = Modifier.fillMaxSize()
                    )
                } else {
                    Box(
                        modifier = Modifier
                            .fillMaxSize()
                            .background(MaterialTheme.colorScheme.surfaceVariant),
                        contentAlignment = Alignment.Center
                    ) {
                        Text(if (item.mediaType == "audio") "\uD83C\uDFB5" else "\uD83C\uDFAC", fontSize = 22.sp)
                    }
                }
                // Type badge, bottom-left corner overlay.
                Surface(
                    color = Color.Black.copy(alpha = 0.55f),
                    shape = RoundedCornerShape(4.dp),
                    modifier = Modifier
                        .align(Alignment.BottomStart)
                        .padding(4.dp)
                ) {
                    Text(
                        if (item.mediaType == "audio") "\uD83C\uDFB5" else "\u25B6",
                        color = Color.White,
                        fontSize = 10.sp,
                        modifier = Modifier.padding(horizontal = 4.dp, vertical = 1.dp)
                    )
                }
            }
            Column(modifier = Modifier.padding(6.dp)) {
                Text(
                    item.title,
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Medium,
                    maxLines = 2,
                    overflow = TextOverflow.Ellipsis,
                    lineHeight = 13.sp
                )
                // v5.4.251cc — Upload date on every media card, including
                // these new search-screen surfaces, per the "all media
                // must have upload date" requirement. Shares the same
                // MediaItem.uploadDate field JwMediaApi already parses
                // and MediaResultCard already displays elsewhere.
                val dateLabel = formatMediaSearchDate(item.uploadDate)
                if (dateLabel.isNotBlank()) {
                    Text(
                        dateLabel,
                        fontSize = 9.sp,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
                if (item.description.startsWith(com.tebogo.markvault.data.VideoTranscriptStore.RESULT_PREFIX)) {
                    Spacer(Modifier.height(3.dp))
                    Text(
                        item.description.substringBefore('\n'),
                        fontSize = 9.sp,
                        fontWeight = FontWeight.SemiBold,
                        color = MaterialTheme.colorScheme.primary,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                    item.description.substringAfter('\n', "").takeIf { it.isNotBlank() }?.let { snippet ->
                        Text(
                            snippet,
                            fontSize = 9.sp,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                            maxLines = 2,
                            overflow = TextOverflow.Ellipsis,
                            lineHeight = 11.sp
                        )
                    }
                }
            }
        }
    }
}

/**
 * Horizontal carousel — one row, scrolls sideways. Sits as the final item
 * in SearchScreen's main results LazyColumn, below the note-text results.
 */
@Composable
fun MediaSearchCarousel(
    items: List<MediaItem>,
    onItemClick: (MediaItem) -> Unit,
    modifier: Modifier = Modifier,
    onItemLongPress: ((MediaItem) -> Unit)? = null
) {
    if (items.isEmpty()) return
    Column(modifier = modifier.fillMaxWidth().padding(top = 8.dp)) {
        Text(
            "\uD83C\uDFAC Media (${items.size})",
            fontWeight = FontWeight.Bold,
            fontSize = 12.sp,
            modifier = Modifier.padding(horizontal = 16.dp, vertical = 6.dp)
        )
        LazyRow(
            horizontalArrangement = Arrangement.spacedBy(8.dp),
            contentPadding = PaddingValues(horizontal = 14.dp)
        ) {
            items(items, key = { it.jwKey.ifBlank { it.title } }) { media ->
                MediaSearchCard(
                    item = media,
                    onClick = { onItemClick(media) },
                    onLongPress = if (onItemLongPress != null) {
                        { onItemLongPress(media) }
                    } else null,
                    modifier = Modifier.width(130.dp)
                )
            }
        }
    }
}

/**
 * Thin vertical panel — sits as a third column to the right of the main
 * results, tablet width only. Mirrors SearchTabletRecentsPanel's pattern
 * (which occupies the equivalent position on the LEFT) but much narrower,
 * per "thinner window next to the search results."
 */
@Composable
fun MediaSearchSidePanel(
    items: List<MediaItem>,
    onItemClick: (MediaItem) -> Unit,
    modifier: Modifier = Modifier,
    onItemLongPress: ((MediaItem) -> Unit)? = null
) {
    Column(modifier = modifier.padding(horizontal = 6.dp)) {
        Text(
            "\uD83C\uDFAC Media (${items.size})",
            fontWeight = FontWeight.Bold,
            fontSize = 12.sp,
            modifier = Modifier.padding(vertical = 8.dp)
        )
        LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp)) {
            items(items, key = { it.jwKey.ifBlank { it.title } }) { media ->
                MediaSearchCard(
                    item = media,
                    onClick = { onItemClick(media) },
                    onLongPress = if (onItemLongPress != null) {
                        { onItemLongPress(media) }
                    } else null,
                    modifier = Modifier.fillMaxWidth()
                )
            }
        }
    }
}
