package com.tebogo.markvault.ui

import com.tebogo.markvault.data.SearchHit

/** The existing keyword filter and token preparation, computed when their inputs change. */
data class SearchResultPresentation(
    val highlightTokens: List<String>,
    val llmHighlightTokens: List<String>,
    val filteredResults: List<SearchHit>,
    val hiddenCount: Int
)

fun searchResultPresentation(
    query: String,
    results: List<SearchHit>,
    keywordFilterOn: Boolean,
    paraphrases: List<String>
): SearchResultPresentation {
    val cleanedQuery = query.removeSurrounding("\"").trim()
    val highlightTokens = cleanedQuery.split(Regex("\\s+"))
        .map { it.trim() }.filter { it.isNotEmpty() }.take(6)
    val llmHighlightTokens = paraphrases
        .flatMap { it.split(Regex("\\s+")) }
        .map { it.trim() }
        .filter { it.length >= 3 }
        .distinctBy { it.lowercase() }
        .take(24)
    val filterTokens = highlightTokens
        .map { it.lowercase().replace(Regex("[^\\p{L}\\p{N}]"), "") }
        .filter { it.isNotEmpty() }
    val bigrams = if (filterTokens.size >= 2) {
        (0 until filterTokens.size - 1).map { i -> "${filterTokens[i]} ${filterTokens[i + 1]}" }
    } else emptyList()
    val filteredResults = if (!keywordFilterOn || bigrams.isEmpty()) {
        results
    } else {
        results.filter { hit ->
            val haystack = (hit.title + " " + hit.snippet)
                .replace("\u27E6", "")
                .replace("\u27E7", "")
                .lowercase()
            bigrams.any { bg -> haystack.contains(bg) }
        }
    }
    return SearchResultPresentation(
        highlightTokens, llmHighlightTokens, filteredResults, results.size - filteredResults.size
    )
}
