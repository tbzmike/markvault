package com.tebogo.markvault.ui

import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.tebogo.markvault.AppViewModel
import com.tebogo.markvault.OfflineHtmlSavePhase

/**
 * v5.5.7 — Visible in-app feedback for single-page WebViewer saves.
 * The old flow stayed visually silent until the final Toast.
 */
@Composable
internal fun OfflineHtmlSaveProgress(
    vm: AppViewModel,
    modifier: Modifier = Modifier
) {
    val state by vm.offlineHtmlSaveState.collectAsStateWithLifecycle()
    if (state.phase == OfflineHtmlSavePhase.IDLE) return

    Surface(
        modifier = modifier,
        shape = androidx.compose.foundation.shape.RoundedCornerShape(14.dp),
        tonalElevation = 6.dp,
        shadowElevation = 4.dp
    ) {
        Column(
            Modifier
                .fillMaxWidth()
                .padding(horizontal = 14.dp, vertical = 10.dp)
        ) {
            val heading = when (state.phase) {
                OfflineHtmlSavePhase.SUCCESS -> "💾 Offline HTML saved"
                OfflineHtmlSavePhase.ERROR -> "⚠️ Offline HTML save failed"
                OfflineHtmlSavePhase.INDEXING -> "🗂️ Indexing saved article"
                OfflineHtmlSavePhase.WRITING -> "💾 Writing offline HTML"
                else -> "💾 Saving offline HTML"
            }
            Text(
                heading,
                fontWeight = FontWeight.Bold,
                fontSize = 13.sp,
                color = MaterialTheme.colorScheme.onSurface
            )
            if (state.message.isNotBlank()) {
                Text(
                    state.message,
                    fontSize = 12.sp,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    maxLines = 2,
                    overflow = TextOverflow.Ellipsis,
                    modifier = Modifier.padding(top = 2.dp)
                )
            }
            if (state.running) {
                if (state.total > 0) {
                    LinearProgressIndicator(
                        progress = { (state.done.toFloat() / state.total.toFloat()).coerceIn(0f, 1f) },
                        modifier = Modifier.fillMaxWidth().padding(top = 7.dp)
                    )
                } else {
                    LinearProgressIndicator(
                        modifier = Modifier.fillMaxWidth().padding(top = 7.dp)
                    )
                }
            }
        }
    }
}
