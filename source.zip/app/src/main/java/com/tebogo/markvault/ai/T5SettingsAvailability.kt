package com.tebogo.markvault.ai

/** Connects model readiness to feature availability. */
object T5SettingsAvailability {
    fun canEnable(): Boolean = T5InstallState.isReady()
}
