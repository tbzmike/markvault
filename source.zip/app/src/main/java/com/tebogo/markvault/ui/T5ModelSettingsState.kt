package com.tebogo.markvault.ui

/** Display state for the T5 model settings screen. */
data class T5ModelSettingsState(
    val available: Boolean = true,
    val installed: Boolean = false,
    val downloading: Boolean = false,
    val progress: Int = 0
)
