package com.tebogo.markvault.ai

/**
 * Dedicated AI Search coordinator. Keeps AI enhancement isolated from UI/ViewModel.
 */
class AiSearchService {
    fun enhance(query: String, enabled: Boolean): List<String> {
        if (!enabled) return listOf(query)
        return AiSearchAssistant.expand(query).distinct()
    }
}
