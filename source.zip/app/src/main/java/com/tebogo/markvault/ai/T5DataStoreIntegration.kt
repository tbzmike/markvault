package com.tebogo.markvault.ai

/** Persistent preference integration bridge. */
object T5DataStoreIntegration {
    private var storedMode = T5ExpansionMode.BUILTIN

    fun saveMode(mode: T5ExpansionMode) { storedMode = mode }
    fun loadMode(): T5ExpansionMode = storedMode
}
