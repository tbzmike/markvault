package com.tebogo.markvault.ui

import android.annotation.SuppressLint
import android.net.Uri
import android.view.ViewGroup
import android.webkit.RenderProcessGoneDetail
import android.webkit.WebResourceRequest
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.material3.Button
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.navigation.NavController
import com.tebogo.markvault.AppViewModel
import com.tebogo.markvault.util.MhtmlParser
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

/**
 * Renders saved offline web archives (`.html`, `.htm`, `.mhtml`, `.mht`) in a
 * crash-hardened WebView.
 *
 * v4.5 changes vs v4.4.3:
 *   1. MHTML is parsed in PURE KOTLIN by MhtmlParser before reaching the WebView.
 *      The WebView's native MHTML parser (which lives in JNI code and can take
 *      the renderer process down on bad input) is never invoked.
 *   2. onRenderProcessGone is implemented — if the renderer crashes anyway, we
 *      catch it cleanly instead of taking the app down.
 *   3. External-open fallback button is always visible in the toolbar.
 *   4. Link taps still route to the in-app WebViewer.
 */
@Composable
fun HtmlReaderScreen(
    vm: AppViewModel,
    nav: NavController,
    id: Long
) {
    val ctx = LocalContext.current
    val theme by vm.theme.collectAsState()

    var title by remember { mutableStateOf("Offline page") }
    var htmlContent by remember { mutableStateOf<String?>(null) }
    var baseUrl by remember { mutableStateOf<String?>(null) }
    var rendererCrashed by remember { mutableStateOf(false) }
    var loadError by remember { mutableStateOf<String?>(null) }
    var originalUri by remember { mutableStateOf<Uri?>(null) }
    var htmlLoaded by remember { mutableStateOf(false) }

    LaunchedEffect(id) {
        val note = withContext(Dispatchers.IO) { vm.loadNote(id) }
        if (note == null) {
            loadError = "Could not load the file from the library."
            return@LaunchedEffect
        }
        title = note.title.ifBlank { note.name }
        originalUri = runCatching { Uri.parse(note.uri) }.getOrNull()

        val bytes = withContext(Dispatchers.IO) {
            runCatching {
                ctx.contentResolver.openInputStream(Uri.parse(note.uri))?.use {
                    it.readBytes()
                }
            }.getOrNull()
        }
        if (bytes == null) {
            loadError = "Could not read the file. The library folder may have been moved."
            return@LaunchedEffect
        }

        val nameLower = note.name.lowercase()
        val isMhtml = nameLower.endsWith(".mhtml") || nameLower.endsWith(".mht")

        if (isMhtml) {
            // Kotlin-side MHTML parse — fully sidesteps WebView's native MHTML
            // path. By the time the WebView sees content it is plain HTML, so
            // it can no longer crash on bad MIME framing.
            val parsed = withContext(Dispatchers.IO) {
                MhtmlParser.extractHtmlContent(bytes)
            }
            if (parsed == null) {
                loadError = "This MHTML file is malformed. Try opening it externally."
                return@LaunchedEffect
            }
            htmlContent = parsed
            baseUrl = withContext(Dispatchers.IO) { MhtmlParser.extractBaseUrl(bytes) }
        } else {
            htmlContent = try {
                String(bytes, Charsets.UTF_8)
            } catch (_: Exception) {
                String(bytes)
            }
        }

        vm.openArticle(id, title, fileType = note.fileType)
    }

    Column(Modifier.fillMaxSize()) {
        Surface(
            modifier = Modifier.fillMaxWidth(),
            color = MaterialTheme.colorScheme.surfaceVariant
        ) {
            Text(
                "\uD83C\uDF10  $title",
                modifier = Modifier.padding(horizontal = 16.dp, vertical = 10.dp),
                fontSize = 14.sp,
                maxLines = 1
            )
        }

        when {
            loadError != null || rendererCrashed -> ErrorPane(
                message = loadError ?: "The page renderer crashed.",
                onOpenExternally = {
                    originalUri?.let { uri ->
                        runCatching {
                            ctx.startActivity(
                                android.content.Intent(
                                    android.content.Intent.ACTION_VIEW, uri
                                ).addFlags(android.content.Intent.FLAG_GRANT_READ_URI_PERMISSION)
                            )
                        }
                    }
                },
                onRetry = {
                    rendererCrashed = false
                    loadError = null
                    htmlLoaded = false
                }
            )

            htmlContent != null -> AndroidView(
                modifier = Modifier.fillMaxWidth().weight(1f),
                factory = { context ->
                    @SuppressLint("SetJavaScriptEnabled")
                    SelectionWebView(context).apply {
                        layoutParams = ViewGroup.LayoutParams(
                            ViewGroup.LayoutParams.MATCH_PARENT,
                            ViewGroup.LayoutParams.MATCH_PARENT
                        )
                        settings.javaScriptEnabled = true
                        settings.domStorageEnabled = true
                        settings.useWideViewPort = true
                        settings.loadWithOverviewMode = true
                        settings.builtInZoomControls = true
                        settings.displayZoomControls = false
                        settings.mixedContentMode = WebSettings.MIXED_CONTENT_COMPATIBILITY_MODE

                        webViewClient = object : WebViewClient() {
                            override fun shouldOverrideUrlLoading(
                                view: WebView?, request: WebResourceRequest?
                            ): Boolean {
                                val u = request?.url ?: return false
                                if (u.scheme == "data" || u.scheme == "cid" ||
                                    u.scheme == "file" || u.scheme == "blob" ||
                                    u.scheme == "about") return false
                                val encUrl = java.net.URLEncoder.encode(u.toString(), "UTF-8")
                                val encLabel = java.net.URLEncoder.encode(
                                    u.host ?: "Link", "UTF-8"
                                )
                                nav.navigate("web/$encUrl/$encLabel") {
                                    launchSingleTop = true
                                }
                                return true
                            }

                            override fun onRenderProcessGone(
                                view: WebView?, detail: RenderProcessGoneDetail?
                            ): Boolean {
                                // CRITICAL — return true so Android does NOT
                                // kill the whole app process. The previous
                                // versions had no handler, so a renderer crash
                                // on a tricky MHTML cascaded into the app
                                // crashing. Now we just show the error pane.
                                rendererCrashed = true
                                runCatching { view?.destroy() }
                                return true
                            }
                        }

                        onSearchInMarkVault = { text ->
                            vm.requestPendingSearch(text)
                            nav.navigate("search") { launchSingleTop = true }
                        }
                        onSearchInWol = { text ->
                            val target = "https://wol.jw.org/en/wol/s/r1/lp-e?q=" +
                                java.net.URLEncoder.encode(text, "UTF-8")
                            vm.requestWebPopup(target)
                        }
                    }
                },
                update = { w ->
                    val html = htmlContent ?: return@AndroidView
                    if (!htmlLoaded) {
                        runCatching {
                            w.loadDataWithBaseURL(
                                baseUrl ?: "about:blank",
                                html,
                                "text/html",
                                "utf-8",
                                null
                            )
                        }
                        htmlLoaded = true
                    }
                }
            )
        }

        MarkVaultBottomBar(
            nav = nav,
            vm = vm,
            extraActions = {
                androidx.compose.material3.IconButton(onClick = {
                    originalUri?.let { uri ->
                        runCatching {
                            ctx.startActivity(
                                android.content.Intent(
                                    android.content.Intent.ACTION_VIEW, uri
                                ).addFlags(android.content.Intent.FLAG_GRANT_READ_URI_PERMISSION)
                            )
                        }
                    }
                }) {
                    Text("\u2197", fontSize = 18.sp)
                }
            }
        )
    }
}

@Composable
private fun ErrorPane(
    message: String,
    onOpenExternally: () -> Unit,
    onRetry: () -> Unit
) {
    Column(
        Modifier.fillMaxSize().padding(24.dp),
        verticalArrangement = Arrangement.Center,
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Text("\u26A0\uFE0F", fontSize = 32.sp)
        Spacer(Modifier.size(14.dp))
        Text(
            "Couldn't display this page",
            fontSize = 17.sp,
            fontWeight = androidx.compose.ui.text.font.FontWeight.SemiBold
        )
        Spacer(Modifier.size(8.dp))
        Text(
            message,
            fontSize = 13.sp,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
            textAlign = androidx.compose.ui.text.style.TextAlign.Center
        )
        Spacer(Modifier.size(24.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            androidx.compose.material3.OutlinedButton(onClick = onRetry) {
                Text("Retry")
            }
            Button(onClick = onOpenExternally) {
                Text("Open externally")
            }
        }
    }
}
