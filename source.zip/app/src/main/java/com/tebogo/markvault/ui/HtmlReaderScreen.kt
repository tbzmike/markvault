package com.tebogo.markvault.ui

import android.annotation.SuppressLint
import android.net.Uri
import android.view.ViewGroup
import android.webkit.RenderProcessGoneDetail
import android.webkit.WebResourceRequest
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.KeyboardArrowDown
import androidx.compose.material.icons.filled.KeyboardArrowUp
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.Button
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.navigation.NavController
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.tebogo.markvault.AppViewModel
import com.tebogo.markvault.util.MhtmlParser
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.filled.Add

/** v5.4.23 — File-level so items()'s generic inference resolves cleanly. */
private data class HtmlHeading(val index: Int, val level: Int, val text: String)

/**
 * Reader for offline web archives — full feature parity with markdown reader:
 *   • Find-in-page with prev/next nav (Ctrl+F equivalent)
 *   • Search-result highlight injection (pendingHighlight from VM)
 *   • Open externally fallback
 *   • Crash-hardened (renderer recovery)
 *   • Comprehensive bottom toolbar with all standard actions
 *   • Link taps route to in-app browser
 *
 * v4.6 changes from v4.5:
 *   1. Find-in-page UI added (WebView.findAllAsync + findNext).
 *   2. Pending highlight from Search screen now flashes in the WebView via
 *      injected JavaScript wrapping matches in <mark> spans.
 *   3. Toolbar now mirrors the markdown reader's button density.
 */
@Composable
fun HtmlReaderScreen(
    vm: AppViewModel,
    nav: NavController,
    id: Long
) {
    val ctx = LocalContext.current
    val theme by vm.theme.collectAsState()

    var title by remember { mutableStateOf("Offline page") }
    var htmlContent by remember { mutableStateOf<String?>(null) }
    var baseUrl by remember { mutableStateOf<String?>(null) }
    var rendererCrashed by remember { mutableStateOf(false) }
    var loadError by remember { mutableStateOf<String?>(null) }
    var originalUri by remember { mutableStateOf<Uri?>(null) }
    var htmlLoaded by remember { mutableStateOf(false) }

    // Find-in-page state — mirrors WebSearchScreen's pattern.
    var findOpen by remember { mutableStateOf(false) }
    var findQuery by remember { mutableStateOf("") }
    var webViewRef by remember { mutableStateOf<WebView?>(null) }

    LaunchedEffect(id) {
        val note = withContext(Dispatchers.IO) { vm.loadNote(id) }
        if (note == null) {
            loadError = "Could not load the file from the library."
            return@LaunchedEffect
        }
        title = note.title.ifBlank { note.name }
        originalUri = runCatching { Uri.parse(note.uri) }.getOrNull()

        val bytes = withContext(Dispatchers.IO) {
            runCatching {
                ctx.contentResolver.openInputStream(Uri.parse(note.uri))?.use {
                    it.readBytes()
                }
            }.getOrNull()
        }
        if (bytes == null) {
            loadError = "Could not read the file. The library folder may have been moved."
            return@LaunchedEffect
        }

        val nameLower = note.name.lowercase()
        val isMhtml = nameLower.endsWith(".mhtml") || nameLower.endsWith(".mht")

        if (isMhtml) {
            val parsed = withContext(Dispatchers.IO) {
                MhtmlParser.extractHtmlContent(bytes)
            }
            if (parsed == null) {
                loadError = "This MHTML file is malformed. Try opening it externally."
                return@LaunchedEffect
            }
            htmlContent = parsed
            baseUrl = withContext(Dispatchers.IO) { MhtmlParser.extractBaseUrl(bytes) }
        } else {
            htmlContent = try {
                String(bytes, Charsets.UTF_8)
            } catch (_: Exception) {
                String(bytes)
            }
        }

        vm.openArticle(id, title, fileType = note.fileType)
    }

    // v5.4.19 — Find-in-article FAB. HtmlReaderScreen uses a Column, not
    // a Scaffold, so we wrap the whole thing in a Box and overlay the
    // FAB at the bottom-end. HTML-file reading uses the keyword branch
    // only — HTML doesn't split cleanly on paragraph boundaries, so
    // semantic-in-article isn't wired here.
    val fabEnabled by vm.searchInArticleFab.collectAsStateWithLifecycle()
    val currentSearchQuery by vm.query.collectAsStateWithLifecycle()
    val openedFromSearchLatched by androidx.compose.runtime.produceState(
        initialValue = false, key1 = id
    ) {
        value = vm.openedFromSearch.value
        vm.clearOpenedFromSearch()
    }
    val fabVisible = openedFromSearchLatched && fabEnabled &&
        currentSearchQuery.trim().removeSurrounding("\"").length >= 2

    // v5.4.23 — Workspace mode + tablet 3-column overlay for HTML files.
    // Same trigger rules as ReaderScreen: workspace ON + width ≥ 600dp.
    // Left panel = tabs list (matches ReaderScreen exactly). Right
    // panel = outline from the HTML document's h1-h6 tags.
    val uiMode by vm.uiMode.collectAsStateWithLifecycle()
    val workspaceOn = uiMode == "workspace"
    val screenWidthDp = androidx.compose.ui.platform.LocalConfiguration.current.screenWidthDp
    val isTabletWidth = screenWidthDp >= 600
    val threeColumn = workspaceOn && isTabletWidth
    val leftColWidth = 240.dp
    val rightColWidth = 220.dp
    val tabs by vm.tabs.collectAsStateWithLifecycle()
    val activeTab by vm.activeTab.collectAsStateWithLifecycle()

    // Extract HTML headings once per document. Match <h1>-<h6> with any
    // attributes, strip inner tags for display text, and preserve the
    // index-in-document order so we can scroll to the Nth heading via
    // querySelectorAll('h1,h2,...')[N] regardless of the HTML's own IDs.
    // v5.4.23 hotfix — htmlContent is String? — smart-cast via a local.
    val htmlHeadings = remember(htmlContent) {
        val body = htmlContent
        if (body.isNullOrBlank()) emptyList()
        else {
            val pattern = Regex(
                "<h([1-6])[^>]*>(.*?)</h[1-6]>",
                setOf(RegexOption.IGNORE_CASE, RegexOption.DOT_MATCHES_ALL)
            )
            pattern.findAll(body).mapIndexed { idx, m ->
                val level = m.groupValues[1].toInt()
                val text = m.groupValues[2]
                    .replace(Regex("<[^>]+>"), "")
                    .replace(Regex("\\s+"), " ")
                    .trim()
                HtmlHeading(idx, level, text)
            }.filter { it.text.isNotBlank() }.toList()
        }
    }

    Box(Modifier.fillMaxSize()) {
    Box(
        Modifier
            .padding(
                start = if (threeColumn) leftColWidth else 0.dp,
                end = if (threeColumn) rightColWidth else 0.dp
            )
            .fillMaxSize()
    ) {
    Column(Modifier.fillMaxSize()) {
        // Title strip
        Surface(
            modifier = Modifier.fillMaxWidth(),
            color = MaterialTheme.colorScheme.surfaceVariant
        ) {
            Text(
                "\uD83C\uDF10  $title",
                modifier = Modifier.padding(horizontal = 16.dp, vertical = 10.dp),
                fontSize = 14.sp,
                maxLines = 1
            )
        }

        // Find-in-page bar (slides in when find button tapped)
        if (findOpen) {
            FindInPageBar(
                query = findQuery,
                onQueryChange = {
                    findQuery = it
                    webViewRef?.findAllAsync(it)
                },
                onNext = { webViewRef?.findNext(true) },
                onPrev = { webViewRef?.findNext(false) },
                onClose = {
                    findOpen = false
                    webViewRef?.clearMatches()
                }
            )
        }

        // Body
        Box(modifier = Modifier.fillMaxWidth().weight(1f)) {
            when {
                loadError != null || rendererCrashed -> ErrorPane(
                    message = loadError ?: "The page renderer crashed.",
                    onOpenExternally = {
                        originalUri?.let { uri ->
                            runCatching {
                                ctx.startActivity(
                                    android.content.Intent(
                                        android.content.Intent.ACTION_VIEW, uri
                                    ).addFlags(
                                        android.content.Intent.FLAG_GRANT_READ_URI_PERMISSION
                                    )
                                )
                            }
                        }
                    },
                    onRetry = {
                        rendererCrashed = false
                        loadError = null
                        htmlLoaded = false
                    }
                )

                htmlContent != null -> AndroidView(
                    modifier = Modifier.fillMaxSize(),
                    factory = { context ->
                        @SuppressLint("SetJavaScriptEnabled")
                        SelectionWebView(context).apply {
                            layoutParams = ViewGroup.LayoutParams(
                                ViewGroup.LayoutParams.MATCH_PARENT,
                                ViewGroup.LayoutParams.MATCH_PARENT
                            )
                            settings.javaScriptEnabled = true
                            settings.domStorageEnabled = true
                            settings.useWideViewPort = true
                            settings.loadWithOverviewMode = true
                            settings.builtInZoomControls = true
                            settings.displayZoomControls = false
                            settings.mixedContentMode =
                                WebSettings.MIXED_CONTENT_COMPATIBILITY_MODE

                            webViewClient = object : WebViewClient() {
                                override fun shouldOverrideUrlLoading(
                                    view: WebView?, request: WebResourceRequest?
                                ): Boolean {
                                    val u = request?.url ?: return false
                                    if (u.scheme == "data" || u.scheme == "cid" ||
                                        u.scheme == "file" || u.scheme == "blob" ||
                                        u.scheme == "about") return false
                                    val encUrl = java.net.URLEncoder.encode(u.toString(), "UTF-8")
                                    val encLabel = java.net.URLEncoder.encode(
                                        u.host ?: "Link", "UTF-8"
                                    )
                                    nav.navigate("web/$encUrl/$encLabel") {
                                        launchSingleTop = true
                                    }
                                    return true
                                }

                                override fun onPageFinished(view: WebView?, url: String?) {
                                    super.onPageFinished(view, url)
                                    // Inject highlight JS for the pending search
                                    // term — flashes the searched word in the
                                    // article so the user doesn't have to find
                                    // it manually. Consume the pending value so
                                    // it doesn't re-fire on later navigations.
                                    // v5.4.6 — gated by articleHighlightEnabled
                                    // toggle so users can disable the text-node
                                    // walk if they suspect it's contributing
                                    // to crashes.
                                    // v5.4.10 — pendingHighlight is now a
                                    // data class with the exact-phrase flag.
                                    val pending = vm.consumePendingHighlight()
                                    val highlightOn = vm.articleHighlightEnabled.value
                                    if (pending != null && pending.query.isNotBlank() &&
                                        view != null && highlightOn) {
                                        // v5.4.9 — Resolve "auto" → smart/keyword
                                        // against the semantic-search state. JS
                                        // only ever sees "smart" or "keyword".
                                        val hlMode = vm.effectiveHighlightMode()
                                        view.evaluateJavascript(
                                            buildHighlightJs(pending.query, hlMode, pending.isPhrase),
                                            null
                                        )
                                    }
                                }

                                override fun onRenderProcessGone(
                                    view: WebView?, detail: RenderProcessGoneDetail?
                                ): Boolean {
                                    rendererCrashed = true
                                    runCatching { view?.destroy() }
                                    return true
                                }
                            }

                            onSearchInMarkVault = { text ->
                                vm.requestPendingSearch(text)
                                nav.navigate("search") { launchSingleTop = true }
                            }
                            onSearchInWol = { text ->
                                val target = "https://wol.jw.org/en/wol/s/r1/lp-e?q=" +
                                    java.net.URLEncoder.encode(text, "UTF-8")
                                vm.requestWebPopup(target)
                            }

                            webViewRef = this
                        }
                    },
                    update = { w ->
                        val html = htmlContent ?: return@AndroidView
                        if (!htmlLoaded) {
                            runCatching {
                                w.loadDataWithBaseURL(
                                    baseUrl ?: "about:blank",
                                    html,
                                    "text/html",
                                    "utf-8",
                                    null
                                )
                            }
                            htmlLoaded = true
                        }
                    }
                )
            }
        }

        // Bottom toolbar — full set: back / find / open-externally / browser /
        // home / overflow. Matches the markdown reader's density.
        MarkVaultBottomBar(
            nav = nav,
            vm = vm,
            extraActions = {
                // v4.22.1 — Summarise current HTML article via on-device chat
                // v5.2.0 — Hidden until the chat model is installed.
                val chatReady by vm.chatModelInstalled.collectAsStateWithLifecycle()
                if (chatReady) {
                    IconButton(onClick = {
                        vm.summarizeNote(id, "html")
                        nav.navigate("chat") { launchSingleTop = true }
                    }) {
                        androidx.compose.material3.Text("\u2728", fontSize = 18.sp)
                    }
                }
                // Find-in-page toggle
                IconButton(onClick = { findOpen = !findOpen }) {
                    Icon(Icons.Default.Search, contentDescription = "Find in page")
                }
                // v5.0.0 — Refresh online: open the original URL in the
                // browser tab system. Lets the user pull the live version
                // of an offline-saved article (which often has updated
                // content, fresh quotes, working scripture links) without
                // having to find the link themselves.
                IconButton(onClick = {
                    originalUri?.let { uri ->
                        val urlStr = uri.toString()
                        if (urlStr.startsWith("http://") || urlStr.startsWith("https://")) {
                            val encUrl = java.net.URLEncoder.encode(urlStr, "UTF-8")
                            val encLabel = java.net.URLEncoder.encode(
                                uri.host ?: "Online", "UTF-8"
                            )
                            nav.navigate("web/$encUrl/$encLabel") {
                                launchSingleTop = true
                            }
                        }
                    }
                }) {
                    Text("\uD83D\uDD04", fontSize = 18.sp)
                }
                // Open externally
                IconButton(onClick = {
                    originalUri?.let { uri ->
                        runCatching {
                            ctx.startActivity(
                                android.content.Intent(
                                    android.content.Intent.ACTION_VIEW, uri
                                ).addFlags(
                                    android.content.Intent.FLAG_GRANT_READ_URI_PERMISSION
                                )
                            )
                        }
                    }
                }) {
                    Text("\u2197", fontSize = 18.sp)
                }
            }
        )
    }
    } // v5.4.23 — end padded center Box
    // v5.4.19 — FAB overlay for "Find in article" — shown only when
    // opened from a search result AND the toggle is on. Wired to the
    // existing find bar so behavior matches WebSearchScreen's find UX.
    if (fabVisible) {
        val webVal = webViewRef
        androidx.compose.material3.ExtendedFloatingActionButton(
            onClick = {
                val wv = webVal ?: return@ExtendedFloatingActionButton
                val rawQ = currentSearchQuery.trim()
                    .removeSurrounding("\"").trim()
                if (rawQ.length < 2) return@ExtendedFloatingActionButton
                findQuery = rawQ
                findOpen = true
                wv.findAllAsync(rawQ)
            },
            icon = { Text("\uD83D\uDD0D") },
            text = { Text("Find in article") },
            modifier = Modifier
                .align(Alignment.BottomEnd)
                .padding(16.dp)
        )
    }
    // v5.4.23 — Tablet three-column side panels for HTML. Rendered
    // only when workspace mode is ON and window width ≥ 600dp. Left
    // panel mirrors ReaderScreen's tab list; right panel shows the
    // HTML document's h1-h6 outline with tap-to-scroll via
    // querySelectorAll.
    if (threeColumn) {
        Column(
            Modifier
                .align(Alignment.TopStart)
                .width(leftColWidth)
                .fillMaxHeight()
                .background(MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.35f))
                .padding(12.dp)
        ) {
            Text(
                "\uD83E\uDDF0 Workspace",
                fontSize = 15.sp,
                fontWeight = androidx.compose.ui.text.font.FontWeight.Bold
            )
            Spacer(Modifier.height(2.dp))
            Text(
                "Open tabs",
                fontSize = 11.sp,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
            Spacer(Modifier.height(10.dp))
            LazyColumn(
                Modifier.weight(1f).fillMaxWidth()
            ) {
                items(
                    tabs, key = { it.id }
                ) { tab ->
                    val selected = tab.id == activeTab
                    Surface(
                        color = if (selected)
                            MaterialTheme.colorScheme.primary.copy(alpha = 0.18f)
                        else androidx.compose.ui.graphics.Color.Transparent,
                        shape = androidx.compose.foundation.shape.RoundedCornerShape(8.dp),
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(vertical = 2.dp)
                            .clickable {
                                vm.setActiveTab(tab.id)
                            }
                    ) {
                        Row(
                            Modifier.padding(horizontal = 10.dp, vertical = 8.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                when (tab.fileType) {
                                    "pdf" -> "\uD83D\uDCC4"
                                    "html", "htm" -> "\uD83C\uDF10"
                                    else -> "\uD83D\uDCDD"
                                },
                                fontSize = 14.sp
                            )
                            Spacer(Modifier.width(8.dp))
                            Text(
                                tab.title,
                                modifier = Modifier.weight(1f),
                                fontSize = 12.sp,
                                maxLines = 1,
                                overflow = androidx.compose.ui.text.style.TextOverflow.Ellipsis,
                                fontWeight = if (selected)
                                    androidx.compose.ui.text.font.FontWeight.SemiBold
                                else androidx.compose.ui.text.font.FontWeight.Normal
                            )
                            IconButton(
                                onClick = { vm.closeTab(tab.id) },
                                modifier = Modifier.size(22.dp)
                            ) {
                                Icon(
                                    androidx.compose.material.icons.Icons.Default.Close,
                                    contentDescription = "Close tab",
                                    modifier = Modifier.size(12.dp),
                                    tint = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }
                        }
                    }
                }
            }
            androidx.compose.material3.HorizontalDivider(
                Modifier.padding(vertical = 6.dp)
            )
            Row(
                Modifier
                    .fillMaxWidth()
                    .clickable { nav.navigate("home") }
                    .padding(vertical = 10.dp, horizontal = 8.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Icon(
                    androidx.compose.material.icons.Icons.Default.Add,
                    contentDescription = null,
                    modifier = Modifier.size(16.dp)
                )
                Spacer(Modifier.width(8.dp))
                Text("Open a new tab", fontSize = 13.sp)
            }
        }
        // Right panel: HTML outline
        Column(
            Modifier
                .align(Alignment.TopEnd)
                .width(rightColWidth)
                .fillMaxHeight()
                .background(MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.35f))
                .padding(12.dp)
        ) {
            Text(
                "\uD83D\uDCD1 Outline",
                fontSize = 15.sp,
                fontWeight = androidx.compose.ui.text.font.FontWeight.Bold
            )
            Spacer(Modifier.height(2.dp))
            Text(
                "${htmlHeadings.size} heading${if (htmlHeadings.size == 1) "" else "s"}",
                fontSize = 11.sp,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
            Spacer(Modifier.height(10.dp))
            if (htmlHeadings.isEmpty()) {
                Text(
                    "No headings in this document.",
                    fontSize = 12.sp,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            } else {
                LazyColumn(
                    Modifier.weight(1f).fillMaxWidth()
                ) {
                    items(htmlHeadings) { h ->
                        Text(
                            h.text,
                            Modifier
                                .fillMaxWidth()
                                .clickable {
                                    // Scroll to the Nth heading via
                                    // querySelectorAll — works for any
                                    // HTML loaded via loadDataWithBaseURL
                                    // regardless of whether the source has
                                    // its own IDs.
                                    webViewRef?.evaluateJavascript(
                                        "(function(){var hs=document.querySelectorAll('h1,h2,h3,h4,h5,h6');" +
                                            "if(hs.length > ${h.index}) hs[${h.index}]." +
                                            "scrollIntoView({behavior:'smooth',block:'start'});})();",
                                        null
                                    )
                                }
                                .padding(
                                    start = ((h.level - 1) * 10).dp,
                                    top = 8.dp, bottom = 8.dp
                                ),
                            fontSize = if (h.level <= 2) 12.sp else 11.sp,
                            fontWeight = if (h.level <= 2)
                                androidx.compose.ui.text.font.FontWeight.SemiBold
                            else androidx.compose.ui.text.font.FontWeight.Normal,
                            color = if (h.level <= 2) MaterialTheme.colorScheme.onSurface
                            else MaterialTheme.colorScheme.onSurfaceVariant,
                            maxLines = 3,
                            overflow = androidx.compose.ui.text.style.TextOverflow.Ellipsis
                        )
                    }
                }
            }
        }
    }
    }
}

/**
 * Find-in-page bar — text input + prev/next + close, identical to the one in
 * WebSearchScreen so the experience is consistent. Auto-focuses when opened.
 */
@Composable
private fun FindInPageBar(
    query: String,
    onQueryChange: (String) -> Unit,
    onNext: () -> Unit,
    onPrev: () -> Unit,
    onClose: () -> Unit
) {
    val focus = remember { FocusRequester() }
    LaunchedEffect(Unit) { runCatching { focus.requestFocus() } }
    Surface(
        modifier = Modifier.fillMaxWidth(),
        color = MaterialTheme.colorScheme.surfaceVariant
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 12.dp, vertical = 6.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Icon(
                Icons.Default.Search,
                contentDescription = null,
                modifier = Modifier.size(18.dp),
                tint = MaterialTheme.colorScheme.onSurfaceVariant
            )
            Spacer(Modifier.width(8.dp))
            BasicTextField(
                value = query,
                onValueChange = onQueryChange,
                singleLine = true,
                modifier = Modifier
                    .weight(1f)
                    .focusRequester(focus),
                textStyle = TextStyle(
                    fontSize = 14.sp,
                    color = MaterialTheme.colorScheme.onSurface
                )
            )
            IconButton(onClick = onPrev) {
                Icon(Icons.Default.KeyboardArrowUp, contentDescription = "Previous")
            }
            IconButton(onClick = onNext) {
                Icon(Icons.Default.KeyboardArrowDown, contentDescription = "Next")
            }
            IconButton(onClick = onClose) {
                Icon(Icons.Default.Close, contentDescription = "Close find")
            }
        }
    }
}

@Composable
private fun ErrorPane(
    message: String,
    onOpenExternally: () -> Unit,
    onRetry: () -> Unit
) {
    Column(
        Modifier.fillMaxSize().padding(24.dp),
        verticalArrangement = Arrangement.Center,
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Text("\u26A0\uFE0F", fontSize = 32.sp)
        Spacer(Modifier.size(14.dp))
        Text(
            "Couldn't display this page",
            fontSize = 17.sp,
            fontWeight = FontWeight.SemiBold
        )
        Spacer(Modifier.size(8.dp))
        Text(
            message,
            fontSize = 13.sp,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
            textAlign = TextAlign.Center
        )
        Spacer(Modifier.size(24.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            androidx.compose.material3.OutlinedButton(onClick = onRetry) {
                Text("Retry")
            }
            Button(onClick = onOpenExternally) {
                Text("Open externally")
            }
        }
    }
}

/**
 * Build a JavaScript snippet that finds the best matching term in [needle],
 * wraps every occurrence in a yellow-tinted `<mark>` span, and scrolls the
 * first match into view.
 *
 * v4.14.0 — phrase-first matching with multi-stage fallback (mirrors what
 * `render.js` already does for the markdown reader):
 *   1. Try the full phrase exactly as supplied
 *   2. Strip trailing punctuation (`?`, `!`, `.`, `,`, `;`, `:`) and retry
 *   3. Fall back to the longest non-stopword that appears in the document
 *   4. Last resort: any word from the query that appears
 *
 * The first stage that finds matches wins; subsequent stages aren't tried.
 * The selected term is what gets highlighted everywhere in the document,
 * so phrases come through as single underlined blocks rather than a confetti
 * of individual word matches.
 *
 * Idempotent — calling it again with a different needle replaces previous
 * marks. Walks text nodes only and skips script/style/mark elements.
 */
private fun buildHighlightJs(needle: String, mode: String = "smart", isPhrase: Boolean = false): String {
    // Escape the user's term for safe JS string embedding.
    val esc = needle
        .replace("\\", "\\\\")
        .replace("'", "\\'")
        .replace("\"", "\\\"")
        .replace("\n", " ")
    val modeEsc = if (mode == "keyword") "keyword" else "smart"
    val phraseFlag = if (isPhrase) "true" else "false"
    return """
        (function(){
          try {
            var raw = '$esc';
            var mode = '$modeEsc';
            var isPhrase = $phraseFlag;
            if (!raw || raw.length < 2) return;

            // Remove any previous markvault highlights so re-runs don't compound.
            var prev = document.querySelectorAll('mark.mv-hl');
            for (var i = 0; i < prev.length; i++) {
              var p = prev[i];
              p.replaceWith(document.createTextNode(p.textContent));
            }

            // v5.4.9 — Two-mode highlight pass. "smart" = sentence-level
            // for body sentences with 2+ distinct query terms, plus
            // word-level backfill so terms in headings and weak matches
            // still get a small mark. "keyword" = word-level only.
            // Improvements over v5.3.0: skip headings entirely from
            // sentence wrap (no more yellow titles), bump min term
            // length 3→4, require 2+ distinct terms.
            var STOPWORDS = {the:1,is:1,a:1,an:1,of:1,to:1,and:1,in:1,on:1,
              "for":1,at:1,by:1,are:1,was:1,were:1,be:1,been:1,being:1,it:1,
              its:1,this:1,that:1,these:1,those:1,with:1,from:1,as:1,or:1,
              but:1,"if":1,so:1,"do":1,does:1,did:1,has:1,have:1,had:1,
              will:1,would:1,can:1,could:1,what:1,who:1,why:1,how:1,
              when:1,where:1,which:1,about:1,not:1,no:1,also:1,more:1,
              some:1,any:1,all:1,one:1,two:1,you:1,your:1,my:1,we:1,
              our:1,us:1,me:1,he:1,she:1,they:1,them:1,their:1,his:1,
              her:1,"i":1};

            function extractTerms(input) {
              var lower = ('' + input).toLowerCase()
                .replace(/\[\[/g, ' ')
                .replace(/\]\]/g, ' ')
                .replace(/\.\.\./g, ' ')
                .replace(/[^a-z0-9'\s]/g, ' ')
                .replace(/\s+/g, ' ')
                .trim();
              var pieces = lower.split(' ');
              var seen = {};
              var out = [];
              for (var i = 0; i < pieces.length; i++) {
                var w = pieces[i];
                // v5.4.9 — min length 4 (was 3) to filter weak matches.
                if (w.length >= 4 && !STOPWORDS[w] && !seen[w]) {
                  seen[w] = 1;
                  out.push(w);
                }
              }
              return out;
            }

            // v5.4.10 — Exact-phrase short-circuit. When the user
            // searched in exact-phrase mode, we want to highlight the
            // literal phrase only, never break it into terms.
            if (isPhrase === true) {
              var phrase = raw.replace(/^"+|"+$/g, '').replace(/^'+|'+$/g, '').trim();
              if (!phrase) return;
              var phraseLow = phrase.toLowerCase();
              var phraseLen = phrase.length;
              var pwalker = document.createTreeWalker(
                document.body, NodeFilter.SHOW_TEXT, {
                  acceptNode: function(n) {
                    if (!n.nodeValue || !n.nodeValue.trim()) return NodeFilter.FILTER_REJECT;
                    var p = n.parentNode;
                    if (!p) return NodeFilter.FILTER_REJECT;
                    var tag = p.nodeName;
                    if (tag === 'SCRIPT' || tag === 'STYLE' ||
                        tag === 'MARK' || tag === 'NOSCRIPT') {
                      return NodeFilter.FILTER_REJECT;
                    }
                    return NodeFilter.FILTER_ACCEPT;
                  }
                }, false);
              var pnodes = [];
              var pn;
              while (pn = pwalker.nextNode()) pnodes.push(pn);
              var pFirst = null;
              var pCap = 200;
              for (var pi = 0; pi < pnodes.length && pCap > 0; pi++) {
                var pt = pnodes[pi];
                var ptext = pt.nodeValue;
                var plower = ptext.toLowerCase();
                var pidx = 0;
                var pranges = [];
                while ((pidx = plower.indexOf(phraseLow, pidx)) !== -1) {
                  pranges.push({s: pidx, e: pidx + phraseLen});
                  pidx += phraseLen;
                }
                if (pranges.length === 0) continue;
                var pparent = pt.parentNode;
                var pcursor = 0;
                var pfrag = document.createDocumentFragment();
                for (var pr = 0; pr < pranges.length && pCap > 0; pr++) {
                  var prr = pranges[pr];
                  if (prr.s > pcursor) {
                    pfrag.appendChild(document.createTextNode(ptext.substring(pcursor, prr.s)));
                  }
                  var pmark = document.createElement('mark');
                  pmark.className = 'mv-hl';
                  pmark.style.backgroundColor = '#ffe066';
                  pmark.style.color = '#000';
                  pmark.style.padding = '0 1px';
                  pmark.appendChild(document.createTextNode(ptext.substring(prr.s, prr.e)));
                  if (!pFirst) pFirst = pmark;
                  pfrag.appendChild(pmark);
                  pcursor = prr.e;
                  pCap--;
                }
                if (pcursor < ptext.length) {
                  pfrag.appendChild(document.createTextNode(ptext.substring(pcursor)));
                }
                pparent.replaceChild(pfrag, pt);
              }
              if (pFirst) pFirst.scrollIntoView({behavior: 'smooth', block: 'center'});
              return;
            }

            function isHeadingTag(t) {
              return t === 'H1' || t === 'H2' || t === 'H3' ||
                     t === 'H4' || t === 'H5' || t === 'H6';
            }

            function hasHeadingAncestor(n) {
              var a = n.parentNode;
              while (a && a !== document.body) {
                if (a.nodeName && isHeadingTag(a.nodeName)) return true;
                a = a.parentNode;
              }
              return false;
            }

            function wrapNode(text, range) {
              var mark = document.createElement('mark');
              mark.className = 'mv-hl';
              mark.style.backgroundColor = '#ffe066';
              mark.style.color = '#000';
              mark.style.padding = '0 1px';
              mark.appendChild(document.createTextNode(text.substring(range.s, range.e)));
              return mark;
            }

            var terms = extractTerms(raw);
            if (terms.length === 0) return;

            // ---- helper: word-level matcher (used by both modes) ----
            // For each term, find every case-insensitive occurrence in
            // every text node and wrap it. No sentence wrap.
            function wordHighlightPass(firstHolder) {
              var walker2 = document.createTreeWalker(
                document.body, NodeFilter.SHOW_TEXT, {
                  acceptNode: function(n) {
                    if (!n.nodeValue || !n.nodeValue.trim()) return NodeFilter.FILTER_REJECT;
                    var p = n.parentNode;
                    if (!p) return NodeFilter.FILTER_REJECT;
                    var tag = p.nodeName;
                    if (tag === 'SCRIPT' || tag === 'STYLE' ||
                        tag === 'MARK' || tag === 'NOSCRIPT') {
                      return NodeFilter.FILTER_REJECT;
                    }
                    return NodeFilter.FILTER_ACCEPT;
                  }
                }, false);
              var wnodes = [];
              var wn;
              while (wn = walker2.nextNode()) wnodes.push(wn);
              var capacity = 200;
              for (var wi = 0; wi < wnodes.length && capacity > 0; wi++) {
                var wt = wnodes[wi];
                var wtext = wt.nodeValue;
                var wlower = wtext.toLowerCase();
                var wranges = [];
                for (var ti = 0; ti < terms.length; ti++) {
                  var term = terms[ti];
                  var idx = 0;
                  while ((idx = wlower.indexOf(term, idx)) !== -1) {
                    wranges.push({s: idx, e: idx + term.length});
                    idx += term.length;
                  }
                }
                if (wranges.length === 0) continue;
                // Sort and merge overlapping ranges
                wranges.sort(function(a, b){ return a.s - b.s; });
                var merged = [wranges[0]];
                for (var mi = 1; mi < wranges.length; mi++) {
                  var top = merged[merged.length - 1];
                  if (wranges[mi].s <= top.e) {
                    top.e = Math.max(top.e, wranges[mi].e);
                  } else {
                    merged.push(wranges[mi]);
                  }
                }
                var wparent = wt.parentNode;
                var wcursor = 0;
                var wfrag = document.createDocumentFragment();
                for (var ri = 0; ri < merged.length && capacity > 0; ri++) {
                  var wr = merged[ri];
                  if (wr.s > wcursor) {
                    wfrag.appendChild(document.createTextNode(wtext.substring(wcursor, wr.s)));
                  }
                  var wmark = wrapNode(wtext, wr);
                  if (!firstHolder.first) firstHolder.first = wmark;
                  wfrag.appendChild(wmark);
                  wcursor = wr.e;
                  capacity--;
                }
                if (wcursor < wtext.length) {
                  wfrag.appendChild(document.createTextNode(wtext.substring(wcursor)));
                }
                wparent.replaceChild(wfrag, wt);
              }
            }

            var firstHolder = { first: null };

            if (mode === 'smart') {
              // ---- sentence-level wrap (body only, 2+ terms required) ----
              var walker = document.createTreeWalker(
                document.body, NodeFilter.SHOW_TEXT, {
                  acceptNode: function(n) {
                    if (!n.nodeValue || !n.nodeValue.trim()) return NodeFilter.FILTER_REJECT;
                    var p = n.parentNode;
                    if (!p) return NodeFilter.FILTER_REJECT;
                    var tag = p.nodeName;
                    if (tag === 'SCRIPT' || tag === 'STYLE' ||
                        tag === 'MARK' || tag === 'NOSCRIPT') {
                      return NodeFilter.FILTER_REJECT;
                    }
                    if (isHeadingTag(tag)) return NodeFilter.FILTER_REJECT;
                    if (hasHeadingAncestor(n)) return NodeFilter.FILTER_REJECT;
                    return NodeFilter.FILTER_ACCEPT;
                  }
                }, false);

              var nodes = [];
              var node;
              while (node = walker.nextNode()) nodes.push(node);

              var totalHighlights = 0;
              var MAX_HIGHLIGHTS = 40;
              // v5.4.16 — Threshold to 1 for reliable highlighting.
              // See render.js note; same fix.
              var MIN_HITS = 1;

              for (var nn = 0; nn < nodes.length && totalHighlights < MAX_HIGHLIGHTS; nn++) {
                var t = nodes[nn];
                var text = t.nodeValue;
                var sentenceRe = /[^.!?\n]+(?:[.!?]+|$)/g;
                var m;
                var ranges = [];
                while ((m = sentenceRe.exec(text)) !== null) {
                  var sentence = m[0];
                  var sentTrim = sentence.replace(/^\s+|\s+$/g, '');
                  if (sentTrim.length < 8) continue;
                  var sentLower = sentence.toLowerCase();
                  var hits = 0;
                  var matched = {};
                  for (var ti = 0; ti < terms.length; ti++) {
                    if (!matched[terms[ti]] && sentLower.indexOf(terms[ti]) >= 0) {
                      matched[terms[ti]] = 1;
                      hits++;
                    }
                  }
                  if (hits >= MIN_HITS) {
                    var s = m.index;
                    var e = s + sentence.length;
                    while (s < e && /\s/.test(text.charAt(s))) s++;
                    if (s < e) ranges.push({s: s, e: e});
                  }
                }
                if (ranges.length === 0) continue;
                var parent = t.parentNode;
                var cursor = 0;
                var frag = document.createDocumentFragment();
                for (var r = 0; r < ranges.length && totalHighlights < MAX_HIGHLIGHTS; r++) {
                  var range = ranges[r];
                  if (range.s > cursor) {
                    frag.appendChild(document.createTextNode(text.substring(cursor, range.s)));
                  }
                  var smark = wrapNode(text, range);
                  if (!firstHolder.first) firstHolder.first = smark;
                  frag.appendChild(smark);
                  cursor = range.e;
                  totalHighlights++;
                }
                if (cursor < text.length) {
                  frag.appendChild(document.createTextNode(text.substring(cursor)));
                }
                parent.replaceChild(frag, t);
              }

              // v5.4.15 — Word-level backfill removed in smart mode.
              // User wants sentence/phrase highlighting only — no
              // individual word marks. Sentences that didn't qualify
              // for the wrap above just stay unhighlighted.
            } else {
              // mode === 'keyword' — just word-level matches everywhere.
              wordHighlightPass(firstHolder);
            }

            if (firstHolder.first) {
              firstHolder.first.scrollIntoView({behavior: 'smooth', block: 'center'});
            }
          } catch (e) {
            console.log('mv-highlight error: ' + e);
          }
        })();
    """.trimIndent()
}
