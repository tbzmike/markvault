package com.tebogo.markvault.ui

import android.annotation.SuppressLint
import android.net.Uri
import android.view.ViewGroup
import android.webkit.RenderProcessGoneDetail
import android.webkit.WebResourceRequest
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.KeyboardArrowDown
import androidx.compose.material.icons.filled.KeyboardArrowUp
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.Button
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import com.tebogo.markvault.ui.DraggableBubble
import com.tebogo.markvault.ui.BubbleCloseZone
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.navigation.NavController
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.tebogo.markvault.AppViewModel
import com.tebogo.markvault.util.MhtmlParser
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.filled.Add
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.material.icons.filled.Menu

/** v5.4.23 — File-level so items()'s generic inference resolves cleanly. */
private data class HtmlHeading(val index: Int, val level: Int, val text: String)

/**
 * Reader for offline web archives — full feature parity with markdown reader:
 *   • Find-in-page with prev/next nav (Ctrl+F equivalent)
 *   • Search-result highlight injection (pendingHighlight from VM)
 *   • Open externally fallback
 *   • Crash-hardened (renderer recovery)
 *   • Comprehensive bottom toolbar with all standard actions
 *   • Link taps route to in-app browser
 *
 * v4.6 changes from v4.5:
 *   1. Find-in-page UI added (WebView.findAllAsync + findNext).
 *   2. Pending highlight from Search screen now flashes in the WebView via
 *      injected JavaScript wrapping matches in <mark> spans.
 *   3. Toolbar now mirrors the markdown reader's button density.
 */
@OptIn(androidx.compose.material3.ExperimentalMaterial3Api::class)
@Composable
fun HtmlReaderScreen(
    vm: AppViewModel,
    nav: NavController,
    id: Long
) {
    val ctx = LocalContext.current
    val theme by vm.theme.collectAsState()

    var title by remember { mutableStateOf("Offline page") }
    var htmlContent by remember { mutableStateOf<String?>(null) }
    var baseUrl by remember { mutableStateOf<String?>(null) }
    var rendererCrashed by remember { mutableStateOf(false) }
    var loadError by remember { mutableStateOf<String?>(null) }
    var originalUri by remember { mutableStateOf<Uri?>(null) }
    var htmlLoaded by remember { mutableStateOf(false) }
    // v5.4.35 — Tracks when the user navigated away to the in-app
    // browser. When they return, the WebView is force-reloaded to
    // clear any stale URL state that caused the "stuck first link"
    // bug. Set to true inside shouldOverrideUrlLoading before
    // navigating; consumed in the AndroidView update block.
    var needsReload by remember { mutableStateOf(false) }
    // v5.4.35 — Source URL extracted from the original HTML file
    // metadata, used by the "🌐 Load Online" toolbar button.
    var sourceUrl by remember { mutableStateOf<String?>(null) }

    // Find-in-page state — mirrors WebSearchScreen's pattern.
    var findOpen by remember { mutableStateOf(false) }
    var findQuery by remember { mutableStateOf("") }
    var webViewRef by remember { mutableStateOf<WebView?>(null) }
    var noteContentForSemantic by remember { mutableStateOf<String?>(null) }
    // v5.4.182cc — Scripture detection state
    val scriptureDetectionOn by vm.scriptureDetectionEnabled.collectAsStateWithLifecycle()
    val htmlScope = androidx.compose.runtime.rememberCoroutineScope()
    // v5.4.36 — Long-press link popup for offline HTML articles.
    var longPressLinkUrl by remember { mutableStateOf<String?>(null) }
    var longPressLinkText by remember { mutableStateOf<String?>(null) }

    // v5.4.108cc — Scroll-position persistence. Matches the pattern used
    // by markdown ReaderScreen (see `latestScroll` / setOnScrollChangeListener
    // there): a mutable state tracks the WebView's scrollY, updated on
    // every scroll callback; on page-load we restore to `note.lastScroll`;
    // on composable dispose we write the latest value back through
    // [AppViewModel.saveScroll] which persists it via `dao.setScroll`.
    // The initial-scroll state carries the value we want to restore
    // exactly ONCE per page-load — subsequent onPageFinished callbacks
    // (from same-page navigation) shouldn't jump the reader back to the
    // original spot.
    val latestScroll = remember { mutableStateOf(0) }
    // v5.4.155cc — scroll-to-hide toolbar (matches ReaderScreen / WebSearchScreen pattern)
    var htmlToolbarsVisible by remember { mutableStateOf(true) }
    var lastHtmlScrollValue by remember { mutableStateOf(0) }
    val enableFullscreenMode by vm.enableFullscreenMode.collectAsStateWithLifecycle()
    var initialScrollToApply by remember { mutableStateOf<Int?>(null) }
    var scrollRestored by remember { mutableStateOf(false) }

    LaunchedEffect(id) {
        val note = withContext(Dispatchers.IO) { vm.loadNote(id) }
        if (note == null) {
            loadError = "Could not load the file from the library."
            return@LaunchedEffect
        }
        title = note.title.ifBlank { note.name }
        originalUri = runCatching { Uri.parse(note.uri) }.getOrNull()
        // v5.4.108cc — Prime the scroll restore. `note.lastScroll` is
        // 0 for freshly-imported notes (default column value); we still
        // set it — a `window.scrollTo(0, 0)` is a no-op if the page
        // hasn't scrolled yet.
        initialScrollToApply = note.lastScroll
        scrollRestored = false
        latestScroll.value = note.lastScroll
        noteContentForSemantic = note.content

        val bytes = withContext(Dispatchers.IO) {
            runCatching {
                ctx.contentResolver.openInputStream(Uri.parse(note.uri))?.use {
                    it.readBytes()
                }
            }.getOrNull()
        }
        if (bytes == null) {
            loadError = "Could not read the file. The library folder may have been moved."
            return@LaunchedEffect
        }

        val nameLower = note.name.lowercase()
        val isMhtml = nameLower.endsWith(".mhtml") || nameLower.endsWith(".mht")

        if (isMhtml) {
            val parsed = withContext(Dispatchers.IO) {
                MhtmlParser.extractHtmlContent(bytes)
            }
            if (parsed == null) {
                loadError = "This MHTML file is malformed. Try opening it externally."
                return@LaunchedEffect
            }
            htmlContent = parsed
            baseUrl = withContext(Dispatchers.IO) { MhtmlParser.extractBaseUrl(bytes) }
            // v5.4.35 — For MHTML files the base URL IS the online source.
            sourceUrl = baseUrl
        } else {
            val raw = try {
                String(bytes, Charsets.UTF_8)
            } catch (_: Exception) {
                String(bytes)
            }
            htmlContent = raw
            // v5.4.35 — Try to extract the online source URL from
            // common meta tags that MarkVault's web-to-HTML saver
            // injects, or from standard HTML meta like og:url.
            sourceUrl = withContext(Dispatchers.IO) {
                val lower = raw.lowercase()
                // Check meta property og:url
                val ogMatch = Regex(
                    """<meta[^>]+property\s*=\s*["']og:url["'][^>]+content\s*=\s*["']([^"']+)["']""",
                    RegexOption.IGNORE_CASE
                ).find(raw)?.groupValues?.getOrNull(1)
                // Check <link rel="canonical">
                val canonMatch = Regex(
                    """<link[^>]+rel\s*=\s*["']canonical["'][^>]+href\s*=\s*["']([^"']+)["']""",
                    RegexOption.IGNORE_CASE
                ).find(raw)?.groupValues?.getOrNull(1)
                // Check MarkVault's own source-url comment
                val mvMatch = Regex(
                    """<!-- source-url: (.+?) -->""",
                    RegexOption.IGNORE_CASE
                ).find(raw)?.groupValues?.getOrNull(1)
                (mvMatch ?: ogMatch ?: canonMatch)?.takeIf {
                    it.startsWith("http://") || it.startsWith("https://")
                }
            }
        }

        // v5.4.133cc — HTML-article semantic-search wiring.
        //
        // Previously `noteContentForSemantic` was set once at the top
        // of this LaunchedEffect from `note.content` (the Room-stored
        // field), which is nearly empty for HTML articles — the full
        // content lives on disk and only gets read into [htmlContent]
        // a few lines above. That's why the brain FAB and the
        // long-press "Search in article" flow always returned "no
        // strongly matching passages" for HTML articles regardless of
        // how highly they were rated: the ranker was embedding an
        // empty string.
        //
        // Now `noteContentForSemantic` is overwritten with the actual
        // HTML text once it's in hand. [findArticlePassages] detects
        // full HTML and strips it to plain text with paragraph breaks
        // preserved before ranking (see AppViewModel v5.4.133cc).
        //
        // v5.4.134cc — Capture [htmlContent] into a local `val` before
        // the null check + call. [htmlContent] is a delegated property
        // (`by remember { mutableStateOf<String?>(null) }`) and Kotlin's
        // flow analysis cannot smart-cast a delegated `String?` down to
        // non-null `String`, so the direct `htmlContent.isNotBlank()`
        // and passing `htmlContent` where a non-null String is expected
        // both fail to compile. A local val is not delegated and DOES
        // get smart-cast, so the guard and the call both work.
        val currentHtml: String? = htmlContent
        noteContentForSemantic = currentHtml

        // v5.4.144cc — Consume (and discard) any pending popup query so
        // it doesn't linger for the next article open. The popup is now
        // driven exclusively from the brain FAB which extracts yellow
        // mark.mv-hl highlights from the live DOM — no semantic search.
        vm.consumePendingPopupQuery()

        vm.openArticle(id, title, fileType = note.fileType)
    }

    // v5.4.108cc — Persist the current scroll position when the
    // composable leaves the composition (back navigation, tab switch
    // away from the HTML reader, process shutdown after RAM-kill).
    // Same pattern as markdown ReaderScreen's DisposableEffect. The
    // save is fire-and-forget on an IO coroutine inside AppViewModel;
    // if the app is dying, DataStore's write-ahead log usually gets
    // the value through anyway.
    androidx.compose.runtime.DisposableEffect(id) {
        onDispose {
            val y = latestScroll.value
            if (y >= 0) vm.saveScroll(id, y)
        }
    }

    // v5.4.19 — Find-in-article FAB. HtmlReaderScreen uses a Column, not
    // a Scaffold, so we wrap the whole thing in a Box and overlay the
    // FAB at the bottom-end. HTML-file reading uses the keyword branch
    // only — HTML doesn't split cleanly on paragraph boundaries, so
    // semantic-in-article isn't wired here.
    val fabEnabled by vm.searchInArticleFab.collectAsStateWithLifecycle()
    val semanticInArticleOn by vm.semanticInArticle.collectAsStateWithLifecycle()
    val currentSearchQuery by vm.query.collectAsStateWithLifecycle()
    val openedFromSearchLatched by androidx.compose.runtime.produceState(
        initialValue = false, key1 = id
    ) {
        value = vm.openedFromSearch.value
        vm.clearOpenedFromSearch()
    }
    var fabBusy by remember { mutableStateOf(false) }
    // fabScope removed v5.4.144cc — no longer needed after popup extraction moved to evaluateJavascript

    // v5.4.23 — Workspace mode + tablet 3-column overlay for HTML files.
    // Same trigger rules as ReaderScreen: workspace ON + width ≥ 600dp.
    // Left panel = tabs list (matches ReaderScreen exactly). Right
    // panel = outline from the HTML document's h1-h6 tags.
    val uiMode by vm.uiMode.collectAsStateWithLifecycle()
    val workspaceOn = uiMode == "workspace"
    val screenWidthDp = androidx.compose.ui.platform.LocalConfiguration.current.screenWidthDp
    val isTabletWidth = screenWidthDp >= 600
    val threeColumn = workspaceOn && isTabletWidth
    val leftColWidth = 240.dp
    val rightColWidth = 220.dp
    val tabs by vm.tabs.collectAsStateWithLifecycle()
    val activeTab by vm.activeTab.collectAsStateWithLifecycle()
    // v5.4.24 — Collapsible panels.
    var leftPanelOpen by remember { mutableStateOf(true) }
    var rightPanelOpen by remember { mutableStateOf(true) }

    // Extract HTML headings once per document. Match <h1>-<h6> with any
    // attributes, strip inner tags for display text, and preserve the
    // index-in-document order so we can scroll to the Nth heading via
    // querySelectorAll('h1,h2,...')[N] regardless of the HTML's own IDs.
    // v5.4.23 hotfix — htmlContent is String? — smart-cast via a local.
    val htmlHeadings = remember(htmlContent) {
        val body = htmlContent
        if (body.isNullOrBlank()) emptyList()
        else {
            val pattern = Regex(
                "<h([1-6])[^>]*>(.*?)</h[1-6]>",
                setOf(RegexOption.IGNORE_CASE, RegexOption.DOT_MATCHES_ALL)
            )
            pattern.findAll(body).mapIndexed { idx, m ->
                val level = m.groupValues[1].toInt()
                val text = m.groupValues[2]
                    .replace(Regex("<[^>]+>"), "")
                    .replace(Regex("\\s+"), " ")
                    .trim()
                HtmlHeading(idx, level, text)
            }.filter { it.text.isNotBlank() }.toList()
        }
    }

    Box(Modifier.fillMaxSize()) {
    Box(
        Modifier
            .padding(
                start = if (threeColumn && leftPanelOpen) leftColWidth else 0.dp,
                end = if (threeColumn && rightPanelOpen) rightColWidth else 0.dp
            )
            .fillMaxSize()
    ) {
    Column(Modifier.fillMaxSize()) {
        // Title strip — hidden when toolbars scroll-hidden (v5.4.155cc)
        if (htmlToolbarsVisible) {
        Surface(
            modifier = Modifier.fillMaxWidth(),
            color = MaterialTheme.colorScheme.surfaceVariant
        ) {
            Text(
                "\uD83C\uDF10  $title",
                modifier = Modifier.padding(horizontal = 16.dp, vertical = 10.dp),
                fontSize = 14.sp,
                maxLines = 1
            )
        }
        }

        // Find-in-page bar (slides in when find button tapped)
        if (findOpen) {
            FindInPageBar(
                query = findQuery,
                onQueryChange = {
                    findQuery = it
                    webViewRef?.findAllAsync(it)
                },
                onNext = { webViewRef?.findNext(true) },
                onPrev = { webViewRef?.findNext(false) },
                onClose = {
                    findOpen = false
                    webViewRef?.clearMatches()
                }
            )
        }

        // Body
        Box(modifier = Modifier.fillMaxWidth().weight(1f)) {
            when {
                loadError != null || rendererCrashed -> ErrorPane(
                    message = loadError ?: "The page renderer crashed.",
                    onOpenExternally = {
                        originalUri?.let { uri ->
                            runCatching {
                                ctx.startActivity(
                                    android.content.Intent(
                                        android.content.Intent.ACTION_VIEW, uri
                                    ).addFlags(
                                        android.content.Intent.FLAG_GRANT_READ_URI_PERMISSION
                                    )
                                )
                            }
                        }
                    },
                    onRetry = {
                        rendererCrashed = false
                        loadError = null
                        htmlLoaded = false
                    }
                )

                htmlContent != null -> AndroidView(
                    modifier = Modifier.fillMaxSize(),
                    factory = { context ->
                        @SuppressLint("SetJavaScriptEnabled")
                        SelectionWebView(context).apply {
                            layoutParams = ViewGroup.LayoutParams(
                                ViewGroup.LayoutParams.MATCH_PARENT,
                                ViewGroup.LayoutParams.MATCH_PARENT
                            )
                            settings.javaScriptEnabled = true
                            settings.domStorageEnabled = true
                            // v5.4.25 — Force mobile layout. Was
                            // useWideViewPort=true which made the
                            // WebView use a 980px default viewport,
                            // forcing sideways scroll for content
                            // authored without an explicit viewport.
                            settings.useWideViewPort = false
                            settings.loadWithOverviewMode = true
                            settings.builtInZoomControls = true
                            settings.displayZoomControls = false
                            settings.mixedContentMode =
                                WebSettings.MIXED_CONTENT_COMPATIBILITY_MODE

                            // v5.4.108cc — Track WebView scrollY so the
                            // DisposableEffect below can persist the
                            // latest position. Same pattern as markdown
                            // ReaderScreen (`setOnScrollChangeListener`
                            // at line 1165).
                            // v5.4.155cc — scroll listener moved to update lambda

                            // v5.4.36 — Long-press on a link in the offline
                            // HTML article shows a popup with options like
                            // "Copy link text" and "Search in library".
                            setOnLongClickListener { v ->
                                val webV = v as? WebView ?: return@setOnLongClickListener false
                                val hit = webV.hitTestResult
                                when (hit.type) {
                                    WebView.HitTestResult.SRC_ANCHOR_TYPE,
                                    WebView.HitTestResult.SRC_IMAGE_ANCHOR_TYPE -> {
                                        val href = hit.extra
                                        if (!href.isNullOrBlank()) {
                                            longPressLinkUrl = href
                                            longPressLinkText = null
                                            webV.evaluateJavascript(
                                                "(function(){" +
                                                "var els=document.querySelectorAll('a[href]');" +
                                                "for(var i=0;i<els.length;i++){" +
                                                "  if(els[i].href==='" + href.replace("'", "\\'") + "'){" +
                                                "    return els[i].innerText.trim();" +
                                                "  }" +
                                                "}" +
                                                "return '';" +
                                                "})()"
                                            ) { result ->
                                                val text = result?.trim()
                                                    ?.removeSurrounding("\"")
                                                    ?.takeIf { it.isNotBlank() && it != "null" }
                                                longPressLinkText = text
                                            }
                                            true
                                        } else false
                                    }
                                    else -> false
                                }
                            }

                            webViewClient = object : WebViewClient() {
                                override fun shouldOverrideUrlLoading(
                                    view: WebView?, request: WebResourceRequest?
                                ): Boolean {
                                    val u = request?.url ?: return false
                                    val scheme = u.scheme ?: return false
                                    if (scheme == "data" || scheme == "cid" ||
                                        scheme == "file" || scheme == "blob" ||
                                        scheme == "about") return false
                                    // v5.4.217cc — Intercept JW.org video links in articles.
                                    // Links like finder?subtype=rendered or library/videos
                                    // get routed to MediaPlayerScreen instead of a browser tab.
                                    val host = u.host ?: ""
                                    if (host.contains("jw.org") || host.contains("link.jw.org")) {
                                        val urlStr = u.toString()
                                        val isVideoLink =
                                            urlStr.contains("subtype=rendered") ||
                                            urlStr.contains("library/videos") ||
                                            (urlStr.contains("finder") &&
                                                urlStr.contains("docid") &&
                                                !urlStr.contains("pub=nwtsty") &&
                                                !urlStr.contains("bible="))
                                        if (isVideoLink) {
                                            val key = u.getQueryParameter("mediaKey")
                                                ?: u.getQueryParameter("naturalKey")
                                                ?: u.getQueryParameter("docid")
                                                ?: u.lastPathSegment
                                            if (!key.isNullOrBlank()) {
                                                htmlScope.launch {
                                                    val media = runCatching {
                                                        com.tebogo.markvault.network.JwMediaApi.fetchByKey(key)
                                                    }.getOrNull()
                                                    if (media != null) {
                                                        val saved = vm.findOrSaveMedia(media)
                                                        vm.setNowPlayingMedia(saved)
                                                        nav.navigate("mediaPlayer/${saved.id}")
                                                    } else {
                                                        // Fallback: open in web viewer
                                                        val encUrl = java.net.URLEncoder.encode(urlStr, "UTF-8")
                                                        val encLabel = java.net.URLEncoder.encode("JW.org Video", "UTF-8")
                                                        nav.navigate("web/$encUrl/$encLabel")
                                                    }
                                                }
                                                return true
                                            }
                                        }
                                    }
                                    // v5.4.205cc — Handle scripture detection links.
                                    // markvault://scripture/{bookNum}/{chapter}/{verseRef}
                                    // verseRef may be "14", "7-9", "8,10", "7-9,12" etc.
                                    val parsed = com.tebogo.markvault.util.ScriptureDetector
                                        .parseScriptureUri(u)
                                    if (parsed != null) {
                                        val (bn, ch, verseRef) = parsed
                                        val anchors = com.tebogo.markvault.util.ScriptureDetector
                                            .buildVerseAnchors(bn, ch, verseRef)
                                        val anchorStr = anchors.joinToString(",")
                                        htmlScope.launch {
                                            val noteId = vm.findNwtNoteId(bn, ch)
                                            if (noteId != null) {
                                                vm.setPendingScriptureAnchor(anchorStr)
                                                nav.navigate("htmlReader/$noteId")
                                            } else {
                                                // Fall back to wol.jw.org using first verse
                                                val firstVs = com.tebogo.markvault.util.ScriptureDetector
                                                    .firstVerseOf(verseRef)
                                                val code = "%02d%03d%03d".format(bn, ch, firstVs)
                                                val url = "https://www.jw.org/finder?srcid=jwlshare" +
                                                    "&wtlocale=E&prefer=lang&bible=$code&pub=nwtsty"
                                                val encUrl = java.net.URLEncoder.encode(url, "UTF-8")
                                                val encLabel = java.net.URLEncoder.encode("NWT", "UTF-8")
                                                nav.navigate("web/$encUrl/$encLabel")
                                            }
                                        }
                                        return true
                                    }
                                    // v5.4.37 — Route JW Library links to
                                    // the JW Library app instead of the
                                    // in-app browser. Converts WOL bible
                                    // URLs to finder format automatically.
                                    when (com.tebogo.markvault.util.routeLink(u)) {
                                        com.tebogo.markvault.util.LinkTarget.JW_LIBRARY_APP -> {
                                            com.tebogo.markvault.util.openInJwLibrary(ctx, u) {
                                                // No JW Library → fall back to in-app browser
                                                view?.clearHistory()
                                                view?.clearCache(false)
                                                needsReload = true
                                                val freshUrl = String(u.toString().toCharArray())
                                                val freshHost = u.host?.let { String(it.toCharArray()) } ?: "Link"
                                                val encUrl = java.net.URLEncoder.encode(freshUrl, "UTF-8")
                                                val encLabel = java.net.URLEncoder.encode(freshHost, "UTF-8")
                                                nav.navigate("web/$encUrl/$encLabel")
                                            }
                                            return true
                                        }
                                        com.tebogo.markvault.util.LinkTarget.IN_APP_WEBVIEW -> {
                                            view?.clearHistory()
                                            view?.clearCache(false)
                                            needsReload = true
                                            val freshUrl = String(u.toString().toCharArray())
                                            val freshHost = u.host?.let { String(it.toCharArray()) } ?: "Link"
                                            val encUrl = java.net.URLEncoder.encode(freshUrl, "UTF-8")
                                            val encLabel = java.net.URLEncoder.encode(freshHost, "UTF-8")
                                            nav.navigate("web/$encUrl/$encLabel")
                                        }
                                        com.tebogo.markvault.util.LinkTarget.SYSTEM_BROWSER -> {
                                            com.tebogo.markvault.util.openExternally(ctx, u)
                                        }
                                    }
                                    return true
                                }

                                override fun onPageFinished(view: WebView?, url: String?) {
                                    super.onPageFinished(view, url)
                                    // v5.4.35 — Clear the forward-history
                                    // stack every time the local HTML page
                                    // finishes loading. This prevents the
                                    // WebView from retaining stale entries
                                    // from previously intercepted external
                                    // URLs, which caused the "stuck first
                                    // link" bug when returning from the
                                    // in-app browser.
                                    view?.clearHistory()
                                    // v5.4.217cc — Highlight JW.org video links in
                                    // articles with a red ▶ so the user knows they
                                    // are tappable to play in the media player.
                                    view?.evaluateJavascript(
                                        "(function(){try{document.querySelectorAll('a[href]')" +
                                        ".forEach(function(a){var h=a.href||'';" +
                                        "if(h.includes('jw.org')&&(" +
                                        "h.includes('subtype=rendered')||h.includes('library/videos')||" +
                                        "(h.includes('finder')&&h.includes('docid')&&" +
                                        "!h.includes('pub=nwtsty')&&!h.includes('bible=')))){" +
                                        "a.style.borderLeft='3px solid #cc3333';" +
                                        "a.style.paddingLeft='4px';" +
                                        "if(!a.dataset.mvVideo){a.dataset.mvVideo='1';" +
                                        "var s=document.createElement('span');" +
                                        "s.textContent='\\u25B6 ';" +
                                        "s.style.color='#cc3333';s.style.fontSize='0.85em';" +
                                        "a.insertBefore(s,a.firstChild);}}})" +
                                        "}catch(e){}})();",
                                        null
                                    )
                                    // scroll position ONCE per note-load.
                                    // Two-frame delay lets the WebView
                                    // finish layout so the target scroll
                                    // is within the scrollable range —
                                    // scrolling before layout produces a
                                    // silent no-op. Guard on
                                    // `scrollRestored` so navigation
                                    // within the article (link taps) after
                                    // the initial restore doesn't yank the
                                    // user back to the start.
                                    val toRestore = initialScrollToApply
                                    if (view != null && !scrollRestored &&
                                        toRestore != null && toRestore > 0
                                    ) {
                                        scrollRestored = true
                                        initialScrollToApply = null
                                        view.postDelayed({
                                            view.evaluateJavascript(
                                                "window.scrollTo(0, $toRestore);", null
                                            )
                                            // Fallback: also set the
                                            // native scroll on the View
                                            // in case the page height
                                            // isn't fully realised in JS
                                            // yet. WebView's own scroll
                                            // will follow the JS scroll
                                            // once the page fills.
                                            runCatching { view.scrollTo(0, toRestore) }
                                        }, 120L)
                                    }
                                    // Inject highlight JS for the pending search
                                    // term — flashes the searched word in the
                                    // article so the user doesn't have to find
                                    // it manually. Consume the pending value so
                                    // it doesn't re-fire on later navigations.
                                    // v5.4.6 — gated by articleHighlightEnabled
                                    // toggle so users can disable the text-node
                                    // walk if they suspect it's contributing
                                    // to crashes.
                                    // v5.4.10 — pendingHighlight is now a
                                    // data class with the exact-phrase flag.
                                    val pending = vm.consumePendingHighlight()
                                    val highlightOn = vm.articleHighlightEnabled.value
                                    if (pending != null && pending.query.isNotBlank() &&
                                        view != null && highlightOn) {
                                        val hlMode = vm.effectiveHighlightMode()
                                        view.evaluateJavascript(
                                            buildHighlightJs(
                                                pending.query, hlMode,
                                                pending.isPhrase, pending.snippet
                                            ),
                                            null
                                        )
                                        // v5.4.76cc — If the Phi-4-mini expander
                                        // produced paraphrases for this query,
                                        // also paint them in a softer lavender
                                        // so the user has an in-article "AI
                                        // trace" alongside the primary yellow
                                        // highlight on their original tokens.
                                        // No-op when llmTerms is empty.
                                        if (pending.llmTerms.isNotEmpty()) {
                                            view.evaluateJavascript(
                                                buildLlmHighlightJsHtml(pending.llmTerms),
                                                null
                                            )
                                        }
                                    }
                                    // v5.4.182cc — Inject scripture detection JS
                                    // after all other injections so it runs on the
                                    // fully-rendered page (highlights, scroll restore).
                                    if (view != null && scriptureDetectionOn) {
                                        view.postDelayed({
                                            view.evaluateJavascript(
                                                com.tebogo.markvault.util.ScriptureDetector
                                                    .scriptureDetectionJs,
                                                null
                                            )
                                        }, 200L)
                                    }
                                    // v5.4.182cc — Consume pending verse anchor and
                                    // scroll-to + highlight the verse element.
                                    val scriptureAnchor = vm.consumePendingScriptureAnchor()
                                    if (view != null && !scriptureAnchor.isNullOrBlank()) {
                                        view.postDelayed({
                                            view.evaluateJavascript(
                                                com.tebogo.markvault.util.ScriptureDetector
                                                    .verseHighlightJs
                                                    .replace("__ANCHOR__", scriptureAnchor),
                                                null
                                            )
                                        }, 350L)
                                    }
                                }

                                override fun onRenderProcessGone(
                                    view: WebView?, detail: RenderProcessGoneDetail?
                                ): Boolean {
                                    rendererCrashed = true
                                    runCatching { view?.destroy() }
                                    return true
                                }
                            }

                            onSearchInMarkVault = { text ->
                                vm.requestPendingSearch(text)
                                nav.navigate("search") { launchSingleTop = true }
                            }
                            onSearchInWol = { text ->
                                val target = "https://wol.jw.org/en/wol/s/r1/lp-e?q=" +
                                    java.net.URLEncoder.encode(text, "UTF-8")
                                vm.requestWebPopup(target)
                            }

                            webViewRef = this
                        }
                    },
                    update = { w ->
                        val html = htmlContent ?: return@AndroidView
                        // v5.4.35 — When the user returns from the in-app
                        // browser, force the WebView to fully reload the
                        // offline HTML. This clears any stale internal URL
                        // routing state that caused "stuck first link".
                        if (needsReload && htmlLoaded) {
                            w.clearHistory()
                            w.clearCache(false)
                            htmlLoaded = false
                            needsReload = false
                        }
                        if (!htmlLoaded) {
                            // v5.4.25 — Inject a viewport meta tag so
                            // the WebView renders at device width. User
                            // HTML often lacks this and would otherwise
                            // lay out at 980px, forcing sideways scroll.
                            // If the HTML already has a viewport tag,
                            // the browser uses the first one — this
                            // injection is safely no-op in that case.
                            val viewportMeta =
                                "<meta name=\"viewport\" content=\"width=device-width, " +
                                    "initial-scale=1.0\">"
                            // v5.4.29 — Mobile-fit CSS override (see
                            // ReaderScreen for rationale). Forces desktop-
                            // width elements to constrain to phone width.
                            val mobileFitCss =
                                "<style id=\"mv-mobile-fit\">" +
                                    "html,body{max-width:100vw!important;overflow-x:hidden!important;" +
                                    "word-wrap:break-word;overflow-wrap:break-word}" +
                                    "*{max-width:100%!important;box-sizing:border-box!important}" +
                                    "img,video,iframe,svg,canvas{max-width:100%!important;height:auto!important}" +
                                    "table{width:100%!important;display:block!important;overflow-x:auto!important}" +
                                    "pre,code{white-space:pre-wrap!important;word-break:break-word!important}" +
                                    "</style>"
                            val headInjection = viewportMeta + mobileFitCss
                            val patched = run {
                                val lower = html.lowercase()
                                val headOpen = lower.indexOf("<head")
                                if (headOpen >= 0) {
                                    val after = html.indexOf('>', headOpen) + 1
                                    if (after > 0)
                                        html.substring(0, after) + headInjection + html.substring(after)
                                    else html
                                } else {
                                    val htmlOpen = lower.indexOf("<html")
                                    if (htmlOpen >= 0) {
                                        val after = html.indexOf('>', htmlOpen) + 1
                                        if (after > 0)
                                            html.substring(0, after) +
                                                "<head>" + headInjection + "</head>" +
                                                html.substring(after)
                                        else html
                                    } else {
                                        "<!doctype html><html><head>" + headInjection +
                                            "</head><body>" + html + "</body></html>"
                                    }
                                }
                            }
                            runCatching {
                                w.loadDataWithBaseURL(
                                    baseUrl ?: "about:blank",
                                    patched,
                                    "text/html",
                                    "utf-8",
                                    null
                                )
                            }
                            htmlLoaded = true
                        }
                        // v5.4.155cc — Scroll-to-hide toolbar, same pattern as
                        // ReaderScreen update lambda and WebSearchScreen.
                        if (enableFullscreenMode) {
                            w.setOnScrollChangeListener { _, _, scrollY, _, _ ->
                                latestScroll.value = scrollY
                                val scrollDelta = scrollY - lastHtmlScrollValue
                                if (scrollDelta > 20 && htmlToolbarsVisible) {
                                    htmlToolbarsVisible = false
                                    lastHtmlScrollValue = scrollY
                                } else if (scrollDelta < -3 && !htmlToolbarsVisible) {
                                    htmlToolbarsVisible = true
                                    lastHtmlScrollValue = scrollY
                                } else if (kotlin.math.abs(scrollDelta) < 2) {
                                    lastHtmlScrollValue = scrollY
                                }
                            }
                        } else {
                            htmlToolbarsVisible = true
                            lastHtmlScrollValue = latestScroll.value
                            w.setOnScrollChangeListener { _, _, scrollY, _, _ ->
                                latestScroll.value = scrollY
                            }
                        }
                    }
                )
            }

            // v5.4.181cc — "Jump to top", same pattern as ReaderScreen's
            // markdown reader (reuses the existing webViewRef + latestScroll
            // already set up for the v5.4.155cc scroll-to-hide work — no
            // new capture logic needed). Instant jump via the plain View
            // scrollTo(0,0) method.
            if (latestScroll.value > 400) {
                Surface(
                    color = MaterialTheme.colorScheme.secondaryContainer.copy(alpha = 0.95f),
                    shape = RoundedCornerShape(16.dp),
                    shadowElevation = 4.dp,
                    modifier = Modifier
                        .align(Alignment.BottomStart)
                        .padding(start = 16.dp, bottom = 16.dp)
                        .clickable { webViewRef?.scrollTo(0, 0) }
                ) {
                    Text(
                        "🔝 Top",
                        color = MaterialTheme.colorScheme.onSecondaryContainer,
                        fontWeight = FontWeight.SemiBold,
                        fontSize = 13.sp,
                        modifier = Modifier.padding(horizontal = 14.dp, vertical = 10.dp)
                    )
                }
            }
        }

        // Bottom toolbar — hidden when toolbars scroll-hidden (v5.4.155cc)
        if (htmlToolbarsVisible) {
        // Full set: back / find / refresh / load-online / open-externally / home / overflow.
        MarkVaultBottomBar(
            nav = nav,
            vm = vm,
            extraActions = {
                // v4.22.1 — Summarise current HTML article via on-device chat
                // v5.2.0 — Hidden until the chat model is installed.
                val chatReady by vm.chatModelInstalled.collectAsStateWithLifecycle()
                if (chatReady) {
                    IconButton(onClick = {
                        vm.summarizeNote(id, "html")
                        nav.navigate("chat") { launchSingleTop = true }
                    }) {
                        androidx.compose.material3.Text("\u2728", fontSize = 18.sp)
                    }
                }
                // Find-in-page toggle
                IconButton(onClick = { findOpen = !findOpen }) {
                    Icon(Icons.Default.Search, contentDescription = "Find in page")
                }
                // v5.4.35 — Refresh: reload the current offline HTML
                // page in the WebView. Useful if JS injection or CSS
                // overrides rendered incorrectly.
                IconButton(onClick = { webViewRef?.reload() }) {
                    Text("\uD83D\uDD04", fontSize = 18.sp)
                }
                // v5.4.35 — Load Online: open the original source URL
                // in the in-app browser. Tries sourceUrl (extracted from
                // HTML meta tags), falls back to originalUri (the file's
                // SAF URI, which may be a content:// and not openable
                // as a web page — in that case the button is hidden).
                val onlineUrl = sourceUrl ?: originalUri?.toString()?.takeIf {
                    it.startsWith("http://") || it.startsWith("https://")
                }
                if (onlineUrl != null) {
                    IconButton(onClick = {
                        val encUrl = java.net.URLEncoder.encode(onlineUrl, "UTF-8")
                        val host = runCatching { Uri.parse(onlineUrl).host }.getOrNull() ?: "Online"
                        val encLabel = java.net.URLEncoder.encode(host, "UTF-8")
                        needsReload = true
                        nav.navigate("web/$encUrl/$encLabel")
                    }) {
                        Text("\uD83C\uDF10", fontSize = 18.sp)
                    }
                }
                // v5.4.37 — Open in JW Library: detects jw.org
                // source URL and opens it in JW Library app.
                val jwUri = (sourceUrl ?: originalUri?.toString())?.let { url ->
                    runCatching { Uri.parse(url) }.getOrNull()
                }?.takeIf { com.tebogo.markvault.util.isJwHost(it) }
                if (jwUri != null) {
                    IconButton(onClick = {
                        com.tebogo.markvault.util.openInJwLibrary(ctx, jwUri) {
                            // Fallback: open in in-app browser
                            val encUrl = java.net.URLEncoder.encode(jwUri.toString(), "UTF-8")
                            val host = jwUri.host ?: "jw.org"
                            val encLabel = java.net.URLEncoder.encode(host, "UTF-8")
                            nav.navigate("web/$encUrl/$encLabel")
                        }
                    }) {
                        Text("\uD83D\uDCD6", fontSize = 18.sp) // 📖
                    }
                }
                // Open externally
                IconButton(onClick = {
                    originalUri?.let { uri ->
                        runCatching {
                            ctx.startActivity(
                                android.content.Intent(
                                    android.content.Intent.ACTION_VIEW, uri
                                ).addFlags(
                                    android.content.Intent.FLAG_GRANT_READ_URI_PERMISSION
                                )
                            )
                        }
                    }
                }) {
                    Text("\u2197", fontSize = 18.sp)
                }
            }
        )
        } // end if (htmlToolbarsVisible) — MarkVaultBottomBar
    }
    } // v5.4.23 — end padded center Box
    // v5.4.19 — FAB overlay for "Find in article" — shown only when
    // opened from a search result AND the toggle is on. Wired to the
    // existing find bar so behavior matches WebSearchScreen's find UX.
    // v5.4.34 — Two compact FABs matching ReaderScreen: keyword + semantic.
    val showKeywordFab = openedFromSearchLatched && fabEnabled &&
        currentSearchQuery.trim().removeSurrounding("\"").length >= 2
    val showSemanticFab = semanticInArticleOn &&
        currentSearchQuery.trim().removeSurrounding("\"").length >= 2

    if (showKeywordFab || showSemanticFab) {
        Column(
            Modifier.align(Alignment.BottomEnd).padding(16.dp),
            horizontalAlignment = Alignment.End,
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            if (showSemanticFab) {
                // v5.4.129cc — In-article semantic-search popup trigger.
                // The FAB now (1) shows the ranked passages in a floating
                // popup with a typewriter effect and (2) still calls the
                // native WebView find so the underlying article scrolls
                // to the top match. When a popup is minimized, the icon
                // pulses like a heartbeat as a subtle alert.
                val popupState by vm.articlePopupState.collectAsState()
                val hasMinimized: Boolean = popupState.let {
                    it is com.tebogo.markvault.AppViewModel.ArticlePopupState.Visible &&
                        it.minimized
                }
                PumpingBrainFab(
                    pulsing = hasMinimized,
                    busy = fabBusy,
                    onClick = {
                        val wv = webViewRef ?: return@PumpingBrainFab
                        // If a minimized popup exists, tapping the brain
                        // brings it back to full size instead of starting
                        // a new search — matches the "brain icon can also
                        // maximize the popup" requirement.
                        if (hasMinimized) {
                            vm.maximizeArticlePopup()
                            return@PumpingBrainFab
                        }
                        val rawQ = currentSearchQuery.trim()
                            .removeSurrounding("\"").trim()
                        if (rawQ.length < 2) return@PumpingBrainFab
                        // v5.4.144cc — Popup now shows ONLY the text that
                        // is yellow-highlighted in the article (mark.mv-hl).
                        // Extract from the live DOM via evaluateJavascript
                        // instead of running a separate semantic search.
                        vm.setArticlePopupLoading(id, rawQ)
                        wv.evaluateJavascript(
                            """(function(){
                              var marks = document.querySelectorAll('mark.mv-hl');
                              var texts = []; var seen = {};
                              for (var i = 0; i < marks.length && texts.length < 20; i++) {
                                var t = (marks[i].textContent || '').replace(/\s+/g,' ').trim();
                                if (t.length > 1 && !seen[t]) { seen[t]=1; texts.push(t); }
                              }
                              return JSON.stringify(texts);
                            })()"""
                        ) { result ->
                            val passages = decodeJsHighlightArray(result)
                            vm.showArticlePopupWithPassages(id, rawQ, passages)
                        }
                    }
                )
            }
            if (showKeywordFab) {
                // v5.4.158cc — Press feedback (squish on tap).
                val keywordFabInteraction = remember { MutableInteractionSource() }
                androidx.compose.material3.SmallFloatingActionButton(
                    onClick = {
                        val wv = webViewRef ?: return@SmallFloatingActionButton
                        val rawQ = currentSearchQuery.trim()
                            .removeSurrounding("\"").trim()
                        if (rawQ.length < 2) return@SmallFloatingActionButton
                        findQuery = rawQ
                        findOpen = true
                        wv.findAllAsync(rawQ)
                    },
                    interactionSource = keywordFabInteraction,
                    modifier = Modifier.fabPressScale(keywordFabInteraction)
                ) {
                    Text("\uD83D\uDD0D", fontSize = 16.sp)
                }
            }
        }
    }

    // ── v5.4.129cc — In-article semantic-search popup overlay ──
    // Rendered aligned to the top-center of the reader Box so it sits
    // above the article content but out of the way of the FAB column
    // in the bottom-right. Drag the popup title bar to move it.
    // When the popup is minimized, a compact pill anchors bottom-start
    // (opposite corner from the FABs so the two never overlap).
    // v5.4.142cc — Multi-bubble system.
    val htmlBubbles by vm.popupBubbles.collectAsStateWithLifecycle()
    var htmlNearBottomBubbleId by remember { mutableStateOf<String?>(null) }
    // v5.4.150cc — Typing speed backed by DataStore.
    val popupTypingSpeed by vm.popupTypingSpeed.collectAsStateWithLifecycle()

    val htmlPopupState by vm.articlePopupState.collectAsState()
    val htmlPopupSlot: com.tebogo.markvault.AppViewModel.ArticlePopupState = htmlPopupState
    when (htmlPopupSlot) {
        is com.tebogo.markvault.AppViewModel.ArticlePopupState.Loading -> {
            ArticlePopupLoading(
                query = htmlPopupSlot.query,
                onCancel = { vm.closeArticlePopup() },
                modifier = Modifier
                    .align(Alignment.BottomCenter)
                    .padding(bottom = 80.dp, start = 16.dp, end = 16.dp)
            )
        }
        is com.tebogo.markvault.AppViewModel.ArticlePopupState.Empty -> {
            ArticlePopupEmpty(
                query = htmlPopupSlot.query,
                onClose = { vm.closeArticlePopup() },
                modifier = Modifier
                    .align(Alignment.BottomCenter)
                    .padding(bottom = 80.dp, start = 16.dp, end = 16.dp)
            )
        }
        is com.tebogo.markvault.AppViewModel.ArticlePopupState.Visible -> {
            val htmlArticleText: String = noteContentForSemantic ?: ""
            ArticlePopupOverlay(
                query = htmlPopupSlot.query,
                passages = htmlPopupSlot.passages,
                onClose = { vm.closeArticlePopup() },
                onMinimize = { vm.minimizeCurrentPopupToBubble() },
                onCycleBlur = { vm.cycleArticlePopupBlur() },
                onOpenUrl = { url ->
                    runCatching {
                        val encUrl = java.net.URLEncoder.encode(url, "UTF-8")
                        val label: String = runCatching {
                            android.net.Uri.parse(url).host ?: "Link"
                        }.getOrDefault("Link")
                        val encLabel = java.net.URLEncoder.encode(label, "UTF-8")
                        nav.navigate("web/$encUrl/$encLabel")
                    }
                },
                mode = htmlPopupSlot.mode,
                onToggleMode = {
                    val slotNoteId = htmlPopupSlot.noteId
                    val slotQuery  = htmlPopupSlot.query
                    vm.toggleArticlePopupMode(slotNoteId, htmlArticleText, slotQuery)
                },
                // v5.4.150cc — Speed backed by DataStore.
                typingSpeed = popupTypingSpeed,
                onTypingSpeedChange = { vm.setPopupTypingSpeed(it) },
                // v5.4.150cc — Start at bottom-center.
                modifier = Modifier
                    .align(Alignment.BottomCenter)
                    .padding(bottom = 80.dp, start = 12.dp, end = 12.dp)
            )
        }
        is com.tebogo.markvault.AppViewModel.ArticlePopupState.Hidden -> {
            // Nothing rendered
        }
    }

    // v5.4.142cc — Active bubbles and close zone.
    htmlBubbles.forEachIndexed { index, bubble ->
        DraggableBubble(
            bubble = bubble,
            startOffsetX = (index * 210).toFloat(),
            startOffsetY = 0f,
            onRestore = { vm.restoreBubble(bubble.id) },
            onNearBottomChanged = { isNear ->
                htmlNearBottomBubbleId = if (isNear) bubble.id
                else if (htmlNearBottomBubbleId == bubble.id) null
                else htmlNearBottomBubbleId
            },
            modifier = Modifier
                .align(Alignment.BottomStart)
                .padding(start = 16.dp, bottom = 72.dp)
        )
    }
    BubbleCloseZone(
        visible = htmlNearBottomBubbleId != null,
        onCloseThis = {
            val id = htmlNearBottomBubbleId ?: return@BubbleCloseZone
            vm.closeBubble(id)
            htmlNearBottomBubbleId = null
        },
        onCloseAll = {
            vm.closeAllPopupsAndBubbles()
            htmlNearBottomBubbleId = null
        },
        modifier = Modifier.align(Alignment.BottomCenter)
    )
    // v5.4.23 — Tablet three-column side panels for HTML. Rendered
    // only when workspace mode is ON and window width ≥ 600dp. Left
    // panel mirrors ReaderScreen's tab list; right panel shows the
    // HTML document's h1-h6 outline with tap-to-scroll via
    // querySelectorAll.
    // v5.4.24 — Collapsibility + status bar padding.
    if (threeColumn && leftPanelOpen) {
        Column(
            Modifier
                .align(Alignment.TopStart)
                .width(leftColWidth)
                .fillMaxHeight()
                .background(MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.35f))
                .statusBarsPadding()
                .padding(12.dp)
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(
                    "\uD83E\uDDF0 Workspace",
                    fontSize = 15.sp,
                    fontWeight = androidx.compose.ui.text.font.FontWeight.Bold,
                    modifier = Modifier.weight(1f)
                )
                IconButton(
                    onClick = { leftPanelOpen = false },
                    modifier = Modifier.size(28.dp)
                ) {
                    Text("◀", fontSize = 14.sp)
                }
            }
            Spacer(Modifier.height(2.dp))
            Text(
                "Open tabs",
                fontSize = 11.sp,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
            Spacer(Modifier.height(10.dp))
            LazyColumn(
                Modifier.weight(1f).fillMaxWidth()
            ) {
                items(
                    tabs, key = { it.id }
                ) { tab ->
                    val selected = tab.id == activeTab
                    Surface(
                        color = if (selected)
                            MaterialTheme.colorScheme.primary.copy(alpha = 0.18f)
                        else androidx.compose.ui.graphics.Color.Transparent,
                        shape = androidx.compose.foundation.shape.RoundedCornerShape(8.dp),
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(vertical = 2.dp)
                            .clickable {
                                vm.setActiveTab(tab.id)
                            }
                    ) {
                        Row(
                            Modifier.padding(horizontal = 10.dp, vertical = 8.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                when (tab.fileType) {
                                    "pdf" -> "\uD83D\uDCC4"
                                    "html", "htm" -> "\uD83C\uDF10"
                                    else -> "\uD83D\uDCDD"
                                },
                                fontSize = 14.sp
                            )
                            Spacer(Modifier.width(8.dp))
                            Text(
                                tab.title,
                                modifier = Modifier.weight(1f),
                                fontSize = 12.sp,
                                maxLines = 1,
                                overflow = androidx.compose.ui.text.style.TextOverflow.Ellipsis,
                                fontWeight = if (selected)
                                    androidx.compose.ui.text.font.FontWeight.SemiBold
                                else androidx.compose.ui.text.font.FontWeight.Normal
                            )
                            IconButton(
                                onClick = { vm.closeTab(tab.id) },
                                modifier = Modifier.size(22.dp)
                            ) {
                                Icon(
                                    androidx.compose.material.icons.Icons.Default.Close,
                                    contentDescription = "Close tab",
                                    modifier = Modifier.size(12.dp),
                                    tint = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }
                        }
                    }
                }
            }
            androidx.compose.material3.HorizontalDivider(
                Modifier.padding(vertical = 6.dp)
            )
            Row(
                Modifier
                    .fillMaxWidth()
                    .clickable { nav.navigate("home") }
                    .padding(vertical = 10.dp, horizontal = 8.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Icon(
                    androidx.compose.material.icons.Icons.Default.Add,
                    contentDescription = null,
                    modifier = Modifier.size(16.dp)
                )
                Spacer(Modifier.width(8.dp))
                Text("Open a new tab", fontSize = 13.sp)
            }
        }
        // Right panel: HTML outline
        }
    if (threeColumn && rightPanelOpen) {
        Column(
            Modifier
                .align(Alignment.TopEnd)
                .width(rightColWidth)
                .fillMaxHeight()
                .background(MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.35f))
                .statusBarsPadding()
                .padding(12.dp)
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(
                    "\uD83D\uDCD1 Outline",
                    fontSize = 15.sp,
                    fontWeight = androidx.compose.ui.text.font.FontWeight.Bold,
                    modifier = Modifier.weight(1f)
                )
                IconButton(
                    onClick = { rightPanelOpen = false },
                    modifier = Modifier.size(28.dp)
                ) {
                    Text("▶", fontSize = 14.sp)
                }
            }
            Spacer(Modifier.height(2.dp))
            Text(
                "${htmlHeadings.size} heading${if (htmlHeadings.size == 1) "" else "s"}",
                fontSize = 11.sp,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
            Spacer(Modifier.height(10.dp))
            if (htmlHeadings.isEmpty()) {
                Text(
                    "No headings in this document.",
                    fontSize = 12.sp,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            } else {
                LazyColumn(
                    Modifier.weight(1f).fillMaxWidth()
                ) {
                    items(htmlHeadings) { h ->
                        Text(
                            h.text,
                            Modifier
                                .fillMaxWidth()
                                .clickable {
                                    // Scroll to the Nth heading via
                                    // querySelectorAll — works for any
                                    // HTML loaded via loadDataWithBaseURL
                                    // regardless of whether the source has
                                    // its own IDs.
                                    webViewRef?.evaluateJavascript(
                                        "(function(){var hs=document.querySelectorAll('h1,h2,h3,h4,h5,h6');" +
                                            "if(hs.length > ${h.index}) hs[${h.index}]." +
                                            "scrollIntoView({behavior:'smooth',block:'start'});})();",
                                        null
                                    )
                                }
                                .padding(
                                    start = ((h.level - 1) * 10).dp,
                                    top = 8.dp, bottom = 8.dp
                                ),
                            fontSize = if (h.level <= 2) 12.sp else 11.sp,
                            fontWeight = if (h.level <= 2)
                                androidx.compose.ui.text.font.FontWeight.SemiBold
                            else androidx.compose.ui.text.font.FontWeight.Normal,
                            color = if (h.level <= 2) MaterialTheme.colorScheme.onSurface
                            else MaterialTheme.colorScheme.onSurfaceVariant,
                            maxLines = 3,
                            overflow = androidx.compose.ui.text.style.TextOverflow.Ellipsis
                        )
                    }
                }
            }
        }
    }
    // v5.4.24 — Corner reopen buttons appear when panels are collapsed.
    if (threeColumn && !leftPanelOpen) {
        IconButton(
            onClick = { leftPanelOpen = true },
            modifier = Modifier
                .align(Alignment.TopStart)
                .statusBarsPadding()
                .padding(4.dp)
                .size(40.dp)
        ) {
            Icon(
                androidx.compose.material.icons.Icons.Default.Menu,
                contentDescription = "Show left panel",
                tint = MaterialTheme.colorScheme.onSurface
            )
        }
    }
    if (threeColumn && !rightPanelOpen) {
        IconButton(
            onClick = { rightPanelOpen = true },
            modifier = Modifier
                .align(Alignment.TopEnd)
                .statusBarsPadding()
                .padding(4.dp)
                .size(40.dp)
        ) {
            Text("📑", fontSize = 18.sp)
        }
    }
    }

    // v5.4.36 — Link long-press action sheet for offline HTML articles.
    longPressLinkUrl?.let { href ->
        androidx.compose.material3.ModalBottomSheet(
            onDismissRequest = { longPressLinkUrl = null; longPressLinkText = null }
        ) {
            Column(Modifier.fillMaxWidth().padding(horizontal = 18.dp, vertical = 8.dp)) {
                Text(
                    href,
                    fontSize = 12.sp,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    maxLines = 2,
                    overflow = androidx.compose.ui.text.style.TextOverflow.Ellipsis,
                    modifier = Modifier.padding(bottom = 8.dp)
                )
                androidx.compose.material3.TextButton(
                    onClick = {
                        val host = runCatching { Uri.parse(href).host }.getOrNull() ?: "Link"
                        needsReload = true
                        val encUrl = java.net.URLEncoder.encode(href, "UTF-8")
                        val encLabel = java.net.URLEncoder.encode(host, "UTF-8")
                        longPressLinkUrl = null; longPressLinkText = null
                        nav.navigate("web/$encUrl/$encLabel")
                    },
                    modifier = Modifier.fillMaxWidth()
                ) { Text("\uD83E\uDE9F  Open in browser") }
                androidx.compose.material3.TextButton(
                    onClick = {
                        val cm = ctx.getSystemService(android.content.Context.CLIPBOARD_SERVICE)
                                as? android.content.ClipboardManager
                        cm?.setPrimaryClip(
                            android.content.ClipData.newPlainText("MarkVault link", href)
                        )
                        android.widget.Toast.makeText(ctx, "Link copied", android.widget.Toast.LENGTH_SHORT).show()
                        longPressLinkUrl = null; longPressLinkText = null
                    },
                    modifier = Modifier.fillMaxWidth()
                ) { Text("\uD83D\uDCCB  Copy link") }
                if (!longPressLinkText.isNullOrBlank()) {
                    androidx.compose.material3.TextButton(
                        onClick = {
                            val cm = ctx.getSystemService(android.content.Context.CLIPBOARD_SERVICE)
                                    as? android.content.ClipboardManager
                            cm?.setPrimaryClip(
                                android.content.ClipData.newPlainText("Link text", longPressLinkText)
                            )
                            android.widget.Toast.makeText(ctx, "Link text copied", android.widget.Toast.LENGTH_SHORT).show()
                            longPressLinkUrl = null; longPressLinkText = null
                        },
                        modifier = Modifier.fillMaxWidth()
                    ) { Text("\uD83D\uDCDD  Copy link text") }
                    androidx.compose.material3.TextButton(
                        onClick = {
                            val query = longPressLinkText ?: return@TextButton
                            vm.query.value = query
                            longPressLinkUrl = null; longPressLinkText = null
                            nav.navigate("search") { launchSingleTop = true }
                        },
                        modifier = Modifier.fillMaxWidth()
                    ) { Text("\uD83D\uDD0D  Search in library") }
                }
            }
        }
    }
}

/**
 * Find-in-page bar — text input + prev/next + close, identical to the one in
 * WebSearchScreen so the experience is consistent. Auto-focuses when opened.
 */
@Composable
private fun FindInPageBar(
    query: String,
    onQueryChange: (String) -> Unit,
    onNext: () -> Unit,
    onPrev: () -> Unit,
    onClose: () -> Unit
) {
    val focus = remember { FocusRequester() }
    LaunchedEffect(Unit) { runCatching { focus.requestFocus() } }
    Surface(
        modifier = Modifier.fillMaxWidth(),
        color = MaterialTheme.colorScheme.surfaceVariant
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 12.dp, vertical = 6.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Icon(
                Icons.Default.Search,
                contentDescription = null,
                modifier = Modifier.size(18.dp),
                tint = MaterialTheme.colorScheme.onSurfaceVariant
            )
            Spacer(Modifier.width(8.dp))
            BasicTextField(
                value = query,
                onValueChange = onQueryChange,
                singleLine = true,
                modifier = Modifier
                    .weight(1f)
                    .focusRequester(focus),
                textStyle = TextStyle(
                    fontSize = 14.sp,
                    color = MaterialTheme.colorScheme.onSurface
                )
            )
            IconButton(onClick = onPrev) {
                Icon(Icons.Default.KeyboardArrowUp, contentDescription = "Previous")
            }
            IconButton(onClick = onNext) {
                Icon(Icons.Default.KeyboardArrowDown, contentDescription = "Next")
            }
            IconButton(onClick = onClose) {
                Icon(Icons.Default.Close, contentDescription = "Close find")
            }
        }
    }
}

@Composable
private fun ErrorPane(
    message: String,
    onOpenExternally: () -> Unit,
    onRetry: () -> Unit
) {
    Column(
        Modifier.fillMaxSize().padding(24.dp),
        verticalArrangement = Arrangement.Center,
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Text("\u26A0\uFE0F", fontSize = 32.sp)
        Spacer(Modifier.size(14.dp))
        Text(
            "Couldn't display this page",
            fontSize = 17.sp,
            fontWeight = FontWeight.SemiBold
        )
        Spacer(Modifier.size(8.dp))
        Text(
            message,
            fontSize = 13.sp,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
            textAlign = TextAlign.Center
        )
        Spacer(Modifier.size(24.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            androidx.compose.material3.OutlinedButton(onClick = onRetry) {
                Text("Retry")
            }
            Button(onClick = onOpenExternally) {
                Text("Open externally")
            }
        }
    }
}

/**
 * v5.4.37 — Build a JavaScript snippet that highlights the most
 * relevant passage in the article and auto-scrolls to it.
 *
 * ## 5-strategy cascade (most precise → broadest)
 *
 * 1. **Snippet match** — Search for the FTS snippet text itself
 *    (the text that was displayed in the search result card). This
 *    is the most reliable needle because it's literal article text
 *    that the search engine already matched. We try progressively
 *    shorter substrings of the snippet (full → halves → thirds)
 *    to handle cases where the snippet spans multiple DOM nodes or
 *    includes whitespace that differs in the rendered HTML.
 *
 * 2. **Full-query phrase match** — Try the entire search query as
 *    a literal substring (e.g. "another name for Peter").
 *
 * 3. **Sentence-level smart match** — Extract distinctive terms
 *    from the query (≥4 chars, not stopwords) and highlight whole
 *    sentences that contain ANY of them.
 *
 * 4. **Word-level keyword match** — Wrap every occurrence of each
 *    distinctive query term individually.
 *
 * 5. **Single-best-word fallback** — Pick the longest meaningful
 *    word from the query that actually appears in the article body.
 *
 * Each strategy is tried in order. The first one that produces ≥1
 * highlighted mark wins — subsequent strategies are skipped.
 *
 * ## Robustness features
 *
 * - **Hidden ancestor reveal**: walks up from every `<mark>` and
 *   forces display/visibility/opacity/aria-hidden/details open.
 * - **Retry at 400ms + 1500ms**: catches late-injected content.
 * - **User-scroll detection**: retries skip auto-scroll if the
 *   user has manually scrolled >200px.
 * - **Skips** SCRIPT, STYLE, MARK, NOSCRIPT, TEMPLATE, HEAD.
 * - **Idempotent** — every attempt clears previous marks first.
 */

/**
 * v5.4.144cc — Decode the JSON array string returned by the
 * yellow-highlight extraction evaluateJavascript call.
 *
 * The WebView wraps the JS return value in an outer JSON string, so
 * `JSON.stringify(["a","b"])` comes back as `"\"[\\\"a\\\",\\\"b\\\"]\""`
 * in the Kotlin callback. We unwrap the outer layer first, then parse
 * the inner JSON array.
 */
private fun decodeJsHighlightArray(raw: String?): List<String> {
    if (raw.isNullOrBlank() || raw == "null") return emptyList()
    return try {
        // Unwrap the outer JSON-string encoding added by the WebView
        val inner = org.json.JSONArray("[$raw]").getString(0)
        val arr = org.json.JSONArray(inner)
        (0 until arr.length()).mapNotNull { i ->
            arr.optString(i).trim().takeIf { it.isNotBlank() }
        }
    } catch (_: Exception) {
        emptyList()
    }
}

private fun buildHighlightJs(
    needle: String,
    mode: String = "smart",
    isPhrase: Boolean = false,
    snippet: String = ""
): String {
    val esc = needle
        .replace("\\", "\\\\")
        .replace("'", "\\'")
        .replace("\"", "\\\"")
        .replace("\n", " ")
    val snippetEsc = snippet
        .replace("\\", "\\\\")
        .replace("'", "\\'")
        .replace("\"", "\\\"")
        .replace("\n", " ")
    val modeEsc = if (mode == "keyword") "keyword" else "smart"
    val phraseFlag = if (isPhrase) "true" else "false"
    return """
        (function(){
          try {
            var raw = '$esc';
            var snippetText = '$snippetEsc';
            var mode = '$modeEsc';
            var isPhrase = $phraseFlag;
            if (!raw || raw.length < 2) return;

            var STOP = {the:1,is:1,a:1,an:1,of:1,to:1,and:1,in:1,on:1,
              "for":1,at:1,by:1,are:1,was:1,were:1,be:1,been:1,being:1,
              it:1,its:1,this:1,that:1,these:1,those:1,with:1,from:1,
              as:1,or:1,but:1,"if":1,so:1,"do":1,does:1,did:1,has:1,
              have:1,had:1,will:1,would:1,can:1,could:1,what:1,who:1,
              why:1,how:1,when:1,where:1,which:1,about:1,not:1,no:1,
              also:1,more:1,some:1,any:1,all:1,one:1,two:1,you:1,
              your:1,my:1,we:1,our:1,us:1,me:1,he:1,she:1,they:1,
              them:1,their:1,his:1,her:1,"i":1,see:1,note:1};

            function isSkip(tag) {
              return tag==='SCRIPT'||tag==='STYLE'||tag==='MARK'||
                     tag==='NOSCRIPT'||tag==='TEMPLATE'||tag==='HEAD';
            }
            function isH(t){return t==='H1'||t==='H2'||t==='H3'||
              t==='H4'||t==='H5'||t==='H6';}
            function inH(n){var a=n.parentNode;while(a&&a!==document.body){
              if(a.nodeName&&isH(a.nodeName))return true;a=a.parentNode;}
              return false;}

            function getTextNodes() {
              var w = document.createTreeWalker(
                document.body, NodeFilter.SHOW_TEXT, {
                  acceptNode: function(n) {
                    if (!n.nodeValue||!n.nodeValue.trim())
                      return NodeFilter.FILTER_REJECT;
                    var p = n.parentNode;
                    if (!p) return NodeFilter.FILTER_REJECT;
                    if (isSkip(p.nodeName)) return NodeFilter.FILTER_REJECT;
                    return NodeFilter.FILTER_ACCEPT;
                  }
                }, false);
              var out = []; var nd;
              while (nd = w.nextNode()) out.push(nd);
              return out;
            }

            function mk(text, s, e) {
              var m = document.createElement('mark');
              m.className = 'mv-hl';
              m.style.cssText = 'background:#ffe066;color:#000;padding:0 2px;border-radius:2px';
              m.appendChild(document.createTextNode(text.substring(s, e)));
              return m;
            }

            function clearAll() {
              var prev = document.querySelectorAll('mark.mv-hl');
              for (var i = 0; i < prev.length; i++) {
                var p = prev[i]; var pt = p.parentNode;
                if (!pt) continue;
                pt.replaceChild(document.createTextNode(p.textContent), p);
                try { pt.normalize(); } catch(e){}
              }
            }

            function unhideAll() {
              var HCLS=['hidden','hide','is-hidden','invisible',
                'd-none','collapse','collapsed'];
              var marks = document.querySelectorAll('mark.mv-hl');
              for (var mi = 0; mi < marks.length; mi++) {
                var a = marks[mi]; var d = 0;
                while (a && a !== document.body && d < 40) {
                  try {
                    if (a.nodeType === 1) {
                      var cs = window.getComputedStyle
                        ? window.getComputedStyle(a) : null;
                      if (cs) {
                        if (cs.display==='none')
                          a.style.setProperty('display','block','important');
                        if (cs.visibility==='hidden')
                          a.style.setProperty('visibility','visible','important');
                        var op = parseFloat(cs.opacity);
                        if (!isNaN(op) && op===0)
                          a.style.setProperty('opacity','1','important');
                      }
                      if (a.tagName==='DETAILS'&&a.open===false) a.open=true;
                      if (a.getAttribute&&a.getAttribute('aria-hidden')==='true')
                        a.setAttribute('aria-hidden','false');
                      if (a.classList) {
                        for (var ci=0;ci<HCLS.length;ci++)
                          if (a.classList.contains(HCLS[ci]))
                            a.classList.remove(HCLS[ci]);
                      }
                      if (a.hasAttribute&&a.hasAttribute('hidden'))
                        a.removeAttribute('hidden');
                    }
                  } catch(e){}
                  a = a.parentNode; d++;
                }
              }
            }

            // ---- Strategy: phrase/substring match ----
            // Wraps every occurrence of `needle` (case-insensitive) in
            // text nodes. Returns first mark or null.
            function phraseMatch(needle) {
              if (!needle || needle.length < 3) return null;
              var nodes = getTextNodes();
              var low = needle.toLowerCase();
              var len = needle.length;
              var first = null; var cap = 80;
              for (var i = 0; i < nodes.length && cap > 0; i++) {
                var t = nodes[i]; var text = t.nodeValue;
                var tlow = text.toLowerCase();
                var idx = 0; var ranges = [];
                while ((idx = tlow.indexOf(low, idx)) !== -1) {
                  ranges.push({s:idx, e:idx+len}); idx += len;
                }
                if (!ranges.length) continue;
                var parent = t.parentNode;
                var cursor = 0;
                var frag = document.createDocumentFragment();
                for (var r = 0; r < ranges.length && cap > 0; r++) {
                  var rr = ranges[r];
                  if (rr.s > cursor)
                    frag.appendChild(document.createTextNode(text.substring(cursor, rr.s)));
                  var m = mk(text, rr.s, rr.e);
                  if (!first) first = m;
                  frag.appendChild(m); cursor = rr.e; cap--;
                }
                if (cursor < text.length)
                  frag.appendChild(document.createTextNode(text.substring(cursor)));
                parent.replaceChild(frag, t);
              }
              return first;
            }

            // ---- Strategy: snippet substring cascade ----
            // Tries the full snippet, then halves, then thirds.
            function snippetCascade(snip) {
              if (!snip || snip.length < 6) return null;
              // Clean common indexer artifacts
              var clean = snip.replace(/\s+/g, ' ').trim();
              // Try full snippet first
              var r = phraseMatch(clean);
              if (r) return r;
              // Try each sentence-ish chunk of the snippet
              var sentences = clean.split(/[.!?\n]+/).filter(function(s){
                return s.trim().length >= 10;
              });
              for (var si = 0; si < sentences.length; si++) {
                clearAll();
                r = phraseMatch(sentences[si].trim());
                if (r) return r;
              }
              // Try the longest half
              if (clean.length >= 20) {
                var mid = Math.floor(clean.length / 2);
                // Find a word boundary near the middle
                var sp = clean.indexOf(' ', mid);
                if (sp < 0 || sp > mid + 15) sp = mid;
                var half1 = clean.substring(0, sp).trim();
                var half2 = clean.substring(sp).trim();
                // Try the longer half first
                var longer = half1.length >= half2.length ? half1 : half2;
                var shorter = half1.length >= half2.length ? half2 : half1;
                clearAll();
                r = phraseMatch(longer);
                if (r) return r;
                clearAll();
                r = phraseMatch(shorter);
                if (r) return r;
              }
              return null;
            }

            function extractTerms(input) {
              var lower = ('' + input).toLowerCase()
                .replace(/[^a-z0-9'\s]/g, ' ')
                .replace(/\s+/g, ' ').trim();
              var pieces = lower.split(' ');
              var seen = {}; var out = [];
              for (var i = 0; i < pieces.length; i++) {
                var w = pieces[i];
                if (w.length >= 4 && !STOP[w] && !seen[w]) {
                  seen[w] = 1; out.push(w);
                }
              }
              return out;
            }

            // ---- Strategy: sentence-level wrap ----
            function sentenceMatch(terms) {
              if (!terms.length) return null;
              var nodes = getTextNodes();
              var first = null; var total = 0; var MAX = 40;
              for (var i = 0; i < nodes.length && total < MAX; i++) {
                var t = nodes[i];
                // Skip headings for sentence wrap
                if (t.parentNode && (isH(t.parentNode.nodeName) || inH(t)))
                  continue;
                var text = t.nodeValue;
                var re = /[^.!?\n]+(?:[.!?]+|$)/g;
                var m; var ranges = [];
                while ((m = re.exec(text)) !== null) {
                  var sent = m[0];
                  if (sent.trim().length < 8) continue;
                  var sl = sent.toLowerCase();
                  var hit = false;
                  for (var ti = 0; ti < terms.length; ti++) {
                    if (sl.indexOf(terms[ti]) >= 0) { hit = true; break; }
                  }
                  if (hit) {
                    var s = m.index; var e = s + sent.length;
                    while (s < e && /\s/.test(text.charAt(s))) s++;
                    if (s < e) ranges.push({s:s, e:e});
                  }
                }
                if (!ranges.length) continue;
                var parent = t.parentNode;
                var cursor = 0;
                var frag = document.createDocumentFragment();
                for (var r = 0; r < ranges.length && total < MAX; r++) {
                  var rr = ranges[r];
                  if (rr.s > cursor)
                    frag.appendChild(document.createTextNode(text.substring(cursor, rr.s)));
                  var sm = mk(text, rr.s, rr.e);
                  if (!first) first = sm;
                  frag.appendChild(sm); cursor = rr.e; total++;
                }
                if (cursor < text.length)
                  frag.appendChild(document.createTextNode(text.substring(cursor)));
                parent.replaceChild(frag, t);
              }
              return first;
            }

            // ---- Strategy: word-level wrap ----
            function wordMatch(terms) {
              if (!terms.length) return null;
              var nodes = getTextNodes();
              var first = null; var cap = 200;
              for (var i = 0; i < nodes.length && cap > 0; i++) {
                var t = nodes[i]; var text = t.nodeValue;
                var tlow = text.toLowerCase();
                var ranges = [];
                for (var ti = 0; ti < terms.length; ti++) {
                  var term = terms[ti]; var idx = 0;
                  while ((idx = tlow.indexOf(term, idx)) !== -1) {
                    ranges.push({s:idx, e:idx+term.length}); idx += term.length;
                  }
                }
                if (!ranges.length) continue;
                ranges.sort(function(a,b){return a.s-b.s;});
                var merged = [ranges[0]];
                for (var mi = 1; mi < ranges.length; mi++) {
                  var top = merged[merged.length-1];
                  if (ranges[mi].s <= top.e) {
                    top.e = Math.max(top.e, ranges[mi].e);
                  } else merged.push(ranges[mi]);
                }
                var parent = t.parentNode;
                var cursor = 0;
                var frag = document.createDocumentFragment();
                for (var ri = 0; ri < merged.length && cap > 0; ri++) {
                  var rr = merged[ri];
                  if (rr.s > cursor)
                    frag.appendChild(document.createTextNode(text.substring(cursor, rr.s)));
                  var wm = mk(text, rr.s, rr.e);
                  if (!first) first = wm;
                  frag.appendChild(wm); cursor = rr.e; cap--;
                }
                if (cursor < text.length)
                  frag.appendChild(document.createTextNode(text.substring(cursor)));
                parent.replaceChild(frag, t);
              }
              return first;
            }

            // ---- Strategy: single best word fallback ----
            function bestWordFallback() {
              var body = (document.body.textContent || '').toLowerCase();
              var words = raw.toLowerCase()
                .split(/[^a-z0-9']+/).filter(function(w){return w&&w.length>=2;});
              words.sort(function(a,b){return b.length-a.length;});
              for (var i = 0; i < words.length; i++) {
                if (STOP[words[i]]) continue;
                if (body.indexOf(words[i]) >= 0) {
                  return phraseMatch(words[i]);
                }
              }
              for (var j = 0; j < words.length; j++) {
                if (body.indexOf(words[j]) >= 0) {
                  return phraseMatch(words[j]);
                }
              }
              return null;
            }

            // ===== MAIN CASCADE =====
            function attempt() {
              clearAll();
              var first = null;

              // Strategy 1: snippet match (most precise)
              if (snippetText && snippetText.length >= 6) {
                first = snippetCascade(snippetText);
                if (first) return first;
                clearAll();
              }

              // Strategy 2: full query as phrase
              if (isPhrase || raw.length >= 6) {
                var qPhrase = raw.replace(/^"+|"+$/g, '')
                                 .replace(/^'+|'+$/g, '').trim();
                if (qPhrase.length >= 4) {
                  first = phraseMatch(qPhrase);
                  if (first) return first;
                  clearAll();
                }
              }

              // Strategy 3: sentence-level smart match
              var terms = extractTerms(raw);
              if (mode === 'smart' && terms.length > 0) {
                first = sentenceMatch(terms);
                if (first) return first;
                clearAll();
              }

              // Strategy 4: word-level match
              // Critical for "keyword" mode (semantic OFF) — the only
              // strategy that runs when sentence-level is skipped.
              // Also acts as fallback in "smart" mode when no full
              // sentence scores high enough.
              if (terms.length > 0) {
                first = wordMatch(terms);
                if (first) return first;
                clearAll();
              }

              // Strategy 5: single best word
              // Last resort to always show something so the user
              // can orient to the query topic in the article.
              first = bestWordFallback();
              return first;
            }

            var initialY = window.pageYOffset ||
                           document.documentElement.scrollTop || 0;
            function userMoved() {
              var y = window.pageYOffset ||
                      document.documentElement.scrollTop || 0;
              return Math.abs(y - initialY) > 200;
            }

            function doScroll(el) {
              try { el.scrollIntoView({behavior:'smooth',block:'center'}); }
              catch(e) { try { el.scrollIntoView(); } catch(_){} }
            }

            function finalize(first, canScroll) {
              if (!first) return;
              unhideAll();
              if (!canScroll) return;
              if (window.requestAnimationFrame) {
                window.requestAnimationFrame(function(){
                  window.requestAnimationFrame(function(){
                    doScroll(first);
                  });
                });
              } else setTimeout(function(){ doScroll(first); }, 60);
            }

            // Immediate attempt
            var r1 = attempt();
            if (r1) { finalize(r1, true); return; }

            // Retry at 400ms
            setTimeout(function() {
              var r2 = attempt();
              if (r2) { finalize(r2, !userMoved()); return; }
              // Retry at 1500ms
              setTimeout(function() {
                var r3 = attempt();
                if (r3) finalize(r3, !userMoved());
              }, 1500);
            }, 400);
          } catch (e) {
            try { console.log('mv-highlight error: ' + e); } catch(_){}
          }
        })();
    """.trimIndent()
}

/**
 * v5.4.76cc — Overlay LLM paraphrase terms in the raw-HTML reader.
 *
 * ## Contract
 *
 * The primary `buildHighlightJs` above has already run: yellow `<mark
 * class="mv-hl">` spans wrap the user's original query terms and scroll
 * is anchored on the first match. This function returns a self-contained
 * IIFE that adds a **second**, lighter, non-flashing overlay for terms
 * the Phi-4-mini expander produced, using `<mark class="mv-llm-hl">`
 * with a soft lavender background so the reader can visually
 * distinguish "the LLM surfaced this word" from "your query literally
 * contained this word".
 *
 * ## Design constraints
 *
 *   - Independent IIFE — never touches globals so the primary highlight
 *     JS's state and retries are untouched.
 *   - Skips SCRIPT / STYLE / MARK / NOSCRIPT / TEMPLATE / HEAD (mirrors
 *     the primary walker so an LLM term inside an already-highlighted
 *     yellow span doesn't get double-wrapped and lose its yellow bg).
 *   - Caps total wrapped occurrences at [MV_LLM_MAX_MARKS] to bound the
 *     work on a 30,000-word Watchtower article.
 *   - Terms are JSON-escaped by the Kotlin side via `JSONObject.quote`,
 *     so nothing the model emits can break out of the string literal.
 */
private const val MV_LLM_MAX_MARKS = 400

private fun buildLlmHighlightJsHtml(rawTerms: List<String>): String {
    // v5.4.144cc — AI highlighting must only wrap PHRASES (2+ words).
    // Any single-keyword term (no space) is rejected before building the JS payload.
    val filtered = rawTerms.map { it.trim() }
        .filter { it.length >= 3 && it.contains(' ') }
        .distinctBy { it.lowercase() }
    if (filtered.isEmpty()) return "(function(){})();"
    val payload = filtered.joinToString(",") { org.json.JSONObject.quote(it) }
    return """
        (function(){
          try {
            var terms = [$payload];
            if (!terms || !terms.length) return;
            // v5.4.143cc — Inject the @keyframes once so CSS animations work
            // inside the article's own HTML document (viewer.css is not loaded
            // here; each HTML article controls its own <head>).
            if (!document.getElementById('mv-llm-kf')) {
              var kfStyle = document.createElement('style');
              kfStyle.id = 'mv-llm-kf';
              kfStyle.textContent = '@keyframes mvLlmFlash{0%,100%{background:rgba(255,105,180,.58);box-shadow:none}50%{background:rgba(255,20,147,.84);box-shadow:0 0 6px rgba(255,20,147,.55)}}';
              (document.head || document.documentElement).appendChild(kfStyle);
            }
            function isSkip(tag) {
              return tag==='SCRIPT'||tag==='STYLE'||tag==='MARK'||
                     tag==='NOSCRIPT'||tag==='TEMPLATE'||tag==='HEAD';
            }
            function collectNodes() {
              var w = document.createTreeWalker(
                document.body, NodeFilter.SHOW_TEXT, {
                  acceptNode: function(n) {
                    if (!n.nodeValue || !n.nodeValue.trim())
                      return NodeFilter.FILTER_REJECT;
                    var p = n.parentNode;
                    if (!p) return NodeFilter.FILTER_REJECT;
                    if (isSkip(p.nodeName)) return NodeFilter.FILTER_REJECT;
                    // Skip nodes already inside a previous highlight so
                    // we don't clobber the yellow mv-hl coverage.
                    while (p && p !== document.body) {
                      if (p.nodeName === 'MARK') return NodeFilter.FILTER_REJECT;
                      p = p.parentNode;
                    }
                    return NodeFilter.FILTER_ACCEPT;
                  }
                }, false);
              var out = [], nd;
              while ((nd = w.nextNode())) { out.push(nd); if (out.length > 4000) break; }
              return out;
            }
            function mkMark(text) {
              var m = document.createElement('mark');
              m.className = 'mv-llm-hl';
              // v5.4.143cc — Flashing hot-pink: pulses between soft pink
              // and bright magenta so the user can tell "AI found this."
              // Dark text (#1a1a1a) keeps it readable on any article background.
              m.style.cssText = 'background:rgba(255,105,180,.65);color:#1a1a1a;padding:0 2px;border-radius:3px;animation:mvLlmFlash 1.8s ease-in-out infinite;';
              m.appendChild(document.createTextNode(text));
              return m;
            }
            var total = 0, MAX = $MV_LLM_MAX_MARKS;
            var nodes = collectNodes();
            // Longest terms first so a paraphrase like "friendship with
            // God" doesn't get chopped by a shorter "friendship" wrap.
            terms.sort(function(a,b){ return b.length - a.length; });
            for (var ti = 0; ti < terms.length && total < MAX; ti++) {
              var term = ('' + terms[ti]).toLowerCase();
              if (term.length < 3) continue;
              for (var ni = 0; ni < nodes.length && total < MAX; ni++) {
                var node = nodes[ni];
                if (!node.parentNode) continue;
                var text = node.nodeValue;
                var lower = text.toLowerCase();
                var idx = lower.indexOf(term);
                if (idx < 0) continue;
                var frag = document.createDocumentFragment();
                var cursor = 0;
                while (idx >= 0) {
                  if (idx > cursor) {
                    frag.appendChild(document.createTextNode(text.slice(cursor, idx)));
                  }
                  frag.appendChild(mkMark(text.slice(idx, idx + term.length)));
                  cursor = idx + term.length;
                  total++;
                  if (total >= MAX) break;
                  idx = lower.indexOf(term, cursor);
                }
                if (cursor > 0) {
                  if (cursor < text.length) {
                    frag.appendChild(document.createTextNode(text.slice(cursor)));
                  }
                  node.parentNode.replaceChild(frag, node);
                }
              }
              // Re-collect after mutation — the walker's nodes list is
              // now stale for this term and future terms.
              nodes = collectNodes();
            }
          } catch (e) {
            try { console.log('mv-llm-highlight error: ' + e); } catch(_){}
          }
        })();
    """.trimIndent()
}

