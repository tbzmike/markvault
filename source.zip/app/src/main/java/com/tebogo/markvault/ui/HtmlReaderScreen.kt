package com.tebogo.markvault.ui

import android.annotation.SuppressLint
import android.net.Uri
import android.view.ViewGroup
import android.webkit.WebResourceRequest
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
// Note: Modifier.weight(...) is provided as an extension by ColumnScope/RowScope
// at the call site — no explicit import needed (and importing
// `androidx.compose.foundation.layout.weight` would pull in an internal symbol
// that doesn't compile against external code).
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.navigation.NavController
import com.tebogo.markvault.AppViewModel
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.ByteArrayInputStream

/**
 * Renders a saved offline web archive (`.html`, `.htm`, `.mhtml`, `.mht`) inside
 * a sandboxed WebView. Distinct from the markdown reader (which uses our own
 * markdown-it pipeline) because these files arrive as the browser produced them
 * and need the WebView's native engine to layout properly.
 *
 * The file content is read once via SAF (using the Note.uri stored at index
 * time) and fed to the WebView via [WebView.loadDataWithBaseURL] — that's the
 * supported way to render in-memory HTML or MHTML without a real http URL.
 *
 * MHTML files are auto-detected by their `MIME-Version` / `Content-Type:
 * multipart/related` headers in the first 200 bytes and loaded with mime type
 * `multipart/related`; modern WebView versions render them correctly. Plain
 * HTML loads with mime `text/html`. The base URL is set to the file's original
 * source if we can find one in the MHTML headers, otherwise to `about:blank`.
 */
@Composable
fun HtmlReaderScreen(
    vm: AppViewModel,
    nav: NavController,
    id: Long
) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    val theme by vm.theme.collectAsState()

    // Initially unknown — we load asynchronously off the main thread because
    // these files can be several MB.
    var title by remember { mutableStateOf("Offline page") }
    var rawText by remember { mutableStateOf<String?>(null) }
    var loadError by remember { mutableStateOf<String?>(null) }

    LaunchedEffect(id) {
        scope.launch {
            val note = withContext(Dispatchers.IO) { vm.loadNote(id) }
            if (note == null) {
                loadError = "Could not load the file from the library."
                return@launch
            }
            title = note.title.ifBlank { note.name }
            // SAF read — handle binary safely. We stream the raw bytes, but
            // since this is a text-based MIME format we can hold the whole thing
            // as a String for loadDataWithBaseURL.
            val bytes = withContext(Dispatchers.IO) {
                runCatching {
                    ctx.contentResolver.openInputStream(Uri.parse(note.uri))?.use { it.readBytes() }
                }.getOrNull()
            }
            if (bytes == null) {
                loadError = "Could not read the file. The library folder may have been moved."
                return@launch
            }
            rawText = bytes.toString(Charsets.UTF_8)
            // Use the indexed plain text as the lastOpened bump
            vm.openArticle(id, title, fileType = note.fileType)
        }
    }

    Column(Modifier.fillMaxSize()) {
        // Title strip at the top — matches PDF reader's look so the user
        // recognises this as a "reader" not the chrome-less popup.
        Surface(
            modifier = Modifier.fillMaxWidth(),
            color = MaterialTheme.colorScheme.surfaceVariant
        ) {
            Text(
                "\uD83C\uDF10  $title",
                modifier = Modifier.padding(horizontal = 16.dp, vertical = 10.dp),
                fontSize = 14.sp,
                maxLines = 1
            )
        }

        // WebView body
        if (loadError != null) {
            Column(
                Modifier.fillMaxSize().padding(24.dp),
                horizontalAlignment = androidx.compose.ui.Alignment.CenterHorizontally
            ) {
                Spacer(Modifier.size(40.dp))
                Text("\u26A0\uFE0F  Couldn't open this file", fontSize = 16.sp)
                Spacer(Modifier.size(12.dp))
                Text(loadError ?: "", fontSize = 13.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
        } else if (rawText != null) {
            AndroidView(
                modifier = Modifier.fillMaxWidth().weight(1f),
                factory = { context ->
                    @SuppressLint("SetJavaScriptEnabled")
                    SelectionWebView(context).apply {
                        layoutParams = ViewGroup.LayoutParams(
                            ViewGroup.LayoutParams.MATCH_PARENT,
                            ViewGroup.LayoutParams.MATCH_PARENT
                        )
                        // Allow scripts so saved jw.org pages render correctly;
                        // they're already-archived content from a trusted origin
                        // and can't reach the live network from this WebView.
                        settings.javaScriptEnabled = true
                        settings.domStorageEnabled = true
                        settings.useWideViewPort = true
                        settings.loadWithOverviewMode = true
                        settings.builtInZoomControls = true
                        settings.displayZoomControls = false
                        settings.mixedContentMode = WebSettings.MIXED_CONTENT_COMPATIBILITY_MODE
                        // Block any outbound network — the page is offline and
                        // we don't want it pulling fresh resources or beacons.
                        webViewClient = object : WebViewClient() {
                            override fun shouldOverrideUrlLoading(
                                view: WebView?, request: WebResourceRequest?
                            ): Boolean {
                                // Off-page navigation → hand to system browser.
                                val u = request?.url ?: return false
                                if (u.scheme == "data" || u.scheme == "cid" || u.scheme == "file")
                                    return false
                                runCatching {
                                    ctx.startActivity(
                                        android.content.Intent(
                                            android.content.Intent.ACTION_VIEW, u
                                        ).addFlags(android.content.Intent.FLAG_ACTIVITY_NEW_TASK)
                                    )
                                }
                                return true
                            }
                        }
                        // Same text-selection menu we use everywhere else.
                        onSearchInMarkVault = { text ->
                            vm.requestPendingSearch(text)
                            nav.navigate("search") { launchSingleTop = true }
                        }
                        onSearchInWol = { text ->
                            val target = "https://wol.jw.org/en/wol/s/r1/lp-e?q=" +
                                java.net.URLEncoder.encode(text, "UTF-8")
                            vm.requestWebPopup(target)
                        }
                    }
                },
                update = { w ->
                    val body = rawText ?: return@AndroidView
                    val isMhtml = looksLikeMhtml(body)
                    // For MHTML, pick the base URL from the Content-Location of
                    // the root part so relative `cid:` references resolve.
                    val baseUrl = if (isMhtml) extractMhtmlBaseUrl(body) else null
                    if (isMhtml) {
                        // Modern WebView renders multipart/related directly.
                        w.loadDataWithBaseURL(
                            baseUrl ?: "about:blank",
                            body,
                            "multipart/related",
                            "utf-8",
                            null
                        )
                    } else {
                        w.loadDataWithBaseURL(
                            baseUrl ?: "about:blank",
                            body,
                            "text/html",
                            "utf-8",
                            null
                        )
                    }
                }
            )
        }

        // Bottom toolbar — matches every other reader screen for consistency.
        MarkVaultBottomBar(
            nav = nav,
            vm = vm,
            extraActions = {
                // No reader-specific actions for now; theming + back are enough.
            }
        )
    }
}

/** Quick MHTML sniff: look for the multipart signature in the first 4 KB. */
private fun looksLikeMhtml(text: String): Boolean {
    val head = text.take(4096)
    return head.contains("MIME-Version:", ignoreCase = true) &&
        head.contains("multipart/related", ignoreCase = true)
}

/** Pull the page's original URL out of an MHTML's root part headers. */
private fun extractMhtmlBaseUrl(text: String): String? {
    // Find the FIRST Content-Location: <url> — that's the URL of the root HTML part.
    val m = Regex("(?im)^content-location:\\s*(\\S+)\\s*$").find(text.take(8192))
    return m?.groupValues?.getOrNull(1)?.trim()
}
