package com.tebogo.markvault.ui

import android.annotation.SuppressLint
import android.net.Uri
import android.view.ViewGroup
import android.webkit.RenderProcessGoneDetail
import android.webkit.WebResourceRequest
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.KeyboardArrowDown
import androidx.compose.material.icons.filled.KeyboardArrowUp
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.Button
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.navigation.NavController
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.tebogo.markvault.AppViewModel
import com.tebogo.markvault.util.MhtmlParser
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.filled.Add
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.material.icons.filled.Menu

/** v5.4.23 — File-level so items()'s generic inference resolves cleanly. */
private data class HtmlHeading(val index: Int, val level: Int, val text: String)

/**
 * Reader for offline web archives — full feature parity with markdown reader:
 *   • Find-in-page with prev/next nav (Ctrl+F equivalent)
 *   • Search-result highlight injection (pendingHighlight from VM)
 *   • Open externally fallback
 *   • Crash-hardened (renderer recovery)
 *   • Comprehensive bottom toolbar with all standard actions
 *   • Link taps route to in-app browser
 *
 * v4.6 changes from v4.5:
 *   1. Find-in-page UI added (WebView.findAllAsync + findNext).
 *   2. Pending highlight from Search screen now flashes in the WebView via
 *      injected JavaScript wrapping matches in <mark> spans.
 *   3. Toolbar now mirrors the markdown reader's button density.
 */
@OptIn(androidx.compose.material3.ExperimentalMaterial3Api::class)
@Composable
fun HtmlReaderScreen(
    vm: AppViewModel,
    nav: NavController,
    id: Long
) {
    val ctx = LocalContext.current
    val theme by vm.theme.collectAsState()

    var title by remember { mutableStateOf("Offline page") }
    var htmlContent by remember { mutableStateOf<String?>(null) }
    var baseUrl by remember { mutableStateOf<String?>(null) }
    var rendererCrashed by remember { mutableStateOf(false) }
    var loadError by remember { mutableStateOf<String?>(null) }
    var originalUri by remember { mutableStateOf<Uri?>(null) }
    var htmlLoaded by remember { mutableStateOf(false) }
    // v5.4.35 — Tracks when the user navigated away to the in-app
    // browser. When they return, the WebView is force-reloaded to
    // clear any stale URL state that caused the "stuck first link"
    // bug. Set to true inside shouldOverrideUrlLoading before
    // navigating; consumed in the AndroidView update block.
    var needsReload by remember { mutableStateOf(false) }
    // v5.4.35 — Source URL extracted from the original HTML file
    // metadata, used by the "🌐 Load Online" toolbar button.
    var sourceUrl by remember { mutableStateOf<String?>(null) }

    // Find-in-page state — mirrors WebSearchScreen's pattern.
    var findOpen by remember { mutableStateOf(false) }
    var findQuery by remember { mutableStateOf("") }
    var webViewRef by remember { mutableStateOf<WebView?>(null) }
    var noteContentForSemantic by remember { mutableStateOf<String?>(null) }
    // v5.4.36 — Long-press link popup for offline HTML articles.
    var longPressLinkUrl by remember { mutableStateOf<String?>(null) }
    var longPressLinkText by remember { mutableStateOf<String?>(null) }

    LaunchedEffect(id) {
        val note = withContext(Dispatchers.IO) { vm.loadNote(id) }
        if (note == null) {
            loadError = "Could not load the file from the library."
            return@LaunchedEffect
        }
        title = note.title.ifBlank { note.name }
        originalUri = runCatching { Uri.parse(note.uri) }.getOrNull()
        noteContentForSemantic = note.content

        val bytes = withContext(Dispatchers.IO) {
            runCatching {
                ctx.contentResolver.openInputStream(Uri.parse(note.uri))?.use {
                    it.readBytes()
                }
            }.getOrNull()
        }
        if (bytes == null) {
            loadError = "Could not read the file. The library folder may have been moved."
            return@LaunchedEffect
        }

        val nameLower = note.name.lowercase()
        val isMhtml = nameLower.endsWith(".mhtml") || nameLower.endsWith(".mht")

        if (isMhtml) {
            val parsed = withContext(Dispatchers.IO) {
                MhtmlParser.extractHtmlContent(bytes)
            }
            if (parsed == null) {
                loadError = "This MHTML file is malformed. Try opening it externally."
                return@LaunchedEffect
            }
            htmlContent = parsed
            baseUrl = withContext(Dispatchers.IO) { MhtmlParser.extractBaseUrl(bytes) }
            // v5.4.35 — For MHTML files the base URL IS the online source.
            sourceUrl = baseUrl
        } else {
            val raw = try {
                String(bytes, Charsets.UTF_8)
            } catch (_: Exception) {
                String(bytes)
            }
            htmlContent = raw
            // v5.4.35 — Try to extract the online source URL from
            // common meta tags that MarkVault's web-to-HTML saver
            // injects, or from standard HTML meta like og:url.
            sourceUrl = withContext(Dispatchers.IO) {
                val lower = raw.lowercase()
                // Check meta property og:url
                val ogMatch = Regex(
                    """<meta[^>]+property\s*=\s*["']og:url["'][^>]+content\s*=\s*["']([^"']+)["']""",
                    RegexOption.IGNORE_CASE
                ).find(raw)?.groupValues?.getOrNull(1)
                // Check <link rel="canonical">
                val canonMatch = Regex(
                    """<link[^>]+rel\s*=\s*["']canonical["'][^>]+href\s*=\s*["']([^"']+)["']""",
                    RegexOption.IGNORE_CASE
                ).find(raw)?.groupValues?.getOrNull(1)
                // Check MarkVault's own source-url comment
                val mvMatch = Regex(
                    """<!-- source-url: (.+?) -->""",
                    RegexOption.IGNORE_CASE
                ).find(raw)?.groupValues?.getOrNull(1)
                (mvMatch ?: ogMatch ?: canonMatch)?.takeIf {
                    it.startsWith("http://") || it.startsWith("https://")
                }
            }
        }

        vm.openArticle(id, title, fileType = note.fileType)
    }

    // v5.4.19 — Find-in-article FAB. HtmlReaderScreen uses a Column, not
    // a Scaffold, so we wrap the whole thing in a Box and overlay the
    // FAB at the bottom-end. HTML-file reading uses the keyword branch
    // only — HTML doesn't split cleanly on paragraph boundaries, so
    // semantic-in-article isn't wired here.
    val fabEnabled by vm.searchInArticleFab.collectAsStateWithLifecycle()
    val semanticInArticleOn by vm.semanticInArticle.collectAsStateWithLifecycle()
    val currentSearchQuery by vm.query.collectAsStateWithLifecycle()
    val openedFromSearchLatched by androidx.compose.runtime.produceState(
        initialValue = false, key1 = id
    ) {
        value = vm.openedFromSearch.value
        vm.clearOpenedFromSearch()
    }
    var fabBusy by remember { mutableStateOf(false) }
    val fabScope = rememberCoroutineScope()

    // v5.4.23 — Workspace mode + tablet 3-column overlay for HTML files.
    // Same trigger rules as ReaderScreen: workspace ON + width ≥ 600dp.
    // Left panel = tabs list (matches ReaderScreen exactly). Right
    // panel = outline from the HTML document's h1-h6 tags.
    val uiMode by vm.uiMode.collectAsStateWithLifecycle()
    val workspaceOn = uiMode == "workspace"
    val screenWidthDp = androidx.compose.ui.platform.LocalConfiguration.current.screenWidthDp
    val isTabletWidth = screenWidthDp >= 600
    val threeColumn = workspaceOn && isTabletWidth
    val leftColWidth = 240.dp
    val rightColWidth = 220.dp
    val tabs by vm.tabs.collectAsStateWithLifecycle()
    val activeTab by vm.activeTab.collectAsStateWithLifecycle()
    // v5.4.24 — Collapsible panels.
    var leftPanelOpen by remember { mutableStateOf(true) }
    var rightPanelOpen by remember { mutableStateOf(true) }

    // Extract HTML headings once per document. Match <h1>-<h6> with any
    // attributes, strip inner tags for display text, and preserve the
    // index-in-document order so we can scroll to the Nth heading via
    // querySelectorAll('h1,h2,...')[N] regardless of the HTML's own IDs.
    // v5.4.23 hotfix — htmlContent is String? — smart-cast via a local.
    val htmlHeadings = remember(htmlContent) {
        val body = htmlContent
        if (body.isNullOrBlank()) emptyList()
        else {
            val pattern = Regex(
                "<h([1-6])[^>]*>(.*?)</h[1-6]>",
                setOf(RegexOption.IGNORE_CASE, RegexOption.DOT_MATCHES_ALL)
            )
            pattern.findAll(body).mapIndexed { idx, m ->
                val level = m.groupValues[1].toInt()
                val text = m.groupValues[2]
                    .replace(Regex("<[^>]+>"), "")
                    .replace(Regex("\\s+"), " ")
                    .trim()
                HtmlHeading(idx, level, text)
            }.filter { it.text.isNotBlank() }.toList()
        }
    }

    Box(Modifier.fillMaxSize()) {
    Box(
        Modifier
            .padding(
                start = if (threeColumn && leftPanelOpen) leftColWidth else 0.dp,
                end = if (threeColumn && rightPanelOpen) rightColWidth else 0.dp
            )
            .fillMaxSize()
    ) {
    Column(Modifier.fillMaxSize()) {
        // Title strip
        Surface(
            modifier = Modifier.fillMaxWidth(),
            color = MaterialTheme.colorScheme.surfaceVariant
        ) {
            Text(
                "\uD83C\uDF10  $title",
                modifier = Modifier.padding(horizontal = 16.dp, vertical = 10.dp),
                fontSize = 14.sp,
                maxLines = 1
            )
        }

        // Find-in-page bar (slides in when find button tapped)
        if (findOpen) {
            FindInPageBar(
                query = findQuery,
                onQueryChange = {
                    findQuery = it
                    webViewRef?.findAllAsync(it)
                },
                onNext = { webViewRef?.findNext(true) },
                onPrev = { webViewRef?.findNext(false) },
                onClose = {
                    findOpen = false
                    webViewRef?.clearMatches()
                }
            )
        }

        // Body
        Box(modifier = Modifier.fillMaxWidth().weight(1f)) {
            when {
                loadError != null || rendererCrashed -> ErrorPane(
                    message = loadError ?: "The page renderer crashed.",
                    onOpenExternally = {
                        originalUri?.let { uri ->
                            runCatching {
                                ctx.startActivity(
                                    android.content.Intent(
                                        android.content.Intent.ACTION_VIEW, uri
                                    ).addFlags(
                                        android.content.Intent.FLAG_GRANT_READ_URI_PERMISSION
                                    )
                                )
                            }
                        }
                    },
                    onRetry = {
                        rendererCrashed = false
                        loadError = null
                        htmlLoaded = false
                    }
                )

                htmlContent != null -> AndroidView(
                    modifier = Modifier.fillMaxSize(),
                    factory = { context ->
                        @SuppressLint("SetJavaScriptEnabled")
                        SelectionWebView(context).apply {
                            layoutParams = ViewGroup.LayoutParams(
                                ViewGroup.LayoutParams.MATCH_PARENT,
                                ViewGroup.LayoutParams.MATCH_PARENT
                            )
                            settings.javaScriptEnabled = true
                            settings.domStorageEnabled = true
                            // v5.4.25 — Force mobile layout. Was
                            // useWideViewPort=true which made the
                            // WebView use a 980px default viewport,
                            // forcing sideways scroll for content
                            // authored without an explicit viewport.
                            settings.useWideViewPort = false
                            settings.loadWithOverviewMode = true
                            settings.builtInZoomControls = true
                            settings.displayZoomControls = false
                            settings.mixedContentMode =
                                WebSettings.MIXED_CONTENT_COMPATIBILITY_MODE

                            // v5.4.36 — Long-press on a link in the offline
                            // HTML article shows a popup with options like
                            // "Copy link text" and "Search in library".
                            setOnLongClickListener { v ->
                                val webV = v as? WebView ?: return@setOnLongClickListener false
                                val hit = webV.hitTestResult
                                when (hit.type) {
                                    WebView.HitTestResult.SRC_ANCHOR_TYPE,
                                    WebView.HitTestResult.SRC_IMAGE_ANCHOR_TYPE -> {
                                        val href = hit.extra
                                        if (!href.isNullOrBlank()) {
                                            longPressLinkUrl = href
                                            longPressLinkText = null
                                            webV.evaluateJavascript(
                                                "(function(){" +
                                                "var els=document.querySelectorAll('a[href]');" +
                                                "for(var i=0;i<els.length;i++){" +
                                                "  if(els[i].href==='" + href.replace("'", "\\'") + "'){" +
                                                "    return els[i].innerText.trim();" +
                                                "  }" +
                                                "}" +
                                                "return '';" +
                                                "})()"
                                            ) { result ->
                                                val text = result?.trim()
                                                    ?.removeSurrounding("\"")
                                                    ?.takeIf { it.isNotBlank() && it != "null" }
                                                longPressLinkText = text
                                            }
                                            true
                                        } else false
                                    }
                                    else -> false
                                }
                            }

                            webViewClient = object : WebViewClient() {
                                override fun shouldOverrideUrlLoading(
                                    view: WebView?, request: WebResourceRequest?
                                ): Boolean {
                                    val u = request?.url ?: return false
                                    val scheme = u.scheme ?: return false
                                    if (scheme == "data" || scheme == "cid" ||
                                        scheme == "file" || scheme == "blob" ||
                                        scheme == "about") return false
                                    // v5.4.35 — Force a fresh string from
                                    // the URI to defeat any internal WebView
                                    // URL caching. Clear the WebView's cache
                                    // and history BEFORE navigating so stale
                                    // entries can't leak into the next load.
                                    view?.clearHistory()
                                    view?.clearCache(false)
                                    needsReload = true
                                    val freshUrl = String(u.toString().toCharArray())
                                    val freshHost = u.host?.let { String(it.toCharArray()) } ?: "Link"
                                    val encUrl = java.net.URLEncoder.encode(freshUrl, "UTF-8")
                                    val encLabel = java.net.URLEncoder.encode(freshHost, "UTF-8")
                                    nav.navigate("web/$encUrl/$encLabel")
                                    return true
                                }

                                override fun onPageFinished(view: WebView?, url: String?) {
                                    super.onPageFinished(view, url)
                                    // v5.4.35 — Clear the forward-history
                                    // stack every time the local HTML page
                                    // finishes loading. This prevents the
                                    // WebView from retaining stale entries
                                    // from previously intercepted external
                                    // URLs, which caused the "stuck first
                                    // link" bug when returning from the
                                    // in-app browser.
                                    view?.clearHistory()
                                    // Inject highlight JS for the pending search
                                    // term — flashes the searched word in the
                                    // article so the user doesn't have to find
                                    // it manually. Consume the pending value so
                                    // it doesn't re-fire on later navigations.
                                    // v5.4.6 — gated by articleHighlightEnabled
                                    // toggle so users can disable the text-node
                                    // walk if they suspect it's contributing
                                    // to crashes.
                                    // v5.4.10 — pendingHighlight is now a
                                    // data class with the exact-phrase flag.
                                    val pending = vm.consumePendingHighlight()
                                    val highlightOn = vm.articleHighlightEnabled.value
                                    if (pending != null && pending.query.isNotBlank() &&
                                        view != null && highlightOn) {
                                        // v5.4.9 — Resolve "auto" → smart/keyword
                                        // against the semantic-search state. JS
                                        // only ever sees "smart" or "keyword".
                                        val hlMode = vm.effectiveHighlightMode()
                                        view.evaluateJavascript(
                                            buildHighlightJs(pending.query, hlMode, pending.isPhrase),
                                            null
                                        )
                                    }
                                }

                                override fun onRenderProcessGone(
                                    view: WebView?, detail: RenderProcessGoneDetail?
                                ): Boolean {
                                    rendererCrashed = true
                                    runCatching { view?.destroy() }
                                    return true
                                }
                            }

                            onSearchInMarkVault = { text ->
                                vm.requestPendingSearch(text)
                                nav.navigate("search") { launchSingleTop = true }
                            }
                            onSearchInWol = { text ->
                                val target = "https://wol.jw.org/en/wol/s/r1/lp-e?q=" +
                                    java.net.URLEncoder.encode(text, "UTF-8")
                                vm.requestWebPopup(target)
                            }

                            webViewRef = this
                        }
                    },
                    update = { w ->
                        val html = htmlContent ?: return@AndroidView
                        // v5.4.35 — When the user returns from the in-app
                        // browser, force the WebView to fully reload the
                        // offline HTML. This clears any stale internal URL
                        // routing state that caused "stuck first link".
                        if (needsReload && htmlLoaded) {
                            w.clearHistory()
                            w.clearCache(false)
                            htmlLoaded = false
                            needsReload = false
                        }
                        if (!htmlLoaded) {
                            // v5.4.25 — Inject a viewport meta tag so
                            // the WebView renders at device width. User
                            // HTML often lacks this and would otherwise
                            // lay out at 980px, forcing sideways scroll.
                            // If the HTML already has a viewport tag,
                            // the browser uses the first one — this
                            // injection is safely no-op in that case.
                            val viewportMeta =
                                "<meta name=\"viewport\" content=\"width=device-width, " +
                                    "initial-scale=1.0\">"
                            // v5.4.29 — Mobile-fit CSS override (see
                            // ReaderScreen for rationale). Forces desktop-
                            // width elements to constrain to phone width.
                            val mobileFitCss =
                                "<style id=\"mv-mobile-fit\">" +
                                    "html,body{max-width:100vw!important;overflow-x:hidden!important;" +
                                    "word-wrap:break-word;overflow-wrap:break-word}" +
                                    "*{max-width:100%!important;box-sizing:border-box!important}" +
                                    "img,video,iframe,svg,canvas{max-width:100%!important;height:auto!important}" +
                                    "table{width:100%!important;display:block!important;overflow-x:auto!important}" +
                                    "pre,code{white-space:pre-wrap!important;word-break:break-word!important}" +
                                    "</style>"
                            val headInjection = viewportMeta + mobileFitCss
                            val patched = run {
                                val lower = html.lowercase()
                                val headOpen = lower.indexOf("<head")
                                if (headOpen >= 0) {
                                    val after = html.indexOf('>', headOpen) + 1
                                    if (after > 0)
                                        html.substring(0, after) + headInjection + html.substring(after)
                                    else html
                                } else {
                                    val htmlOpen = lower.indexOf("<html")
                                    if (htmlOpen >= 0) {
                                        val after = html.indexOf('>', htmlOpen) + 1
                                        if (after > 0)
                                            html.substring(0, after) +
                                                "<head>" + headInjection + "</head>" +
                                                html.substring(after)
                                        else html
                                    } else {
                                        "<!doctype html><html><head>" + headInjection +
                                            "</head><body>" + html + "</body></html>"
                                    }
                                }
                            }
                            runCatching {
                                w.loadDataWithBaseURL(
                                    baseUrl ?: "about:blank",
                                    patched,
                                    "text/html",
                                    "utf-8",
                                    null
                                )
                            }
                            htmlLoaded = true
                        }
                    }
                )
            }
        }

        // Bottom toolbar — full set: back / find / refresh / load-online /
        // open-externally / home / overflow.
        MarkVaultBottomBar(
            nav = nav,
            vm = vm,
            extraActions = {
                // v4.22.1 — Summarise current HTML article via on-device chat
                // v5.2.0 — Hidden until the chat model is installed.
                val chatReady by vm.chatModelInstalled.collectAsStateWithLifecycle()
                if (chatReady) {
                    IconButton(onClick = {
                        vm.summarizeNote(id, "html")
                        nav.navigate("chat") { launchSingleTop = true }
                    }) {
                        androidx.compose.material3.Text("\u2728", fontSize = 18.sp)
                    }
                }
                // Find-in-page toggle
                IconButton(onClick = { findOpen = !findOpen }) {
                    Icon(Icons.Default.Search, contentDescription = "Find in page")
                }
                // v5.4.35 — Refresh: reload the current offline HTML
                // page in the WebView. Useful if JS injection or CSS
                // overrides rendered incorrectly.
                IconButton(onClick = { webViewRef?.reload() }) {
                    Text("\uD83D\uDD04", fontSize = 18.sp)
                }
                // v5.4.35 — Load Online: open the original source URL
                // in the in-app browser. Tries sourceUrl (extracted from
                // HTML meta tags), falls back to originalUri (the file's
                // SAF URI, which may be a content:// and not openable
                // as a web page — in that case the button is hidden).
                val onlineUrl = sourceUrl ?: originalUri?.toString()?.takeIf {
                    it.startsWith("http://") || it.startsWith("https://")
                }
                if (onlineUrl != null) {
                    IconButton(onClick = {
                        val encUrl = java.net.URLEncoder.encode(onlineUrl, "UTF-8")
                        val host = runCatching { Uri.parse(onlineUrl).host }.getOrNull() ?: "Online"
                        val encLabel = java.net.URLEncoder.encode(host, "UTF-8")
                        needsReload = true
                        nav.navigate("web/$encUrl/$encLabel")
                    }) {
                        Text("\uD83C\uDF10", fontSize = 18.sp)
                    }
                }
                // Open externally
                IconButton(onClick = {
                    originalUri?.let { uri ->
                        runCatching {
                            ctx.startActivity(
                                android.content.Intent(
                                    android.content.Intent.ACTION_VIEW, uri
                                ).addFlags(
                                    android.content.Intent.FLAG_GRANT_READ_URI_PERMISSION
                                )
                            )
                        }
                    }
                }) {
                    Text("\u2197", fontSize = 18.sp)
                }
            }
        )
    }
    } // v5.4.23 — end padded center Box
    // v5.4.19 — FAB overlay for "Find in article" — shown only when
    // opened from a search result AND the toggle is on. Wired to the
    // existing find bar so behavior matches WebSearchScreen's find UX.
    // v5.4.34 — Two compact FABs matching ReaderScreen: keyword + semantic.
    val showKeywordFab = openedFromSearchLatched && fabEnabled &&
        currentSearchQuery.trim().removeSurrounding("\"").length >= 2
    val showSemanticFab = semanticInArticleOn &&
        currentSearchQuery.trim().removeSurrounding("\"").length >= 2

    if (showKeywordFab || showSemanticFab) {
        Column(
            Modifier.align(Alignment.BottomEnd).padding(16.dp),
            horizontalAlignment = Alignment.End,
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            if (showSemanticFab) {
                androidx.compose.material3.SmallFloatingActionButton(
                    onClick = {
                        val wv = webViewRef ?: return@SmallFloatingActionButton
                        val rawQ = currentSearchQuery.trim()
                            .removeSurrounding("\"").trim()
                        if (rawQ.length < 2) return@SmallFloatingActionButton
                        // For HTML articles, try to extract text and run semantic search
                        fabBusy = true
                        fabScope.launch {
                            try {
                                val topSnip = vm.semanticInArticleFindTopSnippet(
                                    noteContentForSemantic ?: "", rawQ
                                )
                                if (!topSnip.isNullOrBlank()) {
                                    findQuery = topSnip
                                    findOpen = true
                                    webViewRef?.findAllAsync(topSnip)
                                }
                            } finally {
                                fabBusy = false
                            }
                        }
                    },
                    containerColor = MaterialTheme.colorScheme.tertiaryContainer
                ) {
                    if (fabBusy) {
                        androidx.compose.material3.CircularProgressIndicator(
                            modifier = Modifier.size(16.dp), strokeWidth = 2.dp
                        )
                    } else {
                        Text("\uD83E\uDDE0", fontSize = 16.sp)
                    }
                }
            }
            if (showKeywordFab) {
                androidx.compose.material3.SmallFloatingActionButton(
                    onClick = {
                        val wv = webViewRef ?: return@SmallFloatingActionButton
                        val rawQ = currentSearchQuery.trim()
                            .removeSurrounding("\"").trim()
                        if (rawQ.length < 2) return@SmallFloatingActionButton
                        findQuery = rawQ
                        findOpen = true
                        wv.findAllAsync(rawQ)
                    }
                ) {
                    Text("\uD83D\uDD0D", fontSize = 16.sp)
                }
            }
        }
    }
    // v5.4.23 — Tablet three-column side panels for HTML. Rendered
    // only when workspace mode is ON and window width ≥ 600dp. Left
    // panel mirrors ReaderScreen's tab list; right panel shows the
    // HTML document's h1-h6 outline with tap-to-scroll via
    // querySelectorAll.
    // v5.4.24 — Collapsibility + status bar padding.
    if (threeColumn && leftPanelOpen) {
        Column(
            Modifier
                .align(Alignment.TopStart)
                .width(leftColWidth)
                .fillMaxHeight()
                .background(MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.35f))
                .statusBarsPadding()
                .padding(12.dp)
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(
                    "\uD83E\uDDF0 Workspace",
                    fontSize = 15.sp,
                    fontWeight = androidx.compose.ui.text.font.FontWeight.Bold,
                    modifier = Modifier.weight(1f)
                )
                IconButton(
                    onClick = { leftPanelOpen = false },
                    modifier = Modifier.size(28.dp)
                ) {
                    Text("◀", fontSize = 14.sp)
                }
            }
            Spacer(Modifier.height(2.dp))
            Text(
                "Open tabs",
                fontSize = 11.sp,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
            Spacer(Modifier.height(10.dp))
            LazyColumn(
                Modifier.weight(1f).fillMaxWidth()
            ) {
                items(
                    tabs, key = { it.id }
                ) { tab ->
                    val selected = tab.id == activeTab
                    Surface(
                        color = if (selected)
                            MaterialTheme.colorScheme.primary.copy(alpha = 0.18f)
                        else androidx.compose.ui.graphics.Color.Transparent,
                        shape = androidx.compose.foundation.shape.RoundedCornerShape(8.dp),
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(vertical = 2.dp)
                            .clickable {
                                vm.setActiveTab(tab.id)
                            }
                    ) {
                        Row(
                            Modifier.padding(horizontal = 10.dp, vertical = 8.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                when (tab.fileType) {
                                    "pdf" -> "\uD83D\uDCC4"
                                    "html", "htm" -> "\uD83C\uDF10"
                                    else -> "\uD83D\uDCDD"
                                },
                                fontSize = 14.sp
                            )
                            Spacer(Modifier.width(8.dp))
                            Text(
                                tab.title,
                                modifier = Modifier.weight(1f),
                                fontSize = 12.sp,
                                maxLines = 1,
                                overflow = androidx.compose.ui.text.style.TextOverflow.Ellipsis,
                                fontWeight = if (selected)
                                    androidx.compose.ui.text.font.FontWeight.SemiBold
                                else androidx.compose.ui.text.font.FontWeight.Normal
                            )
                            IconButton(
                                onClick = { vm.closeTab(tab.id) },
                                modifier = Modifier.size(22.dp)
                            ) {
                                Icon(
                                    androidx.compose.material.icons.Icons.Default.Close,
                                    contentDescription = "Close tab",
                                    modifier = Modifier.size(12.dp),
                                    tint = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }
                        }
                    }
                }
            }
            androidx.compose.material3.HorizontalDivider(
                Modifier.padding(vertical = 6.dp)
            )
            Row(
                Modifier
                    .fillMaxWidth()
                    .clickable { nav.navigate("home") }
                    .padding(vertical = 10.dp, horizontal = 8.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Icon(
                    androidx.compose.material.icons.Icons.Default.Add,
                    contentDescription = null,
                    modifier = Modifier.size(16.dp)
                )
                Spacer(Modifier.width(8.dp))
                Text("Open a new tab", fontSize = 13.sp)
            }
        }
        // Right panel: HTML outline
        }
    if (threeColumn && rightPanelOpen) {
        Column(
            Modifier
                .align(Alignment.TopEnd)
                .width(rightColWidth)
                .fillMaxHeight()
                .background(MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.35f))
                .statusBarsPadding()
                .padding(12.dp)
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(
                    "\uD83D\uDCD1 Outline",
                    fontSize = 15.sp,
                    fontWeight = androidx.compose.ui.text.font.FontWeight.Bold,
                    modifier = Modifier.weight(1f)
                )
                IconButton(
                    onClick = { rightPanelOpen = false },
                    modifier = Modifier.size(28.dp)
                ) {
                    Text("▶", fontSize = 14.sp)
                }
            }
            Spacer(Modifier.height(2.dp))
            Text(
                "${htmlHeadings.size} heading${if (htmlHeadings.size == 1) "" else "s"}",
                fontSize = 11.sp,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
            Spacer(Modifier.height(10.dp))
            if (htmlHeadings.isEmpty()) {
                Text(
                    "No headings in this document.",
                    fontSize = 12.sp,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            } else {
                LazyColumn(
                    Modifier.weight(1f).fillMaxWidth()
                ) {
                    items(htmlHeadings) { h ->
                        Text(
                            h.text,
                            Modifier
                                .fillMaxWidth()
                                .clickable {
                                    // Scroll to the Nth heading via
                                    // querySelectorAll — works for any
                                    // HTML loaded via loadDataWithBaseURL
                                    // regardless of whether the source has
                                    // its own IDs.
                                    webViewRef?.evaluateJavascript(
                                        "(function(){var hs=document.querySelectorAll('h1,h2,h3,h4,h5,h6');" +
                                            "if(hs.length > ${h.index}) hs[${h.index}]." +
                                            "scrollIntoView({behavior:'smooth',block:'start'});})();",
                                        null
                                    )
                                }
                                .padding(
                                    start = ((h.level - 1) * 10).dp,
                                    top = 8.dp, bottom = 8.dp
                                ),
                            fontSize = if (h.level <= 2) 12.sp else 11.sp,
                            fontWeight = if (h.level <= 2)
                                androidx.compose.ui.text.font.FontWeight.SemiBold
                            else androidx.compose.ui.text.font.FontWeight.Normal,
                            color = if (h.level <= 2) MaterialTheme.colorScheme.onSurface
                            else MaterialTheme.colorScheme.onSurfaceVariant,
                            maxLines = 3,
                            overflow = androidx.compose.ui.text.style.TextOverflow.Ellipsis
                        )
                    }
                }
            }
        }
    }
    // v5.4.24 — Corner reopen buttons appear when panels are collapsed.
    if (threeColumn && !leftPanelOpen) {
        IconButton(
            onClick = { leftPanelOpen = true },
            modifier = Modifier
                .align(Alignment.TopStart)
                .statusBarsPadding()
                .padding(4.dp)
                .size(40.dp)
        ) {
            Icon(
                androidx.compose.material.icons.Icons.Default.Menu,
                contentDescription = "Show left panel",
                tint = MaterialTheme.colorScheme.onSurface
            )
        }
    }
    if (threeColumn && !rightPanelOpen) {
        IconButton(
            onClick = { rightPanelOpen = true },
            modifier = Modifier
                .align(Alignment.TopEnd)
                .statusBarsPadding()
                .padding(4.dp)
                .size(40.dp)
        ) {
            Text("📑", fontSize = 18.sp)
        }
    }
    }

    // v5.4.36 — Link long-press action sheet for offline HTML articles.
    longPressLinkUrl?.let { href ->
        androidx.compose.material3.ModalBottomSheet(
            onDismissRequest = { longPressLinkUrl = null; longPressLinkText = null }
        ) {
            Column(Modifier.fillMaxWidth().padding(horizontal = 18.dp, vertical = 8.dp)) {
                Text(
                    href,
                    fontSize = 12.sp,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    maxLines = 2,
                    overflow = androidx.compose.ui.text.style.TextOverflow.Ellipsis,
                    modifier = Modifier.padding(bottom = 8.dp)
                )
                androidx.compose.material3.TextButton(
                    onClick = {
                        val host = runCatching { Uri.parse(href).host }.getOrNull() ?: "Link"
                        needsReload = true
                        val encUrl = java.net.URLEncoder.encode(href, "UTF-8")
                        val encLabel = java.net.URLEncoder.encode(host, "UTF-8")
                        longPressLinkUrl = null; longPressLinkText = null
                        nav.navigate("web/$encUrl/$encLabel")
                    },
                    modifier = Modifier.fillMaxWidth()
                ) { Text("\uD83E\uDE9F  Open in browser") }
                androidx.compose.material3.TextButton(
                    onClick = {
                        val cm = ctx.getSystemService(android.content.Context.CLIPBOARD_SERVICE)
                                as? android.content.ClipboardManager
                        cm?.setPrimaryClip(
                            android.content.ClipData.newPlainText("MarkVault link", href)
                        )
                        android.widget.Toast.makeText(ctx, "Link copied", android.widget.Toast.LENGTH_SHORT).show()
                        longPressLinkUrl = null; longPressLinkText = null
                    },
                    modifier = Modifier.fillMaxWidth()
                ) { Text("\uD83D\uDCCB  Copy link") }
                if (!longPressLinkText.isNullOrBlank()) {
                    androidx.compose.material3.TextButton(
                        onClick = {
                            val cm = ctx.getSystemService(android.content.Context.CLIPBOARD_SERVICE)
                                    as? android.content.ClipboardManager
                            cm?.setPrimaryClip(
                                android.content.ClipData.newPlainText("Link text", longPressLinkText)
                            )
                            android.widget.Toast.makeText(ctx, "Link text copied", android.widget.Toast.LENGTH_SHORT).show()
                            longPressLinkUrl = null; longPressLinkText = null
                        },
                        modifier = Modifier.fillMaxWidth()
                    ) { Text("\uD83D\uDCDD  Copy link text") }
                    androidx.compose.material3.TextButton(
                        onClick = {
                            val query = longPressLinkText ?: return@TextButton
                            vm.query.value = query
                            longPressLinkUrl = null; longPressLinkText = null
                            nav.navigate("search") { launchSingleTop = true }
                        },
                        modifier = Modifier.fillMaxWidth()
                    ) { Text("\uD83D\uDD0D  Search in library") }
                }
            }
        }
    }
}

/**
 * Find-in-page bar — text input + prev/next + close, identical to the one in
 * WebSearchScreen so the experience is consistent. Auto-focuses when opened.
 */
@Composable
private fun FindInPageBar(
    query: String,
    onQueryChange: (String) -> Unit,
    onNext: () -> Unit,
    onPrev: () -> Unit,
    onClose: () -> Unit
) {
    val focus = remember { FocusRequester() }
    LaunchedEffect(Unit) { runCatching { focus.requestFocus() } }
    Surface(
        modifier = Modifier.fillMaxWidth(),
        color = MaterialTheme.colorScheme.surfaceVariant
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 12.dp, vertical = 6.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Icon(
                Icons.Default.Search,
                contentDescription = null,
                modifier = Modifier.size(18.dp),
                tint = MaterialTheme.colorScheme.onSurfaceVariant
            )
            Spacer(Modifier.width(8.dp))
            BasicTextField(
                value = query,
                onValueChange = onQueryChange,
                singleLine = true,
                modifier = Modifier
                    .weight(1f)
                    .focusRequester(focus),
                textStyle = TextStyle(
                    fontSize = 14.sp,
                    color = MaterialTheme.colorScheme.onSurface
                )
            )
            IconButton(onClick = onPrev) {
                Icon(Icons.Default.KeyboardArrowUp, contentDescription = "Previous")
            }
            IconButton(onClick = onNext) {
                Icon(Icons.Default.KeyboardArrowDown, contentDescription = "Next")
            }
            IconButton(onClick = onClose) {
                Icon(Icons.Default.Close, contentDescription = "Close find")
            }
        }
    }
}

@Composable
private fun ErrorPane(
    message: String,
    onOpenExternally: () -> Unit,
    onRetry: () -> Unit
) {
    Column(
        Modifier.fillMaxSize().padding(24.dp),
        verticalArrangement = Arrangement.Center,
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Text("\u26A0\uFE0F", fontSize = 32.sp)
        Spacer(Modifier.size(14.dp))
        Text(
            "Couldn't display this page",
            fontSize = 17.sp,
            fontWeight = FontWeight.SemiBold
        )
        Spacer(Modifier.size(8.dp))
        Text(
            message,
            fontSize = 13.sp,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
            textAlign = TextAlign.Center
        )
        Spacer(Modifier.size(24.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            androidx.compose.material3.OutlinedButton(onClick = onRetry) {
                Text("Retry")
            }
            Button(onClick = onOpenExternally) {
                Text("Open externally")
            }
        }
    }
}

/**
 * Build a JavaScript snippet that highlights matches for [needle] in the
 * article body, reveals hidden ancestors so the mark is actually visible,
 * and scrolls the first match into view.
 *
 * v5.4.37 — Stability fixes for "in-article semantic search". Reported
 * failure mode: search snippet clearly shows a match (e.g. "another name
 * for Peter" hits a study note inside a saved WOL page), but on tapping
 * the result nothing is highlighted in the opened article.
 *
 * Three root causes fixed here:
 *
 *   1. HIDDEN ANCESTORS. WOL/jw.org offline HTML wraps study notes,
 *      footnotes, and glossary pop-ups in containers that are `display:
 *      none` (or `visibility: hidden`, `aria-hidden`, or a closed
 *      `<details>`) until the user taps the referent. The text is in
 *      the DOM (so it gets indexed and the walker finds it), but our
 *      `<mark>` is inserted inside a hidden container and `scrollInto
 *      View` becomes a no-op — the user sees no highlight and no scroll.
 *      Fix: after finding the first mark, walk its ancestor chain and
 *      force `display: block !important`, `visibility: visible
 *      !important`, `opacity: 1 !important`, `aria-hidden: false`, and
 *      open any closed `<details>`.
 *
 *   2. LATE-INJECTED CONTENT. Some saved HTML pages run inline scripts
 *      that only inject the interesting content (footnotes, dynamically
 *      built sections) AFTER `onPageFinished` fires. Our first pass
 *      finds no matches because the target text isn't in the DOM yet.
 *      Fix: retry the highlight pass at 400ms and 1500ms if the previous
 *      attempt found nothing. Retries are silent — if the first attempt
 *      succeeded, we don't touch anything again.
 *
 *   3. SMART-MODE SILENT FAILURE. Sentence-level wrap in smart mode
 *      rejects text inside headings and any element with a heading
 *      ancestor. On heavily fragmented HTML (many tiny text nodes,
 *      unusual DOM shapes) it can end up finding zero sentences that
 *      qualify. Fix: if smart-mode sentence-wrap returns nothing, fall
 *      back to a word-level pass so we still show *something* rather
 *      than silently failing.
 *
 * Also skips `<template>` (its content shouldn't be treated as visible)
 * and detects user scroll during the retry window (if the user has
 * manually scrolled >200px away from the initial top, later retries
 * still apply the mark but skip the auto-scroll — avoids the jarring
 * "page jumps under you 1.5s later" case).
 *
 * Idempotent — every attempt clears previous `mark.mv-hl` before
 * re-wrapping, so retries don't compound.
 */
private fun buildHighlightJs(needle: String, mode: String = "smart", isPhrase: Boolean = false): String {
    // Escape the user's term for safe JS string embedding.
    val esc = needle
        .replace("\\", "\\\\")
        .replace("'", "\\'")
        .replace("\"", "\\\"")
        .replace("\n", " ")
    val modeEsc = if (mode == "keyword") "keyword" else "smart"
    val phraseFlag = if (isPhrase) "true" else "false"
    return """
        (function(){
          try {
            var raw = '$esc';
            var mode = '$modeEsc';
            var isPhrase = $phraseFlag;
            if (!raw || raw.length < 2) return;

            var STOPWORDS = {the:1,is:1,a:1,an:1,of:1,to:1,and:1,in:1,on:1,
              "for":1,at:1,by:1,are:1,was:1,were:1,be:1,been:1,being:1,it:1,
              its:1,this:1,that:1,these:1,those:1,with:1,from:1,as:1,or:1,
              but:1,"if":1,so:1,"do":1,does:1,did:1,has:1,have:1,had:1,
              will:1,would:1,can:1,could:1,what:1,who:1,why:1,how:1,
              when:1,where:1,which:1,about:1,not:1,no:1,also:1,more:1,
              some:1,any:1,all:1,one:1,two:1,you:1,your:1,my:1,we:1,
              our:1,us:1,me:1,he:1,she:1,they:1,them:1,their:1,his:1,
              her:1,"i":1};

            function extractTerms(input) {
              var lower = ('' + input).toLowerCase()
                .replace(/\[\[/g, ' ')
                .replace(/\]\]/g, ' ')
                .replace(/\.\.\./g, ' ')
                .replace(/[^a-z0-9'\s]/g, ' ')
                .replace(/\s+/g, ' ')
                .trim();
              var pieces = lower.split(' ');
              var seen = {};
              var out = [];
              for (var i = 0; i < pieces.length; i++) {
                var w = pieces[i];
                if (w.length >= 4 && !STOPWORDS[w] && !seen[w]) {
                  seen[w] = 1;
                  out.push(w);
                }
              }
              return out;
            }

            function isHeadingTag(t) {
              return t === 'H1' || t === 'H2' || t === 'H3' ||
                     t === 'H4' || t === 'H5' || t === 'H6';
            }

            function hasHeadingAncestor(n) {
              var a = n.parentNode;
              while (a && a !== document.body) {
                if (a.nodeName && isHeadingTag(a.nodeName)) return true;
                a = a.parentNode;
              }
              return false;
            }

            function isSkipTag(tag) {
              return tag === 'SCRIPT' || tag === 'STYLE' ||
                     tag === 'MARK' || tag === 'NOSCRIPT' ||
                     tag === 'TEMPLATE' || tag === 'HEAD';
            }

            function makeMark(text, s, e) {
              var mk = document.createElement('mark');
              mk.className = 'mv-hl';
              mk.style.backgroundColor = '#ffe066';
              mk.style.color = '#000';
              mk.style.padding = '0 1px';
              mk.appendChild(document.createTextNode(text.substring(s, e)));
              return mk;
            }

            function clearPrev() {
              var prev = document.querySelectorAll('mark.mv-hl');
              for (var i = 0; i < prev.length; i++) {
                var p = prev[i];
                var pt = p.parentNode;
                if (!pt) continue;
                pt.replaceChild(document.createTextNode(p.textContent), p);
                // Merge adjacent text nodes back together so subsequent
                // attempts can find phrases that were split by an earlier
                // wrap boundary.
                try { pt.normalize(); } catch (e) {}
              }
            }

            // v5.4.37 — Reveal hidden ancestors of a match so
            // scrollIntoView actually lands somewhere visible. Handles:
            //   * display:none (inline or class-driven — we use
            //     setProperty with 'important' priority to beat class
            //     rules that use !important)
            //   * visibility:hidden
            //   * opacity:0
            //   * aria-hidden="true"
            //   * closed <details> elements
            // Also removes common "hidden" utility classes when we
            // detect they're the reason a container isn't laying out.
            function unhideAncestors(el) {
              var HIDING_CLASSES = ['hidden', 'hide', 'is-hidden',
                'invisible', 'd-none', 'collapse', 'collapsed'];
              var a = el;
              var depth = 0;
              while (a && a !== document.body && depth < 40) {
                try {
                  if (a.nodeType === 1) {
                    var cs = window.getComputedStyle
                      ? window.getComputedStyle(a) : null;
                    if (cs) {
                      if (cs.display === 'none') {
                        a.style.setProperty('display', 'block', 'important');
                      }
                      if (cs.visibility === 'hidden') {
                        a.style.setProperty('visibility', 'visible', 'important');
                      }
                      var op = parseFloat(cs.opacity);
                      if (!isNaN(op) && op === 0) {
                        a.style.setProperty('opacity', '1', 'important');
                      }
                    }
                    // Force open closed <details>
                    if (a.tagName === 'DETAILS' && a.open === false) {
                      a.open = true;
                    }
                    // aria-hidden trick
                    if (a.getAttribute &&
                        a.getAttribute('aria-hidden') === 'true') {
                      a.setAttribute('aria-hidden', 'false');
                    }
                    // Strip common CSS "hidden" classes if the element
                    // still doesn't compute a layout box after inline
                    // fixes above (belt-and-braces for class rules that
                    // are hard to override).
                    if (a.classList && a.classList.length > 0) {
                      for (var ci = 0; ci < HIDING_CLASSES.length; ci++) {
                        if (a.classList.contains(HIDING_CLASSES[ci])) {
                          a.classList.remove(HIDING_CLASSES[ci]);
                        }
                      }
                    }
                    // hidden attribute (HTML5)
                    if (a.hasAttribute && a.hasAttribute('hidden')) {
                      a.removeAttribute('hidden');
                    }
                  }
                } catch (e) {}
                a = a.parentNode;
                depth++;
              }
            }

            // ------- phrase-mode pass (isPhrase === true) -------
            function phrasePass() {
              var phrase = raw.replace(/^"+|"+$/g, '')
                              .replace(/^'+|'+$/g, '').trim();
              if (!phrase) return null;
              var phraseLow = phrase.toLowerCase();
              var phraseLen = phrase.length;
              var walker = document.createTreeWalker(
                document.body, NodeFilter.SHOW_TEXT, {
                  acceptNode: function(n) {
                    if (!n.nodeValue || !n.nodeValue.trim())
                      return NodeFilter.FILTER_REJECT;
                    var p = n.parentNode;
                    if (!p) return NodeFilter.FILTER_REJECT;
                    if (isSkipTag(p.nodeName)) return NodeFilter.FILTER_REJECT;
                    return NodeFilter.FILTER_ACCEPT;
                  }
                }, false);
              var nodes = [];
              var nn;
              while (nn = walker.nextNode()) nodes.push(nn);
              var first = null;
              var cap = 200;
              for (var i = 0; i < nodes.length && cap > 0; i++) {
                var t = nodes[i];
                var text = t.nodeValue;
                var lower = text.toLowerCase();
                var idx = 0;
                var ranges = [];
                while ((idx = lower.indexOf(phraseLow, idx)) !== -1) {
                  ranges.push({s: idx, e: idx + phraseLen});
                  idx += phraseLen;
                }
                if (ranges.length === 0) continue;
                var parent = t.parentNode;
                var cursor = 0;
                var frag = document.createDocumentFragment();
                for (var r = 0; r < ranges.length && cap > 0; r++) {
                  var rr = ranges[r];
                  if (rr.s > cursor) {
                    frag.appendChild(document.createTextNode(
                      text.substring(cursor, rr.s)));
                  }
                  var mk = makeMark(text, rr.s, rr.e);
                  if (!first) first = mk;
                  frag.appendChild(mk);
                  cursor = rr.e;
                  cap--;
                }
                if (cursor < text.length) {
                  frag.appendChild(document.createTextNode(
                    text.substring(cursor)));
                }
                parent.replaceChild(frag, t);
              }
              return first;
            }

            // ------- smart-mode sentence-level pass -------
            function sentencePass(terms) {
              var walker = document.createTreeWalker(
                document.body, NodeFilter.SHOW_TEXT, {
                  acceptNode: function(n) {
                    if (!n.nodeValue || !n.nodeValue.trim())
                      return NodeFilter.FILTER_REJECT;
                    var p = n.parentNode;
                    if (!p) return NodeFilter.FILTER_REJECT;
                    var tag = p.nodeName;
                    if (isSkipTag(tag)) return NodeFilter.FILTER_REJECT;
                    if (isHeadingTag(tag)) return NodeFilter.FILTER_REJECT;
                    if (hasHeadingAncestor(n)) return NodeFilter.FILTER_REJECT;
                    return NodeFilter.FILTER_ACCEPT;
                  }
                }, false);
              var nodes = [];
              var nn;
              while (nn = walker.nextNode()) nodes.push(nn);
              var totalHl = 0;
              var MAX_HL = 40;
              var MIN_HITS = 1;
              var first = null;
              for (var i = 0; i < nodes.length && totalHl < MAX_HL; i++) {
                var t = nodes[i];
                var text = t.nodeValue;
                var sentenceRe = /[^.!?\n]+(?:[.!?]+|$)/g;
                var m;
                var ranges = [];
                while ((m = sentenceRe.exec(text)) !== null) {
                  var sentence = m[0];
                  var sentTrim = sentence.replace(/^\s+|\s+$/g, '');
                  if (sentTrim.length < 8) continue;
                  var sentLower = sentence.toLowerCase();
                  var hits = 0;
                  var matched = {};
                  for (var ti = 0; ti < terms.length; ti++) {
                    if (!matched[terms[ti]] &&
                        sentLower.indexOf(terms[ti]) >= 0) {
                      matched[terms[ti]] = 1;
                      hits++;
                    }
                  }
                  if (hits >= MIN_HITS) {
                    var s = m.index;
                    var e = s + sentence.length;
                    while (s < e && /\s/.test(text.charAt(s))) s++;
                    if (s < e) ranges.push({s: s, e: e});
                  }
                }
                if (ranges.length === 0) continue;
                var parent = t.parentNode;
                var cursor = 0;
                var frag = document.createDocumentFragment();
                for (var r = 0; r < ranges.length && totalHl < MAX_HL; r++) {
                  var range = ranges[r];
                  if (range.s > cursor) {
                    frag.appendChild(document.createTextNode(
                      text.substring(cursor, range.s)));
                  }
                  var mk = makeMark(text, range.s, range.e);
                  if (!first) first = mk;
                  frag.appendChild(mk);
                  cursor = range.e;
                  totalHl++;
                }
                if (cursor < text.length) {
                  frag.appendChild(document.createTextNode(
                    text.substring(cursor)));
                }
                parent.replaceChild(frag, t);
              }
              return first;
            }

            // ------- word-level pass (keyword mode + smart-mode fallback) -------
            function wordPass(terms) {
              var walker = document.createTreeWalker(
                document.body, NodeFilter.SHOW_TEXT, {
                  acceptNode: function(n) {
                    if (!n.nodeValue || !n.nodeValue.trim())
                      return NodeFilter.FILTER_REJECT;
                    var p = n.parentNode;
                    if (!p) return NodeFilter.FILTER_REJECT;
                    if (isSkipTag(p.nodeName)) return NodeFilter.FILTER_REJECT;
                    return NodeFilter.FILTER_ACCEPT;
                  }
                }, false);
              var nodes = [];
              var nn;
              while (nn = walker.nextNode()) nodes.push(nn);
              var cap = 200;
              var first = null;
              for (var i = 0; i < nodes.length && cap > 0; i++) {
                var t = nodes[i];
                var text = t.nodeValue;
                var lower = text.toLowerCase();
                var ranges = [];
                for (var ti = 0; ti < terms.length; ti++) {
                  var term = terms[ti];
                  var idx = 0;
                  while ((idx = lower.indexOf(term, idx)) !== -1) {
                    ranges.push({s: idx, e: idx + term.length});
                    idx += term.length;
                  }
                }
                if (ranges.length === 0) continue;
                ranges.sort(function(a, b){ return a.s - b.s; });
                var merged = [ranges[0]];
                for (var mi = 1; mi < ranges.length; mi++) {
                  var top = merged[merged.length - 1];
                  if (ranges[mi].s <= top.e) {
                    top.e = Math.max(top.e, ranges[mi].e);
                  } else {
                    merged.push(ranges[mi]);
                  }
                }
                var parent = t.parentNode;
                var cursor = 0;
                var frag = document.createDocumentFragment();
                for (var ri = 0; ri < merged.length && cap > 0; ri++) {
                  var r = merged[ri];
                  if (r.s > cursor) {
                    frag.appendChild(document.createTextNode(
                      text.substring(cursor, r.s)));
                  }
                  var mk = makeMark(text, r.s, r.e);
                  if (!first) first = mk;
                  frag.appendChild(mk);
                  cursor = r.e;
                  cap--;
                }
                if (cursor < text.length) {
                  frag.appendChild(document.createTextNode(
                    text.substring(cursor)));
                }
                parent.replaceChild(frag, t);
              }
              return first;
            }

            // ------- single attempt (fresh DOM walk each time) -------
            function attempt() {
              clearPrev();
              if (isPhrase === true) {
                return phrasePass();
              }
              var terms = extractTerms(raw);
              if (terms.length === 0) return null;
              if (mode === 'smart') {
                var sfirst = sentencePass(terms);
                if (sfirst) return sfirst;
                // v5.4.37 — smart-mode word-level fallback so we don't
                // silently give up when the DOM shape defeats sentence-
                // level (very fragmented text nodes, unusual heading
                // structure that swallows candidates via
                // hasHeadingAncestor, etc.).
                return wordPass(terms);
              }
              return wordPass(terms);
            }

            // Track initial scroll to detect if the user manually scrolled
            // between the first (silent-failure) attempt and the retries.
            // If they have, don't yank them elsewhere on retry.
            var initialY = window.pageYOffset ||
                           document.documentElement.scrollTop || 0;
            function userMovedAway() {
              var y = window.pageYOffset ||
                      document.documentElement.scrollTop || 0;
              return Math.abs(y - initialY) > 200;
            }

            function scrollToMark(mk, allowScroll) {
              if (!allowScroll) return;
              // Two-frame delay so the unhide-ancestors style changes
              // above get laid out before scrollIntoView measures.
              var doScroll = function() {
                try {
                  mk.scrollIntoView({behavior: 'smooth', block: 'center'});
                } catch (e) {
                  try { mk.scrollIntoView(); } catch (_) {}
                }
              };
              if (window.requestAnimationFrame) {
                window.requestAnimationFrame(function(){
                  window.requestAnimationFrame(doScroll);
                });
              } else {
                setTimeout(doScroll, 60);
              }
            }

            function finalize(mk, allowScroll) {
              if (!mk) return;
              // v5.4.37 — Reveal ancestors of EVERY mark, not just the
              // first. On WOL/jw.org offline pages several study notes
              // may match; if only the first-mark's container is un-
              // hidden, subsequent matches remain invisible when the
              // user scrolls past the first one. Cheap to walk all
              // marks — usually ≤40 (capped in the passes above).
              try {
                var all = document.querySelectorAll('mark.mv-hl');
                for (var ai = 0; ai < all.length; ai++) {
                  unhideAncestors(all[ai]);
                }
              } catch (e) {
                unhideAncestors(mk);
              }
              scrollToMark(mk, allowScroll);
            }

            // ------- try immediately -------
            var mk1 = attempt();
            if (mk1) {
              finalize(mk1, true);
              return;
            }
            // ------- retry at 400ms (dynamic content) -------
            setTimeout(function() {
              var mk2 = attempt();
              if (mk2) {
                finalize(mk2, !userMovedAway());
                return;
              }
              // ------- retry at 1500ms (slow content) -------
              setTimeout(function() {
                var mk3 = attempt();
                if (mk3) {
                  finalize(mk3, !userMovedAway());
                }
              }, 1500);
            }, 400);
          } catch (e) {
            try { console.log('mv-highlight error: ' + e); } catch (_) {}
          }
        })();
    """.trimIndent()
}
