package com.tebogo.markvault.ui

import android.annotation.SuppressLint
import android.net.Uri
import android.view.ViewGroup
import android.webkit.RenderProcessGoneDetail
import android.webkit.WebResourceRequest
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.KeyboardArrowDown
import androidx.compose.material.icons.filled.KeyboardArrowUp
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.Button
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.navigation.NavController
import com.tebogo.markvault.AppViewModel
import com.tebogo.markvault.util.MhtmlParser
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

/**
 * Reader for offline web archives — full feature parity with markdown reader:
 *   • Find-in-page with prev/next nav (Ctrl+F equivalent)
 *   • Search-result highlight injection (pendingHighlight from VM)
 *   • Open externally fallback
 *   • Crash-hardened (renderer recovery)
 *   • Comprehensive bottom toolbar with all standard actions
 *   • Link taps route to in-app browser
 *
 * v4.6 changes from v4.5:
 *   1. Find-in-page UI added (WebView.findAllAsync + findNext).
 *   2. Pending highlight from Search screen now flashes in the WebView via
 *      injected JavaScript wrapping matches in <mark> spans.
 *   3. Toolbar now mirrors the markdown reader's button density.
 */
@Composable
fun HtmlReaderScreen(
    vm: AppViewModel,
    nav: NavController,
    id: Long
) {
    val ctx = LocalContext.current
    val theme by vm.theme.collectAsState()

    var title by remember { mutableStateOf("Offline page") }
    var htmlContent by remember { mutableStateOf<String?>(null) }
    var baseUrl by remember { mutableStateOf<String?>(null) }
    var rendererCrashed by remember { mutableStateOf(false) }
    var loadError by remember { mutableStateOf<String?>(null) }
    var originalUri by remember { mutableStateOf<Uri?>(null) }
    var htmlLoaded by remember { mutableStateOf(false) }

    // Find-in-page state — mirrors WebSearchScreen's pattern.
    var findOpen by remember { mutableStateOf(false) }
    var findQuery by remember { mutableStateOf("") }
    var webViewRef by remember { mutableStateOf<WebView?>(null) }

    LaunchedEffect(id) {
        val note = withContext(Dispatchers.IO) { vm.loadNote(id) }
        if (note == null) {
            loadError = "Could not load the file from the library."
            return@LaunchedEffect
        }
        title = note.title.ifBlank { note.name }
        originalUri = runCatching { Uri.parse(note.uri) }.getOrNull()

        val bytes = withContext(Dispatchers.IO) {
            runCatching {
                ctx.contentResolver.openInputStream(Uri.parse(note.uri))?.use {
                    it.readBytes()
                }
            }.getOrNull()
        }
        if (bytes == null) {
            loadError = "Could not read the file. The library folder may have been moved."
            return@LaunchedEffect
        }

        val nameLower = note.name.lowercase()
        val isMhtml = nameLower.endsWith(".mhtml") || nameLower.endsWith(".mht")

        if (isMhtml) {
            val parsed = withContext(Dispatchers.IO) {
                MhtmlParser.extractHtmlContent(bytes)
            }
            if (parsed == null) {
                loadError = "This MHTML file is malformed. Try opening it externally."
                return@LaunchedEffect
            }
            htmlContent = parsed
            baseUrl = withContext(Dispatchers.IO) { MhtmlParser.extractBaseUrl(bytes) }
        } else {
            htmlContent = try {
                String(bytes, Charsets.UTF_8)
            } catch (_: Exception) {
                String(bytes)
            }
        }

        vm.openArticle(id, title, fileType = note.fileType)
    }

    Column(Modifier.fillMaxSize()) {
        // Title strip
        Surface(
            modifier = Modifier.fillMaxWidth(),
            color = MaterialTheme.colorScheme.surfaceVariant
        ) {
            Text(
                "\uD83C\uDF10  $title",
                modifier = Modifier.padding(horizontal = 16.dp, vertical = 10.dp),
                fontSize = 14.sp,
                maxLines = 1
            )
        }

        // Find-in-page bar (slides in when find button tapped)
        if (findOpen) {
            FindInPageBar(
                query = findQuery,
                onQueryChange = {
                    findQuery = it
                    webViewRef?.findAllAsync(it)
                },
                onNext = { webViewRef?.findNext(true) },
                onPrev = { webViewRef?.findNext(false) },
                onClose = {
                    findOpen = false
                    webViewRef?.clearMatches()
                }
            )
        }

        // Body
        Box(modifier = Modifier.fillMaxWidth().weight(1f)) {
            when {
                loadError != null || rendererCrashed -> ErrorPane(
                    message = loadError ?: "The page renderer crashed.",
                    onOpenExternally = {
                        originalUri?.let { uri ->
                            runCatching {
                                ctx.startActivity(
                                    android.content.Intent(
                                        android.content.Intent.ACTION_VIEW, uri
                                    ).addFlags(
                                        android.content.Intent.FLAG_GRANT_READ_URI_PERMISSION
                                    )
                                )
                            }
                        }
                    },
                    onRetry = {
                        rendererCrashed = false
                        loadError = null
                        htmlLoaded = false
                    }
                )

                htmlContent != null -> AndroidView(
                    modifier = Modifier.fillMaxSize(),
                    factory = { context ->
                        @SuppressLint("SetJavaScriptEnabled")
                        SelectionWebView(context).apply {
                            layoutParams = ViewGroup.LayoutParams(
                                ViewGroup.LayoutParams.MATCH_PARENT,
                                ViewGroup.LayoutParams.MATCH_PARENT
                            )
                            settings.javaScriptEnabled = true
                            settings.domStorageEnabled = true
                            settings.useWideViewPort = true
                            settings.loadWithOverviewMode = true
                            settings.builtInZoomControls = true
                            settings.displayZoomControls = false
                            settings.mixedContentMode =
                                WebSettings.MIXED_CONTENT_COMPATIBILITY_MODE

                            webViewClient = object : WebViewClient() {
                                override fun shouldOverrideUrlLoading(
                                    view: WebView?, request: WebResourceRequest?
                                ): Boolean {
                                    val u = request?.url ?: return false
                                    if (u.scheme == "data" || u.scheme == "cid" ||
                                        u.scheme == "file" || u.scheme == "blob" ||
                                        u.scheme == "about") return false
                                    val encUrl = java.net.URLEncoder.encode(u.toString(), "UTF-8")
                                    val encLabel = java.net.URLEncoder.encode(
                                        u.host ?: "Link", "UTF-8"
                                    )
                                    nav.navigate("web/$encUrl/$encLabel") {
                                        launchSingleTop = true
                                    }
                                    return true
                                }

                                override fun onPageFinished(view: WebView?, url: String?) {
                                    super.onPageFinished(view, url)
                                    // Inject highlight JS for the pending search
                                    // term — flashes the searched word in the
                                    // article so the user doesn't have to find
                                    // it manually. Consume the pending value so
                                    // it doesn't re-fire on later navigations.
                                    val pending = vm.consumePendingHighlight()
                                    if (!pending.isNullOrBlank() && view != null) {
                                        view.evaluateJavascript(
                                            buildHighlightJs(pending), null
                                        )
                                    }
                                }

                                override fun onRenderProcessGone(
                                    view: WebView?, detail: RenderProcessGoneDetail?
                                ): Boolean {
                                    rendererCrashed = true
                                    runCatching { view?.destroy() }
                                    return true
                                }
                            }

                            onSearchInMarkVault = { text ->
                                vm.requestPendingSearch(text)
                                nav.navigate("search") { launchSingleTop = true }
                            }
                            onSearchInWol = { text ->
                                val target = "https://wol.jw.org/en/wol/s/r1/lp-e?q=" +
                                    java.net.URLEncoder.encode(text, "UTF-8")
                                vm.requestWebPopup(target)
                            }

                            webViewRef = this
                        }
                    },
                    update = { w ->
                        val html = htmlContent ?: return@AndroidView
                        if (!htmlLoaded) {
                            runCatching {
                                w.loadDataWithBaseURL(
                                    baseUrl ?: "about:blank",
                                    html,
                                    "text/html",
                                    "utf-8",
                                    null
                                )
                            }
                            htmlLoaded = true
                        }
                    }
                )
            }
        }

        // Bottom toolbar — full set: back / find / open-externally / browser /
        // home / overflow. Matches the markdown reader's density.
        MarkVaultBottomBar(
            nav = nav,
            vm = vm,
            extraActions = {
                // Find-in-page toggle
                IconButton(onClick = { findOpen = !findOpen }) {
                    Icon(Icons.Default.Search, contentDescription = "Find in page")
                }
                // Open externally
                IconButton(onClick = {
                    originalUri?.let { uri ->
                        runCatching {
                            ctx.startActivity(
                                android.content.Intent(
                                    android.content.Intent.ACTION_VIEW, uri
                                ).addFlags(
                                    android.content.Intent.FLAG_GRANT_READ_URI_PERMISSION
                                )
                            )
                        }
                    }
                }) {
                    Text("\u2197", fontSize = 18.sp)
                }
            }
        )
    }
}

/**
 * Find-in-page bar — text input + prev/next + close, identical to the one in
 * WebSearchScreen so the experience is consistent. Auto-focuses when opened.
 */
@Composable
private fun FindInPageBar(
    query: String,
    onQueryChange: (String) -> Unit,
    onNext: () -> Unit,
    onPrev: () -> Unit,
    onClose: () -> Unit
) {
    val focus = remember { FocusRequester() }
    LaunchedEffect(Unit) { runCatching { focus.requestFocus() } }
    Surface(
        modifier = Modifier.fillMaxWidth(),
        color = MaterialTheme.colorScheme.surfaceVariant
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 12.dp, vertical = 6.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Icon(
                Icons.Default.Search,
                contentDescription = null,
                modifier = Modifier.size(18.dp),
                tint = MaterialTheme.colorScheme.onSurfaceVariant
            )
            Spacer(Modifier.width(8.dp))
            BasicTextField(
                value = query,
                onValueChange = onQueryChange,
                singleLine = true,
                modifier = Modifier
                    .weight(1f)
                    .focusRequester(focus),
                textStyle = TextStyle(
                    fontSize = 14.sp,
                    color = MaterialTheme.colorScheme.onSurface
                )
            )
            IconButton(onClick = onPrev) {
                Icon(Icons.Default.KeyboardArrowUp, contentDescription = "Previous")
            }
            IconButton(onClick = onNext) {
                Icon(Icons.Default.KeyboardArrowDown, contentDescription = "Next")
            }
            IconButton(onClick = onClose) {
                Icon(Icons.Default.Close, contentDescription = "Close find")
            }
        }
    }
}

@Composable
private fun ErrorPane(
    message: String,
    onOpenExternally: () -> Unit,
    onRetry: () -> Unit
) {
    Column(
        Modifier.fillMaxSize().padding(24.dp),
        verticalArrangement = Arrangement.Center,
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Text("\u26A0\uFE0F", fontSize = 32.sp)
        Spacer(Modifier.size(14.dp))
        Text(
            "Couldn't display this page",
            fontSize = 17.sp,
            fontWeight = FontWeight.SemiBold
        )
        Spacer(Modifier.size(8.dp))
        Text(
            message,
            fontSize = 13.sp,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
            textAlign = TextAlign.Center
        )
        Spacer(Modifier.size(24.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            androidx.compose.material3.OutlinedButton(onClick = onRetry) {
                Text("Retry")
            }
            Button(onClick = onOpenExternally) {
                Text("Open externally")
            }
        }
    }
}

/**
 * Build a JavaScript snippet that finds the best matching term in [needle],
 * wraps every occurrence in a yellow-tinted `<mark>` span, and scrolls the
 * first match into view.
 *
 * v4.14.0 — phrase-first matching with multi-stage fallback (mirrors what
 * `render.js` already does for the markdown reader):
 *   1. Try the full phrase exactly as supplied
 *   2. Strip trailing punctuation (`?`, `!`, `.`, `,`, `;`, `:`) and retry
 *   3. Fall back to the longest non-stopword that appears in the document
 *   4. Last resort: any word from the query that appears
 *
 * The first stage that finds matches wins; subsequent stages aren't tried.
 * The selected term is what gets highlighted everywhere in the document,
 * so phrases come through as single underlined blocks rather than a confetti
 * of individual word matches.
 *
 * Idempotent — calling it again with a different needle replaces previous
 * marks. Walks text nodes only and skips script/style/mark elements.
 */
private fun buildHighlightJs(needle: String): String {
    // Escape the user's term for safe JS string embedding.
    val esc = needle
        .replace("\\", "\\\\")
        .replace("'", "\\'")
        .replace("\"", "\\\"")
        .replace("\n", " ")
    return """
        (function(){
          try {
            var raw = '$esc';
            if (!raw || raw.length < 2) return;

            // Remove any previous markvault highlights so re-runs don't compound.
            var prev = document.querySelectorAll('mark.mv-hl');
            for (var i = 0; i < prev.length; i++) {
              var p = prev[i];
              p.replaceWith(document.createTextNode(p.textContent));
            }

            // v4.14.0 — phrase-first picker
            var STOPWORDS = {the:1,is:1,a:1,an:1,of:1,to:1,and:1,in:1,on:1,
              "for":1,at:1,by:1,are:1,was:1,were:1,be:1,been:1,being:1,it:1,
              its:1,this:1,that:1,these:1,those:1,with:1,from:1,as:1,or:1,
              but:1,"if":1,so:1,"do":1,does:1,did:1,has:1,have:1,had:1,
              will:1,would:1,can:1,could:1};

            var bodyLower = document.body.textContent.toLowerCase();
            function pickTerm(input) {
              var normalised = input.toLowerCase().replace(/\s+/g, ' ').trim();
              if (!normalised) return null;
              // 1. Whole phrase
              if (bodyLower.indexOf(normalised) >= 0) return normalised;
              // 2. Strip trailing punctuation
              var stripped = normalised.replace(/[?!.,;:]+$/g, '').trim();
              if (stripped && stripped !== normalised &&
                  bodyLower.indexOf(stripped) >= 0) return stripped;
              // 3. Longest non-stopword
              var words = normalised.split(/[^a-z0-9']+/i).filter(function(w){
                return w && w.length >= 2;
              });
              words.sort(function(a,b){ return b.length - a.length; });
              for (var k = 0; k < words.length; k++) {
                var w = words[k];
                if (STOPWORDS[w]) continue;
                if (bodyLower.indexOf(w) >= 0) return w;
              }
              // 4. Last resort: any word, stopwords included
              for (var j = 0; j < words.length; j++) {
                if (bodyLower.indexOf(words[j]) >= 0) return words[j];
              }
              return null;
            }

            var chosen = pickTerm(raw);
            if (!chosen) return;
            var chosenLower = chosen;  // already lower-cased by pickTerm

            var walker = document.createTreeWalker(
              document.body, NodeFilter.SHOW_TEXT, {
                acceptNode: function(n) {
                  var p = n.parentNode;
                  if (!p) return NodeFilter.FILTER_REJECT;
                  var tag = p.nodeName;
                  if (tag === 'SCRIPT' || tag === 'STYLE' ||
                      tag === 'MARK' || tag === 'NOSCRIPT') {
                    return NodeFilter.FILTER_REJECT;
                  }
                  return n.nodeValue.toLowerCase().indexOf(chosenLower) >= 0
                    ? NodeFilter.FILTER_ACCEPT : NodeFilter.FILTER_SKIP;
                }
              }, false);

            var nodes = [];
            var node;
            while (node = walker.nextNode()) nodes.push(node);

            var firstMark = null;
            for (var jj = 0; jj < nodes.length; jj++) {
              var t = nodes[jj];
              var text = t.nodeValue;
              var lower = text.toLowerCase();
              var pieces = document.createDocumentFragment();
              var pos = 0;
              while (true) {
                var idx = lower.indexOf(chosenLower, pos);
                if (idx < 0) break;
                if (idx > pos) {
                  pieces.appendChild(document.createTextNode(text.substring(pos, idx)));
                }
                var mark = document.createElement('mark');
                mark.className = 'mv-hl';
                mark.style.backgroundColor = '#ffe066';
                mark.style.color = '#000';
                mark.style.padding = '0 1px';
                mark.appendChild(document.createTextNode(
                  text.substring(idx, idx + chosenLower.length)
                ));
                if (!firstMark) firstMark = mark;
                pieces.appendChild(mark);
                pos = idx + chosenLower.length;
              }
              if (pos < text.length) {
                pieces.appendChild(document.createTextNode(text.substring(pos)));
              }
              if (pos > 0) t.parentNode.replaceChild(pieces, t);
            }

            if (firstMark) {
              firstMark.scrollIntoView({behavior: 'smooth', block: 'center'});
            }
          } catch (e) {
            console.log('mv-highlight error: ' + e);
          }
        })();
    """.trimIndent()
}
