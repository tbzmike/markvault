package com.tebogo.markvault.ui

import android.annotation.SuppressLint
import android.net.Uri
import android.view.ViewGroup
import android.webkit.WebResourceRequest
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
// Note: Modifier.weight(...) is provided as an extension by ColumnScope/RowScope
// at the call site — no explicit import needed (and importing
// `androidx.compose.foundation.layout.weight` would pull in an internal symbol
// that doesn't compile against external code).
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.navigation.NavController
import com.tebogo.markvault.AppViewModel
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

/**
 * Renders a saved offline web archive (`.html`, `.htm`, `.mhtml`, `.mht`) inside
 * a sandboxed WebView. Distinct from the markdown reader (which uses our own
 * markdown-it pipeline) because these files arrive as the browser produced them
 * and need the WebView's native engine to layout properly.
 *
 * The file content is read once via SAF (using the Note.uri stored at index
 * time) and fed to the WebView via [WebView.loadDataWithBaseURL] — that's the
 * supported way to render in-memory HTML or MHTML without a real http URL.
 *
 * MHTML files are auto-detected by their `MIME-Version` / `Content-Type:
 * multipart/related` headers in the first 200 bytes and loaded with mime type
 * `multipart/related`; modern WebView versions render them correctly. Plain
 * HTML loads with mime `text/html`. The base URL is set to the file's original
 * source if we can find one in the MHTML headers, otherwise to `about:blank`.
 */
@Composable
fun HtmlReaderScreen(
    vm: AppViewModel,
    nav: NavController,
    id: Long
) {
    val ctx = LocalContext.current
    val theme by vm.theme.collectAsState()

    // Initially unknown — we load asynchronously off the main thread because
    // these files can be several MB.
    var title by remember { mutableStateOf("Offline page") }
    var fileUrl by remember { mutableStateOf<String?>(null) }
    var loadError by remember { mutableStateOf<String?>(null) }

    LaunchedEffect(id) {
        val note = withContext(Dispatchers.IO) { vm.loadNote(id) }
        if (note == null) {
            loadError = "Could not load the file from the library."
            return@LaunchedEffect
        }
        title = note.title.ifBlank { note.name }
        // CRITICAL: don't pull the entire file into a Kotlin String. MHTML is
        // technically text but it carries base64-encoded binary parts that get
        // mangled by a UTF-8 roundtrip — which caused the v4.4 crash. Instead
        // we copy the raw bytes byte-for-byte into the app cache and hand the
        // WebView a `file://` URL. WebView's native parser handles both .mhtml
        // and .html from a real file path correctly.
        val cacheFile = withContext(Dispatchers.IO) {
            runCatching {
                val origName = note.name
                val ext = when {
                    origName.endsWith(".mhtml", true) -> "mhtml"
                    origName.endsWith(".mht", true)   -> "mhtml"
                    origName.endsWith(".htm", true)   -> "html"
                    else -> "html"
                }
                val out = java.io.File(ctx.cacheDir, "mvview_${id}_${System.currentTimeMillis()}.$ext")
                ctx.contentResolver.openInputStream(Uri.parse(note.uri))?.use { input ->
                    out.outputStream().use { output -> input.copyTo(output) }
                } ?: return@runCatching null
                out
            }.getOrNull()
        }
        if (cacheFile == null || !cacheFile.exists() || cacheFile.length() == 0L) {
            loadError = "Could not read the file. The library folder may have been moved."
            return@LaunchedEffect
        }
        fileUrl = Uri.fromFile(cacheFile).toString()
        vm.openArticle(id, title, fileType = note.fileType)
    }

    Column(Modifier.fillMaxSize()) {
        // Title strip at the top — matches PDF reader's look so the user
        // recognises this as a "reader" not the chrome-less popup.
        Surface(
            modifier = Modifier.fillMaxWidth(),
            color = MaterialTheme.colorScheme.surfaceVariant
        ) {
            Text(
                "\uD83C\uDF10  $title",
                modifier = Modifier.padding(horizontal = 16.dp, vertical = 10.dp),
                fontSize = 14.sp,
                maxLines = 1
            )
        }

        // WebView body
        if (loadError != null) {
            Column(
                Modifier.fillMaxSize().padding(24.dp),
                horizontalAlignment = androidx.compose.ui.Alignment.CenterHorizontally
            ) {
                Spacer(Modifier.size(40.dp))
                Text("\u26A0\uFE0F  Couldn't open this file", fontSize = 16.sp)
                Spacer(Modifier.size(12.dp))
                Text(loadError ?: "", fontSize = 13.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
        } else if (fileUrl != null) {
            AndroidView(
                modifier = Modifier.fillMaxWidth().weight(1f),
                factory = { context ->
                    @SuppressLint("SetJavaScriptEnabled")
                    SelectionWebView(context).apply {
                        layoutParams = ViewGroup.LayoutParams(
                            ViewGroup.LayoutParams.MATCH_PARENT,
                            ViewGroup.LayoutParams.MATCH_PARENT
                        )
                        // Allow scripts so saved jw.org pages render correctly;
                        // they're already-archived content from a trusted origin
                        // and can't reach the live network from this WebView.
                        settings.javaScriptEnabled = true
                        settings.domStorageEnabled = true
                        settings.useWideViewPort = true
                        settings.loadWithOverviewMode = true
                        settings.builtInZoomControls = true
                        settings.displayZoomControls = false
                        // Saved pages can reference resources via file:// paths
                        // from their own MHTML container — let them resolve.
                        settings.allowFileAccess = true
                        settings.allowContentAccess = true
                        settings.allowFileAccessFromFileURLs = true
                        settings.mixedContentMode = WebSettings.MIXED_CONTENT_COMPATIBILITY_MODE
                        webViewClient = object : WebViewClient() {
                            override fun shouldOverrideUrlLoading(
                                view: WebView?, request: WebResourceRequest?
                            ): Boolean {
                                val u = request?.url ?: return false
                                // Internal MHTML references — let the WebView handle.
                                if (u.scheme == "data" || u.scheme == "cid" ||
                                    u.scheme == "file" || u.scheme == "blob") {
                                    return false
                                }
                                // ALL external links route to the built-in
                                // WebViewer (user request: "WebViewer should
                                // always be the default for all functions
                                // globally"). The WebViewer's own allow-list
                                // decides whether to load in-app or bounce to
                                // the system browser — we don't make that call
                                // here, we just deliver the link to it.
                                val encUrl = java.net.URLEncoder.encode(u.toString(), "UTF-8")
                                val encLabel = java.net.URLEncoder.encode(
                                    u.host ?: "Link", "UTF-8"
                                )
                                nav.navigate("web/$encUrl/$encLabel") {
                                    launchSingleTop = true
                                }
                                return true
                            }
                        }
                        // Same text-selection menu we use everywhere else.
                        onSearchInMarkVault = { text ->
                            vm.requestPendingSearch(text)
                            nav.navigate("search") { launchSingleTop = true }
                        }
                        onSearchInWol = { text ->
                            val target = "https://wol.jw.org/en/wol/s/r1/lp-e?q=" +
                                java.net.URLEncoder.encode(text, "UTF-8")
                            vm.requestWebPopup(target)
                        }
                    }
                },
                update = { w ->
                    // Load only once per fileUrl change. WebView caches the
                    // page after the first load, so subsequent recompositions
                    // don't reload from disk.
                    val u = fileUrl ?: return@AndroidView
                    if (w.url != u) w.loadUrl(u)
                }
            )
        }

        // Bottom toolbar — matches every other reader screen for consistency.
        MarkVaultBottomBar(
            nav = nav,
            vm = vm,
            extraActions = {
                // No reader-specific actions for now; theming + back are enough.
            }
        )
    }
}
