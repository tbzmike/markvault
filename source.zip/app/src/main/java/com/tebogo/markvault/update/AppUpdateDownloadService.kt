package com.tebogo.markvault.update

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Intent
import android.content.pm.ServiceInfo
import android.net.ConnectivityManager
import android.net.NetworkCapabilities
import android.os.Build
import android.os.IBinder
import com.tebogo.markvault.MainActivity
import com.tebogo.markvault.R
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.delay
import kotlinx.coroutines.ensureActive
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import java.io.File
import java.io.FileOutputStream
import java.io.IOException
import java.net.HttpURLConnection
import java.net.URL
import java.util.concurrent.atomic.AtomicBoolean
import kotlin.coroutines.coroutineContext

/**
 * User-started, resumable APK transfer. Network failures never delete the `.part` file:
 * the service moves to WAITING_NETWORK and keeps retrying until the user explicitly
 * cancels. START_STICKY plus persisted release metadata also lets Android restart the
 * transfer after ordinary process/service reclamation.
 */
class AppUpdateDownloadService : Service() {
    companion object {
        const val ACTION_START_OR_RESUME = "com.tebogo.markvault.update.START_OR_RESUME"
        const val ACTION_CANCEL = "com.tebogo.markvault.update.CANCEL"
        const val PART_FILE_NAME = "MarkVault.apk.part"
        const val FINAL_FILE_NAME = "MarkVault.apk"

        private const val CHANNEL_ID = "markvault_app_update"
        private const val NOTIFICATION_ID = 540402
        private const val CONNECT_TIMEOUT_MS = 30_000
        private const val READ_TIMEOUT_MS = 30_000
        private const val HTTP_RANGE_NOT_SATISFIABLE = 416
    }

    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
    private val cancelRequested = AtomicBoolean(false)
    @Volatile private var activeConnection: HttpURLConnection? = null
    @Volatile private var worker: Job? = null

    override fun onCreate() {
        super.onCreate()
        AppUpdateManager.initialize(this)
        createNotificationChannel()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_CANCEL) {
            cancelRequested.set(true)
            activeConnection?.disconnect()
            worker?.cancel()
            AppUpdateManager.clearDownloadedFiles(this)
            val previous = AppUpdateManager.current(this)
            AppUpdateManager.updateFromService(
                this,
                previous.copy(
                    phase = AppUpdatePhase.CANCELED,
                    message = "Update download canceled.",
                    bytesDownloaded = 0L,
                    bytesPerSecond = 0L,
                    candidateVersionName = "",
                    candidateVersionCode = 0L
                )
            )
            stopForeground(STOP_FOREGROUND_REMOVE)
            stopSelf()
            return START_NOT_STICKY
        }

        val current = AppUpdateManager.current(this)
        if (current.assetUrl.isBlank() || current.expectedSha256.length != 64 || current.totalBytes <= 0L) {
            AppUpdateManager.updateFromService(
                this,
                current.copy(
                    phase = AppUpdatePhase.ERROR,
                    message = "Update metadata is incomplete. Check for updates again."
                )
            )
            stopSelf()
            return START_NOT_STICKY
        }

        startForegroundCompat(buildNotification(current.copy(phase = AppUpdatePhase.DOWNLOADING)))
        if (worker?.isActive != true) {
            cancelRequested.set(false)
            worker = scope.launch { runDownloadLoop() }
        }
        return START_STICKY
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onDestroy() {
        activeConnection?.disconnect()
        scope.cancel()
        super.onDestroy()
    }

    override fun onTimeout(startId: Int, fgsType: Int) {
        val current = AppUpdateManager.current(this)
        AppUpdateManager.updateFromService(
            this,
            current.copy(
                phase = AppUpdatePhase.PAUSED_SYSTEM,
                message = "Android paused this long-running transfer. Open MarkVault to resume from saved progress.",
                bytesPerSecond = 0L
            )
        )
        activeConnection?.disconnect()
        worker?.cancel()
        stopForeground(STOP_FOREGROUND_DETACH)
        stopSelf(startId)
    }

    private suspend fun runDownloadLoop() {
        val dir = AppUpdateManager.updateDirectory(this)
        val part = File(dir, PART_FILE_NAME)
        val finalApk = File(dir, FINAL_FILE_NAME)

        val initialMetadata = AppUpdateManager.current(this)
        if (finalApk.isFile && finalApk.length() == initialMetadata.totalBytes) {
            val digestMatches = runCatching {
                AppUpdateManager.sha256Of(finalApk).equals(initialMetadata.expectedSha256, ignoreCase = true)
            }.getOrDefault(false)
            if (digestMatches) {
                val check = AppUpdateInstaller.verifyDownloadedApk(this, finalApk)
                if (check.valid && !cancelRequested.get() && worker?.isCancelled != true) {
                    completeReady(finalApk, initialMetadata, check)
                    return
                }
            }
            finalApk.delete()
        }

        var lastUiAt = 0L
        var lastPersistAt = 0L
        var hashRetryCount = 0

        try {
            while (coroutineContext.isActive && !cancelRequested.get()) {
                val metadata = AppUpdateManager.current(this)
                val expectedTotal = metadata.totalBytes
                var existing = part.takeIf { it.exists() }?.length() ?: 0L
                if (existing > expectedTotal) {
                    part.delete()
                    existing = 0L
                }
                if (existing == expectedTotal && existing > 0L) {
                    val verified = verifyCompletedDownload(part, finalApk, metadata)
                    if (verified) return
                    hashRetryCount++
                    if (hashRetryCount >= 2) {
                        fail("Downloaded APK failed integrity verification twice. Check for updates again.")
                        return
                    }
                    part.delete()
                    continue
                }

                if (!hasUsableNetwork()) {
                    publish(
                        metadata.copy(
                            phase = AppUpdatePhase.WAITING_NETWORK,
                            message = "Waiting for an internet connection — downloaded progress is saved.",
                            bytesDownloaded = existing,
                            bytesPerSecond = 0L
                        ),
                        persist = true
                    )
                    delay(5_000)
                    continue
                }

                try {
                    val connection = openDownloadConnection(metadata.assetUrl, existing)
                    activeConnection = connection
                    val response = connection.responseCode
                    if (response == HTTP_RANGE_NOT_SATISFIABLE) {
                        connection.disconnect()
                        activeConnection = null
                        if (part.length() == expectedTotal) continue
                        part.delete()
                        continue
                    }
                    if (response !in 200..299) {
                        throw IOException("Download server returned HTTP $response")
                    }

                    var append = existing > 0L && response == HttpURLConnection.HTTP_PARTIAL
                    if (existing > 0L && response == HttpURLConnection.HTTP_OK) {
                        part.delete()
                        existing = 0L
                        append = false
                    }
                    if (response == HttpURLConnection.HTTP_PARTIAL && existing > 0L) {
                        validateContentRange(connection.getHeaderField("Content-Range"), existing)
                    }

                    var downloaded = existing
                    var sampleAt = System.currentTimeMillis()
                    var sampleBytes = downloaded
                    publish(
                        metadata.copy(
                            phase = AppUpdatePhase.DOWNLOADING,
                            message = "Downloading MarkVault update…",
                            bytesDownloaded = downloaded,
                            bytesPerSecond = 0L
                        ),
                        persist = true
                    )

                    connection.inputStream.use { input ->
                        FileOutputStream(part, append).use { output ->
                            val buffer = ByteArray(128 * 1024)
                            while (true) {
                                coroutineContext.ensureActive()
                                if (cancelRequested.get()) throw CancellationException("Canceled")
                                val count = input.read(buffer)
                                if (count < 0) break
                                if (count == 0) continue
                                output.write(buffer, 0, count)
                                downloaded += count
                                if (downloaded > expectedTotal) {
                                    throw IOException("Downloaded data exceeds advertised release size")
                                }

                                val now = System.currentTimeMillis()
                                if (now - lastUiAt >= 350L || downloaded == expectedTotal) {
                                    val elapsed = (now - sampleAt).coerceAtLeast(1L)
                                    val speed = ((downloaded - sampleBytes) * 1000L / elapsed).coerceAtLeast(0L)
                                    val progressState = metadata.copy(
                                        phase = AppUpdatePhase.DOWNLOADING,
                                        message = "Downloading MarkVault update…",
                                        bytesDownloaded = downloaded,
                                        bytesPerSecond = speed
                                    )
                                    val shouldPersist = now - lastPersistAt >= 1_000L || downloaded == expectedTotal
                                    publish(progressState, persist = shouldPersist)
                                    lastUiAt = now
                                    if (shouldPersist) lastPersistAt = now
                                    if (now - sampleAt >= 1_000L) {
                                        sampleAt = now
                                        sampleBytes = downloaded
                                    }
                                }
                            }
                            output.fd.sync()
                        }
                    }
                    connection.disconnect()
                    activeConnection = null

                    if (downloaded != expectedTotal) {
                        throw IOException("Connection ended at $downloaded of $expectedTotal bytes")
                    }
                    if (verifyCompletedDownload(part, finalApk, metadata.copy(bytesDownloaded = downloaded))) return
                    hashRetryCount++
                    if (hashRetryCount >= 2) {
                        fail("Downloaded APK failed integrity verification twice. Check for updates again.")
                        return
                    }
                    part.delete()
                } catch (cancel: CancellationException) {
                    throw cancel
                } catch (io: IOException) {
                    if (cancelRequested.get() || !coroutineContext.isActive) {
                        throw CancellationException("Transfer stopped")
                    }
                    activeConnection?.disconnect()
                    activeConnection = null
                    val saved = part.takeIf { it.exists() }?.length() ?: 0L
                    val current = AppUpdateManager.current(this)
                    publish(
                        current.copy(
                            phase = AppUpdatePhase.WAITING_NETWORK,
                            message = "Connection interrupted — ${formatBytes(saved)} saved. Retrying automatically…",
                            bytesDownloaded = saved,
                            bytesPerSecond = 0L
                        ),
                        persist = true
                    )
                    delay(5_000)
                }
            }
        } catch (_: CancellationException) {
            // Manual cancel and system timeout persist their own terminal/paused states.
        } catch (t: Throwable) {
            fail(t.message?.takeIf { it.isNotBlank() } ?: "Unexpected update download error")
        }
    }

    private fun verifyCompletedDownload(part: File, finalApk: File, metadata: AppUpdateState): Boolean {
        publish(
            metadata.copy(
                phase = AppUpdatePhase.VERIFYING,
                message = "Verifying downloaded APK…",
                bytesDownloaded = metadata.totalBytes,
                bytesPerSecond = 0L
            ),
            persist = true
        )
        if (cancelRequested.get() || worker?.isCancelled == true) return true
        val actualSha = AppUpdateManager.sha256Of(part)
        if (cancelRequested.get() || worker?.isCancelled == true) return true
        if (!actualSha.equals(metadata.expectedSha256, ignoreCase = true)) return false

        if (finalApk.exists()) finalApk.delete()
        if (!part.renameTo(finalApk)) {
            fail("Could not finalize the downloaded APK")
            return true
        }
        val packageCheck = AppUpdateInstaller.verifyDownloadedApk(this, finalApk)
        if (cancelRequested.get() || worker?.isCancelled == true) {
            finalApk.delete()
            return true
        }
        if (!packageCheck.valid) {
            finalApk.delete()
            fail(packageCheck.message)
            return true
        }
        completeReady(finalApk, metadata, packageCheck)
        return true
    }

    private fun completeReady(
        finalApk: File,
        metadata: AppUpdateState,
        packageCheck: AppUpdateInstaller.VerificationResult
    ) {
        if (!finalApk.isFile) {
            fail("Verified APK disappeared before installation")
            return
        }
        val ready = metadata.copy(
            phase = AppUpdatePhase.READY_TO_INSTALL,
            message = "MarkVault ${packageCheck.versionName} is verified and ready to install.",
            bytesDownloaded = metadata.totalBytes,
            bytesPerSecond = 0L,
            candidateVersionName = packageCheck.versionName,
            candidateVersionCode = packageCheck.versionCode
        )
        AppUpdateManager.updateFromService(this, ready, persist = true)
        val nm = getSystemService(NOTIFICATION_SERVICE) as NotificationManager
        nm.notify(NOTIFICATION_ID, buildNotification(ready))
        stopForeground(STOP_FOREGROUND_DETACH)
        stopSelf()
    }

    private fun openDownloadConnection(rawUrl: String, resumeFrom: Long): HttpURLConnection {
        val connection = (URL(rawUrl).openConnection() as HttpURLConnection).apply {
            instanceFollowRedirects = true
            connectTimeout = CONNECT_TIMEOUT_MS
            readTimeout = READ_TIMEOUT_MS
            requestMethod = "GET"
            setRequestProperty("User-Agent", "MarkVault-Android updater")
            setRequestProperty("Accept", "application/vnd.android.package-archive, application/octet-stream")
            if (resumeFrom > 0L) setRequestProperty("Range", "bytes=$resumeFrom-")
            connect()
        }
        return connection
    }

    private fun validateContentRange(header: String?, expectedStart: Long) {
        val start = header
            ?.substringAfter("bytes ", "")
            ?.substringBefore('-', "")
            ?.toLongOrNull()
        if (start != expectedStart) {
            throw IOException("Server resumed from an unexpected byte offset")
        }
    }

    private fun hasUsableNetwork(): Boolean {
        val cm = getSystemService(CONNECTIVITY_SERVICE) as ConnectivityManager
        val network = cm.activeNetwork ?: return false
        val caps = cm.getNetworkCapabilities(network) ?: return false
        return caps.hasCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET)
    }

    private fun publish(state: AppUpdateState, persist: Boolean) {
        AppUpdateManager.updateFromService(this, state, persist)
        val nm = getSystemService(NOTIFICATION_SERVICE) as NotificationManager
        nm.notify(NOTIFICATION_ID, buildNotification(state))
    }

    private fun fail(message: String) {
        val current = AppUpdateManager.current(this)
        val failed = current.copy(
            phase = AppUpdatePhase.ERROR,
            message = message,
            bytesPerSecond = 0L
        )
        AppUpdateManager.updateFromService(this, failed, persist = true)
        val nm = getSystemService(NOTIFICATION_SERVICE) as NotificationManager
        nm.notify(NOTIFICATION_ID, buildNotification(failed))
        stopForeground(STOP_FOREGROUND_DETACH)
        stopSelf()
    }

    private fun createNotificationChannel() {
        val nm = getSystemService(NOTIFICATION_SERVICE) as NotificationManager
        val channel = NotificationChannel(
            CHANNEL_ID,
            "MarkVault app updates",
            NotificationManager.IMPORTANCE_LOW
        ).apply {
            description = "Download and installation status for MarkVault updates"
            setShowBadge(false)
        }
        nm.createNotificationChannel(channel)
    }

    private fun buildNotification(state: AppUpdateState): Notification {
        val openApp = PendingIntent.getActivity(
            this,
            0,
            Intent(this, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP or Intent.FLAG_ACTIVITY_SINGLE_TOP),
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        val builder = Notification.Builder(this, CHANNEL_ID)
            .setSmallIcon(R.mipmap.ic_launcher)
            .setContentTitle(notificationTitle(state.phase))
            .setContentText(state.message.take(120))
            .setContentIntent(openApp)
            .setOnlyAlertOnce(true)
            .setOngoing(state.active)
            .setCategory(Notification.CATEGORY_PROGRESS)

        if (state.phase == AppUpdatePhase.DOWNLOADING || state.phase == AppUpdatePhase.WAITING_NETWORK) {
            if (state.totalBytes > 0L) {
                val progress = ((state.bytesDownloaded * 100L) / state.totalBytes).toInt().coerceIn(0, 100)
                builder.setProgress(100, progress, false)
                builder.setSubText("$progress% · ${formatBytes(state.bytesDownloaded)} / ${formatBytes(state.totalBytes)}")
            } else {
                builder.setProgress(0, 0, true)
            }
        } else if (state.phase == AppUpdatePhase.VERIFYING) {
            builder.setProgress(0, 0, true)
        } else if (state.phase == AppUpdatePhase.READY_TO_INSTALL) {
            builder.setProgress(100, 100, false)
            builder.setAutoCancel(true)
        }
        if (state.active) {
            val cancel = PendingIntent.getService(
                this,
                1,
                Intent(this, AppUpdateDownloadService::class.java).setAction(ACTION_CANCEL),
                PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
            )
            builder.addAction(0, "Cancel", cancel)
        }
        return builder.build()
    }

    private fun startForegroundCompat(notification: Notification) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            startForeground(NOTIFICATION_ID, notification, ServiceInfo.FOREGROUND_SERVICE_TYPE_DATA_SYNC)
        } else {
            startForeground(NOTIFICATION_ID, notification)
        }
    }

    private fun notificationTitle(phase: AppUpdatePhase): String = when (phase) {
        AppUpdatePhase.DOWNLOADING -> "Downloading MarkVault update"
        AppUpdatePhase.WAITING_NETWORK -> "MarkVault update paused"
        AppUpdatePhase.VERIFYING -> "Verifying MarkVault update"
        AppUpdatePhase.READY_TO_INSTALL -> "MarkVault update ready"
        AppUpdatePhase.ERROR -> "MarkVault update needs attention"
        AppUpdatePhase.CANCELED -> "MarkVault update canceled"
        AppUpdatePhase.PAUSED_SYSTEM -> "MarkVault update paused by Android"
        else -> "MarkVault app update"
    }

    private fun formatBytes(bytes: Long): String {
        val value = bytes.coerceAtLeast(0L).toDouble()
        return when {
            value >= 1024.0 * 1024.0 * 1024.0 -> String.format("%.2f GB", value / (1024.0 * 1024.0 * 1024.0))
            value >= 1024.0 * 1024.0 -> String.format("%.1f MB", value / (1024.0 * 1024.0))
            value >= 1024.0 -> String.format("%.1f KB", value / 1024.0)
            else -> "${bytes.coerceAtLeast(0L)} B"
        }
    }
}
