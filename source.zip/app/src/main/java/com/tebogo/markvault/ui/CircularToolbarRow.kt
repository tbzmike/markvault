package com.tebogo.markvault.ui

import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.RowScope
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.layout.onGloballyPositioned
import androidx.compose.ui.unit.dp
import kotlinx.coroutines.delay

/**
 * A genuinely circular, manually-scrollable toolbar belt.
 *
 * Two identical cycles are composed side-by-side. Automatic movement advances one pixel at a
 * time; when the first cycle has completely left the viewport, the scroll position is reset by
 * exactly one cycle width. Because cycle two is pixel-identical to cycle one, that reset is
 * visually seamless. User drag has priority: automatic movement pauses while a gesture/scroll is
 * active and resumes afterwards. Controls remain ordinary Compose click targets.
 */
@Composable
fun CircularToolbarRow(
    autoMove: Boolean,
    onAutoMoveChange: (Boolean) -> Unit,
    modifier: Modifier = Modifier,
    content: @Composable RowScope.() -> Unit
) {
    val scroll = rememberScrollState()
    var cycleWidthPx by remember { mutableIntStateOf(0) }

    LaunchedEffect(autoMove, cycleWidthPx) {
        if (!autoMove || cycleWidthPx <= 0) return@LaunchedEffect
        if (scroll.value == 0 && scroll.maxValue >= cycleWidthPx) scroll.scrollTo(cycleWidthPx)
        while (true) {
            if (!scroll.isScrollInProgress) {
                val next = scroll.value - 1
                if (next <= 0) scroll.scrollTo(cycleWidthPx.coerceAtMost(scroll.maxValue))
                else scroll.scrollTo(next)
            }
            delay(18L)
        }
    }

    Row(
        modifier = modifier.horizontalScroll(scroll),
        verticalAlignment = Alignment.CenterVertically
    ) {
        @Composable fun RowScope.Cycle(measure: Boolean) {
            Row(
                modifier = if (measure) Modifier.onGloballyPositioned { cycleWidthPx = it.size.width }
                else Modifier,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Surface(
                    shape = androidx.compose.foundation.shape.RoundedCornerShape(12.dp),
                    color = if (autoMove) MaterialTheme.colorScheme.primaryContainer else MaterialTheme.colorScheme.surfaceVariant,
                    modifier = Modifier.padding(horizontal = 3.dp)
                ) {
                    Text(
                        if (autoMove) "∞ ON" else "∞ OFF",
                        modifier = Modifier
                            .clickable { onAutoMoveChange(!autoMove) }
                            .padding(horizontal = 10.dp, vertical = 8.dp),
                        color = if (autoMove) MaterialTheme.colorScheme.onPrimaryContainer else MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
                content()
            }
        }
        Cycle(measure = true)
        // Extra identical cycles keep the belt scrollable even on wide/tablet windows where one
        // toolbar cycle is narrower than the viewport. The visible reset still happens at exactly
        // one measured cycle, so there is never a jump.
        Cycle(measure = false)
        Cycle(measure = false)
        Cycle(measure = false)
    }
}
