package com.tebogo.markvault.markdown

object FrontMatterParser {
    fun strip(source: String): String {
        return if (source.startsWith("---")) {
            val end = source.indexOf("\n---", 3)
            if (end >= 0) source.substring(end + 4) else source
        } else source
    }
}
