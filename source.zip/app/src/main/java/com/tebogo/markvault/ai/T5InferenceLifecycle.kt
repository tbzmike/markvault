package com.tebogo.markvault.ai

/** Controls T5 runtime lifecycle and safe release. */
object T5InferenceLifecycle {
    private var active = false

    fun activate() { active = true }
    fun isActive(): Boolean = active
    fun release() { active = false }
}
