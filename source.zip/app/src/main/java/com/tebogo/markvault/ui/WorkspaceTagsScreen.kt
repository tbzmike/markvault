package com.tebogo.markvault.ui

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.weight
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.navigation.NavController
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.tebogo.markvault.AppViewModel
import com.tebogo.markvault.WorkspaceTag

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun WorkspaceTagsScreen(vm: AppViewModel, nav: NavController) {
    var loading by remember { mutableStateOf(true) }
    var tags by remember { mutableStateOf<List<WorkspaceTag>>(emptyList()) }
    var query by remember { mutableStateOf("") }
    var selected by remember { mutableStateOf<WorkspaceTag?>(null) }
    val notes by vm.notes.collectAsStateWithLifecycle()

    LaunchedEffect(Unit) {
        tags = vm.workspaceTagIndex()
        loading = false
    }

    val shown = remember(tags, query) {
        val q = query.trim()
        if (q.isBlank()) tags else tags.filter { it.name.contains(q, true) }
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Tags") },
                navigationIcon = {
                    IconButton(onClick = { nav.popBackStack() }) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back")
                    }
                }
            )
        }
    ) { pad ->
        Column(Modifier.fillMaxSize().padding(pad)) {
            OutlinedTextField(
                value = query,
                onValueChange = { query = it.take(120) },
                modifier = Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 6.dp),
                singleLine = true,
                label = { Text("Filter tags") },
                placeholder = { Text("study, bible/prophecy…") }
            )
            if (loading) {
                Row(Modifier.padding(18.dp)) {
                    CircularProgressIndicator()
                    Text("  Building read-only tag index…")
                }
            } else if (selected == null) {
                LazyColumn(Modifier.fillMaxSize()) {
                    items(shown, key = { it.name }) { tag ->
                        Row(
                            Modifier.fillMaxWidth()
                                .clickable { selected = tag }
                                .padding(horizontal = 16.dp, vertical = 12.dp)
                        ) {
                            Text("#${tag.name}", Modifier.weight(1f), fontWeight = FontWeight.SemiBold)
                            Text(
                                tag.noteIds.size.toString(),
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                        HorizontalDivider()
                    }
                    item { Spacer(Modifier.height(24.dp)) }
                }
            } else {
                val tag = selected!!
                val ids = remember(tag) { tag.noteIds.toHashSet() }
                val matchingNotes = remember(notes, ids) { notes.filter { it.id in ids } }
                Text(
                    "← #${tag.name} · ${matchingNotes.size} notes",
                    modifier = Modifier.fillMaxWidth().clickable { selected = null }
                        .padding(horizontal = 16.dp, vertical = 10.dp),
                    fontWeight = FontWeight.Bold
                )
                LazyColumn(Modifier.fillMaxSize()) {
                    items(matchingNotes, key = { it.id }) { note ->
                        Column(
                            Modifier.fillMaxWidth()
                                .clickable {
                                    vm.openArticle(note.id, note.title, fileType = note.fileType)
                                    when (note.fileType.lowercase()) {
                                        "pdf" -> nav.navigate("pdfReader/${note.id}")
                                        "html", "htm", "mhtml", "mht" -> nav.navigate("htmlReader/${note.id}")
                                        "canvas" -> nav.navigate("canvas/${note.id}")
                                        else -> nav.navigate("reader") { launchSingleTop = true }
                                    }
                                }
                                .padding(horizontal = 16.dp, vertical = 10.dp)
                        ) {
                            Text(note.title, fontWeight = FontWeight.Medium, maxLines = 2, overflow = TextOverflow.Ellipsis)
                            Text(
                                note.folder.ifBlank { "Vault" },
                                style = MaterialTheme.typography.labelSmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                        HorizontalDivider()
                    }
                }
            }
        }
    }
}
