package com.tebogo.markvault.ai

/** Controls T5 resource lifecycle to avoid keeping model resources unnecessarily. */
object T5ResourceManager {
    private var loaded = false

    fun markLoaded() { loaded = true }
    fun isLoaded(): Boolean = loaded

    fun release() {
        loaded = false
    }
}
