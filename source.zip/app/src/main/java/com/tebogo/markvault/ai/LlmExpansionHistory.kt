package com.tebogo.markvault.ai

import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import java.util.concurrent.atomic.AtomicReference

/**
 * v5.4.76cc — In-memory record of what the on-device LLM did to each
 * search query the user has run in this app session.
 *
 * ## Why this exists
 *
 * The user's homepage recent-search list is now long-pressable: tapping a
 * recent query and holding shows a dialog with the paraphrases the LLM
 * produced for that query, when the expansion ran, and how long it took.
 * This class is the backing store.
 *
 * ## Storage model
 *
 * Kept intentionally simple: a lower-cased-query-keyed map inside a
 * [MutableStateFlow], capped at [MAX_ENTRIES] to bound RAM. When the cap is
 * reached, the oldest record (lowest [LlmExpansionRecord.timestampMs]) is
 * evicted first. State is *not* persisted to disk in v5.4.76cc — restart
 * of the app clears the history. Persistence can be added later without
 * breaking any current call site because the read/write API is a plain
 * [StateFlow]/`record(...)` pair.
 *
 * ## Thread safety
 *
 * Updates go through a single atomic compare-and-set on an
 * [AtomicReference]; the exposed [entries] flow re-emits after every
 * successful write. Safe to call [record] and [get] from any thread.
 */
data class LlmExpansionRecord(
    /** The original query the user typed, verbatim (post-trim). */
    val query: String,
    /**
     * The paraphrases the LLM produced. Does not include the original
     * query itself — that always contributes to search on its own.
     */
    val paraphrases: List<String>,
    /** When the expansion completed (System.currentTimeMillis). */
    val timestampMs: Long,
    /**
     * Wall-clock milliseconds the whole expansion took, including model
     * load, generation, parsing and unload. Useful for the history
     * dialog so the user can see whether a query hit the cache
     * (~0 ms) or actually ran the model (~10-15 seconds).
     */
    val durationMs: Long,
    /**
     * True when this record is a cache hit — no LLM invocation happened
     * during this observation, we just looked up an earlier record.
     * Distinguishes "fresh LLM run" from "reused prior expansion" in
     * the history dialog.
     */
    val cached: Boolean,
    /**
     * v5.4.121cc — Display name of the engine that produced this
     * expansion ("Phi-4 mini", "T5-base", etc). Defaults to "LLM" so
     * existing call sites that don't pass it keep compiling and the
     * dialog still shows something sensible.
     */
    val modelName: String = "LLM"
)

object LlmExpansionHistory {

    /** Maximum number of distinct queries kept in the ring. */
    const val MAX_ENTRIES = 200

    private val store = AtomicReference<Map<String, LlmExpansionRecord>>(emptyMap())
    private val _entries = MutableStateFlow<Map<String, LlmExpansionRecord>>(emptyMap())

    /** Observable snapshot for UI (e.g. the long-press dialog on Home). */
    val entries: StateFlow<Map<String, LlmExpansionRecord>> = _entries.asStateFlow()

    /**
     * Look up the recorded expansion for a query. Case-insensitive.
     * Returns null when the LLM has not been asked about this query yet
     * (or the entry was evicted).
     */
    fun get(query: String): LlmExpansionRecord? {
        val key = normalise(query) ?: return null
        return store.get()[key]
    }

    /**
     * Insert or replace an expansion record. Thread-safe.
     *
     * When the cap is reached, evicts the oldest entry by
     * [LlmExpansionRecord.timestampMs] before inserting the new one.
     */
    fun record(rec: LlmExpansionRecord) {
        val key = normalise(rec.query) ?: return
        while (true) {
            val cur = store.get()
            val next = HashMap<String, LlmExpansionRecord>(cur)
            next[key] = rec
            if (next.size > MAX_ENTRIES) {
                // Evict the single oldest record by timestamp.
                val victimKey = next.entries.minByOrNull { it.value.timestampMs }?.key
                if (victimKey != null && victimKey != key) next.remove(victimKey)
            }
            if (store.compareAndSet(cur, next)) {
                _entries.value = next
                return
            }
            // Lost the race — retry with the new baseline.
        }
    }

    /** Clear every recorded expansion. Wired to a debug / privacy action. */
    fun clear() {
        store.set(emptyMap())
        _entries.value = emptyMap()
    }

    private fun normalise(q: String): String? {
        val t = q.trim().lowercase()
        return if (t.isEmpty()) null else t
    }
}
