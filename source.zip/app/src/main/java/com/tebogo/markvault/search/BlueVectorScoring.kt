package com.tebogo.markvault.search

import android.database.Cursor
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.currentCoroutineContext
import kotlinx.coroutines.ensureActive
import kotlinx.coroutines.withContext

/** Room owns the cursor and WAL connection; native code only receives vector bytes. */
object BlueVectorScoring {
    private const val BATCH_SIZE = 128

    suspend fun score(
        query: FloatArray,
        openCursor: () -> Cursor,
        previous: Map<Long, Float>,
        scalarScore: (ByteArray) -> Float
    ): Map<Long, Float> = withContext(Dispatchers.IO) {
        // Publish only a complete 900-note page. Insertion order also preserves
        // the original HashMap's tie ordering when the caller merges new IDs.
        val best = LinkedHashMap(previous)
        val noteIds = LongArray(BATCH_SIZE)
        val vectors = ArrayList<ByteArray>(BATCH_SIZE)
        suspend fun flush() {
            if (vectors.isEmpty()) return
            currentCoroutineContext().ensureActive()
            val scores = ExactVectorScorer.score(query, vectors.toTypedArray())
            for (i in vectors.indices) {
                val score = scores?.get(i) ?: scalarScore(vectors[i])
                val old = best[noteIds[i]]
                if (old == null || score > old) best[noteIds[i]] = score
            }
            vectors.clear()
        }
        openCursor().use { cursor ->
            val idColumn = cursor.getColumnIndexOrThrow("noteId")
            val vectorColumn = cursor.getColumnIndexOrThrow("vector")
            while (cursor.moveToNext()) {
                currentCoroutineContext().ensureActive()
                val vector = cursor.getBlob(vectorColumn)
                if (vector.size != query.size * 4) continue
                noteIds[vectors.size] = cursor.getLong(idColumn)
                vectors.add(vector)
                if (vectors.size == BATCH_SIZE) flush()
            }
            flush()
        }
        best
    }
}
