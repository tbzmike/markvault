package com.tebogo.markvault.ai

/** Final guard before enabling T5 execution. */
object T5FinalModelGuard {
    fun enabled(): Boolean {
        return T5ExpansionAvailability.isAvailable()
    }

    fun fallback(): T5ExpansionMode {
        return T5ExpansionMode.BUILTIN
    }
}
