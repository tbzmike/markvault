package com.tebogo.markvault.ai

/**
 * Global AI feature visibility/settings.
 */
object AiFeatureSettings {

    private var aiSearchEnabled = true
    private var globalChatEnabled = true

    fun setAiSearchEnabled(enabled: Boolean) {
        aiSearchEnabled = enabled
    }

    fun isAiSearchEnabled(): Boolean = aiSearchEnabled

    fun setGlobalChatEnabled(enabled: Boolean) {
        globalChatEnabled = enabled
    }

    fun isGlobalChatEnabled(): Boolean = globalChatEnabled
}
