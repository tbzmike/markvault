package com.tebogo.markvault.ui

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.weight
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material3.Card
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.setValue
import androidx.compose.runtime.remember
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.navigation.NavController
import com.tebogo.markvault.AppViewModel
import kotlinx.coroutines.launch

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun WorkspaceBookmarksScreen(vm: AppViewModel, nav: NavController) {
    val bookmarks by vm.workspaceBookmarks.collectAsStateWithLifecycle()
    val scope = rememberCoroutineScope()

    fun openBookmark(type: String, target: String) {
        when (type) {
            "search" -> {
                vm.query.value = target
                vm.mode.value = com.tebogo.markvault.SearchMode.CONTENT
                nav.navigate("search") { launchSingleTop = true }
            }
            "graph" -> {
                target.toLongOrNull()?.let { nav.navigate("graph/$it") { launchSingleTop = true } }
            }
            "url" -> vm.requestWebPopup(target)
            else -> {
                val id = target.toLongOrNull() ?: return
                scope.launch {
                    val note = vm.noteById(id) ?: return@launch
                    vm.openArticle(note.id, note.title.ifBlank { note.name }, fileType = note.fileType)
                    val route = when (note.fileType.lowercase()) {
                        "pdf" -> "pdfReader/${note.id}"
                        "html", "htm", "mhtml", "mht" -> "htmlReader/${note.id}"
                        "canvas" -> "canvas/${note.id}"
                        else -> "reader"
                    }
                    nav.navigate(route) { launchSingleTop = true }
                }
            }
        }
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Workspace bookmarks") },
                navigationIcon = {
                    IconButton(onClick = { nav.popBackStack() }) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back")
                    }
                }
            )
        }
    ) { pad ->
        LazyColumn(Modifier.fillMaxSize().padding(pad).padding(horizontal = 10.dp)) {
            if (bookmarks.isEmpty()) {
                item {
                    Text(
                        "No workspace bookmarks yet. Bookmark notes, searches or graph views from the workspace and Command Palette.",
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        modifier = Modifier.padding(18.dp)
                    )
                }
            }
            items(bookmarks, key = { it.id }) { b ->
                Card(Modifier.fillMaxWidth().padding(vertical = 4.dp)) {
                    Column(Modifier.padding(12.dp)) {
                        Text(
                            b.title,
                            fontWeight = FontWeight.SemiBold,
                            maxLines = 2,
                            overflow = TextOverflow.Ellipsis
                        )
                        Text(
                            buildString {
                                append(b.type.uppercase())
                                if (b.group.isNotBlank()) append(" · ${b.group}")
                                if (b.detail.isNotBlank()) append(" · ${b.detail}")
                            },
                            style = MaterialTheme.typography.labelSmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                            maxLines = 2,
                            overflow = TextOverflow.Ellipsis
                        )
                        Spacer(Modifier.height(4.dp))
                        var groupDraft by remember(b.id, b.group) { mutableStateOf(b.group) }
                        Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                            OutlinedTextField(
                                value = groupDraft,
                                onValueChange = { groupDraft = it.take(80) },
                                modifier = Modifier.weight(1f),
                                singleLine = true,
                                label = { Text("Group") },
                                placeholder = { Text("Study, Research…") }
                            )
                            TextButton(
                                onClick = { vm.setWorkspaceBookmarkGroup(b.id, groupDraft) }
                            ) { Text("Save") }
                        }
                        Row(horizontalArrangement = Arrangement.spacedBy(2.dp)) {
                            TextButton(onClick = { openBookmark(b.type, b.target) }) { Text("Open") }
                            TextButton(onClick = { vm.moveWorkspaceBookmark(b.id, -1) }) { Text("↑") }
                            TextButton(onClick = { vm.moveWorkspaceBookmark(b.id, 1) }) { Text("↓") }
                            TextButton(onClick = { vm.removeWorkspaceBookmark(b.id) }) { Text("Remove") }
                        }
                    }
                }
            }
            item { Spacer(Modifier.height(24.dp)) }
        }
    }
}
