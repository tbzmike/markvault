package com.tebogo.markvault.ai

/** Handles T5 installation failures without breaking search. */
object T5DownloadErrorHandler {
    fun fallbackToBuiltIn(): Boolean {
        T5SelectionController.select(false)
        return true
    }
}
