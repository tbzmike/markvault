package com.tebogo.markvault.ui

import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material3.Card
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.navigation.NavController

private data class ReadOnlyExtensionEntry(
    val name: String,
    val description: String,
    val route: String
)

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ReadOnlyExtensionsScreen(nav: NavController) {
    val entries = listOf(
        ReadOnlyExtensionEntry("Tags", "Nested read-only tag explorer", "workspaceTags"),
        ReadOnlyExtensionEntry("Data Views", "Filter and sort indexed note metadata", "workspaceData"),
        ReadOnlyExtensionEntry("Properties", "Structured read-only note properties in Workspace panes", "workspacePanes"),
        ReadOnlyExtensionEntry("Graph", "Filtered local graph", "graph"),
        ReadOnlyExtensionEntry("Canvas", "Open indexed Obsidian .canvas files read-only", "browse")
    )
    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Read-only extensions") },
                navigationIcon = {
                    IconButton(onClick = { nav.popBackStack() }) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back")
                    }
                }
            )
        }
    ) { pad ->
        LazyColumn(Modifier.fillMaxSize().padding(pad).padding(horizontal = 10.dp)) {
            item {
                Text(
                    "Built-in view modules only. These tools do not edit vault files.",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    modifier = Modifier.padding(vertical = 10.dp)
                )
            }
            items(entries, key = { it.name }) { entry ->
                Card(Modifier.fillMaxWidth().padding(vertical = 4.dp)) {
                    Column(Modifier.padding(12.dp)) {
                        Text(entry.name, fontWeight = FontWeight.SemiBold)
                        Text(
                            entry.description,
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                        TextButton(onClick = { nav.navigate(entry.route) { launchSingleTop = true } }) {
                            Text("Open")
                        }
                    }
                }
            }
        }
    }
}
