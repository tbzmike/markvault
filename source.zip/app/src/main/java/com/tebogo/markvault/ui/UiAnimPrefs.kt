package com.tebogo.markvault.ui

import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.Immutable
import androidx.compose.runtime.ProvidableCompositionLocal
import androidx.compose.runtime.ReadOnlyComposable
import androidx.compose.runtime.remember
import androidx.compose.runtime.staticCompositionLocalOf

/**
 * v5.4.162cc — UI Animations preferences (master on/off + speed).
 *
 * Deliberately a SEPARATE CompositionLocal system from [AppMotion] /
 * [MotionSpecs] in AppMotion.kt. That system is the pre-existing
 * "Expressive motion" opt-in plugin for dialogs/menus/screen-changes,
 * OFF by default. This one governs the different set of animations
 * added in v5.4.157cc through v5.4.161cc — search-result stagger, FAB
 * press/entrance bounce, tab-switch slide, foldable-callout content
 * slide, chat typewriter cues, duplicate-scan shimmer, search-label
 * parallax, popup swipe-to-dismiss, and the theme-switch color fade.
 * Those are meant to just work like normal app polish, so this
 * defaults to enabled=true, unlike Expressive motion's default-off.
 *
 * Every one of those animation call sites reads [UiAnim.prefs] to
 * decide whether to animate at all, and to scale its own duration via
 * [UiAnimPrefs.scaledDurationMs] / [UiAnimPrefs.scaledSpec]. Before
 * v5.4.162cc none of them were reading anything — durations were
 * hardcoded — so a Settings toggle had no effect on them. This file is
 * what makes that toggle (and the speed slider) actually do something.
 */
@Immutable
data class UiAnimPrefs(
    val enabled: Boolean,
    /** Playback-speed multiplier: 2.0 = twice as fast (half duration), 0.5 = half as fast (double duration). */
    val speed: Float
) {
    /**
     * Scales a base duration in milliseconds by [speed]. Returns 0
     * (instant) when [enabled] is false, regardless of [speed] — the
     * master toggle always wins. Never returns less than 1ms so
     * AnimationSpec construction never receives a nonsensical value.
     */
    fun scaledDurationMs(baseMs: Int): Int {
        if (!enabled) return 0
        if (baseMs <= 0) return 0
        return (baseMs / speed.coerceIn(0.25f, 4f)).toInt().coerceAtLeast(1)
    }
}

/**
 * Default (enabled=true, speed=1.0) so any subtree that isn't wrapped
 * in [ProvideUiAnimPrefs] — previews, tests — still animates normally
 * at the originally-shipped timing, rather than silently going inert.
 */
val LocalUiAnimPrefs: ProvidableCompositionLocal<UiAnimPrefs> =
    staticCompositionLocalOf { UiAnimPrefs(enabled = true, speed = 1.0f) }

object UiAnim {
    val prefs: UiAnimPrefs
        @Composable
        @ReadOnlyComposable
        get() = LocalUiAnimPrefs.current
}

/** Installs [LocalUiAnimPrefs] for the given subtree. Call once, high in the tree (MainActivity). */
@Composable
fun ProvideUiAnimPrefs(
    enabled: Boolean,
    speed: Float,
    content: @Composable () -> Unit
) {
    val resolved = remember(enabled, speed) {
        UiAnimPrefs(enabled = enabled, speed = speed.coerceIn(0.5f, 2.0f))
    }
    CompositionLocalProvider(LocalUiAnimPrefs provides resolved, content = content)
}
