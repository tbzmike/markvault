package com.tebogo.markvault.ui

import androidx.compose.animation.core.Spring
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.Immutable
import androidx.compose.runtime.ProvidableCompositionLocal
import androidx.compose.runtime.ReadOnlyComposable
import androidx.compose.runtime.remember
import androidx.compose.runtime.staticCompositionLocalOf

/** Which axis a [UiAnimStyle] rotates on during entrance, if any. */
enum class RotationAxis { NONE, X, Y, Z }

/**
 * v5.4.164cc — Distinct, energetic animation styles for FAB entrance and
 * press feedback, each with a genuinely different visual character
 * rather than just a tweaked number:
 *
 *   BOUNCE — pure scale, very bouncy spring, no rotation. Classic
 *            dramatic pop with real overshoot (settles past 1.0 and
 *            back before resting).
 *   ZOOM   — pure scale, fast/snappy spring (higher stiffness, less
 *            bounce). Reads as punchy rather than floaty.
 *   WIGGLE — scale plus a Z-axis rotation that oscillates as it
 *            settles (the bouncy spring's natural overshoot/undershoot
 *            translates into a genuine side-to-side wiggle, not just a
 *            one-way turn).
 *   SPIN   — scale plus a big one-way Z-axis rotation (starts turned,
 *            spins upright as it settles). Reads as a full "pop and
 *            spin," not a rotation added on top of an otherwise
 *            unrelated bounce.
 *   FLIP   — scale plus a Y-axis (3D) rotation — a genuine card-flip
 *            character, visually distinct from the Z-axis styles
 *            since it rotates in depth rather than in-plane.
 *
 * RANDOM_MIX picks one of the five above independently for each FAB
 * instance (see [FabPressAnimation.kt]'s fabPressScale, which resolves
 * this once per mount) — this is what makes "mix them randomly" actually
 * mean something: the same button can look different from one time you
 * see it to the next, and two FABs visible at once can genuinely differ.
 *
 * dampingRatio/stiffnessMultiplier/pressScaleTarget are the only tuning
 * knobs — see fabPressScale for how they're applied. Rotation-axis
 * styles reuse the SAME entrance spring's natural overshoot for their
 * rotation amount, so there's no separate "how much to overshoot"
 * parameter to keep in sync — one spring, one set of numbers, applied
 * to whichever properties this style turns on.
 */
enum class UiAnimStyle(
    val label: String,
    val emoji: String,
    val rotationAxis: RotationAxis,
    val rotationDegrees: Float,
    val dampingRatio: Float,
    val stiffnessMultiplier: Float,
    val pressScaleTarget: Float
) {
    BOUNCE(
        label = "Bounce", emoji = "\uD83C\uDFC0",
        rotationAxis = RotationAxis.NONE, rotationDegrees = 0f,
        dampingRatio = Spring.DampingRatioHighBouncy, stiffnessMultiplier = 1.0f,
        pressScaleTarget = 0.80f
    ),
    ZOOM(
        label = "Zoom", emoji = "\uD83D\uDD0D",
        rotationAxis = RotationAxis.NONE, rotationDegrees = 0f,
        dampingRatio = Spring.DampingRatioNoBouncy, stiffnessMultiplier = 2.2f,
        pressScaleTarget = 0.70f
    ),
    WIGGLE(
        label = "Wiggle", emoji = "\uD83C\uDF89",
        rotationAxis = RotationAxis.Z, rotationDegrees = 16f,
        dampingRatio = Spring.DampingRatioHighBouncy, stiffnessMultiplier = 1.3f,
        pressScaleTarget = 0.85f
    ),
    SPIN(
        label = "Spin", emoji = "\uD83C\uDF00",
        rotationAxis = RotationAxis.Z, rotationDegrees = 360f,
        dampingRatio = Spring.DampingRatioMediumBouncy, stiffnessMultiplier = 0.85f,
        pressScaleTarget = 0.82f
    ),
    FLIP(
        label = "Flip", emoji = "\uD83C\uDCCF",
        rotationAxis = RotationAxis.Y, rotationDegrees = 180f,
        dampingRatio = Spring.DampingRatioLowBouncy, stiffnessMultiplier = 0.9f,
        pressScaleTarget = 0.85f
    ),
    RANDOM_MIX(
        label = "Random Mix", emoji = "\uD83C\uDFB2",
        rotationAxis = RotationAxis.NONE, rotationDegrees = 0f,
        dampingRatio = Spring.DampingRatioMediumBouncy, stiffnessMultiplier = 1.0f,
        pressScaleTarget = 0.80f
    );

    companion object {
        /** All concrete (non-meta) styles — what RANDOM_MIX picks from. */
        val concreteStyles: List<UiAnimStyle> = UiAnimStyle.entries.filter { it != RANDOM_MIX }

        fun fromName(name: String): UiAnimStyle =
            UiAnimStyle.entries.firstOrNull { it.name == name } ?: BOUNCE
    }
}

/**
 * v5.4.162cc — UI Animations preferences (master on/off + speed).
 *
 * Deliberately a SEPARATE CompositionLocal system from [AppMotion] /
 * [MotionSpecs] in AppMotion.kt. That system is the pre-existing
 * "Expressive motion" opt-in plugin for dialogs/menus/screen-changes,
 * OFF by default. This one governs the different set of animations
 * added in v5.4.157cc through v5.4.161cc — search-result stagger, FAB
 * press/entrance bounce, tab-switch slide, foldable-callout content
 * slide, chat typewriter cues, duplicate-scan shimmer, search-label
 * parallax, popup swipe-to-dismiss, and the theme-switch color fade.
 * Those are meant to just work like normal app polish, so this
 * defaults to enabled=true, unlike Expressive motion's default-off.
 *
 * Every one of those animation call sites reads [UiAnim.prefs] to
 * decide whether to animate at all, and to scale its own duration via
 * [UiAnimPrefs.scaledDurationMs] / [UiAnimPrefs.scaledSpec]. Before
 * v5.4.162cc none of them were reading anything — durations were
 * hardcoded — so a Settings toggle had no effect on them. This file is
 * what makes that toggle (and the speed slider) actually do something.
 *
 * v5.4.164cc — Added [style], consumed by FabPressAnimation.kt's
 * fabPressScale for genuinely distinct entrance/press character.
 */
@Immutable
data class UiAnimPrefs(
    val enabled: Boolean,
    /** Playback-speed multiplier: 2.0 = twice as fast (half duration), 0.5 = half as fast (double duration). */
    val speed: Float,
    val style: UiAnimStyle
) {
    /**
     * Scales a base duration in milliseconds by [speed]. Returns 0
     * (instant) when [enabled] is false, regardless of [speed] — the
     * master toggle always wins. Never returns less than 1ms so
     * AnimationSpec construction never receives a nonsensical value.
     */
    fun scaledDurationMs(baseMs: Int): Int {
        if (!enabled) return 0
        if (baseMs <= 0) return 0
        return (baseMs / speed.coerceIn(0.25f, 4f)).toInt().coerceAtLeast(1)
    }
}

/**
 * Default (enabled=true, speed=1.0, style=BOUNCE) so any subtree that
 * isn't wrapped in [ProvideUiAnimPrefs] — previews, tests — still
 * animates normally at the originally-shipped timing, rather than
 * silently going inert.
 */
val LocalUiAnimPrefs: ProvidableCompositionLocal<UiAnimPrefs> =
    staticCompositionLocalOf { UiAnimPrefs(enabled = true, speed = 1.0f, style = UiAnimStyle.BOUNCE) }

object UiAnim {
    val prefs: UiAnimPrefs
        @Composable
        @ReadOnlyComposable
        get() = LocalUiAnimPrefs.current
}

/** Installs [LocalUiAnimPrefs] for the given subtree. Call once, high in the tree (MainActivity). */
@Composable
fun ProvideUiAnimPrefs(
    enabled: Boolean,
    speed: Float,
    styleName: String,
    content: @Composable () -> Unit
) {
    val resolved = remember(enabled, speed, styleName) {
        UiAnimPrefs(
            enabled = enabled,
            speed = speed.coerceIn(0.5f, 2.0f),
            style = UiAnimStyle.fromName(styleName)
        )
    }
    CompositionLocalProvider(LocalUiAnimPrefs provides resolved, content = content)
}

