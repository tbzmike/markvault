package com.tebogo.markvault.ui

import android.annotation.SuppressLint
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.provider.OpenableColumns
import android.webkit.WebResourceRequest
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.clickable
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.KeyboardArrowDown
import androidx.compose.material.icons.filled.KeyboardArrowUp
import androidx.compose.material.icons.filled.MoreVert
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TextField
import androidx.compose.material3.TextFieldDefaults
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.produceState
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.toArgb
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import com.tebogo.markvault.AppViewModel
import com.tebogo.markvault.MarkVaultTheme
import com.tebogo.markvault.OutlineItem
import com.tebogo.markvault.data.Prefs
import com.tebogo.markvault.data.ObsidianThemeManager
import com.tebogo.markvault.data.ObsidianThemePayload
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import org.json.JSONObject

class ExternalReaderActivity : ComponentActivity() {
    @Suppress("DEPRECATION")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val uri: Uri? = when (intent?.action) {
            Intent.ACTION_SEND -> intent.getParcelableExtra(Intent.EXTRA_STREAM) as? Uri
            else -> intent?.data
        }
        val appPrefs = Prefs(applicationContext)
        setContent {
            val appTheme by appPrefs.theme.collectAsState(initial = "dark")
            val appAppearanceMode by appPrefs.appAppearanceMode.collectAsState(initial = "system")
            val appCustomTheme by appPrefs.customThemeJson.collectAsState(initial = "")
            val appFontScale by appPrefs.fontScale.collectAsState(initial = 1.0f)
            val appObsidianThemeId by appPrefs.obsidianThemeId.collectAsState(initial = "")
            val appObsidianProfiles by appPrefs.obsidianThemeOverridesRaw.collectAsState(initial = "{}")
            val appObsidianAppearance = externalObsidianAppearance(appObsidianProfiles, appObsidianThemeId)
            val appObsidianTheme by produceState<ObsidianThemePayload?>(
                initialValue = null,
                key1 = appObsidianThemeId,
                key2 = appObsidianProfiles
            ) {
                value = withContext(Dispatchers.IO) {
                    val manager = ObsidianThemeManager(applicationContext)
                    manager.applyOverrides(manager.load(appObsidianThemeId), externalObsidianOverrides(appObsidianProfiles, appObsidianThemeId))
                }
            }
            MarkVaultTheme(
                themeName = appTheme,
                customThemeJson = appCustomTheme,
                obsidianThemePayload = appObsidianTheme,
                obsidianAppearanceMode = appObsidianAppearance,
                appAppearanceMode = appAppearanceMode,
                fontScale = appFontScale
            ) {
                Surface(Modifier.fillMaxSize(), color = MaterialTheme.colorScheme.background) {
                    ExternalReader(uri, appObsidianTheme, appObsidianAppearance) { finish() }
                }
            }
        }
    }
}

private fun externalObsidianOverrides(raw: String, themeId: String): Map<String, String> {
    if (themeId.isBlank()) return emptyMap()
    val obj = runCatching { org.json.JSONObject(raw).optJSONObject(themeId) }.getOrNull() ?: return emptyMap()
    val out = linkedMapOf<String, String>()
    val keys = obj.keys()
    while (keys.hasNext()) {
        val key = keys.next()
        val value = obj.optString(key)
        if (key.startsWith("--") && value.isNotBlank()) out[key] = value
    }
    return out
}

private fun externalObsidianAppearance(raw: String, themeId: String): String {
    if (themeId.isBlank()) return "system"
    val mode = runCatching { org.json.JSONObject(raw).optJSONObject(themeId)?.optString("__appearance") }.getOrNull()?.lowercase()
    return if (mode == "light" || mode == "dark") mode else "system"
}

private data class Loaded(val title: String, val content: String, val isHtml: Boolean = false)

@OptIn(ExperimentalMaterial3Api::class)
@SuppressLint("SetJavaScriptEnabled")
@Composable
private fun ExternalReader(uri: Uri?, obsidianThemePayload: ObsidianThemePayload?, obsidianAppearanceMode: String, onClose: () -> Unit) {
    val ctx = LocalContext.current
    val clipboard = LocalClipboardManager.current
    val scope = rememberCoroutineScope()
    val prefs = remember { Prefs(ctx.applicationContext) }
    val fontScale by prefs.fontScale.collectAsState(initial = 1.0f)
    val theme by prefs.theme.collectAsState(initial = "dark")
    val customThemeJson by prefs.customThemeJson.collectAsState(initial = "")
    val obsidianDark = LocalMarkVaultDarkMode.current
    val activeColorScheme = LocalMarkVaultTargetColorScheme.current ?: MaterialTheme.colorScheme
    val effectiveArticleThemeJson = remember(theme, customThemeJson, activeColorScheme) {
        articleThemeJson(activeColorScheme, customThemeJson.takeIf { theme == "custom" })
    }
    val effectiveObsidianCss = remember(theme, obsidianThemePayload, obsidianDark) {
        if (theme == "obsidian_imported") obsidianThemePayload?.let { obsidianArticleCompatibilityCss(obsidianDark) + "\n" + it.css }.orEmpty() else ""
    }

    var loaded by remember { mutableStateOf<Loaded?>(null) }
    var error by remember { mutableStateOf<String?>(null) }

    LaunchedEffect(uri) {
        if (uri == null) { error = "No file was provided."; return@LaunchedEffect }
        val result = withContext(Dispatchers.IO) {
            try {
                val text = ctx.contentResolver.openInputStream(uri)?.use { input ->
                    input.bufferedReader().readText()
                } ?: return@withContext null
                val name = displayName(ctx, uri)
                // v5.4.12 — Detect HTML by MIME type OR file extension OR
                // a quick content sniff. HTML files render directly via
                // WebView.loadDataWithBaseURL; markdown follows the
                // existing flexmark → renderMarkdown JS pipeline.
                val mimeFromResolver = runCatching {
                    ctx.contentResolver.getType(uri)
                }.getOrNull()?.lowercase()
                val nameLower = name.lowercase()
                val isHtml = (mimeFromResolver == "text/html" ||
                    mimeFromResolver == "application/xhtml+xml" ||
                    nameLower.endsWith(".html") ||
                    nameLower.endsWith(".htm") ||
                    nameLower.endsWith(".xhtml") ||
                    text.trimStart().take(15).lowercase().let {
                        it.startsWith("<!doctype html") || it.startsWith("<html")
                    })
                if (isHtml) {
                    // Try to read <title>…</title> for a nice header title.
                    val titleMatch = Regex(
                        "<title[^>]*>([^<]*)</title>",
                        RegexOption.IGNORE_CASE
                    ).find(text)
                    val htmlTitle = titleMatch?.groupValues?.getOrNull(1)?.trim()
                        ?.takeIf { it.isNotBlank() }
                        ?: name.substringBeforeLast('.', name)
                    Loaded(htmlTitle.ifBlank { "HTML" }, text, isHtml = true)
                } else {
                    val title = firstHeading(text)
                        ?: name.removeSuffix(".md").removeSuffix(".markdown")
                    Loaded(title.ifBlank { "Markdown" }, text, isHtml = false)
                }
            } catch (e: Exception) {
                null
            }
        }
        if (result == null) error = "Could not open this file." else loaded = result
    }

    var webView by remember { mutableStateOf<WebView?>(null) }
    var pageReady by remember { mutableStateOf(false) }
    var showFind by remember { mutableStateOf(false) }
    var findQuery by remember { mutableStateOf("") }
    var matchCount by remember { mutableStateOf(0) }
    var activeMatch by remember { mutableStateOf(0) }
    val findFocus = remember { FocusRequester() }
    var menuOpen by remember { mutableStateOf(false) }
    var themeMenuOpen by remember { mutableStateOf(false) }
    var showOutline by remember { mutableStateOf(false) }

    val bg = MaterialTheme.colorScheme.background.toArgb()
    val outline = remember(loaded) {
        loaded?.takeIf { !it.isHtml }
            ?.let { AppViewModel.parseOutline(it.content) }
            ?: emptyList()
    }
    fun js(s: String) = JSONObject.quote(s)

    LaunchedEffect(pageReady, loaded, theme, customThemeJson, obsidianThemePayload, obsidianDark) {
        val wv = webView ?: return@LaunchedEffect
        val doc = loaded ?: return@LaunchedEffect
        if (!pageReady) return@LaunchedEffect
        if (doc.isHtml) {
            // v5.4.12 — Inject the HTML file's content directly via
            // loadDataWithBaseURL. We use a relative baseURL so any
            // relative image / CSS links in the file fail gracefully
            // rather than trying to load from the wrong origin.
            val themeCss = articleThemeHtmlCss(
                activeColorScheme,
                customThemeJson.takeIf { theme == "custom" },
                theme,
                obsidianCss = obsidianThemePayload?.css.takeIf { theme == "obsidian_imported" },
                obsidianDark = obsidianDark,
                darkMode = obsidianDark
            )
            val html = if (doc.content.contains("<head", ignoreCase = true)) {
                val match = Regex("(?i)<head[^>]*>").find(doc.content)
                if (match != null) {
                    val end = match.range.last + 1
                    doc.content.substring(0, end) + themeCss + doc.content.substring(end)
                } else doc.content
            } else {
                "<head>$themeCss</head>" + doc.content
            }
            wv.loadDataWithBaseURL(
                "about:blank",
                html,
                "text/html",
                "UTF-8",
                null
            )
        } else {
            // v4.18.0 — pre-render via flexmark.
            val html = com.tebogo.markvault.markdown.MarkdownEngine.render(doc.content)
            wv.evaluateJavascript(
                "setThemeVariables(${js(effectiveArticleThemeJson)}); renderMarkdown(${js(html)}, $fontScale, ${js(theme)}); setThemeVariables(${js(effectiveArticleThemeJson)}); setObsidianThemeCss(${js(effectiveObsidianCss)}, ${if (obsidianDark) "true" else "false"});",
                null
            )
        }
    }
    LaunchedEffect(fontScale, pageReady) {
        if (pageReady) webView?.evaluateJavascript("setFontScale($fontScale);", null)
    }
    LaunchedEffect(theme, customThemeJson, obsidianThemePayload, obsidianDark, pageReady) {
        if (pageReady && loaded?.isHtml != true) {
            webView?.evaluateJavascript(
                "setTheme(${js(theme)}); setThemeVariables(${js(effectiveArticleThemeJson)}); setObsidianThemeCss(${js(effectiveObsidianCss)}, ${if (obsidianDark) "true" else "false"});",
                null
            )
        }
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text(loaded?.title ?: "MarkVault", maxLines = 1, overflow = TextOverflow.Ellipsis) },
                navigationIcon = {
                    IconButton(onClick = onClose) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Close")
                    }
                },
                actions = {
                    if (loaded != null) {
                        TextButton(onClick = { scope.launch { prefs.setFontScale((fontScale - 0.1f).coerceIn(0.7f, 2.2f)) } }) { Text("A\u2212") }
                        TextButton(onClick = { scope.launch { prefs.setFontScale((fontScale + 0.1f).coerceIn(0.7f, 2.2f)) } }) { Text("A+") }
                        IconButton(onClick = { showFind = !showFind; if (!showFind) webView?.clearMatches() }) {
                            Icon(Icons.Default.Search, contentDescription = "Find")
                        }
                        Box {
                            IconButton(onClick = { menuOpen = true }) {
                                Icon(Icons.Default.MoreVert, contentDescription = "More")
                            }
                            DropdownMenu(expanded = menuOpen, onDismissRequest = { menuOpen = false }) {
                                DropdownMenuItem(
                                    text = { Text("\uD83E\uDDED Outline") },
                                    onClick = { menuOpen = false; showOutline = true }
                                )
                                DropdownMenuItem(
                                    text = { Text("\uD83C\uDFA8 Theme\u2026") },
                                    onClick = { menuOpen = false; themeMenuOpen = true }
                                )
                                DropdownMenuItem(
                                    text = { Text("\u2B06\uFE0F Collapse all boxes") },
                                    onClick = { menuOpen = false; webView?.evaluateJavascript("collapseAllCallouts();", null) }
                                )
                                DropdownMenuItem(
                                    text = { Text("\u2B07\uFE0F Expand all boxes") },
                                    onClick = { menuOpen = false; webView?.evaluateJavascript("expandAllCallouts();", null) }
                                )
                                HorizontalDivider()
                                DropdownMenuItem(
                                    text = { Text("\uD83D\uDCCB Copy text") },
                                    onClick = {
                                        menuOpen = false
                                        loaded?.content?.let {
                                            clipboard.setText(AnnotatedString(it))
                                            Toast.makeText(ctx, "Copied", Toast.LENGTH_SHORT).show()
                                        }
                                    }
                                )
                                DropdownMenuItem(
                                    text = { Text("\uD83D\uDD17 Share") },
                                    onClick = {
                                        menuOpen = false
                                        loaded?.let {
                                            val send = Intent(Intent.ACTION_SEND).apply {
                                                type = "text/plain"
                                                putExtra(Intent.EXTRA_SUBJECT, it.title)
                                                putExtra(Intent.EXTRA_TEXT, it.content)
                                            }
                                            ctx.startActivity(Intent.createChooser(send, "Share note"))
                                        }
                                    }
                                )
                            }
                            DropdownMenu(expanded = themeMenuOpen, onDismissRequest = { themeMenuOpen = false }) {
                                listOf(
                                    "dark" to "\uD83C\uDF11 Dark",
                                    "black" to "\u26AB AMOLED black",
                                    "hicontrast-dark" to "\u26A1 High-contrast dark",
                                        "obsidian" to "\uD83E\uDEA8 Obsidian",
                                    "glass_obsidian" to "🧊 3D Obsidian Glass",
                                    "glass_crystal" to "💎 3D Crystal Glass",
                                "artifact_parchment" to "📜 Illuminated Parchment",
                                "artifact_vellum" to "✒️ Vellum Manuscript",
                                "artifact_stone" to "🪨 Limestone Tablet",
                                "artifact_papyrus" to "🌾 Papyrus Archive",
                                "artifact_marble" to "🏛️ Marble Codex",
                                    "ocean" to "\uD83C\uDF0A Ocean",
                                    "forest" to "\uD83C\uDF32 Forest",
                                    "sepia" to "\uD83D\uDCDC Sepia",
                                    "dark_sepia" to "\uD83D\uDCDC Dark sepia",
                                    "cream" to "\u2615 Cream",
                                    "light_grey" to "\uD83E\uDEA8 Light grey",
                                    "grey" to "\u2B1C Grey",
                                    "sky_blue" to "\uD83C\uDF24 Sky blue",
                                    "light" to "\u2600\uFE0F Light",
                                    "hicontrast-light" to "\u26A1 High-contrast light",
                                    "expr_indigo" to "\uD83D\uDD8B\uFE0F Expressive indigo",
                                    "expr_violet" to "\uD83D\uDD2E Expressive violet",
                                    "expr_ember" to "\uD83D\uDD25 Expressive ember",
                                    "expr_rose" to "\uD83C\uDF39 Expressive rose",
                                    "custom" to "\uD83C\uDFA8 Custom"
                                ).forEach { pair ->
                                    DropdownMenuItem(
                                        text = { Text(pair.second + if (theme == pair.first) "  \u2713" else "") },
                                        onClick = { themeMenuOpen = false; scope.launch { prefs.setTheme(pair.first) } }
                                    )
                                }
                            }
                        }
                    }
                }
            )
        }
    ) { pad ->
        Column(Modifier.padding(pad).fillMaxSize()) {
            if (showFind) {
                Surface(color = MaterialTheme.colorScheme.surfaceVariant) {
                    Row(
                        Modifier.fillMaxWidth().padding(horizontal = 8.dp, vertical = 4.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        TextField(
                            value = findQuery,
                            onValueChange = {
                                findQuery = it
                                val wv = webView
                                if (wv != null) {
                                    if (it.isBlank()) { wv.clearMatches(); matchCount = 0 } else wv.findAllAsync(it)
                                }
                            },
                            modifier = Modifier.weight(1f).focusRequester(findFocus),
                            singleLine = true,
                            placeholder = { Text("Find\u2026") },
                            colors = TextFieldDefaults.colors(
                                focusedContainerColor = Color.Transparent,
                                unfocusedContainerColor = Color.Transparent
                            )
                        )
                        Text(
                            if (matchCount > 0) "${activeMatch + 1}/$matchCount" else "0/0",
                            fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant,
                            modifier = Modifier.padding(horizontal = 6.dp)
                        )
                        IconButton(onClick = { webView?.findNext(false) }) {
                            Icon(Icons.Default.KeyboardArrowUp, contentDescription = "Previous")
                        }
                        IconButton(onClick = { webView?.findNext(true) }) {
                            Icon(Icons.Default.KeyboardArrowDown, contentDescription = "Next")
                        }
                        IconButton(onClick = { showFind = false; findQuery = ""; webView?.clearMatches(); matchCount = 0 }) {
                            Icon(Icons.Default.Close, contentDescription = "Close find")
                        }
                    }
                }
                LaunchedEffect(Unit) { findFocus.requestFocus() }
            }

            Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                when {
                    error != null -> Text(
                        error!!, Modifier.padding(32.dp),
                        textAlign = TextAlign.Center, color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                    loaded == null -> CircularProgressIndicator()
                    else -> AndroidView(
                        modifier = Modifier.fillMaxSize(),
                        factory = { c ->
                            WebView(c).apply {
                                setBackgroundColor(bg)
                                settings.javaScriptEnabled = true
                                settings.allowFileAccess = true
                                settings.domStorageEnabled = true
                                settings.loadsImagesAutomatically = true
                                settings.mixedContentMode = WebSettings.MIXED_CONTENT_COMPATIBILITY_MODE
                                setFindListener { active, count, _ -> matchCount = count; activeMatch = active }
                                webViewClient = object : WebViewClient() {
                                    override fun onPageFinished(view: WebView?, url: String?) { pageReady = true; if (view != null) applyUniversalWebAppearance(view, obsidianDark, allowAlgorithmic = false) }
                                    override fun shouldOverrideUrlLoading(
                                        view: WebView?, request: WebResourceRequest?
                                    ): Boolean {
                                        val u = request?.url ?: return false
                                        if (u.scheme == "file") return false
                                        openLink(ctx, u)
                                        return true
                                    }
                                }
                                loadUrl("file:///android_asset/viewer.html")
                                webView = this
                            }
                        }
                    )
                }
            }
        }
    }

    if (showOutline) {
        ModalBottomSheet(onDismissRequest = { showOutline = false }) {
            Text(
                "\uD83E\uDDED Outline",
                Modifier.padding(start = 20.dp, top = 4.dp, bottom = 8.dp),
                fontWeight = FontWeight.Bold, fontSize = 16.sp
            )
            if (outline.isEmpty()) {
                Text(
                    "No headings in this note.",
                    Modifier.padding(20.dp), color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            } else {
                LazyColumn(Modifier.fillMaxWidth().heightIn(max = 460.dp)) {
                    items(outline) { item: OutlineItem ->
                        Text(
                            item.title,
                            Modifier.fillMaxWidth().clickable {
                                webView?.evaluateJavascript(
                                    "document.getElementById('sec-${item.index}')?." +
                                        "scrollIntoView({behavior:'smooth',block:'start'});",
                                    null
                                )
                                showOutline = false
                            }.padding(
                                start = (16 + (item.level - 1) * 14).dp,
                                end = 16.dp, top = 11.dp, bottom = 11.dp
                            ),
                            fontSize = if (item.level <= 2) 15.sp else 13.sp,
                            fontWeight = if (item.level <= 2) FontWeight.SemiBold else FontWeight.Normal,
                            color = if (item.level <= 2) MaterialTheme.colorScheme.onSurface
                            else MaterialTheme.colorScheme.onSurfaceVariant,
                            maxLines = 2, overflow = TextOverflow.Ellipsis
                        )
                    }
                    item { Spacer(Modifier.height(24.dp)) }
                }
            }
        }
    }
}

private fun displayName(ctx: Context, uri: Uri): String {
    if (uri.scheme == "content") {
        runCatching {
            ctx.contentResolver.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)?.use { c ->
                if (c.moveToFirst()) {
                    val idx = c.getColumnIndex(OpenableColumns.DISPLAY_NAME)
                    if (idx >= 0) return c.getString(idx)
                }
            }
        }
    }
    return uri.lastPathSegment?.substringAfterLast('/') ?: "Markdown"
}

private fun firstHeading(text: String): String? {
    for (raw in text.lineSequence()) {
        val line = raw.trim()
        val m = Regex("^#{1,6}\\s+(.*)$").find(line) ?: continue
        val t = m.groupValues[1].replace(Regex("[*_`~]"), "").replace(Regex("<[^>]+>"), "").trim()
        if (t.isNotBlank()) return t
    }
    return null
}

private fun openLink(ctx: Context, uri: Uri) {
    try {
        ctx.startActivity(Intent(Intent.ACTION_VIEW, uri).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
    } catch (e: Exception) {
        Toast.makeText(ctx, "No app can open this link", Toast.LENGTH_SHORT).show()
    }
}
