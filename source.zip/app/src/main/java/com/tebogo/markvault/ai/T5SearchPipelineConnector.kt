package com.tebogo.markvault.ai

/** Connects expansion selection to retrieval routing. */
object T5SearchPipelineConnector {
    fun selectedMode(): T5ExpansionMode {
        return T5SearchModeResolver.resolve()
    }

    fun shouldUseT5(): Boolean {
        return selectedMode() == T5ExpansionMode.T5_BASE &&
            T5ExpansionAvailability.isAvailable()
    }
}
