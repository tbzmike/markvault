package com.tebogo.markvault.ui

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.widget.Toast
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.selection.SelectionContainer
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.navigation.NavController
import com.tebogo.markvault.util.CrashLogger
import kotlinx.coroutines.launch
import java.io.File

/**
 * v5.4.131cc — Crash-log viewer screen.
 *
 * Lists every crash / non-fatal log written by [CrashLogger], newest
 * first. Each row expands to reveal the full text in a monospaced,
 * selectable, scrollable container. Actions per log entry:
 *
 *   • Copy to clipboard  — for pasting into a bug report.
 *   • Share              — fires `Intent.ACTION_SEND` with plain text
 *                          so the log can go to email, Slack, Drive,
 *                          etc. without needing a FileProvider.
 *   • Delete             — removes just that one log.
 *
 * The top bar has a global "Clear all" that dumps every log after
 * confirmation. File IO runs on Dispatchers.IO inside [CrashLogger];
 * this screen just observes.
 */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun CrashLogViewerScreen(nav: NavController) {
    val ctx: Context = LocalContext.current
    val scope = rememberCoroutineScope()

    var logs by remember { mutableStateOf<List<File>>(emptyList()) }
    var loading by remember { mutableStateOf(true) }
    var confirmClearAll by remember { mutableStateOf(false) }
    // reloadKey bumps every time we want to re-list logs (after a
    // delete / clear). Using an Int state avoids a suspend fun in the
    // reload path.
    var reloadKey by remember { mutableIntStateOf(0) }

    LaunchedEffect(reloadKey) {
        loading = true
        logs = CrashLogger.listLogs()
        loading = false
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("\uD83D\uDC1E  Crash logs") },
                navigationIcon = {
                    IconButton(onClick = { nav.popBackStack() }) {
                        Icon(
                            Icons.AutoMirrored.Filled.ArrowBack,
                            contentDescription = "Back"
                        )
                    }
                },
                actions = {
                    if (logs.isNotEmpty()) {
                        TextButton(onClick = { confirmClearAll = true }) {
                            Text("Clear all")
                        }
                    }
                }
            )
        }
    ) { paddingValues: PaddingValues ->
        Box(
            Modifier
                .fillMaxSize()
                .padding(paddingValues)
        ) {
            when {
                loading -> {
                    Column(
                        modifier = Modifier
                            .fillMaxSize()
                            .padding(24.dp),
                        horizontalAlignment = Alignment.CenterHorizontally,
                        verticalArrangement = Arrangement.Center
                    ) {
                        CircularProgressIndicator(
                            modifier = Modifier.size(28.dp),
                            strokeWidth = 3.dp
                        )
                        Spacer(Modifier.height(12.dp))
                        Text(
                            "Loading logs\u2026",
                            fontSize = 14.sp,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }
                logs.isEmpty() -> {
                    Column(
                        modifier = Modifier
                            .fillMaxSize()
                            .padding(32.dp),
                        horizontalAlignment = Alignment.CenterHorizontally,
                        verticalArrangement = Arrangement.Center
                    ) {
                        Text("\u2728", fontSize = 40.sp)
                        Spacer(Modifier.height(12.dp))
                        Text(
                            "No crash logs",
                            fontSize = 16.sp,
                            fontWeight = FontWeight.SemiBold
                        )
                        Spacer(Modifier.height(6.dp))
                        Text(
                            "Nothing here means the app hasn't crashed " +
                                "or logged a non-fatal error since the " +
                                "logger was installed.",
                            fontSize = 13.sp,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }
                else -> {
                    LazyColumn(
                        modifier = Modifier.fillMaxSize(),
                        contentPadding = PaddingValues(
                            top = 12.dp,
                            start = 12.dp,
                            end = 12.dp,
                            bottom = 24.dp
                        ),
                        verticalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        items(
                            items = logs,
                            key = { it.absolutePath }
                        ) { file ->
                            CrashLogRow(
                                file = file,
                                onDeleted = { reloadKey++ }
                            )
                        }
                    }
                }
            }
        }
    }

    if (confirmClearAll) {
        AlertDialog(
            onDismissRequest = { confirmClearAll = false },
            title = { Text("Clear all crash logs?") },
            text = {
                Text(
                    "Deletes every crash log stored on this device. " +
                        "This can't be undone."
                )
            },
            confirmButton = {
                Button(onClick = {
                    confirmClearAll = false
                    scope.launch {
                        val n = CrashLogger.clearAllLogs()
                        Toast.makeText(
                            ctx,
                            if (n > 0) "Cleared $n log(s)"
                            else "No logs to clear",
                            Toast.LENGTH_SHORT
                        ).show()
                        reloadKey++
                    }
                }) { Text("Clear") }
            },
            dismissButton = {
                TextButton(onClick = { confirmClearAll = false }) {
                    Text("Cancel")
                }
            }
        )
    }
}

/**
 * Single crash-log card. Collapsed: shows filename + file size. Tap to
 * expand, revealing the full log in a monospaced, scrollable,
 * selectable container plus copy / share / delete actions.
 */
@Composable
private fun CrashLogRow(
    file: File,
    onDeleted: () -> Unit
) {
    val ctx: Context = LocalContext.current
    val scope = rememberCoroutineScope()

    var expanded by remember(file.absolutePath) { mutableStateOf(false) }
    var content by remember(file.absolutePath) { mutableStateOf<String?>(null) }
    var reading by remember(file.absolutePath) { mutableStateOf(false) }

    // Kick off a read on first expand.
    LaunchedEffect(expanded) {
        if (expanded && content == null) {
            reading = true
            content = CrashLogger.readLog(file)
            reading = false
        }
    }

    Surface(
        shape = RoundedCornerShape(12.dp),
        color = MaterialTheme.colorScheme.surfaceVariant,
        tonalElevation = 1.dp,
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(Modifier.fillMaxWidth()) {
            // Header — clickable to toggle expansion
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .clickable { expanded = !expanded }
                    .padding(horizontal = 14.dp, vertical = 12.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = if (expanded) "\u25BC" else "\u25B6",
                    fontSize = 14.sp,
                    color = MaterialTheme.colorScheme.primary,
                    modifier = Modifier.padding(end = 10.dp)
                )
                Column(Modifier.weight(1f)) {
                    Text(
                        text = CrashLogger.formatFileName(file.name),
                        fontWeight = FontWeight.SemiBold,
                        fontSize = 14.sp
                    )
                    Text(
                        text = humanSize(file.length()),
                        fontSize = 11.sp,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }

            if (expanded) {
                HorizontalDivider(
                    thickness = 0.5.dp,
                    color = MaterialTheme.colorScheme.outlineVariant
                )
                // Log body — monospace, selectable, scrollable.
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .heightIn(min = 80.dp, max = 380.dp)
                        .background(MaterialTheme.colorScheme.surface)
                ) {
                    if (reading || content == null) {
                        Row(
                            modifier = Modifier.padding(16.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            CircularProgressIndicator(
                                modifier = Modifier.size(14.dp),
                                strokeWidth = 2.dp
                            )
                            Spacer(Modifier.size(10.dp))
                            Text(
                                "Loading\u2026",
                                fontSize = 12.sp,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    } else {
                        SelectionContainer {
                            Text(
                                text = content ?: "",
                                fontFamily = FontFamily.Monospace,
                                fontSize = 11.sp,
                                lineHeight = 15.sp,
                                modifier = Modifier
                                    .verticalScroll(rememberScrollState())
                                    .padding(14.dp)
                            )
                        }
                    }
                }
                HorizontalDivider(
                    thickness = 0.5.dp,
                    color = MaterialTheme.colorScheme.outlineVariant
                )
                // Actions — Copy / Share / Delete
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 6.dp, vertical = 4.dp),
                    horizontalArrangement = Arrangement.End
                ) {
                    TextButton(onClick = {
                        val text: String = content ?: return@TextButton
                        copyToClipboard(ctx, "MarkVault crash log", text)
                        Toast.makeText(
                            ctx, "Copied", Toast.LENGTH_SHORT
                        ).show()
                    }) { Text("Copy") }
                    TextButton(onClick = {
                        val text: String = content ?: return@TextButton
                        shareCrashLog(
                            ctx = ctx,
                            fileName = file.name,
                            body = text
                        )
                    }) { Text("Share") }
                    TextButton(onClick = {
                        scope.launch {
                            val ok = CrashLogger.deleteLog(file)
                            Toast.makeText(
                                ctx,
                                if (ok) "Deleted" else "Delete failed",
                                Toast.LENGTH_SHORT
                            ).show()
                            if (ok) onDeleted()
                        }
                    }) { Text("Delete") }
                }
            }
        }
    }
}

/** Copy plain text to the system clipboard. Safe on any thread. */
private fun copyToClipboard(
    ctx: Context, label: String, text: String
) {
    runCatching {
        val cm: ClipboardManager = ctx.getSystemService(
            Context.CLIPBOARD_SERVICE
        ) as ClipboardManager
        cm.setPrimaryClip(ClipData.newPlainText(label, text))
    }
}

/**
 * Share the log body as plain text via ACTION_SEND. Using
 * `EXTRA_TEXT` (rather than `EXTRA_STREAM` with a content URI) avoids
 * needing a `FileProvider` declaration in the manifest — the log
 * still reaches email / Slack / Drive / etc. and the receiver sees
 * exactly the same content that Copy would produce.
 */
private fun shareCrashLog(
    ctx: Context, fileName: String, body: String
) {
    runCatching {
        val intent = Intent(Intent.ACTION_SEND).apply {
            type = "text/plain"
            putExtra(
                Intent.EXTRA_SUBJECT,
                "MarkVault crash log — $fileName"
            )
            putExtra(Intent.EXTRA_TEXT, body)
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        }
        ctx.startActivity(
            Intent.createChooser(intent, "Share crash log")
                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        )
    }
}

/** Format a byte count for a compact size hint on the collapsed row. */
private fun humanSize(bytes: Long): String {
    if (bytes < 1024L) return "$bytes B"
    val kb: Double = bytes / 1024.0
    if (kb < 1024.0) return String.format("%.1f KB", kb)
    val mb: Double = kb / 1024.0
    return String.format("%.1f MB", mb)
}
