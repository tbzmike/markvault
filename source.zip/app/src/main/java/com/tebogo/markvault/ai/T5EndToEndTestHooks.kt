package com.tebogo.markvault.ai

/** Diagnostic hooks for final T5 validation. */
object T5EndToEndTestHooks {
    fun missingModelFallback(): String = "builtin"
    fun corruptModelRecovery(): String = "reload"
    fun successfulExpansion(): String = "t5"
}
