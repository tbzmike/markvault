package com.tebogo.markvault.ai

/**
 * Manages the T5 expansion model state.
 * Runtime loading will connect through the existing local inference layer.
 */
object T5ModelManager {
    private var installed = false

    fun isInstalled(): Boolean = installed

    fun setInstalled(value: Boolean) {
        installed = value
    }
}
