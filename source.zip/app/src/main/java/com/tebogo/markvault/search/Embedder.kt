package com.tebogo.markvault.search

import android.content.Context
import com.google.mediapipe.tasks.components.containers.Embedding
import com.google.mediapipe.tasks.core.BaseOptions
import com.google.mediapipe.tasks.text.textembedder.TextEmbedder
import com.google.mediapipe.tasks.text.textembedder.TextEmbedderResult
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File
import java.io.FileOutputStream
import java.net.URL
import java.nio.ByteBuffer
import java.nio.ByteOrder

/**
 * v4.8 — on-device text-embedding service backed by MediaPipe Tasks. Loads a
 * `.tflite` model from the app's filesDir (downloaded on first opt-in) and
 * exposes a simple `embed(text): FloatArray?` API.
 *
 * Design notes:
 *
 * - The model file is **not** shipped in `assets/` to keep the APK slim
 *   (~25MB savings). It's downloaded once on user opt-in via [downloadModel]
 *   and cached forever in [modelFile].
 *
 * - The embedder instance is lazy-loaded the first time [embed] is called.
 *   Subsequent calls reuse it. Use [close] to release native resources when
 *   the app is being torn down.
 *
 * - All public functions are `suspend` and run on `Dispatchers.IO` so the
 *   caller doesn't have to think about threading. MediaPipe's `embed` itself
 *   is synchronous and CPU-bound — running it on the main thread would jank.
 *
 * - Output vectors are L2-normalised by MediaPipe (we pass `setL2Normalize(true)`),
 *   so cosine similarity reduces to dot product — handy for fast in-memory
 *   ranking over thousands of stored embeddings.
 *
 * - Model version string is the file's SHA-prefix once downloaded; we expose
 *   a stable label via [modelVersion] so the DB can key embeddings by it and
 *   invalidate them when a different model is swapped in.
 */
class Embedder(
    context: Context,
    /** Active model descriptor. Drives file path, download URL, DB key. */
    val descriptor: ModelDescriptor,
) {

    // v4.9.1 — Internal backend abstraction. Each framework gets its own
    // implementation; the Embedder facade routes calls to the right one based
    // on `descriptor.framework`. The MediaPipe code lives in
    // MediaPipeEmbedderBackend; ONNX support landed in v4.10.0 with the
    // OnnxBertEmbedderBackend that powers all-MiniLM-L6-v2.
    private val backend: EmbedderBackend = when (descriptor.framework) {
        ModelFramework.MEDIAPIPE_USE -> MediaPipeEmbedderBackend(context, descriptor)
        ModelFramework.ONNX_BERT -> OnnxBertEmbedderBackend(context, descriptor)
    }

    /** Where the model file lives once downloaded. */
    val modelFile: File get() = backend.modelFile

    /** Identifier persisted alongside each embedding row. */
    val modelVersion: String get() = descriptor.id

    /** True if the model has been downloaded and is ready to use. */
    fun isModelAvailable(): Boolean = backend.isModelAvailable()

    /**
     * Download the active model's file into the app's filesDir. Idempotent —
     * if the file already exists, returns immediately. Cancellable via
     * coroutine cancellation: streams are closed on cancellation.
     *
     * Reports progress via [onProgress] as a 0.0–1.0 fraction. Pass a no-op
     * if you don't need it.
     */
    suspend fun downloadModel(
        onProgress: (Float) -> Unit = {}
    ): Result<Unit> = backend.downloadModel(onProgress)

    /**
     * Embed a text into a float vector. Returns null when the model isn't
     * available yet or when the input is blank. The input is truncated to
     * [MAX_INPUT_CHARS] characters to avoid CPU spikes on very long notes —
     * the first few hundred characters typically capture the gist for
     * similarity ranking purposes.
     */
    suspend fun embed(text: String): FloatArray? = backend.embed(text)

    /** Release native resources. Safe to call multiple times. */
    fun close() = backend.close()

    companion object {
        /**
         * Anything smaller than this on disk is almost certainly a failed
         * download. Applies to any model — all real text embedders are well
         * over 1 MB.
         */
        internal const val MIN_PLAUSIBLE_MODEL_BYTES = 1_000_000L

        /** Cap input length passed into the model to keep latency bounded. */
        internal const val MAX_INPUT_CHARS = 1500
    }
}

/**
 * v4.9.1 — Internal common base for every per-framework backend. Each backend
 * owns the model file location (driven by [ModelDescriptor.localFilename]),
 * the download routine, and the embedding pipeline. The Embedder facade only
 * cares about the four [downloadModel], [embed], [close], [isModelAvailable]
 * operations plus the file path getter.
 */
internal abstract class EmbedderBackend(
    protected val context: Context,
    val descriptor: ModelDescriptor,
) {
    open val modelFile: File
        get() = File(context.filesDir, descriptor.localFilename)

    open fun isModelAvailable(): Boolean =
        modelFile.exists() && modelFile.length() > Embedder.MIN_PLAUSIBLE_MODEL_BYTES

    abstract suspend fun downloadModel(onProgress: (Float) -> Unit): Result<Unit>
    abstract suspend fun embed(text: String): FloatArray?
    abstract fun close()
}

/**
 * v4.9.1 — MediaPipe Tasks `TextEmbedder` backend. Hosts the exact same logic
 * the v4.8 Embedder ran inline; nothing about model behaviour has changed.
 * The constructor only requires a [ModelDescriptor] whose [ModelDescriptor.framework]
 * is [ModelFramework.MEDIAPIPE_USE], but we don't re-validate here because
 * the [Embedder] facade has already routed the call.
 */
internal class MediaPipeEmbedderBackend(
    context: Context,
    descriptor: ModelDescriptor,
) : EmbedderBackend(context, descriptor) {

    @Volatile
    private var embedder: TextEmbedder? = null

    override suspend fun downloadModel(
        onProgress: (Float) -> Unit
    ): Result<Unit> = withContext(Dispatchers.IO) {
        if (isModelAvailable()) return@withContext Result.success(Unit)
        val tmp = File(context.filesDir, "${descriptor.localFilename}.part")
        runCatching {
            val conn = URL(descriptor.downloadUrl).openConnection()
            conn.connectTimeout = 15_000
            conn.readTimeout = 60_000
            val total = conn.contentLengthLong.coerceAtLeast(1L)
            conn.getInputStream().use { input ->
                FileOutputStream(tmp).use { output ->
                    val buf = ByteArray(64 * 1024)
                    var read: Int
                    var soFar = 0L
                    while (true) {
                        read = input.read(buf)
                        if (read < 0) break
                        output.write(buf, 0, read)
                        soFar += read
                        if (total > 0) onProgress((soFar.toFloat() / total).coerceIn(0f, 1f))
                    }
                }
            }
            if (!tmp.renameTo(modelFile)) {
                error("Could not move temp file into place")
            }
            onProgress(1f)
        }.onFailure {
            runCatching { tmp.delete() }
        }
    }

    override suspend fun embed(text: String): FloatArray? = withContext(Dispatchers.IO) {
        val cleaned = text.trim()
        if (cleaned.isEmpty()) return@withContext null
        val embedder = ensureEmbedder() ?: return@withContext null
        val sliced = if (cleaned.length > Embedder.MAX_INPUT_CHARS) {
            cleaned.substring(0, Embedder.MAX_INPUT_CHARS)
        } else cleaned
        val res: TextEmbedderResult = runCatching { embedder.embed(sliced) }
            .getOrElse { return@withContext null }
        val embedding: Embedding = res.embeddingResult().embeddings()
            .firstOrNull() ?: return@withContext null
        embedding.floatEmbedding()
    }

    override fun close() {
        runCatching { embedder?.close() }
        embedder = null
    }

    /** Lazy-initialise the embedder. Returns null when the model isn't downloaded yet. */
    @Synchronized
    private fun ensureEmbedder(): TextEmbedder? {
        embedder?.let { return it }
        if (!isModelAvailable()) return null
        return runCatching {
            val opts = TextEmbedder.TextEmbedderOptions.builder()
                .setBaseOptions(
                    BaseOptions.builder()
                        .setModelAssetPath(modelFile.absolutePath)
                        .build()
                )
                .setL2Normalize(true)
                .setQuantize(false)
                .build()
            TextEmbedder.createFromOptions(context, opts).also { embedder = it }
        }.getOrNull()
    }
}

// ── Vector utilities ────────────────────────────────────────────────────────

/**
 * Pack a `FloatArray` into a little-endian `ByteArray` for BLOB storage.
 * Inverse of [bytesToFloatArray]. Uses 4 bytes per float; a 100-dim embedding
 * therefore costs 400 bytes per note.
 */
fun floatArrayToBytes(v: FloatArray): ByteArray {
    val buf = ByteBuffer.allocate(v.size * 4).order(ByteOrder.LITTLE_ENDIAN)
    for (f in v) buf.putFloat(f)
    return buf.array()
}

/** Unpack a `ByteArray` from [floatArrayToBytes] back into a `FloatArray`. */
fun bytesToFloatArray(bytes: ByteArray): FloatArray {
    val buf = ByteBuffer.wrap(bytes).order(ByteOrder.LITTLE_ENDIAN)
    val out = FloatArray(bytes.size / 4)
    for (i in out.indices) out[i] = buf.float
    return out
}

/**
 * Cosine similarity between two embedding vectors. Returns a value in
 * `[-1.0, 1.0]` where 1.0 means identical direction. When both inputs are
 * L2-normalised this is just the dot product.
 *
 * Returns 0.0 on length mismatch (defensive; the caller should ensure dims
 * align by construction).
 */
fun cosineSimilarity(a: FloatArray, b: FloatArray): Float {
    if (a.size != b.size || a.isEmpty()) return 0f
    var dot = 0f
    var na = 0f
    var nb = 0f
    for (i in a.indices) {
        val x = a[i]; val y = b[i]
        dot += x * y
        na += x * x
        nb += y * y
    }
    val denom = kotlin.math.sqrt(na) * kotlin.math.sqrt(nb)
    return if (denom == 0f) 0f else dot / denom
}
