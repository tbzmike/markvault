package com.tebogo.markvault.data

import android.content.Context
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import org.json.JSONObject
import java.io.File

/**
 * v5.4.94cc — App-wide activity log.
 *
 * Records every notable action the user (or the app on their behalf)
 * performs, so they can audit what MarkVault has been doing without
 * digging through logcat. Backed by a JSON Lines file in the app's
 * private storage (`filesDir/activity_log.jsonl`) — durable across
 * process death, cheap to append, no schema migrations to worry about.
 *
 * Design choices:
 *  - **File over DataStore**: log grows over hundreds/thousands of
 *    entries, and DataStore's whole-file rewrite-on-edit model is a bad
 *    fit. Appending a single line to a text file is O(entry length) and
 *    doesn't require serialising the entire log every time.
 *  - **JSONL (one JSON object per line)**: dead simple to parse
 *    incrementally, human-readable if the user ever pulls the file for
 *    debugging, tolerant of partial writes (a torn last line only loses
 *    the final entry).
 *  - **Ring-buffer cap of 5000 entries**: when the file exceeds
 *    [MAX_ENTRIES] on read, the oldest entries are truncated on the next
 *    write. Keeps the log finite without needing a background reaper.
 *  - **In-memory StateFlow**: [entries] is a StateFlow the log screen
 *    observes. Bumped after every log/clear so the UI refreshes without
 *    polling the file.
 *
 * All public methods are safe to call from any thread.
 */
class ActivityLog(private val ctx: Context) {

    private val file: File by lazy { File(ctx.filesDir, "activity_log.jsonl") }
    private val ioLock = Any()
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)

    private val _entries = MutableStateFlow<List<Entry>>(emptyList())
    /**
     * All log entries, newest first. Populated lazily on first read and
     * kept in sync with every subsequent [log] / [clear].
     */
    val entries: StateFlow<List<Entry>> = _entries.asStateFlow()

    /**
     * A single log entry. `metadata` is a small map of category-specific
     * details (URL, title, count, duration, etc.) that the log screen can
     * render as a subtitle.
     */
    data class Entry(
        val timestamp: Long,
        val category: Category,
        val message: String,
        val metadata: Map<String, String>
    ) {
        fun formatCopy(): String {
            val sb = StringBuilder()
            sb.append(FMT_LONG.format(java.util.Date(timestamp)))
            sb.append("  [")
            sb.append(category.label)
            sb.append("]  ")
            sb.append(message)
            if (metadata.isNotEmpty()) {
                sb.append('\n')
                for ((k, v) in metadata) {
                    sb.append("    ").append(k).append(": ").append(v).append('\n')
                }
            } else {
                sb.append('\n')
            }
            return sb.toString()
        }

        internal fun toJson(): String {
            val o = JSONObject()
            o.put("t", timestamp)
            o.put("c", category.name)
            o.put("m", message)
            if (metadata.isNotEmpty()) {
                val md = JSONObject()
                for ((k, v) in metadata) md.put(k, v)
                o.put("d", md)
            }
            return o.toString()
        }

        companion object {
            internal fun fromJson(line: String): Entry? {
                if (line.isBlank()) return null
                return runCatching {
                    val o = JSONObject(line)
                    val cat = runCatching {
                        Category.valueOf(o.optString("c", "OTHER"))
                    }.getOrElse { Category.OTHER }
                    val md = o.optJSONObject("d")
                    val meta = if (md == null) emptyMap() else {
                        val m = LinkedHashMap<String, String>()
                        val keys = md.keys()
                        while (keys.hasNext()) {
                            val k = keys.next()
                            m[k] = md.optString(k, "")
                        }
                        m
                    }
                    Entry(
                        timestamp = o.optLong("t", 0L),
                        category = cat,
                        message = o.optString("m", ""),
                        metadata = meta
                    )
                }.getOrNull()
            }
        }
    }

    /**
     * Category taxonomy. Kept broad rather than exhaustively fine-grained
     * so filter chips in the log screen stay usable at a glance.
     */
    enum class Category(val label: String, val emoji: String) {
        SAVED_ARTICLE("Saved article", "\uD83D\uDCBE"),
        BATCH_SAVE("Batch save", "\uD83C\uDFAF"),
        INDEX_SYNC("Index sync", "\uD83D\uDD04"),
        EMBED("Embedding pass", "\uD83E\uDDE0"),
        FAST_SEARCH("Fast search", "⚡"),
        SELECTION("Selection", "\u2713"),
        WEB_NAV("Web viewer", "\uD83C\uDF10"),
        OTHER("Other", "\uD83D\uDCCC")
    }

    /**
     * Append a log entry. Fires and forgets: the write itself happens on
     * an IO coroutine, so the caller isn't blocked on disk. The in-memory
     * StateFlow is patched synchronously so the log screen updates
     * immediately.
     */
    fun log(category: Category, message: String, metadata: Map<String, String> = emptyMap()) {
        val entry = Entry(
            timestamp = System.currentTimeMillis(),
            category = category,
            message = message,
            metadata = metadata
        )
        // Update in-memory list first — cheap, thread-safe (StateFlow),
        // and drives the UI immediately.
        val cur = _entries.value
        _entries.value = (listOf(entry) + cur).take(MAX_ENTRIES)
        // Persist to disk on IO. Serial writes via `ioLock` so
        // concurrent log() calls don't interleave lines mid-file.
        scope.launch {
            synchronized(ioLock) {
                runCatching {
                    // If the file has grown past MAX_ENTRIES, rewrite it
                    // with the trimmed in-memory list (drops the oldest
                    // entries first because we prepend, then re-serialize
                    // newest-first at the top).
                    val curInMem = _entries.value
                    if (curInMem.size >= MAX_ENTRIES) {
                        file.writeText(
                            curInMem.joinToString(separator = "\n") { it.toJson() } + "\n"
                        )
                    } else {
                        file.appendText(entry.toJson() + "\n")
                    }
                }
            }
        }
    }

    /**
     * Force a re-read of the log file. Call once at app start to populate
     * the in-memory list from persistent storage.
     */
    fun refreshFromDisk() {
        scope.launch {
            synchronized(ioLock) {
                val list = runCatching {
                    if (!file.exists()) emptyList<Entry>()
                    else file.readLines().mapNotNull { Entry.fromJson(it) }
                }.getOrElse { emptyList() }
                // Newest first — the log screen presents in reverse
                // chronological order.
                _entries.value = list.sortedByDescending { it.timestamp }.take(MAX_ENTRIES)
            }
        }
    }

    /** Wipe every entry from both memory and disk. */
    fun clear() {
        _entries.value = emptyList()
        scope.launch {
            synchronized(ioLock) {
                runCatching { file.delete() }
            }
        }
    }

    companion object {
        /** Ring-buffer cap. ~5000 entries × ~200 bytes ≈ 1 MB max on disk. */
        private const val MAX_ENTRIES = 5000
        internal val FMT_LONG = java.text.SimpleDateFormat(
            "yyyy-MM-dd HH:mm:ss", java.util.Locale.US
        )
    }
}
