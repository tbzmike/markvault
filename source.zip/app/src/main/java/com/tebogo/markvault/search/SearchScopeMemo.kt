package com.tebogo.markvault.search

import kotlinx.coroutines.currentCoroutineContext
import kotlinx.coroutines.ensureActive
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock

/** One request uses one scope membership snapshot across parallel retrieval stages. */
class SearchScopeMemo {
    private val lock = Mutex()
    private val scopes = HashMap<String, Set<Long>>()

    suspend fun get(scope: String, load: suspend () -> Set<Long>): Set<Long> = lock.withLock {
        currentCoroutineContext().ensureActive()
        scopes[scope] ?: load().toSet().also {
            currentCoroutineContext().ensureActive()
            scopes[scope] = it
        }
    }
}
