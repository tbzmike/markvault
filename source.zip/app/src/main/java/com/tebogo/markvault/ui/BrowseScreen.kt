package com.tebogo.markvault.ui

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.navigation.NavController
import com.tebogo.markvault.AppViewModel
import com.tebogo.markvault.data.NoteMeta

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun BrowseScreen(vm: AppViewModel, nav: NavController) {
    val notes by vm.notes.collectAsStateWithLifecycle()
    var currentPath by rememberSaveable { mutableStateOf("") }

    BackHandler(enabled = currentPath.isNotEmpty()) {
        currentPath = currentPath.substringBeforeLast('/', "")
    }

    fun open(n: NoteMeta) {
        when (n.fileType) {
            "pdf" -> {
                vm.openArticle(n.id, n.title, fileType = "pdf")
                nav.navigate("pdfReader/${n.id}")
            }
            "mhtml", "mht", "html", "htm" -> {
                vm.openArticle(n.id, n.title, fileType = n.fileType)
                nav.navigate("htmlReader/${n.id}")
            }
            "canvas" -> {
                vm.openArticle(n.id, n.title, fileType = "canvas")
                nav.navigate("canvas/${n.id}")
            }
            else -> {
                vm.openArticle(n.id, n.title)
                nav.navigate("reader") { launchSingleTop = true }
            }
        }
    }

    val folderCounts = remember(notes, currentPath) {
        val prefix = if (currentPath.isEmpty()) "" else "$currentPath/"
        val m = sortedMapOf<String, Int>(String.CASE_INSENSITIVE_ORDER)
        for (n in notes) {
            val f = n.folder
            val child: String? = when {
                currentPath.isEmpty() && f.isNotEmpty() -> f.substringBefore('/')
                currentPath.isNotEmpty() && f != currentPath && f.startsWith(prefix) ->
                    f.removePrefix(prefix).substringBefore('/')
                else -> null
            }
            if (!child.isNullOrEmpty()) m[child] = (m[child] ?: 0) + 1
        }
        m
    }
    // v5.2.0 — Sort + view controls. Local-state-only for now; can be
    // promoted to a pref if the user wants persistence across launches.
    var sortMode by rememberSaveable { mutableStateOf("title_asc") }
    var viewMode by rememberSaveable { mutableStateOf("list") }
    val filesHere = remember(notes, currentPath, sortMode) {
        val base = notes.filter { it.folder == currentPath }
        when (sortMode) {
            "newest" -> base.sortedByDescending { it.lastModified }
            "oldest" -> base.sortedBy { it.lastModified }
            "title_desc" -> base.sortedByDescending { it.title.lowercase() }
            else -> base.sortedBy { it.title.lowercase() }
        }
    }

    Scaffold(
        topBar = {
            TopAppBar(title = { Text("\uD83D\uDCC1 Browse files") })
        },
        bottomBar = {
            MarkVaultBottomBar(
                nav = nav, vm = vm,
                onBackOverride = {
                    if (currentPath.isNotEmpty()) currentPath = currentPath.substringBeforeLast('/', "")
                    else nav.popBackStack()
                },
                extraActions = {
                    IconButton(onClick = { vm.enterNormalSearchPage(); nav.navigate("search") }) {
                        Icon(Icons.Default.Search, contentDescription = "Search library")
                    }
                }
            )
        }
    ) { pad ->
        Column(Modifier.padding(pad).fillMaxSize()) {
            Row(
                Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 8.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text("\uD83C\uDFE0", Modifier.clickable { currentPath = "" }, fontSize = 16.sp)
                Spacer(Modifier.width(8.dp))
                Text(
                    if (currentPath.isEmpty()) vm.libraryName() else "/ $currentPath",
                    fontSize = 13.sp, color = MaterialTheme.colorScheme.onSurfaceVariant,
                    maxLines = 1, overflow = TextOverflow.Ellipsis
                )
            }
            HorizontalDivider(color = MaterialTheme.colorScheme.surfaceVariant)
            // v5.2.0 — Sort + view chips. Sort affects file ordering; view
            // toggles between list (default) and grid (denser, 2-column).
            androidx.compose.foundation.layout.Row(
                Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 12.dp, vertical = 6.dp)
                    .horizontalScroll(rememberScrollState()),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                BrowseChip(label = "\u2191 Newest", selected = sortMode == "newest") { sortMode = "newest" }
                BrowseChip(label = "\u2193 Oldest", selected = sortMode == "oldest") { sortMode = "oldest" }
                BrowseChip(label = "A\u2192Z", selected = sortMode == "title_asc") { sortMode = "title_asc" }
                BrowseChip(label = "Z\u2192A", selected = sortMode == "title_desc") { sortMode = "title_desc" }
                androidx.compose.foundation.layout.Spacer(Modifier.width(6.dp))
                BrowseChip(label = "\u2630 List", selected = viewMode == "list") { viewMode = "list" }
                BrowseChip(label = "\u2B1A Grid", selected = viewMode == "grid") { viewMode = "grid" }
            }
            HorizontalDivider(color = MaterialTheme.colorScheme.surfaceVariant)
            if (viewMode == "grid") {
                // v5.2.1 — Manual 2-column grid via LazyColumn + chunked
                // pairs. Avoids depending on lazy.grid.LazyVerticalGrid,
                // which isn't resolvable in this project's compose
                // foundation version. Folders come first, then files.
                val folderList = folderCounts.keys.toList()
                val rowItems: List<Pair<Any, Any?>> = buildList {
                    var i = 0
                    while (i < folderList.size) {
                        val a = folderList[i]
                        val b = if (i + 1 < folderList.size) folderList[i + 1] else null
                        add(a as Any to b as Any?)
                        i += 2
                    }
                    var j = 0
                    while (j < filesHere.size) {
                        val a = filesHere[j]
                        val b = if (j + 1 < filesHere.size) filesHere[j + 1] else null
                        add(a as Any to b as Any?)
                        j += 2
                    }
                }
                LazyColumn(
                    modifier = Modifier.fillMaxSize(),
                    contentPadding = PaddingValues(8.dp),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    items(rowItems) { pair ->
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            BrowseGridSlot(
                                item = pair.first,
                                folderCounts = folderCounts,
                                modifier = Modifier.weight(1f),
                                onOpenFolder = { f ->
                                    currentPath = if (currentPath.isEmpty()) f else "$currentPath/$f"
                                },
                                onOpenFile = { open(it) }
                            )
                            if (pair.second != null) {
                                BrowseGridSlot(
                                    item = pair.second!!,
                                    folderCounts = folderCounts,
                                    modifier = Modifier.weight(1f),
                                    onOpenFolder = { f ->
                                        currentPath = if (currentPath.isEmpty()) f else "$currentPath/$f"
                                    },
                                    onOpenFile = { open(it) }
                                )
                            } else {
                                Spacer(Modifier.weight(1f))
                            }
                        }
                    }
                    item { Spacer(Modifier.height(24.dp)) }
                }
            } else {
                LazyColumn(Modifier.fillMaxSize()) {
                    items(folderCounts.keys.toList()) { folder ->
                        BrowseRow("\uD83D\uDCC1", folder, "${folderCounts[folder]}") {
                            currentPath = if (currentPath.isEmpty()) folder else "$currentPath/$folder"
                        }
                    }
                    items(filesHere, key = { it.id }) { n ->
                        val icon = if (n.fileType == "pdf") "\uD83D\uDCD5" else "\uD83D\uDCC4"
                        BrowseRow(icon, n.title, null) { open(n) }
                    }
                    item { Spacer(Modifier.height(24.dp)) }
                }
            }
        }
    }
}

/**
 * v5.2.1 — Dispatches a single grid cell. The item is either a folder
 * name (String) or a NoteMeta. Extracted so the chunked-pair Row stays
 * readable.
 */
@Composable
private fun BrowseGridSlot(
    item: Any,
    folderCounts: Map<String, Int>,
    modifier: Modifier = Modifier,
    onOpenFolder: (String) -> Unit,
    onOpenFile: (com.tebogo.markvault.data.NoteMeta) -> Unit
) {
    when (item) {
        is String -> {
            BrowseGridCell(
                emoji = "\uD83D\uDCC1",
                title = item,
                trailing = "${folderCounts[item] ?: 0}",
                modifier = modifier
            ) { onOpenFolder(item) }
        }
        is com.tebogo.markvault.data.NoteMeta -> {
            val icon = if (item.fileType == "pdf") "\uD83D\uDCD5" else "\uD83D\uDCC4"
            BrowseGridCell(
                emoji = icon,
                title = item.title,
                trailing = null,
                modifier = modifier
            ) { onOpenFile(item) }
        }
    }
}

@Composable
private fun BrowseChip(label: String, selected: Boolean, onClick: () -> Unit) {
    androidx.compose.material3.FilterChip(
        selected = selected,
        onClick = onClick,
        label = { Text(label, fontSize = 11.sp) }
    )
}

@Composable
private fun BrowseGridCell(
    emoji: String,
    title: String,
    trailing: String?,
    modifier: Modifier = Modifier,
    onClick: () -> Unit
) {
    androidx.compose.material3.Surface(
        color = MaterialTheme.colorScheme.surfaceVariant,
        shape = RoundedCornerShape(10.dp),
        modifier = modifier
            .fillMaxWidth()
            .clickable(onClick = onClick)
    ) {
        Column(
            Modifier.padding(12.dp),
            verticalArrangement = Arrangement.spacedBy(6.dp)
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(emoji, fontSize = 22.sp)
                Spacer(Modifier.weight(1f))
                if (trailing != null) {
                    Text(
                        trailing,
                        fontSize = 11.sp,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }
            Text(
                title,
                fontSize = 13.sp,
                fontWeight = FontWeight.Medium,
                maxLines = 3,
                overflow = TextOverflow.Ellipsis
            )
        }
    }
}

@Composable
private fun BrowseRow(emoji: String, title: String, trailing: String?, onClick: () -> Unit) {
    Row(
        Modifier.fillMaxWidth().clickable(onClick = onClick)
            .padding(horizontal = 16.dp, vertical = 14.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Box(Modifier.size(26.dp), contentAlignment = Alignment.Center) { Text(emoji, fontSize = 17.sp) }
        Spacer(Modifier.width(10.dp))
        Text(
            title, Modifier.weight(1f), fontWeight = FontWeight.Medium,
            maxLines = 2, overflow = TextOverflow.Ellipsis
        )
        if (trailing != null) {
            Text(trailing, fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
    }
    HorizontalDivider(color = MaterialTheme.colorScheme.surfaceVariant)
}
