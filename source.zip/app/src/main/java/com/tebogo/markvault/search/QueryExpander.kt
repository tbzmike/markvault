package com.tebogo.markvault.search

/**
 * Lightweight offline query expansion + fuzzy scoring layer.
 *
 * Two purposes:
 *
 *   1. **Synonym expansion** — when the user searches "Why did God send Jesus",
 *      we run the original query AND a handful of theologically-equivalent
 *      variants ("Why Jehovah sent his Son", "Why Christ was sent", etc.) and
 *      merge the result sets. This is the practical 80% of "semantic" search
 *      without shipping a 10MB embedding model. The synonym groups below
 *      reflect the way JW publications phrase these concepts.
 *
 *   2. **Fuzzy match scoring** — for ranking, we award a small bonus when a
 *      result's title contains a word that's within edit-distance 1–2 of any
 *      query token. This catches typos like "Jeohvah" → "Jehovah" without
 *      changing the query itself.
 *
 * Everything here is pure Kotlin, no native code, no model files, no network.
 * It runs in microseconds on a mid-range Android device.
 *
 * Architecture note: this file is intentionally NOT wired into the DAO
 * directly. The VM is the orchestration layer — it expands the query, runs
 * the existing `titleSearch` / `rankedContentSearch` against each variant,
 * unions the results, and then re-ranks using a blend of original score +
 * fuzzy boost. The DAO and existing search functions are untouched, so the
 * baseline path is byte-for-byte the same as before.
 */
object QueryExpander {

    /**
     * Theological & biblical synonym groups. Each set is a cluster of tokens
     * that are semantically interchangeable in the JW/biblical context.
     *
     * Add freely — at runtime the lookup is O(1) per token because we build
     * a reverse index from each token to its set.
     */
    private val synonymGroups: List<Set<String>> = listOf(
        // Divine persons
        setOf("god", "jehovah", "yahweh", "almighty", "creator", "lord"),
        setOf("jesus", "christ", "messiah", "son", "savior", "saviour", "redeemer", "lamb"),
        setOf("spirit", "ghost", "force"),  // holy spirit / active force
        setOf("satan", "devil", "adversary", "tempter"),
        setOf("angel", "angels", "messenger", "messengers", "heavenly"),

        // Bible / scripture
        setOf("bible", "scripture", "scriptures", "word"),
        setOf("verse", "passage", "text"),
        setOf("chapter", "psalm"),
        setOf("nwt", "translation"),

        // Verbs of choosing / sending
        setOf("chose", "choose", "chosen", "select", "selected", "called", "appointed", "elected"),
        setOf("sent", "send", "sending", "dispatched", "commissioned"),
        setOf("gave", "give", "given", "provided"),

        // Verbs of knowing / understanding
        setOf("understand", "understanding", "comprehend", "grasp", "know"),
        setOf("teach", "teaching", "instruct", "instruction", "educate", "learn"),
        setOf("explain", "explanation", "clarify"),

        // Why / purpose / reason
        setOf("why", "purpose", "reason", "intent", "intention"),
        setOf("how", "way", "manner", "method"),
        setOf("when", "time", "timing"),

        // Kingdom / governance
        setOf("kingdom", "rule", "ruling", "government", "sovereignty", "throne"),
        setOf("king", "ruler", "monarch", "sovereign"),

        // Worship
        setOf("worship", "praise", "honor", "honour", "glorify", "exalt"),
        setOf("pray", "prayer", "praying", "supplication", "petition"),
        setOf("serve", "service", "ministry"),

        // Death / hell / afterlife
        setOf("death", "die", "died", "dying", "deceased", "perished"),
        setOf("hell", "hades", "sheol", "grave", "tomb"),
        setOf("resurrection", "raised", "raising", "awaken", "awakened"),
        setOf("paradise", "heaven", "eternal", "everlasting", "endless"),
        setOf("life", "living", "alive"),

        // Sin / righteousness
        setOf("sin", "sins", "transgression", "wrongdoing", "evil", "iniquity"),
        setOf("righteous", "righteousness", "just", "justice", "upright"),
        setOf("forgive", "forgiveness", "pardon", "mercy"),

        // Love / faith / hope
        setOf("love", "agape", "lovingkindness", "loyal-love"),
        setOf("faith", "belief", "trust", "confidence"),
        setOf("hope", "expectation", "anticipation"),

        // Baptism / discipleship
        setOf("baptize", "baptism", "baptized", "baptised", "dedicated"),
        setOf("disciple", "follower", "follow", "following"),
        setOf("witness", "witnesses", "preach", "preaching", "testify"),

        // Last days / end
        setOf("end", "ending", "conclusion", "completion"),
        setOf("tribulation", "great-tribulation", "armageddon", "judgment", "judgement"),

        // People
        setOf("man", "men", "human", "humans", "mankind", "humankind", "people"),
        setOf("woman", "women", "wife", "wives", "female"),
        setOf("child", "children", "kids", "young", "youngsters", "youth"),
        setOf("brother", "brothers", "brethren", "sibling"),

        // Common patriarchs / figures often re-spelled
        setOf("abraham", "abram"),
        setOf("jacob", "israel"),
        setOf("paul", "saul"),
        setOf("peter", "cephas", "simon"),
    )

    // Reverse index: token → the set it belongs to. O(1) lookup at query time.
    private val tokenIndex: Map<String, Set<String>> by lazy {
        val m = HashMap<String, Set<String>>()
        for (group in synonymGroups) {
            for (token in group) m[token] = group
        }
        m
    }

    /**
     * A generated query variant plus how much the fusion layer should
     * trust it. The user's own words are 1.0; everything we invent
     * scores lower, because a substitution is a *guess* about intent.
     */
    data class WeightedQuery(val text: String, val weight: Double)

    /**
     * v5.4.115cc — Function words we never substitute.
     *
     * These carry almost no retrieval signal (FTS treats most as
     * stopwords, and their IDF is near zero), but several of them sit
     * in synonym groups above — "why" is grouped with purpose/reason/
     * intent. Substituting them produced grammatically broken variants
     * like "purpose did God send Jesus" that match nothing, while
     * consuming the variant budget that should have gone to the terms
     * that actually discriminate between documents.
     */
    private val functionWords: Set<String> = setOf(
        "a", "an", "the", "of", "to", "in", "for", "and", "or", "but", "if",
        "then", "than", "so", "as", "at", "by", "with", "from", "on", "off",
        "up", "down", "out", "over", "into", "about",
        "is", "are", "was", "were", "be", "been", "being", "am",
        "do", "does", "did", "doing", "have", "has", "had", "having",
        "will", "would", "shall", "should", "can", "could", "may", "might",
        "must", "i", "you", "he", "she", "it", "we", "they", "me", "him",
        "her", "us", "them", "my", "your", "his", "its", "our", "their",
        "this", "that", "these", "those", "what", "which", "who", "whom",
        "whose", "why", "how", "when", "where", "there", "here",
        "not", "no", "nor", "only", "own", "same", "too", "very", "just"
    )

    /** True when [token] is a function word not worth expanding. */
    fun isFunctionWord(token: String): Boolean =
        normalizeToken(token) in functionWords

    /** Strip surrounding punctuation and lowercase. */
    private fun normalizeToken(raw: String): String =
        raw.lowercase().trim('"', '\'', '.', ',', '?', '!', ':', ';', '(', ')')

    /**
     * How much retrieval signal a token carries. Higher = a better
     * place to spend variant budget. Returns -1 for tokens we refuse
     * to substitute.
     *
     * Two cheap, robust proxies for specificity, chosen because we have
     * no corpus statistics at query time:
     *   • **Length** — longer words are rarer and more discriminating.
     *   • **Capitalisation** — a capitalised token mid-query is almost
     *     always a proper noun ("Jehovah", "Christ", "Babylon"), which
     *     is exactly the kind of term whose synonym swap changes which
     *     documents match.
     */
    private fun informativeness(raw: String, positionInQuery: Int): Int {
        val norm = normalizeToken(raw)
        if (norm.length < 3) return -1
        if (norm in functionWords) return -1
        var score = norm.length
        // Capitalised and not merely the sentence-initial word.
        if (raw.isNotEmpty() && raw[0].isUpperCase() && positionInQuery > 0) {
            score += 6
        }
        return score
    }

    /**
     * Expand a query into up to [maxVariants] variants, ordered and
     * weighted by expected usefulness. The original query is always
     * first with weight 1.0.
     *
     * ## Why this replaced the v4.7.x depth-first loop
     *
     * The old implementation walked token positions left-to-right and
     * emitted every synonym of the first match before moving on,
     * stopping at the cap. For "Why did God send Jesus" with a budget
     * of 8 that produced:
     *
     * ```
     * purpose did God send Jesus     ← garbage
     * reason did God send Jesus      ← garbage
     * intent did God send Jesus      ← garbage
     * intention did God send Jesus   ← garbage
     * Why did jehovah send Jesus     ← good
     * Why did yahweh send Jesus
     * Why did almighty send Jesus
     * ```
     *
     * Half the budget went to a stopword, and the single most valuable
     * substitution — Jesus → Christ / Messiah, the phrasing the user's
     * own library actually uses — was never reached because the budget
     * ran out one position short.
     *
     * The replacement:
     *   1. Skips function words entirely.
     *   2. Ranks substitutable positions by [informativeness].
     *   3. Allocates the budget **round-robin** across positions, so
     *      every meaningful term gets its best synonym before any term
     *      gets its second-best.
     *   4. Spends any leftover budget on **paired** substitutions of
     *      the top two positions, which is how canonical phrasings like
     *      "Why did Jehovah send Christ" become reachable at all.
     *
     * Weights decay with each round and drop further for paired
     * substitutions, so downstream fusion can trust a first-round swap
     * of a proper noun more than a third-round swap of a common verb.
     */
    fun expandWeighted(query: String, maxVariants: Int = 8): List<WeightedQuery> {
        val trimmed = query.trim()
        if (trimmed.isEmpty()) return emptyList()
        val tokens = trimmed.split(Regex("\\s+")).filter { it.isNotEmpty() }
        if (tokens.isEmpty()) return emptyList()
        val original = tokens.joinToString(" ")

        val out = LinkedHashMap<String, Double>()
        out[original] = 1.0
        if (maxVariants <= 1) return out.map { WeightedQuery(it.key, it.value) }

        // Build the substitutable slots.
        data class Slot(val index: Int, val score: Int, val subs: List<String>)
        val slots = ArrayList<Slot>()
        for ((i, token) in tokens.withIndex()) {
            val score = informativeness(token, i)
            if (score < 0) continue
            val norm = normalizeToken(token)
            val group = tokenIndex[norm] ?: continue
            val subs = group.filter { !it.equals(norm, ignoreCase = true) }
            if (subs.isEmpty()) continue
            slots.add(Slot(i, score, subs))
        }
        if (slots.isEmpty()) return out.map { WeightedQuery(it.key, it.value) }
        slots.sortByDescending { it.score }

        // ── Round-robin single substitutions ──
        val deepest = slots.maxOf { it.subs.size }
        roundRobin@ for (round in 0 until deepest) {
            for (slot in slots) {
                if (out.size >= maxVariants) break@roundRobin
                val sub = slot.subs.getOrNull(round) ?: continue
                val rebuilt = tokens.toMutableList()
                rebuilt[slot.index] = sub
                val weight = (SINGLE_SUB_WEIGHT - round * ROUND_DECAY)
                    .coerceAtLeast(MIN_VARIANT_WEIGHT)
                out.putIfAbsent(rebuilt.joinToString(" "), weight)
            }
        }

        // ── Paired substitution of the two most informative slots ──
        if (out.size < maxVariants && slots.size >= 2) {
            val first = slots[0]
            val second = slots[1]
            paired@ for (a in first.subs.take(PAIR_DEPTH)) {
                for (b in second.subs.take(PAIR_DEPTH)) {
                    if (out.size >= maxVariants) break@paired
                    val rebuilt = tokens.toMutableList()
                    rebuilt[first.index] = a
                    rebuilt[second.index] = b
                    out.putIfAbsent(rebuilt.joinToString(" "), PAIR_SUB_WEIGHT)
                }
            }
        }

        return out.map { WeightedQuery(it.key, it.value) }
    }

    /**
     * Backwards-compatible text-only view of [expandWeighted]. The
     * original query is still element 0.
     */
    fun expand(query: String, maxVariants: Int = 8): List<String> =
        expandWeighted(query, maxVariants).map { it.text }

    /**
     * True when [a] and [b] belong to the same synonym group — i.e. one
     * is an acceptable stand-in for the other in this domain. Used by
     * the LLM paraphrase validator to recognise that a rewrite saying
     * "Jehovah" is still on-topic for a query that said "God".
     */
    fun areSynonyms(a: String, b: String): Boolean {
        val na = normalizeToken(a)
        val nb = normalizeToken(b)
        if (na == nb) return true
        val group = tokenIndex[na] ?: return false
        return nb in group
    }

    /**
     * Content-bearing tokens of a query: function words and very short
     * tokens removed. These are what topical-relevance checks compare.
     */
    fun contentTokens(text: String): List<String> =
        text.split(Regex("\\s+"))
            .map { normalizeToken(it) }
            .filter { it.length >= 3 && it !in functionWords }

    // Weight tuning. A first-round swap of the most informative term is
    // worth a good deal less than the user's own wording, and each
    // subsequent round is a weaker guess.
    private const val SINGLE_SUB_WEIGHT = 0.75
    private const val ROUND_DECAY = 0.08
    private const val PAIR_SUB_WEIGHT = 0.55
    private const val MIN_VARIANT_WEIGHT = 0.40
    private const val PAIR_DEPTH = 2

    /**
     * Levenshtein edit distance between two strings, capped at [maxDistance].
     * Returns [maxDistance] + 1 when the true distance exceeds the cap, so the
     * caller can early-reject without computing the full DP table.
     *
     * Used for fuzzy ranking — a query token that's within edit-distance 2 of
     * a word in the result's title earns a small score bonus.
     */
    fun editDistance(a: String, b: String, maxDistance: Int = 2): Int {
        val s = a.lowercase()
        val t = b.lowercase()
        if (s == t) return 0
        if (kotlin.math.abs(s.length - t.length) > maxDistance) return maxDistance + 1
        // Two-row rolling DP — uses O(min(n, m)) memory.
        val short = if (s.length <= t.length) s else t
        val long_ = if (s.length <= t.length) t else s
        var prev = IntArray(short.length + 1) { it }
        var curr = IntArray(short.length + 1)
        for (i in 1..long_.length) {
            curr[0] = i
            var rowMin = curr[0]
            for (j in 1..short.length) {
                val cost = if (long_[i - 1] == short[j - 1]) 0 else 1
                curr[j] = minOf(
                    curr[j - 1] + 1,
                    prev[j] + 1,
                    prev[j - 1] + cost
                )
                if (curr[j] < rowMin) rowMin = curr[j]
            }
            // Early exit: if no cell in this row is within the cap, the final
            // answer can only grow from here.
            if (rowMin > maxDistance) return maxDistance + 1
            val tmp = prev; prev = curr; curr = tmp
        }
        return prev[short.length]
    }

    /**
     * For a single result, compute a fuzzy-match score against [queryTokens].
     * The score is a small positive integer that the caller adds to the
     * baseline ranking score. The numbers below were picked so that an exact
     * match still dominates a near-match, but a "Jeohvah" query still surfaces
     * pages about Jehovah ahead of unrelated material.
     */
    fun fuzzyBoost(text: String, queryTokens: List<String>): Int {
        if (queryTokens.isEmpty() || text.isEmpty()) return 0
        val words = text.lowercase().split(Regex("\\W+")).filter { it.length >= 3 }
        if (words.isEmpty()) return 0
        var boost = 0
        for (q in queryTokens) {
            val ql = q.lowercase()
            if (ql.length < 3) continue
            // Quick win: contains-match. The baseline ranker already covers
            // this so we don't double-count too heavily.
            if (words.any { it == ql }) { boost += 30; continue }
            if (words.any { it.contains(ql) }) { boost += 15; continue }
            // Edit-distance 1 — likely typo
            if (words.any { editDistance(it, ql, 1) <= 1 }) { boost += 10; continue }
            // Edit-distance 2 — looser typo / variant
            if (words.any { editDistance(it, ql, 2) <= 2 }) { boost += 4 }
        }
        return boost
    }
}
