package com.tebogo.markvault.search

/**
 * Lightweight offline query expansion + fuzzy scoring layer.
 *
 * Two purposes:
 *
 *   1. **Synonym expansion** — when the user searches "Why did God send Jesus",
 *      we run the original query AND a handful of theologically-equivalent
 *      variants ("Why Jehovah sent his Son", "Why Christ was sent", etc.) and
 *      merge the result sets. This is the practical 80% of "semantic" search
 *      without shipping a 10MB embedding model. The synonym groups below
 *      reflect the way JW publications phrase these concepts.
 *
 *   2. **Fuzzy match scoring** — for ranking, we award a small bonus when a
 *      result's title contains a word that's within edit-distance 1–2 of any
 *      query token. This catches typos like "Jeohvah" → "Jehovah" without
 *      changing the query itself.
 *
 * Everything here is pure Kotlin, no native code, no model files, no network.
 * It runs in microseconds on a mid-range Android device.
 *
 * Architecture note: this file is intentionally NOT wired into the DAO
 * directly. The VM is the orchestration layer — it expands the query, runs
 * the existing `titleSearch` / `rankedContentSearch` against each variant,
 * unions the results, and then re-ranks using a blend of original score +
 * fuzzy boost. The DAO and existing search functions are untouched, so the
 * baseline path is byte-for-byte the same as before.
 */
object QueryExpander {

    /**
     * Theological & biblical synonym groups. Each set is a cluster of tokens
     * that are semantically interchangeable in the JW/biblical context.
     *
     * Add freely — at runtime the lookup is O(1) per token because we build
     * a reverse index from each token to its set.
     */
    private val synonymGroups: List<Set<String>> = listOf(
        // Divine persons
        setOf("god", "jehovah", "yahweh", "almighty", "creator", "lord"),
        setOf("jesus", "christ", "messiah", "son", "savior", "saviour", "redeemer", "lamb"),
        setOf("spirit", "ghost", "force"),  // holy spirit / active force
        setOf("satan", "devil", "adversary", "tempter"),
        setOf("angel", "angels", "messenger", "messengers", "heavenly"),

        // Bible / scripture
        setOf("bible", "scripture", "scriptures", "word"),
        setOf("verse", "passage", "text"),
        setOf("chapter", "psalm"),
        setOf("nwt", "translation"),

        // Verbs of choosing / sending
        setOf("chose", "choose", "chosen", "select", "selected", "called", "appointed", "elected"),
        setOf("sent", "send", "sending", "dispatched", "commissioned"),
        setOf("gave", "give", "given", "provided"),

        // Verbs of knowing / understanding
        setOf("understand", "understanding", "comprehend", "grasp", "know"),
        setOf("teach", "teaching", "instruct", "instruction", "educate", "learn"),
        setOf("explain", "explanation", "clarify"),

        // Why / purpose / reason
        setOf("why", "purpose", "reason", "intent", "intention"),
        setOf("how", "way", "manner", "method"),
        setOf("when", "time", "timing"),

        // Kingdom / governance
        setOf("kingdom", "rule", "ruling", "government", "sovereignty", "throne"),
        setOf("king", "ruler", "monarch", "sovereign"),

        // Worship
        setOf("worship", "praise", "honor", "honour", "glorify", "exalt"),
        setOf("pray", "prayer", "praying", "supplication", "petition"),
        setOf("serve", "service", "ministry"),

        // Death / hell / afterlife
        setOf("death", "die", "died", "dying", "deceased", "perished"),
        setOf("hell", "hades", "sheol", "grave", "tomb"),
        setOf("resurrection", "raised", "raising", "awaken", "awakened"),
        setOf("paradise", "heaven", "eternal", "everlasting", "endless"),
        setOf("life", "living", "alive"),

        // Sin / righteousness
        setOf("sin", "sins", "transgression", "wrongdoing", "evil", "iniquity"),
        setOf("righteous", "righteousness", "just", "justice", "upright"),
        setOf("forgive", "forgiveness", "pardon", "mercy"),

        // Love / faith / hope
        setOf("love", "agape", "lovingkindness", "loyal-love"),
        setOf("faith", "belief", "trust", "confidence"),
        setOf("hope", "expectation", "anticipation"),

        // Baptism / discipleship
        setOf("baptize", "baptism", "baptized", "baptised", "dedicated"),
        setOf("disciple", "follower", "follow", "following"),
        setOf("witness", "witnesses", "preach", "preaching", "testify"),

        // Last days / end
        setOf("end", "ending", "conclusion", "completion"),
        setOf("tribulation", "great-tribulation", "armageddon", "judgment", "judgement"),

        // People
        setOf("man", "men", "human", "humans", "mankind", "humankind", "people"),
        setOf("woman", "women", "wife", "wives", "female"),
        setOf("child", "children", "kids", "young", "youngsters", "youth"),
        setOf("brother", "brothers", "brethren", "sibling"),

        // Common patriarchs / figures often re-spelled
        setOf("abraham", "abram"),
        setOf("jacob", "israel"),
        setOf("paul", "saul"),
        setOf("peter", "cephas", "simon"),
    )

    // Reverse index: token → the set it belongs to. O(1) lookup at query time.
    private val tokenIndex: Map<String, Set<String>> by lazy {
        val m = HashMap<String, Set<String>>()
        for (group in synonymGroups) {
            for (token in group) m[token] = group
        }
        m
    }

    /**
     * Expand a query into up to [maxVariants] variants by single-token
     * substitution against the synonym groups.
     *
     * The original query is always the first element of the returned list.
     * Variants are deduplicated (set-then-list) so the caller doesn't have to.
     *
     * Strategy: keep it simple. For each token position, try every synonym
     * (including the original token), building variants depth-first and
     * stopping once we hit the cap. Multi-token substitution within a single
     * variant is NOT done — the combinatorial explosion isn't worth it for a
     * mobile device, and single-substitution already covers cases like
     * "Why did God send Jesus" → "Why did Jehovah send Jesus" /
     * "Why did God sent Jesus" / "Why did God send Christ" / etc.
     */
    fun expand(query: String, maxVariants: Int = 8): List<String> {
        val trimmed = query.trim()
        if (trimmed.isEmpty()) return emptyList()
        val tokens = trimmed.split(Regex("\\s+"))
        if (tokens.isEmpty()) return listOf(trimmed)
        val original = tokens.joinToString(" ")
        val variants = LinkedHashSet<String>()
        variants.add(original)
        // For each token position, swap in each synonym and emit the variant.
        outer@ for ((i, token) in tokens.withIndex()) {
            val group = tokenIndex[token.lowercase()] ?: continue
            for (syn in group) {
                if (syn.equals(token, ignoreCase = true)) continue
                val newTokens = tokens.toMutableList()
                // Preserve the user's capitalization style on the original token
                // by lowercasing the substitution (good enough for case-insensitive
                // search downstream).
                newTokens[i] = syn
                variants.add(newTokens.joinToString(" "))
                if (variants.size >= maxVariants) break@outer
            }
        }
        return variants.toList()
    }

    /**
     * Levenshtein edit distance between two strings, capped at [maxDistance].
     * Returns [maxDistance] + 1 when the true distance exceeds the cap, so the
     * caller can early-reject without computing the full DP table.
     *
     * Used for fuzzy ranking — a query token that's within edit-distance 2 of
     * a word in the result's title earns a small score bonus.
     */
    fun editDistance(a: String, b: String, maxDistance: Int = 2): Int {
        val s = a.lowercase()
        val t = b.lowercase()
        if (s == t) return 0
        if (kotlin.math.abs(s.length - t.length) > maxDistance) return maxDistance + 1
        // Two-row rolling DP — uses O(min(n, m)) memory.
        val short = if (s.length <= t.length) s else t
        val long_ = if (s.length <= t.length) t else s
        var prev = IntArray(short.length + 1) { it }
        var curr = IntArray(short.length + 1)
        for (i in 1..long_.length) {
            curr[0] = i
            var rowMin = curr[0]
            for (j in 1..short.length) {
                val cost = if (long_[i - 1] == short[j - 1]) 0 else 1
                curr[j] = minOf(
                    curr[j - 1] + 1,
                    prev[j] + 1,
                    prev[j - 1] + cost
                )
                if (curr[j] < rowMin) rowMin = curr[j]
            }
            // Early exit: if no cell in this row is within the cap, the final
            // answer can only grow from here.
            if (rowMin > maxDistance) return maxDistance + 1
            val tmp = prev; prev = curr; curr = tmp
        }
        return prev[short.length]
    }

    /**
     * For a single result, compute a fuzzy-match score against [queryTokens].
     * The score is a small positive integer that the caller adds to the
     * baseline ranking score. The numbers below were picked so that an exact
     * match still dominates a near-match, but a "Jeohvah" query still surfaces
     * pages about Jehovah ahead of unrelated material.
     */
    fun fuzzyBoost(text: String, queryTokens: List<String>): Int {
        if (queryTokens.isEmpty() || text.isEmpty()) return 0
        val words = text.lowercase().split(Regex("\\W+")).filter { it.length >= 3 }
        if (words.isEmpty()) return 0
        var boost = 0
        for (q in queryTokens) {
            val ql = q.lowercase()
            if (ql.length < 3) continue
            // Quick win: contains-match. The baseline ranker already covers
            // this so we don't double-count too heavily.
            if (words.any { it == ql }) { boost += 30; continue }
            if (words.any { it.contains(ql) }) { boost += 15; continue }
            // Edit-distance 1 — likely typo
            if (words.any { editDistance(it, ql, 1) <= 1 }) { boost += 10; continue }
            // Edit-distance 2 — looser typo / variant
            if (words.any { editDistance(it, ql, 2) <= 2 }) { boost += 4 }
        }
        return boost
    }
}
