package com.tebogo.markvault.search

/** JNI methods are kept in one class so native ownership is explicit. */
internal object NativeHnswBridge {
    val available: Boolean = runCatching { System.loadLibrary("markvault_hnsw") }.isSuccess
    external fun create(dim: Int, capacity: Int, mutableIndex: Boolean): Long
    external fun close(handle: Long)
    external fun open(handle: Long, path: String, offset: Long, mutableIndex: Boolean)
    external fun reserve(handle: Long, capacity: Int)
    external fun add(handle: Long, key: Long, blob: ByteArray)
    external fun remove(handle: Long, key: Long)
    external fun size(handle: Long): Long
    external fun serializedLength(handle: Long): Long
    external fun append(handle: Long, path: String)
    external fun keys(handle: Long): LongArray
    external fun search(handle: Long, query: FloatArray, wanted: Int, allowedIds: LongArray?): LongArray
    external fun findArticles(handle: Long, query: FloatArray, wanted: Int, minimum: Int, allowedIds: LongArray?): LongArray
}
