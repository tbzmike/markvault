package com.tebogo.markvault.search

/**
 * v5.5.23 — Where an actually-issued retrieval query came from.
 *
 * This is deliberately separate from the Room [com.tebogo.markvault.data.SearchHit]
 * projection.  Provenance belongs to one search execution, not to a note stored in
 * the database, and keeping it here prevents Room/KSP from treating audit fields as
 * columns returned by every search DAO query.
 */
enum class ResultQuerySource {
    ORIGINAL,
    QUESTION_AWARENESS,
    SYNONYM,
    LLM,
    T5;

    val displayName: String
        get() = when (this) {
            ORIGINAL -> "Original query"
            QUESTION_AWARENESS -> "Question Awareness"
            SYNONYM -> "Built-in expansion"
            LLM -> "LLM expansion"
            T5 -> "T5 expansion"
        }

    companion object {
        fun fromStoredName(raw: String): ResultQuerySource =
            entries.firstOrNull { it.name == raw } ?: SYNONYM
    }
}

/**
 * One query that genuinely retrieved/contributed to one result.
 *
 * [contribution] is the retrieval/fusion-stage evidence strength on a bounded
 * 0..1 scale. It is captured before the optional cross-encoder reranker. The
 * reranker may change final position, but never rewrites this evidence.
 */
data class QueryContribution(
    val queryId: String,
    val queryText: String,
    val source: ResultQuerySource,
    /** Null only for the user's original query; generated queries are 1-based. */
    val expansionNumber: Int? = null,
    val keyword: Boolean = false,
    val semantic: Boolean = false,
    val contribution: Double = 0.0,
    val queryWeight: Double = 1.0,
    /** Best (lowest) 1-based rank at which this query retrieved the article. */
    val keywordRank: Int? = null,
    /** Best (lowest) 1-based rank in semantic retrieval for this query. */
    val semanticRank: Int? = null
) {
    val isOriginal: Boolean get() = source == ResultQuerySource.ORIGINAL

    val retrievalPathCount: Int
        get() = (if (keyword) 1 else 0) + (if (semantic) 1 else 0)

    val retrievalPathLabel: String
        get() = when {
            keyword && semantic -> "Keyword + semantic"
            semantic -> "Semantic"
            keyword -> "Keyword"
            else -> "Retrieval path unavailable"
        }

    val displayLabel: String
        get() = expansionNumber?.let { "Expansion $it" } ?: "Original query"
}

/**
 * Complete retrieval provenance for one final result.
 *
 * [primaryQueryId] is persisted explicitly rather than re-inferred from the
 * final reranked position. [contributions] contains every original/generated
 * query that actually surfaced the article.
 */
data class ResultQueryProvenance(
    val primaryQueryId: String,
    val contributions: List<QueryContribution>
) {
    val primary: QueryContribution?
        get() = contributions.firstOrNull { it.queryId == primaryQueryId }
            ?: contributions.maxWithOrNull(
                compareBy<QueryContribution> { it.contribution }
                    .thenBy { it.retrievalPathCount }
                    .thenBy { it.queryWeight }
                    .thenBy { if (it.isOriginal) 1 else 0 }
            )

    val orderedContributions: List<QueryContribution>
        get() {
            val strongest = primary
            return contributions.sortedWith(
                compareByDescending<QueryContribution> { it.queryId == strongest?.queryId }
                    .thenByDescending { it.contribution }
                    .thenBy { it.expansionNumber ?: Int.MIN_VALUE }
            )
        }
}
