package com.tebogo.markvault.ui

/** Per-gesture bookkeeping is not Compose state; only a visibility transition updates the UI. */
class SearchScrollTracker(initialIndex: Int, initialOffset: Int) {
    private var lastIndex = initialIndex
    private var lastOffset = initialOffset
    private var downward = 0
    private var upward = 0

    fun update(index: Int, offset: Int, expanded: Boolean, changedAt: Long, now: Long): Boolean? {
        val atTop = index == 0 && offset < 4
        val downDelta = when {
            index > lastIndex -> 32
            index == lastIndex && offset > lastOffset -> offset - lastOffset
            else -> 0
        }
        val upDelta = when {
            index < lastIndex -> 32
            index == lastIndex && offset < lastOffset -> lastOffset - offset
            else -> 0
        }
        lastIndex = index
        lastOffset = offset
        val settling = now - changedAt < 320L
        when {
            atTop -> {
                downward = 0
                upward = 0
                if (!expanded && !settling) return true
            }
            settling -> { downward = 0; upward = 0 }
            downDelta > 0 -> {
                downward = (downward + downDelta).coerceAtMost(96)
                upward = 0
                if (downward >= 24 && expanded) {
                    downward = 0
                    return false
                }
            }
            upDelta > 0 -> {
                upward = (upward + upDelta).coerceAtMost(96)
                downward = 0
                if (upward >= 18 && !expanded) return true
            }
        }
        return null
    }
}
