package com.tebogo.markvault.ui

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.navigation.NavController
import com.tebogo.markvault.AppViewModel
import com.tebogo.markvault.data.NoteMeta

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun WorkspaceDataViewScreen(vm: AppViewModel, nav: NavController) {
    val notes by vm.notes.collectAsStateWithLifecycle()
    var query by remember { mutableStateOf("") }
    var folder by remember { mutableStateOf("") }
    var type by remember { mutableStateOf("all") }
    var date by remember { mutableStateOf("any") }
    var sort by remember { mutableStateOf("title") }

    val shown = remember(notes, query, folder, type, date, sort) {
        val terms = query.trim().split(Regex("\\s+")).filter { it.isNotBlank() }
        val now = System.currentTimeMillis()
        val minDate = when (date) {
            "7d" -> now - 7L * 86400000L
            "30d" -> now - 30L * 86400000L
            "365d" -> now - 365L * 86400000L
            else -> 0L
        }
        val seq = notes.asSequence().filter { n ->
            val hay = "${n.title} ${n.folder} ${n.relPath}"
            (type == "all" || n.fileType.equals(type, true)) &&
                (folder.isBlank() || n.folder.contains(folder.trim(), true)) &&
                (minDate == 0L || n.lastModified >= minDate) &&
                terms.all { hay.contains(it, true) }
        }
        when (sort) {
            "newest" -> seq.sortedByDescending { it.lastModified }
            "oldest" -> seq.sortedBy { it.lastModified }
            "folder" -> seq.sortedWith(compareBy<NoteMeta> { it.folder.lowercase() }.thenBy { it.title.lowercase() })
            else -> seq.sortedBy { it.title.lowercase() }
        }.take(3000).toList()
    }

    Scaffold(topBar = {
        TopAppBar(
            title = { Text("Data Views") },
            navigationIcon = {
                IconButton(onClick = { nav.popBackStack() }) {
                    Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back")
                }
            }
        )
    }) { pad ->
        Column(Modifier.fillMaxSize().padding(pad)) {
            OutlinedTextField(query, { query = it }, Modifier.fillMaxWidth().padding(horizontal = 10.dp, vertical = 4.dp), singleLine = true, label = { Text("AND search terms") })
            OutlinedTextField(folder, { folder = it }, Modifier.fillMaxWidth().padding(horizontal = 10.dp, vertical = 4.dp), singleLine = true, label = { Text("Folder contains") })
            Row(Modifier.fillMaxWidth().padding(horizontal = 8.dp)) {
                listOf("all","md","pdf","html").forEach { v ->
                    FilterChip(type == v, { type = v }, { Text(v.uppercase()) }, Modifier.padding(horizontal = 2.dp))
                }
            }
            Row(Modifier.fillMaxWidth().padding(horizontal = 8.dp)) {
                listOf("any","7d","30d","365d").forEach { v ->
                    FilterChip(date == v, { date = v }, { Text(v) }, Modifier.padding(horizontal = 2.dp))
                }
            }
            Row(Modifier.fillMaxWidth().padding(horizontal = 8.dp)) {
                listOf("title","newest","oldest","folder").forEach { v ->
                    FilterChip(sort == v, { sort = v }, { Text(v) }, Modifier.padding(horizontal = 2.dp))
                }
            }
            Text("${shown.size} matching notes", Modifier.padding(horizontal = 12.dp, vertical = 5.dp), style = MaterialTheme.typography.labelMedium)
            LazyColumn(Modifier.fillMaxSize()) {
                items(shown, key = { it.id }) { note ->
                    Column(
                        Modifier.fillMaxWidth().clickable {
                            vm.openArticle(note.id, note.title, fileType = note.fileType)
                            when (note.fileType.lowercase()) {
                                "pdf" -> nav.navigate("pdfReader/${note.id}")
                                "html", "htm", "mhtml", "mht" -> nav.navigate("htmlReader/${note.id}")
                                else -> nav.navigate("reader") { launchSingleTop = true }
                            }
                        }.padding(horizontal = 12.dp, vertical = 8.dp)
                    ) {
                        Text(note.title, fontWeight = FontWeight.Medium, maxLines = 1, overflow = TextOverflow.Ellipsis)
                        Text("${note.folder.ifBlank { "Vault" }} · ${note.fileType}", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                    HorizontalDivider()
                }
            }
        }
    }
}
