package com.tebogo.markvault.util

/**
 * v5.4.205cc — Scripture detection utilities for MarkVault's offline NWT integration.
 *
 * Key changes from v5.4.183cc:
 *   • verseHighlightJs now highlights ALL verses in a range/list simultaneously
 *     and the highlight is PERMANENT (no fadeout setTimeout).
 *   • scriptureDetectionJs regex captures full verse references including ranges
 *     (23:7-9) and comma lists (23:8,10), encoding the full ref in the URL.
 *   • parseScriptureUri returns Triple<Int,Int,String> (String = raw verse ref).
 *   • buildVerseAnchors expands a verse ref string into a list of WOL anchor IDs.
 *   • parseQueryAsScripture captures multi-verse refs from the search query.
 *   • firstVerseOf extracts the leading verse number from any ref string.
 */
object ScriptureDetector {

    const val SCHEME = "markvault"
    const val HOST   = "scripture"

    /**
     * Parse a `markvault://scripture/{bookNum}/{chapter}/{verseRef}` URI.
     * verseRef may be a single verse ("14"), a range ("7-9"), a list ("8,10"),
     * or a combined form ("7-9,12"). Returns null if URI doesn't match.
     */
    fun parseScriptureUri(uri: android.net.Uri): Triple<Int, Int, String>? {
        if (uri.scheme != SCHEME || uri.host != HOST) return null
        val segments = uri.pathSegments
        if (segments.size < 3) return null
        val b = segments[0].toIntOrNull() ?: return null
        val c = segments[1].toIntOrNull() ?: return null
        val v = segments[2].ifBlank { "1" }
        return Triple(b, c, v)
    }

    /**
     * Expand a verse reference string into a sorted list of WOL anchor IDs.
     * Examples:
     *   "14"     → ["v40-24-14-1"]
     *   "7-9"    → ["v40-23-7-1","v40-23-8-1","v40-23-9-1"]
     *   "8,10"   → ["v40-23-8-1","v40-23-10-1"]
     *   "7-9,12" → ["v40-23-7-1","v40-23-8-1","v40-23-9-1","v40-23-12-1"]
     */
    fun buildVerseAnchors(bookNum: Int, chapter: Int, verseRef: String): List<String> {
        val verses = linkedSetOf<Int>()
        val dashRe = Regex("[-\u2013\u2014]")     // dash, en-dash, em-dash
        verseRef.split(",").forEach { segment ->
            val part = segment.trim()
            if (dashRe.containsMatchIn(part)) {
                val nums = dashRe.split(part).mapNotNull { it.trim().toIntOrNull() }
                if (nums.size >= 2) (nums[0]..nums[1]).forEach { verses.add(it) }
            } else {
                part.toIntOrNull()?.let { verses.add(it) }
            }
        }
        return verses.sorted().map { buildVerseAnchor(bookNum, chapter, it) }
    }

    /** Construct the WOL verse anchor id: `v{bookNum}-{chapter}-{verse}-1` */
    fun buildVerseAnchor(bookNum: Int, chapter: Int, verse: Int): String =
        "v$bookNum-$chapter-$verse-1"

    /** Extract the first (leading) verse number from any verse ref string. */
    fun firstVerseOf(verseRef: String): Int =
        verseRef.split(",").firstOrNull()
            ?.split(Regex("[-\u2013\u2014]"))?.firstOrNull()
            ?.trim()?.toIntOrNull() ?: 1

    fun buildNwtFileName(bookName: String, chapter: Int): String {
        val formatted = bookName.split(" ").joinToString("_") { w ->
            if (w.all { it.isDigit() }) w else w.replaceFirstChar { it.uppercaseChar() }
        }
        return "${formatted}_${chapter}___Watchtower_ONLINE_LIBRARY"
    }

    val BOOK_NAME_TO_NUMBER: Map<String, Int> = mapOf(
        "genesis" to 1, "exodus" to 2, "leviticus" to 3, "numbers" to 4,
        "deuteronomy" to 5, "joshua" to 6, "judges" to 7, "ruth" to 8,
        "1 samuel" to 9, "2 samuel" to 10, "1 kings" to 11, "2 kings" to 12,
        "1 chronicles" to 13, "2 chronicles" to 14,
        "ezra" to 15, "nehemiah" to 16, "esther" to 17, "job" to 18,
        "psalm" to 19, "psalms" to 19, "proverbs" to 20, "ecclesiastes" to 21,
        "song of solomon" to 22, "song of songs" to 22,
        "isaiah" to 23, "jeremiah" to 24, "lamentations" to 25,
        "ezekiel" to 26, "daniel" to 27,
        "hosea" to 28, "joel" to 29, "amos" to 30, "obadiah" to 31,
        "jonah" to 32, "micah" to 33, "nahum" to 34, "habakkuk" to 35,
        "zephaniah" to 36, "haggai" to 37, "zechariah" to 38, "malachi" to 39,
        "matthew" to 40, "mark" to 41, "luke" to 42, "john" to 43,
        "acts" to 44, "romans" to 45,
        "1 corinthians" to 46, "2 corinthians" to 47,
        "galatians" to 48, "ephesians" to 49, "philippians" to 50,
        "colossians" to 51, "1 thessalonians" to 52, "2 thessalonians" to 53,
        "1 timothy" to 54, "2 timothy" to 55,
        "titus" to 56, "philemon" to 57, "hebrews" to 58, "james" to 59,
        "1 peter" to 60, "2 peter" to 61,
        "1 john" to 62, "2 john" to 63, "3 john" to 64,
        "jude" to 65, "revelation" to 66
    )

    /**
     * v5.4.205cc — Parse a search query for a scripture reference that may include
     * ranges (24:7-9) or comma lists (23:8,10). Returns (bookNum, chapter, verseRef)
     * where verseRef is the raw string — pass to buildVerseAnchors() for anchor IDs.
     */
    fun parseQueryAsScripture(query: String): Triple<Int, Int, String>? {
        val clean = query.trim().removePrefix("\"").removeSuffix("\"").trim()
        val pattern = Regex(
            """^((?:\d\s+)?[A-Za-z]+(?:\s+[A-Za-z]+)*)\s+(\d{1,3}):([\d,\-–—\s]+)""",
            RegexOption.IGNORE_CASE
        )
        val m = pattern.find(clean) ?: return null
        val bookRaw = m.groupValues[1].trim().replace(Regex("""\s+"""), " ").lowercase()
        val chapter  = m.groupValues[2].toIntOrNull() ?: return null
        val verseRef = m.groupValues[3].trim()
        val bookNum  = BOOK_NAME_TO_NUMBER[bookRaw] ?: return null
        return Triple(bookNum, chapter, verseRef)
    }

    val BOOK_NAME_FOR_NUMBER: Map<Int, String> = mapOf(
        1 to "Genesis", 2 to "Exodus", 3 to "Leviticus", 4 to "Numbers",
        5 to "Deuteronomy", 6 to "Joshua", 7 to "Judges", 8 to "Ruth",
        9 to "1 Samuel", 10 to "2 Samuel", 11 to "1 Kings", 12 to "2 Kings",
        13 to "1 Chronicles", 14 to "2 Chronicles",
        15 to "Ezra", 16 to "Nehemiah", 17 to "Esther", 18 to "Job",
        19 to "Psalm", 20 to "Proverbs", 21 to "Ecclesiastes",
        22 to "Song of Solomon",
        23 to "Isaiah", 24 to "Jeremiah", 25 to "Lamentations",
        26 to "Ezekiel", 27 to "Daniel",
        28 to "Hosea", 29 to "Joel", 30 to "Amos", 31 to "Obadiah",
        32 to "Jonah", 33 to "Micah", 34 to "Nahum", 35 to "Habakkuk",
        36 to "Zephaniah", 37 to "Haggai", 38 to "Zechariah", 39 to "Malachi",
        40 to "Matthew", 41 to "Mark", 42 to "Luke", 43 to "John",
        44 to "Acts", 45 to "Romans",
        46 to "1 Corinthians", 47 to "2 Corinthians",
        48 to "Galatians", 49 to "Ephesians", 50 to "Philippians",
        51 to "Colossians", 52 to "1 Thessalonians", 53 to "2 Thessalonians",
        54 to "1 Timothy", 55 to "2 Timothy",
        56 to "Titus", 57 to "Philemon", 58 to "Hebrews", 59 to "James",
        60 to "1 Peter", 61 to "2 Peter",
        62 to "1 John", 63 to "2 John", 64 to "3 John",
        65 to "Jude", 66 to "Revelation"
    )

    /**
     * JavaScript injected into article WebViews to detect and link scripture references.
     *
     * v5.4.205cc changes:
     *   • Regex now captures the FULL verse reference including ranges (7-9) and
     *     comma lists (8,10) — encoded as-is in the markvault://scripture URL.
     *   • href uses the raw verseRef string: markvault://scripture/40/23/8,10
     */
    val scriptureDetectionJs: String = """
(function() {
  if (window.__mvScriptureDetected) return;
  window.__mvScriptureDetected = true;

  var BOOK_MAP = {
    "genesis":1,"exodus":2,"leviticus":3,"numbers":4,"deuteronomy":5,
    "joshua":6,"judges":7,"ruth":8,
    "1 samuel":9,"2 samuel":10,"1 kings":11,"2 kings":12,
    "1 chronicles":13,"2 chronicles":14,
    "ezra":15,"nehemiah":16,"esther":17,"job":18,
    "psalm":19,"psalms":19,"proverbs":20,"ecclesiastes":21,
    "song of solomon":22,"song of songs":22,
    "isaiah":23,"jeremiah":24,"lamentations":25,"ezekiel":26,"daniel":27,
    "hosea":28,"joel":29,"amos":30,"obadiah":31,"jonah":32,"micah":33,
    "nahum":34,"habakkuk":35,"zephaniah":36,"haggai":37,"zechariah":38,"malachi":39,
    "matthew":40,"mark":41,"luke":42,"john":43,
    "acts":44,"romans":45,
    "1 corinthians":46,"2 corinthians":47,
    "galatians":48,"ephesians":49,"philippians":50,"colossians":51,
    "1 thessalonians":52,"2 thessalonians":53,
    "1 timothy":54,"2 timothy":55,
    "titus":56,"philemon":57,"hebrews":58,"james":59,
    "1 peter":60,"2 peter":61,
    "1 john":62,"2 john":63,"3 john":64,
    "jude":65,"revelation":66
  };

  /* Full verse ref: captures single verse, range (7-9), list (8,10), combined (7-9,12). */
  var RE = /\b(Genesis|Exodus|Leviticus|Numbers|Deuteronomy|Joshua|Judges|Ruth|1\s*Samuel|2\s*Samuel|1\s*Kings|2\s*Kings|1\s*Chronicles|2\s*Chronicles|Ezra|Nehemiah|Esther|Job|Psalms?|Proverbs|Ecclesiastes|Song\s*of\s*Solomon|Song\s*of\s*Songs|Isaiah|Jeremiah|Lamentations|Ezekiel|Daniel|Hosea|Joel|Amos|Obadiah|Jonah|Micah|Nahum|Habakkuk|Zephaniah|Haggai|Zechariah|Malachi|Matthew|Mark|Luke|John|Acts|Romans|1\s*Corinthians|2\s*Corinthians|Galatians|Ephesians|Philippians|Colossians|1\s*Thessalonians|2\s*Thessalonians|1\s*Timothy|2\s*Timothy|Titus|Philemon|Hebrews|James|1\s*Peter|2\s*Peter|1\s*John|2\s*John|3\s*John|Jude|Revelation)\s+(\d{1,3})(?::(\d{1,3}(?:[-\u2013\u2014]\d{1,3})?(?:,\s*\d{1,3}(?:[-\u2013\u2014]\d{1,3})?)*))?/gi;

  function bookNum(name) {
    var key = name.toLowerCase().replace(/\s+/g, ' ');
    key = key.replace('psalms', 'psalm');
    return BOOK_MAP[key] || 0;
  }

  function processText(node) {
    var text = node.nodeValue;
    if (!text || text.trim().length < 4) return;
    RE.lastIndex = 0;
    if (!RE.test(text)) return;
    RE.lastIndex = 0;
    var frag = document.createDocumentFragment();
    var last = 0, m;
    while ((m = RE.exec(text)) !== null) {
      var bn = bookNum(m[1]);
      if (bn === 0) continue;
      var ch = parseInt(m[2], 10);
      /* Encode the full verse ref (range/list) — strip spaces so URL is clean */
      var verseRef = m[3] ? m[3].replace(/\s+/g, '') : '1';
      if (m.index > last) frag.appendChild(document.createTextNode(text.slice(last, m.index)));
      var a = document.createElement('a');
      a.href = 'markvault://scripture/' + bn + '/' + ch + '/' + verseRef;
      a.textContent = m[0];
      a.style.cssText =
        'color:#D4A017;font-weight:600;text-decoration:underline;' +
        'text-decoration-color:rgba(212,160,23,0.5);cursor:pointer;' +
        'border-bottom:1px solid rgba(212,160,23,0.4);';
      a.title = 'Open in offline NWT';
      frag.appendChild(a);
      last = m.index + m[0].length;
    }
    if (last === 0) return;
    if (last < text.length) frag.appendChild(document.createTextNode(text.slice(last)));
    if (node.parentNode) node.parentNode.replaceChild(frag, node);
  }

  function walk(root) {
    var walker = document.createTreeWalker(root, NodeFilter.SHOW_TEXT, {
      acceptNode: function(n) {
        var tag = n.parentElement ? n.parentElement.tagName.toUpperCase() : '';
        if (tag === 'A' || tag === 'SCRIPT' || tag === 'STYLE' ||
            tag === 'CODE' || tag === 'PRE') return NodeFilter.FILTER_REJECT;
        return NodeFilter.FILTER_ACCEPT;
      }
    }, false);
    var nodes = [];
    var n;
    while ((n = walker.nextNode())) nodes.push(n);
    nodes.forEach(processText);
  }

  if (document.body) walk(document.body);
})();
""".trimIndent()

    /**
     * v5.4.205cc — Highlights ALL verses in __ANCHOR__ (comma-separated anchor IDs).
     *
     * PERMANENT highlight — no fadeout. Scrolls to the first verse in the set.
     * Handles single verses, ranges (7-9 → 3 anchors), and lists (8,10 → 2 anchors).
     *
     * Usage:
     *   val js = verseHighlightJs.replace("__ANCHOR__", anchors.joinToString(","))
     *   view.evaluateJavascript(js, null)
     */
    const val verseHighlightJs: String = """
(function() {
  var ids = '__ANCHOR__'.split(',');
  var scrolled = false;
  ids.forEach(function(rawId) {
    var anchorId = rawId.trim();
    if (!anchorId) return;
    var el = document.getElementById(anchorId);
    if (!el) el = document.querySelector('[id^="' + anchorId + '"]');
    if (!el) return;
    if (!scrolled) {
      el.scrollIntoView({behavior:'smooth', block:'center'});
      scrolled = true;
    }
    /* Permanent amber highlight — no setTimeout removal */
    el.style.backgroundColor = 'rgba(212,160,23,0.40)';
    el.style.borderRadius    = '4px';
    el.style.padding         = '2px 4px';
    el.style.boxShadow       = '0 0 0 2px rgba(212,160,23,0.25)';
    el.style.transition      = 'none';
  });
})();
"""
}
