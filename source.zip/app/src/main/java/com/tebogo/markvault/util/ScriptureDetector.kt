package com.tebogo.markvault.util

/**
 * v5.4.183cc — Scripture detection utilities for MarkVault's offline NWT integration.
 *
 * Provides:
 *   • [scriptureDetectionJs] — JavaScript injected into WebViews to wrap detected
 *     scripture references (e.g. "Matthew 23:8") in golden amber links that open
 *     the matching offline NWT chapter file via the markvault://scripture/ URL scheme.
 *   • [verseHighlightJs] — JavaScript to scroll-to and flash-highlight a verse element
 *     by its WOL anchor id (e.g. "v40-23-8-1") after navigation.
 *   • [buildVerseAnchor] — Constructs the WOL verse element id.
 *   • [buildNwtFileName] — Builds the expected offline file name prefix.
 *   • [BOOK_NAME_FOR_NUMBER] — Reverse map: book number → canonical book name.
 *
 * Escaping note: scriptureDetectionJs uses a JavaScript REGEX LITERAL (/pattern/gi)
 * rather than new RegExp("string") to avoid the double-escaping complexity of
 * Kotlin triple-quoted strings → JS string literals → RegExp patterns. In a regex
 * literal inside a Kotlin triple-quoted string, one backslash (e.g. \b, \s, \d)
 * is the correct form — no extra escaping layer is needed.
 */
object ScriptureDetector {

    /** URL scheme used by scripture links injected into WebViews. */
    const val SCHEME = "markvault"
    /** Host part of the scripture URL. */
    const val HOST = "scripture"

    /**
     * Parse a `markvault://scripture/{bookNum}/{chapter}/{verse}` URI into its parts.
     * Returns null if the URI doesn't match the expected scheme/host/path.
     */
    fun parseScriptureUri(uri: android.net.Uri): Triple<Int, Int, Int>? {
        if (uri.scheme != SCHEME || uri.host != HOST) return null
        val segments = uri.pathSegments
        if (segments.size < 3) return null
        val b = segments[0].toIntOrNull() ?: return null
        val c = segments[1].toIntOrNull() ?: return null
        val v = segments[2].toIntOrNull() ?: return null
        return Triple(b, c, v)
    }

    /**
     * Construct the WOL verse anchor id used in offline NWT chapter HTML files.
     * Pattern: `v{bookNum}-{chapter}-{verse}-1`
     * Example: Matthew 23:8 → "v40-23-8-1"
     */
    fun buildVerseAnchor(bookNum: Int, chapter: Int, verse: Int): String =
        "v$bookNum-$chapter-$verse-1"

    /**
     * Build the expected filename prefix for an offline WOL NWT chapter file.
     * Pattern: `{BookName}_{chapter}___Watchtower_ONLINE_LIBRARY`
     * Examples:
     *   Genesis 45          → "Genesis_45___Watchtower_ONLINE_LIBRARY"
     *   1 Corinthians 15    → "1_Corinthians_15___Watchtower_ONLINE_LIBRARY"
     *   Song of Solomon 3   → "Song_of_Solomon_3___Watchtower_ONLINE_LIBRARY"
     */
    fun buildNwtFileName(bookName: String, chapter: Int): String {
        val formatted = bookName.split(" ").joinToString("_") { w ->
            if (w.all { it.isDigit() }) w
            else w.replaceFirstChar { it.uppercaseChar() }
        }
        return "${formatted}_${chapter}___Watchtower_ONLINE_LIBRARY"
    }

    /** Reverse map: canonical book number (1–66) → canonical book name. */
    val BOOK_NAME_FOR_NUMBER: Map<Int, String> = mapOf(
        1 to "Genesis", 2 to "Exodus", 3 to "Leviticus", 4 to "Numbers",
        5 to "Deuteronomy", 6 to "Joshua", 7 to "Judges", 8 to "Ruth",
        9 to "1 Samuel", 10 to "2 Samuel", 11 to "1 Kings", 12 to "2 Kings",
        13 to "1 Chronicles", 14 to "2 Chronicles",
        15 to "Ezra", 16 to "Nehemiah", 17 to "Esther", 18 to "Job",
        19 to "Psalm", 20 to "Proverbs", 21 to "Ecclesiastes",
        22 to "Song of Solomon",
        23 to "Isaiah", 24 to "Jeremiah", 25 to "Lamentations",
        26 to "Ezekiel", 27 to "Daniel",
        28 to "Hosea", 29 to "Joel", 30 to "Amos", 31 to "Obadiah",
        32 to "Jonah", 33 to "Micah", 34 to "Nahum", 35 to "Habakkuk",
        36 to "Zephaniah", 37 to "Haggai", 38 to "Zechariah", 39 to "Malachi",
        40 to "Matthew", 41 to "Mark", 42 to "Luke", 43 to "John",
        44 to "Acts", 45 to "Romans",
        46 to "1 Corinthians", 47 to "2 Corinthians",
        48 to "Galatians", 49 to "Ephesians", 50 to "Philippians",
        51 to "Colossians", 52 to "1 Thessalonians", 53 to "2 Thessalonians",
        54 to "1 Timothy", 55 to "2 Timothy",
        56 to "Titus", 57 to "Philemon", 58 to "Hebrews", 59 to "James",
        60 to "1 Peter", 61 to "2 Peter",
        62 to "1 John", 63 to "2 John", 64 to "3 John",
        65 to "Jude", 66 to "Revelation"
    )

    /**
     * JavaScript injected into article WebViews when scripture detection is ON.
     *
     * Uses a JavaScript REGEX LITERAL so that \b, \s, \d etc. are written with
     * exactly ONE backslash in the Kotlin triple-quoted string — no string-escaping
     * layer between Kotlin and the regex engine.
     *
     * The script walks all text nodes, wraps each scripture reference in a golden
     * amber <a href="markvault://scripture/bookNum/chapter/verse"> link, and guards
     * against double-injection with __mvScriptureDetected.
     */
    val scriptureDetectionJs: String = """
(function() {
  if (window.__mvScriptureDetected) return;
  window.__mvScriptureDetected = true;

  var BOOK_MAP = {
    "genesis":1,"exodus":2,"leviticus":3,"numbers":4,"deuteronomy":5,
    "joshua":6,"judges":7,"ruth":8,
    "1 samuel":9,"2 samuel":10,"1 kings":11,"2 kings":12,
    "1 chronicles":13,"2 chronicles":14,
    "ezra":15,"nehemiah":16,"esther":17,"job":18,
    "psalm":19,"psalms":19,"proverbs":20,"ecclesiastes":21,
    "song of solomon":22,"song of songs":22,
    "isaiah":23,"jeremiah":24,"lamentations":25,"ezekiel":26,"daniel":27,
    "hosea":28,"joel":29,"amos":30,"obadiah":31,"jonah":32,"micah":33,
    "nahum":34,"habakkuk":35,"zephaniah":36,"haggai":37,"zechariah":38,"malachi":39,
    "matthew":40,"mark":41,"luke":42,"john":43,
    "acts":44,"romans":45,
    "1 corinthians":46,"2 corinthians":47,
    "galatians":48,"ephesians":49,"philippians":50,"colossians":51,
    "1 thessalonians":52,"2 thessalonians":53,
    "1 timothy":54,"2 timothy":55,
    "titus":56,"philemon":57,"hebrews":58,"james":59,
    "1 peter":60,"2 peter":61,
    "1 john":62,"2 john":63,"3 john":64,
    "jude":65,"revelation":66
  };

  /* Regex literal — ONE backslash per metachar is correct here; no extra
     escaping layer because this is a JS regex literal, not a string arg. */
  var RE = /\b(Genesis|Exodus|Leviticus|Numbers|Deuteronomy|Joshua|Judges|Ruth|1\s*Samuel|2\s*Samuel|1\s*Kings|2\s*Kings|1\s*Chronicles|2\s*Chronicles|Ezra|Nehemiah|Esther|Job|Psalms?|Proverbs|Ecclesiastes|Song\s*of\s*Solomon|Song\s*of\s*Songs|Isaiah|Jeremiah|Lamentations|Ezekiel|Daniel|Hosea|Joel|Amos|Obadiah|Jonah|Micah|Nahum|Habakkuk|Zephaniah|Haggai|Zechariah|Malachi|Matthew|Mark|Luke|John|Acts|Romans|1\s*Corinthians|2\s*Corinthians|Galatians|Ephesians|Philippians|Colossians|1\s*Thessalonians|2\s*Thessalonians|1\s*Timothy|2\s*Timothy|Titus|Philemon|Hebrews|James|1\s*Peter|2\s*Peter|1\s*John|2\s*John|3\s*John|Jude|Revelation)\s+(\d{1,3})(?::(\d{1,3})(?:[-\u2013\u2014]\d{1,3})?)?/gi;

  function bookNum(name) {
    var key = name.toLowerCase().replace(/\s+/g, ' ');
    key = key.replace('psalms', 'psalm');
    return BOOK_MAP[key] || 0;
  }

  function processText(node) {
    var text = node.nodeValue;
    if (!text || text.trim().length < 4) return;
    RE.lastIndex = 0;
    if (!RE.test(text)) return;
    RE.lastIndex = 0;
    var frag = document.createDocumentFragment();
    var last = 0, m;
    while ((m = RE.exec(text)) !== null) {
      var bn = bookNum(m[1]);
      if (bn === 0) continue;
      var ch = parseInt(m[2], 10);
      var vs = m[3] ? parseInt(m[3], 10) : 1;
      if (m.index > last) frag.appendChild(document.createTextNode(text.slice(last, m.index)));
      var a = document.createElement('a');
      a.href = 'markvault://scripture/' + bn + '/' + ch + '/' + vs;
      a.textContent = m[0];
      a.style.cssText =
        'color:#D4A017;font-weight:600;text-decoration:underline;' +
        'text-decoration-color:rgba(212,160,23,0.5);cursor:pointer;' +
        'border-bottom:1px solid rgba(212,160,23,0.4);';
      a.title = 'Open in offline NWT';
      frag.appendChild(a);
      last = m.index + m[0].length;
    }
    if (last === 0) return;
    if (last < text.length) frag.appendChild(document.createTextNode(text.slice(last)));
    if (node.parentNode) node.parentNode.replaceChild(frag, node);
  }

  function walk(root) {
    var walker = document.createTreeWalker(root, NodeFilter.SHOW_TEXT, {
      acceptNode: function(n) {
        var tag = n.parentElement ? n.parentElement.tagName.toUpperCase() : '';
        if (tag === 'A' || tag === 'SCRIPT' || tag === 'STYLE' ||
            tag === 'CODE' || tag === 'PRE') return NodeFilter.FILTER_REJECT;
        return NodeFilter.FILTER_ACCEPT;
      }
    }, false);
    var nodes = [];
    var n;
    while ((n = walker.nextNode())) nodes.push(n);
    nodes.forEach(processText);
  }

  if (document.body) walk(document.body);
})();
""".trimIndent()

    /**
     * JavaScript that scrolls to a verse element by its WOL anchor id and briefly
     * highlights it with a pulsing amber glow.
     *
     * Usage:
     *   view.evaluateJavascript(verseHighlightJs.replace("__ANCHOR__", anchor), null)
     */
    const val verseHighlightJs: String = """
(function() {
  var el = document.getElementById('__ANCHOR__');
  if (!el) el = document.querySelector('[id^="__ANCHOR__"]');
  if (!el) return;
  el.scrollIntoView({behavior:'smooth', block:'center'});
  var orig = el.style.cssText || '';
  el.style.cssText += ';background-color:rgba(212,160,23,0.45);border-radius:4px;' +
    'padding:2px 4px;transition:background-color 0.4s ease;box-shadow:0 0 0 3px rgba(212,160,23,0.3);';
  setTimeout(function() {
    el.style.backgroundColor = 'rgba(212,160,23,0.15)';
    el.style.boxShadow = 'none';
  }, 1600);
  setTimeout(function() { el.style.cssText = orig; }, 4000);
})();
"""
}
