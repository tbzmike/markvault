package com.tebogo.markvault.ai

/** Maps trace data for query history display. */
object T5HistoryDisplayMapper {
    fun map(trace: T5QueryTrace): T5HistoryDetail {
        return T5HistoryDetail(
            query = "",
            expansion = trace.mode,
            generatedQueries = trace.generatedQueries,
            inferenceTimeMs = trace.inferenceTimeMs,
            fallbackReason = trace.fallbackReason
        )
    }
}
