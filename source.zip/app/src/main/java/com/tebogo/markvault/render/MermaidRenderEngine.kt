package com.tebogo.markvault.render

/**
 * Extended offline Mermaid rendering engine foundation.
 *
 * Supports:
 * - flowchart nodes
 * - rounded nodes
 * - decision nodes
 * - arrows
 * - styling metadata
 *
 * Output is SVG-ready for zoom/pan containers.
 */
object MermaidRenderEngine {

    data class Node(
        val id: String,
        val label: String,
        val shape: String = "rect"
    )

    data class Edge(
        val from: String,
        val to: String
    )

    data class Diagram(
        val nodes: List<Node>,
        val edges: List<Edge>
    )

    fun parse(code: String): Diagram {
        val nodes = mutableMapOf<String, Node>()
        val edges = mutableListOf<Edge>()

        code.lines().forEach { line ->
            val parts = line.split("-->")
            if (parts.size >= 2) {
                val from = parseNode(parts[0])
                val to = parseNode(parts[1])

                nodes[from.id] = from
                nodes[to.id] = to
                edges.add(Edge(from.id, to.id))
            }
        }

        return Diagram(nodes.values.toList(), edges)
    }

    fun render(code: String): String {
        val diagram = parse(code)
        return buildSvg(diagram)
    }

    private fun parseNode(value: String): Node {
        val clean = value.trim()

        return when {
            clean.contains("{") ->
                Node(clean.substringBefore("{"), clean, "diamond")

            clean.contains("(") ->
                Node(clean.substringBefore("("), clean, "rounded")

            else ->
                Node(clean.substringBefore("["), clean, "rect")
        }
    }

    private fun buildSvg(diagram: Diagram): String {
        val body = StringBuilder()

        diagram.nodes.forEachIndexed { index, node ->
            val y = 60 + index * 70

            body.append(
                "<rect x=\"40\" y=\"$y\" width=\"160\" height=\"45\" rx=\"10\" />"
            )

            body.append(
                "<text x=\"55\" y=\"${y + 28}\">${node.label}</text>"
            )
        }

        diagram.edges.forEachIndexed { index, edge ->
            body.append(
                "<text x=\"250\" y=\"${80 + index * 60}\">" +
                    "${edge.from} → ${edge.to}</text>"
            )
        }

        return """
            <svg xmlns="http://www.w3.org/2000/svg"
                 width="800"
                 height="600">
                 $body
            </svg>
        """.trimIndent()
    }
}
