package com.tebogo.markvault.render

/**
 * Offline Mermaid rendering engine foundation.
 * Converts simple Mermaid flowcharts into SVG output.
 */
object MermaidRenderEngine {

    fun render(code: String): String {
        val nodes = mutableListOf<String>()
        val edges = mutableListOf<Pair<String, String>>()

        code.lines().forEach { line ->
            val parts = line.split("-->")
            if (parts.size >= 2) {
                val a = clean(parts[0])
                val b = clean(parts[1])
                nodes.add(a)
                nodes.add(b)
                edges.add(a to b)
            }
        }

        return svg(nodes.distinct(), edges)
    }

    private fun clean(value: String): String =
        value.replace("[", "").replace("]", "").trim()

    private fun svg(nodes: List<String>, edges: List<Pair<String,String>>): String {
        val content = StringBuilder()
        nodes.forEachIndexed { i, n ->
            content.append("<text x=\"40\" y=\"${50 + i * 40}\">$n</text>")
        }
        edges.forEachIndexed { i, e ->
            content.append("<text x=\"250\" y=\"${50 + i * 40}\">${e.first} -> ${e.second}</text>")
        }
        return "<svg xmlns=\"http://www.w3.org/2000/svg\" width=\"600\" height=\"400\">$content</svg>"
    }
}
