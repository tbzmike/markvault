package com.tebogo.markvault.graph

/**
 * Graph metadata preparation foundation.
 */
object GraphMetadataEngine {
    fun relatedLinks(tags: List<String>, links: List<String>): List<String> {
        return (tags + links).distinct()
    }
}
