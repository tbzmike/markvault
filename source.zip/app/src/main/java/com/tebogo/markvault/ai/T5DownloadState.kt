package com.tebogo.markvault.ai

enum class T5DownloadState { NOT_INSTALLED, DOWNLOADING, VERIFYING, LOADING, READY, FAILED }
