package com.tebogo.markvault.data

data class RelatedVideoMatch(
    val item: MediaItem,
    val reason: String,
    val cached: Boolean
)

data class RelatedArticleMatch(
    val note: Note,
    val reason: String
)
