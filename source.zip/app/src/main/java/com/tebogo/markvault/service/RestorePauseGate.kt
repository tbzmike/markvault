package com.tebogo.markvault.service

/** Cooperative pause at existing IO checkpoints. No polling or added worker. */
internal class RestorePauseGate {
    private val monitor = Object()
    private var requested = false
    private var closed = false
    fun request(pause: Boolean, onRequest: () -> Unit = {}) = synchronized(monitor) {
        requested = pause
        onRequest()
        if (!pause) monitor.notifyAll()
    }
    fun checkpoint(onPaused: () -> Unit, onResumed: () -> Unit) = synchronized(monitor) {
        check(!closed) { "Restore interrupted" }
        if (requested) {
            onPaused()
            while (requested && !closed) monitor.wait()
            check(!closed) { "Restore interrupted" }
            onResumed()
        }
    }
    fun close() = synchronized(monitor) { closed = true; monitor.notifyAll() }
}
