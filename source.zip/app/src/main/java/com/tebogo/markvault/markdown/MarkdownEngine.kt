package com.tebogo.markvault.markdown

import com.vladsch.flexmark.ext.autolink.AutolinkExtension
import com.vladsch.flexmark.ext.gfm.strikethrough.StrikethroughExtension
import com.vladsch.flexmark.ext.gfm.tasklist.TaskListExtension
import com.vladsch.flexmark.ext.tables.TablesExtension
import com.vladsch.flexmark.ext.typographic.TypographicExtension
import com.vladsch.flexmark.html.HtmlRenderer
import com.vladsch.flexmark.parser.Parser
import com.vladsch.flexmark.util.data.MutableDataSet
import java.net.URLEncoder

/**
 * v4.18.0 — Native Markdown engine replacing the JS-based markdown-it pipeline.
 *
 * This is the same engine Markor uses (flexmark-java 0.64.x), configured to
 * match Markor's rendering quality and GFM extensions.
 *
 * ## Design
 *
 * **Thread-safe singleton.** Parser and HtmlRenderer construction is heavy
 * (it parses option metadata, builds extension chains, compiles regex tables).
 * Doing it per render would be catastrophic. We build once, lazily on first
 * access, then reuse forever. Both classes are thread-safe per the flexmark
 * design.
 *
 * **Configured for GFM/Markor behaviour:**
 *   - GFM pipe tables (`| col | col |`)
 *   - GFM task-lists (`- [ ]` / `- [x]`)
 *   - Soft line breaks become `<br />` tags (matches Markor; differs from
 *     CommonMark default which treats them as spaces)
 *   - Bare URLs auto-link (e.g. `https://example.com` → `<a>`)
 *   - GFM strikethrough (`~~text~~`)
 *   - Smart typographic substitutions (smart quotes, em-dash, ellipsis)
 *
 * **Wikilinks** `[[Note Name]]` are NOT delegated to flexmark's wikilink
 * extension. We need exact control over the produced `href` (must match the
 * `mv://wiki/<URL-encoded target>` scheme that `ReaderScreen.kt`'s
 * `shouldOverrideUrlLoading` intercepts). Instead, [preprocessWikilinks]
 * runs a Kotlin regex before flexmark and substitutes the markdown wikilink
 * syntax with literal `<a class="wikilink">` HTML. flexmark's CommonMark
 * compliance then passes that inline HTML through untouched.
 *
 * ## Security
 *
 * The user's `.md` files are user-authored, not user-input from an untrusted
 * source. Still, [sanitize] strips dangerous tags (`<script>`, `<iframe>`,
 * `<object>`, `<embed>`, and inline `onclick=` / `onerror=` style event
 * handlers) before flexmark sees them. This is defence-in-depth in case the
 * vault contains pasted web content. Wikilinks and ordinary inline HTML
 * (`<span>`, `<u>`, `<details>`, etc.) pass through untouched — they are
 * essential for the user's article formatting style.
 *
 * [sanitize] also strips a class of historical artefacts from earlier
 * MarkVault builds where smart-styling `<span class="sm-num">…</span>`
 * fragments got written back into the source `.md` files. These appear as
 * literal `"sm-num">1513` text in the rendered output of the old engine.
 */
object MarkdownEngine {

    /**
     * Shared option set, used by both [parser] and [renderer]. flexmark
     * requires the same DataHolder for matching parse / render behaviour,
     * otherwise extensions can mis-pair their parser and renderer halves.
     */
    private val options: MutableDataSet by lazy {
        MutableDataSet().apply {
            // Extensions list. Order is not significant; flexmark resolves
            // the dependency graph internally.
            set(
                Parser.EXTENSIONS,
                listOf(
                    TablesExtension.create(),
                    TaskListExtension.create(),
                    StrikethroughExtension.create(),
                    AutolinkExtension.create(),
                    TypographicExtension.create()
                )
            )
            // GFM/Markor behaviour: a single line break in the source
            // becomes a <br /> tag in the output. CommonMark default treats
            // single line breaks as soft (i.e. just a space), which is not
            // what Obsidian / Markor users expect.
            set(HtmlRenderer.SOFT_BREAK, "<br />\n")
            // Don't auto-generate heading IDs — the existing JS post-
            // processor (`setupHeadings` in render.js) installs its own
            // anchor system that the in-app outline relies on. Letting
            // flexmark also add IDs would produce duplicates.
            set(HtmlRenderer.GENERATE_HEADER_ID, false)
            // Leave inline HTML in source untouched. flexmark defaults to
            // CommonMark which already permits inline HTML; we make this
            // explicit. Dangerous tags are pre-stripped by [sanitize].
            set(HtmlRenderer.ESCAPE_HTML, false)
            set(HtmlRenderer.SUPPRESS_HTML_BLOCKS, false)
            set(HtmlRenderer.SUPPRESS_INLINE_HTML, false)
        }
    }

    private val parser: Parser by lazy { Parser.builder(options).build() }
    private val renderer: HtmlRenderer by lazy { HtmlRenderer.builder(options).build() }

    // ── Wikilink pre-processing ──────────────────────────────────────────
    //
    // Supports four Obsidian syntactic variants:
    //   [[Target]]
    //   [[Target|Alias]]
    //   [[Target#section]]
    //   [[Target^block]]
    //
    // Same regex as the previous JS implementation in render.js, ported
    // verbatim so behaviour matches exactly.
    private val WIKILINK_REGEX = Regex(
        """\[\[([^\[\]\n|#^]+)(?:#[^\[\]\n|]*)?(?:\^[^\[\]\n|]*)?(?:\|([^\[\]\n]+))?]]"""
    )

    /** Convert raw wikilink syntax to `<a class="wikilink">` anchors. */
    private fun preprocessWikilinks(src: String): String {
        if (!src.contains("[[")) return src   // fast path: no wikilinks present
        return src.replace(WIKILINK_REGEX) { m ->
            val target = m.groupValues[1].trim()
            val alias = m.groupValues.getOrNull(2)?.trim().orEmpty().ifEmpty { target }
            // Escape the visible label so a user typing `[[Foo<bar>]]`
            // doesn't accidentally inject markup.
            val label = alias.replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;")
            // URLEncoder emits "+" for spaces, but the existing
            // shouldOverrideUrlLoading expects %20 (browser standard).
            // Substitute it back.
            val encoded = URLEncoder.encode(target, "UTF-8").replace("+", "%20")
            """<a class="wikilink" href="mv://wiki/$encoded">$label</a>"""
        }
    }

    // ── Sanitisation ─────────────────────────────────────────────────────
    //
    // Two jobs:
    //   1. Strip the residual `sm-num` / `sm-acronym` etc. fragments left
    //      in some `.md` files by earlier buggy MarkVault builds.
    //   2. Strip XSS-risky tags before HTML rendering. Defence-in-depth —
    //      the source is user-authored but may contain pasted web content.

    private val SM_ARTEFACT_REGEX = Regex(
        """[\u201C\u201D\u2018\u2019"']?sm-(?:ref|num|pct|acronym|quotechar|key|date|cap)[\u201C\u201D\u2018\u2019"']?>+"""
    )
    private val SM_SPAN_OPEN_CLOSE = Regex(
        """<span\s+class\s*=\s*["']sm-[a-z]+["']\s*>([\s\S]*?)</span>""",
        RegexOption.IGNORE_CASE
    )
    private val SM_SPAN_OPEN_ONLY = Regex(
        """<span\s+class\s*=\s*["']sm-[a-z]+["']\s*>""",
        RegexOption.IGNORE_CASE
    )
    private val SCRIPT_BLOCK = Regex("""<script[^>]*>[\s\S]*?</script>""", RegexOption.IGNORE_CASE)
    private val SCRIPT_SELF = Regex("""<script[^>]*/\s*>""", RegexOption.IGNORE_CASE)
    private val IFRAME_BLOCK = Regex("""<iframe[^>]*>[\s\S]*?</iframe>""", RegexOption.IGNORE_CASE)
    private val OBJECT_BLOCK = Regex("""<object[^>]*>[\s\S]*?</object>""", RegexOption.IGNORE_CASE)
    private val EMBED_TAG = Regex("""<embed[^>]*/?>""", RegexOption.IGNORE_CASE)
    // Inline event handlers like onclick="..." / onerror='...'. Match the
    // attribute name and its quoted value as a unit.
    //
    // The double-quoted variant ends with a literal `"` character. In Kotlin
    // a raw string ending in `""""` is ambiguous (3 quotes = end of string,
    // 4th quote = start of a new unterminated string → compile error). The
    // ${'"'} interpolation embeds a literal `"` and resolves the ambiguity.
    private val INLINE_EVENT_DQ = Regex(
        """\son[a-z]+\s*=\s*"[^"]*${'"'}""",
        RegexOption.IGNORE_CASE
    )
    private val INLINE_EVENT_SQ = Regex("""\son[a-z]+\s*=\s*'[^']*'""", RegexOption.IGNORE_CASE)
    private val JS_HREF = Regex("""href\s*=\s*["']?\s*javascript:""", RegexOption.IGNORE_CASE)

    private fun sanitize(src: String): String {
        if (src.isBlank()) return ""
        var s = src
        // Smart-styling artefact cleanup. Order matters: opener-closer pair
        // first (preserves inner content), then bare opener, then bare
        // attribute fragment.
        s = s.replace(SM_SPAN_OPEN_CLOSE, "$1")
        s = s.replace(SM_SPAN_OPEN_ONLY, "")
        s = s.replace(SM_ARTEFACT_REGEX, "")
        // XSS hardening
        s = s.replace(SCRIPT_BLOCK, "")
        s = s.replace(SCRIPT_SELF, "")
        s = s.replace(IFRAME_BLOCK, "")
        s = s.replace(OBJECT_BLOCK, "")
        s = s.replace(EMBED_TAG, "")
        s = s.replace(INLINE_EVENT_DQ, "")
        s = s.replace(INLINE_EVENT_SQ, "")
        s = s.replace(JS_HREF, "href=\"#blocked-javascript\"")
        return s
    }

    /**
     * Convert a markdown source string into production-ready HTML, suitable
     * to drop into a WebView via `element.innerHTML = ...`.
     *
     * Pipeline:
     *   markdown
     *      → sanitize (strip sm-* artefacts + XSS-risky tags)
     *      → preprocessWikilinks (`[[Note]]` → `<a class="wikilink" …>`)
     *      → flexmark parse
     *      → flexmark render
     *      → HTML string
     */
    fun render(markdown: String): String {
        if (markdown.isBlank()) return ""
        val sanitized = sanitize(markdown)
        val withWikilinks = preprocessWikilinks(sanitized)
        val document = parser.parse(withWikilinks)
        return renderer.render(document)
    }
}

/**
 * Extension entry point matching the form requested by the migration spec.
 *
 * Usage:
 * ```kotlin
 * val html = note.content.markdownToHtml()
 * webView.evaluateJavascript("renderMarkdown(${jsString(html)}, …)", null)
 * ```
 */
fun String.markdownToHtml(): String = MarkdownEngine.render(this)
