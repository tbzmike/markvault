package com.tebogo.markvault.markdown

import com.vladsch.flexmark.ext.autolink.AutolinkExtension
import com.vladsch.flexmark.ext.gfm.strikethrough.StrikethroughExtension
import com.vladsch.flexmark.ext.gfm.tasklist.TaskListExtension
import com.vladsch.flexmark.ext.tables.TablesExtension
import com.vladsch.flexmark.ext.typographic.TypographicExtension
import com.vladsch.flexmark.html.HtmlRenderer
import com.vladsch.flexmark.parser.Parser
import com.vladsch.flexmark.util.data.MutableDataSet
import java.net.URLEncoder

/**
 * v4.18.0 — Native Markdown engine replacing the JS-based markdown-it pipeline.
 *
 * This is the same engine Markor uses (flexmark-java 0.64.x), configured to
 * match Markor's rendering quality and GFM extensions.
 *
 * ## Design
 *
 * **Thread-safe singleton.** Parser and HtmlRenderer construction is heavy
 * (it parses option metadata, builds extension chains, compiles regex tables).
 * Doing it per render would be catastrophic. We build once, lazily on first
 * access, then reuse forever. Both classes are thread-safe per the flexmark
 * design.
 *
 * **Configured for GFM/Markor behaviour:**
 *   - GFM pipe tables (`| col | col |`)
 *   - GFM task-lists (`- [ ]` / `- [x]`)
 *   - Soft line breaks become `<br />` tags (matches Markor; differs from
 *     CommonMark default which treats them as spaces)
 *   - Bare URLs auto-link (e.g. `https://example.com` → `<a>`)
 *   - GFM strikethrough (`~~text~~`)
 *   - Smart typographic substitutions (smart quotes, em-dash, ellipsis)
 *
 * **Wikilinks** `[[Note Name]]` are NOT delegated to flexmark's wikilink
 * extension. We need exact control over the produced `href` (must match the
 * `mv://wiki/<URL-encoded target>` scheme that `ReaderScreen.kt`'s
 * `shouldOverrideUrlLoading` intercepts). Instead, [preprocessWikilinks]
 * runs a Kotlin regex before flexmark and substitutes the markdown wikilink
 * syntax with literal `<a class="wikilink">` HTML. flexmark's CommonMark
 * compliance then passes that inline HTML through untouched.
 *
 * ## Security
 *
 * The user's `.md` files are user-authored, not user-input from an untrusted
 * source. Still, [sanitize] strips dangerous tags (`<script>`, `<iframe>`,
 * `<object>`, `<embed>`, and inline `onclick=` / `onerror=` style event
 * handlers) before flexmark sees them. This is defence-in-depth in case the
 * vault contains pasted web content. Wikilinks and ordinary inline HTML
 * (`<span>`, `<u>`, `<details>`, etc.) pass through untouched — they are
 * essential for the user's article formatting style.
 *
 * [sanitize] also strips a class of historical artefacts from earlier
 * MarkVault builds where smart-styling `<span class="sm-num">…</span>`
 * fragments got written back into the source `.md` files. These appear as
 * literal `"sm-num">1513` text in the rendered output of the old engine.
 */
object MarkdownEngine {



    data class MarkdownMetadata(
        val title: String? = null,
        val tags: List<String> = emptyList(),
        val aliases: List<String> = emptyList(),
        val date: String? = null,
        val categories: List<String> = emptyList()
    )

    fun extractMetadata(markdown: String): MarkdownMetadata {
        if (!markdown.startsWith("---")) return MarkdownMetadata()
        val end = markdown.indexOf("\\n---", 3)
        if (end == -1) return MarkdownMetadata()
        val block = markdown.substring(3, end)
        fun value(key: String): String? = Regex("(?m)^" + key + "\\\\s*:\\\\s*(.+)$")
            .find(block)?.groupValues?.get(1)?.trim()
        val tagsBlock = block.substringAfter("tags:", "")
        val tags = Regex("(?m)^\\s*-\\s*(.+)$")
            .findAll(tagsBlock)
            .map { it.groupValues[1].trim().trim('"', '\'') }
            .toList()

        val aliasesBlock = block.substringAfter("aliases:", "")
            .lines()
            .takeWhile { !it.trim().matches(Regex("^\\w+\\s*:.*$")) }
            .joinToString("\n")
        val aliases = Regex("(?m)^\\s*-\\s*(.+)$")
            .findAll(aliasesBlock)
            .map { it.groupValues[1].trim().trim('"', '\'') }
            .toList()

        val categoriesBlock = block.substringAfter("categories:", "")
        val categories = Regex("(?m)^\\s*-\\s*(.+)$")
            .findAll(categoriesBlock)
            .map { it.groupValues[1].trim().trim('"', '\'') }
            .toList()

        return MarkdownMetadata(value("title"), tags, aliases, value("date"), categories)
    }

    /**
     * Removes YAML front matter before Markdown rendering.
     * Metadata extraction can be connected to indexing separately so
     * existing rendering behaviour remains unchanged.
     */
    private fun preprocessFrontMatter(markdown: String): String {
        if (!markdown.startsWith("---")) return markdown
        val end = markdown.indexOf("\n---", 3)
        if (end == -1) return markdown
        return markdown.substring(end + 4).trimStart()
    }



    /**
     * Shared option set, used by both [parser] and [renderer]. flexmark
     * requires the same DataHolder for matching parse / render behaviour,
     * otherwise extensions can mis-pair their parser and renderer halves.
     */
    private val options: MutableDataSet by lazy {
        MutableDataSet().apply {
            // Extensions list. Order is not significant; flexmark resolves
            // the dependency graph internally.
            set(
                Parser.EXTENSIONS,
                listOf(
                    TablesExtension.create(),
                    TaskListExtension.create(),
                    StrikethroughExtension.create(),
                    AutolinkExtension.create(),
                    TypographicExtension.create()
                )
            )
            // GFM/Markor behaviour: a single line break in the source
            // becomes a <br /> tag in the output. CommonMark default treats
            // single line breaks as soft (i.e. just a space), which is not
            // what Obsidian / Markor users expect.
            set(HtmlRenderer.SOFT_BREAK, "<br />\n")
            // Don't auto-generate heading IDs — the existing JS post-
            // processor (`setupHeadings` in render.js) installs its own
            // anchor system that the in-app outline relies on. Letting
            // flexmark also add IDs would produce duplicates.
            set(HtmlRenderer.GENERATE_HEADER_ID, false)
            // Leave inline HTML in source untouched. flexmark defaults to
            // CommonMark which already permits inline HTML; we make this
            // explicit. Dangerous tags are pre-stripped by [sanitize].
            set(HtmlRenderer.ESCAPE_HTML, false)
            set(HtmlRenderer.SUPPRESS_HTML_BLOCKS, false)
            set(HtmlRenderer.SUPPRESS_INLINE_HTML, false)
        }
    }

    private val parser: Parser by lazy { Parser.builder(options).build() }
    private val renderer: HtmlRenderer by lazy { HtmlRenderer.builder(options).build() }

    // ── Wikilink pre-processing ──────────────────────────────────────────
    //
    // Supports four Obsidian syntactic variants:
    //   [[Target]]
    //   [[Target|Alias]]
    //   [[Target#section]]
    //   [[Target^block]]
    //
    // Same regex as the previous JS implementation in render.js, ported
    // verbatim so behaviour matches exactly.
    private val WIKILINK_REGEX = Regex(
        """\[\[([^\[\]\n|#^]+)(?:#[^\[\]\n|]*)?(?:\^[^\[\]\n|]*)?(?:\|([^\[\]\n]+))?]]"""
    )

    /** Convert raw wikilink syntax to `<a class="wikilink">` anchors. */
    private fun preprocessWikilinks(src: String): String {
        if (!src.contains("[[")) return src   // fast path: no wikilinks present
        return src.replace(WIKILINK_REGEX) { m ->
            val target = m.groupValues[1].trim()
            val alias = m.groupValues.getOrNull(2)?.trim().orEmpty().ifEmpty { target }
            // Escape the visible label so a user typing `[[Foo<bar>]]`
            // doesn't accidentally inject markup.
            val label = alias.replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;")
            // URLEncoder emits "+" for spaces, but the existing
            // shouldOverrideUrlLoading expects %20 (browser standard).
            // Substitute it back.
            val encoded = URLEncoder.encode(target, "UTF-8").replace("+", "%20")
            """<a class="wikilink" href="mv://wiki/$encoded">$label</a>"""
        }
    }

    
    /**
     * Detects Markdown math blocks and prepares them for the reader renderer.
     * The rendering layer can later attach KaTeX/MathJax without changing the
     * Markdown parsing pipeline.
     */
    
    /**
     * Basic Markdown footnote reference support foundation.
     */
    private fun preprocessFootnotes(src: String): String {
        return src.replace(Regex("""\[\^([^\]]+)]""")) { match ->
            "<sup class=\"footnote\">${match.groupValues[1]}</sup>"
        }
    }

private fun preprocessMath(src: String): String {
        var result = src
        result = result.replace(Regex("""\$\$([\s\S]*?)\$\$""")) { match ->
            "<div class=\"math-block\">${match.groupValues[1].trim()}</div>"
        }
        result = result.replace(Regex("""(?<!\$)\$([^\$\n]+)\$(?!\$)""")) { match ->
            "<span class=\"math-inline\">${match.groupValues[1]}</span>"
        }
        return result
    }


    /**
     * Supports Obsidian-style inline properties:
     * Key:: Value
     */
    private fun preprocessInlineProperties(src: String): String {
        return src.replace(Regex("""(?m)^([A-Za-z][A-Za-z0-9 _-]*)::\s*(.+)$""")) { match ->
            val key = match.groupValues[1].trim()
            val value = match.groupValues[2].trim()
            """<div class="markdown-property"><strong>$key</strong>: $value</div>"""
        }
    }

    /**
     * Normalizes Obsidian-style tag separators so tags remain searchable
     * when users use comma separated metadata.
     */
    private fun preprocessMetadataSeparators(src: String): String {
        return src.replace(Regex("""(?m)^tags:\s*(.+)$""")) { match ->
            "tags: ${match.groupValues[1].replace(",", " ")}"
        }
    }


    // v5.4.45c: Additional Markdown compatibility helpers.
    // Converts ==highlight== syntax into a semantic HTML mark element.
    private fun preprocessHighlights(src: String): String {
        return src.replace(Regex("""==([^=\n]+)==""")) {
            "<mark>${it.groupValues[1]}</mark>"
        }
    }

    // Supports common emoji shortcodes in offline notes.
    private fun preprocessEmoji(src: String): String {
        val emojis = mapOf(
            ":smile:" to "😊",
            ":heart:" to "❤️",
            ":warning:" to "⚠️",
            ":check:" to "✅",
            ":fire:" to "🔥"
        )
        var result = src
        emojis.forEach { (key, value) ->
            result = result.replace(key, value)
        }
        return result
    }


    /**
     * Adds lightweight superscript and subscript Markdown compatibility.
     * Examples:
     *   x^2^  -> x<sup>2</sup>
     *   H~2~O  -> H<sub>2</sub>O
     */
    private fun preprocessSuperscriptSubscript(src: String): String {
        var s = src.replace(Regex("""\^([^\^\n]+)\^""")) {
            "<sup>${it.groupValues[1]}</sup>"
        }
        s = s.replace(Regex("""~([^~\n]+)~""")) {
            "<sub>${it.groupValues[1]}</sub>"
        }
        return s
    }


    /**
     * Converts Obsidian-style inline properties into readable property rows.
     * Example: Author:: Name
     */
    private fun preprocessObsidianProperties(src: String): String {
        return src.replace(Regex("""(?m)^([A-Za-z][A-Za-z0-9 _-]*)::\s*(.+)$""")) {
            """<div class="property-row"><strong>${it.groupValues[1]}</strong>: ${it.groupValues[2]}</div>"""
        }
    }

private fun preprocessTags(src: String): String {
        return src.replace(Regex("(?m)(^|\\s)#([A-Za-z0-9_-]+)")) { m ->
            val prefix = m.groupValues[1]
            val tag = m.groupValues[2]
            """$prefix<a class="tag" href="mv://tag/$tag">#$tag</a>"""
        }
    }

    // ── Advanced Markdown preprocessing ───────────────────────────────────
    // v5.4.37c: Obsidian-style callouts and Mermaid blocks.
    private fun preprocessAdvancedMarkdown(src: String): String {
        var result = src

        result = result.replace(
            Regex("""```mermaid\s*\n([\s\S]*?)```""")
        ) { match ->
            "<div class=\"mermaid\">\n${match.groupValues[1]}\n</div>"
        }

        result = result.replace(
            Regex("""(?m)^> \[!(NOTE|TIP|IMPORTANT|WARNING|CAUTION|QUOTE|INFO|SUCCESS|FAILURE|DANGER|QUESTION|EXAMPLE)\]\s*\n((?:^>.*\n?)*)""")
        ) { match ->
            val type = match.groupValues[1].lowercase()
            val body = match.groupValues[2]
                .replace(Regex("""^> ?""", RegexOption.MULTILINE), "")
            "<div class=\"callout $type\"><strong>${type.uppercase()}</strong><br>$body</div>"
        }

        return result
    }

    // ── Sanitisation ─────────────────────────────────────────────────────
    //
    // Two jobs:
    //   1. Strip the residual `sm-num` / `sm-acronym` etc. fragments left
    //      in some `.md` files by earlier buggy MarkVault builds.
    //   2. Strip XSS-risky tags before HTML rendering. Defence-in-depth —
    //      the source is user-authored but may contain pasted web content.

    private val SM_ARTEFACT_REGEX = Regex(
        """[\u201C\u201D\u2018\u2019"']?sm-(?:ref|num|pct|acronym|quotechar|key|date|cap)[\u201C\u201D\u2018\u2019"']?>+"""
    )
    private val SM_SPAN_OPEN_CLOSE = Regex(
        """<span\s+class\s*=\s*["']sm-[a-z]+["']\s*>([\s\S]*?)</span>""",
        RegexOption.IGNORE_CASE
    )
    private val SM_SPAN_OPEN_ONLY = Regex(
        """<span\s+class\s*=\s*["']sm-[a-z]+["']\s*>""",
        RegexOption.IGNORE_CASE
    )
    private val SCRIPT_BLOCK = Regex("""<script[^>]*>[\s\S]*?</script>""", RegexOption.IGNORE_CASE)
    private val SCRIPT_SELF = Regex("""<script[^>]*/\s*>""", RegexOption.IGNORE_CASE)
    private val IFRAME_BLOCK = Regex("""<iframe[^>]*>[\s\S]*?</iframe>""", RegexOption.IGNORE_CASE)
    private val OBJECT_BLOCK = Regex("""<object[^>]*>[\s\S]*?</object>""", RegexOption.IGNORE_CASE)
    private val EMBED_TAG = Regex("""<embed[^>]*/?>""", RegexOption.IGNORE_CASE)
    // Inline event handlers like onclick="..." / onerror='...'. Match the
    // attribute name and its quoted value as a unit.
    //
    // The double-quoted variant ends with a literal `"` character. In Kotlin
    // a raw string ending in `""""` is ambiguous (3 quotes = end of string,
    // 4th quote = start of a new unterminated string → compile error). The
    // ${'"'} interpolation embeds a literal `"` and resolves the ambiguity.
    private val INLINE_EVENT_DQ = Regex(
        """\son[a-z]+\s*=\s*"[^"]*${'"'}""",
        RegexOption.IGNORE_CASE
    )
    private val INLINE_EVENT_SQ = Regex("""\son[a-z]+\s*=\s*'[^']*'""", RegexOption.IGNORE_CASE)
    private val JS_HREF = Regex("""href\s*=\s*["']?\s*javascript:""", RegexOption.IGNORE_CASE)

    private fun sanitize(src: String): String {
        if (src.isBlank()) return ""
        var s = src
        // Smart-styling artefact cleanup. Order matters: opener-closer pair
        // first (preserves inner content), then bare opener, then bare
        // attribute fragment.
        s = s.replace(SM_SPAN_OPEN_CLOSE, "$1")
        s = s.replace(SM_SPAN_OPEN_ONLY, "")
        s = s.replace(SM_ARTEFACT_REGEX, "")
        // XSS hardening
        s = s.replace(SCRIPT_BLOCK, "")
        s = s.replace(SCRIPT_SELF, "")
        s = s.replace(IFRAME_BLOCK, "")
        s = s.replace(OBJECT_BLOCK, "")
        s = s.replace(EMBED_TAG, "")
        s = s.replace(INLINE_EVENT_DQ, "")
        s = s.replace(INLINE_EVENT_SQ, "")
        s = s.replace(JS_HREF, "href=\"#blocked-javascript\"")
        return s
    }

    /**
     * Convert a markdown source string into production-ready HTML, suitable
     * to drop into a WebView via `element.innerHTML = ...`.
     *
     * Pipeline:
     *   markdown
     *      → sanitize (strip sm-* artefacts + XSS-risky tags)
     *      → preprocessWikilinks (`[[Note]]` → `<a class="wikilink" …>`)
     *      → flexmark parse
     *      → flexmark render
     *      → HTML string
     */
    fun render(markdown: String): String {
        val markdownContent = preprocessFrontMatter(markdown)
        if (markdown.isBlank()) return ""
        val sanitized = sanitize(markdownContent)
        val withMath = preprocessMath(sanitized)
        val withFootnotes = preprocessFootnotes(withMath)
        val withAdvancedMarkdown = preprocessAdvancedMarkdown(withFootnotes)
        val withHighlights = preprocessHighlights(withAdvancedMarkdown)
        val withEmoji = preprocessEmoji(withHighlights)
        val withProperties = preprocessInlineProperties(withEmoji)
        val withObsidianProperties = preprocessObsidianProperties(withProperties)
        val withMetadata = preprocessMetadataSeparators(withObsidianProperties)
        val withSuperSub = preprocessSuperscriptSubscript(withMetadata)
        val withTags = preprocessTags(withSuperSub)
        val withWikilinks = preprocessWikilinks(withTags)
        val document = parser.parse(withWikilinks)
        return renderer.render(document)
    }
}

/**
 * Extension entry point matching the form requested by the migration spec.
 *
 * Usage:
 * ```kotlin
 * val html = note.content.markdownToHtml()
 * webView.evaluateJavascript("renderMarkdown(${jsString(html)}, …)", null)
 * ```
 */
fun String.markdownToHtml(): String = MarkdownEngine.render(this)
