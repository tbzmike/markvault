package com.tebogo.markvault.markdown

import com.vladsch.flexmark.ext.autolink.AutolinkExtension
import com.vladsch.flexmark.ext.gfm.strikethrough.StrikethroughExtension
import com.vladsch.flexmark.ext.gfm.tasklist.TaskListExtension
import com.vladsch.flexmark.ext.tables.TablesExtension
import com.vladsch.flexmark.ext.typographic.TypographicExtension
import com.vladsch.flexmark.html.HtmlRenderer
import com.vladsch.flexmark.parser.Parser
import com.vladsch.flexmark.util.data.MutableDataSet
import java.net.URLEncoder

/**
 * v4.18.0 — Native Markdown engine replacing the JS-based markdown-it pipeline.
 *
 * This is the same engine Markor uses (flexmark-java 0.64.x), configured to
 * match Markor's rendering quality and GFM extensions.
 *
 * ## Design
 *
 * **Thread-safe singleton.** Parser and HtmlRenderer construction is heavy
 * (it parses option metadata, builds extension chains, compiles regex tables).
 * Doing it per render would be catastrophic. We build once, lazily on first
 * access, then reuse forever. Both classes are thread-safe per the flexmark
 * design.
 *
 * **Configured for GFM/Markor behaviour:**
 *   - GFM pipe tables (`| col | col |`)
 *   - GFM task-lists (`- [ ]` / `- [x]`)
 *   - Soft line breaks become `<br />` tags (matches Markor; differs from
 *     CommonMark default which treats them as spaces)
 *   - Bare URLs auto-link (e.g. `https://example.com` → `<a>`)
 *   - GFM strikethrough (`~~text~~`)
 *   - Smart typographic substitutions (smart quotes, em-dash, ellipsis)
 *
 * **Wikilinks** `[[Note Name]]` are NOT delegated to flexmark's wikilink
 * extension. We need exact control over the produced `href` (must match the
 * `mv://wiki/<URL-encoded target>` scheme that `ReaderScreen.kt`'s
 * `shouldOverrideUrlLoading` intercepts). Instead, [preprocessWikilinks]
 * runs a Kotlin regex before flexmark and substitutes the markdown wikilink
 * syntax with literal `<a class="wikilink">` HTML. flexmark's CommonMark
 * compliance then passes that inline HTML through untouched.
 *
 * ## Security
 *
 * The user's `.md` files are user-authored, not user-input from an untrusted
 * source. Still, [sanitize] strips dangerous tags (`<script>`, `<iframe>`,
 * `<object>`, `<embed>`, and inline `onclick=` / `onerror=` style event
 * handlers) before flexmark sees them. This is defence-in-depth in case the
 * vault contains pasted web content. Wikilinks and ordinary inline HTML
 * (`<span>`, `<u>`, `<details>`, etc.) pass through untouched — they are
 * essential for the user's article formatting style.
 *
 * [sanitize] also strips a class of historical artefacts from earlier
 * MarkVault builds where smart-styling `<span class="sm-num">…</span>`
 * fragments got written back into the source `.md` files. These appear as
 * literal `"sm-num">1513` text in the rendered output of the old engine.
 */
object MarkdownEngine {



    data class MarkdownMetadata(
        val title: String? = null,
        val tags: List<String> = emptyList(),
        val aliases: List<String> = emptyList(),
        val date: String? = null,
        val categories: List<String> = emptyList()
    )

    fun extractMetadata(markdown: String): MarkdownMetadata {
        if (!markdown.startsWith("---")) return MarkdownMetadata()
        val end = markdown.indexOf("\n---", 3)
        if (end == -1) return MarkdownMetadata()
        val block = markdown.substring(3, end)
        fun value(key: String): String? = Regex("(?m)^" + key + "\\s*:\\s*(.+)$")
            .find(block)?.groupValues?.get(1)?.trim()
        val tagsBlock = block.substringAfter("tags:", "")
        val tags = Regex("(?m)^\\s*-\\s*(.+)$")
            .findAll(tagsBlock)
            .map { it.groupValues[1].trim().trim('"', '\'') }
            .toList()

        val aliasesBlock = block.substringAfter("aliases:", "")
            .lines()
            .takeWhile { !it.trim().matches(Regex("^\\w+\\s*:.*$")) }
            .joinToString("\n")
        val aliases = Regex("(?m)^\\s*-\\s*(.+)$")
            .findAll(aliasesBlock)
            .map { it.groupValues[1].trim().trim('"', '\'') }
            .toList()

        val categoriesBlock = block.substringAfter("categories:", "")
        val categories = Regex("(?m)^\\s*-\\s*(.+)$")
            .findAll(categoriesBlock)
            .map { it.groupValues[1].trim().trim('"', '\'') }
            .toList()

        return MarkdownMetadata(value("title"), tags, aliases, value("date"), categories)
    }

    /**
     * Removes YAML front matter before Markdown rendering.
     * Metadata extraction can be connected to indexing separately so
     * existing rendering behaviour remains unchanged.
     */
    private fun preprocessFrontMatter(markdown: String): String {
        if (!markdown.startsWith("---")) return markdown
        val end = markdown.indexOf("\n---", 3)
        if (end == -1) return markdown
        return markdown.substring(end + 4).trimStart()
    }



    /**
     * Shared option set, used by both [parser] and [renderer]. flexmark
     * requires the same DataHolder for matching parse / render behaviour,
     * otherwise extensions can mis-pair their parser and renderer halves.
     */
    private val options: MutableDataSet by lazy {
        MutableDataSet().apply {
            // Extensions list. Order is not significant; flexmark resolves
            // the dependency graph internally.
            set(
                Parser.EXTENSIONS,
                listOf(
                    TablesExtension.create(),
                    TaskListExtension.create(),
                    StrikethroughExtension.create(),
                    AutolinkExtension.create(),
                    TypographicExtension.create()
                    // Footnotes handled by preprocessFootnotes() — no external dep needed.
                )
            )
            // GFM/Markor behaviour: a single line break in the source
            // becomes a <br /> tag in the output. CommonMark default treats
            // single line breaks as soft (i.e. just a space), which is not
            // what Obsidian / Markor users expect.
            set(HtmlRenderer.SOFT_BREAK, "<br />\n")
            // Don't auto-generate heading IDs — the existing JS post-
            // processor (`setupHeadings` in render.js) installs its own
            // anchor system that the in-app outline relies on. Letting
            // flexmark also add IDs would produce duplicates.
            set(HtmlRenderer.GENERATE_HEADER_ID, false)
            // Leave inline HTML in source untouched. flexmark defaults to
            // CommonMark which already permits inline HTML; we make this
            // explicit. Dangerous tags are pre-stripped by [sanitize].
            set(HtmlRenderer.ESCAPE_HTML, false)
            set(HtmlRenderer.SUPPRESS_HTML_BLOCKS, false)
            set(HtmlRenderer.SUPPRESS_INLINE_HTML, false)
        }
    }

    private val parser: Parser by lazy { Parser.builder(options).build() }
    private val renderer: HtmlRenderer by lazy { HtmlRenderer.builder(options).build() }

    // ── Wikilink pre-processing ──────────────────────────────────────────
    //
    // Supports four Obsidian syntactic variants:
    //   [[Target]]
    //   [[Target|Alias]]
    //   [[Target#section]]
    //   [[Target^block]]
    //
    // Same regex as the previous JS implementation in render.js, ported
    // verbatim so behaviour matches exactly.
    // ── Embeds / transclusions ──────────────────────────────────────────
    // v5.4.124cc — New. Obsidian embed syntax:
    //   ![[Note]]              -- transclude another note's full content
    //   ![[Note#Heading]]      -- transclude just that section
    //   ![[image.png]]         -- inline a local image
    //   ![[image.png|300]]     -- ...with an explicit width
    //
    // Must run BEFORE preprocessWikilinks: `![[Note]]` contains `[[Note]]`
    // as a substring, and the plain wikilink regex would otherwise also
    // match it, producing a stray link on top of (or instead of) the
    // embed. Runs on the code-protected text so `` `![[Note]]` `` in a
    // code example stays literal instead of expanding.
    //
    // Note embeds resolve via a caller-supplied [resolveEmbed] callback
    // rather than any file/DB access here -- MarkdownEngine has none, by
    // design (see the class doc). Depth is capped at [MAX_EMBED_DEPTH]
    // and [seenEmbeds] tracks targets already being expanded in this
    // render chain, so A-embeds-B-embeds-A can't recurse forever.
    //
    // Local image embeds resolve to the same bare relative-path `src` a
    // plain markdown `![alt](image.png)` would use -- MarkVault has no
    // vault-relative-path -> loadable-URI resolver anywhere yet (the
    // reader WebView loads with `baseUrl="about:blank"`, so relative
    // image paths don't currently resolve for EITHER syntax). This is a
    // real, pre-existing, separate gap, not something this change makes
    // worse -- fixing it needs a resolver wired into the WebView load
    // path, which is out of scope here.
    private const val MAX_EMBED_DEPTH = 4
    private val IMAGE_EXTENSIONS = setOf("png", "jpg", "jpeg", "gif", "webp", "svg", "bmp")
    private val EMBED_REGEX = Regex(
        """!\[\[([^\[\]\n|#^]+)(?:#([^\[\]\n|^]*))?(?:\^[^\[\]\n|]*)?(?:\|([^\[\]\n]+))?]]"""
    )

    private fun embedErrorHtml(target: String, reason: String): String {
        val safe = target.replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;")
        return "<div class=\"markdown-embed markdown-embed-error\">\u26A0\uFE0F Embed unavailable: $safe ($reason)</div>"
    }

    /**
     * Extracts a heading and its section (up to the next heading of equal
     * or higher level) from raw markdown, for `![[Note#Heading]]`. Match
     * is case-insensitive on the heading text; returns null if not found.
     */
    private fun extractSection(markdown: String, heading: String): String? {
        val lines = markdown.lines()
        val headingRegex = Regex("""^(#{1,6})\s+(.+?)\s*$""")
        var startIdx = -1
        var startLevel = 0
        for ((i, line) in lines.withIndex()) {
            val m = headingRegex.find(line) ?: continue
            if (m.groupValues[2].trim().equals(heading, ignoreCase = true)) {
                startIdx = i
                startLevel = m.groupValues[1].length
                break
            }
        }
        if (startIdx == -1) return null
        val body = StringBuilder()
        body.append(lines[startIdx]).append('\n')
        for (i in (startIdx + 1) until lines.size) {
            val m = headingRegex.find(lines[i])
            if (m != null && m.groupValues[1].length <= startLevel) break
            body.append(lines[i]).append('\n')
        }
        return body.toString()
    }

    private suspend fun renderEmbedMatch(
        m: MatchResult,
        resolver: (suspend (String) -> String?)?,
        depth: Int,
        seen: Set<String>
    ): String {
        val target = m.groupValues[1].trim()
        val heading = m.groupValues.getOrNull(2)?.trim().orEmpty()
        val extra = m.groupValues.getOrNull(3)?.trim().orEmpty()
        val ext = target.substringAfterLast('.', "").lowercase()

        if (ext in IMAGE_EXTENSIONS) {
            val widthAttr = extra.toIntOrNull()?.let { " width=\"$it\"" } ?: ""
            val safeTarget = target.replace("\"", "&quot;")
            return """<img class="markdown-embed-image" src="$safeTarget" alt="$safeTarget"$widthAttr />"""
        }

        if (depth >= MAX_EMBED_DEPTH) return embedErrorHtml(target, "nested too deep")
        val key = target.lowercase()
        if (key in seen) return embedErrorHtml(target, "circular embed")
        if (resolver == null) return embedErrorHtml(target, "not found")
        val content = resolver(target) ?: return embedErrorHtml(target, "not found")
        val section = if (heading.isNotEmpty()) extractSection(content, heading) else content
        if (section == null) return embedErrorHtml(target, "heading \"$heading\" not found")
        val nextSeen = HashSet(seen).apply { add(key) }
        val innerHtml = render(section, depth + 1, nextSeen, resolver)
        val label = (if (heading.isNotEmpty()) "$target \u203A $heading" else target)
            .replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;")
        return """<div class="markdown-embed"><div class="markdown-embed-title">$label</div><div class="markdown-embed-body">$innerHtml</div></div>"""
    }

    /**
     * Expands `![[...]]` embed syntax. Uses manual find/replace rather
     * than `Regex.replace { }` because expanding a note embed requires
     * calling the suspend [resolver] and recursively calling [render],
     * and a synchronous regex-replace lambda can't await either.
     */
    private suspend fun preprocessEmbeds(
        src: String,
        resolver: (suspend (String) -> String?)?,
        depth: Int,
        seen: Set<String>
    ): String {
        if (!src.contains("![[")) return src
        val matches = EMBED_REGEX.findAll(src).toList()
        if (matches.isEmpty()) return src
        val sb = StringBuilder()
        var lastEnd = 0
        for (m in matches) {
            sb.append(src, lastEnd, m.range.first)
            sb.append(renderEmbedMatch(m, resolver, depth, seen))
            lastEnd = m.range.last + 1
        }
        sb.append(src, lastEnd, src.length)
        return sb.toString()
    }

    private val WIKILINK_REGEX = Regex(
        """\[\[([^\[\]\n|#^]+)(?:#[^\[\]\n|]*)?(?:\^[^\[\]\n|]*)?(?:\|([^\[\]\n]+))?]]"""
    )

    /** Convert raw wikilink syntax to `<a class="wikilink">` anchors. */
    private fun preprocessWikilinks(src: String): String {
        if (!src.contains("[[")) return src   // fast path: no wikilinks present
        return src.replace(WIKILINK_REGEX) { m ->
            val target = m.groupValues[1].trim()
            val alias = m.groupValues.getOrNull(2)?.trim().orEmpty().ifEmpty { target }
            // Escape the visible label so a user typing `[[Foo<bar>]]`
            // doesn't accidentally inject markup.
            val label = alias.replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;")
            // URLEncoder emits "+" for spaces, but the existing
            // shouldOverrideUrlLoading expects %20 (browser standard).
            // Substitute it back.
            val encoded = URLEncoder.encode(target, "UTF-8").replace("+", "%20")
            """<a class="wikilink" href="mv://wiki/$encoded">$label</a>"""
        }
    }

    
    /**
     * Detects Markdown math blocks and prepares them for the reader renderer.
     * The rendering layer can later attach KaTeX/MathJax without changing the
     * Markdown parsing pipeline.
     */
    
    /**
     * Basic Markdown footnote reference support foundation.
     */
    /**
     * v5.4.154cc — Two-pass Kotlin footnote processor.
     *
     * Root cause of v5.4.153cc build failure: flexmark-ext-footnotes is NOT
     * published as a separate Maven artifact in the 0.64.x release series.
     * Attempting to import FootnotesExtension caused "Unresolved reference"
     * at both the import line and the extensions list, aborting compilation.
     *
     * This pure-Kotlin implementation reproduces the same HTML structure
     * the flexmark FootnotesExtension would have produced, so the existing
     * viewer.css footnote rules (sup[id^="fnref"], .footnote-backref, etc.)
     * work without any CSS changes.
     *
     * Pass 1 — collect + remove definitions from prose:
     *   [^label]: definition text  →  stored; line removed from document
     *
     * Pass 2 — linkify inline references in order of first appearance:
     *   [^label]  →  <sup id="fnref-label"><a href="#fn-label" class="footnote-ref">N</a></sup>
     *
     * Appends <div class="footnotes"><hr /><ol>…</ol></div> at the end.
     *
     * Safe inside the HTML-protection pipeline: code blocks and HTML tags
     * are already replaced by opaque placeholders at this point, so [^…]
     * markers inside code or HTML attributes are never touched.
     */
    private fun preprocessFootnotes(src: String): String {
        // Fast path: no footnote markers in document.
        if (!src.contains("[^")) return src

        // ── Pass 1: collect definitions and remove them from the prose ────
        val definitionRegex = Regex("""(?m)^\[\^([^\]]+)\]:\s*(.+)$""")
        val definitions = linkedMapOf<String, String>()  // label → text, order preserved
        var cleaned = definitionRegex.replace(src) { match ->
            val label = match.groupValues[1].trim()
            val text  = match.groupValues[2].trim()
            definitions[label] = text
            ""  // remove the definition line; surrounding blank lines are harmless
        }

        // ── Pass 2: replace inline refs with linked superscripts ──────────
        // (?!:) lookahead ensures we never match [^label]: definition lines
        // (which are already removed, but acts as a safety net).
        val inlineRegex = Regex("""\[\^([^\]]+)\](?!:)""")
        var refCounter = 0
        val refOrder = linkedMapOf<String, Int>()  // label → display number
        cleaned = inlineRegex.replace(cleaned) { match ->
            val label = match.groupValues[1].trim()
            val num   = refOrder.getOrPut(label) { ++refCounter }
            "<sup id="fnref-$label"><a href="#fn-$label" class="footnote-ref">$num</a></sup>"
        }

        // If there are no collected definitions, return now (inline refs are linked).
        if (definitions.isEmpty()) return cleaned

        // ── Append footnote section ───────────────────────────────────────
        // HTML structure mirrors flexmark FootnotesExtension output so that
        // the existing viewer.css rules target the right selectors.
        val sb = StringBuilder(cleaned.trimEnd())
        sb.append("

<div class="footnotes">
<hr />
<ol>
")
        definitions.forEach { (label, text) ->
            sb.append("<li id="fn-$label"><p>")
            sb.append(text)
            // ↩ back-reference to the inline anchor
            sb.append(" <a href="#fnref-$label" class="footnote-backref">↩</a>")
            sb.append("</p></li>
")
        }
        sb.append("</ol>
</div>")
        return sb.toString()
    }

    /**
     * Wraps LaTeX math source in containers for client-side typesetting
     * (see render.js's typesetMath, which calls KaTeX on these once its
     * assets are present -- see the KaTeX integration note on [render]).
     * Until then, or if KaTeX assets are missing, these degrade to
     * visible raw LaTeX text rather than rendering blank or crashing.
     *
     * v5.4.125cc — the captured LaTeX was previously embedded as raw HTML
     * content with no escaping. LaTeX routinely contains `<`, `>`, `&`
     * (e.g. `$a < b$`, `$x \& y$`) -- unescaped, those get parsed as HTML
     * markup instead of reaching KaTeX as the text it was meant to be,
     * corrupting the equation (or worse, silently swallowing the rest of
     * the line after a stray `<`). Also added `\[...\]` block delimiters
     * (LaTeX/MathJax convention) alongside the existing `$$...$$`.
     */
    private fun preprocessMath(src: String): String {
        fun escape(s: String) = s.replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;")
        var result = src
        result = result.replace(Regex("""\$\$([\s\S]*?)\$\$""")) { match ->
            "<div class=\"math-block\">${escape(match.groupValues[1].trim())}</div>"
        }
        result = result.replace(Regex("""\\\[([\s\S]*?)\\]""")) { match ->
            "<div class=\"math-block\">${escape(match.groupValues[1].trim())}</div>"
        }
        result = result.replace(Regex("""\\\(([\s\S]*?)\\\)""")) { match ->
            "<span class=\"math-inline\">${escape(match.groupValues[1].trim())}</span>"
        }
        // v5.4.152cc — Tightened single-dollar inline-math regex.
        //
        // Root cause of false positives: the old pattern
        //     (?<!\$)\$([^\$\n]+)\$(?!\$)
        // was greedy and matched ANYTHING between the nearest two `$`
        // characters on the same line. In prose like "costs $5 and $10",
        // it captured "5 and" as a math span.
        //
        // New guards:
        //   (?!\s*\d)  — block $ followed by optional space+digit: blocks
        //                  $5, $100, $ 50, $5.00 (currency patterns).
        //   {1,80}?     — lazy, capped at 80 chars so a lone $ can\'t
        //                  consume an entire paragraph.
        //   [^\$\n\s]  — captured content must end on a non-whitespace
        //                  char; "5 and " (trailing space) does not match.
        result = result.replace(
            Regex("""(?<!\$)\$(?!\s*\d)([^\$\n]{1,80}?[^\$\n\s])\$(?!\$)""")
        ) { match ->
            "<span class=\"math-inline\">${escape(match.groupValues[1])}</span>"
        }
        return result
    }


    /**
     * Supports Obsidian-style inline properties:
     * Key:: Value
     */
    private fun preprocessInlineProperties(src: String): String {
        return src.replace(Regex("""(?m)^([A-Za-z][A-Za-z0-9 _-]*)::\s*(.+)$""")) { match ->
            val key = match.groupValues[1].trim()
            val value = match.groupValues[2].trim()
            """<div class="markdown-property"><strong>$key</strong>: $value</div>"""
        }
    }

    /**
     * Normalizes Obsidian-style tag separators so tags remain searchable
     * when users use comma separated metadata.
     */
    private fun preprocessMetadataSeparators(src: String): String {
        return src.replace(Regex("""(?m)^tags:\s*(.+)$""")) { match ->
            "tags: ${match.groupValues[1].replace(",", " ")}"
        }
    }


    // v5.4.45c: Additional Markdown compatibility helpers.
    // Converts ==highlight== syntax into a semantic HTML mark element.
    private fun preprocessHighlights(src: String): String {
        return src.replace(Regex("""==([^=\n]+)==""")) {
            "<mark>${it.groupValues[1]}</mark>"
        }
    }

    // Supports common emoji shortcodes in offline notes.
    // v5.4.152cc — Expanded emoji shortcode table (was 5 codes, now 100+).
    // Uses the GitHub / Obsidian shortcode convention (:name:).
    // Deliberately excludes religious-cross symbols per standing style rules.
    // The map is iterated once per render; order only matters where two keys
    // share a prefix (none do here). All replacements run on plain text that
    // has already been code-protected and HTML-tag-protected, so shortcodes
    // inside code fences or HTML attribute values are never touched.
    private fun preprocessEmoji(src: String): String {
        val emojis = mapOf(
            // ── Faces / expressions ─────────────────────────────────────
            ":smile:" to "😊",
            ":smiley:" to "😃",
            ":grin:" to "😁",
            ":joy:" to "😂",
            ":rofl:" to "🤣",
            ":blush:" to "😊",
            ":wink:" to "😉",
            ":thinking:" to "🤔",
            ":hushed:" to "😯",
            ":astonished:" to "😲",
            ":open_mouth:" to "😮",
            ":sob:" to "😭",
            ":cry:" to "😢",
            ":worried:" to "😟",
            ":pensive:" to "😔",
            ":confused:" to "😕",
            ":angry:" to "😠",
            ":rage:" to "😡",
            ":scream:" to "😱",
            ":anguished:" to "😧",
            ":disappointed:" to "😞",
            ":sweat:" to "😓",
            ":sleepy:" to "😪",
            ":smirk:" to "😏",
            ":unamused:" to "😒",
            ":expressionless:" to "😑",
            ":neutral_face:" to "😐",
            ":heart_eyes:" to "😍",
            ":star_struck:" to "🤩",
            ":nerd:" to "🤓",
            ":flushed:" to "😳",
            ":lying_face:" to "🤥",
            ":shushing:" to "🤫",
            ":zipper_mouth:" to "🤐",
            ":face_with_raised_eyebrow:" to "🤨",
            ":monocle:" to "🧐",
            // ── Hands / gestures ────────────────────────────────────────
            ":pray:" to "🙏",
            ":raised_hands:" to "🙌",
            ":clap:" to "👏",
            ":+1:" to "👍",
            ":thumbsup:" to "👍",
            ":-1:" to "👎",
            ":thumbsdown:" to "👎",
            ":hand:" to "✋",
            ":raised_hand:" to "✋",
            ":wave:" to "👋",
            ":point_right:" to "👉",
            ":point_left:" to "👈",
            ":point_up:" to "☝️",
            ":point_down:" to "👇",
            ":v:" to "✌️",
            ":ok_hand:" to "👌",
            ":muscle:" to "💪",
            ":handshake:" to "🤝",
            ":open_hands:" to "👐",
            ":writing_hand:" to "✍️",
            // ── Hearts / emotions ────────────────────────────────────────
            ":heart:" to "❤️",
            ":orange_heart:" to "🧡",
            ":yellow_heart:" to "💛",
            ":green_heart:" to "💚",
            ":blue_heart:" to "💙",
            ":purple_heart:" to "💜",
            ":black_heart:" to "🖤",
            ":broken_heart:" to "💔",
            ":sparkling_heart:" to "💖",
            ":heartpulse:" to "💗",
            ":two_hearts:" to "💕",
            ":white_heart:" to "🤍",
            // ── Books / writing / study ─────────────────────────────────
            ":book:" to "📖",
            ":books:" to "📚",
            ":scroll:" to "📜",
            ":pencil:" to "✏️",
            ":pencil2:" to "✏️",
            ":pen:" to "🖊️",
            ":memo:" to "📝",
            ":notepad_spiral:" to "🗒️",
            ":clipboard:" to "📋",
            ":file_folder:" to "📁",
            ":file:" to "📄",
            ":page_facing_up:" to "📄",
            ":newspaper:" to "📰",
            ":label:" to "🏷️",
            ":bookmark:" to "🔖",
            // ── Objects / tools ─────────────────────────────────────────
            ":calendar:" to "📅",
            ":date:" to "📅",
            ":link:" to "🔗",
            ":key:" to "🔑",
            ":lock:" to "🔒",
            ":unlock:" to "🔓",
            ":bulb:" to "💡",
            ":bell:" to "🔔",
            ":no_bell:" to "🔕",
            ":mega:" to "📣",
            ":loudspeaker:" to "📢",
            ":mag:" to "🔍",
            ":magnifying_glass:" to "🔍",
            ":shield:" to "🛡️",
            ":sword:" to "⚔️",
            ":dagger:" to "🗡️",
            ":scales:" to "⚖️",
            ":crown:" to "👑",
            ":gem:" to "💎",
            ":trophy:" to "🏆",
            ":medal:" to "🏅",
            ":microphone:" to "🎤",
            ":headphones:" to "🎧",
            ":telephone:" to "📞",
            ":computer:" to "💻",
            ":inbox_tray:" to "📥",
            ":outbox_tray:" to "📤",
            ":mailbox:" to "📬",
            ":hammer:" to "🔨",
            ":wrench:" to "🔧",
            ":gear:" to "⚙️",
            ":hourglass:" to "⌛",
            ":clock:" to "🕐",
            ":alarm_clock:" to "⏰",
            ":stopwatch:" to "⏱️",
            // ── Nature / places / animals ────────────────────────────────
            ":sun:" to "☀️",
            ":sunny:" to "☀️",
            ":moon:" to "🌙",
            ":full_moon:" to "🌕",
            ":star:" to "⭐",
            ":star2:" to "🌟",
            ":sparkles:" to "✨",
            ":zap:" to "⚡",
            ":rainbow:" to "🌈",
            ":cloud:" to "☁️",
            ":rain_cloud:" to "🌧️",
            ":earth:" to "🌍",
            ":earth_americas:" to "🌎",
            ":globe_with_meridians:" to "🌐",
            ":mountain:" to "⛰️",
            ":sunrise:" to "🌅",
            ":night_with_stars:" to "🌃",
            ":city_sunrise:" to "🌇",
            ":tree:" to "🌲",
            ":evergreen_tree:" to "🌲",
            ":deciduous_tree:" to "🌳",
            ":palm_tree:" to "🌴",
            ":seedling:" to "🌱",
            ":herb:" to "🌿",
            ":rose:" to "🌹",
            ":tulip:" to "🌷",
            ":sunflower:" to "🌻",
            ":blossom:" to "🌸",
            ":bouquet:" to "💐",
            ":dove:" to "🕊️",
            ":eagle:" to "🦅",
            ":lion:" to "🦁",
            ":sheep:" to "🐑",
            ":goat:" to "🐐",
            ":cow:" to "🐄",
            ":horse:" to "🐎",
            ":camel:" to "🐪",
            ":elephant:" to "🐘",
            ":snake:" to "🐍",
            ":fish:" to "🐟",
            ":whale:" to "🐋",
            ":butterfly:" to "🦋",
            ":bee:" to "🐝",
            ":water_wave:" to "🌊",
            // ── Symbols / status / arrows ────────────────────────────────
            ":check:" to "✅",
            ":white_check_mark:" to "✅",
            ":heavy_check_mark:" to "✔️",
            ":x:" to "❌",
            ":no_entry:" to "⛔",
            ":stop_sign:" to "🛑",
            ":warning:" to "⚠️",
            ":question:" to "❓",
            ":grey_question:" to "❔",
            ":exclamation:" to "❗",
            ":grey_exclamation:" to "❕",
            ":information_source:" to "ℹ️",
            ":info:" to "ℹ️",
            ":fire:" to "🔥",
            ":boom:" to "💥",
            ":tada:" to "🎉",
            ":confetti_ball:" to "🎊",
            ":gift:" to "🎁",
            ":recycle:" to "♻️",
            ":infinity:" to "♾️",
            ":peace_symbol:" to "☮️",
            ":peace:" to "☮️",
            ":atom:" to "⚛️",
            ":yin_yang:" to "☯️",
            ":arrow_right:" to "➡️",
            ":arrow_left:" to "⬅️",
            ":arrow_up:" to "⬆️",
            ":arrow_down:" to "⬇️",
            ":arrow_upper_right:" to "↗️",
            ":arrow_lower_right:" to "↘️",
            ":arrows_counterclockwise:" to "🔄",
            ":repeat:" to "🔁",
            ":soon:" to "🔜",
            ":back:" to "🔙",
            ":sos:" to "🆘",
            ":new:" to "🆕",
            ":free:" to "🆓",
            ":100:" to "💯",
            ":abc:" to "🔤",
            ":1234:" to "🔢",
            ":hash:" to "#️⃣",
            ":asterisk:" to "*️⃣",
            // ── Misc / communication ─────────────────────────────────────
            ":speech_balloon:" to "💬",
            ":thought_balloon:" to "💭",
            ":right_anger_bubble:" to "🗯️",
            ":robot:" to "🤖",
            ":brain:" to "🧠",
            ":eyes:" to "👀",
            ":ear:" to "👂",
            ":nose:" to "👃",
            ":heart_decoration:" to "💟",
            ":zzz:" to "💤",
            ":footprints:" to "👣",
            ":art:" to "🎨",
            ":musical_note:" to "🎵",
            ":notes:" to "🎶",
            ":microphone2:" to "🎙️",
            ":camera:" to "📷",
            ":video_camera:" to "📹",
            ":compass:" to "🧭",
            ":map:" to "🗺️",
            ":flag_white:" to "🏳️",
            ":checkered_flag:" to "🏁"
        )
        var result = src
        emojis.forEach { (key, value) ->
            result = result.replace(key, value)
        }
        return result
    }


    /**
     * Adds lightweight superscript and subscript Markdown compatibility.
     * Examples:
     *   x^2^  -> x<sup>2</sup>
     *   H~2~O  -> H<sub>2</sub>O
     */
    private fun preprocessSuperscriptSubscript(src: String): String {
        var s = src.replace(Regex("""\^([^\^\n]+)\^""")) {
            "<sup>${it.groupValues[1]}</sup>"
        }
        s = s.replace(Regex("""~([^~\n]+)~""")) {
            "<sub>${it.groupValues[1]}</sub>"
        }
        return s
    }

    /**
     * v5.4.153cc — Convert __text__ to HTML underline.
     *
     * In Obsidian, **bold** is the primary bold syntax; __text__ is
     * available as a secondary alias for bold but many note authors use
     * it expecting underline (consistent with Discord, Telegram, etc.).
     * This preprocessor intercepts __text__ before flexmark sees it and
     * converts it to <u>text</u>, giving users a shorthand for underline
     * that works alongside **bold**.
     *
     * Guards:
     *   (?<![_])   — opening __ must not be preceded by _ (blocks ___)
     *   (?![_\n\s]) — opening __ must not be followed by _ newline or space
     *   ([^\n]+?)  — lazy, single-line capture (no newlines inside)
     *   (?<![\s_]) — closing __ must not be preceded by space or _
     *   (?![_])    — closing __ must not be followed by _ (blocks ___)
     *
     * Existing articles using __bold__ will render as <u>underline</u>
     * instead; **bold** is unaffected.
     */
    private fun preprocessUnderline(src: String): String {
        return src.replace(
            Regex("""(?<![_])__(?![_
\s])([^
]+?)(?<![\s_])__(?![_])""")
        ) { match ->
            "<u>${match.groupValues[1]}</u>"
        }
    }

    /**
     * Supports simple Markdown definition lists.
     * Example:
     * Term
     * : Definition
     */
    private fun preprocessDefinitionLists(src: String): String {
        return src.replace(Regex("""(?m)^(.+)\n:\s+(.+)$""")) {
            "<dl><dt>${it.groupValues[1]}</dt><dd>${it.groupValues[2]}</dd></dl>"
        }
    }


    /**
     * Improves block quote rendering by preserving multi-line quote blocks.
     */
    private fun preprocessBlockQuotes(src: String): String {
        return src.replace(Regex("""(?m)(^>\s?.+(?:\n^>\s?.+)*)""")) {
            it.value.trimEnd()
        }
    }


    /**
     * Extracts simple markdown hashtags for later filtering/search use.
     * Does not trigger indexing or scanning behaviour changes.
     */
    
    /**
     * Extracts front matter properties into a simple key/value map.
     * Keeps metadata available for future filtering without forcing reindexing.
     */
    private fun extractProperties(src: String): Map<String, String> {
        val result = linkedMapOf<String, String>()
        val block = Regex("""(?s)^---\s*\n(.*?)\n---""").find(src)?.groupValues?.get(1)
            ?: return result
        block.lines().forEach { line ->
            val parts = line.split(":", limit = 2)
            if (parts.size == 2) {
                result[parts[0].trim()] = parts[1].trim()
            }
        }
        return result
    }

    /**
     * Normalizes markdown tags for consistent filtering.
     */
    private fun normalizeTags(tags: List<String>): List<String> {
        return tags.map { it.trim().removePrefix("#").lowercase() }
            .filter { it.isNotBlank() }
            .distinct()
    }

private fun extractInlineTags(src: String): List<String> {
        return Regex("""(?m)(?:^|\s)#([A-Za-z0-9_-]+)""")
            .findAll(src)
            .map { it.groupValues[1] }
            .distinct()
            .toList()
    }


    /**
     * Extracts simple frontmatter properties for metadata display/filtering.
     */
    fun extractFrontmatterProperties(src: String): Map<String, String> {
        val block = Regex("""(?s)^---\s*(.*?)\s*---""")
            .find(src)?.groupValues?.get(1) ?: return emptyMap()
        return block.lines()
            .mapNotNull { line ->
                val parts = line.split(":", limit = 2)
                if (parts.size == 2) parts[0].trim() to parts[1].trim() else null
            }.toMap()
    }

    /**
     * Returns normalized tags for tag filtering.
     */
    fun extractNormalizedTags(src: String): List<String> {
        return Regex("""(?m)(?:^|\s)#([A-Za-z0-9_-]+)""")
            .findAll(src)
            .map { it.groupValues[1].lowercase() }
            .distinct()
            .sorted()
            .toList()
    }

private fun preprocessTags(src: String): String {
        return src.replace(Regex("(?m)(^|\\s)#([A-Za-z0-9_-]+)")) { m ->
            val prefix = m.groupValues[1]
            val tag = m.groupValues[2]
            // v5.4.151cc — Skip CSS hex color codes (3, 6, or 8 hex digits).
            // Belt-and-suspenders alongside protectInlineHtmlTags: even if a
            // bare #hex appears in plain prose text (not inside an HTML tag),
            // it is a color reference, not a topic tag, and should not be
            // linkified as one.
            val isHexColor = tag.matches(Regex("[0-9a-fA-F]{3}")) ||
                tag.matches(Regex("[0-9a-fA-F]{6}")) ||
                tag.matches(Regex("[0-9a-fA-F]{8}"))
            if (isHexColor) m.value
            else """$prefix<a class="tag" href="mv://tag/$tag">#$tag</a>"""
        }
    }

    // ── Mermaid diagram blocks ──────────────────────────────────────────
    // v5.4.37c: Mermaid code fences get converted to a <div class="mermaid">
    // that render.js's Mermaid init picks up.
    //
    // v5.4.124cc — Callout conversion (`> [!NOTE]`) used to also happen
    // here, producing a plain `<div class="callout $type">` with no icon,
    // no fold/collapse support, and titles-on-the-same-line silently
    // broken (the regex required the callout marker to be immediately
    // followed by a newline). That duplicated -- and completely shadowed
    // -- a full, already-CSS-styled, already-wired callout renderer that
    // already existed in render.js's transformCallouts(): it operates on
    // the real `<blockquote>` element flexmark produces, which it never
    // got a chance to see, because this function was rewriting the
    // callout's source text into a plain `<div>` before flexmark ever
    // ran. Removed the Kotlin-side callout conversion entirely so raw
    // `> [!TYPE]` blockquotes now reach flexmark (and therefore
    // render.js) unmodified -- icons, fold/collapse, custom titles, and
    // the fuller type-alias table in render.js's ALIAS map all now work
    // without any new code, because they were already built and simply
    // never got a real blockquote to operate on.
    private fun preprocessMermaid(src: String): String {
        return src.replace(
            Regex("""```mermaid\s*\n([\s\S]*?)```""")
        ) { match ->
            "<div class=\"mermaid\">\n${match.groupValues[1]}\n</div>"
        }
    }

    // ── Code-fence / inline-code protection ─────────────────────────────
    // v5.4.124cc — Every preprocessing pass below (math, highlights,
    // super/subscript, definition lists, tags, properties, etc.) is a raw
    // regex substitution over the ENTIRE markdown string, with no
    // awareness of fenced or inline code. Before this fix, a code sample
    // containing e.g. `if x == 5:`, `$5.00`, or `H~2~O` as literal text
    // would get silently mangled by the highlight/math/subscript passes
    // meant for prose -- because nothing ever protected code regions from
    // them. [protectCodeSpans] replaces every fenced block (```...```)
    // and inline span (`...`) with an opaque placeholder before any of
    // those passes run; [restoreCodeSpans] puts the original text back
    // immediately before flexmark parses the result, so flexmark's own
    // (correct, unaffected) code handling takes it from there.
    //
    // Must run AFTER [preprocessMermaid] -- mermaid fences need to still
    // be real ``` fences when that function looks for them -- and AFTER
    // [sanitize], which strips XSS-risky tags from the whole document
    // (including inside code examples) as defence-in-depth; narrowing
    // that guarantee to skip code blocks is a deliberate security
    // decision, not a rendering nicety, so it's out of scope here.
    private val FENCE_REGEX = Regex("""(?m)^```[^\n]*\n[\s\S]*?^```[ \t]*$""")
    private val INLINE_CODE_REGEX = Regex("""`[^`\n]+`""")

    private data class ProtectedCode(val text: String, val blocks: List<String>)

    private fun protectCodeSpans(src: String): ProtectedCode {
        val blocks = ArrayList<String>()
        var result = FENCE_REGEX.replace(src) { match ->
            blocks.add(match.value)
            "\u0001MVCODE${blocks.size - 1}\u0002"
        }
        result = INLINE_CODE_REGEX.replace(result) { match ->
            blocks.add(match.value)
            "\u0001MVCODE${blocks.size - 1}\u0002"
        }
        return ProtectedCode(result, blocks)
    }

    private fun restoreCodeSpans(protected: ProtectedCode, currentText: String): String {
        var result = currentText
        for (i in protected.blocks.indices) {
            result = result.replace("\u0001MVCODE$i\u0002", protected.blocks[i])
        }
        return result
    }

    // ── Inline HTML tag protection (v5.4.151cc) ───────────────────────────
    //
    // ROOT CAUSE of the "raw <span> tags showing as text" bug:
    //   preprocessTags was running a regex over the ENTIRE source string,
    //   including inside HTML attribute values. When an article had
    //   `<span style="color: #2d5aa6;">`, preprocessTags matched `#2d5aa6`
    //   (preceded by a space) and replaced it with:
    //       <a class="tag" href="mv://tag/2d5aa6">#2d5aa6</a>
    //   This inserted a second `"` inside the outer attribute value, breaking
    //   the span tag's HTML syntax. flexmark then could not recognise
    //   `<span style="color: ` as a valid inline HTML tag — it treated the
    //   whole fragment as a TEXT node. flexmark's TypographicExtension then
    //   converted the attribute's ASCII quotes to curly smart quotes, and the
    //   renderer output the angle-bracket text as visible escaped characters.
    //   Result: the browser showed `<span style="color: #2d5aa6;">` as literal
    //   text with curly quotes, exactly as seen in the bug report screenshot.
    //
    // FIX: before any text-substitution preprocessor runs, replace every
    //   inline HTML tag (opening, closing, self-closing, comments) with an
    //   opaque placeholder. Text preprocessors therefore never see attribute
    //   content. After all text processing, the original tags are restored.
    //
    // Uses \u0003 / \u0004 sentinels — different from protectCodeSpans'
    //   \u0001 / \u0002 — so both can coexist in the same pipeline.
    //
    // Must run AFTER protectCodeSpans (code already protected) and AFTER
    //   preprocessEmbeds (embed HTML generated before protection).

    private val INLINE_HTML_TAG_REGEX = Regex(
        """(?s)<!--.*?-->|</?[a-zA-Z][a-zA-Z0-9:-]*(?:\s[^>]*)?>"""
    )

    private data class ProtectedHtmlTags(val text: String, val tags: List<String>)

    private fun protectInlineHtmlTags(src: String): ProtectedHtmlTags {
        val tags = ArrayList<String>()
        val result = INLINE_HTML_TAG_REGEX.replace(src) { match ->
            tags.add(match.value)
            "\u0003MVTAG${tags.size - 1}\u0004"
        }
        return ProtectedHtmlTags(result, tags)
    }

    private fun restoreInlineHtmlTags(protected: ProtectedHtmlTags, text: String): String {
        var result = text
        for (i in protected.tags.indices) {
            result = result.replace("\u0003MVTAG$i\u0004", protected.tags[i])
        }
        return result
    }

    // ── Sanitisation ─────────────────────────────────────────────────────
    //
    // Two jobs:
    //   1. Strip the residual `sm-num` / `sm-acronym` etc. fragments left
    //      in some `.md` files by earlier buggy MarkVault builds.
    //   2. Strip XSS-risky tags before HTML rendering. Defence-in-depth —
    //      the source is user-authored but may contain pasted web content.

    private val SM_ARTEFACT_REGEX = Regex(
        """[\u201C\u201D\u2018\u2019"']?sm-(?:ref|num|pct|acronym|quotechar|key|date|cap)[\u201C\u201D\u2018\u2019"']?>+"""
    )
    private val SM_SPAN_OPEN_CLOSE = Regex(
        """<span\s+class\s*=\s*["']sm-[a-z]+["']\s*>([\s\S]*?)</span>""",
        RegexOption.IGNORE_CASE
    )
    private val SM_SPAN_OPEN_ONLY = Regex(
        """<span\s+class\s*=\s*["']sm-[a-z]+["']\s*>""",
        RegexOption.IGNORE_CASE
    )
    private val SCRIPT_BLOCK = Regex("""<script[^>]*>[\s\S]*?</script>""", RegexOption.IGNORE_CASE)
    private val SCRIPT_SELF = Regex("""<script[^>]*/\s*>""", RegexOption.IGNORE_CASE)
    private val IFRAME_BLOCK = Regex("""<iframe[^>]*>[\s\S]*?</iframe>""", RegexOption.IGNORE_CASE)
    private val OBJECT_BLOCK = Regex("""<object[^>]*>[\s\S]*?</object>""", RegexOption.IGNORE_CASE)
    private val EMBED_TAG = Regex("""<embed[^>]*/?>""", RegexOption.IGNORE_CASE)
    // Inline event handlers like onclick="..." / onerror='...'. Match the
    // attribute name and its quoted value as a unit.
    //
    // The double-quoted variant ends with a literal `"` character. In Kotlin
    // a raw string ending in `""""` is ambiguous (3 quotes = end of string,
    // 4th quote = start of a new unterminated string → compile error). The
    // ${'"'} interpolation embeds a literal `"` and resolves the ambiguity.
    private val INLINE_EVENT_DQ = Regex(
        """\son[a-z]+\s*=\s*"[^"]*${'"'}""",
        RegexOption.IGNORE_CASE
    )
    private val INLINE_EVENT_SQ = Regex("""\son[a-z]+\s*=\s*'[^']*'""", RegexOption.IGNORE_CASE)
    private val JS_HREF = Regex("""href\s*=\s*["']?\s*javascript:""", RegexOption.IGNORE_CASE)

    private fun sanitize(src: String): String {
        if (src.isBlank()) return ""
        var s = src
        // Smart-styling artefact cleanup. Order matters: opener-closer pair
        // first (preserves inner content), then bare opener, then bare
        // attribute fragment.
        s = s.replace(SM_SPAN_OPEN_CLOSE, "$1")
        s = s.replace(SM_SPAN_OPEN_ONLY, "")
        s = s.replace(SM_ARTEFACT_REGEX, "")
        // XSS hardening
        s = s.replace(SCRIPT_BLOCK, "")
        s = s.replace(SCRIPT_SELF, "")
        s = s.replace(IFRAME_BLOCK, "")
        s = s.replace(OBJECT_BLOCK, "")
        s = s.replace(EMBED_TAG, "")
        s = s.replace(INLINE_EVENT_DQ, "")
        s = s.replace(INLINE_EVENT_SQ, "")
        s = s.replace(JS_HREF, "href=\"#blocked-javascript\"")
        return s
    }

    /**
     * Convert a markdown source string into production-ready HTML, suitable
     * to drop into a WebView via `element.innerHTML = ...`.
     *
     * [resolveEmbed], if provided, resolves an `![[Note]]` embed target to
     * that note's raw markdown content (the caller has DB access;
     * MarkdownEngine deliberately doesn't). Without it, note embeds render
     * as a visible "not found" placeholder rather than expanding — image
     * embeds don't need it. [embedDepth]/[seenEmbeds] are internal
     * recursion bookkeeping for nested embeds; callers should leave them
     * at their defaults.
     *
     * Pipeline:
     *   markdown
     *      → sanitize (strip sm-* artefacts + XSS-risky tags)
     *      → preprocessMermaid (```mermaid fences → <div class="mermaid">)
     *      → protectCodeSpans (fenced/inline code → opaque placeholders)
     *      → preprocessEmbeds (`![[Note]]` / `![[image.png]]` expansion —
     *        must run before wikilinks, see preprocessEmbeds doc)
     *      → [syntax preprocessors: math, footnotes, highlights, emoji,
     *         properties, metadata, super/subscript, definition lists,
     *         block quotes, tags] — all safe from code contamination now
     *      → preprocessWikilinks (`[[Note]]` → `<a class="wikilink" …>`)
     *      → restoreCodeSpans (placeholders → original fenced/inline code)
     *      → flexmark parse (sees real ``` fences and `code` spans again,
     *        plus real `> [!TYPE]` blockquotes for render.js to style)
     *      → flexmark render
     *      → HTML string
     */
    /**
     * Convert a markdown source string into production-ready HTML, suitable
     * to drop into a WebView via `element.innerHTML = ...`.
     *
     * [resolveEmbed], if provided, resolves an `![[Note]]` embed target to
     * that note's raw markdown content (the caller has DB access;
     * MarkdownEngine deliberately doesn't). Without it, note embeds render
     * as a visible "not found" placeholder rather than expanding — image
     * embeds don't need it. [embedDepth]/[seenEmbeds] are internal
     * recursion bookkeeping for nested embeds; callers should leave them
     * at their defaults.
     *
     * Pipeline (v5.4.151cc):
     *   markdown
     *      → sanitize (strip sm-* artefacts + XSS-risky tags)
     *      → preprocessMermaid (```mermaid fences → <div class="mermaid">)
     *      → protectCodeSpans (fenced/inline code → opaque placeholders)
     *      → preprocessEmbeds (![[Note]] expansion — before HTML protection
     *        so embed-generated divs are also shielded from text preprocessors)
     *      → protectInlineHtmlTags (v5.4.151cc — all HTML tags → opaque
     *        placeholders; fixes the #hex-in-attribute corruption bug)
     *      → [text preprocessors: math, footnotes, highlights, emoji,
     *         properties, metadata, super/subscript, definition lists,
     *         block quotes, tags] — none can reach inside HTML attributes now
     *      → preprocessWikilinks ([[Note]] → <a class="wikilink" …>)
     *      → restoreInlineHtmlTags (v5.4.151cc — HTML placeholders → original
     *        tags; wikilink anchors stay as new HTML flexmark will see)
     *      → restoreCodeSpans (code placeholders → original fenced/inline code)
     *      → flexmark parse + render
     *      → HTML string
     */
    suspend fun render(
        markdown: String,
        embedDepth: Int = 0,
        seenEmbeds: Set<String> = emptySet(),
        resolveEmbed: (suspend (String) -> String?)? = null
    ): String {
        val markdownContent = preprocessFrontMatter(markdown)
        if (markdown.isBlank()) return ""
        val sanitized = sanitize(markdownContent)
        val withMermaid = preprocessMermaid(sanitized)
        val protected = protectCodeSpans(withMermaid)
        // Expand embeds BEFORE HTML-tag protection so that the generated
        // <div class="markdown-embed"> containers are also shielded.
        val withEmbeds = preprocessEmbeds(protected.text, resolveEmbed, embedDepth, seenEmbeds)
        // v5.4.151cc — Shield every inline HTML tag from text preprocessors.
        // No preprocessor below can corrupt CSS attribute values now.
        val htmlProtected = protectInlineHtmlTags(withEmbeds)
        val withMath = preprocessMath(htmlProtected.text)
        val withFootnotes = preprocessFootnotes(withMath)
        val withHighlights = preprocessHighlights(withFootnotes)
        val withEmoji = preprocessEmoji(withHighlights)
        val withProperties = preprocessInlineProperties(withEmoji)
        val withMetadata = preprocessMetadataSeparators(withProperties)
        val withSuperSub = preprocessSuperscriptSubscript(withMetadata)
        val withUnderline = preprocessUnderline(withSuperSub)   // v5.4.153cc
        val withDefinitions = preprocessDefinitionLists(withUnderline)
        val withQuotes = preprocessBlockQuotes(withDefinitions)
        val withTags = preprocessTags(withQuotes)
        val withWikilinks = preprocessWikilinks(withTags)
        // v5.4.151cc — Restore HTML tags. Wikilink <a> anchors added above
        // appear between restored tags; flexmark parses all correctly.
        val restoredHtml = restoreInlineHtmlTags(htmlProtected, withWikilinks)
        val restored = restoreCodeSpans(protected, restoredHtml)
        val document = parser.parse(restored)
        return renderer.render(document)
    }
}

/**
 * Extension entry point matching the form requested by the migration spec.
 *
 * Usage:
 * ```kotlin
 * val html = note.content.markdownToHtml()
 * webView.evaluateJavascript("renderMarkdown(${jsString(html)}, …)", null)
 * ```
 */
suspend fun String.markdownToHtml(): String = MarkdownEngine.render(this)
