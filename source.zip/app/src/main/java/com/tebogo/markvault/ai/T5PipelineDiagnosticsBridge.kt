package com.tebogo.markvault.ai

object T5PipelineDiagnosticsBridge {
    fun record(mode: T5ExpansionMode, queries: List<String>) {
        T5PipelineLogger.record(
            T5QueryTrace(mode.name, queries, 0L, null)
        )
    }
}
