package com.tebogo.markvault.ai

import java.io.File

class T5DownloadManager {
    fun prepareDestination(base: File): File {
        val dir = File(base, "models/t5-base")
        dir.mkdirs()
        return dir
    }
}
