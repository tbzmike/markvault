package com.tebogo.markvault.ai

/** Coordinates T5 model download state. */
object T5DownloadManager {
    private var progress: Int = 0
    private var installed: Boolean = false

    fun progress(): Int = progress
    fun isInstalled(): Boolean = installed

    fun updateProgress(value: Int) { progress = value.coerceIn(0, 100) }
    fun markInstalled() { installed = true; progress = 100 }
}
