package com.tebogo.markvault.ui

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.navigation.NavController
import com.tebogo.markvault.AppViewModel
import com.tebogo.markvault.data.MediaItem
import com.tebogo.markvault.data.Playlist

/**
 * v5.4.255cc — Browse and play named playlists (see data/Playlist.kt).
 * Two levels: the playlist list itself, and — when one is tapped — its
 * contents (via vm.getPlaylistContents), with a Play button that loads
 * the whole thing as the current queue (vm.playPlaylist).
 */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun PlaylistsScreen(vm: AppViewModel, nav: NavController) {
    val playlists by vm.playlists.collectAsStateWithLifecycle()
    var openPlaylist by remember { mutableStateOf<Playlist?>(null) }
    var deleteTarget by remember { mutableStateOf<Playlist?>(null) }

    LaunchedEffect(Unit) { vm.loadPlaylists() }

    BackHandler(enabled = openPlaylist != null) { openPlaylist = null }

    if (openPlaylist == null) {
        Scaffold(
            topBar = {
                TopAppBar(
                    title = { Text("\uD83C\uDFB5 Playlists") },
                    navigationIcon = {
                        IconButton(onClick = { nav.popBackStack() }) {
                            Icon(Icons.Default.ArrowBack, contentDescription = "Back")
                        }
                    }
                )
            },
            bottomBar = { MarkVaultBottomBar(nav = nav, vm = vm) }
        ) { pad ->
            if (playlists.isEmpty()) {
                Box(
                    modifier = Modifier.fillMaxSize().padding(pad),
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        "No playlists yet.\nLong-press media in the video browser, or use \u2795 Add to Playlist, to create one.",
                        fontSize = 14.sp,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        modifier = Modifier.padding(24.dp)
                    )
                }
            } else {
                LazyColumn(modifier = Modifier.fillMaxSize().padding(pad)) {
                    items(playlists, key = { it.id }) { pl ->
                        Card(
                            onClick = { openPlaylist = pl },
                            modifier = Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 4.dp),
                            shape = RoundedCornerShape(10.dp)
                        ) {
                            Row(
                                modifier = Modifier.padding(14.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text("\uD83C\uDFB5", fontSize = 20.sp)
                                Spacer(Modifier.width(12.dp))
                                Column(modifier = Modifier.weight(1f)) {
                                    Text(pl.name, fontWeight = FontWeight.Medium, fontSize = 14.sp)
                                    Text(
                                        "${pl.idList().size} item${if (pl.idList().size == 1) "" else "s"}",
                                        fontSize = 11.sp,
                                        color = MaterialTheme.colorScheme.onSurfaceVariant
                                    )
                                }
                                IconButton(onClick = { deleteTarget = pl }) {
                                    Text("\uD83D\uDDD1", fontSize = 16.sp)
                                }
                            }
                        }
                    }
                    item { Spacer(Modifier.height(16.dp)) }
                }
            }
        }
    } else {
        PlaylistDetailScreen(
            vm = vm,
            playlist = openPlaylist!!,
            onBack = { openPlaylist = null }
        )
    }

    deleteTarget?.let { pl ->
        AlertDialog(
            onDismissRequest = { deleteTarget = null },
            title = { Text("Delete Playlist") },
            text = { Text("Delete \u201C${pl.name}\u201D? This can't be undone.") },
            confirmButton = {
                TextButton(onClick = {
                    vm.deletePlaylist(pl.id)
                    if (openPlaylist?.id == pl.id) openPlaylist = null
                    deleteTarget = null
                }) { Text("Delete") }
            },
            dismissButton = {
                TextButton(onClick = { deleteTarget = null }) { Text("Cancel") }
            }
        )
    }
}

/** v5.4.255cc — A single playlist's contents, with a Play button that loads it as the current queue. */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun PlaylistDetailScreen(vm: AppViewModel, playlist: Playlist, onBack: () -> Unit) {
    var contents by remember { mutableStateOf<List<MediaItem>>(emptyList()) }
    var loading by remember { mutableStateOf(true) }

    LaunchedEffect(playlist.id) {
        loading = true
        contents = vm.getPlaylistContents(playlist)
        loading = false
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text(playlist.name, maxLines = 1, overflow = TextOverflow.Ellipsis) },
                navigationIcon = {
                    IconButton(onClick = onBack) {
                        Icon(Icons.Default.ArrowBack, contentDescription = "Back")
                    }
                },
                actions = {
                    if (contents.isNotEmpty()) {
                        TextButton(onClick = { vm.playPlaylist(playlist) }) {
                            Text("\u25B6 Play All")
                        }
                    }
                }
            )
        }
    ) { pad ->
        if (loading) {
            Box(Modifier.fillMaxSize().padding(pad), contentAlignment = Alignment.Center) {
                CircularProgressIndicator()
            }
        } else if (contents.isEmpty()) {
            Box(Modifier.fillMaxSize().padding(pad), contentAlignment = Alignment.Center) {
                Text(
                    "This playlist is empty.",
                    fontSize = 14.sp,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
        } else {
            LazyColumn(modifier = Modifier.fillMaxSize().padding(pad)) {
                itemsIndexed(contents, key = { _, m -> m.id }) { idx, media ->
                    Box(modifier = Modifier.padding(horizontal = 12.dp, vertical = 4.dp)) {
                        MediaResultCard(
                            item = media,
                            onPlay = { vm.playPlaylist(playlist, startIndex = idx) },
                            onToggleFavourite = { vm.toggleMediaFavourite(media) },
                            onLongPress = {
                                vm.removeFromPlaylist(playlist.id, media.id)
                                contents = contents.filter { it.id != media.id }
                            }
                        )
                    }
                }
                item { Spacer(Modifier.height(16.dp)) }
            }
        }
    }
}
