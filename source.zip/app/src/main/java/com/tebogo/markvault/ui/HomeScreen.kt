package com.tebogo.markvault.ui

import android.text.format.DateUtils
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material3.Button
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.navigation.NavController
import com.tebogo.markvault.AppViewModel
import com.tebogo.markvault.data.RecentNote
import com.tebogo.markvault.data.TopicCard

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun HomeScreen(vm: AppViewModel, nav: NavController) {
    val libraryUri by vm.libraryUri.collectAsStateWithLifecycle()
    val notes by vm.notes.collectAsStateWithLifecycle()
    val recent by vm.recent.collectAsStateWithLifecycle()
    val topics by vm.topics.collectAsStateWithLifecycle()
    val progress by vm.progress.collectAsStateWithLifecycle()

    val picker = rememberLauncherForActivityResult(
        ActivityResultContracts.OpenDocumentTree()
    ) { uri -> if (uri != null) vm.setLibrary(uri) }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("\uD83D\uDCDA MarkVault", fontWeight = FontWeight.Bold) },
                actions = {
                    if (libraryUri != null && !progress.running) {
                        IconButton(onClick = { vm.reindex() }) {
                            Icon(Icons.Default.Refresh, contentDescription = "Sync library")
                        }
                    }
                    IconButton(onClick = { nav.navigate("settings") }) {
                        Icon(Icons.Default.Settings, contentDescription = "Settings")
                    }
                }
            )
        }
    ) { pad ->
        Column(Modifier.padding(pad).fillMaxSize()) {
            if (progress.running) {
                LinearProgressIndicator(Modifier.fillMaxWidth())
                Text(
                    "\u23F3 ${progress.phase} ${progress.done} / ${progress.total}",
                    Modifier.padding(horizontal = 16.dp, vertical = 6.dp),
                    fontSize = 13.sp, color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }

            when {
                libraryUri == null -> WelcomeState { picker.launch(null) }
                notes.isEmpty() && !progress.running ->
                    EmptyState(onReindex = { vm.reindex() }, onChange = { picker.launch(null) })
                else -> Dashboard(vm, nav, recent, topics, notes.size)
            }
        }
    }
}

@Composable
private fun Dashboard(
    vm: AppViewModel,
    nav: NavController,
    recent: List<RecentNote>,
    topics: List<TopicCard>,
    noteCount: Int
) {
    LazyColumn(Modifier.fillMaxSize()) {
        item {
            Surface(
                color = MaterialTheme.colorScheme.surfaceVariant,
                shape = RoundedCornerShape(12.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp, vertical = 10.dp)
                    .clickable { nav.navigate("search") }
            ) {
                Row(
                    Modifier.padding(horizontal = 14.dp, vertical = 13.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(
                        Icons.Default.Search, contentDescription = null,
                        tint = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                    Spacer(Modifier.width(10.dp))
                    Text(
                        "Search $noteCount notes by word or topic\u2026",
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }
        }

        item {
            Row(
                Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 2.dp),
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                OutlinedButton(onClick = { nav.navigate("browse") }, modifier = Modifier.weight(1f)) {
                    Text("\uD83D\uDCC1 Browse files")
                }
                OutlinedButton(onClick = { nav.navigate("topics") }, modifier = Modifier.weight(1f)) {
                    Text("\uD83E\uDDED All topics")
                }
            }
        }

        if (recent.isNotEmpty()) {
            item { SectionHeader("\u25B6\uFE0F  Continue reading") }
            item {
                LazyRow(
                    Modifier.fillMaxWidth().padding(vertical = 4.dp),
                    horizontalArrangement = Arrangement.spacedBy(10.dp),
                    contentPadding = androidx.compose.foundation.layout.PaddingValues(horizontal = 16.dp)
                ) {
                    items(recent, key = { it.id }) { r ->
                        RecentCard(r) {
                            vm.openArticle(r.id, r.title)
                            nav.navigate("reader") { launchSingleTop = true }
                        }
                    }
                }
            }
        }

        if (topics.isNotEmpty()) {
            item { SectionHeader("\uD83E\uDDED  Topics in your library") }
            items(topics.chunked(2)) { pair ->
                Row(
                    Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 5.dp),
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    for (t in pair) {
                        TopicCardView(t, Modifier.weight(1f)) { nav.navigate("topic/${t.key}") }
                    }
                    if (pair.size == 1) Spacer(Modifier.weight(1f))
                }
            }
        }

        item { Spacer(Modifier.height(28.dp)) }
    }
}

@Composable
private fun SectionHeader(text: String) {
    Text(
        text,
        Modifier.padding(start = 18.dp, end = 16.dp, top = 16.dp, bottom = 2.dp),
        fontWeight = FontWeight.Bold, fontSize = 15.sp
    )
}

@Composable
private fun RecentCard(r: RecentNote, onClick: () -> Unit) {
    val rel = remember(r.lastOpened) {
        DateUtils.getRelativeTimeSpanString(
            r.lastOpened, System.currentTimeMillis(), DateUtils.MINUTE_IN_MILLIS
        ).toString()
    }
    Surface(
        color = MaterialTheme.colorScheme.surfaceVariant,
        shape = RoundedCornerShape(12.dp),
        modifier = Modifier.widthIn(min = 180.dp, max = 220.dp).clickable(onClick = onClick)
    ) {
        Column(Modifier.padding(14.dp)) {
            Text("\uD83D\uDCC4", fontSize = 18.sp)
            Spacer(Modifier.height(6.dp))
            Text(
                r.title, fontWeight = FontWeight.SemiBold, fontSize = 14.sp,
                maxLines = 2, overflow = TextOverflow.Ellipsis, lineHeight = 18.sp
            )
            Spacer(Modifier.height(6.dp))
            Text(rel, fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
    }
}

@Composable
private fun TopicCardView(t: TopicCard, modifier: Modifier, onClick: () -> Unit) {
    Surface(
        color = MaterialTheme.colorScheme.surfaceVariant,
        shape = RoundedCornerShape(14.dp),
        modifier = modifier.clickable(onClick = onClick)
    ) {
        Row(
            Modifier.padding(14.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(t.emoji, fontSize = 26.sp)
            Spacer(Modifier.width(12.dp))
            Column {
                Text(t.label, fontWeight = FontWeight.SemiBold, fontSize = 15.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                Text(
                    "${t.count} note${if (t.count == 1) "" else "s"}",
                    fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
        }
    }
}

@Composable
private fun WelcomeState(onPick: () -> Unit) {
    Column(
        Modifier.fillMaxSize().padding(32.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        Text("\uD83D\uDCDA", fontSize = 64.sp)
        Spacer(Modifier.height(16.dp))
        Text("Welcome to MarkVault", fontSize = 20.sp, fontWeight = FontWeight.Bold)
        Spacer(Modifier.height(8.dp))
        Text(
            "Choose the folder that holds your Markdown library. " +
                "Everything is indexed and stays 100% on this phone.",
            color = MaterialTheme.colorScheme.onSurfaceVariant, textAlign = TextAlign.Center
        )
        Spacer(Modifier.height(24.dp))
        Button(onClick = onPick) { Text("\uD83D\uDCC1  Choose library folder") }
    }
}

@Composable
private fun EmptyState(onReindex: () -> Unit, onChange: () -> Unit) {
    Column(
        Modifier.fillMaxSize().padding(32.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        Text("No .md files indexed yet.", color = MaterialTheme.colorScheme.onSurfaceVariant)
        Spacer(Modifier.height(12.dp))
        Button(onClick = onReindex) { Text("\u21BB  Index now") }
        Spacer(Modifier.height(12.dp))
        Text(
            "\uD83D\uDCC1 Choose a different folder",
            Modifier.clickable(onClick = onChange).padding(8.dp),
            color = MaterialTheme.colorScheme.primary
        )
    }
}
