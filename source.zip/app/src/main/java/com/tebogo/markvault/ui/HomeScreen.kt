package com.tebogo.markvault.ui

import android.text.format.DateUtils
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.clickable
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.layout.wrapContentHeight
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material3.Button
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.blur
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.navigation.NavController
import com.tebogo.markvault.AppViewModel
import com.tebogo.markvault.OpenSource
import com.tebogo.markvault.data.NoteMeta
import com.tebogo.markvault.data.RecentNote
import com.tebogo.markvault.data.TopicCard
import androidx.compose.foundation.layout.fillMaxHeight

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun HomeScreen(vm: AppViewModel, nav: NavController) {
    val libraryUri by vm.libraryUri.collectAsStateWithLifecycle()
    val notes by vm.notes.collectAsStateWithLifecycle()
    val recent by vm.recent.collectAsStateWithLifecycle()
    val topics by vm.topics.collectAsStateWithLifecycle()
    val progress by vm.progress.collectAsStateWithLifecycle()
    val newNotes by vm.newNotes.collectAsStateWithLifecycle()
    val favouriteNotes by vm.favouriteNotes.collectAsStateWithLifecycle()
    val suggested by vm.suggested.collectAsStateWithLifecycle()
    val recentSources by vm.recentOpenSources.collectAsStateWithLifecycle()
    // v5.4.36 — User preference: vertical vs horizontal scrolling for
    // home-screen article rows (Favourites, Continue reading, etc).
    val homeVertical by vm.homeScrollVertical.collectAsStateWithLifecycle()

    val picker = rememberLauncherForActivityResult(
        ActivityResultContracts.OpenDocumentTree()
    ) { uri -> if (uri != null) vm.setLibrary(uri) }

    // v5.4.33 — Detect tablet layout BEFORE Scaffold so we can
    // conditionally hide the TopAppBar (sidebar already has the title).
    val screenWidthDp = androidx.compose.ui.platform.LocalConfiguration.current.screenWidthDp
    val isTabletWidth = screenWidthDp >= 600
    val uiMode by vm.uiMode.collectAsStateWithLifecycle()
    val workspaceOn = uiMode == "workspace"
    val useTabletLayout = workspaceOn && isTabletWidth

    Scaffold(
        topBar = {
            // v5.4.33 — Skip TopAppBar in tablet layout; the sidebar
            // already shows "MarkVault" and vertical space is precious.
            if (!useTabletLayout) {
                TopAppBar(
                    title = { Text("\uD83D\uDCDA MarkVault", fontWeight = FontWeight.Bold) }
                )
            }
        },
        bottomBar = {
            MarkVaultBottomBar(
                nav = nav, vm = vm,
                showBack = false,
                extraActions = {
                    if (libraryUri != null && !progress.running) {
                        IconButton(onClick = { vm.reindex() }) {
                            Icon(Icons.Default.Refresh, contentDescription = "Sync library")
                        }
                    }
                    IconButton(onClick = { nav.navigate("search") }) {
                        Icon(Icons.Default.Search, contentDescription = "Search library")
                    }
                }
            )
        }
    ) { pad ->

        Row(Modifier.padding(pad).fillMaxSize()) {
            if (useTabletLayout) {
                HomeTabletSidebar(
                    vm = vm,
                    nav = nav,
                    recentArticles = recent,
                    modifier = Modifier.width(280.dp).fillMaxHeight()
                )
                androidx.compose.material3.VerticalDivider()
            }
            Column(Modifier.weight(1f).fillMaxHeight()) {
            if (progress.running) {
                LinearProgressIndicator(Modifier.fillMaxWidth())
                Text(
                    "\u23F3 ${progress.phase} ${progress.done} / ${progress.total}",
                    Modifier.padding(horizontal = 16.dp, vertical = 6.dp),
                    fontSize = 13.sp, color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
            when {
                libraryUri == null -> WelcomeState { picker.launch(null) }
                notes.isEmpty() && !progress.running ->
                    EmptyState(onReindex = { vm.reindex() }, onChange = { picker.launch(null) })
                else -> Dashboard(vm, nav, recent, topics, newNotes, favouriteNotes, suggested, recentSources, notes.size, useTabletLayout, homeVertical)
            }
        }
        } // v5.4.32 — close outer Row
    }
}

@Composable
private fun Dashboard(
    vm: AppViewModel,
    nav: NavController,
    recent: List<RecentNote>,
    topics: List<TopicCard>,
    newNotes: List<NoteMeta>,
    favouriteNotes: List<NoteMeta>,
    suggested: List<NoteMeta>,
    recentSources: Map<Long, OpenSource>,
    noteCount: Int,
    compact: Boolean = false,
    homeVertical: Boolean = false
) {
    /** Open a note in the correct viewer based on its file type. */
    fun openNote(id: Long, title: String, fileType: String) {
        when (fileType) {
            "pdf" -> {
                vm.openArticle(id, title, fileType = "pdf")
                nav.navigate("pdfReader/$id")
            }
            "mhtml", "html" -> {
                // v4.4 — saved offline web archives go to the WebView-backed
                // reader. Avoid the markdown engine, which can't parse MHTML
                // headers and crashes on the binary content.
                vm.openArticle(id, title, fileType = fileType)
                nav.navigate("htmlReader/$id")
            }
            else -> {
                vm.openArticle(id, title)
                nav.navigate("reader") { launchSingleTop = true }
            }
        }
    }

    // v5.0.0 — Hero search overlay state. When true, content behind is
    // blurred and a big centered search bar takes focus. Tap-away on the
    // dim/blur backdrop dismisses the focus. Defaults to true on entry so
    // search is the first thing the user sees.
    var heroSearchFocused by remember { mutableStateOf(true) }
    val backdropBlur = if (heroSearchFocused) 18.dp else 0.dp

    Box(Modifier.fillMaxSize()) {
    LazyColumn(
        Modifier
            .fillMaxSize()
            .blur(backdropBlur)
    ) {
        // Quick-action buttons. Topics removed in v5.0.0 per the
        // homepage redesign; topic-based query expansion still happens
        // in the search backend, just no longer surfaced as a UI section.
        item {
            // v5.4.33 — In tablet/landscape, reduce the hero search
            // clearance since vertical space is scarce.
            Spacer(Modifier.height(if (compact) 52.dp else 96.dp))
        }
        item {
            Row(
                Modifier.fillMaxWidth().padding(
                    horizontal = if (compact) 8.dp else 16.dp,
                    vertical = 2.dp
                ),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                OutlinedButton(onClick = { nav.navigate("browse") }, modifier = Modifier.weight(1f)) {
                    Text("\uD83D\uDCC1 Browse")
                }
                OutlinedButton(onClick = { nav.navigate("graph") }, modifier = Modifier.weight(1f)) {
                    Text("\uD83C\uDF10 Graph")
                }
            }
        }
        // ⭐ Favourites
        if (favouriteNotes.isNotEmpty()) {
            item { SectionHeader("\u2B50  Favourites", compact) }
            if (homeVertical) {
                items(favouriteNotes, key = { it.id }) { n ->
                    FavouriteCard(n, modifier = Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 5.dp)) { openNote(n.id, n.title, n.fileType) }
                }
            } else {
            item {
                LazyRow(
                    Modifier.fillMaxWidth().padding(vertical = 4.dp),
                    horizontalArrangement = Arrangement.spacedBy(10.dp),
                    contentPadding = PaddingValues(horizontal = if (compact) 8.dp else 16.dp)
                ) {
                    items(favouriteNotes, key = { it.id }) { n ->
                        FavouriteCard(n) {
                            openNote(n.id, n.title, n.fileType)
                        }
                    }
                }
            }
            }
        }
        // ✨ New since last sync
        if (newNotes.isNotEmpty()) {
            item { SectionHeader("\u2728  New in library (${newNotes.size})", compact) }
            if (homeVertical) {
                items(newNotes, key = { it.id }) { n ->
                    NewNoteCard(n, modifier = Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 5.dp)) { openNote(n.id, n.title, n.fileType) }
                }
            } else {
            item {
                LazyRow(
                    Modifier.fillMaxWidth().padding(vertical = 4.dp),
                    horizontalArrangement = Arrangement.spacedBy(10.dp),
                    contentPadding = PaddingValues(horizontal = if (compact) 8.dp else 16.dp)
                ) {
                    items(newNotes, key = { it.id }) { n ->
                        NewNoteCard(n) {
                            openNote(n.id, n.title, n.fileType)
                        }
                    }
                }
            }
            }
            item {
                HorizontalDivider(
                    Modifier.padding(horizontal = 16.dp, vertical = 4.dp),
                    color = MaterialTheme.colorScheme.surfaceVariant
                )
            }
        }
        // ▶️ Continue reading
        if (recent.isNotEmpty()) {
            item { SectionHeader("\u25B6\uFE0F  Continue reading", compact) }
            if (homeVertical) {
                items(recent, key = { it.id }) { r ->
                    RecentCard(r, recentSources[r.id], modifier = Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 5.dp)) { openNote(r.id, r.title, r.fileType) }
                }
            } else {
            item {
                LazyRow(
                    Modifier.fillMaxWidth().padding(vertical = 4.dp),
                    horizontalArrangement = Arrangement.spacedBy(10.dp),
                    contentPadding = PaddingValues(horizontal = if (compact) 8.dp else 16.dp)
                ) {
                    items(recent, key = { it.id }) { r ->
                        RecentCard(r, recentSources[r.id]) {
                            openNote(r.id, r.title, r.fileType)
                        }
                    }
                }
            }
            }
        }
        // ✨ Suggested for you — wide swipeable preview cards. Sits above Topics so the two
        //    sections share the screen (carousel above, topics grid below).
        if (suggested.isNotEmpty()) {
            item { SectionHeader("\u2728  Suggested for you", compact) }
            if (compact || homeVertical) {
                // v5.4.33 — Vertical layout in tablet mode or when user
                // prefers vertical scroll: cards stack vertically.
                items(suggested, key = { "sg-" + it.id }) { n ->
                    SuggestedCard(
                        n = n,
                        loadPreview = { vm.previewOf(n.id) },
                        onClick = {
                            openNote(n.id, n.title, n.fileType)
                        },
                        wide = true
                    )
                }
            } else {
            item {
                LazyRow(
                    Modifier.fillMaxWidth().padding(vertical = 4.dp),
                    horizontalArrangement = Arrangement.spacedBy(12.dp),
                    contentPadding = PaddingValues(horizontal = if (compact) 8.dp else 16.dp)
                ) {
                    items(suggested, key = { "sg-" + it.id }) { n ->
                        SuggestedCard(
                            n = n,
                            loadPreview = { vm.previewOf(n.id) },
                            onClick = {
                                openNote(n.id, n.title, n.fileType)
                            }
                        )
                    }
                }
            }
            }
        }
        item { Spacer(Modifier.height(if (compact) 8.dp else 28.dp)) }
    }

    // v5.0.0 — Tap-away backdrop. When the hero search is focused, an
    // invisible click target sits between content and the search bar so
    // tapping anywhere except the search bar dismisses the focus.
    if (heroSearchFocused) {
        Box(
            Modifier
                .fillMaxSize()
                .background(MaterialTheme.colorScheme.scrim.copy(alpha = 0.25f))
                .clickable(
                    indication = null,
                    interactionSource = remember { androidx.compose.foundation.interaction.MutableInteractionSource() }
                ) { heroSearchFocused = false }
        )
    }

    // v5.0.0 — Hero centered search bar. Sits in the foreground always.
    // When focused (default on screen entry): larger, prominent, with
    // blurred content behind. When dismissed by tap-away: shrinks to a
    // compact pill that can be re-focused by tapping it.
    val recents by vm.recentSearches.collectAsStateWithLifecycle()
    val maxRecents by vm.maxRecentSearchesOnHome.collectAsStateWithLifecycle()
    val recentQueries = remember(recents, maxRecents) {
        // De-duplicate by query string (keep newest) and cap at the user's
        // configured limit.
        recents
            .asSequence()
            .map { it.query.trim() }
            .filter { it.isNotEmpty() }
            .distinct()
            .take(maxRecents.coerceAtLeast(0))
            .toList()
    }
    // v5.4.76cc — Long-pressing a recent search chip shows a small
    // dialog with the record of what the on-device LLM did to that
    // query — the paraphrases it produced, when they were produced,
    // and whether the observation came from a fresh run or the
    // in-memory cache. When there is no record (LLM off, model not
    // installed, or the query never went through a submit), the
    // dialog says so plainly.
    var llmHistoryDialogQuery by remember { mutableStateOf<String?>(null) }
    HeroSearchBar(
        focused = heroSearchFocused,
        noteCount = noteCount,
        compact = compact,
        recentQueries = recentQueries,
        onRecentTap = { q ->
            // v5.4.127cc — Set the query, fire a real submit (so AI/T5
            // expansion runs and the query is logged to history), then
            // navigate. submitSearch() records _lastSubmittedQuery so the
            // live debounce on SearchScreen won't cancel the in-flight
            // expansion 220 ms later.
            vm.query.value = q
            vm.submitSearch()
            heroSearchFocused = false
            nav.navigate("search")
        },
        onRecentLongPress = { q ->
            llmHistoryDialogQuery = q
        },
        onFocus = { heroSearchFocused = true },
        onSubmit = { query ->
            // v5.0.0 — Pre-fill the search field by writing to the VM's
            // query StateFlow before navigating. SearchScreen reads from
            // this same flow, so the field shows the typed text already.
            // v5.4.127cc — Also fire submitSearch() so AI/T5 expansion
            // runs and the query is recorded in history. Without this,
            // the search arrived with isSubmit=false (live stream), which
            // blocked expansion and skipped history logging entirely.
            vm.query.value = query
            vm.submitSearch()
            heroSearchFocused = false
            nav.navigate("search")
        },
        onTapJustSearch = {
            // No query typed — just open the regular Search screen.
            heroSearchFocused = false
            nav.navigate("search")
        }
    )
    llmHistoryDialogQuery?.let { q ->
        LlmExpansionHistoryDialog(
            query = q,
            onDismiss = { llmHistoryDialogQuery = null }
        )
    }
    }   // end outer Box
}

@Composable
private fun SectionHeader(text: String, compact: Boolean = false) {
    Text(
        text,
        Modifier.padding(
            start = if (compact) 12.dp else 18.dp,
            end = if (compact) 8.dp else 16.dp,
            top = if (compact) 6.dp else 16.dp,
            bottom = 2.dp
        ),
        fontWeight = FontWeight.Bold,
        fontSize = if (compact) 13.sp else 15.sp
    )
}

@Composable
private fun SuggestedCard(
    n: NoteMeta,
    loadPreview: suspend () -> String?,
    onClick: () -> Unit,
    wide: Boolean = false
) {
    var preview by remember(n.id) { mutableStateOf<String?>(null) }
    LaunchedEffect(n.id) {
        preview = runCatching { loadPreview() }.getOrNull()
            ?.let { stripMarkdownNoise(it) }
    }
    Surface(
        color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.55f),
        shape = RoundedCornerShape(10.dp),
        modifier = Modifier
            .then(
                if (wide) Modifier.fillMaxWidth().padding(horizontal = 8.dp, vertical = 3.dp)
                else Modifier.widthIn(min = 250.dp, max = 280.dp)
            )
            .clickable(onClick = onClick)
    ) {
        if (wide) {
            Row(Modifier.padding(10.dp)) {
                Column(Modifier.weight(1f)) {
                    Text(
                        n.title, fontWeight = FontWeight.SemiBold, fontSize = 13.sp,
                        maxLines = 2, overflow = TextOverflow.Ellipsis, lineHeight = 17.sp
                    )
                    if (n.folder.isNotBlank()) {
                        Text(n.folder, fontSize = 10.sp,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                            maxLines = 1, overflow = TextOverflow.Ellipsis)
                    }
                }
                Spacer(Modifier.width(8.dp))
                Text(
                    preview?.takeIf { it.isNotBlank() }?.take(80) ?: "\u2026",
                    fontSize = 11.sp,
                    lineHeight = 15.sp,
                    color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.68f),
                    maxLines = 3,
                    overflow = TextOverflow.Ellipsis,
                    modifier = Modifier.weight(1f)
                )
            }
        } else {
        Column(Modifier.padding(10.dp)) {
            Text(if (n.fileType == "pdf") "\uD83D\uDCD5" else "\u2728", fontSize = 16.sp)
            Spacer(Modifier.height(6.dp))
            Text(
                n.title, fontWeight = FontWeight.SemiBold, fontSize = 14.sp,
                maxLines = 2, overflow = TextOverflow.Ellipsis, lineHeight = 18.sp
            )
            if (n.folder.isNotBlank()) {
                Spacer(Modifier.height(2.dp))
                Text(n.folder, fontSize = 11.sp,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    maxLines = 1, overflow = TextOverflow.Ellipsis)
            }
            Spacer(Modifier.height(8.dp))
            Text(
                preview?.takeIf { it.isNotBlank() } ?: "\u2026",
                fontSize = 12.sp,
                lineHeight = 17.sp,
                color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.78f),
                maxLines = 5,
                overflow = TextOverflow.Ellipsis
            )
        }
        }
    }
}

/** Strip the noisiest markdown bits so the preview reads naturally. */
private fun stripMarkdownNoise(s: String): String {
    var t = s
    // YAML frontmatter at start
    if (t.startsWith("---")) {
        val end = t.indexOf("---", 3)
        if (end > 0) t = t.substring(end + 3)
    }
    t = t
        .replace(Regex("^#+\\s+", RegexOption.MULTILINE), "")    // # H1 prefix
        .replace(Regex("\\*\\*([^*]+)\\*\\*"), "$1")             // **bold**
        .replace(Regex("__([^_]+)__"), "$1")                      // __bold__
        .replace(Regex("`([^`]+)`"), "$1")                        // `code`
        .replace(Regex("!\\[[^\\]]*]\\([^)]*\\)"), "")            // ![image](url)
        .replace(Regex("\\[([^\\]]+)]\\([^)]*\\)"), "$1")        // [text](url) -> text
        .replace(Regex("\\[\\[([^\\[\\]|#^\\n]+)(?:#[^\\[\\]|\\n]*)?(?:\\^[^\\[\\]|\\n]*)?(?:\\|([^\\[\\]\\n]+))?]]")) { m ->
            m.groupValues[2].ifBlank { m.groupValues[1] }
        }
        .replace(Regex("^>+\\s?", RegexOption.MULTILINE), "")    // > blockquote
        .replace(Regex("^[-*+]\\s+", RegexOption.MULTILINE), "")  // bullet
        .replace(Regex("\\s+"), " ")
        .trim()
    return t
}

@Composable
private fun FavouriteCard(n: NoteMeta, modifier: Modifier = Modifier, onClick: () -> Unit) {
    Surface(
        color = MaterialTheme.colorScheme.primaryContainer,
        shape = RoundedCornerShape(10.dp),
        modifier = modifier.then(Modifier.widthIn(min = 160.dp, max = 240.dp)).clickable(onClick = onClick)
    ) {
        Column(Modifier.padding(10.dp)) {
            Text(if (n.fileType == "pdf") "\u2B50\uD83D\uDCD5" else "\u2B50", fontSize = 18.sp)
            Spacer(Modifier.height(6.dp))
            Text(
                n.title, fontWeight = FontWeight.SemiBold, fontSize = 14.sp,
                maxLines = 2, overflow = TextOverflow.Ellipsis, lineHeight = 18.sp
            )
            if (n.folder.isNotBlank()) {
                Spacer(Modifier.height(4.dp))
                Text(n.folder, fontSize = 11.sp,
                    color = MaterialTheme.colorScheme.onPrimaryContainer.copy(alpha = 0.7f),
                    maxLines = 1, overflow = TextOverflow.Ellipsis)
            }
        }
    }
}

@Composable
private fun NewNoteCard(n: NoteMeta, modifier: Modifier = Modifier, onClick: () -> Unit) {
    Surface(
        color = MaterialTheme.colorScheme.surfaceVariant,
        shape = RoundedCornerShape(10.dp),
        modifier = modifier.then(Modifier.widthIn(min = 160.dp, max = 240.dp)).clickable(onClick = onClick)
    ) {
        Column(Modifier.padding(10.dp)) {
            Text(if (n.fileType == "pdf") "\uD83D\uDCD5" else "\uD83D\uDCC4", fontSize = 18.sp)
            Spacer(Modifier.height(6.dp))
            Text(
                n.title, fontWeight = FontWeight.SemiBold, fontSize = 14.sp,
                maxLines = 2, overflow = TextOverflow.Ellipsis, lineHeight = 18.sp
            )
            if (n.folder.isNotBlank()) {
                Spacer(Modifier.height(4.dp))
                Text(n.folder, fontSize = 11.sp,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    maxLines = 1, overflow = TextOverflow.Ellipsis)
            }
        }
    }
}

@Composable
private fun RecentCard(r: RecentNote, source: OpenSource?, modifier: Modifier = Modifier, onClick: () -> Unit) {
    val rel = remember(r.lastOpened) { formatHistoryTime(r.lastOpened) }
    Surface(
        color = MaterialTheme.colorScheme.surfaceVariant,
        shape = RoundedCornerShape(10.dp),
        modifier = modifier.then(Modifier.widthIn(min = 200.dp, max = 240.dp)).clickable(onClick = onClick)
    ) {
        Column(Modifier.padding(10.dp)) {
            // Line 1: file-type icon + source label
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(if (r.fileType == "pdf") "\uD83D\uDCD5" else "\uD83D\uDCC4", fontSize = 18.sp)
                Spacer(Modifier.width(6.dp))
                val (icon, label) = when (source) {
                    OpenSource.LINK -> "\uD83D\uDD17" to "from a link"
                    OpenSource.BACKLINK -> "\u2190" to "from a backlink"
                    OpenSource.GRAPH -> "\uD83C\uDF10" to "from the graph"
                    OpenSource.DIRECT, null -> "" to "opened"
                }
                if (icon.isNotEmpty()) {
                    Text(icon, fontSize = 11.sp)
                    Spacer(Modifier.width(3.dp))
                }
                Text(label, fontSize = 10.sp,
                    color = MaterialTheme.colorScheme.primary,
                    fontWeight = FontWeight.Medium,
                    maxLines = 1, overflow = TextOverflow.Ellipsis)
            }
            Spacer(Modifier.height(7.dp))
            // Line 2: title (bold, up to 2 wrapped lines)
            Text(
                r.title, fontWeight = FontWeight.SemiBold, fontSize = 14.sp,
                maxLines = 2, overflow = TextOverflow.Ellipsis, lineHeight = 18.sp
            )
            Spacer(Modifier.height(7.dp))
            // Line 3: timestamp in primary accent colour (was muted before)
            Text(rel, fontSize = 11.sp,
                fontWeight = FontWeight.Medium,
                color = MaterialTheme.colorScheme.primary)
        }
    }
}

@Composable
private fun TopicCardView(t: TopicCard, modifier: Modifier, onClick: () -> Unit) {
    Surface(
        color = MaterialTheme.colorScheme.surfaceVariant,
        shape = RoundedCornerShape(14.dp),
        modifier = modifier.clickable(onClick = onClick)
    ) {
        Row(
            Modifier.padding(14.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(t.emoji, fontSize = 26.sp)
            Spacer(Modifier.width(12.dp))
            Column {
                Text(t.label, fontWeight = FontWeight.SemiBold, fontSize = 15.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                Text(
                    "${t.count} note${if (t.count == 1) "" else "s"}",
                    fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
        }
    }
}

@Composable
private fun WelcomeState(onPick: () -> Unit) {
    Column(
        Modifier.fillMaxSize().padding(32.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        Text("\uD83D\uDCDA", fontSize = 64.sp)
        Spacer(Modifier.height(16.dp))
        Text("Welcome to MarkVault", fontSize = 20.sp, fontWeight = FontWeight.Bold)
        Spacer(Modifier.height(8.dp))
        Text(
            "Choose the folder that holds your Markdown library. " +
                "Markdown files and PDFs are indexed and stay 100% on this phone.",
            color = MaterialTheme.colorScheme.onSurfaceVariant, textAlign = TextAlign.Center
        )
        Spacer(Modifier.height(24.dp))
        Button(onClick = onPick) { Text("\uD83D\uDCC1  Choose library folder") }
    }
}

@Composable
private fun EmptyState(onReindex: () -> Unit, onChange: () -> Unit) {
    Column(
        Modifier.fillMaxSize().padding(32.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        Text("No .md or .pdf files indexed yet.", color = MaterialTheme.colorScheme.onSurfaceVariant)
        Spacer(Modifier.height(12.dp))
        Button(onClick = onReindex) { Text("\u21BB  Index now") }
        Spacer(Modifier.height(12.dp))
        Text(
            "\uD83D\uDCC1 Choose a different folder",
            Modifier.clickable(onClick = onChange).padding(8.dp),
            color = MaterialTheme.colorScheme.primary
        )
    }
}

/**
 * v5.0.0 — Hero search bar shown over the homepage. Two states:
 *
 *  - **focused**: large centered pill with a real text field and a Search
 *    button. Sits ~30% from the top of the screen so it lands roughly in
 *    the visual center, slightly above middle so the keyboard doesn't
 *    cover it when it opens.
 *  - **unfocused**: a slim pill near the top that the user can tap to
 *    re-focus. This is the "search has been dismissed but is still
 *    accessible" state.
 */
@OptIn(ExperimentalMaterial3Api::class, ExperimentalFoundationApi::class)
@Composable
private fun HeroSearchBar(
    focused: Boolean,
    noteCount: Int,
    compact: Boolean = false,
    recentQueries: List<String> = emptyList(),
    onRecentTap: (String) -> Unit = {},
    onRecentLongPress: (String) -> Unit = {},
    onFocus: () -> Unit,
    onSubmit: (String) -> Unit,
    onTapJustSearch: () -> Unit
) {
    if (focused) {
        var text by remember { mutableStateOf("") }
        Box(
            Modifier.fillMaxSize(),
            contentAlignment = Alignment.TopCenter
        ) {
            Column(
                Modifier
                    .fillMaxWidth()
                    .padding(horizontal = if (compact) 8.dp else 16.dp)
                    .padding(top = if (compact) 16.dp else 110.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                if (!compact) {
                    Text(
                        "MarkVault",
                        fontSize = 32.sp,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.onSurface
                    )
                    Spacer(Modifier.height(6.dp))
                }
                Text(
                    "Search $noteCount notes by word, phrase, or topic",
                    fontSize = if (compact) 12.sp else 13.sp,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
                Spacer(Modifier.height(if (compact) 8.dp else 24.dp))
                Surface(
                    color = MaterialTheme.colorScheme.surface,
                    shape = RoundedCornerShape(28.dp),
                    tonalElevation = 6.dp,
                    shadowElevation = 8.dp,
                    modifier = Modifier
                        .fillMaxWidth()
                        .wrapContentHeight()
                ) {
                    Row(
                        Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 16.dp, vertical = 8.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(
                            Icons.Default.Search,
                            contentDescription = null,
                            tint = MaterialTheme.colorScheme.primary
                        )
                        Spacer(Modifier.width(12.dp))
                        androidx.compose.material3.TextField(
                            value = text,
                            onValueChange = { text = it },
                            placeholder = {
                                Text(
                                    "What are you looking for?",
                                    fontSize = 16.sp
                                )
                            },
                            singleLine = true,
                            modifier = Modifier.weight(1f),
                            colors = androidx.compose.material3.TextFieldDefaults.colors(
                                focusedContainerColor = androidx.compose.ui.graphics.Color.Transparent,
                                unfocusedContainerColor = androidx.compose.ui.graphics.Color.Transparent,
                                disabledContainerColor = androidx.compose.ui.graphics.Color.Transparent,
                                focusedIndicatorColor = androidx.compose.ui.graphics.Color.Transparent,
                                unfocusedIndicatorColor = androidx.compose.ui.graphics.Color.Transparent
                            ),
                            keyboardOptions = androidx.compose.foundation.text.KeyboardOptions(
                                imeAction = androidx.compose.ui.text.input.ImeAction.Search
                            ),
                            keyboardActions = androidx.compose.foundation.text.KeyboardActions(
                                onSearch = {
                                    if (text.isNotBlank()) onSubmit(text.trim())
                                    else onTapJustSearch()
                                }
                            )
                        )
                        if (text.isNotBlank()) {
                            IconButton(onClick = {
                                if (text.isNotBlank()) onSubmit(text.trim())
                            }) {
                                Text("\u279C", fontSize = 20.sp)
                            }
                        }
                    }
                }
                // v5.2.0 — Recent searches list, italic, under the hero
                // search bar. Tap to re-run any recent query. Number of
                // entries shown is the user's pref (default 7).
                //
                // v5.4.101cc — Wrapped the item list in a bounded-height
                // LazyColumn so long recent-query lists actually scroll
                // instead of overflowing past the bottom of the screen
                // (with the IME up, the parent Column had no vertical
                // slack to absorb 15-20 entries). The 260.dp cap holds
                // roughly 10 items and leaves the search bar + hero
                // text visible above; anything beyond that scrolls in
                // place.
                if (recentQueries.isNotEmpty()) {
                    Spacer(Modifier.height(18.dp))
                    Text(
                        "Recent searches",
                        fontSize = 11.sp,
                        fontWeight = FontWeight.SemiBold,
                        color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.85f)
                    )
                    Spacer(Modifier.height(6.dp))
                    LazyColumn(
                        modifier = Modifier
                            .fillMaxWidth()
                            .heightIn(max = 260.dp)
                    ) {
                        items(recentQueries) { q ->
                            Text(
                                q,
                                fontSize = 14.sp,
                                fontStyle = androidx.compose.ui.text.font.FontStyle.Italic,
                                color = MaterialTheme.colorScheme.primary,
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(vertical = 4.dp)
                                    .combinedClickable(
                                        onClick = { onRecentTap(q) },
                                        onLongClick = { onRecentLongPress(q) }
                                    )
                            )
                        }
                    }
                }
            }
        }
    } else {
        // Compact pill at top, re-focusable.
        Box(
            Modifier.fillMaxSize(),
            contentAlignment = Alignment.TopCenter
        ) {
            Surface(
                color = MaterialTheme.colorScheme.surface,
                shape = RoundedCornerShape(24.dp),
                tonalElevation = 4.dp,
                shadowElevation = 4.dp,
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(
                        horizontal = if (compact) 8.dp else 16.dp,
                        vertical = if (compact) 4.dp else 12.dp
                    )
                    .clickable { onFocus() }
            ) {
                Row(
                    Modifier.padding(
                        horizontal = if (compact) 10.dp else 14.dp,
                        vertical = if (compact) 8.dp else 12.dp
                    ),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(
                        Icons.Default.Search,
                        contentDescription = null,
                        tint = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                    Spacer(Modifier.width(10.dp))
                    Text(
                        "Search $noteCount notes\u2026",
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }
        }
    }
}

/**
 * v5.4.33 — Tablet-mode sidebar for HomeScreen. Shows recently viewed
 * articles with timestamps instead of duplicating the search bar's
 * recent searches list. Tapping an article re-opens it.
 */
@androidx.compose.runtime.Composable
private fun HomeTabletSidebar(
    vm: com.tebogo.markvault.AppViewModel,
    nav: androidx.navigation.NavController,
    recentArticles: List<com.tebogo.markvault.data.RecentNote>,
    modifier: androidx.compose.ui.Modifier = androidx.compose.ui.Modifier
) {
    fun openNote(id: Long, title: String, fileType: String) {
        when (fileType) {
            "pdf" -> {
                vm.openArticle(id, title, fileType = "pdf")
                nav.navigate("pdfReader/$id")
            }
            "mhtml", "html" -> {
                vm.openArticle(id, title, fileType = fileType)
                nav.navigate("htmlReader/$id")
            }
            else -> {
                vm.openArticle(id, title)
                nav.navigate("reader") { launchSingleTop = true }
            }
        }
    }
    androidx.compose.foundation.layout.Column(
        modifier = modifier
            .background(
                androidx.compose.material3.MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.25f)
            )
            .padding(10.dp)
    ) {
        androidx.compose.foundation.layout.Row(
            verticalAlignment = androidx.compose.ui.Alignment.CenterVertically
        ) {
            Text(
                "\uD83D\uDCDA MarkVault",
                fontSize = 18.sp,
                fontWeight = androidx.compose.ui.text.font.FontWeight.Bold
            )
        }
        androidx.compose.foundation.layout.Spacer(
            androidx.compose.ui.Modifier.height(12.dp)
        )
        Text(
            "\uD83D\uDD52 Recently viewed",
            fontSize = 13.sp,
            fontWeight = androidx.compose.ui.text.font.FontWeight.SemiBold,
            color = androidx.compose.material3.MaterialTheme.colorScheme.onSurface
        )
        androidx.compose.foundation.layout.Spacer(
            androidx.compose.ui.Modifier.height(4.dp)
        )
        if (recentArticles.isEmpty()) {
            Text(
                "No recently viewed articles.",
                fontSize = 11.sp,
                color = androidx.compose.material3.MaterialTheme.colorScheme.onSurfaceVariant
            )
        } else {
            Text(
                "${recentArticles.size} articles",
                fontSize = 11.sp,
                color = androidx.compose.material3.MaterialTheme.colorScheme.onSurfaceVariant
            )
            androidx.compose.foundation.layout.Spacer(
                androidx.compose.ui.Modifier.height(6.dp)
            )
            LazyColumn(
                modifier = androidx.compose.ui.Modifier.weight(1f).fillMaxWidth()
            ) {
                items(recentArticles, key = { it.id }) { r ->
                    val rel = remember(r.lastOpened) { formatHistoryTime(r.lastOpened) }
                    androidx.compose.material3.Surface(
                        color = androidx.compose.ui.graphics.Color.Transparent,
                        shape = androidx.compose.foundation.shape.RoundedCornerShape(8.dp),
                        modifier = androidx.compose.ui.Modifier
                            .fillMaxWidth()
                            .padding(vertical = 2.dp)
                            .clickable {
                                openNote(r.id, r.title, r.fileType)
                            }
                    ) {
                        Column(
                            androidx.compose.ui.Modifier.padding(
                                horizontal = 8.dp, vertical = 6.dp
                            )
                        ) {
                            Text(
                                when (r.fileType) {
                                    "pdf" -> "\uD83D\uDCD5"
                                    "html", "mhtml" -> "\uD83C\uDF10"
                                    else -> "\uD83D\uDCDD"
                                } + "  " + r.title,
                                fontSize = 12.sp,
                                fontWeight = FontWeight.Medium,
                                color = androidx.compose.material3.MaterialTheme.colorScheme.onSurface,
                                maxLines = 2,
                                overflow = androidx.compose.ui.text.style.TextOverflow.Ellipsis
                            )
                            Text(
                                rel,
                                fontSize = 10.sp,
                                color = androidx.compose.material3.MaterialTheme.colorScheme.primary
                            )
                        }
                    }
                }
            }
        }
    }
}

/**
 * v5.4.76cc — Dialog shown when the user long-presses a recent search
 * chip on the home screen. Reads the in-memory expansion record for the
 * given [query] from
 * [com.tebogo.markvault.ai.LlmExpansionHistory] and displays:
 *
 *   • The original query.
 *   • The paraphrases the LLM produced, one per line.
 *   • Whether this reflects a fresh LLM run or a cache re-use.
 *   • The wall-clock time the expansion took (only meaningful when the
 *     run was fresh — cache hits show "0 ms — reused earlier
 *     expansion").
 *   • The timestamp of the observation.
 *
 * When there is no record for this query (the user never submitted it
 * with LLM search enabled, or the model was not installed at the time,
 * or the query is too short for the expander to bother), the dialog
 * says so plainly rather than pretending an expansion happened.
 */
@Composable
private fun LlmExpansionHistoryDialog(
    query: String,
    onDismiss: () -> Unit
) {
    val llmRecord = androidx.compose.runtime.remember(query) {
        com.tebogo.markvault.ai.LlmExpansionHistory.get(query)
    }
    // v5.4.115cc — The full plan: original + synonym variants + LLM
    // paraphrases, each with the weight the fusion layer applied.
    val plan = androidx.compose.runtime.remember(query) {
        com.tebogo.markvault.ai.QueryPlanHistory.get(query)
    }
    val muted = androidx.compose.material3.MaterialTheme.colorScheme.onSurfaceVariant

    androidx.compose.material3.AlertDialog(
        onDismissRequest = onDismiss,
        confirmButton = {
            androidx.compose.material3.TextButton(onClick = onDismiss) {
                Text("Close")
            }
        },
        title = { Text("\uD83D\uDD0E Queries used for this search") },
        text = {
            androidx.compose.foundation.layout.Column(
                Modifier
                    .heightIn(max = 460.dp)
                    .verticalScroll(rememberScrollState())
            ) {
                Text(text = "You searched:", fontSize = 12.sp, color = muted)
                Text(text = query, fontSize = 14.sp, fontWeight = FontWeight.SemiBold)
                androidx.compose.foundation.layout.Spacer(Modifier.height(12.dp))

                if (plan == null) {
                    Text(
                        text = "No query plan was recorded for this search yet. " +
                            "Plans are captured when you submit a search in this " +
                            "session; they're cleared when the app restarts.",
                        fontSize = 13.sp, lineHeight = 18.sp, color = muted
                    )
                } else {
                    Text(
                        text = "${plan.generated.size} queries ran " +
                            "(yours + ${plan.generated.size - 1} expansion) \u00B7 " +
                            "slider ${plan.budget} \u00B7 " +
                            (if (plan.semanticOn) "semantic on" else "semantic off"),
                        fontSize = 11.sp, color = muted
                    )
                    androidx.compose.foundation.layout.Spacer(Modifier.height(12.dp))

                    // v5.4.124cc — STRICT MUTUAL EXCLUSION, reflected in the
                    // UI. Exactly one section renders below, chosen by
                    // [QueryPlanRecord.attemptedSource] — the engine the
                    // Settings selection actually authorized for this
                    // search. The other two engines never ran, so they no
                    // longer get a permanent (if empty) section here; a
                    // dialog that always showed "Non-LLM expansion" and a
                    // "Default (no AI model)" block regardless of what was
                    // selected is exactly what made it look like T5-base
                    // never ran, even on searches where it was the only
                    // thing selected.
                    when (plan.attemptedSource) {
                        null -> {
                            Text(
                                text = "No expansion ran for this search \u2014 " +
                                    "the multi-query slider is at 0.",
                                fontSize = 13.sp, lineHeight = 18.sp, color = muted
                            )
                        }
                        com.tebogo.markvault.ai.QuerySource.SYNONYM -> {
                            val synonyms = plan.synonymQueries
                            Text(
                                text = "\uD83D\uDD24 Non-LLM expansion \u00B7 ${synonyms.size}",
                                fontSize = 12.sp, fontWeight = FontWeight.SemiBold
                            )
                            Text(
                                text = "Offline synonym substitution \u2014 no model " +
                                    "involved. (No AI engine was selected in Settings.)",
                                fontSize = 10.sp, color = muted
                            )
                            androidx.compose.foundation.layout.Spacer(Modifier.height(4.dp))
                            if (synonyms.isEmpty()) {
                                Text(
                                    text = "(none \u2014 no substitutable terms were " +
                                        "found in this query)",
                                    fontSize = 12.sp,
                                    fontStyle = androidx.compose.ui.text.font.FontStyle.Italic,
                                    color = muted
                                )
                            } else {
                                for (g in synonyms) {
                                    QueryPlanLine(g.text, g.weight)
                                }
                            }
                        }
                        com.tebogo.markvault.ai.QuerySource.T5,
                        com.tebogo.markvault.ai.QuerySource.LLM -> {
                            val engineEntries = plan.aiQueries
                            // v5.4.123cc -- Name the specific engine that was
                            // authorized to run, so it's possible to confirm
                            // at a glance that T5-base (or the built-in LLM)
                            // is actually the thing that ran.
                            val aiModelLabel = llmRecord?.modelName
                                ?: if (plan.attemptedSource == com.tebogo.markvault.ai.QuerySource.T5) {
                                    "T5-base"
                                } else {
                                    "Built-in"
                                }
                            Text(
                                text = "\uD83E\uDD16 $aiModelLabel expansion \u00B7 ${engineEntries.size}",
                                fontSize = 12.sp, fontWeight = FontWeight.SemiBold
                            )
                            Text(
                                text = if (llmRecord != null) {
                                    "Paraphrases generated on-device."
                                } else {
                                    "$aiModelLabel was selected but hasn't produced a " +
                                        "recorded run for this query yet."
                                },
                                fontSize = 10.sp, color = muted
                            )
                            androidx.compose.foundation.layout.Spacer(Modifier.height(4.dp))
                            if (engineEntries.isEmpty()) {
                                // v5.4.119cc — Diagnose from the record instead
                                // of dumping every possible cause. Long
                                // duration + zero output = the model ran but
                                // produced nothing usable (timed out
                                // mid-generation, or emitted only meta-text /
                                // off-topic paraphrases the validator
                                // rejected). Short duration + zero output =
                                // the model never actually ran this round
                                // (e.g. this was a cached/live-typing pass).
                                val emptyReason = when {
                                    // v5.4.136cc \u2014 Now backed by
                                    // LlmExpansionRecord.skipReason, the ACTUAL
                                    // cause recorded by LlmQueryExpander at the
                                    // moment it happened, instead of a
                                    // duration-based guess. Falls back to the
                                    // old heuristic only for records written
                                    // before this field existed.
                                    llmRecord == null ->
                                        "(none \u2014 $aiModelLabel hasn't completed a " +
                                            "run for this exact query text yet)"
                                    llmRecord.skipReason == "not_installed" ->
                                        "(none \u2014 $aiModelLabel isn't installed on " +
                                            "this device. Download it in Settings \u2192 " +
                                            "On-device chat.)"
                                    llmRecord.skipReason == "ram_skip" ->
                                        "(none \u2014 skipped: not enough free RAM to " +
                                            "safely load $aiModelLabel alongside what's " +
                                            "already running. Close other apps or turn " +
                                            "off Settings \u2192 Memory-optimised LLM mode " +
                                            "to force it anyway.)"
                                    llmRecord.skipReason == "timeout" ->
                                        "(none \u2014 the model ran for " +
                                            "${llmRecord.durationMs / 1000} s and was cut " +
                                            "off before producing usable output. Try a " +
                                            "smaller model or increase the timeout budget " +
                                            "in Settings.)"
                                    llmRecord.skipReason == "engine_error" ->
                                        "(none \u2014 the model engine hit an internal " +
                                            "error while generating. Usually transient \u2014 " +
                                            "try the search again.)"
                                    llmRecord.skipReason == "all_rejected_by_relevance_gate" ->
                                        "(none \u2014 the model produced output but every " +
                                            "line was either meta-commentary or drifted " +
                                            "too far from your query's topic to be kept.)"
                                    llmRecord.durationMs >= 20_000L ->
                                        "(none \u2014 the model ran for " +
                                            "${llmRecord.durationMs / 1000} s but produced " +
                                            "nothing usable. Either it timed out before " +
                                            "emitting an end token, or every line it " +
                                            "generated was meta-text or off-topic and got " +
                                            "rejected. Try a larger model \u2014 the " +
                                            "smallest one struggles to follow the " +
                                            "\"give me N paraphrases\" instruction.)"
                                    llmRecord.durationMs >= 500L ->
                                        "(none \u2014 the model ran for " +
                                            "${llmRecord.durationMs} ms but every " +
                                            "paraphrase it generated was rejected as " +
                                            "meta-text or off-topic)"
                                    else ->
                                        "(none \u2014 the model isn't installed, or this " +
                                            "run reused a cache entry with no paraphrases)"
                                }
                                Text(
                                    text = emptyReason,
                                    fontSize = 12.sp,
                                    fontStyle = androidx.compose.ui.text.font.FontStyle.Italic,
                                    color = muted
                                )
                            } else {
                                for (g in engineEntries) {
                                    QueryPlanLine(g.text, g.weight)
                                }
                            }
                        }
                        com.tebogo.markvault.ai.QuerySource.ORIGINAL -> {
                            // Not a possible attemptedSource value; nothing to render.
                        }
                    }

                    androidx.compose.foundation.layout.Spacer(Modifier.height(12.dp))
                    if (llmRecord != null) {
                        val timeLabel = if (llmRecord.cached) {
                            "0 ms \u2014 reused earlier expansion"
                        } else {
                            "${llmRecord.durationMs} ms \u2014 fresh ${llmRecord.modelName} run"
                        }
                        Text(text = timeLabel, fontSize = 11.sp, color = muted)
                    }
                    Text(
                        text = "Observed ${formatRelativeAge(plan.timestampMs)}",
                        fontSize = 11.sp, color = muted
                    )
                }
            }
        }
    )
}

/**
 * v5.4.115cc — One generated sub-query plus the trust weight the
 * fusion layer gave it. The weight is shown because it explains why
 * two queries that both "ran" did not influence the results equally:
 * the user's own wording is 1.00, a first-round synonym swap ~0.75,
 * an LLM paraphrase 0.60.
 */
@Composable
private fun QueryPlanLine(text: String, weight: Double) {
    androidx.compose.foundation.layout.Row(
        Modifier.padding(vertical = 2.dp)
    ) {
        Text(
            text = String.format(java.util.Locale.US, "%.2f", weight),
            fontSize = 11.sp,
            fontFamily = androidx.compose.ui.text.font.FontFamily.Monospace,
            color = androidx.compose.material3.MaterialTheme.colorScheme.primary
        )
        androidx.compose.foundation.layout.Spacer(Modifier.width(8.dp))
        Text(text = text, fontSize = 13.sp, lineHeight = 18.sp)
    }
}

/**
 * v5.4.76cc — Human-friendly relative age for the LLM expansion
 * timestamp on the history dialog. Deliberately coarse — the user
 * doesn't need millisecond precision, just "was this a moment ago or
 * earlier in the session".
 */
private fun formatRelativeAge(atMs: Long): String {
    val diffMs = System.currentTimeMillis() - atMs
    if (diffMs < 0) return "just now"
    val sec = diffMs / 1000
    if (sec < 5) return "just now"
    if (sec < 60) return "${sec}s ago"
    val min = sec / 60
    if (min < 60) return "${min}m ago"
    val hr = min / 60
    if (hr < 24) return "${hr}h ago"
    val d = hr / 24
    return "${d}d ago"
}
