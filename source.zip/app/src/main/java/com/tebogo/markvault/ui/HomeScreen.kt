package com.tebogo.markvault.ui

import android.text.format.DateUtils
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material3.Button
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.navigation.NavController
import com.tebogo.markvault.AppViewModel
import com.tebogo.markvault.data.NoteMeta
import com.tebogo.markvault.data.RecentNote
import com.tebogo.markvault.data.TopicCard

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun HomeScreen(vm: AppViewModel, nav: NavController) {
    val libraryUri by vm.libraryUri.collectAsStateWithLifecycle()
    val notes by vm.notes.collectAsStateWithLifecycle()
    val recent by vm.recent.collectAsStateWithLifecycle()
    val topics by vm.topics.collectAsStateWithLifecycle()
    val progress by vm.progress.collectAsStateWithLifecycle()
    val newNotes by vm.newNotes.collectAsStateWithLifecycle()
    val favouriteNotes by vm.favouriteNotes.collectAsStateWithLifecycle()
    val suggested by vm.suggested.collectAsStateWithLifecycle()

    val picker = rememberLauncherForActivityResult(
        ActivityResultContracts.OpenDocumentTree()
    ) { uri -> if (uri != null) vm.setLibrary(uri) }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("\uD83D\uDCDA MarkVault", fontWeight = FontWeight.Bold) },
                actions = {
                    if (libraryUri != null && !progress.running) {
                        IconButton(onClick = { vm.reindex() }) {
                            Icon(Icons.Default.Refresh, contentDescription = "Sync library")
                        }
                    }
                    IconButton(onClick = { nav.navigate("settings") }) {
                        Icon(Icons.Default.Settings, contentDescription = "Settings")
                    }
                }
            )
        }
    ) { pad ->
        Column(Modifier.padding(pad).fillMaxSize()) {
            if (progress.running) {
                LinearProgressIndicator(Modifier.fillMaxWidth())
                Text(
                    "\u23F3 ${progress.phase} ${progress.done} / ${progress.total}",
                    Modifier.padding(horizontal = 16.dp, vertical = 6.dp),
                    fontSize = 13.sp, color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
            when {
                libraryUri == null -> WelcomeState { picker.launch(null) }
                notes.isEmpty() && !progress.running ->
                    EmptyState(onReindex = { vm.reindex() }, onChange = { picker.launch(null) })
                else -> Dashboard(vm, nav, recent, topics, newNotes, favouriteNotes, suggested, notes.size)
            }
        }
    }
}

@Composable
private fun Dashboard(
    vm: AppViewModel,
    nav: NavController,
    recent: List<RecentNote>,
    topics: List<TopicCard>,
    newNotes: List<NoteMeta>,
    favouriteNotes: List<NoteMeta>,
    suggested: List<NoteMeta>,
    noteCount: Int
) {
    LazyColumn(Modifier.fillMaxSize()) {
        // Search bar
        item {
            Surface(
                color = MaterialTheme.colorScheme.surfaceVariant,
                shape = RoundedCornerShape(12.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp, vertical = 10.dp)
                    .clickable { nav.navigate("search") }
            ) {
                Row(
                    Modifier.padding(horizontal = 14.dp, vertical = 13.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(Icons.Default.Search, contentDescription = null,
                        tint = MaterialTheme.colorScheme.onSurfaceVariant)
                    Spacer(Modifier.width(10.dp))
                    Text("Search $noteCount notes by word or topic\u2026",
                        color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
            }
        }
        // Quick-action buttons
        item {
            Row(
                Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 2.dp),
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                OutlinedButton(onClick = { nav.navigate("browse") }, modifier = Modifier.weight(1f)) {
                    Text("\uD83D\uDCC1 Browse")
                }
                OutlinedButton(onClick = { nav.navigate("topics") }, modifier = Modifier.weight(1f)) {
                    Text("\uD83E\uDDED Topics")
                }
                OutlinedButton(onClick = { nav.navigate("graph") }, modifier = Modifier.weight(1f)) {
                    Text("\uD83C\uDF10 Graph")
                }
            }
        }
        // ⭐ Favourites
        if (favouriteNotes.isNotEmpty()) {
            item { SectionHeader("\u2B50  Favourites") }
            item {
                LazyRow(
                    Modifier.fillMaxWidth().padding(vertical = 4.dp),
                    horizontalArrangement = Arrangement.spacedBy(10.dp),
                    contentPadding = PaddingValues(horizontal = 16.dp)
                ) {
                    items(favouriteNotes, key = { it.id }) { n ->
                        FavouriteCard(n) {
                            vm.openArticle(n.id, n.title)
                            nav.navigate("reader") { launchSingleTop = true }
                        }
                    }
                }
            }
        }
        // ✨ New since last sync
        if (newNotes.isNotEmpty()) {
            item { SectionHeader("\u2728  New in library (${newNotes.size})") }
            item {
                LazyRow(
                    Modifier.fillMaxWidth().padding(vertical = 4.dp),
                    horizontalArrangement = Arrangement.spacedBy(10.dp),
                    contentPadding = PaddingValues(horizontal = 16.dp)
                ) {
                    items(newNotes, key = { it.id }) { n ->
                        NewNoteCard(n) {
                            vm.openArticle(n.id, n.title)
                            nav.navigate("reader") { launchSingleTop = true }
                        }
                    }
                }
            }
            item {
                HorizontalDivider(
                    Modifier.padding(horizontal = 16.dp, vertical = 4.dp),
                    color = MaterialTheme.colorScheme.surfaceVariant
                )
            }
        }
        // ▶️ Continue reading
        if (recent.isNotEmpty()) {
            item { SectionHeader("\u25B6\uFE0F  Continue reading") }
            item {
                LazyRow(
                    Modifier.fillMaxWidth().padding(vertical = 4.dp),
                    horizontalArrangement = Arrangement.spacedBy(10.dp),
                    contentPadding = PaddingValues(horizontal = 16.dp)
                ) {
                    items(recent, key = { it.id }) { r ->
                        RecentCard(r) {
                            vm.openArticle(r.id, r.title)
                            nav.navigate("reader") { launchSingleTop = true }
                        }
                    }
                }
            }
        }
        // ✨ Suggested for you — wide swipeable preview cards. Sits above Topics so the two
        //    sections share the screen (carousel above, topics grid below).
        if (suggested.isNotEmpty()) {
            item { SectionHeader("\u2728  Suggested for you") }
            item {
                LazyRow(
                    Modifier.fillMaxWidth().padding(vertical = 4.dp),
                    horizontalArrangement = Arrangement.spacedBy(12.dp),
                    contentPadding = PaddingValues(horizontal = 16.dp)
                ) {
                    items(suggested, key = { "sg-" + it.id }) { n ->
                        SuggestedCard(
                            n = n,
                            loadPreview = { vm.previewOf(n.id) },
                            onClick = {
                                vm.openArticle(n.id, n.title)
                                nav.navigate("reader") { launchSingleTop = true }
                            }
                        )
                    }
                }
            }
        }
        // 🧭 Topics
        if (topics.isNotEmpty()) {
            item { SectionHeader("\uD83E\uDDED  Topics in your library") }
            items(topics.chunked(2)) { pair ->
                Row(
                    Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 5.dp),
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    for (t in pair) {
                        TopicCardView(t, Modifier.weight(1f)) { nav.navigate("topic/${t.key}") }
                    }
                    if (pair.size == 1) Spacer(Modifier.weight(1f))
                }
            }
        }
        item { Spacer(Modifier.height(28.dp)) }
    }
}

@Composable
private fun SectionHeader(text: String) {
    Text(
        text,
        Modifier.padding(start = 18.dp, end = 16.dp, top = 16.dp, bottom = 2.dp),
        fontWeight = FontWeight.Bold, fontSize = 15.sp
    )
}

@Composable
private fun SuggestedCard(
    n: NoteMeta,
    loadPreview: suspend () -> String?,
    onClick: () -> Unit
) {
    var preview by remember(n.id) { mutableStateOf<String?>(null) }
    LaunchedEffect(n.id) {
        // Fetch the preview lazily — first 600 chars stripped of markdown noise
        preview = runCatching { loadPreview() }.getOrNull()
            ?.let { stripMarkdownNoise(it) }
    }
    Surface(
        color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.55f),
        shape = RoundedCornerShape(14.dp),
        modifier = Modifier
            .widthIn(min = 250.dp, max = 280.dp)
            .clickable(onClick = onClick)
    ) {
        Column(Modifier.padding(16.dp)) {
            Text("\u2728", fontSize = 16.sp)
            Spacer(Modifier.height(6.dp))
            Text(
                n.title, fontWeight = FontWeight.SemiBold, fontSize = 14.sp,
                maxLines = 2, overflow = TextOverflow.Ellipsis, lineHeight = 18.sp
            )
            if (n.folder.isNotBlank()) {
                Spacer(Modifier.height(2.dp))
                Text(n.folder, fontSize = 11.sp,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    maxLines = 1, overflow = TextOverflow.Ellipsis)
            }
            Spacer(Modifier.height(8.dp))
            Text(
                preview?.takeIf { it.isNotBlank() } ?: "\u2026",
                fontSize = 12.sp,
                lineHeight = 17.sp,
                color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.78f),
                maxLines = 5,
                overflow = TextOverflow.Ellipsis
            )
        }
    }
}

/** Strip the noisiest markdown bits so the preview reads naturally. */
private fun stripMarkdownNoise(s: String): String {
    var t = s
    // YAML frontmatter at start
    if (t.startsWith("---")) {
        val end = t.indexOf("---", 3)
        if (end > 0) t = t.substring(end + 3)
    }
    t = t
        .replace(Regex("^#+\\s+", RegexOption.MULTILINE), "")    // # H1 prefix
        .replace(Regex("\\*\\*([^*]+)\\*\\*"), "$1")             // **bold**
        .replace(Regex("__([^_]+)__"), "$1")                      // __bold__
        .replace(Regex("`([^`]+)`"), "$1")                        // `code`
        .replace(Regex("!\\[[^\\]]*]\\([^)]*\\)"), "")            // ![image](url)
        .replace(Regex("\\[([^\\]]+)]\\([^)]*\\)"), "$1")        // [text](url) -> text
        .replace(Regex("\\[\\[([^\\[\\]|#^\\n]+)(?:#[^\\[\\]|\\n]*)?(?:\\^[^\\[\\]|\\n]*)?(?:\\|([^\\[\\]\\n]+))?]]")) { m ->
            m.groupValues[2].ifBlank { m.groupValues[1] }
        }
        .replace(Regex("^>+\\s?", RegexOption.MULTILINE), "")    // > blockquote
        .replace(Regex("^[-*+]\\s+", RegexOption.MULTILINE), "")  // bullet
        .replace(Regex("\\s+"), " ")
        .trim()
    return t
}

@Composable
private fun FavouriteCard(n: NoteMeta, onClick: () -> Unit) {
    Surface(
        color = MaterialTheme.colorScheme.primaryContainer,
        shape = RoundedCornerShape(12.dp),
        modifier = Modifier.widthIn(min = 160.dp, max = 210.dp).clickable(onClick = onClick)
    ) {
        Column(Modifier.padding(14.dp)) {
            Text("\u2B50", fontSize = 18.sp)
            Spacer(Modifier.height(6.dp))
            Text(
                n.title, fontWeight = FontWeight.SemiBold, fontSize = 14.sp,
                maxLines = 2, overflow = TextOverflow.Ellipsis, lineHeight = 18.sp
            )
            if (n.folder.isNotBlank()) {
                Spacer(Modifier.height(4.dp))
                Text(n.folder, fontSize = 11.sp,
                    color = MaterialTheme.colorScheme.onPrimaryContainer.copy(alpha = 0.7f),
                    maxLines = 1, overflow = TextOverflow.Ellipsis)
            }
        }
    }
}

@Composable
private fun NewNoteCard(n: NoteMeta, onClick: () -> Unit) {
    Surface(
        color = MaterialTheme.colorScheme.surfaceVariant,
        shape = RoundedCornerShape(12.dp),
        modifier = Modifier.widthIn(min = 160.dp, max = 210.dp).clickable(onClick = onClick)
    ) {
        Column(Modifier.padding(14.dp)) {
            Text("\uD83D\uDCC4", fontSize = 18.sp)
            Spacer(Modifier.height(6.dp))
            Text(
                n.title, fontWeight = FontWeight.SemiBold, fontSize = 14.sp,
                maxLines = 2, overflow = TextOverflow.Ellipsis, lineHeight = 18.sp
            )
            if (n.folder.isNotBlank()) {
                Spacer(Modifier.height(4.dp))
                Text(n.folder, fontSize = 11.sp,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    maxLines = 1, overflow = TextOverflow.Ellipsis)
            }
        }
    }
}

@Composable
private fun RecentCard(r: RecentNote, onClick: () -> Unit) {
    val rel = remember(r.lastOpened) {
        DateUtils.getRelativeTimeSpanString(
            r.lastOpened, System.currentTimeMillis(), DateUtils.MINUTE_IN_MILLIS
        ).toString()
    }
    Surface(
        color = MaterialTheme.colorScheme.surfaceVariant,
        shape = RoundedCornerShape(12.dp),
        modifier = Modifier.widthIn(min = 180.dp, max = 220.dp).clickable(onClick = onClick)
    ) {
        Column(Modifier.padding(14.dp)) {
            Text("\uD83D\uDCC4", fontSize = 18.sp)
            Spacer(Modifier.height(6.dp))
            Text(
                r.title, fontWeight = FontWeight.SemiBold, fontSize = 14.sp,
                maxLines = 2, overflow = TextOverflow.Ellipsis, lineHeight = 18.sp
            )
            Spacer(Modifier.height(6.dp))
            Text(rel, fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
    }
}

@Composable
private fun TopicCardView(t: TopicCard, modifier: Modifier, onClick: () -> Unit) {
    Surface(
        color = MaterialTheme.colorScheme.surfaceVariant,
        shape = RoundedCornerShape(14.dp),
        modifier = modifier.clickable(onClick = onClick)
    ) {
        Row(
            Modifier.padding(14.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(t.emoji, fontSize = 26.sp)
            Spacer(Modifier.width(12.dp))
            Column {
                Text(t.label, fontWeight = FontWeight.SemiBold, fontSize = 15.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                Text(
                    "${t.count} note${if (t.count == 1) "" else "s"}",
                    fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
        }
    }
}

@Composable
private fun WelcomeState(onPick: () -> Unit) {
    Column(
        Modifier.fillMaxSize().padding(32.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        Text("\uD83D\uDCDA", fontSize = 64.sp)
        Spacer(Modifier.height(16.dp))
        Text("Welcome to MarkVault", fontSize = 20.sp, fontWeight = FontWeight.Bold)
        Spacer(Modifier.height(8.dp))
        Text(
            "Choose the folder that holds your Markdown library. " +
                "Everything is indexed and stays 100% on this phone.",
            color = MaterialTheme.colorScheme.onSurfaceVariant, textAlign = TextAlign.Center
        )
        Spacer(Modifier.height(24.dp))
        Button(onClick = onPick) { Text("\uD83D\uDCC1  Choose library folder") }
    }
}

@Composable
private fun EmptyState(onReindex: () -> Unit, onChange: () -> Unit) {
    Column(
        Modifier.fillMaxSize().padding(32.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        Text("No .md files indexed yet.", color = MaterialTheme.colorScheme.onSurfaceVariant)
        Spacer(Modifier.height(12.dp))
        Button(onClick = onReindex) { Text("\u21BB  Index now") }
        Spacer(Modifier.height(12.dp))
        Text(
            "\uD83D\uDCC1 Choose a different folder",
            Modifier.clickable(onClick = onChange).padding(8.dp),
            color = MaterialTheme.colorScheme.primary
        )
    }
}
