package com.tebogo.markvault.ui

import android.text.format.DateUtils
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.clickable
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.layout.wrapContentHeight
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material3.Button
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.blur
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.navigation.NavController
import com.tebogo.markvault.AppViewModel
import com.tebogo.markvault.OpenSource
import com.tebogo.markvault.data.NoteMeta
import com.tebogo.markvault.data.RecentNote
import com.tebogo.markvault.data.TopicCard
import androidx.compose.foundation.layout.fillMaxHeight

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun HomeScreen(vm: AppViewModel, nav: NavController) {
    val libraryUri by vm.libraryUri.collectAsStateWithLifecycle()
    val notes by vm.notes.collectAsStateWithLifecycle()
    val recent by vm.recent.collectAsStateWithLifecycle()
    val topics by vm.topics.collectAsStateWithLifecycle()
    val progress by vm.progress.collectAsStateWithLifecycle()
    val newNotes by vm.newNotes.collectAsStateWithLifecycle()
    val favouriteNotes by vm.favouriteNotes.collectAsStateWithLifecycle()
    val suggested by vm.suggested.collectAsStateWithLifecycle()
    val recentSources by vm.recentOpenSources.collectAsStateWithLifecycle()

    val picker = rememberLauncherForActivityResult(
        ActivityResultContracts.OpenDocumentTree()
    ) { uri -> if (uri != null) vm.setLibrary(uri) }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("\uD83D\uDCDA MarkVault", fontWeight = FontWeight.Bold) }
            )
        },
        bottomBar = {
            MarkVaultBottomBar(
                nav = nav, vm = vm,
                showBack = false,   // Home is the root — no back arrow here
                extraActions = {
                    if (libraryUri != null && !progress.running) {
                        IconButton(onClick = { vm.reindex() }) {
                            Icon(Icons.Default.Refresh, contentDescription = "Sync library")
                        }
                    }
                    IconButton(onClick = { nav.navigate("search") }) {
                        Icon(Icons.Default.Search, contentDescription = "Search library")
                    }
                }
            )
        }
    ) { pad ->
        // v5.4.32 — Tablet 2-column layout when workspace mode is on
        // and window is wide enough. Left sidebar shows recent searches
        // (matches SearchScreen's tablet pattern from v5.4.30). Right
        // column = existing dashboard content, unchanged.
        val screenWidthDp = androidx.compose.ui.platform.LocalConfiguration.current.screenWidthDp
        val isTabletWidth = screenWidthDp >= 600
        val uiMode by vm.uiMode.collectAsStateWithLifecycle()
        val workspaceOn = uiMode == "workspace"
        val useTabletLayout = workspaceOn && isTabletWidth
        val recentSearchesForSidebar by vm.recentSearches.collectAsStateWithLifecycle()

        Row(Modifier.padding(pad).fillMaxSize()) {
            if (useTabletLayout) {
                HomeTabletSidebar(
                    vm = vm,
                    nav = nav,
                    recentSearches = recentSearchesForSidebar,
                    modifier = Modifier.width(280.dp).fillMaxHeight()
                )
                androidx.compose.material3.VerticalDivider()
            }
            Column(Modifier.weight(1f).fillMaxHeight()) {
            if (progress.running) {
                LinearProgressIndicator(Modifier.fillMaxWidth())
                Text(
                    "\u23F3 ${progress.phase} ${progress.done} / ${progress.total}",
                    Modifier.padding(horizontal = 16.dp, vertical = 6.dp),
                    fontSize = 13.sp, color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
            when {
                libraryUri == null -> WelcomeState { picker.launch(null) }
                notes.isEmpty() && !progress.running ->
                    EmptyState(onReindex = { vm.reindex() }, onChange = { picker.launch(null) })
                else -> Dashboard(vm, nav, recent, topics, newNotes, favouriteNotes, suggested, recentSources, notes.size)
            }
        }
        } // v5.4.32 — close outer Row
    }
}

@Composable
private fun Dashboard(
    vm: AppViewModel,
    nav: NavController,
    recent: List<RecentNote>,
    topics: List<TopicCard>,
    newNotes: List<NoteMeta>,
    favouriteNotes: List<NoteMeta>,
    suggested: List<NoteMeta>,
    recentSources: Map<Long, OpenSource>,
    noteCount: Int
) {
    /** Open a note in the correct viewer based on its file type. */
    fun openNote(id: Long, title: String, fileType: String) {
        when (fileType) {
            "pdf" -> {
                vm.openArticle(id, title, fileType = "pdf")
                nav.navigate("pdfReader/$id")
            }
            "mhtml", "html" -> {
                // v4.4 — saved offline web archives go to the WebView-backed
                // reader. Avoid the markdown engine, which can't parse MHTML
                // headers and crashes on the binary content.
                vm.openArticle(id, title, fileType = fileType)
                nav.navigate("htmlReader/$id")
            }
            else -> {
                vm.openArticle(id, title)
                nav.navigate("reader") { launchSingleTop = true }
            }
        }
    }

    // v5.0.0 — Hero search overlay state. When true, content behind is
    // blurred and a big centered search bar takes focus. Tap-away on the
    // dim/blur backdrop dismisses the focus. Defaults to true on entry so
    // search is the first thing the user sees.
    var heroSearchFocused by remember { mutableStateOf(true) }
    val backdropBlur = if (heroSearchFocused) 18.dp else 0.dp

    Box(Modifier.fillMaxSize()) {
    LazyColumn(
        Modifier
            .fillMaxSize()
            .blur(backdropBlur)
    ) {
        // Quick-action buttons. Topics removed in v5.0.0 per the
        // homepage redesign; topic-based query expansion still happens
        // in the search backend, just no longer surfaced as a UI section.
        item {
            Spacer(Modifier.height(96.dp))   // space for hero search above
        }
        item {
            Row(
                Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 2.dp),
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                OutlinedButton(onClick = { nav.navigate("browse") }, modifier = Modifier.weight(1f)) {
                    Text("\uD83D\uDCC1 Browse")
                }
                OutlinedButton(onClick = { nav.navigate("graph") }, modifier = Modifier.weight(1f)) {
                    Text("\uD83C\uDF10 Graph")
                }
            }
        }
        // ⭐ Favourites
        if (favouriteNotes.isNotEmpty()) {
            item { SectionHeader("\u2B50  Favourites") }
            item {
                LazyRow(
                    Modifier.fillMaxWidth().padding(vertical = 4.dp),
                    horizontalArrangement = Arrangement.spacedBy(10.dp),
                    contentPadding = PaddingValues(horizontal = 16.dp)
                ) {
                    items(favouriteNotes, key = { it.id }) { n ->
                        FavouriteCard(n) {
                            openNote(n.id, n.title, n.fileType)
                        }
                    }
                }
            }
        }
        // ✨ New since last sync
        if (newNotes.isNotEmpty()) {
            item { SectionHeader("\u2728  New in library (${newNotes.size})") }
            item {
                LazyRow(
                    Modifier.fillMaxWidth().padding(vertical = 4.dp),
                    horizontalArrangement = Arrangement.spacedBy(10.dp),
                    contentPadding = PaddingValues(horizontal = 16.dp)
                ) {
                    items(newNotes, key = { it.id }) { n ->
                        NewNoteCard(n) {
                            openNote(n.id, n.title, n.fileType)
                        }
                    }
                }
            }
            item {
                HorizontalDivider(
                    Modifier.padding(horizontal = 16.dp, vertical = 4.dp),
                    color = MaterialTheme.colorScheme.surfaceVariant
                )
            }
        }
        // ▶️ Continue reading
        if (recent.isNotEmpty()) {
            item { SectionHeader("\u25B6\uFE0F  Continue reading") }
            item {
                LazyRow(
                    Modifier.fillMaxWidth().padding(vertical = 4.dp),
                    horizontalArrangement = Arrangement.spacedBy(10.dp),
                    contentPadding = PaddingValues(horizontal = 16.dp)
                ) {
                    items(recent, key = { it.id }) { r ->
                        RecentCard(r, recentSources[r.id]) {
                            openNote(r.id, r.title, r.fileType)
                        }
                    }
                }
            }
        }
        // ✨ Suggested for you — wide swipeable preview cards. Sits above Topics so the two
        //    sections share the screen (carousel above, topics grid below).
        if (suggested.isNotEmpty()) {
            item { SectionHeader("\u2728  Suggested for you") }
            item {
                LazyRow(
                    Modifier.fillMaxWidth().padding(vertical = 4.dp),
                    horizontalArrangement = Arrangement.spacedBy(12.dp),
                    contentPadding = PaddingValues(horizontal = 16.dp)
                ) {
                    items(suggested, key = { "sg-" + it.id }) { n ->
                        SuggestedCard(
                            n = n,
                            loadPreview = { vm.previewOf(n.id) },
                            onClick = {
                                openNote(n.id, n.title, n.fileType)
                            }
                        )
                    }
                }
            }
        }
        item { Spacer(Modifier.height(28.dp)) }
    }

    // v5.0.0 — Tap-away backdrop. When the hero search is focused, an
    // invisible click target sits between content and the search bar so
    // tapping anywhere except the search bar dismisses the focus.
    if (heroSearchFocused) {
        Box(
            Modifier
                .fillMaxSize()
                .background(MaterialTheme.colorScheme.scrim.copy(alpha = 0.25f))
                .clickable(
                    indication = null,
                    interactionSource = remember { androidx.compose.foundation.interaction.MutableInteractionSource() }
                ) { heroSearchFocused = false }
        )
    }

    // v5.0.0 — Hero centered search bar. Sits in the foreground always.
    // When focused (default on screen entry): larger, prominent, with
    // blurred content behind. When dismissed by tap-away: shrinks to a
    // compact pill that can be re-focused by tapping it.
    val recents by vm.recentSearches.collectAsStateWithLifecycle()
    val maxRecents by vm.maxRecentSearchesOnHome.collectAsStateWithLifecycle()
    val recentQueries = remember(recents, maxRecents) {
        // De-duplicate by query string (keep newest) and cap at the user's
        // configured limit.
        recents
            .asSequence()
            .map { it.query.trim() }
            .filter { it.isNotEmpty() }
            .distinct()
            .take(maxRecents.coerceAtLeast(0))
            .toList()
    }
    HeroSearchBar(
        focused = heroSearchFocused,
        noteCount = noteCount,
        recentQueries = recentQueries,
        onRecentTap = { q ->
            // Re-run a recent query by writing to vm.query then navigating
            // to the Search screen.
            vm.query.value = q
            heroSearchFocused = false
            nav.navigate("search")
        },
        onFocus = { heroSearchFocused = true },
        onSubmit = { query ->
            // v5.0.0 — Pre-fill the search field by writing to the VM's
            // query StateFlow before navigating. SearchScreen reads from
            // this same flow, so the field shows the typed text already.
            vm.query.value = query
            heroSearchFocused = false
            nav.navigate("search")
        },
        onTapJustSearch = {
            // No query typed — just open the regular Search screen.
            heroSearchFocused = false
            nav.navigate("search")
        }
    )
    }   // end outer Box
}

@Composable
private fun SectionHeader(text: String) {
    Text(
        text,
        Modifier.padding(start = 18.dp, end = 16.dp, top = 16.dp, bottom = 2.dp),
        fontWeight = FontWeight.Bold, fontSize = 15.sp
    )
}

@Composable
private fun SuggestedCard(
    n: NoteMeta,
    loadPreview: suspend () -> String?,
    onClick: () -> Unit
) {
    var preview by remember(n.id) { mutableStateOf<String?>(null) }
    LaunchedEffect(n.id) {
        // Fetch the preview lazily — first 600 chars stripped of markdown noise
        preview = runCatching { loadPreview() }.getOrNull()
            ?.let { stripMarkdownNoise(it) }
    }
    Surface(
        color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.55f),
        shape = RoundedCornerShape(14.dp),
        modifier = Modifier
            .widthIn(min = 250.dp, max = 280.dp)
            .clickable(onClick = onClick)
    ) {
        Column(Modifier.padding(16.dp)) {
            Text(if (n.fileType == "pdf") "\uD83D\uDCD5" else "\u2728", fontSize = 16.sp)
            Spacer(Modifier.height(6.dp))
            Text(
                n.title, fontWeight = FontWeight.SemiBold, fontSize = 14.sp,
                maxLines = 2, overflow = TextOverflow.Ellipsis, lineHeight = 18.sp
            )
            if (n.folder.isNotBlank()) {
                Spacer(Modifier.height(2.dp))
                Text(n.folder, fontSize = 11.sp,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    maxLines = 1, overflow = TextOverflow.Ellipsis)
            }
            Spacer(Modifier.height(8.dp))
            Text(
                preview?.takeIf { it.isNotBlank() } ?: "\u2026",
                fontSize = 12.sp,
                lineHeight = 17.sp,
                color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.78f),
                maxLines = 5,
                overflow = TextOverflow.Ellipsis
            )
        }
    }
}

/** Strip the noisiest markdown bits so the preview reads naturally. */
private fun stripMarkdownNoise(s: String): String {
    var t = s
    // YAML frontmatter at start
    if (t.startsWith("---")) {
        val end = t.indexOf("---", 3)
        if (end > 0) t = t.substring(end + 3)
    }
    t = t
        .replace(Regex("^#+\\s+", RegexOption.MULTILINE), "")    // # H1 prefix
        .replace(Regex("\\*\\*([^*]+)\\*\\*"), "$1")             // **bold**
        .replace(Regex("__([^_]+)__"), "$1")                      // __bold__
        .replace(Regex("`([^`]+)`"), "$1")                        // `code`
        .replace(Regex("!\\[[^\\]]*]\\([^)]*\\)"), "")            // ![image](url)
        .replace(Regex("\\[([^\\]]+)]\\([^)]*\\)"), "$1")        // [text](url) -> text
        .replace(Regex("\\[\\[([^\\[\\]|#^\\n]+)(?:#[^\\[\\]|\\n]*)?(?:\\^[^\\[\\]|\\n]*)?(?:\\|([^\\[\\]\\n]+))?]]")) { m ->
            m.groupValues[2].ifBlank { m.groupValues[1] }
        }
        .replace(Regex("^>+\\s?", RegexOption.MULTILINE), "")    // > blockquote
        .replace(Regex("^[-*+]\\s+", RegexOption.MULTILINE), "")  // bullet
        .replace(Regex("\\s+"), " ")
        .trim()
    return t
}

@Composable
private fun FavouriteCard(n: NoteMeta, onClick: () -> Unit) {
    Surface(
        color = MaterialTheme.colorScheme.primaryContainer,
        shape = RoundedCornerShape(12.dp),
        modifier = Modifier.widthIn(min = 160.dp, max = 210.dp).clickable(onClick = onClick)
    ) {
        Column(Modifier.padding(14.dp)) {
            Text(if (n.fileType == "pdf") "\u2B50\uD83D\uDCD5" else "\u2B50", fontSize = 18.sp)
            Spacer(Modifier.height(6.dp))
            Text(
                n.title, fontWeight = FontWeight.SemiBold, fontSize = 14.sp,
                maxLines = 2, overflow = TextOverflow.Ellipsis, lineHeight = 18.sp
            )
            if (n.folder.isNotBlank()) {
                Spacer(Modifier.height(4.dp))
                Text(n.folder, fontSize = 11.sp,
                    color = MaterialTheme.colorScheme.onPrimaryContainer.copy(alpha = 0.7f),
                    maxLines = 1, overflow = TextOverflow.Ellipsis)
            }
        }
    }
}

@Composable
private fun NewNoteCard(n: NoteMeta, onClick: () -> Unit) {
    Surface(
        color = MaterialTheme.colorScheme.surfaceVariant,
        shape = RoundedCornerShape(12.dp),
        modifier = Modifier.widthIn(min = 160.dp, max = 210.dp).clickable(onClick = onClick)
    ) {
        Column(Modifier.padding(14.dp)) {
            Text(if (n.fileType == "pdf") "\uD83D\uDCD5" else "\uD83D\uDCC4", fontSize = 18.sp)
            Spacer(Modifier.height(6.dp))
            Text(
                n.title, fontWeight = FontWeight.SemiBold, fontSize = 14.sp,
                maxLines = 2, overflow = TextOverflow.Ellipsis, lineHeight = 18.sp
            )
            if (n.folder.isNotBlank()) {
                Spacer(Modifier.height(4.dp))
                Text(n.folder, fontSize = 11.sp,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    maxLines = 1, overflow = TextOverflow.Ellipsis)
            }
        }
    }
}

@Composable
private fun RecentCard(r: RecentNote, source: OpenSource?, onClick: () -> Unit) {
    val rel = remember(r.lastOpened) { formatHistoryTime(r.lastOpened) }
    Surface(
        color = MaterialTheme.colorScheme.surfaceVariant,
        shape = RoundedCornerShape(12.dp),
        // Bolder visible border around each card so they read as distinct entries.
        border = androidx.compose.foundation.BorderStroke(
            1.5.dp, MaterialTheme.colorScheme.outlineVariant
        ),
        modifier = Modifier.widthIn(min = 200.dp, max = 240.dp).clickable(onClick = onClick)
    ) {
        Column(Modifier.padding(14.dp)) {
            // Line 1: file-type icon + source label
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(if (r.fileType == "pdf") "\uD83D\uDCD5" else "\uD83D\uDCC4", fontSize = 18.sp)
                Spacer(Modifier.width(6.dp))
                val (icon, label) = when (source) {
                    OpenSource.LINK -> "\uD83D\uDD17" to "from a link"
                    OpenSource.BACKLINK -> "\u2190" to "from a backlink"
                    OpenSource.GRAPH -> "\uD83C\uDF10" to "from the graph"
                    OpenSource.DIRECT, null -> "" to "opened"
                }
                if (icon.isNotEmpty()) {
                    Text(icon, fontSize = 11.sp)
                    Spacer(Modifier.width(3.dp))
                }
                Text(label, fontSize = 10.sp,
                    color = MaterialTheme.colorScheme.primary,
                    fontWeight = FontWeight.Medium,
                    maxLines = 1, overflow = TextOverflow.Ellipsis)
            }
            Spacer(Modifier.height(7.dp))
            // Line 2: title (bold, up to 2 wrapped lines)
            Text(
                r.title, fontWeight = FontWeight.SemiBold, fontSize = 14.sp,
                maxLines = 2, overflow = TextOverflow.Ellipsis, lineHeight = 18.sp
            )
            Spacer(Modifier.height(7.dp))
            // Line 3: timestamp in primary accent colour (was muted before)
            Text(rel, fontSize = 11.sp,
                fontWeight = FontWeight.Medium,
                color = MaterialTheme.colorScheme.primary)
        }
    }
}

@Composable
private fun TopicCardView(t: TopicCard, modifier: Modifier, onClick: () -> Unit) {
    Surface(
        color = MaterialTheme.colorScheme.surfaceVariant,
        shape = RoundedCornerShape(14.dp),
        modifier = modifier.clickable(onClick = onClick)
    ) {
        Row(
            Modifier.padding(14.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(t.emoji, fontSize = 26.sp)
            Spacer(Modifier.width(12.dp))
            Column {
                Text(t.label, fontWeight = FontWeight.SemiBold, fontSize = 15.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                Text(
                    "${t.count} note${if (t.count == 1) "" else "s"}",
                    fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
        }
    }
}

@Composable
private fun WelcomeState(onPick: () -> Unit) {
    Column(
        Modifier.fillMaxSize().padding(32.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        Text("\uD83D\uDCDA", fontSize = 64.sp)
        Spacer(Modifier.height(16.dp))
        Text("Welcome to MarkVault", fontSize = 20.sp, fontWeight = FontWeight.Bold)
        Spacer(Modifier.height(8.dp))
        Text(
            "Choose the folder that holds your Markdown library. " +
                "Markdown files and PDFs are indexed and stay 100% on this phone.",
            color = MaterialTheme.colorScheme.onSurfaceVariant, textAlign = TextAlign.Center
        )
        Spacer(Modifier.height(24.dp))
        Button(onClick = onPick) { Text("\uD83D\uDCC1  Choose library folder") }
    }
}

@Composable
private fun EmptyState(onReindex: () -> Unit, onChange: () -> Unit) {
    Column(
        Modifier.fillMaxSize().padding(32.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        Text("No .md or .pdf files indexed yet.", color = MaterialTheme.colorScheme.onSurfaceVariant)
        Spacer(Modifier.height(12.dp))
        Button(onClick = onReindex) { Text("\u21BB  Index now") }
        Spacer(Modifier.height(12.dp))
        Text(
            "\uD83D\uDCC1 Choose a different folder",
            Modifier.clickable(onClick = onChange).padding(8.dp),
            color = MaterialTheme.colorScheme.primary
        )
    }
}

/**
 * v5.0.0 — Hero search bar shown over the homepage. Two states:
 *
 *  - **focused**: large centered pill with a real text field and a Search
 *    button. Sits ~30% from the top of the screen so it lands roughly in
 *    the visual center, slightly above middle so the keyboard doesn't
 *    cover it when it opens.
 *  - **unfocused**: a slim pill near the top that the user can tap to
 *    re-focus. This is the "search has been dismissed but is still
 *    accessible" state.
 */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun HeroSearchBar(
    focused: Boolean,
    noteCount: Int,
    recentQueries: List<String> = emptyList(),
    onRecentTap: (String) -> Unit = {},
    onFocus: () -> Unit,
    onSubmit: (String) -> Unit,
    onTapJustSearch: () -> Unit
) {
    if (focused) {
        var text by remember { mutableStateOf("") }
        Box(
            Modifier.fillMaxSize(),
            contentAlignment = Alignment.TopCenter
        ) {
            Column(
                Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp)
                    .padding(top = 110.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Text(
                    "MarkVault",
                    fontSize = 32.sp,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.onSurface
                )
                Spacer(Modifier.height(6.dp))
                Text(
                    "Search $noteCount notes by word, phrase, or topic",
                    fontSize = 13.sp,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
                Spacer(Modifier.height(24.dp))
                Surface(
                    color = MaterialTheme.colorScheme.surface,
                    shape = RoundedCornerShape(28.dp),
                    tonalElevation = 6.dp,
                    shadowElevation = 8.dp,
                    modifier = Modifier
                        .fillMaxWidth()
                        .wrapContentHeight()
                ) {
                    Row(
                        Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 16.dp, vertical = 8.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(
                            Icons.Default.Search,
                            contentDescription = null,
                            tint = MaterialTheme.colorScheme.primary
                        )
                        Spacer(Modifier.width(12.dp))
                        androidx.compose.material3.TextField(
                            value = text,
                            onValueChange = { text = it },
                            placeholder = {
                                Text(
                                    "What are you looking for?",
                                    fontSize = 16.sp
                                )
                            },
                            singleLine = true,
                            modifier = Modifier.weight(1f),
                            colors = androidx.compose.material3.TextFieldDefaults.colors(
                                focusedContainerColor = androidx.compose.ui.graphics.Color.Transparent,
                                unfocusedContainerColor = androidx.compose.ui.graphics.Color.Transparent,
                                disabledContainerColor = androidx.compose.ui.graphics.Color.Transparent,
                                focusedIndicatorColor = androidx.compose.ui.graphics.Color.Transparent,
                                unfocusedIndicatorColor = androidx.compose.ui.graphics.Color.Transparent
                            ),
                            keyboardOptions = androidx.compose.foundation.text.KeyboardOptions(
                                imeAction = androidx.compose.ui.text.input.ImeAction.Search
                            ),
                            keyboardActions = androidx.compose.foundation.text.KeyboardActions(
                                onSearch = {
                                    if (text.isNotBlank()) onSubmit(text.trim())
                                    else onTapJustSearch()
                                }
                            )
                        )
                        if (text.isNotBlank()) {
                            IconButton(onClick = {
                                if (text.isNotBlank()) onSubmit(text.trim())
                            }) {
                                Text("\u279C", fontSize = 20.sp)
                            }
                        }
                    }
                }
                // v5.2.0 — Recent searches list, italic, under the hero
                // search bar. Tap to re-run any recent query. Number of
                // entries shown is the user's pref (default 7).
                if (recentQueries.isNotEmpty()) {
                    Spacer(Modifier.height(18.dp))
                    Text(
                        "Recent searches",
                        fontSize = 11.sp,
                        fontWeight = FontWeight.SemiBold,
                        color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.85f)
                    )
                    Spacer(Modifier.height(6.dp))
                    recentQueries.forEach { q ->
                        Text(
                            q,
                            fontSize = 14.sp,
                            fontStyle = androidx.compose.ui.text.font.FontStyle.Italic,
                            color = MaterialTheme.colorScheme.primary,
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(vertical = 4.dp)
                                .clickable { onRecentTap(q) }
                        )
                    }
                }
            }
        }
    } else {
        // Compact pill at top, re-focusable.
        Box(
            Modifier.fillMaxSize(),
            contentAlignment = Alignment.TopCenter
        ) {
            Surface(
                color = MaterialTheme.colorScheme.surface,
                shape = RoundedCornerShape(24.dp),
                tonalElevation = 4.dp,
                shadowElevation = 4.dp,
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp, vertical = 12.dp)
                    .clickable { onFocus() }
            ) {
                Row(
                    Modifier.padding(horizontal = 14.dp, vertical = 12.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(
                        Icons.Default.Search,
                        contentDescription = null,
                        tint = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                    Spacer(Modifier.width(10.dp))
                    Text(
                        "Search $noteCount notes\u2026",
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }
        }
    }
}

/**
 * v5.4.32 — Tablet-mode sidebar for HomeScreen. Shows MarkVault title
 * + Recent searches list. Consistent visual language with SearchScreen's
 * tablet sidebar (v5.4.30). Tapping a recent search routes to Search
 * with that query pre-populated.
 */
@androidx.compose.runtime.Composable
private fun HomeTabletSidebar(
    vm: com.tebogo.markvault.AppViewModel,
    nav: androidx.navigation.NavController,
    recentSearches: List<com.tebogo.markvault.RecentSearch>,
    modifier: androidx.compose.ui.Modifier = androidx.compose.ui.Modifier
) {
    val uniqueQueries = androidx.compose.runtime.remember(recentSearches) {
        val seen = linkedSetOf<String>()
        recentSearches.forEach { rs -> seen.add(rs.query) }
        seen.toList()
    }
    androidx.compose.foundation.layout.Column(
        modifier = modifier
            .background(
                androidx.compose.material3.MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.25f)
            )
            .padding(14.dp)
    ) {
        androidx.compose.foundation.layout.Row(
            verticalAlignment = androidx.compose.ui.Alignment.CenterVertically
        ) {
            Text(
                "\uD83D\uDCDA MarkVault",
                fontSize = 18.sp,
                fontWeight = androidx.compose.ui.text.font.FontWeight.Bold
            )
        }
        androidx.compose.foundation.layout.Spacer(
            androidx.compose.ui.Modifier.height(16.dp)
        )
        Text(
            "\uD83D\uDD53 Recent searches",
            fontSize = 13.sp,
            fontWeight = androidx.compose.ui.text.font.FontWeight.SemiBold,
            color = androidx.compose.material3.MaterialTheme.colorScheme.onSurface
        )
        androidx.compose.foundation.layout.Spacer(
            androidx.compose.ui.Modifier.height(4.dp)
        )
        if (uniqueQueries.isEmpty()) {
            Text(
                "None yet.",
                fontSize = 11.sp,
                color = androidx.compose.material3.MaterialTheme.colorScheme.onSurfaceVariant
            )
        } else {
            Text(
                "${uniqueQueries.size} \u00B7 tap to re-run",
                fontSize = 11.sp,
                color = androidx.compose.material3.MaterialTheme.colorScheme.onSurfaceVariant
            )
            androidx.compose.foundation.layout.Spacer(
                androidx.compose.ui.Modifier.height(8.dp)
            )
            LazyColumn(
                modifier = androidx.compose.ui.Modifier.weight(1f).fillMaxWidth()
            ) {
                items(uniqueQueries, key = { it }) { q ->
                    androidx.compose.material3.Surface(
                        color = androidx.compose.ui.graphics.Color.Transparent,
                        shape = androidx.compose.foundation.shape.RoundedCornerShape(8.dp),
                        modifier = androidx.compose.ui.Modifier
                            .fillMaxWidth()
                            .padding(vertical = 2.dp)
                            .clickable {
                                vm.query.value = q
                                nav.navigate("search")
                            }
                    ) {
                        Text(
                            q,
                            androidx.compose.ui.Modifier.padding(
                                horizontal = 10.dp, vertical = 8.dp
                            ),
                            fontSize = 13.sp,
                            color = androidx.compose.material3.MaterialTheme.colorScheme.onSurface,
                            maxLines = 1,
                            overflow = androidx.compose.ui.text.style.TextOverflow.Ellipsis
                        )
                    }
                }
            }
        }
    }
}
