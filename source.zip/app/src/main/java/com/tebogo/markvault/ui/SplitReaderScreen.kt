package com.tebogo.markvault.ui

import android.net.Uri
import android.os.ParcelFileDescriptor
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.activity.compose.BackHandler
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Close
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.toArgb
import androidx.compose.ui.platform.LocalConfiguration
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.navigation.NavController
import com.tebogo.markvault.AppViewModel
import com.tebogo.markvault.data.Note
import com.tebogo.markvault.util.MhtmlParser
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

/**
 * Dual-pane / split-screen reader — supports ANY combination of file types:
 * markdown ↔ markdown, markdown ↔ PDF, PDF ↔ HTML, HTML ↔ HTML, etc.
 *
 * v4.7 — route changed from `splitReader/{leftId}/{rightId}` (both markdown
 * implicit) to `splitReader/{leftId}/{leftType}/{rightId}/{rightType}`.
 * Each pane dispatches to the right viewer based on its type.
 *
 * The features inside each pane are minimal versions of the standalone readers —
 * no annotations, no toolbar, no find-in-page (all of those live on the
 * fullscreen single-pane readers). Split view is for side-by-side comparison
 * and cross-referencing, not deep editing.
 */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SplitReaderScreen(
    vm: AppViewModel,
    nav: NavController,
    leftId: Long,
    leftType: String,
    rightId: Long,
    rightType: String
) {
    val orientation = LocalConfiguration.current.orientation
    val isLandscape = orientation == android.content.res.Configuration.ORIENTATION_LANDSCAPE
    val routeKey = "splitReader/$leftId/$leftType/$rightId/$rightType"

    BackHandler { nav.popBackStack() }

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Text(
                        "\uD83E\uDE9F  Split view",
                        fontWeight = FontWeight.SemiBold,
                        fontSize = 15.sp
                    )
                }
            )
        },
        bottomBar = {
            MarkVaultBottomBar(
                nav = nav, vm = vm,
                extraActions = {
                    TextButton(onClick = {
                        // Exit-split returns to the LEFT pane's normal reader
                        openInFullReader(vm, nav, leftId, leftType, routeKey)
                    }) { Text("Exit split") }
                }
            )
        }
    ) { pad ->
        Box(Modifier.padding(pad).fillMaxSize()) {
            if (isLandscape) {
                Row(Modifier.fillMaxSize()) {
                    SplitPane(
                        vm = vm,
                        noteId = leftId, fileType = leftType,
                        modifier = Modifier.fillMaxHeight().weight(1f),
                        onClose = { openInFullReader(vm, nav, rightId, rightType, routeKey) }
                    )
                    Surface(
                        color = MaterialTheme.colorScheme.outlineVariant,
                        modifier = Modifier.fillMaxHeight().width(1.dp)
                    ) {}
                    SplitPane(
                        vm = vm,
                        noteId = rightId, fileType = rightType,
                        modifier = Modifier.fillMaxHeight().weight(1f),
                        onClose = { openInFullReader(vm, nav, leftId, leftType, routeKey) }
                    )
                }
            } else {
                Column(Modifier.fillMaxSize()) {
                    SplitPane(
                        vm = vm,
                        noteId = leftId, fileType = leftType,
                        modifier = Modifier.fillMaxWidth().weight(1f),
                        onClose = { openInFullReader(vm, nav, rightId, rightType, routeKey) }
                    )
                    Surface(
                        color = MaterialTheme.colorScheme.outlineVariant,
                        modifier = Modifier.fillMaxWidth().height(1.dp)
                    ) {}
                    SplitPane(
                        vm = vm,
                        noteId = rightId, fileType = rightType,
                        modifier = Modifier.fillMaxWidth().weight(1f),
                        onClose = { openInFullReader(vm, nav, leftId, leftType, routeKey) }
                    )
                }
            }
        }
    }
}

/** Pop the split route and route into the right standalone reader for the surviving pane. */
private fun openInFullReader(
    vm: AppViewModel, nav: NavController, id: Long, type: String, popRoute: String
) {
    when (type) {
        "pdf" -> {
            vm.openArticle(id, "", fileType = "pdf")
            nav.navigate("pdfReader/$id") {
                popUpTo(popRoute) { inclusive = true }
                launchSingleTop = true
            }
        }
        "html", "mhtml" -> {
            vm.openArticle(id, "", fileType = type)
            nav.navigate("htmlReader/$id") {
                popUpTo(popRoute) { inclusive = true }
                launchSingleTop = true
            }
        }
        else -> {
            vm.openArticle(id, "", com.tebogo.markvault.OpenSource.LINK)
            nav.navigate("reader") {
                popUpTo(popRoute) { inclusive = true }
                launchSingleTop = true
            }
        }
    }
}

/** Dispatch to the right pane variant based on the file's type. */
@Composable
private fun SplitPane(
    vm: AppViewModel,
    noteId: Long,
    fileType: String,
    modifier: Modifier = Modifier,
    onClose: () -> Unit
) {
    when (fileType) {
        "pdf" -> SplitPdfPane(vm, noteId, modifier, onClose)
        "html", "mhtml" -> SplitHtmlPane(vm, noteId, modifier, onClose)
        else -> SplitMarkdownPane(vm, noteId, modifier, onClose)
    }
}

/** Markdown pane — same WebView + render.js pipeline used in the standalone reader. */
@Composable
private fun SplitMarkdownPane(
    vm: AppViewModel,
    noteId: Long,
    modifier: Modifier,
    onClose: () -> Unit
) {
    val ctx = LocalContext.current
    val theme by vm.theme.collectAsStateWithLifecycle()
    val fontScale by vm.fontScale.collectAsStateWithLifecycle()
    val smartStylingAllDocs by vm.smartStylingAllDocs.collectAsStateWithLifecycle()
    val textContrast by vm.textContrast.collectAsStateWithLifecycle()

    var note by remember(noteId) { mutableStateOf<Note?>(null) }
    var loading by remember(noteId) { mutableStateOf(true) }
    var pageReady by remember(noteId) { mutableStateOf(false) }
    var webView by remember(noteId) { mutableStateOf<WebView?>(null) }

    LaunchedEffect(noteId) {
        loading = true
        note = vm.loadNote(noteId)
        loading = false
    }

    LaunchedEffect(pageReady, note?.id, theme, fontScale, textContrast) {
        val wv = webView ?: return@LaunchedEffect
        val n = note ?: return@LaunchedEffect
        if (!pageReady) return@LaunchedEffect
        val smartAll = if (smartStylingAllDocs) "true" else "false"
        // v4.18.0 — pre-render markdown via flexmark (see ReaderScreen for
        // rationale). JS `renderMarkdown` now consumes HTML.
        val html = com.tebogo.markvault.markdown.MarkdownEngine.render(n.content) { target ->
            vm.resolveEmbedContent(target)
        }
        wv.evaluateJavascript(
            "renderMarkdown(${jsString(html)}, $fontScale, ${jsString(theme)}, $smartAll, $textContrast);",
            null
        )
    }

    PaneFrame(
        title = note?.title,
        loading = loading,
        notFound = note == null && !loading,
        onClose = onClose,
        modifier = modifier
    ) {
        val bg = MaterialTheme.colorScheme.background.toArgb()
        AndroidView(
            modifier = Modifier.fillMaxSize(),
            factory = { c ->
                WebView(c).apply {
                    settings.javaScriptEnabled = true
                    settings.domStorageEnabled = true
                    settings.allowFileAccessFromFileURLs = false
                    settings.allowUniversalAccessFromFileURLs = false
                    setBackgroundColor(bg)
                    webViewClient = object : WebViewClient() {
                        override fun onPageFinished(view: WebView?, url: String?) {
                            pageReady = true
                        }
                    }
                    loadUrl("file:///android_asset/viewer.html")
                    webView = this
                }
            }
        )
    }
}

/** HTML/MHTML pane — uses the same MhtmlParser + WebView path as HtmlReaderScreen. */
@Composable
private fun SplitHtmlPane(
    vm: AppViewModel,
    noteId: Long,
    modifier: Modifier,
    onClose: () -> Unit
) {
    val ctx = LocalContext.current
    var note by remember(noteId) { mutableStateOf<Note?>(null) }
    var html by remember(noteId) { mutableStateOf<String?>(null) }
    var baseUrl by remember(noteId) { mutableStateOf<String?>(null) }
    var loading by remember(noteId) { mutableStateOf(true) }
    var loaded by remember(noteId) { mutableStateOf(false) }

    LaunchedEffect(noteId) {
        loading = true
        val n = withContext(Dispatchers.IO) { vm.loadNote(noteId) }
        note = n
        if (n == null) { loading = false; return@LaunchedEffect }
        val bytes = withContext(Dispatchers.IO) {
            runCatching {
                ctx.contentResolver.openInputStream(Uri.parse(n.uri))?.use { it.readBytes() }
            }.getOrNull()
        }
        if (bytes != null) {
            val nameLower = n.name.lowercase()
            val isMhtml = nameLower.endsWith(".mhtml") || nameLower.endsWith(".mht")
            if (isMhtml) {
                html = withContext(Dispatchers.IO) { MhtmlParser.extractHtmlContent(bytes) }
                baseUrl = withContext(Dispatchers.IO) { MhtmlParser.extractBaseUrl(bytes) }
            } else {
                html = try { String(bytes, Charsets.UTF_8) } catch (_: Exception) { String(bytes) }
            }
        }
        loading = false
    }

    PaneFrame(
        title = note?.title,
        loading = loading,
        notFound = note == null && !loading,
        onClose = onClose,
        modifier = modifier
    ) {
        if (html != null) {
            AndroidView(
                modifier = Modifier.fillMaxSize(),
                factory = { c ->
                    WebView(c).apply {
                        settings.javaScriptEnabled = true
                        settings.domStorageEnabled = true
                        settings.useWideViewPort = true
                        settings.loadWithOverviewMode = true
                        settings.mixedContentMode = WebSettings.MIXED_CONTENT_COMPATIBILITY_MODE
                        webViewClient = WebViewClient()
                    }
                },
                update = { w ->
                    if (!loaded) {
                        runCatching {
                            w.loadDataWithBaseURL(
                                baseUrl ?: "about:blank",
                                html ?: "",
                                "text/html", "utf-8", null
                            )
                        }
                        loaded = true
                    }
                }
            )
        }
    }
}

/** PDF pane — minimal LazyColumn of rendered page bitmaps via PdfRenderer. */
@Composable
private fun SplitPdfPane(
    vm: AppViewModel,
    noteId: Long,
    modifier: Modifier,
    onClose: () -> Unit
) {
    val ctx = LocalContext.current
    var note by remember(noteId) { mutableStateOf<Note?>(null) }
    var pageCount by remember(noteId) { mutableStateOf(0) }
    var renderer by remember(noteId) {
        mutableStateOf<android.graphics.pdf.PdfRenderer?>(null)
    }
    var loading by remember(noteId) { mutableStateOf(true) }

    LaunchedEffect(noteId) {
        loading = true
        val n = withContext(Dispatchers.IO) { vm.loadNote(noteId) }
        note = n
        if (n != null) {
            withContext(Dispatchers.IO) {
                runCatching {
                    val pfd = ctx.contentResolver.openFileDescriptor(Uri.parse(n.uri), "r")
                    if (pfd != null) {
                        val r = android.graphics.pdf.PdfRenderer(pfd)
                        renderer = r
                        pageCount = r.pageCount
                    }
                }
            }
        }
        loading = false
    }

    val listState = rememberLazyListState()

    PaneFrame(
        title = note?.title,
        loading = loading,
        notFound = note == null && !loading,
        onClose = onClose,
        modifier = modifier
    ) {
        if (renderer != null && pageCount > 0) {
            LazyColumn(
                modifier = Modifier.fillMaxSize().background(MaterialTheme.colorScheme.surface),
                state = listState
            ) {
                items(pageCount) { idx ->
                    SplitPdfPage(renderer!!, idx)
                }
            }
        } else if (!loading) {
            Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                Text(
                    "Could not open PDF.",
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
        }
    }
}

@Composable
private fun SplitPdfPage(
    renderer: android.graphics.pdf.PdfRenderer,
    pageIndex: Int
) {
    var bmp by remember(pageIndex) {
        mutableStateOf<android.graphics.Bitmap?>(null)
    }
    LaunchedEffect(pageIndex) {
        runCatching {
            withContext(Dispatchers.IO) {
                synchronized(renderer) {
                    val page = renderer.openPage(pageIndex)
                    val w = 1080
                    val h = (1080.0 * page.height / page.width).toInt()
                    val b = android.graphics.Bitmap.createBitmap(
                        w, h, android.graphics.Bitmap.Config.ARGB_8888
                    )
                    page.render(b, null, null,
                        android.graphics.pdf.PdfRenderer.Page.RENDER_MODE_FOR_DISPLAY)
                    page.close()
                    bmp = b
                }
            }
        }
    }
    val b = bmp
    if (b != null) {
        Image(
            bitmap = b.asImageBitmap(),
            contentDescription = "Page ${pageIndex + 1}",
            modifier = Modifier.fillMaxWidth().padding(vertical = 2.dp)
        )
    } else {
        Box(Modifier.fillMaxWidth().height(400.dp), contentAlignment = Alignment.Center) {
            Text("Rendering…", color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
    }
}

/** Common pane chrome — header + content area. */
@Composable
private fun PaneFrame(
    title: String?,
    loading: Boolean,
    notFound: Boolean,
    onClose: () -> Unit,
    modifier: Modifier = Modifier,
    content: @Composable () -> Unit
) {
    Column(modifier) {
        Surface(color = MaterialTheme.colorScheme.surfaceVariant) {
            Row(
                Modifier.fillMaxWidth().padding(start = 12.dp, end = 4.dp, top = 4.dp, bottom = 4.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    title ?: "Loading…",
                    Modifier.weight(1f),
                    fontSize = 13.sp,
                    fontWeight = FontWeight.SemiBold,
                    maxLines = 1, overflow = TextOverflow.Ellipsis
                )
                IconButton(onClick = onClose) {
                    Icon(Icons.Default.Close, contentDescription = "Close pane")
                }
            }
        }
        Box(Modifier.fillMaxSize()) {
            when {
                loading -> Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                    Text("Loading…", color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
                notFound -> Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                    Text("Not found.", color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
                else -> content()
            }
        }
    }
}

private fun jsString(s: String?): String {
    if (s == null) return "''"
    val esc = s.replace("\\", "\\\\").replace("'", "\\'")
        .replace("\n", "\\n").replace("\r", "")
    return "'$esc'"
}

/**
 * Picker dialog the Markdown Reader uses when the user taps "Open in split view".
 * Lists every OTHER markdown tab and routes the user into the dual-pane reader
 * with both panes set to `md/md`.
 *
 * Kept in this file (rather than ReaderScreen.kt) because all split-related UI
 * already lives here, so the import surface stays tidy.
 */
@Composable
fun SplitViewPickerDialog(
    currentId: Long,
    tabs: List<com.tebogo.markvault.TabInfo>,
    onDismiss: () -> Unit,
    onPick: (Long) -> Unit
) {
    val partners = tabs.filter { it.id != currentId && it.fileType == "md" }
    androidx.compose.material3.AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Open in split view with…") },
        text = {
            if (partners.isEmpty()) {
                Text(
                    "Open another markdown note first, then come back here to pair them.",
                    fontSize = 13.sp
                )
            } else {
                Column {
                    partners.forEach { p ->
                        androidx.compose.material3.TextButton(
                            onClick = { onPick(p.id) },
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Text(
                                p.title.ifBlank { "Untitled" },
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis
                            )
                        }
                    }
                }
            }
        },
        confirmButton = {
            androidx.compose.material3.TextButton(onClick = onDismiss) { Text("Cancel") }
        }
    )
}
