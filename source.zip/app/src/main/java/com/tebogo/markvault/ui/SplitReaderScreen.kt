package com.tebogo.markvault.ui

import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.activity.compose.BackHandler
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Close
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.toArgb
import androidx.compose.ui.platform.LocalConfiguration
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.navigation.NavController
import com.tebogo.markvault.AppViewModel
import com.tebogo.markvault.data.Note

/**
 * True dual-pane / split-screen reader. Renders two independent notes side-by-side
 * (or stacked, depending on screen orientation). Each pane has its own WebView,
 * its own scroll position, its own loaded content — they don't share runtime state.
 *
 * Layout:
 *   - **Landscape**: side-by-side Row, 50/50 split.
 *   - **Portrait**: stacked Column, 50/50 vertical split.
 *
 * Each pane has a small header showing the note title + a close button. Closing
 * one pane returns the user to the regular single-pane reader for the other note.
 */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SplitReaderScreen(
    vm: AppViewModel,
    nav: NavController,
    leftId: Long,
    rightId: Long
) {
    val config = LocalConfiguration.current
    val isLandscape = config.screenWidthDp > config.screenHeightDp

    BackHandler { nav.popBackStack() }

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Text(
                        "\uD83E\uDE9F Split view",
                        fontWeight = FontWeight.SemiBold,
                        fontSize = 15.sp
                    )
                }
            )
        },
        bottomBar = {
            MarkVaultBottomBar(
                nav = nav, vm = vm,
                extraActions = {
                    // Tapping "Exit split" returns to the regular single-pane reader,
                    // re-opening whichever pane was on the left.
                    TextButton(onClick = {
                        vm.openArticle(leftId, "", com.tebogo.markvault.OpenSource.LINK)
                        nav.navigate("reader") {
                            popUpTo("splitReader/$leftId/$rightId") { inclusive = true }
                            launchSingleTop = true
                        }
                    }) { Text("Exit split") }
                }
            )
        }
    ) { pad ->
        Box(Modifier.padding(pad).fillMaxSize()) {
            if (isLandscape) {
                Row(Modifier.fillMaxSize()) {
                    SplitReaderPane(
                        vm = vm,
                        noteId = leftId,
                        modifier = Modifier.fillMaxHeight().weight(1f),
                        onPaneClose = {
                            // Closing the left pane: route the right one into the regular reader
                            vm.openArticle(rightId, "", com.tebogo.markvault.OpenSource.LINK)
                            nav.navigate("reader") {
                                popUpTo("splitReader/$leftId/$rightId") { inclusive = true }
                                launchSingleTop = true
                            }
                        }
                    )
                    // Divider between panes
                    Surface(
                        color = MaterialTheme.colorScheme.outlineVariant,
                        modifier = Modifier.fillMaxHeight().width(1.dp)
                    ) {}
                    SplitReaderPane(
                        vm = vm,
                        noteId = rightId,
                        modifier = Modifier.fillMaxHeight().weight(1f),
                        onPaneClose = {
                            vm.openArticle(leftId, "", com.tebogo.markvault.OpenSource.LINK)
                            nav.navigate("reader") {
                                popUpTo("splitReader/$leftId/$rightId") { inclusive = true }
                                launchSingleTop = true
                            }
                        }
                    )
                }
            } else {
                Column(Modifier.fillMaxSize()) {
                    SplitReaderPane(
                        vm = vm,
                        noteId = leftId,
                        modifier = Modifier.fillMaxWidth().weight(1f),
                        onPaneClose = {
                            vm.openArticle(rightId, "", com.tebogo.markvault.OpenSource.LINK)
                            nav.navigate("reader") {
                                popUpTo("splitReader/$leftId/$rightId") { inclusive = true }
                                launchSingleTop = true
                            }
                        }
                    )
                    Surface(
                        color = MaterialTheme.colorScheme.outlineVariant,
                        modifier = Modifier.fillMaxWidth().height(1.dp)
                    ) {}
                    SplitReaderPane(
                        vm = vm,
                        noteId = rightId,
                        modifier = Modifier.fillMaxWidth().weight(1f),
                        onPaneClose = {
                            vm.openArticle(leftId, "", com.tebogo.markvault.OpenSource.LINK)
                            nav.navigate("reader") {
                                popUpTo("splitReader/$leftId/$rightId") { inclusive = true }
                                launchSingleTop = true
                            }
                        }
                    )
                }
            }
        }
    }
}

/**
 * One pane within the split view. Independent WebView + scroll position + content.
 * Shares theme/font scale with the rest of the app via the VM flows, so changing
 * font in one pane (via app-wide settings) updates both panes.
 */
@Composable
private fun SplitReaderPane(
    vm: AppViewModel,
    noteId: Long,
    modifier: Modifier = Modifier,
    onPaneClose: () -> Unit
) {
    val ctx = LocalContext.current
    val theme by vm.theme.collectAsStateWithLifecycle()
    val fontScale by vm.fontScale.collectAsStateWithLifecycle()
    val smartStylingAllDocs by vm.smartStylingAllDocs.collectAsStateWithLifecycle()
    val textContrast by vm.textContrast.collectAsStateWithLifecycle()

    var note by remember(noteId) { mutableStateOf<Note?>(null) }
    var loading by remember(noteId) { mutableStateOf(true) }
    var pageReady by remember(noteId) { mutableStateOf(false) }
    var webView by remember(noteId) { mutableStateOf<WebView?>(null) }

    LaunchedEffect(noteId) {
        loading = true
        note = vm.loadNote(noteId)
        loading = false
    }

    // Re-render whenever the note loads or theme/font/contrast changes
    LaunchedEffect(pageReady, note?.id, theme, fontScale, textContrast) {
        val wv = webView ?: return@LaunchedEffect
        val n = note ?: return@LaunchedEffect
        if (!pageReady) return@LaunchedEffect
        val smartAll = if (smartStylingAllDocs) "true" else "false"
        wv.evaluateJavascript(
            "renderMarkdown(${jsString(n.content)}, $fontScale, ${jsString(theme)}, $smartAll, $textContrast);",
            null
        )
    }

    Column(modifier) {
        // Per-pane header: title + close
        Surface(color = MaterialTheme.colorScheme.surfaceVariant) {
            Row(
                Modifier.fillMaxWidth().padding(start = 12.dp, end = 4.dp, top = 4.dp, bottom = 4.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    note?.title ?: "Loading\u2026",
                    Modifier.weight(1f),
                    fontSize = 13.sp,
                    fontWeight = FontWeight.SemiBold,
                    maxLines = 1, overflow = TextOverflow.Ellipsis
                )
                IconButton(onClick = onPaneClose, modifier = Modifier.padding(0.dp)) {
                    Icon(
                        Icons.Default.Close,
                        contentDescription = "Close pane",
                        modifier = Modifier
                    )
                }
            }
        }
        // The WebView fills the rest of the pane
        Box(Modifier.fillMaxSize()) {
            when {
                loading -> Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                    Text("Loading\u2026", color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
                note == null -> Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                    Text("Note not found.", color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
                else -> {
                    val bg = MaterialTheme.colorScheme.background.toArgb()
                    AndroidView(
                        modifier = Modifier.fillMaxSize(),
                        factory = { c ->
                            WebView(c).apply {
                                setBackgroundColor(bg)
                                settings.javaScriptEnabled = true
                                settings.allowFileAccess = true
                                settings.domStorageEnabled = true
                                settings.mixedContentMode = WebSettings.MIXED_CONTENT_COMPATIBILITY_MODE
                                webViewClient = object : WebViewClient() {
                                    override fun onPageFinished(view: WebView?, url: String?) {
                                        pageReady = true
                                    }
                                }
                                loadUrl("file:///android_asset/viewer.html")
                                webView = this
                            }
                        }
                    )
                }
            }
        }
    }
}

/**
 * Dialog shown from the regular Reader's overflow menu to pick another open tab
 * to render side-by-side with the current one. If there are no other tabs open,
 * we explain that.
 */
@Composable
fun SplitViewPickerDialog(
    currentId: Long,
    tabs: List<com.tebogo.markvault.TabInfo>,
    onDismiss: () -> Unit,
    onPick: (otherId: Long) -> Unit
) {
    val candidates = remember(currentId, tabs) {
        tabs.filter { it.id != currentId && it.fileType == "md" }
    }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("\uD83E\uDE9F Open in split view", fontWeight = FontWeight.Bold) },
        text = {
            if (candidates.isEmpty()) {
                Text(
                    "Open another markdown note in a tab first, then come back and pick it here.",
                    fontSize = 13.sp,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            } else {
                Column {
                    Text(
                        "Pick another open note to view alongside this one:",
                        fontSize = 12.sp,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                    Spacer(Modifier.height(8.dp))
                    LazyColumn(Modifier.height(280.dp)) {
                        items(candidates, key = { it.id }) { t ->
                            Surface(
                                color = MaterialTheme.colorScheme.surfaceVariant,
                                shape = RoundedCornerShape(8.dp),
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(vertical = 3.dp)
                                    .clickable { onPick(t.id) }
                            ) {
                                Text(
                                    t.title,
                                    Modifier.padding(horizontal = 12.dp, vertical = 10.dp),
                                    fontSize = 14.sp,
                                    fontWeight = FontWeight.Medium,
                                    maxLines = 2, overflow = TextOverflow.Ellipsis
                                )
                            }
                        }
                    }
                }
            }
        },
        confirmButton = {
            TextButton(onClick = onDismiss) { Text("Cancel") }
        }
    )
}

/** Same Kotlin → JS string escape used by the main Reader. */
private fun jsString(s: String): String =
    "\"" + s.replace("\\", "\\\\")
        .replace("\"", "\\\"")
        .replace("\n", "\\n")
        .replace("\r", "\\r") + "\""
