package com.tebogo.markvault.ui

import android.net.Uri
import android.os.ParcelFileDescriptor
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.activity.compose.BackHandler
import androidx.compose.foundation.Image
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Close
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.toArgb
import androidx.compose.ui.platform.LocalConfiguration
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.navigation.NavController
import com.tebogo.markvault.AppViewModel
import com.tebogo.markvault.data.Note
import com.tebogo.markvault.util.MhtmlParser
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

/**
 * Dual-pane / split-screen reader — supports ANY combination of file types:
 * markdown ↔ markdown, markdown ↔ PDF, PDF ↔ HTML, HTML ↔ HTML, etc.
 *
 * v4.7 — route changed from `splitReader/{leftId}/{rightId}` (both markdown
 * implicit) to `splitReader/{leftId}/{leftType}/{rightId}/{rightType}`.
 * Each pane dispatches to the right viewer based on its type.
 *
 * The features inside each pane are minimal versions of the standalone readers —
 * no annotations, no toolbar, no find-in-page (all of those live on the
 * fullscreen single-pane readers). Split view is for side-by-side comparison
 * and cross-referencing, not deep editing.
 */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SplitReaderScreen(
    vm: AppViewModel,
    nav: NavController,
    leftId: Long,
    leftType: String,
    rightId: Long,
    rightType: String
) {
    val orientation = LocalConfiguration.current.orientation
    val isLandscape = orientation == android.content.res.Configuration.ORIENTATION_LANDSCAPE
    val routeKey = "splitReader/$leftId/$leftType/$rightId/$rightType"
    val persistedSplitRatio by vm.workspaceSplitRatio.collectAsStateWithLifecycle()
    var splitRatio by remember(persistedSplitRatio) { mutableStateOf(persistedSplitRatio) }
    val screenWidthDp = LocalConfiguration.current.screenWidthDp.toFloat().coerceAtLeast(1f)
    val screenHeightDp = LocalConfiguration.current.screenHeightDp.toFloat().coerceAtLeast(1f)
    val openTabs by vm.tabs.collectAsStateWithLifecycle()

    fun replaceSplit(newLeftId: Long, newLeftType: String, newRightId: Long, newRightType: String) {
        val route = "splitReader/$newLeftId/$newLeftType/$newRightId/$newRightType"
        nav.navigate(route) {
            popUpTo(routeKey) { inclusive = true }
            launchSingleTop = true
        }
    }

    LaunchedEffect(leftId, leftType, rightId, rightType) {
        vm.setWorkspaceSplitSession(leftId, leftType, rightId, rightType)
    }

    BackHandler { nav.popBackStack() }

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Text(
                        "\uD83E\uDE9F  Split view",
                        fontWeight = FontWeight.SemiBold,
                        fontSize = 15.sp
                    )
                }
            )
        },
        bottomBar = {
            MarkVaultBottomBar(
                nav = nav, vm = vm,
                extraActions = {
                    TextButton(onClick = {
                        replaceSplit(rightId, rightType, leftId, leftType)
                    }) { Text("Swap") }
                    TextButton(onClick = {
                        // Exit-split returns to the LEFT pane's normal reader
                        openInFullReader(vm, nav, leftId, leftType, routeKey)
                    }) { Text("Exit split") }
                }
            )
        }
    ) { pad ->
        Box(Modifier.padding(pad).fillMaxSize()) {
            if (isLandscape) {
                Row(Modifier.fillMaxSize()) {
                    Column(Modifier.fillMaxHeight().weight(splitRatio)) {
                        PaneTabStrip(
                            tabs = openTabs,
                            selectedId = leftId,
                            excludedId = rightId,
                            onSelect = { tab ->
                                replaceSplit(tab.id, tab.fileType, rightId, rightType)
                            }
                        )
                        SplitPane(
                            vm = vm,
                            noteId = leftId, fileType = leftType,
                            modifier = Modifier.fillMaxWidth().weight(1f),
                            onClose = { openInFullReader(vm, nav, rightId, rightType, routeKey) }
                        )
                    }
                    Surface(
                        color = MaterialTheme.colorScheme.outlineVariant,
                        modifier = Modifier
                            .fillMaxHeight()
                            .width(10.dp)
                            .pointerInput(screenWidthDp, splitRatio) {
                                detectDragGestures(
                                    onDragEnd = { vm.setWorkspaceSplitRatio(splitRatio) }
                                ) { _, dragAmount ->
                                    splitRatio = (splitRatio + dragAmount.x / screenWidthDp)
                                        .coerceIn(0.25f, 0.75f)
                                }
                            }
                    ) {}
                    Column(Modifier.fillMaxHeight().weight(1f - splitRatio)) {
                        PaneTabStrip(
                            tabs = openTabs,
                            selectedId = rightId,
                            excludedId = leftId,
                            onSelect = { tab ->
                                replaceSplit(leftId, leftType, tab.id, tab.fileType)
                            }
                        )
                        SplitPane(
                            vm = vm,
                            noteId = rightId, fileType = rightType,
                            modifier = Modifier.fillMaxWidth().weight(1f),
                            onClose = { openInFullReader(vm, nav, leftId, leftType, routeKey) }
                        )
                    }
                }
            } else {
                Column(Modifier.fillMaxSize()) {
                    Column(Modifier.fillMaxWidth().weight(splitRatio)) {
                        PaneTabStrip(
                            tabs = openTabs,
                            selectedId = leftId,
                            excludedId = rightId,
                            onSelect = { tab ->
                                replaceSplit(tab.id, tab.fileType, rightId, rightType)
                            }
                        )
                        SplitPane(
                            vm = vm,
                            noteId = leftId, fileType = leftType,
                            modifier = Modifier.fillMaxWidth().weight(1f),
                            onClose = { openInFullReader(vm, nav, rightId, rightType, routeKey) }
                        )
                    }
                    Surface(
                        color = MaterialTheme.colorScheme.outlineVariant,
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(10.dp)
                            .pointerInput(screenHeightDp, splitRatio) {
                                detectDragGestures(
                                    onDragEnd = { vm.setWorkspaceSplitRatio(splitRatio) }
                                ) { _, dragAmount ->
                                    splitRatio = (splitRatio + dragAmount.y / screenHeightDp)
                                        .coerceIn(0.25f, 0.75f)
                                }
                            }
                    ) {}
                    Column(Modifier.fillMaxWidth().weight(1f - splitRatio)) {
                        PaneTabStrip(
                            tabs = openTabs,
                            selectedId = rightId,
                            excludedId = leftId,
                            onSelect = { tab ->
                                replaceSplit(leftId, leftType, tab.id, tab.fileType)
                            }
                        )
                        SplitPane(
                            vm = vm,
                            noteId = rightId, fileType = rightType,
                            modifier = Modifier.fillMaxWidth().weight(1f),
                            onClose = { openInFullReader(vm, nav, leftId, leftType, routeKey) }
                        )
                    }
                }
            }
        }
    }
}

/** Pop the split route and route into the right standalone reader for the surviving pane. */
private fun openInFullReader(
    vm: AppViewModel, nav: NavController, id: Long, type: String, popRoute: String
) {
    when (type) {
        "pdf" -> {
            vm.openArticle(id, "", fileType = "pdf")
            nav.navigate("pdfReader/$id") {
                popUpTo(popRoute) { inclusive = true }
                launchSingleTop = true
            }
        }
        "html", "htm", "mhtml", "mht" -> {
            vm.openArticle(id, "", fileType = type)
            nav.navigate("htmlReader/$id") {
                popUpTo(popRoute) { inclusive = true }
                launchSingleTop = true
            }
        }
        "canvas" -> {
            vm.openArticle(id, "", fileType = "canvas")
            nav.navigate("canvas/$id") {
                popUpTo(popRoute) { inclusive = true }
                launchSingleTop = true
            }
        }
        else -> {
            vm.openArticle(id, "", com.tebogo.markvault.OpenSource.LINK)
            nav.navigate("reader") {
                popUpTo(popRoute) { inclusive = true }
                launchSingleTop = true
            }
        }
    }
}

/** Dispatch to the right pane variant based on the file's type. */
@Composable
private fun SplitPane(
    vm: AppViewModel,
    noteId: Long,
    fileType: String,
    modifier: Modifier = Modifier,
    onClose: () -> Unit
) {
    when (fileType.lowercase()) {
        "pdf" -> SplitPdfPane(vm, noteId, modifier, onClose)
        "html", "htm", "mhtml", "mht" -> SplitHtmlPane(vm, noteId, modifier, onClose)
        "canvas" -> SplitCanvasPane(vm, noteId, modifier, onClose)
        else -> SplitMarkdownPane(vm, noteId, modifier, onClose)
    }
}

@Composable
private fun PaneTabStrip(
    tabs: List<com.tebogo.markvault.TabInfo>,
    selectedId: Long,
    excludedId: Long?,
    onSelect: (com.tebogo.markvault.TabInfo) -> Unit
) {
    Row(
        Modifier.fillMaxWidth().horizontalScroll(rememberScrollState())
            .padding(horizontal = 4.dp, vertical = 3.dp),
        horizontalArrangement = androidx.compose.foundation.layout.Arrangement.spacedBy(4.dp)
    ) {
        tabs.filter { it.id == selectedId || it.id != excludedId }.forEach { tab ->
            FilterChip(
                selected = tab.id == selectedId,
                onClick = { onSelect(tab) },
                label = {
                    Text(
                        tab.title.ifBlank { "Untitled" },
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis,
                        fontSize = 11.sp
                    )
                }
            )
        }
    }
}

@Composable
private fun SplitCanvasPane(
    vm: AppViewModel,
    noteId: Long,
    modifier: Modifier,
    onClose: () -> Unit
) {
    var note by remember(noteId) { mutableStateOf<Note?>(null) }
    var labels by remember(noteId) { mutableStateOf<List<String>>(emptyList()) }
    LaunchedEffect(noteId) {
        note = vm.noteById(noteId)
        labels = runCatching {
            val root = org.json.JSONObject(note?.content.orEmpty())
            val arr = root.optJSONArray("nodes") ?: return@runCatching emptyList()
            buildList {
                for (i in 0 until arr.length()) {
                    val o = arr.optJSONObject(i) ?: continue
                    val text = o.optString("text").lineSequence().firstOrNull().orEmpty()
                    val file = o.optString("file")
                    val link = o.optString("url").ifBlank { o.optString("link") }
                    val label = when {
                        text.isNotBlank() -> text.take(140)
                        file.isNotBlank() -> file
                        link.isNotBlank() -> link
                        else -> o.optString("type", "node")
                    }
                    add(label)
                }
            }
        }.getOrElse { emptyList() }
    }
    Column(modifier.background(MaterialTheme.colorScheme.background)) {
        Row(
            Modifier.fillMaxWidth().padding(horizontal = 8.dp, vertical = 4.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                note?.title ?: "Canvas",
                Modifier.weight(1f),
                fontWeight = FontWeight.SemiBold,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )
            IconButton(onClick = onClose, modifier = Modifier.size(32.dp)) {
                Icon(Icons.Default.Close, contentDescription = "Close pane")
            }
        }
        LazyColumn(Modifier.fillMaxSize().padding(horizontal = 8.dp)) {
            items(labels) { label ->
                Surface(
                    color = MaterialTheme.colorScheme.surfaceVariant,
                    shape = androidx.compose.foundation.shape.RoundedCornerShape(8.dp),
                    modifier = Modifier.fillMaxWidth().padding(vertical = 3.dp)
                ) {
                    Text(label, Modifier.padding(10.dp), fontSize = 12.sp, maxLines = 3)
                }
            }
        }
    }
}

/** Markdown pane — same WebView + render.js pipeline used in the standalone reader. */
@Composable
private fun SplitMarkdownPane(
    vm: AppViewModel,
    noteId: Long,
    modifier: Modifier,
    onClose: () -> Unit
) {
    val ctx = LocalContext.current
    val theme by vm.theme.collectAsStateWithLifecycle()
    val fontScale by vm.fontScale.collectAsStateWithLifecycle()
    val smartStylingAllDocs by vm.smartStylingAllDocs.collectAsStateWithLifecycle()
    val textContrast by vm.textContrast.collectAsStateWithLifecycle()

    var note by remember(noteId) { mutableStateOf<Note?>(null) }
    var loading by remember(noteId) { mutableStateOf(true) }
    var pageReady by remember(noteId) { mutableStateOf(false) }
    var webView by remember(noteId) { mutableStateOf<WebView?>(null) }

    LaunchedEffect(noteId) {
        loading = true
        note = vm.loadNote(noteId)
        loading = false
    }

    LaunchedEffect(pageReady, note?.id, theme, fontScale, textContrast) {
        val wv = webView ?: return@LaunchedEffect
        val n = note ?: return@LaunchedEffect
        if (!pageReady) return@LaunchedEffect
        val smartAll = if (smartStylingAllDocs) "true" else "false"
        // v4.18.0 — pre-render markdown via flexmark (see ReaderScreen for
        // rationale). JS `renderMarkdown` now consumes HTML.
        val html = com.tebogo.markvault.markdown.MarkdownEngine.render(n.content) { target ->
            vm.resolveEmbedContent(target)
        }
        wv.evaluateJavascript(
            "renderMarkdown(${jsString(html)}, $fontScale, ${jsString(theme)}, $smartAll, $textContrast);",
            null
        )
    }

    PaneFrame(
        title = note?.title,
        loading = loading,
        notFound = note == null && !loading,
        onClose = onClose,
        modifier = modifier
    ) {
        val bg = MaterialTheme.colorScheme.background.toArgb()
        AndroidView(
            modifier = Modifier.fillMaxSize(),
            factory = { c ->
                WebView(c).apply {
                    settings.javaScriptEnabled = true
                    settings.domStorageEnabled = true
                    settings.allowFileAccessFromFileURLs = false
                    settings.allowUniversalAccessFromFileURLs = false
                    setBackgroundColor(bg)
                    webViewClient = object : WebViewClient() {
                        override fun onPageFinished(view: WebView?, url: String?) {
                            pageReady = true
                        }
                    }
                    loadUrl("file:///android_asset/viewer.html")
                    webView = this
                }
            }
        )
    }
}

/** HTML/MHTML pane — uses the same MhtmlParser + WebView path as HtmlReaderScreen. */
@Composable
private fun SplitHtmlPane(
    vm: AppViewModel,
    noteId: Long,
    modifier: Modifier,
    onClose: () -> Unit
) {
    val ctx = LocalContext.current
    var note by remember(noteId) { mutableStateOf<Note?>(null) }
    var html by remember(noteId) { mutableStateOf<String?>(null) }
    var baseUrl by remember(noteId) { mutableStateOf<String?>(null) }
    var loading by remember(noteId) { mutableStateOf(true) }
    var loaded by remember(noteId) { mutableStateOf(false) }

    LaunchedEffect(noteId) {
        loading = true
        val n = withContext(Dispatchers.IO) { vm.loadNote(noteId) }
        note = n
        if (n == null) { loading = false; return@LaunchedEffect }
        val bytes = withContext(Dispatchers.IO) {
            runCatching {
                ctx.contentResolver.openInputStream(Uri.parse(n.uri))?.use { it.readBytes() }
            }.getOrNull()
        }
        if (bytes != null) {
            val nameLower = n.name.lowercase()
            val isMhtml = nameLower.endsWith(".mhtml") || nameLower.endsWith(".mht")
            if (isMhtml) {
                html = withContext(Dispatchers.IO) { MhtmlParser.extractHtmlContent(bytes) }
                baseUrl = withContext(Dispatchers.IO) { MhtmlParser.extractBaseUrl(bytes) }
            } else {
                html = try { String(bytes, Charsets.UTF_8) } catch (_: Exception) { String(bytes) }
            }
        }
        loading = false
    }

    PaneFrame(
        title = note?.title,
        loading = loading,
        notFound = note == null && !loading,
        onClose = onClose,
        modifier = modifier
    ) {
        if (html != null) {
            AndroidView(
                modifier = Modifier.fillMaxSize(),
                factory = { c ->
                    WebView(c).apply {
                        settings.javaScriptEnabled = true
                        settings.domStorageEnabled = true
                        settings.useWideViewPort = true
                        settings.loadWithOverviewMode = true
                        settings.mixedContentMode = WebSettings.MIXED_CONTENT_COMPATIBILITY_MODE
                        webViewClient = WebViewClient()
                    }
                },
                update = { w ->
                    if (!loaded) {
                        runCatching {
                            w.loadDataWithBaseURL(
                                baseUrl ?: "about:blank",
                                html ?: "",
                                "text/html", "utf-8", null
                            )
                        }
                        loaded = true
                    }
                }
            )
        }
    }
}

/** PDF pane — minimal LazyColumn of rendered page bitmaps via PdfRenderer. */
@Composable
private fun SplitPdfPane(
    vm: AppViewModel,
    noteId: Long,
    modifier: Modifier,
    onClose: () -> Unit
) {
    val ctx = LocalContext.current
    var note by remember(noteId) { mutableStateOf<Note?>(null) }
    var pageCount by remember(noteId) { mutableStateOf(0) }
    var renderer by remember(noteId) {
        mutableStateOf<android.graphics.pdf.PdfRenderer?>(null)
    }
    var loading by remember(noteId) { mutableStateOf(true) }

    LaunchedEffect(noteId) {
        loading = true
        val n = withContext(Dispatchers.IO) { vm.loadNote(noteId) }
        note = n
        if (n != null) {
            withContext(Dispatchers.IO) {
                runCatching {
                    val pfd = ctx.contentResolver.openFileDescriptor(Uri.parse(n.uri), "r")
                    if (pfd != null) {
                        val r = android.graphics.pdf.PdfRenderer(pfd)
                        renderer = r
                        pageCount = r.pageCount
                    }
                }
            }
        }
        loading = false
    }

    val listState = rememberLazyListState()

    PaneFrame(
        title = note?.title,
        loading = loading,
        notFound = note == null && !loading,
        onClose = onClose,
        modifier = modifier
    ) {
        if (renderer != null && pageCount > 0) {
            LazyColumn(
                modifier = Modifier.fillMaxSize().background(MaterialTheme.colorScheme.surface),
                state = listState
            ) {
                items(pageCount) { idx ->
                    SplitPdfPage(renderer!!, idx)
                }
            }
        } else if (!loading) {
            Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                Text(
                    "Could not open PDF.",
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
        }
    }
}

@Composable
private fun SplitPdfPage(
    renderer: android.graphics.pdf.PdfRenderer,
    pageIndex: Int
) {
    var bmp by remember(pageIndex) {
        mutableStateOf<android.graphics.Bitmap?>(null)
    }
    LaunchedEffect(pageIndex) {
        runCatching {
            withContext(Dispatchers.IO) {
                synchronized(renderer) {
                    val page = renderer.openPage(pageIndex)
                    val w = 1080
                    val h = (1080.0 * page.height / page.width).toInt()
                    val b = android.graphics.Bitmap.createBitmap(
                        w, h, android.graphics.Bitmap.Config.ARGB_8888
                    )
                    page.render(b, null, null,
                        android.graphics.pdf.PdfRenderer.Page.RENDER_MODE_FOR_DISPLAY)
                    page.close()
                    bmp = b
                }
            }
        }
    }
    val b = bmp
    if (b != null) {
        Image(
            bitmap = b.asImageBitmap(),
            contentDescription = "Page ${pageIndex + 1}",
            modifier = Modifier.fillMaxWidth().padding(vertical = 2.dp)
        )
    } else {
        Box(Modifier.fillMaxWidth().height(400.dp), contentAlignment = Alignment.Center) {
            Text("Rendering…", color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
    }
}

/** Common pane chrome — header + content area. */
@Composable
private fun PaneFrame(
    title: String?,
    loading: Boolean,
    notFound: Boolean,
    onClose: () -> Unit,
    modifier: Modifier = Modifier,
    content: @Composable () -> Unit
) {
    Column(modifier) {
        Surface(color = MaterialTheme.colorScheme.surfaceVariant) {
            Row(
                Modifier.fillMaxWidth().padding(start = 12.dp, end = 4.dp, top = 4.dp, bottom = 4.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    title ?: "Loading…",
                    Modifier.weight(1f),
                    fontSize = 13.sp,
                    fontWeight = FontWeight.SemiBold,
                    maxLines = 1, overflow = TextOverflow.Ellipsis
                )
                IconButton(onClick = onClose) {
                    Icon(Icons.Default.Close, contentDescription = "Close pane")
                }
            }
        }
        Box(Modifier.fillMaxSize()) {
            when {
                loading -> Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                    Text("Loading…", color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
                notFound -> Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                    Text("Not found.", color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
                else -> content()
            }
        }
    }
}

private fun jsString(s: String?): String {
    if (s == null) return "''"
    val esc = s.replace("\\", "\\\\").replace("'", "\\'")
        .replace("\n", "\\n").replace("\r", "")
    return "'$esc'"
}

/**
 * Picker dialog the Markdown Reader uses when the user taps "Open in split view".
 * Lists every OTHER markdown tab and routes the user into the dual-pane reader
 * with both panes set to `md/md`.
 *
 * Kept in this file (rather than ReaderScreen.kt) because all split-related UI
 * already lives here, so the import surface stays tidy.
 */
@Composable
fun SplitViewPickerDialog(
    currentId: Long,
    tabs: List<com.tebogo.markvault.TabInfo>,
    onDismiss: () -> Unit,
    onPick: (Long) -> Unit
) {
    val partners = tabs.filter { it.id != currentId && it.fileType == "md" }
    androidx.compose.material3.AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Open in split view with…") },
        text = {
            if (partners.isEmpty()) {
                Text(
                    "Open another markdown note first, then come back here to pair them.",
                    fontSize = 13.sp
                )
            } else {
                Column {
                    partners.forEach { p ->
                        androidx.compose.material3.TextButton(
                            onClick = { onPick(p.id) },
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Text(
                                p.title.ifBlank { "Untitled" },
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis
                            )
                        }
                    }
                }
            }
        },
        confirmButton = {
            androidx.compose.material3.TextButton(onClick = onDismiss) { Text("Cancel") }
        }
    )
}
