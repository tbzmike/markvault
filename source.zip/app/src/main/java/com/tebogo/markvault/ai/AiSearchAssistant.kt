package com.tebogo.markvault.ai

/**
 * v5.4.55 Optional AI search layer. It never replaces the search engine.
 * It only prepares complex queries when the user enables AI Search.
 */
object AiSearchAssistant {
    fun shouldEnhance(query: String): Boolean {
        val q = query.trim().lowercase()
        if (q.length < 18) return false
        return listOf("why", "how", "explain", "difference", "meaning", "reason", "does", "should")
            .any { q.startsWith(it) || q.contains(" $it ") }
    }

    fun expand(query: String): List<String> {
        if (!shouldEnhance(query)) return listOf(query)
        return listOf(query, query.replace("why", "reason"), query.replace("how", "way"))
            .distinct()
    }
}
