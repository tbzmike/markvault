package com.tebogo.markvault.ai

/**
 * v5.4.59 — Real on-device-LLM query expansion.
 *
 * Before this version, [expand] never touched the LLM at all — it just
 * did a hardcoded "why"→"reason" / "how"→"way" string swap, gated behind
 * a narrow `shouldEnhance` check. That's why toggling "AI Search" on/off
 * looked identical: for the vast majority of queries `shouldEnhance`
 * returned false and the "AI" path returned the exact same string as the
 * plain path.
 *
 * This object is now a *pure* prompt-builder / output-parser. It holds no
 * reference to the LLM itself — [com.tebogo.markvault.AppViewModel] owns
 * the model lifecycle (load/unload, ChatModelCatalog selection) and calls
 * [com.tebogo.markvault.llm.LlmManager.generate] directly, then hands the
 * raw model output back here to be turned into a safe, bounded query
 * string. Keeping this side-effect-free makes it trivial to unit test.
 */
object AiSearchAssistant {

    /** Below this length there isn't enough signal for the LLM to add value. */
    private const val MIN_QUERY_LENGTH = 3

    /** Hard cap on how much generated text we'll ever append to a query. */
    private const val MAX_APPENDED_CHARS = 300

    fun isWorthExpanding(query: String): Boolean = query.trim().length >= MIN_QUERY_LENGTH

    /**
     * Builds the prompt sent to the on-device model (Qwen 3 0.6B or
     * SmolLM2 135M/360M, whichever is active). Deliberately asks for
     * keywords/synonyms only — not a rewritten sentence — because that's
     * what both models can reliably produce in under a second or two on
     * a short generation budget, and it's directly usable by the FTS +
     * semantic search backend.
     */
    fun buildExpansionPrompt(rawQuery: String): String = buildString {
        append("You are a search-query assistant for a Bible research library ")
        append("about topics such as scripture, theology, manuscripts, and ")
        append("Jehovah's Witness doctrine.\n")
        append("Given the user's question, output 4-8 additional search ")
        append("keywords or synonyms — related names, doctrinal terms, or ")
        append("concepts — that would help find relevant articles.\n")
        append("Output ONLY the keywords, separated by single spaces. ")
        append("No sentences, no numbering, no punctuation, no explanations.\n\n")
        append("QUESTION: ").append(rawQuery).append("\n")
        append("KEYWORDS:")
    }

    /**
     * Turns raw model output into a bounded, sanitised string that gets
     * appended to the original query (the original terms are always kept
     * so a bad/empty generation never loses the user's actual words).
     *
     * Returns `null` if the model output wasn't usable (empty, too long,
     * looks like it echoed the prompt, etc.) — caller should fall back to
     * the raw query alone in that case.
     */
    fun parseExpansion(modelOutput: String): String? {
        val cleaned = modelOutput
            .replace("\n", " ")
            .replace(Regex("[\"'`]"), "")
            .replace(Regex("KEYWORDS:|QUESTION:", RegexOption.IGNORE_CASE), "")
            .trim()
            .replace(Regex("\\s{2,}"), " ")

        if (cleaned.length < 2) return null
        if (cleaned.length > MAX_APPENDED_CHARS) return cleaned.take(MAX_APPENDED_CHARS)
        return cleaned
    }
}
