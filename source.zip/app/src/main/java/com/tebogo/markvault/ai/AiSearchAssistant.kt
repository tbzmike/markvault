package com.tebogo.markvault.ai

/**
 * Optional AI Search enhancement layer.
 * It never replaces MarkVault search. It only improves complex queries.
 */
object AiSearchAssistant {

    data class Enhancement(
        val query: String,
        val used: Boolean,
        val reason: String
    )

    fun shouldEnhance(query: String): Boolean {
        val q = query.trim().lowercase()
        if (q.length < 18) return false
        return listOf("why", "how", "explain", "difference", "meaning", "reason", "does", "should")
            .any { q.startsWith(it) || q.contains(" $it ") }
    }

    fun enhance(query: String): Enhancement {
        if (!shouldEnhance(query)) {
            return Enhancement(query, false, "")
        }

        val expanded = expand(query).joinToString(" ")
        return Enhancement(
            expanded,
            true,
            "AI query understanding expanded the search with related concepts"
        )
    }

    fun expand(query: String): List<String> {
        val q = query.trim()
        if (!shouldEnhance(q)) return listOf(q)

        val additions = mutableListOf<String>()
        val lower = q.lowercase()

        if ("soul" in lower) additions += "life death resurrection condition of the dead"
        if ("immortal" in lower) additions += "everlasting life immortality resurrection"
        if ("god" in lower || "jehovah" in lower) additions += "creator bible scriptures"
        if ("jesus" in lower || "christ" in lower) additions += "messiah son of god"

        additions += when {
            lower.startsWith("why") -> "reason explanation biblical teaching"
            lower.startsWith("how") -> "method explanation bible teaching"
            else -> "related concepts"
        }

        return (listOf(q) + additions).distinct()
    }
}
