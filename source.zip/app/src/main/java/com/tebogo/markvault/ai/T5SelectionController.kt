package com.tebogo.markvault.ai

/** Controls selecting T5 expansion only when the model is ready. */
object T5SelectionController {
    private var selected = false

    fun select(enabled: Boolean): Boolean {
        selected = enabled && T5SettingsAvailability.canEnable()
        return selected
    }

    fun isSelected(): Boolean = selected
}
