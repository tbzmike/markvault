package com.tebogo.markvault.search

import android.content.Context
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.isActive
import kotlinx.coroutines.withContext
import java.io.BufferedInputStream
import java.io.BufferedOutputStream
import java.io.DataInputStream
import java.io.DataOutputStream
import java.io.File
import java.io.FileInputStream
import java.io.FileOutputStream
import kotlin.coroutines.coroutineContext
import kotlin.math.sqrt

/**
 * v5.5.0 — IVF-Flat Approximate Nearest Neighbor index for semantic search.
 *
 * # Problem
 *
 * The brute-force vector scan in [semanticSearchInner] reads EVERY embedding
 * BLOB from SQLite, deserializes each one, and computes a dot product against
 * the query vector. For a 42k-note library with ~3 chunks each (~126k
 * vectors), that's hundreds of megabytes of I/O per query and 3–5 seconds
 * of wall-clock time — which forced the scope-partitioning workaround, the
 * 160-note streaming pages, and aggressive GC cycles.
 *
 * # Solution: Inverted File Index (IVF-Flat)
 *
 * Standard two-phase retrieval technique used by FAISS, ScaNN, and every
 * production vector database:
 *
 *   **Build (once, after embedding):**
 *     1. Sample vectors from the DB and run k-means to find cluster centroids.
 *     2. Stream all vectors and assign each chunk to its nearest centroid.
 *     3. Write a lightweight index file: centroids + per-cluster note ID lists.
 *
 *   **Search (every query):**
 *     1. Compare the query vector to each centroid (~300 dot products).
 *     2. Pick the [nprobe] nearest centroids.
 *     3. Collect note IDs from those clusters (~7% of the library).
 *     4. Load and score ONLY those embeddings from the DB.
 *
 * Result: same recall path as the existing [semanticRerankCandidates] but
 * with ~7% of the I/O. Typical query drops from 3–5 seconds to <500ms.
 *
 * # What's in the index file (~2–3 MB)
 *
 * Only centroids and cluster-membership lists. Vectors stay in the DB — no
 * data duplication. The file is small enough to rebuild in 1–2 minutes and
 * safe to delete at any time (search falls back to brute force).
 *
 * # Accuracy
 *
 * ANN recall depends on the library and embedding distribution; there is no
 * honest fixed recall percentage that can be guaranteed for every vault.
 * v5.5.12 therefore uses an accuracy-first adaptive probe count (roughly 12%
 * of clusters, bounded for latency) instead of relying on the older fixed
 * 24-cluster assumption. The user can still disable ANN for an exact scan.
 */
class AnnIndex(private val context: Context) {

    companion object {
        private const val FILE_VERSION = 1
        /** Below this many chunks, the brute-force scan is already fast. */
        private const val MIN_VECTORS_FOR_INDEX = 500
        private const val MIN_CLUSTERS = 32
        private const val MAX_CLUSTERS = 512
        /** Vectors sampled for k-means centroid learning. */
        private const val KMEANS_SAMPLE_SIZE = 8000
        /** Lloyd's algorithm iterations. 25 is standard; convergence is
         *  usually reached well before this on real embedding distributions. */
        private const val KMEANS_ITERATIONS = 25
        /** Legacy/fallback probe count. v5.5.12 search uses [recommendedAccuracyNprobe]. */
        const val DEFAULT_NPROBE = 24
        /** Accuracy-first probe policy: widen IVF coverage without approaching a full scan. */
        private const val ACCURACY_PROBE_FRACTION = 0.12
        private const val ACCURACY_MIN_NPROBE = 40
        private const val ACCURACY_MAX_NPROBE = 64
        /** Embeddings loaded per DB page during the build pass. */
        private const val BUILD_PAGE_SIZE = 300

        private const val TAG = "AnnIndex"

        /** Shared across AnnIndex instances (ViewModel + foreground service). */
        private val FILE_REPLACE_LOCKS = java.util.concurrent.ConcurrentHashMap<String, Any>()
    }

    /** One scored result from a search. */
    data class SearchResult(val noteId: Long, val score: Float)

    /** Header metadata, persisted in the file and cached in memory. */
    data class IndexStats(
        val modelVersion: String,
        val dim: Int,
        val numClusters: Int,
        val numVectors: Int,
        val buildTimestamp: Long,
        val embeddingCountAtBuild: Int
    )

    // ── Cached state ────────────────────────────────────────────────────

    @Volatile private var cachedStats: IndexStats? = null
    /** Cluster centroids, L2-normalised. Shape: [numClusters][dim]. */
    @Volatile private var cachedCentroids: Array<FloatArray>? = null
    /** Per-cluster list of note IDs whose chunks belong to that cluster. */
    @Volatile private var cachedClusters: Array<LongArray>? = null
    @Volatile var isBuilding: Boolean = false
        private set

    // ── File path ───────────────────────────────────────────────────────

    /**
     * Model-specific index file. Each embedding model gets its own index
     * so switching models doesn't require deleting the old one.
     */
    private fun safeModelKey(modelVersion: String): String =
        modelVersion.replace(Regex("[^a-zA-Z0-9_-]"), "_")

    private fun indexFile(modelVersion: String): File =
        File(context.filesDir, "ann_ivf_${safeModelKey(modelVersion)}.bin")

    /**
     * Replace one complete ANN file without intentionally deleting the only
     * good copy first. The previous writers did `delete(); renameTo()`, so a
     * rare rename failure could leave Fast Search with no index at all.
     * Keep a same-directory backup until the new snapshot is in place.
     */
    private fun replaceIndexFile(tmpFile: File, modelVersion: String) {
        val destFile = indexFile(modelVersion)
        val backup = File(context.filesDir, "${destFile.name}.bak")
        val lockKey = safeModelKey(modelVersion)
        val candidate = Any()
        val lock = FILE_REPLACE_LOCKS.putIfAbsent(lockKey, candidate) ?: candidate
        synchronized(lock) {
            runCatching { backup.delete() }
            val hadDest = destFile.exists()
            if (hadDest && !destFile.renameTo(backup)) {
                throw java.io.IOException("Could not stage existing ANN index for replacement")
            }
            if (!tmpFile.renameTo(destFile)) {
                if (hadDest && backup.exists()) {
                    runCatching { backup.renameTo(destFile) }
                }
                throw java.io.IOException("Failed to finalise ANN index file")
            }
            runCatching { backup.delete() }
        }
    }


    /**
     * v5.5.12 — Accuracy-first IVF probe count for the selected model.
     *
     * A fixed nprobe=24 was only ~6–8% of the clusters in a large MarkVault
     * index. That is fast, but it can drop a relevant passage before exact
     * vector scoring/reranking ever sees it. Probe ~12% of the actual cluster
     * count, never fewer than 40 on a large index and never more than 64.
     * Small indexes naturally clamp to all clusters. This keeps ANN materially
     * faster than brute force while giving candidate recall more headroom.
     */
    fun recommendedAccuracyNprobe(modelVersion: String): Int {
        val clusters = stats(modelVersion)?.numClusters ?: return DEFAULT_NPROBE
        if (clusters <= 0) return DEFAULT_NPROBE
        val proportional = kotlin.math.ceil(clusters * ACCURACY_PROBE_FRACTION).toInt()
        return maxOf(DEFAULT_NPROBE, ACCURACY_MIN_NPROBE, proportional)
            .coerceAtMost(ACCURACY_MAX_NPROBE)
            .coerceAtMost(clusters)
    }

    // ── Public API ──────────────────────────────────────────────────────

    /**
     * True when a valid index exists on disk for [modelVersion] and no
     * build is currently in progress. The caller uses this to decide
     * which search path to take — ANN or brute force.
     */
    fun isAvailable(modelVersion: String): Boolean {
        if (isBuilding) return false
        val f = indexFile(modelVersion)
        return f.exists() && f.length() > 1000
    }

    /** Cached stats from the last [loadIndex] or [build]. Null if not loaded. */
    fun stats(): IndexStats? = cachedStats

    /**
     * v5.5.8 — Read stats for one specific embedding model without loading
     * the centroids/cluster directory into memory.  The old no-argument
     * [stats] accessor could expose the PREVIOUS model's cached stats after
     * the user switched embedding models, which made the Settings card look
     * as though the wrong ANN index belonged to the newly selected model.
     */
    fun stats(modelVersion: String): IndexStats? {
        cachedStats?.takeIf { it.modelVersion == modelVersion }?.let { return it }
        val file = indexFile(modelVersion)
        if (!file.exists() || file.length() < 1000) return null
        return runCatching {
            DataInputStream(BufferedInputStream(FileInputStream(file), 8 * 1024)).use { inp ->
                val version = inp.readInt()
                if (version != FILE_VERSION) return@use null
                val storedModel = inp.readUTF()
                val dim = inp.readInt()
                val clusters = inp.readInt()
                val vectors = inp.readInt()
                val builtAt = inp.readLong()
                val embeddingCount = inp.readInt()
                if (storedModel != modelVersion || dim <= 0 || dim > 2048 ||
                    clusters <= 0 || clusters > MAX_CLUSTERS * 2) return@use null
                IndexStats(storedModel, dim, clusters, vectors, builtAt, embeddingCount)
            }
        }.getOrNull()
    }

    /**
     * v5.5.1 — Return the set of all noteIds currently in the index,
     * reading from the in-memory cached clusters. Returns null if the
     * index isn't loaded or the model version doesn't match. Used by
     * legacy incremental callers to cheaply identify which notes are NEW
     * (not yet indexed) without loading all embedding vectors from the DB.
     * v5.5.8's [synchronizeModel] is now the primary maintenance path.
     */
    fun indexedNoteIds(modelVersion: String): Set<Long>? {
        if (isBuilding) return null
        if (!ensureLoaded(modelVersion)) return null
        val clusters = cachedClusters ?: return null
        val stats = cachedStats ?: return null
        if (stats.modelVersion != modelVersion) return null
        val ids = HashSet<Long>(stats.numVectors)
        for (cluster in clusters) {
            for (id in cluster) ids.add(id)
        }
        return ids
    }

    /**
     * True when the index exists but may be stale (the embedding count
     * at build time differs from the current count). The caller can
     * display "index outdated — rebuild?" in Settings.
     */
    fun isStale(modelVersion: String, currentEmbeddingCount: Int): Boolean {
        val s = stats(modelVersion) ?: return false
        return s.embeddingCountAtBuild != currentEmbeddingCount
    }

    /** Delete the index file and clear cached state. */
    fun delete(modelVersion: String) {
        cachedStats = null
        cachedCentroids = null
        cachedClusters = null
        runCatching { indexFile(modelVersion).delete() }
    }

    /** Release cached data from memory. Safe to call at any time. */
    fun unload() {
        cachedStats = null
        cachedCentroids = null
        cachedClusters = null
    }

    // ── Incremental update ──────────────────────────────────────────────

    /**
     * v5.5.0 — Add newly-embedded notes to the existing index without
     * rebuilding from scratch.
     *
     * For each vector, finds the nearest existing centroid and appends
     * the noteId to that cluster's membership list. The centroids
     * themselves are NOT recalculated — they stay fixed until the next
     * full rebuild. This is fine for routine additions; the cluster
     * structure only needs refreshing if the library's overall topic
     * distribution shifts dramatically.
     *
     * Runs in milliseconds per note. Called automatically after the
     * embedding service finishes a pass.
     *
     * @param vectors  List of (noteId, vectorBytes) for the new notes.
     *                 Multiple chunks per noteId is fine — each chunk is
     *                 assigned independently, and the noteId is added to
     *                 whichever cluster the chunk lands in.
     * @param modelVersion  Must match the loaded index's model version.
     * @return  Number of new noteIds added (0 if the index isn't loaded
     *          or the model doesn't match).
     */
    suspend fun addNotes(
        vectors: List<Pair<Long, ByteArray>>,
        modelVersion: String
    ): Int = withContext(Dispatchers.IO) {
        if (isBuilding) return@withContext 0
        if (!ensureLoaded(modelVersion)) return@withContext 0

        val centroids = cachedCentroids ?: return@withContext 0
        val clusters = cachedClusters ?: return@withContext 0
        val stats = cachedStats ?: return@withContext 0
        if (stats.modelVersion != modelVersion) return@withContext 0

        // Collect all noteIds already in the index for dedup.
        val existing = HashSet<Long>()
        for (cluster in clusters) {
            for (id in cluster) existing.add(id)
        }

        // Assign each new vector to the nearest centroid.
        // Track which clusters gained new members.
        val newMemberships = HashMap<Int, MutableSet<Long>>() // clusterId → new noteIds
        var addedCount = 0
        for ((noteId, vecBytes) in vectors) {
            if (noteId in existing) continue  // already indexed
            val vec = bytesToFloatArray(vecBytes)
            if (vec.size != stats.dim) continue
            val cluster = nearestCentroid(vec, centroids)
            newMemberships.getOrPut(cluster) { mutableSetOf() }.add(noteId)
        }

        // Update cached clusters in place.
        for ((clusterId, newIds) in newMemberships) {
            val oldArray = clusters[clusterId]
            val merged = HashSet<Long>(oldArray.size + newIds.size)
            for (id in oldArray) merged.add(id)
            for (id in newIds) { if (merged.add(id)) addedCount++ }
            clusters[clusterId] = merged.toLongArray()
        }

        if (addedCount > 0) {
            // Update stats to reflect the new count.
            val newStats = stats.copy(
                numVectors = stats.numVectors + addedCount,
                embeddingCountAtBuild = stats.embeddingCountAtBuild + addedCount,
                // v5.5.12 — This field now represents the last successful
                // persisted ANN synchronization, not only the first full build.
                buildTimestamp = System.currentTimeMillis()
            )
            cachedStats = newStats

            // Persist — rewrite the index file with the updated clusters.
            val clusterSets = Array(clusters.size) { c ->
                val set = HashSet<Long>()
                for (id in clusters[c]) set.add(id)
                set
            }
            runCatching {
                val tmpFile = File(context.filesDir, "ann_ivf_incremental_${safeModelKey(modelVersion)}.tmp")
                runCatching { tmpFile.delete() }
                writeIndexFile(tmpFile, newStats, centroids, clusterSets)
                replaceIndexFile(tmpFile, modelVersion)
            }.onFailure {
                android.util.Log.e(TAG, "Failed to persist incremental ANN update", it)
            }
        }

        addedCount
    }

    /**
     * v5.5.8 — Reconcile one model-specific ANN index with the embeddings
     * currently stored in Room.
     *
     * This is intentionally stronger than the old [addNotes] path:
     *  - NEW notes are added.
     *  - UPDATED notes are removed from their old cluster memberships and
     *    re-assigned from their freshly-generated chunk vectors.
     *  - note IDs that no longer have embeddings are pruned.
     *  - [IndexStats.embeddingCountAtBuild] is advanced to the exact current
     *    embedding-row count, so an automatically-maintained index does not
     *    remain falsely marked stale.
     *
     * The database is streamed page-by-page.  We retain only note IDs plus
     * the lightweight ANN membership sets; vector BLOBs never accumulate for
     * the whole library, preserving the v5.5.1 memory-safety fix.
     *
     * @param dirtyNoteIds notes whose embeddings were regenerated in the
     * current pass. They must be re-clustered even when their noteId already
     * exists in the ANN index.
     * @param forceFreshnessWrite persist a new synchronization watermark even
     * when counts and memberships are already equal. This repairs older indexes
     * whose file timestamp predates the newest same-count embedding replacement.
     */
    data class SyncResult(
        val updatedNotes: Int,
        val removedNotes: Int,
        val embeddingCount: Int
    )

    suspend fun synchronizeModel(
        loadPage: suspend (limit: Int, offset: Int) -> List<Pair<Long, ByteArray>>,
        modelVersion: String,
        dirtyNoteIds: Set<Long> = emptySet(),
        forceFreshnessWrite: Boolean = false,
        pageSize: Int = BUILD_PAGE_SIZE
    ): SyncResult = withContext(Dispatchers.IO) {
        if (isBuilding || !ensureLoaded(modelVersion)) {
            return@withContext SyncResult(0, 0, 0)
        }

        val centroids = cachedCentroids ?: return@withContext SyncResult(0, 0, 0)
        val clusters = cachedClusters ?: return@withContext SyncResult(0, 0, 0)
        val stats = cachedStats ?: return@withContext SyncResult(0, 0, 0)
        if (stats.modelVersion != modelVersion) return@withContext SyncResult(0, 0, 0)

        // Work with sets while reconciling so a note with multiple chunks in
        // the same cluster is represented only once in that cluster.
        val clusterSets = Array(clusters.size) { c ->
            HashSet<Long>(clusters[c].size * 2 + 1).apply {
                for (id in clusters[c]) add(id)
            }
        }
        val previouslyIndexed = HashSet<Long>()
        for (set in clusterSets) previouslyIndexed.addAll(set)

        // Updated notes must not keep memberships derived from their old
        // vectors. Remove them first; their current chunks are re-added below.
        if (dirtyNoteIds.isNotEmpty()) {
            for (set in clusterSets) set.removeAll(dirtyNoteIds)
        }

        val validNoteIds = HashSet<Long>(previouslyIndexed.size + dirtyNoteIds.size + 64)
        val touched = HashSet<Long>()
        var embeddingCount = 0
        var offset = 0

        while (coroutineContext.isActive) {
            val page = loadPage(pageSize, offset)
            if (page.isEmpty()) break
            for ((noteId, vecBytes) in page) {
                embeddingCount++
                validNoteIds.add(noteId)

                // Existing clean notes keep their current memberships. New
                // or regenerated notes are assigned from the CURRENT vector.
                if (noteId !in previouslyIndexed || noteId in dirtyNoteIds) {
                    val vec = bytesToFloatArray(vecBytes)
                    if (vec.size != stats.dim) continue
                    val cluster = nearestCentroid(vec, centroids)
                    clusterSets[cluster].add(noteId)
                    touched.add(noteId)
                }
            }
            offset += pageSize
        }

        if (!coroutineContext.isActive) {
            throw kotlinx.coroutines.CancellationException("ANN synchronization cancelled")
        }

        // Remove deleted/orphaned notes that can no longer be loaded from the
        // embedding table. This also repairs old stale memberships left by
        // earlier incremental-only maintenance.
        val removedIds = previouslyIndexed.filterTo(HashSet()) { it !in validNoteIds }
        if (removedIds.isNotEmpty()) {
            for (set in clusterSets) set.removeAll(removedIds)
        }

        val metadataChanged = stats.numVectors != embeddingCount ||
            stats.embeddingCountAtBuild != embeddingCount
        val membershipChanged = touched.isNotEmpty() || removedIds.isNotEmpty() ||
            dirtyNoteIds.any { it in previouslyIndexed }

        // A timestamp-only freshness repair is still a real synchronization.
        // This happens when an edited article was re-embedded into the same
        // number of chunks and the ANN memberships already happen to be valid,
        // or when an older build never advanced the persisted watermark.
        // Persist a fresh header so search does not fall back to exact mode on
        // every request forever.
        if (membershipChanged || metadataChanged || forceFreshnessWrite) {
            val newStats = stats.copy(
                numVectors = embeddingCount,
                embeddingCountAtBuild = embeddingCount,
                // v5.5.12 — Advance the persisted freshness watermark even
                // when the row count did not change (edited article with the
                // same chunk count). Search compares this against MAX(createdAt).
                buildTimestamp = System.currentTimeMillis()
            )
            val tmpFile = File(
                context.filesDir,
                "ann_ivf_sync_${safeModelKey(modelVersion)}.tmp"
            )
            runCatching { tmpFile.delete() }
            writeIndexFile(tmpFile, newStats, centroids, clusterSets)

            replaceIndexFile(tmpFile, modelVersion)

            cachedStats = newStats
            cachedClusters = Array(clusterSets.size) { c -> clusterSets[c].toLongArray() }
            // Centroids are unchanged; keep the already-loaded array.
            cachedCentroids = centroids
        }

        SyncResult(
            updatedNotes = touched.size,
            removedNotes = removedIds.size,
            embeddingCount = embeddingCount
        )
    }

    // ── Build ───────────────────────────────────────────────────────────

    /**
     * Build the IVF index from existing embeddings in the database.
     *
     * Call from a background coroutine (the ViewModel can wrap it in
     * [startProtectedTask] for wake-lock protection). The build is
     * cancellable between pages via coroutine cancellation.
     *
     * @param loadPage  Loads one page of embedding vectors from the DB.
     *                  Parameters: (limit, offset) → list of (noteId, vector bytes).
     *                  The caller provides this so AnnIndex stays decoupled from Room.
     * @param modelVersion  Active model's version string. Stored in the file header.
     * @param dim  Embedding dimensionality (100, 384, 768, or 1024).
     * @param totalVectors  Total chunk count in the DB for this model version.
     *                      Used for progress reporting and cluster count calculation.
     * @param onProgress  0.0–1.0 fraction + stage label for UI reporting.
     */
    suspend fun build(
        loadPage: suspend (limit: Int, offset: Int) -> List<Pair<Long, ByteArray>>,
        modelVersion: String,
        dim: Int,
        totalVectors: Int,
        onProgress: (Float, String) -> Unit
    ): Result<IndexStats> = withContext(Dispatchers.IO) {
        if (totalVectors < MIN_VECTORS_FOR_INDEX) {
            return@withContext Result.failure(
                IllegalStateException(
                    "Only $totalVectors vectors — too few for an ANN index " +
                        "(minimum $MIN_VECTORS_FOR_INDEX). Brute-force search is already fast."
                )
            )
        }
        isBuilding = true
        val tmpFile = File(context.filesDir, "ann_ivf_building_${safeModelKey(modelVersion)}.tmp")
        try {
            onProgress(0f, "Sampling vectors for clustering…")

            // ── 1. Sample vectors for k-means ───────────────────────────
            val sampleSize = minOf(KMEANS_SAMPLE_SIZE, totalVectors)
            val step = if (totalVectors <= sampleSize) 1
                       else totalVectors / sampleSize
            val samples = ArrayList<FloatArray>(sampleSize)
            var sampleOffset = 0
            var globalVecIdx = 0  // counts every vector we see, not just kept ones
            while (samples.size < sampleSize) {
                if (!coroutineContext.isActive) return@withContext Result.failure(
                    kotlinx.coroutines.CancellationException("Build cancelled")
                )
                val page = loadPage(BUILD_PAGE_SIZE, sampleOffset)
                if (page.isEmpty()) break
                for ((_, vecBytes) in page) {
                    if (samples.size >= sampleSize) break
                    // Keep every `step`th vector based on the global counter.
                    if (globalVecIdx % step == 0) {
                        val vec = bytesToFloatArray(vecBytes)
                        if (vec.size == dim) samples.add(vec)
                    }
                    globalVecIdx++
                }
                sampleOffset += BUILD_PAGE_SIZE
                onProgress(
                    0.20f * (samples.size.toFloat() / sampleSize),
                    "Sampling vectors… ${samples.size}/$sampleSize"
                )
            }
            if (samples.size < MIN_CLUSTERS) {
                return@withContext Result.failure(
                    IllegalStateException("Only ${samples.size} usable vectors sampled")
                )
            }

            // ── 2. K-means clustering ───────────────────────────────────
            val numClusters = sqrt(totalVectors.toFloat()).toInt()
                .coerceIn(MIN_CLUSTERS, MAX_CLUSTERS)
            onProgress(0.20f, "Clustering into $numClusters groups…")

            val centroids = kmeansppInit(samples, numClusters, dim)
            runKmeans(samples, centroids, KMEANS_ITERATIONS) { iter ->
                if (!coroutineContext.isActive) throw kotlinx.coroutines.CancellationException("Build cancelled")
                onProgress(
                    0.20f + 0.15f * (iter.toFloat() / KMEANS_ITERATIONS),
                    "Clustering iteration ${iter + 1}/$KMEANS_ITERATIONS…"
                )
            }
            // Free the sample vectors — not needed after clustering.
            samples.clear()
            samples.trimToSize()

            // ── 3. Assign all vectors to clusters ───────────────────────
            onProgress(0.35f, "Assigning vectors to clusters…")
            // clusterMembers[c] = set of noteIds that have at least one
            // chunk assigned to cluster c.
            val clusterMembers = Array(numClusters) { HashSet<Long>() }
            var assignedCount = 0
            var assignOffset = 0
            while (true) {
                if (!coroutineContext.isActive) return@withContext Result.failure(
                    kotlinx.coroutines.CancellationException("Build cancelled")
                )
                val page = loadPage(BUILD_PAGE_SIZE, assignOffset)
                if (page.isEmpty()) break
                for ((noteId, vecBytes) in page) {
                    val vec = bytesToFloatArray(vecBytes)
                    if (vec.size != dim) continue
                    val cluster = nearestCentroid(vec, centroids)
                    clusterMembers[cluster].add(noteId)
                    assignedCount++
                }
                assignOffset += BUILD_PAGE_SIZE
                onProgress(
                    0.35f + 0.55f * (assignedCount.toFloat() / totalVectors),
                    "Assigning… $assignedCount/$totalVectors"
                )
                // Periodic memory check — same philosophy as EmbeddingService.
                val rt = Runtime.getRuntime()
                val used = rt.totalMemory() - rt.freeMemory()
                if (used >= (rt.maxMemory() * 95L) / 100L) {
                    runCatching { System.gc() }
                    kotlinx.coroutines.delay(200L)
                }
            }

            // ── 4. Write index file ─────────────────────────────────────
            onProgress(0.90f, "Writing index…")
            val stats = IndexStats(
                modelVersion = modelVersion,
                dim = dim,
                numClusters = numClusters,
                numVectors = assignedCount,
                buildTimestamp = System.currentTimeMillis(),
                embeddingCountAtBuild = totalVectors
            )
            writeIndexFile(tmpFile, stats, centroids, clusterMembers)

            // Atomic rename: readers either see the old complete file or
            // the new complete file, never a half-written one.
            try {
                replaceIndexFile(tmpFile, modelVersion)
            } catch (io: java.io.IOException) {
                return@withContext Result.failure(io)
            }

            // ── 5. Cache in memory ──────────────────────────────────────
            cachedStats = stats
            cachedCentroids = centroids
            cachedClusters = Array(numClusters) { c ->
                clusterMembers[c].toLongArray()
            }

            onProgress(1f, "Index ready — $numClusters clusters, $assignedCount vectors")
            Result.success(stats)
        } catch (t: Throwable) {
            runCatching { tmpFile.delete() }
            if (t is kotlinx.coroutines.CancellationException) {
                Result.failure(t)
            } else {
                android.util.Log.e(TAG, "ANN index build failed", t)
                Result.failure(t)
            }
        } finally {
            isBuilding = false
        }
    }

    // ── Search ──────────────────────────────────────────────────────────

    /**
     * Find candidate note IDs by probing the nearest clusters. Returns
     * null if the index isn't available (caller should fall back to brute
     * force). Returns an empty set if the index is loaded but no
     * candidates match.
     *
     * The returned set is a SUPERSET of the true top-K: it includes
     * every note that has at least one chunk in the [nprobe] nearest
     * clusters. The caller loads these notes' actual embeddings from the
     * DB, scores them, and takes the final top-K — exactly the same
     * scoring path as [semanticRerankCandidates].
     *
     * @param queryVec  The query embedding vector (L2-normalised).
     * @param modelVersion  Must match the index's model version.
     * @param nprobe  How many clusters to scan. Higher = better recall,
     *                slower. Search normally uses [recommendedAccuracyNprobe].
     */
    suspend fun findCandidates(
        queryVec: FloatArray,
        modelVersion: String,
        nprobe: Int = DEFAULT_NPROBE
    ): Set<Long>? = withContext(Dispatchers.IO) {
        if (isBuilding) return@withContext null
        if (!ensureLoaded(modelVersion)) return@withContext null

        val centroids = cachedCentroids ?: return@withContext null
        val clusters = cachedClusters ?: return@withContext null
        val stats = cachedStats ?: return@withContext null

        if (queryVec.size != stats.dim) return@withContext null

        // Score every centroid against the query. Centroids are
        // L2-normalised (spherical k-means), so dot product = cosine.
        val centroidScores = FloatArray(centroids.size)
        for (c in centroids.indices) {
            centroidScores[c] = dotProduct(queryVec, centroids[c])
        }

        // Pick the top nprobe centroids.
        val probeClusters = centroidScores.indices
            .sortedByDescending { centroidScores[it] }
            .take(nprobe.coerceIn(1, centroids.size))

        // Collect all note IDs from those clusters (deduplicated).
        val candidates = HashSet<Long>()
        for (c in probeClusters) {
            if (c < clusters.size) {
                for (noteId in clusters[c]) candidates.add(noteId)
            }
        }
        candidates
    }

    // ── Index loading ───────────────────────────────────────────────────

    /**
     * Ensure the index is loaded into memory. Idempotent — returns
     * immediately if already loaded for the right model version.
     */
    private fun ensureLoaded(modelVersion: String): Boolean {
        val stats = cachedStats
        if (stats != null && stats.modelVersion == modelVersion &&
            cachedCentroids != null && cachedClusters != null) {
            return true
        }
        // Not loaded or wrong model — try reading from disk.
        return runCatching { readIndexFile(indexFile(modelVersion)) }.getOrElse {
            android.util.Log.e(TAG, "Failed to read ANN index", it)
            false
        }
    }

    // ── K-means ─────────────────────────────────────────────────────────

    /**
     * K-means++ centroid initialisation. Picks the first centroid
     * randomly, then each subsequent centroid with probability
     * proportional to squared distance from the nearest existing
     * centroid. Produces better initial centroids than random selection
     * and converges faster.
     */
    private fun kmeansppInit(
        samples: List<FloatArray>,
        k: Int,
        dim: Int
    ): Array<FloatArray> {
        val rng = java.util.Random(42) // deterministic for reproducibility
        val centroids = Array(k) { FloatArray(dim) }

        // First centroid: random sample.
        val first = samples[rng.nextInt(samples.size)]
        System.arraycopy(first, 0, centroids[0], 0, dim)

        // Subsequent centroids: weighted by squared distance to nearest.
        val distances = FloatArray(samples.size) { Float.MAX_VALUE }
        for (c in 1 until k) {
            // Update distances with the newly added centroid.
            val prev = centroids[c - 1]
            for (i in samples.indices) {
                val d = squaredDistance(samples[i], prev)
                if (d < distances[i]) distances[i] = d
            }
            // Weighted random selection.
            var total = 0.0
            for (d in distances) total += d
            if (total <= 0.0) {
                // Degenerate case: all samples are identical.
                System.arraycopy(samples[rng.nextInt(samples.size)], 0, centroids[c], 0, dim)
                continue
            }
            var r = rng.nextDouble() * total
            var picked = samples.size - 1
            for (i in samples.indices) {
                r -= distances[i]
                if (r <= 0) { picked = i; break }
            }
            System.arraycopy(samples[picked], 0, centroids[c], 0, dim)
        }
        // L2-normalise initial centroids for spherical k-means.
        for (c in centroids) l2NormalizeInPlace(c)
        return centroids
    }

    /**
     * Lloyd's algorithm with L2-normalised centroids (spherical k-means).
     * Spherical k-means is appropriate here because all input vectors are
     * L2-normalised, so cosine similarity is the natural distance metric.
     * Normalising centroids after each mean-update keeps them on the unit
     * sphere alongside the data.
     */
    private fun runKmeans(
        samples: List<FloatArray>,
        centroids: Array<FloatArray>,
        iterations: Int,
        onIteration: (Int) -> Unit
    ) {
        val k = centroids.size
        val dim = centroids[0].size

        for (iter in 0 until iterations) {
            onIteration(iter)

            // ── Assignment + accumulation in one pass ────────────────
            val sums = Array(k) { FloatArray(dim) }
            val counts = IntArray(k)

            for (sample in samples) {
                val nearest = nearestCentroid(sample, centroids)
                counts[nearest]++
                val sum = sums[nearest]
                for (d in 0 until dim) sum[d] += sample[d]
            }

            // ── Update centroids ────────────────────────────────────
            for (c in 0 until k) {
                if (counts[c] == 0) continue // keep the old centroid
                val inv = 1f / counts[c]
                val sum = sums[c]
                val centroid = centroids[c]
                for (d in 0 until dim) centroid[d] = sum[d] * inv
                l2NormalizeInPlace(centroid)
            }
        }
    }

    /**
     * Find the cluster whose centroid has the highest dot product with
     * [vec]. For L2-normalised vectors, max dot product = max cosine
     * similarity = min Euclidean distance.
     */
    private fun nearestCentroid(vec: FloatArray, centroids: Array<FloatArray>): Int {
        var best = 0
        var bestScore = Float.NEGATIVE_INFINITY
        for (c in centroids.indices) {
            val score = dotProduct(vec, centroids[c])
            if (score > bestScore) {
                bestScore = score
                best = c
            }
        }
        return best
    }

    // ── File I/O ────────────────────────────────────────────────────────

    /**
     * Write the complete index file. Format:
     *
     *   [Header]
     *     Int    FILE_VERSION
     *     UTF    modelVersion
     *     Int    dim
     *     Int    numClusters
     *     Int    numVectors
     *     Long   buildTimestamp
     *     Int    embeddingCountAtBuild
     *
     *   [Centroids]  — numClusters × dim floats, contiguous
     *
     *   [Cluster directory]
     *     For each cluster:
     *       Int   memberCount
     *       Long[memberCount]  noteIds
     */
    private fun writeIndexFile(
        file: File,
        stats: IndexStats,
        centroids: Array<FloatArray>,
        clusterMembers: Array<HashSet<Long>>
    ) {
        DataOutputStream(BufferedOutputStream(FileOutputStream(file), 64 * 1024)).use { out ->
            // Header
            out.writeInt(FILE_VERSION)
            out.writeUTF(stats.modelVersion)
            out.writeInt(stats.dim)
            out.writeInt(stats.numClusters)
            out.writeInt(stats.numVectors)
            out.writeLong(stats.buildTimestamp)
            out.writeInt(stats.embeddingCountAtBuild)

            // Centroids
            for (centroid in centroids) {
                for (f in centroid) out.writeFloat(f)
            }

            // Cluster directory
            for (members in clusterMembers) {
                out.writeInt(members.size)
                for (noteId in members) out.writeLong(noteId)
            }
        }
    }

    /**
     * Read the index file into cached state. Returns true on success.
     */
    private fun readIndexFile(file: File): Boolean {
        if (!file.exists() || file.length() < 1000) return false

        DataInputStream(BufferedInputStream(FileInputStream(file), 64 * 1024)).use { inp ->
            // Header
            val version = inp.readInt()
            if (version != FILE_VERSION) return false
            val modelVersion = inp.readUTF()
            val dim = inp.readInt()
            val numClusters = inp.readInt()
            val numVectors = inp.readInt()
            val buildTimestamp = inp.readLong()
            val embCountAtBuild = inp.readInt()

            // Sanity checks
            if (dim <= 0 || dim > 2048) return false
            if (numClusters <= 0 || numClusters > MAX_CLUSTERS * 2) return false

            // Centroids
            val centroids = Array(numClusters) { FloatArray(dim) }
            for (c in 0 until numClusters) {
                for (d in 0 until dim) centroids[c][d] = inp.readFloat()
            }

            // Cluster directory
            val clusters = Array(numClusters) { _ ->
                val count = inp.readInt()
                LongArray(count) { inp.readLong() }
            }

            cachedStats = IndexStats(
                modelVersion, dim, numClusters, numVectors,
                buildTimestamp, embCountAtBuild
            )
            cachedCentroids = centroids
            cachedClusters = clusters
        }
        return true
    }

    // ── Vector math ─────────────────────────────────────────────────────

    private fun dotProduct(a: FloatArray, b: FloatArray): Float {
        var sum = 0f
        for (i in a.indices) sum += a[i] * b[i]
        return sum
    }

    private fun squaredDistance(a: FloatArray, b: FloatArray): Float {
        var sum = 0f
        for (i in a.indices) {
            val d = a[i] - b[i]
            sum += d * d
        }
        return sum
    }

    private fun l2NormalizeInPlace(v: FloatArray) {
        var sumSq = 0f
        for (f in v) sumSq += f * f
        val norm = sqrt(sumSq.toDouble()).toFloat()
        if (norm <= 0f) return
        val inv = 1f / norm
        for (i in v.indices) v[i] *= inv
    }
}
