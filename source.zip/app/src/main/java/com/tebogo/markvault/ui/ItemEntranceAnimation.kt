package com.tebogo.markvault.ui

import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.tween
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.remember
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.unit.dp
import kotlinx.coroutines.delay

/**
 * v5.4.166cc — Shared staggered fade+slide entrance for list items.
 *
 * This generalizes the technique already proven in SearchScreen's
 * search results (v5.4.157cc — stagger-fade on new results) into a
 * reusable modifier any other list in the app can adopt, starting with
 * HomeScreen's Favourites / New-in-library / Continue-reading sections.
 * Each item starts invisible and slightly lower, then fades + slides up
 * into place with a small per-index delay so items cascade in rather
 * than dumping onto screen at once.
 *
 * [seenKeys] must be hoisted — declared via `remember { mutableSetOf() }`
 * ONCE at the top of the screen, not per-item — so items that already
 * played their entrance don't replay it every time the list recomposes
 * (e.g. the list re-sorting when the user favourites something else).
 * Same reasoning as SearchScreen's `animatedResultIds`.
 *
 * Use a section-prefixed [itemKey] (e.g. "fav:${note.id}" vs
 * "new:${note.id}") if the same underlying item can appear in more than
 * one list on the same screen, so animating in one section doesn't
 * silently suppress the animation in another.
 *
 * Reads [UiAnim.prefs] for enabled/speed, so this respects the same
 * Settings → UI Animations toggle and speed slider as everything else —
 * including the v5.4.165cc speed-direction fix (higher = slower).
 */
@Composable
fun Modifier.staggeredEntrance(
    itemKey: String,
    index: Int,
    seenKeys: MutableSet<String>
): Modifier {
    val uiAnim = UiAnim.prefs
    val alreadySeen = remember(itemKey) { itemKey in seenKeys }
    val entranceProgress = remember(itemKey) {
        Animatable(if (alreadySeen || !uiAnim.enabled) 1f else 0f)
    }
    LaunchedEffect(itemKey, uiAnim.enabled, uiAnim.speed) {
        if (!alreadySeen && uiAnim.enabled) {
            val staggerDelayMs = (index * uiAnim.scaledDurationMs(30))
                .coerceAtMost(uiAnim.scaledDurationMs(300))
            delay(staggerDelayMs.toLong())
            entranceProgress.animateTo(
                targetValue = 1f,
                animationSpec = tween(uiAnim.scaledDurationMs(280))
            )
            seenKeys.add(itemKey)
        }
    }
    return this.graphicsLayer {
        alpha = entranceProgress.value
        translationY = (1f - entranceProgress.value) * 20.dp.toPx()
    }
}
