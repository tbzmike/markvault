package com.tebogo.markvault.render

/**
 * Markdown viewer bridge for Mermaid diagrams.
 * Provides rendered SVG content when a Mermaid block is detected.
 */
object MermaidDiagramView {

    fun renderIfNeeded(markdownBlock: String): String? {
        if (!MarkdownDiagramDetector.containsMermaid(markdownBlock)) {
            return null
        }

        val code = markdownBlock
            .replace("```mermaid", "")
            .replace("```", "")
            .trim()

        return MermaidRenderEngine.render(code)
    }
}
