package com.tebogo.markvault.ui

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.os.Build
import android.os.IBinder
import android.os.PowerManager
import androidx.core.app.NotificationCompat
import com.tebogo.markvault.AppViewModel
import com.tebogo.markvault.MainActivity
import com.tebogo.markvault.MarkVaultApp
import com.tebogo.markvault.R
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.launch

/**
 * v5.4.90cc — Foreground service for the WebViewer batch save.
 *
 * Purpose:
 *   - Persistent notification with a real progress bar (0..total),
 *     visible in the notification shade and on the lock screen, so the
 *     user can monitor the save without keeping MarkVault on-screen.
 *   - `PARTIAL_WAKE_LOCK` so the CPU keeps running with the screen off
 *     (jw.org page renders are network-bound but each save still needs
 *     the WebView JS engine + our extraction JS — none of which run
 *     while the CPU is suspended).
 *   - Elevated process priority (any foreground service in the process
 *     bumps the whole app's OOM score) so the OS doesn't kill our
 *     WebView loads when the user switches apps or opens another screen
 *     inside MarkVault.
 *
 * The service does NOT own the WebViews — those live in the composable
 * [HiddenBatchSaver] because WebView needs a UI thread with a view
 * hierarchy to fire onPageFinished reliably. Instead, the service:
 *
 *   1. Reads live progress from `AppViewModel.webSelectionSaving` via the
 *      shared reference on `MarkVaultApp.sharedVm`.
 *   2. Rebuilds and posts the notification each time progress ticks.
 *   3. Auto-stops when progress returns to (0, 0), i.e. when the batch
 *      finishes and the VM calls `finishBatchSave()`.
 *
 * Model:
 *   - `EmbeddingService` for the notification/wake-lock pattern.
 *   - `ChatModelDownloadService` for the completion notification shape.
 *
 * Notification tap opens MainActivity so the user can jump back to the
 * WebViewer (or to their library) directly from the shade.
 */
class BatchSaveService : Service() {

    private val serviceScope = CoroutineScope(SupervisorJob() + Dispatchers.Main.immediate)
    private var wakeLock: PowerManager.WakeLock? = null
    private var observeJob: Job? = null

    /** Latest snapshot from the VM — mirrored here so onDestroy can show a summary. */
    @Volatile private var lastDone: Int = 0
    @Volatile private var lastTotal: Int = 0

    override fun onCreate() {
        super.onCreate()
        createNotificationChannel()
        val pm = getSystemService(Context.POWER_SERVICE) as PowerManager
        wakeLock = pm.newWakeLock(
            PowerManager.PARTIAL_WAKE_LOCK,
            "MarkVault::BatchSaveWakeLock"
        )
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        // v5.4.109cc — Stop-action route. The notification's "Stop"
        // button relaunches the service with ACTION_STOP; we forward
        // that to vm.cancelBatchSave() and let the observer loop
        // notice the queue draining, which will stop the foreground
        // service naturally. We don't return early even in this path
        // because startForeground MUST be called before the OS gives
        // us grace to hang around and process the cancel — otherwise
        // Android throws ForegroundServiceDidNotStartInTimeException.
        val isStopAction = intent?.action == ACTION_STOP
        if (isStopAction) {
            runCatching {
                (application as? MarkVaultApp)?.sharedVm?.cancelBatchSave()
            }
        }

        // Acquire the wake lock (with a 60-min ceiling as a safety net —
        // a batch of 100 URLs at ~4 s each finishes in ~7 min, so 60 min
        // is generous). If already held, no-op.
        if (wakeLock?.isHeld != true) {
            runCatching { wakeLock?.acquire(WAKELOCK_TIMEOUT_MS) }
        }

        // Post the initial notification and enter foreground. The
        // indeterminate progress is a placeholder — the first tick from
        // the VM will replace it within milliseconds.
        startForeground(NOTIFICATION_ID, buildNotification(0, 0, false))

        // Start (or restart) the VM observer. `START_STICKY` combined
        // with a re-entrant observer means the Android runtime is welcome
        // to restart us after a low-memory kill; we'll just re-attach to
        // the same VM state.
        observeVmProgress()
        return START_STICKY
    }

    /**
     * Continuously mirror `AppViewModel.webSelectionSaving` into the
     * notification. When progress hits (0, 0) after having been non-zero,
     * treat that as "batch finished" — post a one-shot completion
     * notification and stop the service.
     */
    private fun observeVmProgress() {
        observeJob?.cancel()
        val vm = (application as? MarkVaultApp)?.sharedVm ?: run {
            // No VM (process just started, MainActivity hasn't loaded yet)
            // — nothing meaningful to display. Stop gracefully.
            stopForegroundAndSelf()
            return
        }
        observeJob = serviceScope.launch {
            var seenNonZero = false
            // v5.4.112cc — Merge two sources: the batch save progress
            // (webSelectionSaving) AND the general op-progress line
            // (opProgress, used for head expansion). Whichever is
            // active drives the notification. We collect both via a
            // combine so either updating refreshes the shade.
            kotlinx.coroutines.flow.combine(
                vm.webSelectionSaving,
                vm.opProgress
            ) { saving, op -> saving to op }.collect { (saving, op) ->
                val (done, total) = saving
                lastDone = done
                lastTotal = total
                when {
                    total > 0 -> {
                        // Batch save in flight — takes priority.
                        seenNonZero = true
                        updateNotification(done, total, complete = false)
                    }
                    op != null -> {
                        // No batch save, but an op (expansion/search)
                        // is running — show its indeterminate line.
                        seenNonZero = true
                        updateOpNotification(op)
                    }
                    seenNonZero -> {
                        // Everything went idle after real work — post
                        // the completion notification and shut down.
                        updateNotification(lastDone, lastDone.coerceAtLeast(1),
                            complete = true)
                        stopForegroundAndSelf()
                    }
                }
            }
        }
    }

    private fun stopForegroundAndSelf() {
        // Keep the completion notification visible so the user sees the
        // final count. `STOP_FOREGROUND_DETACH` (API 24+) detaches without
        // dismissing.
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N) {
            stopForeground(STOP_FOREGROUND_DETACH)
        } else {
            @Suppress("DEPRECATION") stopForeground(false)
        }
        stopSelf()
    }

    override fun onDestroy() {
        observeJob?.cancel()
        serviceScope.cancel()
        runCatching { if (wakeLock?.isHeld == true) wakeLock?.release() }
        super.onDestroy()
    }

    override fun onBind(intent: Intent?): IBinder? = null

    // ── Notification ─────────────────────────────────────────────────────

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                CHANNEL_ID,
                "Offline article saves",
                NotificationManager.IMPORTANCE_LOW
            ).apply {
                description = "Progress while batch-saving articles from the WebViewer"
                setShowBadge(false)
            }
            val nm = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
            nm.createNotificationChannel(channel)
        }
    }

    private fun buildNotification(done: Int, total: Int, complete: Boolean): Notification {
        // v5.4.110cc — Notification tap opens the live batch dashboard.
        // We route through MainActivity with an "open_dashboard" extra
        // rather than a deep link so the existing single-top launch
        // behaviour is preserved. MainActivity picks up the extra and
        // navigates once composition is up.
        val openPi = PendingIntent.getActivity(
            this, 0,
            Intent(this, MainActivity::class.java).apply {
                flags = Intent.FLAG_ACTIVITY_SINGLE_TOP or Intent.FLAG_ACTIVITY_CLEAR_TOP
                putExtra("open_dashboard", true)
            },
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        val title: String
        val text: String
        when {
            complete -> {
                title = "MarkVault — save complete"
                text = if (done == 1) "Saved 1 article to your library"
                    else "Saved $done articles to your library"
            }
            total == 0 -> {
                title = "MarkVault — preparing"
                text = "Starting batch save\u2026"
            }
            else -> {
                val pct = (done * 100 / total).coerceIn(0, 100)
                title = "MarkVault — saving articles"
                text = "$done / $total ($pct%)"
            }
        }

        val builder = NotificationCompat.Builder(this, CHANNEL_ID)
            .setSmallIcon(R.mipmap.ic_launcher)
            .setContentTitle(title)
            .setContentText(text)
            .setContentIntent(openPi)
            .setOngoing(!complete)
            .setOnlyAlertOnce(true)
            .setPriority(NotificationCompat.PRIORITY_LOW)
            .setCategory(NotificationCompat.CATEGORY_PROGRESS)

        // v5.4.109cc — "Stop" action while the save is in flight.
        // Fires ACTION_STOP back into this same service; onStartCommand
        // catches it and calls vm.cancelBatchSave(). Uses
        // FLAG_UPDATE_CURRENT so a re-post of the notification (from
        // every progress tick) keeps the same PendingIntent instance.
        if (!complete) {
            val stopPi = PendingIntent.getService(
                this, 1,
                Intent(this, BatchSaveService::class.java).apply {
                    action = ACTION_STOP
                },
                PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
            )
            builder.addAction(
                android.R.drawable.ic_menu_close_clear_cancel,
                "Stop",
                stopPi
            )
        }

        when {
            complete -> {
                // Static completion state — no progress bar.
            }
            total > 0 -> builder.setProgress(total, done, false)
            else -> builder.setProgress(0, 0, true)  // indeterminate warm-up
        }

        return builder.build()
    }

    private fun updateNotification(done: Int, total: Int, complete: Boolean) {
        val nm = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        nm.notify(NOTIFICATION_ID, buildNotification(done, total, complete))
    }

    /**
     * v5.4.112cc — Notification for a general op (head expansion,
     * search, etc.) that reports an indeterminate or counted progress
     * line rather than the batch save's done/total. Tapping still
     * opens the dashboard (which shows expansion events in its
     * timeline).
     */
    private fun updateOpNotification(op: AppViewModel.OpProgress) {
        val nm = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        val openPi = PendingIntent.getActivity(
            this, 0,
            Intent(this, MainActivity::class.java).apply {
                flags = Intent.FLAG_ACTIVITY_SINGLE_TOP or Intent.FLAG_ACTIVITY_CLEAR_TOP
                putExtra("open_dashboard", true)
            },
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        val builder = NotificationCompat.Builder(this, CHANNEL_ID)
            .setSmallIcon(R.mipmap.ic_launcher)
            .setContentTitle(op.title)
            .setContentText(op.text)
            .setContentIntent(openPi)
            .setOngoing(true)
            .setOnlyAlertOnce(true)
            .setPriority(NotificationCompat.PRIORITY_LOW)
            .setCategory(NotificationCompat.CATEGORY_PROGRESS)
        if (op.indeterminate) {
            builder.setProgress(0, 0, true)
        } else if (op.total > 0) {
            builder.setProgress(op.total, op.done, false)
        }
        nm.notify(NOTIFICATION_ID, builder.build())
    }

    companion object {
        private const val CHANNEL_ID = "markvault_batch_save"
        private const val NOTIFICATION_ID = 4820
        // 60-min ceiling. A typical batch of 6 articles finishes in ~15 s
        // with 3 parallel workers; large batches (100+) top out around 5-8
        // min. 60 min is a generous safety net.
        private const val WAKELOCK_TIMEOUT_MS = 60L * 60L * 1000L
        // v5.4.109cc — Notification "Stop" action.
        const val ACTION_STOP = "com.tebogo.markvault.action.BATCH_STOP"
    }
}
