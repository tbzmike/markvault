package com.tebogo.markvault.render

data class MermaidViewState(
    val zoom: Float = 1f,
    val offsetX: Float = 0f,
    val offsetY: Float = 0f
)
