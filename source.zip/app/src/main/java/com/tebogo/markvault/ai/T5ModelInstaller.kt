package com.tebogo.markvault.ai

/** T5 model installation flow bridge. */
object T5ModelInstaller {
    fun verifyAndLoad(filesPresent: Boolean, checksumOk: Boolean): Boolean {
        if (!filesPresent || !checksumOk) {
            T5ModelInstallStateStore.set(T5ModelInstallState.FAILED)
            return false
        }
        T5ModelInstallStateStore.set(T5ModelInstallState.LOADING)
        T5ModelInstallStateStore.set(T5ModelInstallState.READY)
        return true
    }
}
