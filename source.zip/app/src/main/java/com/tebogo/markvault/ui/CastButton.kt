package com.tebogo.markvault.ui

import androidx.compose.material3.IconButton
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.sp
import androidx.mediarouter.app.MediaRouteChooserDialog
import androidx.mediarouter.media.MediaRouteSelector
import com.google.android.gms.cast.CastMediaControlIntent
import com.google.android.gms.cast.framework.CastContext
import com.google.android.gms.cast.framework.CastState
import com.google.android.gms.cast.framework.CastStateListener

/**
 * v5.4.248cc — Pure-Compose Cast button.
 *
 * # Why this replaces MediaRouteButton + AndroidView
 *
 * The v5.4.247cc implementation wrapped [MediaRouteButton] in [AndroidView]
 * inside the TopAppBar actions slot. This caused:
 *
 *   java.lang.IllegalArgumentException: background can not be translucent: #0...
 *
 * Crash on every navigation to MediaPlayerScreen before the user could interact
 * with anything. Root cause: MediaRouteButton.init() reads
 * android.R.attr.colorBackground from the theme context during CONSTRUCTION —
 * not on tap. Compose wraps the Activity context in its own ContextThemeWrapper
 * for its rendering pipeline. The app theme (parent=android:Theme.Material.
 * NoActionBar) leaves colorBackground unset; the Compose wrapper strips
 * unexplicited attributes, so the attribute resolves to #00000000
 * (transparent) and MediaRouteButton throws before it is ever displayed.
 *
 * # How this composable works instead
 *
 * - [CastStateListener] observes the Cast SDK's device-availability + session
 *   state ([CastState]) from within Compose's lifecycle (DisposableEffect).
 * - The button is only rendered when at least one device is discoverable
 *   ([CastState.NO_DEVICES_AVAILABLE] → invisible).
 * - On tap (not connected): opens [MediaRouteChooserDialog] — an
 *   AppCompatDialog that sets its own window background and has NO
 *   colorBackground attribute check in its constructor, so no crash.
 * - On tap (connected): calls sessionManager.endCurrentSession(), which
 *   triggers onCastSessionUnavailable() in PlaybackService → transferToLocal().
 * - While connecting: taps are ignored (user can see the ⏳ icon).
 *
 * No AndroidView, no MediaRouteButton, no crash.
 */
@Composable
fun CastButton(modifier: Modifier = Modifier) {
    val ctx = LocalContext.current

    // Obtain the Cast singleton. runCatching keeps the composable alive on
    // devices / custom ROMs that ship without Google Play Services.
    val castCtx = remember(ctx) {
        runCatching { CastContext.getSharedInstance(ctx) }.getOrNull()
    }

    // Mirror the current cast state into Compose state so recomposition
    // tracks availability and connection changes automatically.
    var castState by remember { mutableIntStateOf(CastState.NO_DEVICES_AVAILABLE) }

    DisposableEffect(castCtx) {
        val cc = castCtx ?: return@DisposableEffect onDispose {}
        val listener = CastStateListener { state -> castState = state }
        cc.addCastStateListener(listener)
        // Seed with current state — without this the button stays hidden
        // until the NEXT state-change event fires.
        castState = cc.castState
        onDispose { cc.removeCastStateListener(listener) }
    }

    // Nothing to show when no Chromecast is on the local network.
    if (castState == CastState.NO_DEVICES_AVAILABLE) return

    val isCasting    = castState == CastState.CONNECTED
    val isConnecting = castState == CastState.CONNECTING

    IconButton(
        onClick = {
            when {
                isCasting -> {
                    // End the active cast session.
                    // PlaybackService.onCastSessionUnavailable()
                    // → transferToLocal() picks up from the last known position.
                    castCtx?.sessionManager?.endCurrentSession(true)
                }
                !isConnecting -> {
                    // Open the system device-picker. MediaRouteChooserDialog
                    // (AppCompatDialog) uses its own window background —
                    // no colorBackground attribute check, no crash.
                    val selector = MediaRouteSelector.Builder()
                        .addControlCategory(
                            CastMediaControlIntent.categoryForCast(CAST_APP_ID)
                        )
                        .build()
                    runCatching {
                        MediaRouteChooserDialog(ctx).also { dlg ->
                            dlg.setRouteSelector(selector)
                            dlg.show()
                        }
                    }
                }
                // isConnecting — ignore taps while handshake is in progress
            }
        },
        modifier = modifier
    ) {
        Text(
            text = when {
                isCasting    -> "\uD83D\uDCFA"  // 📺  casting to TV
                isConnecting -> "\u23F3"         // ⏳  connecting
                else         -> "\uD83D\uDCE1"  // 📡  cast available, not connected
            },
            fontSize = 16.sp
        )
    }
}

/** Receiver application ID — mirrors CastOptionsProvider.DEFAULT_APP_ID. */
private const val CAST_APP_ID = "CC1AD845"
