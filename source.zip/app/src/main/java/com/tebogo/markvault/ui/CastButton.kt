package com.tebogo.markvault.ui

import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.viewinterop.AndroidView
import androidx.mediarouter.app.MediaRouteButton
import com.google.android.gms.cast.framework.CastButtonFactory

/**
 * v5.4.261cc — Official Google Cast button.
 *
 * The previous implementation manually created a MediaRouter instance,
 * installed a callback, requested active discovery, rendered a custom dialog,
 * and called selectRoute() itself. That is the wrong discovery/control layer
 * for the Cast Application Framework (CAF): the CastContext owns MediaRouter
 * discovery and SessionManager owns the session lifecycle. Google explicitly
 * recommends wiring a MediaRouteButton through CastButtonFactory instead.
 *
 * Keeping the button as an AndroidView lets the rest of MarkVault remain
 * Compose-first while giving CAF complete ownership of:
 *   • device discovery timing
 *   • the route chooser/controller dialog
 *   • route selection
 *   • Cast session creation/resumption/termination
 *   • the connected/disconnected visual state
 *
 * MainActivity is a FragmentActivity specifically because MediaRouteButton's
 * standard dialog requires a FragmentActivity. No custom MediaRouter callback
 * or manual active scan is used here.
 */
@Composable
fun CastButton(modifier: Modifier = Modifier) {
    AndroidView(
        factory = { context ->
            MediaRouteButton(context).apply {
                contentDescription = "Cast"
                CastButtonFactory.setUpMediaRouteButton(
                    context.applicationContext,
                    this
                )
            }
        },
        modifier = modifier
    )
}
