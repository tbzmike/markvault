package com.tebogo.markvault.ui

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.IconButton
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.mediarouter.media.MediaRouteSelector
import androidx.mediarouter.media.MediaRouter
import com.google.android.gms.cast.CastMediaControlIntent
import com.google.android.gms.cast.framework.CastContext
import com.google.android.gms.cast.framework.CastState
import com.google.android.gms.cast.framework.CastStateListener

/**
 * v5.4.249cc — Pure-Compose Cast button. Rewritten because v5.4.248cc's fix
 * itself failed CI:
 *
 *   e: CastButton.kt:100:33 Cannot access 'AppCompatDialog' which is a
 *      supertype of 'MediaRouteChooserDialog'. Check your module classpath
 *      for missing or conflicting dependencies.
 *   e: CastButton.kt:101:33 Unresolved reference 'show'.
 *
 * # Root cause
 *
 * [MediaRouteChooserDialog] lives in androidx.mediarouter.**app** and
 * extends AppCompatDialog. This project has no androidx.appcompat
 * dependency anywhere — the whole app is Compose + Material3 on a bare
 * `android:Theme.Material.NoActionBar` theme — so AppCompatDialog can't be
 * resolved on the compile classpath, and neither can setRouteSelector()/
 * show(), which are inherited through that unresolvable supertype.
 *
 * # Fix — verified against the real AndroidX source, not assumption
 *
 * Fetched the actual androidx.mediarouter.media.MediaRouter.java source
 * (AOSP frameworks/support). Its import list has ZERO androidx.appcompat.*
 * references — only androidx.core, androidx.annotation, and
 * androidx.collection. RouteInfo is a plain static nested class, not an
 * AppCompat type. This is corroborated by the CI log itself: the v5.4.248cc
 * build compiled MediaRouteSelector (also in the .media package) with zero
 * errors — only the .app-package MediaRouteChooserDialog failed. Real
 * source with no AppCompat import, plus a same-package sibling class
 * already proven to compile clean in this exact project, is why this
 * rewrite uses ONLY androidx.mediarouter.**media**.* — MediaRouter,
 * RouteInfo, MediaRouteSelector, Callback — and never touches
 * androidx.mediarouter.app.* again.
 *
 * The device-picker UI is now a plain Material3 AlertDialog
 * ([CastDevicePickerDialog]) instead of MediaRouteChooserDialog. Routes are
 * discovered via MediaRouter.addCallback(..., CALLBACK_FLAG_PERFORM_ACTIVE_SCAN)
 * — the exact flag AndroidX's own javadoc specifies for this situation
 * ("should be used when the media route chooser dialog is showing to
 * confirm the presence of available routes"). Selection calls the
 * confirmed-public MediaRouter.selectRoute(route) — the same call
 * MediaRouteButton's own showDialog() path ultimately triggers internally.
 *
 * No androidx.mediarouter.app import anywhere in this file. No AppCompat
 * dependency needed. No theme-mismatch crash risk category at all.
 */
@Composable
fun CastButton(modifier: Modifier = Modifier) {
    val ctx = LocalContext.current

    // Obtain the Cast singleton. runCatching keeps the composable alive on
    // devices / custom ROMs that ship without Google Play Services.
    val castCtx = remember(ctx) {
        runCatching { CastContext.getSharedInstance(ctx) }.getOrNull()
    }

    // Mirror the current cast state into Compose state so recomposition
    // tracks availability and connection changes automatically.
    var castState by remember { mutableIntStateOf(CastState.NO_DEVICES_AVAILABLE) }

    DisposableEffect(castCtx) {
        val cc = castCtx ?: return@DisposableEffect onDispose {}
        val listener = CastStateListener { state -> castState = state }
        cc.addCastStateListener(listener)
        // Seed with current state — without this the button stays hidden
        // until the NEXT state-change event fires.
        castState = cc.castState
        onDispose { cc.removeCastStateListener(listener) }
    }

    // Nothing to show when no Chromecast is on the local network.
    if (castState == CastState.NO_DEVICES_AVAILABLE) return

    val isCasting    = castState == CastState.CONNECTED
    val isConnecting = castState == CastState.CONNECTING
    var showPicker by remember { mutableStateOf(false) }

    IconButton(
        onClick = {
            when {
                isCasting -> {
                    // End the active cast session.
                    // PlaybackService.onCastSessionUnavailable()
                    // → transferToLocal() picks up from the last known position.
                    castCtx?.sessionManager?.endCurrentSession(true)
                }
                !isConnecting -> showPicker = true
                // isConnecting — ignore taps while handshake is in progress
            }
        },
        modifier = modifier
    ) {
        Text(
            text = when {
                isCasting    -> "\uD83D\uDCFA"  // 📺  casting to TV
                isConnecting -> "\u23F3"         // ⏳  connecting
                else         -> "\uD83D\uDCE1"  // 📡  cast available, not connected
            },
            fontSize = 16.sp
        )
    }

    if (showPicker) {
        CastDevicePickerDialog(onDismiss = { showPicker = false })
    }
}

/**
 * Plain Material3 device picker — replaces MediaRouteChooserDialog.
 * Discovers routes via the core androidx.mediarouter.media.MediaRouter API
 * (verified AppCompat-free — see file doc comment) and lets the user tap
 * one to connect.
 */
@Composable
private fun CastDevicePickerDialog(onDismiss: () -> Unit) {
    val ctx = LocalContext.current
    val mediaRouter = remember { MediaRouter.getInstance(ctx) }
    val selector = remember {
        MediaRouteSelector.Builder()
            .addControlCategory(CastMediaControlIntent.categoryForCast(CAST_APP_ID))
            .build()
    }

    var routes by remember {
        mutableStateOf(mediaRouter.routes.filter { it.matchesSelector(selector) })
    }

    DisposableEffect(Unit) {
        val callback = object : MediaRouter.Callback() {
            override fun onRouteAdded(router: MediaRouter, route: MediaRouter.RouteInfo) {
                routes = router.routes.filter { it.matchesSelector(selector) }
            }
            override fun onRouteRemoved(router: MediaRouter, route: MediaRouter.RouteInfo) {
                routes = router.routes.filter { it.matchesSelector(selector) }
            }
            override fun onRouteChanged(router: MediaRouter, route: MediaRouter.RouteInfo) {
                routes = router.routes.filter { it.matchesSelector(selector) }
            }
        }
        // CALLBACK_FLAG_PERFORM_ACTIVE_SCAN is what AndroidX's own docs
        // specify for exactly this situation: "should be used when the
        // media route chooser dialog is showing to confirm the presence
        // of available routes." It implies CALLBACK_FLAG_REQUEST_DISCOVERY.
        // Only active while this dialog is on screen — removed on dispose
        // so it doesn't keep scanning (and draining battery) afterward.
        mediaRouter.addCallback(
            selector,
            callback,
            MediaRouter.CALLBACK_FLAG_REQUEST_DISCOVERY or MediaRouter.CALLBACK_FLAG_PERFORM_ACTIVE_SCAN
        )
        onDispose { mediaRouter.removeCallback(callback) }
    }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Cast to") },
        text = {
            Column {
                if (routes.isEmpty()) {
                    Text("Searching for devices\u2026", fontSize = 13.sp)
                } else {
                    routes.forEach { route ->
                        Text(
                            text = route.name,
                            fontSize = 15.sp,
                            modifier = Modifier
                                .fillMaxWidth()
                                .clickable {
                                    mediaRouter.selectRoute(route)
                                    onDismiss()
                                }
                                .padding(vertical = 12.dp)
                        )
                    }
                }
            }
        },
        confirmButton = {
            TextButton(onClick = onDismiss) { Text("Cancel") }
        }
    )
}

/** Receiver application ID — mirrors CastOptionsProvider.DEFAULT_APP_ID. */
private const val CAST_APP_ID = "CC1AD845"
