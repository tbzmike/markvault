package com.tebogo.markvault.ai

/** Connects T5 availability state with UI selection. */
object T5ModelUiConnector {
    fun canSelectT5(): Boolean = T5ExpansionAvailability.isAvailable()
}
