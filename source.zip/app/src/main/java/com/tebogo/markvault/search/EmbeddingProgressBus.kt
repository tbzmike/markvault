package com.tebogo.markvault.search

import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow

/**
 * Process-level progress bus for embedding work.
 *
 * v4.15.0 introduced the foreground [EmbeddingService] so that embedding
 * a 14k+ library doesn't stop the moment the user backgrounds the app or
 * the screen turns off. The service writes progress to this singleton;
 * the [com.tebogo.markvault.AppViewModel] reads from it; the Settings UI
 * observes through the VM. All three live in the same Android process
 * so a single in-memory StateFlow is enough.
 *
 * Lifecycle in [progress] values:
 *   - `null`           — idle (no pass running, or last pass complete)
 *   - `(0, 0)`         — preparing: service has started but the
 *                        DAO count hasn't returned yet
 *   - `(done, total)`  — running: `done` notes embedded out of `total`
 *
 * [isRunning] is the boolean shortcut used by UI to decide whether to
 * show the progress bar / Cancel button.
 */
object EmbeddingProgressBus {

    private val _progress = MutableStateFlow<Pair<Int, Int>?>(null)
    val progress: StateFlow<Pair<Int, Int>?> = _progress

    private val _isRunning = MutableStateFlow(false)
    val isRunning: StateFlow<Boolean> = _isRunning

    /** Called by the service when the embed job kicks off. */
    fun start() {
        _isRunning.value = true
        _progress.value = 0 to 0
    }

    /** Called per-note as the embed loop advances. */
    fun updateProgress(done: Int, total: Int) {
        _progress.value = done to total
    }

    /** Called by the service after the last note is embedded. */
    fun complete() {
        _progress.value = null
        _isRunning.value = false
    }

    /**
     * Called on service tear-down (cancelled, OS-killed, completed). Same
     * end state as [complete] — kept as a separate method so callers can
     * read the code's intent at the call site.
     */
    fun idle() {
        _progress.value = null
        _isRunning.value = false
    }
}
