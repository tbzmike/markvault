package com.tebogo.markvault.llm

import android.content.Context
import com.tebogo.markvault.ai.LlmExpansionHistory
import com.tebogo.markvault.ai.LlmExpansionRecord
import com.tebogo.markvault.ai.LocalAIProvider
import kotlinx.coroutines.TimeoutCancellationException
import kotlinx.coroutines.flow.toList
import kotlinx.coroutines.withTimeout

/**
 * v5.4.76cc — Concrete [LocalAIProvider] implementation. Bridges the
 * multi-query retrieval pipeline
 * ([com.tebogo.markvault.ai.MultiQueryRetriever],
 * [com.tebogo.markvault.AppViewModel.expandedContentSearch]) to
 * [LlmManager]'s Phi-4-mini engine for actual on-device query paraphrasing.
 *
 * ## Contract
 *
 * Take one user search query, produce up to [DEFAULT_PARAPHRASE_COUNT]
 * distinct short paraphrases of it. Purely for retrieval — the output
 * feeds directly into FTS+semantic sub-queries, never into a chat UI.
 *
 * ## RAM policy
 *
 * As demanded by the "optimally low RAM" requirement:
 *
 *   1. Every call goes load → generate → parse → **unload** inside a
 *      single `try/finally` so the ~4.5 GB Phi-4-mini footprint is
 *      resident only for the seconds a single expansion takes and is
 *      released deterministically, even on error paths.
 *   2. Repeat queries hit [LlmExpansionHistory] cache and skip the model
 *      entirely — no reload, no re-inference, no RAM spike.
 *   3. Model load time on the first expansion of a session is ~10 s per
 *      LiteRT-LM docs; generation of the short paraphrase list is
 *      ~3-5 s; unload ~1 s. Total for a cold submit is ~15 s. Every
 *      subsequent submit of the same query is instant from cache.
 *
 * ## Timeout guard
 *
 * A hard [GENERATION_TIMEOUT_MS] wraps the streaming generate call. If
 * the model hangs (rare but observed on very long prompts on stressed
 * devices), the coroutine is cancelled cleanly and the caller sees an
 * empty paraphrase list rather than an indefinite hang on the search
 * hot path.
 *
 * ## Not a singleton
 *
 * Instances are cheap; the ViewModel constructs one per app process on
 * demand, giving it the app [Context] so it can resolve the on-disk
 * model path via [ChatModelCatalog.default].
 */
class LlmQueryExpander(
    private val appContext: Context
) : LocalAIProvider {

    override fun modelName(): String =
        ChatModelCatalog.default.displayName

    override suspend fun expandQuery(query: String): List<String> {
        val trimmed = query.trim()
        if (trimmed.length < MIN_QUERY_LEN) return emptyList()

        // ---- Fast path: cache hit ----
        LlmExpansionHistory.get(trimmed)?.let { cached ->
            // Re-record so the UI dialog reflects a fresh "you searched
            // this again just now" observation while making it clear
            // that the LLM did not re-run.
            LlmExpansionHistory.record(
                LlmExpansionRecord(
                    query = trimmed,
                    paraphrases = cached.paraphrases,
                    timestampMs = System.currentTimeMillis(),
                    durationMs = 0L,
                    cached = true
                )
            )
            return cached.paraphrases
        }

        // ---- Slow path: run the model ----
        val descriptor = ChatModelCatalog.default
        val file = descriptor.fileIn(appContext.filesDir)
        if (!file.exists() ||
            file.length() <= ChatModelCatalog.MIN_PLAUSIBLE_MODEL_BYTES
        ) {
            // Model not installed — this shouldn't happen because the
            // caller gates on installation, but be defensive.
            return emptyList()
        }

        val startNs = System.nanoTime()
        val paraphrases: List<String> = try {
            LlmManager.load(file.absolutePath)
            val prompt = buildPrompt(trimmed, DEFAULT_PARAPHRASE_COUNT)
            val chunks = withTimeout(GENERATION_TIMEOUT_MS) {
                LlmManager.generate(prompt).toList()
            }
            parseParaphrases(chunks.joinToString(separator = ""), trimmed, DEFAULT_PARAPHRASE_COUNT)
        } catch (_: TimeoutCancellationException) {
            emptyList()
        } catch (_: Throwable) {
            // Any failure (OOM, engine init failure, cancellation) →
            // degrade gracefully. Callers merge an empty list and fall
            // back to non-LLM retrieval.
            emptyList()
        } finally {
            // Non-negotiable per the RAM policy: always unload.
            runCatching { LlmManager.unload() }
        }

        val durationMs = (System.nanoTime() - startNs) / 1_000_000L
        LlmExpansionHistory.record(
            LlmExpansionRecord(
                query = trimmed,
                paraphrases = paraphrases,
                timestampMs = System.currentTimeMillis(),
                durationMs = durationMs,
                cached = false
            )
        )
        return paraphrases
    }

    // ------------------------------------------------------------------
    // Prompt construction & output parsing
    // ------------------------------------------------------------------

    /**
     * Build the paraphrase-generation prompt. Deliberately terse:
     *
     *   - The instruction section forces "one per line, no numbering,
     *     no preamble" so the parser is a trivial split-on-newline.
     *   - We frame the domain as "Bible research and apologetics
     *     articles" so the LLM biases toward vocabulary the user's
     *     14k-note library actually contains (per user context — this
     *     is Tebogo's Obsidian JW library).
     *   - We ban the original query from appearing in output — the
     *     original always contributes to search on its own.
     *   - `count` is embedded as a target number so the model calibrates
     *     rather than defaulting to "as many as I feel like".
     */
    private fun buildPrompt(query: String, count: Int): String = """
        You are a search query paraphrase generator for a personal library of
        Bible research and apologetics articles (Jehovah's Witnesses / NWT
        vocabulary, biblical topics, scriptural citations).

        Given the user's search query, produce exactly $count distinct short
        paraphrased or related queries. Each paraphrase should express the
        same information need in different words, so it will surface notes
        that use different vocabulary for the same concept.

        Rules:
        - Output ONLY the paraphrases, one per line.
        - No numbering, no bullets, no explanations, no preamble.
        - Each paraphrase must be a short search query (2 to 8 words).
        - Prefer different keywords than the original query where possible.
        - Do NOT repeat the original query.
        - Do NOT add quotes around any paraphrase.

        User query: $query

        Paraphrases:
    """.trimIndent()

    /**
     * Parse the model output into up to [maxCount] paraphrases.
     *
     *   1. Split on newlines.
     *   2. Trim each line and strip common prefixes the model sometimes
     *      emits despite the instructions (numeric bullets like "1.",
     *      dash bullets, leading quotes, trailing punctuation-only lines).
     *   3. Drop the original query if it echoes.
     *   4. Deduplicate case-insensitively while preserving order.
     *   5. Take the first [maxCount] survivors.
     */
    private fun parseParaphrases(raw: String, original: String, maxCount: Int): List<String> {
        if (raw.isBlank()) return emptyList()
        val originalLower = original.lowercase().trim()
        val seen = HashSet<String>()
        val out = ArrayList<String>(maxCount)
        for (line in raw.split('\n')) {
            var s = line.trim()
            if (s.isEmpty()) continue
            // Strip common leading noise: "1.", "1)", "-", "*", "•", quotes.
            s = s.trimStart('-', '*', '•', ' ', '\t')
            s = s.replace(Regex("^\\d+[.)\\-:]\\s*"), "")
            s = s.trim('"', '\'', ' ', '\t')
            if (s.isEmpty()) continue
            if (s.length < MIN_PARAPHRASE_LEN || s.length > MAX_PARAPHRASE_LEN) continue
            val key = s.lowercase()
            if (key == originalLower) continue
            if (!seen.add(key)) continue
            out += s
            if (out.size >= maxCount) break
        }
        return out
    }

    companion object {
        /** Number of paraphrases requested from the LLM per expansion. */
        const val DEFAULT_PARAPHRASE_COUNT = 3

        /** Below this length we don't bother invoking the LLM. */
        const val MIN_QUERY_LEN = 2

        /** Sanity floor / ceiling on any individual paraphrase length. */
        private const val MIN_PARAPHRASE_LEN = 3
        private const val MAX_PARAPHRASE_LEN = 120

        /**
         * Hard cap on the streaming generate call. Chosen to comfortably
         * cover Phi-4-mini's ~3-5 s typical paraphrase generation while
         * guarding against a runaway on a very cold CPU. Includes only
         * generation — the preceding [LlmManager.load] is not covered
         * by this timeout because a slow load is expected on first use
         * (~10 s) and should not be aborted as if it were a hang.
         */
        private const val GENERATION_TIMEOUT_MS = 30_000L
    }
}
