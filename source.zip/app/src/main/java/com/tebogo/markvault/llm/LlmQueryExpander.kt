package com.tebogo.markvault.llm

import android.app.ActivityManager
import android.content.Context
import com.tebogo.markvault.ai.LlmExpansionHistory
import com.tebogo.markvault.ai.LlmExpansionRecord
import com.tebogo.markvault.ai.LocalAIProvider
import kotlinx.coroutines.TimeoutCancellationException
import kotlinx.coroutines.flow.toList
import kotlinx.coroutines.withTimeout

/**
 * v5.4.79cc — Concrete [LocalAIProvider] implementation. Bridges the
 * multi-query retrieval pipeline
 * ([com.tebogo.markvault.ai.MultiQueryRetriever],
 * [com.tebogo.markvault.AppViewModel.expandedContentSearch]) to
 * [LlmManager]'s active model for on-device query paraphrasing.
 *
 * ## What changed in v5.4.79cc
 *
 * v5.4.76cc–v5.4.78cc hard-coded the descriptor to
 * [ChatModelCatalog.default] and used a 30-second generate timeout with
 * no free-RAM check. On a 6 GB device with Phi-4-mini selected, the
 * ~4.5 GB peak-RAM inference kicked the process into OOM territory and
 * the OS killed the app mid-generation.
 *
 * v5.4.79cc addresses that in three ways:
 *
 *   1. **Per-call model resolution.** The expander no longer hard-codes
 *      the catalog default. Instead it takes a `descriptorProvider`
 *      lambda that returns the *currently active* descriptor at the
 *      moment of the call. When the user picks SmolLM2-135M in
 *      Settings, subsequent expansions run against SmolLM2 (~350 MB
 *      peak RAM) instead of Phi-4-mini. Switching is free — no
 *      restart, no explicit unload of the previous model needed
 *      because we already unload after every call.
 *
 *   2. **Free-RAM precheck** when memory-optimised mode is on
 *      ([Prefs.memoryOptimizedLlm]). Before load, we ask ActivityManager
 *      for the process's `availMem` in bytes and refuse to load if the
 *      free-RAM headroom is less than `descriptor.approxRamMb + 300 MB`.
 *      Skipped expansions return `emptyList()`; the caller falls back
 *      to Kotlin-synonym expansion so the search still returns
 *      *something* useful.
 *
 *   3. **Aggressive 5-second generate timeout** (down from 30 s). Load
 *      is *not* timed out — a cold Phi-4-mini load takes ~10 s and
 *      that's expected. The 5-second cap is only on the streaming
 *      generate step. Timeouts fall back to `emptyList()` on the
 *      caller side, same as the RAM-precheck skip path.
 *
 * ## Contract
 *
 * Take one user search query, produce up to [DEFAULT_PARAPHRASE_COUNT]
 * distinct short paraphrases of it. Purely for retrieval — the output
 * feeds directly into FTS+semantic sub-queries, never into a chat UI.
 *
 * ## RAM policy (unchanged)
 *
 * Every call is load → generate → parse → **unload** inside a single
 * `try/finally` so the model's footprint is resident only for the
 * seconds a single expansion takes and is released deterministically,
 * even on error paths. Repeat queries hit [LlmExpansionHistory] cache
 * and skip the model entirely.
 */
class LlmQueryExpander(
    private val appContext: Context,
    /**
     * Returns the descriptor of the model currently selected for LLM
     * query expansion. Called on every expansion so a Settings change
     * takes effect at the next submit without needing to reconstruct
     * this expander.
     */
    private val descriptorProvider: () -> ChatModelDescriptor,
    /**
     * Returns whether the memory-safety belt is on right now. When it
     * is, the free-RAM precheck and shorter timeout apply. Read at the
     * top of every expansion so a Settings change is honoured on the
     * next submit.
     */
    private val memoryOptimizedProvider: () -> Boolean,
    /**
     * v5.4.80cc — Returns the paraphrase-count slider value (0..10).
     * When zero, the expander short-circuits before load and returns
     * `emptyList()`. Otherwise the value is used as the paraphrase
     * target and passed through to the prompt so the LLM knows how
     * many rewrites the user asked for.
     */
    private val countProvider: () -> Int
) : LocalAIProvider {

    override fun modelName(): String = descriptorProvider().displayName

    override suspend fun expandQuery(query: String): List<String> {
        val trimmed = query.trim()
        if (trimmed.length < MIN_QUERY_LEN) return emptyList()

        // v5.4.80cc — Slider-driven paraphrase target. When the user has
        // dragged the slider to 0, treat it as "LLM off for this
        // preference" and skip everything — no cache read, no cache
        // write, no history record. This gives the user a per-slider
        // off switch that leaves the master aiLlmSearchEnabled toggle
        // in "available" state (unlike flipping the toggle off, which
        // would hide the pumping brain).
        val targetCount = countProvider().coerceIn(0, MAX_PARAPHRASE_COUNT)
        if (targetCount == 0) return emptyList()

        // ---- Fast path: cache hit ----
        LlmExpansionHistory.get(trimmed)?.let { cached ->
            // Re-record so the UI dialog reflects a fresh "you searched
            // this again just now" observation while making it clear
            // that the LLM did not re-run.
            LlmExpansionHistory.record(
                LlmExpansionRecord(
                    query = trimmed,
                    paraphrases = cached.paraphrases,
                    timestampMs = System.currentTimeMillis(),
                    durationMs = 0L,
                    cached = true
                )
            )
            return cached.paraphrases
        }

        // ---- Slow path: run the model ----
        val descriptor = descriptorProvider()
        val memoryOptimised = memoryOptimizedProvider()
        val file = descriptor.fileIn(appContext.filesDir)
        if (!file.exists() ||
            file.length() <= ChatModelCatalog.MIN_PLAUSIBLE_MODEL_BYTES
        ) {
            // Model not installed — the caller gates on installation but
            // be defensive.
            return emptyList()
        }

        // ---- Memory-safety belt ----
        if (memoryOptimised && !hasEnoughFreeRam(descriptor)) {
            // Not enough free RAM to safely load this descriptor. Record
            // a *zero-paraphrase* observation so the Home-screen history
            // dialog can show the user that the run was skipped rather
            // than "silently no results". Return empty; the search
            // falls back to Kotlin synonyms.
            LlmExpansionHistory.record(
                LlmExpansionRecord(
                    query = trimmed,
                    paraphrases = emptyList(),
                    timestampMs = System.currentTimeMillis(),
                    durationMs = 0L,
                    cached = false
                )
            )
            return emptyList()
        }

        val startNs = System.nanoTime()
        val loadTimeoutMs = if (memoryOptimised) {
            SHORT_LOAD_TIMEOUT_MS
        } else {
            LONG_LOAD_TIMEOUT_MS
        }
        val generateTimeoutMs = if (memoryOptimised) {
            SHORT_GENERATION_TIMEOUT_MS
        } else {
            LONG_GENERATION_TIMEOUT_MS
        }
        val paraphrases: List<String> = try {
            // v5.4.80cc — Wrap load in withTimeout too. In v5.4.79cc
            // only generate was timed out, so a stalled native
            // `Engine.initialize()` (corrupt file, unsupported model
            // format, mmap failure) hung the whole search hot path
            // forever. Now load has its own cap: 15 s in
            // memory-optimised mode (SmolLM2 loads in ~1-2 s so 15 s
            // is generous), 45 s otherwise (Phi-4-mini's cold load can
            // legitimately be ~10 s).
            withTimeout(loadTimeoutMs) {
                LlmManager.load(file.absolutePath)
            }
            val prompt = buildPrompt(trimmed, targetCount)
            val chunks = withTimeout(generateTimeoutMs) {
                LlmManager.generate(prompt).toList()
            }
            parseParaphrases(chunks.joinToString(separator = ""), trimmed, targetCount)
        } catch (_: TimeoutCancellationException) {
            emptyList()
        } catch (_: Throwable) {
            // Any failure (OOM, engine init failure, cancellation) →
            // degrade gracefully. Callers merge an empty list and fall
            // back to non-LLM retrieval.
            emptyList()
        } finally {
            // Non-negotiable per the RAM policy: always unload.
            runCatching { LlmManager.unload() }
        }

        val durationMs = (System.nanoTime() - startNs) / 1_000_000L
        LlmExpansionHistory.record(
            LlmExpansionRecord(
                query = trimmed,
                paraphrases = paraphrases,
                timestampMs = System.currentTimeMillis(),
                durationMs = durationMs,
                cached = false
            )
        )
        return paraphrases
    }

    // ------------------------------------------------------------------
    // Memory-safety helpers
    // ------------------------------------------------------------------

    /**
     * v5.4.79cc — Free-RAM precheck. Refuses to load a model whose
     * peak RAM estimate wouldn't fit alongside the current allocation
     * plus a 300 MB safety margin (BGE-large's working set, WebView
     * paint pipeline spikes, transient allocation during
     * `LlmManager.load`).
     *
     * `ActivityManager.getMemoryInfo().availMem` is the OS-reported
     * total free RAM available to *any* process on the device, which
     * over-estimates our own headroom slightly; we compensate for that
     * conservatism with the 300 MB margin.
     *
     * Returns `true` if it's safe to proceed, `false` if we should
     * skip the expansion for this query.
     */
    private fun hasEnoughFreeRam(descriptor: ChatModelDescriptor): Boolean {
        val am = appContext.getSystemService(Context.ACTIVITY_SERVICE) as? ActivityManager
            ?: return true  // no ActivityManager → don't second-guess the OS, let it try
        val info = ActivityManager.MemoryInfo()
        am.getMemoryInfo(info)
        val availMb = info.availMem / (1024L * 1024L)
        val needed = (descriptor.approxRamMb + FREE_RAM_SAFETY_MARGIN_MB).toLong()
        return availMb >= needed
    }

    // ------------------------------------------------------------------
    // Prompt construction & output parsing
    // ------------------------------------------------------------------

    /**
     * Build the paraphrase-generation prompt. Deliberately terse:
     *
     *   - The instruction section forces "one per line, no numbering,
     *     no preamble" so the parser is a trivial split-on-newline.
     *   - We frame the domain as "Bible research and apologetics
     *     articles" so the LLM biases toward vocabulary the user's
     *     14k-note library actually contains.
     *   - We ban the original query from appearing in output — the
     *     original always contributes to search on its own.
     *   - `count` is embedded as a target number so the model calibrates
     *     rather than defaulting to "as many as I feel like".
     *
     * The prompt works with both catalog models. SmolLM2-135M
     * sometimes ignores the "one per line" rule and emits numbered
     * bullets; the parser strips those defensively.
     */
    private fun buildPrompt(query: String, count: Int): String = """
        You are a search query paraphrase generator for a personal library of
        Bible research and apologetics articles (Jehovah's Witnesses / NWT
        vocabulary, biblical topics, scriptural citations).

        Given the user's search query, produce exactly $count distinct short
        paraphrased or related queries. Each paraphrase should express the
        same information need in different words, so it will surface notes
        that use different vocabulary for the same concept.

        Rules:
        - Output ONLY the paraphrases, one per line.
        - No numbering, no bullets, no explanations, no preamble.
        - Each paraphrase must be a short search query (2 to 8 words).
        - Prefer different keywords than the original query where possible.
        - Do NOT repeat the original query.
        - Do NOT add quotes around any paraphrase.

        User query: $query

        Paraphrases:
    """.trimIndent()

    /**
     * Parse the model output into up to [maxCount] paraphrases.
     *
     *   1. Split on newlines.
     *   2. Trim each line and strip common prefixes the model sometimes
     *      emits despite the instructions.
     *   3. Drop the original query if it echoes.
     *   4. Deduplicate case-insensitively while preserving order.
     *   5. Take the first [maxCount] survivors.
     */
    private fun parseParaphrases(raw: String, original: String, maxCount: Int): List<String> {
        if (raw.isBlank()) return emptyList()
        val originalLower = original.lowercase().trim()
        val seen = HashSet<String>()
        val out = ArrayList<String>(maxCount)
        for (line in raw.split('\n')) {
            var s = line.trim()
            if (s.isEmpty()) continue
            // Strip common leading noise: "1.", "1)", "-", "*", "•", quotes.
            s = s.trimStart('-', '*', '•', ' ', '\t')
            s = s.replace(Regex("^\\d+[.)\\-:]\\s*"), "")
            s = s.trim('"', '\'', ' ', '\t')
            if (s.isEmpty()) continue
            if (s.length < MIN_PARAPHRASE_LEN || s.length > MAX_PARAPHRASE_LEN) continue
            val key = s.lowercase()
            if (key == originalLower) continue
            if (!seen.add(key)) continue
            out += s
            if (out.size >= maxCount) break
        }
        return out
    }

    companion object {
        /**
         * v5.4.80cc — Default paraphrase count when the slider preference
         * hasn't been touched. Kept as a fallback for tests / call sites
         * that construct an expander outside the ViewModel wiring.
         */
        const val DEFAULT_PARAPHRASE_COUNT = 3

        /**
         * v5.4.80cc — Slider ceiling. Matches Prefs' coercion range so
         * a spliced pref value can never request more.
         */
        const val MAX_PARAPHRASE_COUNT = 10

        /** Below this length we don't bother invoking the LLM. */
        const val MIN_QUERY_LEN = 2

        /** Sanity floor / ceiling on any individual paraphrase length. */
        private const val MIN_PARAPHRASE_LEN = 3
        private const val MAX_PARAPHRASE_LEN = 120

        /**
         * v5.4.80cc — Load timeout for memory-optimised mode.
         * SmolLM2-135M loads in ~1-2 s on the CPU backend, so 15 s is
         * a generous cap that still bows out quickly if the native
         * `Engine.initialize()` call has actually stalled (corrupt
         * file, memory-mapping failure, incompatible bundle).
         */
        private const val SHORT_LOAD_TIMEOUT_MS = 15_000L

        /**
         * v5.4.80cc — Load timeout for non-memory-optimised mode.
         * Phi-4-mini's cold load can legitimately take ~10 s per docs,
         * so 45 s covers pathological first-runs on a slow SoC.
         */
        private const val LONG_LOAD_TIMEOUT_MS = 45_000L

        /**
         * Aggressive generate timeout used in memory-optimised mode.
         * Chosen per v5.4.79cc's memory-safety belt — the goal is to
         * bow out fast rather than hold the search hot path.
         */
        private const val SHORT_GENERATION_TIMEOUT_MS = 5_000L

        /**
         * Generate timeout used when memory-optimised mode is off. Same
         * 30 s ceiling v5.4.76cc used — comfortably covers Phi-4-mini's
         * typical paraphrase generation while guarding against a
         * runaway on a very cold CPU.
         */
        private const val LONG_GENERATION_TIMEOUT_MS = 30_000L

        /**
         * MB of free-RAM headroom demanded on top of the model's
         * declared peak RAM before we agree to load it. Covers the
         * transient allocation churn of `LlmManager.load` plus paint,
         * Room and WebView spikes.
         */
        private const val FREE_RAM_SAFETY_MARGIN_MB = 300
    }
}
