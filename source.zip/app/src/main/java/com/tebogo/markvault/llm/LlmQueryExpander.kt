package com.tebogo.markvault.llm

import android.app.ActivityManager
import android.content.Context
import com.tebogo.markvault.ai.LlmExpansionHistory
import com.tebogo.markvault.ai.LlmExpansionRecord
import com.tebogo.markvault.ai.LocalAIProvider
import kotlinx.coroutines.TimeoutCancellationException
import kotlinx.coroutines.NonCancellable
import kotlinx.coroutines.withContext
import kotlinx.coroutines.flow.collect
import kotlinx.coroutines.flow.takeWhile
import kotlinx.coroutines.withTimeout

/**
 * v5.4.79cc — Concrete [LocalAIProvider] implementation. Bridges the
 * multi-query retrieval pipeline
 * ([com.tebogo.markvault.ai.MultiQueryRetriever],
 * [com.tebogo.markvault.AppViewModel.expandedContentSearch]) to
 * [LlmManager]'s active model for on-device query paraphrasing.
 *
 * ## What changed in v5.4.79cc
 *
 * v5.4.76cc–v5.4.78cc hard-coded the descriptor to
 * [ChatModelCatalog.default] and used a 30-second generate timeout with
 * no free-RAM check. On a 6 GB device with Phi-4-mini selected, the
 * ~4.5 GB peak-RAM inference kicked the process into OOM territory and
 * the OS killed the app mid-generation.
 *
 * v5.4.79cc addresses that in three ways:
 *
 *   1. **Per-call model resolution.** The expander no longer hard-codes
 *      the catalog default. Instead it takes a `descriptorProvider`
 *      lambda that returns the *currently active* descriptor at the
 *      moment of the call. When the user picks SmolLM2-135M in
 *      Settings, subsequent expansions run against SmolLM2 (~350 MB
 *      peak RAM) instead of Phi-4-mini. Switching is free — no
 *      restart, no explicit unload of the previous model needed
 *      because we already unload after every call.
 *
 *   2. **Free-RAM precheck** when memory-optimised mode is on
 *      ([Prefs.memoryOptimizedLlm]). Before load, we ask ActivityManager
 *      for the process's `availMem` in bytes and refuse to load if the
 *      free-RAM headroom is less than `descriptor.approxRamMb + 300 MB`.
 *      Skipped expansions return `emptyList()`; the caller falls back
 *      to Kotlin-synonym expansion so the search still returns
 *      *something* useful.
 *
 *   3. **Aggressive 5-second generate timeout** (down from 30 s). Load
 *      is *not* timed out — a cold Phi-4-mini load takes ~10 s and
 *      that's expected. The 5-second cap is only on the streaming
 *      generate step. Timeouts fall back to `emptyList()` on the
 *      caller side, same as the RAM-precheck skip path.
 *
 * ## Contract
 *
 * Take one user search query, produce up to [DEFAULT_PARAPHRASE_COUNT]
 * distinct short paraphrases of it. Purely for retrieval — the output
 * feeds directly into FTS+semantic sub-queries, never into a chat UI.
 *
 * ## RAM policy (unchanged)
 *
 * Every call is load → generate → parse → **unload** inside a single
 * `try/finally` so the model's footprint is resident only for the
 * seconds a single expansion takes and is released deterministically,
 * even on error paths. Repeat queries hit [LlmExpansionHistory] cache
 * and skip the model entirely.
 */
class LlmQueryExpander(
    private val appContext: Context,
    /**
     * Returns the descriptor of the model currently selected for LLM
     * query expansion. Called on every expansion so a Settings change
     * takes effect at the next submit without needing to reconstruct
     * this expander.
     */
    private val descriptorProvider: () -> ChatModelDescriptor,
    /**
     * Returns whether the memory-safety belt is on right now. When it
     * is, the free-RAM precheck and shorter timeout apply. Read at the
     * top of every expansion so a Settings change is honoured on the
     * next submit.
     */
    private val memoryOptimizedProvider: () -> Boolean,
    /**
     * v5.4.80cc — Returns the paraphrase-count slider value (0..10).
     * When zero, the expander short-circuits before load and returns
     * `emptyList()`. Otherwise the value is used as the paraphrase
     * target and passed through to the prompt so the LLM knows how
     * many rewrites the user asked for.
     */
    private val countProvider: () -> Int
) : LocalAIProvider {

    /**
     * v5.4.137cc — Cool-down window after a bad LLM run.
     *
     * When the LLM path fails with a timeout, engine error, or the
     * outer budget blowing, the underlying native session may be
     * left in a partially-torn-down state that a subsequent load
     * would hang trying to reuse (the `LlmManager.load` fast-path
     * checks `engine != null` and short-circuits — if that engine's
     * native side is actually wedged from a previous crash-adjacent
     * cleanup, generate() then hangs forever on the wedged session
     * and the search UI sticks on "searching…").
     *
     * The cool-down is a simple monotonic-time cutoff: after any
     * failed run, all LLM expansions are skipped for
     * [COOLDOWN_AFTER_ERROR_MS] milliseconds. During the cool-down,
     * `expandQuery` returns `emptyList()` with `skipReason =
     * "cooldown"` immediately, and the caller falls back to the
     * synonym expander so search still returns results.
     *
     * The cool-down is per-process (in-memory `@Volatile` long),
     * so an app restart clears it. That's intentional — a real
     * restart is the surest way to guarantee a clean native session.
     */
    @Volatile private var cooldownUntilNanos: Long = 0L

    override fun modelName(): String = descriptorProvider().displayName

    override suspend fun expandQuery(query: String): List<String> {
        val trimmed = query.trim()
        if (trimmed.length < MIN_QUERY_LEN) return emptyList()

        // v5.4.137cc — Cool-down: skip if a recent LLM run failed.
        // See [cooldownUntilNanos] doc for the wedged-native-session
        // reasoning. Records a `cooldown` history entry so the user
        // can see why this run was skipped rather than "silently no
        // results" — the history dialog will explain the retry
        // window explicitly.
        val nowNs: Long = System.nanoTime()
        if (nowNs < cooldownUntilNanos) {
            val remainingMs: Long = (cooldownUntilNanos - nowNs) / 1_000_000L
            LlmExpansionHistory.record(
                LlmExpansionRecord(
                    query = trimmed,
                    paraphrases = emptyList(),
                    timestampMs = System.currentTimeMillis(),
                    durationMs = 0L,
                    cached = false,
                    modelName = descriptorProvider().displayName,
                    skipReason = "cooldown"
                )
            )
            return emptyList()
        }

        // v5.4.80cc — Slider-driven paraphrase target. When the user has
        // dragged the slider to 0, treat it as "LLM off for this
        // preference" and skip everything — no cache read, no cache
        // write, no history record. This gives the user a per-slider
        // off switch that leaves the master aiLlmSearchEnabled toggle
        // in "available" state (unlike flipping the toggle off, which
        // would hide the pumping brain).
        val targetCount = countProvider().coerceIn(0, MAX_PARAPHRASE_COUNT)
        if (targetCount == 0) return emptyList()

        // Resolve the model that should service this call BEFORE touching
        // the cache — see the fast-path note just below for why.
        val descriptor = descriptorProvider()

        // ---- Fast path: cache hit ----
        //
        // v5.4.140cc — Cache hits must be scoped to the CURRENTLY SELECTED
        // model, not just the query text. [LlmExpansionHistory] is a flat
        // query -> record map with no model dimension, so a record left
        // behind by e.g. SmolLM2 was previously replayed verbatim the
        // instant the user switched to Gemma 4 E2B and re-ran the same
        // query — the cache hit fired here before Gemma (or any other
        // newly-selected model) ever loaded. Worse, the re-record below
        // stamped that stale SmolLM2 output with Gemma's displayName, so
        // the history dialog claimed Gemma produced paraphrases it never
        // generated. Net effect: switching models appeared to do nothing —
        // search kept "falling back" to whichever model ran first, even
        // with the (unrelated) synonym-fallback toggle off, and the
        // newly-selected model looked permanently unwired.
        //
        // The caller ([AppViewModel.expandedContentSearch]) already
        // guards its OWN cache read with an equivalent modelName check;
        // this mirrors that so the guarantee holds even when callers
        // invoke this expander directly.
        LlmExpansionHistory.get(trimmed)
            ?.takeIf { it.modelName == descriptor.displayName && it.paraphrases.isNotEmpty() }
            ?.let { cached ->
                // Re-record so the UI dialog reflects a fresh "you searched
                // this again just now" observation while making it clear
                // that the LLM did not re-run.
                LlmExpansionHistory.record(
                    LlmExpansionRecord(
                        query = trimmed,
                        paraphrases = cached.paraphrases,
                        timestampMs = System.currentTimeMillis(),
                        durationMs = 0L,
                        cached = true,
                        modelName = descriptor.displayName
                    )
                )
                return cached.paraphrases
            }

        // ---- Slow path: run the model ----
        val memoryOptimised = memoryOptimizedProvider()
        val file = descriptor.fileIn(appContext.filesDir)
        if (!file.exists() ||
            file.length() <= ChatModelCatalog.MIN_PLAUSIBLE_MODEL_BYTES
        ) {
            // Model not installed — the caller gates on installation but
            // be defensive. v5.4.136cc — record so the history dialog
            // shows the real reason instead of guessing.
            LlmExpansionHistory.record(
                LlmExpansionRecord(
                    query = trimmed,
                    paraphrases = emptyList(),
                    timestampMs = System.currentTimeMillis(),
                    durationMs = 0L,
                    cached = false,
                    modelName = descriptor.displayName,
                    skipReason = "not_installed"
                )
            )
            return emptyList()
        }

        // ---- Memory-safety belt ----
        if (memoryOptimised && !hasEnoughFreeRam(descriptor)) {
            // Not enough free RAM to safely load this descriptor. Record
            // a *zero-paraphrase* observation so the Home-screen history
            // dialog can show the user that the run was skipped rather
            // than "silently no results". Return empty; the search
            // falls back to Kotlin synonyms.
            LlmExpansionHistory.record(
                LlmExpansionRecord(
                    query = trimmed,
                    paraphrases = emptyList(),
                    timestampMs = System.currentTimeMillis(),
                    durationMs = 0L,
                    cached = false,
                    modelName = descriptor.displayName,
                    skipReason = "ram_skip"
                )
            )
            return emptyList()
        }

        val startNs = System.nanoTime()
        val loadTimeoutMs = if (memoryOptimised) {
            SHORT_LOAD_TIMEOUT_MS
        } else {
            LONG_LOAD_TIMEOUT_MS
        }
        val generateTimeoutMs = if (memoryOptimised) {
            SHORT_GENERATION_TIMEOUT_MS
        } else {
            LONG_GENERATION_TIMEOUT_MS
        }
        // v5.5.40 — Search must not wait for a chat-style response to end.
        // Keep completed, relevance-checked query lines as the model streams,
        // then stop when enough valid expansions have arrived. A deadline
        // retains those completed lines instead of throwing them away.
        // LlmManager.generate() drains its native callback thread on early
        // Flow termination; unload below remains mandatory on every path.
        val stream = LlmStreamAccumulator(
            target = targetCount,
            parse = { text -> parseParaphrases(text, trimmed, targetCount) }
        )
        var skipReasonHolder: String? = null
        val outerBudgetMs = loadTimeoutMs + generateTimeoutMs + 3_000L
        val paraphrases: List<String> = kotlinx.coroutines.withTimeoutOrNull(outerBudgetMs) {
            try {
                withTimeout(loadTimeoutMs) {
                    LlmManager.load(file.absolutePath)
                }
                val prompt = buildPrompt(trimmed, targetCount)
                withTimeout(generateTimeoutMs) {
                    LlmManager.generate(prompt)
                        .takeWhile { chunk -> stream.appendAndContinue(chunk) }
                        .collect()
                }
                stream.results(completedNormally = true)
            } catch (cancelled: kotlinx.coroutines.CancellationException) {
                // Search edits and explicit cancellation are not LLM failures.
                if (cancelled !is TimeoutCancellationException) throw cancelled
                skipReasonHolder = "timeout"
                stream.results(completedNormally = false)
            } catch (_: Throwable) {
                skipReasonHolder = "engine_error"
                stream.results(completedNormally = false)
            } finally {
                // Preserve the crash-tested LiteRT native callback drain.
                // A partial expansion never keeps a multi-GB engine resident.
                withContext(NonCancellable) {
                    runCatching { LlmManager.unload() }
                }
            }
        } ?: run {
            skipReasonHolder = "timeout"
            // Keep completed, validated lines on outer budget expiry too.
            withContext(NonCancellable) {
                runCatching { LlmManager.unload() }
            }
            stream.results(completedNormally = false)
        }
        if (paraphrases.isEmpty() && skipReasonHolder == null) {
            skipReasonHolder = "all_rejected_by_relevance_gate"
        }
        val durationMs = (System.nanoTime() - startNs) / 1_000_000L
        // v5.4.142cc — Cooldown policy.
        //
        // The cooldown guards against re-using a *genuinely wedged* native
        // session: if a JNI call doesn't yield to coroutine cancellation, the
        // LlmManager.unload() in the finally block may not fully tear down
        // the engine, and a subsequent load() on the same Engine object can
        // hang. The cooldown skips expansion for COOLDOWN_AFTER_ERROR_MS ms
        // so the user gets search results (via synonyms) while the native
        // layer settles.
        //
        // However, "timeout" with memory-optimised OFF means the budget was
        // simply too short for the model on this device — the finally block
        // did run cleanly (LlmManager.unload() → drain → close). There is
        // no wedged state; the next load will start from scratch. Applying
        // a cooldown in this case just silently blocks the next search for
        // 30 s after an already-slow (and now extended-timeout) run, which
        // the user perceives as "the LLM still isn't working." Only arm the
        // cooldown for genuine engine errors where the session integrity is
        // in doubt.
        //
        // In memory-optimised mode the timeout is far more aggressive (5 s
        // generate) and can fire mid-JNI without a clean unload — the
        // wedged-session risk is real there, so keep the cooldown for both
        // "timeout" and "engine_error" in that mode.
        val finalReason: String? = if (paraphrases.isEmpty()) skipReasonHolder else null
        when (finalReason) {
            "engine_error" -> {
                // Genuine failure — native session integrity unknown.
                cooldownUntilNanos = System.nanoTime() +
                    COOLDOWN_AFTER_ERROR_MS * 1_000_000L
            }
            "timeout" -> {
                if (memoryOptimised) {
                    // Memory-optimised: 5 s cap can fire mid-JNI → possible wedge.
                    cooldownUntilNanos = System.nanoTime() +
                        COOLDOWN_AFTER_ERROR_MS * 1_000_000L
                } else {
                    // Non-memory-optimised: extended budget was still too short.
                    // Session was cleanly unloaded; no wedge risk. Clear any
                    // lingering cooldown so the next search proceeds immediately.
                    cooldownUntilNanos = 0L
                }
            }
            null -> {
                // Success — clear any lingering cool-down from a prior
                // failure so the good result "restarts the clock".
                cooldownUntilNanos = 0L
            }
            else -> {
                // Empty result but for a benign reason (relevance-gate
                // rejected everything): no cool-down needed. Native
                // session was cleanly used.
            }
        }
        LlmExpansionHistory.record(
            LlmExpansionRecord(
                query = trimmed,
                paraphrases = paraphrases,
                timestampMs = System.currentTimeMillis(),
                durationMs = durationMs,
                cached = false,
                modelName = descriptor.displayName,
                skipReason = finalReason
            )
        )
        return paraphrases
    }

    // ------------------------------------------------------------------
    // Memory-safety helpers
    // ------------------------------------------------------------------

    /**
     * v5.4.79cc — Free-RAM precheck. Refuses to load a model whose
     * peak RAM estimate wouldn't fit alongside the current allocation
     * plus a 300 MB safety margin (BGE-large's working set, WebView
     * paint pipeline spikes, transient allocation during
     * `LlmManager.load`).
     *
     * `ActivityManager.getMemoryInfo().availMem` is the OS-reported
     * total free RAM available to *any* process on the device, which
     * over-estimates our own headroom slightly; we compensate for that
     * conservatism with the 300 MB margin.
     *
     * Returns `true` if it's safe to proceed, `false` if we should
     * skip the expansion for this query.
     */
    private fun hasEnoughFreeRam(descriptor: ChatModelDescriptor): Boolean {
        val am = appContext.getSystemService(Context.ACTIVITY_SERVICE) as? ActivityManager
            ?: return true  // no ActivityManager → don't second-guess the OS, let it try
        val info = ActivityManager.MemoryInfo()
        am.getMemoryInfo(info)
        val availMb = info.availMem / (1024L * 1024L)
        val needed = (descriptor.approxRamMb + FREE_RAM_SAFETY_MARGIN_MB).toLong()
        return availMb >= needed
    }

    // ------------------------------------------------------------------
    // Prompt construction & output parsing
    // ------------------------------------------------------------------

    /**
     * v5.4.81cc — Build the paraphrase-generation prompt.
     *
     * **Aggressively short** vs v5.4.80cc's version. On SmolLM2-135M
     * most of the inference wall-clock is spent on prompt processing
     * rather than token generation (135M params, 570-dim hidden state
     * — decoding is fast, prefill scales with prompt length). Cutting
     * the prompt from ~200 tokens to ~50 shaves ~70% off the SmolLM2
     * wall-clock without measurably hurting paraphrase quality; the
     * expander already trims and dedupes whatever the model emits.
     *
     * The Bible-domain framing is preserved (biases vocabulary toward
     * the user's 14k-note JW/NWT library) but expressed in one line
     * instead of a paragraph. The "no numbering, no quotes" rules are
     * kept because SmolLM2 in particular loves to number its output,
     * and the parser strips numbering defensively.
     */
    private fun buildPrompt(query: String, count: Int): String = """
        Write $count different, short search queries about the SAME topic as:
        $query
        Keep key names and meaning; use Bible terms when relevant.
        One search query per line, no answers, numbering, or explanations.
        Do not repeat the original query or add unrelated topics.
    """.trimIndent()

    /**
     * Parse the model output into up to [maxCount] paraphrases.
     *
     *   1. Split on newlines.
     *   2. Trim each line and strip common prefixes the model sometimes
     *      emits despite the instructions.
     *   3. Drop the original query if it echoes.
     *   4. Deduplicate case-insensitively while preserving order.
     *   5. Take the first [maxCount] survivors.
     *
     * v5.4.136cc — Soft-fallback safety net. The strict topical-
     * relevance gate ([isTopicallyRelevant]) was found to reject
     * 100% of a small model's (SmolLM2-135M, the default) paraphrases
     * for many real queries — not because the paraphrases were wild
     * or off-topic, but because genuine paraphrasing legitimately uses
     * DIFFERENT vocabulary than the original, and the curated ~300-word
     * synonym table plus edit-distance-1 only covers a narrow slice of
     * that variation. The net effect: users saw the LLM technically
     * running (cost paid, cold-load included) but NEVER contributing a
     * single sub-query — indistinguishable from "LLM doesn't work".
     *
     * Fix: if every syntactically-valid candidate line (passed length
     * bounds and [isMetaText]) is rejected by the strict gate, instead
     * of returning nothing, keep the single candidate with the highest
     * [topicalOverlapScore] — the "least drifted" line rather than
     * zero lines. This only activates when NOTHING passed the strict
     * gate; if even one candidate passes normally, the fallback never
     * engages and behaviour is unchanged from before.
     */
    private fun parseParaphrases(raw: String, original: String, maxCount: Int): List<String> {
        if (raw.isBlank()) return emptyList()
        val originalLower = original.lowercase().trim()
        // v5.4.115cc — Content tokens of the original drive the
        // topical-relevance gate below.
        val originalContent = com.tebogo.markvault.search.QueryExpander
            .contentTokens(original)
        val seen = HashSet<String>()
        val out = ArrayList<String>(maxCount)
        // v5.4.136cc — Every syntactically-valid candidate (survived
        // length + meta-text checks + wasn't an echo) is recorded here
        // regardless of whether it passed the strict relevance gate,
        // so the soft fallback below has something to choose from.
        val allValidCandidates = ArrayList<String>()
        for (line in raw.split('\n')) {
            var s = line.trim()
            if (s.isEmpty()) continue
            // Strip common leading noise: "1.", "1)", "-", "*", "•", quotes.
            s = s.trimStart('-', '*', '•', ' ', '\t')
            s = s.replace(Regex("^\\d+[.)\\-:]\\s*"), "")
            s = s.trim('"', '\'', ' ', '\t')
            if (s.isEmpty()) continue
            if (s.length < MIN_PARAPHRASE_LEN || s.length > MAX_PARAPHRASE_LEN) continue
            // v5.4.115cc — Reject the model's conversational scaffolding.
            if (isMetaText(s)) continue
            val key = s.lowercase()
            if (key == originalLower) continue
            // v5.4.115cc — Also reject near-echoes of the original that
            // differ only by punctuation or spacing; they add a
            // duplicate FTS pass with zero new recall.
            if (normalizeForEcho(key) == normalizeForEcho(originalLower)) continue
            if (!seen.add(key)) continue
            // This line is syntactically valid regardless of topical
            // relevance — remember it for the soft-fallback path.
            allValidCandidates.add(s)
            // v5.4.115cc — Reject topical drift (strict gate).
            if (!isTopicallyRelevant(s, originalContent)) continue
            out += s
            if (out.size >= maxCount) break
        }
        if (out.isNotEmpty()) return out
        // v5.4.136cc — Strict gate rejected every candidate. Rather
        // than surface zero paraphrases (which reads as "LLM doesn't
        // work"), keep the single least-drifted valid candidate, if
        // any existed. A genuinely wild/unrelated model output (score
        // 0 on every candidate) still contributes nothing — this only
        // rescues candidates that had SOME vocabulary overlap the
        // strict all-or-nothing signals didn't quite clear.
        val best = allValidCandidates
            .map { it to topicalOverlapScore(it, originalContent) }
            .filter { it.second > 0 }
            .maxByOrNull { it.second }
        return if (best != null) listOf(best.first) else emptyList()
    }

    /**
     * v5.4.115cc — Does this line look like the model talking to us
     * rather than producing a query?
     *
     * SmolLM2-135M in particular is prone to prefacing its output
     * ("Here are three queries:") and to echoing section headers from
     * the prompt ("Focused retrieval queries:"). The old parser
     * accepted these — they're non-empty, within the length bounds, and
     * not an exact echo of the query — so they went straight into
     * retrieval as literal FTS searches for the word "Here", polluting
     * the fused result set.
     */
    private fun isMetaText(line: String): Boolean {
        val l = line.lowercase().trim()
        // A trailing colon almost always marks a header, not a query.
        if (l.endsWith(":")) return true
        // Must contain at least one letter to be a query at all.
        if (l.none { it.isLetter() }) return true
        return META_PREFIXES.any { l.startsWith(it) }
    }

    /**
     * v5.4.115cc — Topical-relevance gate.
     *
     * A paraphrase is only useful if it retrieves documents about the
     * *same subject*. A small model asked to rewrite "Was the Comma
     * Johanneum in the earliest manuscripts" will sometimes emit
     * something like "What is the meaning of life" — fluent, correctly
     * formatted, and completely unrelated. Nothing in the old parser
     * caught that, and because every sub-query contributed equally to
     * Reciprocal Rank Fusion, one drifted paraphrase could promote
     * genuinely irrelevant notes into the top results.
     *
     * The gate requires the paraphrase to share at least one
     * content-bearing token with the original, where "share" is
     * generous enough not to punish legitimate rewording:
     *   • exact token match, or
     *   • same synonym group (so "Jehovah" counts for "God"), or
     *   • edit distance ≤ 1 (morphology and the model's typos:
     *     "manuscript" vs "manuscripts"), or
     *   • one token contains the other as a substring, length ≥ 4
     *     (v5.4.136cc — catches morphological variants the curated
     *     ~300-word synonym table and edit-distance-1 both miss, e.g.
     *     "witness" / "witnessing", "sacrifice" / "sacrificial",
     *     "resurrect" / "resurrection". The synonym table only covers
     *     theological vocabulary explicitly enumerated in
     *     [synonymGroups] — a smaller model's paraphrase using a
     *     related-but-uncatalogued word was being rejected outright.)
     *
     * When the original has no content tokens at all (a one-word
     * function-word query), the gate passes everything rather than
     * rejecting everything.
     */
    private fun isTopicallyRelevant(
        paraphrase: String,
        originalContent: List<String>
    ): Boolean {
        if (originalContent.isEmpty()) return true
        val expander = com.tebogo.markvault.search.QueryExpander
        val candidateTokens = expander.contentTokens(paraphrase)
        if (candidateTokens.isEmpty()) return false
        for (candidate in candidateTokens) {
            for (source in originalContent) {
                if (candidate == source) return true
                if (expander.areSynonyms(candidate, source)) return true
                if (expander.editDistance(candidate, source, 1) <= 1) return true
                if (candidate.length >= 4 && source.length >= 4 &&
                    (candidate.contains(source) || source.contains(candidate))
                ) return true
            }
        }
        return false
    }

    /**
     * v5.4.136cc — Overlap score used ONLY by the soft-fallback path in
     * [parseParaphrases] when the strict [isTopicallyRelevant] gate
     * would otherwise reject every single candidate line. Counts how
     * many of the paraphrase's content tokens satisfy any of the same
     * four signals used by the strict gate, against any original token.
     * Higher = closer to the original's vocabulary. Used purely to
     * pick the "least drifted" candidate as a last resort, never to
     * admit a candidate the strict gate wouldn't otherwise question —
     * see the call site for exactly when this activates.
     */
    private fun topicalOverlapScore(
        paraphrase: String,
        originalContent: List<String>
    ): Int {
        if (originalContent.isEmpty()) return 0
        val expander = com.tebogo.markvault.search.QueryExpander
        val candidateTokens = expander.contentTokens(paraphrase)
        var score = 0
        for (candidate in candidateTokens) {
            for (source in originalContent) {
                if (candidate == source) { score += 3; continue }
                if (expander.areSynonyms(candidate, source)) { score += 2; continue }
                if (expander.editDistance(candidate, source, 1) <= 1) { score += 2; continue }
                if (candidate.length >= 4 && source.length >= 4 &&
                    (candidate.contains(source) || source.contains(candidate))
                ) { score += 1 }
            }
        }
        return score
    }

    /** Collapse punctuation/whitespace so near-echoes compare equal. */
    private fun normalizeForEcho(s: String): String =
        s.replace(Regex("[^\\p{L}\\p{N}]+"), " ").trim()

    companion object {
        /**
         * v5.4.80cc — Default paraphrase count when the slider preference
         * hasn't been touched. Kept as a fallback for tests / call sites
         * that construct an expander outside the ViewModel wiring.
         */
        const val DEFAULT_PARAPHRASE_COUNT = 3

        /**
         * v5.4.80cc — Slider ceiling. Matches Prefs' coercion range so
         * a spliced pref value can never request more.
         */
        const val MAX_PARAPHRASE_COUNT = 10

        /** Below this length we don't bother invoking the LLM. */
        const val MIN_QUERY_LEN = 2

        /** Sanity floor / ceiling on any individual paraphrase length. */
        private const val MIN_PARAPHRASE_LEN = 3
        private const val MAX_PARAPHRASE_LEN = 120

        /**
         * v5.4.115cc — Openers that mark a line as the model's
         * commentary rather than a retrieval query. Matched
         * case-insensitively against the start of the line.
         */
        private val META_PREFIXES = listOf(
            "here are", "here's", "here is", "sure", "okay", "ok,", "of course",
            "certainly", "the following", "below are", "these are",
            "query:", "queries:", "output:", "answer:", "result:", "results:",
            "rewritten", "paraphrase", "paraphrases", "original query",
            "focused retrieval", "retrieval queries", "note:", "explanation:",
            "i hope", "let me", "as an ai", "based on the"
        )

        /**
         * v5.4.80cc — Load timeout for memory-optimised mode.
         * SmolLM2-135M loads in ~1-2 s on the CPU backend, so 15 s is
         * a generous cap that still bows out quickly if the native
         * `Engine.initialize()` call has actually stalled (corrupt
         * file, memory-mapping failure, incompatible bundle).
         */
        private const val SHORT_LOAD_TIMEOUT_MS = 15_000L

        /**
         * v5.4.80cc — Load timeout for non-memory-optimised mode.
         * v5.4.142cc — Raised 45 s → 120 s (historic).
         * v5.5.40 — Capped at 35 s for responsive search; a cold model
         * that cannot load in this window safely falls back to retrieval.
         *
         * Gemma 4 E2B is a 2.59 GB file. On Snapdragon 732G with
         * typical eMMC / UFS read speeds, streaming that into RAM via
         * memory-mapping can take 30–60 s on a cold first run (OS page
         * cache is empty). The previous 45 s cap caused the LOAD step
         * itself to time out on some cold-launch paths, which looked
         * indistinguishable from an engine hang. 120 s gives Gemma
         * enough headroom on any supported device tier without risking
         * a hung-forever situation (a genuine stall at the JNI layer
         * will still fire the outer budget).
         */
        private const val LONG_LOAD_TIMEOUT_MS = 35_000L

        /**
         * Aggressive generate timeout used in memory-optimised mode.
         * Chosen per v5.4.79cc's memory-safety belt — the goal is to
         * bow out fast rather than hold the search hot path.
         */
        private const val SHORT_GENERATION_TIMEOUT_MS = 5_000L

        /**
         * v5.4.80cc — Generate timeout for non-memory-optimised mode.
         * v5.4.142cc — Raised 30 s → 180 s (historic).
         * v5.5.40 — Bound to 28 s for an interactive search; completed
         * paraphrases are retained even when the model times out.
         *
         * **Why 30 s was wrong for Gemma 4 E2B on Snapdragon 732G:**
         * The catalog comment quotes S26 Ultra benchmarks of 30–45
         * tokens/sec, which makes Gemma look fast. But on S732G (a
         * 2020 mid-range SoC), the same quantised 2B model generates
         * at only ~2–3 tokens/sec on the CPU backend. A typical
         * 3-paraphrase run needs:
         *   • ~150-token prefill  →  ~15 s at 10 tokens/sec prefill
         *   • ~40 output tokens   →  ~16 s at 2.5 tokens/sec decode
         *   • Total generate      →  ~31 s
         * The old 30 s cap fired during decode, cutting Gemma off every
         * single time and recording "0 paraphrases — cut off after 35 s"
         * in the history dialog.
         *
         * The interactive search now stops at the first complete set of
         * valid paraphrases or at the deadline. Very slow models can
         * produce fewer paraphrases than the slider target.
         */
        private const val LONG_GENERATION_TIMEOUT_MS = 28_000L

        /**
         * v5.4.137cc — How long the LLM path is skipped after a
         * timeout / engine-error run. 30 s balances "give the native
         * session time to settle" against "not too much dead time
         * for a user who's still typing". Cleared to 0 on any
         * successful (non-empty) run.
         */
        private const val COOLDOWN_AFTER_ERROR_MS = 30_000L

        /**
         * MB of free-RAM headroom demanded on top of the model's
         * declared peak RAM before we agree to load it. Covers the
         * transient allocation churn of `LlmManager.load` plus paint,
         * Room and WebView spikes.
         */
        private const val FREE_RAM_SAFETY_MARGIN_MB = 300
    }
}
