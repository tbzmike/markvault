package com.tebogo.markvault.ai

/** Validates the T5 execution chain before enabling model expansion. */
object T5ExecutionValidator {
    fun validate(loaderReady: Boolean, tokenizerReady: Boolean): Boolean {
        return loaderReady && tokenizerReady
    }
}
