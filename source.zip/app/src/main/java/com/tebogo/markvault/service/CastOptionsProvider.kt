package com.tebogo.markvault.service

import android.content.Context
import com.google.android.gms.cast.framework.CastOptions
import com.google.android.gms.cast.framework.OptionsProvider
import com.google.android.gms.cast.framework.SessionProvider

/**
 * v5.4.247cc — Required by the Google Cast SDK.
 *
 * Declared in AndroidManifest via the
 * `com.google.android.gms.cast.framework.OPTIONS_PROVIDER_CLASS_NAME`
 * meta-data key. The Cast framework discovers this class automatically on
 * the first CastContext.getSharedInstance() call and uses it to configure
 * the Cast session.
 *
 * CC1AD845 is Google's built-in Default Media Receiver application — it
 * works for personal use with NO Cast developer account or registration
 * required. The Chromecast's own system UI handles playback display and
 * controls when casting. Custom branding would require registering a
 * custom receiver app at cast.google.com/publish, which is unnecessary
 * for a personal Bible-study tool.
 */
class CastOptionsProvider : OptionsProvider {

    override fun getCastOptions(context: Context): CastOptions =
        CastOptions.Builder()
            .setReceiverApplicationId(DEFAULT_APP_ID)
            .build()

    override fun getAdditionalSessionProviders(context: Context): List<SessionProvider> =
        emptyList()

    companion object {
        /** Google's built-in Default Media Receiver — no registration needed. */
        private const val DEFAULT_APP_ID = "CC1AD845"
    }
}
