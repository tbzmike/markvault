package com.tebogo.markvault.web

object ArticleDetectorJs {
    fun queryArticleLinks(): String = """
    (function() {
        const articles = Array.from(document.querySelectorAll('article, .article, .post, a'))
            .map(e => e.href || e.querySelector('a')?.href)
            .filter(Boolean);
        return JSON.stringify([...new Set(articles)]);
    })()
    """.trimIndent()
}
