package com.tebogo.markvault.web

object ArticleDetectorJs {

    fun queryArticleLinks(): String = """
    (function(){
      const nodes=[...document.querySelectorAll("article, main article, .article, .post")];
      return JSON.stringify(nodes.map(n=>({
        url:n.querySelector("a")?.href || location.href,
        title:n.querySelector("h1,h2,h3")?.innerText || document.title
      })));
    })()
    """.trimIndent()

    fun extractReadableArticle(): String = """
    (function(){
      try {
        if (typeof Readability === "undefined") {
          return JSON.stringify({html: document.documentElement.outerHTML, title: document.title});
        }
        const article = new Readability(document.cloneNode(true)).parse();
        return JSON.stringify({
          title: article.title || document.title,
          html: article.content || ""
        });
      } catch(e) {
        return JSON.stringify({html:"", title:document.title});
      }
    })()
    """.trimIndent()
}
