package com.tebogo.markvault.web

object ArticleDetectorJs {

    fun queryArticleLinks(): String = """
    (function(){
      const nodes=[...document.querySelectorAll("article, main article, .article, .post")];
      return JSON.stringify(nodes.map(n=>({
        url:n.querySelector("a")?.href || location.href,
        title:n.querySelector("h1,h2,h3")?.innerText || document.title
      })));
    })()
    """.trimIndent()

    fun extractReadableArticles(): String = """
    (function(){
      const nodes=[...document.querySelectorAll("article, main article, .article, .post")];
      const source = nodes.length ? nodes : [document.body];

      return JSON.stringify(source.map(function(node){
        try {
          const clone = node.cloneNode(true);
          if (typeof Readability !== "undefined") {
            const parsed = new Readability(clone).parse();
            return {
              url: node.querySelector("a")?.href || location.href,
              title: parsed?.title || document.title,
              html: parsed?.content || node.innerHTML
            };
          }
          return {
            url: node.querySelector("a")?.href || location.href,
            title: document.title,
            html: node.innerHTML
          };
        } catch(e) {
          return {
            url: location.href,
            title: document.title,
            html: node.innerHTML
          };
        }
      }));
    })()
    """.trimIndent()
}
