package com.tebogo.markvault.web

object ArticleDetectorJs {

    const val SCRIPT = """
    (function() {
        let links = [...document.querySelectorAll('a')]
            .map(a => a.href)
            .filter(h => h && h.startsWith('http'));

        return JSON.stringify([...new Set(links)]);
    })()
    """
}
