
package com.tebogo.markvault.web

object ArticleDetectorJs {
    fun detectArticles(): String = """
    (function(){
      const nodes=[...document.querySelectorAll("article, main article, .article, .post")];
      return JSON.stringify(nodes.map(n=>({
        url:n.querySelector("a")?.href || location.href,
        title:n.querySelector("h1,h2,h3")?.innerText || document.title,
        html:n.outerHTML
      })));
    })()
    """.trimIndent()
}
