package com.tebogo.markvault.web

/**
 * v5.4.79 — Trusted scripture site detection.
 */
object ScriptureWebHandler {

    fun isScriptureSite(url: String?): Boolean {
        if (url == null) return false

        return url.contains("jw.org", true) ||
            url.contains("wol.jw.org", true)
    }
}
