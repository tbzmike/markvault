package com.tebogo.markvault.ai

data class RetrievalModelInfo(
    val name: String,
    val installed: Boolean,
    val recommended: Boolean = false
)

/**
 * v5.4.60 — Offline retrieval model catalog.
 */
object RetrievalModelCatalog {

    fun models(): List<RetrievalModelInfo> = listOf(
        RetrievalModelInfo(
            name = "Qwen 2.5 1.5B Instruct (Q8) — recommended for 6 GB devices",
            installed = false,
            recommended = true
        ),
        RetrievalModelInfo(
            name = "Qwen 3 0.6B (mixed INT4) — lightweight fallback",
            installed = true
        ),
        RetrievalModelInfo(
            name = "Phi-4 Mini Instruct (3.8B) — high quality, high memory",
            installed = false
        ),
        RetrievalModelInfo(
            name = "Qwen 3 4B (channel INT8) — high memory expansion model",
            installed = false
        )
    )
}
