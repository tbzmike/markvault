package com.tebogo.markvault.ai

data class RetrievalModelInfo(
    val name: String,
    val installed: Boolean
)

/**
 * v5.4.120cc — Lightweight display-only catalog for the retrieval-side model
 * picker. Kept as a thin wrapper so the AI settings UI has something to
 * enumerate without pulling in [com.tebogo.markvault.llm.ChatModelCatalog]
 * directly. Mirrors the models actually shipped in that catalog.
 *
 * v5.4.120cc: replaced Phi-4-mini with Qwen3 4B Instruct 2507 to match
 * the removal of Phi-4-mini and Qwen3 0.6B from ChatModelCatalog.
 */
object RetrievalModelCatalog {

    fun models(): List<RetrievalModelInfo> = listOf(
        RetrievalModelInfo(
            "Qwen3 4B",
            true
        )
    )
}
