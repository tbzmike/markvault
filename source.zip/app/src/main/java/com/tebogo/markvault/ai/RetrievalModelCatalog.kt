package com.tebogo.markvault.ai

data class RetrievalModelInfo(
    val name: String,
    val installed: Boolean
)

object RetrievalModelCatalog {

    fun models(): List<RetrievalModelInfo> = listOf(
        RetrievalModelInfo(
            "Gemma 3 Qwen 0.6B",
            true
        )
    )
}
