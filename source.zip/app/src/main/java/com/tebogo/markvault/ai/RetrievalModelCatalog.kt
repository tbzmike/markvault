package com.tebogo.markvault.ai

data class RetrievalModelInfo(
    val name: String,
    val installed: Boolean
)

/**
 * v5.4.59 — Informational catalog of retrieval models available for
 * multi-query expansion. Actual install-state is checked live via
 * [com.tebogo.markvault.llm.ChatModelDescriptor.isInstalled] in AppViewModel.
 */
object RetrievalModelCatalog {

    fun models(): List<RetrievalModelInfo> = listOf(
        RetrievalModelInfo(
            name = "Qwen 3 0.6B (mixed INT4) — default, safe on 6 GB",
            installed = true
        ),
        RetrievalModelInfo(
            name = "Qwen 3 4B (channel INT8) — better expansion, requires \u22658 GB RAM",
            installed = false   // install state resolved live in AppViewModel
        )
    )
}
