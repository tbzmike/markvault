package com.tebogo.markvault.ai

data class RetrievalModelInfo(
    val name: String,
    val installed: Boolean,
    val recommended: Boolean = false
)

/**
 * v5.4.73 — Informational catalog.
 * Actual install state is checked live via ChatModelDescriptor.isInstalled().
 */
object RetrievalModelCatalog {

    fun models(): List<RetrievalModelInfo> = listOf(
        RetrievalModelInfo(
            name = "Qwen 3 0.6B (mixed INT4) \u2014 lightweight default",
            installed = true
        ),
        RetrievalModelInfo(
            name = "Qwen 2.5 1.5B Instruct (INT8) \u2B50 recommended",
            installed = false,
            recommended = true
        ),
        RetrievalModelInfo(
            name = "Qwen 3 4B (channel INT8) \u2014 strongest, high memory",
            installed = false
        )
    )
}
