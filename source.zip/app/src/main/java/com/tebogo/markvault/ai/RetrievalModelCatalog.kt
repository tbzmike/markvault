package com.tebogo.markvault.ai

data class RetrievalModelInfo(
    val name: String,
    val installed: Boolean
)

/**
 * v5.4.74cc — Lightweight display-only catalog for the retrieval-side model
 * picker. Kept as a thin wrapper so the AI settings UI has something to
 * enumerate without pulling in [com.tebogo.markvault.llm.ChatModelCatalog]
 * directly. Mirrors the model actually shipped in that catalog.
 */
object RetrievalModelCatalog {

    fun models(): List<RetrievalModelInfo> = listOf(
        RetrievalModelInfo(
            "Qwen 2.5 3B",
            true
        )
    )
}
