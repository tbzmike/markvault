package com.tebogo.markvault.search

import androidx.sqlite.db.SupportSQLiteDatabase

/** An atomic notes-write revision. A missed/asynchronous Room invalidation cannot reuse stale FTS hits. */
object BlueKeywordRevision {
    @Volatile private var installedDatabase: SupportSQLiteDatabase? = null
    private val lock = Any()

    fun current(db: SupportSQLiteDatabase): Long? = runCatching {
        if (installedDatabase !== db) synchronized(lock) {
            if (installedDatabase !== db) {
                db.beginTransaction()
                try {
                    db.execSQL("CREATE TABLE IF NOT EXISTS markvault_blue_keyword_revision (id INTEGER PRIMARY KEY CHECK(id = 1), revision INTEGER NOT NULL)")
                    db.execSQL("INSERT OR IGNORE INTO markvault_blue_keyword_revision(id, revision) VALUES (1, 0)")
                    for (operation in listOf("INSERT", "UPDATE", "DELETE")) {
                        db.execSQL("CREATE TRIGGER IF NOT EXISTS markvault_blue_keyword_${operation.lowercase()} AFTER $operation ON notes BEGIN UPDATE markvault_blue_keyword_revision SET revision = revision + 1 WHERE id = 1; END")
                    }
                    db.setTransactionSuccessful()
                } finally { db.endTransaction() }
                installedDatabase = db
            }
        }
        db.query("SELECT revision FROM markvault_blue_keyword_revision WHERE id = 1").use { cursor ->
            if (cursor.moveToFirst()) cursor.getLong(0) else null
        }
    }.getOrNull()
}
