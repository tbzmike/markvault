package com.tebogo.markvault.ui

import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.Checkbox
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateMapOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.navigation.NavController
import com.tebogo.markvault.AppViewModel
import com.tebogo.markvault.data.NoteMeta
import kotlinx.coroutines.launch

/**
 * v5.4.34 — Duplicate Detection screen. Scans the vault for articles
 * with identical content (SHA-256 hash match), lets the user compare
 * them side-by-side, and delete selected duplicates with password
 * protection.
 */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun DuplicatesScreen(vm: AppViewModel, nav: NavController) {
    val scope = rememberCoroutineScope()
    var scanning by remember { mutableStateOf(false) }
    var scanned by remember { mutableStateOf(false) }
    var groups by remember { mutableStateOf<List<AppViewModel.DuplicateGroup>>(emptyList()) }
    val selected = remember { mutableStateMapOf<Long, Boolean>() }
    val storedPwHash by vm.duplicateDeletePassword.collectAsStateWithLifecycle()
    val hasPassword = storedPwHash.isNotBlank()

    // Dialogs
    var showSetPassword by remember { mutableStateOf(false) }
    var showEnterPassword by remember { mutableStateOf(false) }
    var showCompare by remember { mutableStateOf<Pair<NoteMeta, NoteMeta>?>(null) }
    var deleteError by remember { mutableStateOf<String?>(null) }

    // Auto-scan on entry
    LaunchedEffect(Unit) {
        scanning = true
        groups = vm.findDuplicates()
        scanning = false
        scanned = true
    }

    Scaffold(
        topBar = {
            TopAppBar(
                navigationIcon = {
                    IconButton(onClick = { nav.popBackStack() }) {
                        Icon(Icons.Default.ArrowBack, "Back")
                    }
                },
                title = {
                    Text(
                        "\uD83D\uDD0D Duplicate Detector",
                        fontWeight = FontWeight.Bold
                    )
                },
                actions = {
                    // Rescan button
                    IconButton(onClick = {
                        scope.launch {
                            scanning = true
                            selected.clear()
                            groups = vm.findDuplicates()
                            scanning = false
                            scanned = true
                        }
                    }) {
                        Text("\uD83D\uDD04", fontSize = 18.sp)
                    }
                }
            )
        }
    ) { pad ->
        Column(
            Modifier
                .padding(pad)
                .fillMaxSize()
                .padding(horizontal = 16.dp)
        ) {
            // Status bar
            if (scanning) {
                Row(
                    Modifier.fillMaxWidth().padding(vertical = 12.dp),
                    horizontalArrangement = Arrangement.Center,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    androidx.compose.material3.CircularProgressIndicator(
                        modifier = Modifier.size(20.dp),
                        strokeWidth = 2.dp
                    )
                    Spacer(Modifier.width(10.dp))
                    Text("Scanning vault for duplicates\u2026", fontSize = 13.sp)
                }
                // v5.4.160cc — Shimmer skeleton placeholders. Scanning
                // 14,000+ files for SHA-256 duplicates can take a real,
                // noticeable moment — the small spinner above communicated
                // "something is happening" but left the entire results
                // area blank underneath. These placeholder blocks mimic
                // the shape of a real duplicate-group header + 2 note
                // rows, so the screen reads as "your results are being
                // assembled" rather than "empty."
                DuplicatesScanningSkeleton()
            } else if (scanned && groups.isEmpty()) {
                Column(
                    Modifier.fillMaxWidth().padding(vertical = 24.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Text("\u2705", fontSize = 40.sp)
                    Spacer(Modifier.height(8.dp))
                    Text("No duplicates found!", fontSize = 16.sp,
                        fontWeight = FontWeight.SemiBold)
                    Text("Your vault is clean.", fontSize = 13.sp,
                        color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
            } else if (scanned) {
                val totalDupes = groups.sumOf { it.notes.size - 1 }
                val selectedCount = selected.count { it.value }
                Row(
                    Modifier.fillMaxWidth().padding(vertical = 8.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column {
                        Text(
                            "${groups.size} duplicate group(s) found",
                            fontSize = 14.sp,
                            fontWeight = FontWeight.SemiBold
                        )
                        Text(
                            "$totalDupes extra copies can be removed",
                            fontSize = 12.sp,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                    if (selectedCount > 0) {
                        Button(
                            onClick = {
                                if (!hasPassword) {
                                    showSetPassword = true
                                } else {
                                    showEnterPassword = true
                                }
                            }
                        ) {
                            Icon(Icons.Default.Delete, null, Modifier.size(16.dp))
                            Spacer(Modifier.width(4.dp))
                            Text("Delete ($selectedCount)")
                        }
                    }
                }
                HorizontalDivider()

                // Duplicate groups list
                LazyColumn(
                    Modifier.weight(1f).fillMaxWidth(),
                    verticalArrangement = Arrangement.spacedBy(8.dp),
                    contentPadding = PaddingValues(vertical = 8.dp)
                ) {
                    groups.forEachIndexed { gi, group ->
                        item(key = "header-$gi") {
                            Surface(
                                color = MaterialTheme.colorScheme.errorContainer.copy(alpha = 0.3f),
                                shape = RoundedCornerShape(8.dp),
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                Column(Modifier.padding(10.dp)) {
                                    Text(
                                        "\u26A0\uFE0F Duplicate group ${gi + 1}",
                                        fontSize = 13.sp,
                                        fontWeight = FontWeight.Bold
                                    )
                                    Text(
                                        group.reason,
                                        fontSize = 11.sp,
                                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                                        lineHeight = 15.sp
                                    )
                                    Text(
                                        "Hash: ${group.hash}\u2026",
                                        fontSize = 10.sp,
                                        color = MaterialTheme.colorScheme.onSurfaceVariant
                                    )
                                }
                            }
                        }
                        items(group.notes, key = { "note-${it.id}" }) { note ->
                            val isFirst = note == group.notes.first()
                            val isChecked = selected[note.id] == true
                            Surface(
                                color = if (isFirst)
                                    MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.2f)
                                else
                                    MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.3f),
                                shape = RoundedCornerShape(8.dp),
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                Row(
                                    Modifier.padding(8.dp),
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Checkbox(
                                        checked = isChecked,
                                        onCheckedChange = { selected[note.id] = it }
                                    )
                                    Column(Modifier.weight(1f)) {
                                        Row(verticalAlignment = Alignment.CenterVertically) {
                                            if (isFirst) {
                                                Surface(
                                                    color = MaterialTheme.colorScheme.primary,
                                                    shape = RoundedCornerShape(4.dp)
                                                ) {
                                                    Text(
                                                        " ORIGINAL ",
                                                        fontSize = 9.sp,
                                                        color = MaterialTheme.colorScheme.onPrimary,
                                                        fontWeight = FontWeight.Bold
                                                    )
                                                }
                                                Spacer(Modifier.width(6.dp))
                                            }
                                            Text(
                                                note.title,
                                                fontSize = 13.sp,
                                                fontWeight = FontWeight.Medium,
                                                maxLines = 2,
                                                overflow = TextOverflow.Ellipsis,
                                                modifier = Modifier.weight(1f, fill = false)
                                            )
                                        }
                                        Text(
                                            note.relPath,
                                            fontSize = 11.sp,
                                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                                            maxLines = 2,
                                            overflow = TextOverflow.Ellipsis
                                        )
                                    }
                                    // Compare button: compare this note with the first in group
                                    if (!isFirst) {
                                        IconButton(
                                            onClick = {
                                                showCompare = group.notes.first() to note
                                            },
                                            modifier = Modifier.size(32.dp)
                                        ) {
                                            Text("\uD83D\uDD0E", fontSize = 14.sp)
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }

            // Password notice
            if (scanned && groups.isNotEmpty()) {
                Surface(
                    color = MaterialTheme.colorScheme.surfaceVariant,
                    shape = RoundedCornerShape(8.dp),
                    modifier = Modifier.fillMaxWidth().padding(vertical = 8.dp)
                ) {
                    Row(
                        Modifier.padding(12.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text("\uD83D\uDD12", fontSize = 20.sp)
                        Spacer(Modifier.width(10.dp))
                        Column(Modifier.weight(1f)) {
                            Text(
                                if (hasPassword) "Deletion password is set"
                                else "No deletion password set yet",
                                fontSize = 12.sp,
                                fontWeight = FontWeight.Medium
                            )
                            Text(
                                if (hasPassword) "You\u2019ll be asked for it before any deletion."
                                else "You\u2019ll be asked to create one before your first deletion.",
                                fontSize = 11.sp,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                        if (hasPassword) {
                            TextButton(onClick = { showSetPassword = true }) {
                                Text("Change", fontSize = 11.sp)
                            }
                        }
                    }
                }
            }
        }
    }

    // ── Set Password dialog ──
    if (showSetPassword) {
        var pw1 by remember { mutableStateOf("") }
        var pw2 by remember { mutableStateOf("") }
        var pwError by remember { mutableStateOf<String?>(null) }

        AlertDialog(
            onDismissRequest = { showSetPassword = false },
            title = { Text("\uD83D\uDD10 Set deletion password") },
            text = {
                Column {
                    Text(
                        "This password protects against accidental deletion. " +
                            "It\u2019s only used here, not for the app itself.",
                        fontSize = 12.sp,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                    Spacer(Modifier.height(12.dp))
                    OutlinedTextField(
                        value = pw1,
                        onValueChange = { pw1 = it; pwError = null },
                        label = { Text("Password") },
                        visualTransformation = PasswordVisualTransformation(),
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth()
                    )
                    Spacer(Modifier.height(8.dp))
                    OutlinedTextField(
                        value = pw2,
                        onValueChange = { pw2 = it; pwError = null },
                        label = { Text("Confirm password") },
                        visualTransformation = PasswordVisualTransformation(),
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth()
                    )
                    if (pwError != null) {
                        Spacer(Modifier.height(4.dp))
                        Text(pwError!!, fontSize = 12.sp, color = MaterialTheme.colorScheme.error)
                    }
                }
            },
            confirmButton = {
                Button(onClick = {
                    when {
                        pw1.length < 4 -> pwError = "At least 4 characters required."
                        pw1 != pw2 -> pwError = "Passwords don\u2019t match."
                        else -> {
                            vm.setDuplicateDeletePassword(pw1)
                            showSetPassword = false
                            // If we were trying to delete, now ask for it
                            if (selected.count { it.value } > 0) {
                                showEnterPassword = true
                            }
                        }
                    }
                }) { Text("Save") }
            },
            dismissButton = {
                TextButton(onClick = { showSetPassword = false }) { Text("Cancel") }
            }
        )
    }

    // ── Enter Password dialog (before deletion) ──
    if (showEnterPassword) {
        var pw by remember { mutableStateOf("") }
        var pwError by remember { mutableStateOf<String?>(null) }
        val idsToDelete = selected.filter { it.value }.keys.toList()

        AlertDialog(
            onDismissRequest = { showEnterPassword = false },
            title = { Text("\uD83D\uDD12 Confirm deletion") },
            text = {
                Column {
                    Text(
                        "You are about to permanently delete ${idsToDelete.size} article(s). " +
                            "Enter your deletion password to confirm.",
                        fontSize = 12.sp
                    )
                    Spacer(Modifier.height(12.dp))
                    OutlinedTextField(
                        value = pw,
                        onValueChange = { pw = it; pwError = null },
                        label = { Text("Deletion password") },
                        visualTransformation = PasswordVisualTransformation(),
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth()
                    )
                    if (pwError != null) {
                        Spacer(Modifier.height(4.dp))
                        Text(pwError!!, fontSize = 12.sp, color = MaterialTheme.colorScheme.error)
                    }
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        if (vm.verifyDuplicatePassword(pw)) {
                            vm.deleteNotesByIds(idsToDelete)
                            // Remove deleted notes from groups
                            groups = groups.mapNotNull { g ->
                                val remaining = g.notes.filter { it.id !in idsToDelete }
                                if (remaining.size >= 2) g.copy(notes = remaining)
                                else null
                            }
                            selected.clear()
                            showEnterPassword = false
                        } else {
                            pwError = "Wrong password."
                        }
                    },
                    colors = androidx.compose.material3.ButtonDefaults.buttonColors(
                        containerColor = MaterialTheme.colorScheme.error
                    )
                ) { Text("Delete permanently") }
            },
            dismissButton = {
                TextButton(onClick = { showEnterPassword = false }) { Text("Cancel") }
            }
        )
    }

    // ── Split-screen comparison bottom sheet ──
    if (showCompare != null) {
        val (noteA, noteB) = showCompare!!
        var contentA by remember { mutableStateOf<String?>(null) }
        var contentB by remember { mutableStateOf<String?>(null) }

        LaunchedEffect(noteA.id, noteB.id) {
            contentA = vm.getContentForComparison(noteA.id)
            contentB = vm.getContentForComparison(noteB.id)
        }

        ModalBottomSheet(
            onDismissRequest = { showCompare = null }
        ) {
            Column(Modifier.fillMaxWidth().padding(horizontal = 12.dp)) {
                Text(
                    "\uD83D\uDD0E Side-by-side comparison",
                    fontSize = 16.sp,
                    fontWeight = FontWeight.Bold
                )
                Spacer(Modifier.height(4.dp))
                Text(
                    "Verify these are truly identical before deleting.",
                    fontSize = 11.sp,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
                Spacer(Modifier.height(8.dp))
                // Two columns side by side
                Row(
                    Modifier
                        .fillMaxWidth()
                        .heightIn(max = 400.dp),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    // Left: Article A (original)
                    Column(
                        Modifier
                            .weight(1f)
                            .fillMaxHeight()
                            .background(
                                MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.15f),
                                RoundedCornerShape(8.dp)
                            )
                            .padding(8.dp)
                    ) {
                        Surface(
                            color = MaterialTheme.colorScheme.primary,
                            shape = RoundedCornerShape(4.dp)
                        ) {
                            Text(
                                " ORIGINAL ",
                                fontSize = 9.sp,
                                color = MaterialTheme.colorScheme.onPrimary,
                                fontWeight = FontWeight.Bold
                            )
                        }
                        Spacer(Modifier.height(4.dp))
                        Text(
                            noteA.title,
                            fontSize = 12.sp,
                            fontWeight = FontWeight.SemiBold,
                            maxLines = 2,
                            overflow = TextOverflow.Ellipsis
                        )
                        Text(
                            noteA.relPath,
                            fontSize = 9.sp,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis
                        )
                        HorizontalDivider(Modifier.padding(vertical = 4.dp))
                        Text(
                            contentA?.take(1500) ?: "Loading\u2026",
                            fontSize = 10.sp,
                            lineHeight = 14.sp,
                            modifier = Modifier
                                .weight(1f)
                                .verticalScroll(rememberScrollState())
                        )
                    }
                    // Right: Article B (duplicate)
                    Column(
                        Modifier
                            .weight(1f)
                            .fillMaxHeight()
                            .background(
                                MaterialTheme.colorScheme.errorContainer.copy(alpha = 0.15f),
                                RoundedCornerShape(8.dp)
                            )
                            .padding(8.dp)
                    ) {
                        Surface(
                            color = MaterialTheme.colorScheme.error,
                            shape = RoundedCornerShape(4.dp)
                        ) {
                            Text(
                                " DUPLICATE ",
                                fontSize = 9.sp,
                                color = MaterialTheme.colorScheme.onError,
                                fontWeight = FontWeight.Bold
                            )
                        }
                        Spacer(Modifier.height(4.dp))
                        Text(
                            noteB.title,
                            fontSize = 12.sp,
                            fontWeight = FontWeight.SemiBold,
                            maxLines = 2,
                            overflow = TextOverflow.Ellipsis
                        )
                        Text(
                            noteB.relPath,
                            fontSize = 9.sp,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis
                        )
                        HorizontalDivider(Modifier.padding(vertical = 4.dp))
                        Text(
                            contentB?.take(1500) ?: "Loading\u2026",
                            fontSize = 10.sp,
                            lineHeight = 14.sp,
                            modifier = Modifier
                                .weight(1f)
                                .verticalScroll(rememberScrollState())
                        )
                    }
                }
                Spacer(Modifier.height(8.dp))
                // Verdict
                if (contentA != null && contentB != null) {
                    val identical = contentA == contentB
                    Surface(
                        color = if (identical)
                            MaterialTheme.colorScheme.errorContainer
                        else
                            MaterialTheme.colorScheme.primaryContainer,
                        shape = RoundedCornerShape(6.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Text(
                            if (identical)
                                "\u26A0\uFE0F Content is byte-for-byte identical. Safe to delete one copy."
                            else
                                "\u2705 Content differs! These may NOT be true duplicates.",
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Medium,
                            modifier = Modifier.padding(10.dp)
                        )
                    }
                }
                Spacer(Modifier.height(12.dp))
                OutlinedButton(
                    onClick = { showCompare = null },
                    modifier = Modifier.fillMaxWidth()
                ) { Text("Close comparison") }
                Spacer(Modifier.height(16.dp))
            }
        }
    }
}

/**
 * v5.4.160cc — A single pulsing placeholder block: a solid rounded
 * rectangle whose alpha breathes between dim and brighter on an endless
 * loop. This is the "shimmer" — simpler than a traveling gradient sweep
 * (no Brush/Offset machinery needed), but reads exactly the same way to
 * the user: a calm, obviously-still-loading placeholder shape.
 */
@Composable
private fun ShimmerBlock(modifier: Modifier = Modifier) {
    val transition = rememberInfiniteTransition(label = "dupeShimmer")
    val shimmerAlpha by transition.animateFloat(
        initialValue = 0.25f,
        targetValue = 0.55f,
        animationSpec = infiniteRepeatable(
            animation = tween(750, easing = LinearEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "dupeShimmerAlpha"
    )
    Box(
        modifier = modifier
            .clip(RoundedCornerShape(6.dp))
            .background(MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = shimmerAlpha))
    )
}

/**
 * v5.4.160cc — Skeleton placeholder for the duplicate-scan results area.
 * Shows 2 fake "duplicate group" blocks, each shaped like a real group:
 * a header bar (mimics the "Duplicate group N" + reason + hash text)
 * followed by 2 note-row bars (mimics the checkbox + title rows). Purely
 * decorative — no real data — shown only while [scanning] is true.
 */
@Composable
private fun DuplicatesScanningSkeleton() {
    Column(
        Modifier
            .fillMaxWidth()
            .padding(top = 8.dp),
        verticalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        repeat(2) {
            // Header block: title-width bar + narrower reason/hash bars.
            Column(
                Modifier
                    .fillMaxWidth()
                    .padding(10.dp),
                verticalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                ShimmerBlock(Modifier.fillMaxWidth(0.55f).height(14.dp))
                ShimmerBlock(Modifier.fillMaxWidth(0.85f).height(11.dp))
                ShimmerBlock(Modifier.fillMaxWidth(0.35f).height(10.dp))
            }
            // Two note rows underneath.
            repeat(2) {
                Row(
                    Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 10.dp, vertical = 4.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    ShimmerBlock(Modifier.size(20.dp))
                    Spacer(Modifier.width(10.dp))
                    ShimmerBlock(Modifier.weight(1f).height(16.dp))
                }
            }
        }
    }
}

