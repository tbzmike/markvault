package com.tebogo.markvault.ai

import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import java.util.concurrent.atomic.AtomicReference

/**
 * v5.4.115cc — Full record of the *query plan* behind each search.
 *
 * ## Why this exists alongside [LlmExpansionHistory]
 *
 * [LlmExpansionHistory] only ever captured the LLM's paraphrases. But
 * a MarkVault search fans out across two independent expanders:
 *
 *   • the **non-LLM** synonym expander
 *     ([com.tebogo.markvault.search.QueryExpander]), which substitutes
 *     theologically-equivalent terms, and
 *   • the **LLM** paraphraser
 *     ([com.tebogo.markvault.llm.LlmQueryExpander]).
 *
 * The history dialog could therefore only ever show half the picture —
 * the LLM half — and the synonym variants that did most of the recall
 * work were invisible. This store records *every* sub-query that was
 * actually issued, tagged with where it came from and how much the
 * fusion layer weighted it, so the user can see and audit the whole
 * plan.
 *
 * ## Storage model
 *
 * Mirrors [LlmExpansionHistory] exactly: lower-cased-query-keyed map in
 * an [AtomicReference], capped at [MAX_ENTRIES] with oldest-first
 * eviction, exposed as a [StateFlow]. In-memory only — cleared on
 * process death, same as the LLM history.
 */

/** Where a generated sub-query came from. */
enum class QuerySource {
    /** The user's own words, verbatim. Always weight 1.0. */
    ORIGINAL,

    /** Produced by the offline synonym expander. No model involved. */
    SYNONYM,

    /** Produced by the on-device LLM paraphraser. */
    LLM,

    /** Produced by the T5-base paraphrase expansion engine. */
    T5
}

/**
 * One sub-query that was actually issued against the index.
 *
 * @param weight the trust weight the fusion layer applied. Higher means
 *        this sub-query's rankings counted for more in the final order.
 */
data class GeneratedQuery(
    val text: String,
    val source: QuerySource,
    val weight: Double
)

data class QueryPlanRecord(
    /** The original query the user typed, post-trim. */
    val query: String,
    /** Every sub-query issued, including the original at index 0. */
    val generated: List<GeneratedQuery>,
    val timestampMs: Long,
    /** Whether semantic search was on for this run. */
    val semanticOn: Boolean,
    /**
     * The multi-query budget in force (the Settings slider value). Each
     * expander was allowed to contribute up to this many sub-queries on
     * top of the original.
     */
    val budget: Int
) {
    val synonymQueries: List<GeneratedQuery>
        get() = generated.filter { it.source == QuerySource.SYNONYM }

    val llmQueries: List<GeneratedQuery>
        get() = generated.filter { it.source == QuerySource.LLM }
}

object QueryPlanHistory {

    /** Maximum number of distinct queries kept. */
    const val MAX_ENTRIES = 200

    private val store = AtomicReference<Map<String, QueryPlanRecord>>(emptyMap())
    private val _entries = MutableStateFlow<Map<String, QueryPlanRecord>>(emptyMap())

    /** Observable snapshot for UI. */
    val entries: StateFlow<Map<String, QueryPlanRecord>> = _entries.asStateFlow()

    /** Look up the plan recorded for a query. Case-insensitive. */
    fun get(query: String): QueryPlanRecord? {
        val key = normalise(query) ?: return null
        return store.get()[key]
    }

    /** Insert or replace a plan record. Thread-safe. */
    fun record(rec: QueryPlanRecord) {
        val key = normalise(rec.query) ?: return
        while (true) {
            val cur = store.get()
            val next = HashMap<String, QueryPlanRecord>(cur)
            next[key] = rec
            if (next.size > MAX_ENTRIES) {
                val victimKey = next.entries.minByOrNull { it.value.timestampMs }?.key
                if (victimKey != null && victimKey != key) next.remove(victimKey)
            }
            if (store.compareAndSet(cur, next)) {
                _entries.value = next
                return
            }
            // Lost the race — retry against the new baseline.
        }
    }

    fun clear() {
        store.set(emptyMap())
        _entries.value = emptyMap()
    }

    private fun normalise(q: String): String? {
        val t = q.trim().lowercase()
        return if (t.isEmpty()) null else t
    }
}
