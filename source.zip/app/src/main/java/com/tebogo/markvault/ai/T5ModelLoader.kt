package com.tebogo.markvault.ai

/**
 * Loads T5 model artifacts from the local model store.
 */
class T5ModelLoader {
    fun isAvailable(): Boolean {
        return T5ModelManager.isInstalled()
    }
}
