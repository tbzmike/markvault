package com.tebogo.markvault.ui

import androidx.compose.material3.ColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.staticCompositionLocalOf
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Shape
import androidx.compose.ui.graphics.lerp
import androidx.compose.ui.draw.shadow
import androidx.compose.foundation.border
import androidx.compose.material3.MaterialTheme
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.ui.unit.dp

/**
 * Visual language used only by MarkVault's depth/"4D" themes.
 *
 * The ColorScheme still remains the single source of truth for readable text
 * and component colors.  This profile adds restrained depth, alternating tile
 * tones, and theme-specific geometry without introducing animated gradients or
 * per-frame effects.  That keeps the look premium rather than cartoonish and
 * avoids battery/performance regressions.
 */
data class FourDThemeStyle(
    val enabled: Boolean = false,
    val searchCornerDp: Int = 12,
    val cardCornerPattern: List<Int> = listOf(12),
    val tileColors: List<Color> = emptyList(),
    val resultElevationDp: Int = 3,
    val searchElevationDp: Int = 0
)

val LocalFourDThemeStyle = staticCompositionLocalOf { FourDThemeStyle() }

fun fourDThemeStyleFor(themeName: String?, scheme: ColorScheme): FourDThemeStyle {
    if (!isFourDTheme(themeName)) return FourDThemeStyle()

    val corners = when (themeName) {
        "4d_titanium" -> listOf(8, 14, 10, 16)
        "4d_quartz" -> listOf(18, 26, 20, 30)
        "4d_emerald" -> listOf(12, 22, 16, 26)
        "4d_sapphire" -> listOf(10, 20, 14, 24)
        "4d_crimson" -> listOf(8, 18, 12, 22)
        else -> listOf(14, 24, 18, 28) // Aurora
    }

    // Each result gets a related but visibly different tonal surface.  We
    // blend from the theme's own readable Material roles rather than inventing
    // arbitrary raw colors, so text can consistently remain onSurface.
    val tones = listOf(
        lerp(scheme.surface, scheme.primaryContainer, 0.38f),
        lerp(scheme.surface, scheme.secondaryContainer, 0.34f),
        lerp(scheme.surface, scheme.tertiaryContainer, 0.32f),
        lerp(scheme.surfaceVariant, scheme.primaryContainer, 0.24f),
        lerp(scheme.surfaceVariant, scheme.secondaryContainer, 0.22f),
        lerp(scheme.surfaceVariant, scheme.tertiaryContainer, 0.20f)
    )

    return FourDThemeStyle(
        enabled = true,
        searchCornerDp = when (themeName) {
            "4d_titanium", "4d_crimson" -> 12
            "4d_quartz" -> 28
            else -> 20
        },
        cardCornerPattern = corners,
        tileColors = tones,
        resultElevationDp = if (themeName == "4d_titanium") 5 else 7,
        searchElevationDp = if (themeName == "4d_quartz") 8 else 6
    )
}

fun isFourDTheme(themeName: String?): Boolean = themeName in setOf(
    "4d_aurora",
    "4d_titanium",
    "4d_emerald",
    "4d_sapphire",
    "4d_crimson",
    "4d_quartz"
)

fun fourDTileShape(style: FourDThemeStyle, index: Int): Shape {
    val size = style.cardCornerPattern.size
    val radius = if (size == 0) 12 else style.cardCornerPattern[((index % size) + size) % size]
    // Alternate one corner pair very subtly.  This makes neighbouring results
    // distinct without turning cards into novelty shapes.
    return if (index % 2 == 0) {
        RoundedCornerShape(topStart = radius.dp, topEnd = (radius + 4).dp, bottomEnd = radius.dp, bottomStart = (radius + 2).dp)
    } else {
        RoundedCornerShape(topStart = (radius + 3).dp, topEnd = radius.dp, bottomEnd = (radius + 2).dp, bottomStart = radius.dp)
    }
}

/** Premium depth treatment for every DropdownMenu in 4D themes. */
@Composable
fun Modifier.fourDMenuChrome(): Modifier {
    val style = LocalFourDThemeStyle.current
    if (!style.enabled) return this
    val shape = MaterialTheme.shapes.extraSmall
    return this
        .shadow(14.dp, shape, clip = false)
        .border(1.dp, MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.82f), shape)
}
