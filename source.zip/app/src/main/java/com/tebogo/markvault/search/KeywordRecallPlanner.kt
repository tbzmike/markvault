package com.tebogo.markvault.search

/**
 * Conservative FTS4 query normalization for natural-language questions.
 * This is lexical query parsing, not generated-query expansion: it remains
 * available when the expansion slider is zero. Exact phrases bypass it.
 */
object KeywordRecallPlanner {
    private val tokenPattern = Regex("[\\p{L}\\p{N}]+")
    private val possessive = Regex("(?i)(?<=[\\p{L}])['’]s\\b")
    private val internalApostrophe = Regex("(?<=[\\p{L}])['’](?=[\\p{L}])")
    private val starters = setOf(
        "who", "whom", "whose", "what", "which", "where", "when", "why", "how",
        "is", "are", "was", "were", "do", "does", "did", "can", "could",
        "would", "should", "will", "has", "have", "had"
    )
    // Retain negation and relationship/subject words. Do not remove words from
    // statements, quotes, or queries with no reliable question structure.
    private val questionGrammar = setOf(
        "who", "whom", "whose", "what", "which", "where", "when", "why", "how",
        "is", "are", "was", "were", "do", "does", "did", "can", "could",
        "would", "should", "will", "has", "have", "had", "the", "a", "an",
        "of", "to", "for", "at", "by", "in", "on", "with", "me", "please",
        "tell", "explain", "you", "he", "she", "they", "it", "his", "her", "their"
    )

    fun hasQuestionStructure(raw: String): Boolean {
        val trimmed = raw.trim().trimStart('\"')
        val first = tokenPattern.find(trimmed)?.value?.lowercase().orEmpty()
        // Reuse Question Awareness's conservative question classifier; words like
        // "who" in "who magazine" or "how old testament prophecies" must not
        // trigger a weaker FTS query.
        return first in starters && QuestionAwareness.analyze(raw).isQuestion
    }

    /** Apostrophe inside a misspelled name (e'sau) is punctuation, not a word break. */
    private fun normalizedWords(raw: String): List<String> {
        val spelling = raw.lowercase().replace(possessive, "")
            .replace(internalApostrophe, "")
        return tokenPattern.findAll(spelling).map { it.value }.toList()
    }

    fun coreTokens(raw: String): List<String> {
        val words = normalizedWords(raw)
        if (words.isEmpty()) return emptyList()
        if (!hasQuestionStructure(raw)) return words
        val key = words.filter { it !in questionGrammar }
        // Do not erase the search if the whole question is stopwords.
        return (if (key.isNotEmpty()) key else words).distinct()
    }

    /** Null for ordinary statements and explicit quotes, preserving existing behavior. */
    fun coreQuery(raw: String): String? {
        val trimmed = raw.trim()
        if (trimmed.length >= 2 && trimmed.startsWith('\"') && trimmed.endsWith('\"')) return null
        if (!hasQuestionStructure(raw) && !raw.contains('’') && !raw.contains('\'')) return null
        val words = coreTokens(raw)
        if (words.isEmpty()) return null
        val standard = tokenPattern.findAll(trimmed.lowercase()).map { it.value }.toList()
        return if (words == standard) null else words.joinToString(" ") { "$it*" }
    }

    /** A second, bounded FTS4 proximity probe when the primary 500-hit pool is full. */
    fun proximityQuery(raw: String): String? {
        if (!hasQuestionStructure(raw) || raw.trim().startsWith('\"')) return null
        val tokens = coreTokens(raw).filter { it.length >= 2 }
        if (tokens.size !in 2..8) return null
        // For question stems, the final two content terms typically express the
        // requested relationship (e.g. sons / Esau). Proximity is symmetric.
        val a = tokens[tokens.size - 2]
        val b = tokens.last()
        if (a == b) return null
        return "$a* NEAR/8 $b*"
    }
}
