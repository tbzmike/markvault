package com.tebogo.markvault.ai

/** Local retrieval expansion model catalog. */
object T5ModelCatalog {
    data class ModelInfo(
        val id: String,
        val name: String,
        val installed: Boolean
    )

    fun models(): List<ModelInfo> = listOf(
        ModelInfo(
            id = "t5-base-paraphrase",
            name = "T5-base Paraphraser",
            installed = false
        )
    )
}
