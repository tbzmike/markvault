package com.tebogo.markvault.ai

/**
 * Catalog of the T5-base paraphrase model's real, publicly hosted artifact
 * files.
 *
 * Source: https://huggingface.co/Xenova/t5-base -- an ONNX export of
 * google-t5/t5-base maintained for use with Transformers.js, structured as
 * Optimum's standard seq2seq-lm-with-past ONNX layout (encoder / merged
 * decoder-with-past graphs). Verified to exist at time of writing; re-check
 * https://huggingface.co/Xenova/t5-base/tree/main if a download 404s, since
 * upstream repo layouts can change.
 *
 * We deliberately do NOT hardcode a SHA-256 for these files here: a
 * checksum copied from memory/training data with no way to verify it
 * against the live file is worse than useless -- it would either always
 * fail (blocking installs) or silently be skipped. Instead
 * [T5ModelDownloadService] uses trust-on-first-use pinning via
 * [T5ChecksumStore]: the hash is computed locally from the actual
 * downloaded bytes on first install and pinned, so any future re-download
 * that returns different bytes for the same file name is caught.
 */
object T5ModelCatalog {
    const val REPO_ID = "Xenova/t5-base"
    private const val RESOLVE_BASE = "https://huggingface.co/$REPO_ID/resolve/main/"

    data class ModelFile(
        val fileName: String,
        val repoPath: String,
        /** Rough expected size in bytes, for progress display only -- not verified. */
        val approxSizeBytes: Long
    ) {
        val url: String get() = RESOLVE_BASE + repoPath
    }

    val ENCODER = ModelFile("encoder_model.onnx", "onnx/encoder_model.onnx", 110L * 1024 * 1024)
    val DECODER = ModelFile("decoder_model.onnx", "onnx/decoder_model.onnx", 164L * 1024 * 1024)
    val CONFIG = ModelFile("config.json", "config.json", 2 * 1024)
    val TOKENIZER = ModelFile("tokenizer.json", "tokenizer.json", 2500L * 1024)
    val SPIECE = ModelFile("spiece.model", "spiece.model", 800L * 1024)

    /** All files required for a complete, working install. */
    val requiredFiles: List<ModelFile> = listOf(ENCODER, DECODER, CONFIG, TOKENIZER, SPIECE)

    data class ModelInfo(val id: String, val name: String, val installed: Boolean)

    fun models(): List<ModelInfo> = listOf(
        ModelInfo(
            id = "t5-base-paraphrase",
            name = "T5-base Paraphraser",
            installed = T5ModelManager.isInstalled()
        )
    )
}
