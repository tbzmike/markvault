package com.tebogo.markvault.ai

/**
 * STATUS NOTE (added during a build-fix pass): every `T5*` class in this
 * package is unwired scaffolding — no download URL, checksum, tokenizer
 * vocab, or ONNX/TFLite runner exists anywhere in this package, and
 * nothing outside it calls into these classes. The app's actual on-device
 * query-expansion model is [com.tebogo.markvault.llm.ChatModelCatalog]
 * (SmolLM2 / Phi-4-mini via LiteRT-LM), used through
 * [com.tebogo.markvault.ai.MultiQueryRetriever] /
 * [com.tebogo.markvault.ai.LocalAIProvider].
 *
 * If a T5-base paraphraser is actually wanted as a separate/lighter model,
 * the missing pieces are: (1) a real hosted `.onnx` or `.tflite` weight
 * file + sentencepiece vocab you control or trust, (2) a checksum for
 * that specific file, and (3) tensor-shape-correct encoder/decoder code
 * in `T5InferenceEngine`. None of that can be filled in safely without a
 * real, verifiable source for the model artifact — plugging in a guessed
 * URL would either 404 or silently point at someone else's arbitrary
 * binary. Until that source exists, consider routing paraphrase/query
 * expansion through the existing LiteRT-LM pipeline above instead of
 * standing up a second, redundant model runtime.
 */

/** Local retrieval expansion model catalog. */
object T5ModelCatalog {
    data class ModelInfo(
        val id: String,
        val name: String,
        val installed: Boolean
    )

    fun models(): List<ModelInfo> = listOf(
        ModelInfo(
            id = "t5-base-paraphrase",
            name = "T5-base Paraphraser",
            installed = false
        )
    )
}
