package com.tebogo.markvault.ui

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.navigation.NavController
import com.tebogo.markvault.AppViewModel
import com.tebogo.markvault.data.WebBookmark
import java.net.URLEncoder

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun WebBookmarksScreen(vm: AppViewModel, nav: NavController) {
    var bookmarks by remember { mutableStateOf<List<WebBookmark>>(emptyList()) }
    var loading by remember { mutableStateOf(true) }
    var reloadCounter by remember { mutableStateOf(0) }

    LaunchedEffect(reloadCounter) {
        loading = true
        bookmarks = vm.loadBookmarks()
        loading = false
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("\uD83D\uDD16 Bookmarks") },
                navigationIcon = {
                    IconButton(onClick = { nav.popBackStack() }) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back")
                    }
                },
                actions = { GlobalAppMenu(nav, vm) }
            )
        }
    ) { pad ->
        when {
            loading -> Box(Modifier.padding(pad).fillMaxSize(), contentAlignment = Alignment.Center) {
                Text("Loading\u2026", color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
            bookmarks.isEmpty() -> Box(Modifier.padding(pad).fillMaxSize(), contentAlignment = Alignment.Center) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Text("\uD83D\uDD16", fontSize = 36.sp)
                    Spacer(Modifier.height(8.dp))
                    Text("No bookmarks yet.", color = MaterialTheme.colorScheme.onSurfaceVariant)
                    Text(
                        "In the browser, tap the \u2606 star icon to save a page.",
                        fontSize = 12.sp,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        modifier = Modifier.padding(top = 4.dp)
                    )
                }
            }
            else -> LazyColumn(Modifier.padding(pad).fillMaxSize()) {
                items(bookmarks, key = { it.id }) { b ->
                    Row(
                        Modifier
                            .fillMaxWidth()
                            .clickable {
                                val encU = URLEncoder.encode(b.url, "UTF-8")
                                val encL = URLEncoder.encode(b.title.ifBlank { b.host }, "UTF-8")
                                nav.navigate("web/$encU/$encL")
                            }
                            .padding(horizontal = 18.dp, vertical = 12.dp),
                        verticalAlignment = Alignment.Top
                    ) {
                        Text("\u2B50", fontSize = 20.sp, modifier = Modifier.padding(top = 2.dp))
                        Spacer(Modifier.width(12.dp))
                        Column(Modifier.weight(1f)) {
                            Text(
                                b.title.ifBlank { b.url },
                                fontSize = 14.sp,
                                fontWeight = FontWeight.SemiBold,
                                maxLines = 2, overflow = TextOverflow.Ellipsis
                            )
                            Spacer(Modifier.height(2.dp))
                            Text(
                                b.host.ifBlank { b.url },
                                fontSize = 12.sp,
                                color = MaterialTheme.colorScheme.onSurfaceVariant,
                                maxLines = 1, overflow = TextOverflow.Ellipsis
                            )
                            Spacer(Modifier.height(3.dp))
                            Text(
                                formatHistoryTime(b.addedAt),
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Medium,
                                color = MaterialTheme.colorScheme.primary
                            )
                        }
                        IconButton(
                            onClick = {
                                vm.deleteBookmarkEntry(b.id)
                                reloadCounter++
                            },
                            modifier = Modifier.size(36.dp)
                        ) {
                            Icon(
                                Icons.Default.Delete,
                                contentDescription = "Remove",
                                tint = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    }
                    HistoryBoldDivider()
                }
                item { Spacer(Modifier.height(40.dp)) }
            }
        }
    }
}
