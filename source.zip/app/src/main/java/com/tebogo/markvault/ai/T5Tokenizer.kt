package com.tebogo.markvault.ai

/**
 * Tokenizer bridge for T5 paraphrase inference.
 * Runtime-specific tokenizer implementation is injected later.
 */
class T5Tokenizer {
    fun encode(text: String): IntArray {
        return text.trim().split("\\s+".toRegex())
            .filter { it.isNotEmpty() }
            .map { it.hashCode() }
            .toIntArray()
    }

    fun decode(tokens: IntArray): String {
        return tokens.joinToString(" ")
    }
}
