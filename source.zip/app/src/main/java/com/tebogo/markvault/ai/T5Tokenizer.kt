package com.tebogo.markvault.ai

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject
import java.io.File

/**
 * Tokenizer for T5-base paraphrase inference, built from the real vocab
 * shipped in the downloaded `tokenizer.json` (see [T5ModelCatalog]).
 *
 * LIMITATION (disclosed, not hidden): T5's tokenizer is a trained
 * SentencePiece Unigram model, whose reference implementation finds the
 * *highest-probability* segmentation of a string via a Viterbi lattice
 * search over piece scores. Re-implementing that from scratch is a
 * substantial undertaking on its own. This class instead does **greedy
 * longest-match** segmentation over the same vocab table -- correct
 * piece-for-piece for the common case (most real words match their
 * longest known piece first), but not guaranteed byte-identical to
 * SentencePiece's optimal segmentation on unusual/rare input. If exact
 * parity is required, swap this for a JNI binding to Google's
 * `sentencepiece` library loaded against the also-downloaded
 * `spiece.model` binary, which this class currently downloads but does
 * not parse.
 */
class T5Tokenizer(private val context: Context) {

    private var pieceToId: Map<String, Int> = emptyMap()
    private var idToPiece: List<String> = emptyList()
    private var padId: Int = 0
    private var eosId: Int = 1
    private var unkId: Int = 2
    private var maxPieceLen: Int = 1
    private var loaded = false

    fun load(): Boolean {
        if (loaded) return true
        val file = File(context.filesDir, "models/t5-base/${T5ModelCatalog.TOKENIZER.fileName}")
        if (!file.exists()) return false

        val root = JSONObject(file.readText())
        val model = root.getJSONObject("model")
        val vocabArray: JSONArray = model.getJSONArray("vocab")

        val pieces = ArrayList<String>(vocabArray.length())
        for (i in 0 until vocabArray.length()) {
            val entry = vocabArray.getJSONArray(i)
            pieces.add(entry.getString(0))
        }
        idToPiece = pieces
        pieceToId = pieces.withIndex().associate { (idx, piece) -> piece to idx }
        maxPieceLen = pieces.maxOfOrNull { it.length } ?: 1

        unkId = if (model.has("unk_id")) model.getInt("unk_id") else (pieceToId["<unk>"] ?: 2)
        eosId = pieceToId["</s>"] ?: 1
        padId = pieceToId["<pad>"] ?: 0

        loaded = true
        return true
    }

    /** Encodes [text] into T5 input ids, appending the end-of-sequence token. */
    fun encode(text: String): IntArray {
        if (!loaded) load()
        val normalized = "\u2581" + text.trim().replace(" ", "\u2581")
        val ids = ArrayList<Int>()

        var i = 0
        while (i < normalized.length) {
            var matched = false
            val upper = minOf(maxPieceLen, normalized.length - i)
            for (len in upper downTo 1) {
                val candidate = normalized.substring(i, i + len)
                val id = pieceToId[candidate]
                if (id != null) {
                    ids.add(id)
                    i += len
                    matched = true
                    break
                }
            }
            if (!matched) {
                ids.add(unkId)
                i += 1
            }
        }
        ids.add(eosId)
        return ids.toIntArray()
    }

    /** Decodes T5 output ids back into text, dropping pad/eos control tokens. */
    fun decode(tokens: IntArray): String {
        if (!loaded) load()
        val sb = StringBuilder()
        for (id in tokens) {
            if (id == padId || id == eosId) continue
            val piece = idToPiece.getOrNull(id) ?: continue
            sb.append(piece)
        }
        return sb.toString().replace("\u2581", " ").trim()
    }
}
