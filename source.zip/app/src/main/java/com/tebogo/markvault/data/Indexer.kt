package com.tebogo.markvault.data

import com.tebogo.markvault.util.sanitizeMarkVaultHtml

import android.content.Context
import android.net.Uri
import android.provider.DocumentsContract
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.async
import kotlinx.coroutines.awaitAll
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.withContext

data class IndexProgress(
    val running: Boolean = false,
    val phase: String = "",
    val done: Int = 0,
    val total: Int = 0
)

data class ScannedFile(
    val docId: String,
    val name: String,
    val relPath: String,
    val lastModified: Long,
    val size: Long
)

private data class LoadedFile(
    val file: ScannedFile,
    val uri: String,
    val text: String,
    val lastOpened: Long,
    val title: String,
    val topics: List<Pair<String, Int>>,
    val links: List<String>,
    val fileType: String = "md"
)

class Indexer(private val context: Context, private val dao: NoteDao) {

    @OptIn(ExperimentalCoroutinesApi::class)
    suspend fun sync(treeUriString: String, onProgress: (IndexProgress) -> Unit) =
        withContext(Dispatchers.IO) {
            val treeUri = Uri.parse(treeUriString)
            onProgress(IndexProgress(true, "Scanning library\u2026", 0, 0))

            val files = ArrayList<ScannedFile>(2048)
            val rootId = DocumentsContract.getTreeDocumentId(treeUri)
            scanFolder(treeUri, rootId, "", files)

            val existing = dao.syncInfo().associateBy { it.uri }
            val seenIds = HashSet<Long>(files.size)
            var done = 0
            val total = files.size
            onProgress(IndexProgress(true, "Indexing\u2026", 0, total))

            // Split into unchanged (skip) and changed (must read + index).
            val changed = ArrayList<Pair<ScannedFile, String>>()
            for (f in files) {
                val fileUri =
                    DocumentsContract.buildDocumentUriUsingTree(treeUri, f.docId).toString()
                val old = existing[fileUri]
                if (old != null && old.lastModified == f.lastModified && old.size == f.size) {
                    seenIds.add(old.id)
                    done++
                } else {
                    changed.add(f to fileUri)
                }
            }
            onProgress(IndexProgress(true, "Indexing\u2026", done, total))

            val io = Dispatchers.IO.limitedParallelism(8)
            // Read changed files in parallel, in bounded chunks to cap memory.
            for (chunk in changed.chunked(200)) {
                val loaded = coroutineScope {
                    chunk.map { (f, fileUri) ->
                        async(io) {
                            val nameLower = f.name.lowercase()
                            val isPdf = nameLower.endsWith(".pdf")
                            // v4.3 — mhtml/mht web archives and plain html files.
                            // Their text gets extracted for FTS and topic
                            // classification, exactly like markdown.
                            val isMhtml = nameLower.endsWith(".mhtml") || nameLower.endsWith(".mht")
                            val isHtml = nameLower.endsWith(".html") || nameLower.endsWith(".htm")
                            val rawText = when {
                                isPdf -> ""
                                isMhtml -> extractMhtmlText(readText(fileUri) ?: "")
                                isHtml -> stripHtmlForIndex(readText(fileUri) ?: "")
                                else -> readText(fileUri) ?: ""
                            }
                            val text = rawText
                            val title = if (isPdf) extractTitle("", f.name)
                                        else extractTitle(text, f.name)
                            val topics = if (isPdf) emptyList()
                                else runCatching { Topics.classify(title, text) }
                                    .getOrElse { emptyList() }
                            val links = if (isPdf || isMhtml || isHtml) emptyList()
                                else runCatching { Wikilinks.extract(text) }
                                    .getOrElse { emptyList() }
                            val type = when {
                                isPdf -> "pdf"
                                isMhtml -> "mhtml"
                                isHtml -> "html"
                                else -> "md"
                            }
                            LoadedFile(f, fileUri, text, existing[fileUri]?.lastOpened ?: 0,
                                title, topics, links, type)
                        }
                    }.awaitAll()
                }
                for (lf in loaded) {
                    val folder = lf.file.relPath.substringBeforeLast('/', "")
                    // Defensive sanitize — strip any leaked smart-styling artefacts
                    // (e.g. literal `"sm-ref">` fragments from a historically corrupted
                    // .md file) BEFORE the text reaches Room. This is the pre-save
                    // pass requested for v4.2. Without it, corrupted markdown stays
                    // corrupted in the DB and shows up in the FTS index too.
                    val cleanContent = lf.text.sanitizeMarkVaultHtml()
                    val newId = dao.upsert(
                        Note(
                            id = 0,
                            uri = lf.uri,
                            relPath = lf.file.relPath,
                            name = lf.file.name,
                            title = lf.title,
                            folder = folder,
                            content = cleanContent,
                            lastModified = lf.file.lastModified,
                            size = lf.file.size,
                            lastOpened = lf.lastOpened,
                            fileType = lf.fileType
                        )
                    )
                    seenIds.add(newId)
                    runCatching {
                        dao.clearTopicsForNote(newId)
                        if (lf.topics.isNotEmpty()) {
                            dao.insertTopics(lf.topics.map { NoteTopic(newId, it.first, it.second) })
                        }
                    }
                    runCatching {
                        dao.clearLinksForNote(newId)
                        if (lf.links.isNotEmpty()) {
                            dao.insertLinks(lf.links.map { tgt ->
                                NoteLink(newId, tgt, Wikilinks.normalize(tgt))
                            })
                        }
                    }
                    done++
                }
                onProgress(IndexProgress(true, "Indexing\u2026", done, total))
            }

            val toDelete = existing.values.asSequence()
                .filter { it.id !in seenIds }
                .map { it.id }
                .toList()
            if (toDelete.isNotEmpty()) {
                toDelete.chunked(500).forEach { dao.deleteByIds(it) }
            }
            runCatching { dao.pruneOrphanTopics() }
            runCatching { dao.pruneOrphanLinks() }
            // v5.4.37 — Prune orphaned embedding rows. When the
            // indexer re-indexes a note, INSERT OR REPLACE deletes
            // the old row (old id) and inserts a new one (new auto-
            // generated id). The embedding keyed to the old noteId
            // becomes orphaned. Without this cleanup, the embedding
            // count doubles after every full re-index.
            runCatching { dao.pruneOrphanEmbeddings() }

            onProgress(IndexProgress(false, "Done", total, total))
        }

    private fun scanFolder(
        treeUri: Uri,
        parentDocId: String,
        parentPath: String,
        out: MutableList<ScannedFile>
    ) {
        val childrenUri =
            DocumentsContract.buildChildDocumentsUriUsingTree(treeUri, parentDocId)
        val projection = arrayOf(
            DocumentsContract.Document.COLUMN_DOCUMENT_ID,
            DocumentsContract.Document.COLUMN_DISPLAY_NAME,
            DocumentsContract.Document.COLUMN_MIME_TYPE,
            DocumentsContract.Document.COLUMN_LAST_MODIFIED,
            DocumentsContract.Document.COLUMN_SIZE
        )
        try {
            context.contentResolver.query(childrenUri, projection, null, null, null)?.use { c ->
                while (c.moveToNext()) {
                    val docId = c.getString(0) ?: continue
                    val name = c.getString(1) ?: continue
                    val mime = if (c.isNull(2)) "" else c.getString(2)
                    val lastMod = if (c.isNull(3)) 0L else c.getLong(3)
                    val size = if (c.isNull(4)) 0L else c.getLong(4)
                    val path = if (parentPath.isEmpty()) name else "$parentPath/$name"
                    if (mime == DocumentsContract.Document.MIME_TYPE_DIR) {
                        scanFolder(treeUri, docId, path, out)
                    } else if (
                        name.endsWith(".md", ignoreCase = true) ||
                        name.endsWith(".markdown", ignoreCase = true) ||
                        name.endsWith(".pdf", ignoreCase = true) ||
                        // v4.3 — offline web archives saved via "Save as Offline HTML"
                        // are now first-class citizens. They render in a WebView and
                        // their text content is extracted into the FTS index just like
                        // markdown notes, so library search can find them.
                        name.endsWith(".mhtml", ignoreCase = true) ||
                        name.endsWith(".mht", ignoreCase = true) ||
                        name.endsWith(".html", ignoreCase = true) ||
                        name.endsWith(".htm", ignoreCase = true)
                    ) {
                        out.add(ScannedFile(docId, name, path, lastMod, size))
                    }
                }
            }
        } catch (_: Exception) {
            // Folder unreadable; skip it rather than crash the whole index.
        }
    }

    private fun readText(uriString: String): String? = try {
        context.contentResolver.openInputStream(Uri.parse(uriString))?.use {
            it.bufferedReader(Charsets.UTF_8).readText()
        }
    } catch (_: Exception) {
        null
    }

    companion object {
        fun extractTitle(text: String, fileName: String): String {
            for (line in text.lineSequence().take(40)) {
                val t = line.trim()
                if (t.startsWith("#")) {
                    val title = t.trimStart('#').trim()
                    if (title.isNotEmpty()) return title
                }
            }
            return fileName
                .removeSuffix(".md").removeSuffix(".MD")
                .removeSuffix(".markdown").removeSuffix(".MARKDOWN")
                .removeSuffix(".pdf").removeSuffix(".PDF")
        }
    }
}

/**
 * v4.3 — pull a searchable plain-text body out of a `.mhtml` web archive.
 *
 * An MHTML file is a multipart MIME envelope (RFC 2557) where the first part
 * is typically `text/html` carrying the page itself; subsequent parts hold
 * embedded images/CSS encoded with `Content-Transfer-Encoding: base64` or
 * `quoted-printable`. For indexing we only need the HTML body's visible text,
 * so we strip:
 *   1. Everything up to and including the first blank line (MIME headers)
 *   2. The MIME part separator and any trailing parts
 *   3. quoted-printable soft line breaks (`=\r?\n`) and `=XX` escapes
 *   4. <script>, <style>, and HTML tags themselves
 *
 * This is a defensive best-effort extractor — it doesn't need to be perfect,
 * just good enough that searching for "internal contradictions" matches the
 * saved page even when the original .mhtml is byte-for-byte preserved.
 */
internal fun extractMhtmlText(raw: String): String {
    if (raw.isBlank()) return ""
    // Find the boundary string. MIME multipart envelopes declare it in the
    // top headers as e.g.  Content-Type: multipart/related; boundary="----X"
    val boundaryMatch = Regex("""(?im)^content-type:\s*multipart/[^;\n]+;\s*boundary\s*=\s*"?([^"\r\n]+)"?""")
        .find(raw)
    val parts = if (boundaryMatch != null) {
        val boundary = boundaryMatch.groupValues[1].trim()
        raw.split("--$boundary")
    } else {
        listOf(raw)
    }
    // Find the first text/html part — that's the page content.
    val htmlPart = parts.firstOrNull {
        it.contains(Regex("""(?im)^content-type:\s*text/html"""))
    } ?: parts.firstOrNull() ?: return ""

    // Split header from body at the first blank line.
    val headerBodySplit = htmlPart.indexOf("\r\n\r\n").let {
        if (it >= 0) it + 4 else htmlPart.indexOf("\n\n").let { j -> if (j >= 0) j + 2 else 0 }
    }
    var body = htmlPart.substring(headerBodySplit)

    // Decode quoted-printable soft line breaks: `=` at end of line + newline.
    body = body.replace(Regex("=\\r?\\n"), "")
    // Decode `=XX` (hex) byte escapes — common in quoted-printable.
    body = body.replace(Regex("=([0-9A-Fa-f]{2})")) { m ->
        runCatching { m.groupValues[1].toInt(16).toChar().toString() }
            .getOrElse { m.value }
    }
    return stripHtmlForIndex(body)
}

/**
 * Strip a chunk of HTML down to its visible text so we can feed it to FTS.
 * Removes scripts, styles, all tags, and decodes the common HTML entities
 * that would otherwise show up as literals (`&amp;`, `&nbsp;`, etc).
 */
/**
 * v5.4.100cc — Pull the source URL out of a raw HTML document
 * without any other stripping / normalization. Tries, in order:
 *   1. MarkVault's own envelope comment
 *      `<!-- Saved by MarkVault … from <url> -->`
 *   2. `<base href="<url>">`
 *   3. `<link rel="canonical" href="<url>">`
 *   4. `<meta property="og:url" content="<url>">`
 *
 * Returns null if none are present. Shared between [stripHtmlForIndex]
 * (called at index time) and AppViewModel's URL-cache backfill (which
 * reads the raw file directly for legacy notes indexed before this
 * function existed). Sharing the extractor keeps the two paths
 * guaranteed to agree on what URL a given document "belongs to".
 */
internal fun extractSourceUrlFromRawHtml(html: String): String? {
    if (html.isBlank()) return null
    // Look at only the first ~8KB — envelope comment, base href,
    // canonical, and og:url all live in the document head.
    val head = if (html.length > 8192) html.substring(0, 8192) else html
    val envelopeUrl = Regex(
        """<!--\s*Saved\s+by\s+MarkVault[^-]*?from\s+(\S+?)\s*-->""",
        setOf(RegexOption.IGNORE_CASE)
    ).find(head)?.groupValues?.getOrNull(1)
    if (!envelopeUrl.isNullOrBlank()) return envelopeUrl
    val baseHrefUrl = Regex(
        """<base\s+href\s*=\s*["']([^"']+)["']""",
        setOf(RegexOption.IGNORE_CASE)
    ).find(head)?.groupValues?.getOrNull(1)
    if (!baseHrefUrl.isNullOrBlank()) return baseHrefUrl
    val canonicalUrl = Regex(
        """<link[^>]+rel\s*=\s*["']canonical["'][^>]+href\s*=\s*["']([^"']+)["']""",
        setOf(RegexOption.IGNORE_CASE)
    ).find(head)?.groupValues?.getOrNull(1)
    if (!canonicalUrl.isNullOrBlank()) return canonicalUrl
    val ogUrl = Regex(
        """<meta[^>]+property\s*=\s*["']og:url["'][^>]+content\s*=\s*["']([^"']+)["']""",
        setOf(RegexOption.IGNORE_CASE)
    ).find(head)?.groupValues?.getOrNull(1)
    return ogUrl
}

internal fun stripHtmlForIndex(html: String): String {
    if (html.isBlank()) return ""
    var s = html
    // v5.4.100cc — Extract source URL BEFORE stripping comments so
    // cross-format dedup can find it in the FTS content. HTML files
    // saved by MarkVault carry a `<!-- Saved by MarkVault on … from
    // <URL> -->` envelope comment and a `<base href="<URL>">` tag;
    // both would otherwise be stripped (line-below regex removes all
    // comments, then all tags). We pull the URL out here and prepend
    // it as an inline `source: <URL>` line so `notesForUrlHarvest`
    // catches it and the WebViewer's URL-cache backfill lights up
    // this note as "already saved" the next time the user tries to
    // batch-save that same article.
    val preservedSourceUrl = extractSourceUrlFromRawHtml(s)
    s = s.replace(Regex("(?is)<script[^>]*>.*?</script>"), " ")
    s = s.replace(Regex("(?is)<style[^>]*>.*?</style>"), " ")
    s = s.replace(Regex("(?is)<noscript[^>]*>.*?</noscript>"), " ")
    s = s.replace(Regex("(?s)<!--.*?-->"), " ")
    s = s.replace(Regex("(?is)<br[^>]*/?>"), "\n")
    s = s.replace(Regex("(?is)</p>|</div>|</li>|</h[1-6]>"), "\n")
    s = s.replace(Regex("<[^>]+>"), " ")
    s = s.replace("&nbsp;", " ")
        .replace("&amp;", "&")
        .replace("&lt;", "<")
        .replace("&gt;", ">")
        .replace("&quot;", "\"")
        .replace("&#39;", "'")
        .replace("&apos;", "'")
    // Numeric entities (&#1234; / &#x4D2;)
    s = s.replace(Regex("&#(\\d+);")) { m ->
        runCatching { m.groupValues[1].toInt().toChar().toString() }.getOrElse { m.value }
    }
    s = s.replace(Regex("&#x([0-9A-Fa-f]+);")) { m ->
        runCatching { m.groupValues[1].toInt(16).toChar().toString() }.getOrElse { m.value }
    }
    s = s.replace(Regex("\\s+"), " ")
    val trimmed = s.trim()
    // Prepend the preserved URL so `notesForUrlHarvest`'s
    // `content LIKE '%source:%'` filter catches it and the FTS
    // tokenizer keeps it near the head of the row.
    return if (!preservedSourceUrl.isNullOrBlank()) {
        "source: $preservedSourceUrl\n$trimmed"
    } else {
        trimmed
    }
}
