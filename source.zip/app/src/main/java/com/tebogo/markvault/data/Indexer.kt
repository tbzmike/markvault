package com.tebogo.markvault.data

import android.content.Context
import android.net.Uri
import android.provider.DocumentsContract
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.async
import kotlinx.coroutines.awaitAll
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.withContext

data class IndexProgress(
    val running: Boolean = false,
    val phase: String = "",
    val done: Int = 0,
    val total: Int = 0
)

data class ScannedFile(
    val docId: String,
    val name: String,
    val relPath: String,
    val lastModified: Long,
    val size: Long
)

private data class LoadedFile(
    val file: ScannedFile,
    val uri: String,
    val text: String,
    val lastOpened: Long,
    val title: String,
    val topics: List<Pair<String, Int>>
)

class Indexer(private val context: Context, private val dao: NoteDao) {

    @OptIn(ExperimentalCoroutinesApi::class)
    suspend fun sync(treeUriString: String, onProgress: (IndexProgress) -> Unit) =
        withContext(Dispatchers.IO) {
            val treeUri = Uri.parse(treeUriString)
            onProgress(IndexProgress(true, "Scanning library\u2026", 0, 0))

            val files = ArrayList<ScannedFile>(2048)
            val rootId = DocumentsContract.getTreeDocumentId(treeUri)
            scanFolder(treeUri, rootId, "", files)

            val existing = dao.syncInfo().associateBy { it.uri }
            val seenIds = HashSet<Long>(files.size)
            var done = 0
            val total = files.size
            onProgress(IndexProgress(true, "Indexing\u2026", 0, total))

            // Split into unchanged (skip) and changed (must read + index).
            val changed = ArrayList<Pair<ScannedFile, String>>()
            for (f in files) {
                val fileUri =
                    DocumentsContract.buildDocumentUriUsingTree(treeUri, f.docId).toString()
                val old = existing[fileUri]
                if (old != null && old.lastModified == f.lastModified && old.size == f.size) {
                    seenIds.add(old.id)
                    done++
                } else {
                    changed.add(f to fileUri)
                }
            }
            onProgress(IndexProgress(true, "Indexing\u2026", done, total))

            val io = Dispatchers.IO.limitedParallelism(8)
            // Read changed files in parallel, in bounded chunks to cap memory.
            for (chunk in changed.chunked(200)) {
                val loaded = coroutineScope {
                    chunk.map { (f, fileUri) ->
                        async(io) {
                            val text = readText(fileUri) ?: ""
                            val title = extractTitle(text, f.name)
                            val topics = runCatching { Topics.classify(title, text) }.getOrElse { emptyList() }
                            LoadedFile(f, fileUri, text, existing[fileUri]?.lastOpened ?: 0, title, topics)
                        }
                    }.awaitAll()
                }
                for (lf in loaded) {
                    val folder = lf.file.relPath.substringBeforeLast('/', "")
                    val newId = dao.upsert(
                        Note(
                            id = 0,
                            uri = lf.uri,
                            relPath = lf.file.relPath,
                            name = lf.file.name,
                            title = lf.title,
                            folder = folder,
                            content = lf.text,
                            lastModified = lf.file.lastModified,
                            size = lf.file.size,
                            lastOpened = lf.lastOpened
                        )
                    )
                    seenIds.add(newId)
                    runCatching {
                        dao.clearTopicsForNote(newId)
                        if (lf.topics.isNotEmpty()) {
                            dao.insertTopics(lf.topics.map { NoteTopic(newId, it.first, it.second) })
                        }
                    }
                    done++
                }
                onProgress(IndexProgress(true, "Indexing\u2026", done, total))
            }

            val toDelete = existing.values.asSequence()
                .filter { it.id !in seenIds }
                .map { it.id }
                .toList()
            if (toDelete.isNotEmpty()) {
                toDelete.chunked(500).forEach { dao.deleteByIds(it) }
            }
            runCatching { dao.pruneOrphanTopics() }

            onProgress(IndexProgress(false, "Done", total, total))
        }

    private fun scanFolder(
        treeUri: Uri,
        parentDocId: String,
        parentPath: String,
        out: MutableList<ScannedFile>
    ) {
        val childrenUri =
            DocumentsContract.buildChildDocumentsUriUsingTree(treeUri, parentDocId)
        val projection = arrayOf(
            DocumentsContract.Document.COLUMN_DOCUMENT_ID,
            DocumentsContract.Document.COLUMN_DISPLAY_NAME,
            DocumentsContract.Document.COLUMN_MIME_TYPE,
            DocumentsContract.Document.COLUMN_LAST_MODIFIED,
            DocumentsContract.Document.COLUMN_SIZE
        )
        try {
            context.contentResolver.query(childrenUri, projection, null, null, null)?.use { c ->
                while (c.moveToNext()) {
                    val docId = c.getString(0) ?: continue
                    val name = c.getString(1) ?: continue
                    val mime = if (c.isNull(2)) "" else c.getString(2)
                    val lastMod = if (c.isNull(3)) 0L else c.getLong(3)
                    val size = if (c.isNull(4)) 0L else c.getLong(4)
                    val path = if (parentPath.isEmpty()) name else "$parentPath/$name"
                    if (mime == DocumentsContract.Document.MIME_TYPE_DIR) {
                        scanFolder(treeUri, docId, path, out)
                    } else if (
                        name.endsWith(".md", ignoreCase = true) ||
                        name.endsWith(".markdown", ignoreCase = true)
                    ) {
                        out.add(ScannedFile(docId, name, path, lastMod, size))
                    }
                }
            }
        } catch (_: Exception) {
            // Folder unreadable; skip it rather than crash the whole index.
        }
    }

    private fun readText(uriString: String): String? = try {
        context.contentResolver.openInputStream(Uri.parse(uriString))?.use {
            it.bufferedReader(Charsets.UTF_8).readText()
        }
    } catch (_: Exception) {
        null
    }

    companion object {
        fun extractTitle(text: String, fileName: String): String {
            for (line in text.lineSequence().take(40)) {
                val t = line.trim()
                if (t.startsWith("#")) {
                    val title = t.trimStart('#').trim()
                    if (title.isNotEmpty()) return title
                }
            }
            return fileName
                .removeSuffix(".md").removeSuffix(".MD")
                .removeSuffix(".markdown").removeSuffix(".MARKDOWN")
        }
    }
}
