package com.tebogo.markvault.ui

import android.annotation.SuppressLint
import android.graphics.pdf.PdfDocument
import android.view.View
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.tebogo.markvault.AppViewModel
import kotlinx.coroutines.CompletableDeferred
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.suspendCancellableCoroutine
import kotlinx.coroutines.withContext
import java.io.File
import java.io.FileOutputStream

/**
 * v5.4.10 — Convert a shared URL into a PDF file in the user's library.
 *
 * v5.4.11 — Rewritten to use android.graphics.pdf.PdfDocument + View.draw
 * instead of android.print.PrintDocumentAdapter. The adapter's
 * LayoutResultCallback / WriteResultCallback have package-private
 * constructors in the platform, so subclassing them from outside
 * android.print fails to compile. PdfDocument is the lower-level API
 * designed for exactly this kind of programmatic "render a View into a
 * PDF" use case and exposes only public types.
 *
 * Strategy:
 *   1. Load URL in a hidden WebView at a fixed desktop-ish width.
 *   2. Wait for the page to finish loading + 2s grace for late JS.
 *   3. Re-measure to capture the fully-laid-out content height.
 *   4. Split the content into A4-ish pages of fixed height.
 *   5. For each page: start a PdfDocument page, translate the canvas
 *      by the page offset, and call webView.draw(canvas).
 *   6. Write the document to a temp file, then hand off to the VM's
 *      library saver.
 */
@SuppressLint("SetJavaScriptEnabled")
@Composable
fun UrlToPdfScreen(
    vm: AppViewModel,
    url: String,
    onClose: () -> Unit,
    onSavedToLibrary: (relPath: String) -> Unit
) {
    val ctx = LocalContext.current
    var status by remember { mutableStateOf("Loading page\u2026") }
    var error by remember { mutableStateOf<String?>(null) }
    var done by remember { mutableStateOf(false) }

    LaunchedEffect(url) {
        try {
            status = "Loading page\u2026"
            val wv = WebView(ctx)
            wv.settings.javaScriptEnabled = true
            wv.settings.loadWithOverviewMode = true
            wv.settings.useWideViewPort = true

            val pageReady = CompletableDeferred<Unit>()
            wv.setWebViewClient(object : WebViewClient() {
                override fun onPageFinished(view: WebView?, finishedUrl: String?) {
                    if (!pageReady.isCompleted) pageReady.complete(Unit)
                }
            })
            val pageWidthPx = 1280
            val pageHeightPx = 1800
            wv.measure(
                View.MeasureSpec.makeMeasureSpec(pageWidthPx, View.MeasureSpec.EXACTLY),
                View.MeasureSpec.makeMeasureSpec(0, View.MeasureSpec.UNSPECIFIED)
            )
            wv.layout(0, 0, pageWidthPx, pageHeightPx)
            wv.loadUrl(url)

            pageReady.await()
            status = "Waiting for late content\u2026"
            delay(2000L)

            status = "Rendering PDF\u2026"
            wv.measure(
                View.MeasureSpec.makeMeasureSpec(pageWidthPx, View.MeasureSpec.EXACTLY),
                View.MeasureSpec.makeMeasureSpec(0, View.MeasureSpec.UNSPECIFIED)
            )
            val totalContentHeight = wv.measuredHeight.coerceAtLeast(pageHeightPx)
            wv.layout(0, 0, pageWidthPx, totalContentHeight)

            val tempPdf = renderWebViewToPdf(wv, pageWidthPx, pageHeightPx, totalContentHeight, ctx.cacheDir)
            if (tempPdf == null || !tempPdf.exists() || tempPdf.length() < 256L) {
                error = "PDF rendering failed. Try \"View live website\" instead."
                runCatching { tempPdf?.delete() }
                return@LaunchedEffect
            }

            status = "Saving to library\u2026"
            val host = runCatching {
                android.net.Uri.parse(url).host ?: "page"
            }.getOrElse { "page" }
            val titleGuess = runCatching {
                suspendCancellableCoroutine<String?> { cont ->
                    wv.evaluateJavascript("document.title") {
                        val t = it?.trim('"')?.takeIf { s -> s.isNotBlank() && s != "null" }
                        cont.resumeWith(Result.success(t))
                    }
                }
            }.getOrNull()
            val baseName = (titleGuess ?: host)
                .replace(Regex("[\\\\/:*?\"<>|]"), "_")
                .take(80)
                .trim()
            val fileName = "$baseName.pdf"

            val saved = vm.saveSharedPdfToLibrary(tempPdf, fileName)
            runCatching { tempPdf.delete() }
            if (saved == null) {
                error = "Couldn't save to library. Is the library folder set in Settings?"
                return@LaunchedEffect
            }
            done = true
            onSavedToLibrary(saved)
        } catch (t: Throwable) {
            error = "Conversion failed: ${t.message ?: t::class.java.simpleName}"
        }
    }

    Scaffold { pad ->
        Box(
            modifier = Modifier
                .padding(pad)
                .fillMaxSize()
                .padding(24.dp),
            contentAlignment = Alignment.Center
        ) {
            Column(
                modifier = Modifier.fillMaxWidth(),
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.Center
            ) {
                Text("\uD83D\uDCC4", fontSize = 64.sp)
                Spacer(Modifier.height(16.dp))
                Text(
                    "Converting to PDF",
                    fontSize = 18.sp,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.onSurface
                )
                Spacer(Modifier.height(10.dp))
                if (error != null) {
                    Text(
                        error!!,
                        fontSize = 13.sp,
                        color = MaterialTheme.colorScheme.error
                    )
                    Spacer(Modifier.height(20.dp))
                    TextButton(onClick = onClose) { Text("Close") }
                } else if (done) {
                    Text(
                        "Done.",
                        fontSize = 13.sp,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                } else {
                    Text(
                        status,
                        fontSize = 13.sp,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                    Spacer(Modifier.height(16.dp))
                    CircularProgressIndicator()
                }
            }
        }
    }
}

/**
 * Render a (already-laid-out) WebView's full content into a PDF file
 * by tiling pages of [pageHeight] pixels each across [contentHeight].
 * Runs on the main thread because WebView.draw must be called on the
 * UI thread; the I/O writeTo() at the end is also fine on Main since
 * PdfDocument buffers everything in memory first.
 */
private suspend fun renderWebViewToPdf(
    wv: WebView,
    pageWidth: Int,
    pageHeight: Int,
    contentHeight: Int,
    cacheDir: File
): File? = withContext(Dispatchers.Main) {
    try {
        val out = File.createTempFile("urlpdf_", ".pdf", cacheDir)
        val doc = PdfDocument()
        val pages = ((contentHeight + pageHeight - 1) / pageHeight).coerceAtLeast(1)
        for (i in 0 until pages) {
            val pageInfo = PdfDocument.PageInfo.Builder(pageWidth, pageHeight, i + 1).create()
            val page = doc.startPage(pageInfo)
            val canvas = page.canvas
            canvas.translate(0f, -(i * pageHeight).toFloat())
            wv.draw(canvas)
            doc.finishPage(page)
        }
        FileOutputStream(out).use { fos -> doc.writeTo(fos) }
        doc.close()
        out
    } catch (t: Throwable) {
        android.util.Log.e("MarkVault", "renderWebViewToPdf failed", t)
        null
    }
}
