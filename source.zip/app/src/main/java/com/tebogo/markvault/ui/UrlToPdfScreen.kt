package com.tebogo.markvault.ui

import android.annotation.SuppressLint
import android.os.Bundle
import android.os.CancellationSignal
import android.os.ParcelFileDescriptor
import android.print.PageRange
import android.print.PrintAttributes
import android.print.PrintDocumentAdapter
import android.print.PrintDocumentInfo
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.tebogo.markvault.AppViewModel
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File
import java.io.FileOutputStream

/**
 * v5.4.10 — Convert a shared URL into a PDF file in the user's library.
 *
 * Strategy: load the URL in a hidden WebView, wait for the page to
 * finish loading (with a 2s grace period for late-loading JS), then
 * use Android's built-in WebView.createPrintDocumentAdapter() to
 * render the page to a PDF via PrintManager's print framework. The
 * resulting PDF gets saved into the user's library and opened in the
 * PDF reader.
 *
 * No external libraries required — everything in
 * android.print + android.webkit is part of the platform.
 */
@SuppressLint("SetJavaScriptEnabled")
@Composable
fun UrlToPdfScreen(
    vm: AppViewModel,
    url: String,
    onClose: () -> Unit,
    onSavedToLibrary: (relPath: String) -> Unit
) {
    val ctx = LocalContext.current
    var status by remember { mutableStateOf("Loading page\u2026") }
    var error by remember { mutableStateOf<String?>(null) }
    var done by remember { mutableStateOf(false) }

    LaunchedEffect(url) {
        try {
            status = "Loading page\u2026"
            // Hidden WebView for rendering
            val wv = WebView(ctx)
            wv.settings.javaScriptEnabled = true
            wv.settings.loadWithOverviewMode = true
            wv.settings.useWideViewPort = true

            // Wait for page load with a 2s post-load grace for late JS
            val pageReady = kotlinx.coroutines.CompletableDeferred<Unit>()
            wv.webViewClient = object : WebViewClient() {
                override fun onPageFinished(view: WebView?, finishedUrl: String?) {
                    if (!pageReady.isCompleted) pageReady.complete(Unit)
                }
            }
            wv.loadUrl(url)
            pageReady.await()
            status = "Waiting for late content\u2026"
            kotlinx.coroutines.delay(2000L)

            status = "Rendering PDF\u2026"
            // Create a temporary file for the PDF output
            val tempPdf = File.createTempFile("urlpdf_", ".pdf", ctx.cacheDir)
            val adapter = wv.createPrintDocumentAdapter("MarkVault-Web")
            val attrs = PrintAttributes.Builder()
                .setMediaSize(PrintAttributes.MediaSize.ISO_A4)
                .setResolution(PrintAttributes.Resolution("pdf", "pdf", 600, 600))
                .setMinMargins(PrintAttributes.Margins.NO_MARGINS)
                .build()

            val ok = renderToPdf(adapter, tempPdf, attrs)
            if (!ok || !tempPdf.exists() || tempPdf.length() < 256L) {
                error = "PDF rendering failed. Try \"View live website\" instead."
                runCatching { tempPdf.delete() }
                return@LaunchedEffect
            }

            status = "Saving to library\u2026"
            // Filename: hostname + short title where possible
            val host = runCatching {
                android.net.Uri.parse(url).host ?: "page"
            }.getOrElse { "page" }
            val titleGuess = runCatching {
                kotlinx.coroutines.suspendCancellableCoroutine<String?> { cont ->
                    wv.evaluateJavascript("document.title") {
                        val t = it?.trim('"')?.takeIf { s -> s.isNotBlank() && s != "null" }
                        cont.resumeWith(Result.success(t))
                    }
                }
            }.getOrNull()
            val baseName = (titleGuess ?: host)
                .replace(Regex("[\\\\/:*?\"<>|]"), "_")
                .take(80)
                .trim()
            val fileName = "$baseName.pdf"

            val saved = vm.saveSharedPdfToLibrary(tempPdf, fileName)
            runCatching { tempPdf.delete() }
            if (saved == null) {
                error = "Couldn't save to library. Is the library folder set in Settings?"
                return@LaunchedEffect
            }
            done = true
            onSavedToLibrary(saved)
        } catch (t: Throwable) {
            error = "Conversion failed: ${t.message ?: t::class.java.simpleName}"
        }
    }

    Scaffold { pad ->
        Box(
            modifier = Modifier
                .padding(pad)
                .fillMaxSize()
                .padding(24.dp),
            contentAlignment = Alignment.Center
        ) {
            Column(
                modifier = Modifier.fillMaxWidth(),
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.Center
            ) {
                Text("\uD83D\uDCC4", fontSize = 64.sp)
                Spacer(Modifier.height(16.dp))
                Text(
                    "Converting to PDF",
                    fontSize = 18.sp,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.onSurface
                )
                Spacer(Modifier.height(10.dp))
                if (error != null) {
                    Text(
                        error!!,
                        fontSize = 13.sp,
                        color = MaterialTheme.colorScheme.error
                    )
                    Spacer(Modifier.height(20.dp))
                    TextButton(onClick = onClose) { Text("Close") }
                } else if (done) {
                    Text(
                        "Done.",
                        fontSize = 13.sp,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                } else {
                    Text(
                        status,
                        fontSize = 13.sp,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                    Spacer(Modifier.height(16.dp))
                    CircularProgressIndicator()
                }
            }
        }
    }
}

/**
 * Drive a PrintDocumentAdapter through its layout + write callbacks
 * synchronously and write the resulting PDF to [outFile]. Returns
 * true if both steps reported success.
 *
 * The PrintDocumentAdapter API is callback-based and a bit awkward
 * outside a real print dialog context, but we just need the file —
 * not an actual user-facing print UI.
 */
private suspend fun renderToPdf(
    adapter: PrintDocumentAdapter,
    outFile: File,
    attrs: PrintAttributes
): Boolean = withContext(Dispatchers.Main) {
    val layoutOk = kotlinx.coroutines.CompletableDeferred<Boolean>()
    adapter.onLayout(
        null, attrs, CancellationSignal(),
        object : PrintDocumentAdapter.LayoutResultCallback() {
            override fun onLayoutFinished(info: PrintDocumentInfo?, changed: Boolean) {
                layoutOk.complete(info != null)
            }
            override fun onLayoutFailed(error: CharSequence?) {
                layoutOk.complete(false)
            }
        },
        Bundle()
    )
    if (!layoutOk.await()) return@withContext false

    val pfd = ParcelFileDescriptor.open(
        outFile,
        ParcelFileDescriptor.MODE_READ_WRITE or
            ParcelFileDescriptor.MODE_CREATE or
            ParcelFileDescriptor.MODE_TRUNCATE
    )
    val writeOk = kotlinx.coroutines.CompletableDeferred<Boolean>()
    adapter.onWrite(
        arrayOf(PageRange.ALL_PAGES),
        pfd,
        CancellationSignal(),
        object : PrintDocumentAdapter.WriteResultCallback() {
            override fun onWriteFinished(pages: Array<out PageRange>?) {
                writeOk.complete(true)
            }
            override fun onWriteFailed(error: CharSequence?) {
                writeOk.complete(false)
            }
            override fun onWriteCancelled() {
                writeOk.complete(false)
            }
        }
    )
    val ok = writeOk.await()
    runCatching { pfd.close() }
    return@withContext ok
}
