package com.tebogo.markvault.ai

/**
 * Bridge for installed offline LLM runtimes.
 * This is retrieval-only, not a chat interface.
 */
interface LocalAIProvider : QueryExpansionProvider {
    override suspend fun expandQuery(query: String): List<String>
    override fun modelName(): String
}
