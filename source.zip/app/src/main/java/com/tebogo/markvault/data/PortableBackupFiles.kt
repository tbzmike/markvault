package com.tebogo.markvault.data

import android.content.Context
import android.net.Uri
import android.provider.DocumentsContract
import org.json.JSONArray
import java.io.File
import java.io.FileInputStream
import java.io.FileOutputStream
import java.io.InputStream
import java.io.OutputStream
import java.security.MessageDigest
import java.util.zip.ZipInputStream

/**
 * Explicit-user-only transfer of SAF library files and app-private assets.
 * Paths are relative and checked, never tied to the old device's document IDs.
 * All copying is synchronous inside the existing backup/restore foreground job.
 */
internal object PortableBackupFiles {
    const val LIBRARY_PREFIX = "library/files/"
    const val DIRECTORIES_ENTRY = "library/directories.json"
    const val APP_PREFIX = "app/files/"
    const val PREF_PREFIX = "app/shared_prefs/"

    data class LibraryFile(val relativePath: String, val uri: Uri, val size: Long)
    data class LibraryTree(val files: List<LibraryFile>, val directories: List<String>)
    data class AppFile(val entry: String, val file: File)

    fun safeRel(path: String): Boolean =
        path.isNotBlank() && !path.startsWith('/') && !path.contains('\\') &&
        !path.contains('\u0000') && path.split('/').all { it.isNotBlank() && it != "." && it != ".." }

    fun scanLibrary(ctx: Context, treeString: String): LibraryTree {
        val tree = Uri.parse(treeString)
        val rootId = DocumentsContract.getTreeDocumentId(tree)
        val cr = ctx.contentResolver
        val files = mutableListOf<LibraryFile>()
        val directories = mutableListOf<String>()
        val pending = ArrayDeque<Pair<String, String>>()
        pending.add(rootId to "")
        val projection = arrayOf(
            DocumentsContract.Document.COLUMN_DOCUMENT_ID,
            DocumentsContract.Document.COLUMN_DISPLAY_NAME,
            DocumentsContract.Document.COLUMN_MIME_TYPE,
            DocumentsContract.Document.COLUMN_SIZE
        )
        while (pending.isNotEmpty()) {
            val (parentId, prefix) = pending.removeLast()
            val children = DocumentsContract.buildChildDocumentsUriUsingTree(tree, parentId)
            val cursor = cr.query(children, projection, null, null, null)
                ?: error("Cannot enumerate library folder: $prefix")
            cursor.use { c ->
                while (c.moveToNext()) {
                    val id = c.getString(0) ?: error("Missing library document ID")
                    val name = c.getString(1) ?: error("Missing library filename")
                    val path = if (prefix.isEmpty()) name else "$prefix/$name"
                    require(safeRel(path)) { "Unsafe library path: $path" }
                    if (c.getString(2) == DocumentsContract.Document.MIME_TYPE_DIR) {
                        directories.add(path)
                        pending.add(id to path)
                    } else {
                        val uri = DocumentsContract.buildDocumentUriUsingTree(tree, id)
                        val size = if (c.isNull(3)) -1L else c.getLong(3)
                        files.add(LibraryFile(path, uri, size))
                    }
                }
            }
        }
        require(files.map { it.relativePath }.toSet().size == files.size) {
            "Library has duplicate relative paths"
        }
        return LibraryTree(files.sortedBy { it.relativePath }, directories.sorted())
    }

    fun appFiles(ctx: Context): List<AppFile> {
        val root = ctx.filesDir
        val files = root.walkTopDown().filter { it.isFile }.mapNotNull { file ->
            val rel = file.relativeTo(root).invariantSeparatorsPath
            if (!safeRel(rel) || rel.startsWith("restore_pending/") ||
                rel.startsWith("datastore/") || rel.startsWith("app_updates/") ||
                rel.startsWith("crash_logs/") ||
                rel.matches(Regex("ann_(?:ivf|hnsw)_[A-Za-z0-9_-]+\\.bin")) ||
                rel.endsWith(".part") || rel.endsWith(".tmp") || rel.endsWith(".bak")) null
            else AppFile(APP_PREFIX + rel, file)
        }.toList()
        val prefsDir = File(ctx.applicationInfo.dataDir, "shared_prefs")
        val prefs = prefsDir.listFiles()?.filter { it.isFile &&
            it.name.endsWith(".xml") && safeRel(it.name) }
            ?.map { AppFile(PREF_PREFIX + it.name, it) }.orEmpty()
        return (files + prefs).sortedBy { it.entry }
    }

    fun directoryBytes(tree: LibraryTree): ByteArray =
        JSONArray(tree.directories).toString().toByteArray(Charsets.UTF_8)

    private fun verifyCreatedName(ctx: Context, uri: Uri, expected: String) {
        ctx.contentResolver.query(uri, arrayOf(DocumentsContract.Document.COLUMN_DISPLAY_NAME),
            null, null, null)?.use { c ->
            require(c.moveToFirst() && c.getString(0) == expected) {
                "Destination provider renamed $expected; portable path cannot be preserved"
            }
        } ?: error("Cannot verify destination filename $expected")
    }

    private fun hash(stream: InputStream): String {
        val digest = MessageDigest.getInstance("SHA-256")
        val buf = ByteArray(128 * 1024)
        while (true) {
            val count = stream.read(buf)
            if (count < 0) break
            if (count > 0) digest.update(buf, 0, count)
        }
        return digest.digest().joinToString("") { "%02x".format(it) }
    }

    /**
     * Install into an explicitly selected SAF tree. Existing files must match
     * the verified archive byte-for-byte: a restore must never overwrite a
     * different user document. Newly created files/dirs are rolled back if
     * any file cannot be restored.
     */
    fun restoreLibrary(ctx: Context, source: Uri, treeString: String): Int {
        val cr = ctx.contentResolver
        val tree = Uri.parse(treeString)
        val rootId = DocumentsContract.getTreeDocumentId(tree)
        val dirIds = mutableMapOf("" to rootId)
        val existingFiles = mutableMapOf<String, Uri>()
        val made = mutableListOf<Uri>()
        val existing = scanLibrary(ctx, treeString)
        existing.files.forEach { existingFiles[it.relativePath] = it.uri }
        // Resolve existing subtrees once; no per-file full-tree scan.
        val queue = ArrayDeque<Pair<String, String>>()
        queue.add("" to rootId)
        while (queue.isNotEmpty()) {
            val (prefix, id) = queue.removeFirst()
            val children = DocumentsContract.buildChildDocumentsUriUsingTree(tree, id)
            cr.query(children, arrayOf(
                DocumentsContract.Document.COLUMN_DOCUMENT_ID,
                DocumentsContract.Document.COLUMN_DISPLAY_NAME,
                DocumentsContract.Document.COLUMN_MIME_TYPE
            ), null, null, null)?.use { c ->
                while (c.moveToNext()) {
                    if (c.getString(2) != DocumentsContract.Document.MIME_TYPE_DIR) continue
                    val path = if (prefix.isEmpty()) c.getString(1) else "$prefix/${c.getString(1)}"
                    val childId = c.getString(0)
                    dirIds[path] = childId
                    queue.add(path to childId)
                }
            } ?: error("Cannot read target library folders")
        }
        fun ensureDir(path: String): String {
            if (path.isEmpty()) return rootId
            dirIds[path]?.let { return it }
            require(safeRel(path)) { "Unsafe folder path" }
            val parent = path.substringBeforeLast('/', "")
            val parentId = ensureDir(parent)
            val parentUri = DocumentsContract.buildDocumentUriUsingTree(tree, parentId)
            val uri = DocumentsContract.createDocument(
                cr, parentUri, DocumentsContract.Document.MIME_TYPE_DIR, path.substringAfterLast('/')
            ) ?: error("Cannot create destination folder: $path")
            made.add(uri)
            verifyCreatedName(ctx, uri, path.substringAfterLast('/'))
            val id = DocumentsContract.getDocumentId(uri)
            dirIds[path] = id
            return id
        }
        var installed = 0
        try {
            cr.openInputStream(source)?.buffered()?.use { raw ->
                ZipInputStream(raw).use { zip ->
                    var entry = zip.nextEntry
                    while (entry != null) {
                        if (entry.name == DIRECTORIES_ENTRY) {
                            val dirs = JSONArray(zip.readBytes().toString(Charsets.UTF_8))
                            for (i in 0 until dirs.length()) ensureDir(dirs.getString(i))
                        } else if (entry.name.startsWith(LIBRARY_PREFIX)) {
                            val path = entry.name.removePrefix(LIBRARY_PREFIX)
                            require(safeRel(path) && !entry.isDirectory) { "Unsafe backup library file" }
                            val current = existingFiles[path]
                            if (current != null) {
                                // Never clobber a file in the user's selected folder.
                                val actual = cr.openInputStream(current)?.use { hash(it) }
                                    ?: error("Cannot verify existing file $path")
                                val expected = hash(zip)
                                require(actual.equals(expected, true)) {
                                    "Destination contains a different file: $path"
                                }
                            } else {
                                val parentId = ensureDir(path.substringBeforeLast('/', ""))
                                val parentUri = DocumentsContract.buildDocumentUriUsingTree(tree, parentId)
                                val name = path.substringAfterLast('/')
                                val mime = when (name.substringAfterLast('.', "").lowercase()) {
                                    "md", "txt" -> "text/plain"
                                    "html", "htm" -> "text/html"
                                    "pdf" -> "application/pdf"
                                    "json" -> "application/json"
                                    else -> "application/octet-stream"
                                }
                                val created = DocumentsContract.createDocument(cr, parentUri, mime, name)
                                    ?: error("Cannot create library file $path")
                                made.add(created)
                                verifyCreatedName(ctx, created, name)
                                cr.openOutputStream(created, "w")?.use { zip.copyTo(it, 128 * 1024) }
                                    ?: error("Cannot write library file $path")
                                existingFiles[path] = created
                                installed++
                            }
                        }
                        zip.closeEntry()
                        entry = zip.nextEntry
                    }
                }
            } ?: error("Backup document cannot be opened")
            return installed
        } catch (error: Exception) {
            made.asReversed().forEach { runCatching { DocumentsContract.deleteDocument(cr, it) } }
            throw error
        }
    }

    /** Stream restored model and app files to verified per-file staging first. */
    fun restoreAppFiles(ctx: Context, source: Uri, staging: File) {
        val staged = File(staging, "portable_app")
        staged.mkdirs()
        ctx.contentResolver.openInputStream(source)?.buffered()?.use { raw ->
            ZipInputStream(raw).use { zip ->
                var entry = zip.nextEntry
                while (entry != null) {
                    val rel = when {
                        entry.name.startsWith(APP_PREFIX) -> entry.name.removePrefix(APP_PREFIX)
                        entry.name.startsWith(PREF_PREFIX) -> "shared_prefs/" + entry.name.removePrefix(PREF_PREFIX)
                        else -> null
                    }
                    if (rel != null) {
                        require(!entry.isDirectory && safeRel(rel)) { "Unsafe portable file path" }
                        val target = File(staged, rel)
                        require(target.canonicalPath.startsWith(staged.canonicalPath + File.separator)) {
                            "Portable file escapes staging root"
                        }
                        target.parentFile?.mkdirs()
                        FileOutputStream(target).use { output ->
                            zip.copyTo(output, 128 * 1024)
                            output.fd.sync()
                        }
                    }
                    zip.closeEntry()
                    entry = zip.nextEntry
                }
            }
        } ?: error("Cannot open portable app archive")
    }

    /**
     * User-owned app files are installed with per-file rollback. SharedPrefs
     * stay staged for cold start because the live preferences cache is active.
     */
    fun installAppFiles(ctx: Context, staging: File) {
        val src = File(staging, "portable_app")
        if (!src.isDirectory) return
        val rollback = mutableListOf<Pair<File, File?>>()
        try {
            src.walkTopDown().filter { it.isFile && !it.relativeTo(src).invariantSeparatorsPath.startsWith("shared_prefs/") }
                .forEach { file ->
                    val rel = file.relativeTo(src).invariantSeparatorsPath
                    require(safeRel(rel)) { "Unsafe application file path" }
                    val target = File(ctx.filesDir, rel)
                    target.parentFile?.mkdirs()
                    val saved = if (target.exists()) File(target.parentFile, target.name + ".mv551_rollback") else null
                    saved?.let { require(!it.exists() && target.renameTo(it)) { "Cannot back up $rel" } }
                    rollback.add(target to saved)
                    try {
                        FileInputStream(file).use { input ->
                            FileOutputStream(target).use { output ->
                                input.copyTo(output, 128 * 1024)
                                output.fd.sync()
                            }
                        }
                        require(file.length() == target.length()) { "App file copy failed: $rel" }
                    } catch (e: Exception) {
                        throw e
                    }
                }
            rollback.forEach { (_, saved) -> saved?.delete() }
        } catch (e: Exception) {
            rollback.asReversed().forEach { (target, saved) ->
                runCatching {
                    target.delete()
                    if (saved != null) saved.renameTo(target)
                }
            }
            throw e
        }
        val prefsStaged = File(src, "shared_prefs")
        if (prefsStaged.isDirectory) {
            val pending = File(ctx.filesDir, "restore_pending/shared_prefs").apply { mkdirs() }
            prefsStaged.listFiles()?.filter { it.isFile && it.name.endsWith(".xml") }
                ?.forEach { file ->
                    val target = File(pending, file.name)
                    FileInputStream(file).use { input ->
                        FileOutputStream(target).use { output ->
                            input.copyTo(output)
                            output.fd.sync()
                        }
                    }
                }
        }
    }

    fun applyPendingSharedPrefs(ctx: Context) {
        val pending = File(ctx.filesDir, "restore_pending/shared_prefs")
        if (!pending.isDirectory) return
        val dest = File(ctx.applicationInfo.dataDir, "shared_prefs").apply { mkdirs() }
        pending.listFiles()?.filter { it.isFile && it.name.endsWith(".xml") }?.forEach { source ->
            val target = File(dest, source.name)
            val saved = File(dest, source.name + ".mv551_rollback")
            try {
                saved.delete()
                if (target.exists()) require(target.renameTo(saved)) { "Could not save existing preferences" }
                FileInputStream(source).use { input ->
                    FileOutputStream(target).use { output ->
                        input.copyTo(output)
                        output.fd.sync()
                    }
                }
                require(target.length() == source.length()) { "Restored preferences size mismatch" }
                saved.delete()
                source.delete()
            } catch (e: Exception) {
                target.delete()
                if (saved.exists()) saved.renameTo(target)
                throw e
            }
        }
        pending.delete()
    }
}
