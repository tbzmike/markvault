package com.tebogo.markvault.data

import android.content.Context
import android.net.Uri
import android.provider.DocumentsContract
import org.json.JSONArray
import java.io.File
import java.io.FileInputStream
import java.io.FileOutputStream
import java.io.InputStream
import java.io.OutputStream
import java.security.MessageDigest
import java.security.DigestInputStream
import java.util.Locale

/**
 * Explicit-user-only transfer of SAF library files and app-private assets.
 * Paths are relative and checked, never tied to the old device's document IDs.
 * All copying is synchronous inside the existing backup/restore foreground job.
 */
internal object PortableBackupFiles {
    const val LIBRARY_PREFIX = "library/files/"
    const val DIRECTORIES_ENTRY = "library/directories.json"
    const val APP_PREFIX = "app/files/"
    const val PREF_PREFIX = "app/shared_prefs/"

    data class LibraryFile(
        val relativePath: String,
        val uri: Uri,
        val size: Long,
        val sourceRelativePath: String = relativePath,
        val lastModified: Long = 0L
    )
    data class LibraryTree(
        val files: List<LibraryFile>,
        val directories: List<String>,
        val directoryIds: Map<String, String> = emptyMap()
    )
    data class AppFile(val entry: String, val file: File)

    fun safeRel(path: String): Boolean =
        path.isNotBlank() && !path.startsWith('/') && !path.contains('\\') &&
        !path.contains('\u0000') && path.split('/').all { it.isNotBlank() && it != "." && it != ".." }

    fun scanLibrary(ctx: Context, treeString: String, onScan: (Int) -> Unit = {}): LibraryTree {
        var lastScanReport = 0L
        val tree = Uri.parse(treeString)
        val rootId = DocumentsContract.getTreeDocumentId(tree)
        val cr = ctx.contentResolver
        val files = mutableListOf<LibraryFile>()
        val directories = mutableListOf<String>()
        val directoryIds = mutableMapOf("" to rootId)
        val visitedDirectories = HashSet<String>()
        // Each branch has its archive path and its *original* provider path.
        val pending = ArrayDeque<Triple<String, String, String>>()
        pending.add(Triple(rootId, "", ""))
        val projection = arrayOf(
            DocumentsContract.Document.COLUMN_DOCUMENT_ID,
            DocumentsContract.Document.COLUMN_DISPLAY_NAME,
            DocumentsContract.Document.COLUMN_MIME_TYPE,
            DocumentsContract.Document.COLUMN_SIZE,
            DocumentsContract.Document.COLUMN_LAST_MODIFIED
        )
        data class Row(val id: String, val name: String, val mime: String, val size: Long, val modified: Long)
        while (pending.isNotEmpty()) {
            val (parentId, prefix, originalPrefix) = pending.removeLast()
            // An alias/cycle must not recursively duplicate the whole tree.
            if (!visitedDirectories.add(parentId)) continue
            val children = DocumentsContract.buildChildDocumentsUriUsingTree(tree, parentId)
            val cursor = cr.query(children, projection, null, null, null)
                ?: error("Cannot enumerate library folder: $originalPrefix")
            val rows = mutableListOf<Row>()
            cursor.use { c ->
                while (c.moveToNext()) {
                    val id = c.getString(0) ?: error("Missing library document ID")
                    val name = c.getString(1) ?: error("Missing library filename")
                    val mime = c.getString(2).orEmpty()
                    val size = if (c.isNull(3)) -1L else c.getLong(3)
                    val modified = if (c.isNull(4)) 0L else c.getLong(4)
                    rows.add(Row(id, name, mime, size, modified))
                }
            }
            val distinctRows = rows.sortedWith(compareBy<Row>({ it.name.lowercase(java.util.Locale.ROOT) }, { it.id }, { it.name }))
                .distinctBy { it.id }
            val byId = distinctRows.associateBy { it.id }
            for (assigned in PortableLibraryPaths.assign(distinctRows.map { PortableLibraryPaths.Child(it.id, it.name) })) {
                val row = byId[assigned.child.documentId] ?: error("Missing document metadata")
                val path = if (prefix.isEmpty()) assigned.archiveName else "$prefix/${assigned.archiveName}"
                val original = if (originalPrefix.isEmpty()) row.name else "$originalPrefix/${row.name}"
                require(safeRel(path) && safeRel(original)) { "Unsafe library document path: $original" }
                if (row.mime == DocumentsContract.Document.MIME_TYPE_DIR) {
                    directories.add(path)
                    directoryIds[path] = row.id
                    pending.add(Triple(row.id, path, original))
                } else {
                    val uri = DocumentsContract.buildDocumentUriUsingTree(tree, row.id)
                    files.add(LibraryFile(path, uri, row.size, original, row.modified))
                    val now = System.nanoTime()
                    if (now - lastScanReport >= 500_000_000L) {
                        onScan(files.size)
                        lastScanReport = now
                    }
                }
            }
        }
        // Never silently drop different documents or overwrite a ZIP member.
        require(files.map { it.relativePath }.toSet().size == files.size) {
            "Cannot produce unique archive paths for the library"
        }
        val directorySet = directories.toHashSet()
        require(files.none { it.relativePath in directorySet }) { "Library contains file/directory path conflicts" }
        onScan(files.size)
        return LibraryTree(files.sortedBy { it.relativePath }, directories.sorted(), directoryIds)
    }

    fun appFiles(ctx: Context): List<AppFile> {
        val root = ctx.filesDir
        val files = root.walkTopDown().filter { it.isFile }.mapNotNull { file ->
            val rel = file.relativeTo(root).invariantSeparatorsPath
            if (!safeRel(rel) || rel.startsWith("restore_pending/") ||
                rel.startsWith("datastore/") || rel.startsWith("app_updates/") ||
                rel.startsWith("crash_logs/") ||
                rel.matches(Regex("ann_(?:ivf|hnsw)_[A-Za-z0-9_-]+\\.bin")) ||
                rel.endsWith(".part") || rel.endsWith(".tmp") || rel.endsWith(".bak")) null
            else AppFile(APP_PREFIX + rel, file)
        }.toList()
        val prefsDir = File(ctx.applicationInfo.dataDir, "shared_prefs")
        val prefs = prefsDir.listFiles()?.filter { it.isFile &&
            it.name.endsWith(".xml") && safeRel(it.name) }
            ?.map { AppFile(PREF_PREFIX + it.name, it) }.orEmpty()
        return (files + prefs).sortedBy { it.entry }
    }

    fun directoryBytes(tree: LibraryTree): ByteArray =
        JSONArray(tree.directories).toString().toByteArray(Charsets.UTF_8)

    private fun verifyCreatedName(ctx: Context, uri: Uri, expected: String) {
        ctx.contentResolver.query(uri, arrayOf(DocumentsContract.Document.COLUMN_DISPLAY_NAME),
            null, null, null)?.use { c ->
            require(c.moveToFirst() && c.getString(0) == expected) {
                "Destination provider renamed $expected; portable path cannot be preserved"
            }
        } ?: error("Cannot verify destination filename $expected")
    }

    private fun hash(stream: InputStream, buf: ByteArray): String {
        val digest = MessageDigest.getInstance("SHA-256")
        while (true) {
            val count = stream.read(buf)
            if (count < 0) break
            if (count > 0) digest.update(buf, 0, count)
        }
        return BackupZipIO.hex(digest.digest())
    }

    data class LibraryRestoreResult(
        val installed: Int,
        val conflicts: Int,
        val documentIds: Map<String, String>
    )

    /**
     * The manifest was verified before this pass. Reuse identical documents;
     * never overwrite different destination data. A conflicting archive file
     * gets a deterministic sibling name and an explicit archive-path -> SAF ID
     * mapping. This also makes retrying a partially completed restore safe.
     * Newly created files/dirs are rolled back if this file pass fails.
     */
    fun restoreLibrary(
        ctx: Context, source: Uri, treeString: String,
        expectedHashes: Map<String, String>,
        directoryHash: String? = null,
        onActivity: (String, Long, Long) -> Unit = { _, _, _ -> },
        onProgress: (Long, Long) -> Unit = { _, _ -> }
    ): LibraryRestoreResult {
        val cr = ctx.contentResolver
        val tree = Uri.parse(treeString)
        val rootId = DocumentsContract.getTreeDocumentId(tree)
        val dirIds = mutableMapOf("" to rootId)
        val existingFiles = mutableMapOf<String, Uri>()
        val made = mutableListOf<Uri>()
        val restoredIds = LinkedHashMap<String, String>(expectedHashes.size)
        val buffer = ByteArray(128 * 1024)
        val existing = scanLibrary(ctx, treeString) { count ->
            onActivity("Scanning existing library… ($count files found)", 0, expectedHashes.size.toLong())
        }
        fun key(path: String) = path.lowercase(Locale.ROOT)
        val occupied = HashSet<String>()
        val reserved = HashSet<String>()
        val sha256Pattern = Regex("[0-9a-fA-F]{64}")
        for ((path, hash) in expectedHashes) {
            require(safeRel(path) && hash.matches(sha256Pattern)) { "Invalid library checksum: $path" }
            var prefix = path
            while (prefix.isNotEmpty()) {
                reserved.add(key(prefix))
                prefix = prefix.substringBeforeLast('/', "")
            }
        }
        existing.files.forEach {
            existingFiles[it.relativePath] = it.uri
            occupied.add(key(it.relativePath))
            // Also reserve raw names from providers with duplicate display names.
            occupied.add(key(it.sourceRelativePath))
        }
        dirIds.putAll(existing.directoryIds)
        occupied.addAll(existing.directories.map { key(it) })
        fun ensureDir(path: String): String {
            if (path.isEmpty()) return rootId
            dirIds[path]?.let { return it }
            require(safeRel(path)) { "Unsafe folder path" }
            require(key(path) !in occupied) {
                "Destination has a file or differently named folder at $path. Choose an empty restore folder."
            }
            val parentId = ensureDir(path.substringBeforeLast('/', ""))
            val parentUri = DocumentsContract.buildDocumentUriUsingTree(tree, parentId)
            val uri = DocumentsContract.createDocument(
                cr, parentUri, DocumentsContract.Document.MIME_TYPE_DIR, path.substringAfterLast('/')
            ) ?: error("Cannot create destination folder: $path")
            made.add(uri)
            verifyCreatedName(ctx, uri, path.substringAfterLast('/'))
            val id = DocumentsContract.getDocumentId(uri)
            dirIds[path] = id
            occupied.add(key(path))
            return id
        }
        fun matches(uri: Uri, expected: String, path: String): Boolean =
            cr.openInputStream(uri)?.use { hash(it, buffer).equals(expected, true) }
                ?: error("Cannot verify existing file $path")
        // Obsidian uses the original .obsidian filenames as live configuration.
        // Keep the destination's live settings untouched; retain incoming
        // conflicting configuration in a separate vault-relative recovery tree.
        var obsidianConflictRoot: String? = null
        fun obsidianRecoveryRoot(): String {
            obsidianConflictRoot?.let { return it }
            var suffix = 1
            while (true) {
                val candidate = if (suffix == 1) ".markvault-restore-conflicts"
                    else ".markvault-restore-conflicts-$suffix"
                if (key(candidate) !in reserved &&
                    (key(candidate) !in occupied || candidate in dirIds)) {
                    ensureDir(candidate)
                    obsidianConflictRoot = candidate
                    return candidate
                }
                suffix++
            }
        }
        fun conflictPath(path: String, expected: String): String {
            val originalParent = path.substringBeforeLast('/', "")
            val isObsidian = path.substringBefore('/').equals(".obsidian", ignoreCase = true)
            val parent = if (isObsidian) "${obsidianRecoveryRoot()}/$originalParent".trimEnd('/')
                else originalParent
            val name = path.substringAfterLast('/')
            val dot = name.lastIndexOf('.')
            val stem = if (dot > 0) name.substring(0, dot) else name
            val ext = if (dot > 0) name.substring(dot) else ""
            var suffix = 1
            while (true) {
                val label = if (suffix == 1) "MarkVault restored ${expected.take(12).lowercase(Locale.ROOT)}"
                    else "MarkVault restored ${expected.take(12).lowercase(Locale.ROOT)} $suffix"
                val nameCopy = "$stem ($label)$ext"
                val candidate = if (parent.isEmpty()) nameCopy else "$parent/$nameCopy"
                if (key(candidate) !in reserved) {
                    val prior = existingFiles[candidate]
                    if (prior != null && matches(prior, expected, candidate)) return candidate
                    if (key(candidate) !in occupied) return candidate
                }
                suffix++
            }
        }
        var installed = 0
        var conflicts = 0
        var lastProgressNs = 0L
        try {
            onProgress(0, expectedHashes.size.toLong())
            BackupZipIO.visit(ctx, source, { it.name == DIRECTORIES_ENTRY || it.name.startsWith(LIBRARY_PREFIX) }) { entry, zip ->
                        if (entry.name == DIRECTORIES_ENTRY) {
                            val directoryBytes = if (directoryHash == null) zip.readBytes()
                                else BackupZipIO.checked(zip, directoryHash) { it.readBytes() }
                            val dirs = JSONArray(directoryBytes.toString(Charsets.UTF_8))
                            for (i in 0 until dirs.length()) {
                                val dir = dirs.getString(i)
                                require(safeRel(dir)) { "Unsafe backup folder" }
                                reserved.add(key(dir))
                                ensureDir(dir)
                            }
                        } else if (entry.name.startsWith(LIBRARY_PREFIX)) {
                            val path = entry.name.removePrefix(LIBRARY_PREFIX)
                            require(safeRel(path) && !entry.isDirectory && path !in restoredIds) {
                                "Unsafe or duplicate backup library file"
                            }
                            val expected = expectedHashes[path] ?: error("Library file absent from verified manifest: $path")
                            val current = existingFiles[path]
                            val target = if (current != null && matches(current, expected, path)) path
                                else if (key(path) in occupied) {
                                    conflicts++
                                    conflictPath(path, expected)
                                } else path
                            val reused = existingFiles[target]
                            val resolved = if (reused != null) reused else {
                                val parentId = ensureDir(target.substringBeforeLast('/', ""))
                                val parentUri = DocumentsContract.buildDocumentUriUsingTree(tree, parentId)
                                val name = target.substringAfterLast('/')
                                val mime = when (name.substringAfterLast('.', "").lowercase(Locale.ROOT)) {
                                    "md", "txt" -> "text/plain"
                                    "html", "htm" -> "text/html"
                                    "pdf" -> "application/pdf"
                                    "json" -> "application/json"
                                    else -> "application/octet-stream"
                                }
                                val created = DocumentsContract.createDocument(cr, parentUri, mime, name)
                                    ?: error("Cannot create library file $target")
                                made.add(created)
                                verifyCreatedName(ctx, created, name)
                                // Do not close DigestInputStream: it wraps the current ZIP entry.
                                val digest = MessageDigest.getInstance("SHA-256")
                                cr.openOutputStream(created, "w")?.use { output ->
                                    var copied = 0L
                                    BackupZipIO.copy(DigestInputStream(zip, digest), output, buffer) { n ->
                                        copied += n
                                        val now = System.nanoTime()
                                        if (now - lastProgressNs >= 500_000_000L) {
                                            onActivity("Restoring library file… (${copied / 1048576} MiB: ${name.take(48)})",
                                                restoredIds.size.toLong(), expectedHashes.size.toLong())
                                            lastProgressNs = now
                                        }
                                    }
                                } ?: error("Cannot write library file $target")
                                require(BackupZipIO.hex(digest.digest()).equals(expected, true)) {
                                    "Backup file changed during restore: $path"
                                }
                                existingFiles[target] = created
                                occupied.add(key(target))
                                // Prevent a later archive member from reusing this new name.
                                reserved.add(key(target))
                                installed++
                                created
                            }
                            restoredIds[path] = DocumentsContract.getDocumentId(resolved)
                            val now = System.nanoTime()
                            if (now - lastProgressNs >= 500_000_000L) {
                                onProgress(restoredIds.size.toLong(), expectedHashes.size.toLong())
                                lastProgressNs = now
                            }
                        }
            }
            require(restoredIds.keys == expectedHashes.keys) { "Some verified library files were not restored" }
            require(restoredIds.values.toSet().size == restoredIds.size) { "Distinct backup files resolved to the same document" }
            onProgress(restoredIds.size.toLong(), expectedHashes.size.toLong())
            return LibraryRestoreResult(installed, conflicts, restoredIds)
        } catch (error: Exception) {
            made.asReversed().forEach { runCatching { DocumentsContract.deleteDocument(cr, it) } }
            throw error
        }
    }

    /** Stream restored model and app files to verified per-file staging first. */
    fun restoreAppFiles(ctx: Context, source: Uri, staging: File, expectedHash: (String) -> String,
                        onBytes: (Long) -> Unit = {}) {
        val staged = File(staging, "portable_app")
        staged.mkdirs()
        val buffer = ByteArray(128 * 1024)
        var bytes = 0L
        var last = 0L
        BackupZipIO.visitVerified(ctx, source, expectedHash, { it.name.startsWith(APP_PREFIX) || it.name.startsWith(PREF_PREFIX) }) { entry, zip ->
            val rel = if (entry.name.startsWith(APP_PREFIX)) entry.name.removePrefix(APP_PREFIX)
                else "shared_prefs/" + entry.name.removePrefix(PREF_PREFIX)
            require(!entry.isDirectory && safeRel(rel)) { "Unsafe portable file path" }
            val target = File(staged, rel)
            require(target.canonicalPath.startsWith(staged.canonicalPath + File.separator)) { "Portable file escapes staging root" }
            target.parentFile?.mkdirs()
            FileOutputStream(target).use { output ->
                BackupZipIO.copy(zip, output, buffer) { n ->
                    bytes += n
                    val now = System.nanoTime()
                    if (now - last >= 500_000_000L) { onBytes(bytes); last = now }
                }
                output.fd.sync()
            }
        }
        onBytes(bytes)
    }

    /**
     * User-owned app files are installed with per-file rollback. SharedPrefs
     * stay staged for cold start because the live preferences cache is active.
     */
    fun installAppFiles(ctx: Context, staging: File, onProgress: (Long, Long) -> Unit = { _, _ -> }) {
        val src = File(staging, "portable_app")
        if (!src.isDirectory) return
        val rollback = mutableListOf<Pair<File, File?>>()
        try {
            val files = src.walkTopDown().filter { it.isFile && !it.relativeTo(src).invariantSeparatorsPath.startsWith("shared_prefs/") }.toList()
            val total = files.sumOf { it.length() }
            var done = 0L
            var last = 0L
            val buffer = ByteArray(128 * 1024)
            files.forEach { file ->
                    val rel = file.relativeTo(src).invariantSeparatorsPath
                    require(safeRel(rel)) { "Unsafe application file path" }
                    val target = File(ctx.filesDir, rel)
                    target.parentFile?.mkdirs()
                    val saved = if (target.exists()) File(target.parentFile, target.name + ".mv551_rollback") else null
                    saved?.let { require(!it.exists() && target.renameTo(it)) { "Cannot back up $rel" } }
                    rollback.add(target to saved)
                    try {
                        FileInputStream(file).use { input ->
                            FileOutputStream(target).use { output ->
                                BackupZipIO.copy(input, output, buffer) { n ->
                                    done += n
                                    val now = System.nanoTime()
                                    if (now - last >= 500_000_000L) { onProgress(done, total); last = now }
                                }
                                output.fd.sync()
                            }
                        }
                        require(file.length() == target.length()) { "App file copy failed: $rel" }
                    } catch (e: Exception) {
                        throw e
                    }
                }
            onProgress(done, total)
            rollback.forEach { (_, saved) -> saved?.delete() }
        } catch (e: Exception) {
            rollback.asReversed().forEach { (target, saved) ->
                runCatching {
                    target.delete()
                    if (saved != null) saved.renameTo(target)
                }
            }
            throw e
        }
        val prefsStaged = File(src, "shared_prefs")
        if (prefsStaged.isDirectory) {
            val pending = File(ctx.filesDir, "restore_pending/shared_prefs").apply { mkdirs() }
            prefsStaged.listFiles()?.filter { it.isFile && it.name.endsWith(".xml") }
                ?.forEach { file ->
                    val target = File(pending, file.name)
                    FileInputStream(file).use { input ->
                        FileOutputStream(target).use { output ->
                            input.copyTo(output)
                            output.fd.sync()
                        }
                    }
                }
        }
    }

    fun applyPendingSharedPrefs(ctx: Context) {
        val pending = File(ctx.filesDir, "restore_pending/shared_prefs")
        if (!pending.isDirectory) return
        val dest = File(ctx.applicationInfo.dataDir, "shared_prefs").apply { mkdirs() }
        pending.listFiles()?.filter { it.isFile && it.name.endsWith(".xml") }?.forEach { source ->
            val target = File(dest, source.name)
            val saved = File(dest, source.name + ".mv551_rollback")
            try {
                saved.delete()
                if (target.exists()) require(target.renameTo(saved)) { "Could not save existing preferences" }
                FileInputStream(source).use { input ->
                    FileOutputStream(target).use { output ->
                        input.copyTo(output)
                        output.fd.sync()
                    }
                }
                require(target.length() == source.length()) { "Restored preferences size mismatch" }
                saved.delete()
                source.delete()
            } catch (e: Exception) {
                target.delete()
                if (saved.exists()) saved.renameTo(target)
                throw e
            }
        }
        pending.delete()
    }
}
