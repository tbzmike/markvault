package com.tebogo.markvault.search

import ai.onnxruntime.OnnxTensor
import ai.onnxruntime.OrtEnvironment
import ai.onnxruntime.OrtSession
import android.content.Context
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.isActive
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import kotlinx.coroutines.withContext
import java.io.File
import java.io.FileOutputStream
import java.net.HttpURLConnection
import java.net.URL
import java.nio.LongBuffer
import kotlin.coroutines.coroutineContext

/**
 * v4.23.0 — Cross-encoder reranker for second-stage search ranking.
 *
 * # How a cross-encoder differs from an embedder
 *
 * The existing [Embedder] produces ONE vector per text, computed once at
 * indexing time. Searches then cosine-compare the query vector against
 * every cached document vector. Fast, scalable to 14k+ notes, but limited:
 * cosine in shared embedding space is a rough estimate of relevance.
 *
 * A cross-encoder is the opposite — it takes a query AND a document
 * TOGETHER as a single input and produces ONE relevance score. This means
 * the model can attend across both texts, catching subtleties like "this
 * doc mentions Jerusalem repeatedly but is about a different city" that
 * cosine can't. The tradeoff is cost: every (query, doc) pair needs its
 * own model invocation. Not scalable to 14k notes per query.
 *
 * # The two-stage pipeline
 *
 *   1. Embedder produces cosine ranking → top 30 candidates (~5 ms)
 *   2. Reranker scores each candidate vs query → final top 10 (~3–5 s)
 *
 * Stage 1 narrows from "everything" to "plausibly relevant". Stage 2
 * refines the ranking among those. Result: search quality jumps without
 * a per-query scan of 14k notes.
 *
 * # Why ms-marco-MiniLM-L-12-v2
 *
 * See [RerankerCatalog.MS_MARCO_MINI_LM_L12]. Industry standard, small
 * (33 MB quantized), Apache 2.0 licensed, ONNX-ready via the Xenova
 * export we already trust for BGE-large.
 *
 * # Why a foreground download isn't used here
 *
 * The chat LLM is 400+ MB so we built a foreground service for it. The
 * reranker is 33 MB — a few seconds on most networks, ~30 s on slower
 * mobile data. Downloading in a viewModelScope coroutine is simpler and
 * good enough. If the download is interrupted, [download] cleans up the
 * `.part` file and the user retries.
 */
class Reranker(private val context: Context) {

    private val descriptor: RerankerDescriptor = RerankerCatalog.default
    private val modelFile: File = descriptor.modelFileIn(context.filesDir)
    private val vocabFile: File = descriptor.vocabFileIn(context.filesDir)

    @Volatile private var session: OrtSession? = null
    @Volatile private var tokenizer: BertTokenizer? = null
    private val loadLock = Mutex()

    /** True iff both model and vocab files are present and big enough. */
    fun isInstalled(): Boolean = descriptor.isInstalled(context.filesDir)

    /** True iff the ONNX session is currently loaded in memory. */
    val isLoaded: Boolean get() = session != null

    /**
     * Score how relevant [doc] is to [query]. Higher = more relevant.
     * Returns null if the model can't be loaded or tokenization fails.
     *
     * The score is the raw logit from the model — typically in the range
     * `-15..+15`. Reranking only depends on relative ordering, so the
     * absolute scale doesn't matter. Caller treats null as "unable to
     * score" and should fall back to the cosine score in that case.
     */
    suspend fun score(query: String, doc: String): Float? = withContext(Dispatchers.IO) {
        if (!ensureLoaded()) return@withContext null
        val sess = session ?: return@withContext null
        val tok = tokenizer ?: return@withContext null

        runCatching {
            val enc = tok.encodePair(query, doc, maxLength = descriptor.maxSeqLen)
            runScoreInternal(sess, enc)
        }.getOrNull()
    }

    /**
     * Batched scoring — same query against many docs. Sequential
     * inference but reuses the loaded session, which is the expensive
     * part. Returns one score per doc in the same order. Nulls in the
     * output mean that pair couldn't be scored (caller falls back to
     * the cosine score for those).
     *
     * Cancellable: checks coroutine cancellation between docs so the
     * caller can abort if the user cancels the search.
     */
    suspend fun scoreBatch(query: String, docs: List<String>): FloatArray = withContext(Dispatchers.IO) {
        val out = FloatArray(docs.size) { Float.NaN }
        if (!ensureLoaded()) return@withContext out
        val sess = session ?: return@withContext out
        val tok = tokenizer ?: return@withContext out

        for ((i, doc) in docs.withIndex()) {
            if (!coroutineContext.isActive) break
            runCatching {
                val enc = tok.encodePair(query, doc, maxLength = descriptor.maxSeqLen)
                runScoreInternal(sess, enc)
            }.onSuccess { out[i] = it }
        }
        out
    }

    /**
     * Build the three ONNX input tensors from a [BertTokenizer.PairEncoding]
     * and run a single forward pass. Output shape is `[1, 1]` containing
     * the raw logit.
     */
    private fun runScoreInternal(
        sess: OrtSession,
        enc: BertTokenizer.PairEncoding
    ): Float {
        val seqLen = enc.inputIds.size
        val inputIds = LongArray(seqLen) { enc.inputIds[it].toLong() }
        val attentionMask = LongArray(seqLen) { enc.attentionMask[it].toLong() }
        val tokenTypeIds = LongArray(seqLen) { enc.tokenTypeIds[it].toLong() }
        val env = OrtEnvironment.getEnvironment()
        val shape = longArrayOf(1L, seqLen.toLong())

        return OnnxTensor.createTensor(env, LongBuffer.wrap(inputIds), shape).use { idsT ->
            OnnxTensor.createTensor(env, LongBuffer.wrap(attentionMask), shape).use { maskT ->
                OnnxTensor.createTensor(env, LongBuffer.wrap(tokenTypeIds), shape).use { typeT ->
                    val inputs = mapOf(
                        "input_ids" to idsT,
                        "attention_mask" to maskT,
                        "token_type_ids" to typeT
                    )
                    sess.run(inputs).use { results ->
                        // Cross-encoder output: logits of shape [1, 1].
                        // The Xenova export uses the standard
                        // SequenceClassification head.
                        @Suppress("UNCHECKED_CAST")
                        val arr = results[0].value as? Array<FloatArray>
                            ?: return@use 0f
                        arr[0][0]
                    }
                }
            }
        }
    }

    /**
     * Load the ONNX session and tokenizer if not already loaded.
     * Idempotent. Returns true iff both are ready after this call.
     */
    private suspend fun ensureLoaded(): Boolean = loadLock.withLock {
        if (session != null && tokenizer != null) return@withLock true
        if (!isInstalled()) return@withLock false

        if (tokenizer == null) {
            val vocabMap = runCatching {
                BertTokenizer.buildVocabMap(vocabFile.readLines())
            }.getOrElse { return@withLock false }
            if (!BertTokenizer.isVocabUsable(vocabMap)) return@withLock false
            tokenizer = BertTokenizer(vocabMap)
        }

        if (session == null) {
            session = runCatching {
                val env = OrtEnvironment.getEnvironment()
                val opts = OrtSession.SessionOptions()
                env.createSession(modelFile.absolutePath, opts)
            }.getOrNull()
            if (session == null) return@withLock false
        }
        true
    }

    /** Release the ONNX session and tokenizer. Frees ~150 MB. */
    fun unload() {
        runCatching { session?.close() }
        session = null
        tokenizer = null
    }

    /** Delete both model files. Stops any in-flight load first. */
    fun deleteFiles(): Boolean {
        unload()
        val m = modelFile.delete()
        val v = vocabFile.delete()
        return m || v
    }

    /**
     * Download both files (model + vocab). Reports progress via [onProgress]
     * as 0.0–1.0 across the combined byte total. Mirrors the pattern from
     * [com.tebogo.markvault.llm.ChatModelDownloader] but inline here since
     * the reranker is small enough to skip foreground-service complexity.
     */
    suspend fun download(onProgress: (Float) -> Unit = {}): Result<Unit> = withContext(Dispatchers.IO) {
        // Combined approximate total bytes for progress calculation.
        val approxModelBytes = descriptor.approxSizeMb.toLong() * 1_000_000L
        val approxVocabBytes = 250_000L
        val approxTotal = approxModelBytes + approxVocabBytes

        // 1. Model file
        val r1 = downloadFile(
            url = descriptor.modelUrl,
            dest = modelFile,
            onChunkBytes = { copied ->
                onProgress((copied.toFloat() / approxTotal.toFloat()).coerceIn(0f, 1f))
            }
        )
        if (r1.isFailure) return@withContext r1

        // 2. Vocab file (start where model left off in progress space)
        val r2 = downloadFile(
            url = descriptor.vocabUrl,
            dest = vocabFile,
            onChunkBytes = { copied ->
                val pct = ((approxModelBytes + copied).toFloat() / approxTotal.toFloat()).coerceIn(0f, 1f)
                onProgress(pct)
            }
        )
        if (r2.isFailure) {
            // Clean up the model file too — we can't use it without vocab.
            modelFile.delete()
            return@withContext r2
        }

        // Final plausibility check.
        if (modelFile.length() < RerankerCatalog.MIN_PLAUSIBLE_MODEL_BYTES) {
            modelFile.delete()
            vocabFile.delete()
            return@withContext Result.failure(
                java.io.IOException(
                    "Downloaded reranker model is only ${modelFile.length() / 1_000_000} MB " +
                        "— much smaller than expected ${descriptor.approxSizeMb} MB. " +
                        "Likely an HTML error page rather than the model. " +
                        "Check internet connection and try again."
                )
            )
        }
        onProgress(1f)
        Result.success(Unit)
    }

    /**
     * Download one URL to [dest], reporting bytes-copied via [onChunkBytes].
     * Writes to `<dest>.part` then atomic-renames on success.
     */
    private suspend fun downloadFile(
        url: String,
        dest: File,
        onChunkBytes: (Long) -> Unit
    ): Result<Unit> {
        val partFile = File(dest.parentFile, "${dest.name}.part")
        runCatching { partFile.delete() }

        try {
            val conn = (URL(url).openConnection() as HttpURLConnection).apply {
                connectTimeout = 30_000
                readTimeout = 30_000
                instanceFollowRedirects = true
                requestMethod = "GET"
            }
            conn.connect()
            val code = conn.responseCode
            if (code !in 200..299) {
                conn.disconnect()
                return Result.failure(
                    java.io.IOException("HTTP $code while downloading ${url.substringAfterLast('/')}")
                )
            }

            val buffer = ByteArray(32 * 1024)
            var copied = 0L
            var nextProgressAt = 200_000L  // smaller interval — files are small

            conn.inputStream.use { input ->
                FileOutputStream(partFile).use { output ->
                    while (true) {
                        if (!coroutineContext.isActive) {
                            runCatching { partFile.delete() }
                            return Result.failure(
                                kotlinx.coroutines.CancellationException(
                                    "Reranker download cancelled"
                                )
                            )
                        }
                        val n = input.read(buffer)
                        if (n <= 0) break
                        output.write(buffer, 0, n)
                        copied += n
                        if (copied >= nextProgressAt) {
                            onChunkBytes(copied)
                            nextProgressAt += 200_000L
                        }
                    }
                }
            }
            conn.disconnect()
            onChunkBytes(copied)

            if (dest.exists()) dest.delete()
            if (!partFile.renameTo(dest)) {
                runCatching { partFile.delete() }
                return Result.failure(java.io.IOException("Failed to finalise downloaded file"))
            }
            return Result.success(Unit)
        } catch (e: Throwable) {
            runCatching { partFile.delete() }
            return Result.failure(e)
        }
    }
}
