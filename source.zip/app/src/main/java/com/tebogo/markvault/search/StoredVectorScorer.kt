package com.tebogo.markvault.search

object StoredVectorScorer {
    data class Score(val noteId: Long, val chunkIndex: Int, val value: Float)
    fun score(path: String?, model: String, query: FloatArray, ids: List<Long>): List<Score>? {
        if (path == null || path.isBlank() || !NativeHnswBridge.available || ids.size > 900) return null
        return runCatching {
            val packet = NativeHnswBridge.scoreStoredVectors(path, model, query, ids.toLongArray())
            check(packet.isNotEmpty() && packet[0] == 1L && (packet.size - 1) % 3 == 0)
            (1 until packet.size step 3).map { i -> Score(packet[i], packet[i + 1].toInt(), Float.fromBits(packet[i + 2].toInt())) }
        }.getOrNull()
    }
}
