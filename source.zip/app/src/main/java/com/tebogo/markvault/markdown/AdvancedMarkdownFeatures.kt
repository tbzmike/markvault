package com.tebogo.markvault.markdown

/**
 * Optional advanced Markdown rendering switches.
 * Kept independent so features can be disabled without touching the engine.
 */
object AdvancedMarkdownFeatures {
    var enableYamlFrontMatter = true
    var enableCallouts = true
    var enableMermaid = true
    var enableScriptureDetection = true
    var enableTagExtraction = true
}
