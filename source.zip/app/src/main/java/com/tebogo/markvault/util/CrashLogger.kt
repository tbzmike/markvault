package com.tebogo.markvault.util

import android.content.Context
import android.os.Build
import android.util.Log
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File
import java.io.PrintWriter
import java.io.StringWriter
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/**
 * v5.4.131cc — Crash & non-fatal error logger.
 *
 * ## What it does
 *
 * - Installs a global [Thread.UncaughtExceptionHandler] that writes a
 *   detailed crash report to `context.filesDir/crash_logs/` before the
 *   process dies. The prior handler (typically Android's default death
 *   dialog + kill) is still invoked afterwards so app behaviour on
 *   crash is unchanged aside from the log side-effect.
 *
 * - Provides [logException] for non-fatal errors — file-parsing
 *   failures, indexing hiccups, network errors — that the app has
 *   caught and recovered from but that we still want to know about.
 *
 * - Exposes [listLogs] / [readLog] / [clearAllLogs] / [deleteLog] for
 *   the in-app crash-log viewer UI ([CrashLogViewerScreen]).
 *
 * ## Threading
 *
 * The uncaught-exception path is **synchronous** on the crashing
 * thread — the process is about to die so we can't defer to a
 * coroutine and hope it finishes. Everything else runs on
 * [Dispatchers.IO] via [ioScope] or `withContext(Dispatchers.IO)` so
 * the main thread never touches the filesystem.
 *
 * ## File format
 *
 * Files are named `crash_yyyy-MM-dd_HH-mm-ss.txt` and pruned to
 * [MAX_LOGS] entries (oldest first) on init. Content is UTF-8 text,
 * safe to copy/paste into a bug report or share via
 * `Intent.ACTION_SEND`.
 */
object CrashLogger {

    private const val TAG = "CrashLogger"
    private const val LOG_DIR_NAME = "crash_logs"
    private const val LOG_FILE_PREFIX = "crash_"
    private const val LOG_FILE_SUFFIX = ".txt"
    private const val FILE_TIMESTAMP_PATTERN = "yyyy-MM-dd_HH-mm-ss"
    private const val DISPLAY_TIMESTAMP_PATTERN = "yyyy-MM-dd HH:mm:ss z"

    /** Auto-prune logs beyond this count on init. Keeps the folder
     *  from growing unbounded on a device that crashes repeatedly. */
    private const val MAX_LOGS = 50

    @Volatile private var appContext: Context? = null
    @Volatile private var appVersionName: String = "?"
    @Volatile private var appVersionCode: Long = 0L

    /** Long-lived scope for background writes ([logException]). Uses
     *  [SupervisorJob] so one failed write doesn't cancel the scope. */
    private val ioScope: CoroutineScope =
        CoroutineScope(SupervisorJob() + Dispatchers.IO)

    /**
     * Initialise the crash logger. Safe to call exactly once from
     * [android.app.Application.onCreate].
     *
     * Effects:
     *   1. Captures the app's version info.
     *   2. Ensures the crash-logs directory exists.
     *   3. Prunes older logs beyond [MAX_LOGS].
     *   4. Registers a chained [Thread.UncaughtExceptionHandler] that
     *      writes a report, then delegates to whatever handler was
     *      previously installed.
     */
    fun init(context: Context) {
        val ctx: Context = context.applicationContext
        appContext = ctx

        // Snapshot the version info once — reading it inside the crash
        // handler could throw if the PackageManager is in a bad state.
        runCatching {
            val pkg = ctx.packageManager.getPackageInfo(ctx.packageName, 0)
            appVersionName = pkg.versionName ?: "?"
            appVersionCode = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) {
                pkg.longVersionCode
            } else {
                @Suppress("DEPRECATION")
                pkg.versionCode.toLong()
            }
        }

        // Ensure the dir exists so writeCrashLogSync doesn't have to
        // race with a first-launch mkdir on a dying process.
        runCatching { logDir()?.mkdirs() }

        // Prune older logs off the main thread.
        ioScope.launch {
            runCatching { pruneOldLogs() }
        }

        // Chain onto whatever handler is currently installed. Do NOT
        // remove it — Android's default handler is what actually kills
        // the process; if we swallow the exception the process leaks.
        val priorHandler: Thread.UncaughtExceptionHandler? =
            Thread.getDefaultUncaughtExceptionHandler()

        Thread.setDefaultUncaughtExceptionHandler { thread, throwable ->
            // Logcat trace so a developer with `adb logcat` still sees it.
            runCatching {
                Log.e(TAG, "Uncaught on ${thread.name}", throwable)
            }
            // Last-ditch OOM recovery attempt — the JVM may or may not
            // be able to run the finalizer, but it's cheap to try.
            if (throwable is OutOfMemoryError) {
                runCatching { System.gc() }
            }
            // Write the report synchronously. Any exception here is
            // caught — we must not throw from the uncaught handler,
            // that would recurse.
            runCatching {
                writeCrashLogSync(
                    throwable = throwable,
                    threadName = thread.name,
                    extraContext = "UNCAUGHT"
                )
            }
            // Delegate to whatever ran before — normally Android's
            // default handler which shows the "App has stopped" dialog
            // (or nothing on newer versions) and terminates the process.
            runCatching {
                priorHandler?.uncaughtException(thread, throwable)
            }
        }
    }

    /**
     * Log a caught, non-fatal exception. Never blocks the caller — the
     * write is dispatched onto [Dispatchers.IO] via [ioScope]. Safe to
     * call from any thread, including the main thread.
     *
     * @param throwable    the exception that was caught
     * @param extraContext optional context string prepended to the log
     *                     (e.g. "parseNote() rel=$relPath", "index rebuild")
     */
    fun logException(throwable: Throwable, extraContext: String? = null) {
        ioScope.launch {
            runCatching {
                writeCrashLogSync(
                    throwable = throwable,
                    threadName = Thread.currentThread().name,
                    extraContext = extraContext ?: "NON-FATAL"
                )
            }
        }
    }

    /** Enumerate all crash logs, newest first. Suspending; runs on IO. */
    suspend fun listLogs(): List<File> = withContext(Dispatchers.IO) {
        val dir: File = logDir() ?: return@withContext emptyList()
        val files: Array<File> = runCatching { dir.listFiles() }.getOrNull()
            ?: return@withContext emptyList()
        files.asSequence()
            .filter { it.isFile }
            .filter { it.name.startsWith(LOG_FILE_PREFIX) }
            .filter { it.name.endsWith(LOG_FILE_SUFFIX) }
            .sortedByDescending { it.lastModified() }
            .toList()
    }

    /** Read a single log's content. Suspending; runs on IO. Returns a
     *  human-readable error message rather than throwing on read failure. */
    suspend fun readLog(file: File): String = withContext(Dispatchers.IO) {
        runCatching { file.readText(Charsets.UTF_8) }
            .getOrElse { "(failed to read \"${file.name}\": ${it.message})" }
    }

    /** Delete every crash log. Returns the count actually deleted. */
    suspend fun clearAllLogs(): Int = withContext(Dispatchers.IO) {
        val dir: File = logDir() ?: return@withContext 0
        val files: Array<File> = runCatching { dir.listFiles() }.getOrNull()
            ?: return@withContext 0
        var deleted = 0
        for (f in files) {
            if (!f.isFile) continue
            if (!f.name.startsWith(LOG_FILE_PREFIX)) continue
            if (!f.name.endsWith(LOG_FILE_SUFFIX)) continue
            if (runCatching { f.delete() }.getOrDefault(false)) deleted++
        }
        deleted
    }

    /** Delete a single log file. Returns true on success. */
    suspend fun deleteLog(file: File): Boolean = withContext(Dispatchers.IO) {
        runCatching { file.delete() }.getOrDefault(false)
    }

    /** Human-readable display name from a log file name.
     *  "crash_2026-07-25_14-32-11.txt" → "2026-07-25 14:32:11". */
    fun formatFileName(name: String): String {
        if (!name.startsWith(LOG_FILE_PREFIX)) return name
        if (!name.endsWith(LOG_FILE_SUFFIX)) return name
        val stem: String = name
            .removePrefix(LOG_FILE_PREFIX)
            .removeSuffix(LOG_FILE_SUFFIX)
        // stem = "yyyy-MM-dd_HH-mm-ss" → "yyyy-MM-dd HH:mm:ss"
        val parts: List<String> = stem.split("_")
        if (parts.size != 2) return stem
        val date: String = parts[0]
        val time: String = parts[1].replace('-', ':')
        return "$date  $time"
    }

    // ─────────────────────────────────────────────────────────────
    // Internal
    // ─────────────────────────────────────────────────────────────

    private fun writeCrashLogSync(
        throwable: Throwable,
        threadName: String,
        extraContext: String?
    ) {
        val ctx: Context = appContext ?: return
        val dir: File = logDir() ?: return
        if (!dir.exists()) {
            runCatching { dir.mkdirs() }
        }

        val now: Date = Date()
        val fileTimestamp: String = SimpleDateFormat(
            FILE_TIMESTAMP_PATTERN, Locale.US
        ).format(now)
        val displayTimestamp: String = SimpleDateFormat(
            DISPLAY_TIMESTAMP_PATTERN, Locale.US
        ).format(now)

        val fileName = "$LOG_FILE_PREFIX$fileTimestamp$LOG_FILE_SUFFIX"
        val outFile = File(dir, fileName)

        // Render the stack trace.
        val stackTraceText: String = runCatching {
            val sw = StringWriter()
            PrintWriter(sw).use { pw -> throwable.printStackTrace(pw) }
            sw.toString()
        }.getOrElse { "(failed to render stack trace: ${it.message})" }

        val body: String = buildString {
            appendLine("═══════════════════════════════════════════════")
            appendLine("  MarkVault crash report")
            appendLine("═══════════════════════════════════════════════")
            appendLine()
            appendLine("App version : $appVersionName  (build $appVersionCode)")
            appendLine("Timestamp   : $displayTimestamp")
            appendLine("Thread      : $threadName")
            if (!extraContext.isNullOrBlank()) {
                appendLine("Context     : $extraContext")
            }
            appendLine("Package     : ${ctx.packageName}")
            appendLine()
            appendLine("── Device ─────────────────────────────────────")
            appendLine("Manufacturer  : ${Build.MANUFACTURER}")
            appendLine("Brand         : ${Build.BRAND}")
            appendLine("Model         : ${Build.MODEL}")
            appendLine("Device        : ${Build.DEVICE}")
            appendLine("Product       : ${Build.PRODUCT}")
            appendLine("Hardware      : ${Build.HARDWARE}")
            appendLine("Android OS    : ${Build.VERSION.RELEASE}")
            appendLine("API level     : ${Build.VERSION.SDK_INT}")
            appendLine("ABIs          : ${Build.SUPPORTED_ABIS.joinToString()}")
            appendLine("Fingerprint   : ${Build.FINGERPRINT}")
            appendLine()
            appendLine("── Exception ──────────────────────────────────")
            appendLine("Type    : ${throwable::class.java.name}")
            appendLine("Message : ${throwable.message ?: "(no message)"}")
            // Include the cause chain concisely for context.
            var cause: Throwable? = throwable.cause
            var depth = 0
            while (cause != null && depth < 6) {
                appendLine(
                    "Caused by [$depth]: ${cause::class.java.name}" +
                        (cause.message?.let { " — $it" } ?: "")
                )
                cause = cause.cause
                depth++
            }
            appendLine()
            appendLine("── Stack trace ────────────────────────────────")
            append(stackTraceText)
        }

        // Write to a .tmp file first, then rename. Prevents a partial
        // write from being surfaced as a valid log if the process dies
        // mid-write.
        runCatching {
            val tmp = File(dir, "$fileName.tmp")
            tmp.writeText(body, Charsets.UTF_8)
            if (!tmp.renameTo(outFile)) {
                // Fallback: rename failed (rare), write directly.
                outFile.writeText(body, Charsets.UTF_8)
                runCatching { tmp.delete() }
            }
        }.onFailure {
            // Last-ditch: try to log to Logcat so the write failure
            // itself doesn't disappear silently.
            runCatching {
                Log.e(TAG, "Failed to write crash log: ${it.message}")
            }
        }
    }

    private fun logDir(): File? {
        val ctx: Context = appContext ?: return null
        return File(ctx.filesDir, LOG_DIR_NAME)
    }

    private fun pruneOldLogs() {
        val dir: File = logDir() ?: return
        val logs: List<File> = dir.listFiles()
            ?.asSequence()
            ?.filter { it.isFile }
            ?.filter { it.name.startsWith(LOG_FILE_PREFIX) }
            ?.filter { it.name.endsWith(LOG_FILE_SUFFIX) }
            ?.sortedByDescending { it.lastModified() }
            ?.toList()
            ?: return
        if (logs.size > MAX_LOGS) {
            logs.drop(MAX_LOGS).forEach { f ->
                runCatching { f.delete() }
            }
        }
    }
}
