package com.tebogo.markvault.ai

/** Final history payload for expansion diagnostics. */
data class T5FinalHistoryRecord(
    val query: String,
    val mode: String,
    val generatedQueries: List<String>,
    val inferenceTimeMs: Long,
    val fallbackReason: String? = null
)
