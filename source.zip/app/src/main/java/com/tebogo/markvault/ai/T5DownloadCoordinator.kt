package com.tebogo.markvault.ai

class T5DownloadCoordinator(private val manager: T5DownloadManager = T5DownloadManager()) {
    fun start(target: java.io.File): Boolean {
        manager.prepareDestination(target)
        return true
    }
}
