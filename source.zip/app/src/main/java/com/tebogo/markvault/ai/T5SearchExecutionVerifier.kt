package com.tebogo.markvault.ai

/** Verification hooks for expansion execution path. */
object T5SearchExecutionVerifier {
    fun verify(mode: T5ExpansionMode): Boolean {
        return mode == T5ExpansionMode.BUILTIN || mode == T5ExpansionMode.T5_BASE
    }
}
