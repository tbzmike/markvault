package com.tebogo.markvault.ui

import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

/**
 * v5.4.358cc — Opaque, words-only cold-launch welcome.
 *
 * The real app initializes underneath, but this layer is fully opaque so no
 * Home/index/library text can mix with the welcome. It remains visible for at
 * least 3.6 seconds AND until AppViewModel confirms the initial library DB read
 * succeeded. Only the three requested text lines are drawn.
 */
@Composable
fun MarkVaultLaunchWelcome(
    libraryReady: Boolean,
    onFinished: () -> Unit,
    modifier: Modifier = Modifier
) {
    val splitAlpha = remember { Animatable(0f) }
    val markX = remember { Animatable(-240f) }
    val vaultX = remember { Animatable(240f) }
    val brandAlpha = remember { Animatable(0f) }
    val brandScale = remember { Animatable(0.84f) }
    val taglineAlpha = remember { Animatable(0f) }
    val overlayAlpha = remember { Animatable(1f) }
    var minimumElapsed by remember { mutableStateOf(false) }

    LaunchedEffect(Unit) {
        // Minimum launch-display time is independent of animation timing.
        launch {
            delay(3600)
            minimumElapsed = true
        }

        coroutineScope {
            launch { splitAlpha.animateTo(1f, tween(320, easing = FastOutSlowInEasing)) }
            launch { markX.animateTo(-64f, tween(900, easing = FastOutSlowInEasing)) }
            launch { vaultX.animateTo(64f, tween(900, easing = FastOutSlowInEasing)) }
        }
        delay(180)
        coroutineScope {
            launch { brandAlpha.animateTo(1f, tween(420, easing = FastOutSlowInEasing)) }
            launch { brandScale.animateTo(1.06f, tween(420, easing = FastOutSlowInEasing)) }
        }
        brandScale.animateTo(1f, tween(220, easing = FastOutSlowInEasing))
        taglineAlpha.animateTo(1f, tween(500, easing = FastOutSlowInEasing))
    }

    LaunchedEffect(minimumElapsed, libraryReady) {
        if (minimumElapsed && libraryReady) {
            overlayAlpha.animateTo(0f, tween(320, easing = FastOutSlowInEasing))
            onFinished()
        }
    }

    val colors = MaterialTheme.colorScheme
    Box(
        modifier = modifier
            .fillMaxSize()
            .graphicsLayer { alpha = overlayAlpha.value }
            .background(colors.background),
        contentAlignment = Alignment.Center
    ) {
        Column(
            modifier = Modifier.fillMaxWidth().padding(horizontal = 28.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center
        ) {
            Box(Modifier.fillMaxWidth().height(70.dp), contentAlignment = Alignment.Center) {
                Text(
                    text = "Mark",
                    color = colors.onBackground,
                    fontSize = 34.sp,
                    fontWeight = FontWeight.SemiBold,
                    modifier = Modifier.alpha(splitAlpha.value).graphicsLayer { translationX = markX.value }
                )
                Text(
                    text = "vault",
                    color = colors.primary,
                    fontSize = 34.sp,
                    fontWeight = FontWeight.SemiBold,
                    modifier = Modifier.alpha(splitAlpha.value).graphicsLayer { translationX = vaultX.value }
                )
            }
            Text(
                text = "MarkVault",
                color = colors.onBackground,
                fontSize = 44.sp,
                fontWeight = FontWeight.Bold,
                modifier = Modifier.alpha(brandAlpha.value).graphicsLayer {
                    scaleX = brandScale.value
                    scaleY = brandScale.value
                }
            )
            Text(
                text = "Let's dig deeper no assume",
                color = colors.onSurfaceVariant,
                fontSize = 18.sp,
                fontWeight = FontWeight.Medium,
                textAlign = TextAlign.Center,
                modifier = Modifier.padding(top = 24.dp).alpha(taglineAlpha.value)
            )
        }
    }
}
