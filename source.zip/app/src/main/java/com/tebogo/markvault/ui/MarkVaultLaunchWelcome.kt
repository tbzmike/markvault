package com.tebogo.markvault.ui

import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

/**
 * Branded cold-launch welcome for MarkVault.
 *
 * The real application is composed and initialized underneath this overlay;
 * this composable is deliberately visual-only so restored navigation,
 * indexing state, media services and other startup work are never blocked by
 * the animation. [onFinished] removes the overlay after the exit fade.
 */
@Composable
fun MarkVaultLaunchWelcome(
    onFinished: () -> Unit,
    modifier: Modifier = Modifier
) {
    val pairAlpha = remember { Animatable(0f) }
    val markX = remember { Animatable(-210f) }
    val vaultX = remember { Animatable(210f) }
    val pairScale = remember { Animatable(0.96f) }
    val brandAlpha = remember { Animatable(0f) }
    val brandScale = remember { Animatable(0.78f) }
    val taglineAlpha = remember { Animatable(0f) }
    val taglineY = remember { Animatable(18f) }
    val sweep = remember { Animatable(0f) }
    val overlayAlpha = remember { Animatable(1f) }
    var showSplitName by remember { mutableStateOf(true) }

    LaunchedEffect(Unit) {
        coroutineScope {
            launch { pairAlpha.animateTo(1f, tween(260, easing = FastOutSlowInEasing)) }
            launch { markX.animateTo(-46f, tween(720, easing = FastOutSlowInEasing)) }
            launch { vaultX.animateTo(46f, tween(720, easing = FastOutSlowInEasing)) }
            launch { pairScale.animateTo(1.03f, tween(720, easing = FastOutSlowInEasing)) }
        }

        pairAlpha.animateTo(0f, tween(150))
        showSplitName = false

        coroutineScope {
            launch { brandAlpha.animateTo(1f, tween(230, easing = FastOutSlowInEasing)) }
            launch { brandScale.animateTo(1.08f, tween(260, easing = FastOutSlowInEasing)) }
        }
        brandScale.animateTo(1f, tween(180, easing = FastOutSlowInEasing))

        coroutineScope {
            launch { taglineAlpha.animateTo(1f, tween(360, easing = FastOutSlowInEasing)) }
            launch { taglineY.animateTo(0f, tween(360, easing = FastOutSlowInEasing)) }
            launch { sweep.animateTo(1f, tween(620, easing = LinearEasing)) }
        }

        delay(520)
        overlayAlpha.animateTo(0f, tween(280, easing = FastOutSlowInEasing))
        onFinished()
    }

    val colors = MaterialTheme.colorScheme
    val backdrop = Brush.radialGradient(
        colors = listOf(
            colors.primary.copy(alpha = 0.12f),
            colors.surface.copy(alpha = 0.98f),
            colors.background
        ),
        radius = 980f
    )

    Box(
        modifier = modifier
            .fillMaxSize()
            .graphicsLayer { alpha = overlayAlpha.value }
            .background(backdrop),
        contentAlignment = Alignment.Center
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 28.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center
        ) {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(78.dp),
                contentAlignment = Alignment.Center
            ) {
                if (showSplitName) {
                    Text(
                        text = "Mark",
                        color = colors.onBackground,
                        fontSize = 34.sp,
                        fontWeight = FontWeight.SemiBold,
                        modifier = Modifier
                            .alpha(pairAlpha.value)
                            .graphicsLayer {
                                translationX = markX.value
                                scaleX = pairScale.value
                                scaleY = pairScale.value
                            }
                    )
                    Text(
                        text = "vault",
                        color = colors.primary,
                        fontSize = 34.sp,
                        fontWeight = FontWeight.SemiBold,
                        modifier = Modifier
                            .alpha(pairAlpha.value)
                            .graphicsLayer {
                                translationX = vaultX.value
                                scaleX = pairScale.value
                                scaleY = pairScale.value
                            }
                    )
                }

                Text(
                    text = "MarkVault",
                    color = colors.onBackground,
                    fontSize = 42.sp,
                    fontWeight = FontWeight.Bold,
                    letterSpacing = 0.4.sp,
                    modifier = Modifier
                        .alpha(brandAlpha.value)
                        .graphicsLayer {
                            scaleX = brandScale.value
                            scaleY = brandScale.value
                        }
                )
            }

            Box(
                modifier = Modifier
                    .width(190.dp)
                    .height(3.dp)
                    .clip(RoundedCornerShape(50))
                    .background(colors.outlineVariant.copy(alpha = 0.28f))
            ) {
                Box(
                    modifier = Modifier
                        .fillMaxWidth(sweep.value.coerceIn(0f, 1f))
                        .height(3.dp)
                        .background(
                            Brush.horizontalGradient(
                                listOf(
                                    Color.Transparent,
                                    colors.primary,
                                    colors.secondary,
                                    Color.Transparent
                                )
                            )
                        )
                )
            }

            Spacer(Modifier.height(20.dp))

            Text(
                text = "Let’s dig deeper, not assume.",
                color = colors.onSurfaceVariant,
                fontSize = 17.sp,
                fontWeight = FontWeight.Medium,
                textAlign = TextAlign.Center,
                modifier = Modifier
                    .alpha(taglineAlpha.value)
                    .offset(y = taglineY.value.dp)
            )
        }
    }
}
