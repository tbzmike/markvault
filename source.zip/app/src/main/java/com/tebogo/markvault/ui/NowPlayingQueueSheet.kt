package com.tebogo.markvault.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import coil.compose.AsyncImage
import com.tebogo.markvault.AppViewModel

/**
 * v5.4.255cc — "Now Playing Queue": shows the full current playback
 * queue (vm.currentQueue), highlights whichever item is actually playing
 * (vm.currentQueueIndex, kept in sync by AppViewModel's Player.Listener
 * through auto-advance, shuffle, and manual next/previous alike), and
 * lets the user tap any entry to jump straight to it.
 *
 * Deliberately shows the queue in its ORIGINAL load order even when
 * shuffle is on — shuffle changes PLAYBACK order via the Player itself;
 * this list stays stable so it reads like a normal playlist with a
 * "now playing" marker, matching how most traditional media players
 * present their queue.
 */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun NowPlayingQueueSheet(vm: AppViewModel, onDismiss: () -> Unit) {
    val queue by vm.currentQueue.collectAsStateWithLifecycle()
    val currentIndex by vm.currentQueueIndex.collectAsStateWithLifecycle()

    ModalBottomSheet(onDismissRequest = onDismiss) {
        Column(modifier = Modifier.fillMaxWidth().padding(bottom = 24.dp)) {
            Text(
                "\uD83C\uDFB5 Now Playing Queue (${queue.size})",
                fontWeight = FontWeight.Bold,
                fontSize = 16.sp,
                modifier = Modifier.padding(horizontal = 16.dp, vertical = 8.dp)
            )
            if (queue.isEmpty()) {
                Text(
                    "Nothing queued.",
                    fontSize = 13.sp,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    modifier = Modifier.padding(16.dp)
                )
            } else {
                LazyColumn(modifier = Modifier.heightIn(max = 420.dp)) {
                    itemsIndexed(queue, key = { idx, m -> "${m.id}-$idx" }) { idx, media ->
                        val isCurrent = idx == currentIndex
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .background(
                                    if (isCurrent) MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.4f)
                                    else MaterialTheme.colorScheme.surface
                                )
                                .clickable {
                                    vm.seekToQueueIndex(idx)
                                    onDismiss()
                                }
                                .padding(horizontal = 16.dp, vertical = 10.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                if (isCurrent) "\u25B6" else "${idx + 1}",
                                fontSize = 13.sp,
                                color = if (isCurrent) MaterialTheme.colorScheme.primary
                                        else MaterialTheme.colorScheme.onSurfaceVariant,
                                modifier = Modifier.width(24.dp)
                            )
                            if (media.thumbnailUrl.isNotBlank()) {
                                AsyncImage(
                                    model = media.thumbnailUrl,
                                    contentDescription = null,
                                    contentScale = ContentScale.Crop,
                                    modifier = Modifier
                                        .size(width = 56.dp, height = 36.dp)
                                        .clip(RoundedCornerShape(4.dp))
                                )
                            } else {
                                Box(
                                    modifier = Modifier
                                        .size(width = 56.dp, height = 36.dp)
                                        .clip(RoundedCornerShape(4.dp))
                                        .background(MaterialTheme.colorScheme.surfaceVariant),
                                    contentAlignment = Alignment.Center
                                ) {
                                    Text(
                                        if (media.mediaType == "audio") "\uD83C\uDFB5" else "\uD83C\uDFAC",
                                        fontSize = 14.sp
                                    )
                                }
                            }
                            Spacer(Modifier.width(10.dp))
                            Text(
                                media.title,
                                fontSize = 13.sp,
                                fontWeight = if (isCurrent) FontWeight.Bold else FontWeight.Normal,
                                maxLines = 2,
                                overflow = TextOverflow.Ellipsis,
                                modifier = Modifier.weight(1f)
                            )
                        }
                    }
                }
            }
        }
    }
}
