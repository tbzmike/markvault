package com.tebogo.markvault.ai

/** Persistent-ready state bridge for T5 installation. */
object T5InstallState {
    private var ready = false

    fun setReady(value: Boolean) {
        ready = value
    }

    fun isReady(): Boolean = ready
}
