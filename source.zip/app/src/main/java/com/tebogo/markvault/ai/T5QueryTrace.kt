package com.tebogo.markvault.ai

/** Trace information for debugging expanded queries through retrieval. */
data class T5QueryTrace(
    val mode: String,
    val generatedQueries: List<String>,
    val inferenceTimeMs: Long,
    val fallbackReason: String? = null
)
