package com.tebogo.markvault.ai

data class T5HistoryDetail(
    val query: String,
    val expansion: String,
    val generatedQueries: List<String>,
    val inferenceTimeMs: Long,
    val fallbackReason: String? = null
)
