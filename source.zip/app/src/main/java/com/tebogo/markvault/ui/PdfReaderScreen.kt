package com.tebogo.markvault.ui

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.pdf.PdfRenderer
import android.net.Uri
import android.os.ParcelFileDescriptor
import android.print.PrintAttributes
import android.print.PrintDocumentAdapter
import android.print.PrintDocumentInfo
import android.print.PrintManager
import android.util.Log
import android.widget.Toast
import androidx.activity.compose.BackHandler
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.gestures.detectTransformGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyListState
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.rememberScrollState
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.filled.KeyboardArrowLeft
import androidx.compose.material.icons.automirrored.filled.KeyboardArrowRight
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.KeyboardArrowDown
import androidx.compose.material.icons.filled.KeyboardArrowUp
import androidx.compose.material.icons.filled.MoreVert
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TextField
import androidx.compose.material3.TextFieldDefaults
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.rememberModalBottomSheetState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.derivedStateOf
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateMapOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.runtime.snapshots.SnapshotStateList
import androidx.compose.runtime.snapshots.SnapshotStateMap
import androidx.compose.runtime.toMutableStateList
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.StrokeJoin
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.navigation.NavController
import com.tebogo.markvault.AppViewModel
import com.tom_roush.pdfbox.pdmodel.PDDocument
import com.tom_roush.pdfbox.text.PDFTextStripper
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.channels.Channel
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import org.json.JSONArray
import java.io.File
import java.io.FileOutputStream
import kotlin.math.roundToInt

private const val TAG = "PdfReader"

/* ════════════════════════════════════════════════════════════════════════
 *  PDF RENDERER POOL — parallel rendering across multiple PdfRenderer instances
 * ════════════════════════════════════════════════════════════════════════ */

class PdfRendererPool private constructor(
    private val renderers: List<PdfRenderer>,
    /** If non-null, this is a decrypted copy in cache that should be deleted on close. */
    private val tempFileToDelete: File? = null
) {
    private val available = Channel<PdfRenderer>(Channel.UNLIMITED).also { ch ->
        renderers.forEach { ch.trySend(it) }
    }

    val pageCount: Int = renderers.firstOrNull()?.pageCount ?: 0
    val poolSize: Int = renderers.size

    suspend fun renderPage(pageIndex: Int, targetWidth: Int): Bitmap? = withContext(Dispatchers.IO) {
        if (pageIndex < 0 || pageIndex >= pageCount) return@withContext null
        val r = available.receive()
        try {
            val page = r.openPage(pageIndex)
            val scale = targetWidth.toFloat() / page.width
            val h = (page.height * scale).toInt().coerceAtLeast(1)
            val bmp = Bitmap.createBitmap(targetWidth, h, Bitmap.Config.ARGB_8888)
            bmp.eraseColor(android.graphics.Color.WHITE)
            page.render(bmp, null, null, PdfRenderer.Page.RENDER_MODE_FOR_DISPLAY)
            page.close()
            bmp
        } catch (e: Exception) {
            Log.e(TAG, "renderPage($pageIndex) failed", e); null
        } finally { available.trySend(r) }
    }

    suspend fun firstPageAspect(): Float = withContext(Dispatchers.IO) {
        if (pageCount == 0) return@withContext 1.414f
        val r = available.receive()
        try {
            val p = r.openPage(0)
            val aspect = p.height.toFloat() / p.width.toFloat()
            p.close(); aspect
        } catch (e: Exception) { 1.414f }
        finally { available.trySend(r) }
    }

    fun close() {
        renderers.forEach { runCatching { it.close() } }
        available.close()
        tempFileToDelete?.let { runCatching { it.delete() } }
    }

    companion object {
        /**
         * Open a PDF for parallel rendering.
         * Returns Result.Success(pool) on success, Result.NeedsPassword if encrypted,
         * Result.Failure for other errors.
         */
        suspend fun open(
            ctx: Context, uri: Uri, poolSize: Int = 3, password: String? = null
        ): OpenResult = withContext(Dispatchers.IO) {
            // Try native first if no password
            if (password == null) {
                try {
                    val list = mutableListOf<PdfRenderer>()
                    repeat(poolSize) {
                        val pfd = ctx.contentResolver.openFileDescriptor(uri, "r")
                        if (pfd != null) list.add(PdfRenderer(pfd))
                    }
                    if (list.isNotEmpty()) return@withContext OpenResult.Success(PdfRendererPool(list))
                } catch (e: SecurityException) {
                    return@withContext OpenResult.NeedsPassword
                } catch (e: Exception) {
                    // Some encrypted PDFs throw IOException with "password" in the message
                    if (e.message?.contains("password", ignoreCase = true) == true ||
                        e.message?.contains("encrypt", ignoreCase = true) == true) {
                        return@withContext OpenResult.NeedsPassword
                    }
                    Log.e(TAG, "open native failed", e)
                    return@withContext OpenResult.Failure(e.message ?: "Could not open PDF")
                }
            }

            // Encrypted path: use PdfBox to decrypt to a temp file, then open the temp file natively
            try {
                val cacheDir = File(ctx.cacheDir, "pdf_decrypted").apply { mkdirs() }
                // Delete stale temp files
                cacheDir.listFiles()?.forEach { runCatching { it.delete() } }
                val temp = File.createTempFile("dec_", ".pdf", cacheDir)
                val ok = ctx.contentResolver.openInputStream(uri)?.use { input ->
                    try {
                        PDDocument.load(input, password ?: "").use { doc ->
                            doc.setAllSecurityToBeRemoved(true)
                            FileOutputStream(temp).use { os -> doc.save(os) }
                        }
                        true
                    } catch (e: com.tom_roush.pdfbox.pdmodel.encryption.InvalidPasswordException) {
                        Log.w(TAG, "wrong password"); false
                    } catch (e: Exception) {
                        Log.e(TAG, "decrypt failed", e); false
                    }
                } ?: false

                if (!ok) {
                    runCatching { temp.delete() }
                    return@withContext if (password != null) OpenResult.WrongPassword
                    else OpenResult.NeedsPassword
                }

                val list = mutableListOf<PdfRenderer>()
                repeat(poolSize) {
                    try {
                        val pfd = ParcelFileDescriptor.open(temp, ParcelFileDescriptor.MODE_READ_ONLY)
                        list.add(PdfRenderer(pfd))
                    } catch (e: Exception) { Log.w(TAG, "tmp renderer #$it failed", e) }
                }
                if (list.isEmpty()) {
                    runCatching { temp.delete() }
                    return@withContext OpenResult.Failure("Could not open decrypted file")
                }
                OpenResult.Success(PdfRendererPool(list, tempFileToDelete = temp))
            } catch (e: Exception) {
                Log.e(TAG, "decrypt path failed", e)
                OpenResult.Failure(e.message ?: "Could not open PDF")
            }
        }
    }

    sealed class OpenResult {
        data class Success(val pool: PdfRendererPool) : OpenResult()
        object NeedsPassword : OpenResult()
        object WrongPassword : OpenResult()
        data class Failure(val message: String) : OpenResult()
    }
}

/* ════════════════════════════════════════════════════════════════════════
 *  Per-item page composable — with annotation drawing layer
 * ════════════════════════════════════════════════════════════════════════ */

@Composable
private fun PdfPageItem(
    pool: PdfRendererPool,
    pageIndex: Int,
    targetWidth: Int,
    placeholderHeight: Dp,
    highlight: Boolean,
    annotation: SnapshotStateList<List<Offset>>,
    drawMode: Boolean,
    onAnnotationChanged: () -> Unit,
    onLongPress: (Int) -> Unit
) {
    var bitmap by remember(pool, pageIndex) { mutableStateOf<Bitmap?>(null) }

    LaunchedEffect(pool, pageIndex) {
        val bmp = pool.renderPage(pageIndex, targetWidth)
        bitmap = bmp
    }

    DisposableEffect(pool, pageIndex) {
        onDispose {
            val b = bitmap
            bitmap = null
            try { b?.recycle() } catch (_: Exception) { }
        }
    }

    val b = bitmap
    val density = LocalContext.current.resources.displayMetrics.density
    Box(
        Modifier
            .fillMaxWidth()
            .then(if (highlight) Modifier.background(Color(0x33FFC107)) else Modifier)
    ) {
        if (b != null && !b.isRecycled) {
            Image(
                bitmap = b.asImageBitmap(),
                contentDescription = "Page ${pageIndex + 1}",
                contentScale = ContentScale.FillWidth,
                modifier = Modifier.fillMaxWidth()
            )

            // Drawing layer — sits on top of the bitmap
            val pageHeight = b.height.toFloat() / b.width.toFloat() * targetWidth.toFloat()
            Canvas(
                modifier = Modifier
                    .fillMaxWidth()
                    .height((pageHeight / density).dp)
                    .then(
                        if (drawMode) Modifier.pointerInput(pool, pageIndex) {
                            val current = mutableListOf<Offset>()
                            detectDragGestures(
                                onDragStart = { offset -> current.clear(); current.add(offset) },
                                onDragEnd = {
                                    if (current.size > 1) {
                                        // Normalize to 0..1 against page width / height
                                        val sw = size.width.toFloat()
                                        val sh = size.height.toFloat()
                                        if (sw > 0 && sh > 0) {
                                            val normalised = current.map {
                                                Offset(it.x / sw, it.y / sh)
                                            }
                                            annotation.add(normalised)
                                            onAnnotationChanged()
                                        }
                                    }
                                    current.clear()
                                },
                                onDrag = { change, _ -> current.add(change.position) }
                            )
                        } else Modifier.pointerInput(pageIndex) {
                            detectTapGestures(onLongPress = { onLongPress(pageIndex) })
                        }
                    )
            ) {
                val sw = size.width; val sh = size.height
                annotation.forEach { stroke ->
                    if (stroke.size < 2) return@forEach
                    val path = Path()
                    val first = stroke.first()
                    path.moveTo(first.x * sw, first.y * sh)
                    for (i in 1 until stroke.size) {
                        path.lineTo(stroke[i].x * sw, stroke[i].y * sh)
                    }
                    drawPath(
                        path = path,
                        color = Color(0xFFFFEB3B),
                        style = Stroke(width = 5f, cap = StrokeCap.Round, join = StrokeJoin.Round)
                    )
                }
            }
        } else {
            Box(
                Modifier.fillMaxWidth().height(placeholderHeight).background(Color(0xFF1A1A1A)),
                contentAlignment = Alignment.Center
            ) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    CircularProgressIndicator(Modifier.size(24.dp), color = Color(0xFF666666), strokeWidth = 2.dp)
                    Spacer(Modifier.height(6.dp))
                    Text("Page ${pageIndex + 1}", fontSize = 11.sp, color = Color(0xFF666666))
                }
            }
        }
    }
}

/* ════════════════════════════════════════════════════════════════════════
 *  PdfReaderScreen — in-app PDF viewer (note from DB)
 * ════════════════════════════════════════════════════════════════════════ */

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun PdfReaderScreen(vm: AppViewModel, nav: NavController, noteId: Long) {
    val ctx = LocalContext.current
    val favouriteIds by vm.favouriteIds.collectAsStateWithLifecycle()
    val tabs by vm.tabs.collectAsStateWithLifecycle()
    val activeTab by vm.activeTab.collectAsStateWithLifecycle()
    val scope = rememberCoroutineScope()

    var title by remember { mutableStateOf("PDF") }
    var pdfUri by remember { mutableStateOf<String?>(null) }
    var pool by remember { mutableStateOf<PdfRendererPool?>(null) }
    var pageAspect by remember { mutableFloatStateOf(1.414f) }
    var loading by remember { mutableStateOf(true) }
    var error by remember { mutableStateOf<String?>(null) }
    var menuOpen by remember { mutableStateOf(false) }

    // Password dialog
    var showPasswordDialog by remember { mutableStateOf(false) }
    var passwordError by remember { mutableStateOf(false) }

    // Search
    var searchOpen by remember { mutableStateOf(false) }
    var searchQuery by remember { mutableStateOf("") }
    var pageTexts by remember { mutableStateOf<Map<Int, String>>(emptyMap()) }
    var extractProgress by remember { mutableFloatStateOf(0f) }
    var extracting by remember { mutableStateOf(false) }
    var matches by remember { mutableStateOf<List<Int>>(emptyList()) }
    var currentMatch by remember { mutableIntStateOf(0) }

    // Jump to page
    var showJumpDialog by remember { mutableStateOf(false) }

    // Text panel (long-press → bottom sheet)
    var textPanelPage by remember { mutableStateOf<Int?>(null) }

    // Annotations (per-page in-memory + persisted)
    val annotations = remember { mutableStateMapOf<Int, SnapshotStateList<List<Offset>>>() }
    var drawMode by remember { mutableStateOf(false) }

    // Zoom
    var scale by remember { mutableFloatStateOf(1f) }
    var offsetX by remember { mutableFloatStateOf(0f) }
    var offsetY by remember { mutableFloatStateOf(0f) }
    val listState = rememberLazyListState()
    val searchFocus = remember { FocusRequester() }

    val pageCount = pool?.pageCount ?: 0
    val currentPage by remember {
        derivedStateOf {
            (listState.firstVisibleItemIndex + 1).coerceIn(1, pageCount.coerceAtLeast(1))
        }
    }

    // Open the PDF (re-runs if password is supplied)
    fun openPdf(password: String?) {
        scope.launch {
            loading = true; error = null; passwordError = false
            val note = withContext(Dispatchers.IO) { vm.loadNote(noteId) }
            if (note == null || note.fileType != "pdf") {
                error = "Not a PDF file"; loading = false; return@launch
            }
            title = note.title; pdfUri = note.uri

            when (val res = PdfRendererPool.open(ctx, Uri.parse(note.uri), poolSize = 3, password = password)) {
                is PdfRendererPool.OpenResult.Success -> {
                    pool = res.pool
                    pageAspect = res.pool.firstPageAspect()
                    showPasswordDialog = false
                    // Log this view in PDF history
                    vm.recordPdfView(note.uri, note.title, noteId, isExternal = false)
                    // Load saved annotations from DB
                    val saved = vm.loadAllAnnotations(noteId)
                    saved.forEach { (page, json) ->
                        annotations[page] = parsePathsJson(json).toMutableStateList()
                    }
                    loading = false
                }
                is PdfRendererPool.OpenResult.NeedsPassword -> {
                    showPasswordDialog = true
                    loading = false
                }
                is PdfRendererPool.OpenResult.WrongPassword -> {
                    passwordError = true
                    showPasswordDialog = true
                    loading = false
                }
                is PdfRendererPool.OpenResult.Failure -> {
                    error = res.message; loading = false
                }
            }
        }
    }

    LaunchedEffect(noteId) { openPdf(null) }

    DisposableEffect(Unit) { onDispose { pool?.close() } }

    BackHandler {
        when {
            searchOpen -> { searchOpen = false; searchQuery = ""; matches = emptyList() }
            drawMode -> drawMode = false
            else -> nav.popBackStack()
        }
    }

    // Text extraction: use cache if available, else extract once and save to cache
    LaunchedEffect(pool, searchOpen) {
        if (!searchOpen) return@LaunchedEffect
        if (pageTexts.isNotEmpty()) return@LaunchedEffect
        val uri = pdfUri ?: return@LaunchedEffect
        val total = pool?.pageCount ?: return@LaunchedEffect
        if (total == 0) return@LaunchedEffect

        // 1. Try cache first — instant
        val cached = vm.cachedPdfPageText(noteId)
        if (cached != null) {
            pageTexts = cached
            return@LaunchedEffect
        }

        // 2. Extract — single-pass fast extraction
        extracting = true; extractProgress = 0.05f
        val texts = withContext(Dispatchers.IO) {
            extractPdfTextFast(ctx, Uri.parse(uri)) { done, all ->
                extractProgress = if (all > 0) done.toFloat() / all else 0f
            }
        }
        pageTexts = texts
        extracting = false
        // 3. Save to cache for next time
        if (texts.isNotEmpty()) vm.savePdfPageText(noteId, texts)
    }

    // Match recomputation
    LaunchedEffect(searchQuery, pageTexts) {
        val q = searchQuery.trim()
        if (q.length < 2 || pageTexts.isEmpty()) {
            matches = emptyList(); currentMatch = 0
            return@LaunchedEffect
        }
        val lc = q.lowercase()
        val hits = pageTexts.entries.asSequence()
            .filter { it.value.lowercase().contains(lc) }
            .map { it.key }.sorted().toList()
        matches = hits; currentMatch = 0
        if (hits.isNotEmpty()) scope.launch { runCatching { listState.animateScrollToItem(hits[0]) } }
    }

    val density = ctx.resources.displayMetrics.density
    val placeholderH = remember(pageAspect) {
        (ctx.resources.displayMetrics.widthPixels * pageAspect / density).dp
    }

    Scaffold(
        topBar = {
            if (searchOpen) {
                PdfSearchBar(
                    query = searchQuery, onQueryChange = { searchQuery = it },
                    extracting = extracting, extractProgress = extractProgress,
                    matchCount = matches.size, currentMatch = currentMatch,
                    focusRequester = searchFocus,
                    onClose = { searchOpen = false; searchQuery = ""; matches = emptyList() },
                    onPrev = {
                        if (matches.isNotEmpty()) {
                            currentMatch = (currentMatch - 1 + matches.size) % matches.size
                            scope.launch { runCatching { listState.animateScrollToItem(matches[currentMatch]) } }
                        }
                    },
                    onNext = {
                        if (matches.isNotEmpty()) {
                            currentMatch = (currentMatch + 1) % matches.size
                            scope.launch { runCatching { listState.animateScrollToItem(matches[currentMatch]) } }
                        }
                    }
                )
                LaunchedEffect(Unit) { runCatching { searchFocus.requestFocus() } }
            } else {
                TopAppBar(
                    title = {
                        Column {
                            Text(title, maxLines = 1, overflow = TextOverflow.Ellipsis,
                                fontSize = 15.sp, fontWeight = FontWeight.SemiBold)
                            if (pageCount > 0) {
                                Text("Page $currentPage of $pageCount",
                                    fontSize = 11.sp,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant)
                            }
                        }
                    },
                    navigationIcon = {
                        IconButton(onClick = { nav.popBackStack() }) {
                            Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back")
                        }
                    },
                    actions = {
                        IconButton(onClick = { searchOpen = true }) {
                            Icon(Icons.Default.Search, contentDescription = "Search in PDF")
                        }
                        // Tab navigation — switches between any open tabs (markdown OR pdf).
                        // Routes to /reader for markdown tabs, /pdfReader for pdf tabs.
                        if (tabs.size > 1) {
                            IconButton(onClick = {
                                val list = tabs
                                val idx = list.indexOfFirst { it.id == noteId }
                                if (idx >= 0) {
                                    val prev = list[(idx - 1 + list.size) % list.size]
                                    vm.openArticle(prev.id, prev.title, fileType = prev.fileType)
                                    if (prev.fileType == "pdf") {
                                        nav.navigate("pdfReader/${prev.id}") {
                                            popUpTo("pdfReader/$noteId") { inclusive = true }
                                            launchSingleTop = true
                                        }
                                    } else {
                                        nav.navigate("reader") { launchSingleTop = true }
                                    }
                                }
                            }) {
                                Icon(Icons.AutoMirrored.Filled.KeyboardArrowLeft,
                                    contentDescription = "Previous tab")
                            }
                            IconButton(onClick = {
                                val list = tabs
                                val idx = list.indexOfFirst { it.id == noteId }
                                if (idx >= 0) {
                                    val next = list[(idx + 1) % list.size]
                                    vm.openArticle(next.id, next.title, fileType = next.fileType)
                                    if (next.fileType == "pdf") {
                                        nav.navigate("pdfReader/${next.id}") {
                                            popUpTo("pdfReader/$noteId") { inclusive = true }
                                            launchSingleTop = true
                                        }
                                    } else {
                                        nav.navigate("reader") { launchSingleTop = true }
                                    }
                                }
                            }) {
                                Icon(Icons.AutoMirrored.Filled.KeyboardArrowRight,
                                    contentDescription = "Next tab")
                            }
                        }
                        IconButton(onClick = { drawMode = !drawMode }) {
                            Icon(
                                Icons.Default.Edit,
                                contentDescription = if (drawMode) "Stop drawing" else "Annotate",
                                tint = if (drawMode) Color(0xFFFFEB3B) else MaterialTheme.colorScheme.onSurface
                            )
                        }
                        TextButton(onClick = { scale = (scale - 0.25f).coerceIn(0.5f, 4f) }) {
                            Text("\u2212", fontSize = 18.sp)
                        }
                        Text("${(scale * 100).roundToInt()}%", fontSize = 12.sp,
                            color = MaterialTheme.colorScheme.onSurfaceVariant)
                        TextButton(onClick = { scale = (scale + 0.25f).coerceIn(0.5f, 4f) }) {
                            Text("+", fontSize = 18.sp)
                        }
                        Box {
                            IconButton(onClick = { menuOpen = true }) {
                                Icon(Icons.Default.MoreVert, contentDescription = "More")
                            }
                            DropdownMenu(expanded = menuOpen, onDismissRequest = { menuOpen = false }) {
                                val isFav = noteId in favouriteIds
                                DropdownMenuItem(
                                    text = { Text(if (isFav) "\uD83D\uDC94 Remove favourite" else "\u2B50 Add favourite") },
                                    onClick = { menuOpen = false; vm.toggleFavourite(noteId) }
                                )
                                HorizontalDivider()
                                DropdownMenuItem(
                                    text = { Text("\u23E9 Go to page\u2026") },
                                    onClick = { menuOpen = false; showJumpDialog = true }
                                )
                                DropdownMenuItem(
                                    text = { Text("\uD83D\uDD0D Search library") },
                                    onClick = { menuOpen = false; nav.navigate("search") }
                                )
                                DropdownMenuItem(
                                    text = { Text("\uD83D\uDCDC PDF history") },
                                    onClick = { menuOpen = false; nav.navigate("pdfHistory") }
                                )
                                DropdownMenuItem(
                                    text = { Text("\u2699\uFE0F Settings") },
                                    onClick = { menuOpen = false; nav.navigate("settings") }
                                )
                                HorizontalDivider()
                                DropdownMenuItem(
                                    text = { Text("\uD83D\uDDA8\uFE0F Print PDF") },
                                    onClick = { menuOpen = false; printPdf(ctx, pdfUri, title) }
                                )
                                DropdownMenuItem(
                                    text = { Text("\uD83D\uDCE4 Share PDF") },
                                    onClick = { menuOpen = false; sharePdf(ctx, pdfUri, title) }
                                )
                                DropdownMenuItem(
                                    text = { Text("\uD83C\uDF10 Open externally") },
                                    onClick = { menuOpen = false; openPdfExternally(ctx, pdfUri) }
                                )
                                HorizontalDivider()
                                if (annotations.values.any { it.isNotEmpty() }) {
                                    DropdownMenuItem(
                                        text = { Text("\uD83D\uDDD1\uFE0F Clear all annotations") },
                                        onClick = {
                                            menuOpen = false
                                            annotations.clear()
                                            scope.launch { vm.clearAllAnnotations(noteId) }
                                        }
                                    )
                                }
                                DropdownMenuItem(
                                    text = { Text("\uD83D\uDD04 Reset zoom") },
                                    onClick = { menuOpen = false; scale = 1f; offsetX = 0f; offsetY = 0f }
                                )
                            }
                        }
                    }
                )
            }
        }
    ) { pad ->
        Box(Modifier.padding(pad).fillMaxSize().background(Color(0xFF0A0A0A))) {
            when {
                loading -> CenteredStatus("\u23F3 Opening PDF\u2026")
                error != null -> CenteredStatus("\u26A0\uFE0F $error")
                pool != null -> {
                    PageScrollContainer(
                        pool = pool!!,
                        listState = listState,
                        placeholderHeight = placeholderH,
                        scale = scale, onScale = { scale = it },
                        offsetX = offsetX, onOffsetX = { offsetX = it },
                        offsetY = offsetY, onOffsetY = { offsetY = it },
                        matchPages = matches.toSet(),
                        annotations = annotations,
                        drawMode = drawMode,
                        onAnnotationChanged = { page ->
                            scope.launch {
                                val json = serializePathsJson(annotations[page] ?: emptyList())
                                vm.saveAnnotation(noteId, page, json)
                            }
                        },
                        onLongPress = { page -> textPanelPage = page }
                    )
                    if (pageCount > 0) {
                        // Page chip — tap to jump
                        Surface(
                            modifier = Modifier
                                .align(Alignment.BottomCenter)
                                .padding(bottom = 20.dp)
                                .clickable { showJumpDialog = true },
                            color = Color(0xE61A1A1A),
                            shape = RoundedCornerShape(20.dp)
                        ) {
                            Text(
                                "\uD83D\uDCC4 $currentPage / $pageCount",
                                Modifier.padding(horizontal = 18.dp, vertical = 10.dp),
                                fontSize = 14.sp, fontWeight = FontWeight.Medium,
                                color = Color(0xFFEEEEEE)
                            )
                        }
                    }
                    if (drawMode) {
                        Surface(
                            modifier = Modifier.align(Alignment.TopCenter).padding(top = 8.dp),
                            color = Color(0xCCFFC107), shape = RoundedCornerShape(14.dp)
                        ) {
                            Text(
                                "\uD83D\uDD8D\uFE0F Drawing mode — drag to annotate",
                                Modifier.padding(horizontal = 14.dp, vertical = 6.dp),
                                fontSize = 12.sp, color = Color(0xFF1A1A1A),
                                fontWeight = FontWeight.Medium
                            )
                        }
                    }
                }
            }
        }
    }

    // ── Password dialog ──
    if (showPasswordDialog) {
        PasswordDialog(
            wrongPassword = passwordError,
            onCancel = { showPasswordDialog = false; nav.popBackStack() },
            onSubmit = { pw -> openPdf(pw) }
        )
    }

    // ── Jump to page dialog ──
    if (showJumpDialog && pageCount > 0) {
        JumpToPageDialog(
            current = currentPage, total = pageCount,
            onDismiss = { showJumpDialog = false },
            onJump = { target ->
                showJumpDialog = false
                scope.launch {
                    runCatching {
                        listState.animateScrollToItem((target - 1).coerceIn(0, pageCount - 1))
                    }
                }
            }
        )
    }

    // ── Text panel bottom sheet (text "selection" via long-press) ──
    val tp = textPanelPage
    if (tp != null) {
        TextPanelSheet(
            pageIndex = tp,
            pageTexts = pageTexts,
            onExtractAll = {
                // If text not yet extracted, kick off extraction
                if (pageTexts.isEmpty() && !extracting) {
                    searchOpen = true   // triggers extraction LaunchedEffect
                }
            },
            onCopy = { txt ->
                val cb = ctx.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                cb.setPrimaryClip(ClipData.newPlainText("PDF text", txt))
                Toast.makeText(ctx, "Copied to clipboard \uD83D\uDCCB", Toast.LENGTH_SHORT).show()
            },
            onDismiss = { textPanelPage = null }
        )
    }
}

/* ════════════════════════════════════════════════════════════════════════
 *  PdfViewerStandalone — external PDF activity (no DB, no nav)
 * ════════════════════════════════════════════════════════════════════════ */

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun PdfViewerStandalone(uri: Uri?, titleHint: String, onClose: () -> Unit) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()

    var title by remember { mutableStateOf(titleHint) }
    var pool by remember { mutableStateOf<PdfRendererPool?>(null) }
    var pageAspect by remember { mutableFloatStateOf(1.414f) }
    var loading by remember { mutableStateOf(true) }
    var error by remember { mutableStateOf<String?>(null) }
    var menuOpen by remember { mutableStateOf(false) }
    var showPasswordDialog by remember { mutableStateOf(false) }
    var passwordError by remember { mutableStateOf(false) }
    var showJumpDialog by remember { mutableStateOf(false) }

    var searchOpen by remember { mutableStateOf(false) }
    var searchQuery by remember { mutableStateOf("") }
    var pageTexts by remember { mutableStateOf<Map<Int, String>>(emptyMap()) }
    var extractProgress by remember { mutableFloatStateOf(0f) }
    var extracting by remember { mutableStateOf(false) }
    var matches by remember { mutableStateOf<List<Int>>(emptyList()) }
    var currentMatch by remember { mutableIntStateOf(0) }
    var textPanelPage by remember { mutableStateOf<Int?>(null) }

    var scale by remember { mutableFloatStateOf(1f) }
    var offsetX by remember { mutableFloatStateOf(0f) }
    var offsetY by remember { mutableFloatStateOf(0f) }
    val listState = rememberLazyListState()
    val searchFocus = remember { FocusRequester() }
    val annotations = remember { mutableStateMapOf<Int, SnapshotStateList<List<Offset>>>() }

    val pageCount = pool?.pageCount ?: 0
    val currentPage by remember {
        derivedStateOf {
            (listState.firstVisibleItemIndex + 1).coerceIn(1, pageCount.coerceAtLeast(1))
        }
    }

    fun openPdf(password: String?) {
        scope.launch {
            loading = true; error = null; passwordError = false
            if (uri == null) { error = "No file was provided."; loading = false; return@launch }
            when (val res = PdfRendererPool.open(ctx, uri, poolSize = 3, password = password)) {
                is PdfRendererPool.OpenResult.Success -> {
                    pool = res.pool; pageAspect = res.pool.firstPageAspect()
                    showPasswordDialog = false; loading = false
                }
                is PdfRendererPool.OpenResult.NeedsPassword -> { showPasswordDialog = true; loading = false }
                is PdfRendererPool.OpenResult.WrongPassword -> {
                    passwordError = true; showPasswordDialog = true; loading = false
                }
                is PdfRendererPool.OpenResult.Failure -> { error = res.message; loading = false }
            }
        }
    }

    LaunchedEffect(uri) { openPdf(null) }

    DisposableEffect(Unit) { onDispose { pool?.close() } }

    BackHandler {
        if (searchOpen) { searchOpen = false; searchQuery = ""; matches = emptyList() }
        else onClose()
    }

    LaunchedEffect(searchOpen) {
        if (!searchOpen || pageTexts.isNotEmpty() || uri == null) return@LaunchedEffect
        val total = pool?.pageCount ?: return@LaunchedEffect
        if (total == 0) return@LaunchedEffect
        extracting = true; extractProgress = 0.05f
        val texts = withContext(Dispatchers.IO) {
            extractPdfTextFast(ctx, uri) { done, all ->
                extractProgress = if (all > 0) done.toFloat() / all else 0f
            }
        }
        pageTexts = texts; extracting = false
    }

    LaunchedEffect(searchQuery, pageTexts) {
        val q = searchQuery.trim()
        if (q.length < 2 || pageTexts.isEmpty()) {
            matches = emptyList(); currentMatch = 0; return@LaunchedEffect
        }
        val lc = q.lowercase()
        val hits = pageTexts.entries.asSequence()
            .filter { it.value.lowercase().contains(lc) }
            .map { it.key }.sorted().toList()
        matches = hits; currentMatch = 0
        if (hits.isNotEmpty()) scope.launch { runCatching { listState.animateScrollToItem(hits[0]) } }
    }

    val density = ctx.resources.displayMetrics.density
    val placeholderH = remember(pageAspect) {
        (ctx.resources.displayMetrics.widthPixels * pageAspect / density).dp
    }

    Scaffold(
        topBar = {
            if (searchOpen) {
                PdfSearchBar(
                    query = searchQuery, onQueryChange = { searchQuery = it },
                    extracting = extracting, extractProgress = extractProgress,
                    matchCount = matches.size, currentMatch = currentMatch,
                    focusRequester = searchFocus,
                    onClose = { searchOpen = false; searchQuery = ""; matches = emptyList() },
                    onPrev = {
                        if (matches.isNotEmpty()) {
                            currentMatch = (currentMatch - 1 + matches.size) % matches.size
                            scope.launch { runCatching { listState.animateScrollToItem(matches[currentMatch]) } }
                        }
                    },
                    onNext = {
                        if (matches.isNotEmpty()) {
                            currentMatch = (currentMatch + 1) % matches.size
                            scope.launch { runCatching { listState.animateScrollToItem(matches[currentMatch]) } }
                        }
                    }
                )
                LaunchedEffect(Unit) { runCatching { searchFocus.requestFocus() } }
            } else {
                TopAppBar(
                    title = {
                        Column {
                            Text(title, maxLines = 1, overflow = TextOverflow.Ellipsis,
                                fontSize = 15.sp, fontWeight = FontWeight.SemiBold)
                            if (pageCount > 0) {
                                Text("Page $currentPage of $pageCount",
                                    fontSize = 11.sp,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant)
                            }
                        }
                    },
                    navigationIcon = {
                        IconButton(onClick = onClose) {
                            Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Close")
                        }
                    },
                    actions = {
                        IconButton(onClick = { searchOpen = true }) {
                            Icon(Icons.Default.Search, contentDescription = "Search in PDF")
                        }
                        TextButton(onClick = { scale = (scale - 0.25f).coerceIn(0.5f, 4f) }) {
                            Text("\u2212", fontSize = 18.sp)
                        }
                        Text("${(scale * 100).roundToInt()}%", fontSize = 12.sp,
                            color = MaterialTheme.colorScheme.onSurfaceVariant)
                        TextButton(onClick = { scale = (scale + 0.25f).coerceIn(0.5f, 4f) }) {
                            Text("+", fontSize = 18.sp)
                        }
                        Box {
                            IconButton(onClick = { menuOpen = true }) {
                                Icon(Icons.Default.MoreVert, contentDescription = "More")
                            }
                            DropdownMenu(expanded = menuOpen, onDismissRequest = { menuOpen = false }) {
                                DropdownMenuItem(
                                    text = { Text("\u23E9 Go to page\u2026") },
                                    onClick = { menuOpen = false; showJumpDialog = true }
                                )
                                HorizontalDivider()
                                DropdownMenuItem(
                                    text = { Text("\uD83D\uDDA8\uFE0F Print PDF") },
                                    onClick = { menuOpen = false; printPdf(ctx, uri?.toString(), title) }
                                )
                                DropdownMenuItem(
                                    text = { Text("\uD83D\uDCE4 Share PDF") },
                                    onClick = { menuOpen = false; sharePdf(ctx, uri?.toString(), title) }
                                )
                                DropdownMenuItem(
                                    text = { Text("\uD83C\uDF10 Open externally") },
                                    onClick = { menuOpen = false; openPdfExternally(ctx, uri?.toString()) }
                                )
                                HorizontalDivider()
                                DropdownMenuItem(
                                    text = { Text("\uD83D\uDD04 Reset zoom") },
                                    onClick = { menuOpen = false; scale = 1f; offsetX = 0f; offsetY = 0f }
                                )
                            }
                        }
                    }
                )
            }
        }
    ) { pad ->
        Box(Modifier.padding(pad).fillMaxSize().background(Color(0xFF0A0A0A))) {
            when {
                loading -> CenteredStatus("\u23F3 Opening PDF\u2026")
                error != null -> CenteredStatus("\u26A0\uFE0F $error")
                pool != null -> {
                    PageScrollContainer(
                        pool = pool!!, listState = listState, placeholderHeight = placeholderH,
                        scale = scale, onScale = { scale = it },
                        offsetX = offsetX, onOffsetX = { offsetX = it },
                        offsetY = offsetY, onOffsetY = { offsetY = it },
                        matchPages = matches.toSet(),
                        annotations = annotations, drawMode = false,
                        onAnnotationChanged = { },
                        onLongPress = { p -> textPanelPage = p }
                    )
                    if (pageCount > 0) {
                        Surface(
                            modifier = Modifier
                                .align(Alignment.BottomCenter)
                                .padding(bottom = 20.dp)
                                .clickable { showJumpDialog = true },
                            color = Color(0xE61A1A1A),
                            shape = RoundedCornerShape(20.dp)
                        ) {
                            Text(
                                "\uD83D\uDCC4 $currentPage / $pageCount",
                                Modifier.padding(horizontal = 18.dp, vertical = 10.dp),
                                fontSize = 14.sp, fontWeight = FontWeight.Medium,
                                color = Color(0xFFEEEEEE)
                            )
                        }
                    }
                }
            }
        }
    }

    if (showPasswordDialog) {
        PasswordDialog(
            wrongPassword = passwordError,
            onCancel = { showPasswordDialog = false; onClose() },
            onSubmit = { pw -> openPdf(pw) }
        )
    }

    if (showJumpDialog && pageCount > 0) {
        JumpToPageDialog(
            current = currentPage, total = pageCount,
            onDismiss = { showJumpDialog = false },
            onJump = { target ->
                showJumpDialog = false
                scope.launch {
                    runCatching { listState.animateScrollToItem((target - 1).coerceIn(0, pageCount - 1)) }
                }
            }
        )
    }

    val tp = textPanelPage
    if (tp != null) {
        TextPanelSheet(
            pageIndex = tp, pageTexts = pageTexts,
            onExtractAll = { if (pageTexts.isEmpty() && !extracting) searchOpen = true },
            onCopy = { txt ->
                val cb = ctx.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                cb.setPrimaryClip(ClipData.newPlainText("PDF text", txt))
                Toast.makeText(ctx, "Copied to clipboard \uD83D\uDCCB", Toast.LENGTH_SHORT).show()
            },
            onDismiss = { textPanelPage = null }
        )
    }
}

/* ════════════════════════════════════════════════════════════════════════
 *  Reusable building blocks
 * ════════════════════════════════════════════════════════════════════════ */

@Composable
private fun PageScrollContainer(
    pool: PdfRendererPool,
    listState: LazyListState,
    placeholderHeight: Dp,
    scale: Float, onScale: (Float) -> Unit,
    offsetX: Float, onOffsetX: (Float) -> Unit,
    offsetY: Float, onOffsetY: (Float) -> Unit,
    matchPages: Set<Int>,
    annotations: SnapshotStateMap<Int, SnapshotStateList<List<Offset>>>,
    drawMode: Boolean,
    onAnnotationChanged: (Int) -> Unit,
    onLongPress: (Int) -> Unit
) {
    val ctx = LocalContext.current
    val screenWidth = ctx.resources.displayMetrics.widthPixels

    Box(
        Modifier.fillMaxSize()
            .pointerInput(drawMode) {
                // Only respond to multi-touch zoom; single-finger gestures go to children
                detectTransformGestures { _, pan, zoom, _ ->
                    if (drawMode) return@detectTransformGestures   // drawing instead
                    val ns = (scale * zoom).coerceIn(0.5f, 4f)
                    if (ns > 1f) { onOffsetX(offsetX + pan.x); onOffsetY(offsetY + pan.y) }
                    else { onOffsetX(0f); onOffsetY(0f) }
                    onScale(ns)
                }
            }
            .pointerInput(drawMode) {
                detectTapGestures(onDoubleTap = {
                    if (drawMode) return@detectTapGestures
                    if (scale > 1.1f) { onScale(1f); onOffsetX(0f); onOffsetY(0f) }
                    else onScale(2f)
                })
            }
    ) {
        LazyColumn(
            state = listState,
            modifier = Modifier.fillMaxSize().graphicsLayer(
                scaleX = scale, scaleY = scale,
                translationX = offsetX, translationY = offsetY
            ),
            verticalArrangement = Arrangement.spacedBy(4.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            items(pool.pageCount) { index ->
                val ann = annotations.getOrCreate(index)
                PdfPageItem(
                    pool = pool,
                    pageIndex = index,
                    targetWidth = screenWidth,
                    placeholderHeight = placeholderHeight,
                    highlight = index in matchPages,
                    annotation = ann,
                    drawMode = drawMode,
                    onAnnotationChanged = { onAnnotationChanged(index) },
                    onLongPress = onLongPress
                )
            }
            item { Spacer(Modifier.height(80.dp)) }
        }
    }
}

private fun <T> SnapshotStateMap<Int, SnapshotStateList<T>>.getOrCreate(key: Int): SnapshotStateList<T> {
    return this.getOrPut(key) { mutableStateListOf() }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun PdfSearchBar(
    query: String, onQueryChange: (String) -> Unit,
    extracting: Boolean, extractProgress: Float,
    matchCount: Int, currentMatch: Int,
    focusRequester: FocusRequester,
    onClose: () -> Unit, onPrev: () -> Unit, onNext: () -> Unit
) {
    Column {
        TopAppBar(
            title = {
                TextField(
                    value = query, onValueChange = onQueryChange,
                    placeholder = { Text("Search in PDF\u2026", fontSize = 14.sp) },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth().focusRequester(focusRequester),
                    keyboardOptions = KeyboardOptions(imeAction = ImeAction.Search),
                    colors = TextFieldDefaults.colors(
                        focusedContainerColor = Color.Transparent,
                        unfocusedContainerColor = Color.Transparent
                    )
                )
            },
            navigationIcon = {
                IconButton(onClick = onClose) {
                    Icon(Icons.Default.Close, contentDescription = "Close search")
                }
            },
            actions = {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    if (extracting) {
                        Text("${(extractProgress * 100).toInt()}%",
                            fontSize = 11.sp,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                            modifier = Modifier.padding(end = 6.dp))
                    } else if (query.trim().length >= 2) {
                        Text(
                            if (matchCount > 0) "${currentMatch + 1}/$matchCount" else "0/0",
                            fontSize = 12.sp,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                            modifier = Modifier.padding(end = 4.dp))
                        IconButton(onClick = onPrev) {
                            Icon(Icons.Default.KeyboardArrowUp, contentDescription = "Previous match")
                        }
                        IconButton(onClick = onNext) {
                            Icon(Icons.Default.KeyboardArrowDown, contentDescription = "Next match")
                        }
                    }
                    Spacer(Modifier.width(4.dp))
                }
            }
        )
        if (extracting) {
            LinearProgressIndicator(progress = { extractProgress }, modifier = Modifier.fillMaxWidth())
        }
    }
}

@Composable
private fun CenteredStatus(msg: String) {
    Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
        Text(msg, color = MaterialTheme.colorScheme.onSurfaceVariant,
            fontSize = 14.sp, lineHeight = 20.sp)
    }
}

@Composable
private fun PasswordDialog(
    wrongPassword: Boolean,
    onCancel: () -> Unit,
    onSubmit: (String) -> Unit
) {
    var password by remember { mutableStateOf("") }
    AlertDialog(
        onDismissRequest = onCancel,
        title = { Text("\uD83D\uDD12 Password required") },
        text = {
            Column {
                Text(
                    if (wrongPassword) "Incorrect password. Try again:"
                    else "This PDF is password protected.",
                    fontSize = 14.sp
                )
                Spacer(Modifier.height(12.dp))
                OutlinedTextField(
                    value = password, onValueChange = { password = it },
                    label = { Text("Password") },
                    singleLine = true,
                    visualTransformation = PasswordVisualTransformation(),
                    keyboardOptions = KeyboardOptions(
                        keyboardType = KeyboardType.Password, imeAction = ImeAction.Done
                    ),
                    modifier = Modifier.fillMaxWidth()
                )
            }
        },
        confirmButton = {
            Button(onClick = { onSubmit(password) }, enabled = password.isNotEmpty()) {
                Text("Open")
            }
        },
        dismissButton = { TextButton(onClick = onCancel) { Text("Cancel") } }
    )
}

@Composable
private fun JumpToPageDialog(
    current: Int, total: Int,
    onDismiss: () -> Unit, onJump: (Int) -> Unit
) {
    var input by remember { mutableStateOf(current.toString()) }
    var err by remember { mutableStateOf<String?>(null) }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("\u23E9 Go to page") },
        text = {
            Column {
                Text("Total pages: $total", fontSize = 12.sp,
                    color = MaterialTheme.colorScheme.onSurfaceVariant)
                Spacer(Modifier.height(8.dp))
                OutlinedTextField(
                    value = input, onValueChange = { input = it.filter { c -> c.isDigit() }; err = null },
                    label = { Text("Page number") },
                    singleLine = true, isError = err != null,
                    keyboardOptions = KeyboardOptions(
                        keyboardType = KeyboardType.Number, imeAction = ImeAction.Go
                    ),
                    modifier = Modifier.fillMaxWidth()
                )
                err?.let {
                    Spacer(Modifier.height(4.dp))
                    Text(it, color = MaterialTheme.colorScheme.error, fontSize = 12.sp)
                }
            }
        },
        confirmButton = {
            Button(onClick = {
                val n = input.toIntOrNull()
                if (n == null || n < 1 || n > total) err = "Enter 1 to $total"
                else onJump(n)
            }) { Text("Go") }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Cancel") } }
    )
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun TextPanelSheet(
    pageIndex: Int,
    pageTexts: Map<Int, String>,
    onExtractAll: () -> Unit,
    onCopy: (String) -> Unit,
    onDismiss: () -> Unit
) {
    val sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true)
    val text = pageTexts[pageIndex]
    ModalBottomSheet(
        onDismissRequest = onDismiss, sheetState = sheetState,
        containerColor = MaterialTheme.colorScheme.surface
    ) {
        Column(
            Modifier.fillMaxWidth()
                .heightIn(min = 200.dp, max = 600.dp)
                .padding(16.dp)
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(
                    "\uD83D\uDCC4 Page ${pageIndex + 1} text",
                    fontSize = 15.sp, fontWeight = FontWeight.SemiBold,
                    modifier = Modifier.weight(1f)
                )
                if (!text.isNullOrBlank()) {
                    TextButton(onClick = { onCopy(text) }) {
                        Text("\uD83D\uDCCB Copy all", fontSize = 13.sp)
                    }
                }
            }
            Spacer(Modifier.height(8.dp))
            if (text == null) {
                Text(
                    "Text isn't extracted yet. Tap below to extract — then you can long-press any page to copy text.",
                    fontSize = 13.sp, color = MaterialTheme.colorScheme.onSurfaceVariant
                )
                Spacer(Modifier.height(12.dp))
                Button(onClick = onExtractAll) { Text("Extract page text") }
            } else if (text.isBlank()) {
                Text(
                    "This page has no extractable text (it may be a scanned image).",
                    fontSize = 13.sp, color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            } else {
                SelectionContainer {
                    Box(Modifier.fillMaxWidth().verticalScroll(rememberScrollState())) {
                        Text(text, fontSize = 14.sp, lineHeight = 21.sp)
                    }
                }
            }
        }
    }
}

@Composable
private fun SelectionContainer(content: @Composable () -> Unit) {
    androidx.compose.foundation.text.selection.SelectionContainer { content() }
}

/* ════════════════════════════════════════════════════════════════════════
 *  Text extraction — single-pass fast path
 * ════════════════════════════════════════════════════════════════════════ */

/**
 * Extracts ALL pages of a PDF in ONE pass. PdfBox inserts a form-feed (\u000C)
 * between pages by default, so a single getText() call followed by splitting on
 * \u000C is dramatically faster than calling getText() once per page (which is
 * what the old code did — and what made 2000-page PDFs take forever).
 */
private suspend fun extractPdfTextFast(
    ctx: Context, uri: Uri,
    onProgress: (done: Int, total: Int) -> Unit
): Map<Int, String> = withContext(Dispatchers.IO) {
    val result = mutableMapOf<Int, String>()
    try {
        ctx.contentResolver.openInputStream(uri)?.use { input ->
            PDDocument.load(input).use { doc ->
                val total = doc.numberOfPages
                onProgress(0, total)
                val stripper = PDFTextStripper()
                stripper.startPage = 1
                stripper.endPage = total
                stripper.lineSeparator = "\n"
                // Single getText call — orders of magnitude faster than per-page
                val all = stripper.getText(doc) ?: ""
                val pages = all.split('\u000C')
                for (i in 0 until total) {
                    result[i] = if (i < pages.size) pages[i] else ""
                    if ((i + 1) % 25 == 0 || i + 1 == total) onProgress(i + 1, total)
                }
            }
        }
    } catch (e: Exception) {
        Log.e(TAG, "extractPdfTextFast failed", e)
    }
    result
}

/* ════════════════════════════════════════════════════════════════════════
 *  Annotation serialization
 * ════════════════════════════════════════════════════════════════════════ */

private fun serializePathsJson(paths: List<List<Offset>>): String {
    val root = JSONArray()
    for (stroke in paths) {
        val s = JSONArray()
        for (p in stroke) {
            val pt = org.json.JSONObject()
            pt.put("x", p.x); pt.put("y", p.y)
            s.put(pt)
        }
        root.put(s)
    }
    return root.toString()
}

private fun parsePathsJson(json: String): List<List<Offset>> {
    return try {
        val out = mutableListOf<List<Offset>>()
        val root = JSONArray(json)
        for (i in 0 until root.length()) {
            val strokeArr = root.getJSONArray(i)
            val stroke = mutableListOf<Offset>()
            for (j in 0 until strokeArr.length()) {
                val pt = strokeArr.getJSONObject(j)
                stroke.add(Offset(pt.getDouble("x").toFloat(), pt.getDouble("y").toFloat()))
            }
            if (stroke.size > 1) out.add(stroke)
        }
        out
    } catch (_: Exception) { emptyList() }
}

/* ════════════════════════════════════════════════════════════════════════
 *  Share / open / print helpers
 * ════════════════════════════════════════════════════════════════════════ */

private fun sharePdf(ctx: Context, uriString: String?, title: String) {
    if (uriString == null) {
        Toast.makeText(ctx, "PDF URI not available", Toast.LENGTH_SHORT).show(); return
    }
    try {
        val intent = Intent(Intent.ACTION_SEND).apply {
            type = "application/pdf"
            putExtra(Intent.EXTRA_STREAM, Uri.parse(uriString))
            putExtra(Intent.EXTRA_SUBJECT, title)
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        }
        ctx.startActivity(Intent.createChooser(intent, "Share PDF"))
    } catch (e: Exception) {
        Toast.makeText(ctx, "Could not share: ${e.message}", Toast.LENGTH_SHORT).show()
    }
}

private fun openPdfExternally(ctx: Context, uriString: String?) {
    if (uriString == null) {
        Toast.makeText(ctx, "PDF URI not available", Toast.LENGTH_SHORT).show(); return
    }
    try {
        val intent = Intent(Intent.ACTION_VIEW).apply {
            setDataAndType(Uri.parse(uriString), "application/pdf")
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_ACTIVITY_NEW_TASK)
        }
        ctx.startActivity(intent)
    } catch (e: Exception) {
        Toast.makeText(ctx, "No app can open this PDF", Toast.LENGTH_SHORT).show()
    }
}

/**
 * Print the PDF via Android PrintManager. Streams the raw PDF bytes to the print
 * framework so the system print spooler can route to a printer or "Save as PDF".
 */
private fun printPdf(ctx: Context, uriString: String?, title: String) {
    if (uriString == null) {
        Toast.makeText(ctx, "PDF URI not available", Toast.LENGTH_SHORT).show(); return
    }
    try {
        val pm = ctx.getSystemService(Context.PRINT_SERVICE) as PrintManager
        val jobName = "MarkVault: $title"
        val adapter = object : PrintDocumentAdapter() {
            override fun onLayout(
                old: PrintAttributes?, new: PrintAttributes?,
                cancellationSignal: android.os.CancellationSignal?,
                callback: LayoutResultCallback?, extras: android.os.Bundle?
            ) {
                if (cancellationSignal?.isCanceled == true) { callback?.onLayoutCancelled(); return }
                val info = PrintDocumentInfo.Builder(jobName)
                    .setContentType(PrintDocumentInfo.CONTENT_TYPE_DOCUMENT)
                    .build()
                callback?.onLayoutFinished(info, true)
            }
            override fun onWrite(
                pages: Array<out android.print.PageRange>?,
                destination: ParcelFileDescriptor?,
                cancellationSignal: android.os.CancellationSignal?,
                callback: WriteResultCallback?
            ) {
                try {
                    ctx.contentResolver.openInputStream(Uri.parse(uriString))?.use { input ->
                        java.io.FileOutputStream(destination?.fileDescriptor).use { out ->
                            input.copyTo(out)
                        }
                    }
                    callback?.onWriteFinished(arrayOf(android.print.PageRange.ALL_PAGES))
                } catch (e: Exception) {
                    Log.e(TAG, "print onWrite failed", e)
                    callback?.onWriteFailed(e.message)
                }
            }
        }
        pm.print(jobName, adapter, null)
    } catch (e: Exception) {
        Toast.makeText(ctx, "Print failed: ${e.message}", Toast.LENGTH_SHORT).show()
    }
}
