package com.tebogo.markvault.ui

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.pdf.PdfRenderer
import android.net.Uri
import android.os.ParcelFileDescriptor
import android.print.PrintAttributes
import android.print.PrintDocumentAdapter
import android.print.PrintDocumentInfo
import android.print.PrintManager
import android.util.Log
import android.widget.Toast
import androidx.activity.compose.BackHandler
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.awaitEachGesture
import androidx.compose.foundation.gestures.awaitFirstDown
import androidx.compose.foundation.gestures.calculatePan
import androidx.compose.foundation.gestures.calculateZoom
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.gestures.detectTransformGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyListState
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.rememberScrollState
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.filled.KeyboardArrowLeft
import androidx.compose.material.icons.automirrored.filled.KeyboardArrowRight
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.KeyboardArrowDown
import androidx.compose.material.icons.filled.KeyboardArrowUp
import androidx.compose.material.icons.filled.MoreVert
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TextField
import androidx.compose.material3.TextFieldDefaults
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.rememberModalBottomSheetState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.derivedStateOf
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateMapOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.runtime.setValue
import androidx.compose.runtime.snapshots.SnapshotStateList
import androidx.compose.runtime.snapshots.SnapshotStateMap
import androidx.compose.runtime.toMutableStateList
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.StrokeJoin
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.navigation.NavController
import com.tebogo.markvault.AppViewModel
import com.tom_roush.pdfbox.pdmodel.PDDocument
import com.tom_roush.pdfbox.text.PDFTextStripper
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.channels.Channel
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import org.json.JSONArray
import java.io.File
import java.io.FileOutputStream
import kotlin.math.roundToInt
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.filled.Add
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.material.icons.filled.Menu

private const val TAG = "PdfReader"

/* ════════════════════════════════════════════════════════════════════════
 *  PDF RENDERER POOL — parallel rendering across multiple PdfRenderer instances
 * ════════════════════════════════════════════════════════════════════════ */

class PdfRendererPool private constructor(
    private val renderers: List<PdfRenderer>,
    /** If non-null, this is a decrypted copy in cache that should be deleted on close. */
    private val tempFileToDelete: File? = null
) {
    private val available = Channel<PdfRenderer>(Channel.UNLIMITED).also { ch ->
        renderers.forEach { ch.trySend(it) }
    }

    val pageCount: Int = renderers.firstOrNull()?.pageCount ?: 0
    val poolSize: Int = renderers.size

    suspend fun renderPage(pageIndex: Int, targetWidth: Int): Bitmap? = withContext(Dispatchers.IO) {
        if (pageIndex < 0 || pageIndex >= pageCount) return@withContext null
        val r = available.receive()
        try {
            val page = r.openPage(pageIndex)
            val scale = targetWidth.toFloat() / page.width
            val h = (page.height * scale).toInt().coerceAtLeast(1)
            val bmp = Bitmap.createBitmap(targetWidth, h, Bitmap.Config.ARGB_8888)
            bmp.eraseColor(android.graphics.Color.WHITE)
            page.render(bmp, null, null, PdfRenderer.Page.RENDER_MODE_FOR_DISPLAY)
            page.close()
            bmp
        } catch (e: Exception) {
            Log.e(TAG, "renderPage($pageIndex) failed", e); null
        } finally { available.trySend(r) }
    }

    suspend fun firstPageAspect(): Float = withContext(Dispatchers.IO) {
        if (pageCount == 0) return@withContext 1.414f
        val r = available.receive()
        try {
            val p = r.openPage(0)
            val aspect = p.height.toFloat() / p.width.toFloat()
            p.close(); aspect
        } catch (e: Exception) { 1.414f }
        finally { available.trySend(r) }
    }

    fun close() {
        renderers.forEach { runCatching { it.close() } }
        available.close()
        tempFileToDelete?.let { runCatching { it.delete() } }
    }

    companion object {
        /**
         * Open a PDF for parallel rendering.
         * Returns Result.Success(pool) on success, Result.NeedsPassword if encrypted,
         * Result.Failure for other errors.
         */
        suspend fun open(
            ctx: Context, uri: Uri, poolSize: Int = 3, password: String? = null
        ): OpenResult = withContext(Dispatchers.IO) {
            // Try native first if no password
            if (password == null) {
                try {
                    val list = mutableListOf<PdfRenderer>()
                    repeat(poolSize) {
                        val pfd = ctx.contentResolver.openFileDescriptor(uri, "r")
                        if (pfd != null) list.add(PdfRenderer(pfd))
                    }
                    if (list.isNotEmpty()) return@withContext OpenResult.Success(PdfRendererPool(list))
                } catch (e: SecurityException) {
                    return@withContext OpenResult.NeedsPassword
                } catch (e: Exception) {
                    // Some encrypted PDFs throw IOException with "password" in the message
                    if (e.message?.contains("password", ignoreCase = true) == true ||
                        e.message?.contains("encrypt", ignoreCase = true) == true) {
                        return@withContext OpenResult.NeedsPassword
                    }
                    Log.e(TAG, "open native failed", e)
                    return@withContext OpenResult.Failure(e.message ?: "Could not open PDF")
                }
            }

            // Encrypted path: use PdfBox to decrypt to a temp file, then open the temp file natively
            try {
                val cacheDir = File(ctx.cacheDir, "pdf_decrypted").apply { mkdirs() }
                // Delete stale temp files
                cacheDir.listFiles()?.forEach { runCatching { it.delete() } }
                val temp = File.createTempFile("dec_", ".pdf", cacheDir)
                val ok = ctx.contentResolver.openInputStream(uri)?.use { input ->
                    try {
                        PDDocument.load(input, password ?: "").use { doc ->
                            doc.setAllSecurityToBeRemoved(true)
                            FileOutputStream(temp).use { os -> doc.save(os) }
                        }
                        true
                    } catch (e: com.tom_roush.pdfbox.pdmodel.encryption.InvalidPasswordException) {
                        Log.w(TAG, "wrong password"); false
                    } catch (e: Exception) {
                        Log.e(TAG, "decrypt failed", e); false
                    }
                } ?: false

                if (!ok) {
                    runCatching { temp.delete() }
                    return@withContext if (password != null) OpenResult.WrongPassword
                    else OpenResult.NeedsPassword
                }

                val list = mutableListOf<PdfRenderer>()
                repeat(poolSize) {
                    try {
                        val pfd = ParcelFileDescriptor.open(temp, ParcelFileDescriptor.MODE_READ_ONLY)
                        list.add(PdfRenderer(pfd))
                    } catch (e: Exception) { Log.w(TAG, "tmp renderer #$it failed", e) }
                }
                if (list.isEmpty()) {
                    runCatching { temp.delete() }
                    return@withContext OpenResult.Failure("Could not open decrypted file")
                }
                OpenResult.Success(PdfRendererPool(list, tempFileToDelete = temp))
            } catch (e: Exception) {
                Log.e(TAG, "decrypt path failed", e)
                OpenResult.Failure(e.message ?: "Could not open PDF")
            }
        }
    }

    sealed class OpenResult {
        data class Success(val pool: PdfRendererPool) : OpenResult()
        object NeedsPassword : OpenResult()
        object WrongPassword : OpenResult()
        data class Failure(val message: String) : OpenResult()
    }
}

/* ════════════════════════════════════════════════════════════════════════
 *  Per-item page composable — with annotation drawing layer
 * ════════════════════════════════════════════════════════════════════════ */

@Composable
private fun PdfPageItem(
    pool: PdfRendererPool,
    pageIndex: Int,
    targetWidth: Int,
    placeholderHeight: Dp,
    highlight: Boolean,
    annotation: SnapshotStateList<List<Offset>>,
    drawMode: Boolean,
    onAnnotationChanged: () -> Unit,
    onLongPress: (Int) -> Unit
) {
    var bitmap by remember(pool, pageIndex) { mutableStateOf<Bitmap?>(null) }

    LaunchedEffect(pool, pageIndex) {
        val bmp = pool.renderPage(pageIndex, targetWidth)
        bitmap = bmp
    }

    DisposableEffect(pool, pageIndex) {
        onDispose {
            val b = bitmap
            bitmap = null
            try { b?.recycle() } catch (_: Exception) { }
        }
    }

    val b = bitmap
    val density = LocalContext.current.resources.displayMetrics.density
    Box(
        Modifier
            .fillMaxWidth()
            .then(if (highlight) Modifier.background(Color(0x33FFC107)) else Modifier)
    ) {
        if (b != null && !b.isRecycled) {
            Image(
                bitmap = b.asImageBitmap(),
                contentDescription = "Page ${pageIndex + 1}",
                contentScale = ContentScale.FillWidth,
                modifier = Modifier.fillMaxWidth()
            )

            // Drawing layer — sits on top of the bitmap
            val pageHeight = b.height.toFloat() / b.width.toFloat() * targetWidth.toFloat()
            Canvas(
                modifier = Modifier
                    .fillMaxWidth()
                    .height((pageHeight / density).dp)
                    .then(
                        if (drawMode) Modifier.pointerInput(pool, pageIndex) {
                            val current = mutableListOf<Offset>()
                            detectDragGestures(
                                onDragStart = { offset -> current.clear(); current.add(offset) },
                                onDragEnd = {
                                    if (current.size > 1) {
                                        // Normalize to 0..1 against page width / height
                                        val sw = size.width.toFloat()
                                        val sh = size.height.toFloat()
                                        if (sw > 0 && sh > 0) {
                                            val normalised = current.map {
                                                Offset(it.x / sw, it.y / sh)
                                            }
                                            annotation.add(normalised)
                                            onAnnotationChanged()
                                        }
                                    }
                                    current.clear()
                                },
                                onDrag = { change, _ -> current.add(change.position) }
                            )
                        } else Modifier.pointerInput(pageIndex) {
                            detectTapGestures(onLongPress = { onLongPress(pageIndex) })
                        }
                    )
            ) {
                val sw = size.width; val sh = size.height
                annotation.forEach { stroke ->
                    if (stroke.size < 2) return@forEach
                    val path = Path()
                    val first = stroke.first()
                    path.moveTo(first.x * sw, first.y * sh)
                    for (i in 1 until stroke.size) {
                        path.lineTo(stroke[i].x * sw, stroke[i].y * sh)
                    }
                    drawPath(
                        path = path,
                        color = Color(0xFFFFEB3B),
                        style = Stroke(width = 5f, cap = StrokeCap.Round, join = StrokeJoin.Round)
                    )
                }
            }
        } else {
            Box(
                Modifier.fillMaxWidth().height(placeholderHeight).background(Color(0xFF1A1A1A)),
                contentAlignment = Alignment.Center
            ) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    CircularProgressIndicator(Modifier.size(24.dp), color = Color(0xFF666666), strokeWidth = 2.dp)
                    Spacer(Modifier.height(6.dp))
                    Text("Page ${pageIndex + 1}", fontSize = 11.sp, color = Color(0xFF666666))
                }
            }
        }
    }
}

/* ════════════════════════════════════════════════════════════════════════
 *  PdfReaderScreen — in-app PDF viewer (note from DB)
 * ════════════════════════════════════════════════════════════════════════ */

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun PdfReaderScreen(vm: AppViewModel, nav: NavController, noteId: Long) {
    val ctx = LocalContext.current
    val favouriteIds by vm.favouriteIds.collectAsStateWithLifecycle()
    val tabs by vm.tabs.collectAsStateWithLifecycle()
    val activeTab by vm.activeTab.collectAsStateWithLifecycle()
    val scope = rememberCoroutineScope()

    var title by remember { mutableStateOf("PDF") }
    var pdfUri by remember { mutableStateOf<String?>(null) }
    var pool by remember { mutableStateOf<PdfRendererPool?>(null) }
    var pageAspect by remember { mutableFloatStateOf(1.414f) }
    var loading by remember { mutableStateOf(true) }
    var error by remember { mutableStateOf<String?>(null) }
    var menuOpen by remember { mutableStateOf(false) }

    // Password dialog
    var showPasswordDialog by remember { mutableStateOf(false) }
    var passwordError by remember { mutableStateOf(false) }

    // Search
    var searchOpen by remember { mutableStateOf(false) }
    var searchQuery by remember { mutableStateOf("") }
    var pageTexts by remember { mutableStateOf<Map<Int, String>>(emptyMap()) }
    var extractProgress by remember { mutableFloatStateOf(0f) }
    var extracting by remember { mutableStateOf(false) }
    var matches by remember { mutableStateOf<List<Int>>(emptyList()) }
    var currentMatch by remember { mutableIntStateOf(0) }

    // Jump to page
    var showJumpDialog by remember { mutableStateOf(false) }

    // Text panel (long-press → bottom sheet)
    var textPanelPage by remember { mutableStateOf<Int?>(null) }

    // Annotations (per-page in-memory + persisted)
    val annotations = remember { mutableStateMapOf<Int, SnapshotStateList<List<Offset>>>() }
    var drawMode by remember { mutableStateOf(false) }

    // Zoom
    var scale by remember { mutableFloatStateOf(1f) }
    var offsetX by remember { mutableFloatStateOf(0f) }
    var offsetY by remember { mutableFloatStateOf(0f) }
    val listState = rememberLazyListState()
    val searchFocus = remember { FocusRequester() }

    // v4.7 — read `pool` INSIDE derivedStateOf so the page count updates after
    // the PDF finishes loading. The previous version captured pageCount=0 from
    // the outer scope at first composition, which permanently coerced the
    // current-page calculation into [1, 1] → the counter always read 1 and the
    // prev/next arrow buttons computed scroll targets relative to that
    // permanently-wrong value, which made them appear to do nothing.
    val pageCount = pool?.pageCount ?: 0
    val currentPage by remember {
        derivedStateOf {
            val pc = pool?.pageCount ?: 0
            (listState.firstVisibleItemIndex + 1).coerceIn(1, pc.coerceAtLeast(1))
        }
    }

    // Open the PDF (re-runs if password is supplied)
    fun openPdf(password: String?) {
        scope.launch {
            loading = true; error = null; passwordError = false
            val note = withContext(Dispatchers.IO) { vm.loadNote(noteId) }
            if (note == null || note.fileType != "pdf") {
                error = "Not a PDF file"; loading = false; return@launch
            }
            title = note.title; pdfUri = note.uri

            when (val res = PdfRendererPool.open(ctx, Uri.parse(note.uri), poolSize = 3, password = password)) {
                is PdfRendererPool.OpenResult.Success -> {
                    pool = res.pool
                    pageAspect = res.pool.firstPageAspect()
                    showPasswordDialog = false
                    // Log this view in PDF history
                    vm.recordPdfView(note.uri, note.title, noteId, isExternal = false)
                    // Load saved annotations from DB
                    val saved = vm.loadAllAnnotations(noteId)
                    saved.forEach { (page, json) ->
                        annotations[page] = parsePathsJson(json).toMutableStateList()
                    }
                    loading = false
                }
                is PdfRendererPool.OpenResult.NeedsPassword -> {
                    showPasswordDialog = true
                    loading = false
                }
                is PdfRendererPool.OpenResult.WrongPassword -> {
                    passwordError = true
                    showPasswordDialog = true
                    loading = false
                }
                is PdfRendererPool.OpenResult.Failure -> {
                    error = res.message; loading = false
                }
            }
        }
    }

    LaunchedEffect(noteId) { openPdf(null) }

    DisposableEffect(Unit) { onDispose { pool?.close() } }

    BackHandler {
        when {
            searchOpen -> { searchOpen = false; searchQuery = ""; matches = emptyList() }
            drawMode -> drawMode = false
            else -> nav.popBackStack()
        }
    }

    // v4.14.0 — Auto-jump on search-result click.
    //
    // When the user opens a PDF from a search result, the VM has a
    // `pendingHighlight` set. We consume it here exactly once per
    // PDF-load event, force-open the search panel (which triggers text
    // extraction below), and seed the query. The phrase-first picker in
    // the match LaunchedEffect downstream chooses the best matching
    // sub-term if the full phrase isn't in the document verbatim.
    //
    // `autoNavConsumed` guards against re-firing on recomposition.
    var autoNavConsumed by remember { mutableStateOf(false) }
    LaunchedEffect(pool) {
        if (pool == null || autoNavConsumed) return@LaunchedEffect
        autoNavConsumed = true
        // v5.4.10 — pendingHighlight became a data class. PDF in-page
        // search just needs the query string.
        val pending = vm.consumePendingHighlight()
        val term = pending?.query?.takeIf { it.isNotBlank() }
            ?: return@LaunchedEffect
        searchOpen = true
        searchQuery = term
    }

    // Text extraction: use cache if available, else extract once and save to cache
    LaunchedEffect(pool, searchOpen) {
        if (!searchOpen) return@LaunchedEffect
        if (pageTexts.isNotEmpty()) return@LaunchedEffect
        val uri = pdfUri ?: return@LaunchedEffect
        val total = pool?.pageCount ?: return@LaunchedEffect
        if (total == 0) return@LaunchedEffect

        // 1. Try cache first — instant
        val cached = vm.cachedPdfPageText(noteId)
        if (cached != null) {
            pageTexts = cached
            return@LaunchedEffect
        }

        // 2. Extract — single-pass fast extraction
        extracting = true; extractProgress = 0.05f
        val texts = withContext(Dispatchers.IO) {
            extractPdfTextFast(ctx, Uri.parse(uri)) { done, all ->
                extractProgress = if (all > 0) done.toFloat() / all else 0f
            }
        }
        pageTexts = texts
        extracting = false
        // 3. Save to cache for next time
        if (texts.isNotEmpty()) vm.savePdfPageText(noteId, texts)
    }

    // v4.14.0 — Phrase-first match recomputation.
    //
    // The existing single-needle `contains` was too strict for multi-word
    // queries: searching "many bodies of the holy ones" on a PDF that
    // actually has that exact phrase split across line breaks or with
    // small formatting differences returns zero hits. Now we try (in
    // order):
    //   1. The full normalised phrase
    //   2. The phrase with trailing punctuation removed
    //   3. The longest non-stopword that appears anywhere in the PDF
    //   4. Any matching word, stopwords included
    //
    // The first stage that produces any hit wins. Pages containing the
    // chosen term get added to the match list; the first one is
    // animateScrollTo'd. This benefits both manual search and the
    // auto-jump-on-result-click flow above.
    LaunchedEffect(searchQuery, pageTexts) {
        val q = searchQuery.trim()
        if (q.length < 2 || pageTexts.isEmpty()) {
            matches = emptyList(); currentMatch = 0
            return@LaunchedEffect
        }
        val picked = pickPdfHighlightTerm(q, pageTexts) ?: q.lowercase()
        val hits = pageTexts.entries.asSequence()
            .filter { it.value.lowercase().contains(picked) }
            .map { it.key }.sorted().toList()
        matches = hits; currentMatch = 0
        if (hits.isNotEmpty()) scope.launch { runCatching { listState.animateScrollToItem(hits[0]) } }
    }

    val density = ctx.resources.displayMetrics.density
    val placeholderH = remember(pageAspect) {
        (ctx.resources.displayMetrics.widthPixels * pageAspect / density).dp
    }

    // v5.4.23 — Workspace + tablet 2-column overlay for PDF. Left
    // panel = tabs list. No right panel: PDF outline needs the pdf
    // lib's TOC API which isn't wired here yet, so at tablet width
    // we get tabs | pdf reader. Phone width + standard mode → no
    // change.
    val uiMode by vm.uiMode.collectAsStateWithLifecycle()
    val workspaceOn = uiMode == "workspace"
    val screenWidthDp = androidx.compose.ui.platform.LocalConfiguration.current.screenWidthDp
    val isTabletWidth = screenWidthDp >= 600
    val threeColumn = workspaceOn && isTabletWidth
    val leftColWidth = 240.dp
    // v5.4.24 — Collapsible left panel (PDF has no right panel).
    var leftPanelOpen by remember { mutableStateOf(true) }

    // v5.4.34 — FABs for find-in-article (PDF).
    val fabEnabled by vm.searchInArticleFab.collectAsStateWithLifecycle()
    val semanticInArticleOn by vm.semanticInArticle.collectAsStateWithLifecycle()
    val currentSearchQuery by vm.query.collectAsStateWithLifecycle()
    val pdfOpenedFromSearch by androidx.compose.runtime.produceState(
        initialValue = false, key1 = noteId
    ) {
        value = vm.openedFromSearch.value
        vm.clearOpenedFromSearch()
    }

    // v5.4.39 — "Talk to the article" semantic search dialog state for PDF
    var showArticleSemanticDialog by remember { mutableStateOf(false) }

    androidx.compose.foundation.layout.Box(Modifier.fillMaxSize()) {
    androidx.compose.foundation.layout.Box(
        Modifier
            .padding(start = if (threeColumn && leftPanelOpen) leftColWidth else 0.dp)
            .fillMaxSize()
    ) {
    Scaffold(
        topBar = {
            if (searchOpen) {
                PdfSearchBar(
                    query = searchQuery, onQueryChange = { searchQuery = it },
                    extracting = extracting, extractProgress = extractProgress,
                    matchCount = matches.size, currentMatch = currentMatch,
                    focusRequester = searchFocus,
                    onClose = { searchOpen = false; searchQuery = ""; matches = emptyList() },
                    onPrev = {
                        if (matches.isNotEmpty()) {
                            currentMatch = (currentMatch - 1 + matches.size) % matches.size
                            scope.launch { runCatching { listState.animateScrollToItem(matches[currentMatch]) } }
                        }
                    },
                    onNext = {
                        if (matches.isNotEmpty()) {
                            currentMatch = (currentMatch + 1) % matches.size
                            scope.launch { runCatching { listState.animateScrollToItem(matches[currentMatch]) } }
                        }
                    }
                )
                LaunchedEffect(Unit) { runCatching { searchFocus.requestFocus() } }
            } else {
                TopAppBar(
                    title = {
                        if (tabs.size > 1) {
                            Column {
                                Text(
                                    "\uD83D\uDCD5 PDF \u00B7 ${tabs.size} tabs",
                                    fontSize = 12.sp,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                                    maxLines = 1, overflow = TextOverflow.Ellipsis
                                )
                                if (pageCount > 0) {
                                    Text("Page $currentPage of $pageCount",
                                        fontSize = 11.sp,
                                        color = MaterialTheme.colorScheme.onSurfaceVariant)
                                }
                            }
                        } else {
                            Column {
                                Text(title, maxLines = 1, overflow = TextOverflow.Ellipsis,
                                    fontSize = 15.sp, fontWeight = FontWeight.SemiBold)
                                if (pageCount > 0) {
                                    Text("Page $currentPage of $pageCount",
                                        fontSize = 11.sp,
                                        color = MaterialTheme.colorScheme.onSurfaceVariant)
                                }
                            }
                        }
                    }
                )
            }
        },
        bottomBar = {
            if (!searchOpen) {
                Surface(color = MaterialTheme.colorScheme.surfaceVariant, shadowElevation = 8.dp) {
                    Column(Modifier.fillMaxWidth()) {
                        // ── Row 1: PDF page navigation (only shown when a PDF has pages) ──
                        // The previous floating "BottomCenter" page bar was occluded by the
                        // new bottomBar — that's why the page number wasn't visible and the
                        // skip buttons weren't responding. Moving page nav INTO the bottom
                        // toolbar fixes both at once.
                        if (pageCount > 0) {
                            Row(
                                Modifier.fillMaxWidth().padding(horizontal = 4.dp, vertical = 2.dp),
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.Center
                            ) {
                                IconButton(onClick = {
                                    // currentPage is 1-indexed; list is 0-indexed.
                                    // Previous page → target index = currentPage - 2,
                                    // clamped to 0 so we don't underflow at page 1.
                                    val targetIdx = (currentPage - 2).coerceAtLeast(0)
                                    scope.launch {
                                        runCatching { listState.animateScrollToItem(targetIdx) }
                                    }
                                }) {
                                    Icon(Icons.AutoMirrored.Filled.KeyboardArrowLeft,
                                        contentDescription = "Previous page")
                                }
                                TextButton(
                                    onClick = { scale = (scale - 0.25f).coerceIn(0.5f, 4f) },
                                    contentPadding = PaddingValues(horizontal = 8.dp, vertical = 4.dp)
                                ) {
                                    Text("\u2212", fontSize = 18.sp, fontWeight = FontWeight.Bold)
                                }
                                // Page chip — also opens the jump-to-page dialog
                                Surface(
                                    color = MaterialTheme.colorScheme.primaryContainer,
                                    shape = RoundedCornerShape(14.dp),
                                    modifier = Modifier.clickable { showJumpDialog = true }
                                ) {
                                    Text(
                                        "\uD83D\uDCC4 $currentPage / $pageCount",
                                        Modifier.padding(horizontal = 14.dp, vertical = 6.dp),
                                        fontSize = 14.sp,
                                        fontWeight = FontWeight.SemiBold,
                                        color = MaterialTheme.colorScheme.onPrimaryContainer
                                    )
                                }
                                TextButton(
                                    onClick = { scale = (scale + 0.25f).coerceIn(0.5f, 4f) },
                                    contentPadding = PaddingValues(horizontal = 8.dp, vertical = 4.dp)
                                ) {
                                    Text("+", fontSize = 18.sp, fontWeight = FontWeight.Bold)
                                }
                                IconButton(onClick = {
                                    // Next page → target = currentPage (which is
                                    // already 1-indexed, so this gives us the
                                    // 0-indexed next page). Clamped to last page.
                                    val maxIdx = (pageCount - 1).coerceAtLeast(0)
                                    val targetIdx = currentPage.coerceAtMost(maxIdx)
                                    scope.launch {
                                        runCatching { listState.animateScrollToItem(targetIdx) }
                                    }
                                }) {
                                    Icon(Icons.AutoMirrored.Filled.KeyboardArrowRight,
                                        contentDescription = "Next page")
                                }
                            }
                            HorizontalDivider()
                        }
                        // ── Row 2: actions ──
                        Row(
                            Modifier.fillMaxWidth().padding(horizontal = 2.dp, vertical = 2.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            IconButton(onClick = { nav.popBackStack() }) {
                                Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back")
                            }
                            IconButton(onClick = { searchOpen = true }) {
                                Icon(Icons.Default.Search, contentDescription = "Search in PDF")
                            }
                            // v4.22.1 — Summarise this PDF via on-device chat.
                            // Aggregates extracted page text (if available)
                            // and feeds it into RagPromptBuilder.buildSummarize.
                            // v5.2.0 — Hidden when the chat model isn't installed.
                            val chatReady by vm.chatModelInstalled.collectAsStateWithLifecycle()
                            if (chatReady) {
                                IconButton(onClick = {
                                    vm.summarizeNote(noteId, "pdf")
                                    nav.navigate("chat") { launchSingleTop = true }
                                }) {
                                    Text("\u2728", fontSize = 18.sp)
                                }
                            }
                            if (tabs.size > 1) {
                                IconButton(onClick = {
                                    val list = tabs
                                    val idx = list.indexOfFirst { it.id == noteId }
                                    if (idx >= 0) {
                                        val prev = list[(idx - 1 + list.size) % list.size]
                                        vm.openArticle(prev.id, prev.title, fileType = prev.fileType)
                                        if (prev.fileType == "pdf") {
                                            nav.navigate("pdfReader/${prev.id}") {
                                                popUpTo("pdfReader/$noteId") { inclusive = true }
                                                launchSingleTop = true
                                            }
                                        } else {
                                            nav.navigate("reader") { launchSingleTop = true }
                                        }
                                    }
                                }) {
                                    Icon(Icons.AutoMirrored.Filled.KeyboardArrowLeft,
                                        contentDescription = "Previous tab")
                                }
                            IconButton(onClick = {
                                val list = tabs
                                val idx = list.indexOfFirst { it.id == noteId }
                                if (idx >= 0) {
                                    val next = list[(idx + 1) % list.size]
                                    vm.openArticle(next.id, next.title, fileType = next.fileType)
                                    if (next.fileType == "pdf") {
                                        nav.navigate("pdfReader/${next.id}") {
                                            popUpTo("pdfReader/$noteId") { inclusive = true }
                                            launchSingleTop = true
                                        }
                                    } else {
                                        nav.navigate("reader") { launchSingleTop = true }
                                    }
                                }
                            }) {
                                Icon(Icons.AutoMirrored.Filled.KeyboardArrowRight,
                                    contentDescription = "Next tab")
                            }
                        }
                        IconButton(onClick = { drawMode = !drawMode }) {
                            Icon(
                                Icons.Default.Edit,
                                contentDescription = if (drawMode) "Stop drawing" else "Annotate",
                                tint = if (drawMode) Color(0xFFFFEB3B) else MaterialTheme.colorScheme.onSurface
                            )
                        }
                        androidx.compose.foundation.layout.Spacer(Modifier.weight(1f))
                        // v4.2 — browser button on PDF reader bottom toolbar
                        IconButton(onClick = {
                            val encUrl = java.net.URLEncoder.encode("https://www.jw.org", "UTF-8")
                            val encLabel = java.net.URLEncoder.encode("jw.org", "UTF-8")
                            nav.navigate("web/$encUrl/$encLabel") { launchSingleTop = true }
                        }) {
                            Text("\uD83C\uDF10", fontSize = 18.sp)
                        }
                        HomeButton(nav)
                        Box {
                            IconButton(onClick = { menuOpen = true }) {
                                Icon(Icons.Default.MoreVert, contentDescription = "More")
                            }
                            DropdownMenu(expanded = menuOpen, onDismissRequest = { menuOpen = false }) {
                                val isFav = noteId in favouriteIds
                                DropdownMenuItem(
                                    text = { Text(if (isFav) "\uD83D\uDC94 Remove favourite" else "\u2B50 Add favourite") },
                                    onClick = { menuOpen = false; vm.toggleFavourite(noteId) }
                                )
                                HorizontalDivider()
                                DropdownMenuItem(
                                    text = { Text("\u23E9 Go to page\u2026") },
                                    onClick = { menuOpen = false; showJumpDialog = true }
                                )
                                DropdownMenuItem(
                                    text = { Text("\uD83D\uDD0D Search library") },
                                    onClick = { menuOpen = false; nav.navigate("search") }
                                )
                                DropdownMenuItem(
                                    text = { Text("\uD83D\uDCDC PDF history") },
                                    onClick = { menuOpen = false; nav.navigate("pdfHistory") }
                                )
                                DropdownMenuItem(
                                    text = { Text("\uD83D\uDD52 Web history") },
                                    onClick = { menuOpen = false; nav.navigate("webHistory") }
                                )
                                DropdownMenuItem(
                                    text = { Text("\uD83D\uDD16 Bookmarks") },
                                    onClick = { menuOpen = false; nav.navigate("webBookmarks") }
                                )
                                DropdownMenuItem(
                                    text = { Text("\u2699\uFE0F Settings") },
                                    onClick = { menuOpen = false; nav.navigate("settings") }
                                )
                                HorizontalDivider()
                                DropdownMenuItem(
                                    text = { Text("\uD83D\uDDA8\uFE0F Print PDF") },
                                    onClick = { menuOpen = false; printPdf(ctx, pdfUri, title) }
                                )
                                DropdownMenuItem(
                                    text = { Text("\uD83D\uDCE4 Share PDF") },
                                    onClick = { menuOpen = false; sharePdf(ctx, pdfUri, title) }
                                )
                                DropdownMenuItem(
                                    text = { Text("\uD83C\uDF10 Open externally") },
                                    onClick = { menuOpen = false; openPdfExternally(ctx, pdfUri) }
                                )
                                HorizontalDivider()
                                if (annotations.values.any { it.isNotEmpty() }) {
                                    DropdownMenuItem(
                                        text = { Text("\uD83D\uDDD1\uFE0F Clear all annotations") },
                                        onClick = {
                                            menuOpen = false
                                            annotations.clear()
                                            scope.launch { vm.clearAllAnnotations(noteId) }
                                        }
                                    )
                                }
                                DropdownMenuItem(
                                    text = { Text("\uD83D\uDD04 Reset zoom") },
                                    onClick = { menuOpen = false; scale = 1f; offsetX = 0f; offsetY = 0f }
                                )
                            }
                        }
                    }
                    }  // close Column wrapper (page nav + actions rows)
                }
            }
        }
    ) { pad ->
        Box(Modifier.padding(pad).fillMaxSize().background(Color(0xFF0A0A0A))) {
            when {
                loading -> CenteredStatus("\u23F3 Opening PDF\u2026")
                error != null -> CenteredStatus("\u26A0\uFE0F $error")
                pool != null -> {
                    PageScrollContainer(
                        pool = pool!!,
                        listState = listState,
                        placeholderHeight = placeholderH,
                        scale = scale, onScale = { scale = it },
                        offsetX = offsetX, onOffsetX = { offsetX = it },
                        offsetY = offsetY, onOffsetY = { offsetY = it },
                        matchPages = matches.toSet(),
                        annotations = annotations,
                        drawMode = drawMode,
                        onAnnotationChanged = { page ->
                            scope.launch {
                                val json = serializePathsJson(annotations[page] ?: emptyList())
                                vm.saveAnnotation(noteId, page, json)
                            }
                        },
                        onLongPress = { page -> textPanelPage = page }
                    )
                    if (drawMode) {
                        Surface(
                            modifier = Modifier.align(Alignment.TopCenter).padding(top = 8.dp),
                            color = Color(0xCCFFC107), shape = RoundedCornerShape(14.dp)
                        ) {
                            Text(
                                "\uD83D\uDD8D\uFE0F Drawing mode — drag to annotate",
                                Modifier.padding(horizontal = 14.dp, vertical = 6.dp),
                                fontSize = 12.sp, color = Color(0xFF1A1A1A),
                                fontWeight = FontWeight.Medium
                            )
                        }
                    }
                }
            }
        }
    }

    // ── Password dialog ──
    if (showPasswordDialog) {
        PasswordDialog(
            wrongPassword = passwordError,
            onCancel = { showPasswordDialog = false; nav.popBackStack() },
            onSubmit = { pw -> openPdf(pw) }
        )
    }

    // ── Jump to page dialog ──
    if (showJumpDialog && pageCount > 0) {
        JumpToPageDialog(
            current = currentPage, total = pageCount,
            onDismiss = { showJumpDialog = false },
            onJump = { target ->
                showJumpDialog = false
                scope.launch {
                    runCatching {
                        listState.animateScrollToItem((target - 1).coerceIn(0, pageCount - 1))
                    }
                }
            }
        )
    }

    // ── Text panel bottom sheet (text "selection" via long-press) ──
    val tp = textPanelPage
    if (tp != null) {
        TextPanelSheet(
            pageIndex = tp,
            pageTexts = pageTexts,
            onExtractAll = {
                // If text not yet extracted, kick off extraction
                if (pageTexts.isEmpty() && !extracting) {
                    searchOpen = true   // triggers extraction LaunchedEffect
                }
            },
            onCopy = { txt ->
                val cb = ctx.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                cb.setPrimaryClip(ClipData.newPlainText("PDF text", txt))
                Toast.makeText(ctx, "Copied to clipboard \uD83D\uDCCB", Toast.LENGTH_SHORT).show()
            },
            onDismiss = { textPanelPage = null }
        )
    }
    } // v5.4.23 — end padded center Box
    // v5.4.23 — PDF workspace left panel (tabs list). No right panel
    // because we don't have a PDF outline extractor wired in yet.
    // v5.4.24 — Collapsibility + status bar padding.
    if (threeColumn && leftPanelOpen) {
        androidx.compose.foundation.layout.Column(
            Modifier
                .align(androidx.compose.ui.Alignment.TopStart)
                .width(leftColWidth)
                .fillMaxHeight()
                .background(MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.35f))
                .statusBarsPadding()
                .padding(12.dp)
        ) {
            val tabs by vm.tabs.collectAsStateWithLifecycle()
            val activeTab by vm.activeTab.collectAsStateWithLifecycle()
            androidx.compose.foundation.layout.Row(
                verticalAlignment = androidx.compose.ui.Alignment.CenterVertically
            ) {
                Text(
                    "\uD83E\uDDF0 Workspace",
                    fontSize = 15.sp,
                    fontWeight = androidx.compose.ui.text.font.FontWeight.Bold,
                    modifier = Modifier.weight(1f)
                )
                IconButton(
                    onClick = { leftPanelOpen = false },
                    modifier = Modifier.size(28.dp)
                ) {
                    androidx.compose.material3.Text("◀", fontSize = 14.sp)
                }
            }
            androidx.compose.foundation.layout.Spacer(Modifier.height(2.dp))
            Text(
                "Open tabs",
                fontSize = 11.sp,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
            androidx.compose.foundation.layout.Spacer(Modifier.height(10.dp))
            LazyColumn(
                Modifier.weight(1f).fillMaxWidth()
            ) {
                items(
                    tabs, key = { it.id }
                ) { tab ->
                    val selected = tab.id == activeTab
                    androidx.compose.material3.Surface(
                        color = if (selected)
                            MaterialTheme.colorScheme.primary.copy(alpha = 0.18f)
                        else androidx.compose.ui.graphics.Color.Transparent,
                        shape = androidx.compose.foundation.shape.RoundedCornerShape(8.dp),
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(vertical = 2.dp)
                            .clickable { vm.setActiveTab(tab.id) }
                    ) {
                        androidx.compose.foundation.layout.Row(
                            Modifier.padding(horizontal = 10.dp, vertical = 8.dp),
                            verticalAlignment = androidx.compose.ui.Alignment.CenterVertically
                        ) {
                            Text(
                                when (tab.fileType) {
                                    "pdf" -> "\uD83D\uDCC4"
                                    "html", "htm" -> "\uD83C\uDF10"
                                    else -> "\uD83D\uDCDD"
                                },
                                fontSize = 14.sp
                            )
                            androidx.compose.foundation.layout.Spacer(Modifier.width(8.dp))
                            Text(
                                tab.title,
                                modifier = Modifier.weight(1f),
                                fontSize = 12.sp,
                                maxLines = 1,
                                overflow = androidx.compose.ui.text.style.TextOverflow.Ellipsis,
                                fontWeight = if (selected)
                                    androidx.compose.ui.text.font.FontWeight.SemiBold
                                else androidx.compose.ui.text.font.FontWeight.Normal
                            )
                            IconButton(
                                onClick = { vm.closeTab(tab.id) },
                                modifier = Modifier.size(22.dp)
                            ) {
                                androidx.compose.material3.Icon(
                                    androidx.compose.material.icons.Icons.Default.Close,
                                    contentDescription = "Close tab",
                                    modifier = Modifier.size(12.dp),
                                    tint = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }
                        }
                    }
                }
            }
            androidx.compose.material3.HorizontalDivider(Modifier.padding(vertical = 6.dp))
            androidx.compose.foundation.layout.Row(
                Modifier
                    .fillMaxWidth()
                    .clickable { nav.navigate("home") }
                    .padding(vertical = 10.dp, horizontal = 8.dp),
                verticalAlignment = androidx.compose.ui.Alignment.CenterVertically
            ) {
                androidx.compose.material3.Icon(
                    androidx.compose.material.icons.Icons.Default.Add,
                    contentDescription = null,
                    modifier = Modifier.size(16.dp)
                )
                androidx.compose.foundation.layout.Spacer(Modifier.width(8.dp))
                Text("Open a new tab", fontSize = 13.sp)
            }
        }
    }
    // v5.4.24 — Corner reopen button. Appears when the left panel is
    // collapsed. statusBarsPadding puts it safely below the notification
    // bar.
    if (threeColumn && !leftPanelOpen) {
        IconButton(
            onClick = { leftPanelOpen = true },
            modifier = Modifier
                .align(androidx.compose.ui.Alignment.TopStart)
                .statusBarsPadding()
                .padding(4.dp)
                .size(40.dp)
        ) {
            androidx.compose.material3.Icon(
                androidx.compose.material.icons.Icons.Default.Menu,
                contentDescription = "Show left panel",
                tint = MaterialTheme.colorScheme.onSurface
            )
        }
    }
    // v5.4.34 — Compact FABs for PDF reader. Keyword FAB opens the
    // existing PDF search bar with the query pre-filled.
    // v5.4.39 — Add "Talk to Article" FAB for semantic search within PDF.
    val showKwFab = pdfOpenedFromSearch && fabEnabled &&
        currentSearchQuery.trim().removeSurrounding("\"").length >= 2
    val showTalkToArticleFab = pageTexts.isNotEmpty()  // Show when PDF pages are extracted

    if (showKwFab || showTalkToArticleFab) {
        Column(
            Modifier
                .align(Alignment.BottomEnd)
                .padding(16.dp),
            horizontalAlignment = Alignment.End,
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            // v5.4.39 — "Talk to Article" FAB for semantic search
            if (showTalkToArticleFab) {
                androidx.compose.material3.SmallFloatingActionButton(
                    onClick = {
                        showArticleSemanticDialog = true
                    },
                    containerColor = MaterialTheme.colorScheme.primaryContainer
                ) {
                    Text("💭", fontSize = 16.sp)
                }
            }
            // Keyword search FAB
            if (showKwFab) {
                androidx.compose.material3.SmallFloatingActionButton(
                    onClick = {
                        val rawQ = currentSearchQuery.trim()
                            .removeSurrounding("\"").trim()
                        if (rawQ.length >= 2) {
                            searchQuery = rawQ
                            searchOpen = true
                        }
                    }
                ) {
                    Text("\uD83D\uDD0D", fontSize = 16.sp)
                }
            }
        }
    }
    } // v5.4.23 — end outer Box

    // v5.4.39 — "Talk to the Article" semantic search dialog for PDF
    if (showArticleSemanticDialog && pageTexts.isNotEmpty()) {
        // Combine all page texts for semantic search
        val fullPdfText = pageTexts.values.joinToString("\n\n")
        ArticleSemanticSearchDialog(
            articleText = fullPdfText,
            articleTitle = title,
            onDismiss = { showArticleSemanticDialog = false },
            onHighlightSnippet = { snippet, _ ->
                // For PDF, open search bar and search for the snippet
                searchQuery = snippet
                searchOpen = true
            },
            onPerformSemanticSearch = { text, query ->
                // Call the ViewModel's semantic search function
                vm.semanticSearchArticle(text, query)
            }
        )
    }
}

/* ════════════════════════════════════════════════════════════════════════
 *  PdfViewerStandalone — external PDF activity (no DB, no nav)
 * ════════════════════════════════════════════════════════════════════════ */

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun PdfViewerStandalone(uri: Uri?, titleHint: String, onClose: () -> Unit) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()

    var title by remember { mutableStateOf(titleHint) }
    var pool by remember { mutableStateOf<PdfRendererPool?>(null) }
    var pageAspect by remember { mutableFloatStateOf(1.414f) }
    var loading by remember { mutableStateOf(true) }
    var error by remember { mutableStateOf<String?>(null) }
    var menuOpen by remember { mutableStateOf(false) }
    var showPasswordDialog by remember { mutableStateOf(false) }
    var passwordError by remember { mutableStateOf(false) }
    var showJumpDialog by remember { mutableStateOf(false) }

    var searchOpen by remember { mutableStateOf(false) }
    var searchQuery by remember { mutableStateOf("") }
    var pageTexts by remember { mutableStateOf<Map<Int, String>>(emptyMap()) }
    var extractProgress by remember { mutableFloatStateOf(0f) }
    var extracting by remember { mutableStateOf(false) }
    var matches by remember { mutableStateOf<List<Int>>(emptyList()) }
    var currentMatch by remember { mutableIntStateOf(0) }
    var textPanelPage by remember { mutableStateOf<Int?>(null) }

    var scale by remember { mutableFloatStateOf(1f) }
    var offsetX by remember { mutableFloatStateOf(0f) }
    var offsetY by remember { mutableFloatStateOf(0f) }
    val listState = rememberLazyListState()
    val searchFocus = remember { FocusRequester() }
    val annotations = remember { mutableStateMapOf<Int, SnapshotStateList<List<Offset>>>() }

    // v4.7 — read `pool` INSIDE derivedStateOf so the page count updates after
    // the PDF finishes loading. The previous version captured pageCount=0 from
    // the outer scope at first composition, which permanently coerced the
    // current-page calculation into [1, 1] → the counter always read 1 and the
    // prev/next arrow buttons computed scroll targets relative to that
    // permanently-wrong value, which made them appear to do nothing.
    val pageCount = pool?.pageCount ?: 0
    val currentPage by remember {
        derivedStateOf {
            val pc = pool?.pageCount ?: 0
            (listState.firstVisibleItemIndex + 1).coerceIn(1, pc.coerceAtLeast(1))
        }
    }

    fun openPdf(password: String?) {
        scope.launch {
            loading = true; error = null; passwordError = false
            if (uri == null) { error = "No file was provided."; loading = false; return@launch }
            when (val res = PdfRendererPool.open(ctx, uri, poolSize = 3, password = password)) {
                is PdfRendererPool.OpenResult.Success -> {
                    pool = res.pool; pageAspect = res.pool.firstPageAspect()
                    showPasswordDialog = false; loading = false
                }
                is PdfRendererPool.OpenResult.NeedsPassword -> { showPasswordDialog = true; loading = false }
                is PdfRendererPool.OpenResult.WrongPassword -> {
                    passwordError = true; showPasswordDialog = true; loading = false
                }
                is PdfRendererPool.OpenResult.Failure -> { error = res.message; loading = false }
            }
        }
    }

    LaunchedEffect(uri) { openPdf(null) }

    DisposableEffect(Unit) { onDispose { pool?.close() } }

    BackHandler {
        if (searchOpen) { searchOpen = false; searchQuery = ""; matches = emptyList() }
        else onClose()
    }

    LaunchedEffect(searchOpen) {
        if (!searchOpen || pageTexts.isNotEmpty() || uri == null) return@LaunchedEffect
        val total = pool?.pageCount ?: return@LaunchedEffect
        if (total == 0) return@LaunchedEffect
        extracting = true; extractProgress = 0.05f
        val texts = withContext(Dispatchers.IO) {
            extractPdfTextFast(ctx, uri) { done, all ->
                extractProgress = if (all > 0) done.toFloat() / all else 0f
            }
        }
        pageTexts = texts; extracting = false
    }

    LaunchedEffect(searchQuery, pageTexts) {
        val q = searchQuery.trim()
        if (q.length < 2 || pageTexts.isEmpty()) {
            matches = emptyList(); currentMatch = 0; return@LaunchedEffect
        }
        val lc = q.lowercase()
        val hits = pageTexts.entries.asSequence()
            .filter { it.value.lowercase().contains(lc) }
            .map { it.key }.sorted().toList()
        matches = hits; currentMatch = 0
        if (hits.isNotEmpty()) scope.launch { runCatching { listState.animateScrollToItem(hits[0]) } }
    }

    val density = ctx.resources.displayMetrics.density
    val placeholderH = remember(pageAspect) {
        (ctx.resources.displayMetrics.widthPixels * pageAspect / density).dp
    }

    Scaffold(
        topBar = {
            if (searchOpen) {
                PdfSearchBar(
                    query = searchQuery, onQueryChange = { searchQuery = it },
                    extracting = extracting, extractProgress = extractProgress,
                    matchCount = matches.size, currentMatch = currentMatch,
                    focusRequester = searchFocus,
                    onClose = { searchOpen = false; searchQuery = ""; matches = emptyList() },
                    onPrev = {
                        if (matches.isNotEmpty()) {
                            currentMatch = (currentMatch - 1 + matches.size) % matches.size
                            scope.launch { runCatching { listState.animateScrollToItem(matches[currentMatch]) } }
                        }
                    },
                    onNext = {
                        if (matches.isNotEmpty()) {
                            currentMatch = (currentMatch + 1) % matches.size
                            scope.launch { runCatching { listState.animateScrollToItem(matches[currentMatch]) } }
                        }
                    }
                )
                LaunchedEffect(Unit) { runCatching { searchFocus.requestFocus() } }
            } else {
                TopAppBar(
                    title = {
                        Column {
                            Text(title, maxLines = 1, overflow = TextOverflow.Ellipsis,
                                fontSize = 15.sp, fontWeight = FontWeight.SemiBold)
                            if (pageCount > 0) {
                                Text("Page $currentPage of $pageCount",
                                    fontSize = 11.sp,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant)
                            }
                        }
                    }
                )
            }
        },
        bottomBar = {
            if (!searchOpen) {
                Surface(color = MaterialTheme.colorScheme.surfaceVariant, shadowElevation = 8.dp) {
                    Column(Modifier.fillMaxWidth()) {
                        // Row 1: page navigation
                        if (pageCount > 0) {
                            Row(
                                Modifier.fillMaxWidth().padding(horizontal = 4.dp, vertical = 2.dp),
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.Center
                            ) {
                                IconButton(onClick = {
                                    // currentPage is 1-indexed; list is 0-indexed.
                                    // Previous page → target index = currentPage - 2,
                                    // clamped to 0 so we don't underflow at page 1.
                                    val targetIdx = (currentPage - 2).coerceAtLeast(0)
                                    scope.launch {
                                        runCatching { listState.animateScrollToItem(targetIdx) }
                                    }
                                }) {
                                    Icon(Icons.AutoMirrored.Filled.KeyboardArrowLeft,
                                        contentDescription = "Previous page")
                                }
                                Surface(
                                    color = MaterialTheme.colorScheme.primaryContainer,
                                    shape = RoundedCornerShape(14.dp),
                                    modifier = Modifier.clickable { showJumpDialog = true }
                                ) {
                                    Text(
                                        "\uD83D\uDCC4 $currentPage / $pageCount",
                                        Modifier.padding(horizontal = 14.dp, vertical = 6.dp),
                                        fontSize = 14.sp,
                                        fontWeight = FontWeight.SemiBold,
                                        color = MaterialTheme.colorScheme.onPrimaryContainer
                                    )
                                }
                                IconButton(onClick = {
                                    // Next page → target = currentPage (which is
                                    // already 1-indexed, so this gives us the
                                    // 0-indexed next page). Clamped to last page.
                                    val maxIdx = (pageCount - 1).coerceAtLeast(0)
                                    val targetIdx = currentPage.coerceAtMost(maxIdx)
                                    scope.launch {
                                        runCatching { listState.animateScrollToItem(targetIdx) }
                                    }
                                }) {
                                    Icon(Icons.AutoMirrored.Filled.KeyboardArrowRight,
                                        contentDescription = "Next page")
                                }
                            }
                            HorizontalDivider()
                        }
                        Row(
                            Modifier.fillMaxWidth().padding(horizontal = 2.dp, vertical = 2.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            IconButton(onClick = onClose) {
                                Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Close")
                            }
                            IconButton(onClick = { searchOpen = true }) {
                                Icon(Icons.Default.Search, contentDescription = "Search in PDF")
                            }
                            TextButton(onClick = { scale = (scale - 0.25f).coerceIn(0.5f, 4f) }) {
                                Text("\u2212", fontSize = 18.sp)
                            }
                            Text("${(scale * 100).roundToInt()}%", fontSize = 12.sp,
                                color = MaterialTheme.colorScheme.onSurfaceVariant)
                            TextButton(onClick = { scale = (scale + 0.25f).coerceIn(0.5f, 4f) }) {
                                Text("+", fontSize = 18.sp)
                            }
                            androidx.compose.foundation.layout.Spacer(Modifier.weight(1f))
                            Box {
                                IconButton(onClick = { menuOpen = true }) {
                                    Icon(Icons.Default.MoreVert, contentDescription = "More")
                                }
                                DropdownMenu(expanded = menuOpen, onDismissRequest = { menuOpen = false }) {
                                    DropdownMenuItem(
                                        text = { Text("\u23E9 Go to page\u2026") },
                                        onClick = { menuOpen = false; showJumpDialog = true }
                                    )
                                    HorizontalDivider()
                                    DropdownMenuItem(
                                        text = { Text("\uD83D\uDDA8\uFE0F Print PDF") },
                                        onClick = { menuOpen = false; printPdf(ctx, uri?.toString(), title) }
                                    )
                                    DropdownMenuItem(
                                        text = { Text("\uD83D\uDCE4 Share PDF") },
                                        onClick = { menuOpen = false; sharePdf(ctx, uri?.toString(), title) }
                                    )
                                    DropdownMenuItem(
                                        text = { Text("\uD83C\uDF10 Open externally") },
                                        onClick = { menuOpen = false; openPdfExternally(ctx, uri?.toString()) }
                                    )
                                    HorizontalDivider()
                                    DropdownMenuItem(
                                        text = { Text("\uD83D\uDD04 Reset zoom") },
                                        onClick = { menuOpen = false; scale = 1f; offsetX = 0f; offsetY = 0f }
                                    )
                                }
                            }
                        }
                    }
                }
            }
        }
    ) { pad ->
        Box(Modifier.padding(pad).fillMaxSize().background(Color(0xFF0A0A0A))) {
            when {
                loading -> CenteredStatus("\u23F3 Opening PDF\u2026")
                error != null -> CenteredStatus("\u26A0\uFE0F $error")
                pool != null -> {
                    PageScrollContainer(
                        pool = pool!!, listState = listState, placeholderHeight = placeholderH,
                        scale = scale, onScale = { scale = it },
                        offsetX = offsetX, onOffsetX = { offsetX = it },
                        offsetY = offsetY, onOffsetY = { offsetY = it },
                        matchPages = matches.toSet(),
                        annotations = annotations, drawMode = false,
                        onAnnotationChanged = { },
                        onLongPress = { p -> textPanelPage = p }
                    )
                }
            }
        }
    }

    if (showPasswordDialog) {
        PasswordDialog(
            wrongPassword = passwordError,
            onCancel = { showPasswordDialog = false; onClose() },
            onSubmit = { pw -> openPdf(pw) }
        )
    }

    if (showJumpDialog && pageCount > 0) {
        JumpToPageDialog(
            current = currentPage, total = pageCount,
            onDismiss = { showJumpDialog = false },
            onJump = { target ->
                showJumpDialog = false
                scope.launch {
                    runCatching { listState.animateScrollToItem((target - 1).coerceIn(0, pageCount - 1)) }
                }
            }
        )
    }

    val tp = textPanelPage
    if (tp != null) {
        TextPanelSheet(
            pageIndex = tp, pageTexts = pageTexts,
            onExtractAll = { if (pageTexts.isEmpty() && !extracting) searchOpen = true },
            onCopy = { txt ->
                val cb = ctx.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                cb.setPrimaryClip(ClipData.newPlainText("PDF text", txt))
                Toast.makeText(ctx, "Copied to clipboard \uD83D\uDCCB", Toast.LENGTH_SHORT).show()
            },
            onDismiss = { textPanelPage = null }
        )
    }
}

/* ════════════════════════════════════════════════════════════════════════
 *  Reusable building blocks
 * ════════════════════════════════════════════════════════════════════════ */

@Composable
private fun PageScrollContainer(
    pool: PdfRendererPool,
    listState: LazyListState,
    placeholderHeight: Dp,
    scale: Float, onScale: (Float) -> Unit,
    offsetX: Float, onOffsetX: (Float) -> Unit,
    offsetY: Float, onOffsetY: (Float) -> Unit,
    matchPages: Set<Int>,
    annotations: SnapshotStateMap<Int, SnapshotStateList<List<Offset>>>,
    drawMode: Boolean,
    onAnnotationChanged: (Int) -> Unit,
    onLongPress: (Int) -> Unit
) {
    val ctx = LocalContext.current
    val screenWidth = ctx.resources.displayMetrics.widthPixels
    // Stale-closure fix: capture latest values so the gesture lambda below
    // doesn't see scale/offset from the FIRST composition forever.
    val currentScale by rememberUpdatedState(scale)
    val currentOffsetX by rememberUpdatedState(offsetX)
    val currentOffsetY by rememberUpdatedState(offsetY)
    val currentDrawMode by rememberUpdatedState(drawMode)

    Box(
        Modifier.fillMaxSize()
            // Stale-closure fix: the previous implementation keyed pointerInput on
            // `drawMode` only, so the gesture lambda captured `scale` at first
            // composition. Tapping the zoom buttons updated the state but the
            // lambda still saw scale=1f — leading to scale being reset to 1f on
            // the next swipe ("after zooming swipe zooms out immediately").
            //
            // The fix uses rememberUpdatedState so the lambda always reads the
            // latest values, plus a custom 2-finger-only detector that lets
            // single-finger drags fall through to the LazyColumn's native scroll.
            .pointerInput(Unit) {
                awaitEachGesture {
                    awaitFirstDown(requireUnconsumed = false)
                    do {
                        val event = awaitPointerEvent()
                        if (currentDrawMode) {
                            // Drawing handler claims single-finger gestures; we
                            // simply skip them here so they reach PdfPageItem.
                        } else {
                            val activePointers = event.changes.count { it.pressed }
                            if (activePointers >= 2) {
                                // PINCH: zoom + optional pan
                                val zoomChange = event.calculateZoom()
                                val pan = event.calculatePan()
                                if (zoomChange != 1f) {
                                    val ns = (currentScale * zoomChange).coerceIn(0.5f, 4f)
                                    onScale(ns)
                                    if (ns > 1f) {
                                        onOffsetX(currentOffsetX + pan.x)
                                        onOffsetY(currentOffsetY + pan.y)
                                    } else {
                                        onOffsetX(0f); onOffsetY(0f)
                                    }
                                    event.changes.forEach { it.consume() }
                                } else if (pan != Offset.Zero && currentScale > 1f) {
                                    // Two-finger pan while zoomed
                                    onOffsetX(currentOffsetX + pan.x)
                                    onOffsetY(currentOffsetY + pan.y)
                                    event.changes.forEach { it.consume() }
                                }
                            } else if (activePointers == 1 && currentScale > 1f) {
                                // ONE FINGER WHILE ZOOMED: pan the zoomed view.
                                // (At 1x, we DON'T consume so LazyColumn scrolls.)
                                val pan = event.calculatePan()
                                if (pan != Offset.Zero) {
                                    onOffsetX(currentOffsetX + pan.x)
                                    onOffsetY(currentOffsetY + pan.y)
                                    event.changes.forEach { it.consume() }
                                }
                            }
                            // else: single finger at 1x → don't consume → LazyColumn scrolls
                        }
                    } while (event.changes.any { it.pressed })
                }
            }
            .pointerInput(Unit) {
                detectTapGestures(onDoubleTap = {
                    if (currentDrawMode) return@detectTapGestures
                    if (currentScale > 1.1f) {
                        onScale(1f); onOffsetX(0f); onOffsetY(0f)
                    } else onScale(2f)
                })
            }
    ) {
        LazyColumn(
            state = listState,
            modifier = Modifier.fillMaxSize().graphicsLayer(
                scaleX = scale, scaleY = scale,
                translationX = offsetX, translationY = offsetY
            ),
            verticalArrangement = Arrangement.spacedBy(4.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            items(pool.pageCount) { index ->
                val ann = annotations.getOrCreate(index)
                PdfPageItem(
                    pool = pool,
                    pageIndex = index,
                    targetWidth = screenWidth,
                    placeholderHeight = placeholderHeight,
                    highlight = index in matchPages,
                    annotation = ann,
                    drawMode = drawMode,
                    onAnnotationChanged = { onAnnotationChanged(index) },
                    onLongPress = onLongPress
                )
            }
            item { Spacer(Modifier.height(80.dp)) }
        }
    }
}

private fun <T> SnapshotStateMap<Int, SnapshotStateList<T>>.getOrCreate(key: Int): SnapshotStateList<T> {
    return this.getOrPut(key) { mutableStateListOf() }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun PdfSearchBar(
    query: String, onQueryChange: (String) -> Unit,
    extracting: Boolean, extractProgress: Float,
    matchCount: Int, currentMatch: Int,
    focusRequester: FocusRequester,
    onClose: () -> Unit, onPrev: () -> Unit, onNext: () -> Unit
) {
    Column {
        TopAppBar(
            title = {
                TextField(
                    value = query, onValueChange = onQueryChange,
                    placeholder = { Text("Search in PDF\u2026", fontSize = 14.sp) },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth().focusRequester(focusRequester),
                    keyboardOptions = KeyboardOptions(imeAction = ImeAction.Search),
                    colors = TextFieldDefaults.colors(
                        focusedContainerColor = Color.Transparent,
                        unfocusedContainerColor = Color.Transparent
                    )
                )
            },
            navigationIcon = {
                IconButton(onClick = onClose) {
                    Icon(Icons.Default.Close, contentDescription = "Close search")
                }
            },
            actions = {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    if (extracting) {
                        Text("${(extractProgress * 100).toInt()}%",
                            fontSize = 11.sp,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                            modifier = Modifier.padding(end = 6.dp))
                    } else if (query.trim().length >= 2) {
                        Text(
                            if (matchCount > 0) "${currentMatch + 1}/$matchCount" else "0/0",
                            fontSize = 12.sp,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                            modifier = Modifier.padding(end = 4.dp))
                        IconButton(onClick = onPrev) {
                            Icon(Icons.Default.KeyboardArrowUp, contentDescription = "Previous match")
                        }
                        IconButton(onClick = onNext) {
                            Icon(Icons.Default.KeyboardArrowDown, contentDescription = "Next match")
                        }
                    }
                    Spacer(Modifier.width(4.dp))
                }
            }
        )
        if (extracting) {
            LinearProgressIndicator(progress = { extractProgress }, modifier = Modifier.fillMaxWidth())
        }
    }
}

@Composable
private fun CenteredStatus(msg: String) {
    Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
        Text(msg, color = MaterialTheme.colorScheme.onSurfaceVariant,
            fontSize = 14.sp, lineHeight = 20.sp)
    }
}

@Composable
private fun PasswordDialog(
    wrongPassword: Boolean,
    onCancel: () -> Unit,
    onSubmit: (String) -> Unit
) {
    var password by remember { mutableStateOf("") }
    AlertDialog(
        onDismissRequest = onCancel,
        title = { Text("\uD83D\uDD12 Password required") },
        text = {
            Column {
                Text(
                    if (wrongPassword) "Incorrect password. Try again:"
                    else "This PDF is password protected.",
                    fontSize = 14.sp
                )
                Spacer(Modifier.height(12.dp))
                OutlinedTextField(
                    value = password, onValueChange = { password = it },
                    label = { Text("Password") },
                    singleLine = true,
                    visualTransformation = PasswordVisualTransformation(),
                    keyboardOptions = KeyboardOptions(
                        keyboardType = KeyboardType.Password, imeAction = ImeAction.Done
                    ),
                    modifier = Modifier.fillMaxWidth()
                )
            }
        },
        confirmButton = {
            Button(onClick = { onSubmit(password) }, enabled = password.isNotEmpty()) {
                Text("Open")
            }
        },
        dismissButton = { TextButton(onClick = onCancel) { Text("Cancel") } }
    )
}

@Composable
private fun JumpToPageDialog(
    current: Int, total: Int,
    onDismiss: () -> Unit, onJump: (Int) -> Unit
) {
    var input by remember { mutableStateOf(current.toString()) }
    var err by remember { mutableStateOf<String?>(null) }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("\u23E9 Go to page") },
        text = {
            Column {
                Text("Total pages: $total", fontSize = 12.sp,
                    color = MaterialTheme.colorScheme.onSurfaceVariant)
                Spacer(Modifier.height(8.dp))
                OutlinedTextField(
                    value = input, onValueChange = { input = it.filter { c -> c.isDigit() }; err = null },
                    label = { Text("Page number") },
                    singleLine = true, isError = err != null,
                    keyboardOptions = KeyboardOptions(
                        keyboardType = KeyboardType.Number, imeAction = ImeAction.Go
                    ),
                    modifier = Modifier.fillMaxWidth()
                )
                err?.let {
                    Spacer(Modifier.height(4.dp))
                    Text(it, color = MaterialTheme.colorScheme.error, fontSize = 12.sp)
                }
            }
        },
        confirmButton = {
            Button(onClick = {
                val n = input.toIntOrNull()
                if (n == null || n < 1 || n > total) err = "Enter 1 to $total"
                else onJump(n)
            }) { Text("Go") }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Cancel") } }
    )
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun TextPanelSheet(
    pageIndex: Int,
    pageTexts: Map<Int, String>,
    onExtractAll: () -> Unit,
    onCopy: (String) -> Unit,
    onDismiss: () -> Unit
) {
    val sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true)
    val text = pageTexts[pageIndex]
    ModalBottomSheet(
        onDismissRequest = onDismiss, sheetState = sheetState,
        containerColor = MaterialTheme.colorScheme.surface
    ) {
        Column(
            Modifier.fillMaxWidth()
                .heightIn(min = 200.dp, max = 600.dp)
                .padding(16.dp)
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(
                    "\uD83D\uDCC4 Page ${pageIndex + 1} text",
                    fontSize = 15.sp, fontWeight = FontWeight.SemiBold,
                    modifier = Modifier.weight(1f)
                )
                if (!text.isNullOrBlank()) {
                    TextButton(onClick = { onCopy(text) }) {
                        Text("\uD83D\uDCCB Copy all", fontSize = 13.sp)
                    }
                }
            }
            Spacer(Modifier.height(8.dp))
            if (text == null) {
                Text(
                    "Text isn't extracted yet. Tap below to extract — then you can long-press any page to copy text.",
                    fontSize = 13.sp, color = MaterialTheme.colorScheme.onSurfaceVariant
                )
                Spacer(Modifier.height(12.dp))
                Button(onClick = onExtractAll) { Text("Extract page text") }
            } else if (text.isBlank()) {
                Text(
                    "This page has no extractable text (it may be a scanned image).",
                    fontSize = 13.sp, color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            } else {
                SelectionContainer {
                    Box(Modifier.fillMaxWidth().verticalScroll(rememberScrollState())) {
                        Text(text, fontSize = 14.sp, lineHeight = 21.sp)
                    }
                }
            }
        }
    }
}

@Composable
private fun SelectionContainer(content: @Composable () -> Unit) {
    androidx.compose.foundation.text.selection.SelectionContainer { content() }
}

/* ════════════════════════════════════════════════════════════════════════
 *  Text extraction — single-pass fast path
 * ════════════════════════════════════════════════════════════════════════ */

/**
 * Extracts ALL pages of a PDF in ONE pass. PdfBox inserts a form-feed (\u000C)
 * between pages by default, so a single getText() call followed by splitting on
 * \u000C is dramatically faster than calling getText() once per page (which is
 * what the old code did — and what made 2000-page PDFs take forever).
 */
private suspend fun extractPdfTextFast(
    ctx: Context, uri: Uri,
    onProgress: (done: Int, total: Int) -> Unit
): Map<Int, String> = withContext(Dispatchers.IO) {
    val result = mutableMapOf<Int, String>()
    try {
        ctx.contentResolver.openInputStream(uri)?.use { input ->
            PDDocument.load(input).use { doc ->
                val total = doc.numberOfPages
                onProgress(0, total)
                val stripper = PDFTextStripper()
                stripper.startPage = 1
                stripper.endPage = total
                stripper.lineSeparator = "\n"
                // Single getText call — orders of magnitude faster than per-page
                val all = stripper.getText(doc) ?: ""
                val pages = all.split('\u000C')
                for (i in 0 until total) {
                    result[i] = if (i < pages.size) pages[i] else ""
                    if ((i + 1) % 25 == 0 || i + 1 == total) onProgress(i + 1, total)
                }
            }
        }
    } catch (e: Exception) {
        Log.e(TAG, "extractPdfTextFast failed", e)
    }
    result
}

/* ════════════════════════════════════════════════════════════════════════
 *  Annotation serialization
 * ════════════════════════════════════════════════════════════════════════ */

private fun serializePathsJson(paths: List<List<Offset>>): String {
    val root = JSONArray()
    for (stroke in paths) {
        val s = JSONArray()
        for (p in stroke) {
            val pt = org.json.JSONObject()
            pt.put("x", p.x); pt.put("y", p.y)
            s.put(pt)
        }
        root.put(s)
    }
    return root.toString()
}

private fun parsePathsJson(json: String): List<List<Offset>> {
    return try {
        val out = mutableListOf<List<Offset>>()
        val root = JSONArray(json)
        for (i in 0 until root.length()) {
            val strokeArr = root.getJSONArray(i)
            val stroke = mutableListOf<Offset>()
            for (j in 0 until strokeArr.length()) {
                val pt = strokeArr.getJSONObject(j)
                stroke.add(Offset(pt.getDouble("x").toFloat(), pt.getDouble("y").toFloat()))
            }
            if (stroke.size > 1) out.add(stroke)
        }
        out
    } catch (_: Exception) { emptyList() }
}

/* ════════════════════════════════════════════════════════════════════════
 *  Share / open / print helpers
 * ════════════════════════════════════════════════════════════════════════ */

private fun sharePdf(ctx: Context, uriString: String?, title: String) {
    if (uriString == null) {
        Toast.makeText(ctx, "PDF URI not available", Toast.LENGTH_SHORT).show(); return
    }
    try {
        val intent = Intent(Intent.ACTION_SEND).apply {
            type = "application/pdf"
            putExtra(Intent.EXTRA_STREAM, Uri.parse(uriString))
            putExtra(Intent.EXTRA_SUBJECT, title)
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        }
        ctx.startActivity(Intent.createChooser(intent, "Share PDF"))
    } catch (e: Exception) {
        Toast.makeText(ctx, "Could not share: ${e.message}", Toast.LENGTH_SHORT).show()
    }
}

private fun openPdfExternally(ctx: Context, uriString: String?) {
    if (uriString == null) {
        Toast.makeText(ctx, "PDF URI not available", Toast.LENGTH_SHORT).show(); return
    }
    try {
        val intent = Intent(Intent.ACTION_VIEW).apply {
            setDataAndType(Uri.parse(uriString), "application/pdf")
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_ACTIVITY_NEW_TASK)
        }
        ctx.startActivity(intent)
    } catch (e: Exception) {
        Toast.makeText(ctx, "No app can open this PDF", Toast.LENGTH_SHORT).show()
    }
}

/**
 * Print the PDF via Android PrintManager. Streams the raw PDF bytes to the print
 * framework so the system print spooler can route to a printer or "Save as PDF".
 */
private fun printPdf(ctx: Context, uriString: String?, title: String) {
    if (uriString == null) {
        Toast.makeText(ctx, "PDF URI not available", Toast.LENGTH_SHORT).show(); return
    }
    try {
        val pm = ctx.getSystemService(Context.PRINT_SERVICE) as PrintManager
        val jobName = "MarkVault: $title"
        val adapter = object : PrintDocumentAdapter() {
            override fun onLayout(
                old: PrintAttributes?, new: PrintAttributes?,
                cancellationSignal: android.os.CancellationSignal?,
                callback: LayoutResultCallback?, extras: android.os.Bundle?
            ) {
                if (cancellationSignal?.isCanceled == true) { callback?.onLayoutCancelled(); return }
                val info = PrintDocumentInfo.Builder(jobName)
                    .setContentType(PrintDocumentInfo.CONTENT_TYPE_DOCUMENT)
                    .build()
                callback?.onLayoutFinished(info, true)
            }
            override fun onWrite(
                pages: Array<out android.print.PageRange>?,
                destination: ParcelFileDescriptor?,
                cancellationSignal: android.os.CancellationSignal?,
                callback: WriteResultCallback?
            ) {
                try {
                    ctx.contentResolver.openInputStream(Uri.parse(uriString))?.use { input ->
                        java.io.FileOutputStream(destination?.fileDescriptor).use { out ->
                            input.copyTo(out)
                        }
                    }
                    callback?.onWriteFinished(arrayOf(android.print.PageRange.ALL_PAGES))
                } catch (e: Exception) {
                    Log.e(TAG, "print onWrite failed", e)
                    callback?.onWriteFailed(e.message)
                }
            }
        }
        pm.print(jobName, adapter, null)
    } catch (e: Exception) {
        Toast.makeText(ctx, "Print failed: ${e.message}", Toast.LENGTH_SHORT).show()
    }
}

/**
 * v4.14.0 — Phrase-first PDF highlight term picker.
 *
 * Mirrors the markdown reader's `pickHighlightTerm` (in `render.js`) and the
 * HTML reader's in-JS picker so all three article types follow the same
 * "phrases beat individual words" rule when a search result is opened.
 *
 * Returns the longest sub-term of [raw] that actually appears somewhere in
 * the concatenated PDF text. Search order:
 *   1. Full phrase, whitespace-normalised and lower-cased
 *   2. Same, with trailing punctuation (`?`, `!`, `.`, `,`, `;`, `:`) removed
 *   3. Longest non-stopword in the phrase
 *   4. Any word, stopwords included
 *
 * Returns null when nothing matches — the caller should fall back to the
 * raw query in that case (which then itself produces zero matches, which
 * is the honest answer).
 */
private fun pickPdfHighlightTerm(
    raw: String,
    pageTexts: Map<Int, String>
): String? {
    if (raw.isBlank() || pageTexts.isEmpty()) return null
    // Concatenate all pages once for a single contains() scan per stage.
    val combined = pageTexts.values.joinToString(" ").lowercase()
    val normalised = raw.lowercase().replace(Regex("\\s+"), " ").trim()
    if (normalised.isBlank()) return null
    // 1. Whole phrase
    if (combined.contains(normalised)) return normalised
    // 2. Strip trailing punctuation
    val stripped = normalised.replace(Regex("[?!.,;:]+$"), "").trim()
    if (stripped.isNotEmpty() && stripped != normalised && combined.contains(stripped)) {
        return stripped
    }
    // 3. Longest non-stopword that appears
    val stopwords = setOf(
        "the","is","a","an","of","to","and","in","on","for","at","by",
        "are","was","were","be","been","being","it","its","this","that",
        "these","those","with","from","as","or","but","if","so","do",
        "does","did","has","have","had","will","would","can","could"
    )
    val words = normalised.split(Regex("[^a-z0-9']+")).filter { it.length >= 2 }
    val byLengthDesc = words.sortedByDescending { it.length }
    for (w in byLengthDesc) {
        if (w in stopwords) continue
        if (combined.contains(w)) return w
    }
    // 4. Last resort: any matching word, stopwords included
    for (w in byLengthDesc) {
        if (combined.contains(w)) return w
    }
    return null
}
