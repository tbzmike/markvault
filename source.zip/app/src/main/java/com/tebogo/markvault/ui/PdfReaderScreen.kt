package com.tebogo.markvault.ui

import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.pdf.PdfRenderer
import android.net.Uri
import android.widget.Toast
import androidx.activity.compose.BackHandler
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.gestures.detectTransformGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyListState
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.MoreVert
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.derivedStateOf
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateMapOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.runtime.snapshotFlow
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.navigation.NavController
import com.tebogo.markvault.AppViewModel
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.collectLatest
import kotlinx.coroutines.flow.distinctUntilChanged
import kotlinx.coroutines.withContext
import kotlin.math.abs
import kotlin.math.roundToInt

/* ══════════════════════════════════════════════════════════════════════
 *  CORE PDF RENDERING ENGINE — shared by both viewers
 *
 *  Strategy:
 *    • ONE centralized rendering coroutine (no per-item effects)
 *    • Renders on Dispatchers.Default, writes state on Main thread
 *    • @Synchronized on PdfRenderer access (one page at a time)
 *    • collectLatest cancels stale renders on fast scroll
 *    • RGB_565 bitmaps (2 bytes/px instead of 4)
 *    • Evicts pages >10 away from viewport to bound memory
 *    • Eagerly pre-renders first 4 pages for instant display
 * ══════════════════════════════════════════════════════════════════════ */

private const val CACHE_RADIUS = 10  // Keep ±10 pages around viewport
private const val BUFFER_AHEAD = 5   // Pre-render 5 pages ahead
private const val BUFFER_BEHIND = 2  // Keep 2 pages behind

/** Thread-safe single-page render. PdfRenderer allows only one open page at a time. */
@Synchronized
private fun renderPageBitmap(renderer: PdfRenderer, index: Int, targetWidth: Int): Bitmap? {
    if (index < 0 || index >= renderer.pageCount) return null
    return try {
        val page = renderer.openPage(index)
        val scale = targetWidth.toFloat() / page.width
        val h = (page.height * scale).toInt().coerceAtLeast(1)
        val bmp = Bitmap.createBitmap(targetWidth, h, Bitmap.Config.RGB_565)
        bmp.eraseColor(android.graphics.Color.WHITE)
        page.render(bmp, null, null, PdfRenderer.Page.RENDER_MODE_FOR_DISPLAY)
        page.close()
        bmp
    } catch (_: Exception) { null }
}

/**
 * The scrollable page list with centralized rendering engine.
 * No per-item LaunchedEffects — one coroutine drives all rendering.
 */
@Composable
private fun PdfPagesList(
    renderer: PdfRenderer?,
    pageCount: Int,
    placeholderHeight: Dp,
    listState: LazyListState,
    scale: Float,
    offsetX: Float,
    offsetY: Float
) {
    val ctx = LocalContext.current
    val screenWidth = ctx.resources.displayMetrics.widthPixels
    val pageCache = remember { mutableStateMapOf<Int, Bitmap>() }

    // ── Central rendering engine ──
    LaunchedEffect(renderer, pageCount) {
        val r = renderer ?: return@LaunchedEffect
        if (pageCount == 0) return@LaunchedEffect

        // Phase 1: Eagerly render first 4 pages for instant display
        for (i in 0 until minOf(4, pageCount)) {
            if (pageCache.containsKey(i)) continue
            val bmp = withContext(Dispatchers.Default) { renderPageBitmap(r, i, screenWidth) }
            if (bmp != null) pageCache[i] = bmp   // ← Main thread write
        }

        // Phase 2: React to scroll — render visible+buffer, evict distant
        snapshotFlow { listState.firstVisibleItemIndex }
            .distinctUntilChanged()
            .collectLatest { first ->
                // Evict distant pages to free memory
                pageCache.keys.toList().forEach { k ->
                    if (abs(k - first) > CACHE_RADIUS) pageCache.remove(k)
                }

                // Priority: render currently visible pages first
                val visibleEnd = minOf(first + BUFFER_AHEAD, pageCount - 1)
                val bufferStart = maxOf(first - BUFFER_BEHIND, 0)

                for (i in first..visibleEnd) {
                    if (pageCache.containsKey(i)) continue
                    val bmp = withContext(Dispatchers.Default) { renderPageBitmap(r, i, screenWidth) }
                    if (bmp != null) pageCache[i] = bmp
                }
                // Then render buffer-behind pages
                for (i in bufferStart until first) {
                    if (pageCache.containsKey(i)) continue
                    val bmp = withContext(Dispatchers.Default) { renderPageBitmap(r, i, screenWidth) }
                    if (bmp != null) pageCache[i] = bmp
                }
            }
    }

    // Clean up all bitmaps on dispose
    DisposableEffect(Unit) { onDispose { pageCache.clear() } }

    // ── Display ──
    LazyColumn(
        state = listState,
        modifier = Modifier
            .fillMaxSize()
            .graphicsLayer(
                scaleX = scale, scaleY = scale,
                translationX = offsetX, translationY = offsetY
            ),
        verticalArrangement = Arrangement.spacedBy(4.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        items(pageCount) { index ->
            val bitmap = pageCache[index]
            if (bitmap != null) {
                Image(
                    bitmap = bitmap.asImageBitmap(),
                    contentDescription = "Page ${index + 1}",
                    contentScale = ContentScale.FillWidth,
                    modifier = Modifier.fillMaxWidth()
                )
            } else {
                Box(
                    Modifier
                        .fillMaxWidth()
                        .height(placeholderHeight)
                        .background(Color(0xFF1A1A1A)),
                    contentAlignment = Alignment.Center
                ) {
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        CircularProgressIndicator(
                            Modifier.size(22.dp), color = Color(0xFF555555), strokeWidth = 2.dp
                        )
                        Spacer(Modifier.height(4.dp))
                        Text("Page ${index + 1}", fontSize = 11.sp, color = Color(0xFF555555))
                    }
                }
            }
        }
        item { Spacer(Modifier.height(80.dp)) }
    }
}

/* ──────────────────────────────────────────────────────────────────────
 *  Zoom + gestures wrapper (shared by both viewers)
 * ────────────────────────────────────────────────────────────────────── */

@Composable
private fun ZoomablePageContainer(
    renderer: PdfRenderer?,
    pageCount: Int,
    placeholderHeight: Dp,
    listState: LazyListState,
    scale: Float,
    onScaleChange: (Float) -> Unit,
    offsetX: Float,
    onOffsetXChange: (Float) -> Unit,
    offsetY: Float,
    onOffsetYChange: (Float) -> Unit
) {
    Box(
        Modifier
            .fillMaxSize()
            .pointerInput(Unit) {
                detectTransformGestures { _, pan, zoom, _ ->
                    val ns = (scale * zoom).coerceIn(0.5f, 4f)
                    if (ns > 1f) {
                        onOffsetXChange(offsetX + pan.x)
                        onOffsetYChange(offsetY + pan.y)
                    } else {
                        onOffsetXChange(0f); onOffsetYChange(0f)
                    }
                    onScaleChange(ns)
                }
            }
            .pointerInput(Unit) {
                detectTapGestures(onDoubleTap = {
                    if (scale > 1.1f) {
                        onScaleChange(1f); onOffsetXChange(0f); onOffsetYChange(0f)
                    } else onScaleChange(2f)
                })
            }
    ) {
        PdfPagesList(renderer, pageCount, placeholderHeight, listState, scale, offsetX, offsetY)
    }
}

/* ══════════════════════════════════════════════════════════════════════
 *  PdfReaderScreen — in-app viewer (note from database)
 * ══════════════════════════════════════════════════════════════════════ */

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun PdfReaderScreen(vm: AppViewModel, nav: NavController, noteId: Long) {
    val ctx = LocalContext.current
    val favouriteIds by vm.favouriteIds.collectAsStateWithLifecycle()

    var title by remember { mutableStateOf("PDF") }
    var pdfUri by remember { mutableStateOf<String?>(null) }
    var renderer by remember { mutableStateOf<PdfRenderer?>(null) }
    var pageCount by remember { mutableIntStateOf(0) }
    var pageAspect by remember { mutableFloatStateOf(1.414f) }
    var loading by remember { mutableStateOf(true) }
    var error by remember { mutableStateOf<String?>(null) }
    var menuOpen by remember { mutableStateOf(false) }

    var scale by remember { mutableFloatStateOf(1f) }
    var offsetX by remember { mutableFloatStateOf(0f) }
    var offsetY by remember { mutableFloatStateOf(0f) }
    val listState = rememberLazyListState()

    val currentPage by remember {
        derivedStateOf {
            (listState.firstVisibleItemIndex + 1).coerceIn(1, pageCount.coerceAtLeast(1))
        }
    }

    // Open PDF
    LaunchedEffect(noteId) {
        loading = true; error = null
        val note = withContext(Dispatchers.IO) { vm.loadNote(noteId) }
        if (note == null || note.fileType != "pdf") {
            error = "Not a PDF file"; loading = false; return@LaunchedEffect
        }
        title = note.title; pdfUri = note.uri
        val r = withContext(Dispatchers.IO) {
            try {
                val pfd = ctx.contentResolver.openFileDescriptor(Uri.parse(note.uri), "r")
                    ?: return@withContext null
                PdfRenderer(pfd)
            } catch (_: Exception) { null }
        }
        if (r == null) {
            error = "Could not open the PDF.\nThe file may have been moved or deleted."
            loading = false; return@LaunchedEffect
        }
        renderer = r; pageCount = r.pageCount
        // Read first page aspect for placeholder sizing
        if (r.pageCount > 0) withContext(Dispatchers.Default) {
            try {
                val p = r.openPage(0)
                pageAspect = p.height.toFloat() / p.width.toFloat()
                p.close()
            } catch (_: Exception) { }
        }
        loading = false
    }

    DisposableEffect(Unit) { onDispose { renderer?.close() } }
    BackHandler { nav.popBackStack() }

    val density = ctx.resources.displayMetrics.density
    val placeholderH = remember(pageAspect) {
        (ctx.resources.displayMetrics.widthPixels * pageAspect / density).dp
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text(title, maxLines = 1, overflow = TextOverflow.Ellipsis) },
                navigationIcon = {
                    IconButton(onClick = { nav.popBackStack() }) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back")
                    }
                },
                actions = {
                    TextButton(onClick = { scale = (scale - 0.25f).coerceIn(0.5f, 4f) }) {
                        Text("\u2212", fontSize = 18.sp)
                    }
                    Text(
                        "${(scale * 100).roundToInt()}%", fontSize = 12.sp,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                    TextButton(onClick = { scale = (scale + 0.25f).coerceIn(0.5f, 4f) }) {
                        Text("+", fontSize = 18.sp)
                    }
                    Box {
                        IconButton(onClick = { menuOpen = true }) {
                            Icon(Icons.Default.MoreVert, contentDescription = "More")
                        }
                        DropdownMenu(expanded = menuOpen, onDismissRequest = { menuOpen = false }) {
                            val isFav = noteId in favouriteIds
                            DropdownMenuItem(
                                text = { Text(if (isFav) "\uD83D\uDC94 Remove favourite" else "\u2B50 Add favourite") },
                                onClick = { menuOpen = false; vm.toggleFavourite(noteId) }
                            )
                            HorizontalDivider()
                            DropdownMenuItem(
                                text = { Text("\uD83D\uDD0D Search library") },
                                onClick = { menuOpen = false; nav.navigate("search") }
                            )
                            HorizontalDivider()
                            DropdownMenuItem(
                                text = { Text("\uD83D\uDCE4 Share PDF") },
                                onClick = { menuOpen = false; sharePdf(ctx, pdfUri, title) }
                            )
                            DropdownMenuItem(
                                text = { Text("\uD83C\uDF10 Open externally") },
                                onClick = { menuOpen = false; openPdfExternally(ctx, pdfUri) }
                            )
                            HorizontalDivider()
                            DropdownMenuItem(
                                text = { Text("\uD83D\uDD04 Reset zoom") },
                                onClick = { menuOpen = false; scale = 1f; offsetX = 0f; offsetY = 0f }
                            )
                        }
                    }
                }
            )
        }
    ) { pad ->
        Box(Modifier.padding(pad).fillMaxSize().background(Color(0xFF0A0A0A))) {
            when {
                loading -> CenteredStatus("\u23F3 Opening PDF\u2026")
                error != null -> CenteredStatus("\u26A0\uFE0F $error")
                else -> {
                    ZoomablePageContainer(
                        renderer, pageCount, placeholderH, listState,
                        scale, { scale = it }, offsetX, { offsetX = it }, offsetY, { offsetY = it }
                    )
                    if (pageCount > 0) PageChip(currentPage, pageCount, Modifier.align(Alignment.BottomCenter))
                }
            }
        }
    }
}

/* ══════════════════════════════════════════════════════════════════════
 *  PdfViewerStandalone — external PDF activity (no DB, no nav)
 * ══════════════════════════════════════════════════════════════════════ */

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun PdfViewerStandalone(uri: Uri?, titleHint: String, onClose: () -> Unit) {
    val ctx = LocalContext.current

    var title by remember { mutableStateOf(titleHint) }
    var renderer by remember { mutableStateOf<PdfRenderer?>(null) }
    var pageCount by remember { mutableIntStateOf(0) }
    var pageAspect by remember { mutableFloatStateOf(1.414f) }
    var loading by remember { mutableStateOf(true) }
    var error by remember { mutableStateOf<String?>(null) }
    var menuOpen by remember { mutableStateOf(false) }

    var scale by remember { mutableFloatStateOf(1f) }
    var offsetX by remember { mutableFloatStateOf(0f) }
    var offsetY by remember { mutableFloatStateOf(0f) }
    val listState = rememberLazyListState()

    val currentPage by remember {
        derivedStateOf {
            (listState.firstVisibleItemIndex + 1).coerceIn(1, pageCount.coerceAtLeast(1))
        }
    }

    LaunchedEffect(uri) {
        loading = true; error = null
        if (uri == null) { error = "No file was provided."; loading = false; return@LaunchedEffect }
        val r = withContext(Dispatchers.IO) {
            try {
                val pfd = ctx.contentResolver.openFileDescriptor(uri, "r") ?: return@withContext null
                PdfRenderer(pfd)
            } catch (_: Exception) { null }
        }
        if (r == null) { error = "Could not open this PDF."; loading = false; return@LaunchedEffect }
        renderer = r; pageCount = r.pageCount
        if (r.pageCount > 0) withContext(Dispatchers.Default) {
            try {
                val p = r.openPage(0); pageAspect = p.height.toFloat() / p.width.toFloat(); p.close()
            } catch (_: Exception) { }
        }
        loading = false
    }

    DisposableEffect(Unit) { onDispose { renderer?.close() } }
    BackHandler { onClose() }

    val density = ctx.resources.displayMetrics.density
    val placeholderH = remember(pageAspect) {
        (ctx.resources.displayMetrics.widthPixels * pageAspect / density).dp
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text(title, maxLines = 1, overflow = TextOverflow.Ellipsis) },
                navigationIcon = {
                    IconButton(onClick = onClose) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Close")
                    }
                },
                actions = {
                    TextButton(onClick = { scale = (scale - 0.25f).coerceIn(0.5f, 4f) }) {
                        Text("\u2212", fontSize = 18.sp)
                    }
                    Text("${(scale * 100).roundToInt()}%", fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    TextButton(onClick = { scale = (scale + 0.25f).coerceIn(0.5f, 4f) }) {
                        Text("+", fontSize = 18.sp)
                    }
                    Box {
                        IconButton(onClick = { menuOpen = true }) {
                            Icon(Icons.Default.MoreVert, contentDescription = "More")
                        }
                        DropdownMenu(expanded = menuOpen, onDismissRequest = { menuOpen = false }) {
                            DropdownMenuItem(
                                text = { Text("\uD83D\uDCE4 Share PDF") },
                                onClick = { menuOpen = false; sharePdf(ctx, uri?.toString(), title) }
                            )
                            DropdownMenuItem(
                                text = { Text("\uD83C\uDF10 Open externally") },
                                onClick = { menuOpen = false; openPdfExternally(ctx, uri?.toString()) }
                            )
                            HorizontalDivider()
                            DropdownMenuItem(
                                text = { Text("\uD83D\uDD04 Reset zoom") },
                                onClick = { menuOpen = false; scale = 1f; offsetX = 0f; offsetY = 0f }
                            )
                        }
                    }
                }
            )
        }
    ) { pad ->
        Box(Modifier.padding(pad).fillMaxSize().background(Color(0xFF0A0A0A))) {
            when {
                loading -> CenteredStatus("\u23F3 Opening PDF\u2026")
                error != null -> CenteredStatus("\u26A0\uFE0F $error")
                else -> {
                    ZoomablePageContainer(
                        renderer, pageCount, placeholderH, listState,
                        scale, { scale = it }, offsetX, { offsetX = it }, offsetY, { offsetY = it }
                    )
                    if (pageCount > 0) PageChip(currentPage, pageCount, Modifier.align(Alignment.BottomCenter))
                }
            }
        }
    }
}

/* ──────────────────────────────────────────────────────────────────────
 *  Small shared UI pieces
 * ────────────────────────────────────────────────────────────────────── */

@Composable
private fun CenteredStatus(msg: String) {
    Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
        Text(msg, color = MaterialTheme.colorScheme.onSurfaceVariant, fontSize = 14.sp, lineHeight = 20.sp)
    }
}

@Composable
private fun PageChip(current: Int, total: Int, modifier: Modifier) {
    Surface(modifier = modifier.padding(bottom = 20.dp), color = Color(0xCC1A1A1A), shape = RoundedCornerShape(20.dp)) {
        Text(
            "\uD83D\uDCC4 $current / $total",
            Modifier.padding(horizontal = 16.dp, vertical = 8.dp),
            fontSize = 13.sp, fontWeight = FontWeight.Medium, color = Color(0xFFCCCCCC)
        )
    }
}

/* ──────────────────────────────────────────────────────────────────────
 *  Share / open helpers
 * ────────────────────────────────────────────────────────────────────── */

private fun sharePdf(ctx: Context, uriString: String?, title: String) {
    if (uriString == null) { Toast.makeText(ctx, "PDF URI not available", Toast.LENGTH_SHORT).show(); return }
    try {
        val intent = Intent(Intent.ACTION_SEND).apply {
            type = "application/pdf"
            putExtra(Intent.EXTRA_STREAM, Uri.parse(uriString))
            putExtra(Intent.EXTRA_SUBJECT, title)
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        }
        ctx.startActivity(Intent.createChooser(intent, "Share PDF"))
    } catch (e: Exception) { Toast.makeText(ctx, "Could not share: ${e.message}", Toast.LENGTH_SHORT).show() }
}

private fun openPdfExternally(ctx: Context, uriString: String?) {
    if (uriString == null) { Toast.makeText(ctx, "PDF URI not available", Toast.LENGTH_SHORT).show(); return }
    try {
        val intent = Intent(Intent.ACTION_VIEW).apply {
            setDataAndType(Uri.parse(uriString), "application/pdf")
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_ACTIVITY_NEW_TASK)
        }
        ctx.startActivity(intent)
    } catch (_: Exception) { Toast.makeText(ctx, "No app can open this PDF", Toast.LENGTH_SHORT).show() }
}
