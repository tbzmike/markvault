package com.tebogo.markvault.ui

import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.pdf.PdfRenderer
import android.net.Uri
import android.widget.Toast
import androidx.activity.compose.BackHandler
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.gestures.detectTransformGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.MoreVert
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.derivedStateOf
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateMapOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.runtime.snapshotFlow
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.navigation.NavController
import com.tebogo.markvault.AppViewModel
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import kotlinx.coroutines.withContext
import kotlin.math.abs
import kotlin.math.roundToInt

/* ──────────────────────────────────────────────────────────────────────
 *  PdfReaderScreen — in-app PDF viewer (note from DB)
 * ────────────────────────────────────────────────────────────────────── */

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun PdfReaderScreen(
    vm: AppViewModel,
    nav: NavController,
    noteId: Long
) {
    val ctx = LocalContext.current
    val favouriteIds by vm.favouriteIds.collectAsStateWithLifecycle()

    var title by remember { mutableStateOf("PDF") }
    var pdfUri by remember { mutableStateOf<String?>(null) }

    // Lazy-rendered PDF state
    var renderer by remember { mutableStateOf<PdfRenderer?>(null) }
    var pageCount by remember { mutableIntStateOf(0) }
    var pageAspect by remember { mutableFloatStateOf(1.414f) } // A4 default
    val pageCache = remember { mutableStateMapOf<Int, Bitmap>() }
    val renderMutex = remember { Mutex() }

    var loading by remember { mutableStateOf(true) }
    var error by remember { mutableStateOf<String?>(null) }
    var menuOpen by remember { mutableStateOf(false) }

    // Zoom
    var scale by remember { mutableFloatStateOf(1f) }
    var offsetX by remember { mutableFloatStateOf(0f) }
    var offsetY by remember { mutableFloatStateOf(0f) }

    val listState = rememberLazyListState()
    val screenWidth = ctx.resources.displayMetrics.widthPixels

    val currentPage by remember {
        derivedStateOf {
            (listState.firstVisibleItemIndex + 1).coerceIn(1, pageCount.coerceAtLeast(1))
        }
    }

    // Open renderer — lightweight, only reads metadata
    LaunchedEffect(noteId) {
        loading = true; error = null
        try {
            val note = withContext(Dispatchers.IO) { vm.loadNote(noteId) }
            if (note == null || note.fileType != "pdf") {
                error = "Not a PDF file"; loading = false; return@LaunchedEffect
            }
            title = note.title; pdfUri = note.uri

            val r = withContext(Dispatchers.IO) { openRenderer(ctx, note.uri) }
            if (r == null) {
                error = "Could not open the PDF.\nThe file may have been moved or deleted."
                loading = false; return@LaunchedEffect
            }
            renderer = r; pageCount = r.pageCount

            // Read first page dims for placeholder aspect ratio
            if (r.pageCount > 0) withContext(Dispatchers.IO) {
                val p = r.openPage(0)
                pageAspect = p.height.toFloat() / p.width.toFloat()
                p.close()
            }
        } catch (e: Exception) {
            error = "Failed: ${e.message ?: e.javaClass.simpleName}"
        }
        loading = false
    }

    // Evict distant pages as user scrolls
    LaunchedEffect(listState) {
        snapshotFlow { listState.firstVisibleItemIndex }.collect { first ->
            val keys = pageCache.keys.toList()
            for (k in keys) {
                if (abs(k - first) > 6) pageCache.remove(k)
            }
        }
    }

    DisposableEffect(Unit) {
        onDispose {
            renderer?.close()
            pageCache.values.forEach { /* let GC handle */ }
            pageCache.clear()
        }
    }

    BackHandler { nav.popBackStack() }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text(title, maxLines = 1, overflow = TextOverflow.Ellipsis) },
                navigationIcon = {
                    IconButton(onClick = { nav.popBackStack() }) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back")
                    }
                },
                actions = {
                    TextButton(onClick = { scale = (scale - 0.25f).coerceIn(0.5f, 4f) }) {
                        Text("\u2212", fontSize = 18.sp)
                    }
                    Text(
                        "${(scale * 100).roundToInt()}%", fontSize = 12.sp,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                    TextButton(onClick = { scale = (scale + 0.25f).coerceIn(0.5f, 4f) }) {
                        Text("+", fontSize = 18.sp)
                    }
                    Box {
                        IconButton(onClick = { menuOpen = true }) {
                            Icon(Icons.Default.MoreVert, contentDescription = "More")
                        }
                        DropdownMenu(expanded = menuOpen, onDismissRequest = { menuOpen = false }) {
                            val isFav = noteId in favouriteIds
                            DropdownMenuItem(
                                text = { Text(if (isFav) "\uD83D\uDC94 Remove favourite" else "\u2B50 Add favourite") },
                                onClick = { menuOpen = false; vm.toggleFavourite(noteId) }
                            )
                            HorizontalDivider()
                            DropdownMenuItem(
                                text = { Text("\uD83D\uDD0D Search library") },
                                onClick = { menuOpen = false; nav.navigate("search") }
                            )
                            HorizontalDivider()
                            DropdownMenuItem(
                                text = { Text("\uD83D\uDCE4 Share PDF") },
                                onClick = { menuOpen = false; sharePdf(ctx, pdfUri, title) }
                            )
                            DropdownMenuItem(
                                text = { Text("\uD83C\uDF10 Open externally") },
                                onClick = { menuOpen = false; openPdfExternally(ctx, pdfUri) }
                            )
                            HorizontalDivider()
                            DropdownMenuItem(
                                text = { Text("\uD83D\uDD04 Reset zoom") },
                                onClick = { menuOpen = false; scale = 1f; offsetX = 0f; offsetY = 0f }
                            )
                        }
                    }
                }
            )
        }
    ) { pad ->
        Box(
            Modifier.padding(pad).fillMaxSize().background(Color(0xFF0A0A0A))
        ) {
            when {
                loading -> LoadingState("Loading PDF\u2026")
                error != null -> ErrorState(error!!)
                else -> {
                    Box(
                        Modifier.fillMaxSize()
                            .pointerInput(Unit) {
                                detectTransformGestures { _, pan, zoom, _ ->
                                    val ns = (scale * zoom).coerceIn(0.5f, 4f)
                                    if (ns > 1f) { offsetX += pan.x; offsetY += pan.y }
                                    else { offsetX = 0f; offsetY = 0f }
                                    scale = ns
                                }
                            }
                            .pointerInput(Unit) {
                                detectTapGestures(onDoubleTap = {
                                    if (scale > 1.1f) { scale = 1f; offsetX = 0f; offsetY = 0f }
                                    else scale = 2f
                                })
                            }
                    ) {
                        val placeholderH = (screenWidth * pageAspect / ctx.resources.displayMetrics.density).dp
                        LazyColumn(
                            state = listState,
                            modifier = Modifier.fillMaxSize().graphicsLayer(
                                scaleX = scale, scaleY = scale,
                                translationX = offsetX, translationY = offsetY
                            ),
                            verticalArrangement = Arrangement.spacedBy(4.dp),
                            horizontalAlignment = Alignment.CenterHorizontally
                        ) {
                            items(pageCount) { index ->
                                val bitmap = pageCache[index]

                                // Trigger render for this page
                                LaunchedEffect(index, renderer) {
                                    val r = renderer ?: return@LaunchedEffect
                                    if (pageCache.containsKey(index)) return@LaunchedEffect
                                    withContext(Dispatchers.IO) {
                                        renderMutex.withLock {
                                            if (pageCache.containsKey(index)) return@withLock
                                            try {
                                                val page = r.openPage(index)
                                                val ratio = screenWidth.toFloat() / page.width
                                                val h = (page.height * ratio).toInt()
                                                val bmp = Bitmap.createBitmap(
                                                    screenWidth, h, Bitmap.Config.RGB_565
                                                )
                                                bmp.eraseColor(android.graphics.Color.WHITE)
                                                page.render(
                                                    bmp, null, null,
                                                    PdfRenderer.Page.RENDER_MODE_FOR_DISPLAY
                                                )
                                                page.close()
                                                pageCache[index] = bmp
                                            } catch (_: Exception) { }
                                        }
                                    }
                                }

                                if (bitmap != null) {
                                    Image(
                                        bitmap = bitmap.asImageBitmap(),
                                        contentDescription = "Page ${index + 1}",
                                        contentScale = ContentScale.FillWidth,
                                        modifier = Modifier.fillMaxWidth()
                                    )
                                } else {
                                    // Placeholder while rendering
                                    Box(
                                        Modifier.fillMaxWidth().height(placeholderH)
                                            .background(Color(0xFF1A1A1A)),
                                        contentAlignment = Alignment.Center
                                    ) {
                                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                            CircularProgressIndicator(
                                                Modifier.size(24.dp),
                                                color = Color(0xFF555555),
                                                strokeWidth = 2.dp
                                            )
                                            Spacer(Modifier.height(6.dp))
                                            Text(
                                                "Page ${index + 1}",
                                                fontSize = 11.sp, color = Color(0xFF555555)
                                            )
                                        }
                                    }
                                }
                            }
                            item { Spacer(Modifier.height(80.dp)) }
                        }
                    }

                    if (pageCount > 0) {
                        Surface(
                            modifier = Modifier.align(Alignment.BottomCenter).padding(bottom = 20.dp),
                            color = Color(0xCC1A1A1A), shape = RoundedCornerShape(20.dp)
                        ) {
                            Text(
                                "\uD83D\uDCC4 $currentPage / $pageCount",
                                Modifier.padding(horizontal = 16.dp, vertical = 8.dp),
                                fontSize = 13.sp, fontWeight = FontWeight.Medium, color = Color(0xFFCCCCCC)
                            )
                        }
                    }
                }
            }
        }
    }
}

/* ──────────────────────────────────────────────────────────────────────
 *  PdfViewerStandalone — used by ExternalPdfActivity (no DB, no nav)
 * ────────────────────────────────────────────────────────────────────── */

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun PdfViewerStandalone(
    uri: Uri?,
    titleHint: String,
    onClose: () -> Unit
) {
    val ctx = LocalContext.current

    var title by remember { mutableStateOf(titleHint) }
    var renderer by remember { mutableStateOf<PdfRenderer?>(null) }
    var pageCount by remember { mutableIntStateOf(0) }
    var pageAspect by remember { mutableFloatStateOf(1.414f) }
    val pageCache = remember { mutableStateMapOf<Int, Bitmap>() }
    val renderMutex = remember { Mutex() }

    var loading by remember { mutableStateOf(true) }
    var error by remember { mutableStateOf<String?>(null) }
    var menuOpen by remember { mutableStateOf(false) }

    var scale by remember { mutableFloatStateOf(1f) }
    var offsetX by remember { mutableFloatStateOf(0f) }
    var offsetY by remember { mutableFloatStateOf(0f) }

    val listState = rememberLazyListState()
    val screenWidth = ctx.resources.displayMetrics.widthPixels

    val currentPage by remember {
        derivedStateOf {
            (listState.firstVisibleItemIndex + 1).coerceIn(1, pageCount.coerceAtLeast(1))
        }
    }

    LaunchedEffect(uri) {
        loading = true; error = null
        if (uri == null) { error = "No file was provided."; loading = false; return@LaunchedEffect }
        try {
            val r = withContext(Dispatchers.IO) {
                val pfd = ctx.contentResolver.openFileDescriptor(uri, "r") ?: return@withContext null
                PdfRenderer(pfd)
            }
            if (r == null) { error = "Could not open this PDF."; loading = false; return@LaunchedEffect }
            renderer = r; pageCount = r.pageCount
            if (r.pageCount > 0) withContext(Dispatchers.IO) {
                val p = r.openPage(0); pageAspect = p.height.toFloat() / p.width.toFloat(); p.close()
            }
        } catch (e: Exception) {
            error = "Failed: ${e.message ?: e.javaClass.simpleName}"
        }
        loading = false
    }

    LaunchedEffect(listState) {
        snapshotFlow { listState.firstVisibleItemIndex }.collect { first ->
            val keys = pageCache.keys.toList()
            for (k in keys) { if (abs(k - first) > 6) pageCache.remove(k) }
        }
    }

    DisposableEffect(Unit) { onDispose { renderer?.close(); pageCache.clear() } }

    BackHandler { onClose() }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text(title, maxLines = 1, overflow = TextOverflow.Ellipsis) },
                navigationIcon = {
                    IconButton(onClick = onClose) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Close")
                    }
                },
                actions = {
                    TextButton(onClick = { scale = (scale - 0.25f).coerceIn(0.5f, 4f) }) {
                        Text("\u2212", fontSize = 18.sp)
                    }
                    Text(
                        "${(scale * 100).roundToInt()}%", fontSize = 12.sp,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                    TextButton(onClick = { scale = (scale + 0.25f).coerceIn(0.5f, 4f) }) {
                        Text("+", fontSize = 18.sp)
                    }
                    Box {
                        IconButton(onClick = { menuOpen = true }) {
                            Icon(Icons.Default.MoreVert, contentDescription = "More")
                        }
                        DropdownMenu(expanded = menuOpen, onDismissRequest = { menuOpen = false }) {
                            DropdownMenuItem(
                                text = { Text("\uD83D\uDCE4 Share PDF") },
                                onClick = { menuOpen = false; sharePdf(ctx, uri?.toString(), title) }
                            )
                            DropdownMenuItem(
                                text = { Text("\uD83C\uDF10 Open externally") },
                                onClick = { menuOpen = false; openPdfExternally(ctx, uri?.toString()) }
                            )
                            HorizontalDivider()
                            DropdownMenuItem(
                                text = { Text("\uD83D\uDD04 Reset zoom") },
                                onClick = { menuOpen = false; scale = 1f; offsetX = 0f; offsetY = 0f }
                            )
                        }
                    }
                }
            )
        }
    ) { pad ->
        Box(Modifier.padding(pad).fillMaxSize().background(Color(0xFF0A0A0A))) {
            when {
                loading -> LoadingState("Loading PDF\u2026")
                error != null -> ErrorState(error!!)
                else -> {
                    Box(
                        Modifier.fillMaxSize()
                            .pointerInput(Unit) {
                                detectTransformGestures { _, pan, zoom, _ ->
                                    val ns = (scale * zoom).coerceIn(0.5f, 4f)
                                    if (ns > 1f) { offsetX += pan.x; offsetY += pan.y }
                                    else { offsetX = 0f; offsetY = 0f }
                                    scale = ns
                                }
                            }
                            .pointerInput(Unit) {
                                detectTapGestures(onDoubleTap = {
                                    if (scale > 1.1f) { scale = 1f; offsetX = 0f; offsetY = 0f }
                                    else scale = 2f
                                })
                            }
                    ) {
                        val placeholderH = (screenWidth * pageAspect / ctx.resources.displayMetrics.density).dp
                        LazyColumn(
                            state = listState,
                            modifier = Modifier.fillMaxSize().graphicsLayer(
                                scaleX = scale, scaleY = scale,
                                translationX = offsetX, translationY = offsetY
                            ),
                            verticalArrangement = Arrangement.spacedBy(4.dp),
                            horizontalAlignment = Alignment.CenterHorizontally
                        ) {
                            items(pageCount) { index ->
                                val bitmap = pageCache[index]
                                LaunchedEffect(index, renderer) {
                                    val r = renderer ?: return@LaunchedEffect
                                    if (pageCache.containsKey(index)) return@LaunchedEffect
                                    withContext(Dispatchers.IO) {
                                        renderMutex.withLock {
                                            if (pageCache.containsKey(index)) return@withLock
                                            try {
                                                val page = r.openPage(index)
                                                val ratio = screenWidth.toFloat() / page.width
                                                val h = (page.height * ratio).toInt()
                                                val bmp = Bitmap.createBitmap(screenWidth, h, Bitmap.Config.RGB_565)
                                                bmp.eraseColor(android.graphics.Color.WHITE)
                                                page.render(bmp, null, null, PdfRenderer.Page.RENDER_MODE_FOR_DISPLAY)
                                                page.close()
                                                pageCache[index] = bmp
                                            } catch (_: Exception) { }
                                        }
                                    }
                                }
                                if (bitmap != null) {
                                    Image(
                                        bitmap = bitmap.asImageBitmap(),
                                        contentDescription = "Page ${index + 1}",
                                        contentScale = ContentScale.FillWidth,
                                        modifier = Modifier.fillMaxWidth()
                                    )
                                } else {
                                    Box(
                                        Modifier.fillMaxWidth().height(placeholderH).background(Color(0xFF1A1A1A)),
                                        contentAlignment = Alignment.Center
                                    ) {
                                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                            CircularProgressIndicator(Modifier.size(24.dp), color = Color(0xFF555555), strokeWidth = 2.dp)
                                            Spacer(Modifier.height(6.dp))
                                            Text("Page ${index + 1}", fontSize = 11.sp, color = Color(0xFF555555))
                                        }
                                    }
                                }
                            }
                            item { Spacer(Modifier.height(80.dp)) }
                        }
                    }
                    if (pageCount > 0) {
                        Surface(
                            modifier = Modifier.align(Alignment.BottomCenter).padding(bottom = 20.dp),
                            color = Color(0xCC1A1A1A), shape = RoundedCornerShape(20.dp)
                        ) {
                            Text(
                                "\uD83D\uDCC4 $currentPage / $pageCount",
                                Modifier.padding(horizontal = 16.dp, vertical = 8.dp),
                                fontSize = 13.sp, fontWeight = FontWeight.Medium, color = Color(0xFFCCCCCC)
                            )
                        }
                    }
                }
            }
        }
    }
}

/* ──────────────────────────────────────────────────────────────────────
 *  Shared helpers
 * ────────────────────────────────────────────────────────────────────── */

@Composable
private fun LoadingState(msg: String) {
    Column(
        Modifier.fillMaxSize(), Arrangement.Center, Alignment.CenterHorizontally
    ) {
        CircularProgressIndicator(color = MaterialTheme.colorScheme.primary, modifier = Modifier.size(42.dp))
        Spacer(Modifier.height(16.dp))
        Text(msg, color = MaterialTheme.colorScheme.onSurfaceVariant, fontSize = 14.sp)
    }
}

@Composable
private fun ErrorState(msg: String) {
    Column(
        Modifier.fillMaxSize().padding(32.dp), Arrangement.Center, Alignment.CenterHorizontally
    ) {
        Text("\u26A0\uFE0F", fontSize = 48.sp)
        Spacer(Modifier.height(16.dp))
        Text(msg, color = MaterialTheme.colorScheme.onSurfaceVariant, fontSize = 14.sp, lineHeight = 20.sp)
    }
}

private fun openRenderer(ctx: Context, uriString: String): PdfRenderer? {
    return try {
        val uri = Uri.parse(uriString)
        val pfd = ctx.contentResolver.openFileDescriptor(uri, "r") ?: return null
        PdfRenderer(pfd)
    } catch (_: Exception) { null }
}

private fun sharePdf(ctx: Context, uriString: String?, title: String) {
    if (uriString == null) { Toast.makeText(ctx, "PDF URI not available", Toast.LENGTH_SHORT).show(); return }
    try {
        val intent = Intent(Intent.ACTION_SEND).apply {
            type = "application/pdf"
            putExtra(Intent.EXTRA_STREAM, Uri.parse(uriString))
            putExtra(Intent.EXTRA_SUBJECT, title)
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        }
        ctx.startActivity(Intent.createChooser(intent, "Share PDF"))
    } catch (e: Exception) {
        Toast.makeText(ctx, "Could not share: ${e.message}", Toast.LENGTH_SHORT).show()
    }
}

private fun openPdfExternally(ctx: Context, uriString: String?) {
    if (uriString == null) { Toast.makeText(ctx, "PDF URI not available", Toast.LENGTH_SHORT).show(); return }
    try {
        val intent = Intent(Intent.ACTION_VIEW).apply {
            setDataAndType(Uri.parse(uriString), "application/pdf")
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_ACTIVITY_NEW_TASK)
        }
        ctx.startActivity(intent)
    } catch (_: Exception) {
        Toast.makeText(ctx, "No app can open this PDF", Toast.LENGTH_SHORT).show()
    }
}
