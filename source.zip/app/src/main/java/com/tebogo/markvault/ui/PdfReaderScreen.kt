package com.tebogo.markvault.ui

import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.pdf.PdfRenderer
import android.net.Uri
import android.util.Log
import android.widget.Toast
import androidx.activity.compose.BackHandler
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.gestures.detectTransformGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyListState
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.KeyboardArrowDown
import androidx.compose.material.icons.filled.KeyboardArrowUp
import androidx.compose.material.icons.filled.MoreVert
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TextField
import androidx.compose.material3.TextFieldDefaults
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.derivedStateOf
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.navigation.NavController
import com.tebogo.markvault.AppViewModel
import com.tom_roush.pdfbox.pdmodel.PDDocument
import com.tom_roush.pdfbox.text.PDFTextStripper
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.channels.Channel
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import kotlin.math.roundToInt

private const val TAG = "PdfReader"

/* ════════════════════════════════════════════════════════════════════════
 *  PDF RENDERER POOL — true parallelism via multiple PdfRenderer instances
 *
 *  Android's PdfRenderer allows only ONE open page per renderer instance,
 *  so to render multiple pages in parallel we open the PDF N times. Each
 *  worker renders independently on Dispatchers.IO.
 * ════════════════════════════════════════════════════════════════════════ */

class PdfRendererPool private constructor(
    private val renderers: List<PdfRenderer>
) {
    private val available = Channel<PdfRenderer>(Channel.UNLIMITED).also { ch ->
        renderers.forEach { ch.trySend(it) }
    }

    val pageCount: Int = renderers.firstOrNull()?.pageCount ?: 0
    val poolSize: Int = renderers.size

    /** Render one page to a bitmap. Multiple calls in parallel use different renderers. */
    suspend fun renderPage(pageIndex: Int, targetWidth: Int): Bitmap? = withContext(Dispatchers.IO) {
        if (pageIndex < 0 || pageIndex >= pageCount) return@withContext null
        val r = available.receive()
        try {
            val page = r.openPage(pageIndex)
            val scale = targetWidth.toFloat() / page.width
            val h = (page.height * scale).toInt().coerceAtLeast(1)
            val bmp = Bitmap.createBitmap(targetWidth, h, Bitmap.Config.ARGB_8888)
            bmp.eraseColor(android.graphics.Color.WHITE)
            page.render(bmp, null, null, PdfRenderer.Page.RENDER_MODE_FOR_DISPLAY)
            page.close()
            bmp
        } catch (e: Exception) {
            Log.e(TAG, "renderPage($pageIndex) failed", e)
            null
        } finally {
            available.trySend(r)
        }
    }

    /** Aspect ratio of first page, used to size placeholders. */
    suspend fun firstPageAspect(): Float = withContext(Dispatchers.IO) {
        if (pageCount == 0) return@withContext 1.414f
        val r = available.receive()
        try {
            val p = r.openPage(0)
            val aspect = p.height.toFloat() / p.width.toFloat()
            p.close()
            aspect
        } catch (e: Exception) { 1.414f }
        finally { available.trySend(r) }
    }

    fun close() {
        renderers.forEach { runCatching { it.close() } }
        available.close()
    }

    companion object {
        /** Open a PDF with N independent renderers for parallel page rendering. */
        suspend fun open(ctx: Context, uri: Uri, poolSize: Int = 3): PdfRendererPool? =
            withContext(Dispatchers.IO) {
                try {
                    val list = mutableListOf<PdfRenderer>()
                    repeat(poolSize) {
                        try {
                            val pfd = ctx.contentResolver.openFileDescriptor(uri, "r")
                            if (pfd != null) list.add(PdfRenderer(pfd))
                        } catch (e: Exception) {
                            Log.w(TAG, "Could not open renderer #$it", e)
                        }
                    }
                    if (list.isEmpty()) null else PdfRendererPool(list)
                } catch (e: Exception) {
                    Log.e(TAG, "PdfRendererPool.open failed", e)
                    null
                }
            }
    }
}

/* ════════════════════════════════════════════════════════════════════════
 *  PER-ITEM PAGE COMPONENT
 *
 *  Each visible page gets its own LaunchedEffect that renders the page in
 *  parallel via the pool. State writes happen AFTER withContext returns
 *  (guaranteed main thread). Bitmap is recycled on dispose.
 * ════════════════════════════════════════════════════════════════════════ */

@Composable
private fun PdfPageItem(
    pool: PdfRendererPool,
    pageIndex: Int,
    targetWidth: Int,
    placeholderHeight: Dp,
    highlight: Boolean
) {
    var bitmap by remember(pool, pageIndex) { mutableStateOf<Bitmap?>(null) }

    LaunchedEffect(pool, pageIndex) {
        val bmp = pool.renderPage(pageIndex, targetWidth)
        bitmap = bmp   // ← main thread write after withContext returns
    }

    DisposableEffect(pool, pageIndex) {
        onDispose {
            val b = bitmap
            bitmap = null
            try { b?.recycle() } catch (_: Exception) { }
        }
    }

    val b = bitmap
    Box(
        Modifier
            .fillMaxWidth()
            .then(
                if (highlight) Modifier.background(Color(0x33FFC107)) else Modifier
            )
    ) {
        if (b != null && !b.isRecycled) {
            Image(
                bitmap = b.asImageBitmap(),
                contentDescription = "Page ${pageIndex + 1}",
                contentScale = ContentScale.FillWidth,
                modifier = Modifier.fillMaxWidth()
            )
        } else {
            Box(
                Modifier
                    .fillMaxWidth()
                    .height(placeholderHeight)
                    .background(Color(0xFF1A1A1A)),
                contentAlignment = Alignment.Center
            ) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    CircularProgressIndicator(
                        Modifier.size(24.dp), color = Color(0xFF666666), strokeWidth = 2.dp
                    )
                    Spacer(Modifier.height(6.dp))
                    Text("Page ${pageIndex + 1}", fontSize = 11.sp, color = Color(0xFF666666))
                }
            }
        }
    }
}

/* ════════════════════════════════════════════════════════════════════════
 *  PdfReaderScreen — in-app PDF viewer (note from DB)
 * ════════════════════════════════════════════════════════════════════════ */

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun PdfReaderScreen(vm: AppViewModel, nav: NavController, noteId: Long) {
    val ctx = LocalContext.current
    val favouriteIds by vm.favouriteIds.collectAsStateWithLifecycle()

    var title by remember { mutableStateOf("PDF") }
    var pdfUri by remember { mutableStateOf<String?>(null) }
    var pool by remember { mutableStateOf<PdfRendererPool?>(null) }
    var pageAspect by remember { mutableFloatStateOf(1.414f) }
    var loading by remember { mutableStateOf(true) }
    var error by remember { mutableStateOf<String?>(null) }
    var menuOpen by remember { mutableStateOf(false) }

    // In-PDF search state
    var searchOpen by remember { mutableStateOf(false) }
    var searchQuery by remember { mutableStateOf("") }
    var pageTexts by remember { mutableStateOf<Map<Int, String>>(emptyMap()) }
    var extractProgress by remember { mutableFloatStateOf(0f) }
    var extracting by remember { mutableStateOf(false) }
    var matches by remember { mutableStateOf<List<Int>>(emptyList()) }
    var currentMatch by remember { mutableIntStateOf(0) }

    var scale by remember { mutableFloatStateOf(1f) }
    var offsetX by remember { mutableFloatStateOf(0f) }
    var offsetY by remember { mutableFloatStateOf(0f) }
    val listState = rememberLazyListState()
    val scope = rememberCoroutineScope()
    val searchFocus = remember { FocusRequester() }

    val pageCount = pool?.pageCount ?: 0
    val currentPage by remember {
        derivedStateOf {
            (listState.firstVisibleItemIndex + 1).coerceIn(1, pageCount.coerceAtLeast(1))
        }
    }

    // Open the PDF
    LaunchedEffect(noteId) {
        loading = true; error = null
        val note = withContext(Dispatchers.IO) { vm.loadNote(noteId) }
        if (note == null || note.fileType != "pdf") {
            error = "Not a PDF file"; loading = false; return@LaunchedEffect
        }
        title = note.title; pdfUri = note.uri

        val p = PdfRendererPool.open(ctx, Uri.parse(note.uri), poolSize = 3)
        if (p == null) {
            error = "Could not open the PDF.\nThe file may have been moved or deleted."
            loading = false; return@LaunchedEffect
        }
        pool = p
        pageAspect = p.firstPageAspect()
        loading = false
    }

    DisposableEffect(Unit) {
        onDispose {
            pool?.close()
        }
    }

    BackHandler {
        if (searchOpen) {
            searchOpen = false; searchQuery = ""; matches = emptyList()
        } else {
            nav.popBackStack()
        }
    }

    // Extract text on first search open (one-shot per session)
    LaunchedEffect(searchOpen) {
        if (!searchOpen) return@LaunchedEffect
        if (pageTexts.isNotEmpty()) return@LaunchedEffect
        val uri = pdfUri ?: return@LaunchedEffect
        val total = pool?.pageCount ?: return@LaunchedEffect
        if (total == 0) return@LaunchedEffect

        extracting = true; extractProgress = 0f
        val texts = withContext(Dispatchers.IO) {
            extractPdfText(ctx, Uri.parse(uri)) { done, all ->
                extractProgress = if (all > 0) done.toFloat() / all else 0f
            }
        }
        pageTexts = texts
        extracting = false
    }

    // Recompute matches when query or texts change
    LaunchedEffect(searchQuery, pageTexts) {
        val q = searchQuery.trim()
        if (q.length < 2 || pageTexts.isEmpty()) {
            matches = emptyList(); currentMatch = 0
            return@LaunchedEffect
        }
        val lc = q.lowercase()
        val hits = pageTexts.entries
            .asSequence()
            .filter { it.value.lowercase().contains(lc) }
            .map { it.key }
            .sorted()
            .toList()
        matches = hits
        currentMatch = 0
        if (hits.isNotEmpty()) {
            scope.launch { runCatching { listState.animateScrollToItem(hits[0]) } }
        }
    }

    val density = ctx.resources.displayMetrics.density
    val placeholderH = remember(pageAspect) {
        (ctx.resources.displayMetrics.widthPixels * pageAspect / density).dp
    }

    Scaffold(
        topBar = {
            if (searchOpen) {
                PdfSearchBar(
                    query = searchQuery,
                    onQueryChange = { searchQuery = it },
                    extracting = extracting,
                    extractProgress = extractProgress,
                    matchCount = matches.size,
                    currentMatch = currentMatch,
                    focusRequester = searchFocus,
                    onClose = { searchOpen = false; searchQuery = ""; matches = emptyList() },
                    onPrev = {
                        if (matches.isNotEmpty()) {
                            currentMatch = (currentMatch - 1 + matches.size) % matches.size
                            scope.launch { runCatching { listState.animateScrollToItem(matches[currentMatch]) } }
                        }
                    },
                    onNext = {
                        if (matches.isNotEmpty()) {
                            currentMatch = (currentMatch + 1) % matches.size
                            scope.launch { runCatching { listState.animateScrollToItem(matches[currentMatch]) } }
                        }
                    }
                )
                LaunchedEffect(Unit) { runCatching { searchFocus.requestFocus() } }
            } else {
                TopAppBar(
                    title = { Text(title, maxLines = 1, overflow = TextOverflow.Ellipsis) },
                    navigationIcon = {
                        IconButton(onClick = { nav.popBackStack() }) {
                            Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back")
                        }
                    },
                    actions = {
                        IconButton(onClick = { searchOpen = true }) {
                            Icon(Icons.Default.Search, contentDescription = "Search in PDF")
                        }
                        TextButton(onClick = { scale = (scale - 0.25f).coerceIn(0.5f, 4f) }) {
                            Text("\u2212", fontSize = 18.sp)
                        }
                        Text("${(scale * 100).roundToInt()}%", fontSize = 12.sp,
                            color = MaterialTheme.colorScheme.onSurfaceVariant)
                        TextButton(onClick = { scale = (scale + 0.25f).coerceIn(0.5f, 4f) }) {
                            Text("+", fontSize = 18.sp)
                        }
                        Box {
                            IconButton(onClick = { menuOpen = true }) {
                                Icon(Icons.Default.MoreVert, contentDescription = "More")
                            }
                            DropdownMenu(expanded = menuOpen, onDismissRequest = { menuOpen = false }) {
                                val isFav = noteId in favouriteIds
                                DropdownMenuItem(
                                    text = { Text(if (isFav) "\uD83D\uDC94 Remove favourite" else "\u2B50 Add favourite") },
                                    onClick = { menuOpen = false; vm.toggleFavourite(noteId) }
                                )
                                HorizontalDivider()
                                DropdownMenuItem(
                                    text = { Text("\uD83D\uDD0D Search library") },
                                    onClick = { menuOpen = false; nav.navigate("search") }
                                )
                                HorizontalDivider()
                                DropdownMenuItem(
                                    text = { Text("\uD83D\uDCE4 Share PDF") },
                                    onClick = { menuOpen = false; sharePdf(ctx, pdfUri, title) }
                                )
                                DropdownMenuItem(
                                    text = { Text("\uD83C\uDF10 Open externally") },
                                    onClick = { menuOpen = false; openPdfExternally(ctx, pdfUri) }
                                )
                                HorizontalDivider()
                                DropdownMenuItem(
                                    text = { Text("\uD83D\uDD04 Reset zoom") },
                                    onClick = { menuOpen = false; scale = 1f; offsetX = 0f; offsetY = 0f }
                                )
                            }
                        }
                    }
                )
            }
        }
    ) { pad ->
        Box(Modifier.padding(pad).fillMaxSize().background(Color(0xFF0A0A0A))) {
            when {
                loading -> CenteredStatus("\u23F3 Opening PDF\u2026")
                error != null -> CenteredStatus("\u26A0\uFE0F $error")
                pool != null -> {
                    PageScrollContainer(
                        pool = pool!!,
                        listState = listState,
                        placeholderHeight = placeholderH,
                        scale = scale, onScale = { scale = it },
                        offsetX = offsetX, onOffsetX = { offsetX = it },
                        offsetY = offsetY, onOffsetY = { offsetY = it },
                        matchPages = matches.toSet()
                    )
                    if (pageCount > 0) {
                        PageChip(currentPage, pageCount, Modifier.align(Alignment.BottomCenter))
                    }
                }
            }
        }
    }
}

/* ════════════════════════════════════════════════════════════════════════
 *  PdfViewerStandalone — external PDF activity (no DB, no nav)
 * ════════════════════════════════════════════════════════════════════════ */

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun PdfViewerStandalone(uri: Uri?, titleHint: String, onClose: () -> Unit) {
    val ctx = LocalContext.current

    var title by remember { mutableStateOf(titleHint) }
    var pool by remember { mutableStateOf<PdfRendererPool?>(null) }
    var pageAspect by remember { mutableFloatStateOf(1.414f) }
    var loading by remember { mutableStateOf(true) }
    var error by remember { mutableStateOf<String?>(null) }
    var menuOpen by remember { mutableStateOf(false) }

    var searchOpen by remember { mutableStateOf(false) }
    var searchQuery by remember { mutableStateOf("") }
    var pageTexts by remember { mutableStateOf<Map<Int, String>>(emptyMap()) }
    var extractProgress by remember { mutableFloatStateOf(0f) }
    var extracting by remember { mutableStateOf(false) }
    var matches by remember { mutableStateOf<List<Int>>(emptyList()) }
    var currentMatch by remember { mutableIntStateOf(0) }

    var scale by remember { mutableFloatStateOf(1f) }
    var offsetX by remember { mutableFloatStateOf(0f) }
    var offsetY by remember { mutableFloatStateOf(0f) }
    val listState = rememberLazyListState()
    val scope = rememberCoroutineScope()
    val searchFocus = remember { FocusRequester() }

    val pageCount = pool?.pageCount ?: 0
    val currentPage by remember {
        derivedStateOf {
            (listState.firstVisibleItemIndex + 1).coerceIn(1, pageCount.coerceAtLeast(1))
        }
    }

    LaunchedEffect(uri) {
        loading = true; error = null
        if (uri == null) { error = "No file was provided."; loading = false; return@LaunchedEffect }
        val p = PdfRendererPool.open(ctx, uri, poolSize = 3)
        if (p == null) { error = "Could not open this PDF."; loading = false; return@LaunchedEffect }
        pool = p
        pageAspect = p.firstPageAspect()
        loading = false
    }

    DisposableEffect(Unit) { onDispose { pool?.close() } }

    BackHandler {
        if (searchOpen) { searchOpen = false; searchQuery = ""; matches = emptyList() }
        else onClose()
    }

    LaunchedEffect(searchOpen) {
        if (!searchOpen) return@LaunchedEffect
        if (pageTexts.isNotEmpty()) return@LaunchedEffect
        val u = uri ?: return@LaunchedEffect
        val total = pool?.pageCount ?: return@LaunchedEffect
        if (total == 0) return@LaunchedEffect
        extracting = true; extractProgress = 0f
        val texts = withContext(Dispatchers.IO) {
            extractPdfText(ctx, u) { done, all ->
                extractProgress = if (all > 0) done.toFloat() / all else 0f
            }
        }
        pageTexts = texts
        extracting = false
    }

    LaunchedEffect(searchQuery, pageTexts) {
        val q = searchQuery.trim()
        if (q.length < 2 || pageTexts.isEmpty()) {
            matches = emptyList(); currentMatch = 0
            return@LaunchedEffect
        }
        val lc = q.lowercase()
        val hits = pageTexts.entries.asSequence()
            .filter { it.value.lowercase().contains(lc) }
            .map { it.key }.sorted().toList()
        matches = hits; currentMatch = 0
        if (hits.isNotEmpty()) scope.launch { runCatching { listState.animateScrollToItem(hits[0]) } }
    }

    val density = ctx.resources.displayMetrics.density
    val placeholderH = remember(pageAspect) {
        (ctx.resources.displayMetrics.widthPixels * pageAspect / density).dp
    }

    Scaffold(
        topBar = {
            if (searchOpen) {
                PdfSearchBar(
                    query = searchQuery, onQueryChange = { searchQuery = it },
                    extracting = extracting, extractProgress = extractProgress,
                    matchCount = matches.size, currentMatch = currentMatch,
                    focusRequester = searchFocus,
                    onClose = { searchOpen = false; searchQuery = ""; matches = emptyList() },
                    onPrev = {
                        if (matches.isNotEmpty()) {
                            currentMatch = (currentMatch - 1 + matches.size) % matches.size
                            scope.launch { runCatching { listState.animateScrollToItem(matches[currentMatch]) } }
                        }
                    },
                    onNext = {
                        if (matches.isNotEmpty()) {
                            currentMatch = (currentMatch + 1) % matches.size
                            scope.launch { runCatching { listState.animateScrollToItem(matches[currentMatch]) } }
                        }
                    }
                )
                LaunchedEffect(Unit) { runCatching { searchFocus.requestFocus() } }
            } else {
                TopAppBar(
                    title = { Text(title, maxLines = 1, overflow = TextOverflow.Ellipsis) },
                    navigationIcon = {
                        IconButton(onClick = onClose) {
                            Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Close")
                        }
                    },
                    actions = {
                        IconButton(onClick = { searchOpen = true }) {
                            Icon(Icons.Default.Search, contentDescription = "Search in PDF")
                        }
                        TextButton(onClick = { scale = (scale - 0.25f).coerceIn(0.5f, 4f) }) {
                            Text("\u2212", fontSize = 18.sp)
                        }
                        Text("${(scale * 100).roundToInt()}%", fontSize = 12.sp,
                            color = MaterialTheme.colorScheme.onSurfaceVariant)
                        TextButton(onClick = { scale = (scale + 0.25f).coerceIn(0.5f, 4f) }) {
                            Text("+", fontSize = 18.sp)
                        }
                        Box {
                            IconButton(onClick = { menuOpen = true }) {
                                Icon(Icons.Default.MoreVert, contentDescription = "More")
                            }
                            DropdownMenu(expanded = menuOpen, onDismissRequest = { menuOpen = false }) {
                                DropdownMenuItem(
                                    text = { Text("\uD83D\uDCE4 Share PDF") },
                                    onClick = { menuOpen = false; sharePdf(ctx, uri?.toString(), title) }
                                )
                                DropdownMenuItem(
                                    text = { Text("\uD83C\uDF10 Open externally") },
                                    onClick = { menuOpen = false; openPdfExternally(ctx, uri?.toString()) }
                                )
                                HorizontalDivider()
                                DropdownMenuItem(
                                    text = { Text("\uD83D\uDD04 Reset zoom") },
                                    onClick = { menuOpen = false; scale = 1f; offsetX = 0f; offsetY = 0f }
                                )
                            }
                        }
                    }
                )
            }
        }
    ) { pad ->
        Box(Modifier.padding(pad).fillMaxSize().background(Color(0xFF0A0A0A))) {
            when {
                loading -> CenteredStatus("\u23F3 Opening PDF\u2026")
                error != null -> CenteredStatus("\u26A0\uFE0F $error")
                pool != null -> {
                    PageScrollContainer(
                        pool = pool!!, listState = listState, placeholderHeight = placeholderH,
                        scale = scale, onScale = { scale = it },
                        offsetX = offsetX, onOffsetX = { offsetX = it },
                        offsetY = offsetY, onOffsetY = { offsetY = it },
                        matchPages = matches.toSet()
                    )
                    if (pageCount > 0) PageChip(currentPage, pageCount, Modifier.align(Alignment.BottomCenter))
                }
            }
        }
    }
}

/* ════════════════════════════════════════════════════════════════════════
 *  Shared composables
 * ════════════════════════════════════════════════════════════════════════ */

@Composable
private fun PageScrollContainer(
    pool: PdfRendererPool,
    listState: LazyListState,
    placeholderHeight: Dp,
    scale: Float, onScale: (Float) -> Unit,
    offsetX: Float, onOffsetX: (Float) -> Unit,
    offsetY: Float, onOffsetY: (Float) -> Unit,
    matchPages: Set<Int>
) {
    val ctx = LocalContext.current
    val screenWidth = ctx.resources.displayMetrics.widthPixels

    Box(
        Modifier.fillMaxSize()
            .pointerInput(Unit) {
                detectTransformGestures { _, pan, zoom, _ ->
                    val ns = (scale * zoom).coerceIn(0.5f, 4f)
                    if (ns > 1f) { onOffsetX(offsetX + pan.x); onOffsetY(offsetY + pan.y) }
                    else { onOffsetX(0f); onOffsetY(0f) }
                    onScale(ns)
                }
            }
            .pointerInput(Unit) {
                detectTapGestures(onDoubleTap = {
                    if (scale > 1.1f) { onScale(1f); onOffsetX(0f); onOffsetY(0f) }
                    else onScale(2f)
                })
            }
    ) {
        LazyColumn(
            state = listState,
            modifier = Modifier.fillMaxSize().graphicsLayer(
                scaleX = scale, scaleY = scale,
                translationX = offsetX, translationY = offsetY
            ),
            verticalArrangement = Arrangement.spacedBy(4.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            items(pool.pageCount) { index ->
                PdfPageItem(
                    pool = pool,
                    pageIndex = index,
                    targetWidth = screenWidth,
                    placeholderHeight = placeholderHeight,
                    highlight = index in matchPages
                )
            }
            item { Spacer(Modifier.height(80.dp)) }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun PdfSearchBar(
    query: String,
    onQueryChange: (String) -> Unit,
    extracting: Boolean,
    extractProgress: Float,
    matchCount: Int,
    currentMatch: Int,
    focusRequester: FocusRequester,
    onClose: () -> Unit,
    onPrev: () -> Unit,
    onNext: () -> Unit
) {
    Column {
        TopAppBar(
            title = {
                TextField(
                    value = query,
                    onValueChange = onQueryChange,
                    placeholder = { Text("Search in PDF\u2026", fontSize = 14.sp) },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth().focusRequester(focusRequester),
                    keyboardOptions = KeyboardOptions(imeAction = ImeAction.Search),
                    colors = TextFieldDefaults.colors(
                        focusedContainerColor = Color.Transparent,
                        unfocusedContainerColor = Color.Transparent
                    )
                )
            },
            navigationIcon = {
                IconButton(onClick = onClose) {
                    Icon(Icons.Default.Close, contentDescription = "Close search")
                }
            },
            actions = {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    if (extracting) {
                        Text(
                            "${(extractProgress * 100).toInt()}%",
                            fontSize = 11.sp,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                            modifier = Modifier.padding(end = 6.dp)
                        )
                    } else if (query.trim().length >= 2) {
                        Text(
                            if (matchCount > 0) "${currentMatch + 1}/$matchCount" else "0/0",
                            fontSize = 12.sp,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                            modifier = Modifier.padding(end = 4.dp)
                        )
                        IconButton(onClick = onPrev) {
                            Icon(Icons.Default.KeyboardArrowUp, contentDescription = "Previous match")
                        }
                        IconButton(onClick = onNext) {
                            Icon(Icons.Default.KeyboardArrowDown, contentDescription = "Next match")
                        }
                    }
                    Spacer(Modifier.width(4.dp))
                }
            }
        )
        if (extracting) {
            LinearProgressIndicator(
                progress = { extractProgress },
                modifier = Modifier.fillMaxWidth()
            )
        }
    }
}

@Composable
private fun CenteredStatus(msg: String) {
    Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
        Text(msg, color = MaterialTheme.colorScheme.onSurfaceVariant,
            fontSize = 14.sp, lineHeight = 20.sp)
    }
}

@Composable
private fun PageChip(current: Int, total: Int, modifier: Modifier) {
    Surface(
        modifier = modifier.padding(bottom = 20.dp),
        color = Color(0xCC1A1A1A),
        shape = RoundedCornerShape(20.dp)
    ) {
        Text(
            "\uD83D\uDCC4 $current / $total",
            Modifier.padding(horizontal = 16.dp, vertical = 8.dp),
            fontSize = 13.sp, fontWeight = FontWeight.Medium, color = Color(0xFFCCCCCC)
        )
    }
}

/* ════════════════════════════════════════════════════════════════════════
 *  Text extraction via PdfBox-Android
 * ════════════════════════════════════════════════════════════════════════ */

/**
 * Extract per-page text from a PDF. Returns a map of pageIndex (0-based) → text.
 * Progress callback fires per page.
 */
private suspend fun extractPdfText(
    ctx: Context,
    uri: Uri,
    onProgress: (done: Int, total: Int) -> Unit
): Map<Int, String> = withContext(Dispatchers.IO) {
    val result = mutableMapOf<Int, String>()
    try {
        ctx.contentResolver.openInputStream(uri)?.use { input ->
            PDDocument.load(input).use { doc ->
                val total = doc.numberOfPages
                val stripper = PDFTextStripper()
                for (i in 1..total) {
                    try {
                        stripper.startPage = i
                        stripper.endPage = i
                        val text = stripper.getText(doc) ?: ""
                        result[i - 1] = text
                    } catch (e: Exception) {
                        Log.w(TAG, "text extraction failed at page $i", e)
                        result[i - 1] = ""
                    }
                    onProgress(i, total)
                }
            }
        }
    } catch (e: Exception) {
        Log.e(TAG, "extractPdfText failed", e)
    }
    result
}

/* ════════════════════════════════════════════════════════════════════════
 *  Share / open helpers
 * ════════════════════════════════════════════════════════════════════════ */

private fun sharePdf(ctx: Context, uriString: String?, title: String) {
    if (uriString == null) {
        Toast.makeText(ctx, "PDF URI not available", Toast.LENGTH_SHORT).show(); return
    }
    try {
        val intent = Intent(Intent.ACTION_SEND).apply {
            type = "application/pdf"
            putExtra(Intent.EXTRA_STREAM, Uri.parse(uriString))
            putExtra(Intent.EXTRA_SUBJECT, title)
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        }
        ctx.startActivity(Intent.createChooser(intent, "Share PDF"))
    } catch (e: Exception) {
        Toast.makeText(ctx, "Could not share: ${e.message}", Toast.LENGTH_SHORT).show()
    }
}

private fun openPdfExternally(ctx: Context, uriString: String?) {
    if (uriString == null) {
        Toast.makeText(ctx, "PDF URI not available", Toast.LENGTH_SHORT).show(); return
    }
    try {
        val intent = Intent(Intent.ACTION_VIEW).apply {
            setDataAndType(Uri.parse(uriString), "application/pdf")
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_ACTIVITY_NEW_TASK)
        }
        ctx.startActivity(intent)
    } catch (e: Exception) {
        Toast.makeText(ctx, "No app can open this PDF", Toast.LENGTH_SHORT).show()
    }
}
