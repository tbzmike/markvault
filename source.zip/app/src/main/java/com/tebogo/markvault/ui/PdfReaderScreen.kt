package com.tebogo.markvault.ui

import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.pdf.PdfRenderer
import android.net.Uri
import android.widget.Toast
import androidx.activity.compose.BackHandler
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.gestures.detectTransformGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.MoreVert
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.derivedStateOf
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.navigation.NavController
import com.tebogo.markvault.AppViewModel
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import kotlin.math.roundToInt

/**
 * Full-screen PDF viewer using Android's native PdfRenderer.
 * Pages are rendered as bitmaps into a vertical scrolling list.
 * Supports pinch-to-zoom, page indicator, and share/open actions.
 */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun PdfReaderScreen(
    vm: AppViewModel,
    nav: NavController,
    noteId: Long
) {
    val ctx = LocalContext.current
    val favouriteIds by vm.favouriteIds.collectAsStateWithLifecycle()

    var title by remember { mutableStateOf("PDF") }
    var pdfUri by remember { mutableStateOf<String?>(null) }
    var renderer by remember { mutableStateOf<PdfRenderer?>(null) }
    var pageCount by remember { mutableIntStateOf(0) }
    var pages by remember { mutableStateOf<List<Bitmap>>(emptyList()) }
    var loading by remember { mutableStateOf(true) }
    var error by remember { mutableStateOf<String?>(null) }
    var menuOpen by remember { mutableStateOf(false) }

    // Zoom state
    var scale by remember { mutableFloatStateOf(1f) }
    var offsetX by remember { mutableFloatStateOf(0f) }
    var offsetY by remember { mutableFloatStateOf(0f) }

    val listState = rememberLazyListState()

    // Current visible page (1-indexed)
    val currentPage by remember {
        derivedStateOf {
            val first = listState.firstVisibleItemIndex + 1
            first.coerceIn(1, pageCount.coerceAtLeast(1))
        }
    }

    // Load the PDF
    LaunchedEffect(noteId) {
        loading = true
        error = null
        try {
            val note = withContext(Dispatchers.IO) { vm.loadNote(noteId) }
            if (note == null || note.fileType != "pdf") {
                error = "Not a PDF file"
                loading = false
                return@LaunchedEffect
            }
            title = note.title
            pdfUri = note.uri

            val bitmaps = withContext(Dispatchers.IO) {
                renderPdfPages(ctx, note.uri)
            }
            if (bitmaps == null) {
                error = "Could not open the PDF. The file may have been moved or deleted."
                loading = false
                return@LaunchedEffect
            }
            pages = bitmaps.first
            pageCount = bitmaps.second
            renderer = bitmaps.third
        } catch (e: Exception) {
            error = "Failed to load PDF: ${e.message ?: e.javaClass.simpleName}"
        }
        loading = false
    }

    // Clean up renderer on exit
    DisposableEffect(Unit) {
        onDispose {
            renderer?.close()
        }
    }

    BackHandler { nav.popBackStack() }

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Text(
                        title,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                },
                navigationIcon = {
                    IconButton(onClick = { nav.popBackStack() }) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back")
                    }
                },
                actions = {
                    // Zoom controls
                    TextButton(onClick = { scale = (scale - 0.25f).coerceIn(0.5f, 4f) }) {
                        Text("\u2212", fontSize = 18.sp)
                    }
                    Text(
                        "${(scale * 100).roundToInt()}%",
                        fontSize = 12.sp,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                    TextButton(onClick = { scale = (scale + 0.25f).coerceIn(0.5f, 4f) }) {
                        Text("+", fontSize = 18.sp)
                    }
                    Box {
                        IconButton(onClick = { menuOpen = true }) {
                            Icon(Icons.Default.MoreVert, contentDescription = "More")
                        }
                        DropdownMenu(expanded = menuOpen, onDismissRequest = { menuOpen = false }) {
                            val isFav = noteId in favouriteIds
                            DropdownMenuItem(
                                text = { Text(if (isFav) "\uD83D\uDC94 Remove from favourites" else "\u2B50 Add to favourites") },
                                onClick = {
                                    menuOpen = false
                                    vm.toggleFavourite(noteId)
                                }
                            )
                            HorizontalDivider()
                            DropdownMenuItem(
                                text = { Text("\uD83D\uDCE4 Share PDF") },
                                onClick = {
                                    menuOpen = false
                                    sharePdf(ctx, pdfUri, title)
                                }
                            )
                            DropdownMenuItem(
                                text = { Text("\uD83C\uDF10 Open in external app") },
                                onClick = {
                                    menuOpen = false
                                    openPdfExternally(ctx, pdfUri)
                                }
                            )
                            HorizontalDivider()
                            DropdownMenuItem(
                                text = { Text("\uD83D\uDD04 Reset zoom") },
                                onClick = {
                                    menuOpen = false
                                    scale = 1f
                                    offsetX = 0f
                                    offsetY = 0f
                                }
                            )
                        }
                    }
                }
            )
        }
    ) { pad ->
        Box(
            Modifier
                .padding(pad)
                .fillMaxSize()
                .background(Color(0xFF0A0A0A))
        ) {
            when {
                loading -> {
                    Column(
                        Modifier.fillMaxSize(),
                        verticalArrangement = Arrangement.Center,
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        CircularProgressIndicator(
                            color = MaterialTheme.colorScheme.primary,
                            modifier = Modifier.size(42.dp)
                        )
                        Spacer(Modifier.height(16.dp))
                        Text(
                            "Loading PDF\u2026",
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                            fontSize = 14.sp
                        )
                    }
                }
                error != null -> {
                    Column(
                        Modifier.fillMaxSize().padding(32.dp),
                        verticalArrangement = Arrangement.Center,
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Text("\u26A0\uFE0F", fontSize = 48.sp)
                        Spacer(Modifier.height(16.dp))
                        Text(
                            error!!,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                            fontSize = 14.sp,
                            lineHeight = 20.sp
                        )
                    }
                }
                else -> {
                    // PDF pages — zoomable continuous scroll
                    Box(
                        Modifier
                            .fillMaxSize()
                            .pointerInput(Unit) {
                                detectTransformGestures { _, pan, zoom, _ ->
                                    val newScale = (scale * zoom).coerceIn(0.5f, 4f)
                                    // Only allow panning when zoomed in
                                    if (newScale > 1f) {
                                        offsetX += pan.x
                                        offsetY += pan.y
                                    } else {
                                        offsetX = 0f
                                        offsetY = 0f
                                    }
                                    scale = newScale
                                }
                            }
                            .pointerInput(Unit) {
                                detectTapGestures(
                                    onDoubleTap = {
                                        if (scale > 1.1f) {
                                            scale = 1f
                                            offsetX = 0f
                                            offsetY = 0f
                                        } else {
                                            scale = 2f
                                        }
                                    }
                                )
                            }
                    ) {
                        LazyColumn(
                            state = listState,
                            modifier = Modifier
                                .fillMaxSize()
                                .graphicsLayer(
                                    scaleX = scale,
                                    scaleY = scale,
                                    translationX = offsetX,
                                    translationY = offsetY
                                ),
                            verticalArrangement = Arrangement.spacedBy(4.dp),
                            horizontalAlignment = Alignment.CenterHorizontally
                        ) {
                            items(pages.size) { index ->
                                val bitmap = pages[index]
                                Image(
                                    bitmap = bitmap.asImageBitmap(),
                                    contentDescription = "Page ${index + 1}",
                                    contentScale = ContentScale.FillWidth,
                                    modifier = Modifier.fillMaxWidth()
                                )
                            }
                            item { Spacer(Modifier.height(80.dp)) }
                        }
                    }

                    // Page indicator chip — bottom center
                    if (pageCount > 0) {
                        Surface(
                            modifier = Modifier
                                .align(Alignment.BottomCenter)
                                .padding(bottom = 20.dp),
                            color = Color(0xCC1A1A1A),
                            shape = RoundedCornerShape(20.dp)
                        ) {
                            Text(
                                "\uD83D\uDCC4 $currentPage / $pageCount",
                                modifier = Modifier.padding(horizontal = 16.dp, vertical = 8.dp),
                                fontSize = 13.sp,
                                fontWeight = FontWeight.Medium,
                                color = Color(0xFFCCCCCC)
                            )
                        }
                    }
                }
            }
        }
    }
}

/**
 * Render all pages of a PDF into bitmaps at screen-appropriate resolution.
 * Returns the list of bitmaps, page count, and the renderer (caller must close).
 */
private fun renderPdfPages(
    ctx: Context,
    uriString: String
): Triple<List<Bitmap>, Int, PdfRenderer>? {
    return try {
        val uri = Uri.parse(uriString)
        val pfd = ctx.contentResolver.openFileDescriptor(uri, "r") ?: return null
        val renderer = PdfRenderer(pfd)
        val count = renderer.pageCount
        val displayMetrics = ctx.resources.displayMetrics
        val targetWidth = displayMetrics.widthPixels

        val bitmaps = ArrayList<Bitmap>(count)
        for (i in 0 until count) {
            val page = renderer.openPage(i)
            // Scale to fill screen width while keeping aspect ratio
            val ratio = targetWidth.toFloat() / page.width
            val height = (page.height * ratio).toInt()
            val bitmap = Bitmap.createBitmap(targetWidth, height, Bitmap.Config.ARGB_8888)
            // White background for pages
            bitmap.eraseColor(android.graphics.Color.WHITE)
            page.render(bitmap, null, null, PdfRenderer.Page.RENDER_MODE_FOR_DISPLAY)
            page.close()
            bitmaps.add(bitmap)
        }
        Triple(bitmaps, count, renderer)
    } catch (e: Exception) {
        null
    }
}

private fun sharePdf(ctx: Context, uriString: String?, title: String) {
    if (uriString == null) {
        Toast.makeText(ctx, "PDF URI not available", Toast.LENGTH_SHORT).show()
        return
    }
    try {
        val uri = Uri.parse(uriString)
        val intent = Intent(Intent.ACTION_SEND).apply {
            type = "application/pdf"
            putExtra(Intent.EXTRA_STREAM, uri)
            putExtra(Intent.EXTRA_SUBJECT, title)
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        }
        ctx.startActivity(Intent.createChooser(intent, "Share PDF"))
    } catch (e: Exception) {
        Toast.makeText(ctx, "Could not share: ${e.message}", Toast.LENGTH_SHORT).show()
    }
}

private fun openPdfExternally(ctx: Context, uriString: String?) {
    if (uriString == null) {
        Toast.makeText(ctx, "PDF URI not available", Toast.LENGTH_SHORT).show()
        return
    }
    try {
        val uri = Uri.parse(uriString)
        val intent = Intent(Intent.ACTION_VIEW).apply {
            setDataAndType(uri, "application/pdf")
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_ACTIVITY_NEW_TASK)
        }
        ctx.startActivity(intent)
    } catch (e: Exception) {
        Toast.makeText(ctx, "No app can open this PDF", Toast.LENGTH_SHORT).show()
    }
}
