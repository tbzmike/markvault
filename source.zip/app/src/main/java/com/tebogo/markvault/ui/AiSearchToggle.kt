package com.tebogo.markvault.ui

import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.foundation.layout.Row
import androidx.compose.runtime.*
import com.tebogo.markvault.ai.AiRetrievalPreference

@Composable
fun AiSearchToggle() {
    var enabled by remember { mutableStateOf(AiRetrievalPreference.isEnabled()) }

    Row {
        Text("AI Search")
        Switch(
            checked = enabled,
            onCheckedChange = {
                enabled = it
                AiRetrievalPreference.setEnabled(it)
            }
        )
    }
}
