package com.tebogo.markvault.ui

import androidx.compose.foundation.layout.Row
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import com.tebogo.markvault.ai.AiRetrievalPreference

@Composable
fun AiSearchToggle() {
    var enabled by remember { mutableStateOf(AiRetrievalPreference.isEnabled()) }

    Row {
        Text("AI")
        Switch(
            checked = enabled,
            onCheckedChange = { value ->
                enabled = value
                AiRetrievalPreference.setEnabled(value)
            }
        )
    }
}
