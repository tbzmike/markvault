package com.tebogo.markvault.ui

import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.foundation.layout.Row
import androidx.compose.runtime.*
import androidx.compose.ui.platform.LocalContext
import com.tebogo.markvault.ai.AiRetrievalPreference
import com.tebogo.markvault.ai.AiPreferenceStore
import kotlinx.coroutines.launch

@Composable
fun AiSearchToggle() {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()

    var enabled by remember { mutableStateOf(true) }

    LaunchedEffect(Unit) {
        enabled = AiPreferenceStore.loadEnabled(context)
        AiRetrievalPreference.setEnabled(enabled)
    }

    Row {
        Text("AI Search")
        Switch(
            checked = enabled,
            onCheckedChange = {
                enabled = it
                AiRetrievalPreference.setEnabled(it)
                scope.launch {
                    AiPreferenceStore.saveEnabled(context, it)
                }
            }
        )
    }
}
