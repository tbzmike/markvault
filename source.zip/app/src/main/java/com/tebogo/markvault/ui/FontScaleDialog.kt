package com.tebogo.markvault.ui

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Slider
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.tebogo.markvault.AppViewModel

/**
 * v4.16.0 — Global text-size adjustment dialog.
 *
 * Reachable from the toolbar overflow menu on every screen. Edits the same
 * `Prefs.fontScale` value that the Settings → Reading font size slider uses;
 * the two stay in sync automatically because they're both bound to the same
 * StateFlow.
 *
 * Effect: every Compose `Text` in the app re-renders at the new size,
 * because `MarkVaultTheme` provides a scaled `LocalDensity`. The markdown
 * reader's WebView also picks the same value up through its existing
 * `renderMarkdown(content, fontScale, ...)` JS call.
 *
 * Range: 0.7× to 1.5×, capped defensively in `MarkVaultTheme`. Step of
 * 0.05× via A−/A+. Reset returns to 1.0×.
 */
@Composable
fun FontScaleDialog(vm: AppViewModel, onDismiss: () -> Unit) {
    val current by vm.fontScale.collectAsStateWithLifecycle()
    val safe = current.coerceIn(0.7f, 1.5f)
    val pct = (safe * 100f).toInt()

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("\uD83D\uDD20 Text size") },
        text = {
            Column(Modifier.fillMaxWidth()) {
                Text(
                    "Current size: ${pct}%",
                    fontSize = 14.sp,
                    fontWeight = FontWeight.Medium,
                    color = MaterialTheme.colorScheme.primary
                )
                Spacer(Modifier.height(4.dp))
                Text(
                    "This setting affects every screen in MarkVault — menus, lists, articles, settings — everything.",
                    fontSize = 12.sp,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
                Spacer(Modifier.height(16.dp))

                // ── Quick A−/Reset/A+ row ────────────────────────────────────
                Row(
                    Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    OutlinedButton(
                        onClick = {
                            val next = (safe - 0.05f).coerceAtLeast(0.7f)
                            vm.setFontScale(next)
                        },
                        modifier = Modifier.fillMaxWidth().weight(1f)
                    ) { Text("A−", fontSize = 16.sp) }
                    OutlinedButton(
                        onClick = { vm.setFontScale(1.0f) },
                        modifier = Modifier.fillMaxWidth().weight(1f)
                    ) { Text("Reset", fontSize = 13.sp) }
                    OutlinedButton(
                        onClick = {
                            val next = (safe + 0.05f).coerceAtMost(1.5f)
                            vm.setFontScale(next)
                        },
                        modifier = Modifier.fillMaxWidth().weight(1f)
                    ) { Text("A+", fontSize = 18.sp, fontWeight = FontWeight.Bold) }
                }

                Spacer(Modifier.height(16.dp))

                // ── Slider for fine control ───────────────────────────────────
                Text(
                    "Drag to adjust precisely",
                    fontSize = 12.sp,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
                Slider(
                    value = safe,
                    onValueChange = { vm.setFontScale(it) },
                    valueRange = 0.7f..1.5f,
                    // 16 discrete stops between 0.7 and 1.5 (steps of 0.05).
                    // The Material slider's `steps` count excludes endpoints,
                    // so 15 = 16 stops total.
                    steps = 15
                )

                Spacer(Modifier.height(12.dp))
                // ── Live preview ──────────────────────────────────────────────
                // This Text doesn't multiply by fontScale itself — the
                // LocalDensity override in MarkVaultTheme already does that
                // globally, so it reflects the change immediately as the
                // user drags the slider.
                Text(
                    "Sample text at current size",
                    fontSize = 16.sp,
                    color = MaterialTheme.colorScheme.onSurface
                )
            }
        },
        confirmButton = { TextButton(onClick = onDismiss) { Text("Done") } }
    )
}
