package com.tebogo.markvault.ai

/** Stores last T5 validation result for diagnostics. */
object T5ValidationLog {
    private var lastResult = false

    fun update(result: Boolean) {
        lastResult = result
    }

    fun passed(): Boolean = lastResult
}
