package com.tebogo.markvault.ai

/** Final safety hooks for T5 model execution. */
object T5ValidationHooks {
    fun validateModel(files: Set<String>): Boolean {
        return files.contains("model.tflite") &&
               files.contains("tokenizer.json") &&
               files.contains("config.json")
    }

    fun handleCorruptModel(): String {
        return "T5 model unavailable, using built-in expansion"
    }
}
