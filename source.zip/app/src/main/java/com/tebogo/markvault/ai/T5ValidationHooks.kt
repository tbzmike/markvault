package com.tebogo.markvault.ai

/** Final safety hooks for T5 model execution. */
object T5ValidationHooks {
    fun validateModel(files: Set<String>): Boolean {
        return T5ModelFileRegistry.missingFiles(files).isEmpty()
    }

    fun handleCorruptModel(): String {
        return "T5 model unavailable, using built-in expansion"
    }
}
