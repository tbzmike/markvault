package com.tebogo.markvault.network

import com.tebogo.markvault.data.MediaItem
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONObject

/**
 * v5.4.244cc — Finds the actual playable video/audio inside a shared web
 * page, rather than guessing at it via search.
 *
 * Previously, sharing a JW.org article/video PAGE (not a direct .mp4/.mp3
 * link) into MarkVault took the URL's slug, ran it through a fuzzy title
 * search, and hoped a similarly-titled video existed elsewhere in the
 * library. That's a weak proxy — it often found nothing for the exact
 * page that was shared, and silently gave up.
 *
 * This fetches the page's actual HTML and looks for the real embedded
 * media, in order of reliability:
 *   1. Native `<video>`/`<audio>` tags with a direct src (or nested
 *      `<source src>`) — the most reliable signal; no guessing at all.
 *   2. JW.org's custom player `data-json-src` attribute — points at a
 *      per-article JSON manifest with the real file list. Fetched and
 *      parsed the same way JwMediaApi parses category/search results
 *      (`progressiveDownloadURL` field, verified in v5.4.231cc).
 *   3. `data-mediaid`/`data-video-mediaid` — a JW.org natural key with no
 *      direct file/manifest URL on the page itself. No verified endpoint
 *      exists for resolving one item by key alone, so this is recorded
 *      but not resolved directly here.
 *   4. Any raw .mp4/.m4v/.webm/.mp3/.m4a/.ogg URL appearing anywhere in
 *      the page's HTML — a broad net that catches CDN URLs sitting in
 *      inline scripts/JSON even outside a clean <video> tag.
 *
 * Only falls back to search (in AppViewModel.resolveMediaInfoOnly) if
 * ALL of these come back empty.
 */
object PageMediaResolver {

    private const val TIMEOUT = 15_000

    /** Fetch [pageUrl] and find the real playable media inside it, or null. */
    suspend fun resolve(pageUrl: String): MediaItem? = withContext(Dispatchers.IO) {
        val html = fetchHtml(pageUrl) ?: return@withContext null
        val title = extractTitle(html) ?: pageUrl.substringAfterLast('/').replace(Regex("[-_]+"), " ")

        // 1. Native <video>/<audio> tags.
        directTagSrc(html)?.let { (url, kind) ->
            return@withContext MediaItem(title = title, streamUrl = url, mediaType = kind)
        }

        // 2. JW.org data-json-src manifest.
        jsonSrcMedia(html, title)?.let { return@withContext it }

        // 4. Broad raw-URL scan (step 3, data-mediaid alone, has no direct
        // resolution path — skipped, falls through to the caller's search
        // fallback instead).
        rawMediaUrl(html)?.let { (url, kind) ->
            return@withContext MediaItem(title = title, streamUrl = url, mediaType = kind)
        }

        null
    }

    private fun fetchHtml(url: String): String? = try {
        val conn = java.net.URL(url).openConnection() as java.net.HttpURLConnection
        conn.connectTimeout = TIMEOUT
        conn.readTimeout = TIMEOUT
        conn.instanceFollowRedirects = true
        conn.setRequestProperty("Accept", "text/html,*/*")
        conn.setRequestProperty(
            "User-Agent",
            "Mozilla/5.0 (Linux; Android 13) AppleWebKit/537.36 " +
                "(KHTML, like Gecko) Chrome/120.0.0.0 Mobile Safari/537.36"
        )
        if (conn.responseCode == 200) conn.inputStream.bufferedReader().readText() else null
    } catch (_: Exception) { null }

    private fun fetchText(url: String): String? = fetchHtml(url)

    private val titleRegex = Regex("<title[^>]*>([^<]+)</title>", RegexOption.IGNORE_CASE)
    private val ogTitleRegex = Regex(
        """<meta[^>]+property=["']og:title["'][^>]+content=["']([^"']+)["']""",
        RegexOption.IGNORE_CASE
    )

    private fun extractTitle(html: String): String? =
        ogTitleRegex.find(html)?.groupValues?.get(1)?.trim()?.ifBlank { null }
            ?: titleRegex.find(html)?.groupValues?.get(1)?.trim()?.ifBlank { null }

    // <video src="..."> or <video>...<source src="...">...</video>
    // <audio src="..."> or <audio>...<source src="...">...</audio>
    private val videoBlockRegex = Regex(
        "<video\\b[^>]*>.*?</video>|<video\\b[^>]*/?>",
        setOf(RegexOption.IGNORE_CASE, RegexOption.DOT_MATCHES_ALL)
    )
    private val audioBlockRegex = Regex(
        "<audio\\b[^>]*>.*?</audio>|<audio\\b[^>]*/?>",
        setOf(RegexOption.IGNORE_CASE, RegexOption.DOT_MATCHES_ALL)
    )
    private val srcAttrRegex = Regex("""\bsrc=["']([^"']+)["']""", RegexOption.IGNORE_CASE)

    private fun directTagSrc(html: String): Pair<String, String>? {
        videoBlockRegex.find(html)?.value?.let { block ->
            srcAttrRegex.find(block)?.groupValues?.get(1)?.takeIf { it.isNotBlank() }
                ?.let { return it to "video" }
        }
        audioBlockRegex.find(html)?.value?.let { block ->
            srcAttrRegex.find(block)?.groupValues?.get(1)?.takeIf { it.isNotBlank() }
                ?.let { return it to "audio" }
        }
        return null
    }

    private val jsonSrcRegex = Regex("""data-json-src=["']([^"']+)["']""", RegexOption.IGNORE_CASE)

    /**
     * JW.org's custom player embeds a `data-json-src` pointing at a
     * per-article JSON manifest for that exact video/audio. Fetches and
     * parses it using the SAME field names JwMediaApi already verified
     * against real JW.org responses (progressiveDownloadURL primary,
     * url fallback) — one consistent extraction, not a second guess at
     * the API shape.
     */
    private fun jsonSrcMedia(html: String, fallbackTitle: String): MediaItem? {
        val jsonUrl = jsonSrcRegex.find(html)?.groupValues?.get(1)?.let {
            it.replace("&amp;", "&")
        } ?: return null
        val body = fetchText(jsonUrl) ?: return null
        val json = runCatching { JSONObject(body) }.getOrNull() ?: return null

        // Response shapes vary: a single media object at root, OR a
        // wrapper with the media object nested one level down.
        val media = json.optJSONObject("media")
            ?: json.optJSONArray("media")?.optJSONObject(0)
            ?: json

        val files = media.optJSONArray("files") ?: return null
        var bestUrl = ""; var bestRes = -1
        for (i in 0 until files.length()) {
            val f = files.optJSONObject(i) ?: continue
            val url = f.optString("progressiveDownloadURL").ifBlank { f.optString("url") }
            if (url.isBlank()) continue
            val label = f.optString("label", "")
            val res = label.trimEnd('p').toIntOrNull() ?: f.optInt("frameHeight", 0)
            if (bestUrl.isEmpty()) { bestUrl = url; bestRes = res }
            else if (res in (bestRes + 1)..720) { bestUrl = url; bestRes = res }
        }
        if (bestUrl.isBlank()) return null

        val title = media.optString("title").ifBlank { fallbackTitle }
        val type = media.optString("type").ifBlank {
            if (bestUrl.endsWith(".mp3", true) || bestUrl.endsWith(".m4a", true)) "audio" else "video"
        }
        return MediaItem(title = title, streamUrl = bestUrl, mediaType = type)
    }

    private val rawMediaUrlRegex = Regex(
        """https?://[^\s"'<>]+\.(mp4|m4v|webm|mp3|m4a|ogg)(\?[^\s"'<>]*)?""",
        RegexOption.IGNORE_CASE
    )

    private fun rawMediaUrl(html: String): Pair<String, String>? {
        val m = rawMediaUrlRegex.find(html) ?: return null
        val url = m.value
        val kind = if (url.contains(".mp3", true) || url.contains(".m4a", true) || url.contains(".ogg", true))
            "audio" else "video"
        return url to kind
    }
}
