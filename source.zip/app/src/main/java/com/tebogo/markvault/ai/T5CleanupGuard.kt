package com.tebogo.markvault.ai

object T5CleanupGuard {
    fun isSafeWithoutModel(): Boolean = !T5ExpansionAvailability.isAvailable()
}
