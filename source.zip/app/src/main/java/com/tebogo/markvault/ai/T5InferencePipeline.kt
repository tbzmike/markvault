package com.tebogo.markvault.ai

import android.content.Context

/** Connects T5 expansion execution into retrieval flow. */
class T5InferencePipeline(
    private val context: Context,
    private val loader: T5ArtifactLoader = T5ArtifactLoader(context),
    private val engineProvider: () -> T5InferenceEngine? = { T5InferenceEngine.loadFrom(context) }
) {
    private var engine: T5InferenceEngine? = null

    fun prepare(): Boolean {
        if (!loader.initializeInference()) return false
        if (engine == null) engine = engineProvider()
        return engine != null
    }

    suspend fun expand(query: String): List<String> {
        if (!prepare()) return emptyList()
        val paraphrase = engine?.generate("paraphrase: $query") ?: return listOf(query)
        return listOf(query, paraphrase).distinct()
    }
}
