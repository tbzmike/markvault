package com.tebogo.markvault.ai

/** Connects T5 expansion execution into retrieval flow. */
class T5InferencePipeline(
    private val loader: T5ArtifactLoader = T5ArtifactLoader()
) {
    fun prepare(): Boolean = loader.initializeInference()

    suspend fun expand(query: String): List<String> {
        if (!prepare()) return emptyList()
        return listOf(query)
    }
}
