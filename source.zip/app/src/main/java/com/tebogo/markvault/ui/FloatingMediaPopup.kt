package com.tebogo.markvault.ui

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.background
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalConfiguration
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Popup
import androidx.compose.ui.window.PopupProperties
import androidx.media3.common.Player
import androidx.media3.ui.PlayerView
import androidx.compose.ui.viewinterop.AndroidView
import com.tebogo.markvault.AppViewModel
import kotlin.math.roundToInt

/**
 * v5.4.234cc — Movable, resizable floating media player popup.
 *
 * Fixes from v5.4.233cc:
 *   • Default size much larger (was 300x210dp — cramped). Now sized so a
 *     16:9 video fills its area with NO letterboxing by default.
 *   • Resize is now ASPECT-RATIO-LOCKED: dragging only changes width, and
 *     height is ALWAYS derived from width using the true 16:9 ratio for
 *     video (fixed height for audio). This is the actual fix for "video
 *     only shows half" — that happened because width/height could drift
 *     independently, putting the video box out of proportion to the real
 *     video and clipping/letterboxing it badly.
 *   • The resize handle is now a dedicated footer STRIP below the video,
 *     never overlapping PlayerView. The old corner handle sat ON TOP of
 *     PlayerView, and PlayerView's own touch handling (tap-to-show-
 *     controls) was winning the gesture, which is why resize didn't work.
 *
 * Attaches to the SHARED MediaController (owned by PlaybackService) —
 * playback was already started by vm.playMedia() before this popup ever
 * renders, so closing it does not stop playback.
 */
@Composable
fun FloatingMediaPopup(
    vm: AppViewModel,
    title: String,
    url: String,
    mediaType: String,           // "video" or "audio"
    onDismiss: () -> Unit
) {
    val density = LocalDensity.current
    val config  = LocalConfiguration.current
    val screenW = config.screenWidthDp.dp
    val screenH = config.screenHeightDp.dp
    val isVideo = mediaType != "audio"

    // v5.4.233cc — Attach to the already-playing shared controller.
    var player by remember { mutableStateOf<Player?>(null) }
    LaunchedEffect(Unit) {
        var waited = 0
        while (player == null && waited < 3000) {
            player = vm.getMediaController()
            if (player == null) {
                kotlinx.coroutines.delay(50L)
                waited += 50
            }
        }
    }

    var isFullscreen by remember { mutableStateOf(false) }
    var isMinimized  by remember { mutableStateOf(false) }

    // v5.4.234cc — Single degree of freedom: only WIDTH is tracked.
    // Height is always derived from it (16:9 for video, fixed for audio),
    // so the video can never be cropped or shown "half" — resizing the
    // popup can never put it out of proportion to the real video.
    val headerH = 36.dp
    val footerH = 22.dp
    val audioAreaH = 160.dp
    val defaultW = minOf(380.dp, screenW * 0.92f)
    var widthPx by remember { mutableStateOf(with(density) { defaultW.toPx() }) }
    var offsetX by remember { mutableStateOf(with(density) { 12.dp.toPx() }) }
    var offsetY by remember { mutableStateOf(with(density) { 70.dp.toPx() }) }

    val minWidthPx = with(density) { 220.dp.toPx() }
    val maxWidthPx = with(density) { (screenW - 16.dp).toPx() }
    val maxScreenHeightPx = with(density) { (screenH - 24.dp).toPx() }

    fun contentHeightDp(wPx: Float): androidx.compose.ui.unit.Dp = with(density) {
        if (isVideo) (wPx * 9f / 16f).toDp() else audioAreaH
    }

    Popup(
        properties = PopupProperties(
            focusable = false,
            dismissOnBackPress = false,
            dismissOnClickOutside = false
        ),
        onDismissRequest = onDismiss
    ) {
        val widthDp = with(density) { widthPx.toDp() }
        val videoAreaH = contentHeightDp(widthPx)
        val fullHeightDp = headerH + videoAreaH + footerH

        val renderW = when {
            isFullscreen -> screenW
            isMinimized  -> 170.dp
            else         -> widthDp
        }
        val renderH = when {
            isFullscreen -> screenH
            isMinimized  -> headerH
            else         -> fullHeightDp.coerceAtMost(with(density) { maxScreenHeightPx.toDp() })
        }
        val renderX = if (isFullscreen) 0f else offsetX
        val renderY = if (isFullscreen) 0f else offsetY

        BackHandler(enabled = true) { onDismiss() }

        Box(
            modifier = Modifier
                .offset { IntOffset(renderX.roundToInt(), renderY.roundToInt()) }
                .size(width = renderW, height = renderH)
                .clip(RoundedCornerShape(if (isFullscreen) 0.dp else 10.dp))
                .background(Color(0xFF1E1E1E))
        ) {
            Column(modifier = Modifier.fillMaxSize()) {

                // ── Header (drag to move + controls) ────────────────────────
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(headerH)
                        .background(Color(0xFF2A2A2A))
                        .pointerInput(isFullscreen, isMinimized) {
                            if (!isFullscreen && !isMinimized) {
                                detectDragGestures { _, drag ->
                                    val curWDp = with(density) { widthPx.toDp() }
                                    val curHPx = with(density) { (headerH + contentHeightDp(widthPx) + footerH).toPx() }
                                    offsetX = (offsetX + drag.x).coerceIn(0f, maxWidthPx + 16f - with(density) { curWDp.toPx() })
                                    offsetY = (offsetY + drag.y).coerceIn(0f, maxScreenHeightPx - curHPx)
                                }
                            }
                        }
                        .padding(horizontal = 8.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(4.dp)
                ) {
                    Text(
                        if (mediaType == "audio") "\uD83D\uDD0A" else "\u25B6",
                        fontSize = 12.sp,
                        color = Color(0xFFEEEEEE)
                    )
                    Text(
                        title,
                        color = Color(0xFFDDDDDD),
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Medium,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis,
                        modifier = Modifier.weight(1f)
                    )
                    IconButton(
                        onClick = { isMinimized = !isMinimized },
                        modifier = Modifier.size(28.dp)
                    ) {
                        Text(
                            if (isMinimized) "\u25A1" else "\u2013",
                            color = Color(0xFFEEEEEE),
                            fontSize = 12.sp
                        )
                    }
                    if (!isMinimized) {
                        IconButton(
                            onClick = { isFullscreen = !isFullscreen },
                            modifier = Modifier.size(28.dp)
                        ) {
                            Text(
                                if (isFullscreen) "\u2922" else "\u26F6",
                                color = Color(0xFFEEEEEE),
                                fontSize = 12.sp
                            )
                        }
                    }
                    IconButton(onClick = onDismiss, modifier = Modifier.size(28.dp)) {
                        Text("\u2715", color = Color(0xFFEEEEEE), fontSize = 13.sp)
                    }
                }

                // ── Player body (hidden when minimized) ─────────────────────
                if (!isMinimized) {
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(videoAreaH)
                            .background(Color.Black)
                    ) {
                        if (player == null) {
                            CircularProgressIndicator(
                                color = Color.White,
                                modifier = Modifier.align(Alignment.Center)
                            )
                        } else {
                            AndroidView(
                                factory = { c ->
                                    PlayerView(c).apply {
                                        this.player = player
                                        useController = true
                                    }
                                },
                                update = { it.player = player },
                                modifier = Modifier.fillMaxSize()
                            )
                        }
                    }

                    // ── Resize footer strip — dedicated, NEVER overlaps
                    // PlayerView, so its drag gesture always wins (the old
                    // corner-handle-on-top-of-video approach lost touch
                    // priority to PlayerView's own tap/controls handling).
                    if (!isFullscreen) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(footerH)
                                .background(Color(0xFF2A2A2A))
                                .pointerInput(Unit) {
                                    detectDragGestures { _, drag ->
                                        widthPx = (widthPx + drag.x).coerceIn(minWidthPx, maxWidthPx)
                                    }
                                },
                            horizontalArrangement = Arrangement.End,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                "\u2921",
                                color = Color(0xFFAAAAAA),
                                fontSize = 13.sp,
                                modifier = Modifier.padding(end = 8.dp)
                            )
                        }
                    }
                }
            }
        }
    }
}
