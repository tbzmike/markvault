package com.tebogo.markvault.ui

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.background
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalConfiguration
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Popup
import androidx.compose.ui.window.PopupProperties
import androidx.media3.common.MediaItem as ExoMediaItem
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.ui.PlayerView
import androidx.compose.ui.viewinterop.AndroidView
import kotlin.math.roundToInt

/**
 * v5.4.228cc — Movable, resizable floating media player popup.
 *
 * Features:
 *   • Drag anywhere on the header to move
 *   • Drag the bottom-right corner to resize
 *   • Fullscreen toggle
 *   • Minimize (collapses to a small floating pill)
 *   • Close button (X)
 *   • BackHandler → closes the popup
 */
@Composable
fun FloatingMediaPopup(
    title: String,
    url: String,
    mediaType: String,           // "video" or "audio"
    onDismiss: () -> Unit
) {
    val ctx     = LocalContext.current
    val density = LocalDensity.current
    val config  = LocalConfiguration.current
    val screenW = config.screenWidthDp.dp
    val screenH = config.screenHeightDp.dp

    // ── Player instance ─────────────────────────────────────────────────────
    val player = remember { ExoPlayer.Builder(ctx).build() }
    DisposableEffect(url) {
        player.setMediaItem(ExoMediaItem.fromUri(url))
        player.prepare()
        player.playWhenReady = true
        onDispose { player.release() }
    }

    // ── Position & size state ───────────────────────────────────────────────
    var isFullscreen by remember { mutableStateOf(false) }
    var isMinimized  by remember { mutableStateOf(false) }

    val defaultW = 300.dp
    val defaultH = 210.dp
    var widthPx  by remember { mutableStateOf(with(density) { defaultW.toPx() }) }
    var heightPx by remember { mutableStateOf(with(density) { defaultH.toPx() }) }
    var offsetX  by remember { mutableStateOf(with(density) { 20.dp.toPx() }) }
    var offsetY  by remember { mutableStateOf(with(density) { 80.dp.toPx() }) }

    val minWidthPx  = with(density) { 200.dp.toPx() }
    val minHeightPx = with(density) { 140.dp.toPx() }
    val maxWidthPx  = with(density) { screenW.toPx() - 20f }
    val maxHeightPx = with(density) { screenH.toPx() - 40f }

    // ── Back handler closes popup ───────────────────────────────────────────
    BackHandler(enabled = true) { onDismiss() }

    Popup(
        properties = PopupProperties(
            focusable = false,
            dismissOnBackPress = false,
            dismissOnClickOutside = false
        ),
        onDismissRequest = onDismiss
    ) {
        // Compute rendering geometry
        val renderW = when {
            isFullscreen -> screenW
            isMinimized  -> 160.dp
            else         -> with(density) { widthPx.toDp() }
        }
        val renderH = when {
            isFullscreen -> screenH
            isMinimized  -> 44.dp
            else         -> with(density) { heightPx.toDp() }
        }
        val renderX = if (isFullscreen) 0f else offsetX
        val renderY = if (isFullscreen) 0f else offsetY

        Box(
            modifier = Modifier
                .offset { IntOffset(renderX.roundToInt(), renderY.roundToInt()) }
                .size(width = renderW, height = renderH)
                .clip(RoundedCornerShape(if (isFullscreen) 0.dp else 10.dp))
                .background(Color(0xFF1E1E1E))
        ) {
            Column(modifier = Modifier.fillMaxSize()) {

                // ── Header (drag to move + controls) ────────────────────────
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(if (isMinimized) 44.dp else 36.dp)
                        .background(Color(0xFF2A2A2A))
                        .pointerInput(isFullscreen, isMinimized) {
                            if (!isFullscreen && !isMinimized) {
                                detectDragGestures { _, drag ->
                                    offsetX = (offsetX + drag.x).coerceIn(0f, maxWidthPx - widthPx)
                                    offsetY = (offsetY + drag.y).coerceIn(0f, maxHeightPx - heightPx)
                                }
                            }
                        }
                        .padding(horizontal = 8.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(4.dp)
                ) {
                    Text(
                        if (mediaType == "audio") "\uD83D\uDD0A" else "\u25B6",
                        fontSize = 12.sp,
                        color = Color(0xFFEEEEEE)
                    )
                    Text(
                        title,
                        color = Color(0xFFDDDDDD),
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Medium,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis,
                        modifier = Modifier.weight(1f)
                    )
                    // Minimize / restore
                    IconButton(
                        onClick = { isMinimized = !isMinimized },
                        modifier = Modifier.size(28.dp)
                    ) {
                        Text(
                            if (isMinimized) "\u25A1" else "\u2013",  // □ or –
                            color = Color(0xFFEEEEEE),
                            fontSize = 12.sp
                        )
                    }
                    // Fullscreen toggle
                    if (!isMinimized) {
                        IconButton(
                            onClick = { isFullscreen = !isFullscreen },
                            modifier = Modifier.size(28.dp)
                        ) {
                            Text(
                                if (isFullscreen) "\u2922" else "\u26F6",
                                color = Color(0xFFEEEEEE),
                                fontSize = 12.sp
                            )
                        }
                    }
                    // Close
                    IconButton(onClick = onDismiss, modifier = Modifier.size(28.dp)) {
                        Text("\u2715", color = Color(0xFFEEEEEE), fontSize = 13.sp)
                    }
                }

                // ── Player body (hidden when minimized) ─────────────────────
                if (!isMinimized) {
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .weight(1f)
                            .background(Color.Black)
                    ) {
                        AndroidView(
                            factory = { c ->
                                PlayerView(c).apply {
                                    this.player = player
                                    useController = true
                                }
                            },
                            modifier = Modifier.fillMaxSize()
                        )
                        // Resize handle (bottom-right) — only when not fullscreen
                        if (!isFullscreen) {
                            Box(
                                modifier = Modifier
                                    .align(Alignment.BottomEnd)
                                    .size(24.dp)
                                    .background(Color(0xFF444444).copy(alpha = 0.6f))
                                    .pointerInput(Unit) {
                                        detectDragGestures { _, drag ->
                                            widthPx  = (widthPx + drag.x).coerceIn(minWidthPx, maxWidthPx - offsetX)
                                            heightPx = (heightPx + drag.y).coerceIn(minHeightPx, maxHeightPx - offsetY)
                                        }
                                    },
                                contentAlignment = Alignment.Center
                            ) {
                                Text("\u2921", color = Color.White, fontSize = 12.sp)
                            }
                        }
                    }
                }
            }
        }
    }
}
