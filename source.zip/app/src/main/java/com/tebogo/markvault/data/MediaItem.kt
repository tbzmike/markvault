package com.tebogo.markvault.data

import androidx.room.*

/**
 * v5.4.225cc — Media item for JW.org videos/audio and local media files.
 * Uses LIKE search (not FTS) — table stays small (hundreds of items),
 * avoiding Room KSP schema conflicts from FTS virtual tables.
 */
@Entity(tableName = "media_items")
data class MediaItem(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val title: String = "",
    val description: String = "",
    val durationMs: Long = 0L,
    val thumbnailUrl: String = "",
    val streamUrl: String = "",
    val localPath: String = "",
    /** "video" or "audio" */
    val mediaType: String = "video",
    val mimeType: String = "video/mp4",
    val jwKey: String = "",
    val scriptureRefs: String = "",
    val category: String = "",
    val source: String = "jworg",
    val cachedAt: Long = System.currentTimeMillis(),
    val lastPlayedAt: Long = 0L,
    val resumePositionMs: Long = 0L,
    /**
     * v5.4.235cc — Available quality variants for the video-quality picker,
     * one per line as "label\turl" (tab-separated — never appears in a
     * label or URL, so no escaping needed). Empty when only one quality
     * was available (nothing to pick between) or for local/direct files.
     */
    val qualityOptions: String = "",
    /**
     * v5.4.250cc — Epoch millis of JW.org's own `firstPublished` field
     * (the actual upload/publish date, verified against jw-scripts'
     * jwlib/parse.py — same field this app's JwMediaApi.kt already cites
     * as its verification source). 0 when unknown (older cached rows
     * from before this column existed, or a source with no publish date).
     * Category browse listings sort by this, newest first; search
     * results are sorted by match relevance instead — see
     * JwMediaApi.searchInCategory()'s doc comment for that reasoning.
     */
    val uploadDate: Long = 0L,
    /**
     * v5.4.254cc — Favourite flag, mirroring notes.favourite's exact
     * pattern (Int 0/1, not Boolean) for consistency with the rest of
     * this schema. 0 = not favourited, 1 = favourited.
     */
    val isFavourite: Int = 0
)

@Dao
interface MediaDao {

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsert(item: MediaItem): Long

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsertAll(items: List<MediaItem>)

    @Query("SELECT * FROM media_items WHERE id = :id")
    suspend fun getById(id: Long): MediaItem?

    @Query("SELECT * FROM media_items WHERE id IN (:ids)")
    suspend fun getByIds(ids: List<Long>): List<MediaItem>

    @Query("SELECT * FROM media_items WHERE jwKey = :key LIMIT 1")
    suspend fun getByJwKey(key: String): MediaItem?

    /** LIKE search — adequate for a small media cache table. */
    @Query("""
        SELECT * FROM media_items
        WHERE title       LIKE '%' || :q || '%'
           OR description LIKE '%' || :q || '%'
           OR scriptureRefs LIKE '%' || :q || '%'
        ORDER BY cachedAt DESC
        LIMIT :limit
    """)
    suspend fun searchLocal(q: String, limit: Int = 20): List<MediaItem>

    @Query("SELECT * FROM media_items ORDER BY cachedAt DESC LIMIT :limit")
    suspend fun getRecent(limit: Int = 50): List<MediaItem>

    /** v5.4.233cc — Playback history, most recently played first. */
    @Query("SELECT * FROM media_items WHERE lastPlayedAt > 0 ORDER BY lastPlayedAt DESC LIMIT :limit")
    suspend fun getRecentlyPlayed(limit: Int = 20): List<MediaItem>

    @Query("SELECT * FROM media_items WHERE mediaType = :type ORDER BY cachedAt DESC LIMIT :limit")
    suspend fun getByType(type: String, limit: Int = 50): List<MediaItem>

    @Query("UPDATE media_items SET lastPlayedAt = :ts, resumePositionMs = :pos WHERE id = :id")
    suspend fun updatePlayback(id: Long, ts: Long, pos: Long)

    /** v5.4.254cc — Favourite toggle, mirroring notes' favourite = :fav pattern. */
    @Query("UPDATE media_items SET isFavourite = :fav WHERE id = :id")
    suspend fun setFavourite(id: Long, fav: Int)

    @Query("SELECT * FROM media_items WHERE isFavourite = 1 ORDER BY title")
    suspend fun favourites(): List<MediaItem>

    @Query("DELETE FROM media_items WHERE id = :id")
    suspend fun delete(id: Long)

    @Query("SELECT COUNT(*) FROM media_items")
    suspend fun count(): Int
}
