package com.tebogo.markvault.data

import androidx.room.*

/**
 * v5.4.212cc — Media item for JW.org videos/audio and local media files.
 * Stored locally after fetching from JW.org API or scanning local storage.
 * FTS5 search covers title, description, and scripture references.
 */
@Entity(tableName = "media_items")
data class MediaItem(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,

    /** Display title — from JW.org or filename */
    val title: String,

    /** Description / synopsis */
    val description: String = "",

    /** Duration in milliseconds */
    val durationMs: Long = 0,

    /** Thumbnail image URL */
    val thumbnailUrl: String = "",

    /** Streaming or local playback URL (best quality) */
    val streamUrl: String = "",

    /** Local file path if downloaded */
    val localPath: String = "",

    /** "video" or "audio" */
    val mediaType: String = "video",

    /** MIME type: video/mp4, audio/mp3, etc. */
    val mimeType: String = "video/mp4",

    /** JW.org language-agnostic natural key (unique ID on JW.org) */
    val jwKey: String = "",

    /** Scripture references mentioned in this media, comma-separated */
    val scriptureRefs: String = "",

    /** JW.org category key (e.g. "VODBibleDrama") */
    val category: String = "",

    /** Source: "jworg" or "local" */
    val source: String = "jworg",

    /** Epoch ms when cached/downloaded */
    val cachedAt: Long = System.currentTimeMillis(),

    /** Epoch ms last played, 0 if never */
    val lastPlayedAt: Long = 0,

    /** Playback position in ms for resume */
    val resumePositionMs: Long = 0
)

/** FTS5 shadow for media search */
@Fts4(contentEntity = MediaItem::class)
@Entity(tableName = "media_items_fts")
data class MediaItemFts(
    val title: String,
    val description: String,
    val scriptureRefs: String
)

/** Lightweight projection for search result cards */
data class MediaSearchResult(
    val id: Long,
    val title: String,
    val description: String,
    val durationMs: Long,
    val thumbnailUrl: String,
    val streamUrl: String,
    val localPath: String,
    val mediaType: String,
    val mimeType: String,
    val jwKey: String,
    val category: String,
    val source: String
)

@Dao
interface MediaDao {

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsert(item: MediaItem): Long

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsertAll(items: List<MediaItem>)

    @Query("SELECT * FROM media_items WHERE id = :id")
    suspend fun getById(id: Long): MediaItem?

    @Query("SELECT * FROM media_items WHERE jwKey = :key LIMIT 1")
    suspend fun getByJwKey(key: String): MediaItem?

    @Query("SELECT * FROM media_items ORDER BY cachedAt DESC LIMIT :limit")
    suspend fun getRecent(limit: Int = 50): List<MediaItem>

    @Query("""
        SELECT m.id, m.title, m.description, m.durationMs, m.thumbnailUrl,
               m.streamUrl, m.localPath, m.mediaType, m.mimeType,
               m.jwKey, m.category, m.source
        FROM media_items m
        JOIN media_items_fts f ON m.rowid = f.rowid
        WHERE media_items_fts MATCH :query
        ORDER BY rank
        LIMIT :limit
    """)
    suspend fun ftsSearch(query: String, limit: Int = 30): List<MediaSearchResult>

    @Query("SELECT * FROM media_items WHERE mediaType = :type ORDER BY cachedAt DESC LIMIT :limit")
    suspend fun getByType(type: String, limit: Int = 50): List<MediaItem>

    @Query("UPDATE media_items SET lastPlayedAt = :ts, resumePositionMs = :pos WHERE id = :id")
    suspend fun updatePlayback(id: Long, ts: Long, pos: Long)

    @Query("DELETE FROM media_items WHERE id = :id")
    suspend fun delete(id: Long)

    @Query("SELECT COUNT(*) FROM media_items")
    suspend fun count(): Int
}
