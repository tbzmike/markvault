package com.tebogo.markvault.data

import androidx.room.*

/**
 * v5.4.212cc — Media item for JW.org videos/audio and local media files.
 * Uses LIKE search (not FTS) since the table stays small (hundreds of items).
 * FTS virtual tables are avoided here to prevent Room KSP schema conflicts.
 */
@Entity(tableName = "media_items")
data class MediaItem(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val title: String = "",
    val description: String = "",
    val durationMs: Long = 0L,
    val thumbnailUrl: String = "",
    val streamUrl: String = "",
    val localPath: String = "",
    /** "video" or "audio" */
    val mediaType: String = "video",
    val mimeType: String = "video/mp4",
    /** JW.org unique natural key */
    val jwKey: String = "",
    /** Comma-separated scripture references, e.g. "John 5:28, Rev 21:4" */
    val scriptureRefs: String = "",
    val category: String = "",
    /** "jworg" or "local" */
    val source: String = "jworg",
    val cachedAt: Long = System.currentTimeMillis(),
    val lastPlayedAt: Long = 0L,
    val resumePositionMs: Long = 0L
)

@Dao
interface MediaDao {

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsert(item: MediaItem): Long

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsertAll(items: List<MediaItem>)

    @Query("SELECT * FROM media_items WHERE id = :id")
    suspend fun getById(id: Long): MediaItem?

    @Query("SELECT * FROM media_items WHERE jwKey = :key LIMIT 1")
    suspend fun getByJwKey(key: String): MediaItem?

    /**
     * LIKE search across title, description and scripture refs.
     * Adequate for a small (< 1 000) media cache table — no FTS needed.
     */
    @Query("""
        SELECT * FROM media_items
        WHERE title LIKE '%' || :q || '%'
           OR description LIKE '%' || :q || '%'
           OR scriptureRefs LIKE '%' || :q || '%'
        ORDER BY cachedAt DESC
        LIMIT :limit
    """)
    suspend fun searchLocal(q: String, limit: Int = 20): List<MediaItem>

    @Query("SELECT * FROM media_items ORDER BY cachedAt DESC LIMIT :limit")
    suspend fun getRecent(limit: Int = 50): List<MediaItem>

    @Query("SELECT * FROM media_items WHERE mediaType = :type ORDER BY cachedAt DESC LIMIT :limit")
    suspend fun getByType(type: String, limit: Int = 50): List<MediaItem>

    @Query("UPDATE media_items SET lastPlayedAt = :ts, resumePositionMs = :pos WHERE id = :id")
    suspend fun updatePlayback(id: Long, ts: Long, pos: Long)

    @Query("DELETE FROM media_items WHERE id = :id")
    suspend fun delete(id: Long)

    @Query("SELECT COUNT(*) FROM media_items")
    suspend fun count(): Int
}
