package com.tebogo.markvault.ai

/** Final routing point for expansion selection. */
object T5FinalSearchFlow {
    fun mode(): T5ExpansionMode {
        return T5ModePersistenceBridge.currentMode()
    }

    fun useT5(): Boolean {
        return mode() == T5ExpansionMode.T5_BASE &&
            T5ExpansionAvailability.isAvailable()
    }
}
