package com.tebogo.markvault.data

import android.content.Context
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.net.HttpURLConnection
import java.net.URL
import java.security.MessageDigest

/**
 * v5.4.288cc — Isolated video-caption transcript cache.
 *
 * This intentionally does NOT use the notes/note_embeddings tables. Video
 * transcripts live in app-internal files and are searched independently, so
 * caption extraction cannot alter the 20k/22k article scopes or their 200k+
 * semantic chunks.
 *
 * A complete JW.org WebVTT track is fetched in one request when available.
 * If a video exposes only a runtime text track, [appendPlaybackCue] builds a
 * partial transcript from the cues Media3 actually renders. A later complete
 * VTT fetch safely replaces that partial copy.
 */
object VideoTranscriptStore {
    const val RESULT_PREFIX = "🎬 Found in video transcript"

    data class Cue(
        val startMs: Long,
        val endMs: Long,
        val text: String
    )

    data class Transcript(
        val mediaId: Long,
        val jwKey: String,
        val title: String,
        val language: String,
        val subtitleUrl: String,
        val complete: Boolean,
        val cues: List<Cue>,
        val updatedAt: Long
    )

    data class Match(
        val mediaId: Long,
        val jwKey: String,
        val title: String,
        val startMs: Long,
        val snippet: String,
        val score: Int
    )

    private val fileLock = Any()

    fun isEligible(item: MediaItem): Boolean = item.mediaType.equals("video", ignoreCase = true)

    suspend fun hasComplete(context: Context, item: MediaItem): Boolean = withContext(Dispatchers.IO) {
        load(context, item)?.complete == true
    }

    suspend fun load(context: Context, item: MediaItem): Transcript? = withContext(Dispatchers.IO) {
        synchronized(fileLock) { readFile(fileFor(context, item)) }
    }

    /** Fetch and persist the complete caption track in one pass. */
    suspend fun fetchComplete(context: Context, item: MediaItem): Transcript? = withContext(Dispatchers.IO) {
        val captionUrl = item.subtitleUrl.trim()
        if (!isEligible(item) || captionUrl.isBlank()) return@withContext null

        val raw = fetchText(captionUrl) ?: return@withContext null
        val cues = parseWebVtt(raw)
        if (cues.isEmpty()) return@withContext null

        val transcript = Transcript(
            mediaId = item.id,
            jwKey = item.jwKey,
            title = item.title,
            language = item.subtitleLanguage,
            subtitleUrl = captionUrl,
            complete = true,
            cues = cues,
            updatedAt = System.currentTimeMillis()
        )
        synchronized(fileLock) { writeFile(fileFor(context, item), transcript) }
        transcript
    }

    /**
     * Fallback path for captions that are available to Media3 but not exposed
     * as a separately downloadable VTT URL. Duplicate/repeated screen cues are
     * collapsed before writing.
     */
    suspend fun appendPlaybackCue(
        context: Context,
        item: MediaItem,
        positionMs: Long,
        text: String
    ) = withContext(Dispatchers.IO) {
        if (!isEligible(item)) return@withContext
        val clean = cleanCueText(text)
        if (clean.isBlank()) return@withContext

        synchronized(fileLock) {
            val file = fileFor(context, item)
            val old = readFile(file)
            if (old?.complete == true) return@synchronized

            val cues = old?.cues?.toMutableList() ?: mutableListOf()
            val last = cues.lastOrNull()
            val duplicate = last != null &&
                last.text == clean &&
                kotlin.math.abs(last.startMs - positionMs) < 4_000L
            if (!duplicate) {
                cues += Cue(positionMs.coerceAtLeast(0L), positionMs.coerceAtLeast(0L) + 4_000L, clean)
                writeFile(
                    file,
                    Transcript(
                        mediaId = item.id,
                        jwKey = item.jwKey,
                        title = item.title,
                        language = item.subtitleLanguage,
                        subtitleUrl = item.subtitleUrl,
                        complete = false,
                        cues = cues,
                        updatedAt = System.currentTimeMillis()
                    )
                )
            }
        }
    }

    /**
     * Fast local transcript lookup used only by media search. It never touches
     * note search/index state. Exact phrase matches rank first; otherwise token
     * overlap is enough to surface the video and its matching caption passage.
     */
    suspend fun search(context: Context, query: String, limit: Int = 12): List<Match> = withContext(Dispatchers.IO) {
        val q = normalize(query)
        if (q.length < 2) return@withContext emptyList()
        val tokens = q.split(' ').filter { it.length >= 2 }.distinct()
        if (tokens.isEmpty()) return@withContext emptyList()

        val files = transcriptDir(context).listFiles { f -> f.isFile && f.extension == "json" }
            ?.sortedByDescending { it.lastModified() }
            .orEmpty()
        val matches = ArrayList<Match>()

        for (file in files) {
            val transcript = synchronized(fileLock) { readFile(file) } ?: continue
            var best: Match? = null
            // Search a sliding 1–3 cue window. Spoken phrases commonly cross a
            // VTT cue boundary; searching cues individually would miss them.
            for (start in transcript.cues.indices) {
                for (windowSize in 1..3) {
                    val endExclusive = (start + windowSize).coerceAtMost(transcript.cues.size)
                    if (endExclusive <= start) continue
                    val window = transcript.cues.subList(start, endExclusive)
                    val snippet = window.joinToString(" ") { it.text }.trim()
                    val n = normalize(snippet)
                    if (n.isBlank()) continue
                    var score = 0
                    if (n.contains(q)) score += 100
                    var tokenHits = 0
                    for (token in tokens) if (n.contains(token)) tokenHits++
                    score += tokenHits * 12
                    // Prefer the smallest passage when scores tie.
                    score -= (windowSize - 1)
                    if (score <= 0) continue
                    val candidate = Match(
                        mediaId = transcript.mediaId,
                        jwKey = transcript.jwKey,
                        title = transcript.title,
                        startMs = window.first().startMs,
                        snippet = snippet,
                        score = score
                    )
                    if (best == null || candidate.score > best.score) best = candidate
                    if (endExclusive == transcript.cues.size) break
                }
            }
            best?.let(matches::add)
        }

        matches.sortedByDescending { it.score }.take(limit)
    }

    private fun fetchText(url: String): String? {
        val connection = (URL(url).openConnection() as HttpURLConnection).apply {
            connectTimeout = 15_000
            readTimeout = 20_000
            instanceFollowRedirects = true
            requestMethod = "GET"
            setRequestProperty("User-Agent", "MarkVault/Android")
            setRequestProperty("Accept", "text/vtt,text/plain,*/*")
        }
        return try {
            val code = connection.responseCode
            if (code !in 200..299) return null
            connection.inputStream.bufferedReader(Charsets.UTF_8).use { it.readText() }
        } catch (_: Throwable) {
            null
        } finally {
            connection.disconnect()
        }
    }

    internal fun parseWebVtt(raw: String): List<Cue> {
        val lines = raw.replace("\r\n", "\n").replace('\r', '\n').lines()
        val result = mutableListOf<Cue>()
        var i = 0
        while (i < lines.size) {
            var line = lines[i].trim()
            if (line.isBlank() || line == "WEBVTT" || line.startsWith("NOTE") ||
                line.startsWith("STYLE") || line.startsWith("REGION")) {
                i++
                continue
            }

            // Optional cue identifier line before the timestamp.
            if (!line.contains("-->")) {
                if (i + 1 >= lines.size || !lines[i + 1].contains("-->")) {
                    i++
                    continue
                }
                i++
                line = lines[i].trim()
            }

            val arrow = line.indexOf("-->")
            if (arrow < 0) {
                i++
                continue
            }
            val startRaw = line.substring(0, arrow).trim()
            val endRaw = line.substring(arrow + 3).trim().substringBefore(' ').trim()
            val start = parseTimestamp(startRaw)
            if (start == null) {
                i++
                continue
            }
            val end = parseTimestamp(endRaw) ?: (start + 4_000L)
            i++

            val textLines = mutableListOf<String>()
            while (i < lines.size && lines[i].isNotBlank()) {
                textLines += lines[i]
                i++
            }
            val text = cleanCueText(textLines.joinToString(" "))
            if (text.isNotBlank()) result += Cue(start, end.coerceAtLeast(start), text)
        }

        // Some VTT files repeat the same caption text in adjacent cues while
        // progressively revealing a sentence. Keep the timeline but remove
        // exact adjacent duplicates so saved/search text stays clean.
        return result.filterIndexed { index, cue ->
            index == 0 || result[index - 1].text != cue.text || result[index - 1].startMs != cue.startMs
        }
    }

    private fun parseTimestamp(value: String): Long? {
        val parts = value.split(':')
        return try {
            val secondsPart = parts.last().replace(',', '.').toDouble()
            val secondsMs = (secondsPart * 1000.0).toLong()
            when (parts.size) {
                2 -> parts[0].toLong() * 60_000L + secondsMs
                3 -> parts[0].toLong() * 3_600_000L + parts[1].toLong() * 60_000L + secondsMs
                else -> null
            }
        } catch (_: Throwable) {
            null
        }
    }

    private fun cleanCueText(value: String): String = value
        .replace(Regex("<[^>]+>"), " ")
        .replace("&nbsp;", " ")
        .replace("&amp;", "&")
        .replace("&quot;", "\"")
        .replace("&#39;", "'")
        .replace(Regex("\\s+"), " ")
        .trim()

    private fun normalize(value: String): String = value
        .lowercase()
        .replace(Regex("[^\\p{L}\\p{Nd}]+"), " ")
        .replace(Regex("\\s+"), " ")
        .trim()

    private fun transcriptDir(context: Context): File =
        File(context.filesDir, "video_transcripts").apply { mkdirs() }

    private fun fileFor(context: Context, item: MediaItem): File {
        val identity = item.jwKey.ifBlank {
            item.subtitleUrl.ifBlank { item.streamUrl.ifBlank { "media-${item.id}-${item.title}" } }
        }
        val digest = MessageDigest.getInstance("SHA-256")
            .digest(identity.toByteArray(Charsets.UTF_8))
            .joinToString("") { "%02x".format(it) }
        return File(transcriptDir(context), "$digest.json")
    }

    private fun writeFile(file: File, transcript: Transcript) {
        val root = JSONObject()
            .put("mediaId", transcript.mediaId)
            .put("jwKey", transcript.jwKey)
            .put("title", transcript.title)
            .put("language", transcript.language)
            .put("subtitleUrl", transcript.subtitleUrl)
            .put("complete", transcript.complete)
            .put("updatedAt", transcript.updatedAt)
        val cues = JSONArray()
        transcript.cues.forEach { cue ->
            cues.put(
                JSONObject()
                    .put("startMs", cue.startMs)
                    .put("endMs", cue.endMs)
                    .put("text", cue.text)
            )
        }
        root.put("cues", cues)
        val tmp = File(file.parentFile, file.name + ".tmp")
        tmp.writeText(root.toString(), Charsets.UTF_8)
        if (file.exists()) file.delete()
        if (!tmp.renameTo(file)) {
            file.writeText(root.toString(), Charsets.UTF_8)
            tmp.delete()
        }
    }

    private fun readFile(file: File): Transcript? = runCatching {
        if (!file.exists()) return@runCatching null
        val root = JSONObject(file.readText(Charsets.UTF_8))
        val arr = root.optJSONArray("cues") ?: JSONArray()
        val cues = ArrayList<Cue>(arr.length())
        for (i in 0 until arr.length()) {
            val o = arr.optJSONObject(i) ?: continue
            val text = o.optString("text").trim()
            if (text.isBlank()) continue
            cues += Cue(
                startMs = o.optLong("startMs", 0L),
                endMs = o.optLong("endMs", o.optLong("startMs", 0L) + 4_000L),
                text = text
            )
        }
        Transcript(
            mediaId = root.optLong("mediaId", 0L),
            jwKey = root.optString("jwKey"),
            title = root.optString("title"),
            language = root.optString("language"),
            subtitleUrl = root.optString("subtitleUrl"),
            complete = root.optBoolean("complete", false),
            cues = cues,
            updatedAt = root.optLong("updatedAt", file.lastModified())
        )
    }.getOrNull()
}
