package com.tebogo.markvault.data

import android.content.Context
import android.content.ContentValues
import android.database.sqlite.SQLiteDatabase
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import kotlinx.coroutines.currentCoroutineContext
import kotlinx.coroutines.ensureActive
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.net.HttpURLConnection
import java.net.URL
import java.security.MessageDigest

/**
 * v5.4.288cc — Isolated video-caption transcript cache.
 *
 * This intentionally does NOT use the notes/note_embeddings tables. Video
 * transcripts live in app-internal files and are searched independently, so
 * caption extraction cannot alter the 20k/22k article scopes or their 200k+
 * semantic chunks.
 *
 * A complete JW.org WebVTT track is fetched in one request when available.
 * If a video exposes only a runtime text track, [appendPlaybackCue] builds a
 * partial transcript from the cues Media3 actually renders. A later complete
 * VTT fetch safely replaces that partial copy.
 */
object VideoTranscriptStore {
    const val RESULT_PREFIX = "🎬 Found in video transcript"

    data class Cue(
        val startMs: Long,
        val endMs: Long,
        val text: String
    )

    data class Transcript(
        val mediaId: Long,
        val jwKey: String,
        val title: String,
        val language: String,
        val subtitleUrl: String,
        val complete: Boolean,
        val cues: List<Cue>,
        val updatedAt: Long
    )

    data class Match(
        val mediaId: Long,
        val jwKey: String,
        val title: String,
        val language: String,
        val startMs: Long,
        val snippet: String,
        val score: Int
    )

    private val fileLock = Any()

    // v5.4.389cc — Dedicated caption-search sidecar database. This database is
    // intentionally outside Room and outside notes/media semantic embeddings.
    // It exists only to map caption text -> video identity quickly.
    private const val INDEX_DB_NAME = "transcript_search.db"
    private val indexDbLock = Any()
    @Volatile private var indexDb: SQLiteDatabase? = null

    fun isEligible(item: MediaItem): Boolean = item.mediaType.equals("video", ignoreCase = true)

    suspend fun hasComplete(context: Context, item: MediaItem): Boolean = withContext(Dispatchers.IO) {
        load(context, item)?.complete == true
    }

    suspend fun load(context: Context, item: MediaItem): Transcript? = withContext(Dispatchers.IO) {
        synchronized(fileLock) {
            val currentFile = fileFor(context, item)
            readFile(currentFile) ?: run {
                // v5.4.386cc — Older builds keyed transcripts only by JW key,
                // which lets one language overwrite/masquerade as another.
                // Migrate a legacy file only when its stored language matches
                // this media edition; otherwise leave it untouched.
                val legacy = legacyFileFor(context, item)
                val old = readFile(legacy)
                val requestedLanguage = item.subtitleLanguage.ifBlank { item.contentLanguage }.ifBlank { "E" }
                if (old != null && old.language.equals(requestedLanguage, ignoreCase = true)) {
                    writeFile(currentFile, old)
                    legacy.delete()
                    old
                } else null
            }
        }
    }

    /** Fetch and persist the complete caption track in one pass. */
    suspend fun fetchComplete(context: Context, item: MediaItem): Transcript? = withContext(Dispatchers.IO) {
        val captionUrl = item.subtitleUrl.trim()
        if (!isEligible(item) || captionUrl.isBlank()) return@withContext null

        val raw = fetchText(captionUrl) ?: return@withContext null
        val cues = parseWebVtt(raw)
        if (cues.isEmpty()) return@withContext null

        val transcript = Transcript(
            mediaId = item.id,
            jwKey = item.jwKey,
            title = item.title,
            language = item.subtitleLanguage,
            subtitleUrl = captionUrl,
            complete = true,
            cues = cues,
            updatedAt = System.currentTimeMillis()
        )
        synchronized(fileLock) { writeFile(fileFor(context, item), transcript) }
        transcript
    }

    /**
     * Fallback path for captions that are available to Media3 but not exposed
     * as a separately downloadable VTT URL. Duplicate/repeated screen cues are
     * collapsed before writing.
     */
    suspend fun appendPlaybackCue(
        context: Context,
        item: MediaItem,
        positionMs: Long,
        text: String
    ) = withContext(Dispatchers.IO) {
        if (!isEligible(item)) return@withContext
        val clean = cleanCueText(text)
        if (clean.isBlank()) return@withContext

        synchronized(fileLock) {
            val file = fileFor(context, item)
            val old = readFile(file)
            if (old?.complete == true) return@synchronized

            val cues = old?.cues?.toMutableList() ?: mutableListOf()
            val last = cues.lastOrNull()
            val duplicate = last != null &&
                last.text == clean &&
                kotlin.math.abs(last.startMs - positionMs) < 4_000L
            if (!duplicate) {
                cues += Cue(positionMs.coerceAtLeast(0L), positionMs.coerceAtLeast(0L) + 4_000L, clean)
                writeFile(
                    file,
                    Transcript(
                        mediaId = item.id,
                        jwKey = item.jwKey,
                        title = item.title,
                        language = item.subtitleLanguage,
                        subtitleUrl = item.subtitleUrl,
                        complete = false,
                        cues = cues,
                        updatedAt = System.currentTimeMillis()
                    )
                )
            }
        }
    }

    /**
     * v5.4.389cc — Fast caption-only lookup through a dedicated FTS sidecar.
     * The main/global article search never scans transcript JSON files. Existing
     * transcript files are indexed incrementally by [prepareSearchIndex], while
     * every newly written transcript updates the sidecar immediately.
     */
    suspend fun search(
        context: Context,
        query: String,
        limit: Int = 12,
        language: String? = null
    ): List<Match> = withContext(Dispatchers.IO) {
        val q = normalize(query)
        if (q.length < 2) return@withContext emptyList()
        val tokens = q.split(' ').filter { it.length >= 2 }.distinct()
        if (tokens.isEmpty()) return@withContext emptyList()

        val db = openIndexDb(transcriptDir(context))
        val candidateKeys = LinkedHashSet<String>()
        val candidateLimit = (limit.coerceAtLeast(1) * 6).coerceAtMost(240)

        // Exact token phrase first, then a token-OR fallback. SQLite unicode61
        // tokenization is case-insensitive, while normalize() also makes the
        // result stable across punctuation/case differences.
        fun collect(matchExpression: String) {
            if (candidateKeys.size >= candidateLimit) return
            synchronized(indexDbLock) {
                db.rawQuery(
                    "SELECT fileKey FROM transcript_fts WHERE transcript_fts MATCH ? LIMIT ?",
                    arrayOf(matchExpression, candidateLimit.toString())
                ).use { cursor ->
                    while (cursor.moveToNext() && candidateKeys.size < candidateLimit) {
                        candidateKeys += cursor.getString(0)
                    }
                }
            }
        }

        collect("\"$q\"")
        if (candidateKeys.size < limit) {
            collect(tokens.joinToString(" OR ") { token -> "\"$token\"" })
        }

        val requestedLanguage = language?.trim()?.takeIf { it.isNotBlank() }
        val matches = ArrayList<Match>()
        for (fileKey in candidateKeys) {
            val transcript = synchronized(fileLock) {
                readFile(File(transcriptDir(context), "$fileKey.json"))
            } ?: continue
            if (requestedLanguage != null &&
                !transcript.language.equals(requestedLanguage, ignoreCase = true)) continue
            bestMatch(transcript, q, tokens)?.let(matches::add)
        }
        matches.sortedByDescending { it.score }.take(limit)
    }

    /**
     * Build/repair the caption sidecar incrementally. Safe to run in the
     * background: it reads only transcript JSON files and writes only the
     * separate transcript_search.db file. It never opens the MarkVault Room DB.
     */
    suspend fun prepareSearchIndex(context: Context) = withContext(Dispatchers.IO) {
        val dir = transcriptDir(context)
        val db = openIndexDb(dir)
        val files = dir.listFiles { f -> f.isFile && f.extension == "json" }.orEmpty()
        val liveKeys = HashSet<String>(files.size)
        for ((index, file) in files.withIndex()) {
            if (index > 0 && index % 20 == 0) kotlinx.coroutines.delay(8L)
            val key = file.nameWithoutExtension
            liveKeys += key
            val current = synchronized(indexDbLock) {
                db.rawQuery(
                    "SELECT modified, size FROM transcript_index_meta WHERE fileKey = ? LIMIT 1",
                    arrayOf(key)
                ).use { c ->
                    if (c.moveToFirst()) c.getLong(0) to c.getLong(1) else null
                }
            }
            if (current != null && current.first == file.lastModified() && current.second == file.length()) continue
            val transcript = synchronized(fileLock) { readFile(file) } ?: continue
            indexTranscript(file, transcript)
        }

        // Remove sidecar rows for transcript JSON files that no longer exist.
        val stale = ArrayList<Pair<String, Long>>()
        synchronized(indexDbLock) {
            db.rawQuery("SELECT fileKey, ftsRowId FROM transcript_index_meta", null).use { c ->
                while (c.moveToNext()) {
                    val key = c.getString(0)
                    if (key !in liveKeys) stale += key to c.getLong(1)
                }
            }
            if (stale.isNotEmpty()) {
                db.beginTransaction()
                try {
                    stale.forEach { (key, rowId) ->
                        db.delete("transcript_fts", "rowid = ?", arrayOf(rowId.toString()))
                        db.delete("transcript_index_meta", "fileKey = ?", arrayOf(key))
                    }
                    db.setTransactionSuccessful()
                } finally {
                    db.endTransaction()
                }
            }
        }
    }


    /**
     * v5.4.391cc — Delete every downloaded/captured CC transcript plus the
     * dedicated caption-only FTS sidecar. This never opens or mutates the
     * MarkVault Room database, article FTS, embeddings or chunks.
     */
    suspend fun deleteAll(
        context: Context,
        onProgress: (deleted: Int, total: Int, current: String) -> Unit = { _, _, _ -> }
    ): Int = withContext(Dispatchers.IO) {
        val dir = transcriptDir(context)
        synchronized(indexDbLock) {
            runCatching { indexDb?.close() }
            indexDb = null
        }
        val files = dir.listFiles()?.filter { it.isFile }.orEmpty()
        val total = files.size
        var deleted = 0
        onProgress(0, total, "Preparing caption deletion…")
        for (file in files) {
            currentCoroutineContext().ensureActive()
            val ok = synchronized(fileLock) { runCatching { !file.exists() || file.delete() }.getOrDefault(false) }
            if (ok) deleted++
            onProgress(deleted, total, file.name)
        }
        // SQLite can leave WAL/SHM files after close on some devices; remove any
        // leftovers explicitly before considering the caption cache empty.
        dir.listFiles()?.filter { it.isFile }?.forEach { file ->
            currentCoroutineContext().ensureActive()
            runCatching { file.delete() }
        }
        deleted
    }

    private fun bestMatch(transcript: Transcript, q: String, tokens: List<String>): Match? {
        var best: Match? = null
        for (start in transcript.cues.indices) {
            for (windowSize in 1..8) {
                val endExclusive = (start + windowSize).coerceAtMost(transcript.cues.size)
                if (endExclusive <= start) continue
                val window = transcript.cues.subList(start, endExclusive)
                val snippet = window.joinToString(" ") { it.text }.trim()
                val n = normalize(snippet)
                if (n.isBlank()) continue
                var score = 0
                if (n.contains(q)) score += 100
                var tokenHits = 0
                for (token in tokens) if (n.contains(token)) tokenHits++
                score += tokenHits * 12
                score -= (windowSize - 1)
                if (score <= 0) continue
                val candidate = Match(
                    mediaId = transcript.mediaId,
                    jwKey = transcript.jwKey,
                    title = transcript.title,
                    language = transcript.language,
                    startMs = window.first().startMs,
                    snippet = snippet,
                    score = score
                )
                if (best == null || candidate.score > best!!.score) best = candidate
                if (endExclusive == transcript.cues.size) break
            }
        }
        return best
    }

    private fun openIndexDb(dir: File): SQLiteDatabase {
        indexDb?.takeIf { it.isOpen }?.let { return it }
        return synchronized(indexDbLock) {
            indexDb?.takeIf { it.isOpen } ?: SQLiteDatabase.openOrCreateDatabase(
                File(dir, INDEX_DB_NAME), null
            ).also { db ->
                db.execSQL(
                    "CREATE TABLE IF NOT EXISTS transcript_index_meta (" +
                        "fileKey TEXT PRIMARY KEY, modified INTEGER NOT NULL, size INTEGER NOT NULL, ftsRowId INTEGER NOT NULL)"
                )
                runCatching {
                    db.execSQL(
                        "CREATE VIRTUAL TABLE IF NOT EXISTS transcript_fts USING fts4(" +
                            "fileKey, mediaId, jwKey, title, language, content, tokenize=unicode61)"
                    )
                }.getOrElse {
                    db.execSQL(
                        "CREATE VIRTUAL TABLE IF NOT EXISTS transcript_fts USING fts4(" +
                            "fileKey, mediaId, jwKey, title, language, content)"
                    )
                }
                indexDb = db
            }
        }
    }

    private fun indexTranscript(file: File, transcript: Transcript) {
        val db = openIndexDb(file.parentFile ?: return)
        val key = file.nameWithoutExtension
        synchronized(indexDbLock) {
            db.beginTransaction()
            try {
                val oldRowId = db.rawQuery(
                    "SELECT ftsRowId FROM transcript_index_meta WHERE fileKey = ? LIMIT 1",
                    arrayOf(key)
                ).use { c -> if (c.moveToFirst()) c.getLong(0) else null }
                if (oldRowId != null) {
                    db.delete("transcript_fts", "rowid = ?", arrayOf(oldRowId.toString()))
                }
                val values = ContentValues().apply {
                    put("fileKey", key)
                    put("mediaId", transcript.mediaId.toString())
                    put("jwKey", transcript.jwKey)
                    put("title", transcript.title)
                    put("language", transcript.language)
                    put("content", transcript.cues.joinToString(" ") { it.text })
                }
                val rowId = db.insertOrThrow("transcript_fts", null, values)
                db.execSQL(
                    "INSERT OR REPLACE INTO transcript_index_meta(fileKey, modified, size, ftsRowId) VALUES(?, ?, ?, ?)",
                    arrayOf(key, file.lastModified(), file.length(), rowId)
                )
                db.setTransactionSuccessful()
            } finally {
                db.endTransaction()
            }
        }
    }

    private fun fetchText(url: String): String? {
        val connection = (URL(url).openConnection() as HttpURLConnection).apply {
            connectTimeout = 15_000
            readTimeout = 20_000
            instanceFollowRedirects = true
            requestMethod = "GET"
            setRequestProperty("User-Agent", "MarkVault/Android")
            setRequestProperty("Accept", "text/vtt,text/plain,*/*")
        }
        return try {
            val code = connection.responseCode
            if (code !in 200..299) return null
            connection.inputStream.bufferedReader(Charsets.UTF_8).use { it.readText() }
        } catch (_: Throwable) {
            null
        } finally {
            connection.disconnect()
        }
    }

    internal fun parseWebVtt(raw: String): List<Cue> {
        val lines = raw.replace("\r\n", "\n").replace('\r', '\n').lines()
        val result = mutableListOf<Cue>()
        var i = 0
        while (i < lines.size) {
            var line = lines[i].trim()
            if (line.isBlank() || line == "WEBVTT" || line.startsWith("NOTE") ||
                line.startsWith("STYLE") || line.startsWith("REGION")) {
                i++
                continue
            }

            // Optional cue identifier line before the timestamp.
            if (!line.contains("-->")) {
                if (i + 1 >= lines.size || !lines[i + 1].contains("-->")) {
                    i++
                    continue
                }
                i++
                line = lines[i].trim()
            }

            val arrow = line.indexOf("-->")
            if (arrow < 0) {
                i++
                continue
            }
            val startRaw = line.substring(0, arrow).trim()
            val endRaw = line.substring(arrow + 3).trim().substringBefore(' ').trim()
            val start = parseTimestamp(startRaw)
            if (start == null) {
                i++
                continue
            }
            val end = parseTimestamp(endRaw) ?: (start + 4_000L)
            i++

            val textLines = mutableListOf<String>()
            while (i < lines.size && lines[i].isNotBlank()) {
                textLines += lines[i]
                i++
            }
            val text = cleanCueText(textLines.joinToString(" "))
            if (text.isNotBlank()) result += Cue(start, end.coerceAtLeast(start), text)
        }

        // Some VTT files repeat the same caption text in adjacent cues while
        // progressively revealing a sentence. Keep the timeline but remove
        // exact adjacent duplicates so saved/search text stays clean.
        return result.filterIndexed { index, cue ->
            index == 0 || result[index - 1].text != cue.text || result[index - 1].startMs != cue.startMs
        }
    }

    private fun parseTimestamp(value: String): Long? {
        val parts = value.split(':')
        return try {
            val secondsPart = parts.last().replace(',', '.').toDouble()
            val secondsMs = (secondsPart * 1000.0).toLong()
            when (parts.size) {
                2 -> parts[0].toLong() * 60_000L + secondsMs
                3 -> parts[0].toLong() * 3_600_000L + parts[1].toLong() * 60_000L + secondsMs
                else -> null
            }
        } catch (_: Throwable) {
            null
        }
    }

    private fun cleanCueText(value: String): String = value
        .replace(Regex("<[^>]+>"), " ")
        .replace("&nbsp;", " ")
        .replace("&amp;", "&")
        .replace("&quot;", "\"")
        .replace("&#39;", "'")
        .replace(Regex("\\s+"), " ")
        .trim()

    private fun normalize(value: String): String = value
        .lowercase(java.util.Locale.ROOT)
        .replace(Regex("[^\\p{L}\\p{Nd}]+"), " ")
        .replace(Regex("\\s+"), " ")
        .trim()

    private fun transcriptDir(context: Context): File =
        File(context.filesDir, "video_transcripts").apply { mkdirs() }

    private fun fileFor(context: Context, item: MediaItem): File {
        val baseIdentity = transcriptIdentity(item)
        val language = item.subtitleLanguage.ifBlank { item.contentLanguage }.ifBlank { "E" }
        return hashedTranscriptFile(context, "$baseIdentity|lang:${language.uppercase()}")
    }

    /** Pre-v5.4.386cc path, retained only for one-time language-safe migration. */
    private fun legacyFileFor(context: Context, item: MediaItem): File =
        hashedTranscriptFile(context, transcriptIdentity(item))

    private fun transcriptIdentity(item: MediaItem): String = item.jwKey.ifBlank {
        item.subtitleUrl.ifBlank { item.streamUrl.ifBlank { "media-${item.id}-${item.title}" } }
    }

    private fun hashedTranscriptFile(context: Context, identity: String): File {
        val digest = MessageDigest.getInstance("SHA-256")
            .digest(identity.toByteArray(Charsets.UTF_8))
            .joinToString("") { "%02x".format(it) }
        return File(transcriptDir(context), "$digest.json")
    }

    private fun writeFile(file: File, transcript: Transcript) {
        val root = JSONObject()
            .put("mediaId", transcript.mediaId)
            .put("jwKey", transcript.jwKey)
            .put("title", transcript.title)
            .put("language", transcript.language)
            .put("subtitleUrl", transcript.subtitleUrl)
            .put("complete", transcript.complete)
            .put("updatedAt", transcript.updatedAt)
        val cues = JSONArray()
        transcript.cues.forEach { cue ->
            cues.put(
                JSONObject()
                    .put("startMs", cue.startMs)
                    .put("endMs", cue.endMs)
                    .put("text", cue.text)
            )
        }
        root.put("cues", cues)
        val tmp = File(file.parentFile, file.name + ".tmp")
        tmp.writeText(root.toString(), Charsets.UTF_8)
        if (file.exists()) file.delete()
        if (!tmp.renameTo(file)) {
            file.writeText(root.toString(), Charsets.UTF_8)
            tmp.delete()
        }
        // Keep the dedicated caption sidecar current at write time. Failure is
        // non-fatal: prepareSearchIndex() will repair it later.
        runCatching { indexTranscript(file, transcript) }
    }

    private fun readFile(file: File): Transcript? = runCatching {
        if (!file.exists()) return@runCatching null
        val root = JSONObject(file.readText(Charsets.UTF_8))
        val arr = root.optJSONArray("cues") ?: JSONArray()
        val cues = ArrayList<Cue>(arr.length())
        for (i in 0 until arr.length()) {
            val o = arr.optJSONObject(i) ?: continue
            val text = o.optString("text").trim()
            if (text.isBlank()) continue
            cues += Cue(
                startMs = o.optLong("startMs", 0L),
                endMs = o.optLong("endMs", o.optLong("startMs", 0L) + 4_000L),
                text = text
            )
        }
        Transcript(
            mediaId = root.optLong("mediaId", 0L),
            jwKey = root.optString("jwKey"),
            title = root.optString("title"),
            language = root.optString("language"),
            subtitleUrl = root.optString("subtitleUrl"),
            complete = root.optBoolean("complete", false),
            cues = cues,
            updatedAt = root.optLong("updatedAt", file.lastModified())
        )
    }.getOrNull()
}
