package com.tebogo.markvault.ai

/**
 * Maps selected retrieval models to local LiteRT-LM files.
 */
object RetrievalModelPathResolver {

    fun pathFor(model: RetrievalModelManager.Model): String {
        return when (model) {
            RetrievalModelManager.Model.QWEN2_5_1_5B ->
                "models/Qwen2.5-1.5B-Instruct_multi-prefill-seq_q8_ekv4096.litertlm"
            RetrievalModelManager.Model.QWEN3_0_6B ->
                "models/qwen3_0_6b_mixed_int4.litertlm"
            RetrievalModelManager.Model.PHI4_MINI ->
                "models/Phi-4-mini-instruct_multi-prefill-seq_q8_ekv4096.litertlm"
            RetrievalModelManager.Model.QWEN3_4B ->
                "models/qwen3_4b_channelwise_int8_float32kv.litertlm"
        }
    }
}
