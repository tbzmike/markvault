package com.tebogo.markvault.ai

/**
 * v5.4.73 — Maps retrieval model enum to local filenames.
 *
 * These must match the [ChatModelDescriptor.localFilename] values in
 * [ChatModelCatalog] exactly. Files live in filesDir root (no subfolder).
 */
object RetrievalModelPathResolver {

    fun pathFor(model: RetrievalModelManager.Model): String {
        return when (model) {
            RetrievalModelManager.Model.QWEN2_5_1_5B ->
                "qwen25-1_5b-instruct-q8.litertlm"
            RetrievalModelManager.Model.QWEN3_0_6B ->
                "qwen3-0_6b-mixed-int4.litertlm"
            RetrievalModelManager.Model.PHI4_MINI ->
                "qwen3-4b-channelwise-int8.litertlm"
            RetrievalModelManager.Model.QWEN3_4B ->
                "qwen3-4b-channelwise-int8.litertlm"
        }
    }
}
