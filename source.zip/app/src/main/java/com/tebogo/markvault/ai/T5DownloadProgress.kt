package com.tebogo.markvault.ai

/** Progress state for T5 model installation. */
data class T5DownloadProgress(
    val downloading: Boolean = false,
    val progress: Int = 0,
    val error: String? = null
)
