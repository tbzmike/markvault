package com.tebogo.markvault.ai

/**
 * T5-base paraphrase expansion provider.
 *
 * Uses the T5 inference engine directly. Retrieval remains independent
 * from the model execution layer.
 *
 * BUG FIX: the previous version called [T5InferenceEngine.generate]
 * exactly once per search and tried to split the single result into
 * multiple candidates on `"\\n"` -- which, as a Kotlin string literal, is
 * the two literal characters backslash+n, not an actual newline. Real
 * generated text was never split, so this provider always returned at
 * most one paraphrase regardless of the slider's count -- the slider had
 * no effect at all once T5 was selected. Fixed by calling
 * [expandQuery] with an explicit target [count] and generating up to that
 * many times (using temperature sampling after the first, deterministic,
 * greedy pass so repeated calls aren't identical), stopping once enough
 * distinct paraphrases are collected or the attempt budget runs out.
 */
class T5QueryExpansionProvider(
    private val engine: T5InferenceEngine
) : QueryExpansionProvider {

    /** Interface-required single-shot form; delegates to the count-aware version. */
    override suspend fun expandQuery(query: String): List<String> = expandQuery(query, count = 1)

    /**
     * Generates up to [count] distinct paraphrases of [query]. May return
     * fewer than [count] if the model keeps producing duplicates or empty
     * output within the attempt budget -- that's a real model-diversity
     * limit, not silently capped by this code.
     */
    suspend fun expandQuery(query: String, count: Int): List<String> {
        val trimmed = query.trim()
        if (trimmed.isEmpty() || count <= 0) return emptyList()

        val originalLower = trimmed.lowercase()
        val maxAttempts = (count * 3).coerceAtLeast(count)
        val raw = try {
            engine.generateMany("paraphrase: $trimmed", count, maxAttempts)
        } catch (_: Exception) {
            emptyList()
        }

        return raw
            .map { it.trim() }
            .filter { it.isNotEmpty() && it.lowercase() != originalLower }
            .distinct()
            .take(count)
    }

    override fun modelName(): String = "T5-base"
}
