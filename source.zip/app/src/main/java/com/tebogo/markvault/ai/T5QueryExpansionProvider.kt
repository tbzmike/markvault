package com.tebogo.markvault.ai

/**
 * T5-base paraphrase expansion provider.
 *
 * Uses the T5 inference engine directly. Retrieval remains independent
 * from the model execution layer.
 */
class T5QueryExpansionProvider(
    private val engine: T5InferenceEngine
) : QueryExpansionProvider {

    override suspend fun expandQuery(query: String): List<String> {
        if (query.isBlank()) return emptyList()

        return try {
            val generated = engine.generate(query)

            generated
                .split("\\n", "|", ";")
                .map { it.trim() }
                .filter { it.isNotEmpty() && it != query }
                .distinct()
        } catch (_: Exception) {
            emptyList()
        }
    }

    override fun modelName(): String = "T5-base"
}
