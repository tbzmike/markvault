package com.tebogo.markvault.ai

/**
 * T5-base paraphrase expansion provider.
 *
 * This provider is separated from the LLM expansion pipeline.
 * The model inference implementation will be connected through the
 * existing local model runtime.
 */
class T5QueryExpansionProvider(
    private val inference: suspend (String) -> List<String>
) : QueryExpansionProvider {

    override suspend fun expandQuery(query: String): List<String> {
        return inference(query)
            .map { it.trim() }
            .filter { it.isNotEmpty() }
            .distinct()
    }

    override fun modelName(): String = "T5-base"
}
