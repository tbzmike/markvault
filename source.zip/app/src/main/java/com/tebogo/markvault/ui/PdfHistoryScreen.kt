package com.tebogo.markvault.ui

import android.content.Intent
import android.net.Uri
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.navigation.NavController
import com.tebogo.markvault.AppViewModel
import com.tebogo.markvault.data.PdfHistoryEntry
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/**
 * Displays every PDF that has been opened — library notes and external files
 * (from file managers, downloads, chat apps, etc). Tap an entry to reopen it.
 */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun PdfHistoryScreen(vm: AppViewModel, nav: NavController) {
    val ctx = LocalContext.current
    var entries by remember { mutableStateOf<List<PdfHistoryEntry>>(emptyList()) }
    var loading by remember { mutableStateOf(true) }
    var confirmClear by remember { mutableStateOf(false) }
    var reloadCounter by remember { mutableStateOf(0) }

    LaunchedEffect(reloadCounter) {
        loading = true
        entries = vm.loadPdfHistory(limit = 200)
        loading = false
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("\uD83D\uDCDC PDF history") },
                navigationIcon = {
                    IconButton(onClick = { nav.popBackStack() }) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back")
                    }
                },
                actions = {
                    if (entries.isNotEmpty()) {
                        IconButton(onClick = { confirmClear = true }) {
                            Icon(Icons.Default.Delete, contentDescription = "Clear all history")
                        }
                    }
                }
            )
        }
    ) { pad ->
        when {
            loading -> Box(
                Modifier.padding(pad).fillMaxSize(),
                contentAlignment = Alignment.Center
            ) { Text("Loading\u2026", color = MaterialTheme.colorScheme.onSurfaceVariant) }
            entries.isEmpty() -> Box(
                Modifier.padding(pad).fillMaxSize(),
                contentAlignment = Alignment.Center
            ) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Text("\uD83D\uDCDC", fontSize = 36.sp)
                    Spacer(Modifier.height(8.dp))
                    Text(
                        "No PDFs opened yet.",
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                    Text(
                        "PDFs from your library and external files\nwill show up here once you open them.",
                        textAlign = androidx.compose.ui.text.style.TextAlign.Center,
                        fontSize = 12.sp,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        modifier = Modifier.padding(top = 4.dp)
                    )
                }
            }
            else -> LazyColumn(Modifier.padding(pad).fillMaxSize()) {
                items(entries, key = { it.id }) { entry ->
                    PdfHistoryRow(
                        entry = entry,
                        onTap = {
                            if (entry.isExternal || entry.noteId == 0L) {
                                // Re-open external PDF via system viewer chain
                                runCatching {
                                    val intent = Intent(Intent.ACTION_VIEW).apply {
                                        setDataAndType(Uri.parse(entry.uri), "application/pdf")
                                        addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                                        addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                                    }
                                    ctx.startActivity(intent)
                                }
                            } else {
                                vm.openArticle(entry.noteId, entry.title, fileType = "pdf")
                                nav.navigate("pdfReader/${entry.noteId}")
                            }
                        },
                        onDelete = {
                            vm.deletePdfHistoryEntry(entry.id)
                            reloadCounter++
                        }
                    )
                    HistoryBoldDivider()
                }
                item { Spacer(Modifier.height(40.dp)) }
            }
        }
    }

    if (confirmClear) {
        AlertDialog(
            onDismissRequest = { confirmClear = false },
            title = { Text("Clear PDF history?") },
            text = { Text("This removes every entry from PDF history. The PDF files themselves are not affected.") },
            confirmButton = {
                Button(onClick = {
                    vm.clearPdfHistory()
                    confirmClear = false
                    reloadCounter++
                }) { Text("Clear all") }
            },
            dismissButton = { TextButton(onClick = { confirmClear = false }) { Text("Cancel") } }
        )
    }
}

@Composable
private fun PdfHistoryRow(
    entry: PdfHistoryEntry,
    onTap: () -> Unit,
    onDelete: () -> Unit
) {
    Row(
        Modifier.fillMaxWidth().clickable { onTap() }
            .padding(horizontal = 18.dp, vertical = 12.dp),
        verticalAlignment = Alignment.Top
    ) {
        Text("\uD83D\uDCD5", fontSize = 22.sp, modifier = Modifier.padding(top = 2.dp))
        Spacer(Modifier.width(12.dp))
        Column(Modifier.weight(1f)) {
            // Line 1: title
            Text(
                entry.title,
                fontSize = 15.sp,
                fontWeight = FontWeight.SemiBold,
                maxLines = 2, overflow = TextOverflow.Ellipsis
            )
            Spacer(Modifier.height(3.dp))
            // Line 2: source badge
            Row(verticalAlignment = Alignment.CenterVertically) {
                Surface(
                    color = if (entry.isExternal)
                        MaterialTheme.colorScheme.tertiaryContainer
                    else MaterialTheme.colorScheme.secondaryContainer,
                    shape = RoundedCornerShape(6.dp)
                ) {
                    Text(
                        if (entry.isExternal) "EXTERNAL" else "LIBRARY",
                        fontSize = 9.sp,
                        fontWeight = FontWeight.Bold,
                        color = if (entry.isExternal)
                            MaterialTheme.colorScheme.onTertiaryContainer
                        else MaterialTheme.colorScheme.onSecondaryContainer,
                        modifier = Modifier.padding(horizontal = 7.dp, vertical = 2.dp)
                    )
                }
            }
            Spacer(Modifier.height(4.dp))
            // Line 3: timestamp in accent colour
            Text(
                formatHistoryTime(entry.openedAt),
                fontSize = 11.sp,
                fontWeight = FontWeight.Medium,
                color = MaterialTheme.colorScheme.primary
            )
        }
        IconButton(onClick = onDelete, modifier = Modifier.size(36.dp)) {
            Icon(
                Icons.Default.Delete,
                contentDescription = "Remove from history",
                tint = MaterialTheme.colorScheme.onSurfaceVariant
            )
        }
    }
}

/** Old relative-only formatter retained for backwards compat (no longer used directly). */
private fun formatRelative(ts: Long): String {
    val diffMs = System.currentTimeMillis() - ts
    val mins = diffMs / 60_000
    val hours = mins / 60
    val days = hours / 24
    return when {
        mins < 1 -> "just now"
        mins < 60 -> "$mins min ago"
        hours < 24 -> if (hours == 1L) "1 hour ago" else "$hours hours ago"
        days == 1L -> "yesterday"
        days < 7 -> "$days days ago"
        else -> SimpleDateFormat("d MMM yyyy", Locale.getDefault()).format(Date(ts))
    }
}
