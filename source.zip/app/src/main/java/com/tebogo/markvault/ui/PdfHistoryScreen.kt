package com.tebogo.markvault.ui

import android.content.Intent
import android.net.Uri
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.ui.graphics.asImageBitmap
import kotlinx.coroutines.withContext
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.navigation.NavController
import com.tebogo.markvault.AppViewModel
import com.tebogo.markvault.data.PdfHistoryEntry
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/**
 * Displays every PDF that has been opened — library notes and external files
 * (from file managers, downloads, chat apps, etc). Tap an entry to reopen it.
 */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun PdfHistoryScreen(vm: AppViewModel, nav: NavController) {
    val ctx = LocalContext.current
    var entries by remember { mutableStateOf<List<PdfHistoryEntry>>(emptyList()) }
    var loading by remember { mutableStateOf(true) }
    var confirmClear by remember { mutableStateOf(false) }
    var reloadCounter by remember { mutableStateOf(0) }
    // View mode: false = list (3-line rows), true = grid (thumbnail cards)
    var gridMode by remember { mutableStateOf(false) }

    LaunchedEffect(reloadCounter) {
        loading = true
        entries = vm.loadPdfHistory(limit = 200)
        loading = false
    }

    Scaffold(
        topBar = { TopAppBar(title = { Text("\uD83D\uDCDC PDF history") }) },
        bottomBar = {
            MarkVaultBottomBar(
                nav = nav, vm = vm,
                extraActions = {
                    IconButton(onClick = { gridMode = !gridMode }) {
                        Text(if (gridMode) "\u2630" else "\u25A6", fontSize = 18.sp)
                    }
                    if (entries.isNotEmpty()) {
                        IconButton(onClick = { confirmClear = true }) {
                            Icon(Icons.Default.Delete, contentDescription = "Clear all history")
                        }
                    }
                }
            )
        }
    ) { pad ->
        when {
            loading -> Box(
                Modifier.padding(pad).fillMaxSize(),
                contentAlignment = Alignment.Center
            ) { Text("Loading\u2026", color = MaterialTheme.colorScheme.onSurfaceVariant) }
            entries.isEmpty() -> Box(
                Modifier.padding(pad).fillMaxSize(),
                contentAlignment = Alignment.Center
            ) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Text("\uD83D\uDCDC", fontSize = 36.sp)
                    Spacer(Modifier.height(8.dp))
                    Text(
                        "No PDFs opened yet.",
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                    Text(
                        "PDFs from your library and external files\nwill show up here once you open them.",
                        textAlign = androidx.compose.ui.text.style.TextAlign.Center,
                        fontSize = 12.sp,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        modifier = Modifier.padding(top = 4.dp)
                    )
                }
            }
            else -> {
                // Reusable tap / delete handlers (same for list and grid modes)
                val onTapEntry: (PdfHistoryEntry) -> Unit = { entry ->
                    if (entry.isExternal || entry.noteId == 0L) {
                        runCatching {
                            val intent = Intent(Intent.ACTION_VIEW).apply {
                                setDataAndType(Uri.parse(entry.uri), "application/pdf")
                                addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                            }
                            ctx.startActivity(intent)
                        }
                    } else {
                        vm.openArticle(entry.noteId, entry.title, fileType = "pdf")
                        nav.navigate("pdfReader/${entry.noteId}")
                    }
                }
                val onDeleteEntry: (PdfHistoryEntry) -> Unit = { entry ->
                    vm.deletePdfHistoryEntry(entry.id)
                    reloadCounter++
                }

                if (gridMode) {
                    androidx.compose.foundation.lazy.grid.LazyVerticalGrid(
                        columns = androidx.compose.foundation.lazy.grid.GridCells.Fixed(2),
                        modifier = Modifier.padding(pad).fillMaxSize(),
                        contentPadding = androidx.compose.foundation.layout.PaddingValues(10.dp),
                        horizontalArrangement = Arrangement.spacedBy(10.dp),
                        verticalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        items(entries, key = { it.id }) { entry ->
                            PdfHistoryGridCard(
                                entry = entry,
                                onTap = { onTapEntry(entry) }
                            )
                        }
                    }
                } else {
                    LazyColumn(Modifier.padding(pad).fillMaxSize()) {
                        items(entries, key = { it.id }) { entry ->
                            PdfHistoryRow(
                                entry = entry,
                                onTap = { onTapEntry(entry) },
                                onDelete = { onDeleteEntry(entry) }
                            )
                            HistoryBoldDivider()
                        }
                        item { Spacer(Modifier.height(40.dp)) }
                    }
                }
            }
        }
    }

    if (confirmClear) {
        AlertDialog(
            onDismissRequest = { confirmClear = false },
            title = { Text("Clear PDF history?") },
            text = { Text("This removes every entry from PDF history. The PDF files themselves are not affected.") },
            confirmButton = {
                Button(onClick = {
                    vm.clearPdfHistory()
                    confirmClear = false
                    reloadCounter++
                }) { Text("Clear all") }
            },
            dismissButton = { TextButton(onClick = { confirmClear = false }) { Text("Cancel") } }
        )
    }
}

/**
 * Grid-mode card: large thumbnail of the PDF's first page + title + accent timestamp.
 * Thumbnails are rendered on demand and cached to disk under cache/pdf_thumbs/.
 */
@Composable
private fun PdfHistoryGridCard(entry: PdfHistoryEntry, onTap: () -> Unit) {
    val ctx = LocalContext.current
    var thumb by remember(entry.uri) { mutableStateOf<android.graphics.Bitmap?>(null) }
    var thumbLoadFailed by remember(entry.uri) { mutableStateOf(false) }

    LaunchedEffect(entry.uri) {
        thumb = withContext(kotlinx.coroutines.Dispatchers.IO) {
            runCatching { loadOrRenderPdfThumb(ctx, entry.uri) }.getOrNull()
        }
        if (thumb == null) thumbLoadFailed = true
    }

    Surface(
        color = MaterialTheme.colorScheme.surfaceVariant,
        shape = RoundedCornerShape(10.dp),
        border = androidx.compose.foundation.BorderStroke(
            1.5.dp, MaterialTheme.colorScheme.outlineVariant
        ),
        modifier = Modifier.fillMaxWidth().clickable { onTap() }
    ) {
        Column {
            // Thumbnail area (3:4 aspect, white background like a real page)
            Box(
                Modifier
                    .fillMaxWidth()
                    .height(180.dp)
                    .background(androidx.compose.ui.graphics.Color.White),
                contentAlignment = Alignment.Center
            ) {
                val t = thumb
                if (t != null) {
                    androidx.compose.foundation.Image(
                        bitmap = t.asImageBitmap(),
                        contentDescription = entry.title,
                        modifier = Modifier.fillMaxWidth().height(180.dp),
                        contentScale = androidx.compose.ui.layout.ContentScale.Crop
                    )
                } else if (thumbLoadFailed) {
                    Text("\uD83D\uDCD5", fontSize = 48.sp)
                } else {
                    Text("\u2026",
                        color = androidx.compose.ui.graphics.Color.Gray,
                        fontSize = 24.sp)
                }
            }
            // Caption: title + timestamp
            Column(Modifier.padding(8.dp)) {
                Text(
                    entry.title,
                    fontSize = 12.sp,
                    fontWeight = FontWeight.SemiBold,
                    maxLines = 2, overflow = TextOverflow.Ellipsis,
                    lineHeight = 14.sp
                )
                Spacer(Modifier.height(4.dp))
                Row(verticalAlignment = Alignment.CenterVertically) {
                    if (entry.isExternal) {
                        Text("EXT \u00B7 ", fontSize = 9.sp,
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.tertiary)
                    }
                    Text(
                        formatHistoryTime(entry.openedAt),
                        fontSize = 10.sp,
                        fontWeight = FontWeight.Medium,
                        color = MaterialTheme.colorScheme.primary,
                        maxLines = 1, overflow = TextOverflow.Ellipsis
                    )
                }
            }
        }
    }
}

/**
 * Render (or load from cache) a thumbnail of the first page of a PDF.
 * Cache lives in cache/pdf_thumbs/<sha-of-uri>.png. Small thumbs (~400px wide)
 * so memory footprint stays modest even for hundreds of history entries.
 */
private fun loadOrRenderPdfThumb(
    ctx: android.content.Context,
    uri: String
): android.graphics.Bitmap? {
    val cacheDir = java.io.File(ctx.cacheDir, "pdf_thumbs").apply { mkdirs() }
    // Hash the URI for a stable filename (no special chars)
    val hash = java.security.MessageDigest.getInstance("SHA-1")
        .digest(uri.toByteArray()).joinToString("") { "%02x".format(it) }
    val cacheFile = java.io.File(cacheDir, "$hash.png")
    if (cacheFile.exists()) {
        return runCatching { android.graphics.BitmapFactory.decodeFile(cacheFile.absolutePath) }.getOrNull()
    }
    // Render fresh
    val pfd = runCatching {
        ctx.contentResolver.openFileDescriptor(Uri.parse(uri), "r")
    }.getOrNull() ?: return null
    return pfd.use { d ->
        runCatching {
            val renderer = android.graphics.pdf.PdfRenderer(d)
            renderer.use { r ->
                if (r.pageCount == 0) return@runCatching null
                r.openPage(0).use { page ->
                    val targetW = 400
                    val ratio = targetW.toFloat() / page.width
                    val h = (page.height * ratio).toInt()
                    val bmp = android.graphics.Bitmap.createBitmap(
                        targetW, h, android.graphics.Bitmap.Config.ARGB_8888
                    ).apply { eraseColor(android.graphics.Color.WHITE) }
                    page.render(bmp, null, null,
                        android.graphics.pdf.PdfRenderer.Page.RENDER_MODE_FOR_DISPLAY)
                    // Persist to cache
                    runCatching {
                        java.io.FileOutputStream(cacheFile).use { out ->
                            bmp.compress(android.graphics.Bitmap.CompressFormat.PNG, 85, out)
                        }
                    }
                    bmp
                }
            }
        }.getOrNull()
    }
}

@Composable
private fun PdfHistoryRow(
    entry: PdfHistoryEntry,
    onTap: () -> Unit,
    onDelete: () -> Unit
) {
    Row(
        Modifier.fillMaxWidth().clickable { onTap() }
            .padding(horizontal = 18.dp, vertical = 12.dp),
        verticalAlignment = Alignment.Top
    ) {
        Text("\uD83D\uDCD5", fontSize = 22.sp, modifier = Modifier.padding(top = 2.dp))
        Spacer(Modifier.width(12.dp))
        Column(Modifier.weight(1f)) {
            // Line 1: title
            Text(
                entry.title,
                fontSize = 15.sp,
                fontWeight = FontWeight.SemiBold,
                maxLines = 2, overflow = TextOverflow.Ellipsis
            )
            Spacer(Modifier.height(3.dp))
            // Line 2: source badge
            Row(verticalAlignment = Alignment.CenterVertically) {
                Surface(
                    color = if (entry.isExternal)
                        MaterialTheme.colorScheme.tertiaryContainer
                    else MaterialTheme.colorScheme.secondaryContainer,
                    shape = RoundedCornerShape(6.dp)
                ) {
                    Text(
                        if (entry.isExternal) "EXTERNAL" else "LIBRARY",
                        fontSize = 9.sp,
                        fontWeight = FontWeight.Bold,
                        color = if (entry.isExternal)
                            MaterialTheme.colorScheme.onTertiaryContainer
                        else MaterialTheme.colorScheme.onSecondaryContainer,
                        modifier = Modifier.padding(horizontal = 7.dp, vertical = 2.dp)
                    )
                }
            }
            Spacer(Modifier.height(4.dp))
            // Line 3: timestamp in accent colour
            Text(
                formatHistoryTime(entry.openedAt),
                fontSize = 11.sp,
                fontWeight = FontWeight.Medium,
                color = MaterialTheme.colorScheme.primary
            )
        }
        IconButton(onClick = onDelete, modifier = Modifier.size(36.dp)) {
            Icon(
                Icons.Default.Delete,
                contentDescription = "Remove from history",
                tint = MaterialTheme.colorScheme.onSurfaceVariant
            )
        }
    }
}

/** Old relative-only formatter retained for backwards compat (no longer used directly). */
private fun formatRelative(ts: Long): String {
    val diffMs = System.currentTimeMillis() - ts
    val mins = diffMs / 60_000
    val hours = mins / 60
    val days = hours / 24
    return when {
        mins < 1 -> "just now"
        mins < 60 -> "$mins min ago"
        hours < 24 -> if (hours == 1L) "1 hour ago" else "$hours hours ago"
        days == 1L -> "yesterday"
        days < 7 -> "$days days ago"
        else -> SimpleDateFormat("d MMM yyyy", Locale.getDefault()).format(Date(ts))
    }
}
