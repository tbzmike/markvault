package com.tebogo.markvault

import android.app.Application
import android.content.ComponentCallbacks2
import android.content.res.Configuration
import android.util.Log
import com.tom_roush.pdfbox.android.PDFBoxResourceLoader

class MarkVaultApp : Application() {
    /**
     * v5.4.0 — Weak handle to the active VM. Set by [AppViewModel]'s
     * init block. Lets the process-level memory callbacks below reach
     * the VM without forcing a hard reference that would defeat the
     * VM's own garbage collection.
     */
    @Volatile var sharedVm: AppViewModel? = null

    override fun onCreate() {
        super.onCreate()
        // v5.3.1 — Last-resort crash defender.
        val priorHandler = Thread.getDefaultUncaughtExceptionHandler()
        Thread.setDefaultUncaughtExceptionHandler { thread, throwable ->
            Log.e("MarkVault", "Uncaught on ${thread.name}", throwable)
            if (throwable is OutOfMemoryError) {
                runCatching { System.gc() }
            }
            try {
                priorHandler?.uncaughtException(thread, throwable)
            } catch (_: Throwable) {}
        }

        // Initialize PDFBox resource loader once for the app's lifetime.
        runCatching { PDFBoxResourceLoader.init(applicationContext) }

        // v5.4.0 — Android memory-pressure callbacks. Fires when the OS
        // hides our UI (TRIM_MEMORY_UI_HIDDEN, ~5 s after home button)
        // and again at progressively-tighter levels. Each level >=
        // UI_HIDDEN triggers a freeMemory() pass that releases ~490 MB
        // of native + heap (embedder, reranker, semantic index, tab
        // thumbnails). No extra Gradle dependency — onTrimMemory is
        // part of plain Android since API 14.
        registerComponentCallbacks(object : ComponentCallbacks2 {
            override fun onTrimMemory(level: Int) {
                if (level >= ComponentCallbacks2.TRIM_MEMORY_UI_HIDDEN) {
                    Log.i("MarkVault", "Trim level $level — releasing models")
                    sharedVm?.freeMemory()
                }
            }
            override fun onLowMemory() {
                Log.w("MarkVault", "onLowMemory — releasing models")
                sharedVm?.freeMemory()
            }
            override fun onConfigurationChanged(newConfig: Configuration) {}
        })
    }
}
