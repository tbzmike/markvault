package com.tebogo.markvault

import android.app.Application
import com.tom_roush.pdfbox.android.PDFBoxResourceLoader

class MarkVaultApp : Application() {
    override fun onCreate() {
        super.onCreate()
        // Initialize PDFBox resource loader once for the app's lifetime.
        // Required for text extraction in the PDF viewer.
        runCatching { PDFBoxResourceLoader.init(applicationContext) }
    }
}
