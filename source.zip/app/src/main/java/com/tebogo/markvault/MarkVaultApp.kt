package com.tebogo.markvault

import android.app.Application
import android.util.Log
import com.tom_roush.pdfbox.android.PDFBoxResourceLoader

class MarkVaultApp : Application() {
    override fun onCreate() {
        super.onCreate()
        // v5.3.1 — Last-resort crash defender. Wraps the previously-set
        // uncaught handler so we still get whatever Android's framework
        // logged, then catches anything that escapes our per-call
        // try/catch nets in the search pipeline (chiefly background
        // coroutines that touch native ONNX code). If the throwable
        // looks like an OutOfMemoryError we explicitly hint at GC to
        // recover for the next operation instead of letting the JVM
        // tear down the process.
        val priorHandler = Thread.getDefaultUncaughtExceptionHandler()
        Thread.setDefaultUncaughtExceptionHandler { thread, throwable ->
            Log.e("MarkVault", "Uncaught on ${thread.name}", throwable)
            if (throwable is OutOfMemoryError) {
                runCatching { System.gc() }
            }
            // Defer to the prior handler (usually the system default) so
            // Crashlytics / Logcat still see the event. Only the very last
            // handler in the chain actually terminates the process; we
            // still want that for genuine UI-thread crashes that can't
            // recover (corrupt state). What we DON'T want is the process
            // dying when a background coroutine in the search pipeline
            // throws and bubbles up — the user-facing impact of that is
            // "search results were empty for this query" not "app dies".
            try {
                priorHandler?.uncaughtException(thread, throwable)
            } catch (_: Throwable) {}
        }

        // Initialize PDFBox resource loader once for the app's lifetime.
        // Required for text extraction in the PDF viewer.
        runCatching { PDFBoxResourceLoader.init(applicationContext) }
    }
}
