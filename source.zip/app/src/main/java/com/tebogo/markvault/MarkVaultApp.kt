package com.tebogo.markvault

import android.app.Application
import android.content.ComponentCallbacks2
import android.content.res.Configuration
import android.util.Log
import com.tom_roush.pdfbox.android.PDFBoxResourceLoader

class MarkVaultApp : Application() {
    /**
     * v5.4.0 — Weak handle to the active VM. Set by [AppViewModel]'s
     * init block. Lets the process-level memory callbacks below reach
     * the VM without forcing a hard reference that would defeat the
     * VM's own garbage collection.
     */
    @Volatile var sharedVm: AppViewModel? = null

    /**
     * v5.4.94cc — App-wide activity log. Lazily initialised on first
     * access so any early call site (VM constructor, first
     * BatchSaveService tick) picks up the same singleton.
     */
    val activityLog: com.tebogo.markvault.data.ActivityLog by lazy {
        com.tebogo.markvault.data.ActivityLog(this).also { it.refreshFromDisk() }
    }

    override fun onCreate() {
        super.onCreate()
        // v5.4.131cc — CrashLogger installs the app-wide uncaught
        // exception handler, writes a detailed report to
        // filesDir/crash_logs/ before delegating to whatever prior
        // handler was installed (typically Android's default which
        // shows the crash dialog and kills the process). Replaces the
        // v5.3.1 inline handler that only wrote to Logcat; the same
        // Logcat trace + OOM gc + priorHandler chaining is preserved
        // inside CrashLogger.init.
        com.tebogo.markvault.util.CrashLogger.init(this)

        // Initialize PDFBox resource loader once for the app's lifetime.
        runCatching { PDFBoxResourceLoader.init(applicationContext) }

        // v5.4.0 — Android memory-pressure callbacks. Fires when the OS
        // hides our UI (TRIM_MEMORY_UI_HIDDEN, ~5 s after home button)
        // and again at progressively-tighter levels. Each level >=
        // UI_HIDDEN triggers a freeMemory() pass that releases ~490 MB
        // of native + heap (embedder, reranker, semantic index, tab
        // thumbnails). No extra Gradle dependency — onTrimMemory is
        // part of plain Android since API 14.
        registerComponentCallbacks(object : ComponentCallbacks2 {
            override fun onTrimMemory(level: Int) {
                if (level >= ComponentCallbacks2.TRIM_MEMORY_UI_HIDDEN) {
                    Log.i("MarkVault", "Trim level $level — releasing models")
                    sharedVm?.freeMemoryAuto()
                }
            }
            override fun onLowMemory() {
                Log.w("MarkVault", "onLowMemory — releasing models")
                sharedVm?.freeMemoryAuto()
            }
            override fun onConfigurationChanged(newConfig: Configuration) {}
        })
    }
}
