package com.tebogo.markvault

import android.app.Application
import android.content.ComponentCallbacks2
import android.content.res.Configuration
import android.util.Log
import coil.ImageLoader
import coil.ImageLoaderFactory
import coil.memory.MemoryCache
import com.tom_roush.pdfbox.android.PDFBoxResourceLoader

class MarkVaultApp : Application(), ImageLoaderFactory {

    /**
     * v5.4.241cc — Coil was running on pure defaults everywhere in the
     * app (every AsyncImage — search thumbnails, media cards, mini-player,
     * chooser previews) since it was never configured at all. Coil's
     * default memory cache sizes itself as a percentage of available app
     * memory with NO connection to anything MarkVault's own cleanup code
     * does — it's a completely separate singleton that survives every
     * .close()/.unload()/System.gc() call in AppViewModel, and can only
     * be explicitly cleared through Coil's own API. Bounded small here,
     * AND explicitly cleared by every memory-cleanup path in AppViewModel
     * (see clearImageCache()).
     */
    override fun newImageLoader(): ImageLoader {
        return ImageLoader.Builder(this)
            .memoryCache {
                MemoryCache.Builder(this)
                    .maxSizePercent(0.05)   // bounded small — was unbounded default
                    .build()
            }
            .build()
    }
    /**
     * v5.4.0 — Weak handle to the active VM. Set by [AppViewModel]'s
     * init block. Lets the process-level memory callbacks below reach
     * the VM without forcing a hard reference that would defeat the
     * VM's own garbage collection.
     */
    @Volatile var sharedVm: AppViewModel? = null

    /**
     * v5.4.94cc — App-wide activity log. Lazily initialised on first
     * access so any early call site (VM constructor, first
     * BatchSaveService tick) picks up the same singleton.
     */
    val activityLog: com.tebogo.markvault.data.ActivityLog by lazy {
        com.tebogo.markvault.data.ActivityLog(this).also { it.refreshFromDisk() }
    }

    override fun onCreate() {
        super.onCreate()

        // v5.4.305cc — Restore settings only on a cold process start. BackupManager
        // deliberately stages DataStore during restore instead of replacing an
        // actively-open preferences file. This runs before any screen/ViewModel
        // can create the settings DataStore singleton.
        com.tebogo.markvault.data.BackupManager.applyPendingDatastoreRestore(this)

        // v5.4.131cc — CrashLogger installs the app-wide uncaught
        // exception handler, writes a detailed report to
        // filesDir/crash_logs/ before delegating to whatever prior
        // handler was installed (typically Android's default which
        // shows the crash dialog and kills the process). Replaces the
        // v5.3.1 inline handler that only wrote to Logcat; the same
        // Logcat trace + OOM gc + priorHandler chaining is preserved
        // inside CrashLogger.init.
        com.tebogo.markvault.util.CrashLogger.init(this)

        // Initialize PDFBox resource loader once for the app's lifetime.
        runCatching { PDFBoxResourceLoader.init(applicationContext) }

        // v5.4.247cc — Prime the Cast SDK singleton early so that
        // PlaybackService.onCreate() can call getSharedInstance() without
        // blocking. Must run on the main thread (Application.onCreate()
        // already is). runCatching guards against devices / custom ROMs
        // that ship without Google Play Services — local-only playback
        // continues to work normally on those devices.
        runCatching {
            com.google.android.gms.cast.framework.CastContext.getSharedInstance(this)
        }

        // v5.4.0 — Android memory-pressure callbacks. Fires when the OS
        // hides our UI (TRIM_MEMORY_UI_HIDDEN, ~5 s after home button)
        // and again at progressively-tighter levels. Each level >=
        // UI_HIDDEN triggers a freeMemory() pass that releases ~490 MB
        // of native + heap (embedder, reranker, semantic index, tab
        // thumbnails). No extra Gradle dependency — onTrimMemory is
        // part of plain Android since API 14.
        registerComponentCallbacks(object : ComponentCallbacks2 {
            override fun onTrimMemory(level: Int) {
                if (level >= ComponentCallbacks2.TRIM_MEMORY_UI_HIDDEN) {
                    Log.i("MarkVault", "Trim level $level — releasing models")
                    sharedVm?.freeMemoryAuto()
                }
            }
            override fun onLowMemory() {
                Log.w("MarkVault", "onLowMemory — releasing models")
                sharedVm?.freeMemoryAuto()
            }
            override fun onConfigurationChanged(newConfig: Configuration) {}
        })
    }
}
