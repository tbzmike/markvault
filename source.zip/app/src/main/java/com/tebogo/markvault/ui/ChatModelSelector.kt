package com.tebogo.markvault.ui

import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import com.tebogo.markvault.llm.ChatModelCatalog

@Composable
fun ChatModelSelector() {
    ChatModelCatalog.models().forEach {
        Text(it.name)
    }
}
