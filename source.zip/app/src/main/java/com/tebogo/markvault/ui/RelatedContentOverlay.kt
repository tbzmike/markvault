package com.tebogo.markvault.ui

import android.net.Uri
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.navigation.NavController
import coil.compose.AsyncImage
import com.tebogo.markvault.AppViewModel
import com.tebogo.markvault.data.RelatedArticleMatch
import com.tebogo.markvault.data.RelatedVideoMatch

@OptIn(ExperimentalFoundationApi::class)
@Composable
fun RelatedVideosCarousel(
    vm: AppViewModel,
    matches: List<RelatedVideoMatch>,
    onClose: () -> Unit
) {
    var horizontal by remember { mutableStateOf(true) }
    var longPressed by remember { mutableStateOf<RelatedVideoMatch?>(null) }
    Surface(tonalElevation = 10.dp, shadowElevation = 14.dp, shape = MaterialTheme.shapes.large) {
        Column(Modifier.fillMaxWidth().padding(8.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text("Related videos", fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f))
                TextButton(onClick = { horizontal = !horizontal }) { Text(if (horizontal) "Vertical" else "Horizontal") }
                IconButton(onClick = onClose) { Text("✕") }
            }
            // Defensive UI de-duplication: related discovery can briefly expose the cached
            // pass before the online-enriched pass finishes. Older media databases may contain
            // more than one row for the same JW key, and LazyRow/LazyColumn require unique keys.
            val visibleMatches = remember(matches) {
                matches.distinctBy { m ->
                    when {
                        m.item.jwKey.isNotBlank() -> "jw:${m.item.jwKey.trim().lowercase()}"
                        m.item.streamUrl.isNotBlank() -> "url:${m.item.streamUrl.trim()}"
                        m.item.id > 0L -> "id:${m.item.id}"
                        else -> "fallback:${m.item.title.trim().lowercase()}|${m.item.category.trim().lowercase()}"
                    }
                }
            }
            if (horizontal) LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                itemsIndexed(visibleMatches, key = { index, m ->
                    val identity = when {
                        m.item.jwKey.isNotBlank() -> "jw:${m.item.jwKey.trim().lowercase()}"
                        m.item.streamUrl.isNotBlank() -> "url:${m.item.streamUrl.trim()}"
                        m.item.id > 0L -> "id:${m.item.id}"
                        else -> "fallback:${m.item.title.trim().lowercase()}|${m.item.category.trim().lowercase()}"
                    }
                    "$identity#$index"
                }) { _, m -> RelatedVideoCard(vm, m, Modifier.width(220.dp), { longPressed = m }) }
            } else LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.heightIn(max = 430.dp)) {
                itemsIndexed(visibleMatches, key = { index, m ->
                    val identity = when {
                        m.item.jwKey.isNotBlank() -> "jw:${m.item.jwKey.trim().lowercase()}"
                        m.item.streamUrl.isNotBlank() -> "url:${m.item.streamUrl.trim()}"
                        m.item.id > 0L -> "id:${m.item.id}"
                        else -> "fallback:${m.item.title.trim().lowercase()}|${m.item.category.trim().lowercase()}"
                    }
                    "$identity#$index"
                }) { _, m -> RelatedVideoCard(vm, m, Modifier.fillMaxWidth(), { longPressed = m }) }
            }
        }
    }
    longPressed?.let { m ->
        AlertDialog(onDismissRequest = { longPressed = null }, title = { Text("Why this video was suggested") },
            text = { Text(m.reason) }, confirmButton = { TextButton(onClick = { longPressed = null }) { Text("Close") } })
    }
}

@OptIn(ExperimentalFoundationApi::class)
@Composable
private fun RelatedVideoCard(vm: AppViewModel, m: RelatedVideoMatch, modifier: Modifier, onLong: () -> Unit) {
    Card(modifier.combinedClickable(onClick = { vm.playMedia(m.item); vm.requestMediaPopup(m.item) }, onLongClick = onLong)) {
        Column {
            AsyncImage(model = m.item.thumbnailUrl, contentDescription = m.item.title, modifier = Modifier.fillMaxWidth().height(118.dp))
            Text(m.item.title, fontWeight = FontWeight.SemiBold, fontSize = 13.sp, maxLines = 2, overflow = TextOverflow.Ellipsis, modifier = Modifier.padding(8.dp))
            Text(if (m.cached) "Cached" else "Online", fontSize = 11.sp, modifier = Modifier.padding(horizontal = 8.dp, vertical = 2.dp))
        }
    }
}

@OptIn(ExperimentalFoundationApi::class)
@Composable
fun RelatedArticlesCarousel(vm: AppViewModel, nav: NavController, mediaTitle: String, matches: List<RelatedArticleMatch>, onClose: () -> Unit) {
    var horizontal by remember { mutableStateOf(false) }
    var preview by remember { mutableStateOf<RelatedArticleMatch?>(null) }
    Surface(tonalElevation = 10.dp, shadowElevation = 14.dp, shape = MaterialTheme.shapes.large) {
        Column(Modifier.fillMaxWidth().padding(8.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text("Related articles", fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f))
                TextButton(onClick = { horizontal = !horizontal }) { Text(if (horizontal) "Vertical" else "Horizontal") }
                IconButton(onClick = onClose) { Text("✕") }
            }
            val card: @Composable (RelatedArticleMatch, Modifier) -> Unit = { m, mod ->
                Card(mod.combinedClickable(onClick = {
                    vm.openArticle(m.note.id, m.note.title, fileType = m.note.fileType)
                    if (m.note.fileType in listOf("html","htm","mhtml","mht")) nav.navigate("htmlReader/${m.note.id}") else nav.navigate("reader") { launchSingleTop = true }
                }, onLongClick = { preview = m })) {
                    Column(Modifier.padding(12.dp)) {
                        Text(m.note.title, fontWeight = FontWeight.SemiBold, maxLines = 2, overflow = TextOverflow.Ellipsis)
                        Text(m.reason, fontSize = 11.sp, maxLines = 2, overflow = TextOverflow.Ellipsis)
                    }
                }
            }
            if (horizontal) LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) { items(matches) { card(it, Modifier.width(240.dp)) } }
            else LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.heightIn(max = 400.dp)) { items(matches) { card(it, Modifier.fillMaxWidth()) } }
            TextButton(onClick = { vm.requestWebPopup("https://www.jw.org/en/search/?q=" + Uri.encode(mediaTitle)) }) { Text("Search related articles on JW.org") }
        }
    }
    preview?.let { m -> AlertDialog(onDismissRequest = { preview = null }, title = { Text("Why this article was suggested") }, text = { Text(m.reason) }, confirmButton = { TextButton(onClick = { preview = null }) { Text("Close") } }) }
}
