package com.tebogo.markvault.ui

import androidx.compose.foundation.layout.Column
import androidx.compose.material3.Slider
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.platform.LocalContext
import com.tebogo.markvault.ai.MultiQueryPreference
import com.tebogo.markvault.ai.AiPreferenceStore
import kotlinx.coroutines.launch

@Composable
fun MultiQuerySlider() {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()

    var value by remember { mutableFloatStateOf(3f) }

    LaunchedEffect(Unit) {
        value = AiPreferenceStore.loadQueryCount(context).toFloat()
        MultiQueryPreference.setCount(value.toInt())
    }

    Column {
        Text("AI Multi-Query Retrieval: ${value.toInt()} queries")
        Slider(
            value = value,
            onValueChange = {
                value = it
                val count = it.toInt()
                MultiQueryPreference.setCount(count)
                scope.launch {
                    AiPreferenceStore.saveQueryCount(context, count)
                }
            },
            valueRange = 0f..10f,
            steps = 9
        )
    }
}
