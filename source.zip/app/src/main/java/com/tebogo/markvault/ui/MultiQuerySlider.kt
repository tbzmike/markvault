package com.tebogo.markvault.ui

import androidx.compose.foundation.layout.Column
import androidx.compose.material3.Slider
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import com.tebogo.markvault.ai.MultiQueryPreference

@Composable
fun MultiQuerySlider() {
    var value by remember { mutableFloatStateOf(MultiQueryPreference.getCount().toFloat()) }

    Column {
        Text("AI Multi-Query Retrieval: ${value.toInt()} queries")
        Slider(
            value = value,
            onValueChange = {
                value = it
                MultiQueryPreference.setCount(it.toInt())
            },
            valueRange = 0f..10f,
            steps = 9
        )
    }
}
