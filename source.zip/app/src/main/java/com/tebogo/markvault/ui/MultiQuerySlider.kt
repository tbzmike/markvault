package com.tebogo.markvault.ui

import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Slider
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.tebogo.markvault.AppViewModel

/**
 * v5.4.74 — Multi-query retrieval slider, wired to persisted count.
 *
 *   • 0     → OFF (original query only)
 *   • 1..3  → Fast: pure Kotlin synonym expansion (~0 MB overhead)
 *   • 4..10 → Best quality: LLM expansion (loads active model then unloads)
 */
@Composable
fun MultiQuerySlider(vm: AppViewModel) {
    val count by vm.multiQueryCount.collectAsStateWithLifecycle()

    Column(Modifier.fillMaxWidth()) {
        val label = when {
            count == 0 -> "OFF"
            count in 1..3 -> "$count \u2014 Fast (synonyms only)"
            else -> "$count \u2014 Best quality (uses LLM)"
        }
        Text(
            "Multi-query retrieval: $label",
            fontWeight = FontWeight.Medium,
            fontSize = 14.sp
        )
        Spacer(Modifier.height(2.dp))
        Text(
            "0 = off. 1-3 = fast synonym expansion. 4-10 = LLM-based " +
                "query understanding (model loads then fully unloads " +
                "between searches to protect memory).",
            fontSize = 11.sp,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
            lineHeight = 15.sp
        )
        Slider(
            value = count.toFloat(),
            onValueChange = { vm.setMultiQueryCount(it.toInt()) },
            valueRange = 0f..10f,
            steps = 9,
            modifier = Modifier.fillMaxWidth()
        )
    }
}
