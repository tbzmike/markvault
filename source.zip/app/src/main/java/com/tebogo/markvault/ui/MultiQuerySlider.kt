package com.tebogo.markvault.ui

import androidx.compose.foundation.layout.Column
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Slider
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.tebogo.markvault.AppViewModel

/**
 * v5.4.80cc — Slider controlling how many paraphrased sub-queries the
 * on-device LLM should produce per submitted search.
 *
 * Previous incarnation of this composable wrote to an in-memory
 * `MultiQueryPreference` singleton that (a) wasn't persisted across
 * app restarts and (b) wasn't read by [com.tebogo.markvault.llm.LlmQueryExpander],
 * so dragging the slider did nothing to the actual expansion count.
 * v5.4.80cc binds it to [AppViewModel.llmParaphraseCount] (backed by
 * a DataStore-persisted preference) and the expander reads that same
 * preference via its `countProvider` lambda on every submit.
 *
 * ### Meaning of the values
 *
 *   • **0** — Skip the LLM entirely, even when the master AI toggle
 *     (or the pumping-brain button on the search screen) is on. Acts
 *     as a per-slider off switch that leaves the toggle in "available"
 *     state.
 *   • **1..10** — Ask the LLM to produce that many paraphrases. Higher
 *     values give broader recall but take proportionally longer to
 *     generate; SmolLM2-135M handles ~5 comfortably, Phi-4-mini tops
 *     out around ~10 within the 5-second generate timeout.
 *
 * `onValueChangeFinished` is used to persist so we don't hammer
 * DataStore with a write per pixel of drag.
 */
@Composable
fun MultiQuerySlider(vm: AppViewModel) {
    val persisted by vm.llmParaphraseCount.collectAsStateWithLifecycle()
    // Local mirror so the thumb tracks the finger smoothly during a
    // drag; committed to DataStore on release via
    // onValueChangeFinished. `remember(persisted)` reseeds the local
    // mirror if the preference changes elsewhere (e.g. remote sync,
    // wipe-and-reset, another surface writing the same key).
    var value by remember(persisted) { mutableFloatStateOf(persisted.toFloat()) }
    val currentInt = value.toInt()

    Column {
        val label = if (currentInt == 0) {
            "\uD83E\uDDE0 LLM paraphrases per query: 0 (off — LLM will not run)"
        } else {
            "\uD83E\uDDE0 LLM paraphrases per query: $currentInt"
        }
        Text(
            text = label,
            fontSize = 13.sp,
            fontWeight = FontWeight.Medium
        )
        Text(
            text = "Controls how many paraphrased sub-queries the on-device " +
                "LLM produces for each submitted search. Higher = broader " +
                "recall but slower generation.",
            fontSize = 11.sp,
            color = MaterialTheme.colorScheme.onSurfaceVariant
        )
        Slider(
            value = value,
            onValueChange = { value = it },
            onValueChangeFinished = { vm.setLlmParaphraseCount(value.toInt()) },
            valueRange = 0f..10f,
            steps = 9
        )
    }
}
