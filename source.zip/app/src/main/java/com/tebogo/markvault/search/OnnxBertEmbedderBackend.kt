package com.tebogo.markvault.search

import ai.onnxruntime.OnnxTensor
import ai.onnxruntime.OrtEnvironment
import ai.onnxruntime.OrtSession
import android.content.Context
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File
import java.io.FileOutputStream
import java.net.URL
import java.nio.LongBuffer

/**
 * ONNX Runtime backend for BERT-family text embedding models, currently
 * all-MiniLM-L6-v2 (384-dim, 2021). The pipeline:
 *
 *   1. **Tokenize** with the in-Kotlin [BertTokenizer], which reads the
 *      `vocab.txt` downloaded alongside the model.
 *   2. **Run inference** through ONNX Runtime with three inputs the BERT
 *      family expects: `input_ids`, `attention_mask`, `token_type_ids`.
 *   3. **Mean-pool** the output `last_hidden_state` over the sequence
 *      dimension, masked by `attention_mask`. This is what Sentence-
 *      Transformers does to produce sentence embeddings and is essential
 *      for the cosine-similarity blend to work.
 *   4. **L2-normalize** so cosine similarity reduces to a dot product,
 *      matching what the existing in-memory semantic index assumes.
 *
 * Unlike the MediaPipe backend, this one needs TWO files on disk — the
 * `.onnx` model file (primary, ~23 MB) and `vocab.txt` (extra, ~232 KB).
 * The [downloadModel] override fetches both and updates progress for the
 * combined operation; [isModelAvailable] requires both to be present.
 *
 * v4.10.0 — introduced. Implements the [EmbedderBackend] contract.
 */
internal class OnnxBertEmbedderBackend(
    context: Context,
    descriptor: ModelDescriptor,
) : EmbedderBackend(context, descriptor) {

    /** Cached ONNX session. Created lazily on first [embed] call. */
    @Volatile
    private var session: OrtSession? = null

    /** Cached tokenizer instance. Created lazily alongside [session]. */
    @Volatile
    private var tokenizer: BertTokenizer? = null

    /**
     * Both the primary model file AND every entry in `descriptor.extraFiles`
     * must exist on disk for this backend to be considered installed. The
     * base class only checks the primary file; we extend it.
     */
    override fun isModelAvailable(): Boolean {
        if (!super.isModelAvailable()) return false
        return descriptor.extraFiles.all { asset ->
            File(context.filesDir, asset.localFilename).exists()
        }
    }

    /**
     * Multi-file download: fetches the primary `.onnx` model and every
     * `extraFiles` asset (vocab.txt for BERT) in sequence. Progress is
     * reported as a single 0.0–1.0 fraction weighted by approximate file
     * size — the model is ~99 % of total bytes so the progress bar tracks
     * its download closely.
     *
     * Each file is downloaded to a `.part` temp path and atomically
     * renamed when complete, so an interrupted download leaves no
     * misleading partial files behind.
     *
     * Already-present files are skipped (the user's previous install
     * remains valid across app updates).
     */
    override suspend fun downloadModel(
        onProgress: (Float) -> Unit
    ): Result<Unit> = withContext(Dispatchers.IO) {
        val files = buildList {
            add(RemoteAsset(descriptor.downloadUrl, descriptor.localFilename))
            addAll(descriptor.extraFiles)
        }
        // Weight by approximate size. Model is ~23 MB, vocab is ~232 KB — so
        // ~99 % goes to the first file and the remainder to the rest. Keeps
        // the progress bar visually accurate.
        val weights = FloatArray(files.size).also { w ->
            for (i in files.indices) w[i] = if (i == 0) 0.99f else 0.01f / (files.size - 1).coerceAtLeast(1)
        }
        runCatching {
            var cumulative = 0f
            for ((idx, asset) in files.withIndex()) {
                val target = File(context.filesDir, asset.localFilename)
                if (target.exists() && target.length() > 0L) {
                    cumulative += weights[idx]
                    onProgress(cumulative.coerceIn(0f, 1f))
                    continue
                }
                val tmp = File(context.filesDir, "${asset.localFilename}.part")
                val conn = URL(asset.url).openConnection()
                conn.connectTimeout = 15_000
                conn.readTimeout = 60_000
                val total = conn.contentLengthLong.coerceAtLeast(1L)
                conn.getInputStream().use { input ->
                    FileOutputStream(tmp).use { output ->
                        val buf = ByteArray(64 * 1024)
                        var soFar = 0L
                        while (true) {
                            val read = input.read(buf)
                            if (read < 0) break
                            output.write(buf, 0, read)
                            soFar += read
                            if (total > 0) {
                                val frac = soFar.toFloat() / total
                                val combined = cumulative + weights[idx] * frac
                                onProgress(combined.coerceIn(0f, 1f))
                            }
                        }
                    }
                }
                if (!tmp.renameTo(target)) {
                    runCatching { tmp.delete() }
                    error("Could not move ${asset.localFilename} into place")
                }
                cumulative += weights[idx]
            }
            onProgress(1f)
        }
    }

    /**
     * Embed [text] into a 384-dim L2-normalised float vector. Returns null on
     * any soft failure — model not installed, tokenizer not ready, ONNX
     * inference throws, output tensor has unexpected shape, etc. The search
     * pipeline degrades gracefully to keyword + synonym ranking when null
     * is returned.
     *
     * Internally truncates input to [Embedder.MAX_INPUT_CHARS] before
     * tokenization, then to 256 tokens after tokenization. The combination
     * keeps a single inference well under 200 ms even on mid-range Android.
     */
    override suspend fun embed(text: String): FloatArray? = withContext(Dispatchers.IO) {
        val cleaned = text.trim()
        if (cleaned.isEmpty()) return@withContext null
        val sliced = if (cleaned.length > Embedder.MAX_INPUT_CHARS) {
            cleaned.substring(0, Embedder.MAX_INPUT_CHARS)
        } else cleaned

        // Lazy session + tokenizer init. Returns null if either failed to
        // load (corrupt vocab, missing model, etc.).
        if (!ensureLoaded()) return@withContext null
        val sess = session ?: return@withContext null
        val tok = tokenizer ?: return@withContext null

        runCatching {
            val ids = tok.encode(sliced, maxLength = 256)
            val seqLen = ids.size
            val inputIds = LongArray(seqLen) { ids[it].toLong() }
            val attentionMask = LongArray(seqLen) { 1L }
            val tokenTypeIds = LongArray(seqLen) { 0L }
            val env = OrtEnvironment.getEnvironment()
            val shape = longArrayOf(1L, seqLen.toLong())

            OnnxTensor.createTensor(env, LongBuffer.wrap(inputIds), shape).use { idsT ->
                OnnxTensor.createTensor(env, LongBuffer.wrap(attentionMask), shape).use { maskT ->
                    OnnxTensor.createTensor(env, LongBuffer.wrap(tokenTypeIds), shape).use { typeT ->
                        val inputs = mapOf(
                            "input_ids" to idsT,
                            "attention_mask" to maskT,
                            "token_type_ids" to typeT,
                        )
                        sess.run(inputs).use { results ->
                            // Output 0 is `last_hidden_state` for the
                            // Xenova/sentence-transformers MiniLM exports.
                            // Shape: [1, seq_len, 384].
                            @Suppress("UNCHECKED_CAST")
                            val hidden = results[0].value as? Array<Array<FloatArray>>
                                ?: return@use null
                            meanPoolAndNormalize(hidden[0], attentionMask)
                        }
                    }
                }
            }
        }.getOrNull()
    }

    /**
     * Sentence-Transformers-style mean pooling followed by L2 normalisation.
     *
     * For each output dimension, sum the token-position values where the
     * attention mask is 1, then divide by the count of attended tokens. This
     * gives the "average" token embedding, treating each attended position
     * equally. Padding positions (mask = 0) are excluded.
     *
     * Then divide the resulting vector by its L2 norm so the magnitude is 1.
     * That makes downstream cosine similarity equivalent to a plain dot
     * product, which is exactly what the in-memory semantic index assumes.
     */
    private fun meanPoolAndNormalize(
        hidden: Array<FloatArray>,
        attentionMask: LongArray,
    ): FloatArray {
        if (hidden.isEmpty()) return FloatArray(0)
        val dim = hidden[0].size
        val pooled = FloatArray(dim)
        var attended = 0
        for (i in hidden.indices) {
            if (i < attentionMask.size && attentionMask[i] == 1L) {
                val row = hidden[i]
                for (j in 0 until dim) pooled[j] += row[j]
                attended++
            }
        }
        if (attended == 0) return pooled
        val inv = 1f / attended
        for (j in 0 until dim) pooled[j] *= inv
        // L2 normalise.
        var sumSq = 0f
        for (v in pooled) sumSq += v * v
        val norm = kotlin.math.sqrt(sumSq.toDouble()).toFloat()
        if (norm > 0f) {
            val invNorm = 1f / norm
            for (j in 0 until dim) pooled[j] *= invNorm
        }
        return pooled
    }

    /** Release the ONNX session. Safe to call multiple times. */
    override fun close() {
        runCatching { session?.close() }
        session = null
        tokenizer = null
    }

    /**
     * Initialise [session] and [tokenizer] on the first call. Synchronized
     * because multiple search coroutines may race here on the first query
     * after the user installs the model. Returns true if both are ready
     * after this call; false otherwise (caller should treat as "model not
     * usable yet" — exactly the same behaviour as before installation).
     */
    @Synchronized
    private fun ensureLoaded(): Boolean {
        if (session != null && tokenizer != null) return true
        if (!isModelAvailable()) return false
        // Both files exist — build the tokenizer first (cheap) so any vocab
        // problem is surfaced before we pay the cost of creating the ONNX
        // session.
        if (tokenizer == null) {
            val vocabAsset = descriptor.extraFiles.firstOrNull() ?: return false
            val vocabFile = File(context.filesDir, vocabAsset.localFilename)
            val vocabMap = runCatching {
                BertTokenizer.buildVocabMap(vocabFile.readLines())
            }.getOrElse { return false }
            if (!BertTokenizer.isVocabUsable(vocabMap)) return false
            tokenizer = BertTokenizer(vocabMap)
        }
        if (session == null) {
            session = runCatching {
                val env = OrtEnvironment.getEnvironment()
                val opts = OrtSession.SessionOptions()
                env.createSession(modelFile.absolutePath, opts)
            }.getOrNull()
            if (session == null) return false
        }
        return true
    }
}
