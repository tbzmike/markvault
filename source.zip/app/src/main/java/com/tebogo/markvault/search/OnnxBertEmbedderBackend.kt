package com.tebogo.markvault.search

import ai.onnxruntime.OnnxTensor
import ai.onnxruntime.OrtEnvironment
import ai.onnxruntime.OrtSession
import android.content.Context
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.sync.withLock
import kotlinx.coroutines.withContext
import java.io.File
import java.io.FileOutputStream
import java.net.URL
import java.nio.LongBuffer

/**
 * ONNX Runtime backend for BERT-family text embedding models, currently
 * all-MiniLM-L6-v2 (384-dim, 2021). The pipeline:
 *
 *   1. **Tokenize** with the in-Kotlin [BertTokenizer], which reads the
 *      `vocab.txt` downloaded alongside the model.
 *   2. **Run inference** through ONNX Runtime with three inputs the BERT
 *      family expects: `input_ids`, `attention_mask`, `token_type_ids`.
 *   3. **Mean-pool** the output `last_hidden_state` over the sequence
 *      dimension, masked by `attention_mask`. This is what Sentence-
 *      Transformers does to produce sentence embeddings and is essential
 *      for the cosine-similarity blend to work.
 *   4. **L2-normalize** so cosine similarity reduces to a dot product,
 *      matching what the existing in-memory semantic index assumes.
 *
 * Unlike the MediaPipe backend, this one needs TWO files on disk — the
 * `.onnx` model file (primary, ~23 MB) and `vocab.txt` (extra, ~232 KB).
 * The [downloadModel] override fetches both and updates progress for the
 * combined operation; [isModelAvailable] requires both to be present.
 *
 * v4.10.0 — introduced. Implements the [EmbedderBackend] contract.
 */
internal class OnnxBertEmbedderBackend(
    context: Context,
    descriptor: ModelDescriptor,
) : EmbedderBackend(context, descriptor) {

    /** Cached ONNX session. Created lazily on first [embed] call. */
    @Volatile
    private var session: OrtSession? = null

    /** Cached tokenizer instance. Created lazily alongside [session]. */
    @Volatile
    private var tokenizer: BertTokenizer? = null

    /** v5.4.1 — Serialise inference. ONNX sessions are not thread-safe;
     *  fast-typing users can fire two debounced searches whose embedder
     *  calls overlap and corrupt native state. The mutex guarantees one
     *  inference at a time per instance. */
    private val inferenceLock = kotlinx.coroutines.sync.Mutex()

    /**
     * Both the primary model file AND every entry in `descriptor.extraFiles`
     * must exist on disk for this backend to be considered installed. The
     * base class only checks the primary file; we extend it.
     */
    override fun isModelAvailable(): Boolean {
        if (!super.isModelAvailable()) return false
        return descriptor.extraFiles.all { asset ->
            File(context.filesDir, asset.localFilename).exists()
        }
    }

    /**
     * Multi-file download: fetches the primary `.onnx` model and every
     * `extraFiles` asset (vocab.txt for BERT) in sequence. Progress is
     * reported as a single 0.0–1.0 fraction weighted by approximate file
     * size — the model is ~99 % of total bytes so the progress bar tracks
     * its download closely.
     *
     * Each file is downloaded to a `.part` temp path and atomically
     * renamed when complete, so an interrupted download leaves no
     * misleading partial files behind.
     *
     * Already-present files are skipped (the user's previous install
     * remains valid across app updates).
     */
    override suspend fun downloadModel(
        onProgress: (Float) -> Unit
    ): Result<Unit> = withContext(Dispatchers.IO) {
        val files = buildList {
            add(RemoteAsset(descriptor.downloadUrl, descriptor.localFilename))
            addAll(descriptor.extraFiles)
        }
        // Weight by approximate size. Model is ~23 MB, vocab is ~232 KB — so
        // ~99 % goes to the first file and the remainder to the rest. Keeps
        // the progress bar visually accurate.
        val weights = FloatArray(files.size).also { w ->
            for (i in files.indices) w[i] = if (i == 0) 0.99f else 0.01f / (files.size - 1).coerceAtLeast(1)
        }
        runCatching {
            var cumulative = 0f
            for ((idx, asset) in files.withIndex()) {
                val target = File(context.filesDir, asset.localFilename)
                if (target.exists() && target.length() > 0L) {
                    cumulative += weights[idx]
                    onProgress(cumulative.coerceIn(0f, 1f))
                    continue
                }
                val tmp = File(context.filesDir, "${asset.localFilename}.part")
                val conn = URL(asset.url).openConnection()
                conn.connectTimeout = 15_000
                conn.readTimeout = 60_000
                val total = conn.contentLengthLong.coerceAtLeast(1L)
                conn.getInputStream().use { input ->
                    FileOutputStream(tmp).use { output ->
                        val buf = ByteArray(64 * 1024)
                        var soFar = 0L
                        while (true) {
                            val read = input.read(buf)
                            if (read < 0) break
                            output.write(buf, 0, read)
                            soFar += read
                            if (total > 0) {
                                val frac = soFar.toFloat() / total
                                val combined = cumulative + weights[idx] * frac
                                onProgress(combined.coerceIn(0f, 1f))
                            }
                        }
                    }
                }
                if (!tmp.renameTo(target)) {
                    runCatching { tmp.delete() }
                    error("Could not move ${asset.localFilename} into place")
                }
                cumulative += weights[idx]
            }
            onProgress(1f)
        }
    }

    /**
     * Embed [text] into a 384-dim L2-normalised float vector. Returns null on
     * any soft failure — model not installed, tokenizer not ready, ONNX
     * inference throws, output tensor has unexpected shape, etc. The search
     * pipeline degrades gracefully to keyword + synonym ranking when null
     * is returned.
     *
     * Internally truncates input to [Embedder.MAX_INPUT_CHARS] before
     * tokenization, then to 512 tokens after tokenization (raised from 256
     * in v5.4.172cc — see below for why).
     *
     * v5.4.172cc — Why 512, and why this is safe:
     *   The ORIGINAL 256 limit meant any note/passage past roughly 180-200
     *   words was silently invisible to semantic search — the embedding
     *   model never saw that part of the text at all, regardless of how
     *   relevant it was. For long-form notes (the common case here), that's
     *   a real accuracy cost, not just a theoretical one.
     *   512 is BGE-large-en-v1.5's actual supported sequence length, so
     *   this isn't over-extending past what the model can use correctly.
     *   Latency impact is asymmetric and, in practice, small where it
     *   matters: QUERIES stay short regardless of this ceiling (maxLength
     *   is an upper BOUND, not a fixed pad length — see encode()'s budget
     *   logic), so per-query search latency is essentially unchanged. Only
     *   INDEXING of long documents gets slower, and that already runs as a
     *   background job with its own progress notification — not something
     *   blocking the search UI.
     */
    override suspend fun embed(text: String): FloatArray? = withContext(Dispatchers.IO) {
        val cleaned = text.trim()
        if (cleaned.isEmpty()) return@withContext null
        val sliced = if (cleaned.length > Embedder.MAX_INPUT_CHARS) {
            cleaned.substring(0, Embedder.MAX_INPUT_CHARS)
        } else cleaned

        // Lazy session + tokenizer init. Returns null if either failed to
        // load (corrupt vocab, missing model, etc.).
        if (!ensureLoaded()) return@withContext null
        val sess = session ?: return@withContext null
        val tok = tokenizer ?: return@withContext null

        // v5.4.1 — Serialise ONNX inference. See class-level comment on
        // [inferenceLock] for why this matters.
        inferenceLock.withLock {
            runCatching {
            val ids = tok.encode(sliced, maxLength = 512)
            val seqLen = ids.size
            val inputIds = LongArray(seqLen) { ids[it].toLong() }
            val attentionMask = LongArray(seqLen) { 1L }
            val tokenTypeIds = LongArray(seqLen) { 0L }
            val env = OrtEnvironment.getEnvironment()
            val shape = longArrayOf(1L, seqLen.toLong())

            OnnxTensor.createTensor(env, LongBuffer.wrap(inputIds), shape).use { idsT ->
                OnnxTensor.createTensor(env, LongBuffer.wrap(attentionMask), shape).use { maskT ->
                    OnnxTensor.createTensor(env, LongBuffer.wrap(tokenTypeIds), shape).use { typeT ->
                        val inputs = mapOf(
                            "input_ids" to idsT,
                            "attention_mask" to maskT,
                            "token_type_ids" to typeT,
                        )
                        sess.run(inputs).use { results ->
                            // Output 0 is `last_hidden_state` for the
                            // Xenova/sentence-transformers MiniLM exports
                            // and the BGE exports.
                            // Shape: [1, seq_len, embedding_dim].
                            @Suppress("UNCHECKED_CAST")
                            val hidden = results[0].value as? Array<Array<FloatArray>>
                                ?: return@use null
                            poolAndNormalize(hidden[0], attentionMask)
                        }
                    }
                }
            }
        }.getOrNull()
        }
    }

    /**
     * Reduce per-token hidden states into a single sentence embedding,
     * then L2-normalise. The pooling algorithm is chosen by the active
     * model's [ModelDescriptor.poolingStrategy]:
     *
     *   - [PoolingStrategy.MEAN] — Sentence-Transformers convention. Average
     *     all attended token positions. Used by MiniLM.
     *   - [PoolingStrategy.CLS] — BGE convention. Take the first token's
     *     (`[CLS]`) hidden state directly.
     *
     * After pooling, the result is L2-normalised so cosine similarity
     * reduces to a dot product, matching what the in-memory semantic
     * index assumes.
     *
     * Using the wrong pooling algorithm produces embeddings that look
     * superficially like vectors but encode nothing useful for retrieval —
     * which is why this dispatcher is mandatory.
     */
    private fun poolAndNormalize(
        hidden: Array<FloatArray>,
        attentionMask: LongArray,
    ): FloatArray {
        if (hidden.isEmpty()) return FloatArray(0)
        val pooled = when (descriptor.poolingStrategy) {
            PoolingStrategy.MEAN -> meanPool(hidden, attentionMask)
            PoolingStrategy.CLS -> clsPool(hidden)
        }
        l2NormalizeInPlace(pooled)
        return pooled
    }

    /**
     * Sentence-Transformers-style mean pooling. For each output dimension,
     * sum the token-position values where the attention mask is 1, then
     * divide by the count of attended tokens. Padding positions (mask = 0)
     * are excluded. Used by MiniLM and most Sentence-Transformers models.
     */
    private fun meanPool(
        hidden: Array<FloatArray>,
        attentionMask: LongArray,
    ): FloatArray {
        val dim = hidden[0].size
        val pooled = FloatArray(dim)
        var attended = 0
        for (i in hidden.indices) {
            if (i < attentionMask.size && attentionMask[i] == 1L) {
                val row = hidden[i]
                for (j in 0 until dim) pooled[j] += row[j]
                attended++
            }
        }
        if (attended == 0) return pooled
        val inv = 1f / attended
        for (j in 0 until dim) pooled[j] *= inv
        return pooled
    }

    /**
     * BGE-style CLS pooling. The first token is always `[CLS]` (inserted
     * by [BertTokenizer.encode]); its hidden state is treated as the whole
     * sentence's representation. Faster than mean pool — no per-token
     * accumulation — but only correct for models trained with this
     * convention (BGE family).
     */
    private fun clsPool(hidden: Array<FloatArray>): FloatArray {
        // Defensive copy: subsequent L2 normalisation mutates the returned
        // array, and we don't want to alter the raw ONNX output buffer.
        return hidden[0].copyOf()
    }

    /** Divide [vec] by its L2 norm in place. No-op if the norm is zero. */
    private fun l2NormalizeInPlace(vec: FloatArray) {
        var sumSq = 0f
        for (v in vec) sumSq += v * v
        val norm = kotlin.math.sqrt(sumSq.toDouble()).toFloat()
        if (norm <= 0f) return
        val invNorm = 1f / norm
        for (j in vec.indices) vec[j] *= invNorm
    }

    /** Release the ONNX session. Safe to call multiple times. */
    override fun close() {
        runCatching { session?.close() }
        session = null
        tokenizer = null
    }

    /**
     * Initialise [session] and [tokenizer] on the first call. Synchronized
     * because multiple search coroutines may race here on the first query
     * after the user installs the model. Returns true if both are ready
     * after this call; false otherwise (caller should treat as "model not
     * usable yet" — exactly the same behaviour as before installation).
     */
    @Synchronized
    private fun ensureLoaded(): Boolean {
        if (session != null && tokenizer != null) return true
        if (!isModelAvailable()) return false
        // Both files exist — build the tokenizer first (cheap) so any vocab
        // problem is surfaced before we pay the cost of creating the ONNX
        // session.
        if (tokenizer == null) {
            val vocabAsset = descriptor.extraFiles.firstOrNull() ?: return false
            val vocabFile = File(context.filesDir, vocabAsset.localFilename)
            val vocabMap = runCatching {
                BertTokenizer.buildVocabMap(vocabFile.readLines())
            }.getOrElse { return false }
            if (!BertTokenizer.isVocabUsable(vocabMap)) return false
            tokenizer = BertTokenizer(vocabMap)
        }
        if (session == null) {
            session = runCatching {
                val env = OrtEnvironment.getEnvironment()
                val opts = OrtSession.SessionOptions()
                // v5.4.4 — Back to ONNX defaults. See Reranker for the
                // full justification — short version: dropping below
                // ALL_OPT broke model compatibility on Xenova's exports
                // and made v5.4.3 crash more, not less.
                env.createSession(modelFile.absolutePath, opts)
            }.getOrNull()
            if (session == null) return false
        }
        return true
    }
}
