package com.tebogo.markvault.ui

import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.LinkAnnotation
import androidx.compose.ui.text.SpanStyle
import androidx.compose.ui.text.TextLinkStyles
import androidx.compose.ui.text.buildAnnotatedString
import androidx.compose.ui.text.font.FontStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextDecoration
import androidx.compose.ui.text.withLink
import androidx.compose.ui.text.withStyle
import androidx.compose.ui.unit.sp

/**
 * v5.4.130cc — Lightweight markdown → AnnotatedString converter for
 * the in-article semantic-search popup.
 *
 * The passages the popup shows are extracted verbatim from the article,
 * so they still contain raw markdown syntax (`**bold**`, `*italic*`,
 * `[text](url)`, `<u>text</u>`, `<span style="color:X">text</span>`,
 * headings, block-quotes, bullets). Displaying that raw syntax to the
 * user is what the "no raw text (code)" complaint was about — this
 * renderer converts those markers into styled spans so the popup looks
 * like a well-formatted excerpt rather than a source dump.
 *
 * Supported inline markers:
 *   • **bold**            → FontWeight.Bold
 *   • *italic*            → FontStyle.Italic (won't confuse `**bold**`)
 *   • [text](url)         → clickable [LinkAnnotation.Url] (jw.org links
 *                           open in the system browser / JW Library)
 *   • <u>text</u>         → underline
 *   • <span style="color:X">text</span>  → colored span (#hex or #rgb)
 *
 * Supported block markers:
 *   • # / ## / ###        → bold + larger font size
 *   • > quote             → italic + a leading "┃" glyph
 *   • - / *  bullet       → leading "• " bullet
 *
 * Emojis pass through as unicode characters (rendered by the platform
 * font). Images (![alt](url)) are stripped rather than shown — Compose's
 * `Text` can't inline bitmaps, and inserting the alt text mid-passage
 * usually reads worse than skipping it. Tables and other complex HTML
 * are also stripped by fall-through (they render as plain text).
 *
 * Never throws — malformed markdown just appears as plain text at the
 * point where parsing gives up.
 */
object PopupMarkdownRenderer {

    private val LINK_PATTERN =
        Regex("""\[([^\]\n]+)\]\(([^)\s]+)\)""")
    private val BOLD_PATTERN =
        Regex("""\*\*([^*\n]+)\*\*""")
    private val ITALIC_PATTERN =
        Regex("""(?<![\*\w])\*([^*\n]+)\*(?!\*)""")
    private val UNDERLINE_PATTERN =
        Regex("""<u>([^<\n]+)</u>""", RegexOption.IGNORE_CASE)
    private val COLOR_SPAN_PATTERN =
        Regex(
            """<span\s+style\s*=\s*["']\s*color\s*:\s*([^"';]+?)\s*;?\s*["']\s*>([^<]+)</span>""",
            RegexOption.IGNORE_CASE
        )
    private val IMAGE_PATTERN =
        Regex("""!\[([^\]]*)\]\([^)\s]+\)""")
    // v5.4.140cc — Expanded block-level HTML stripper to cover the
    // rest of the tags real articles use (`<a>`, `<br>`, `<hr>`,
    // `<blockquote>`, `<sub>`, `<sup>`, headers) so their raw source
    // never leaks into the popup / snippet.
    private val OTHER_HTML_TAG =
        Regex(
            """</?(details|summary|div|table|thead|tbody|tr|td|th|br|hr|a|blockquote|sub|sup|em|strong|small|big|h[1-6]|section|article|aside|nav|figure|figcaption|main|header|footer|abbr|cite|q|mark|del|s|ins|kbd|samp|var|time|address)\b[^>]*/?>""",
            RegexOption.IGNORE_CASE
        )
    // v5.4.140cc — Obsidian-style wikilinks. `[[Note Title]]` and
    // `[[Note Title|Alias]]` render as their display text (alias if
    // present, otherwise the target). No link annotation attached —
    // these point at other notes in the vault, not URLs, and the
    // popup doesn't currently have a note-open pipeline.
    private val WIKILINK_PATTERN =
        Regex("""\[\[([^\]|\n]+?)(?:\|([^\]\n]+))?\]\]""")
    // v5.4.140cc — YAML frontmatter block at the very top of a note.
    // `---\nkey: value\n---\n`. Stripped entirely.
    private val FRONTMATTER_PATTERN =
        Regex("""\A---\r?\n[\s\S]*?\r?\n---\r?\n""")
    // v5.4.140cc — Fenced code blocks `\`\`\`lang\ncode\n\`\`\``.
    // Stripped entirely — inline embedded code doesn't render well
    // in the popup and is almost always noise for scripture articles.
    private val FENCED_CODE_PATTERN =
        Regex("""```[\s\S]*?```""")
    // v5.4.140cc — Inline code `\`code\``. Kept but the backticks
    // are removed — the text between them displays as plain text so
    // "the term `keriah`" doesn't show raw backticks.
    private val INLINE_CODE_PATTERN =
        Regex("""`([^`\n]+)`""")
    // v5.4.140cc — Obsidian callout tag `> [!NOTE]` / `[!WARNING]`
    // at the start of a blockquote line. Stripped; the following
    // quote content still renders as a blockquote via the `> `
    // line-level handler.
    private val CALLOUT_TAG_PATTERN =
        Regex("""^\s*>\s*\[!\w+\][-+]?\s*""", RegexOption.MULTILINE)
    // v5.4.140cc — Footnote references `[^1]`, `[^note]`. Stripped.
    private val FOOTNOTE_REF_PATTERN =
        Regex("""\[\^[^\]\s]+\]""")
    // v5.4.140cc — Footnote DEFINITIONS at the bottom of a note:
    // `[^1]: definition text`. Stripped entirely (whole line).
    private val FOOTNOTE_DEF_PATTERN =
        Regex("""^\[\^[^\]\s]+\]:.*$""", RegexOption.MULTILINE)
    // v5.4.140cc — Task-list checkboxes at the start of list items.
    // `- [ ] task` and `- [x] done`. Preserves the list bullet and
    // the task text; drops the brackets.
    private val TASK_CHECKBOX_PATTERN =
        Regex("""^(\s*[-*+]\s+)\[[ xX]\]\s+""", RegexOption.MULTILINE)
    // v5.4.140cc — Bare HTML entity references that don't get
    // caught by our per-entity replace map. Numeric refs handled
    // separately in parseColor's neighbour. Named refs unknown to
    // us are stripped rather than shown as raw `&foo;`.
    private val UNKNOWN_HTML_ENTITY =
        Regex("""&[a-zA-Z]{2,10};""")
    // v5.4.140cc — Horizontal rule lines. `---`, `***`, `___` on
    // their own line. Replaced with a single blank line so the
    // paragraph flow around them is preserved.
    private val HR_LINE_PATTERN =
        Regex("""^\s*(?:---+|\*\*\*+|___+)\s*$""", RegexOption.MULTILINE)

    /**
     * v5.4.140cc — Public plain-text stripper for search snippets.
     *
     * SearchScreen renders the FTS `hit.snippet` field via
     * `highlightSentences`, which expects plain text — but the snippet
     * still contains raw markdown ("**bold**", "[text](url)",
     * "[[Note]]", inline `code`, etc.) that came straight from the
     * article body. Result: raw markdown syntax visible in the
     * results list.
     *
     * This helper runs the same cleaning passes as [render]'s pre-
     * clean step, plus a strip for the inline markers themselves
     * (since we don't render span styles here). Everything collapses
     * to single-line-safe plain text — newlines become spaces, runs
     * of whitespace become one, leading/trailing whitespace is
     * trimmed.
     *
     * The output preserves:
     *   • the text inside `**bold**`, `*italic*`, `<u>underline</u>`
     *   • the display text of `[text](url)` and `[[wikilink|alias]]`
     *   • the text inside `<span style="color:X">…</span>`
     *   • the text inside `` `inline code` ``
     *   • emojis (they're just unicode)
     *
     * The output drops:
     *   • images
     *   • frontmatter blocks
     *   • fenced code blocks
     *   • footnote references and definitions
     *   • callout tags
     *   • horizontal rules
     *   • all remaining HTML tags
     *   • unknown HTML entities
     */
    fun stripToPlainText(rawText: String): String {
        if (rawText.isBlank()) return ""
        var t: String = rawText
            .replace(FRONTMATTER_PATTERN, "")
            .replace(FENCED_CODE_PATTERN, "")
            .replace(FOOTNOTE_DEF_PATTERN, "")
            .replace(FOOTNOTE_REF_PATTERN, "")
            .replace(IMAGE_PATTERN, "")
            .replace(OTHER_HTML_TAG, "")
            .replace(CALLOUT_TAG_PATTERN, "")
            .replace(TASK_CHECKBOX_PATTERN, "$1")
            .replace(HR_LINE_PATTERN, "")
            .replace(INLINE_CODE_PATTERN, "$1")
            .replace(UNKNOWN_HTML_ENTITY, "")
        // Wikilinks — keep display text
        t = t.replace(WIKILINK_PATTERN) { m ->
            val alias: String? = m.groupValues.getOrNull(2)?.takeIf { it.isNotBlank() }
            alias ?: m.groupValues[1]
        }
        // Standard markdown links — keep display text, drop URL
        t = t.replace(LINK_PATTERN) { it.groupValues[1] }
        // Color spans — keep inner text
        t = t.replace(COLOR_SPAN_PATTERN) { it.groupValues[2] }
        // Underline — keep inner text
        t = t.replace(UNDERLINE_PATTERN) { it.groupValues[1] }
        // Bold — keep inner text
        t = t.replace(BOLD_PATTERN) { it.groupValues[1] }
        // Italic — keep inner text
        t = t.replace(ITALIC_PATTERN) { it.groupValues[1] }
        // Line-level markers — strip the leading tokens on each line
        // so snippet doesn't show a stray "# " or "> ".
        t = t.replace(Regex("""^\s*#{1,6}\s+""", RegexOption.MULTILINE), "")
        t = t.replace(Regex("""^\s*>\s+""", RegexOption.MULTILINE), "")
        t = t.replace(Regex("""^\s*[-*+]\s+""", RegexOption.MULTILINE), "")
        t = t.replace(Regex("""^\s*\d+\.\s+""", RegexOption.MULTILINE), "")
        // Snippet render is single-line; collapse newlines to spaces
        // and squeeze runs of whitespace.
        t = t.replace(Regex("""[\r\n]+"""), " ")
        t = t.replace(Regex("""\s{2,}"""), " ")
        return t.trim()
    }

    fun render(
        rawText: String,
        linkColor: Color,
        onLinkClick: ((String) -> Unit)? = null
    ): AnnotatedString {
        // Pre-clean: drop images and unhandled block-level HTML so
        // downstream inline parsing doesn't have to worry about them.
        //
        // v5.4.140cc — Expanded cleaning pipeline. Order matters:
        //   1. Frontmatter block first — must run before any line-
        //      level pass touches lines that happen to look like
        //      YAML.
        //   2. Fenced code blocks — must run before inline patterns
        //      that might match text INSIDE fenced blocks.
        //   3. Footnote definitions — whole-line strip.
        //   4. Footnote refs, images, unhandled HTML, callout tags,
        //      task checkboxes, hr rules — inline strips.
        //   5. Inline code — unwrap the backticks (keep the text).
        //   6. Unknown HTML entities — strip.
        val cleaned: String = rawText
            .replace(FRONTMATTER_PATTERN, "")
            .replace(FENCED_CODE_PATTERN, "")
            .replace(FOOTNOTE_DEF_PATTERN, "")
            .replace(FOOTNOTE_REF_PATTERN, "")
            .replace(IMAGE_PATTERN, "")
            .replace(OTHER_HTML_TAG, "")
            .replace(CALLOUT_TAG_PATTERN, "> ")
            .replace(TASK_CHECKBOX_PATTERN, "$1")
            .replace(HR_LINE_PATTERN, "")
            .replace(INLINE_CODE_PATTERN, "$1")
            .replace(UNKNOWN_HTML_ENTITY, "")

        return buildAnnotatedString {
            val lines: List<String> = cleaned.split("\n")
            for ((i, rawLine) in lines.withIndex()) {
                val line: String = rawLine
                when {
                    line.startsWith("### ") -> {
                        withStyle(
                            SpanStyle(
                                fontWeight = FontWeight.Bold,
                                fontSize = 15.sp
                            )
                        ) { renderInline(line.substring(4), linkColor, onLinkClick) }
                    }
                    line.startsWith("## ") -> {
                        withStyle(
                            SpanStyle(
                                fontWeight = FontWeight.Bold,
                                fontSize = 16.sp
                            )
                        ) { renderInline(line.substring(3), linkColor, onLinkClick) }
                    }
                    line.startsWith("# ") -> {
                        withStyle(
                            SpanStyle(
                                fontWeight = FontWeight.Bold,
                                fontSize = 17.sp
                            )
                        ) { renderInline(line.substring(2), linkColor, onLinkClick) }
                    }
                    line.startsWith("> ") -> {
                        withStyle(SpanStyle(fontStyle = FontStyle.Italic)) {
                            append("\u2503 ")
                            renderInline(line.substring(2), linkColor, onLinkClick)
                        }
                    }
                    line.trimStart().let {
                        it.startsWith("- ") || it.startsWith("* ")
                    } -> {
                        val trimmed: String = line.trimStart()
                        // Guard against a lone "* " being confused for an
                        // italic marker on the next line.
                        append("\u2022 ")
                        renderInline(trimmed.substring(2), linkColor, onLinkClick)
                    }
                    else -> renderInline(line, linkColor, onLinkClick)
                }
                if (i < lines.size - 1) append("\n")
            }
        }
    }

    /**
     * Data holder used only within [renderInline]. Represents one
     * matched marker in the input text — its byte range, what kind of
     * marker it is, its display text, and (for links) its target URL.
     */
    private data class Marker(
        val start: Int,
        val end: Int,
        val kind: String,
        val display: String,
        val url: String? = null
    )

    private fun AnnotatedString.Builder.renderInline(
        text: String,
        linkColor: Color,
        onLinkClick: ((String) -> Unit)?
    ) {
        if (text.isEmpty()) return
        // v5.4.140cc — Pre-substitute wikilinks so their display text
        // (alias if present, otherwise the target) becomes plain text
        // before the marker-based pass runs. Otherwise `[[Genesis]]`
        // would leak its brackets into the popup. Shadowing `text` so
        // every downstream regex sees the substituted string.
        @Suppress("NAME_SHADOWING")
        val text: String = text.replace(WIKILINK_PATTERN) { m ->
            val alias: String? = m.groupValues.getOrNull(2)?.takeIf { it.isNotBlank() }
            alias ?: m.groupValues[1]
        }
        val markers: MutableList<Marker> = mutableListOf()

        // Links must be extracted first — they contain [text](url)
        // brackets that other patterns must NOT match inside of.
        for (m in LINK_PATTERN.findAll(text)) {
            markers.add(
                Marker(
                    start = m.range.first,
                    end = m.range.last + 1,
                    kind = "link",
                    display = m.groupValues[1],
                    url = m.groupValues[2]
                )
            )
        }
        for (m in COLOR_SPAN_PATTERN.findAll(text)) {
            if (overlapsAny(m.range.first, m.range.last, markers)) continue
            markers.add(
                Marker(
                    start = m.range.first,
                    end = m.range.last + 1,
                    kind = "color:" + m.groupValues[1].trim(),
                    display = m.groupValues[2]
                )
            )
        }
        for (m in UNDERLINE_PATTERN.findAll(text)) {
            if (overlapsAny(m.range.first, m.range.last, markers)) continue
            markers.add(
                Marker(
                    start = m.range.first,
                    end = m.range.last + 1,
                    kind = "u",
                    display = m.groupValues[1]
                )
            )
        }
        for (m in BOLD_PATTERN.findAll(text)) {
            if (overlapsAny(m.range.first, m.range.last, markers)) continue
            markers.add(
                Marker(
                    start = m.range.first,
                    end = m.range.last + 1,
                    kind = "bold",
                    display = m.groupValues[1]
                )
            )
        }
        for (m in ITALIC_PATTERN.findAll(text)) {
            if (overlapsAny(m.range.first, m.range.last, markers)) continue
            markers.add(
                Marker(
                    start = m.range.first,
                    end = m.range.last + 1,
                    kind = "italic",
                    display = m.groupValues[1]
                )
            )
        }

        markers.sortBy { it.start }

        var cursor = 0
        for (marker in markers) {
            if (marker.start > cursor) {
                append(text.substring(cursor, marker.start))
            }
            when {
                marker.kind == "link" -> {
                    val url: String = marker.url ?: ""
                    if (url.isNotEmpty()) {
                        // v5.4.135cc — When onLinkClick is provided,
                        // intercept the tap and hand the URL back to
                        // the caller (routes to the in-app WebView
                        // via nav.navigate("web/…")). When null,
                        // Compose falls back to the platform's
                        // default URI handler (system browser).
                        val listener: androidx.compose.ui.text.LinkInteractionListener? =
                            onLinkClick?.let { cb ->
                                androidx.compose.ui.text.LinkInteractionListener { link ->
                                    val target: String = when (link) {
                                        is LinkAnnotation.Url -> link.url
                                        else -> url
                                    }
                                    cb(target)
                                }
                            }
                        withLink(
                            LinkAnnotation.Url(
                                url = url,
                                styles = TextLinkStyles(
                                    style = SpanStyle(
                                        color = linkColor,
                                        textDecoration = TextDecoration.Underline
                                    )
                                ),
                                linkInteractionListener = listener
                            )
                        ) { append(marker.display) }
                    } else {
                        // No URL parsed — just render the display text
                        append(marker.display)
                    }
                }
                marker.kind == "bold" -> {
                    withStyle(SpanStyle(fontWeight = FontWeight.Bold)) {
                        append(marker.display)
                    }
                }
                marker.kind == "italic" -> {
                    withStyle(SpanStyle(fontStyle = FontStyle.Italic)) {
                        append(marker.display)
                    }
                }
                marker.kind == "u" -> {
                    withStyle(
                        SpanStyle(textDecoration = TextDecoration.Underline)
                    ) { append(marker.display) }
                }
                marker.kind.startsWith("color:") -> {
                    val colorStr: String = marker.kind.substring(6)
                    val parsed: Color? = parseColor(colorStr)
                    if (parsed != null) {
                        withStyle(SpanStyle(color = parsed)) {
                            append(marker.display)
                        }
                    } else {
                        append(marker.display)
                    }
                }
                else -> append(marker.display)
            }
            cursor = marker.end
        }
        if (cursor < text.length) {
            append(text.substring(cursor))
        }
    }

    private fun overlapsAny(
        s: Int, e: Int, existing: List<Marker>
    ): Boolean {
        for (m in existing) {
            // Any positional overlap is a conflict — we don't nest
            // inline markers.
            if (s < m.end && e >= m.start) return true
        }
        return false
    }

    private fun parseColor(raw: String): Color? {
        return try {
            val hex: String = raw.trim().removePrefix("#")
            when (hex.length) {
                3 -> {
                    val r: Int = (hex[0].toString() + hex[0]).toInt(16)
                    val g: Int = (hex[1].toString() + hex[1]).toInt(16)
                    val b: Int = (hex[2].toString() + hex[2]).toInt(16)
                    Color(red = r, green = g, blue = b)
                }
                6 -> {
                    val r: Int = hex.substring(0, 2).toInt(16)
                    val g: Int = hex.substring(2, 4).toInt(16)
                    val b: Int = hex.substring(4, 6).toInt(16)
                    Color(red = r, green = g, blue = b)
                }
                8 -> {
                    val a: Int = hex.substring(0, 2).toInt(16)
                    val r: Int = hex.substring(2, 4).toInt(16)
                    val g: Int = hex.substring(4, 6).toInt(16)
                    val b: Int = hex.substring(6, 8).toInt(16)
                    Color(red = r, green = g, blue = b, alpha = a)
                }
                else -> null
            }
        } catch (_: Throwable) {
            null
        }
    }
}
