package com.tebogo.markvault.ui

import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.LinkAnnotation
import androidx.compose.ui.text.SpanStyle
import androidx.compose.ui.text.TextLinkStyles
import androidx.compose.ui.text.buildAnnotatedString
import androidx.compose.ui.text.font.FontStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextDecoration
import androidx.compose.ui.text.withLink
import androidx.compose.ui.text.withStyle
import androidx.compose.ui.unit.sp

/**
 * v5.4.130cc — Lightweight markdown → AnnotatedString converter for
 * the in-article semantic-search popup.
 *
 * The passages the popup shows are extracted verbatim from the article,
 * so they still contain raw markdown syntax (`**bold**`, `*italic*`,
 * `[text](url)`, `<u>text</u>`, `<span style="color:X">text</span>`,
 * headings, block-quotes, bullets). Displaying that raw syntax to the
 * user is what the "no raw text (code)" complaint was about — this
 * renderer converts those markers into styled spans so the popup looks
 * like a well-formatted excerpt rather than a source dump.
 *
 * Supported inline markers:
 *   • **bold**            → FontWeight.Bold
 *   • *italic*            → FontStyle.Italic (won't confuse `**bold**`)
 *   • [text](url)         → clickable [LinkAnnotation.Url] (jw.org links
 *                           open in the system browser / JW Library)
 *   • <u>text</u>         → underline
 *   • <span style="color:X">text</span>  → colored span (#hex or #rgb)
 *
 * Supported block markers:
 *   • # / ## / ###        → bold + larger font size
 *   • > quote             → italic + a leading "┃" glyph
 *   • - / *  bullet       → leading "• " bullet
 *
 * Emojis pass through as unicode characters (rendered by the platform
 * font). Images (![alt](url)) are stripped rather than shown — Compose's
 * `Text` can't inline bitmaps, and inserting the alt text mid-passage
 * usually reads worse than skipping it. Tables and other complex HTML
 * are also stripped by fall-through (they render as plain text).
 *
 * Never throws — malformed markdown just appears as plain text at the
 * point where parsing gives up.
 */
object PopupMarkdownRenderer {

    private val LINK_PATTERN =
        Regex("""\[([^\]\n]+)\]\(([^)\s]+)\)""")
    private val BOLD_PATTERN =
        Regex("""\*\*([^*\n]+)\*\*""")
    private val ITALIC_PATTERN =
        Regex("""(?<![\*\w])\*([^*\n]+)\*(?!\*)""")
    private val UNDERLINE_PATTERN =
        Regex("""<u>([^<\n]+)</u>""", RegexOption.IGNORE_CASE)
    private val COLOR_SPAN_PATTERN =
        Regex(
            """<span\s+style\s*=\s*["']\s*color\s*:\s*([^"';]+?)\s*;?\s*["']\s*>([^<]+)</span>""",
            RegexOption.IGNORE_CASE
        )
    private val IMAGE_PATTERN =
        Regex("""!\[([^\]]*)\]\([^)\s]+\)""")
    // Strip anything else that looks like a raw HTML tag we don't handle
    private val OTHER_HTML_TAG =
        Regex("""</?(details|summary|div|table|thead|tbody|tr|td|th|br|hr)[^>]*>""",
            RegexOption.IGNORE_CASE)

    fun render(rawText: String, linkColor: Color): AnnotatedString {
        // Pre-clean: drop images and unhandled block-level HTML so
        // downstream inline parsing doesn't have to worry about them.
        val cleaned: String = rawText
            .replace(IMAGE_PATTERN, "")
            .replace(OTHER_HTML_TAG, "")

        return buildAnnotatedString {
            val lines: List<String> = cleaned.split("\n")
            for ((i, rawLine) in lines.withIndex()) {
                val line: String = rawLine
                when {
                    line.startsWith("### ") -> {
                        withStyle(
                            SpanStyle(
                                fontWeight = FontWeight.Bold,
                                fontSize = 15.sp
                            )
                        ) { renderInline(line.substring(4), linkColor) }
                    }
                    line.startsWith("## ") -> {
                        withStyle(
                            SpanStyle(
                                fontWeight = FontWeight.Bold,
                                fontSize = 16.sp
                            )
                        ) { renderInline(line.substring(3), linkColor) }
                    }
                    line.startsWith("# ") -> {
                        withStyle(
                            SpanStyle(
                                fontWeight = FontWeight.Bold,
                                fontSize = 17.sp
                            )
                        ) { renderInline(line.substring(2), linkColor) }
                    }
                    line.startsWith("> ") -> {
                        withStyle(SpanStyle(fontStyle = FontStyle.Italic)) {
                            append("\u2503 ")
                            renderInline(line.substring(2), linkColor)
                        }
                    }
                    line.trimStart().let {
                        it.startsWith("- ") || it.startsWith("* ")
                    } -> {
                        val trimmed: String = line.trimStart()
                        // Guard against a lone "* " being confused for an
                        // italic marker on the next line.
                        append("\u2022 ")
                        renderInline(trimmed.substring(2), linkColor)
                    }
                    else -> renderInline(line, linkColor)
                }
                if (i < lines.size - 1) append("\n")
            }
        }
    }

    /**
     * Data holder used only within [renderInline]. Represents one
     * matched marker in the input text — its byte range, what kind of
     * marker it is, its display text, and (for links) its target URL.
     */
    private data class Marker(
        val start: Int,
        val end: Int,
        val kind: String,
        val display: String,
        val url: String? = null
    )

    private fun AnnotatedString.Builder.renderInline(
        text: String, linkColor: Color
    ) {
        if (text.isEmpty()) return
        val markers: MutableList<Marker> = mutableListOf()

        // Links must be extracted first — they contain [text](url)
        // brackets that other patterns must NOT match inside of.
        for (m in LINK_PATTERN.findAll(text)) {
            markers.add(
                Marker(
                    start = m.range.first,
                    end = m.range.last + 1,
                    kind = "link",
                    display = m.groupValues[1],
                    url = m.groupValues[2]
                )
            )
        }
        for (m in COLOR_SPAN_PATTERN.findAll(text)) {
            if (overlapsAny(m.range.first, m.range.last, markers)) continue
            markers.add(
                Marker(
                    start = m.range.first,
                    end = m.range.last + 1,
                    kind = "color:" + m.groupValues[1].trim(),
                    display = m.groupValues[2]
                )
            )
        }
        for (m in UNDERLINE_PATTERN.findAll(text)) {
            if (overlapsAny(m.range.first, m.range.last, markers)) continue
            markers.add(
                Marker(
                    start = m.range.first,
                    end = m.range.last + 1,
                    kind = "u",
                    display = m.groupValues[1]
                )
            )
        }
        for (m in BOLD_PATTERN.findAll(text)) {
            if (overlapsAny(m.range.first, m.range.last, markers)) continue
            markers.add(
                Marker(
                    start = m.range.first,
                    end = m.range.last + 1,
                    kind = "bold",
                    display = m.groupValues[1]
                )
            )
        }
        for (m in ITALIC_PATTERN.findAll(text)) {
            if (overlapsAny(m.range.first, m.range.last, markers)) continue
            markers.add(
                Marker(
                    start = m.range.first,
                    end = m.range.last + 1,
                    kind = "italic",
                    display = m.groupValues[1]
                )
            )
        }

        markers.sortBy { it.start }

        var cursor = 0
        for (marker in markers) {
            if (marker.start > cursor) {
                append(text.substring(cursor, marker.start))
            }
            when {
                marker.kind == "link" -> {
                    val url: String = marker.url ?: ""
                    if (url.isNotEmpty()) {
                        withLink(
                            LinkAnnotation.Url(
                                url = url,
                                styles = TextLinkStyles(
                                    style = SpanStyle(
                                        color = linkColor,
                                        textDecoration = TextDecoration.Underline
                                    )
                                )
                            )
                        ) { append(marker.display) }
                    } else {
                        // No URL parsed — just render the display text
                        append(marker.display)
                    }
                }
                marker.kind == "bold" -> {
                    withStyle(SpanStyle(fontWeight = FontWeight.Bold)) {
                        append(marker.display)
                    }
                }
                marker.kind == "italic" -> {
                    withStyle(SpanStyle(fontStyle = FontStyle.Italic)) {
                        append(marker.display)
                    }
                }
                marker.kind == "u" -> {
                    withStyle(
                        SpanStyle(textDecoration = TextDecoration.Underline)
                    ) { append(marker.display) }
                }
                marker.kind.startsWith("color:") -> {
                    val colorStr: String = marker.kind.substring(6)
                    val parsed: Color? = parseColor(colorStr)
                    if (parsed != null) {
                        withStyle(SpanStyle(color = parsed)) {
                            append(marker.display)
                        }
                    } else {
                        append(marker.display)
                    }
                }
                else -> append(marker.display)
            }
            cursor = marker.end
        }
        if (cursor < text.length) {
            append(text.substring(cursor))
        }
    }

    private fun overlapsAny(
        s: Int, e: Int, existing: List<Marker>
    ): Boolean {
        for (m in existing) {
            // Any positional overlap is a conflict — we don't nest
            // inline markers.
            if (s < m.end && e >= m.start) return true
        }
        return false
    }

    private fun parseColor(raw: String): Color? {
        return try {
            val hex: String = raw.trim().removePrefix("#")
            when (hex.length) {
                3 -> {
                    val r: Int = (hex[0].toString() + hex[0]).toInt(16)
                    val g: Int = (hex[1].toString() + hex[1]).toInt(16)
                    val b: Int = (hex[2].toString() + hex[2]).toInt(16)
                    Color(red = r, green = g, blue = b)
                }
                6 -> {
                    val r: Int = hex.substring(0, 2).toInt(16)
                    val g: Int = hex.substring(2, 4).toInt(16)
                    val b: Int = hex.substring(4, 6).toInt(16)
                    Color(red = r, green = g, blue = b)
                }
                8 -> {
                    val a: Int = hex.substring(0, 2).toInt(16)
                    val r: Int = hex.substring(2, 4).toInt(16)
                    val g: Int = hex.substring(4, 6).toInt(16)
                    val b: Int = hex.substring(6, 8).toInt(16)
                    Color(red = r, green = g, blue = b, alpha = a)
                }
                else -> null
            }
        } catch (_: Throwable) {
            null
        }
    }
}
