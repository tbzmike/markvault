package com.tebogo.markvault.ai

import android.content.Context
import org.json.JSONObject
import java.io.File

/**
 * Trust-on-first-use SHA-256 pinning for downloaded T5 model files.
 *
 * We have no independently-verified checksum to ship for the upstream
 * files (see the note in [T5ModelCatalog]), so instead: the first
 * successful download of a given file name has its SHA-256 computed from
 * the actual bytes received and pinned here. Every later download of a
 * file with the same name must match the pinned hash, or it's rejected --
 * this catches corruption, a tampered mirror, or an unexpected silent
 * upstream file swap. It does NOT protect the very first download the way
 * a checksum from a trusted out-of-band source would; that's a real,
 * disclosed limitation, not a hidden one.
 */
class T5ChecksumStore(context: Context) {
    private val storeFile = File(context.filesDir, "models/t5-base/checksums.json")

    private fun readAll(): JSONObject {
        if (!storeFile.exists()) return JSONObject()
        return try {
            JSONObject(storeFile.readText())
        } catch (e: Exception) {
            JSONObject()
        }
    }

    fun pinnedHashFor(fileName: String): String? {
        val obj = readAll()
        return if (obj.has(fileName)) obj.getString(fileName) else null
    }

    fun pin(fileName: String, sha256Hex: String) {
        storeFile.parentFile?.mkdirs()
        val obj = readAll()
        obj.put(fileName, sha256Hex)
        storeFile.writeText(obj.toString())
    }

    fun clear() {
        if (storeFile.exists()) storeFile.delete()
    }
}
