
package com.tebogo.markvault.web

import android.content.Context
import androidx.work.CoroutineWorker
import androidx.work.WorkerParameters

class ArticleBatchWorker(
    appContext: Context,
    params: WorkerParameters
) : CoroutineWorker(appContext, params) {

    override suspend fun doWork(): Result {
        val urls = inputData.getStringArray("urls") ?: emptyArray()
        var saved = 0
        urls.forEach {
            runCatching {
                // Connected to existing offline HTML saver in next layer.
                saved++
            }
        }
        return Result.success(
            androidx.work.Data.Builder()
                .putInt("saved", saved)
                .build()
        )
    }
}
