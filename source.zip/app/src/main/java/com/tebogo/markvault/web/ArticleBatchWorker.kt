package com.tebogo.markvault.web

import android.content.Context
import androidx.work.CoroutineWorker
import androidx.work.WorkerParameters
import com.tebogo.markvault.data.Note
import com.tebogo.markvault.data.VaultDb
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONArray

class ArticleBatchWorker(
    appContext: Context,
    params: WorkerParameters
) : CoroutineWorker(appContext, params) {

    companion object {
        fun enqueue(context: Context, articlesJson: String) {
            val data = androidx.work.Data.Builder()
                .putString("articles", articlesJson)
                .build()

            val request = androidx.work.OneTimeWorkRequestBuilder<ArticleBatchWorker>()
                .setInputData(data)
                .build()

            androidx.work.WorkManager.getInstance(context).enqueue(request)
        }
    }

    override suspend fun doWork(): Result = withContext(Dispatchers.IO) {
        var saved = 0
        val json = inputData.getString("articles") ?: "[]"

        runCatching {
            val array = JSONArray(json)
            val dao = VaultDb.get(applicationContext).notes()

            for (i in 0 until array.length()) {
                val item = array.getJSONObject(i)
                val title = item.optString("title", "Offline article")
                val url = item.optString("url")
                val html = item.optString("html")

                dao.upsert(
                    Note(
                        uri = url,
                        relPath = "Web Articles/$title.html",
                        name = "$title.html",
                        title = title,
                        folder = "Web Articles",
                        content = html,
                        lastModified = System.currentTimeMillis(),
                        size = html.length.toLong(),
                        fileType = "html"
                    )
                )

                saved++
                setProgress(
                    androidx.work.workDataOf(
                        "done" to saved,
                        "total" to array.length()
                    )
                )
            }
        }

        Result.success(androidx.work.workDataOf("saved" to saved))
    }
}
