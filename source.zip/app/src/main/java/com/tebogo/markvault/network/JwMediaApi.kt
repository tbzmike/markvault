package com.tebogo.markvault.network

import com.tebogo.markvault.data.MediaItem
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONObject

/**
 * v5.4.217cc — JW.org public media API.
 *
 * Fixes:
 *   • Browser-like User-Agent so JW.org's CDN doesn't reject the request
 *   • parseSearch tries both "results" and "media" root keys
 *   • lastError captures the raw HTTP status + body prefix for debugging
 *   • fetchByKey() looks up a single video by its natural key or docId
 */
object JwMediaApi {

    private const val BASE    = "https://data.jw-api.org/mediator/v1"
    private const val LANG    = "E"
    private const val TIMEOUT = 20_000

    /** Last raw HTTP outcome — set on every fetchJson call for debugging. */
    @Volatile var lastError: String = "(not called yet)"

    // ── Public API ──────────────────────────────────────────────────────────

    suspend fun search(query: String, limit: Int = 20): List<MediaItem> =
        withContext(Dispatchers.IO) {
            val url = "$BASE/search/results/$LANG?q=${enc(query)}&limit=$limit"
            parseSearch(fetchJson(url) ?: return@withContext emptyList())
        }

    /**
     * Look up a single video by its JW.org natural key or docId.
     * Used when the user taps a JW.org video link inside an article.
     */
    suspend fun fetchByKey(key: String): MediaItem? = withContext(Dispatchers.IO) {
        // Try direct category key (works for well-known program/drama keys)
        val catUrl = "$BASE/categories/$LANG/$key?detailed=1"
        val catJson = fetchJson(catUrl)
        if (catJson != null) {
            val items = parseCategoryItems(catJson)
            if (items.isNotEmpty()) return@withContext items[0]
        }
        // Fall back to search
        val results = parseSearch(fetchJson("$BASE/search/results/$LANG?q=${enc(key)}&limit=3") ?: return@withContext null)
        results.firstOrNull()
    }

    suspend fun topCategories(): List<JwCategory> = withContext(Dispatchers.IO) {
        parseCategories(fetchJson("$BASE/categories/$LANG?detailed=1") ?: return@withContext emptyList())
    }

    suspend fun categoryItems(key: String): List<MediaItem> = withContext(Dispatchers.IO) {
        parseCategoryItems(fetchJson("$BASE/categories/$LANG/$key?detailed=1") ?: return@withContext emptyList())
    }

    // ── HTTP ────────────────────────────────────────────────────────────────

    private fun fetchJson(url: String): JSONObject? = try {
        val conn = java.net.URL(url).openConnection() as java.net.HttpURLConnection
        conn.connectTimeout = TIMEOUT
        conn.readTimeout    = TIMEOUT
        conn.instanceFollowRedirects = true
        // Browser-like UA so JW.org CDN doesn't reject the request
        conn.setRequestProperty("Accept", "application/json, */*")
        conn.setRequestProperty("Accept-Language", "en-US,en;q=0.9")
        conn.setRequestProperty(
            "User-Agent",
            "Mozilla/5.0 (Linux; Android 13) AppleWebKit/537.36 " +
                "(KHTML, like Gecko) Chrome/120.0.0.0 Mobile Safari/537.36"
        )
        val code = conn.responseCode
        if (code == 200) {
            val body = conn.inputStream.bufferedReader().readText()
            lastError = "HTTP 200 — ${body.take(120)}"
            JSONObject(body)
        } else {
            val err = runCatching { conn.errorStream?.bufferedReader()?.readText()?.take(120) }.getOrNull() ?: ""
            lastError = "HTTP $code — $err"
            null
        }
    } catch (e: Exception) {
        lastError = "Exception: ${e.javaClass.simpleName}: ${e.message}"
        null
    }

    private fun enc(s: String) = java.net.URLEncoder.encode(s, "UTF-8")

    // ── Parsers ─────────────────────────────────────────────────────────────

    private fun parseSearch(json: JSONObject): List<MediaItem> {
        // JW.org API uses "results" at root level; some endpoints use "media"
        val arr = json.optJSONArray("results")
            ?: json.optJSONArray("media")
            ?: return emptyList()
        return (0 until arr.length()).mapNotNull { arr.optJSONObject(it)?.let(::fromJson) }
    }

    private fun parseCategoryItems(json: JSONObject): List<MediaItem> {
        val arr = json.optJSONObject("category")?.optJSONArray("media") ?: return emptyList()
        return (0 until arr.length()).mapNotNull { arr.optJSONObject(it)?.let(::fromJson) }
    }

    private fun parseCategories(json: JSONObject): List<JwCategory> {
        val arr = json.optJSONArray("categories") ?: return emptyList()
        return (0 until arr.length()).mapNotNull { o ->
            arr.optJSONObject(o)?.let {
                JwCategory(it.optString("key"), it.optString("name"),
                    it.optString("description"), thumbnail(it))
            }
        }
    }

    private fun fromJson(j: JSONObject): MediaItem {
        val mime = bestMime(j)
        return MediaItem(
            title         = j.optString("title"),
            description   = j.optString("description"),
            durationMs    = j.optLong("durationInMs", 0L),
            thumbnailUrl  = thumbnail(j),
            streamUrl     = bestFileUrl(j),
            mediaType     = if (mime.startsWith("audio")) "audio" else "video",
            mimeType      = mime,
            jwKey         = j.optString("languageAgnosticNaturalKey").ifBlank {
                "${j.optString("primaryCategory")}_${j.optString("title").hashCode()}"
            },
            scriptureRefs = buildScriptureRefs(j),
            category      = j.optString("primaryCategory"),
            source        = "jworg"
        )
    }

    private fun thumbnail(j: JSONObject): String {
        val img = j.optJSONObject("images") ?: return ""
        return img.optJSONObject("lsr")?.optString("md")?.ifBlank { null }
            ?: img.optJSONObject("sqr")?.optString("md")?.ifBlank { null }
            ?: ""
    }

    private fun bestFileUrl(j: JSONObject): String {
        val files = j.optJSONArray("files") ?: return ""
        var best = ""
        for (i in 0 until files.length()) {
            val f   = files.optJSONObject(i) ?: continue
            val url = f.optString("url")
            val lbl = f.optString("label", "")
            if (url.endsWith(".mp4") && lbl.contains("720")) return url
            if (url.endsWith(".mp4") && best.isEmpty()) best = url
            if (best.isEmpty()) best = url
        }
        return best
    }

    private fun bestMime(j: JSONObject): String {
        val files = j.optJSONArray("files") ?: return "video/mp4"
        for (i in 0 until files.length()) {
            val m = files.optJSONObject(i)?.optString("mimetype") ?: continue
            if (m.isNotBlank()) return m
        }
        return "video/mp4"
    }

    private fun buildScriptureRefs(j: JSONObject): String {
        val tags = j.optJSONArray("tags") ?: return ""
        return (0 until tags.length())
            .mapNotNull { tags.optString(it).takeIf { t -> t.matches(Regex(".*\\d+:\\d+.*")) } }
            .joinToString(", ")
    }
}

data class JwCategory(val key: String, val name: String, val description: String, val thumbnailUrl: String)
