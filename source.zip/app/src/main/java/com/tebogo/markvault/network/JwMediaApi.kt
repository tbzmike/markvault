package com.tebogo.markvault.network

import com.tebogo.markvault.data.MediaItem
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject

/**
 * v5.4.232cc — JW.org public media API client.
 *
 * Confirmed-working endpoint (verified against the open-source jw-scripts
 * downloader's actual field usage):
 *   Category: /categories/{lang}/{key}?detailed=1
 *     → category.media[]          (direct media in this category)
 *     → category.subcategories[]  (JW.org's video library IS hierarchical —
 *                                   many "folders" hold mostly subcategories
 *                                   with little/no direct media of their own)
 *
 * The dedicated "/search/results" endpoint's exact response shape is
 * undocumented and could not be verified. Search is therefore built
 * entirely on the confirmed category endpoint: crawl top categories + one
 * subcategory level, filter by title/description match. Slower than a
 * dedicated search call but guaranteed to actually return results.
 */
object JwMediaApi {

    private const val BASE    = "https://data.jw-api.org/mediator/v1"
    private const val JW_MEDIA_BASE = "https://b.jw-cdn.org/apis/mediator/v1"
    private const val LANG    = "E"
    private const val TIMEOUT = 15_000

    data class CategoryDetail(
        val key: String,
        val name: String,
        val subcategories: List<JwCategory>,
        val media: List<MediaItem>
    )

    // ── Browse ────────────────────────────────────────────────────────────────

    suspend fun topCategories(language: String = LANG): List<JwCategory> = withContext(Dispatchers.IO) {
        val lang = language.ifBlank { LANG }
        val json = fetchJson("$BASE/categories/$lang?detailed=1") ?: return@withContext emptyList()
        parseCategories(json)
    }

    /** v5.4.350cc — Languages exposed by JW mediator, localized in [displayLanguage]. */
    suspend fun languages(displayLanguage: String = LANG): List<JwMediaLanguage> = withContext(Dispatchers.IO) {
        val lang = displayLanguage.ifBlank { LANG }
        val json = fetchJson("$JW_MEDIA_BASE/languages/$lang/web") ?: return@withContext listOf(JwMediaLanguage("E", "English", "English"))
        val arr = json.optJSONArray("languages")
            ?: json.optJSONArray("translations")
            ?: json.optJSONArray("items")
        if (arr == null) return@withContext listOf(JwMediaLanguage("E", "English", "English"))
        val out = mutableListOf<JwMediaLanguage>()
        for (i in 0 until arr.length()) {
            val o = arr.optJSONObject(i) ?: continue
            val code = o.optString("code")
            if (code.isBlank()) continue
            val name = o.optString("name").ifBlank { code }
            val native = o.optString("vernacular").ifBlank { name }
            val locale = o.optString("locale")
            out += JwMediaLanguage(code, name, native, locale)
        }
        if (out.none { it.code == "E" }) out += JwMediaLanguage("E", "English", "English")
        out.distinctBy { it.code }.sortedBy { it.name.lowercase() }
    }

    /**
     * v5.4.232cc — Full category detail: BOTH its own direct media AND its
     * subcategories. Previously only `media` was read, so any category that
     * is mostly a "folder of folders" (which is most of them — JW.org's
     * video library nests several levels deep) appeared almost empty.
     *
     * v5.4.250cc — `media` is now sorted by upload date, newest first, so
     * every screen that reads it (JwVideoBrowseScreen's folder view,
     * MarkVault's global search sidebar/carousel) automatically shows
     * newest-first without each caller having to re-sort.
     */
    suspend fun categoryDetail(key: String, language: String = LANG): CategoryDetail = withContext(Dispatchers.IO) {
        val lang = language.ifBlank { LANG }
        val json = fetchJson("$BASE/categories/$lang/$key?detailed=1")
        val cat  = json?.optJSONObject("category")
        CategoryDetail(
            key           = key,
            name          = cat?.optString("name")?.ifBlank { key } ?: key,
            subcategories = parseSubcategories(cat),
            media         = parseMediaArraySafe(cat?.optJSONArray("media"), lang)
                                .sortedByDescending { it.uploadDate }
        )
    }


    /**
     * v5.4.386cc — Crawl the complete selected-language JW media hierarchy
     * and return every distinct video. Unlike search(), this intentionally has
     * no shallow depth/budget because the bulk-caption command must cover the
     * whole library, not just recently cached or nearby categories.
     */
    suspend fun allVideos(
        language: String = LANG,
        onProgress: ((visitedCategories: Int, discoveredVideos: Int) -> Unit)? = null
    ): List<MediaItem> = withContext(Dispatchers.IO) {
        val lang = language.ifBlank { LANG }
        val queue = java.util.ArrayDeque<JwCategory>()
        topCategories(lang).forEach(queue::addLast)
        val visited = HashSet<String>()
        val videos = LinkedHashMap<String, MediaItem>()

        while (queue.isNotEmpty()) {
            val category = queue.removeFirst()
            if (category.key.isBlank() || !visited.add(category.key)) continue

            val detail = runCatching { categoryDetail(category.key, lang) }.getOrNull()
            if (detail == null) {
                onProgress?.invoke(visited.size, videos.size)
                continue
            }
            detail.subcategories.forEach { sub ->
                if (sub.key.isNotBlank() && sub.key !in visited) queue.addLast(sub)
            }
            detail.media.asSequence()
                .filter { it.mediaType.equals("video", ignoreCase = true) }
                .forEach { media ->
                    val stableKey = media.jwKey.ifBlank {
                        "${media.title}|${media.streamUrl}|${media.contentLanguage}"
                    }
                    videos.putIfAbsent(stableKey, media)
                }
            onProgress?.invoke(visited.size, videos.size)
        }

        videos.values.toList()
    }

    /** Back-compat wrapper for existing callers that only need the media list. */
    suspend fun categoryItems(key: String, language: String = LANG): List<MediaItem> = categoryDetail(key, language).media

    /**
     * v5.4.288cc — Resolve one exact media item by JW's stable
     * languageAgnosticNaturalKey. This is the mediator route used for a video
     * after it has already been selected, and lets legacy cached MarkVault rows
     * acquire their VTT caption URL without crawling/searching categories.
     */
    suspend fun mediaByNaturalKey(key: String, language: String = LANG): MediaItem? =
        withContext(Dispatchers.IO) {
            if (key.isBlank()) return@withContext null
            val safeLanguage = language.ifBlank { LANG }
            val encodedKey = java.net.URLEncoder.encode(key, "UTF-8")
            val json = fetchJson("$JW_MEDIA_BASE/media-items/$safeLanguage/$encodedKey?clientType=www")
                ?: return@withContext null
            // The mediator has returned both array-shaped and single-object
            // media payloads over time. Accept either instead of silently
            // losing caption metadata for legacy cached videos.
            val mediaNode = json.opt("media")
            when (mediaNode) {
                is org.json.JSONArray -> parseMediaArraySafe(mediaNode, safeLanguage).firstOrNull()
                is org.json.JSONObject -> runCatching { mediaItemFromJson(mediaNode, safeLanguage) }.getOrNull()
                else -> {
                    val direct = json.optJSONObject("mediaItem")
                    if (direct != null) runCatching { mediaItemFromJson(direct, safeLanguage) }.getOrNull() else null
                }
            }
        }

    // ── Search ────────────────────────────────────────────────────────────────

    /**
     * v5.4.232cc — Search built on the confirmed-working category endpoint.
     * Step 1: best-effort attempt at the (unverified) direct search endpoint
     *         — kept because it's cheap and harmless if it happens to work.
     * Step 2: guaranteed fallback — crawl top categories, then one level of
     *         subcategories, filtering title/description for [query].
     *         Bounded to 25 category fetches so it stays responsive.
     */
    /**
     * v5.4.234cc — Fuzzy, case-insensitive, "closest match" search.
     * Every candidate is SCORED (not just included/excluded) by how many
     * query tokens appear in its title/description, so a query doesn't
     * need to be exact — "caleb sofia" still finds "Caleb and Sophia"
     * even with a misspelling, and results are ranked by relevance
     * rather than returned in arbitrary crawl order.
     *
     * Crawls 2 levels of subcategories (was 1) with a larger visit
     * budget, since JW.org's real hierarchy is often 3+ levels deep —
     * a shallow crawl was the main reason legitimate queries found
     * nothing even though matching content existed further down the tree.
     */
    suspend fun search(query: String, limit: Int = 40, language: String = LANG): List<MediaItem> = withContext(Dispatchers.IO) {
        val lang = language.ifBlank { LANG }
        val q = query.trim()
        if (q.isBlank()) return@withContext emptyList()
        val qLower = q.lowercase()
        val tokens = qLower.split(Regex("[^\\p{L}\\p{Nd}]+")).filter { token -> token.length >= 2 || token.all { ch -> ch.isDigit() } }
        if (tokens.isEmpty()) return@withContext emptyList()

        val scored   = LinkedHashMap<String, Pair<MediaItem, Int>>()  // key -> (item, bestScore)

        fun scoreOf(m: MediaItem): Int {
            val titleL = m.title.lowercase()
            val descL  = m.description.lowercase()
            var score = 0
            // v5.4.297cc — A bare number in an Audio-folder search means a
            // song number. Give an exact "Song N" / leading-N title a dominant
            // score while retaining ordinary name/fuzzy search unchanged.
            val requestedSongNo = qLower.toIntOrNull()
            if (requestedSongNo != null) {
                val songMatch = Regex("(?i)\\bsong\\s*(?:no\\.?\\s*)?${requestedSongNo}\\b").containsMatchIn(m.title) ||
                    Regex("^\\s*${requestedSongNo}(?:[.\\s:–—-]|$)").containsMatchIn(m.title)
                if (songMatch) score += 100
            }
            if (titleL.contains(qLower)) score += 12          // whole phrase in title — best signal
            if (descL.contains(qLower))  score += 4            // whole phrase in description
            for (t in tokens) {
                if (titleL.contains(t)) score += 3              // individual word in title
                if (descL.contains(t))  score += 1              // individual word in description
            }
            return score
        }

        fun addCandidate(m: MediaItem) {
            val s = scoreOf(m)
            if (s <= 0) return
            val key = m.jwKey.ifBlank { m.title }
            val existing = scored[key]
            if (existing == null || s > existing.second) scored[key] = m to s
        }

        // Step 1 — best-effort direct search call (unverified endpoint,
        // kept because it's cheap and harmless if it happens to work).
        runCatching {
            val json = fetchJson("$BASE/search/results/$lang?q=${encode(q)}&limit=$limit")
            val arr = json?.optJSONArray("results") ?: json?.optJSONArray("media")
            if (arr != null) {
                for (i in 0 until arr.length()) {
                    val o = arr.optJSONObject(i) ?: continue
                    runCatching { mediaItemFromJson(o, lang) }.getOrNull()?.let(::addCandidate)
                }
            }
        }

        // Step 2 — guaranteed fallback: crawl top categories + 2 levels of
        // subcategories, fuzzy-scoring every item found along the way.
        val tops = runCatching { topCategories(lang) }.getOrElse { emptyList() }
        var visited = 0
        val maxVisits = 60

        suspend fun crawl(cat: JwCategory, depthRemaining: Int) {
            if (visited >= maxVisits) return
            visited++
            val detail = runCatching { categoryDetail(cat.key, lang) }.getOrNull() ?: return
            detail.media.forEach(::addCandidate)
            if (depthRemaining > 0) {
                for (sub in detail.subcategories) {
                    if (visited >= maxVisits) break
                    crawl(sub, depthRemaining - 1)
                }
            }
        }

        for (top in tops) {
            if (visited >= maxVisits) break
            crawl(top, depthRemaining = 2)   // top -> sub -> sub-sub (2 levels below top)
        }

        scored.values.sortedByDescending { it.second }.take(limit).map { it.first }
    }

    /**
     * v5.4.250cc — Folder-scoped search. Crawls ONLY [rootKey]'s own media
     * plus its own subcategory subtree — never the rest of JW.org's
     * library — so searching while browsing inside a folder stays
     * confined to that folder's contents, matching the fuzzy title/
     * description scoring [search] above uses, just seeded at one
     * category instead of every top category.
     *
     * Deliberately NOT sharing code with [search]: an isolated, fully
     * self-contained function means this addition cannot regress the
     * existing, already-verified global search in any way — [search]
     * above is untouched, byte for byte.
     *
     * Crawls deeper (4 levels) than the global search's 2-level cap:
     * confined to one branch instead of scanning the whole library
     * leaves budget to go further down before hitting maxVisits.
     *
     * Results are sorted by match relevance (like [search]), not upload
     * date — a search result's usefulness is about how well it matches
     * the query, not when it was published; browse listings (which have
     * no relevance signal) are what [categoryDetail] sorts by date.
     */
    suspend fun searchInCategory(
        rootKey: String,
        query: String,
        limit: Int = 40,
        language: String = LANG,
        includeJwKeys: Set<String> = emptySet()
    ): List<MediaItem> = withContext(Dispatchers.IO) {
        val lang = language.ifBlank { LANG }
        val q = query.trim()
        if (q.isBlank() || rootKey.isBlank()) return@withContext emptyList()
        val qLower = q.lowercase()
        val tokens = qLower.split(Regex("[^\\p{L}\\p{Nd}]+")).filter { token -> token.length >= 2 || token.all { ch -> ch.isDigit() } }
        if (tokens.isEmpty()) return@withContext emptyList()

        val scored = LinkedHashMap<String, Pair<MediaItem, Int>>()  // key -> (item, bestScore)

        fun scoreOf(m: MediaItem): Int {
            val titleL = m.title.lowercase()
            val descL  = m.description.lowercase()
            var score = 0
            // v5.4.297cc — A bare number in an Audio-folder search means a
            // song number. Give an exact "Song N" / leading-N title a dominant
            // score while retaining ordinary name/fuzzy search unchanged.
            val requestedSongNo = qLower.toIntOrNull()
            if (requestedSongNo != null) {
                val songMatch = Regex("(?i)\\bsong\\s*(?:no\\.?\\s*)?${requestedSongNo}\\b").containsMatchIn(m.title) ||
                    Regex("^\\s*${requestedSongNo}(?:[.\\s:–—-]|$)").containsMatchIn(m.title)
                if (songMatch) score += 100
            }
            if (titleL.contains(qLower)) score += 12
            if (descL.contains(qLower))  score += 4
            for (t in tokens) {
                if (titleL.contains(t)) score += 3
                if (descL.contains(t))  score += 1
            }
            return score
        }

        fun addCandidate(m: MediaItem) {
            val key = m.jwKey.ifBlank { m.title }
            // v5.4.387cc — Caption search supplies stable JW keys that matched
            // downloaded transcript text. Including those keys here lets a
            // folder-scoped Media Library search preserve its existing subtree
            // boundary without putting caption text into this metadata search.
            val captionHit = m.jwKey.isNotBlank() && m.jwKey in includeJwKeys
            val s = scoreOf(m) + if (captionHit) 1_000 else 0
            if (s <= 0) return
            val existing = scored[key]
            if (existing == null || s > existing.second) scored[key] = m to s
        }

        var visited = 0
        val maxVisits = 60

        suspend fun crawl(key: String, depthRemaining: Int) {
            if (visited >= maxVisits) return
            visited++
            val detail = runCatching { categoryDetail(key, lang) }.getOrNull() ?: return
            detail.media.forEach(::addCandidate)
            if (depthRemaining > 0) {
                for (sub in detail.subcategories) {
                    if (visited >= maxVisits) break
                    crawl(sub.key, depthRemaining - 1)
                }
            }
        }

        crawl(rootKey, depthRemaining = 4)

        scored.values.sortedByDescending { it.second }.take(limit).map { it.first }
    }

    private fun fetchJson(url: String): JSONObject? = try {
        val conn = java.net.URL(url).openConnection() as java.net.HttpURLConnection
        conn.connectTimeout = TIMEOUT
        conn.readTimeout    = TIMEOUT
        conn.setRequestProperty("Accept", "application/json")
        conn.setRequestProperty("User-Agent", "MarkVault/5.4 Android")
        if (conn.responseCode == 200) {
            val body = conn.inputStream.bufferedReader().readText()
            JSONObject(body)
        } else null
    } catch (_: Exception) { null }

    private fun encode(s: String) = java.net.URLEncoder.encode(s, "UTF-8")

    // ── Parsers ───────────────────────────────────────────────────────────────

    private fun parseCategories(json: JSONObject): List<JwCategory> {
        val cats   = json.optJSONArray("categories") ?: return emptyList()
        val result = mutableListOf<JwCategory>()
        for (i in 0 until cats.length()) {
            val c = cats.optJSONObject(i) ?: continue
            runCatching {
                result += JwCategory(
                    key          = c.optString("key"),
                    name         = c.optString("name"),
                    description  = c.optString("description"),
                    thumbnailUrl = thumbnail(c)
                )
            }
        }
        return result
    }

    private fun parseSubcategories(cat: JSONObject?): List<JwCategory> {
        val arr = cat?.optJSONArray("subcategories") ?: return emptyList()
        val result = mutableListOf<JwCategory>()
        for (i in 0 until arr.length()) {
            val s = arr.optJSONObject(i) ?: continue
            runCatching {
                result += JwCategory(
                    key          = s.optString("key"),
                    name         = s.optString("name"),
                    description  = s.optString("description"),
                    thumbnailUrl = thumbnail(s)
                )
            }
        }
        return result
    }

    /**
     * v5.4.232cc — Per-item try/catch so ONE malformed entry never kills the
     * whole batch. Previously, if `mediaItemFromJson()` threw on any single
     * item, the exception propagated up through the suspend function chain
     * to the caller's `runCatching{}.getOrElse{emptyList()}` — silently
     * discarding the ENTIRE category's results, not just the bad item. This
     * is the root cause of categories appearing completely empty.
     */
    private fun parseMediaArraySafe(arr: JSONArray?, language: String = LANG): List<MediaItem> {
        if (arr == null) return emptyList()
        val items = mutableListOf<MediaItem>()
        for (i in 0 until arr.length()) {
            val o = arr.optJSONObject(i) ?: continue
            runCatching { mediaItemFromJson(o, language) }.getOrNull()?.let { items += it }
        }
        return items
    }

    private fun mediaItemFromJson(j: JSONObject, language: String = LANG): MediaItem {
        val title   = j.optString("title")
        val desc    = j.optString("description")
        val jwKey   = j.optString("languageAgnosticNaturalKey").ifBlank {
            j.optString("primaryCategory") + "_" + j.optString("title").hashCode()
        }
        val durMs   = j.optLong("durationInMs", 0L)
        val thumb   = thumbnail(j)
        val fileUrl = bestFileUrl(j)
        // JW.org's own "type" field ("video"/"audio") is the authoritative
        // classification — more reliable than mime sniffing.
        val mime    = bestMime(j)
        val mType   = j.optString("type").ifBlank {
            if (mime.startsWith("audio")) "audio" else "video"
        }
        val cat     = j.optString("primaryCategory")
        val tags    = j.optJSONArray("tags")
        val scripts = buildString {
            if (tags != null) for (t in 0 until tags.length()) {
                val tag = tags.optString(t)
                if (tag.matches(Regex(".*\\d+:\\d+.*"))) append("$tag, ")
            }
        }.trimEnd(',', ' ')
        return MediaItem(
            title         = title,
            description   = desc,
            durationMs    = durMs,
            thumbnailUrl  = thumb,
            streamUrl     = fileUrl,
            mediaType     = mType,
            mimeType      = mime,
            jwKey         = jwKey,
            scriptureRefs = scripts,
            category      = cat,
            source        = "jworg",
            qualityOptions = allQualityOptions(j),
            uploadDate    = parseUploadDate(j),
            subtitleUrl   = bestSubtitleUrl(j),
            subtitleLanguage = language.ifBlank { LANG },
            contentLanguage = language.ifBlank { LANG }
        )
    }

    private fun thumbnail(j: JSONObject): String {
        val images = j.optJSONObject("images") ?: return ""
        return images.optJSONObject("lsr")?.optString("md")?.ifBlank { null }
            ?: images.optJSONObject("sqr")?.optString("md")?.ifBlank { null }
            ?: ""
    }

    /**
     * v5.4.250cc — Upload/publish date, epoch millis. Field name and format
     * verified against jw-scripts' jwlib/parse.py (the same open-source
     * project this file's own header comment already cites as the
     * verification source for the category/media endpoint shape):
     *
     *   if 'firstPublished' in j_media:
     *       date_string = re.sub(r'\.[0-9]+Z$', '', j_media['firstPublished'])
     *       date = time.mktime(time.strptime(date_string, '%Y-%m-%dT%H:%M:%S'))
     *
     * i.e. `firstPublished` is a top-level string field on each media
     * object, ISO-8601 with fractional seconds and a trailing 'Z'
     * (e.g. "2023-05-12T14:30:00.000Z"). Instant.parse() accepts that
     * exact format directly — no manual regex-stripping needed the way
     * the Python version does. runCatching guards any field-shape drift;
     * a missing/malformed date yields 0 (unknown), never a crash.
     */
    private fun parseUploadDate(j: JSONObject): Long {
        val raw = j.optString("firstPublished")
        if (raw.isBlank()) return 0L
        return runCatching { java.time.Instant.parse(raw).toEpochMilli() }.getOrDefault(0L)
    }

    /**
     * v5.4.235cc — Collect EVERY available quality variant (not just the
     * best ≤720p one bestFileUrl() picks) for the in-player quality
     * picker. Format: one "label\turl" pair per line, highest resolution
     * first. Skips entries with no usable URL. Deduplicates by resolution
     * so the picker doesn't show two identical "480p" entries.
     */
    private fun allQualityOptions(j: JSONObject): String {
        val files = j.optJSONArray("files") ?: return ""
        data class Variant(val res: Int, val label: String, val url: String)
        val variants = mutableListOf<Variant>()
        for (i in 0 until files.length()) {
            val f = files.optJSONObject(i) ?: continue
            val url = f.optString("progressiveDownloadURL").ifBlank { f.optString("url") }
            if (url.isBlank()) continue
            val rawLabel = f.optString("label", "")
            val res = rawLabel.trimEnd('p').toIntOrNull() ?: f.optInt("frameHeight", 0)
            val label = rawLabel.ifBlank { if (res > 0) "${res}p" else "Standard" }
            variants += Variant(res, label, url)
        }
        return variants
            .distinctBy { it.res }
            .sortedByDescending { it.res }
            .joinToString("\n") { "${it.label}\t${it.url}" }
    }

    /**
     * v5.4.231cc — The actual streaming URL field on each file entry is
     * `progressiveDownloadURL`, NOT `url`. Verified against the open-source
     * jw-scripts downloader (`j_media_file['progressiveDownloadURL']`).
     * Picks the highest resolution at or below 720p; falls back to whatever
     * is available if nothing meets that cap.
     */
    private fun bestFileUrl(j: JSONObject): String {
        val files = j.optJSONArray("files") ?: return ""
        var best = ""
        var bestRes = -1
        for (i in 0 until files.length()) {
            val f = files.optJSONObject(i) ?: continue
            val url = f.optString("progressiveDownloadURL").ifBlank { f.optString("url") }
            if (url.isBlank()) continue
            val label = f.optString("label", "")
            val res = label.trimEnd('p').toIntOrNull() ?: f.optInt("frameHeight", 0)
            if (best.isEmpty()) { best = url; bestRes = res }
            else if (res in (bestRes + 1)..720) { best = url; bestRes = res }
        }
        return best
    }

    /**
     * v5.4.288cc — Caption URL paired with the same quality-selection logic
     * used by [bestFileUrl]. JW mediator file objects expose captions as
     * `subtitles.url`. If the selected rendition has no subtitle object, fall
     * back to the first usable subtitle URL on another rendition.
     */
    private fun bestSubtitleUrl(j: JSONObject): String {
        val files = j.optJSONArray("files") ?: return ""
        var best: JSONObject? = null
        var bestRes = -1
        for (i in 0 until files.length()) {
            val f = files.optJSONObject(i) ?: continue
            val url = f.optString("progressiveDownloadURL").ifBlank { f.optString("url") }
            if (url.isBlank()) continue
            val label = f.optString("label", "")
            val res = label.trimEnd('p').toIntOrNull() ?: f.optInt("frameHeight", 0)
            if (best == null) {
                best = f
                bestRes = res
            } else if (res in (bestRes + 1)..720) {
                best = f
                bestRes = res
            }
        }
        best?.optJSONObject("subtitles")?.optString("url")?.takeIf { it.isNotBlank() }?.let { return it }
        for (i in 0 until files.length()) {
            val subtitle = files.optJSONObject(i)?.optJSONObject("subtitles")?.optString("url").orEmpty()
            if (subtitle.isNotBlank()) return subtitle
        }
        return ""
    }

    private fun bestMime(j: JSONObject): String {
        val files = j.optJSONArray("files") ?: return "video/mp4"
        for (i in 0 until files.length()) {
            val mime = files.optJSONObject(i)?.optString("mimetype") ?: continue
            if (mime.isNotBlank()) return mime
        }
        val url = bestFileUrl(j)
        return when {
            url.endsWith(".mp3", true) -> "audio/mpeg"
            url.endsWith(".m4a", true) -> "audio/mp4"
            else -> "video/mp4"
        }
    }
}

data class JwMediaLanguage(
    val code: String,
    val name: String,
    val nativeName: String,
    /** JW web locale/symbol (for example en, es, nso). */
    val locale: String = ""
)

data class JwCategory(
    val key: String,
    val name: String,
    val description: String,
    val thumbnailUrl: String
)
