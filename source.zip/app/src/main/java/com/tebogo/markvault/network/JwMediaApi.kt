package com.tebogo.markvault.network

import com.tebogo.markvault.data.MediaItem
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject

/**
 * v5.4.232cc — JW.org public media API client.
 *
 * Confirmed-working endpoint (verified against the open-source jw-scripts
 * downloader's actual field usage):
 *   Category: /categories/{lang}/{key}?detailed=1
 *     → category.media[]          (direct media in this category)
 *     → category.subcategories[]  (JW.org's video library IS hierarchical —
 *                                   many "folders" hold mostly subcategories
 *                                   with little/no direct media of their own)
 *
 * The dedicated "/search/results" endpoint's exact response shape is
 * undocumented and could not be verified. Search is therefore built
 * entirely on the confirmed category endpoint: crawl top categories + one
 * subcategory level, filter by title/description match. Slower than a
 * dedicated search call but guaranteed to actually return results.
 */
object JwMediaApi {

    private const val BASE    = "https://data.jw-api.org/mediator/v1"
    private const val LANG    = "E"
    private const val TIMEOUT = 15_000

    data class CategoryDetail(
        val key: String,
        val name: String,
        val subcategories: List<JwCategory>,
        val media: List<MediaItem>
    )

    // ── Browse ────────────────────────────────────────────────────────────────

    suspend fun topCategories(): List<JwCategory> = withContext(Dispatchers.IO) {
        val json = fetchJson("$BASE/categories/$LANG?detailed=1") ?: return@withContext emptyList()
        parseCategories(json)
    }

    /**
     * v5.4.232cc — Full category detail: BOTH its own direct media AND its
     * subcategories. Previously only `media` was read, so any category that
     * is mostly a "folder of folders" (which is most of them — JW.org's
     * video library nests several levels deep) appeared almost empty.
     */
    suspend fun categoryDetail(key: String): CategoryDetail = withContext(Dispatchers.IO) {
        val json = fetchJson("$BASE/categories/$LANG/$key?detailed=1")
        val cat  = json?.optJSONObject("category")
        CategoryDetail(
            key           = key,
            name          = cat?.optString("name")?.ifBlank { key } ?: key,
            subcategories = parseSubcategories(cat),
            media         = parseMediaArraySafe(cat?.optJSONArray("media"))
        )
    }

    /** Back-compat wrapper for existing callers that only need the media list. */
    suspend fun categoryItems(key: String): List<MediaItem> = categoryDetail(key).media

    // ── Search ────────────────────────────────────────────────────────────────

    /**
     * v5.4.232cc — Search built on the confirmed-working category endpoint.
     * Step 1: best-effort attempt at the (unverified) direct search endpoint
     *         — kept because it's cheap and harmless if it happens to work.
     * Step 2: guaranteed fallback — crawl top categories, then one level of
     *         subcategories, filtering title/description for [query].
     *         Bounded to 25 category fetches so it stays responsive.
     */
    suspend fun search(query: String, limit: Int = 40): List<MediaItem> = withContext(Dispatchers.IO) {
        val q = query.trim()
        if (q.isBlank()) return@withContext emptyList()
        val qLower = q.lowercase()
        val matches  = mutableListOf<MediaItem>()
        val seenKeys = HashSet<String>()

        fun matchesQuery(m: MediaItem) =
            m.title.lowercase().contains(qLower) || m.description.lowercase().contains(qLower)

        fun addIfNew(m: MediaItem) {
            if (seenKeys.add(m.jwKey.ifBlank { m.title })) matches += m
        }

        // Step 1 — best-effort direct search call.
        runCatching {
            val json = fetchJson("$BASE/search/results/$LANG?q=${encode(q)}&limit=$limit")
            val arr = json?.optJSONArray("results") ?: json?.optJSONArray("media")
            if (arr != null) {
                for (i in 0 until arr.length()) {
                    val o = arr.optJSONObject(i) ?: continue
                    runCatching { mediaItemFromJson(o) }.getOrNull()?.let(::addIfNew)
                }
            }
        }

        // Step 2 — guaranteed fallback crawl.
        if (matches.size < limit) {
            val tops = runCatching { topCategories() }.getOrElse { emptyList() }
            var visited = 0
            val maxVisits = 25
            for (top in tops) {
                if (matches.size >= limit || visited >= maxVisits) break
                visited++
                val detail = runCatching { categoryDetail(top.key) }.getOrNull() ?: continue
                detail.media.forEach { if (matchesQuery(it)) addIfNew(it) }
                for (sub in detail.subcategories) {
                    if (matches.size >= limit || visited >= maxVisits) break
                    visited++
                    val subDetail = runCatching { categoryDetail(sub.key) }.getOrNull() ?: continue
                    subDetail.media.forEach { if (matchesQuery(it)) addIfNew(it) }
                }
            }
        }
        matches.take(limit)
    }

    // ── Internal HTTP ─────────────────────────────────────────────────────────

    private fun fetchJson(url: String): JSONObject? = try {
        val conn = java.net.URL(url).openConnection() as java.net.HttpURLConnection
        conn.connectTimeout = TIMEOUT
        conn.readTimeout    = TIMEOUT
        conn.setRequestProperty("Accept", "application/json")
        conn.setRequestProperty("User-Agent", "MarkVault/5.4 Android")
        if (conn.responseCode == 200) {
            val body = conn.inputStream.bufferedReader().readText()
            JSONObject(body)
        } else null
    } catch (_: Exception) { null }

    private fun encode(s: String) = java.net.URLEncoder.encode(s, "UTF-8")

    // ── Parsers ───────────────────────────────────────────────────────────────

    private fun parseCategories(json: JSONObject): List<JwCategory> {
        val cats   = json.optJSONArray("categories") ?: return emptyList()
        val result = mutableListOf<JwCategory>()
        for (i in 0 until cats.length()) {
            val c = cats.optJSONObject(i) ?: continue
            runCatching {
                result += JwCategory(
                    key          = c.optString("key"),
                    name         = c.optString("name"),
                    description  = c.optString("description"),
                    thumbnailUrl = thumbnail(c)
                )
            }
        }
        return result
    }

    private fun parseSubcategories(cat: JSONObject?): List<JwCategory> {
        val arr = cat?.optJSONArray("subcategories") ?: return emptyList()
        val result = mutableListOf<JwCategory>()
        for (i in 0 until arr.length()) {
            val s = arr.optJSONObject(i) ?: continue
            runCatching {
                result += JwCategory(
                    key          = s.optString("key"),
                    name         = s.optString("name"),
                    description  = s.optString("description"),
                    thumbnailUrl = thumbnail(s)
                )
            }
        }
        return result
    }

    /**
     * v5.4.232cc — Per-item try/catch so ONE malformed entry never kills the
     * whole batch. Previously, if `mediaItemFromJson()` threw on any single
     * item, the exception propagated up through the suspend function chain
     * to the caller's `runCatching{}.getOrElse{emptyList()}` — silently
     * discarding the ENTIRE category's results, not just the bad item. This
     * is the root cause of categories appearing completely empty.
     */
    private fun parseMediaArraySafe(arr: JSONArray?): List<MediaItem> {
        if (arr == null) return emptyList()
        val items = mutableListOf<MediaItem>()
        for (i in 0 until arr.length()) {
            val o = arr.optJSONObject(i) ?: continue
            runCatching { mediaItemFromJson(o) }.getOrNull()?.let { items += it }
        }
        return items
    }

    private fun mediaItemFromJson(j: JSONObject): MediaItem {
        val title   = j.optString("title")
        val desc    = j.optString("description")
        val jwKey   = j.optString("languageAgnosticNaturalKey").ifBlank {
            j.optString("primaryCategory") + "_" + j.optString("title").hashCode()
        }
        val durMs   = j.optLong("durationInMs", 0L)
        val thumb   = thumbnail(j)
        val fileUrl = bestFileUrl(j)
        // JW.org's own "type" field ("video"/"audio") is the authoritative
        // classification — more reliable than mime sniffing.
        val mime    = bestMime(j)
        val mType   = j.optString("type").ifBlank {
            if (mime.startsWith("audio")) "audio" else "video"
        }
        val cat     = j.optString("primaryCategory")
        val tags    = j.optJSONArray("tags")
        val scripts = buildString {
            if (tags != null) for (t in 0 until tags.length()) {
                val tag = tags.optString(t)
                if (tag.matches(Regex(".*\\d+:\\d+.*"))) append("$tag, ")
            }
        }.trimEnd(',', ' ')
        return MediaItem(
            title         = title,
            description   = desc,
            durationMs    = durMs,
            thumbnailUrl  = thumb,
            streamUrl     = fileUrl,
            mediaType     = mType,
            mimeType      = mime,
            jwKey         = jwKey,
            scriptureRefs = scripts,
            category      = cat,
            source        = "jworg"
        )
    }

    private fun thumbnail(j: JSONObject): String {
        val images = j.optJSONObject("images") ?: return ""
        return images.optJSONObject("lsr")?.optString("md")?.ifBlank { null }
            ?: images.optJSONObject("sqr")?.optString("md")?.ifBlank { null }
            ?: ""
    }

    /**
     * v5.4.231cc — The actual streaming URL field on each file entry is
     * `progressiveDownloadURL`, NOT `url`. Verified against the open-source
     * jw-scripts downloader (`j_media_file['progressiveDownloadURL']`).
     * Picks the highest resolution at or below 720p; falls back to whatever
     * is available if nothing meets that cap.
     */
    private fun bestFileUrl(j: JSONObject): String {
        val files = j.optJSONArray("files") ?: return ""
        var best = ""
        var bestRes = -1
        for (i in 0 until files.length()) {
            val f = files.optJSONObject(i) ?: continue
            val url = f.optString("progressiveDownloadURL").ifBlank { f.optString("url") }
            if (url.isBlank()) continue
            val label = f.optString("label", "")
            val res = label.trimEnd('p').toIntOrNull() ?: f.optInt("frameHeight", 0)
            if (best.isEmpty()) { best = url; bestRes = res }
            else if (res in (bestRes + 1)..720) { best = url; bestRes = res }
        }
        return best
    }

    private fun bestMime(j: JSONObject): String {
        val files = j.optJSONArray("files") ?: return "video/mp4"
        for (i in 0 until files.length()) {
            val mime = files.optJSONObject(i)?.optString("mimetype") ?: continue
            if (mime.isNotBlank()) return mime
        }
        val url = bestFileUrl(j)
        return when {
            url.endsWith(".mp3", true) -> "audio/mpeg"
            url.endsWith(".m4a", true) -> "audio/mp4"
            else -> "video/mp4"
        }
    }
}

data class JwCategory(
    val key: String,
    val name: String,
    val description: String,
    val thumbnailUrl: String
)
