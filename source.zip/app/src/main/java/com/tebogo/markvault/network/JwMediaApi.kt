package com.tebogo.markvault.network

import com.tebogo.markvault.data.MediaItem
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONObject

/**
 * v5.4.212cc — JW.org public media API (no auth required).
 * Base: https://data.jw-api.org/mediator/v1/
 */
object JwMediaApi {

    private const val BASE    = "https://data.jw-api.org/mediator/v1"
    private const val LANG    = "E"
    private const val TIMEOUT = 15_000

    suspend fun search(query: String, limit: Int = 20): List<MediaItem> =
        withContext(Dispatchers.IO) {
            val url = "$BASE/search/results/$LANG?q=${encode(query)}&limit=$limit"
            parseSearch(fetchJson(url) ?: return@withContext emptyList())
        }

    suspend fun topCategories(): List<JwCategory> =
        withContext(Dispatchers.IO) {
            parseCategories(fetchJson("$BASE/categories/$LANG?detailed=1") ?: return@withContext emptyList())
        }

    suspend fun categoryItems(key: String): List<MediaItem> =
        withContext(Dispatchers.IO) {
            val url = "$BASE/categories/$LANG/$key?detailed=1"
            parseCategoryItems(fetchJson(url) ?: return@withContext emptyList())
        }

    private fun fetchJson(url: String): JSONObject? = try {
        val conn = java.net.URL(url).openConnection() as java.net.HttpURLConnection
        conn.connectTimeout = TIMEOUT; conn.readTimeout = TIMEOUT
        conn.setRequestProperty("Accept", "application/json")
        conn.setRequestProperty("User-Agent", "MarkVault/5.4 Android")
        if (conn.responseCode == 200)
            JSONObject(conn.inputStream.bufferedReader().readText())
        else null
    } catch (_: Exception) { null }

    private fun encode(s: String) = java.net.URLEncoder.encode(s, "UTF-8")

    private fun parseSearch(json: JSONObject): List<MediaItem> {
        val arr = json.optJSONArray("results") ?: return emptyList()
        return (0 until arr.length()).mapNotNull { arr.optJSONObject(it)?.let(::fromJson) }
    }

    private fun parseCategoryItems(json: JSONObject): List<MediaItem> {
        val arr = json.optJSONObject("category")?.optJSONArray("media") ?: return emptyList()
        return (0 until arr.length()).mapNotNull { arr.optJSONObject(it)?.let(::fromJson) }
    }

    private fun parseCategories(json: JSONObject): List<JwCategory> {
        val arr = json.optJSONArray("categories") ?: return emptyList()
        return (0 until arr.length()).mapNotNull { o ->
            arr.optJSONObject(o)?.let {
                JwCategory(it.optString("key"), it.optString("name"),
                    it.optString("description"), thumbnail(it))
            }
        }
    }

    private fun fromJson(j: JSONObject): MediaItem {
        val files = j.optJSONArray("files")
        val fileUrl = bestFileUrl(j)
        val mime    = bestMime(j)
        return MediaItem(
            title        = j.optString("title"),
            description  = j.optString("description"),
            durationMs   = j.optLong("durationInMs", 0L),
            thumbnailUrl = thumbnail(j),
            streamUrl    = fileUrl,
            mediaType    = if (mime.startsWith("audio")) "audio" else "video",
            mimeType     = mime,
            jwKey        = j.optString("languageAgnosticNaturalKey").ifBlank {
                "${j.optString("primaryCategory")}_${j.optString("title").hashCode()}"
            },
            scriptureRefs = buildScriptureRefs(j),
            category     = j.optString("primaryCategory"),
            source       = "jworg"
        )
    }

    private fun thumbnail(j: JSONObject): String {
        val img = j.optJSONObject("images") ?: return ""
        return img.optJSONObject("lsr")?.optString("md")?.ifBlank { null }
            ?: img.optJSONObject("sqr")?.optString("md")?.ifBlank { null }
            ?: ""
    }

    private fun bestFileUrl(j: JSONObject): String {
        val files = j.optJSONArray("files") ?: return ""
        var best = ""
        for (i in 0 until files.length()) {
            val f = files.optJSONObject(i) ?: continue
            val url = f.optString("url")
            val lbl = f.optString("label", "")
            if (url.endsWith(".mp4") && lbl.contains("720")) return url
            if (url.endsWith(".mp4") && best.isEmpty()) best = url
            if (best.isEmpty()) best = url
        }
        return best
    }

    private fun bestMime(j: JSONObject): String {
        val files = j.optJSONArray("files") ?: return "video/mp4"
        for (i in 0 until files.length()) {
            val m = files.optJSONObject(i)?.optString("mimetype") ?: continue
            if (m.isNotBlank()) return m
        }
        return "video/mp4"
    }

    private fun buildScriptureRefs(j: JSONObject): String {
        val tags = j.optJSONArray("tags") ?: return ""
        return (0 until tags.length())
            .mapNotNull { tags.optString(it).takeIf { t -> t.matches(Regex(".*\\d+:\\d+.*")) } }
            .joinToString(", ")
    }
}

data class JwCategory(val key: String, val name: String, val description: String, val thumbnailUrl: String)
