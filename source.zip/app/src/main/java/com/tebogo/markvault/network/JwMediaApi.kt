package com.tebogo.markvault.network

import com.tebogo.markvault.data.MediaItem
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONObject

/**
 * v5.4.212cc — JW.org public media API client.
 *
 * No authentication required. All endpoints return JSON.
 * Base: https://data.jw-api.org/mediator/v1/
 *
 * Key endpoints:
 *   Search:  /search/results/{lang}?q={query}&limit={n}
 *   Browse:  /categories/{lang}?detailed=1
 *   Detail:  /categories/{lang}/{key}?detailed=1
 */
object JwMediaApi {

    private const val BASE    = "https://data.jw-api.org/mediator/v1"
    private const val LANG    = "E"   // English; swap for other locales
    private const val TIMEOUT = 15_000

    // ── Search ────────────────────────────────────────────────────────────────

    /**
     * Search JW.org media for [query]. Returns up to [limit] MediaItems.
     * Results include videos and audio; caller can filter by [mediaType].
     */
    suspend fun search(
        query: String,
        limit: Int = 20,
        mediaType: String? = null   // null = both; "video" or "audio"
    ): List<MediaItem> = withContext(Dispatchers.IO) {
        val typeParam = when (mediaType) {
            "video" -> "&type=video"
            "audio" -> "&type=audio"
            else    -> ""
        }
        val url = "$BASE/search/results/$LANG?q=${encode(query)}&limit=$limit$typeParam"
        val json = fetchJson(url) ?: return@withContext emptyList()
        parseSearchResults(json)
    }

    // ── Browse categories ─────────────────────────────────────────────────────

    /**
     * Fetch top-level JW.org media categories (JW Broadcasting, Dramas, etc.)
     */
    suspend fun topCategories(): List<JwCategory> = withContext(Dispatchers.IO) {
        val url = "$BASE/categories/$LANG?detailed=1"
        val json = fetchJson(url) ?: return@withContext emptyList()
        parseCategories(json)
    }

    /**
     * Fetch media items inside a specific JW.org category key.
     */
    suspend fun categoryItems(key: String): List<MediaItem> = withContext(Dispatchers.IO) {
        val url = "$BASE/categories/$LANG/$key?detailed=1"
        val json = fetchJson(url) ?: return@withContext emptyList()
        parseCategoryItems(json)
    }

    // ── Internal HTTP ─────────────────────────────────────────────────────────

    private fun fetchJson(url: String): JSONObject? = try {
        val conn = java.net.URL(url).openConnection() as java.net.HttpURLConnection
        conn.connectTimeout = TIMEOUT
        conn.readTimeout    = TIMEOUT
        conn.setRequestProperty("Accept", "application/json")
        conn.setRequestProperty("User-Agent", "MarkVault/5.4 Android")
        if (conn.responseCode == 200) {
            val body = conn.inputStream.bufferedReader().readText()
            JSONObject(body)
        } else null
    } catch (_: Exception) { null }

    private fun encode(s: String) =
        java.net.URLEncoder.encode(s, "UTF-8")

    // ── Parsers ───────────────────────────────────────────────────────────────

    private fun parseSearchResults(json: JSONObject): List<MediaItem> {
        val results = json.optJSONArray("results") ?: return emptyList()
        val items   = mutableListOf<MediaItem>()
        for (i in 0 until results.length()) {
            val r = results.optJSONObject(i) ?: continue
            items += mediaItemFromJson(r)
        }
        return items
    }

    private fun parseCategoryItems(json: JSONObject): List<MediaItem> {
        val cat   = json.optJSONObject("category") ?: return emptyList()
        val media = cat.optJSONArray("media") ?: return emptyList()
        val items = mutableListOf<MediaItem>()
        for (i in 0 until media.length()) {
            val m = media.optJSONObject(i) ?: continue
            items += mediaItemFromJson(m)
        }
        return items
    }

    private fun parseCategories(json: JSONObject): List<JwCategory> {
        val cats   = json.optJSONArray("categories") ?: return emptyList()
        val result = mutableListOf<JwCategory>()
        for (i in 0 until cats.length()) {
            val c = cats.optJSONObject(i) ?: continue
            result += JwCategory(
                key         = c.optString("key"),
                name        = c.optString("name"),
                description = c.optString("description"),
                thumbnailUrl = thumbnail(c)
            )
        }
        return result
    }

    private fun mediaItemFromJson(j: JSONObject): MediaItem {
        val title   = j.optString("title")
        val desc    = j.optString("description")
        val jwKey   = j.optString("languageAgnosticNaturalKey").ifBlank {
            j.optString("primaryCategory") + "_" + j.optString("title").hashCode()
        }
        val durMs   = j.optLong("durationInMs", 0L)
        val thumb   = thumbnail(j)
        val fileUrl = bestFileUrl(j)
        // v5.4.231cc — JW.org's own "type" field ("video"/"audio") is the
        // authoritative classification — more reliable than mime sniffing.
        val mType   = j.optString("type").ifBlank {
            val mime = bestMime(j)
            if (mime.startsWith("audio")) "audio" else "video"
        }
        val mime    = bestMime(j)
        val cat     = j.optString("primaryCategory")
        val tags    = j.optJSONArray("tags")
        val scripts = buildString {
            if (tags != null) for (t in 0 until tags.length()) {
                val tag = tags.optString(t)
                if (tag.matches(Regex(".*\\d+:\\d+.*"))) append("$tag, ")
            }
        }.trimEnd(',', ' ')
        return MediaItem(
            title        = title,
            description  = desc,
            durationMs   = durMs,
            thumbnailUrl = thumb,
            streamUrl    = fileUrl,
            mediaType    = mType,
            mimeType     = mime,
            jwKey        = jwKey,
            scriptureRefs = scripts,
            category     = cat,
            source       = "jworg"
        )
    }

    private fun thumbnail(j: JSONObject): String {
        val images = j.optJSONObject("images") ?: return ""
        // Prefer landscape (lsr) md, then sqr (square) md
        return images.optJSONObject("lsr")?.optString("md")?.ifBlank { null }
            ?: images.optJSONObject("sqr")?.optString("md")?.ifBlank { null }
            ?: ""
    }

    /**
     * v5.4.231cc — CRITICAL FIX: the actual streaming URL field on each file
     * entry is `progressiveDownloadURL`, NOT `url`. Verified against JW.org's
     * public mediator API field names (cross-checked with the open-source
     * jw-scripts downloader, which reads
     * `j_media_file['progressiveDownloadURL']`). The old code read a
     * non-existent `url` field, so every streamUrl was silently empty —
     * media loaded and displayed fine (title/thumbnail/description all come
     * from other fields) but nothing could ever play.
     */
    private fun bestFileUrl(j: JSONObject): String {
        val files = j.optJSONArray("files") ?: return ""
        var best = ""
        var bestRes = -1
        for (i in 0 until files.length()) {
            val f = files.optJSONObject(i) ?: continue
            val url = f.optString("progressiveDownloadURL").ifBlank { f.optString("url") }
            if (url.isBlank()) continue
            val label = f.optString("label", "")
            val res = label.trimEnd('p').toIntOrNull()
                ?: f.optInt("frameHeight", 0)
            // Prefer the highest resolution at or below 720p (keeps mobile
            // data usage sane); fall back to whatever is available.
            if (best.isEmpty()) { best = url; bestRes = res }
            else if (res in (bestRes + 1)..720) { best = url; bestRes = res }
        }
        return best
    }

    private fun bestMime(j: JSONObject): String {
        val files = j.optJSONArray("files") ?: return "video/mp4"
        for (i in 0 until files.length()) {
            val mime = files.optJSONObject(i)?.optString("mimetype") ?: continue
            if (mime.isNotBlank()) return mime
        }
        // Fall back to inferring from the URL extension when mimetype is absent.
        val url = bestFileUrl(j)
        return when {
            url.endsWith(".mp3", true) -> "audio/mpeg"
            url.endsWith(".m4a", true) -> "audio/mp4"
            else -> "video/mp4"
        }
    }
}

data class JwCategory(
    val key: String,
    val name: String,
    val description: String,
    val thumbnailUrl: String
)
