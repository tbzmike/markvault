package com.tebogo.markvault.ai

object T5PipelineLogger {
    private var lastTrace: T5QueryTrace? = null

    fun record(trace: T5QueryTrace) { lastTrace = trace }
    fun last(): T5QueryTrace? = lastTrace
}
