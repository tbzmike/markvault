package com.tebogo.markvault.llm

import com.tebogo.markvault.data.Note
import com.tebogo.markvault.data.NoteDao
import com.tebogo.markvault.search.Embedder

/**
 * v4.20.0 — Stage 4: RAG prompt builder.
 *
 * Turns a user question into a single prompt string that the chat LLM
 * answers. The prompt is structured in three parts:
 *
 *   1. **System rules** — encodes the user's standing instructions
 *      (NWT-first, no speculation, no cross symbol, refuse if notes
 *      don't cover it). Verbatim from the user's memory items.
 *   2. **Retrieved notes** — the top-K most semantically similar notes
 *      from the user's library, prefixed by title for citation tracking.
 *   3. **The question** — the user's literal query, last so the model's
 *      most recent attention is on what to answer.
 *
 * This file is pure orchestration — no UI, no service, no LiteRT-LM
 * calls. It produces a String + citations and is trivially unit-testable.
 *
 * ## Why the prompt structure looks like this
 *
 * The rules-first / context / question pattern is the standard RAG
 * prompt shape and small instruction-tuned models follow it well. The
 * "refuse if not in notes" rule is the safeguard against the LLM
 * inventing content not in the user's library — which would violate the
 * user's "no speculative claims" standing instruction.
 *
 * The JW-specific framing comes straight from the user's memory:
 *   - "primarily use the New World Translation"
 *   - "Respond as one of Jehovah's Witnesses"
 *   - "NEVER use the cross symbol — Jesus died on a torture stake"
 *   - "no speculation"
 */

/**
 * A single citation produced by the RAG pipeline. The chat UI renders
 * these as tappable chips that open the source note.
 */
data class RagCitation(
    val noteId: Long,
    val title: String,
    /** Cosine similarity score from BGE-large (higher = more relevant). */
    val score: Float,
    /** Short preview of the note content, ≤ 200 chars. */
    val snippet: String
)

/**
 * The complete output of the RAG pipeline. The `prompt` field goes to
 * [LlmManager.generate]; the `citations` field goes to the chat UI.
 */
data class RagPrompt(
    val prompt: String,
    val citations: List<RagCitation>,
    /** Empty when no notes scored above [RagPromptBuilder.MIN_SCORE]. */
    val isLibraryHit: Boolean
)

object RagPromptBuilder {

    /**
     * Cosine score below which a note is considered "not really relevant"
     * and excluded from the prompt. Tuned empirically — BGE-large scores
     * for genuinely related notes typically land 0.55+; below 0.40 is
     * usually drift. We err toward including borderline matches because
     * the LLM can recognise irrelevance and ignore them.
     */
    private const val MIN_SCORE = 0.35f

    /**
     * Hard cap on note content per slot in the prompt, in characters.
     * Gemma 3 1B has a 4096-token context. Each token ≈ 4 chars on
     * average for English. We budget:
     *   ~ 1000 tokens for system rules + question + structure
     *   ~ 3000 tokens for retrieved notes
     *   ~ 96 tokens of margin
     * At 6 notes × ~2000 chars each = ~12000 chars ≈ 3000 tokens.
     */
    private const val NOTE_EXCERPT_CHARS = 2000

    /** How long the citation chip snippet shows (must be shorter than NOTE_EXCERPT_CHARS). */
    private const val CITATION_SNIPPET_CHARS = 200

    /**
     * The system rules block, prepended to every prompt. Verbatim
     * encoding of the user's standing instructions plus the
     * grounded-in-notes safety rail.
     */
    private val SYSTEM_RULES = """
You are an assistant helping the user — one of Jehovah's Witnesses — find and
synthesise information from their personal Bible-study notes library.

ABSOLUTE RULES (never violate):
1. Answer ONLY from the notes provided below. If the notes do not contain
   enough information to answer the question, say so honestly and stop. Do
   NOT invent facts, scriptures, or arguments not present in the notes.
2. When quoting or paraphrasing scripture, use the New World Translation
   (NWT) as the primary translation.
3. Speak as one of Jehovah's Witnesses, using the terminology of jw.org
   and wol.jw.org publications.
4. NEVER use the cross symbol or the word "cross" when referring to the
   instrument of Jesus' death. Jesus died on a torture stake.
5. Do not speculate about manuscript history, "lost originals", or
   anything not supported by the notes you were given.
6. At the end of your answer, cite which note titles each main claim came
   from, in the form: [Note title].

If multiple notes disagree, present both views and indicate the disagreement
rather than picking a side.

""".trimIndent()

    /**
     * Build a prompt for [userQuery] by retrieving up to [topK] relevant
     * notes from [dao] via [embedder] + the in-memory semantic search
     * function provided by the caller (typically
     * `AppViewModel::semanticSearch`).
     *
     * @param userQuery The user's literal question.
     * @param topK How many notes to pull from semantic search.
     * @param semanticSearch Function that takes a query and returns
     *   `(noteId, score)` pairs sorted descending by score. This is
     *   injected rather than imported directly so the prompt builder
     *   has no dependency on AppViewModel.
     * @param dao Room DAO for fetching note content by id.
     * @param embedder Currently unused here — left in the signature so
     *   future versions can optionally re-embed for HyDE-style retrieval.
     */
    suspend fun build(
        userQuery: String,
        topK: Int = 6,
        semanticSearch: suspend (String, Int) -> List<Pair<Long, Float>>,
        dao: NoteDao,
        @Suppress("UNUSED_PARAMETER") embedder: Embedder
    ): RagPrompt {
        val trimmed = userQuery.trim()
        if (trimmed.isEmpty()) {
            return RagPrompt(
                prompt = "$SYSTEM_RULES\n\nThe user's question was empty.",
                citations = emptyList(),
                isLibraryHit = false
            )
        }

        // 1. Retrieve top-K from semantic search.
        val hits = semanticSearch(trimmed, topK)
            .filter { it.second >= MIN_SCORE }
            .take(topK)

        if (hits.isEmpty()) {
            // No good matches at all — produce a prompt that explicitly
            // tells the model the library doesn't cover this. The model
            // will then say so honestly (which is exactly what we want).
            val emptyPrompt = buildString {
                append(SYSTEM_RULES)
                append("\n\n")
                append("NOTES PROVIDED: (none — the user's library does not contain ")
                append("any notes relevant to this question)\n\n")
                append("QUESTION: ")
                append(trimmed)
                append("\n\nANSWER:")
            }
            return RagPrompt(
                prompt = emptyPrompt,
                citations = emptyList(),
                isLibraryHit = false
            )
        }

        // 2. Fetch note content from Room and assemble citation list.
        val citations = mutableListOf<RagCitation>()
        val noteBlocks = mutableListOf<String>()
        for ((noteId, score) in hits) {
            val note: Note = dao.byId(noteId) ?: continue
            val excerpt = note.content
                .take(NOTE_EXCERPT_CHARS)
                .trim()
            val snippet = note.content
                .replace(Regex("\\s+"), " ")
                .trim()
                .take(CITATION_SNIPPET_CHARS)
            citations += RagCitation(
                noteId = noteId,
                title = note.title,
                score = score,
                snippet = snippet
            )
            noteBlocks += buildString {
                append("--- NOTE: ")
                append(note.title)
                append(" ---\n")
                append(excerpt)
                if (note.content.length > NOTE_EXCERPT_CHARS) {
                    append("\n[…note continues; truncated for context budget…]")
                }
            }
        }

        // 3. Assemble final prompt.
        val finalPrompt = buildString {
            append(SYSTEM_RULES)
            append("\n\n")
            append("NOTES PROVIDED:\n\n")
            append(noteBlocks.joinToString("\n\n"))
            append("\n\nQUESTION: ")
            append(trimmed)
            append("\n\nANSWER:")
        }

        return RagPrompt(
            prompt = finalPrompt,
            citations = citations,
            isLibraryHit = citations.isNotEmpty()
        )
    }

    /**
     * v4.22.1 — Build a prompt that asks the model to summarise a specific
     * document. Bypasses semantic retrieval — the caller (typically a
     * reader screen's "Summarise" button) already knows which document
     * is in view.
     *
     * The same [SYSTEM_RULES] apply (NWT-first, no cross symbol, no
     * speculation, JW terminology). The question asks specifically for
     * a concise summary covering the main argument, key scriptures
     * cited, and notable conclusions.
     */
    fun buildSummarize(noteId: Long, title: String, content: String): RagPrompt {
        val excerpt = content.take(NOTE_EXCERPT_CHARS).trim()
        val truncated = content.length > NOTE_EXCERPT_CHARS
        val snippet = content.replace(Regex("\\s+"), " ").trim().take(CITATION_SNIPPET_CHARS)
        val prompt = buildString {
            append(SYSTEM_RULES)
            append("\n\n")
            append("NOTES PROVIDED:\n\n")
            append("--- NOTE: ").append(title).append(" ---\n")
            append(excerpt)
            if (truncated) {
                append("\n[…note continues; truncated for context budget…]")
            }
            append("\n\nQUESTION: Please summarise the note above concisely. ")
            append("Cover the main argument or topic, key scriptures cited, ")
            append("and any notable conclusions. Be brief — 4 to 8 sentences.")
            append("\n\nANSWER:")
        }
        return RagPrompt(
            prompt = prompt,
            citations = listOf(RagCitation(noteId, title, 1.0f, snippet)),
            isLibraryHit = true
        )
    }

    /**
     * v5.4.46 — Build a RAG prompt from a pre-selected list of notes.
     * Used by the global chat screen's "recent articles" context mode,
     * where semantic search is bypassed and the caller already knows
     * which notes to feed.
     *
     * Each note's content is truncated to [NOTE_EXCERPT_CHARS] so the
     * total prompt fits comfortably in even SmolLM2 135M's context
     * window (the caller limits the list to 1–5 notes anyway).
     *
     * Citations are synthesised with a fixed score of 1.0 (we're not
     * ranking — the user chose these notes via recency).
     */
    fun buildFromNotes(
        userQuery: String,
        notes: List<Triple<Long, String, String>>  // (id, title, content)
    ): RagPrompt {
        val trimmed = userQuery.trim()
        if (trimmed.isEmpty() || notes.isEmpty()) {
            val emptyPrompt = buildString {
                append(SYSTEM_RULES)
                append("\n\n")
                if (notes.isEmpty()) {
                    append("NOTES PROVIDED: (none — no recently opened articles found)\n\n")
                }
                append("QUESTION: ").append(trimmed.ifEmpty { "(empty)" })
                append("\n\nANSWER:")
            }
            return RagPrompt(
                prompt = emptyPrompt,
                citations = emptyList(),
                isLibraryHit = false
            )
        }

        val citations = mutableListOf<RagCitation>()
        val noteBlocks = mutableListOf<String>()
        for ((noteId, title, content) in notes) {
            val excerpt = content.take(NOTE_EXCERPT_CHARS).trim()
            val snippet = content.replace(Regex("\\s+"), " ").trim().take(CITATION_SNIPPET_CHARS)
            citations += RagCitation(
                noteId = noteId,
                title = title,
                score = 1.0f,
                snippet = snippet
            )
            noteBlocks += buildString {
                append("--- NOTE: ").append(title).append(" ---\n")
                append(excerpt)
                if (content.length > NOTE_EXCERPT_CHARS) {
                    append("\n[…note continues; truncated for context budget…]")
                }
            }
        }

        val finalPrompt = buildString {
            append(SYSTEM_RULES)
            append("\n\n")
            append("NOTES PROVIDED:\n\n")
            append(noteBlocks.joinToString("\n\n"))
            append("\n\nQUESTION: ").append(trimmed)
            append("\n\nANSWER:")
        }
        return RagPrompt(
            prompt = finalPrompt,
            citations = citations,
            isLibraryHit = true
        )
    }
}
