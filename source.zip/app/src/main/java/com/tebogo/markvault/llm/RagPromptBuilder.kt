package com.tebogo.markvault.llm

import com.tebogo.markvault.data.Note
import com.tebogo.markvault.data.NoteDao
import com.tebogo.markvault.search.Embedder

/**
 * v4.20.0 — Stage 4: RAG prompt builder.
 *
 * Turns a user question into a single prompt string that the chat LLM
 * answers. The prompt is structured in three parts:
 *
 *   1. **System rules** — encodes the user's standing instructions
 *      (NWT-first, no speculation, no cross symbol, refuse if notes
 *      don't cover it). Verbatim from the user's memory items.
 *   2. **Retrieved notes** — the top-K most semantically similar notes
 *      from the user's library, prefixed by title for citation tracking.
 *   3. **The question** — the user's literal query, last so the model's
 *      most recent attention is on what to answer.
 *
 * This file is pure orchestration — no UI, no service, no LiteRT-LM
 * calls. It produces a String + citations and is trivially unit-testable.
 *
 * ## Why the prompt structure looks like this
 *
 * The rules-first / context / question pattern is the standard RAG
 * prompt shape and small instruction-tuned models follow it well. The
 * "refuse if not in notes" rule is the safeguard against the LLM
 * inventing content not in the user's library — which would violate the
 * user's "no speculative claims" standing instruction.
 *
 * The JW-specific framing comes straight from the user's memory:
 *   - "primarily use the New World Translation"
 *   - "Respond as one of Jehovah's Witnesses"
 *   - "NEVER use the cross symbol — Jesus died on a torture stake"
 *   - "no speculation"
 *
 * ## v4.22.2 — Two bug fixes
 *
 * ### Fix 1: early-return on no library hit
 *
 * Previously, when `isLibraryHit = false` (no notes scored above
 * [MIN_SCORE]), the "no notes" prompt was still handed to the LLM and
 * the model would often answer from its own weights anyway, ignoring the
 * system rule that says to refuse. The fix is to NOT call
 * [LlmManager.generate] at all when [isLibraryHit] is false — the
 * caller ([AppViewModel.sendChatMessage]) must short-circuit and display
 * the [NO_LIBRARY_HIT_REPLY] directly without running inference.
 *
 * ### Fix 2: token-budget enforcement before LiteRT-LM call
 *
 * Previously the per-note char cap ([NOTE_EXCERPT_CHARS] = 2000) was
 * calculated against Gemma 3's context window and never revisited. With
 * 6 notes × 2000 chars ≈ 3000 tokens, plus the ~400-token system prompt
 * and the question, the total easily exceeded 4096 tokens — producing
 * LiteRT-LM status code 3 ("Input token ids are too long"). The fix
 * enforces a hard character ceiling on the *assembled note block* before
 * it enters the prompt, trimming notes from the bottom (lowest score)
 * first until the budget is satisfied.
 */

/**
 * A single citation produced by the RAG pipeline. The chat UI renders
 * these as tappable chips that open the source note.
 */
data class RagCitation(
    val noteId: Long,
    val title: String,
    /** Cosine similarity score from BGE-large (higher = more relevant). */
    val score: Float,
    /** Short preview of the note content, ≤ 200 chars. */
    val snippet: String
)

/**
 * The complete output of the RAG pipeline. The `prompt` field goes to
 * [LlmManager.generate]; the `citations` field goes to the chat UI.
 *
 * When [isLibraryHit] is false, callers MUST NOT pass [prompt] to
 * [LlmManager.generate] — instead display [NO_LIBRARY_HIT_REPLY]
 * directly. This is enforced in [AppViewModel.sendChatMessage].
 */
data class RagPrompt(
    val prompt: String,
    val citations: List<RagCitation>,
    /** Empty when no notes scored above [RagPromptBuilder.MIN_SCORE]. */
    val isLibraryHit: Boolean
)

object RagPromptBuilder {

    /**
     * Cosine score below which a note is considered "not really relevant"
     * and excluded from the prompt. Tuned empirically — BGE-large scores
     * for genuinely related notes typically land 0.55+; below 0.40 is
     * usually drift. We err toward including borderline matches because
     * the LLM can recognise irrelevance and ignore them.
     */
    private const val MIN_SCORE = 0.35f

    /**
     * Hard cap on note content per slot in the prompt, in characters.
     * One token ≈ 4 chars for English. We want each note to contribute
     * at most ~300 tokens so 6 notes ≈ 1800 tokens, leaving ~2300 tokens
     * for the system prompt (~400 tok) and question (~50 tok) with a
     * comfortable margin inside the 4096-token window.
     */
    private const val NOTE_EXCERPT_CHARS = 1200

    /**
     * Total character budget for the assembled note block (all notes
     * concatenated, including titles and separators). This is the hard
     * ceiling that prevents status-code-3 overflows regardless of how
     * many notes are retrieved or how long each one is.
     *
     * Budget reasoning (4096-token context):
     *   ~400  tokens — system rules
     *   ~100  tokens — question + prompt scaffolding ("NOTES PROVIDED:",
     *                  "QUESTION:", "ANSWER:", separators)
     *   ~300  tokens — safety margin
     *   ────────────
     *   ~3296 tokens remaining for notes → × 4 chars/token ≈ 13,000 chars
     *
     * We use 12,000 chars (≈ 3,000 tokens) to stay safely under.
     */
    private const val MAX_NOTES_BLOCK_CHARS = 12_000

    /** How long the citation chip snippet shows (must be shorter than NOTE_EXCERPT_CHARS). */
    private const val CITATION_SNIPPET_CHARS = 200

    /**
     * Message returned to the user — without any LLM call — when
     * semantic search finds no notes above [MIN_SCORE].
     *
     * Callers check [RagPrompt.isLibraryHit] and display this directly
     * instead of invoking [LlmManager.generate], preventing the model
     * from answering out of its own weights on topics not covered by the
     * library.
     */
    const val NO_LIBRARY_HIT_REPLY =
        "I couldn't find any notes in your library that cover this topic. " +
        "Try saving some articles or study notes on it first, then ask again."

    /**
     * The system rules block, prepended to every prompt. Verbatim
     * encoding of the user's standing instructions plus the
     * grounded-in-notes safety rail.
     */
    private val SYSTEM_RULES = """
You are an assistant helping the user — one of Jehovah's Witnesses — find and
synthesise information from their personal Bible-study notes library.

ABSOLUTE RULES (never violate):
1. Answer ONLY from the notes provided below. If the notes do not contain
   enough information to answer the question, say so honestly and stop. Do
   NOT invent facts, scriptures, or arguments not present in the notes.
2. When quoting or paraphrasing scripture, use the New World Translation
   (NWT) as the primary translation.
3. Speak as one of Jehovah's Witnesses, using the terminology of jw.org
   and wol.jw.org publications.
4. NEVER use the cross symbol or the word "cross" when referring to the
   instrument of Jesus' death. Jesus died on a torture stake.
5. Do not speculate about manuscript history, "lost originals", or
   anything not supported by the notes you were given.
6. At the end of your answer, cite which note titles each main claim came
   from, in the form: [Note title].

If multiple notes disagree, present both views and indicate the disagreement
rather than picking a side.

""".trimIndent()

    /**
     * Build a prompt for [userQuery] by retrieving up to [topK] relevant
     * notes from [dao] via [embedder] + the in-memory semantic search
     * function provided by the caller (typically
     * `AppViewModel::semanticSearch`).
     *
     * When [RagPrompt.isLibraryHit] is false on the returned value,
     * callers MUST NOT pass the prompt to [LlmManager.generate] — display
     * [NO_LIBRARY_HIT_REPLY] directly instead.
     *
     * @param userQuery The user's literal question.
     * @param topK How many notes to pull from semantic search.
     * @param semanticSearch Function that takes a query and returns
     *   `(noteId, score)` pairs sorted descending by score. This is
     *   injected rather than imported directly so the prompt builder
     *   has no dependency on AppViewModel.
     * @param dao Room DAO for fetching note content by id.
     * @param embedder Currently unused here — left in the signature so
     *   future versions can optionally re-embed for HyDE-style retrieval.
     */
    suspend fun build(
        userQuery: String,
        topK: Int = 6,
        semanticSearch: suspend (String, Int) -> List<Pair<Long, Float>>,
        dao: NoteDao,
        @Suppress("UNUSED_PARAMETER") embedder: Embedder
    ): RagPrompt {
        val trimmed = userQuery.trim()
        if (trimmed.isEmpty()) {
            return RagPrompt(
                prompt = "",
                citations = emptyList(),
                isLibraryHit = false
            )
        }

        // 1. Retrieve top-K from semantic search.
        val hits = semanticSearch(trimmed, topK)
            .filter { it.second >= MIN_SCORE }
            .take(topK)

        // Fix 1: no library hit → return early, caller shows
        // NO_LIBRARY_HIT_REPLY without calling LlmManager.generate.
        if (hits.isEmpty()) {
            return RagPrompt(
                prompt = "",
                citations = emptyList(),
                isLibraryHit = false
            )
        }

        // 2. Fetch note content from Room and assemble citation list.
        val citations = mutableListOf<RagCitation>()
        val noteBlocks = mutableListOf<String>()
        for ((noteId, score) in hits) {
            val note: Note = dao.byId(noteId) ?: continue
            val excerpt = note.content
                .take(NOTE_EXCERPT_CHARS)
                .trim()
            val snippet = note.content
                .replace(Regex("\\s+"), " ")
                .trim()
                .take(CITATION_SNIPPET_CHARS)
            citations += RagCitation(
                noteId = noteId,
                title = note.title,
                score = score,
                snippet = snippet
            )
            noteBlocks += buildString {
                append("--- NOTE: ")
                append(note.title)
                append(" ---\n")
                append(excerpt)
                if (note.content.length > NOTE_EXCERPT_CHARS) {
                    append("\n[…note continues; truncated for context budget…]")
                }
            }
        }

        // Fix 2: enforce total note-block character budget to prevent
        // LiteRT-LM status code 3 ("Input token ids are too long").
        // Drop the lowest-scoring notes (end of list) until the joined
        // block fits within MAX_NOTES_BLOCK_CHARS.
        while (noteBlocks.isNotEmpty()) {
            val joined = noteBlocks.joinToString("\n\n")
            if (joined.length <= MAX_NOTES_BLOCK_CHARS) break
            // Remove the last block (lowest score — hits are desc by score).
            noteBlocks.removeAt(noteBlocks.lastIndex)
            if (citations.size > noteBlocks.size) {
                citations.removeAt(citations.lastIndex)
            }
        }

        // 3. Assemble final prompt.
        val finalPrompt = buildString {
            append(SYSTEM_RULES)
            append("\n\n")
            append("NOTES PROVIDED:\n\n")
            append(noteBlocks.joinToString("\n\n"))
            append("\n\nQUESTION: ")
            append(trimmed)
            append("\n\nANSWER:")
        }

        return RagPrompt(
            prompt = finalPrompt,
            citations = citations,
            isLibraryHit = citations.isNotEmpty()
        )
    }

    /**
     * v4.22.1 — Build a prompt that asks the model to summarise a specific
     * document. Bypasses semantic retrieval — the caller (typically a
     * reader screen's "Summarise" button) already knows which document
     * is in view.
     *
     * The same [SYSTEM_RULES] apply (NWT-first, no cross symbol, no
     * speculation, JW terminology). The question asks specifically for
     * a concise summary covering the main argument, key scriptures
     * cited, and notable conclusions.
     *
     * Token budget: a single note at [NOTE_EXCERPT_CHARS] chars ≈ 300
     * tokens, well within the 4096-token window.
     */
    fun buildSummarize(noteId: Long, title: String, content: String): RagPrompt {
        val excerpt = content.take(NOTE_EXCERPT_CHARS).trim()
        val truncated = content.length > NOTE_EXCERPT_CHARS
        val snippet = content.replace(Regex("\\s+"), " ").trim().take(CITATION_SNIPPET_CHARS)
        val prompt = buildString {
            append(SYSTEM_RULES)
            append("\n\n")
            append("NOTES PROVIDED:\n\n")
            append("--- NOTE: ").append(title).append(" ---\n")
            append(excerpt)
            if (truncated) {
                append("\n[…note continues; truncated for context budget…]")
            }
            append("\n\nQUESTION: Please summarise the note above concisely. ")
            append("Cover the main argument or topic, key scriptures cited, ")
            append("and any notable conclusions. Be brief — 4 to 8 sentences.")
            append("\n\nANSWER:")
        }
        return RagPrompt(
            prompt = prompt,
            citations = listOf(RagCitation(noteId, title, 1.0f, snippet)),
            isLibraryHit = true
        )
    }
}
