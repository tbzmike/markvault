package com.tebogo.markvault.llm

import com.tebogo.markvault.data.Note
import com.tebogo.markvault.data.NoteDao
import com.tebogo.markvault.search.Embedder

/**
 * v4.20.0 — Stage 4: RAG prompt builder.
 *
 * Turns a user question into a single prompt string that the chat LLM
 * answers. The prompt is structured in three parts:
 *
 *   1. **System rules** — encodes the user's standing instructions
 *      (NWT-first, no speculation, no cross symbol, refuse if notes
 *      don't cover it). Verbatim from the user's memory items.
 *   2. **Retrieved notes** — the top-K most semantically similar notes
 *      from the user's library, prefixed by title for citation tracking.
 *   3. **The question** — the user's literal query, last so the model's
 *      most recent attention is on what to answer.
 *
 * This file is pure orchestration — no UI, no service, no LiteRT-LM
 * calls. It produces a String + citations and is trivially unit-testable.
 *
 * ## Why the prompt structure looks like this
 *
 * The rules-first / context / question pattern is the standard RAG
 * prompt shape and small instruction-tuned models follow it well. The
 * "refuse if not in notes" rule is the safeguard against the LLM
 * inventing content not in the user's library — which would violate the
 * user's "no speculative claims" standing instruction.
 *
 * The JW-specific framing comes straight from the user's memory:
 *   - "primarily use the New World Translation"
 *   - "Respond as one of Jehovah's Witnesses"
 *   - "NEVER use the cross symbol — Jesus died on a torture stake"
 *   - "no speculation"
 */

/**
 * A single citation produced by the RAG pipeline. The chat UI renders
 * these as tappable chips that open the source note.
 */
data class RagCitation(
    val noteId: Long,
    val title: String,
    /** Cosine similarity score from BGE-large (higher = more relevant). */
    val score: Float,
    /** Short preview of the note content, ≤ 200 chars. */
    val snippet: String
)

/**
 * The complete output of the RAG pipeline. The `prompt` field goes to
 * [LlmManager.generate]; the `citations` field goes to the chat UI.
 */
data class RagPrompt(
    val prompt: String,
    val citations: List<RagCitation>,
    /** Empty when no notes scored above [RagPromptBuilder.MIN_SCORE]. */
    val isLibraryHit: Boolean
)

object RagPromptBuilder {

    /**
     * Cosine score below which a note is considered "not really relevant"
     * and excluded from the prompt. Tuned empirically — BGE-large scores
     * for genuinely related notes typically land 0.55+; below 0.40 is
     * usually drift. We err toward including borderline matches because
     * the LLM can recognise irrelevance and ignore them.
     */
    private const val MIN_SCORE = 0.35f

    /**
     * v5.4.141cc — REMOVED the old fixed `NOTE_EXCERPT_CHARS = 2000`
     * budget. It assumed a specific model's context window (a stale
     * comment said "Gemma 3 1B has a 4096-token context" — a model not
     * even in [com.tebogo.markvault.llm.ChatModelCatalog]) and a flat
     * 4 chars/token average, then multiplied that single per-note
     * figure by a hard-coded `topK = 6` to "prove" it fit. Two things
     * made that math wrong in practice:
     *
     *   1. Real JW/scriptural text — verse references ("1 Corinthians
     *      13:4-7"), capitalised proper nouns, transliterated Hebrew
     *      names — tokenizes denser than average English prose, so
     *      4 chars/token undercounts the true cost.
     *   2. The budget was never actually checked against the model
     *      that was really going to run generation. A field report hit
     *      exactly this: 6 notes at the old per-note cap produced a
     *      4644-token prompt against a 4096-token model limit —
     *      "Input token ids are too long" thrown by the native engine
     *      with no graceful fallback, killing the whole chat turn.
     *
     * Now the per-note character budget is DERIVED per call from the
     * caller-supplied [maxContextTokens] (the *actual* active chat
     * model's real limit) and the *actual* number of notes retrieved,
     * using a conservative (not average-case) chars/token ratio. On
     * top of that, [build] re-measures the fully assembled prompt
     * afterwards and drops the lowest-scoring notes one at a time
     * until it's confirmed to fit — a hard safety net that holds even
     * if the estimate above is still wrong for a given model's
     * tokenizer, rather than trusting the estimate alone and letting
     * the native call fail.
     */
    private const val CHARS_PER_TOKEN_ESTIMATE = 3.2

    /** Absolute ceiling on any single note's excerpt, regardless of how
     *  generous the per-call budget works out to be — keeps one giant
     *  note from crowding out every other citation. */
    private const val NOTE_EXCERPT_CHARS_CEILING = 3000

    /** Floor so a note excerpt is never trimmed down to nothing useful. */
    private const val NOTE_EXCERPT_CHARS_FLOOR = 400

    /** Tokens reserved for the model's generated answer plus a margin for
     *  BOS/EOS and any chat-template special tokens the engine adds that
     *  aren't visible in this plain prompt string. */
    private const val GENERATION_AND_MARGIN_TOKENS = 512

    /**
     * Fallback context window used only when a caller doesn't pass
     * [maxContextTokens] explicitly. Deliberately the SMALLER of the two
     * catalog models' context sizes (SmolLM2 135M = 2048) rather than
     * the larger (Gemma 4 E2B = 4096) — an unspecified budget should
     * degrade to the safer assumption, not the more permissive one.
     */
    private const val DEFAULT_MAX_CONTEXT_TOKENS = 2048

    /** How long the citation chip snippet shows. */
    private const val CITATION_SNIPPET_CHARS = 200

    /** Tokens reserved for the fixed structural text around the notes
     *  block ("NOTES PROVIDED:", "--- NOTE: ... ---" headers/separators,
     *  "QUESTION:"/"ANSWER:" labels) that isn't part of SYSTEM_RULES or
     *  the notes/question content themselves. */
    private const val STRUCTURE_OVERHEAD_TOKENS = 64

    /** Conservative token-count estimate for a string. Rounds UP so the
     *  estimate never under-reports (better to trim slightly more than
     *  to still overflow). */
    private fun estimateTokens(s: String): Int =
        kotlin.math.ceil(s.length / CHARS_PER_TOKEN_ESTIMATE).toInt()

    /**
     * The system rules block, prepended to every prompt. Verbatim
     * encoding of the user's standing instructions plus the
     * grounded-in-notes safety rail.
     */
    private val SYSTEM_RULES = """
You are an assistant helping the user — one of Jehovah's Witnesses — find and
synthesise information from their personal Bible-study notes library.

ABSOLUTE RULES (never violate):
1. Answer ONLY from the notes provided below. If the notes do not contain
   enough information to answer the question, say so honestly and stop. Do
   NOT invent facts, scriptures, or arguments not present in the notes.
2. When quoting or paraphrasing scripture, use the New World Translation
   (NWT) as the primary translation.
3. Speak as one of Jehovah's Witnesses, using the terminology of jw.org
   and wol.jw.org publications.
4. NEVER use the cross symbol or the word "cross" when referring to the
   instrument of Jesus' death. Jesus died on a torture stake.
5. Do not speculate about manuscript history, "lost originals", or
   anything not supported by the notes you were given.
6. At the end of your answer, cite which note titles each main claim came
   from, in the form: [Note title].

If multiple notes disagree, present both views and indicate the disagreement
rather than picking a side.

""".trimIndent()

    /**
     * Build a prompt for [userQuery] by retrieving up to [topK] relevant
     * notes from [dao] via [embedder] + the in-memory semantic search
     * function provided by the caller (typically
     * `AppViewModel::semanticSearch`).
     *
     * @param userQuery The user's literal question.
     * @param topK How many notes to pull from semantic search.
     * @param maxContextTokens The REAL context window of the model that
     *   will actually run generation (e.g. the active
     *   [com.tebogo.markvault.llm.ChatModelDescriptor.contextTokens]).
     *   The per-note excerpt budget below is derived from this, and the
     *   final assembled prompt is verified against it — so passing the
     *   wrong number is the one way this can still overflow. Defaults
     *   to the smaller of the two catalog models when the caller
     *   doesn't know better.
     * @param semanticSearch Function that takes a query and returns
     *   `(noteId, score)` pairs sorted descending by score. This is
     *   injected rather than imported directly so the prompt builder
     *   has no dependency on AppViewModel.
     * @param dao Room DAO for fetching note content by id.
     * @param embedder Currently unused here — left in the signature so
     *   future versions can optionally re-embed for HyDE-style retrieval.
     */
    suspend fun build(
        userQuery: String,
        topK: Int = 6,
        maxContextTokens: Int = DEFAULT_MAX_CONTEXT_TOKENS,
        semanticSearch: suspend (String, Int) -> List<Pair<Long, Float>>,
        dao: NoteDao,
        @Suppress("UNUSED_PARAMETER") embedder: Embedder
    ): RagPrompt {
        val trimmed = userQuery.trim()
        if (trimmed.isEmpty()) {
            return RagPrompt(
                prompt = "$SYSTEM_RULES\n\nThe user's question was empty.",
                citations = emptyList(),
                isLibraryHit = false
            )
        }

        // 1. Retrieve top-K from semantic search.
        val hits = semanticSearch(trimmed, topK)
            .filter { it.second >= MIN_SCORE }
            .take(topK)

        if (hits.isEmpty()) {
            // No good matches at all — produce a prompt that explicitly
            // tells the model the library doesn't cover this. The model
            // will then say so honestly (which is exactly what we want).
            val emptyPrompt = buildString {
                append(SYSTEM_RULES)
                append("\n\n")
                append("NOTES PROVIDED: (none — the user's library does not contain ")
                append("any notes relevant to this question)\n\n")
                append("QUESTION: ")
                append(trimmed)
                append("\n\nANSWER:")
            }
            return RagPrompt(
                prompt = emptyPrompt,
                citations = emptyList(),
                isLibraryHit = false
            )
        }

        // 2. Derive the per-note excerpt budget from the notes actually
        // retrieved and the real model context, instead of a fixed
        // constant sized for an assumed note count. Reserve tokens for
        // the system rules + question + structural text + generation
        // headroom first; whatever's left is split across hits.size
        // notes (not a hard-coded topK), each clamped to a sane
        // [floor, ceiling] so one note can't eat the whole budget and
        // a low budget doesn't zero every note out.
        val reservedTokens = estimateTokens(SYSTEM_RULES) +
            estimateTokens(trimmed) +
            STRUCTURE_OVERHEAD_TOKENS +
            GENERATION_AND_MARGIN_TOKENS
        val notesBudgetTokens = (maxContextTokens - reservedTokens)
            .coerceAtLeast(hits.size * NOTE_EXCERPT_CHARS_FLOOR / CHARS_PER_TOKEN_ESTIMATE.toInt())
        val perNoteBudgetChars = (notesBudgetTokens / hits.size * CHARS_PER_TOKEN_ESTIMATE)
            .toInt()
            .coerceIn(NOTE_EXCERPT_CHARS_FLOOR, NOTE_EXCERPT_CHARS_CEILING)

        // 3. Fetch note content from Room and assemble citation list,
        // highest-score first (semanticSearch already sorts descending,
        // so noteBlocks[i] pairs 1:1 with citations[i] in score order —
        // trimToBudget below relies on that ordering to drop the
        // weakest match first).
        val citations = mutableListOf<RagCitation>()
        val noteBlocks = mutableListOf<String>()
        for ((noteId, score) in hits) {
            val note: Note = dao.byId(noteId) ?: continue
            val excerpt = note.content
                .take(perNoteBudgetChars)
                .trim()
            val snippet = note.content
                .replace(Regex("\\s+"), " ")
                .trim()
                .take(CITATION_SNIPPET_CHARS)
            citations += RagCitation(
                noteId = noteId,
                title = note.title,
                score = score,
                snippet = snippet
            )
            noteBlocks += buildString {
                append("--- NOTE: ")
                append(note.title)
                append(" ---\n")
                append(excerpt)
                if (note.content.length > perNoteBudgetChars) {
                    append("\n[…note continues; truncated for context budget…]")
                }
            }
        }

        // 4. Assemble, then verify against the real budget. The per-note
        // estimate above assumes every note is roughly average-density
        // text; if the real tokenizer disagrees (or note titles/markup
        // push the structural overhead higher than estimated), this is
        // the hard safety net: drop the lowest-scoring note+citation
        // pair and re-measure, repeating until it fits or nothing is
        // left. This guarantees the prompt handed to the engine never
        // exceeds [maxContextTokens] regardless of estimation error —
        // the failure mode becomes "fewer citations" instead of a
        // thrown "input token ids are too long" error killing the turn.
        fun assemble(): String = buildString {
            append(SYSTEM_RULES)
            append("\n\n")
            append("NOTES PROVIDED:\n\n")
            append(noteBlocks.joinToString("\n\n"))
            append("\n\nQUESTION: ")
            append(trimmed)
            append("\n\nANSWER:")
        }
        var finalPrompt = assemble()
        val hardBudget = maxContextTokens - GENERATION_AND_MARGIN_TOKENS
        while (estimateTokens(finalPrompt) > hardBudget && noteBlocks.isNotEmpty()) {
            noteBlocks.removeAt(noteBlocks.size - 1)
            citations.removeAt(citations.size - 1)
            finalPrompt = assemble()
        }

        return RagPrompt(
            prompt = finalPrompt,
            citations = citations,
            isLibraryHit = citations.isNotEmpty()
        )
    }

    /**
     * v4.22.1 — Build a prompt that asks the model to summarise a specific
     * document. Bypasses semantic retrieval — the caller (typically a
     * reader screen's "Summarise" button) already knows which document
     * is in view.
     *
     * The same [SYSTEM_RULES] apply (NWT-first, no cross symbol, no
     * speculation, JW terminology). The question asks specifically for
     * a concise summary covering the main argument, key scriptures
     * cited, and notable conclusions.
     */
    fun buildSummarize(
        noteId: Long,
        title: String,
        content: String,
        maxContextTokens: Int = DEFAULT_MAX_CONTEXT_TOKENS
    ): RagPrompt {
        // Same reasoning as [build]: derive the excerpt budget from the
        // real model context instead of a fixed constant, and clamp to
        // the same [floor, ceiling] used there.
        val reservedTokens = estimateTokens(SYSTEM_RULES) +
            STRUCTURE_OVERHEAD_TOKENS + GENERATION_AND_MARGIN_TOKENS + 64
        val excerptBudgetChars = ((maxContextTokens - reservedTokens) * CHARS_PER_TOKEN_ESTIMATE)
            .toInt()
            .coerceIn(NOTE_EXCERPT_CHARS_FLOOR, NOTE_EXCERPT_CHARS_CEILING)
        val excerpt = content.take(excerptBudgetChars).trim()
        val truncated = content.length > excerptBudgetChars
        val snippet = content.replace(Regex("\\s+"), " ").trim().take(CITATION_SNIPPET_CHARS)
        val prompt = buildString {
            append(SYSTEM_RULES)
            append("\n\n")
            append("NOTES PROVIDED:\n\n")
            append("--- NOTE: ").append(title).append(" ---\n")
            append(excerpt)
            if (truncated) {
                append("\n[…note continues; truncated for context budget…]")
            }
            append("\n\nQUESTION: Please summarise the note above concisely. ")
            append("Cover the main argument or topic, key scriptures cited, ")
            append("and any notable conclusions. Be brief — 4 to 8 sentences.")
            append("\n\nANSWER:")
        }
        // Hard safety net, same guarantee as [build]: if the estimate
        // above still overshoots the real tokenizer for this note's
        // content, chop the prompt down to the byte budget rather than
        // handing the engine something it will reject outright. A
        // shortened summary source beats a thrown error killing the
        // whole "Summarise" action.
        val hardBudgetChars =
            ((maxContextTokens - GENERATION_AND_MARGIN_TOKENS) * CHARS_PER_TOKEN_ESTIMATE).toInt()
        val safePrompt = if (prompt.length > hardBudgetChars) {
            prompt.take(hardBudgetChars) + "\n\nANSWER:"
        } else prompt
        return RagPrompt(
            prompt = safePrompt,
            citations = listOf(RagCitation(noteId, title, 1.0f, snippet)),
            isLibraryHit = true
        )
    }
}
