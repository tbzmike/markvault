package com.tebogo.markvault.ai

enum class T5ExpansionPreference { BUILTIN, T5_BASE }

object T5ExpansionPreferenceStore {
    private var current = T5ExpansionPreference.BUILTIN
    fun set(value: T5ExpansionPreference) { current = value }
    fun get(): T5ExpansionPreference = current
}
