package com.tebogo.markvault.ai

data class LocalModelInfo(
    val name: String,
    val size: String,
    val installed: Boolean
)

object ModelCatalog {
    private val models = mutableListOf(
        LocalModelInfo("Gemma 3", "Installed model", true),
        LocalModelInfo("Qwen", "Installed model", true),
        LocalModelInfo("SmolLM2 360M", "360M lightweight model", false)
    )

    fun models(): List<LocalModelInfo> = models

    fun markInstalled(name: String) {
        val index = models.indexOfFirst { it.name == name }
        if (index >= 0) {
            models[index] = models[index].copy(installed = true)
        }
    }
}
