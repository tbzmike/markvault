package com.tebogo.markvault.ai

object T5SearchTraceRecorder {
    private var lastTrace: T5SearchRuntimeTrace? = null

    fun record(trace: T5SearchRuntimeTrace) {
        lastTrace = trace
    }

    fun latest(): T5SearchRuntimeTrace? = lastTrace
}
