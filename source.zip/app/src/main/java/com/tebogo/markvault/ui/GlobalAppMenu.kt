package com.tebogo.markvault.ui

import androidx.compose.foundation.layout.Box
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.MoreVert
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.navigation.NavController

/**
 * Global "…" overflow menu — drops at minimum a Settings link, a PDF history
 * link, and a Home shortcut into every top bar. Screens add it to their
 * `actions = { … }` block to keep Settings reachable from anywhere.
 *
 * Usage:
 *   actions = {
 *     IconButton(...) { ... }     // screen-specific actions
 *     GlobalAppMenu(nav)          // always last in the actions row
 *   }
 */
@Composable
fun GlobalAppMenu(nav: NavController) {
    var open by remember { mutableStateOf(false) }
    Box {
        IconButton(onClick = { open = true }) {
            Icon(Icons.Default.MoreVert, contentDescription = "More options")
        }
        DropdownMenu(expanded = open, onDismissRequest = { open = false }) {
            DropdownMenuItem(
                text = { Text("\u2699\uFE0F Settings") },
                onClick = { open = false; nav.navigate("settings") }
            )
            DropdownMenuItem(
                text = { Text("\uD83D\uDCDC PDF history") },
                onClick = { open = false; nav.navigate("pdfHistory") }
            )
            HorizontalDivider()
            DropdownMenuItem(
                text = { Text("\uD83C\uDFE0 Home") },
                onClick = {
                    open = false
                    nav.navigate("home") {
                        popUpTo("home") { inclusive = false }
                        launchSingleTop = true
                    }
                }
            )
        }
    }
}
