package com.tebogo.markvault.ui

import androidx.compose.foundation.layout.Box
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.MoreVert
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.navigation.NavController
import com.tebogo.markvault.AppViewModel

/** Always-visible 🏠 icon. Use standalone on screens that have their own dropdown. */
@Composable
fun HomeButton(nav: NavController) {
    IconButton(onClick = {
        nav.navigate("home") {
            popUpTo("home") { inclusive = false }
            launchSingleTop = true
        }
    }) {
        Icon(Icons.Default.Home, contentDescription = "Home")
    }
}

/** The "⋮" overflow with: Search, Themes, PDF history, Web history, Settings. */
@Composable
fun OverflowMenu(nav: NavController, vm: AppViewModel? = null) {
    var open by remember { mutableStateOf(false) }
    var themePicker by remember { mutableStateOf(false) }
    Box {
        IconButton(onClick = { open = true }) {
            Icon(Icons.Default.MoreVert, contentDescription = "More options")
        }
        DropdownMenu(expanded = open, onDismissRequest = { open = false }) {
            DropdownMenuItem(
                text = { Text("\uD83D\uDD0D Search library") },
                onClick = { open = false; nav.navigate("search") }
            )
            if (vm != null) {
                DropdownMenuItem(
                    text = { Text("\uD83C\uDFA8 Themes") },
                    onClick = { open = false; themePicker = true }
                )
            }
            HorizontalDivider()
            DropdownMenuItem(
                text = { Text("\uD83D\uDCDC PDF history") },
                onClick = { open = false; nav.navigate("pdfHistory") }
            )
            DropdownMenuItem(
                text = { Text("\uD83D\uDD52 Web history") },
                onClick = { open = false; nav.navigate("webHistory") }
            )
            HorizontalDivider()
            DropdownMenuItem(
                text = { Text("\u2699\uFE0F Settings") },
                onClick = { open = false; nav.navigate("settings") }
            )
        }
    }
    if (themePicker && vm != null) {
        ThemePickerDialog(vm, onDismiss = { themePicker = false })
    }
}

/** Both icons in one drop-in component. */
@Composable
fun GlobalAppMenu(nav: NavController, vm: AppViewModel? = null) {
    HomeButton(nav)
    OverflowMenu(nav, vm)
}


