package com.tebogo.markvault.ui

import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.size
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.MoreVert
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.navigation.NavController

/**
 * Two-icon top-bar block to drop into every screen's `actions = { ... }`:
 *   1. 🏠 Home — always visible, one tap home
 *   2. … overflow — Settings, PDF history, Web history, Search, Home
 *
 * Usage in a TopAppBar:
 *   actions = {
 *     IconButton(...) { ... }     // screen-specific actions
 *     GlobalAppMenu(nav)          // always last in the actions row
 *   }
 */
@Composable
fun GlobalAppMenu(nav: NavController) {
    var open by remember { mutableStateOf(false) }
    // Always-visible Home button so the user never has to walk the back stack
    IconButton(onClick = {
        nav.navigate("home") {
            popUpTo("home") { inclusive = false }
            launchSingleTop = true
        }
    }) {
        Icon(Icons.Default.Home, contentDescription = "Home")
    }
    Box {
        IconButton(onClick = { open = true }) {
            Icon(Icons.Default.MoreVert, contentDescription = "More options")
        }
        DropdownMenu(expanded = open, onDismissRequest = { open = false }) {
            DropdownMenuItem(
                text = { Text("\uD83D\uDD0D Search library") },
                onClick = { open = false; nav.navigate("search") }
            )
            HorizontalDivider()
            DropdownMenuItem(
                text = { Text("\uD83D\uDCDC PDF history") },
                onClick = { open = false; nav.navigate("pdfHistory") }
            )
            DropdownMenuItem(
                text = { Text("\uD83D\uDD52 Web history") },
                onClick = { open = false; nav.navigate("webHistory") }
            )
            HorizontalDivider()
            DropdownMenuItem(
                text = { Text("\u2699\uFE0F Settings") },
                onClick = { open = false; nav.navigate("settings") }
            )
        }
    }
}

