package com.tebogo.markvault.ui

import androidx.compose.foundation.layout.Box
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.MoreVert
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.navigation.NavController
import com.tebogo.markvault.AppViewModel

/** Always-visible 🏠 icon. Use standalone on screens that have their own dropdown. */
@Composable
fun HomeButton(nav: NavController) {
    // v5.4.145cc — Increased button size from 40.dp (default) to 56.dp
    // for easier pressing on mobile. Icon itself is 28.dp (was 24.dp).
    IconButton(
        onClick = {
            nav.navigate("home") {
                popUpTo("home") { inclusive = false }
                launchSingleTop = true
            }
        },
        modifier = Modifier.size(56.dp)
    ) {
        Icon(
            Icons.Default.Home,
            contentDescription = "Home",
            modifier = Modifier.size(28.dp)
        )
    }
}

/**
 * The "⋮" overflow menu — comprehensive 16-item menu that is identical on
 * EVERY screen so the user doesn't have to remember "which screen has X". You
 * said this very clearly: "It must have all 16, even in pdf".
 *
 * Sections (separated by dividers):
 *   • Library navigation (Search, Browse, Topics, Graph)
 *   • Web (browser, bookmarks, web history)
 *   • History & sync (PDF history, library sync, search history)
 *   • Personalisation (Themes)
 *   • System (Settings, About)
 *   • Reader actions (Open externally, Share)
 *   • Browser actions (Save offline, Convert to MD)  -- shown but disabled when
 *     not applicable in current context
 */
@Composable
fun OverflowMenu(nav: NavController, vm: AppViewModel? = null) {
    var open by remember { mutableStateOf(false) }
    var themePicker by remember { mutableStateOf(false) }
    var fontScaleDialog by remember { mutableStateOf(false) }
    Box {
        IconButton(onClick = { open = true }) {
            Icon(Icons.Default.MoreVert, contentDescription = "More options")
        }
        DropdownMenu(expanded = open, onDismissRequest = { open = false }) {
            // ── Library navigation ──────────────────────────────────────────
            DropdownMenuItem(
                text = { Text("\uD83D\uDD0D  Search library") },
                onClick = { open = false; nav.navigate("search") }
            )
            DropdownMenuItem(
                text = { Text("\uD83D\uDCAC  Chat with library") },
                onClick = { open = false; nav.navigate("chat") }
            )
            DropdownMenuItem(
                text = { Text("\uD83C\uDFE0  Home") },
                onClick = {
                    open = false
                    nav.navigate("home") {
                        popUpTo("home") { inclusive = false }
                        launchSingleTop = true
                    }
                }
            )
            DropdownMenuItem(
                text = { Text("\uD83D\uDCC2  Browse files") },
                onClick = { open = false; nav.navigate("browse") }
            )
            DropdownMenuItem(
                text = { Text("\uD83D\uDD78\uFE0F  Graph view") },
                onClick = { open = false; nav.navigate("graph") }
            )

            HorizontalDivider()
            // ── Web ─────────────────────────────────────────────────────────
            DropdownMenuItem(
                text = { Text("\uD83C\uDF10  jw.org browser") },
                onClick = {
                    open = false
                    val encUrl = java.net.URLEncoder.encode("https://www.jw.org", "UTF-8")
                    val encLabel = java.net.URLEncoder.encode("jw.org", "UTF-8")
                    nav.navigate("web/$encUrl/$encLabel") { launchSingleTop = true }
                }
            )
            DropdownMenuItem(
                text = { Text("\u2B50  Web bookmarks") },
                onClick = { open = false; nav.navigate("webBookmarks") }
            )
            DropdownMenuItem(
                text = { Text("\uD83D\uDD52  Web history") },
                onClick = { open = false; nav.navigate("webHistory") }
            )

            HorizontalDivider()
            // ── History & sync ──────────────────────────────────────────────
            DropdownMenuItem(
                text = { Text("\uD83D\uDCDC  PDF history") },
                onClick = { open = false; nav.navigate("pdfHistory") }
            )
            // v5.4.101cc — Activity log promoted from WebViewer-only to
            // the global overflow menu. Same route ("activity_log")
            // used by WebSearchScreen and Settings, just now reachable
            // from every screen's bottom-bar overflow so backfill /
            // batch-save / index-sync entries can be inspected without
            // navigating into the WebViewer first.
            DropdownMenuItem(
                text = { Text("\uD83D\uDCCB  Activity log") },
                onClick = { open = false; nav.navigate("activity_log") }
            )
            // v5.4.110cc — Batch save dashboard. Available from any
            // screen so the user can peek at the live save even after
            // navigating away from the WebViewer. The dashboard itself
            // handles the "no batch in progress" empty state so we
            // don't need to gate this menu entry.
            DropdownMenuItem(
                text = { Text("\uD83D\uDCCA  Batch save dashboard") },
                onClick = { open = false; nav.navigate("batch_dashboard") }
            )
            DropdownMenuItem(
                text = { Text("\uD83D\uDD04  Re-sync library") },
                onClick = {
                    open = false
                    vm?.reindex()
                }
            )

            HorizontalDivider()
            // ── Personalisation ─────────────────────────────────────────────
            if (vm != null) {
                DropdownMenuItem(
                    text = { Text("\uD83C\uDFA8  Themes") },
                    onClick = { open = false; themePicker = true }
                )
                // v4.16.0 — Global text size dialog. Same Prefs.fontScale
                // value the Settings screen edits, but reachable from the
                // toolbar overflow on every screen.
                DropdownMenuItem(
                    text = { Text("\uD83D\uDD20  Text size") },
                    onClick = { open = false; fontScaleDialog = true }
                )
            }

            HorizontalDivider()
            // ── System ──────────────────────────────────────────────────────
            DropdownMenuItem(
                text = { Text("\u2699\uFE0F  Settings") },
                onClick = { open = false; nav.navigate("settings") }
            )
            DropdownMenuItem(
                text = { Text("\u2139\uFE0F  About") },
                onClick = { open = false; nav.navigate("settings") }
            )
        }
    }
    if (themePicker && vm != null) {
        ThemePickerDialog(vm, onDismiss = { themePicker = false })
    }
    if (fontScaleDialog && vm != null) {
        FontScaleDialog(vm, onDismiss = { fontScaleDialog = false })
    }
}

/** Both icons in one drop-in component. */
@Composable
fun GlobalAppMenu(nav: NavController, vm: AppViewModel? = null) {
    HomeButton(nav)
    OverflowMenu(nav, vm)
}
