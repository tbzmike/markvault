package com.tebogo.markvault.search

import android.content.Context
import android.util.AtomicFile
import com.tebogo.markvault.data.SearchHit
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.util.UUID

/**
 * Persists completed search result sets so a completed background search survives process death
 * and can be restored without re-running the expensive semantic/reranker pipeline.
 *
 * v5.5.11 — Durable retention is AGE-based only: every valid session is kept for up to six months.
 * UI/recent-search limits must never delete calendar history from disk.
 */
data class SavedSearchSession(
    val id: String,
    val query: String,
    val metadataVersion: Int = 2,
    val createdAt: Long,
    val durationMs: Long,
    val scope: String,
    val dualMode: Boolean,
    val rerankEnabled: Boolean,
    val searchType: String = "Deep",
    val llmUsed: Boolean = false,
    val llmEngine: String = "",
    // v5.5.14 — Complete execution metadata. Defaults preserve every pre-5.5.14 JSON session.
    val stopped: Boolean = false,
    val stoppedPercent: Int? = null,
    val semanticEnabled: Boolean = false,
    val accurateSearch: Boolean = false,
    val annEnabled: Boolean = false,
    val rerankUsed: Boolean = false,
    val scopeLabel: String = "",
    val expansions: List<String> = emptyList(),
    val hitScopes: Map<Long, String> = emptyMap(),
    val hits: List<SearchHit>
)

/** v5.5.2 — Lightweight metadata for calendar rendering without decoding full hit payloads. */
data class SessionMeta(
    val id: String,
    val query: String,
    val createdAt: Long,
    val hitCount: Int,
    val searchType: String = "Deep",
    val durationMs: Long = 0
)

object SavedSearchStore {
    private const val DIR_NAME = "saved_search_results"

    private fun dir(context: Context): File =
        File(context.filesDir, DIR_NAME).apply { mkdirs() }

    suspend fun save(
        context: Context,
        query: String,
        durationMs: Long,
        scope: String,
        dualMode: Boolean,
        rerankEnabled: Boolean,
        searchType: String,
        llmUsed: Boolean,
        llmEngine: String,
        stopped: Boolean = false,
        stoppedPercent: Int? = null,
        semanticEnabled: Boolean = false,
        accurateSearch: Boolean = false,
        annEnabled: Boolean = false,
        rerankUsed: Boolean = false,
        scopeLabel: String = "",
        expansions: List<String>,
        hitScopes: Map<Long, String>,
        hits: List<SearchHit>
    ): SavedSearchSession = withContext(Dispatchers.IO) {
        val now = System.currentTimeMillis()
        val session = SavedSearchSession(
            id = "${now}_${UUID.randomUUID().toString().take(8)}",
            query = query.trim(),
            metadataVersion = 2,
            createdAt = now,
            durationMs = durationMs.coerceAtLeast(0L),
            scope = scope,
            dualMode = dualMode,
            rerankEnabled = rerankEnabled,
            searchType = searchType,
            llmUsed = llmUsed,
            llmEngine = llmEngine,
            stopped = stopped,
            stoppedPercent = stoppedPercent?.coerceIn(0, 100),
            semanticEnabled = semanticEnabled,
            accurateSearch = accurateSearch,
            annEnabled = annEnabled,
            rerankUsed = rerankUsed,
            scopeLabel = scopeLabel,
            expansions = expansions.toList(),
            hitScopes = hitScopes.toMap(),
            hits = hits.toList()
        )
        writeSession(context, session)
        // v5.5.11 — A completed search must not evict a newer-than-six-month
        // session merely because a UI list limit was reached.
        purgeOlderThan6Months(context)
        session
    }

    suspend fun list(context: Context, maxSessions: Int = 50): List<SavedSearchSession> = withContext(Dispatchers.IO) {
        purgeOlderThan6Months(context)
        sessionFilesNewestFirst(context)
            // This is only an in-memory/recent-navigation window. It never deletes files.
            .take(maxSessions.coerceIn(1, 50))
            .mapNotNull { file -> runCatching { decode(file.readText(Charsets.UTF_8)) }.getOrNull() }
    }

    /**
     * v5.5.2 — Load ALL sessions within the 6-month retention window.
     * Used by the calendar/list view in SavedSearchesScreen.
     */
    suspend fun listAll(context: Context): List<SavedSearchSession> = withContext(Dispatchers.IO) {
        purgeOlderThan6Months(context)
        sessionFilesNewestFirst(context)
            .mapNotNull { file -> runCatching { decode(file.readText(Charsets.UTF_8)) }.getOrNull() }
    }

    /**
     * v5.5.2 — Lightweight metadata-only listing for calendar rendering.
     * Returns (id, query, createdAt, hitCount) without decoding full hit
     * payloads, so it's fast even for hundreds of sessions.
     */
    suspend fun listMeta(context: Context): List<SessionMeta> = withContext(Dispatchers.IO) {
        purgeOlderThan6Months(context)
        sessionFilesNewestFirst(context).mapNotNull { file ->
            runCatching {
                val root = JSONObject(file.readText(Charsets.UTF_8))
                SessionMeta(
                    id = root.getString("id"),
                    query = root.optString("query"),
                    createdAt = root.optLong("createdAt"),
                    hitCount = root.optJSONArray("hits")?.length() ?: 0,
                    searchType = root.optString("searchType", "Deep"),
                    durationMs = root.optLong("durationMs")
                )
            }.getOrNull()
        }
    }

    /** v5.5.2 — Auto-delete saved searches older than 6 months. */
    private fun purgeOlderThan6Months(context: Context) {
        val sixMonthsAgo = System.currentTimeMillis() - (180L * 24 * 60 * 60 * 1000)
        dir(context).listFiles { f -> f.isFile && f.extension == "json" }?.forEach { file ->
            val ts = file.nameWithoutExtension.substringBefore('_').toLongOrNull()
            if (ts != null && ts < sixMonthsAgo) runCatching { file.delete() }
        }
    }

    suspend fun load(context: Context, id: String): SavedSearchSession? = withContext(Dispatchers.IO) {
        if (id.isBlank()) return@withContext null
        val file = File(dir(context), "$id.json")
        if (!file.isFile) return@withContext null
        runCatching { decode(file.readText(Charsets.UTF_8)) }.getOrNull()
    }

    suspend fun delete(context: Context, id: String) = withContext(Dispatchers.IO) {
        if (id.isNotBlank()) File(dir(context), "$id.json").delete()
    }

    private fun writeSession(context: Context, session: SavedSearchSession) {
        val atomic = AtomicFile(File(dir(context), "${session.id}.json"))
        val bytes = encode(session).toByteArray(Charsets.UTF_8)
        val out = atomic.startWrite()
        try {
            out.write(bytes)
            out.flush()
            atomic.finishWrite(out)
        } catch (t: Throwable) {
            atomic.failWrite(out)
            throw t
        }
    }

    /**
     * v5.5.11 — Kept for source compatibility with older callers. A UI count limit must never
     * delete durable calendar history, so this now enforces only the six-month retention policy.
     */
    @Suppress("UNUSED_PARAMETER")
    suspend fun enforceLimit(context: Context, maxSessions: Int) = withContext(Dispatchers.IO) {
        // The recent-list window is applied by [list]; durable storage is age-based only.
        purgeOlderThan6Months(context)
    }

    private fun sessionFilesNewestFirst(context: Context): List<File> =
        dir(context).listFiles { f -> f.isFile && f.extension == "json" }
            ?.sortedWith(
                compareByDescending<File> {
                    it.nameWithoutExtension.substringBefore('_').toLongOrNull()
                        ?: it.lastModified()
                }.thenByDescending { it.lastModified() }
            )
            ?: emptyList()

    private fun encode(session: SavedSearchSession): String {
        val root = JSONObject()
            .put("version", 2)
            .put("id", session.id)
            .put("query", session.query)
            .put("createdAt", session.createdAt)
            .put("durationMs", session.durationMs)
            .put("scope", session.scope)
            .put("dualMode", session.dualMode)
            .put("rerankEnabled", session.rerankEnabled)
            .put("searchType", session.searchType)
            .put("llmUsed", session.llmUsed)
            .put("llmEngine", session.llmEngine)
            .put("stopped", session.stopped)
            .apply { if (session.stoppedPercent != null) put("stoppedPercent", session.stoppedPercent) }
            .put("semanticEnabled", session.semanticEnabled)
            .put("accurateSearch", session.accurateSearch)
            .put("annEnabled", session.annEnabled)
            .put("rerankUsed", session.rerankUsed)
            .put("scopeLabel", session.scopeLabel)
            .put("expansions", JSONArray(session.expansions))
        val hits = JSONArray()
        session.hits.forEach { hit ->
            hits.put(
                JSONObject()
                    .put("id", hit.id)
                    .put("relPath", hit.relPath)
                    .put("title", hit.title)
                    .put("snippet", hit.snippet)
                    .put("fileType", hit.fileType)
                    .put("scope", session.hitScopes[hit.id] ?: "")
                    .apply {
                        if (hit.score != null) put("score", hit.score.toDouble())
                        else put("score", JSONObject.NULL)
                    }
            )
        }
        root.put("hits", hits)
        return root.toString()
    }

    private fun decode(raw: String): SavedSearchSession {
        val root = JSONObject(raw)
        val arr = root.optJSONArray("hits") ?: JSONArray()
        val hits = ArrayList<SearchHit>(arr.length())
        val hitScopes = LinkedHashMap<Long, String>()
        for (i in 0 until arr.length()) {
            val item = arr.getJSONObject(i)
            val hitId = item.getLong("id")
            item.optString("scope").takeIf { it.isNotBlank() }?.let { hitScopes[hitId] = it }
            hits += SearchHit(
                id = hitId,
                relPath = item.optString("relPath"),
                title = item.optString("title"),
                snippet = item.optString("snippet"),
                fileType = item.optString("fileType", "md"),
                score = if (item.isNull("score")) null else item.optDouble("score").toFloat()
            )
        }
        return SavedSearchSession(
            id = root.getString("id"),
            query = root.optString("query"),
            metadataVersion = root.optInt("version", 1),
            createdAt = root.optLong("createdAt"),
            durationMs = root.optLong("durationMs"),
            scope = root.optString("scope", "all"),
            dualMode = root.optBoolean("dualMode", false),
            rerankEnabled = root.optBoolean("rerankEnabled", false),
            searchType = root.optString("searchType", "Deep"),
            llmUsed = root.optBoolean("llmUsed", false),
            llmEngine = root.optString("llmEngine", ""),
            stopped = root.optBoolean("stopped", false),
            stoppedPercent = if (root.has("stoppedPercent") && !root.isNull("stoppedPercent")) root.optInt("stoppedPercent").coerceIn(0, 100) else null,
            semanticEnabled = root.optBoolean("semanticEnabled", false),
            accurateSearch = root.optBoolean("accurateSearch", false),
            annEnabled = root.optBoolean("annEnabled", false),
            rerankUsed = root.optBoolean("rerankUsed", root.optBoolean("rerankEnabled", false)),
            scopeLabel = root.optString("scopeLabel", ""),
            expansions = root.optJSONArray("expansions")?.let { a -> List(a.length()) { i -> a.optString(i) }.filter { it.isNotBlank() } } ?: emptyList(),
            hitScopes = hitScopes,
            hits = hits
        )
    }
}
