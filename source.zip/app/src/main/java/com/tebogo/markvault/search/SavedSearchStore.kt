package com.tebogo.markvault.search

import android.content.Context
import android.util.AtomicFile
import com.tebogo.markvault.data.SearchHit
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.util.UUID

/**
 * Persists completed search result sets so a completed background search survives process death
 * and can be restored without re-running the expensive semantic/reranker pipeline.
 *
 * v5.5.11 — Durable retention is AGE-based only: every valid session is kept for up to six months.
 * UI/recent-search limits must never delete calendar history from disk.
 */
data class SavedSearchSession(
    val id: String,
    val query: String,
    val createdAt: Long,
    val durationMs: Long,
    val scope: String,
    val dualMode: Boolean,
    val rerankEnabled: Boolean,
    val searchType: String = "Deep",
    val llmUsed: Boolean = false,
    val llmEngine: String = "",
    val expansions: List<String> = emptyList(),
    val hitScopes: Map<Long, String> = emptyMap(),
    // v5.5.14 — execution metadata is persisted with every submitted search.
    // Defaults keep every v1 saved-search JSON file fully backward compatible.
    val metadataVersion: Int = 1,
    val stopped: Boolean = false,
    val stoppedAtPercent: Int? = null,
    val stoppedAtDone: Int = 0,
    val stoppedAtTotal: Int = 0,
    val semanticEnabled: Boolean = false,
    val accurateSearchUsed: Boolean = false,
    val annEnabled: Boolean = false,
    val annUsed: Boolean = false,
    val rerankApplied: Boolean = false,
    val rerankerEngine: String = "",
    val scopeNoteCount: Int = 0,
    val totalNoteCount: Int = 0,
    // v5.5.14 — Question Awareness audit metadata. Kept separate from generic
    // expansions so saved results can state whether a question was detected and
    // whether answer-oriented retrieval actually affected the search.
    val questionAwarenessEnabled: Boolean = false,
    val queryDetectedAsQuestion: Boolean = false,
    val questionAwarenessUsed: Boolean = false,
    val questionType: String = "",
    val questionAwareQueries: List<String> = emptyList(),
    val hits: List<SearchHit>
)

/** v5.5.2 — Lightweight metadata for calendar rendering without decoding full hit payloads. */
data class SessionMeta(
    val id: String,
    val query: String,
    val createdAt: Long,
    val hitCount: Int,
    val searchType: String = "Deep",
    val durationMs: Long = 0
)

object SavedSearchStore {
    private const val DIR_NAME = "saved_search_results"

    private fun dir(context: Context): File =
        File(context.filesDir, DIR_NAME).apply { mkdirs() }

    suspend fun save(
        context: Context,
        query: String,
        durationMs: Long,
        scope: String,
        dualMode: Boolean,
        rerankEnabled: Boolean,
        searchType: String,
        llmUsed: Boolean,
        llmEngine: String,
        expansions: List<String>,
        hitScopes: Map<Long, String>,
        stopped: Boolean = false,
        stoppedAtPercent: Int? = null,
        stoppedAtDone: Int = 0,
        stoppedAtTotal: Int = 0,
        semanticEnabled: Boolean = false,
        accurateSearchUsed: Boolean = false,
        annEnabled: Boolean = false,
        annUsed: Boolean = false,
        rerankApplied: Boolean = false,
        rerankerEngine: String = "",
        scopeNoteCount: Int = 0,
        totalNoteCount: Int = 0,
        questionAwarenessEnabled: Boolean = false,
        queryDetectedAsQuestion: Boolean = false,
        questionAwarenessUsed: Boolean = false,
        questionType: String = "",
        questionAwareQueries: List<String> = emptyList(),
        hits: List<SearchHit>
    ): SavedSearchSession = withContext(Dispatchers.IO) {
        val now = System.currentTimeMillis()
        // v5.5.16 — Persist Question Awareness as "used" only when all
        // execution evidence agrees: the toggle was enabled, the query really
        // was detected as a question, and answer-oriented queries were actually
        // produced for retrieval. This keeps saved-search reporting/watermarks
        // truthful even if an upstream caller supplies inconsistent booleans.
        val persistedQuestionQueries = questionAwareQueries
            .map { it.trim() }
            .filter { it.isNotBlank() }
            .distinct()
        val persistedQuestionUsed = questionAwarenessEnabled &&
            queryDetectedAsQuestion && questionAwarenessUsed &&
            persistedQuestionQueries.isNotEmpty()
        val session = SavedSearchSession(
            id = "${now}_${UUID.randomUUID().toString().take(8)}",
            query = query.trim(),
            createdAt = now,
            durationMs = durationMs.coerceAtLeast(0L),
            scope = scope,
            dualMode = dualMode,
            rerankEnabled = rerankEnabled,
            searchType = searchType,
            llmUsed = llmUsed,
            llmEngine = llmEngine,
            expansions = expansions.toList(),
            hitScopes = hitScopes.toMap(),
            metadataVersion = 3,
            stopped = stopped,
            stoppedAtPercent = stoppedAtPercent?.coerceIn(0, 100),
            stoppedAtDone = stoppedAtDone.coerceAtLeast(0),
            stoppedAtTotal = stoppedAtTotal.coerceAtLeast(0),
            semanticEnabled = semanticEnabled,
            accurateSearchUsed = accurateSearchUsed,
            annEnabled = annEnabled,
            annUsed = annUsed,
            rerankApplied = rerankApplied,
            rerankerEngine = rerankerEngine,
            scopeNoteCount = scopeNoteCount.coerceAtLeast(0),
            totalNoteCount = totalNoteCount.coerceAtLeast(0),
            questionAwarenessEnabled = questionAwarenessEnabled,
            queryDetectedAsQuestion = queryDetectedAsQuestion,
            questionAwarenessUsed = persistedQuestionUsed,
            questionType = if (queryDetectedAsQuestion) questionType.trim() else "",
            questionAwareQueries = if (persistedQuestionUsed) persistedQuestionQueries else emptyList(),
            hits = hits.toList()
        )
        writeSession(context, session)
        // v5.5.11 — A completed search must not evict a newer-than-six-month
        // session merely because a UI list limit was reached.
        purgeOlderThan6Months(context)
        session
    }

    suspend fun list(context: Context, maxSessions: Int = 50): List<SavedSearchSession> = withContext(Dispatchers.IO) {
        purgeOlderThan6Months(context)
        sessionFilesNewestFirst(context)
            // This is only an in-memory/recent-navigation window. It never deletes files.
            .take(maxSessions.coerceIn(1, 50))
            .mapNotNull { file -> runCatching { decode(file.readText(Charsets.UTF_8)) }.getOrNull() }
    }

    /**
     * v5.5.2 — Load ALL sessions within the 6-month retention window.
     * Used by the calendar/list view in SavedSearchesScreen.
     */
    suspend fun listAll(context: Context): List<SavedSearchSession> = withContext(Dispatchers.IO) {
        purgeOlderThan6Months(context)
        sessionFilesNewestFirst(context)
            .mapNotNull { file -> runCatching { decode(file.readText(Charsets.UTF_8)) }.getOrNull() }
    }

    /**
     * v5.5.2 — Lightweight metadata-only listing for calendar rendering.
     * Returns (id, query, createdAt, hitCount) without decoding full hit
     * payloads, so it's fast even for hundreds of sessions.
     */
    suspend fun listMeta(context: Context): List<SessionMeta> = withContext(Dispatchers.IO) {
        purgeOlderThan6Months(context)
        sessionFilesNewestFirst(context).mapNotNull { file ->
            runCatching {
                val root = JSONObject(file.readText(Charsets.UTF_8))
                SessionMeta(
                    id = root.getString("id"),
                    query = root.optString("query"),
                    createdAt = root.optLong("createdAt"),
                    hitCount = root.optJSONArray("hits")?.length() ?: 0,
                    searchType = root.optString("searchType", "Deep"),
                    durationMs = root.optLong("durationMs")
                )
            }.getOrNull()
        }
    }

    /** v5.5.2 — Auto-delete saved searches older than 6 months. */
    private fun purgeOlderThan6Months(context: Context) {
        val sixMonthsAgo = System.currentTimeMillis() - (180L * 24 * 60 * 60 * 1000)
        dir(context).listFiles { f -> f.isFile && f.extension == "json" }?.forEach { file ->
            val ts = file.nameWithoutExtension.substringBefore('_').toLongOrNull()
            if (ts != null && ts < sixMonthsAgo) runCatching { file.delete() }
        }
    }

    suspend fun load(context: Context, id: String): SavedSearchSession? = withContext(Dispatchers.IO) {
        if (id.isBlank()) return@withContext null
        val file = File(dir(context), "$id.json")
        if (!file.isFile) return@withContext null
        runCatching { decode(file.readText(Charsets.UTF_8)) }.getOrNull()
    }

    suspend fun delete(context: Context, id: String) = withContext(Dispatchers.IO) {
        if (id.isNotBlank()) File(dir(context), "$id.json").delete()
    }

    private fun writeSession(context: Context, session: SavedSearchSession) {
        val atomic = AtomicFile(File(dir(context), "${session.id}.json"))
        val bytes = encode(session).toByteArray(Charsets.UTF_8)
        val out = atomic.startWrite()
        try {
            out.write(bytes)
            out.flush()
            atomic.finishWrite(out)
        } catch (t: Throwable) {
            atomic.failWrite(out)
            throw t
        }
    }

    /**
     * v5.5.11 — Kept for source compatibility with older callers. A UI count limit must never
     * delete durable calendar history, so this now enforces only the six-month retention policy.
     */
    @Suppress("UNUSED_PARAMETER")
    suspend fun enforceLimit(context: Context, maxSessions: Int) = withContext(Dispatchers.IO) {
        // The recent-list window is applied by [list]; durable storage is age-based only.
        purgeOlderThan6Months(context)
    }

    private fun sessionFilesNewestFirst(context: Context): List<File> =
        dir(context).listFiles { f -> f.isFile && f.extension == "json" }
            ?.sortedWith(
                compareByDescending<File> {
                    it.nameWithoutExtension.substringBefore('_').toLongOrNull()
                        ?: it.lastModified()
                }.thenByDescending { it.lastModified() }
            )
            ?: emptyList()

    private fun encode(session: SavedSearchSession): String {
        val root = JSONObject()
            .put("version", 3)
            .put("id", session.id)
            .put("query", session.query)
            .put("createdAt", session.createdAt)
            .put("durationMs", session.durationMs)
            .put("scope", session.scope)
            .put("dualMode", session.dualMode)
            .put("rerankEnabled", session.rerankEnabled)
            .put("searchType", session.searchType)
            .put("llmUsed", session.llmUsed)
            .put("llmEngine", session.llmEngine)
            .put("expansions", JSONArray(session.expansions))
            .put("stopped", session.stopped)
            .apply {
                session.stoppedAtPercent?.let { put("stoppedAtPercent", it) }
            }
            .put("stoppedAtDone", session.stoppedAtDone)
            .put("stoppedAtTotal", session.stoppedAtTotal)
            .put("semanticEnabled", session.semanticEnabled)
            .put("accurateSearchUsed", session.accurateSearchUsed)
            .put("annEnabled", session.annEnabled)
            .put("annUsed", session.annUsed)
            .put("rerankApplied", session.rerankApplied)
            .put("rerankerEngine", session.rerankerEngine)
            .put("scopeNoteCount", session.scopeNoteCount)
            .put("totalNoteCount", session.totalNoteCount)
            .put("questionAwarenessEnabled", session.questionAwarenessEnabled)
            .put("queryDetectedAsQuestion", session.queryDetectedAsQuestion)
            .put("questionAwarenessUsed", session.questionAwarenessUsed)
            .put("questionType", session.questionType)
            .put("questionAwareQueries", JSONArray(session.questionAwareQueries))
        val hits = JSONArray()
        session.hits.forEach { hit ->
            hits.put(
                JSONObject()
                    .put("id", hit.id)
                    .put("relPath", hit.relPath)
                    .put("title", hit.title)
                    .put("snippet", hit.snippet)
                    .put("fileType", hit.fileType)
                    .put("scope", session.hitScopes[hit.id] ?: "")
                    .apply {
                        if (hit.score != null) put("score", hit.score.toDouble())
                        else put("score", JSONObject.NULL)
                    }
            )
        }
        root.put("hits", hits)
        return root.toString()
    }

    private fun decode(raw: String): SavedSearchSession {
        val root = JSONObject(raw)
        val arr = root.optJSONArray("hits") ?: JSONArray()
        val hits = ArrayList<SearchHit>(arr.length())
        val hitScopes = LinkedHashMap<Long, String>()
        for (i in 0 until arr.length()) {
            val item = arr.getJSONObject(i)
            val hitId = item.getLong("id")
            item.optString("scope").takeIf { it.isNotBlank() }?.let { hitScopes[hitId] = it }
            hits += SearchHit(
                id = hitId,
                relPath = item.optString("relPath"),
                title = item.optString("title"),
                snippet = item.optString("snippet"),
                fileType = item.optString("fileType", "md"),
                score = if (item.isNull("score")) null else item.optDouble("score").toFloat()
            )
        }
        return SavedSearchSession(
            id = root.getString("id"),
            query = root.optString("query"),
            createdAt = root.optLong("createdAt"),
            durationMs = root.optLong("durationMs"),
            scope = root.optString("scope", "all"),
            dualMode = root.optBoolean("dualMode", false),
            rerankEnabled = root.optBoolean("rerankEnabled", false),
            searchType = root.optString("searchType", "Deep"),
            llmUsed = root.optBoolean("llmUsed", false),
            llmEngine = root.optString("llmEngine", ""),
            expansions = root.optJSONArray("expansions")?.let { a -> List(a.length()) { i -> a.optString(i) }.filter { it.isNotBlank() } } ?: emptyList(),
            hitScopes = hitScopes,
            metadataVersion = root.optInt("version", 1).coerceAtLeast(1),
            stopped = root.optBoolean("stopped", false),
            stoppedAtPercent = if (root.has("stoppedAtPercent") && !root.isNull("stoppedAtPercent"))
                root.optInt("stoppedAtPercent").coerceIn(0, 100) else null,
            stoppedAtDone = root.optInt("stoppedAtDone", 0).coerceAtLeast(0),
            stoppedAtTotal = root.optInt("stoppedAtTotal", 0).coerceAtLeast(0),
            semanticEnabled = root.optBoolean("semanticEnabled", false),
            accurateSearchUsed = root.optBoolean("accurateSearchUsed", false),
            annEnabled = root.optBoolean("annEnabled", false),
            annUsed = root.optBoolean("annUsed", false),
            rerankApplied = root.optBoolean("rerankApplied", false),
            rerankerEngine = root.optString("rerankerEngine", ""),
            scopeNoteCount = root.optInt("scopeNoteCount", 0).coerceAtLeast(0),
            totalNoteCount = root.optInt("totalNoteCount", 0).coerceAtLeast(0),
            questionAwarenessEnabled = root.optBoolean("questionAwarenessEnabled", false),
            queryDetectedAsQuestion = root.optBoolean("queryDetectedAsQuestion", false),
            questionAwarenessUsed = root.optBoolean("questionAwarenessUsed", false),
            questionType = root.optString("questionType", ""),
            questionAwareQueries = root.optJSONArray("questionAwareQueries")?.let { a ->
                List(a.length()) { i -> a.optString(i) }.filter { it.isNotBlank() }
            } ?: emptyList(),
            hits = hits
        )
    }
}
