package com.tebogo.markvault.search

import android.content.Context
import android.util.AtomicFile
import com.google.gson.stream.JsonReader
import com.google.gson.stream.JsonToken
import com.tebogo.markvault.data.SearchHit
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.ensureActive
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.util.UUID

/**
 * Persists completed search result sets so a completed background search survives process death
 * and can be restored without re-running the expensive semantic/reranker pipeline.
 *
 * v5.5.11 — Durable retention is AGE-based only: every valid session is kept for up to six months.
 * UI/recent-search limits must never delete calendar history from disk.
 */
data class SavedSearchSession(
    val id: String,
    val query: String,
    val createdAt: Long,
    val durationMs: Long,
    val scope: String,
    val dualMode: Boolean,
    val rerankEnabled: Boolean,
    val searchType: String = "Deep",
    val llmUsed: Boolean = false,
    val llmEngine: String = "",
    val expansions: List<String> = emptyList(),
    val hitScopes: Map<Long, String> = emptyMap(),
    /** v5.5.23 — Exact retrieval/fusion provenance for every saved result. */
    val hitProvenance: Map<Long, ResultQueryProvenance> = emptyMap(),
    // v5.5.14 — execution metadata is persisted with every submitted search.
    // Defaults keep every v1 saved-search JSON file fully backward compatible.
    val metadataVersion: Int = 1,
    val stopped: Boolean = false,
    val stoppedAtPercent: Int? = null,
    val stoppedAtDone: Int = 0,
    val stoppedAtTotal: Int = 0,
    val semanticEnabled: Boolean = false,
    val accurateSearchUsed: Boolean = false,
    val annEnabled: Boolean = false,
    val annUsed: Boolean = false,
    val hnswEnabled: Boolean = false,
    val hnswUsed: Boolean = false,
    val timingSummary: String = "",
    val rerankApplied: Boolean = false,
    val rerankerEngine: String = "",
    val scopeNoteCount: Int = 0,
    val totalNoteCount: Int = 0,
    // v5.5.14 — Question Awareness audit metadata. Kept separate from generic
    // expansions so saved results can state whether a question was detected and
    // whether answer-oriented retrieval actually affected the search.
    val questionAwarenessEnabled: Boolean = false,
    val queryDetectedAsQuestion: Boolean = false,
    val questionAwarenessUsed: Boolean = false,
    val questionType: String = "",
    val questionAwareQueries: List<String> = emptyList(),
    val hits: List<SearchHit>
)

/** v5.5.2 — Lightweight metadata for calendar rendering without decoding full hit payloads. */
data class SessionMeta(
    val id: String,
    val query: String,
    val createdAt: Long,
    val hitCount: Int,
    val searchType: String = "Deep",
    val durationMs: Long = 0
)

object SavedSearchStore {
    private const val DIR_NAME = "saved_search_results"

    private fun dir(context: Context): File =
        File(context.filesDir, DIR_NAME).apply { mkdirs() }

    suspend fun save(
        context: Context,
        query: String,
        durationMs: Long,
        scope: String,
        dualMode: Boolean,
        rerankEnabled: Boolean,
        searchType: String,
        llmUsed: Boolean,
        llmEngine: String,
        expansions: List<String>,
        hitScopes: Map<Long, String>,
        hitProvenance: Map<Long, ResultQueryProvenance> = emptyMap(),
        stopped: Boolean = false,
        stoppedAtPercent: Int? = null,
        stoppedAtDone: Int = 0,
        stoppedAtTotal: Int = 0,
        semanticEnabled: Boolean = false,
        accurateSearchUsed: Boolean = false,
        annEnabled: Boolean = false,
        annUsed: Boolean = false,
        hnswEnabled: Boolean = false,
        hnswUsed: Boolean = false,
        timingSummary: String = "",
        rerankApplied: Boolean = false,
        rerankerEngine: String = "",
        scopeNoteCount: Int = 0,
        totalNoteCount: Int = 0,
        questionAwarenessEnabled: Boolean = false,
        queryDetectedAsQuestion: Boolean = false,
        questionAwarenessUsed: Boolean = false,
        questionType: String = "",
        questionAwareQueries: List<String> = emptyList(),
        hits: List<SearchHit>
    ): SavedSearchSession = withContext(Dispatchers.IO) {
        val now = System.currentTimeMillis()
        // v5.5.16 — Persist Question Awareness as "used" only when all
        // execution evidence agrees: the toggle was enabled, the query really
        // was detected as a question, and answer-oriented queries were actually
        // produced for retrieval. This keeps saved-search reporting/watermarks
        // truthful even if an upstream caller supplies inconsistent booleans.
        val persistedQuestionQueries = questionAwareQueries
            .map { it.trim() }
            .filter { it.isNotBlank() }
            .distinct()
        val persistedQuestionUsed = questionAwarenessEnabled &&
            queryDetectedAsQuestion && questionAwarenessUsed &&
            persistedQuestionQueries.isNotEmpty()
        val finalHitIds = hits.mapTo(HashSet()) { it.id }
        val session = SavedSearchSession(
            id = "${now}_${UUID.randomUUID().toString().take(8)}",
            query = query.trim(),
            createdAt = now,
            durationMs = durationMs.coerceAtLeast(0L),
            scope = scope,
            dualMode = dualMode,
            rerankEnabled = rerankEnabled,
            searchType = searchType,
            llmUsed = llmUsed,
            llmEngine = llmEngine,
            expansions = expansions.toList(),
            hitScopes = hitScopes.toMap(),
            hitProvenance = hitProvenance
                .filterKeys { id -> id in finalHitIds }
                .mapValues { (_, provenance) ->
                    val clean = provenance.contributions
                        .filter { it.queryText.isNotBlank() }
                        .map { contribution ->
                            contribution.copy(
                                contribution = contribution.contribution
                                    .takeIf { it.isFinite() }
                                    ?.coerceIn(0.0, 1.0) ?: 0.0,
                                queryWeight = contribution.queryWeight
                                    .takeIf { it.isFinite() }
                                    ?.coerceAtLeast(0.0) ?: 1.0
                            )
                        }
                    val primary = clean.firstOrNull { it.queryId == provenance.primaryQueryId }
                        ?: clean.maxWithOrNull(
                            compareBy<QueryContribution> { it.contribution }
                                .thenBy { it.retrievalPathCount }
                                .thenBy { it.queryWeight }
                                .thenBy { if (it.isOriginal) 1 else 0 }
                        )
                    ResultQueryProvenance(
                        primaryQueryId = primary?.queryId.orEmpty(),
                        contributions = clean
                    )
                }
                .filterValues { it.contributions.isNotEmpty() },
            metadataVersion = 6,
            stopped = stopped,
            stoppedAtPercent = stoppedAtPercent?.coerceIn(0, 100),
            stoppedAtDone = stoppedAtDone.coerceAtLeast(0),
            stoppedAtTotal = stoppedAtTotal.coerceAtLeast(0),
            semanticEnabled = semanticEnabled,
            accurateSearchUsed = accurateSearchUsed,
            annEnabled = annEnabled,
            annUsed = annUsed,
            hnswEnabled = hnswEnabled,
            hnswUsed = hnswUsed,
            timingSummary = timingSummary,
            rerankApplied = rerankApplied,
            rerankerEngine = rerankerEngine,
            scopeNoteCount = scopeNoteCount.coerceAtLeast(0),
            totalNoteCount = totalNoteCount.coerceAtLeast(0),
            questionAwarenessEnabled = questionAwarenessEnabled,
            queryDetectedAsQuestion = queryDetectedAsQuestion,
            questionAwarenessUsed = persistedQuestionUsed,
            questionType = if (queryDetectedAsQuestion) questionType.trim() else "",
            questionAwareQueries = if (persistedQuestionUsed) persistedQuestionQueries else emptyList(),
            hits = hits.toList()
        )
        writeSession(context, session)
        // v5.5.11 — A completed search must not evict a newer-than-six-month
        // session merely because a UI list limit was reached.
        purgeOlderThan6Months(context)
        session
    }

    suspend fun list(context: Context, maxSessions: Int = 50): List<SavedSearchSession> = withContext(Dispatchers.IO) {
        purgeOlderThan6Months(context)
        sessionFilesNewestFirst(context)
            // This is only an in-memory/recent-navigation window. It never deletes files.
            .take(maxSessions.coerceIn(1, 50))
            .mapNotNull { file -> runCatching { decode(file.readText(Charsets.UTF_8)) }.getOrNull() }
    }

    /**
     * v5.5.2 — Load ALL sessions within the 6-month retention window.
     * Used by the calendar/list view in SavedSearchesScreen.
     */
    suspend fun listAll(context: Context): List<SavedSearchSession> = withContext(Dispatchers.IO) {
        purgeOlderThan6Months(context)
        sessionFilesNewestFirst(context)
            .mapNotNull { file -> runCatching { decode(file.readText(Charsets.UTF_8)) }.getOrNull() }
    }

    /** UI reports never retain snippets, vectors, result objects or per-result provenance. */
    suspend fun listReports(context: Context, limit: Int? = null): List<SavedSearchReport> = withContext(Dispatchers.IO) {
        purgeOlderThan6Months(context)
        val files = sessionFilesNewestFirst(context)
        val selected = if (limit == null) files else files.take(limit.coerceIn(1, 50))
        val scanContext = kotlinx.coroutines.currentCoroutineContext()
        selected.mapNotNull { file ->
            scanContext.ensureActive()
            runCatching { readReport(file, scanContext) }.getOrElse {
                if (it is kotlinx.coroutines.CancellationException) throw it
                null
            }
        }
    }

    private fun readReport(file: File, scanContext: kotlin.coroutines.CoroutineContext): SavedSearchReport = file.bufferedReader(Charsets.UTF_8).use { input ->
        JsonReader(input).use { reader ->
            val header = JSONObject()
            var hitCount = 0
            val provenanceIds = HashSet<Long>()
            reader.beginObject()
            while (reader.hasNext()) {
                val name = reader.nextName()
                if (name == "hits") {
                    hitCount = 0
                    provenanceIds.clear()
                    if (reader.peek() == JsonToken.BEGIN_ARRAY) {
                        reader.beginArray()
                        while (reader.hasNext()) {
                            scanContext.ensureActive()
                            var id: Long? = null
                            var hasProvenance = false
                            reader.beginObject()
                            while (reader.hasNext()) {
                                when (reader.nextName()) {
                                    "id" -> id = JSONObject().put("id", readReportValue(reader)).getLong("id")
                                    "queryProvenance" -> hasProvenance = readReportProvenance(reader)
                                    else -> reader.skipValue()
                                }
                            }
                            reader.endObject()
                            val hitId = requireNotNull(id) { "Saved result has no id" }
                            hitCount++
                            if (hasProvenance) provenanceIds.add(hitId)
                        }
                        reader.endArray()
                    } else reader.skipValue()
                } else if (name in REPORT_FIELDS) {
                    header.put(name, readReportValue(reader))
                } else reader.skipValue()
            }
            reader.endObject()
            check(reader.peek() == JsonToken.END_DOCUMENT) { "Trailing saved-search data" }
            // The original decoder remains the single authority for metadata defaults/coercion.
            SavedSearchReport(decode(header.toString()), hitCount, provenanceIds.size)
        }
    }

    /** Match decodeProvenance's acceptance rule without constructing contributions or hit text. */
    private fun readReportProvenance(reader: JsonReader): Boolean {
        if (reader.peek() != JsonToken.BEGIN_OBJECT) {
            reader.skipValue()
            return false
        }
        var accepted = false
        reader.beginObject()
        while (reader.hasNext()) {
            if (reader.nextName() != "contributions") {
                reader.skipValue()
            } else {
                accepted = false
                if (reader.peek() == JsonToken.BEGIN_ARRAY) {
                    reader.beginArray()
                    while (reader.hasNext()) {
                        if (reader.peek() != JsonToken.BEGIN_OBJECT) {
                            reader.skipValue()
                        } else {
                            var queryText = ""
                            reader.beginObject()
                            while (reader.hasNext()) {
                                if (reader.nextName() == "queryText") {
                                    queryText = JSONObject().put("text", readReportValue(reader)).optString("text")
                                } else reader.skipValue()
                            }
                            reader.endObject()
                            if (queryText.trim().isNotEmpty()) accepted = true
                        }
                    }
                    reader.endArray()
                } else reader.skipValue()
            }
        }
        reader.endObject()
        return accepted
    }

    private fun readReportValue(reader: JsonReader): Any = when (reader.peek()) {
        JsonToken.STRING -> reader.nextString()
        JsonToken.NUMBER -> reader.nextString().let { it.toLongOrNull() ?: it.toDouble() }
        JsonToken.BOOLEAN -> reader.nextBoolean()
        JsonToken.NULL -> { reader.nextNull(); JSONObject.NULL }
        JsonToken.BEGIN_ARRAY -> JSONArray().also { array ->
            reader.beginArray()
            while (reader.hasNext()) array.put(readReportValue(reader))
            reader.endArray()
        }
        JsonToken.BEGIN_OBJECT -> JSONObject().also { obj ->
            reader.beginObject()
            while (reader.hasNext()) obj.put(reader.nextName(), readReportValue(reader))
            reader.endObject()
        }
        else -> error("Invalid saved-search metadata")
    }

    private val REPORT_FIELDS = setOf(
        "version", "id", "query", "createdAt", "durationMs", "scope", "dualMode", "rerankEnabled",
        "searchType", "llmUsed", "llmEngine", "expansions", "stopped", "stoppedAtPercent", "stoppedAtDone",
        "stoppedAtTotal", "semanticEnabled", "accurateSearchUsed", "annEnabled", "annUsed", "hnswEnabled",
        "hnswUsed", "timingSummary", "rerankApplied", "rerankerEngine", "scopeNoteCount", "totalNoteCount",
        "questionAwarenessEnabled", "queryDetectedAsQuestion", "questionAwarenessUsed", "questionType",
        "questionAwareQueries"
    )

    /**
     * v5.5.2 — Lightweight metadata-only listing for calendar rendering.
     * Returns (id, query, createdAt, hitCount) without decoding full hit
     * payloads, so it's fast even for hundreds of sessions.
     */
    suspend fun listMeta(context: Context): List<SessionMeta> = withContext(Dispatchers.IO) {
        listReports(context).map { it.metadata() }
    }

    /** v5.5.2 — Auto-delete saved searches older than 6 months. */
    private fun purgeOlderThan6Months(context: Context) {
        val sixMonthsAgo = System.currentTimeMillis() - (180L * 24 * 60 * 60 * 1000)
        dir(context).listFiles { f -> f.isFile && f.extension == "json" }?.forEach { file ->
            val ts = file.nameWithoutExtension.substringBefore('_').toLongOrNull()
            if (ts != null && ts < sixMonthsAgo) runCatching { file.delete() }
        }
    }

    suspend fun load(context: Context, id: String): SavedSearchSession? = withContext(Dispatchers.IO) {
        if (id.isBlank()) return@withContext null
        val file = File(dir(context), "$id.json")
        if (!file.isFile) return@withContext null
        runCatching { decode(file.readText(Charsets.UTF_8)) }.getOrNull()
    }

    suspend fun delete(context: Context, id: String) = withContext(Dispatchers.IO) {
        if (id.isNotBlank()) File(dir(context), "$id.json").delete()
    }

    private fun writeSession(context: Context, session: SavedSearchSession) {
        val atomic = AtomicFile(File(dir(context), "${session.id}.json"))
        val bytes = encode(session).toByteArray(Charsets.UTF_8)
        val out = atomic.startWrite()
        try {
            out.write(bytes)
            out.flush()
            atomic.finishWrite(out)
        } catch (t: Throwable) {
            atomic.failWrite(out)
            throw t
        }
    }

    /**
     * v5.5.11 — Kept for source compatibility with older callers. A UI count limit must never
     * delete durable calendar history, so this now enforces only the six-month retention policy.
     */
    @Suppress("UNUSED_PARAMETER")
    suspend fun enforceLimit(context: Context, maxSessions: Int) = withContext(Dispatchers.IO) {
        // The recent-list window is applied by [list]; durable storage is age-based only.
        purgeOlderThan6Months(context)
    }

    private fun sessionFilesNewestFirst(context: Context): List<File> =
        dir(context).listFiles { f -> f.isFile && f.extension == "json" }
            ?.sortedWith(
                compareByDescending<File> {
                    it.nameWithoutExtension.substringBefore('_').toLongOrNull()
                        ?: it.lastModified()
                }.thenByDescending { it.lastModified() }
            )
            ?: emptyList()

    private fun encode(session: SavedSearchSession): String {
        val root = JSONObject()
            .put("version", 6)
            .put("id", session.id)
            .put("query", session.query)
            .put("createdAt", session.createdAt)
            .put("durationMs", session.durationMs)
            .put("scope", session.scope)
            .put("dualMode", session.dualMode)
            .put("rerankEnabled", session.rerankEnabled)
            .put("searchType", session.searchType)
            .put("llmUsed", session.llmUsed)
            .put("llmEngine", session.llmEngine)
            .put("expansions", JSONArray(session.expansions))
            .put("stopped", session.stopped)
            .apply {
                session.stoppedAtPercent?.let { put("stoppedAtPercent", it) }
            }
            .put("stoppedAtDone", session.stoppedAtDone)
            .put("stoppedAtTotal", session.stoppedAtTotal)
            .put("semanticEnabled", session.semanticEnabled)
            .put("accurateSearchUsed", session.accurateSearchUsed)
            .put("annEnabled", session.annEnabled)
            .put("annUsed", session.annUsed)
            .put("hnswEnabled", session.hnswEnabled)
            .put("hnswUsed", session.hnswUsed)
            .put("timingSummary", session.timingSummary)
            .put("rerankApplied", session.rerankApplied)
            .put("rerankerEngine", session.rerankerEngine)
            .put("scopeNoteCount", session.scopeNoteCount)
            .put("totalNoteCount", session.totalNoteCount)
            .put("questionAwarenessEnabled", session.questionAwarenessEnabled)
            .put("queryDetectedAsQuestion", session.queryDetectedAsQuestion)
            .put("questionAwarenessUsed", session.questionAwarenessUsed)
            .put("questionType", session.questionType)
            .put("questionAwareQueries", JSONArray(session.questionAwareQueries))
        val hits = JSONArray()
        session.hits.forEach { hit ->
            hits.put(
                JSONObject()
                    .put("id", hit.id)
                    .put("relPath", hit.relPath)
                    .put("title", hit.title)
                    .put("snippet", hit.snippet)
                    .put("fileType", hit.fileType)
                    .put("scope", session.hitScopes[hit.id] ?: "")
                    .apply {
                        if (hit.score != null) put("score", hit.score.toDouble())
                        else put("score", JSONObject.NULL)
                        session.hitProvenance[hit.id]?.let { provenance ->
                            put("queryProvenance", encodeProvenance(provenance))
                        }
                    }
            )
        }
        root.put("hits", hits)
        return root.toString()
    }

    private fun decode(raw: String): SavedSearchSession {
        val root = JSONObject(raw)
        val arr = root.optJSONArray("hits") ?: JSONArray()
        val hits = ArrayList<SearchHit>(arr.length())
        val hitScopes = LinkedHashMap<Long, String>()
        val hitProvenance = LinkedHashMap<Long, ResultQueryProvenance>()
        for (i in 0 until arr.length()) {
            val item = arr.getJSONObject(i)
            val hitId = item.getLong("id")
            item.optString("scope").takeIf { it.isNotBlank() }?.let { hitScopes[hitId] = it }
            item.optJSONObject("queryProvenance")?.let { stored ->
                decodeProvenance(stored)?.let { hitProvenance[hitId] = it }
            }
            hits += SearchHit(
                id = hitId,
                relPath = item.optString("relPath"),
                title = item.optString("title"),
                snippet = item.optString("snippet"),
                fileType = item.optString("fileType", "md"),
                score = if (item.isNull("score")) null else item.optDouble("score").toFloat()
            )
        }
        return SavedSearchSession(
            id = root.getString("id"),
            query = root.optString("query"),
            createdAt = root.optLong("createdAt"),
            durationMs = root.optLong("durationMs"),
            scope = root.optString("scope", "all"),
            dualMode = root.optBoolean("dualMode", false),
            rerankEnabled = root.optBoolean("rerankEnabled", false),
            searchType = root.optString("searchType", "Deep"),
            llmUsed = root.optBoolean("llmUsed", false),
            llmEngine = root.optString("llmEngine", ""),
            expansions = root.optJSONArray("expansions")?.let { a -> List(a.length()) { i -> a.optString(i) }.filter { it.isNotBlank() } } ?: emptyList(),
            hitScopes = hitScopes,
            hitProvenance = hitProvenance,
            metadataVersion = root.optInt("version", 1).coerceAtLeast(1),
            stopped = root.optBoolean("stopped", false),
            stoppedAtPercent = if (root.has("stoppedAtPercent") && !root.isNull("stoppedAtPercent"))
                root.optInt("stoppedAtPercent").coerceIn(0, 100) else null,
            stoppedAtDone = root.optInt("stoppedAtDone", 0).coerceAtLeast(0),
            stoppedAtTotal = root.optInt("stoppedAtTotal", 0).coerceAtLeast(0),
            semanticEnabled = root.optBoolean("semanticEnabled", false),
            accurateSearchUsed = root.optBoolean("accurateSearchUsed", false),
            annEnabled = root.optBoolean("annEnabled", false),
            annUsed = root.optBoolean("annUsed", false),
            hnswEnabled = root.optBoolean("hnswEnabled", false),
            hnswUsed = root.optBoolean("hnswUsed", false),
            timingSummary = root.optString("timingSummary", ""),
            rerankApplied = root.optBoolean("rerankApplied", false),
            rerankerEngine = root.optString("rerankerEngine", ""),
            scopeNoteCount = root.optInt("scopeNoteCount", 0).coerceAtLeast(0),
            totalNoteCount = root.optInt("totalNoteCount", 0).coerceAtLeast(0),
            questionAwarenessEnabled = root.optBoolean("questionAwarenessEnabled", false),
            queryDetectedAsQuestion = root.optBoolean("queryDetectedAsQuestion", false),
            questionAwarenessUsed = root.optBoolean("questionAwarenessUsed", false),
            questionType = root.optString("questionType", ""),
            questionAwareQueries = root.optJSONArray("questionAwareQueries")?.let { a ->
                List(a.length()) { i -> a.optString(i) }.filter { it.isNotBlank() }
            } ?: emptyList(),
            hits = hits
        )
    }

    private fun encodeProvenance(provenance: ResultQueryProvenance): JSONObject {
        val contributions = JSONArray()
        provenance.contributions.forEach { contribution ->
            contributions.put(
                JSONObject()
                    .put("queryId", contribution.queryId)
                    .put("queryText", contribution.queryText)
                    .put("source", contribution.source.name)
                    .put("keyword", contribution.keyword)
                    .put("semantic", contribution.semantic)
                    .put("contribution", contribution.contribution)
                    .put("queryWeight", contribution.queryWeight)
                    .apply {
                        contribution.expansionNumber?.let { put("expansionNumber", it) }
                        contribution.keywordRank?.let { put("keywordRank", it) }
                        contribution.semanticRank?.let { put("semanticRank", it) }
                    }
            )
        }
        return JSONObject()
            .put("primaryQueryId", provenance.primaryQueryId)
            .put("contributions", contributions)
    }

    private fun decodeProvenance(raw: JSONObject): ResultQueryProvenance? {
        val stored = raw.optJSONArray("contributions") ?: return null
        val contributions = buildList {
            for (i in 0 until stored.length()) {
                val item = stored.optJSONObject(i) ?: continue
                val queryText = item.optString("queryText").trim()
                if (queryText.isEmpty()) continue
                val expansionNumber = if (
                    item.has("expansionNumber") && !item.isNull("expansionNumber")
                ) item.optInt("expansionNumber").takeIf { it > 0 } else null
                add(
                    QueryContribution(
                        queryId = item.optString(
                            "queryId",
                            expansionNumber?.let { "expansion:$it" } ?: "original"
                        ),
                        queryText = queryText,
                        source = ResultQuerySource.fromStoredName(item.optString("source")),
                        expansionNumber = expansionNumber,
                        keyword = item.optBoolean("keyword", false),
                        semantic = item.optBoolean("semantic", false),
                        contribution = item.optDouble("contribution", 0.0)
                            .takeIf { it.isFinite() }?.coerceIn(0.0, 1.0) ?: 0.0,
                        queryWeight = item.optDouble("queryWeight", 1.0)
                            .takeIf { it.isFinite() }?.coerceAtLeast(0.0) ?: 1.0,
                        keywordRank = if (item.has("keywordRank"))
                            item.optInt("keywordRank").takeIf { it > 0 } else null,
                        semanticRank = if (item.has("semanticRank"))
                            item.optInt("semanticRank").takeIf { it > 0 } else null
                    )
                )
            }
        }
        if (contributions.isEmpty()) return null
        val requestedPrimary = raw.optString("primaryQueryId")
        val primary = contributions.firstOrNull { it.queryId == requestedPrimary }
            ?: contributions.maxWithOrNull(
                compareBy<QueryContribution> { it.contribution }
                    .thenBy { it.retrievalPathCount }
                    .thenBy { it.queryWeight }
                    .thenBy { if (it.isOriginal) 1 else 0 }
            )
            ?: return null
        return ResultQueryProvenance(primary.queryId, contributions)
    }
}
