package com.tebogo.markvault.search

import android.content.Context
import android.util.AtomicFile
import com.tebogo.markvault.data.SearchHit
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.util.UUID

/**
 * Persists the five most recent completed search result sets so a completed
 * background search survives process death and can be restored without
 * re-running the expensive semantic/reranker pipeline.
 */
data class SavedSearchSession(
    val id: String,
    val query: String,
    val createdAt: Long,
    val durationMs: Long,
    val scope: String,
    val dualMode: Boolean,
    val rerankEnabled: Boolean,
    val hits: List<SearchHit>
)

object SavedSearchStore {
    private const val DIR_NAME = "saved_search_results"
    private const val MAX_SESSIONS = 5

    private fun dir(context: Context): File =
        File(context.filesDir, DIR_NAME).apply { mkdirs() }

    suspend fun save(
        context: Context,
        query: String,
        durationMs: Long,
        scope: String,
        dualMode: Boolean,
        rerankEnabled: Boolean,
        hits: List<SearchHit>
    ): SavedSearchSession = withContext(Dispatchers.IO) {
        val now = System.currentTimeMillis()
        val session = SavedSearchSession(
            id = "${now}_${UUID.randomUUID().toString().take(8)}",
            query = query.trim(),
            createdAt = now,
            durationMs = durationMs.coerceAtLeast(0L),
            scope = scope,
            dualMode = dualMode,
            rerankEnabled = rerankEnabled,
            hits = hits.toList()
        )
        writeSession(context, session)
        trimToLimit(context)
        session
    }

    suspend fun list(context: Context): List<SavedSearchSession> = withContext(Dispatchers.IO) {
        readAll(context).sortedByDescending { it.createdAt }.take(MAX_SESSIONS)
    }

    suspend fun load(context: Context, id: String): SavedSearchSession? = withContext(Dispatchers.IO) {
        if (id.isBlank()) return@withContext null
        val file = File(dir(context), "$id.json")
        if (!file.isFile) return@withContext null
        runCatching { decode(file.readText(Charsets.UTF_8)) }.getOrNull()
    }

    suspend fun delete(context: Context, id: String) = withContext(Dispatchers.IO) {
        if (id.isNotBlank()) File(dir(context), "$id.json").delete()
    }

    private fun writeSession(context: Context, session: SavedSearchSession) {
        val atomic = AtomicFile(File(dir(context), "${session.id}.json"))
        val bytes = encode(session).toByteArray(Charsets.UTF_8)
        val out = atomic.startWrite()
        try {
            out.write(bytes)
            out.flush()
            atomic.finishWrite(out)
        } catch (t: Throwable) {
            atomic.failWrite(out)
            throw t
        }
    }

    private fun trimToLimit(context: Context) {
        val keep = readAll(context)
            .sortedByDescending { it.createdAt }
            .take(MAX_SESSIONS)
            .mapTo(HashSet()) { it.id }
        dir(context).listFiles { f -> f.isFile && f.extension == "json" }
            ?.forEach { file ->
                val id = file.nameWithoutExtension
                if (id !in keep) file.delete()
            }
    }

    private fun readAll(context: Context): List<SavedSearchSession> =
        dir(context).listFiles { f -> f.isFile && f.extension == "json" }
            ?.mapNotNull { file -> runCatching { decode(file.readText(Charsets.UTF_8)) }.getOrNull() }
            ?: emptyList()

    private fun encode(session: SavedSearchSession): String {
        val root = JSONObject()
            .put("version", 1)
            .put("id", session.id)
            .put("query", session.query)
            .put("createdAt", session.createdAt)
            .put("durationMs", session.durationMs)
            .put("scope", session.scope)
            .put("dualMode", session.dualMode)
            .put("rerankEnabled", session.rerankEnabled)
        val hits = JSONArray()
        session.hits.forEach { hit ->
            hits.put(
                JSONObject()
                    .put("id", hit.id)
                    .put("relPath", hit.relPath)
                    .put("title", hit.title)
                    .put("snippet", hit.snippet)
                    .put("fileType", hit.fileType)
                    .apply {
                        if (hit.score != null) put("score", hit.score.toDouble())
                        else put("score", JSONObject.NULL)
                    }
            )
        }
        root.put("hits", hits)
        return root.toString()
    }

    private fun decode(raw: String): SavedSearchSession {
        val root = JSONObject(raw)
        val arr = root.optJSONArray("hits") ?: JSONArray()
        val hits = ArrayList<SearchHit>(arr.length())
        for (i in 0 until arr.length()) {
            val item = arr.getJSONObject(i)
            hits += SearchHit(
                id = item.getLong("id"),
                relPath = item.optString("relPath"),
                title = item.optString("title"),
                snippet = item.optString("snippet"),
                fileType = item.optString("fileType", "md"),
                score = if (item.isNull("score")) null else item.optDouble("score").toFloat()
            )
        }
        return SavedSearchSession(
            id = root.getString("id"),
            query = root.optString("query"),
            createdAt = root.optLong("createdAt"),
            durationMs = root.optLong("durationMs"),
            scope = root.optString("scope", "all"),
            dualMode = root.optBoolean("dualMode", false),
            rerankEnabled = root.optBoolean("rerankEnabled", false),
            hits = hits
        )
    }
}
