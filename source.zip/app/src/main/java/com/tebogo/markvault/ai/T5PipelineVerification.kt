package com.tebogo.markvault.ai

object T5PipelineVerification {
    fun stageOrder(): List<String> = listOf(
        "query",
        "expansion",
        "multi_query_retriever",
        "semantic_search",
        "reranker",
        "results"
    )
}
