package com.tebogo.markvault.ui

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.gestures.detectTransformGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.nativeCanvas
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.navigation.NavController
import com.tebogo.markvault.AppViewModel
import com.tebogo.markvault.FocusGraph
import com.tebogo.markvault.LinkDir
import kotlin.math.cos
import kotlin.math.hypot
import kotlin.math.min
import kotlin.math.sin

/** Pre-computed screen position + bounds for one node, used for hit-testing. */
private data class PlacedNode(
    val id: Long,
    val title: String,
    val cx: Float,
    val cy: Float,
    val radius: Float,
    val ring: Int, // 0 = center, 1 = inner ring, 2 = outer ring
    val dir: LinkDir = LinkDir.OUTGOING
)

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun GraphScreen(vm: AppViewModel, nav: NavController, startNoteId: Long?) {
    var currentCenterId by remember { mutableStateOf<Long?>(startNoteId) }
    var graph by remember { mutableStateOf<FocusGraph?>(null) }
    var loading by remember { mutableStateOf(true) }
    var emptyMessage by remember { mutableStateOf<String?>(null) }

    // Pan / zoom state — survives recompositions and recentre events.
    var scale by remember { mutableStateOf(1f) }
    var offsetX by remember { mutableStateOf(0f) }
    var offsetY by remember { mutableStateOf(0f) }

    LaunchedEffect(currentCenterId) {
        loading = true
        graph = null
        emptyMessage = null
        val id = currentCenterId ?: vm.mostConnectedNote()?.id
        if (id == null) {
            emptyMessage = "No notes with wikilinks were found in your library yet."
        } else {
            val g = vm.buildFocusGraph(id)
            if (g == null) {
                emptyMessage = "That note isn't in the library anymore."
            } else {
                graph = g
                // Reset view whenever we recentre on a new note
                scale = 1f; offsetX = 0f; offsetY = 0f
            }
        }
        loading = false
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Column {
                        Text("\uD83C\uDF10 Focus graph",
                            fontWeight = FontWeight.SemiBold, fontSize = 16.sp)
                        val g = graph
                        if (g != null) {
                            Text(
                                g.center.title,
                                maxLines = 1, overflow = TextOverflow.Ellipsis,
                                fontSize = 11.sp,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    }
                },
                navigationIcon = {
                    IconButton(onClick = { nav.popBackStack() }) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back")
                    }
                },
                actions = {
                    IconButton(onClick = { scale = 1f; offsetX = 0f; offsetY = 0f }) {
                        Icon(Icons.Default.Refresh, contentDescription = "Reset view")
                    }
                }
            )
        }
    ) { pad ->
        Box(Modifier.padding(pad).fillMaxSize()) {
            when {
                loading -> Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                    CircularProgressIndicator()
                }
                emptyMessage != null -> Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                    Text(emptyMessage!!, color = MaterialTheme.colorScheme.onSurfaceVariant,
                        modifier = Modifier.padding(32.dp))
                }
                graph != null -> GraphCanvas(
                    graph = graph!!,
                    scale = scale,
                    offsetX = offsetX,
                    offsetY = offsetY,
                    onScaleChange = { s, dx, dy ->
                        scale = (scale * s).coerceIn(0.4f, 3f)
                        offsetX += dx
                        offsetY += dy
                    },
                    onNodeTap = { id ->
                        if (id != graph!!.center.id) currentCenterId = id
                    },
                    onNodeLongPress = { id, title ->
                        vm.openArticle(id, title)
                        nav.navigate("reader") { launchSingleTop = true }
                    }
                )
            }
            // Legend overlay (bottom-left)
            graph?.let {
                LegendCard(
                    firstRingShown = it.firstRing.size,
                    firstRingTotal = it.firstRingTotal,
                    secondRingShown = it.secondRing.size,
                    modifier = Modifier.align(Alignment.BottomStart).padding(12.dp)
                )
            }
        }
    }
}

@Composable
private fun LegendCard(
    firstRingShown: Int,
    firstRingTotal: Int,
    secondRingShown: Int,
    modifier: Modifier = Modifier
) {
    Surface(
        color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.93f),
        shape = RoundedCornerShape(10.dp),
        modifier = modifier
    ) {
        Column(Modifier.padding(horizontal = 10.dp, vertical = 8.dp)) {
            Text("Tap node \u2192 re-centre", fontSize = 11.sp,
                color = MaterialTheme.colorScheme.onSurfaceVariant)
            Text("Long-press \u2192 open note", fontSize = 11.sp,
                color = MaterialTheme.colorScheme.onSurfaceVariant)
            Spacer(Modifier.height(4.dp))
            val moreFirst = if (firstRingTotal > firstRingShown) " (+${firstRingTotal - firstRingShown})" else ""
            Text("1\u00B0: $firstRingShown$moreFirst  \u00B7  2\u00B0: $secondRingShown",
                fontSize = 11.sp, fontWeight = FontWeight.Medium)
        }
    }
}

@Composable
private fun GraphCanvas(
    graph: FocusGraph,
    scale: Float,
    offsetX: Float,
    offsetY: Float,
    onScaleChange: (scale: Float, dx: Float, dy: Float) -> Unit,
    onNodeTap: (id: Long) -> Unit,
    onNodeLongPress: (id: Long, title: String) -> Unit
) {
    // Style values pulled from the theme; remembered per recomposition.
    val accent = MaterialTheme.colorScheme.primary
    val secondary = MaterialTheme.colorScheme.secondary
    val surfaceVariant = MaterialTheme.colorScheme.surfaceVariant
    val edgeColor = MaterialTheme.colorScheme.outline.copy(alpha = 0.55f)
    val incomingColor = secondary.copy(alpha = 0.75f)
    val outgoingColor = accent.copy(alpha = 0.75f)
    val labelColor = MaterialTheme.colorScheme.onSurface
    val labelDimColor = MaterialTheme.colorScheme.onSurfaceVariant
    val backgroundColor = MaterialTheme.colorScheme.background

    // Hit-test list mutated in place during each draw; gesture callbacks read the latest contents.
    val placedRef = remember { ArrayList<PlacedNode>(48) }

    Canvas(
        modifier = Modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
            .pointerInput(graph.center.id) {
                detectTransformGestures { _, panChange, zoomChange, _ ->
                    onScaleChange(zoomChange, panChange.x, panChange.y)
                }
            }
            .pointerInput(graph.center.id) {
                detectTapGestures(
                    onTap = { pos ->
                        val hit = hitTest(pos, placedRef)
                        if (hit != null) onNodeTap(hit.id)
                    },
                    onLongPress = { pos ->
                        val hit = hitTest(pos, placedRef)
                        if (hit != null) onNodeLongPress(hit.id, hit.title)
                    }
                )
            }
    ) {
        val w = size.width
        val h = size.height
        val cx0 = w / 2f + offsetX
        val cy0 = h / 2f + offsetY

        // Ring radii scale with canvas size; pinch-zoom scales everything around the center.
        val baseUnit = (min(w, h) * 0.35f) * scale
        val innerRadius = baseUnit * 0.55f
        val outerRadius = baseUnit * 1.0f
        val centerNodeR = 26f * scale
        val firstNodeR = 18f * scale
        val secondNodeR = 11f * scale

        // === Compute positions for all nodes ===
        val firstPlaced = ArrayList<PlacedNode>(graph.firstRing.size)
        val first = graph.firstRing
        if (first.isNotEmpty()) {
            val step = (2.0 * Math.PI / first.size).toFloat()
            // Start at top (-PI/2) so the first node sits above the centre
            val start = (-Math.PI / 2.0).toFloat()
            for ((i, n) in first.withIndex()) {
                val a = start + step * i
                val x = cx0 + cos(a) * innerRadius
                val y = cy0 + sin(a) * innerRadius
                firstPlaced.add(PlacedNode(n.note.id, n.note.title, x, y, firstNodeR, 1, n.dir))
            }
        }
        // Group 2°-ring nodes by their "via" 1°-node, then spread them out near that parent.
        val secondPlaced = ArrayList<PlacedNode>(graph.secondRing.size)
        if (graph.secondRing.isNotEmpty()) {
            val viaToChildren = graph.secondRing.groupBy { it.viaNoteId }
            for (parent in firstPlaced) {
                val kids = viaToChildren[parent.id] ?: continue
                // Angle of parent from centre
                val parentAngle = kotlin.math.atan2(parent.cy - cy0, parent.cx - cx0)
                // Spread kids in a small arc on the far side of the parent
                val spread = (Math.PI / 4.5).toFloat()
                val startAngle = parentAngle - spread / 2f
                val angleStep = if (kids.size > 1) spread / (kids.size - 1) else 0f
                for ((j, e) in kids.withIndex()) {
                    val a = if (kids.size == 1) parentAngle else startAngle + angleStep * j
                    val x = cx0 + cos(a) * outerRadius
                    val y = cy0 + sin(a) * outerRadius
                    secondPlaced.add(PlacedNode(e.note.id, e.note.title, x, y, secondNodeR, 2))
                }
            }
        }

        // === Draw edges first (so nodes sit on top) ===
        val strokeW = (1.4f * scale).coerceAtLeast(1f)
        for (p in firstPlaced) {
            val color = when (p.dir) {
                LinkDir.OUTGOING -> outgoingColor
                LinkDir.INCOMING -> incomingColor
                LinkDir.BOTH -> outgoingColor
            }
            drawLine(
                color = color,
                start = Offset(cx0, cy0),
                end = Offset(p.cx, p.cy),
                strokeWidth = strokeW
            )
        }
        for (e in graph.secondRing) {
            val parent = firstPlaced.firstOrNull { it.id == e.viaNoteId } ?: continue
            val placedKid = secondPlaced.firstOrNull { it.id == e.note.id } ?: continue
            drawLine(
                color = edgeColor,
                start = Offset(parent.cx, parent.cy),
                end = Offset(placedKid.cx, placedKid.cy),
                strokeWidth = strokeW * 0.7f
            )
        }

        // === Draw nodes ===
        // Center
        drawCircle(color = accent.copy(alpha = 0.25f), radius = centerNodeR + 8f * scale, center = Offset(cx0, cy0))
        drawCircle(color = accent, radius = centerNodeR, center = Offset(cx0, cy0))
        // First ring
        for (p in firstPlaced) {
            val fill = when (p.dir) {
                LinkDir.OUTGOING -> outgoingColor
                LinkDir.INCOMING -> incomingColor
                LinkDir.BOTH -> outgoingColor
            }
            drawCircle(color = surfaceVariant, radius = p.radius + 2f, center = Offset(p.cx, p.cy))
            drawCircle(color = fill, radius = p.radius, center = Offset(p.cx, p.cy))
            drawCircle(color = backgroundColor, radius = p.radius - 4f * scale,
                center = Offset(p.cx, p.cy))
            drawCircle(color = fill.copy(alpha = 1f), radius = p.radius - 4f * scale,
                center = Offset(p.cx, p.cy), style = Stroke(width = 2f * scale))
        }
        // Second ring
        for (p in secondPlaced) {
            drawCircle(color = surfaceVariant, radius = p.radius + 2f, center = Offset(p.cx, p.cy))
            drawCircle(color = labelDimColor.copy(alpha = 0.85f), radius = p.radius, center = Offset(p.cx, p.cy))
        }

        // === Draw labels via native Canvas (drawText on DrawScope needs a TextMeasurer; using nativeCanvas keeps it simple) ===
        val paint = android.graphics.Paint().apply {
            isAntiAlias = true
            textSize = 30f * scale
            color = android.graphics.Color.argb(
                (labelColor.alpha * 255).toInt(),
                (labelColor.red * 255).toInt(),
                (labelColor.green * 255).toInt(),
                (labelColor.blue * 255).toInt()
            )
            textAlign = android.graphics.Paint.Align.CENTER
            isFakeBoldText = true
        }
        val paintDim = android.graphics.Paint(paint).apply {
            textSize = 24f * scale
            isFakeBoldText = false
            color = android.graphics.Color.argb(
                (labelDimColor.alpha * 255).toInt(),
                (labelDimColor.red * 255).toInt(),
                (labelDimColor.green * 255).toInt(),
                (labelDimColor.blue * 255).toInt()
            )
        }
        // Center label below the center node
        drawContext.canvas.nativeCanvas.drawText(
            truncate(graph.center.title, 22),
            cx0,
            cy0 + centerNodeR + 30f * scale,
            paint
        )
        // First-ring labels just outside each node, radially outward
        for (p in firstPlaced) {
            val dx = p.cx - cx0
            val dy = p.cy - cy0
            val len = hypot(dx, dy).coerceAtLeast(0.001f)
            val nx = dx / len; val ny = dy / len
            val tx = p.cx + nx * (p.radius + 18f * scale)
            val ty = p.cy + ny * (p.radius + 18f * scale) + 6f * scale
            drawContext.canvas.nativeCanvas.drawText(truncate(p.title, 18), tx, ty, paint)
        }
        // Second-ring labels: tiny, dimmer, only when zoom is comfortable
        if (scale >= 0.85f) {
            for (p in secondPlaced) {
                val dx = p.cx - cx0
                val dy = p.cy - cy0
                val len = hypot(dx, dy).coerceAtLeast(0.001f)
                val nx = dx / len; val ny = dy / len
                val tx = p.cx + nx * (p.radius + 12f * scale)
                val ty = p.cy + ny * (p.radius + 12f * scale) + 4f * scale
                drawContext.canvas.nativeCanvas.drawText(truncate(p.title, 14), tx, ty, paintDim)
            }
        }

        // Update placed list for hit-testing on next gesture
        placedRef.clear()
        placedRef.add(PlacedNode(graph.center.id, graph.center.title, cx0, cy0, centerNodeR, 0))
        placedRef.addAll(firstPlaced)
        placedRef.addAll(secondPlaced)
    }
}

private fun hitTest(pos: Offset, nodes: List<PlacedNode>): PlacedNode? {
    // Reverse order so top-drawn (smaller, later) nodes win when overlapping
    for (i in nodes.indices.reversed()) {
        val n = nodes[i]
        val dx = pos.x - n.cx
        val dy = pos.y - n.cy
        // Slightly enlarge the tap area for accessibility
        val touchR = n.radius + 14f
        if (dx * dx + dy * dy <= touchR * touchR) return n
    }
    return null
}

private fun truncate(s: String, maxLen: Int): String {
    if (s.length <= maxLen) return s
    return s.take(maxLen - 1).trimEnd() + "\u2026"
}
