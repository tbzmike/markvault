package com.tebogo.markvault.ui

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.gestures.detectTransformGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.FilterChip
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.nativeCanvas
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.navigation.NavController
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.tebogo.markvault.AppViewModel
import com.tebogo.markvault.FocusGraph
import com.tebogo.markvault.GroupGraph
import com.tebogo.markvault.LinkDir
import kotlinx.coroutines.launch
import kotlin.math.ceil
import kotlin.math.cos
import kotlin.math.sqrt
import kotlin.math.hypot
import kotlin.math.min
import kotlin.math.sin

/** Pre-computed screen position + bounds for one node, used for hit-testing.
 *  If [width] > 0 the node is treated as an axis-aligned rectangle (tree view boxes);
 *  otherwise [radius] is used (radial view circles). */
private data class PlacedNode(
    val id: Long,
    val title: String,
    val cx: Float,
    val cy: Float,
    val radius: Float,
    val ring: Int, // 0 = center, 1 = inner ring, 2 = outer ring
    val dir: LinkDir = LinkDir.OUTGOING,
    val width: Float = 0f,
    val height: Float = 0f
)

/** Which layout the graph view is using. */
private enum class GraphLayout { TREE, RADIAL }

private fun graphGroupSuffix(index: Int): String {
    var n = index.coerceAtLeast(0)
    val out = StringBuilder()
    do {
        out.append(('a'.code + (n % 26)).toChar())
        n = n / 26 - 1
    } while (n >= 0)
    return out.reverse().toString()
}

private fun graphGroupLabel(groupSize: Int, index: Int): String =
    "${groupSize / 1000}K${graphGroupSuffix(index)}"

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun GraphScreen(vm: AppViewModel, nav: NavController, startNoteId: Long?) {
    // Stack of centered note IDs the user has visited inside this graph view.
    // Top of the stack = currently centered. Lets system Back walk through them before exiting.
    val centerStack = remember { mutableStateListOf<Long>() }
    val currentCenterId: Long? = centerStack.lastOrNull() ?: startNoteId
    var graph by remember { mutableStateOf<FocusGraph?>(null) }
    var groupGraph by remember { mutableStateOf<GroupGraph?>(null) }
    var loading by remember { mutableStateOf(true) }
    var emptyMessage by remember { mutableStateOf<String?>(null) }

    // Pan / zoom state — survives recompositions and recentre events.
    var scale by remember { mutableStateOf(1f) }
    var offsetX by remember { mutableStateOf(0f) }
    var offsetY by remember { mutableStateOf(0f) }
    val graphLayoutName by vm.workspaceGraphLayout.collectAsStateWithLifecycle()
    val layout = if (graphLayoutName == "radial") GraphLayout.RADIAL else GraphLayout.TREE
    /** Node currently expanded (first tap). Tap again to open; tap elsewhere to dismiss. */
    var selectedId by remember { mutableStateOf<Long?>(null) }
    val graphDepth by vm.workspaceGraphDepth.collectAsStateWithLifecycle()
    val directionFilter by vm.workspaceGraphDirection.collectAsStateWithLifecycle()
    val folderFilter by vm.workspaceGraphFolder.collectAsStateWithLifecycle()
    val tagFilter by vm.workspaceGraphTag.collectAsStateWithLifecycle()
    val savedCenterId by vm.workspaceGraphCenterId.collectAsStateWithLifecycle()
    val graphScopeMode by vm.workspaceGraphScope.collectAsStateWithLifecycle()
    val graphGroupIndex by vm.workspaceGraphGroupIndex.collectAsStateWithLifecycle()
    var articleCount by remember { mutableStateOf(0) }
    var allowedGraphIds by remember { mutableStateOf<Set<Long>?>(null) }
    var graphGroupLoading by remember { mutableStateOf(true) }
    var groupMenu by remember { mutableStateOf(false) }
    val activeReaderTab by vm.activeTab.collectAsStateWithLifecycle()
    val readerTabs by vm.tabs.collectAsStateWithLifecycle()
    var folderMenu by remember { mutableStateOf(false) }
    val graphScope = rememberCoroutineScope()
    var tagMenu by remember { mutableStateOf(false) }
    var nodeTags by remember { mutableStateOf<Map<Long, List<String>>>(emptyMap()) }

    // v5.4.359cc — Graph-only windows keep large libraries manageable without
    // touching indexing/embeddings. 5K/10K scopes materialise only the stable
    // note-id membership for the selected article window; All keeps the legacy
    // unrestricted focus graph. Deep-linked articles automatically select their
    // own window so "Graph" always opens the article the user asked for.
    LaunchedEffect(startNoteId, graphScopeMode, graphGroupIndex) {
        loading = true
        graphGroupLoading = true
        val total = vm.graphArticleCount()
        articleCount = total
        val groupSize = when (graphScopeMode) {
            "10k" -> 10_000
            "all" -> 0
            else -> 5_000
        }
        if (groupSize == 0) {
            allowedGraphIds = null
            val loadedAll = vm.buildAllArticleGraph()
            groupGraph = loadedAll
            nodeTags = vm.tagsForNotes(loadedAll.nodes.map { it.id })
            centerStack.clear()
            startNoteId?.takeIf { id -> loadedAll.nodes.any { it.id == id } }?.let(centerStack::add)
        } else {
            val groupCount = ((total + groupSize - 1) / groupSize).coerceAtLeast(1)
            var targetGroup = graphGroupIndex.coerceIn(0, groupCount - 1)
            if (startNoteId != null && vm.noteById(startNoteId) != null) {
                targetGroup = vm.graphGroupIndexForNote(startNoteId, groupSize).coerceIn(0, groupCount - 1)
                if (targetGroup != graphGroupIndex) {
                    vm.setWorkspaceGraphGroupIndex(targetGroup)
                    graphGroupLoading = false
                    return@LaunchedEffect
                }
            } else if (targetGroup != graphGroupIndex) {
                vm.setWorkspaceGraphGroupIndex(targetGroup)
            }
            val ids = vm.graphGroupIds(groupSize, targetGroup)
            allowedGraphIds = ids
            // v5.4.360cc — This is the actual group graph, not merely an ID fence around
            // the old focus graph. Every article in the selected window is loaded as a node,
            // plus every resolvable wikilink whose two endpoints are inside that window.
            val loadedGroup = vm.buildGraphGroup(groupSize, targetGroup)
            groupGraph = loadedGroup
            nodeTags = vm.tagsForNotes(loadedGroup.nodes.map { it.id })
            val existing = centerStack.lastOrNull()?.takeIf { it in ids }
            val deepLink = startNoteId?.takeIf { it in ids }
            val persisted = savedCenterId?.takeIf { it in ids }
            val seed = deepLink ?: existing ?: persisted ?: vm.graphGroupFirst(groupSize, targetGroup)?.id
            centerStack.clear()
            if (seed != null) centerStack.add(seed)
        }
        graphGroupLoading = false
    }

    // System Back: walk back through the in-graph centered-note history before exiting the screen.
    androidx.activity.compose.BackHandler(enabled = centerStack.size >= 2) {
        centerStack.removeAt(centerStack.size - 1)
    }

    LaunchedEffect(currentCenterId, allowedGraphIds, graphGroupLoading, graphScopeMode) {
        if (graphGroupLoading) return@LaunchedEffect
        // 5K, 10K and the explicit All-articles option are overview graphs now.
        // The legacy focus builder remains available elsewhere but is not used to pretend that a
        // 1°/2° neighbourhood is a complete article group.
        if (groupGraph != null) {
            graph = null
            loading = false
            return@LaunchedEffect
        }
        loading = true
        graph = null
        emptyMessage = null
        val id = currentCenterId
        if (id == null) {
            emptyMessage = "No notes with wikilinks were found in your library yet."
        } else {
            val g = vm.buildFocusGraph(id, allowedGraphIds)
            if (g == null) {
                emptyMessage = "That note isn't in the library anymore."
            } else {
                graph = g
                vm.setWorkspaceGraphCenterId(g.center.id)
                nodeTags = vm.tagsForNotes(
                    buildList {
                        add(g.center.id)
                        addAll(g.firstRing.map { it.note.id })
                        addAll(g.secondRing.map { it.note.id })
                    }
                )
                // Reset view whenever we recentre on a new note
                scale = 1f; offsetX = 0f; offsetY = 0f
                selectedId = null
            }
        }
        loading = false
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Column {
                        Text("\uD83C\uDF10 Focus graph",
                            fontWeight = FontWeight.SemiBold, fontSize = 16.sp)
                        val g = graph
                        val gg = groupGraph
                        if (gg != null) {
                            val scopeLabel = when (graphScopeMode) {
                                "all" -> "All articles"
                                "10k" -> graphGroupLabel(10_000, graphGroupIndex)
                                else -> graphGroupLabel(5_000, graphGroupIndex)
                            }
                            Text(
                                "$scopeLabel · ${gg.nodes.size} articles · ${gg.edges.size} links",
                                maxLines = 1, overflow = TextOverflow.Ellipsis,
                                fontSize = 11.sp,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        } else if (g != null) {
                            Text(
                                "All articles · ${g.center.title}",
                                maxLines = 1, overflow = TextOverflow.Ellipsis,
                                fontSize = 11.sp,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    }
                },
                actions = {
                    val g = graph
                    val gg = groupGraph
                    if (g != null || gg != null) {
                        IconButton(onClick = {
                            nav.navigate("workspacePanes") { launchSingleTop = true }
                        }) { Text("▦", fontSize = 18.sp) }
                    }
                }
            )
        },
        bottomBar = {
            MarkVaultBottomBar(
                nav = nav, vm = vm,
                onBackOverride = {
                    // Walk in-graph history first, then exit to system back
                    if (centerStack.size >= 2) {
                        centerStack.removeAt(centerStack.size - 1)
                    } else {
                        nav.popBackStack()
                    }
                },
                extraActions = {
                    IconButton(onClick = { vm.enterNormalSearchPage(); nav.navigate("search") }) {
                        Icon(Icons.Default.Search, contentDescription = "Search library")
                    }
                    androidx.compose.material3.TextButton(onClick = {
                        vm.setWorkspaceGraphLayout(if (layout == GraphLayout.TREE) "radial" else "tree")
                        scale = 1f; offsetX = 0f; offsetY = 0f
                    }) {
                        Text(if (layout == GraphLayout.TREE) "\uD83C\uDF00" else "\uD83C\uDF33")
                    }
                    IconButton(onClick = { scale = 1f; offsetX = 0f; offsetY = 0f }) {
                        Icon(Icons.Default.Refresh, contentDescription = "Reset view")
                    }
                }
            )
        }
    ) { pad ->
        Box(Modifier.padding(pad).fillMaxSize()) {
            when {
                loading -> Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                    CircularProgressIndicator()
                }
                groupGraph != null -> {
                    val gg = groupGraph!!
                    val filteredNodes = remember(gg, folderFilter, tagFilter, nodeTags) {
                        gg.nodes.filter { node ->
                            (folderFilter.isBlank() || node.folder == folderFilter) &&
                                (tagFilter.isBlank() || nodeTags[node.id].orEmpty().any { it.equals(tagFilter, ignoreCase = true) })
                        }
                    }
                    val visibleIds = remember(filteredNodes) { filteredNodes.mapTo(HashSet(filteredNodes.size)) { it.id } }
                    val filteredGroup = remember(gg, filteredNodes, visibleIds) {
                        GroupGraph(filteredNodes, gg.edges.filter { it.fromId in visibleIds && it.toId in visibleIds })
                    }
                    fun openGroupNode(id: Long, title: String) {
                        graphScope.launch {
                            val fileType = vm.fileTypeOf(id).lowercase()
                            vm.openArticle(id, title, com.tebogo.markvault.OpenSource.GRAPH, fileType)
                            when (fileType) {
                                "pdf" -> nav.navigate("pdfReader/$id")
                                "html", "htm", "mhtml", "mht" -> nav.navigate("htmlReader/$id")
                                "canvas" -> nav.navigate("canvas/$id")
                                else -> nav.navigate("reader") { launchSingleTop = true }
                            }
                        }
                    }
                    GroupOverviewCanvas(
                        graph = filteredGroup,
                        scale = scale, offsetX = offsetX, offsetY = offsetY,
                        selectedId = selectedId,
                        onScaleChange = { s, dx, dy ->
                            scale = (scale * s).coerceIn(0.35f, 80f)
                            offsetX += dx; offsetY += dy
                        },
                        onNodeTap = { id, title ->
                            if (selectedId == id) openGroupNode(id, title) else selectedId = id
                        },
                        onNodeLongPress = { id, title -> openGroupNode(id, title) }
                    )
                }
                emptyMessage != null -> Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                    Text(emptyMessage!!, color = MaterialTheme.colorScheme.onSurfaceVariant,
                        modifier = Modifier.padding(32.dp))
                }
                graph != null -> {
                    val baseGraph = graph!!
                    val filteredFirst = baseGraph.firstRing.filter { n ->
                        val dirOk = when (directionFilter) {
                            "incoming" -> n.dir == LinkDir.INCOMING || n.dir == LinkDir.BOTH
                            "outgoing" -> n.dir == LinkDir.OUTGOING || n.dir == LinkDir.BOTH
                            else -> true
                        }
                        val folderOk = folderFilter.isBlank() || n.note.folder == folderFilter
                        val tagOk = tagFilter.isBlank() ||
                            nodeTags[n.note.id].orEmpty().any { it.equals(tagFilter, ignoreCase = true) }
                        dirOk && folderOk && tagOk
                    }
                    val shownFirstIds = filteredFirst.map { it.note.id }.toSet()
                    val filteredGraph = baseGraph.copy(
                        firstRing = filteredFirst,
                        secondRing = if (graphDepth <= 1) emptyList() else baseGraph.secondRing.filter { edge ->
                            val folderOk = folderFilter.isBlank() || edge.note.folder == folderFilter
                            val tagOk = tagFilter.isBlank() ||
                                nodeTags[edge.note.id].orEmpty().any { it.equals(tagFilter, ignoreCase = true) }
                            edge.viaNoteId in shownFirstIds && folderOk && tagOk
                        }
                    )
                    val onScale: (Float, Float, Float) -> Unit = { s, dx, dy ->
                        scale = (scale * s).coerceIn(0.4f, 3f)
                        offsetX += dx
                        offsetY += dy
                    }
                    fun openGraphNode(id: Long, title: String) {
                        graphScope.launch {
                            val fileType = vm.fileTypeOf(id).lowercase()
                            vm.openArticle(
                                id = id,
                                title = title,
                                fileType = fileType,
                                source = com.tebogo.markvault.OpenSource.GRAPH
                            )
                            when (fileType) {
                                "pdf" -> nav.navigate("pdfReader/$id")
                                "html", "htm", "mhtml", "mht" -> nav.navigate("htmlReader/$id")
                                "canvas" -> nav.navigate("canvas/$id")
                                else -> nav.navigate("reader") { launchSingleTop = true }
                            }
                        }
                    }
                    val onTap: (Long, String) -> Unit = { id, title ->
                        // First tap selects; second tap opens with the actual indexed file type.
                        if (id == filteredGraph.center.id || selectedId == id) {
                            openGraphNode(id, title)
                        } else {
                            selectedId = id
                        }
                    }
                    val onLongPress: (Long, String) -> Unit = { id, _ ->
                        // Long-press still re-centers (clears selection)
                        if (id != filteredGraph.center.id) {
                            selectedId = null
                            centerStack.add(id)
                        }
                    }
                    if (layout == GraphLayout.TREE) {
                        GraphTreeCanvas(
                            graph = filteredGraph,
                            scale = scale, offsetX = offsetX, offsetY = offsetY,
                            selectedId = selectedId,
                            onScaleChange = onScale,
                            onNodeTap = onTap,
                            onNodeLongPress = onLongPress
                        )
                    } else {
                        GraphCanvas(
                            graph = filteredGraph,
                            scale = scale, offsetX = offsetX, offsetY = offsetY,
                            selectedId = selectedId,
                            onScaleChange = onScale,
                            onNodeTap = onTap,
                            onNodeLongPress = onLongPress
                        )
                    }
                }
            }
            if (graph != null || groupGraph != null) {
                val g = graph
                val folders = remember(g, groupGraph) {
                    val source = groupGraph?.nodes?.map { it.folder }
                        ?: if (g != null) (g.firstRing.map { it.note.folder } + g.secondRing.map { it.note.folder })
                        else emptyList()
                    source.filter { it.isNotBlank() }.distinct().sorted().take(100)
                }
                val tags = remember(nodeTags) {
                    nodeTags.values.flatten().distinct().sorted().take(60)
                }
                Row(
                    Modifier.align(Alignment.TopStart).fillMaxWidth()
                        .horizontalScroll(rememberScrollState())
                        .padding(horizontal = 8.dp, vertical = 6.dp),
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    FilterChip(selected = graphScopeMode == "5k", onClick = {
                        vm.setWorkspaceGraphScope("5k")
                        vm.setWorkspaceGraphGroupIndex(0)
                    }, label = { Text("5K") })
                    FilterChip(selected = graphScopeMode == "10k", onClick = {
                        vm.setWorkspaceGraphScope("10k")
                        vm.setWorkspaceGraphGroupIndex(0)
                    }, label = { Text("10K") })
                    FilterChip(selected = graphScopeMode == "all", onClick = {
                        vm.setWorkspaceGraphScope("all")
                        vm.setWorkspaceGraphGroupIndex(0)
                    }, label = { Text("All articles") })
                    val selectedGroupSize = when (graphScopeMode) { "10k" -> 10_000; "5k" -> 5_000; else -> 0 }
                    if (selectedGroupSize > 0) {
                        val groupCount = ((articleCount + selectedGroupSize - 1) / selectedGroupSize).coerceAtLeast(1)
                        Box {
                            androidx.compose.material3.TextButton(onClick = { groupMenu = true }) {
                                val safeIndex = graphGroupIndex.coerceIn(0, groupCount - 1)
                                val start = safeIndex * selectedGroupSize + 1
                                val end = minOf(articleCount, (safeIndex + 1) * selectedGroupSize)
                                Text("${graphGroupLabel(selectedGroupSize, safeIndex)} · $start–$end")
                            }
                            DropdownMenu(expanded = groupMenu, onDismissRequest = { groupMenu = false }) {
                                repeat(groupCount) { idx ->
                                    val start = idx * selectedGroupSize + 1
                                    val end = minOf(articleCount, (idx + 1) * selectedGroupSize)
                                    DropdownMenuItem(
                                        text = { Text("${graphGroupLabel(selectedGroupSize, idx)} · articles $start–$end") },
                                        onClick = {
                                            groupMenu = false
                                            vm.setWorkspaceGraphGroupIndex(idx)
                                        }
                                    )
                                }
                            }
                        }
                    }
                    if (groupGraph == null) {
                    FilterChip(selected = directionFilter == "all", onClick = {
                        vm.setWorkspaceGraphDirection("all")
                    }, label = { Text("All") })
                    FilterChip(selected = directionFilter == "incoming", onClick = {
                        vm.setWorkspaceGraphDirection("incoming")
                    }, label = { Text("Incoming") })
                    FilterChip(selected = directionFilter == "outgoing", onClick = {
                        vm.setWorkspaceGraphDirection("outgoing")
                    }, label = { Text("Outgoing") })
                    FilterChip(selected = graphDepth == 1, onClick = {
                        vm.setWorkspaceGraphDepth(1)
                    }, label = { Text("1°") })
                    FilterChip(selected = graphDepth == 2, onClick = {
                        vm.setWorkspaceGraphDepth(2)
                    }, label = { Text("2°") })
                    }
                    Box {
                        androidx.compose.material3.TextButton(onClick = { folderMenu = true }) {
                            Text(if (folderFilter.isBlank()) "All folders" else folderFilter.substringAfterLast('/'))
                        }
                        DropdownMenu(expanded = folderMenu, onDismissRequest = { folderMenu = false }) {
                            DropdownMenuItem(text = { Text("All folders") }, onClick = {
                                vm.setWorkspaceGraphFolder("")
                                folderMenu = false
                            })
                            folders.forEach { folder ->
                                DropdownMenuItem(text = { Text(folder) }, onClick = {
                                    vm.setWorkspaceGraphFolder(folder)
                                    folderMenu = false
                                })
                            }
                        }
                    }
                    Box {
                        androidx.compose.material3.TextButton(onClick = { tagMenu = true }) {
                            Text(if (tagFilter.isBlank()) "All tags" else "#$tagFilter")
                        }
                        DropdownMenu(expanded = tagMenu, onDismissRequest = { tagMenu = false }) {
                            DropdownMenuItem(text = { Text("All tags") }, onClick = {
                                vm.setWorkspaceGraphTag("")
                                tagMenu = false
                            })
                            tags.forEach { tag ->
                                DropdownMenuItem(text = { Text("#$tag") }, onClick = {
                                    vm.setWorkspaceGraphTag(tag)
                                    tagMenu = false
                                })
                            }
                        }
                    }
                }
                if (graphScopeMode == "all" && g != null) selectedId?.let { id ->
                    val selectedTitle = g.firstRing.firstOrNull { it.note.id == id }?.note?.title
                        ?: g.secondRing.firstOrNull { it.note.id == id }?.note?.title
                    val left = activeReaderTab?.let { aid -> readerTabs.firstOrNull { it.id == aid } }
                    if (selectedTitle != null && left != null && left.id != id) {
                        androidx.compose.material3.TextButton(
                            onClick = {
                                vm.openArticle(id, selectedTitle, com.tebogo.markvault.OpenSource.GRAPH)
                                val rightType = vm.tabs.value.firstOrNull { it.id == id }?.fileType ?: "md"
                                nav.navigate("splitReader/${left.id}/${left.fileType}/$id/$rightType")
                            },
                            modifier = Modifier.align(Alignment.TopEnd).padding(top = 58.dp, end = 10.dp)
                        ) { Text("Open in split") }
                    }
                }
            }

            // Legend overlay (bottom-left)
            graph?.let {
                LegendCard(
                    layout = layout,
                    firstRingShown = it.firstRing.size,
                    firstRingTotal = it.firstRingTotal,
                    secondRingShown = it.secondRing.size,
                    centeredSteps = centerStack.size,
                    modifier = Modifier.align(Alignment.BottomStart).padding(12.dp)
                )
            }
        }
    }
}

@Composable
private fun LegendCard(
    layout: GraphLayout,
    firstRingShown: Int,
    firstRingTotal: Int,
    secondRingShown: Int,
    centeredSteps: Int,
    modifier: Modifier = Modifier
) {
    Surface(
        color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.93f),
        shape = RoundedCornerShape(10.dp),
        modifier = modifier
    ) {
        Column(Modifier.padding(horizontal = 10.dp, vertical = 8.dp)) {
            Text("Tap node \u2192 re-centre", fontSize = 11.sp,
                color = MaterialTheme.colorScheme.onSurfaceVariant)
            Text("Long-press \u2192 open note", fontSize = 11.sp,
                color = MaterialTheme.colorScheme.onSurfaceVariant)
            val zoomHint = if (layout == GraphLayout.RADIAL)
                "Pinch to zoom \u2192 reveal labels"
            else
                "Pinch / drag \u2192 zoom & pan"
            Text(zoomHint, fontSize = 11.sp,
                color = MaterialTheme.colorScheme.onSurfaceVariant)
            Spacer(Modifier.height(4.dp))
            val moreFirst = if (firstRingTotal > firstRingShown) " (+${firstRingTotal - firstRingShown})" else ""
            val back = if (centeredSteps >= 2) "  \u00B7  \u21A9 ${centeredSteps - 1}" else ""
            Text("1\u00B0: $firstRingShown$moreFirst  \u00B7  2\u00B0: $secondRingShown$back",
                fontSize = 11.sp, fontWeight = FontWeight.Medium)
        }
    }
}


/**
 * v5.4.361cc — Obsidian-style relationship graph for complete 5K/10K/All windows.
 *
 * The world layout is derived from the link topology, never from list order: connected components
 * form clusters, high-degree notes become local anchors, and graph-distance/relationship structure
 * determines each node's radius and angle. Rendering is vector/world-coordinate based and uses
 * semantic zoom (level of detail): at overview scale only the most connected landmarks are drawn;
 * as the user zooms, more nodes, then more edges, then collision-free labels are revealed.
 */
private data class OverviewNode(
    val id: Long,
    val title: String,
    val world: Offset,
    val degree: Int,
    val importance: Float,
    val revealAt: Float
)

private data class OverviewLayout(
    val nodes: List<OverviewNode>,
    val byId: Map<Long, OverviewNode>,
    val worldRadius: Float
)

private data class OverviewGeometry(
    val center: Offset,
    val pxPerWorld: Float,
    val visibleNodes: List<OverviewNode>
)

private fun stableUnit(id: Long, salt: Long = 0L): Float {
    var x = id xor salt
    x = (x xor (x ushr 33)) * -49064778989728563L
    x = (x xor (x ushr 33)) * -4265267296055464877L
    x = x xor (x ushr 33)
    return ((x and 0x7fffffffL).toDouble() / 0x7fffffffL.toDouble()).toFloat()
}

/** O(nodes + edges) deterministic force-inspired clustering, suitable for mobile-sized 5K/10K pages. */
private fun buildOverviewLayout(graph: GroupGraph): OverviewLayout {
    val notes = graph.nodes
    if (notes.isEmpty()) return OverviewLayout(emptyList(), emptyMap(), 1f)
    val index = HashMap<Long, Int>(notes.size * 2)
    notes.forEachIndexed { i, n -> index[n.id] = i }
    val adjacency = Array(notes.size) { IntArray(0) }
    val temp = Array(notes.size) { ArrayList<Int>() }
    for (e in graph.edges) {
        val a = index[e.fromId] ?: continue
        val b = index[e.toId] ?: continue
        if (a == b) continue
        temp[a].add(b); temp[b].add(a)
    }
    for (i in temp.indices) adjacency[i] = temp[i].distinct().toIntArray()
    val degree = IntArray(notes.size) { adjacency[it].size }

    // Components are actual relationship islands. Largest/most-connected islands sit nearer center.
    val seen = BooleanArray(notes.size)
    val components = ArrayList<IntArray>()
    for (seed in notes.indices) {
        if (seen[seed]) continue
        val queue = ArrayDeque<Int>()
        val members = ArrayList<Int>()
        queue.add(seed); seen[seed] = true
        while (queue.isNotEmpty()) {
            val v = queue.removeFirst(); members.add(v)
            for (u in adjacency[v]) if (!seen[u]) {
                seen[u] = true
                queue.add(u)
            }
        }
        components.add(members.toIntArray())
    }
    components.sortByDescending { comp -> comp.sumOf { degree[it] + 1 } }

    val positions = Array(notes.size) { Offset.Zero }
    val golden = 2.39996323f
    val compCount = components.size.coerceAtLeast(1)
    components.forEachIndexed { ci, comp ->
        val root = comp.maxByOrNull { degree[it] } ?: comp[0]
        // Component centers themselves follow a round phyllotaxis disc. Relationship islands therefore
        // fill an approximately circular world rather than a square bounding box.
        val compRadius = if (ci == 0) 0f else 2.8f * kotlin.math.sqrt(ci.toFloat())
        val compAngle = ci * golden
        val cc = Offset(kotlin.math.cos(compAngle) * compRadius, kotlin.math.sin(compAngle) * compRadius)

        // BFS graph-distance from the component hub gives relationship-driven rings.
        val dist = HashMap<Int, Int>(comp.size * 2)
        val q = ArrayDeque<Int>()
        dist[root] = 0; q.add(root)
        while (q.isNotEmpty()) {
            val v = q.removeFirst()
            val d = dist[v] ?: 0
            for (u in adjacency[v]) if (u !in dist) { dist[u] = d + 1; q.add(u) }
        }
        val ringBuckets = comp.groupBy { dist[it] ?: 0 }
        positions[root] = cc
        ringBuckets.toSortedMap().forEach { (ring, bucket) ->
            if (ring == 0) return@forEach
            val count = bucket.size.coerceAtLeast(1)
            val baseR = 0.55f + ring * 0.48f + kotlin.math.sqrt(count.toFloat()) * 0.035f
            bucket.sortedWith(compareByDescending<Int> { degree[it] }.thenBy { notes[it].id }).forEachIndexed { bi, v ->
                val jitter = stableUnit(notes[v].id, ring.toLong()) * 0.34f - 0.17f
                val angle = (2f * Math.PI.toFloat() * bi / count) + ring * 0.63f + jitter
                // Higher degree pulls slightly inward, mimicking force-directed attraction.
                val pull = 1f / (1f + kotlin.math.ln((degree[v] + 1).toFloat()) * 0.10f)
                val r = baseR * pull
                positions[v] = cc + Offset(kotlin.math.cos(angle) * r, kotlin.math.sin(angle) * r)
            }
        }
    }

    // One cheap relation-attraction pass pulls linked endpoints together without O(n²) repulsion.
    repeat(4) {
        val delta = Array(notes.size) { Offset.Zero }
        val counts = IntArray(notes.size)
        for (e in graph.edges) {
            val a = index[e.fromId] ?: continue; val b = index[e.toId] ?: continue
            val mid = (positions[a] + positions[b]) * 0.5f
            delta[a] += (mid - positions[a]) * 0.12f
            delta[b] += (mid - positions[b]) * 0.12f
            counts[a]++; counts[b]++
        }
        for (i in positions.indices) if (counts[i] > 0) positions[i] += delta[i] / counts[i].toFloat()
    }

    val maxDegree = degree.maxOrNull()?.coerceAtLeast(1) ?: 1
    val laid = notes.indices.map { i ->
        val d = degree[i]
        val degreeScore = kotlin.math.ln((d + 1).toFloat()) / kotlin.math.ln((maxDegree + 1).toFloat())
        // Isolated/low-degree notes are revealed later; hubs are landmarks at overview scale.
        val reveal = when {
            d >= maxDegree * 0.30f -> 0.55f
            d >= 8 -> 0.75f
            d >= 4 -> 1.0f
            d >= 2 -> 1.35f
            d == 1 -> 1.8f
            else -> 2.6f + stableUnit(notes[i].id, 99L) * 1.8f
        }
        OverviewNode(notes[i].id, notes[i].title, positions[i], d, degreeScore, reveal)
    }
    val radius = laid.maxOfOrNull { kotlin.math.hypot(it.world.x, it.world.y) }?.coerceAtLeast(1f) ?: 1f
    return OverviewLayout(laid, laid.associateBy { it.id }, radius)
}

@Composable
private fun GroupOverviewCanvas(
    graph: GroupGraph,
    scale: Float,
    offsetX: Float,
    offsetY: Float,
    selectedId: Long?,
    onScaleChange: (scale: Float, dx: Float, dy: Float) -> Unit,
    onNodeTap: (id: Long, title: String) -> Unit,
    onNodeLongPress: (id: Long, title: String) -> Unit
) {
    val nodeColor = MaterialTheme.colorScheme.primary
    val selectedColor = MaterialTheme.colorScheme.tertiary
    val edgeColor = MaterialTheme.colorScheme.outline
    val labelColor = MaterialTheme.colorScheme.onSurface
    val backgroundColor = MaterialTheme.colorScheme.background
    val layout = remember(graph.nodes, graph.edges) { buildOverviewLayout(graph) }
    val geometryRef = remember { arrayOfNulls<OverviewGeometry>(1) }

    Canvas(
        Modifier.fillMaxSize().background(backgroundColor)
            .pointerInput(graph.nodes.size, graph.edges.size) {
                detectTransformGestures { centroid, pan, zoom, _ ->
                    // Pinch around the fingers: compensate pan so the world point under the centroid stays put.
                    val z = zoom.coerceIn(0.65f, 1.55f)
                    onScaleChange(z, pan.x + (centroid.x - size.width / 2f) * (1f - z), pan.y + (centroid.y - size.height / 2f) * (1f - z))
                }
            }
            .pointerInput(graph.nodes.size, graph.edges.size, selectedId, scale) {
                detectTapGestures(
                    onTap = { pos -> nearestOverviewNode(pos, geometryRef[0])?.let { onNodeTap(it.id, it.title) } },
                    onLongPress = { pos -> nearestOverviewNode(pos, geometryRef[0])?.let { onNodeLongPress(it.id, it.title) } }
                )
            }
    ) {
        if (layout.nodes.isEmpty()) return@Canvas
        // Initial view fits the complete relationship world inside a circle. Scale thereafter is true
        // world zoom; geometry/text is regenerated every frame, so no bitmap quality is lost.
        val fit = (minOf(size.width, size.height) * 0.43f / layout.worldRadius).coerceAtLeast(0.35f)
        val pxPerWorld = fit * scale
        val center = Offset(size.width / 2f + offsetX, size.height / 2f + offsetY)
        fun screen(n: OverviewNode) = center + n.world * pxPerWorld

        val semanticZoom = scale
        val viewportPad = 32f
        val visible = ArrayList<OverviewNode>()
        for (n in layout.nodes) {
            if (n.revealAt > semanticZoom && n.id != selectedId) continue
            val p = screen(n)
            if (p.x !in -viewportPad..(size.width + viewportPad) || p.y !in -viewportPad..(size.height + viewportPad)) continue
            visible.add(n)
        }
        geometryRef[0] = OverviewGeometry(center, pxPerWorld, visible)
        val visibleIds = visible.mapTo(HashSet(visible.size * 2)) { it.id }

        // Progressive edge detail. At overview only landmark-to-landmark relations are visible; more
        // relationship lines appear naturally as their endpoints are revealed by semantic zoom.
        val edgeAlpha = (0.10f + semanticZoom * 0.035f).coerceIn(0.10f, 0.42f)
        val edgeWidth = (0.55f + semanticZoom * 0.08f).coerceIn(0.55f, 1.7f)
        for (e in graph.edges) {
            if (e.fromId !in visibleIds || e.toId !in visibleIds) continue
            val a = layout.byId[e.fromId] ?: continue; val b = layout.byId[e.toId] ?: continue
            val pa = screen(a); val pb = screen(b)
            drawLine(edgeColor.copy(alpha = edgeAlpha), pa, pb, strokeWidth = edgeWidth)
        }

        for (n in visible) {
            val p = screen(n)
            val base = 1.8f + n.importance * 2.5f
            val radius = (base + kotlin.math.ln((semanticZoom + 1f)) * 0.8f).coerceIn(1.8f, 7.2f)
            if (n.id == selectedId) {
                drawCircle(selectedColor.copy(alpha = 0.22f), radius * 2.5f, p)
                drawCircle(selectedColor, radius * 1.45f, p)
            } else drawCircle(nodeColor.copy(alpha = 0.90f), radius, p)
        }

        // Collision-aware labels: never dump a fixed quota on top of the graph. Candidates are hubs,
        // selected node, then progressively lower-degree notes as zoom creates physical screen space.
        val paint = android.graphics.Paint().apply {
            isAntiAlias = true
            color = android.graphics.Color.argb(
                (labelColor.alpha * 255).toInt(), (labelColor.red * 255).toInt(),
                (labelColor.green * 255).toInt(), (labelColor.blue * 255).toInt()
            )
            textSize = (10.5f + kotlin.math.ln((semanticZoom + 1f).toDouble()).toFloat() * 0.75f).coerceAtMost(13.5f).sp.toPx()
        }
        val occupied = ArrayList<android.graphics.RectF>()
        val labelCandidates = visible.sortedWith(compareByDescending<OverviewNode> { it.id == selectedId }.thenByDescending { it.degree })
        val minLabelZoom = 1.6f
        for (n in labelCandidates) {
            if (n.id != selectedId && semanticZoom < minLabelZoom) continue
            val p = screen(n)
            val title = truncate(n.title, if (semanticZoom > 7f) 42 else 30)
            val textW = paint.measureText(title)
            val fm = paint.fontMetrics
            val textH = fm.descent - fm.ascent
            val gap = 5f
            val rect = android.graphics.RectF(p.x + gap, p.y + fm.ascent - 2f, p.x + gap + textW, p.y + fm.descent + 2f)
            if (rect.left < 0f || rect.right > size.width || rect.top < 0f || rect.bottom > size.height) continue
            if (n.id != selectedId && occupied.any { android.graphics.RectF.intersects(it, rect) }) continue
            drawContext.canvas.nativeCanvas.drawText(title, p.x + gap, p.y, paint)
            occupied.add(rect)
        }
    }
}

private fun nearestOverviewNode(pos: Offset, geometry: OverviewGeometry?): OverviewNode? {
    geometry ?: return null
    var best: OverviewNode? = null
    var bestD = Float.MAX_VALUE
    for (n in geometry.visibleNodes) {
        val p = geometry.center + n.world * geometry.pxPerWorld
        val dx = pos.x - p.x; val dy = pos.y - p.y
        val d = dx * dx + dy * dy
        if (d < bestD) { bestD = d; best = n }
    }
    return if (bestD <= 22f * 22f) best else null
}

@Composable
private fun GraphCanvas(
    graph: FocusGraph,
    scale: Float,
    offsetX: Float,
    offsetY: Float,
    selectedId: Long?,
    onScaleChange: (scale: Float, dx: Float, dy: Float) -> Unit,
    onNodeTap: (id: Long, title: String) -> Unit,
    onNodeLongPress: (id: Long, title: String) -> Unit
) {
    // Style values pulled from the theme; remembered per recomposition.
    val accent = MaterialTheme.colorScheme.primary
    val secondary = MaterialTheme.colorScheme.secondary
    val surfaceVariant = MaterialTheme.colorScheme.surfaceVariant
    val edgeColor = MaterialTheme.colorScheme.outline.copy(alpha = 0.55f)
    val incomingColor = secondary.copy(alpha = 0.75f)
    val outgoingColor = accent.copy(alpha = 0.75f)
    val labelColor = MaterialTheme.colorScheme.onSurface
    val labelDimColor = MaterialTheme.colorScheme.onSurfaceVariant
    val backgroundColor = MaterialTheme.colorScheme.background

    // Hit-test list mutated in place during each draw; gesture callbacks read the latest contents.
    val placedRef = remember { ArrayList<PlacedNode>(48) }

    Canvas(
        modifier = Modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
            .pointerInput(graph.center.id) {
                detectTransformGestures { _, panChange, zoomChange, _ ->
                    onScaleChange(zoomChange, panChange.x, panChange.y)
                }
            }
            .pointerInput(graph.center.id) {
                detectTapGestures(
                    onTap = { pos ->
                        val hit = hitTest(pos, placedRef)
                        if (hit != null) onNodeTap(hit.id, hit.title)
                    },
                    onLongPress = { pos ->
                        val hit = hitTest(pos, placedRef)
                        if (hit != null) onNodeLongPress(hit.id, hit.title)
                    }
                )
            }
    ) {
        val w = size.width
        val h = size.height
        val cx0 = w / 2f + offsetX
        val cy0 = h / 2f + offsetY

        // Ring radii scale with canvas size; pinch-zoom scales everything around the center.
        // Use SEPARATE X/Y radii (elliptical rings) so labels have horizontal breathing room.
        // Phones are taller than wide, so we stretch the X radius and compress the Y radius.
        val sShort = min(w, h)
        val innerRX = (w * 0.32f) * scale
        val innerRY = (sShort * 0.20f) * scale
        val outerRX = (w * 0.42f) * scale
        val outerRY = (sShort * 0.31f) * scale
        val centerNodeR = 26f * scale
        val firstNodeR = 18f * scale
        val secondNodeR = 10f * scale

        // === Compute positions for all nodes ===
        val firstPlaced = ArrayList<PlacedNode>(graph.firstRing.size)
        val first = graph.firstRing
        if (first.isNotEmpty()) {
            val step = (2.0 * Math.PI / first.size).toFloat()
            // Start at top (-PI/2) so the first node sits above the centre
            val start = (-Math.PI / 2.0).toFloat()
            for ((i, n) in first.withIndex()) {
                val a = start + step * i
                val x = cx0 + cos(a) * innerRX
                val y = cy0 + sin(a) * innerRY
                firstPlaced.add(PlacedNode(n.note.id, n.note.title, x, y, firstNodeR, 1, n.dir))
            }
        }
        // Group 2°-ring nodes by their "via" 1°-node, then spread them out near that parent.
        val secondPlaced = ArrayList<PlacedNode>(graph.secondRing.size)
        if (graph.secondRing.isNotEmpty()) {
            val viaToChildren = graph.secondRing.groupBy { it.viaNoteId }
            for (parent in firstPlaced) {
                val kids = viaToChildren[parent.id] ?: continue
                // Angle of parent from centre
                val parentAngle = kotlin.math.atan2(parent.cy - cy0, parent.cx - cx0)
                // Spread kids in a small arc on the far side of the parent
                val spread = (Math.PI / 4.5).toFloat()
                val startAngle = parentAngle - spread / 2f
                val angleStep = if (kids.size > 1) spread / (kids.size - 1) else 0f
                for ((j, e) in kids.withIndex()) {
                    val a = if (kids.size == 1) parentAngle else startAngle + angleStep * j
                    val x = cx0 + cos(a) * outerRX
                    val y = cy0 + sin(a) * outerRY
                    secondPlaced.add(PlacedNode(e.note.id, e.note.title, x, y, secondNodeR, 2))
                }
            }
        }

        // === Draw edges first (so nodes sit on top) ===
        val strokeW = (1.4f * scale).coerceAtLeast(1f)
        for (p in firstPlaced) {
            val color = when (p.dir) {
                LinkDir.OUTGOING -> outgoingColor
                LinkDir.INCOMING -> incomingColor
                LinkDir.BOTH -> outgoingColor
            }
            drawLine(
                color = color,
                start = Offset(cx0, cy0),
                end = Offset(p.cx, p.cy),
                strokeWidth = strokeW
            )
        }
        for (e in graph.secondRing) {
            val parent = firstPlaced.firstOrNull { it.id == e.viaNoteId } ?: continue
            val placedKid = secondPlaced.firstOrNull { it.id == e.note.id } ?: continue
            drawLine(
                color = edgeColor,
                start = Offset(parent.cx, parent.cy),
                end = Offset(placedKid.cx, placedKid.cy),
                strokeWidth = strokeW * 0.7f
            )
        }

        // === Draw nodes ===
        // Center
        drawCircle(color = accent.copy(alpha = 0.25f), radius = centerNodeR + 8f * scale, center = Offset(cx0, cy0))
        drawCircle(color = accent, radius = centerNodeR, center = Offset(cx0, cy0))
        // First ring
        for (p in firstPlaced) {
            val fill = when (p.dir) {
                LinkDir.OUTGOING -> outgoingColor
                LinkDir.INCOMING -> incomingColor
                LinkDir.BOTH -> outgoingColor
            }
            drawCircle(color = surfaceVariant, radius = p.radius + 2f, center = Offset(p.cx, p.cy))
            drawCircle(color = fill, radius = p.radius, center = Offset(p.cx, p.cy))
            drawCircle(color = backgroundColor, radius = p.radius - 4f * scale,
                center = Offset(p.cx, p.cy))
            drawCircle(color = fill.copy(alpha = 1f), radius = p.radius - 4f * scale,
                center = Offset(p.cx, p.cy), style = Stroke(width = 2f * scale))
        }
        // Second ring
        for (p in secondPlaced) {
            drawCircle(color = surfaceVariant, radius = p.radius + 2f, center = Offset(p.cx, p.cy))
            drawCircle(color = labelDimColor.copy(alpha = 0.85f), radius = p.radius, center = Offset(p.cx, p.cy))
        }

        // === Draw labels via native Canvas (drawText on DrawScope needs a TextMeasurer; using nativeCanvas keeps it simple) ===
        // Smaller, lighter fonts than before. Bold only on the centre.
        val labelTextSize = (22f + 6f * scale).coerceIn(22f, 38f)
        val centerTextSize = (26f + 6f * scale).coerceIn(26f, 42f)
        val dimTextSize = (18f + 4f * scale).coerceIn(18f, 30f)
        val paintCenter = android.graphics.Paint().apply {
            isAntiAlias = true
            textSize = centerTextSize
            color = android.graphics.Color.argb(
                (labelColor.alpha * 255).toInt(),
                (labelColor.red * 255).toInt(),
                (labelColor.green * 255).toInt(),
                (labelColor.blue * 255).toInt()
            )
            textAlign = android.graphics.Paint.Align.CENTER
            isFakeBoldText = true
        }
        val paint = android.graphics.Paint(paintCenter).apply {
            textSize = labelTextSize
            isFakeBoldText = false
        }
        val paintDim = android.graphics.Paint(paintCenter).apply {
            textSize = dimTextSize
            isFakeBoldText = false
            color = android.graphics.Color.argb(
                (labelDimColor.alpha * 255).toInt(),
                (labelDimColor.red * 255).toInt(),
                (labelDimColor.green * 255).toInt(),
                (labelDimColor.blue * 255).toInt()
            )
        }
        // Track drawn label rectangles to skip ones that would overlap.
        val drawnRects = ArrayList<FloatArray>(48)
        fun tryDraw(text: String, x: Float, y: Float, p: android.graphics.Paint): Boolean {
            val width = p.measureText(text)
            val height = p.textSize
            // Build the rectangle that this label would occupy. textAlign=CENTER means x is the midpoint.
            val left = x - width / 2f - 4f
            val right = x + width / 2f + 4f
            val top = y - height + 4f
            val bottom = y + 4f
            // Skip off-screen labels entirely
            if (right < 0f || left > w || bottom < 0f || top > h) return false
            // Reject if it overlaps any previously drawn label (with a small padding).
            for (r in drawnRects) {
                if (left < r[2] && right > r[0] && top < r[3] && bottom > r[1]) return false
            }
            drawnRects.add(floatArrayOf(left, top, right, bottom))
            drawContext.canvas.nativeCanvas.drawText(text, x, y, p)
            return true
        }

        // Centre label first (always drawn, claims its rectangle)
        tryDraw(
            truncate(graph.center.title, 22),
            cx0,
            cy0 + centerNodeR + 30f * scale,
            paintCenter
        )
        // First-ring labels: anchor outside the node radially outward; collision-skipped.
        // Shorter truncation than before to reduce overlap risk.
        for (p in firstPlaced) {
            val dx = p.cx - cx0
            val dy = p.cy - cy0
            val len = hypot(dx, dy).coerceAtLeast(0.001f)
            val nx = dx / len; val ny = dy / len
            val tx = p.cx + nx * (p.radius + 16f * scale)
            val ty = p.cy + ny * (p.radius + 16f * scale) + 6f * scale
            tryDraw(truncate(p.title, 14), tx, ty, paint)
        }
        // Second-ring labels: progressively revealed only when zoomed in past 1.3.
        // At default zoom the 2° dots stay unlabelled to keep the view legible.
        if (scale >= 1.3f) {
            for (p in secondPlaced) {
                val dx = p.cx - cx0
                val dy = p.cy - cy0
                val len = hypot(dx, dy).coerceAtLeast(0.001f)
                val nx = dx / len; val ny = dy / len
                val tx = p.cx + nx * (p.radius + 10f * scale)
                val ty = p.cy + ny * (p.radius + 10f * scale) + 4f * scale
                tryDraw(truncate(p.title, 12), tx, ty, paintDim)
            }
        }

        // Update placed list for hit-testing on next gesture
        placedRef.clear()
        placedRef.add(PlacedNode(graph.center.id, graph.center.title, cx0, cy0, centerNodeR, 0))
        placedRef.addAll(firstPlaced)
        placedRef.addAll(secondPlaced)
    }
}

private fun hitTest(pos: Offset, nodes: List<PlacedNode>): PlacedNode? {
    // Reverse order so top-drawn (smaller, later) nodes win when overlapping
    for (i in nodes.indices.reversed()) {
        val n = nodes[i]
        if (n.width > 0f && n.height > 0f) {
            // Rect hit (tree boxes) — slight tap-area enlargement
            val pad = 8f
            val left = n.cx - n.width / 2f - pad
            val right = n.cx + n.width / 2f + pad
            val top = n.cy - n.height / 2f - pad
            val bottom = n.cy + n.height / 2f + pad
            if (pos.x in left..right && pos.y in top..bottom) return n
        } else {
            // Circle hit (radial dots)
            val dx = pos.x - n.cx
            val dy = pos.y - n.cy
            val touchR = n.radius + 14f
            if (dx * dx + dy * dy <= touchR * touchR) return n
        }
    }
    return null
}

private fun truncate(s: String, maxLen: Int): String {
    if (s.length <= maxLen) return s
    return s.take(maxLen - 1).trimEnd() + "\u2026"
}

/** Greedy word-wrap by pixel width (used by the selected-node tooltip). */
private fun wrapText(text: String, paint: android.graphics.Paint, maxWidth: Float): List<String> {
    if (text.isEmpty()) return listOf("")
    if (paint.measureText(text) <= maxWidth) return listOf(text)
    val words = text.split(Regex("\\s+")).filter { it.isNotEmpty() }
    if (words.isEmpty()) return listOf(text)
    val lines = ArrayList<String>()
    val cur = StringBuilder()
    for (w in words) {
        val candidate = if (cur.isEmpty()) w else "$cur $w"
        if (paint.measureText(candidate) <= maxWidth) {
            cur.clear(); cur.append(candidate)
        } else {
            if (cur.isNotEmpty()) {
                lines.add(cur.toString()); cur.clear()
            }
            // Single very long word — hard-break with ellipsis if needed
            if (paint.measureText(w) > maxWidth) {
                var t = w
                while (t.isNotEmpty() && paint.measureText("$t\u2026") > maxWidth) t = t.dropLast(1)
                lines.add(if (t.length < w.length) "$t\u2026" else t)
            } else {
                cur.append(w)
            }
        }
        // Cap at 3 lines max so the tooltip doesn't dominate the screen
        if (lines.size >= 3) break
    }
    if (cur.isNotEmpty() && lines.size < 3) lines.add(cur.toString())
    return lines
}

/**
 * Sugiyama-style hierarchical layout (top-down).
 *  Layer 0: focus note centred at the top.
 *  Layer 1: direct neighbours arranged horizontally, evenly spaced.
 *  Layer 2: 2°-removed notes positioned under their 1° parent in a sub-row.
 * Connections drawn as straight lines with subtle arrow direction.
 * Same gestures, hit-testing, and back navigation as the radial view.
 */
@Composable
private fun GraphTreeCanvas(
    graph: FocusGraph,
    scale: Float,
    offsetX: Float,
    offsetY: Float,
    selectedId: Long?,
    onScaleChange: (scale: Float, dx: Float, dy: Float) -> Unit,
    onNodeTap: (id: Long, title: String) -> Unit,
    onNodeLongPress: (id: Long, title: String) -> Unit
) {
    val accent = MaterialTheme.colorScheme.primary
    val secondary = MaterialTheme.colorScheme.secondary
    val surface = MaterialTheme.colorScheme.surface
    val surfaceVariant = MaterialTheme.colorScheme.surfaceVariant
    val outline = MaterialTheme.colorScheme.outline.copy(alpha = 0.55f)
    val incomingColor = secondary.copy(alpha = 0.85f)
    val outgoingColor = accent.copy(alpha = 0.85f)
    val labelColor = MaterialTheme.colorScheme.onSurface
    val labelDimColor = MaterialTheme.colorScheme.onSurfaceVariant
    val backgroundColor = MaterialTheme.colorScheme.background
    val onAccentColor = MaterialTheme.colorScheme.onPrimary

    val placedRef = remember { ArrayList<PlacedNode>(48) }

    Canvas(
        modifier = Modifier
            .fillMaxSize()
            .background(backgroundColor)
            .pointerInput(graph.center.id) {
                detectTransformGestures { _, panChange, zoomChange, _ ->
                    onScaleChange(zoomChange, panChange.x, panChange.y)
                }
            }
            .pointerInput(graph.center.id) {
                detectTapGestures(
                    onTap = { pos ->
                        val hit = hitTest(pos, placedRef)
                        if (hit != null) onNodeTap(hit.id, hit.title)
                    },
                    onLongPress = { pos ->
                        val hit = hitTest(pos, placedRef)
                        if (hit != null) onNodeLongPress(hit.id, hit.title)
                    }
                )
            }
    ) {
        val w = size.width
        val h = size.height

        // Box dimensions — scale with zoom. The center box is slightly bigger.
        val centerBoxW = 220f * scale
        val centerBoxH = 64f * scale
        val firstBoxW = 180f * scale
        val firstBoxH = 56f * scale
        val secondBoxW = 150f * scale
        val secondBoxH = 46f * scale

        // === Tree layout: focus at top centre, each 1° child gets its own column,
        //     and that child's 2° descendants stack vertically beneath it.
        //     This gives a proper top-down tree shape (parent above, children below). ===
        val topMargin = 60f * scale
        val centerY = topMargin + centerBoxH / 2f + offsetY
        val firstY = centerY + centerBoxH / 2f + 90f * scale + firstBoxH / 2f
        val rowGap2 = 12f * scale  // gap between stacked 2° rows in a column
        val rowH2 = secondBoxH + rowGap2
        val cxRoot = w / 2f + offsetX

        // --- Position 1° children in horizontal columns under the centre ---
        val first = graph.firstRing
        val viaToChildren = graph.secondRing.groupBy { it.viaNoteId }
        val maxChildrenPerParent = 6
        val colGap = 18f * scale
        // Compute column width: must fit both the 1° box and the wider of any 2° kid below
        val colW = maxOf(firstBoxW, secondBoxW) + colGap
        val firstPlaced = ArrayList<PlacedNode>(first.size)
        val secondPlaced = ArrayList<PlacedNode>(graph.secondRing.size)
        val skippedPerParent = HashMap<Long, Int>()
        if (first.isNotEmpty()) {
            val totalW = (first.size - 1) * colW
            val startX = cxRoot - totalW / 2f
            for ((i, n) in first.withIndex()) {
                val colX = startX + i * colW
                firstPlaced.add(
                    PlacedNode(
                        id = n.note.id,
                        title = n.note.title,
                        cx = colX,
                        cy = firstY,
                        radius = 0f,
                        ring = 1,
                        dir = n.dir,
                        width = firstBoxW,
                        height = firstBoxH
                    )
                )
                // Stack this parent's 2° children vertically beneath it (same column)
                val kids = viaToChildren[n.note.id] ?: continue
                val shown = kids.take(maxChildrenPerParent)
                val skipped = kids.size - shown.size
                if (skipped > 0) skippedPerParent[n.note.id] = skipped
                val firstChildY = firstY + firstBoxH / 2f + 60f * scale + secondBoxH / 2f
                for ((j, e) in shown.withIndex()) {
                    val y = firstChildY + j * rowH2
                    secondPlaced.add(
                        PlacedNode(
                            id = e.note.id,
                            title = e.note.title,
                            cx = colX,
                            cy = y,
                            radius = 0f,
                            ring = 2,
                            width = secondBoxW,
                            height = secondBoxH
                        )
                    )
                }
            }
        }

        // --- Draw edges first so boxes sit on top ---
        val strokeW = (2f * scale).coerceAtLeast(1.5f)
        // Centre → 1° edges
        for (p in firstPlaced) {
            val color = when (p.dir) {
                LinkDir.OUTGOING -> outgoingColor
                LinkDir.INCOMING -> incomingColor
                LinkDir.BOTH -> outgoingColor
            }
            drawLine(
                color = color,
                start = Offset(cxRoot, centerY + centerBoxH / 2f),
                end = Offset(p.cx, p.cy - p.height / 2f),
                strokeWidth = strokeW
            )
        }
        // 1° → 2° edges: connect each kid in the column to the one immediately above
        // (parent → kid₁, kid₁ → kid₂, kid₂ → kid₃, …). Gives clean sequential lines.
        for (parent in firstPlaced) {
            val colKids = secondPlaced.filter { kotlin.math.abs(it.cx - parent.cx) < 1f }
                .sortedBy { it.cy }
            var prevBottom = parent.cy + parent.height / 2f
            var prevCx = parent.cx
            for (kid in colKids) {
                drawLine(
                    color = outline,
                    start = Offset(prevCx, prevBottom),
                    end = Offset(kid.cx, kid.cy - kid.height / 2f),
                    strokeWidth = strokeW * 0.7f
                )
                prevBottom = kid.cy + kid.height / 2f
                prevCx = kid.cx
            }
        }

        // --- Draw boxes ---
        // Centre box (accent fill)
        drawRoundRect(
            color = accent,
            topLeft = Offset(cxRoot - centerBoxW / 2f, centerY - centerBoxH / 2f),
            size = androidx.compose.ui.geometry.Size(centerBoxW, centerBoxH),
            cornerRadius = androidx.compose.ui.geometry.CornerRadius(12f * scale, 12f * scale)
        )
        // 1° boxes (surfaceVariant fill, accent or secondary stroke for direction)
        for (p in firstPlaced) {
            val isSel = selectedId == p.id
            val strokeColor = when (p.dir) {
                LinkDir.OUTGOING -> outgoingColor
                LinkDir.INCOMING -> incomingColor
                LinkDir.BOTH -> outgoingColor
            }
            val fillColor = if (isSel) accent.copy(alpha = 0.30f) else surfaceVariant
            drawRoundRect(
                color = fillColor,
                topLeft = Offset(p.cx - p.width / 2f, p.cy - p.height / 2f),
                size = androidx.compose.ui.geometry.Size(p.width, p.height),
                cornerRadius = androidx.compose.ui.geometry.CornerRadius(10f * scale, 10f * scale)
            )
            drawRoundRect(
                color = strokeColor,
                topLeft = Offset(p.cx - p.width / 2f, p.cy - p.height / 2f),
                size = androidx.compose.ui.geometry.Size(p.width, p.height),
                cornerRadius = androidx.compose.ui.geometry.CornerRadius(10f * scale, 10f * scale),
                style = Stroke(width = if (isSel) 3.5f * scale else 2f * scale)
            )
        }
        // 2° boxes (surface fill, dim outline)
        for (p in secondPlaced) {
            val isSel = selectedId == p.id
            val fillColor = if (isSel) accent.copy(alpha = 0.25f) else surface
            val strokeColor = if (isSel) outgoingColor else outline
            drawRoundRect(
                color = fillColor,
                topLeft = Offset(p.cx - p.width / 2f, p.cy - p.height / 2f),
                size = androidx.compose.ui.geometry.Size(p.width, p.height),
                cornerRadius = androidx.compose.ui.geometry.CornerRadius(8f * scale, 8f * scale)
            )
            drawRoundRect(
                color = strokeColor,
                topLeft = Offset(p.cx - p.width / 2f, p.cy - p.height / 2f),
                size = androidx.compose.ui.geometry.Size(p.width, p.height),
                cornerRadius = androidx.compose.ui.geometry.CornerRadius(8f * scale, 8f * scale),
                style = Stroke(width = if (isSel) 3f * scale else 1.5f * scale)
            )
        }

        // --- Draw text inside boxes ---
        val centreTextSize = (20f + 4f * scale).coerceIn(20f, 30f)
        val firstTextSize = (18f + 3f * scale).coerceIn(18f, 26f)
        val secondTextSize = (16f + 2f * scale).coerceIn(16f, 22f)
        val paintCenter = android.graphics.Paint().apply {
            isAntiAlias = true
            textSize = centreTextSize
            color = android.graphics.Color.argb(
                (onAccentColor.alpha * 255).toInt(),
                (onAccentColor.red * 255).toInt(),
                (onAccentColor.green * 255).toInt(),
                (onAccentColor.blue * 255).toInt()
            )
            textAlign = android.graphics.Paint.Align.CENTER
            isFakeBoldText = true
        }
        val paintFirst = android.graphics.Paint(paintCenter).apply {
            textSize = firstTextSize
            isFakeBoldText = false
            color = android.graphics.Color.argb(
                (labelColor.alpha * 255).toInt(),
                (labelColor.red * 255).toInt(),
                (labelColor.green * 255).toInt(),
                (labelColor.blue * 255).toInt()
            )
        }
        val paintSecond = android.graphics.Paint(paintFirst).apply {
            textSize = secondTextSize
            color = android.graphics.Color.argb(
                (labelDimColor.alpha * 255).toInt(),
                (labelDimColor.red * 255).toInt(),
                (labelDimColor.green * 255).toInt(),
                (labelDimColor.blue * 255).toInt()
            )
        }

        fun drawBoxText(text: String, p: android.graphics.Paint, x: Float, y: Float, boxW: Float) {
            // Truncate to fit the box
            var t = text
            while (t.isNotEmpty() && p.measureText(t) > boxW - 16f * scale) {
                t = t.dropLast(1)
            }
            if (t.length < text.length) t = t.dropLast(1) + "\u2026"
            // y given is box centre; offset slightly so the glyph sits visually centred
            val baseline = y + p.textSize * 0.36f
            drawContext.canvas.nativeCanvas.drawText(t, x, baseline, p)
        }

        drawBoxText(graph.center.title, paintCenter, cxRoot, centerY, centerBoxW)
        for (p in firstPlaced) drawBoxText(p.title, paintFirst, p.cx, p.cy, p.width)
        for (p in secondPlaced) drawBoxText(p.title, paintSecond, p.cx, p.cy, p.width)

        // --- Floating tooltip with the FULL title above the selected node ---
        val selected = selectedId?.let { id ->
            firstPlaced.firstOrNull { it.id == id } ?: secondPlaced.firstOrNull { it.id == id }
        }
        if (selected != null) {
            val tipPaint = android.graphics.Paint(paintFirst).apply {
                isFakeBoldText = true
                textSize = (18f + 2f * scale).coerceIn(18f, 26f)
            }
            // Wrap full title across multiple lines so the tooltip stays readable.
            val maxTipWidth = (w * 0.85f).coerceAtMost(540f * scale)
            val lines = wrapText(selected.title, tipPaint, maxTipWidth - 24f * scale)
            val lineH = tipPaint.textSize * 1.25f
            val tipH = lines.size * lineH + 16f * scale
            // Measure widest line
            var tipW = 0f
            for (line in lines) tipW = maxOf(tipW, tipPaint.measureText(line))
            tipW += 24f * scale
            // Position above the selected box; flip below if it would clip the top of the canvas.
            val cx = selected.cx.coerceIn(tipW / 2f + 8f, w - tipW / 2f - 8f)
            val preferTop = selected.cy - selected.height / 2f - 14f * scale - tipH
            val finalTop = if (preferTop < 8f) selected.cy + selected.height / 2f + 14f * scale else preferTop
            // Tooltip background
            drawRoundRect(
                color = accent.copy(alpha = 0.95f),
                topLeft = Offset(cx - tipW / 2f, finalTop),
                size = androidx.compose.ui.geometry.Size(tipW, tipH),
                cornerRadius = androidx.compose.ui.geometry.CornerRadius(10f * scale, 10f * scale)
            )
            // Tooltip text — on-accent colour
            val tipPaintFg = android.graphics.Paint(tipPaint).apply {
                color = android.graphics.Color.argb(
                    (onAccentColor.alpha * 255).toInt(),
                    (onAccentColor.red * 255).toInt(),
                    (onAccentColor.green * 255).toInt(),
                    (onAccentColor.blue * 255).toInt()
                )
            }
            for ((idx, line) in lines.withIndex()) {
                drawContext.canvas.nativeCanvas.drawText(
                    line, cx, finalTop + 8f * scale + lineH * (idx + 0.75f),
                    tipPaintFg
                )
            }
        }

        // "+N more" badge under each column that has hidden children
        if (skippedPerParent.isNotEmpty()) {
            val paintBadge = android.graphics.Paint(paintSecond).apply { textSize = 16f * scale }
            for ((parentId, n) in skippedPerParent) {
                // Find the y of the lowest 2° kid drawn in this parent's column
                val kidsInCol = secondPlaced.filter { it ->
                    // 2° kid's column equals its parent's column (same cx)
                    val parent = firstPlaced.firstOrNull { p -> p.id == parentId }
                    parent != null && kotlin.math.abs(it.cx - parent.cx) < 1f
                }
                val parent = firstPlaced.firstOrNull { it.id == parentId } ?: continue
                val bottomY = if (kidsInCol.isNotEmpty())
                    kidsInCol.maxOf { it.cy + it.height / 2f } else
                    (parent.cy + parent.height / 2f)
                drawContext.canvas.nativeCanvas.drawText(
                    "+$n more",
                    parent.cx,
                    bottomY + 22f * scale,
                    paintBadge
                )
            }
        }

        // Update placed list for hit-testing
        placedRef.clear()
        placedRef.add(
            PlacedNode(
                graph.center.id, graph.center.title,
                cxRoot, centerY, 0f, 0,
                width = centerBoxW, height = centerBoxH
            )
        )
        placedRef.addAll(firstPlaced)
        placedRef.addAll(secondPlaced)
    }
}
