package com.tebogo.markvault.ui

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.gestures.detectTransformGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.nativeCanvas
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.navigation.NavController
import com.tebogo.markvault.AppViewModel
import com.tebogo.markvault.FocusGraph
import com.tebogo.markvault.LinkDir
import kotlin.math.cos
import kotlin.math.hypot
import kotlin.math.min
import kotlin.math.sin

/** Pre-computed screen position + bounds for one node, used for hit-testing.
 *  If [width] > 0 the node is treated as an axis-aligned rectangle (tree view boxes);
 *  otherwise [radius] is used (radial view circles). */
private data class PlacedNode(
    val id: Long,
    val title: String,
    val cx: Float,
    val cy: Float,
    val radius: Float,
    val ring: Int, // 0 = center, 1 = inner ring, 2 = outer ring
    val dir: LinkDir = LinkDir.OUTGOING,
    val width: Float = 0f,
    val height: Float = 0f
)

/** Which layout the graph view is using. */
private enum class GraphLayout { TREE, RADIAL }

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun GraphScreen(vm: AppViewModel, nav: NavController, startNoteId: Long?) {
    // Stack of centered note IDs the user has visited inside this graph view.
    // Top of the stack = currently centered. Lets system Back walk through them before exiting.
    val centerStack = remember { mutableStateListOf<Long>() }
    val currentCenterId: Long? = centerStack.lastOrNull() ?: startNoteId
    var graph by remember { mutableStateOf<FocusGraph?>(null) }
    var loading by remember { mutableStateOf(true) }
    var emptyMessage by remember { mutableStateOf<String?>(null) }

    // Pan / zoom state — survives recompositions and recentre events.
    var scale by remember { mutableStateOf(1f) }
    var offsetX by remember { mutableStateOf(0f) }
    var offsetY by remember { mutableStateOf(0f) }
    var layout by remember { mutableStateOf(GraphLayout.TREE) }
    /** Node currently expanded (first tap). Tap again to open; tap elsewhere to dismiss. */
    var selectedId by remember { mutableStateOf<Long?>(null) }

    // Seed the stack with the starting note (only once)
    LaunchedEffect(Unit) {
        if (centerStack.isEmpty()) {
            val seed = startNoteId ?: vm.mostConnectedNote()?.id
            if (seed != null) centerStack.add(seed)
        }
    }

    // System Back: walk back through the in-graph centered-note history before exiting the screen.
    androidx.activity.compose.BackHandler(enabled = centerStack.size >= 2) {
        centerStack.removeAt(centerStack.size - 1)
    }

    LaunchedEffect(currentCenterId) {
        loading = true
        graph = null
        emptyMessage = null
        val id = currentCenterId
        if (id == null) {
            emptyMessage = "No notes with wikilinks were found in your library yet."
        } else {
            val g = vm.buildFocusGraph(id)
            if (g == null) {
                emptyMessage = "That note isn't in the library anymore."
            } else {
                graph = g
                // Reset view whenever we recentre on a new note
                scale = 1f; offsetX = 0f; offsetY = 0f
                selectedId = null
            }
        }
        loading = false
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Column {
                        Text("\uD83C\uDF10 Focus graph",
                            fontWeight = FontWeight.SemiBold, fontSize = 16.sp)
                        val g = graph
                        if (g != null) {
                            Text(
                                g.center.title,
                                maxLines = 1, overflow = TextOverflow.Ellipsis,
                                fontSize = 11.sp,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    }
                },
                navigationIcon = {
                    IconButton(onClick = {
                        // Same logic as system Back: walk in-graph history first, then exit
                        if (centerStack.size >= 2) {
                            centerStack.removeAt(centerStack.size - 1)
                        } else {
                            nav.popBackStack()
                        }
                    }) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back")
                    }
                },
                actions = {
                    // Quick Home button — escape directly without walking the back stack
                    IconButton(onClick = {
                        nav.navigate("home") {
                            popUpTo("home") { inclusive = false }
                            launchSingleTop = true
                        }
                    }) {
                        Icon(Icons.Default.Home, contentDescription = "Home")
                    }
                    // Layout toggle — labels stay short so they fit the toolbar
                    androidx.compose.material3.TextButton(onClick = {
                        layout = if (layout == GraphLayout.TREE) GraphLayout.RADIAL else GraphLayout.TREE
                        // Reset view when switching layout
                        scale = 1f; offsetX = 0f; offsetY = 0f
                    }) {
                        Text(if (layout == GraphLayout.TREE) "\uD83C\uDF00 Radial" else "\uD83C\uDF33 Tree")
                    }
                    IconButton(onClick = { scale = 1f; offsetX = 0f; offsetY = 0f }) {
                        Icon(Icons.Default.Refresh, contentDescription = "Reset view")
                    }
                }
            )
        }
    ) { pad ->
        Box(Modifier.padding(pad).fillMaxSize()) {
            when {
                loading -> Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                    CircularProgressIndicator()
                }
                emptyMessage != null -> Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                    Text(emptyMessage!!, color = MaterialTheme.colorScheme.onSurfaceVariant,
                        modifier = Modifier.padding(32.dp))
                }
                graph != null -> {
                    val onScale: (Float, Float, Float) -> Unit = { s, dx, dy ->
                        scale = (scale * s).coerceIn(0.4f, 3f)
                        offsetX += dx
                        offsetY += dy
                    }
                    val onTap: (Long, String) -> Unit = { id, title ->
                        // First tap on an unselected node = select it (show full title, tinted).
                        // Second tap on a *selected* node = open it in the Reader.
                        if (id == graph!!.center.id) {
                            // Tapping the centre opens it (long-press would re-center, but it's already centered)
                            vm.openArticle(id, title)
                            nav.navigate("reader")
                        } else if (selectedId == id) {
                            vm.openArticle(id, title)
                            nav.navigate("reader")
                        } else {
                            selectedId = id
                        }
                    }
                    val onLongPress: (Long, String) -> Unit = { id, _ ->
                        // Long-press still re-centers (clears selection)
                        if (id != graph!!.center.id) {
                            selectedId = null
                            centerStack.add(id)
                        }
                    }
                    if (layout == GraphLayout.TREE) {
                        GraphTreeCanvas(
                            graph = graph!!,
                            scale = scale, offsetX = offsetX, offsetY = offsetY,
                            selectedId = selectedId,
                            onScaleChange = onScale,
                            onNodeTap = onTap,
                            onNodeLongPress = onLongPress
                        )
                    } else {
                        GraphCanvas(
                            graph = graph!!,
                            scale = scale, offsetX = offsetX, offsetY = offsetY,
                            selectedId = selectedId,
                            onScaleChange = onScale,
                            onNodeTap = onTap,
                            onNodeLongPress = onLongPress
                        )
                    }
                }
            }
            // Legend overlay (bottom-left)
            graph?.let {
                LegendCard(
                    layout = layout,
                    firstRingShown = it.firstRing.size,
                    firstRingTotal = it.firstRingTotal,
                    secondRingShown = it.secondRing.size,
                    centeredSteps = centerStack.size,
                    modifier = Modifier.align(Alignment.BottomStart).padding(12.dp)
                )
            }
        }
    }
}

@Composable
private fun LegendCard(
    layout: GraphLayout,
    firstRingShown: Int,
    firstRingTotal: Int,
    secondRingShown: Int,
    centeredSteps: Int,
    modifier: Modifier = Modifier
) {
    Surface(
        color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.93f),
        shape = RoundedCornerShape(10.dp),
        modifier = modifier
    ) {
        Column(Modifier.padding(horizontal = 10.dp, vertical = 8.dp)) {
            Text("Tap node \u2192 re-centre", fontSize = 11.sp,
                color = MaterialTheme.colorScheme.onSurfaceVariant)
            Text("Long-press \u2192 open note", fontSize = 11.sp,
                color = MaterialTheme.colorScheme.onSurfaceVariant)
            val zoomHint = if (layout == GraphLayout.RADIAL)
                "Pinch to zoom \u2192 reveal labels"
            else
                "Pinch / drag \u2192 zoom & pan"
            Text(zoomHint, fontSize = 11.sp,
                color = MaterialTheme.colorScheme.onSurfaceVariant)
            Spacer(Modifier.height(4.dp))
            val moreFirst = if (firstRingTotal > firstRingShown) " (+${firstRingTotal - firstRingShown})" else ""
            val back = if (centeredSteps >= 2) "  \u00B7  \u21A9 ${centeredSteps - 1}" else ""
            Text("1\u00B0: $firstRingShown$moreFirst  \u00B7  2\u00B0: $secondRingShown$back",
                fontSize = 11.sp, fontWeight = FontWeight.Medium)
        }
    }
}

@Composable
private fun GraphCanvas(
    graph: FocusGraph,
    scale: Float,
    offsetX: Float,
    offsetY: Float,
    selectedId: Long?,
    onScaleChange: (scale: Float, dx: Float, dy: Float) -> Unit,
    onNodeTap: (id: Long, title: String) -> Unit,
    onNodeLongPress: (id: Long, title: String) -> Unit
) {
    // Style values pulled from the theme; remembered per recomposition.
    val accent = MaterialTheme.colorScheme.primary
    val secondary = MaterialTheme.colorScheme.secondary
    val surfaceVariant = MaterialTheme.colorScheme.surfaceVariant
    val edgeColor = MaterialTheme.colorScheme.outline.copy(alpha = 0.55f)
    val incomingColor = secondary.copy(alpha = 0.75f)
    val outgoingColor = accent.copy(alpha = 0.75f)
    val labelColor = MaterialTheme.colorScheme.onSurface
    val labelDimColor = MaterialTheme.colorScheme.onSurfaceVariant
    val backgroundColor = MaterialTheme.colorScheme.background

    // Hit-test list mutated in place during each draw; gesture callbacks read the latest contents.
    val placedRef = remember { ArrayList<PlacedNode>(48) }

    Canvas(
        modifier = Modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
            .pointerInput(graph.center.id) {
                detectTransformGestures { _, panChange, zoomChange, _ ->
                    onScaleChange(zoomChange, panChange.x, panChange.y)
                }
            }
            .pointerInput(graph.center.id) {
                detectTapGestures(
                    onTap = { pos ->
                        val hit = hitTest(pos, placedRef)
                        if (hit != null) onNodeTap(hit.id, hit.title)
                    },
                    onLongPress = { pos ->
                        val hit = hitTest(pos, placedRef)
                        if (hit != null) onNodeLongPress(hit.id, hit.title)
                    }
                )
            }
    ) {
        val w = size.width
        val h = size.height
        val cx0 = w / 2f + offsetX
        val cy0 = h / 2f + offsetY

        // Ring radii scale with canvas size; pinch-zoom scales everything around the center.
        // Use SEPARATE X/Y radii (elliptical rings) so labels have horizontal breathing room.
        // Phones are taller than wide, so we stretch the X radius and compress the Y radius.
        val sShort = min(w, h)
        val innerRX = (w * 0.32f) * scale
        val innerRY = (sShort * 0.20f) * scale
        val outerRX = (w * 0.42f) * scale
        val outerRY = (sShort * 0.31f) * scale
        val centerNodeR = 26f * scale
        val firstNodeR = 18f * scale
        val secondNodeR = 10f * scale

        // === Compute positions for all nodes ===
        val firstPlaced = ArrayList<PlacedNode>(graph.firstRing.size)
        val first = graph.firstRing
        if (first.isNotEmpty()) {
            val step = (2.0 * Math.PI / first.size).toFloat()
            // Start at top (-PI/2) so the first node sits above the centre
            val start = (-Math.PI / 2.0).toFloat()
            for ((i, n) in first.withIndex()) {
                val a = start + step * i
                val x = cx0 + cos(a) * innerRX
                val y = cy0 + sin(a) * innerRY
                firstPlaced.add(PlacedNode(n.note.id, n.note.title, x, y, firstNodeR, 1, n.dir))
            }
        }
        // Group 2°-ring nodes by their "via" 1°-node, then spread them out near that parent.
        val secondPlaced = ArrayList<PlacedNode>(graph.secondRing.size)
        if (graph.secondRing.isNotEmpty()) {
            val viaToChildren = graph.secondRing.groupBy { it.viaNoteId }
            for (parent in firstPlaced) {
                val kids = viaToChildren[parent.id] ?: continue
                // Angle of parent from centre
                val parentAngle = kotlin.math.atan2(parent.cy - cy0, parent.cx - cx0)
                // Spread kids in a small arc on the far side of the parent
                val spread = (Math.PI / 4.5).toFloat()
                val startAngle = parentAngle - spread / 2f
                val angleStep = if (kids.size > 1) spread / (kids.size - 1) else 0f
                for ((j, e) in kids.withIndex()) {
                    val a = if (kids.size == 1) parentAngle else startAngle + angleStep * j
                    val x = cx0 + cos(a) * outerRX
                    val y = cy0 + sin(a) * outerRY
                    secondPlaced.add(PlacedNode(e.note.id, e.note.title, x, y, secondNodeR, 2))
                }
            }
        }

        // === Draw edges first (so nodes sit on top) ===
        val strokeW = (1.4f * scale).coerceAtLeast(1f)
        for (p in firstPlaced) {
            val color = when (p.dir) {
                LinkDir.OUTGOING -> outgoingColor
                LinkDir.INCOMING -> incomingColor
                LinkDir.BOTH -> outgoingColor
            }
            drawLine(
                color = color,
                start = Offset(cx0, cy0),
                end = Offset(p.cx, p.cy),
                strokeWidth = strokeW
            )
        }
        for (e in graph.secondRing) {
            val parent = firstPlaced.firstOrNull { it.id == e.viaNoteId } ?: continue
            val placedKid = secondPlaced.firstOrNull { it.id == e.note.id } ?: continue
            drawLine(
                color = edgeColor,
                start = Offset(parent.cx, parent.cy),
                end = Offset(placedKid.cx, placedKid.cy),
                strokeWidth = strokeW * 0.7f
            )
        }

        // === Draw nodes ===
        // Center
        drawCircle(color = accent.copy(alpha = 0.25f), radius = centerNodeR + 8f * scale, center = Offset(cx0, cy0))
        drawCircle(color = accent, radius = centerNodeR, center = Offset(cx0, cy0))
        // First ring
        for (p in firstPlaced) {
            val fill = when (p.dir) {
                LinkDir.OUTGOING -> outgoingColor
                LinkDir.INCOMING -> incomingColor
                LinkDir.BOTH -> outgoingColor
            }
            drawCircle(color = surfaceVariant, radius = p.radius + 2f, center = Offset(p.cx, p.cy))
            drawCircle(color = fill, radius = p.radius, center = Offset(p.cx, p.cy))
            drawCircle(color = backgroundColor, radius = p.radius - 4f * scale,
                center = Offset(p.cx, p.cy))
            drawCircle(color = fill.copy(alpha = 1f), radius = p.radius - 4f * scale,
                center = Offset(p.cx, p.cy), style = Stroke(width = 2f * scale))
        }
        // Second ring
        for (p in secondPlaced) {
            drawCircle(color = surfaceVariant, radius = p.radius + 2f, center = Offset(p.cx, p.cy))
            drawCircle(color = labelDimColor.copy(alpha = 0.85f), radius = p.radius, center = Offset(p.cx, p.cy))
        }

        // === Draw labels via native Canvas (drawText on DrawScope needs a TextMeasurer; using nativeCanvas keeps it simple) ===
        // Smaller, lighter fonts than before. Bold only on the centre.
        val labelTextSize = (22f + 6f * scale).coerceIn(22f, 38f)
        val centerTextSize = (26f + 6f * scale).coerceIn(26f, 42f)
        val dimTextSize = (18f + 4f * scale).coerceIn(18f, 30f)
        val paintCenter = android.graphics.Paint().apply {
            isAntiAlias = true
            textSize = centerTextSize
            color = android.graphics.Color.argb(
                (labelColor.alpha * 255).toInt(),
                (labelColor.red * 255).toInt(),
                (labelColor.green * 255).toInt(),
                (labelColor.blue * 255).toInt()
            )
            textAlign = android.graphics.Paint.Align.CENTER
            isFakeBoldText = true
        }
        val paint = android.graphics.Paint(paintCenter).apply {
            textSize = labelTextSize
            isFakeBoldText = false
        }
        val paintDim = android.graphics.Paint(paintCenter).apply {
            textSize = dimTextSize
            isFakeBoldText = false
            color = android.graphics.Color.argb(
                (labelDimColor.alpha * 255).toInt(),
                (labelDimColor.red * 255).toInt(),
                (labelDimColor.green * 255).toInt(),
                (labelDimColor.blue * 255).toInt()
            )
        }
        // Track drawn label rectangles to skip ones that would overlap.
        val drawnRects = ArrayList<FloatArray>(48)
        fun tryDraw(text: String, x: Float, y: Float, p: android.graphics.Paint): Boolean {
            val width = p.measureText(text)
            val height = p.textSize
            // Build the rectangle that this label would occupy. textAlign=CENTER means x is the midpoint.
            val left = x - width / 2f - 4f
            val right = x + width / 2f + 4f
            val top = y - height + 4f
            val bottom = y + 4f
            // Skip off-screen labels entirely
            if (right < 0f || left > w || bottom < 0f || top > h) return false
            // Reject if it overlaps any previously drawn label (with a small padding).
            for (r in drawnRects) {
                if (left < r[2] && right > r[0] && top < r[3] && bottom > r[1]) return false
            }
            drawnRects.add(floatArrayOf(left, top, right, bottom))
            drawContext.canvas.nativeCanvas.drawText(text, x, y, p)
            return true
        }

        // Centre label first (always drawn, claims its rectangle)
        tryDraw(
            truncate(graph.center.title, 22),
            cx0,
            cy0 + centerNodeR + 30f * scale,
            paintCenter
        )
        // First-ring labels: anchor outside the node radially outward; collision-skipped.
        // Shorter truncation than before to reduce overlap risk.
        for (p in firstPlaced) {
            val dx = p.cx - cx0
            val dy = p.cy - cy0
            val len = hypot(dx, dy).coerceAtLeast(0.001f)
            val nx = dx / len; val ny = dy / len
            val tx = p.cx + nx * (p.radius + 16f * scale)
            val ty = p.cy + ny * (p.radius + 16f * scale) + 6f * scale
            tryDraw(truncate(p.title, 14), tx, ty, paint)
        }
        // Second-ring labels: progressively revealed only when zoomed in past 1.3.
        // At default zoom the 2° dots stay unlabelled to keep the view legible.
        if (scale >= 1.3f) {
            for (p in secondPlaced) {
                val dx = p.cx - cx0
                val dy = p.cy - cy0
                val len = hypot(dx, dy).coerceAtLeast(0.001f)
                val nx = dx / len; val ny = dy / len
                val tx = p.cx + nx * (p.radius + 10f * scale)
                val ty = p.cy + ny * (p.radius + 10f * scale) + 4f * scale
                tryDraw(truncate(p.title, 12), tx, ty, paintDim)
            }
        }

        // Update placed list for hit-testing on next gesture
        placedRef.clear()
        placedRef.add(PlacedNode(graph.center.id, graph.center.title, cx0, cy0, centerNodeR, 0))
        placedRef.addAll(firstPlaced)
        placedRef.addAll(secondPlaced)
    }
}

private fun hitTest(pos: Offset, nodes: List<PlacedNode>): PlacedNode? {
    // Reverse order so top-drawn (smaller, later) nodes win when overlapping
    for (i in nodes.indices.reversed()) {
        val n = nodes[i]
        if (n.width > 0f && n.height > 0f) {
            // Rect hit (tree boxes) — slight tap-area enlargement
            val pad = 8f
            val left = n.cx - n.width / 2f - pad
            val right = n.cx + n.width / 2f + pad
            val top = n.cy - n.height / 2f - pad
            val bottom = n.cy + n.height / 2f + pad
            if (pos.x in left..right && pos.y in top..bottom) return n
        } else {
            // Circle hit (radial dots)
            val dx = pos.x - n.cx
            val dy = pos.y - n.cy
            val touchR = n.radius + 14f
            if (dx * dx + dy * dy <= touchR * touchR) return n
        }
    }
    return null
}

private fun truncate(s: String, maxLen: Int): String {
    if (s.length <= maxLen) return s
    return s.take(maxLen - 1).trimEnd() + "\u2026"
}

/** Greedy word-wrap by pixel width (used by the selected-node tooltip). */
private fun wrapText(text: String, paint: android.graphics.Paint, maxWidth: Float): List<String> {
    if (text.isEmpty()) return listOf("")
    if (paint.measureText(text) <= maxWidth) return listOf(text)
    val words = text.split(Regex("\\s+")).filter { it.isNotEmpty() }
    if (words.isEmpty()) return listOf(text)
    val lines = ArrayList<String>()
    val cur = StringBuilder()
    for (w in words) {
        val candidate = if (cur.isEmpty()) w else "$cur $w"
        if (paint.measureText(candidate) <= maxWidth) {
            cur.clear(); cur.append(candidate)
        } else {
            if (cur.isNotEmpty()) {
                lines.add(cur.toString()); cur.clear()
            }
            // Single very long word — hard-break with ellipsis if needed
            if (paint.measureText(w) > maxWidth) {
                var t = w
                while (t.isNotEmpty() && paint.measureText("$t\u2026") > maxWidth) t = t.dropLast(1)
                lines.add(if (t.length < w.length) "$t\u2026" else t)
            } else {
                cur.append(w)
            }
        }
        // Cap at 3 lines max so the tooltip doesn't dominate the screen
        if (lines.size >= 3) break
    }
    if (cur.isNotEmpty() && lines.size < 3) lines.add(cur.toString())
    return lines
}

/**
 * Sugiyama-style hierarchical layout (top-down).
 *  Layer 0: focus note centred at the top.
 *  Layer 1: direct neighbours arranged horizontally, evenly spaced.
 *  Layer 2: 2°-removed notes positioned under their 1° parent in a sub-row.
 * Connections drawn as straight lines with subtle arrow direction.
 * Same gestures, hit-testing, and back navigation as the radial view.
 */
@Composable
private fun GraphTreeCanvas(
    graph: FocusGraph,
    scale: Float,
    offsetX: Float,
    offsetY: Float,
    selectedId: Long?,
    onScaleChange: (scale: Float, dx: Float, dy: Float) -> Unit,
    onNodeTap: (id: Long, title: String) -> Unit,
    onNodeLongPress: (id: Long, title: String) -> Unit
) {
    val accent = MaterialTheme.colorScheme.primary
    val secondary = MaterialTheme.colorScheme.secondary
    val surface = MaterialTheme.colorScheme.surface
    val surfaceVariant = MaterialTheme.colorScheme.surfaceVariant
    val outline = MaterialTheme.colorScheme.outline.copy(alpha = 0.55f)
    val incomingColor = secondary.copy(alpha = 0.85f)
    val outgoingColor = accent.copy(alpha = 0.85f)
    val labelColor = MaterialTheme.colorScheme.onSurface
    val labelDimColor = MaterialTheme.colorScheme.onSurfaceVariant
    val backgroundColor = MaterialTheme.colorScheme.background
    val onAccentColor = MaterialTheme.colorScheme.onPrimary

    val placedRef = remember { ArrayList<PlacedNode>(48) }

    Canvas(
        modifier = Modifier
            .fillMaxSize()
            .background(backgroundColor)
            .pointerInput(graph.center.id) {
                detectTransformGestures { _, panChange, zoomChange, _ ->
                    onScaleChange(zoomChange, panChange.x, panChange.y)
                }
            }
            .pointerInput(graph.center.id) {
                detectTapGestures(
                    onTap = { pos ->
                        val hit = hitTest(pos, placedRef)
                        if (hit != null) onNodeTap(hit.id, hit.title)
                    },
                    onLongPress = { pos ->
                        val hit = hitTest(pos, placedRef)
                        if (hit != null) onNodeLongPress(hit.id, hit.title)
                    }
                )
            }
    ) {
        val w = size.width
        val h = size.height

        // Box dimensions — scale with zoom. The center box is slightly bigger.
        val centerBoxW = 220f * scale
        val centerBoxH = 64f * scale
        val firstBoxW = 180f * scale
        val firstBoxH = 56f * scale
        val secondBoxW = 150f * scale
        val secondBoxH = 46f * scale

        // === Tree layout: focus at top centre, each 1° child gets its own column,
        //     and that child's 2° descendants stack vertically beneath it.
        //     This gives a proper top-down tree shape (parent above, children below). ===
        val topMargin = 60f * scale
        val centerY = topMargin + centerBoxH / 2f + offsetY
        val firstY = centerY + centerBoxH / 2f + 90f * scale + firstBoxH / 2f
        val rowGap2 = 12f * scale  // gap between stacked 2° rows in a column
        val rowH2 = secondBoxH + rowGap2
        val cxRoot = w / 2f + offsetX

        // --- Position 1° children in horizontal columns under the centre ---
        val first = graph.firstRing
        val viaToChildren = graph.secondRing.groupBy { it.viaNoteId }
        val maxChildrenPerParent = 6
        val colGap = 18f * scale
        // Compute column width: must fit both the 1° box and the wider of any 2° kid below
        val colW = maxOf(firstBoxW, secondBoxW) + colGap
        val firstPlaced = ArrayList<PlacedNode>(first.size)
        val secondPlaced = ArrayList<PlacedNode>(graph.secondRing.size)
        val skippedPerParent = HashMap<Long, Int>()
        if (first.isNotEmpty()) {
            val totalW = (first.size - 1) * colW
            val startX = cxRoot - totalW / 2f
            for ((i, n) in first.withIndex()) {
                val colX = startX + i * colW
                firstPlaced.add(
                    PlacedNode(
                        id = n.note.id,
                        title = n.note.title,
                        cx = colX,
                        cy = firstY,
                        radius = 0f,
                        ring = 1,
                        dir = n.dir,
                        width = firstBoxW,
                        height = firstBoxH
                    )
                )
                // Stack this parent's 2° children vertically beneath it (same column)
                val kids = viaToChildren[n.note.id] ?: continue
                val shown = kids.take(maxChildrenPerParent)
                val skipped = kids.size - shown.size
                if (skipped > 0) skippedPerParent[n.note.id] = skipped
                val firstChildY = firstY + firstBoxH / 2f + 60f * scale + secondBoxH / 2f
                for ((j, e) in shown.withIndex()) {
                    val y = firstChildY + j * rowH2
                    secondPlaced.add(
                        PlacedNode(
                            id = e.note.id,
                            title = e.note.title,
                            cx = colX,
                            cy = y,
                            radius = 0f,
                            ring = 2,
                            width = secondBoxW,
                            height = secondBoxH
                        )
                    )
                }
            }
        }

        // --- Draw edges first so boxes sit on top ---
        val strokeW = (2f * scale).coerceAtLeast(1.5f)
        // Centre → 1° edges
        for (p in firstPlaced) {
            val color = when (p.dir) {
                LinkDir.OUTGOING -> outgoingColor
                LinkDir.INCOMING -> incomingColor
                LinkDir.BOTH -> outgoingColor
            }
            drawLine(
                color = color,
                start = Offset(cxRoot, centerY + centerBoxH / 2f),
                end = Offset(p.cx, p.cy - p.height / 2f),
                strokeWidth = strokeW
            )
        }
        // 1° → 2° edges: connect each kid in the column to the one immediately above
        // (parent → kid₁, kid₁ → kid₂, kid₂ → kid₃, …). Gives clean sequential lines.
        for (parent in firstPlaced) {
            val colKids = secondPlaced.filter { kotlin.math.abs(it.cx - parent.cx) < 1f }
                .sortedBy { it.cy }
            var prevBottom = parent.cy + parent.height / 2f
            var prevCx = parent.cx
            for (kid in colKids) {
                drawLine(
                    color = outline,
                    start = Offset(prevCx, prevBottom),
                    end = Offset(kid.cx, kid.cy - kid.height / 2f),
                    strokeWidth = strokeW * 0.7f
                )
                prevBottom = kid.cy + kid.height / 2f
                prevCx = kid.cx
            }
        }

        // --- Draw boxes ---
        // Centre box (accent fill)
        drawRoundRect(
            color = accent,
            topLeft = Offset(cxRoot - centerBoxW / 2f, centerY - centerBoxH / 2f),
            size = androidx.compose.ui.geometry.Size(centerBoxW, centerBoxH),
            cornerRadius = androidx.compose.ui.geometry.CornerRadius(12f * scale, 12f * scale)
        )
        // 1° boxes (surfaceVariant fill, accent or secondary stroke for direction)
        for (p in firstPlaced) {
            val isSel = selectedId == p.id
            val strokeColor = when (p.dir) {
                LinkDir.OUTGOING -> outgoingColor
                LinkDir.INCOMING -> incomingColor
                LinkDir.BOTH -> outgoingColor
            }
            val fillColor = if (isSel) accent.copy(alpha = 0.30f) else surfaceVariant
            drawRoundRect(
                color = fillColor,
                topLeft = Offset(p.cx - p.width / 2f, p.cy - p.height / 2f),
                size = androidx.compose.ui.geometry.Size(p.width, p.height),
                cornerRadius = androidx.compose.ui.geometry.CornerRadius(10f * scale, 10f * scale)
            )
            drawRoundRect(
                color = strokeColor,
                topLeft = Offset(p.cx - p.width / 2f, p.cy - p.height / 2f),
                size = androidx.compose.ui.geometry.Size(p.width, p.height),
                cornerRadius = androidx.compose.ui.geometry.CornerRadius(10f * scale, 10f * scale),
                style = Stroke(width = if (isSel) 3.5f * scale else 2f * scale)
            )
        }
        // 2° boxes (surface fill, dim outline)
        for (p in secondPlaced) {
            val isSel = selectedId == p.id
            val fillColor = if (isSel) accent.copy(alpha = 0.25f) else surface
            val strokeColor = if (isSel) outgoingColor else outline
            drawRoundRect(
                color = fillColor,
                topLeft = Offset(p.cx - p.width / 2f, p.cy - p.height / 2f),
                size = androidx.compose.ui.geometry.Size(p.width, p.height),
                cornerRadius = androidx.compose.ui.geometry.CornerRadius(8f * scale, 8f * scale)
            )
            drawRoundRect(
                color = strokeColor,
                topLeft = Offset(p.cx - p.width / 2f, p.cy - p.height / 2f),
                size = androidx.compose.ui.geometry.Size(p.width, p.height),
                cornerRadius = androidx.compose.ui.geometry.CornerRadius(8f * scale, 8f * scale),
                style = Stroke(width = if (isSel) 3f * scale else 1.5f * scale)
            )
        }

        // --- Draw text inside boxes ---
        val centreTextSize = (20f + 4f * scale).coerceIn(20f, 30f)
        val firstTextSize = (18f + 3f * scale).coerceIn(18f, 26f)
        val secondTextSize = (16f + 2f * scale).coerceIn(16f, 22f)
        val paintCenter = android.graphics.Paint().apply {
            isAntiAlias = true
            textSize = centreTextSize
            color = android.graphics.Color.argb(
                (onAccentColor.alpha * 255).toInt(),
                (onAccentColor.red * 255).toInt(),
                (onAccentColor.green * 255).toInt(),
                (onAccentColor.blue * 255).toInt()
            )
            textAlign = android.graphics.Paint.Align.CENTER
            isFakeBoldText = true
        }
        val paintFirst = android.graphics.Paint(paintCenter).apply {
            textSize = firstTextSize
            isFakeBoldText = false
            color = android.graphics.Color.argb(
                (labelColor.alpha * 255).toInt(),
                (labelColor.red * 255).toInt(),
                (labelColor.green * 255).toInt(),
                (labelColor.blue * 255).toInt()
            )
        }
        val paintSecond = android.graphics.Paint(paintFirst).apply {
            textSize = secondTextSize
            color = android.graphics.Color.argb(
                (labelDimColor.alpha * 255).toInt(),
                (labelDimColor.red * 255).toInt(),
                (labelDimColor.green * 255).toInt(),
                (labelDimColor.blue * 255).toInt()
            )
        }

        fun drawBoxText(text: String, p: android.graphics.Paint, x: Float, y: Float, boxW: Float) {
            // Truncate to fit the box
            var t = text
            while (t.isNotEmpty() && p.measureText(t) > boxW - 16f * scale) {
                t = t.dropLast(1)
            }
            if (t.length < text.length) t = t.dropLast(1) + "\u2026"
            // y given is box centre; offset slightly so the glyph sits visually centred
            val baseline = y + p.textSize * 0.36f
            drawContext.canvas.nativeCanvas.drawText(t, x, baseline, p)
        }

        drawBoxText(graph.center.title, paintCenter, cxRoot, centerY, centerBoxW)
        for (p in firstPlaced) drawBoxText(p.title, paintFirst, p.cx, p.cy, p.width)
        for (p in secondPlaced) drawBoxText(p.title, paintSecond, p.cx, p.cy, p.width)

        // --- Floating tooltip with the FULL title above the selected node ---
        val selected = selectedId?.let { id ->
            firstPlaced.firstOrNull { it.id == id } ?: secondPlaced.firstOrNull { it.id == id }
        }
        if (selected != null) {
            val tipPaint = android.graphics.Paint(paintFirst).apply {
                isFakeBoldText = true
                textSize = (18f + 2f * scale).coerceIn(18f, 26f)
            }
            // Wrap full title across multiple lines so the tooltip stays readable.
            val maxTipWidth = (w * 0.85f).coerceAtMost(540f * scale)
            val lines = wrapText(selected.title, tipPaint, maxTipWidth - 24f * scale)
            val lineH = tipPaint.textSize * 1.25f
            val tipH = lines.size * lineH + 16f * scale
            // Measure widest line
            var tipW = 0f
            for (line in lines) tipW = maxOf(tipW, tipPaint.measureText(line))
            tipW += 24f * scale
            // Position above the selected box; flip below if it would clip the top of the canvas.
            val cx = selected.cx.coerceIn(tipW / 2f + 8f, w - tipW / 2f - 8f)
            val preferTop = selected.cy - selected.height / 2f - 14f * scale - tipH
            val finalTop = if (preferTop < 8f) selected.cy + selected.height / 2f + 14f * scale else preferTop
            // Tooltip background
            drawRoundRect(
                color = accent.copy(alpha = 0.95f),
                topLeft = Offset(cx - tipW / 2f, finalTop),
                size = androidx.compose.ui.geometry.Size(tipW, tipH),
                cornerRadius = androidx.compose.ui.geometry.CornerRadius(10f * scale, 10f * scale)
            )
            // Tooltip text — on-accent colour
            val tipPaintFg = android.graphics.Paint(tipPaint).apply {
                color = android.graphics.Color.argb(
                    (onAccentColor.alpha * 255).toInt(),
                    (onAccentColor.red * 255).toInt(),
                    (onAccentColor.green * 255).toInt(),
                    (onAccentColor.blue * 255).toInt()
                )
            }
            for ((idx, line) in lines.withIndex()) {
                drawContext.canvas.nativeCanvas.drawText(
                    line, cx, finalTop + 8f * scale + lineH * (idx + 0.75f),
                    tipPaintFg
                )
            }
        }

        // "+N more" badge under each column that has hidden children
        if (skippedPerParent.isNotEmpty()) {
            val paintBadge = android.graphics.Paint(paintSecond).apply { textSize = 16f * scale }
            for ((parentId, n) in skippedPerParent) {
                // Find the y of the lowest 2° kid drawn in this parent's column
                val kidsInCol = secondPlaced.filter { it ->
                    // 2° kid's column equals its parent's column (same cx)
                    val parent = firstPlaced.firstOrNull { p -> p.id == parentId }
                    parent != null && kotlin.math.abs(it.cx - parent.cx) < 1f
                }
                val parent = firstPlaced.firstOrNull { it.id == parentId } ?: continue
                val bottomY = if (kidsInCol.isNotEmpty())
                    kidsInCol.maxOf { it.cy + it.height / 2f } else
                    (parent.cy + parent.height / 2f)
                drawContext.canvas.nativeCanvas.drawText(
                    "+$n more",
                    parent.cx,
                    bottomY + 22f * scale,
                    paintBadge
                )
            }
        }

        // Update placed list for hit-testing
        placedRef.clear()
        placedRef.add(
            PlacedNode(
                graph.center.id, graph.center.title,
                cxRoot, centerY, 0f, 0,
                width = centerBoxW, height = centerBoxH
            )
        )
        placedRef.addAll(firstPlaced)
        placedRef.addAll(secondPlaced)
    }
}
