package com.tebogo.markvault.data

/** Database and embeddings are one consistency group; ANN requires that group. */
object BackupSelection {
    const val FILES = 1
    const val DATABASE = 2
    const val ANN = 4
    const val SETTINGS = 8
    const val APP_FILES = 16
    const val ALL = 31
    val choices = listOf(
        FILES to "Library files and folders",
        DATABASE to "Indexed database, article/media embeddings and database history",
        ANN to "IVF / HNSW indexes",
        SETTINGS to "Settings and preferences",
        APP_FILES to "Downloaded AI models and other saved app files"
    )
    fun has(mask: Int, group: Int) = (mask and group) != 0
    fun valid(mask: Int): Boolean = mask in 1..ALL &&
        (!has(mask, DATABASE) || has(mask, FILES)) &&
        (!has(mask, ANN) || has(mask, DATABASE))
    fun toggle(mask: Int, group: Int, enabled: Boolean): Int {
        var next = if (enabled) mask or group else mask and group.inv()
        if (enabled && group == ANN) next = next or DATABASE or FILES
        if (enabled && group == DATABASE) next = next or FILES
        if (!enabled && group == FILES) next = next and (DATABASE or ANN).inv()
        if (!enabled && group == DATABASE) next = next and ANN.inv()
        return next
    }
}
