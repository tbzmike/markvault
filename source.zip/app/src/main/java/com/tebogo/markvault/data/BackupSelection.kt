package com.tebogo.markvault.data

/** Database and embeddings are one consistency group; ANN requires that group. */
object BackupSelection {
    const val FILES = 1
    const val DATABASE = 2
    const val ANN = 4
    const val SETTINGS = 8
    const val APP_FILES = 16
    const val ALL = 31
    val choices = listOf(
        FILES to "Library files and folders",
        DATABASE to "Indexed database, article/media embeddings and database history",
        ANN to "IVF / HNSW indexes",
        SETTINGS to "Settings and preferences",
        APP_FILES to "Downloaded AI models and other saved app files"
    )
    fun has(mask: Int, group: Int) = (mask and group) != 0
    fun valid(mask: Int): Boolean = mask in 1..ALL &&
        (!has(mask, DATABASE) || has(mask, FILES)) &&
        (!has(mask, ANN) || has(mask, DATABASE))
    fun toggle(mask: Int, group: Int, enabled: Boolean): Int {
        var next = if (enabled) mask or group else mask and group.inv()
        if (enabled && group == ANN) next = next or DATABASE or FILES
        if (enabled && group == DATABASE) next = next or FILES
        if (!enabled && group == FILES) next = next and (DATABASE or ANN).inv()
        if (!enabled && group == DATABASE) next = next and ANN.inv()
        return next
    }
}

/** Model asset groups. Embedding rows and ANN snapshots are separate consistency groups.
 * Exact file names match ModelCatalog, RerankerCatalog, ChatModelCatalog and T5 storage. */
object BackupModelSelection {
    data class Group(val flag: Int, val label: String, val paths: Set<String>, val prefix: String? = null)
    val groups = listOf(
        Group(1, "USE Lite", setOf("use_lite_embedder.tflite")),
        Group(2, "MiniLM-L6 embedding", setOf("minilm_l6_v2.onnx", "minilm_l6_v2_vocab.txt")),
        Group(4, "BGE-base embedding", setOf("bge_base_en_v15.onnx", "bge_base_en_v15_vocab.txt")),
        Group(8, "BGE-large embedding", setOf("bge_large_en_v15.onnx", "bge_large_en_v15_vocab.txt")),
        Group(16, "MiniLM-L12 reranker", setOf("ms-marco-minilm-l12-v2.q.onnx", "ms-marco-minilm-l12-v2.vocab.txt")),
        Group(32, "MiniLM-L6 reranker", setOf("ms-marco-minilm-l6-v2.q.onnx", "ms-marco-minilm-l6-v2.vocab.txt")),
        Group(64, "SmolLM2", setOf("smollm2-135m-instruct-q8.litertlm")),
        Group(128, "Gemma 4", setOf("gemma-4-e2b-it.litertlm")),
        Group(256, "T5-base", emptySet(), "models/t5-base/"),
        Group(512, "Other saved app files", emptySet())
    )
    const val OTHER = 512
    const val ALL = 1023
    fun groupFor(entry: String): Int {
        val path = entry.removePrefix("app/files/")
        return groups.firstOrNull { it.flag != OTHER && (path in it.paths || it.prefix?.let(path::startsWith) == true) }?.flag ?: OTHER
    }
    fun includes(mask: Int, entry: String) = mask and groupFor(entry) != 0
    fun valid(mask: Int) = mask in 0..ALL
    fun available(entries: Iterable<String>): Int = entries.filter { it.startsWith("app/files/") }.fold(0) { mask, entry -> mask or groupFor(entry) }
    fun fits(bytes: Long, available: Long, copies: Int = 2): Boolean =
        bytes >= 0 && copies > 0 && bytes <= (available - 32L * 1024 * 1024).coerceAtLeast(0L) / copies
    fun isNoSpace(error: Throwable): Boolean = generateSequence(error) { it.cause }.any {
        if (it.javaClass.simpleName == "SQLiteFullException") return@any true
        val message = it.message.orEmpty().lowercase(java.util.Locale.ROOT)
        message.contains("enospc") || message.contains("no space left") || message.contains("disk full") || message.contains("database or disk is full")
    }
}

/** Internal cooperative cancellation; never fall back to another archive pass. */
class BackupOperationStoppedException : IllegalStateException("Backup/restore stopped at a safe checkpoint")
