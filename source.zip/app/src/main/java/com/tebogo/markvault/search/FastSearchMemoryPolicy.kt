package com.tebogo.markvault.search

/** Existing emergency release remains authoritative; warm reuse needs measured headroom. */
object FastSearchMemoryPolicy {
    private const val MB = 1024L * 1024L

    fun canRetain(
        blueHnsw: Boolean,
        lowRamDevice: Boolean,
        lowMemory: Boolean,
        availableBytes: Long,
        heapUsed: Long,
        heapMax: Long,
        processPssBytes: Long,
        embedderMb: Int,
        rerankerMb: Int
    ): Boolean {
        if (!blueHnsw || lowRamDevice || lowMemory || heapMax <= 0 || heapUsed < 0 ||
            processPssBytes <= 0 || availableBytes <= 0 || embedderMb <= 0 || rerankerMb < 0) return false
        if (heapUsed >= heapMax * 70L / 100L) return false
        val stackMb = embedderMb.toLong() + rerankerMb.toLong()
        val reserveBytes = maxOf(1024L * MB, stackMb * 3L * MB)
        // Include the resident 200k-passage graph in measured PSS. A fixed
        // half-reserve cap would evict healthy BGE sessions on every search.
        return availableBytes >= reserveBytes && processPssBytes < availableBytes
    }
}
