package com.tebogo.markvault.search

/** Existing emergency release remains authoritative; warm reuse needs measured headroom. */
object FastSearchMemoryPolicy {
    private const val MB = 1024L * 1024L

    /** One shared weight set plus a conservative workspace budget per concurrent Run. */
    fun rerankWorkers(
        lowRamDevice: Boolean, lowMemory: Boolean, availableBytes: Long,
        heapUsed: Long, heapMax: Long, embedderMb: Int, rerankerMb: Int,
        loadedSessions: Int, processors: Int
    ): Int {
        if (lowMemory || heapMax <= 0 || heapUsed < 0 || heapUsed >= heapMax * 70L / 100L ||
            availableBytes <= 0 || embedderMb <= 0 || rerankerMb <= 0 || processors <= 0) return 0
        val weights = rerankerMb.toLong() * MB
        val reserve = maxOf(512L * MB, embedderMb.toLong() * 3L * MB)
        val spendable = availableBytes - reserve + loadedSessions.coerceIn(0, 1) * weights
        if (spendable < weights * 2L) return 0
        val workers = ((spendable - weights) / weights).coerceAtMost(4L).toInt()
        return minOf(if (lowRamDevice) 1 else 4, processors, workers)
    }

    fun canRetain(
        blueHnsw: Boolean,
        lowRamDevice: Boolean,
        lowMemory: Boolean,
        availableBytes: Long,
        heapUsed: Long,
        heapMax: Long,
        processPssBytes: Long,
        embedderMb: Int,
        rerankerMb: Int
    ): Boolean {
        if (!blueHnsw || lowRamDevice || lowMemory || heapMax <= 0 || heapUsed < 0 ||
            processPssBytes <= 0 || availableBytes <= 0 || embedderMb <= 0 || rerankerMb < 0) return false
        if (heapUsed >= heapMax * 70L / 100L) return false
        val stackMb = embedderMb.toLong() + rerankerMb.toLong()
        val reserveBytes = maxOf(1024L * MB, stackMb * 3L * MB)
        // Include the resident 200k-passage graph in measured PSS. A fixed
        // half-reserve cap would evict healthy BGE sessions on every search.
        return availableBytes >= reserveBytes && processPssBytes < availableBytes
    }
}
