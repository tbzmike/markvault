package com.tebogo.markvault.update

import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.provider.Settings
import androidx.core.content.FileProvider
import java.io.File
import java.security.MessageDigest

object AppUpdateInstaller {
    data class VerificationResult(
        val valid: Boolean,
        val message: String,
        val versionName: String = "",
        val versionCode: Long = 0L
    )

    fun finalApk(context: Context): File =
        File(AppUpdateManager.updateDirectory(context), AppUpdateDownloadService.FINAL_FILE_NAME)

    fun verifyDownloadedApk(context: Context, apk: File): VerificationResult {
        if (!apk.isFile || apk.length() <= 0L) {
            return VerificationResult(false, "Downloaded APK is missing or empty")
        }
        val pm = context.packageManager
        val flags = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) {
            PackageManager.GET_SIGNING_CERTIFICATES
        } else {
            @Suppress("DEPRECATION")
            PackageManager.GET_SIGNATURES
        }
        val archive = pm.getPackageArchiveInfo(apk.absolutePath, flags)
            ?: return VerificationResult(false, "Android could not read the downloaded APK")
        if (archive.packageName != context.packageName) {
            return VerificationResult(false, "Downloaded APK is not the MarkVault package")
        }
        val installed = try {
            pm.getPackageInfo(context.packageName, flags)
        } catch (_: PackageManager.NameNotFoundException) {
            return VerificationResult(false, "Installed MarkVault package could not be verified")
        }
        val archiveSigners = signerDigests(archive)
        val installedSigners = signerDigests(installed)
        if (archiveSigners.isEmpty() || installedSigners.isEmpty() || archiveSigners.intersect(installedSigners).isEmpty()) {
            return VerificationResult(false, "Downloaded APK signing certificate does not match installed MarkVault")
        }
        val candidateCode = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) {
            archive.longVersionCode
        } else {
            @Suppress("DEPRECATION")
            archive.versionCode.toLong()
        }
        val installedCode = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) {
            installed.longVersionCode
        } else {
            @Suppress("DEPRECATION")
            installed.versionCode.toLong()
        }
        val versionName = archive.versionName.orEmpty()
        if (candidateCode <= installedCode) {
            return VerificationResult(
                false,
                "Release build is not newer than installed MarkVault",
                versionName,
                candidateCode
            )
        }
        return VerificationResult(true, "Verified", versionName, candidateCode)
    }

    fun canRequestPackageInstalls(context: Context): Boolean =
        context.packageManager.canRequestPackageInstalls()

    fun unknownSourcesSettingsIntent(context: Context): Intent =
        Intent(Settings.ACTION_MANAGE_UNKNOWN_APP_SOURCES).apply {
            data = Uri.parse("package:${context.packageName}")
        }

    fun installIntent(context: Context): Intent {
        val apk = finalApk(context)
        val uri = FileProvider.getUriForFile(
            context,
            "${context.packageName}.updates",
            apk
        )
        return Intent(Intent.ACTION_VIEW).apply {
            setDataAndType(uri, "application/vnd.android.package-archive")
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        }
    }

    private fun signerDigests(info: android.content.pm.PackageInfo): Set<String> {
        val signatures = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) {
            val signingInfo = info.signingInfo ?: return emptySet()
            signingInfo.apkContentsSigners.orEmpty().toList()
        } else {
            @Suppress("DEPRECATION")
            info.signatures.orEmpty().toList()
        }
        return signatures.mapTo(linkedSetOf()) { signature ->
            val digest = MessageDigest.getInstance("SHA-256").digest(signature.toByteArray())
            digest.joinToString("") { byte -> "%02x".format(byte) }
        }
    }
}
