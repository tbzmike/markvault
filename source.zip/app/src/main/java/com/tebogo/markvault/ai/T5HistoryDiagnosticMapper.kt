package com.tebogo.markvault.ai

object T5HistoryDiagnosticMapper {
    fun fromTrace(trace: T5QueryTrace): T5HistoryDiagnosticEntry {
        return T5HistoryDiagnosticEntry(
            trace.mode,
            trace.generatedQueries,
            trace.inferenceTimeMs,
            trace.fallbackReason
        )
    }
}
