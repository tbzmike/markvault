package com.tebogo.markvault.ui

import androidx.activity.compose.BackHandler
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Alignment
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.tebogo.markvault.AppViewModel
import com.tebogo.markvault.data.MediaItem
import com.tebogo.markvault.data.Prefs
import com.tebogo.markvault.network.JwCategory
import com.tebogo.markvault.network.JwMediaApi
import com.tebogo.markvault.network.JwMediaLanguage
import kotlinx.coroutines.launch
import kotlinx.coroutines.delay

/**
 * v5.4.232cc — Dedicated JW.org video browse + search screen.
 *
 * Changes from v5.4.225cc:
 *   • Categories now show their SUBCATEGORIES too (JW.org's library is
 *     hierarchical — most "folders" hold mostly subcategories, not direct
 *     media, which is why they previously appeared empty).
 *   • categoryBackStack tracks how deep we've drilled in, so both the
 *     on-screen "← Categories" button and the system back button pop ONE
 *     level at a time instead of exiting the whole screen.
 *   • BackHandler intercepts system back: clears search first, then pops
 *     one category level, and only lets the screen close once already at
 *     the top with nothing to unwind.
 *
 * v5.4.251cc — Folder-scoped search + offline caching:
 *   • Searching while INSIDE a folder (selectedCat != null) now calls
 *     JwMediaApi.searchInCategory(selectedCat.key, ...) — confined to that
 *     folder's own media plus every subfolder beneath it — instead of the
 *     global search. Global search (JwMediaApi.search) is used ONLY on
 *     the root/main page (selectedCat == null); everywhere a folder is
 *     open, search stays confined to that folder's subtree.
 *   • selectedCat / categoryBackStack are no longer cleared when a
 *     folder-scoped search runs — the user stays "inside" the folder
 *     while its contents are filtered, and the breadcrumb ("← Back" +
 *     folder name) stays visible throughout.
 *   • Both category browsing (loadCategoryContents) and searching
 *     (doSearch) now feed every result into the shared offline media
 *     cache via vm.cacheMediaItems() — the same media_items table
 *     MarkVault's global search (SearchScreen) reads offline-first via
 *     vm.searchMedia(). One shared index, fed from every place media is
 *     browsed or searched, not a separate parallel cache.
 *
 * v5.4.255cc — Continuous play + multi-select:
 *   • Tapping a media item now calls vm.playMediaFromList(item,
 *     contextList) instead of a bare single-item play — when Continuous
 *     Play is on (default), the REST of whichever list the tap came from
 *     (search results / category items / recently played) queues too, so
 *     playback continues automatically. Media3's Player handles the
 *     actual auto-advance on its own once a multi-item queue is loaded —
 *     nothing here has to detect "finished" and load the next item.
 *   • Long-press on any card enters multi-select mode (checkbox overlay,
 *     top bar swaps to a "N selected" / Add to Playlist bar) — "the
 *     standard media browser" multi-select multi-selection Tebogo asked
 *     for. Favouriting stays on the star icon each card already has;
 *     select mode is specifically for batch "Add to Playlist."
 */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun JwVideoBrowseScreen(vm: AppViewModel, nav: androidx.navigation.NavController) {
    var query            by remember { mutableStateOf("") }
    var isSearching      by remember { mutableStateOf(false) }
    var searchGeneration by remember { mutableIntStateOf(0) }
    var searchResults    by remember { mutableStateOf<List<MediaItem>>(emptyList()) }
    var categories       by remember { mutableStateOf<List<JwCategory>>(emptyList()) }
    var selectedCat      by remember { mutableStateOf<JwCategory?>(null) }
    var catItems         by remember { mutableStateOf<List<MediaItem>>(emptyList()) }
    var catSubcategories by remember { mutableStateOf<List<JwCategory>>(emptyList()) }
    var isCatLoading     by remember { mutableStateOf(false) }
    // v5.4.232cc — Breadcrumb of categories drilled into, deepest last.
    var categoryBackStack by remember { mutableStateOf<List<JwCategory>>(emptyList()) }
    val mediaListState = rememberLazyListState()
    var categoryScrollBackStack by remember { mutableStateOf<List<Pair<Int, Int>>>(emptyList()) }
    var pendingMediaScrollRestore by remember { mutableStateOf<Pair<Int, Int>?>(null) }
    val scope         = rememberCoroutineScope()
    val nowPlaying    by vm.nowPlayingMedia.collectAsStateWithLifecycle()
    val androidAutoConnected by vm.androidAutoConnected.collectAsStateWithLifecycle()
    val mediaContext = LocalContext.current
    val mediaPrefs = remember(mediaContext) { Prefs(mediaContext.applicationContext) }
    val globalMediaLanguage by mediaPrefs.mediaLibraryLanguage.collectAsState(initial = "E")
    val searchAsYouType by vm.mediaSearchAsYouType.collectAsStateWithLifecycle()
    val recentMediaLanguages by mediaPrefs.mediaRecentLanguages.collectAsState(initial = emptyList())
    val folderLanguageRaw by mediaPrefs.mediaFolderLanguagesRaw.collectAsState(initial = "{}")
    val folderLanguages = remember(folderLanguageRaw) {
        runCatching {
            val obj = org.json.JSONObject(folderLanguageRaw)
            buildMap<String, String> {
                val keys = obj.keys()
                while (keys.hasNext()) {
                    val key = keys.next()
                    obj.optString(key).takeIf { it.isNotBlank() }?.let { put(key, it) }
                }
            }
        }.getOrDefault(emptyMap())
    }
    var availableLanguages by remember { mutableStateOf(listOf(JwMediaLanguage("E", "English", "English"))) }
    var languagePickerTarget by remember { mutableStateOf<String?>(null) } // __GLOBAL__ or category key
    var languageSearch by remember { mutableStateOf("") }
    val mediaScreenWidthDp = androidx.compose.ui.platform.LocalConfiguration.current.screenWidthDp
    val mediaUiMode by vm.uiMode.collectAsStateWithLifecycle()
    val forceTabletUi by vm.forceWorkspaceTabletUi.collectAsStateWithLifecycle()
    val mediaTabletWorkspace = mediaUiMode == "workspace" && (mediaScreenWidthDp >= 600 || forceTabletUi)
    var mediaGridView by rememberSaveable { mutableStateOf(true) }
    // v5.4.325cc — Grid/List are explicit Media Library views. Grid cards are
    // intentionally smaller than the previous oversized two-column posters.
    val mediaGridColumns = when {
        mediaScreenWidthDp >= 1200 -> 4
        mediaScreenWidthDp >= 600 -> 3
        mediaTabletWorkspace && mediaScreenWidthDp >= 480 -> 2
        mediaTabletWorkspace -> 1
        else -> 2
    }
    // v5.4.297cc — Media browser ordering. Audio defaults to song number;
    // video/mixed folders default to JW publish/upload date (newest first).
    var audioSortMode by rememberSaveable { mutableStateOf(MediaBrowseSort.SONG_NUMBER) }

    // v5.4.255cc — Multi-select state: long-press any card to enter,
    // tap toggles selection while active, "Add to Playlist" batch-adds.
    var isSelectMode by remember { mutableStateOf(false) }
    var selectedItems by remember { mutableStateOf<Set<MediaItem>>(emptySet()) }
    var showPlaylistPicker by remember { mutableStateOf(false) }

    fun enterSelectMode(first: MediaItem) {
        isSelectMode = true
        selectedItems = setOf(first)
    }
    fun toggleSelected(item: MediaItem) {
        selectedItems = if (item in selectedItems) selectedItems - item else selectedItems + item
        if (selectedItems.isEmpty()) isSelectMode = false
    }
    fun exitSelectMode() {
        isSelectMode = false
        selectedItems = emptySet()
    }

    fun effectiveLanguageFor(categoryKey: String? = selectedCat?.key): String {
        if (!categoryKey.isNullOrBlank()) folderLanguages[categoryKey]?.let { return it }
        for (ancestor in categoryBackStack.asReversed()) {
            folderLanguages[ancestor.key]?.let { return it }
        }
        return globalMediaLanguage.ifBlank { "E" }
    }

    fun parentLanguageFor(categoryKey: String): String {
        for (ancestor in categoryBackStack.asReversed()) {
            if (ancestor.key != categoryKey) folderLanguages[ancestor.key]?.let { return it }
        }
        return globalMediaLanguage.ifBlank { "E" }
    }

    fun persistFolderLanguage(categoryKey: String, language: String?) {
        scope.launch {
            val obj = runCatching { org.json.JSONObject(folderLanguageRaw) }.getOrElse { org.json.JSONObject() }
            if (language.isNullOrBlank()) obj.remove(categoryKey) else obj.put(categoryKey, language)
            mediaPrefs.setMediaFolderLanguagesRaw(obj.toString())
        }
    }

    LaunchedEffect(globalMediaLanguage) {
        isCatLoading = true
        query = ""
        searchResults = emptyList()
        selectedCat = null
        categoryBackStack = emptyList()
        catItems = emptyList()
        catSubcategories = emptyList()
        val loaded = kotlinx.coroutines.withContext(kotlinx.coroutines.Dispatchers.IO) {
            val langs = runCatching { JwMediaApi.languages(globalMediaLanguage) }.getOrElse { emptyList() }
            val cats = runCatching { JwMediaApi.topCategories(globalMediaLanguage) }.getOrElse { emptyList() }
            langs to cats
        }
        if (loaded.first.isNotEmpty()) availableLanguages = loaded.first
        categories = loaded.second
        isCatLoading = false
        vm.loadRecentlyPlayed()
    }
    val recentlyPlayed by vm.recentlyPlayedMedia.collectAsStateWithLifecycle()

    // v5.4.251cc — Folder-scoped search: global search applies ONLY on
    // the root/main page (selectedCat == null); searching while a folder
    // is open stays confined to that folder + everything beneath it via
    // searchInCategory, which crawls the full subtree. selectedCat and
    // categoryBackStack are deliberately left untouched here so the user
    // stays "inside" the folder — the breadcrumb and Back button remain
    // visible the whole time a folder-scoped search is active.
    fun doSearch() {
        val requested = query.trim()
        if (requested.length < 2) {
            searchGeneration++
            searchResults = emptyList()
            isSearching = false
            return
        }
        val generation = ++searchGeneration
        isSearching = true
        val scopedCat = selectedCat
        if (scopedCat == null) {
            catItems = emptyList()
            catSubcategories = emptyList()
            categoryBackStack = emptyList()
        }
        scope.launch {
            val language = if (scopedCat != null) effectiveLanguageFor(scopedCat.key) else globalMediaLanguage

            // v5.4.388cc — Local captions are the first search tier. At root they
            // render immediately, before any network request, so downloaded CC
            // search never waits for JW.org. Matching is case-insensitive in
            // VideoTranscriptStore.normalize().
            val captionResults = kotlinx.coroutines.withContext(kotlinx.coroutines.Dispatchers.IO) {
                vm.searchVideoTranscripts(requested, language = language, limit = 60)
            }
            if (generation != searchGeneration || query.trim() != requested) return@launch
            if (scopedCat == null) {
                searchResults = captionResults
                if (captionResults.isNotEmpty()) isSearching = false
            }

            val networkResults = kotlinx.coroutines.withContext(kotlinx.coroutines.Dispatchers.IO) {
                runCatching {
                    if (scopedCat != null) {
                        JwMediaApi.searchInCategory(
                            scopedCat.key, requested, limit = 60, language = language,
                            includeJwKeys = captionResults.mapNotNull { it.jwKey.takeIf(String::isNotBlank) }.toSet()
                        )
                    } else {
                        JwMediaApi.search(requested, limit = 60, language = language)
                    }
                }.getOrElse { emptyList() }
            }
            if (generation != searchGeneration || query.trim() != requested) return@launch

            val allowedCaptionKeys: Set<String>? = if (scopedCat != null) {
                networkResults.mapNotNull { it.jwKey.takeIf(String::isNotBlank) }.toSet()
            } else null
            val merged = LinkedHashMap<String, MediaItem>()
            captionResults.forEach { item ->
                if (allowedCaptionKeys == null || item.jwKey in allowedCaptionKeys) {
                    merged.putIfAbsent(item.jwKey.ifBlank { "id:${item.id}" }, item)
                }
            }
            networkResults.forEach { item ->
                merged.putIfAbsent(item.jwKey.ifBlank { "id:${item.id}" }, item)
            }
            val all = merged.values.toList()
            val captionHits = all.filter {
                it.description.startsWith(com.tebogo.markvault.data.VideoTranscriptStore.RESULT_PREFIX)
            }
            val ordinary = all.filterNot {
                it.description.startsWith(com.tebogo.markvault.data.VideoTranscriptStore.RESULT_PREFIX)
            }
            searchResults = captionHits + if (ordinary.isNotEmpty() && ordinary.all { it.mediaType.equals("audio", true) })
                sortMediaForBrowse(ordinary, audioSortMode) else ordinary.sortedByDescending { it.uploadDate }
            isSearching = false
            if (networkResults.isNotEmpty()) vm.cacheMediaItems(networkResults)
        }
    }

    fun loadCategoryContents(cat: JwCategory, forcedLanguage: String? = null) {
        selectedCat = cat
        catItems = emptyList()
        catSubcategories = emptyList()
        isCatLoading = true
        scope.launch {
            val detail = kotlinx.coroutines.withContext(kotlinx.coroutines.Dispatchers.IO) {
                runCatching { JwMediaApi.categoryDetail(cat.key, forcedLanguage ?: effectiveLanguageFor(cat.key)) }.getOrNull()
            }
            catItems = detail?.media ?: emptyList()
            catSubcategories = detail?.subcategories ?: emptyList()
            isCatLoading = false
            // v5.4.251cc — Same offline-cache feed as doSearch() above:
            // every folder browsed also becomes searchable later without
            // network, not just explicit search hits.
            if (catItems.isNotEmpty()) vm.cacheMediaItems(catItems)
        }
    }

    fun openCategory(cat: JwCategory) {
        categoryScrollBackStack = categoryScrollBackStack +
            (mediaListState.firstVisibleItemIndex to mediaListState.firstVisibleItemScrollOffset)
        categoryBackStack = categoryBackStack + cat
        loadCategoryContents(cat)
    }

    fun goBackOneCategory() {
        if (categoryBackStack.isEmpty()) return
        pendingMediaScrollRestore = categoryScrollBackStack.lastOrNull() ?: (0 to 0)
        categoryScrollBackStack = categoryScrollBackStack.dropLast(1)
        categoryBackStack = categoryBackStack.dropLast(1)
        val prev = categoryBackStack.lastOrNull()
        if (prev != null) {
            loadCategoryContents(prev)
        } else {
            selectedCat = null
            catItems = emptyList()
            catSubcategories = emptyList()
        }
    }

    LaunchedEffect(selectedCat?.key, isCatLoading, pendingMediaScrollRestore) {
        if (!isCatLoading) {
            pendingMediaScrollRestore?.let { (index, offset) ->
                mediaListState.scrollToItem(index.coerceAtLeast(0), offset.coerceAtLeast(0))
                pendingMediaScrollRestore = null
            }
        }
    }

    // v5.4.232cc — Layered back handling: clear search first, then pop one
    // category level, only exiting the screen once both are empty.
    // v5.4.255cc — Exiting select mode takes priority over both.
    BackHandler(
        enabled = isSelectMode || query.isNotBlank() || searchResults.isNotEmpty() || categoryBackStack.isNotEmpty()
    ) {
        when {
            isSelectMode -> exitSelectMode()
            query.isNotBlank() || searchResults.isNotEmpty() -> {
                query = ""
                searchResults = emptyList()
            }
            categoryBackStack.isNotEmpty() -> goBackOneCategory()
        }
    }

    // v5.4.233cc — Playback now routes through the shared PlaybackService
    // controller, so audio/video survives navigating away from this
    // screen or backgrounding the app entirely. Memory clearing on
    // navigation is now handled globally (MainActivity's destination
    // listener), so no per-screen delay-then-navigate dance is needed here.
    //
    // v5.4.255cc — playFromList routes through vm.playMediaFromList so
    // Continuous Play (when on) queues the rest of whichever list the tap
    // came from, instead of always playing just the one tapped item.
    fun playFromList(item: MediaItem, contextList: List<MediaItem>) {
        vm.playMediaFromList(item, contextList)
        nav.navigate("mediaPlayer/0") { launchSingleTop = true }
    }

    // v5.4.388cc — Configurable live search. Debounce prevents a network call
    // for every key event while still making local caption hits feel immediate.
    LaunchedEffect(query, searchAsYouType, selectedCat?.key, globalMediaLanguage) {
        if (!searchAsYouType) return@LaunchedEffect
        val q = query.trim()
        if (q.length < 2) {
            searchGeneration++
            searchResults = emptyList()
            isSearching = false
            return@LaunchedEffect
        }
        delay(180L)
        if (query.trim() == q) doSearch()
    }

    Scaffold(
        // v5.4.354cc — This screen is already hosted inside WorkspaceTabletShell,
        // which owns the system/status-bar insets. Keeping Scaffold's default
        // safeDrawing inset here caused a second inset/measurement pass in
        // forced-tablet Workspace mode and contributed to a large empty band
        // above the actual Media Library content. The phone top/bottom bars
        // still contribute their own measured content padding normally.
        contentWindowInsets = WindowInsets(0, 0, 0, 0),
        topBar = {
            if (!mediaTabletWorkspace && isSelectMode) {
                TopAppBar(
                    title = { Text("${selectedItems.size} selected") },
                    navigationIcon = {
                        IconButton(onClick = { exitSelectMode() }) {
                            Text("\u2715", fontSize = 18.sp)
                        }
                    },
                    actions = {
                        TextButton(
                            onClick = { showPlaylistPicker = true },
                            enabled = selectedItems.isNotEmpty()
                        ) { Text("Add to Playlist") }
                    }
                )
            } else if (!mediaTabletWorkspace) {
                TopAppBar(
                    title = { Text("\uD83C\uDFA5 JW.org Videos") },
                    navigationIcon = {
                        IconButton(onClick = { if (categoryBackStack.isNotEmpty()) goBackOneCategory() else nav.popBackStack() }) {
                            Icon(Icons.Default.ArrowBack, contentDescription = "Back")
                        }
                    },
                    actions = {
                        TextButton(onClick = { languagePickerTarget = "__GLOBAL__"; languageSearch = "" }) {
                            Text("🌐 ${globalMediaLanguage}", fontSize = 12.sp)
                        }
                        IconButton(onClick = { nav.navigate("playlists") }) {
                            Text("\uD83C\uDFB5", fontSize = 18.sp)
                        }
                    }
                )
            }
        },
        bottomBar = { if (!mediaTabletWorkspace) MarkVaultBottomBar(nav = nav, vm = vm, onBackOverride = { if (categoryBackStack.isNotEmpty()) goBackOneCategory() else nav.popBackStack() }) }
    ) { pad ->
        Column(modifier = Modifier.fillMaxSize().padding(pad)) {
            if (mediaTabletWorkspace) {
                // v5.4.354cc — Keep this a true compact toolbar. On forced-tablet
                // Workspace layouts the segmented control could otherwise cause
                // the parent Row to consume a large share of the available height,
                // visually centring the toolbar hundreds of pixels below the top.
                Row(
                    Modifier
                        .fillMaxWidth()
                        .heightIn(min = 44.dp, max = 52.dp)
                        .padding(horizontal = 8.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    TextButton(onClick = { if (categoryBackStack.isNotEmpty()) goBackOneCategory() else nav.popBackStack() }) { Text("←", fontSize = 17.sp) }
                    Text("🎬 Media Library", fontSize = 17.sp, fontWeight = FontWeight.Bold)
                    Spacer(Modifier.weight(1f))
                    TextButton(onClick = { languagePickerTarget = "__GLOBAL__"; languageSearch = "" }) {
                        Text("🌐 ${availableLanguages.firstOrNull { it.code == globalMediaLanguage }?.nativeName ?: globalMediaLanguage}", fontSize = 11.sp)
                    }
                    if (isSelectMode) {
                        TextButton(onClick = { exitSelectMode() }) { Text("${selectedItems.size} selected · Cancel") }
                        TextButton(onClick = { showPlaylistPicker = true }, enabled = selectedItems.isNotEmpty()) { Text("Add to Playlist") }
                    }
                    SingleChoiceSegmentedButtonRow(
                        modifier = Modifier.heightIn(max = 40.dp)
                    ) {
                        SegmentedButton(
                            selected = !mediaGridView,
                            onClick = { mediaGridView = false },
                            shape = SegmentedButtonDefaults.itemShape(index = 0, count = 2),
                            label = { Text("☷ List", fontSize = 11.sp) }
                        )
                        SegmentedButton(
                            selected = mediaGridView,
                            onClick = { mediaGridView = true },
                            shape = SegmentedButtonDefaults.itemShape(index = 1, count = 2),
                            label = { Text("▦ Grid", fontSize = 11.sp) }
                        )
                    }
                    TextButton(onClick = { nav.navigate("playlists") }) { Text("🎵 Playlists") }
                }
                HorizontalDivider()
            }
            OutlinedTextField(
                value = query, onValueChange = { query = it },
                // v5.4.251cc — Context-aware placeholder: makes the
                // folder-scoped search mode visible, not just functional.
                placeholder = {
                    Text(
                        selectedCat?.let { "Search in \u201C${it.name}\u201D\u2026" }
                            ?: "Search JW.org videos\u2026"
                    )
                },
                trailingIcon = {
                    IconButton(onClick = { doSearch() }) {
                        Icon(Icons.Default.Search, contentDescription = "Search")
                    }
                },
                singleLine = true,
                keyboardOptions = KeyboardOptions(imeAction = ImeAction.Search),
                keyboardActions = KeyboardActions(onSearch = { doSearch() }),
                modifier = Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = if (mediaTabletWorkspace) 4.dp else 8.dp)
            )
            AnimatedVisibility(visible = isSearching || isCatLoading) {
                LinearProgressIndicator(modifier = Modifier.fillMaxWidth())
            }
            nowPlaying?.let { item ->
                MiniPlayerBar(
                    item = item,
                    onExpand  = { nav.navigate("mediaPlayer/${item.id}") },
                    onDismiss = { vm.setNowPlayingMedia(null) },
                    androidAutoConnected = androidAutoConnected
                )
            }
            val currentItemsAreAudio = catItems.isNotEmpty() && catItems.all { it.mediaType.equals("audio", true) }
            if (selectedCat != null && query.isBlank() && currentItemsAreAudio) {
                Row(
                    modifier = Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 4.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text("Sort audio:", fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
                    Spacer(Modifier.width(8.dp))
                    MediaBrowseSort.values().forEach { mode ->
                        FilterChip(
                            selected = audioSortMode == mode,
                            onClick = { audioSortMode = mode },
                            label = { Text(mode.label, fontSize = 11.sp) },
                            modifier = Modifier.padding(end = 5.dp)
                        )
                    }
                }
            }
            val displayedCatItems = if (currentItemsAreAudio)
                sortMediaForBrowse(catItems, audioSortMode)
            else catItems.sortedByDescending { it.uploadDate }

            LazyColumn(state = mediaListState, modifier = Modifier.weight(1f)) {

                // ── Folder breadcrumb — visible whenever inside a folder,
                // regardless of whether a search is active, so the user
                // always sees (and can leave) the folder they're
                // browsing or searching within. ──
                if (selectedCat != null) {
                    item {
                        Row(modifier = Modifier.padding(horizontal = 12.dp, vertical = 6.dp),
                            verticalAlignment = Alignment.CenterVertically) {
                            TextButton(onClick = { goBackOneCategory() }) { Text("\u2190 Back") }
                            Text(selectedCat!!.name, fontWeight = FontWeight.Bold, fontSize = 14.sp, modifier = Modifier.weight(1f))
                            TextButton(onClick = { languagePickerTarget = selectedCat!!.key; languageSearch = "" }) {
                                Text("🌐 ${effectiveLanguageFor(selectedCat!!.key)}", fontSize = 11.sp)
                            }
                        }
                    }
                }

                // ── Search results — global at the root page, folder-
                // scoped (that folder + every subfolder beneath it) when
                // a folder is open. ──
                if (query.isNotBlank()) {
                    if (searchResults.isNotEmpty()) {
                        item {
                            Text(
                                selectedCat?.let { "Results in \u201C${it.name}\u201D (${searchResults.size})" }
                                    ?: "Results (${searchResults.size})",
                                fontWeight = FontWeight.Bold,
                                fontSize = 13.sp, modifier = Modifier.padding(horizontal = 16.dp, vertical = 6.dp))
                        }
                        if (mediaTabletWorkspace && mediaGridView) {
                            items(searchResults.chunked(mediaGridColumns), key = { row -> row.joinToString("|") { it.jwKey.ifBlank { it.title } } }) { rowItems ->
                                Row(Modifier.fillMaxWidth().padding(horizontal = 8.dp)) {
                                    rowItems.forEach { media ->
                                        SelectableMediaCard(
                                            media = media, contextList = searchResults,
                                            isSelectMode = isSelectMode, isSelected = media in selectedItems,
                                            onToggleSelect = { toggleSelected(media) },
                                            onEnterSelectMode = { enterSelectMode(media) },
                                            onPlay = { item, list -> playFromList(item, list) },
                                            onToggleFavourite = { vm.toggleMediaFavourite(media) },
                                            tabletPosterLayout = mediaTabletWorkspace && mediaGridView,
                                            modifier = Modifier.weight(1f).padding(4.dp)
                                        )
                                    }
                                    repeat((mediaGridColumns - rowItems.size).coerceAtLeast(0)) { Spacer(Modifier.weight(1f)) }
                                }
                            }
                        } else {
                        items(searchResults, key = { it.jwKey.ifBlank { it.title } }) { media ->
                            SelectableMediaCard(
                                media = media, contextList = searchResults,
                                isSelectMode = isSelectMode, isSelected = media in selectedItems,
                                onToggleSelect = { toggleSelected(media) },
                                onEnterSelectMode = { enterSelectMode(media) },
                                onPlay = { item, list -> playFromList(item, list) },
                                onToggleFavourite = { vm.toggleMediaFavourite(media) },
                                modifier = Modifier.padding(horizontal = 12.dp, vertical = 4.dp)
                            )
                        }
                        }
                    } else if (isSearching) {
                        item {
                            Text("Searching\u2026", fontSize = 13.sp,
                                modifier = Modifier.padding(horizontal = 16.dp, vertical = 12.dp))
                        }
                    } else if (!isSearching) {
                        item {
                            Text("No results for \"$query\"", fontSize = 13.sp,
                                modifier = Modifier.padding(horizontal = 16.dp, vertical = 12.dp))
                        }
                    }
                }

                // ── Category detail: subcategories (folders) + direct
                // media — only when NOT actively searching (a search
                // query, above, replaces this view with filtered
                // results while the folder stays open). ──
                if (selectedCat != null && query.isBlank()) {
                    if (catSubcategories.isNotEmpty()) {
                        items(catSubcategories, key = { "sub_" + it.key }) { sub ->
                            Card(onClick = { openCategory(sub) },
                                modifier = Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 4.dp)) {
                                Row(modifier = Modifier.padding(14.dp),
                                    verticalAlignment = Alignment.CenterVertically) {
                                    Text("\uD83D\uDCC2", fontSize = 20.sp)
                                    Spacer(Modifier.width(12.dp))
                                    Column(modifier = Modifier.weight(1f)) {
                                        Text(sub.name, fontWeight = FontWeight.Medium, fontSize = 14.sp)
                                        if (sub.description.isNotBlank())
                                            Text(sub.description, fontSize = 11.sp, maxLines = 1,
                                                color = MaterialTheme.colorScheme.onSurfaceVariant)
                                    }
                                    TextButton(onClick = { languagePickerTarget = sub.key; languageSearch = "" }) {
                                        Text("🌐 ${folderLanguages[sub.key] ?: "Auto"}", fontSize = 10.sp)
                                    }
                                    Text("\u203A", fontSize = 20.sp,
                                        color = MaterialTheme.colorScheme.onSurfaceVariant)
                                }
                            }
                        }
                    }
                    if (catItems.isNotEmpty()) {
                        item {
                            Text("\uD83C\uDFA5 Videos & Audio (${displayedCatItems.size})",
                                fontWeight = FontWeight.Bold, fontSize = 12.sp,
                                modifier = Modifier.padding(horizontal = 16.dp, vertical = 6.dp))
                        }
                        if (mediaTabletWorkspace && mediaGridView) {
                            items(displayedCatItems.chunked(mediaGridColumns), key = { row -> row.joinToString("|") { it.jwKey.ifBlank { it.title } } }) { rowItems ->
                                Row(Modifier.fillMaxWidth().padding(horizontal = 8.dp)) {
                                    rowItems.forEach { media ->
                                        SelectableMediaCard(
                                            media = media, contextList = displayedCatItems,
                                            isSelectMode = isSelectMode, isSelected = media in selectedItems,
                                            onToggleSelect = { toggleSelected(media) },
                                            onEnterSelectMode = { enterSelectMode(media) },
                                            onPlay = { item, list -> playFromList(item, list) },
                                            onToggleFavourite = { vm.toggleMediaFavourite(media) },
                                            tabletPosterLayout = mediaTabletWorkspace && mediaGridView,
                                            modifier = Modifier.weight(1f).padding(4.dp)
                                        )
                                    }
                                    repeat((mediaGridColumns - rowItems.size).coerceAtLeast(0)) { Spacer(Modifier.weight(1f)) }
                                }
                            }
                        } else {
                        items(displayedCatItems, key = { it.jwKey.ifBlank { it.title } }) { media ->
                            SelectableMediaCard(
                                media = media, contextList = displayedCatItems,
                                isSelectMode = isSelectMode, isSelected = media in selectedItems,
                                onToggleSelect = { toggleSelected(media) },
                                onEnterSelectMode = { enterSelectMode(media) },
                                onPlay = { item, list -> playFromList(item, list) },
                                onToggleFavourite = { vm.toggleMediaFavourite(media) },
                                modifier = Modifier.padding(horizontal = 12.dp, vertical = 4.dp)
                            )
                        }
                        }
                    }
                    if (!isCatLoading && catItems.isEmpty() && catSubcategories.isEmpty()) {
                        item {
                            Text("This category has no content yet.", fontSize = 13.sp,
                                modifier = Modifier.padding(horizontal = 16.dp, vertical = 12.dp))
                        }
                    }
                }

                // ── Recently Played (playback history) ────────────────────────
                if (selectedCat == null && query.isBlank() && recentlyPlayed.isNotEmpty()) {
                    item {
                        Text("\u25B6 Recently Played", fontWeight = FontWeight.Bold, fontSize = 13.sp,
                            modifier = Modifier.padding(horizontal = 16.dp, vertical = 6.dp))
                    }
                    if (mediaTabletWorkspace && mediaGridView) {
                        items(recentlyPlayed.chunked(mediaGridColumns), key = { row -> row.joinToString("|") { "recent_" + it.id } }) { rowItems ->
                            Row(Modifier.fillMaxWidth().padding(horizontal = 8.dp)) {
                                rowItems.forEach { media ->
                                    SelectableMediaCard(
                                        media = media, contextList = recentlyPlayed,
                                        isSelectMode = isSelectMode, isSelected = media in selectedItems,
                                        onToggleSelect = { toggleSelected(media) },
                                        onEnterSelectMode = { enterSelectMode(media) },
                                        onPlay = { item, list -> playFromList(item, list) },
                                        onToggleFavourite = { vm.toggleMediaFavourite(media) },
                                        tabletPosterLayout = mediaTabletWorkspace && mediaGridView,
                                        modifier = Modifier.weight(1f).padding(4.dp)
                                    )
                                }
                                repeat((mediaGridColumns - rowItems.size).coerceAtLeast(0)) { Spacer(Modifier.weight(1f)) }
                            }
                        }
                    } else {
                    items(recentlyPlayed, key = { "recent_" + it.id }) { media ->
                        SelectableMediaCard(
                            media = media, contextList = recentlyPlayed,
                            isSelectMode = isSelectMode, isSelected = media in selectedItems,
                            onToggleSelect = { toggleSelected(media) },
                            onEnterSelectMode = { enterSelectMode(media) },
                            onPlay = { item, list -> playFromList(item, list) },
                            onToggleFavourite = { vm.toggleMediaFavourite(media) },
                            tabletPosterLayout = mediaTabletWorkspace && mediaGridView,
                                            modifier = Modifier.padding(horizontal = 12.dp, vertical = 4.dp)
                        )
                    }
                    }
                    item { Spacer(Modifier.height(4.dp)) }
                }

                // ── Top-level category list ───────────────────────────────────
                if (selectedCat == null && query.isBlank()) {
                    item {
                        Text("Browse Categories", fontWeight = FontWeight.Bold, fontSize = 13.sp,
                            modifier = Modifier.padding(horizontal = 16.dp, vertical = 6.dp))
                    }
                    items(categories, key = { it.key }) { cat ->
                        Card(onClick = { openCategory(cat) },
                            modifier = Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 4.dp)) {
                            Row(modifier = Modifier.padding(14.dp),
                                verticalAlignment = Alignment.CenterVertically) {
                                Text("\uD83D\uDCC2", fontSize = 20.sp)
                                Spacer(Modifier.width(12.dp))
                                Column(modifier = Modifier.weight(1f)) {
                                    Text(cat.name, fontWeight = FontWeight.Medium, fontSize = 14.sp)
                                    if (cat.description.isNotBlank())
                                        Text(cat.description, fontSize = 11.sp, maxLines = 1,
                                            color = MaterialTheme.colorScheme.onSurfaceVariant)
                                }
                                TextButton(onClick = { languagePickerTarget = cat.key; languageSearch = "" }) {
                                    Text("🌐 ${folderLanguages[cat.key] ?: "Auto"}", fontSize = 10.sp)
                                }
                                Text("\u203A", fontSize = 20.sp,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant)
                            }
                        }
                    }
                    item { Spacer(Modifier.height(16.dp)) }
                }
            }
        }
    }

    languagePickerTarget?.let { target ->
        val isGlobal = target == "__GLOBAL__"
        val inherited = if (isGlobal) globalMediaLanguage else effectiveLanguageFor(target)
        val filtered = availableLanguages
            .filter {
                languageSearch.isBlank() || it.name.contains(languageSearch, true) ||
                    it.nativeName.contains(languageSearch, true) || it.code.contains(languageSearch, true)
            }
            .sortedWith(compareBy<JwMediaLanguage> { lang ->
                val idx = recentMediaLanguages.indexOfFirst { it.equals(lang.code, true) }
                if (idx >= 0) idx else Int.MAX_VALUE
            }.thenBy { it.name.lowercase() })
        AlertDialog(
            onDismissRequest = { languagePickerTarget = null },
            title = { Text(if (isGlobal) "Media Library language" else "Folder language") },
            text = {
                Column {
                    Text(
                        if (isGlobal) "Change all JW.org Media Library browsing and searches."
                        else "Override this folder and its subfolders. Choose Auto to follow the nearest parent/global language.",
                        fontSize = 12.sp,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                    Spacer(Modifier.height(8.dp))
                    OutlinedTextField(
                        value = languageSearch,
                        onValueChange = { languageSearch = it },
                        placeholder = { Text("Search languages…") },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth()
                    )
                    Spacer(Modifier.height(6.dp))
                    LazyColumn(Modifier.heightIn(max = 320.dp)) {
                        if (!isGlobal) {
                            item {
                                TextButton(
                                    onClick = {
                                        persistFolderLanguage(target, null)
                                        languagePickerTarget = null
                                        if (selectedCat?.key == target || categoryBackStack.any { it.key == target }) {
                                            selectedCat?.let { loadCategoryContents(it, parentLanguageFor(target)) }
                                        }
                                    },
                                    modifier = Modifier.fillMaxWidth()
                                ) { Text("Auto · Use parent / Media Library language") }
                            }
                        }
                        if (languageSearch.isBlank() && recentMediaLanguages.isNotEmpty()) {
                            item {
                                Text("Recent languages", fontSize = 11.sp, fontWeight = FontWeight.Bold,
                                    color = MaterialTheme.colorScheme.primary, modifier = Modifier.padding(horizontal = 12.dp, vertical = 4.dp))
                            }
                        }
                        items(filtered, key = { "lang_" + it.code }) { lang ->
                            val selected = if (isGlobal) globalMediaLanguage == lang.code else folderLanguages[target] == lang.code
                            TextButton(
                                onClick = {
                                    if (isGlobal) {
                                        scope.launch { mediaPrefs.setMediaLibraryLanguage(lang.code) }
                                    } else {
                                        scope.launch { mediaPrefs.rememberMediaLanguage(lang.code) }
                                        persistFolderLanguage(target, lang.code)
                                        if (selectedCat?.key == target || categoryBackStack.any { it.key == target }) {
                                            selectedCat?.let { current ->
                                                scope.launch {
                                                    kotlinx.coroutines.delay(50)
                                                    loadCategoryContents(current, lang.code)
                                                }
                                            }
                                        }
                                    }
                                    languagePickerTarget = null
                                },
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                Text((if (selected) "✓ " else "") + lang.nativeName +
                                    (if (lang.name != lang.nativeName) " · ${lang.name}" else "") + "  [${lang.code}]")
                            }
                        }
                    }
                    if (!isGlobal) Text("Current effective language: $inherited", fontSize = 11.sp)
                }
            },
            confirmButton = { TextButton(onClick = { languagePickerTarget = null }) { Text("Close") } }
        )
    }

    // v5.4.255cc — Batch "Add to Playlist" for the current selection.
    if (showPlaylistPicker) {
        AddToPlaylistDialog(
            vm = vm,
            items = selectedItems.toList(),
            onDismiss = {
                showPlaylistPicker = false
                exitSelectMode()
            }
        )
    }
}

private enum class MediaBrowseSort(val label: String) {
    SONG_NUMBER("Song #"), ALPHABETICAL("A–Z"), UPLOAD_DATE("Upload date")
}

private fun mediaSongNumber(title: String): Int? {
    val explicit = Regex("(?i)\\bsong\\s*(?:no\\.?\\s*)?(\\d{1,3})\\b").find(title)
        ?.groupValues?.getOrNull(1)?.toIntOrNull()
    if (explicit != null) return explicit
    return Regex("^\\s*(\\d{1,3})(?:[.\\s:–—-]|$)").find(title)
        ?.groupValues?.getOrNull(1)?.toIntOrNull()
}

private fun sortMediaForBrowse(items: List<MediaItem>, mode: MediaBrowseSort): List<MediaItem> = when (mode) {
    MediaBrowseSort.SONG_NUMBER -> items.sortedWith(
        compareBy<MediaItem> { mediaSongNumber(it.title) ?: Int.MAX_VALUE }
            .thenBy { it.title.lowercase() }
    )
    MediaBrowseSort.ALPHABETICAL -> items.sortedBy { it.title.lowercase() }
    MediaBrowseSort.UPLOAD_DATE -> items.sortedByDescending { it.uploadDate }
}

/**
 * v5.4.255cc — MediaResultCard wrapped with select-mode behavior: a
 * checkbox overlay appears while isSelectMode is true, and the tap
 * target switches from "play" to "toggle selection." Local to this file
 * — multi-select is specifically a JwVideoBrowseScreen ("the standard
 * media browser") feature per the request, not something every screen
 * showing media needs.
 */
@Composable
private fun SelectableMediaCard(
    media: MediaItem,
    contextList: List<MediaItem>,
    isSelectMode: Boolean,
    isSelected: Boolean,
    onToggleSelect: () -> Unit,
    onEnterSelectMode: () -> Unit,
    onPlay: (MediaItem, List<MediaItem>) -> Unit,
    onToggleFavourite: () -> Unit,
    modifier: Modifier = Modifier,
    tabletPosterLayout: Boolean = false
) {
    Box(modifier = modifier) {
        MediaResultCard(
            item = media,
            onPlay = { if (isSelectMode) onToggleSelect() else onPlay(media, contextList) },
            onToggleFavourite = onToggleFavourite,
            onLongPress = { if (!isSelectMode) onEnterSelectMode() },
            modifier = Modifier.fillMaxWidth(),
            tabletPosterLayout = tabletPosterLayout
        )
        if (isSelectMode) {
            Checkbox(
                checked = isSelected,
                onCheckedChange = { onToggleSelect() },
                modifier = Modifier.align(Alignment.TopStart)
            )
        }
    }
}
