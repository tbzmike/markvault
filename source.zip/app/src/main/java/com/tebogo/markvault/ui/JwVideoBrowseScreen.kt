package com.tebogo.markvault.ui

import androidx.activity.compose.BackHandler
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.tebogo.markvault.AppViewModel
import com.tebogo.markvault.data.MediaItem
import com.tebogo.markvault.network.JwCategory
import com.tebogo.markvault.network.JwMediaApi
import kotlinx.coroutines.launch

/**
 * v5.4.232cc — Dedicated JW.org video browse + search screen.
 *
 * Changes from v5.4.225cc:
 *   • Categories now show their SUBCATEGORIES too (JW.org's library is
 *     hierarchical — most "folders" hold mostly subcategories, not direct
 *     media, which is why they previously appeared empty).
 *   • categoryBackStack tracks how deep we've drilled in, so both the
 *     on-screen "← Categories" button and the system back button pop ONE
 *     level at a time instead of exiting the whole screen.
 *   • BackHandler intercepts system back: clears search first, then pops
 *     one category level, and only lets the screen close once already at
 *     the top with nothing to unwind.
 *
 * v5.4.251cc — Folder-scoped search + offline caching:
 *   • Searching while INSIDE a folder (selectedCat != null) now calls
 *     JwMediaApi.searchInCategory(selectedCat.key, ...) — confined to that
 *     folder's own media plus every subfolder beneath it — instead of the
 *     global search. Global search (JwMediaApi.search) is used ONLY on
 *     the root/main page (selectedCat == null); everywhere a folder is
 *     open, search stays confined to that folder's subtree.
 *   • selectedCat / categoryBackStack are no longer cleared when a
 *     folder-scoped search runs — the user stays "inside" the folder
 *     while its contents are filtered, and the breadcrumb ("← Back" +
 *     folder name) stays visible throughout.
 *   • Both category browsing (loadCategoryContents) and searching
 *     (doSearch) now feed every result into the shared offline media
 *     cache via vm.cacheMediaItems() — the same media_items table
 *     MarkVault's global search (SearchScreen) reads offline-first via
 *     vm.searchMedia(). One shared index, fed from every place media is
 *     browsed or searched, not a separate parallel cache.
 */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun JwVideoBrowseScreen(vm: AppViewModel, nav: androidx.navigation.NavController) {
    var query            by remember { mutableStateOf("") }
    var isSearching      by remember { mutableStateOf(false) }
    var searchResults    by remember { mutableStateOf<List<MediaItem>>(emptyList()) }
    var categories       by remember { mutableStateOf<List<JwCategory>>(emptyList()) }
    var selectedCat      by remember { mutableStateOf<JwCategory?>(null) }
    var catItems         by remember { mutableStateOf<List<MediaItem>>(emptyList()) }
    var catSubcategories by remember { mutableStateOf<List<JwCategory>>(emptyList()) }
    var isCatLoading     by remember { mutableStateOf(false) }
    // v5.4.232cc — Breadcrumb of categories drilled into, deepest last.
    var categoryBackStack by remember { mutableStateOf<List<JwCategory>>(emptyList()) }
    val scope         = rememberCoroutineScope()
    val nowPlaying    by vm.nowPlayingMedia.collectAsStateWithLifecycle()

    LaunchedEffect(Unit) {
        categories = kotlinx.coroutines.withContext(kotlinx.coroutines.Dispatchers.IO) {
            runCatching { JwMediaApi.topCategories() }.getOrElse { emptyList() }
        }
        vm.loadRecentlyPlayed()
    }
    val recentlyPlayed by vm.recentlyPlayedMedia.collectAsStateWithLifecycle()

    // v5.4.251cc — Folder-scoped search: global search applies ONLY on
    // the root/main page (selectedCat == null); searching while a folder
    // is open stays confined to that folder + everything beneath it via
    // searchInCategory, which crawls the full subtree. selectedCat and
    // categoryBackStack are deliberately left untouched here so the user
    // stays "inside" the folder — the breadcrumb and Back button remain
    // visible the whole time a folder-scoped search is active.
    fun doSearch() {
        if (query.isBlank()) return
        isSearching = true
        val scopedCat = selectedCat
        if (scopedCat == null) {
            // Root-level search: clear any stray category state so the
            // results view isn't mixed with leftover folder-browsing UI.
            catItems = emptyList()
            catSubcategories = emptyList()
            categoryBackStack = emptyList()
        }
        scope.launch {
            searchResults = kotlinx.coroutines.withContext(kotlinx.coroutines.Dispatchers.IO) {
                runCatching {
                    if (scopedCat != null) {
                        JwMediaApi.searchInCategory(scopedCat.key, query.trim(), limit = 40)
                    } else {
                        JwMediaApi.search(query.trim(), limit = 40)
                    }
                }.getOrElse { emptyList() }
            }
            isSearching = false
            // v5.4.251cc — Feed results into the shared offline media
            // cache so content found here stays findable later from
            // MarkVault's global search, without network.
            if (searchResults.isNotEmpty()) vm.cacheMediaItems(searchResults)
        }
    }

    fun loadCategoryContents(cat: JwCategory) {
        selectedCat = cat
        catItems = emptyList()
        catSubcategories = emptyList()
        isCatLoading = true
        scope.launch {
            val detail = kotlinx.coroutines.withContext(kotlinx.coroutines.Dispatchers.IO) {
                runCatching { JwMediaApi.categoryDetail(cat.key) }.getOrNull()
            }
            catItems = detail?.media ?: emptyList()
            catSubcategories = detail?.subcategories ?: emptyList()
            isCatLoading = false
            // v5.4.251cc — Same offline-cache feed as doSearch() above:
            // every folder browsed also becomes searchable later without
            // network, not just explicit search hits.
            if (catItems.isNotEmpty()) vm.cacheMediaItems(catItems)
        }
    }

    fun openCategory(cat: JwCategory) {
        categoryBackStack = categoryBackStack + cat
        loadCategoryContents(cat)
    }

    fun goBackOneCategory() {
        if (categoryBackStack.isEmpty()) return
        categoryBackStack = categoryBackStack.dropLast(1)
        val prev = categoryBackStack.lastOrNull()
        if (prev != null) {
            loadCategoryContents(prev)
        } else {
            selectedCat = null
            catItems = emptyList()
            catSubcategories = emptyList()
        }
    }

    // v5.4.232cc — Layered back handling: clear search first, then pop one
    // category level, only exiting the screen once both are empty.
    BackHandler(
        enabled = query.isNotBlank() || searchResults.isNotEmpty() || categoryBackStack.isNotEmpty()
    ) {
        when {
            query.isNotBlank() || searchResults.isNotEmpty() -> {
                query = ""
                searchResults = emptyList()
            }
            categoryBackStack.isNotEmpty() -> goBackOneCategory()
        }
    }

    // v5.4.233cc — Playback now routes through the shared PlaybackService
    // controller (vm.playMedia), so audio/video survives navigating away
    // from this screen or backgrounding the app entirely. Memory clearing
    // on navigation is now handled globally (MainActivity's destination
    // listener), so no per-screen delay-then-navigate dance is needed here.
    fun playMedia(item: MediaItem) {
        vm.playMedia(item)
        nav.navigate("mediaPlayer/0") { launchSingleTop = true }
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("\uD83C\uDFA5 JW.org Videos") },
                navigationIcon = {
                    IconButton(onClick = { nav.popBackStack() }) {
                        Icon(Icons.Default.ArrowBack, contentDescription = "Back")
                    }
                }
            )
        },
        bottomBar = { MarkVaultBottomBar(nav = nav, vm = vm) }
    ) { pad ->
        Column(modifier = Modifier.fillMaxSize().padding(pad)) {
            OutlinedTextField(
                value = query, onValueChange = { query = it },
                // v5.4.251cc — Context-aware placeholder: makes the
                // folder-scoped search mode visible, not just functional.
                placeholder = {
                    Text(
                        selectedCat?.let { "Search in \u201C${it.name}\u201D\u2026" }
                            ?: "Search JW.org videos\u2026"
                    )
                },
                trailingIcon = {
                    IconButton(onClick = { doSearch() }) {
                        Icon(Icons.Default.Search, contentDescription = "Search")
                    }
                },
                singleLine = true,
                keyboardOptions = KeyboardOptions(imeAction = ImeAction.Search),
                keyboardActions = KeyboardActions(onSearch = { doSearch() }),
                modifier = Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 8.dp)
            )
            AnimatedVisibility(visible = isSearching || isCatLoading) {
                LinearProgressIndicator(modifier = Modifier.fillMaxWidth())
            }
            nowPlaying?.let { item ->
                MiniPlayerBar(
                    item = item,
                    onExpand  = { nav.navigate("mediaPlayer/${item.id}") },
                    onDismiss = { vm.setNowPlayingMedia(null) }
                )
            }
            LazyColumn(modifier = Modifier.weight(1f)) {

                // ── Folder breadcrumb — visible whenever inside a folder,
                // regardless of whether a search is active, so the user
                // always sees (and can leave) the folder they're
                // browsing or searching within. ──
                if (selectedCat != null) {
                    item {
                        Row(modifier = Modifier.padding(horizontal = 12.dp, vertical = 6.dp),
                            verticalAlignment = Alignment.CenterVertically) {
                            TextButton(onClick = { goBackOneCategory() }) { Text("\u2190 Back") }
                            Text(selectedCat!!.name, fontWeight = FontWeight.Bold, fontSize = 14.sp)
                        }
                    }
                }

                // ── Search results — global at the root page, folder-
                // scoped (that folder + every subfolder beneath it) when
                // a folder is open. ──
                if (query.isNotBlank()) {
                    if (searchResults.isNotEmpty()) {
                        item {
                            Text(
                                selectedCat?.let { "Results in \u201C${it.name}\u201D (${searchResults.size})" }
                                    ?: "Results (${searchResults.size})",
                                fontWeight = FontWeight.Bold,
                                fontSize = 13.sp, modifier = Modifier.padding(horizontal = 16.dp, vertical = 6.dp))
                        }
                        items(searchResults, key = { it.jwKey.ifBlank { it.title } }) { media ->
                            MediaResultCard(item = media, onPlay = { playMedia(media) },
                                modifier = Modifier.padding(horizontal = 12.dp, vertical = 4.dp))
                        }
                    } else if (isSearching) {
                        item {
                            Text("Searching\u2026", fontSize = 13.sp,
                                modifier = Modifier.padding(horizontal = 16.dp, vertical = 12.dp))
                        }
                    } else if (!isSearching) {
                        item {
                            Text("No results for \"$query\"", fontSize = 13.sp,
                                modifier = Modifier.padding(horizontal = 16.dp, vertical = 12.dp))
                        }
                    }
                }

                // ── Category detail: subcategories (folders) + direct
                // media — only when NOT actively searching (a search
                // query, above, replaces this view with filtered
                // results while the folder stays open). ──
                if (selectedCat != null && query.isBlank()) {
                    if (catSubcategories.isNotEmpty()) {
                        items(catSubcategories, key = { "sub_" + it.key }) { sub ->
                            Card(onClick = { openCategory(sub) },
                                modifier = Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 4.dp)) {
                                Row(modifier = Modifier.padding(14.dp),
                                    verticalAlignment = Alignment.CenterVertically) {
                                    Text("\uD83D\uDCC2", fontSize = 20.sp)
                                    Spacer(Modifier.width(12.dp))
                                    Column(modifier = Modifier.weight(1f)) {
                                        Text(sub.name, fontWeight = FontWeight.Medium, fontSize = 14.sp)
                                        if (sub.description.isNotBlank())
                                            Text(sub.description, fontSize = 11.sp, maxLines = 1,
                                                color = MaterialTheme.colorScheme.onSurfaceVariant)
                                    }
                                    Text("\u203A", fontSize = 20.sp,
                                        color = MaterialTheme.colorScheme.onSurfaceVariant)
                                }
                            }
                        }
                    }
                    if (catItems.isNotEmpty()) {
                        item {
                            Text("\uD83C\uDFA5 Videos & Audio (${catItems.size})",
                                fontWeight = FontWeight.Bold, fontSize = 12.sp,
                                modifier = Modifier.padding(horizontal = 16.dp, vertical = 6.dp))
                        }
                        items(catItems, key = { it.jwKey.ifBlank { it.title } }) { media ->
                            MediaResultCard(item = media, onPlay = { playMedia(media) },
                                modifier = Modifier.padding(horizontal = 12.dp, vertical = 4.dp))
                        }
                    }
                    if (!isCatLoading && catItems.isEmpty() && catSubcategories.isEmpty()) {
                        item {
                            Text("This category has no content yet.", fontSize = 13.sp,
                                modifier = Modifier.padding(horizontal = 16.dp, vertical = 12.dp))
                        }
                    }
                }

                // ── Recently Played (playback history) ────────────────────────
                if (selectedCat == null && query.isBlank() && recentlyPlayed.isNotEmpty()) {
                    item {
                        Text("\u25B6 Recently Played", fontWeight = FontWeight.Bold, fontSize = 13.sp,
                            modifier = Modifier.padding(horizontal = 16.dp, vertical = 6.dp))
                    }
                    items(recentlyPlayed, key = { "recent_" + it.id }) { media ->
                        MediaResultCard(item = media, onPlay = { playMedia(media) },
                            modifier = Modifier.padding(horizontal = 12.dp, vertical = 4.dp))
                    }
                    item { Spacer(Modifier.height(4.dp)) }
                }

                // ── Top-level category list ───────────────────────────────────
                if (selectedCat == null && query.isBlank()) {
                    item {
                        Text("Browse Categories", fontWeight = FontWeight.Bold, fontSize = 13.sp,
                            modifier = Modifier.padding(horizontal = 16.dp, vertical = 6.dp))
                    }
                    items(categories, key = { it.key }) { cat ->
                        Card(onClick = { openCategory(cat) },
                            modifier = Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 4.dp)) {
                            Row(modifier = Modifier.padding(14.dp),
                                verticalAlignment = Alignment.CenterVertically) {
                                Text("\uD83D\uDCC2", fontSize = 20.sp)
                                Spacer(Modifier.width(12.dp))
                                Column(modifier = Modifier.weight(1f)) {
                                    Text(cat.name, fontWeight = FontWeight.Medium, fontSize = 14.sp)
                                    if (cat.description.isNotBlank())
                                        Text(cat.description, fontSize = 11.sp, maxLines = 1,
                                            color = MaterialTheme.colorScheme.onSurfaceVariant)
                                }
                                Text("\u203A", fontSize = 20.sp,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant)
                            }
                        }
                    }
                    item { Spacer(Modifier.height(16.dp)) }
                }
            }
        }
    }
}
