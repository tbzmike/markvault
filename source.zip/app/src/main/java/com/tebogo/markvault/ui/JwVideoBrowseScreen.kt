package com.tebogo.markvault.ui

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.tebogo.markvault.AppViewModel
import com.tebogo.markvault.data.MediaItem
import com.tebogo.markvault.network.JwCategory
import com.tebogo.markvault.network.JwMediaApi

/**
 * v5.4.220cc — Dedicated JW.org video browse + search screen.
 *
 * Features:
 *   • Own search bar — search JW.org videos by name
 *   • Top-level JW.org category list for browsing
 *   • Tapping a category loads its videos
 *   • Tapping a video card opens MediaPlayerScreen
 */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun JwVideoBrowseScreen(
    vm: AppViewModel,
    nav: androidx.navigation.NavController
) {
    var query          by remember { mutableStateOf("") }
    var isSearching    by remember { mutableStateOf(false) }
    var searchResults  by remember { mutableStateOf<List<MediaItem>>(emptyList()) }
    var categories     by remember { mutableStateOf<List<JwCategory>>(emptyList()) }
    var selectedCat    by remember { mutableStateOf<JwCategory?>(null) }
    var catItems       by remember { mutableStateOf<List<MediaItem>>(emptyList()) }
    var isCatLoading   by remember { mutableStateOf(false) }
    val scope          = androidx.compose.runtime.rememberCoroutineScope()

    // Load top-level categories once
    LaunchedEffect(Unit) {
        categories = kotlinx.coroutines.withContext(kotlinx.coroutines.Dispatchers.IO) {
            runCatching { JwMediaApi.topCategories() }.getOrElse { emptyList() }
        }
    }

    fun doSearch() {
        if (query.isBlank()) return
        isSearching = true
        selectedCat = null
        scope.launch {
            searchResults = kotlinx.coroutines.withContext(kotlinx.coroutines.Dispatchers.IO) {
                runCatching { JwMediaApi.search(query.trim(), limit = 30) }.getOrElse { emptyList() }
            }
            isSearching = false
        }
    }

    fun openCategory(cat: JwCategory) {
        selectedCat = cat
        catItems    = emptyList()
        isCatLoading = true
        scope.launch {
            catItems = kotlinx.coroutines.withContext(kotlinx.coroutines.Dispatchers.IO) {
                runCatching { JwMediaApi.categoryItems(cat.key) }.getOrElse { emptyList() }
            }
            isCatLoading = false
        }
    }

    fun playMedia(item: MediaItem) {
        scope.launch {
            val saved = vm.findOrSaveMedia(item)
            vm.setNowPlayingMedia(saved)
            nav.navigate("mediaPlayer/${saved.id}")
        }
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("\uD83C\uDFA5 JW.org Videos") },
                navigationIcon = {
                    IconButton(onClick = { nav.popBackStack() }) {
                        Icon(Icons.Default.ArrowBack, contentDescription = "Back")
                    }
                }
            )
        },
        bottomBar = { MarkVaultBottomBar(nav = nav, vm = vm) }
    ) { pad ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(pad)
        ) {
            // ── Search bar ──────────────────────────────────────────────────
            OutlinedTextField(
                value = query,
                onValueChange = { query = it },
                placeholder = { Text("Search JW.org videos…") },
                trailingIcon = {
                    IconButton(onClick = { doSearch() }) {
                        Icon(Icons.Default.Search, contentDescription = "Search")
                    }
                },
                singleLine = true,
                keyboardOptions = KeyboardOptions(imeAction = ImeAction.Search),
                keyboardActions = KeyboardActions(onSearch = { doSearch() }),
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 12.dp, vertical = 8.dp)
            )

            // ── Loading indicator ───────────────────────────────────────────
            AnimatedVisibility(visible = isSearching || isCatLoading) {
                LinearProgressIndicator(modifier = Modifier.fillMaxWidth())
            }

            // ── MiniPlayer if playing ───────────────────────────────────────
            val nowPlaying by vm.nowPlayingMedia.collectAsStateWithLifecycle()
            nowPlaying?.let { item ->
                MiniPlayerBar(
                    item = item,
                    onExpand = { nav.navigate("mediaPlayer/${item.id}") },
                    onDismiss = { vm.setNowPlayingMedia(null) }
                )
            }

            LazyColumn(modifier = Modifier.weight(1f)) {

                // ── Search results ──────────────────────────────────────────
                if (searchResults.isNotEmpty() && selectedCat == null) {
                    item {
                        Text(
                            "Results for \"$query\" (${searchResults.size})",
                            fontWeight = FontWeight.Bold,
                            fontSize = 13.sp,
                            modifier = Modifier.padding(horizontal = 16.dp, vertical = 6.dp)
                        )
                    }
                    items(searchResults, key = { it.jwKey.ifBlank { it.title } }) { media ->
                        MediaResultCard(
                            item = media,
                            onPlay = { playMedia(media) },
                            modifier = Modifier.padding(horizontal = 12.dp, vertical = 4.dp)
                        )
                    }
                    item { Spacer(Modifier.height(8.dp)) }
                }

                // ── Category detail ─────────────────────────────────────────
                if (selectedCat != null) {
                    item {
                        Row(
                            modifier = Modifier.padding(horizontal = 12.dp, vertical = 6.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            TextButton(onClick = { selectedCat = null }) {
                                Text("← Categories")
                            }
                            Text(
                                selectedCat!!.name,
                                fontWeight = FontWeight.Bold,
                                fontSize = 14.sp
                            )
                        }
                    }
                    if (!isCatLoading && catItems.isEmpty()) {
                        item {
                            Text(
                                "No videos in this category.",
                                fontSize = 13.sp,
                                modifier = Modifier.padding(horizontal = 16.dp, vertical = 8.dp)
                            )
                        }
                    }
                    items(catItems, key = { it.jwKey.ifBlank { it.title } }) { media ->
                        MediaResultCard(
                            item = media,
                            onPlay = { playMedia(media) },
                            modifier = Modifier.padding(horizontal = 12.dp, vertical = 4.dp)
                        )
                    }
                }

                // ── Category list (browse) ──────────────────────────────────
                if (selectedCat == null && searchResults.isEmpty()) {
                    item {
                        Text(
                            "Browse JW.org Categories",
                            fontWeight = FontWeight.Bold,
                            fontSize = 13.sp,
                            modifier = Modifier.padding(horizontal = 16.dp, vertical = 6.dp)
                        )
                    }
                    if (categories.isEmpty()) {
                        item {
                            Box(
                                modifier = Modifier.fillMaxWidth().padding(32.dp),
                                contentAlignment = Alignment.Center
                            ) {
                                CircularProgressIndicator()
                            }
                        }
                    }
                    items(categories, key = { it.key }) { cat ->
                        Card(
                            onClick = { openCategory(cat) },
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(horizontal = 12.dp, vertical = 4.dp)
                        ) {
                            Row(
                                modifier = Modifier.padding(14.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text("\uD83D\uDCC2", fontSize = 20.sp)
                                Spacer(Modifier.width(12.dp))
                                Column(modifier = Modifier.weight(1f)) {
                                    Text(cat.name, fontWeight = FontWeight.Medium, fontSize = 14.sp)
                                    if (cat.description.isNotBlank())
                                        Text(
                                            cat.description,
                                            fontSize = 11.sp,
                                            maxLines = 1,
                                            color = MaterialTheme.colorScheme.onSurfaceVariant
                                        )
                                }
                                Text("›", fontSize = 20.sp,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant)
                            }
                        }
                    }
                    item { Spacer(Modifier.height(16.dp)) }
                }
            }
        }
    }
}
