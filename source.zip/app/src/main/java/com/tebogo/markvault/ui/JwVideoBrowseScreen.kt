package com.tebogo.markvault.ui

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.tebogo.markvault.AppViewModel
import com.tebogo.markvault.data.MediaItem
import com.tebogo.markvault.network.JwCategory
import com.tebogo.markvault.network.JwMediaApi
import kotlinx.coroutines.launch

/** v5.4.225cc — Dedicated JW.org video browse + search screen. */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun JwVideoBrowseScreen(vm: AppViewModel, nav: androidx.navigation.NavController) {
    var query         by remember { mutableStateOf("") }
    var isSearching   by remember { mutableStateOf(false) }
    var searchResults by remember { mutableStateOf<List<MediaItem>>(emptyList()) }
    var categories    by remember { mutableStateOf<List<JwCategory>>(emptyList()) }
    var selectedCat   by remember { mutableStateOf<JwCategory?>(null) }
    var catItems      by remember { mutableStateOf<List<MediaItem>>(emptyList()) }
    var isCatLoading  by remember { mutableStateOf(false) }
    val scope         = rememberCoroutineScope()
    val nowPlaying    by vm.nowPlayingMedia.collectAsStateWithLifecycle()

    LaunchedEffect(Unit) {
        categories = kotlinx.coroutines.withContext(kotlinx.coroutines.Dispatchers.IO) {
            runCatching { JwMediaApi.topCategories() }.getOrElse { emptyList() }
        }
    }

    fun doSearch() {
        if (query.isBlank()) return
        isSearching = true
        selectedCat = null
        scope.launch {
            searchResults = kotlinx.coroutines.withContext(kotlinx.coroutines.Dispatchers.IO) {
                runCatching { JwMediaApi.search(query.trim(), limit = 30) }.getOrElse { emptyList() }
            }
            isSearching = false
        }
    }

    fun openCategory(cat: JwCategory) {
        selectedCat = cat; catItems = emptyList(); isCatLoading = true
        scope.launch {
            catItems = kotlinx.coroutines.withContext(kotlinx.coroutines.Dispatchers.IO) {
                runCatching { JwMediaApi.categoryItems(cat.key) }.getOrElse { emptyList() }
            }
            isCatLoading = false
        }
    }

    var pendingPlay by remember { mutableStateOf<MediaItem?>(null) }

    // v5.4.231cc — Free memory + short delay BEFORE navigating to the media
    // player. Opening MediaPlayerScreen creates a new ExoPlayer instance
    // (native buffers, threads) while this browse screen's Coil-cached
    // thumbnails and search/category results stay alive in the back stack.
    // Without freeing memory first, repeated play attempts accumulate
    // pressure until the heap has no room even for a 32-byte allocation.
    LaunchedEffect(pendingPlay) {
        val target = pendingPlay
        if (target != null) {
            vm.freeMemoryForNavigation()
            kotlinx.coroutines.delay(500L)   // let GC actually reclaim before allocating the player
            val saved = vm.findOrSaveMedia(target)
            vm.setNowPlayingMedia(saved)
            nav.navigate("mediaPlayer/${saved.id}")
            pendingPlay = null
        }
    }

    fun playMedia(item: MediaItem) {
        pendingPlay = item
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("\uD83C\uDFA5 JW.org Videos") },
                navigationIcon = {
                    IconButton(onClick = { nav.popBackStack() }) {
                        Icon(Icons.Default.ArrowBack, contentDescription = "Back")
                    }
                }
            )
        },
        bottomBar = { MarkVaultBottomBar(nav = nav, vm = vm) }
    ) { pad ->
        Column(modifier = Modifier.fillMaxSize().padding(pad)) {
            OutlinedTextField(
                value = query, onValueChange = { query = it },
                placeholder = { Text("Search JW.org videos\u2026") },
                trailingIcon = {
                    IconButton(onClick = { doSearch() }) {
                        Icon(Icons.Default.Search, contentDescription = "Search")
                    }
                },
                singleLine = true,
                keyboardOptions = KeyboardOptions(imeAction = ImeAction.Search),
                keyboardActions = KeyboardActions(onSearch = { doSearch() }),
                modifier = Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 8.dp)
            )
            AnimatedVisibility(visible = isSearching || isCatLoading) {
                LinearProgressIndicator(modifier = Modifier.fillMaxWidth())
            }
            nowPlaying?.let { item ->
                MiniPlayerBar(
                    item = item,
                    onExpand  = { nav.navigate("mediaPlayer/${item.id}") },
                    onDismiss = { vm.setNowPlayingMedia(null) }
                )
            }
            LazyColumn(modifier = Modifier.weight(1f)) {
                if (searchResults.isNotEmpty() && selectedCat == null) {
                    item {
                        Text("Results (${searchResults.size})", fontWeight = FontWeight.Bold,
                            fontSize = 13.sp, modifier = Modifier.padding(horizontal = 16.dp, vertical = 6.dp))
                    }
                    items(searchResults, key = { it.jwKey.ifBlank { it.title } }) { media ->
                        MediaResultCard(item = media, onPlay = { playMedia(media) },
                            modifier = Modifier.padding(horizontal = 12.dp, vertical = 4.dp))
                    }
                }
                if (selectedCat != null) {
                    item {
                        Row(modifier = Modifier.padding(horizontal = 12.dp, vertical = 6.dp),
                            verticalAlignment = Alignment.CenterVertically) {
                            TextButton(onClick = { selectedCat = null }) { Text("\u2190 Categories") }
                            Text(selectedCat!!.name, fontWeight = FontWeight.Bold, fontSize = 14.sp)
                        }
                    }
                    items(catItems, key = { it.jwKey.ifBlank { it.title } }) { media ->
                        MediaResultCard(item = media, onPlay = { playMedia(media) },
                            modifier = Modifier.padding(horizontal = 12.dp, vertical = 4.dp))
                    }
                }
                if (selectedCat == null && searchResults.isEmpty()) {
                    item {
                        Text("Browse Categories", fontWeight = FontWeight.Bold, fontSize = 13.sp,
                            modifier = Modifier.padding(horizontal = 16.dp, vertical = 6.dp))
                    }
                    items(categories, key = { it.key }) { cat ->
                        Card(onClick = { openCategory(cat) },
                            modifier = Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 4.dp)) {
                            Row(modifier = Modifier.padding(14.dp),
                                verticalAlignment = Alignment.CenterVertically) {
                                Text("\uD83D\uDCC2", fontSize = 20.sp)
                                Spacer(Modifier.width(12.dp))
                                Column(modifier = Modifier.weight(1f)) {
                                    Text(cat.name, fontWeight = FontWeight.Medium, fontSize = 14.sp)
                                    if (cat.description.isNotBlank())
                                        Text(cat.description, fontSize = 11.sp, maxLines = 1,
                                            color = MaterialTheme.colorScheme.onSurfaceVariant)
                                }
                                Text("\u203A", fontSize = 20.sp,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant)
                            }
                        }
                    }
                    item { Spacer(Modifier.height(16.dp)) }
                }
            }
        }
    }
}
