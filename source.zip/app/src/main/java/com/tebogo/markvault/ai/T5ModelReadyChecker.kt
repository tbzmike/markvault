package com.tebogo.markvault.ai

/** Checks whether all T5 requirements are satisfied before activation. */
object T5ModelReadyChecker {
    fun isReady(requiredPresent: Boolean, tokenizerPresent: Boolean): Boolean {
        val ready = requiredPresent && tokenizerPresent
        T5InstallState.setReady(ready)
        T5ExpansionAvailability.update(ready)
        return ready
    }
}
