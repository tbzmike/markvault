package com.tebogo.markvault.ai

/** Keeps settings state synchronized with runtime state. */
object T5SettingsRuntimeSync {
    fun current(): T5ExpansionMode = T5ModePersistenceBridge.currentMode()
}
