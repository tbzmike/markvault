package com.tebogo.markvault.ai

/** Adapter preparing T5 diagnostics for history storage. */
object T5HistoryStorageAdapter {
    fun create(detail: T5HistoryDetail): T5HistoryDetail = detail
}
