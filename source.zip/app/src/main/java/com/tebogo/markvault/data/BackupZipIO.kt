package com.tebogo.markvault.data

import android.content.Context
import android.net.Uri
import java.io.File
import java.io.InputStream
import java.io.OutputStream
import java.security.DigestInputStream
import java.security.MessageDigest
import java.util.zip.ZipEntry
import java.util.zip.ZipFile
import java.util.zip.ZipInputStream

/** Operation-scoped ZIP I/O. No background workers or persistent buffers. */
internal object BackupZipIO {
    private const val BUFFER_SIZE = 128 * 1024
    private const val HEX = "0123456789abcdef"
    fun hex(bytes: ByteArray): String = CharArray(bytes.size * 2).also { chars ->
        bytes.forEachIndexed { i, b ->
            val n = b.toInt() and 255
            chars[i * 2] = HEX[n ushr 4]
            chars[i * 2 + 1] = HEX[n and 15]
        }
    }.concatToString()

    fun copy(input: InputStream, output: OutputStream, buffer: ByteArray,
             onBytes: (Long) -> Unit = {}) {
        while (true) {
            val n = input.read(buffer)
            if (n < 0) break
            if (n == 0) continue
            output.write(buffer, 0, n)
            onBytes(n.toLong())
        }
    }

    /** Visit only requested entries. ZipFile does NOT inflate skipped entries. */
    fun visitSeekable(archive: ZipFile, select: (ZipEntry) -> Boolean,
                      consume: (ZipEntry, InputStream) -> Unit) {
        val entries = archive.entries()
        while (entries.hasMoreElements()) {
            val entry = entries.nextElement()
            if (select(entry)) archive.getInputStream(entry).use { consume(entry, it) }
        }
    }

    fun visitStreaming(raw: InputStream, select: (ZipEntry) -> Boolean,
                       consume: (ZipEntry, InputStream) -> Unit) {
        ZipInputStream(raw.buffered(BUFFER_SIZE)).use { zip ->
            var entry = zip.nextEntry
            while (entry != null) {
                if (select(entry)) consume(entry, zip)
                zip.closeEntry()
                entry = zip.nextEntry
            }
        }
    }

    /** Only descriptor/open failure permits streaming fallback. Never retry writes. */
    fun visit(ctx: Context, source: Uri, select: (ZipEntry) -> Boolean,
              consume: (ZipEntry, InputStream) -> Unit) {
        val descriptor = runCatching { ctx.contentResolver.openFileDescriptor(source, "r") }.getOrNull()
        if (descriptor != null) descriptor.use { fd ->
            val archive = runCatching { ZipFile(File("/proc/self/fd/${fd.fd}")) }.getOrNull()
            if (archive != null) {
                archive.use { visitSeekable(it, select, consume) }
                return
            }
        }
        val raw = ctx.contentResolver.openInputStream(source) ?: error("Backup document cannot be opened")
        raw.use { visitStreaming(it, select, consume) }
    }

    /** Recheck bytes used for installation against the already verified manifest.
     * This also protects ZipFile readers that do not verify CRC automatically.
     * No second inflation of the entry is needed.
     */
    fun <T> checked(input: InputStream, expectedHash: String, consume: (InputStream) -> T): T {
        val digest = MessageDigest.getInstance("SHA-256")
        val checked = DigestInputStream(input, digest)
        val result = consume(checked)
        val first = checked.read()
        if (first != -1) {
            val buffer = ByteArray(BUFFER_SIZE)
            while (checked.read(buffer) != -1) { /* drain only this entry */ }
        }
        require(hex(digest.digest()).equals(expectedHash, ignoreCase = true)) {
            "Backup content changed or failed checksum during restoration"
        }
        return result
    }

    fun visitVerified(ctx: Context, source: Uri, expectedHash: (String) -> String,
                      select: (ZipEntry) -> Boolean, consume: (ZipEntry, InputStream) -> Unit) =
        visit(ctx, source, select) { entry, input ->
            checked(input, expectedHash(entry.name)) { consume(entry, it) }
        }

    fun percent(start: Int, end: Int, done: Long, total: Long): Int =
        if (total <= 0L) start else start + ((end - start) *
            (done.toDouble() / total.toDouble()).coerceIn(0.0, 1.0)).toInt()

    /** Actual bytes and item counts, throttled by work, not a polling timer. */
    class Stage(private val label: String, private val start: Int, private val end: Int,
                private val total: Long, private val totalBytes: Long,
                private val emit: (String, Long, Long, Int) -> Unit) {
        private var done = 0L
        private var bytes = 0L
        private var last = 0L
        fun bytes(n: Long) { bytes += n; report() }
        fun item() { done++; report() }
        fun report(force: Boolean = false) {
            val now = System.nanoTime()
            if (!force && now - last < 500_000_000L) return
            last = now
            val pct = if (totalBytes > 0L) percent(start, end, bytes, totalBytes)
                else percent(start, end, done, total)
            val detail = if (totalBytes > 0) " (${bytes / 1048576} / ${totalBytes / 1048576} MiB)" else ""
            emit(label + detail, done, total, if (done >= total) end else pct.coerceAtMost(end - 1))
        }
    }
}
