package com.tebogo.markvault.search

/** A single overlapping-window chunk — see [buildOverlappingChunks]. */
data class TextChunk(val text: String, val startWordIdx: Int)

/**
 * v5.4.135cc — Fixed-size overlapping-chunk splitter, originally built
 * for the in-article semantic ranker (AppViewModel.findArticlePassages).
 *
 * v5.4.174cc — Extracted from AppViewModel into this shared file so the
 * main embedding index (EmbeddingService) can use the EXACT SAME,
 * already-proven chunking logic instead of a second, separately-written
 * copy that could quietly drift out of sync with this one over time.
 * Renamed ArticleChunk → TextChunk since it's no longer article-popup-
 * specific, but the algorithm itself is byte-for-byte unchanged.
 *
 * Splits [text] into windows of [targetWords] words with [overlapWords]
 * words of overlap between adjacent windows. Documents shorter than
 * [targetWords] become a single chunk (splitting them further would
 * produce chunks below the embedder's minimum useful size).
 *
 * Returns [TextChunk] rather than raw strings so callers can de-overlap
 * top-K results by comparing start-word indices.
 */
fun buildOverlappingChunks(
    text: String,
    targetWords: Int,
    overlapWords: Int,
    minWords: Int
): List<TextChunk> {
    // Tokenize on whitespace runs, preserving punctuation with its
    // attached word. Empty strings from consecutive whitespace are
    // dropped.
    val words: List<String> = text.split(Regex("\\s+")).filter { it.isNotEmpty() }
    if (words.size < minWords) return emptyList()

    // Short documents fit into a single chunk — no split.
    if (words.size <= targetWords) {
        return listOf(TextChunk(text = words.joinToString(" "), startWordIdx = 0))
    }

    val step: Int = (targetWords - overlapWords).coerceAtLeast(1)
    val chunks: MutableList<TextChunk> = mutableListOf()
    var i = 0
    while (i < words.size) {
        val end: Int = minOf(i + targetWords, words.size)
        val chunkText: String = words.subList(i, end).joinToString(" ")
        chunks.add(TextChunk(text = chunkText, startWordIdx = i))
        if (end >= words.size) break
        i += step
    }
    return chunks
}
