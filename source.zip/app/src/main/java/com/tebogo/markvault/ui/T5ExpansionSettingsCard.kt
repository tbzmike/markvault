package com.tebogo.markvault.ui

import androidx.compose.material3.*
import androidx.compose.foundation.layout.*
import androidx.compose.runtime.Composable
import com.tebogo.markvault.ai.T5ExpansionMode

@Composable
fun T5ExpansionSettingsCard(
    mode: T5ExpansionMode,
    status: String,
    enabled: Boolean,
    onModeChanged: (T5ExpansionMode) -> Unit
) {
    Card {
        Column {
            Text("Query Expansion")
            Row {
                RadioButton(
                    selected = mode == T5ExpansionMode.BUILTIN,
                    onClick = { onModeChanged(T5ExpansionMode.BUILTIN) }
                )
                Text("Built-in")
            }
            Row {
                RadioButton(
                    selected = mode == T5ExpansionMode.T5_BASE,
                    enabled = enabled,
                    onClick = { onModeChanged(T5ExpansionMode.T5_BASE) }
                )
                Text("T5-base")
            }
            Text("T5 Model Status: $status")
        }
    }
}
