package com.tebogo.markvault.ui

import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.tebogo.markvault.ai.T5ExpansionMode

@Composable
fun T5ExpansionSettingsCard(
    mode: T5ExpansionMode,
    status: String,
    enabled: Boolean,
    onModeChanged: (T5ExpansionMode) -> Unit,
    onInstallClick: () -> Unit
) {
    Card(modifier = Modifier.fillMaxWidth()) {
        Column(
            modifier = Modifier.padding(16.dp)
        ) {
            Text("Query Expansion")

            Row {
                RadioButton(
                    selected = mode == T5ExpansionMode.BUILTIN,
                    onClick = { onModeChanged(T5ExpansionMode.BUILTIN) }
                )
                Text("Built-in")
            }

            Row {
                RadioButton(
                    selected = mode == T5ExpansionMode.T5_BASE,
                    enabled = enabled,
                    onClick = { onModeChanged(T5ExpansionMode.T5_BASE) }
                )
                Text("T5-base")
            }

            Text("T5 Model Status: $status")

            if (status != "Ready") {
                Spacer(modifier = Modifier.height(8.dp))
                Button(onClick = onInstallClick) {
                    Text("Download T5-base model")
                }
            }
        }
    }
}
