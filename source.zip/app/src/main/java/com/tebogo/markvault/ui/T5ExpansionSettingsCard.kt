package com.tebogo.markvault.ui

import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.RadioButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.tebogo.markvault.ai.T5ExpansionMode
import com.tebogo.markvault.ai.T5ModelCatalog

/**
 * Settings card for T5-base query-expansion mode.
 *
 * The T5-base radio button is only selectable once the model is actually
 * installed ([installed]); until then, tapping "Download T5-base model"
 * kicks off [onDownloadClick] (wired to `AppViewModel.downloadT5Model()`),
 * which shows live progress here and flips [installed] to true on success.
 */
@Composable
fun T5ExpansionSettingsCard(
    mode: T5ExpansionMode,
    installed: Boolean,
    downloadProgress: Float?,
    error: String?,
    onModeChanged: (T5ExpansionMode) -> Unit,
    onDownloadClick: () -> Unit
) {
    Card {
        Column(Modifier.padding(16.dp)) {
            Text("Query Expansion")
            Row(verticalAlignment = Alignment.CenterVertically) {
                RadioButton(
                    selected = mode == T5ExpansionMode.BUILTIN,
                    onClick = { onModeChanged(T5ExpansionMode.BUILTIN) }
                )
                Text("Built-in")
            }
            Row(verticalAlignment = Alignment.CenterVertically) {
                RadioButton(
                    selected = mode == T5ExpansionMode.T5_BASE,
                    enabled = installed,
                    onClick = { onModeChanged(T5ExpansionMode.T5_BASE) }
                )
                Text("T5-base")
            }

            val statusText = when {
                downloadProgress != null -> "Downloading… ${(downloadProgress * 100).toInt()}%"
                installed -> "Installed"
                error != null -> "Not installed — $error"
                else -> "Not installed"
            }
            Text(
                "T5 Model Status: $statusText",
                color = if (error != null && downloadProgress == null && !installed) {
                    MaterialTheme.colorScheme.error
                } else {
                    MaterialTheme.colorScheme.onSurface
                }
            )

            Spacer(Modifier.height(8.dp))

            when {
                downloadProgress != null -> {
                    LinearProgressIndicator(
                        progress = { downloadProgress },
                        modifier = Modifier.fillMaxWidth()
                    )
                }
                !installed -> {
                    Button(onClick = onDownloadClick, modifier = Modifier.fillMaxWidth()) {
                        Text("Download T5-base model (~${T5ModelCatalog.approxTotalSizeMb} MB)")
                    }
                }
            }
        }
    }
}
