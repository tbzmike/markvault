package com.tebogo.markvault.ui

import android.content.Context
import android.util.AttributeSet
import android.view.ActionMode
import android.view.Menu
import android.view.MenuItem
import android.view.View
import android.webkit.WebView

/**
 * WebView that injects a custom "Search in MarkVault" entry into the native text
 * selection action mode menu (alongside Copy, Share, etc.).
 *
 * Behaviour:
 *   1. User long-presses on plain text inside the WebView.
 *   2. Android starts an ActionMode with the standard Copy/Share/etc. menu.
 *   3. We wrap that ActionMode.Callback and append our menu item.
 *   4. When the user taps "Search in MarkVault" we pull the current selection
 *      out of the WebView via JavaScript and call [onSearchInMarkVault].
 *
 * The caller wires [onSearchInMarkVault] to navigate to the Search screen with
 * the captured text already entered.
 */
class SelectionWebView @JvmOverloads constructor(
    context: Context,
    attrs: AttributeSet? = null
) : WebView(context, attrs) {

    /** Wired from Compose — receives the selected text when the user taps our menu. */
    var onSearchInMarkVault: ((String) -> Unit)? = null

    /**
     * Override both startActionMode signatures. Android calls the (callback, type)
     * variant on API 23+ for floating action modes; older paths call the (callback)
     * variant. We wrap whichever the platform invokes.
     */
    override fun startActionMode(callback: ActionMode.Callback?, type: Int): ActionMode? {
        return super.startActionMode(wrap(callback), type)
    }

    override fun startActionMode(callback: ActionMode.Callback?): ActionMode? {
        return super.startActionMode(wrap(callback))
    }

    /**
     * Wrap the system callback with one that also adds our menu item.
     */
    private fun wrap(orig: ActionMode.Callback?): ActionMode.Callback {
        return object : ActionMode.Callback {
            override fun onCreateActionMode(mode: ActionMode?, menu: Menu?): Boolean {
                val ret = orig?.onCreateActionMode(mode, menu) ?: true
                // Append our custom menu item. The ID is a synthetic constant we
                // recognise in onActionItemClicked below.
                menu?.add(0, MENU_ID_SEARCH_MARKVAULT, 999, "Search in MarkVault")
                return ret
            }

            override fun onPrepareActionMode(mode: ActionMode?, menu: Menu?): Boolean {
                return orig?.onPrepareActionMode(mode, menu) ?: false
            }

            override fun onActionItemClicked(mode: ActionMode?, item: MenuItem?): Boolean {
                if (item?.itemId == MENU_ID_SEARCH_MARKVAULT) {
                    // Pull the current selection out of the WebView via JS — the
                    // platform doesn't expose it directly. window.getSelection()
                    // returns whatever the user is highlighting.
                    evaluateJavascript(
                        "(function(){return window.getSelection().toString();})();"
                    ) { jsonValue ->
                        val text = decodeJsSelection(jsonValue).trim()
                        if (text.isNotEmpty()) onSearchInMarkVault?.invoke(text)
                    }
                    mode?.finish()
                    return true
                }
                return orig?.onActionItemClicked(mode, item) ?: false
            }

            override fun onDestroyActionMode(mode: ActionMode?) {
                orig?.onDestroyActionMode(mode)
            }
        }
    }

    companion object {
        /** Synthetic ID for our injected menu item — high enough to avoid platform IDs. */
        private const val MENU_ID_SEARCH_MARKVAULT = 0x00C0FFEE
    }
}

/**
 * Decode a JSON-quoted string returned by WebView.evaluateJavascript.
 * Kept separate from the version in WebSearchScreen so this file is self-contained.
 */
private fun decodeJsSelection(jsonValue: String?): String {
    if (jsonValue.isNullOrBlank() || jsonValue == "null") return ""
    var s = jsonValue.trim()
    if (s.startsWith("\"") && s.endsWith("\"")) s = s.substring(1, s.length - 1)
    val sb = StringBuilder(s.length)
    var i = 0
    while (i < s.length) {
        val c = s[i]
        if (c == '\\' && i + 1 < s.length) {
            when (val n = s[i + 1]) {
                '"', '\\', '/' -> { sb.append(n); i += 2 }
                'n' -> { sb.append('\n'); i += 2 }
                'r' -> { sb.append('\r'); i += 2 }
                't' -> { sb.append('\t'); i += 2 }
                'u' -> {
                    if (i + 5 < s.length) {
                        val hex = s.substring(i + 2, i + 6)
                        val cp = runCatching { hex.toInt(16) }.getOrNull()
                        if (cp != null) sb.append(cp.toChar()) else sb.append(n)
                        i += 6
                    } else { sb.append(n); i += 2 }
                }
                else -> { sb.append(n); i += 2 }
            }
        } else {
            sb.append(c); i++
        }
    }
    return sb.toString()
}
