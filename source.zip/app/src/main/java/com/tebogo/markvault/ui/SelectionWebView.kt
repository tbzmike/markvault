package com.tebogo.markvault.ui

import android.content.Context
import android.util.AttributeSet
import android.view.ActionMode
import android.view.Menu
import android.view.MenuItem
import android.view.MotionEvent
import android.webkit.WebView

/**
 * WebView that injects custom entries into the native text-selection ActionMode:
 *
 *   • "Search in MarkVault"   — runs an FTS search over the local library
 *   • "Search in wol.jw.org"  — opens wol.jw.org search for the selected text
 *
 * Both menu items are added alongside the platform Copy/Share buttons, regardless
 * of whether this view is hosted in the main browser screen, the WebPopup bottom
 * sheet, the fullscreen popup, or the markdown reader. Behaviour is consistent
 * because we wrap whichever ActionMode.Callback the platform passes us.
 *
 * v4.2 fixes:
 *   1. INSTABILITY — earlier code called `mode.finish()` synchronously, which
 *      cleared the selection BEFORE `window.getSelection().toString()` could
 *      run via evaluateJavascript. Now finish() runs INSIDE the JS callback so
 *      we always capture the text first.
 *   2. WOL SEARCH on highlighted text — second menu item added.
 *   3. WORKS IN POPUP — by virtue of using SelectionWebView in WebPopup too,
 *      not just the main browser.
 */
class SelectionWebView @JvmOverloads constructor(
    context: Context,
    attrs: AttributeSet? = null
) : WebView(context, attrs) {

    /** Wired from Compose — receives the selected text when "Search in MarkVault" is tapped. */
    var onSearchInMarkVault: ((String) -> Unit)? = null

    /** Wired from Compose — receives the selected text when "Search in wol.jw.org" is tapped. */
    var onSearchInWol: ((String) -> Unit)? = null

    /**
     * Wired from Compose — receives the selected text when "Search on jw.org"
     * is tapped. v4.12.0.
     */
    var onSearchInJwOrg: ((String) -> Unit)? = null

    /**
     * Wired from Compose — receives the selected text when "Share" is tapped.
     * Default behaviour fires an Android `ACTION_SEND` intent if the callback
     * is left null. v4.12.0.
     */
    var onShare: ((String) -> Unit)? = null

    /**
     * v5.4.91cc — Last touch coordinates in VIEW pixels. Populated in
     * [onTouchEvent] on every ACTION_DOWN and ACTION_MOVE.
     *
     * Why we need this: Android's [android.webkit.WebView.HitTestResult]
     * misreports the payload for `SRC_IMAGE_ANCHOR_TYPE` — long-pressing a
     * thumbnail inside a link returns the IMAGE `src` in
     * `HitTestResult.getExtra()`, not the enclosing anchor's href. That's
     * why the v5.4.90cc batch save wrote 641-byte thumbnail HTML files
     * instead of the article pages the user actually picked.
     *
     * With touch coordinates in hand we can bounce through
     * `document.elementFromPoint(x, y).closest('a[href]')` in JS to find
     * the real anchor. See [resolveAnchorAtLastTouch].
     */
    @Volatile var lastTouchX: Float = 0f
    @Volatile var lastTouchY: Float = 0f

    /**
     * v5.4.93cc — Drag-select support. Once the caller has confirmed a
     * long-press should enter drag-select mode (via
     * [enableDragSelectForCurrentPress]), every ACTION_MOVE over a NEW
     * anchor fires [onDragSelectAnchor] with the anchor's href + text.
     * The last URL toggled is remembered so the callback doesn't fire
     * repeatedly while the finger is still inside the same card.
     *
     * Why we track it here rather than in the Composable: the touch
     * stream is on this view, and MOVE events must reach us before the
     * default WebView touch handler decides whether to scroll. Once the
     * long-press has fired we swallow the scroll (by not calling super
     * during drag-select MOVE events), which lets the user glide across
     * multiple cards in one gesture.
     */
    var onDragSelectAnchor: ((href: String, text: String) -> Unit)? = null

    @Volatile private var isPressing: Boolean = false
    @Volatile private var isDragSelecting: Boolean = false
    @Volatile private var dragQueryInFlight: Boolean = false
    @Volatile private var lastDragSelectedUrl: String = ""

    /**
     * Called by the long-press handler after selection mode is confirmed
     * on. Marks the current press as a drag-select session so subsequent
     * MOVE events auto-select. No-op if the finger has already lifted by
     * the time this fires (unusual — the callback normally runs before
     * ACTION_UP dispatches).
     */
    fun enableDragSelectForCurrentPress() {
        if (isPressing) isDragSelecting = true
    }

    override fun onTouchEvent(event: MotionEvent): Boolean {
        when (event.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                lastTouchX = event.x
                lastTouchY = event.y
                isPressing = true
                isDragSelecting = false
                lastDragSelectedUrl = ""
                dragQueryInFlight = false
            }
            MotionEvent.ACTION_MOVE -> {
                lastTouchX = event.x
                lastTouchY = event.y
                if (isDragSelecting && !dragQueryInFlight) {
                    // Serialise JS lookups — no point firing another
                    // elementFromPoint query while one is still in flight.
                    // The last-URL guard downstream deduplicates hits on
                    // the same card.
                    dragQueryInFlight = true
                    resolveAnchorAtLastTouch { href, text ->
                        dragQueryInFlight = false
                        if (href.isNotBlank() && href != lastDragSelectedUrl) {
                            lastDragSelectedUrl = href
                            onDragSelectAnchor?.invoke(href, text)
                        }
                    }
                }
            }
            MotionEvent.ACTION_UP,
            MotionEvent.ACTION_CANCEL -> {
                isPressing = false
                isDragSelecting = false
                dragQueryInFlight = false
                lastDragSelectedUrl = ""
            }
        }
        return super.onTouchEvent(event)
    }

    /**
     * Resolve the anchor (`<a href=...>`) at the last touch position via
     * `document.elementFromPoint`. Callback fires on the main thread with
     * the anchor's href and inner text; both come back empty when the
     * touch didn't land on any linked element.
     *
     * Coordinates are converted from view pixels to CSS pixels using
     * `WebView.getScale()`. The getter is deprecated in favour of
     * WindowInsets-aware APIs, but it's still the correct value for
     * `elementFromPoint` — that function operates in the layout viewport
     * which is exactly the space `getScale()` maps to.
     */
    fun resolveAnchorAtLastTouch(callback: (href: String, text: String) -> Unit) {
        @Suppress("DEPRECATION")
        val s = scale.coerceAtLeast(0.01f)
        val cssX = lastTouchX / s
        val cssY = lastTouchY / s
        // Ternary chain in JS: walk up parents until we find <a href>. If
        // nothing found, return empty string — Kotlin side treats that as
        // "no anchor here" and falls back to hitTestResult.extra.
        evaluateJavascript(
            "(function(){" +
            "var el=document.elementFromPoint($cssX,$cssY);" +
            "while(el&&el.tagName!=='A'){el=el.parentElement;}" +
            "if(!el||!el.href)return '';" +
            "var t=(el.innerText||el.textContent||'').replace(/\\s+/g,' ').trim();" +
            "return el.href+'\\u0001'+t;" +
            "})();"
        ) { result ->
            val decoded = decodeJsSelection(result)
            if (decoded.isBlank()) {
                callback("", "")
                return@evaluateJavascript
            }
            // Split on U+0001 (a control character no URL or text will
            // contain) to separate href from text without needing a JSON
            // parser here.
            val idx = decoded.indexOf('\u0001')
            if (idx < 0) {
                callback(decoded.trim(), "")
            } else {
                callback(decoded.substring(0, idx).trim(), decoded.substring(idx + 1).trim())
            }
        }
    }

    override fun startActionMode(callback: ActionMode.Callback?, type: Int): ActionMode? {
        return super.startActionMode(wrap(callback), type)
    }

    override fun startActionMode(callback: ActionMode.Callback?): ActionMode? {
        return super.startActionMode(wrap(callback))
    }

    private fun wrap(orig: ActionMode.Callback?): ActionMode.Callback {
        return object : ActionMode.Callback {
            override fun onCreateActionMode(mode: ActionMode?, menu: Menu?): Boolean {
                val ret = orig?.onCreateActionMode(mode, menu) ?: true
                // Append our custom menu items. High order values keep them at
                // the end of the toolbar (after Copy/Share/Translate/etc.).
                menu?.add(0, MENU_ID_SEARCH_MARKVAULT, 997, "Search in MarkVault")
                menu?.add(0, MENU_ID_SEARCH_WOL,       998, "Search wol.jw.org")
                menu?.add(0, MENU_ID_SEARCH_JWORG,     999, "Search jw.org")
                menu?.add(0, MENU_ID_SHARE,            1000, "Share")
                return ret
            }

            override fun onPrepareActionMode(mode: ActionMode?, menu: Menu?): Boolean {
                return orig?.onPrepareActionMode(mode, menu) ?: false
            }

            override fun onActionItemClicked(mode: ActionMode?, item: MenuItem?): Boolean {
                val id = item?.itemId ?: return orig?.onActionItemClicked(mode, item) ?: false
                if (id !in CUSTOM_IDS) {
                    return orig?.onActionItemClicked(mode, item) ?: false
                }
                // CRITICAL fix: capture selection BEFORE finishing the action
                // mode. In v4.0/4.1, mode.finish() ran synchronously which often
                // cleared the selection before window.getSelection() could read
                // it — that's why "Search in MarkVault" was unstable. Move
                // finish() into the JS callback and we always get the text.
                evaluateJavascript(
                    "(function(){return window.getSelection().toString();})();"
                ) { jsonValue ->
                    val text = decodeJsSelection(jsonValue).trim()
                    if (text.isNotEmpty()) {
                        when (id) {
                            MENU_ID_SEARCH_MARKVAULT -> onSearchInMarkVault?.invoke(text)
                            MENU_ID_SEARCH_WOL       -> onSearchInWol?.invoke(text)
                            MENU_ID_SEARCH_JWORG     -> onSearchInJwOrg?.invoke(text)
                            MENU_ID_SHARE            -> {
                                val cb = onShare
                                if (cb != null) cb(text)
                                else fallbackShare(text)
                            }
                        }
                    }
                    // Finish AFTER capturing — selection survives long enough
                    // for window.getSelection().toString() to return a value.
                    runCatching { mode?.finish() }
                }
                return true
            }

            override fun onDestroyActionMode(mode: ActionMode?) {
                orig?.onDestroyActionMode(mode)
            }
        }
    }

    /**
     * Default share action used when no custom [onShare] callback is wired.
     * Fires an `ACTION_SEND` intent with plain text — the system share sheet
     * appears, letting the user pick any target app.
     */
    private fun fallbackShare(text: String) {
        runCatching {
            val intent = android.content.Intent(android.content.Intent.ACTION_SEND).apply {
                type = "text/plain"
                putExtra(android.content.Intent.EXTRA_TEXT, text)
                addFlags(android.content.Intent.FLAG_ACTIVITY_NEW_TASK)
            }
            val chooser = android.content.Intent.createChooser(intent, "Share via")
                .addFlags(android.content.Intent.FLAG_ACTIVITY_NEW_TASK)
            context.startActivity(chooser)
        }
    }

    companion object {
        private const val MENU_ID_SEARCH_MARKVAULT = 0x00C0FFEE
        private const val MENU_ID_SEARCH_WOL       = 0x00C0FFEF
        // v4.12.0 — two new entries the user explicitly asked for.
        private const val MENU_ID_SEARCH_JWORG     = 0x00C0FFF0
        private const val MENU_ID_SHARE            = 0x00C0FFF1

        private val CUSTOM_IDS = setOf(
            MENU_ID_SEARCH_MARKVAULT,
            MENU_ID_SEARCH_WOL,
            MENU_ID_SEARCH_JWORG,
            MENU_ID_SHARE,
        )
    }
}

private fun decodeJsSelection(jsonValue: String?): String {
    if (jsonValue.isNullOrBlank() || jsonValue == "null") return ""
    var s = jsonValue.trim()
    if (s.startsWith("\"") && s.endsWith("\"")) s = s.substring(1, s.length - 1)
    val sb = StringBuilder(s.length)
    var i = 0
    while (i < s.length) {
        val c = s[i]
        if (c == '\\' && i + 1 < s.length) {
            when (val n = s[i + 1]) {
                '"', '\\', '/' -> { sb.append(n); i += 2 }
                'n' -> { sb.append('\n'); i += 2 }
                'r' -> { sb.append('\r'); i += 2 }
                't' -> { sb.append('\t'); i += 2 }
                'u' -> {
                    if (i + 5 < s.length) {
                        val hex = s.substring(i + 2, i + 6)
                        val cp = runCatching { hex.toInt(16) }.getOrNull()
                        if (cp != null) sb.append(cp.toChar()) else sb.append(n)
                        i += 6
                    } else { sb.append(n); i += 2 }
                }
                else -> { sb.append(n); i += 2 }
            }
        } else {
            sb.append(c); i++
        }
    }
    return sb.toString()
}

/**
 * Public alias used by other UI files (WebPopup, ReaderScreen) that also need
 * to decode JSON strings returned by WebView.evaluateJavascript. Keeps the
 * private implementation single-sourced.
 */
fun decodeJsSelectionPublic(jsonValue: String?): String = decodeJsSelection(jsonValue)
