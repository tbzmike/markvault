package com.tebogo.markvault.ui

import android.content.Context
import android.util.AttributeSet
import android.view.ActionMode
import android.view.Menu
import android.view.MenuItem
import android.webkit.WebView

/**
 * WebView that injects custom entries into the native text-selection ActionMode:
 *
 *   • "Search in MarkVault"   — runs an FTS search over the local library
 *   • "Search in wol.jw.org"  — opens wol.jw.org search for the selected text
 *
 * Both menu items are added alongside the platform Copy/Share buttons, regardless
 * of whether this view is hosted in the main browser screen, the WebPopup bottom
 * sheet, the fullscreen popup, or the markdown reader. Behaviour is consistent
 * because we wrap whichever ActionMode.Callback the platform passes us.
 *
 * v4.2 fixes:
 *   1. INSTABILITY — earlier code called `mode.finish()` synchronously, which
 *      cleared the selection BEFORE `window.getSelection().toString()` could
 *      run via evaluateJavascript. Now finish() runs INSIDE the JS callback so
 *      we always capture the text first.
 *   2. WOL SEARCH on highlighted text — second menu item added.
 *   3. WORKS IN POPUP — by virtue of using SelectionWebView in WebPopup too,
 *      not just the main browser.
 */
class SelectionWebView @JvmOverloads constructor(
    context: Context,
    attrs: AttributeSet? = null
) : WebView(context, attrs) {

    /** Wired from Compose — receives the selected text when "Search in MarkVault" is tapped. */
    var onSearchInMarkVault: ((String) -> Unit)? = null

    /** Wired from Compose — receives the selected text when "Search in wol.jw.org" is tapped. */
    var onSearchInWol: ((String) -> Unit)? = null

    override fun startActionMode(callback: ActionMode.Callback?, type: Int): ActionMode? {
        return super.startActionMode(wrap(callback), type)
    }

    override fun startActionMode(callback: ActionMode.Callback?): ActionMode? {
        return super.startActionMode(wrap(callback))
    }

    private fun wrap(orig: ActionMode.Callback?): ActionMode.Callback {
        return object : ActionMode.Callback {
            override fun onCreateActionMode(mode: ActionMode?, menu: Menu?): Boolean {
                val ret = orig?.onCreateActionMode(mode, menu) ?: true
                // Append our custom menu items. High order values keep them at
                // the end of the toolbar (after Copy/Share/Translate/etc.).
                menu?.add(0, MENU_ID_SEARCH_MARKVAULT, 998, "Search in MarkVault")
                menu?.add(0, MENU_ID_SEARCH_WOL,       999, "Search in wol.jw.org")
                return ret
            }

            override fun onPrepareActionMode(mode: ActionMode?, menu: Menu?): Boolean {
                return orig?.onPrepareActionMode(mode, menu) ?: false
            }

            override fun onActionItemClicked(mode: ActionMode?, item: MenuItem?): Boolean {
                val id = item?.itemId ?: return orig?.onActionItemClicked(mode, item) ?: false
                if (id != MENU_ID_SEARCH_MARKVAULT && id != MENU_ID_SEARCH_WOL) {
                    return orig?.onActionItemClicked(mode, item) ?: false
                }
                // CRITICAL fix: capture selection BEFORE finishing the action
                // mode. In v4.0/4.1, mode.finish() ran synchronously which often
                // cleared the selection before window.getSelection() could read
                // it — that's why "Search in MarkVault" was unstable. Move
                // finish() into the JS callback and we always get the text.
                evaluateJavascript(
                    "(function(){return window.getSelection().toString();})();"
                ) { jsonValue ->
                    val text = decodeJsSelection(jsonValue).trim()
                    if (text.isNotEmpty()) {
                        when (id) {
                            MENU_ID_SEARCH_MARKVAULT -> onSearchInMarkVault?.invoke(text)
                            MENU_ID_SEARCH_WOL       -> onSearchInWol?.invoke(text)
                        }
                    }
                    // Finish AFTER capturing — selection survives long enough
                    // for window.getSelection().toString() to return a value.
                    runCatching { mode?.finish() }
                }
                return true
            }

            override fun onDestroyActionMode(mode: ActionMode?) {
                orig?.onDestroyActionMode(mode)
            }
        }
    }

    companion object {
        private const val MENU_ID_SEARCH_MARKVAULT = 0x00C0FFEE
        private const val MENU_ID_SEARCH_WOL       = 0x00C0FFEF
    }
}

private fun decodeJsSelection(jsonValue: String?): String {
    if (jsonValue.isNullOrBlank() || jsonValue == "null") return ""
    var s = jsonValue.trim()
    if (s.startsWith("\"") && s.endsWith("\"")) s = s.substring(1, s.length - 1)
    val sb = StringBuilder(s.length)
    var i = 0
    while (i < s.length) {
        val c = s[i]
        if (c == '\\' && i + 1 < s.length) {
            when (val n = s[i + 1]) {
                '"', '\\', '/' -> { sb.append(n); i += 2 }
                'n' -> { sb.append('\n'); i += 2 }
                'r' -> { sb.append('\r'); i += 2 }
                't' -> { sb.append('\t'); i += 2 }
                'u' -> {
                    if (i + 5 < s.length) {
                        val hex = s.substring(i + 2, i + 6)
                        val cp = runCatching { hex.toInt(16) }.getOrNull()
                        if (cp != null) sb.append(cp.toChar()) else sb.append(n)
                        i += 6
                    } else { sb.append(n); i += 2 }
                }
                else -> { sb.append(n); i += 2 }
            }
        } else {
            sb.append(c); i++
        }
    }
    return sb.toString()
}

/**
 * Public alias used by other UI files (WebPopup, ReaderScreen) that also need
 * to decode JSON strings returned by WebView.evaluateJavascript. Keeps the
 * private implementation single-sourced.
 */
fun decodeJsSelectionPublic(jsonValue: String?): String = decodeJsSelection(jsonValue)
