package com.tebogo.markvault.ui

import android.annotation.SuppressLint
import android.webkit.WebResourceRequest
import android.webkit.WebResourceError
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.Toast
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxScope
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.navigationBars
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.windowInsetsPadding
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.ExtendedFloatingActionButton
import androidx.compose.material3.FloatingActionButtonDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import com.tebogo.markvault.AppViewModel
import com.tebogo.markvault.SaveResult
import kotlinx.coroutines.channels.Channel
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.suspendCancellableCoroutine
import kotlinx.coroutines.withTimeoutOrNull
import kotlin.coroutines.resume

/**
 * v5.4.89cc — WebViewer multi-selection helpers.
 *
 * Two important changes over v5.4.88cc based on user report:
 *
 *  1. **Highlight was invisible.** The old CSS relied on `outline` which
 *     can be clipped by ancestor `overflow: hidden` and on
 *     `background-color` which competes with the site's own
 *     `!important` rules. Replaced with a heavy multi-signal treatment:
 *     inward-drawn outline (`outline-offset: -4px` — can't be clipped),
 *     inset box-shadow, saturated background tint, AND a physical
 *     `.mv-badge` DIV child inserted in the top-left corner so there's
 *     always a "✓ SELECTED" flag even on cards with hostile CSS.
 *
 *  2. **Every save failed.** The old HTTP-based batch (v5.4.88cc)
 *     couldn't get past Cloudflare's bot heuristics on jw.org — every
 *     request returned a challenge stub instead of the real HTML. Fixed
 *     by delegating the load loop to a hidden 1dp WebView which shares
 *     Chromium's TLS session and cookie jar with the visible tab. Same
 *     WebView instance is reused across all URLs in the batch to keep
 *     memory pressure down. See [HiddenBatchSaver].
 *
 * Three composables + a handful of JS injection helpers are exported:
 *  - [SelectionMenuItems] — DropdownMenuItems for the overflow menu.
 *  - [WebSelectionFab] — the bottom-start save FAB.
 *  - [HiddenBatchSaver] — off-screen WebView that runs the batch.
 *  - [applySelectionOnLoad] — drop into `onPageFinished` to restore
 *    highlights after navigation.
 */

// ─────────────────────────────────────────────────────────────────────────
// JavaScript payloads
// ─────────────────────────────────────────────────────────────────────────

/**
 * Enable the selection-mode stylesheet on the current page. Idempotent:
 * safe to re-run on every `onPageFinished`, and safe to run repeatedly if
 * the user turns the mode on/off/on again. The CSS is deliberately
 * over-specified so it wins against sites like jw.org that heavily style
 * their own cards:
 *   - `outline-offset: -4px` draws the outline INSIDE the box so parents
 *     with `overflow: hidden` can't clip it away.
 *   - `box-shadow: inset ...` reinforces the outline with a second inner
 *     border that sites even more rarely target.
 *   - `background-color` with `!important` swamps the site's own bg
 *     rule, and the same rule is duplicated on `.mv-selected *` so
 *     children with their own opaque backgrounds don't hide the tint.
 *   - A physical `.mv-badge` DIV (inserted by JS below, not `::before`)
 *     is placed absolute-in-corner as a belt-and-braces "SELECTED" flag
 *     that survives even the weirdest CSS.
 *   - `-webkit-user-select: none` on anchors while mode is on stops the
 *     WebView from grabbing text-selection handles on long-press —
 *     otherwise the user gets the copy/paste toolbar competing with the
 *     link long-press we want.
 */
internal const val SELECTION_CSS_ON_JS = """
(function() {
  var s = document.getElementById('mv-selection-style');
  if (!s) {
    s = document.createElement('style');
    s.id = 'mv-selection-style';
    s.textContent = '' +
      '.mv-selected {' +
      '  position: relative !important;' +
      '  outline: 4px solid #22c55e !important;' +
      '  outline-offset: -4px !important;' +
      '  outline-style: solid !important;' +
      '  background-color: rgba(34,197,94,0.28) !important;' +
      '  box-shadow: inset 0 0 0 4px rgba(34,197,94,0.35), 0 0 0 4px rgba(34,197,94,0.55) !important;' +
      '  transition: none !important;' +
      '} ' +
      '.mv-selected * {' +
      '  background-color: rgba(34,197,94,0.10) !important;' +
      '} ' +
      // v5.4.90cc — "Already saved" treatment. Distinct blue tint so the
      // user can tell at a glance that an item is already in the library
      // (and would be a no-op if they picked it). They can still
      // long-press to select for re-save; the blue then flips to green.
      '.mv-already-saved:not(.mv-selected) {' +
      '  position: relative !important;' +
      '  outline: 3px dashed #3b82f6 !important;' +
      '  outline-offset: -3px !important;' +
      '  background-color: rgba(59,130,246,0.15) !important;' +
      '  transition: none !important;' +
      '} ' +
      '.mv-badge {' +
      '  position: absolute !important;' +
      '  top: 0 !important;' +
      '  left: 0 !important;' +
      '  z-index: 2147483647 !important;' +
      '  background: #16a34a !important;' +
      '  color: #ffffff !important;' +
      '  padding: 4px 10px !important;' +
      '  font-size: 12px !important;' +
      '  font-weight: 800 !important;' +
      '  font-family: -apple-system, BlinkMacSystemFont, sans-serif !important;' +
      '  border-radius: 0 0 8px 0 !important;' +
      '  box-shadow: 0 2px 6px rgba(0,0,0,0.35) !important;' +
      '  pointer-events: none !important;' +
      '  letter-spacing: 0.5px !important;' +
      '  line-height: 1 !important;' +
      '  display: block !important;' +
      '  text-transform: uppercase !important;' +
      '} ' +
      // v5.4.90cc — "In library" badge. Same slot, blue palette, shows
      // when a previously-saved article surfaces on a page.
      '.mv-badge-lib {' +
      '  position: absolute !important;' +
      '  top: 0 !important;' +
      '  left: 0 !important;' +
      '  z-index: 2147483647 !important;' +
      '  background: #2563eb !important;' +
      '  color: #ffffff !important;' +
      '  padding: 4px 10px !important;' +
      '  font-size: 11px !important;' +
      '  font-weight: 700 !important;' +
      '  font-family: -apple-system, BlinkMacSystemFont, sans-serif !important;' +
      '  border-radius: 0 0 8px 0 !important;' +
      '  box-shadow: 0 2px 6px rgba(0,0,0,0.35) !important;' +
      '  pointer-events: none !important;' +
      '  letter-spacing: 0.5px !important;' +
      '  line-height: 1 !important;' +
      '  display: block !important;' +
      '  text-transform: uppercase !important;' +
      '} ' +
      'a[href], a[href] * {' +
      '  -webkit-user-select: none !important;' +
      '  user-select: none !important;' +
      '  -webkit-touch-callout: none !important;' +
      '  -webkit-tap-highlight-color: rgba(34,197,94,0.30) !important;' +
      '}';
    (document.head || document.documentElement).appendChild(s);
  }
})();
"""

/**
 * v5.4.105cc — Strip the green `.mv-selected` treatment (outline + tint
 * + "SAVED" badge) from every element on the page, WITHOUT touching the
 * blue `.mv-already-saved` / `.mv-badge-lib` library flags. Fired by
 * the "Clear selection" menu action so basket-clear also visually
 * unpicks every card the user had selected. Previously the menu just
 * emptied the VM basket but left the DOM green outlines behind —
 * confusing.
 */
internal const val SELECTION_CLEAR_PICKS_JS = """
(function() {
  var picked = document.querySelectorAll('.mv-selected');
  for (var i = 0; i < picked.length; i++) picked[i].classList.remove('mv-selected');
  var badges = document.querySelectorAll('.mv-badge');
  for (var j = 0; j < badges.length; j++) {
    if (badges[j].parentNode) badges[j].parentNode.removeChild(badges[j]);
  }
})();
"""

/** v5.4.105cc — Injects [SELECTION_CLEAR_PICKS_JS]. */
internal fun webViewClearPickedHighlights(webView: WebView) {
    webView.evaluateJavascript(SELECTION_CLEAR_PICKS_JS, null)
}

/**
 * Turn selection mode off: strip the stylesheet, remove the class from
 * everything currently marked, and delete any badge DIVs we injected.
 * Idempotent.
 */
internal const val SELECTION_CSS_OFF_JS = """
(function() {
  var s = document.getElementById('mv-selection-style');
  if (s && s.parentNode) s.parentNode.removeChild(s);
  var picked = document.querySelectorAll('.mv-selected');
  for (var i = 0; i < picked.length; i++) picked[i].classList.remove('mv-selected');
  var alreadySaved = document.querySelectorAll('.mv-already-saved');
  for (var a = 0; a < alreadySaved.length; a++) alreadySaved[a].classList.remove('mv-already-saved');
  var badges = document.querySelectorAll('.mv-badge, .mv-badge-lib');
  for (var j = 0; j < badges.length; j++) {
    if (badges[j].parentNode) badges[j].parentNode.removeChild(badges[j]);
  }
})();
"""

/**
 * Paint the "already saved" (blue, dashed) treatment on every anchor
 * whose href appears in the [%URLS%] JSON array. Called on page-load
 * while selection mode is ON so cards that are already in the library
 * are visually distinct — the user can then choose to pick them for
 * re-save (which flips them to green) or leave them alone.
 */
private const val MARK_ALREADY_SAVED_TEMPLATE = """
(function() {
  var urls = %URLS%;
  var titles = %TITLES%;
  if ((!urls || urls.length === 0) && (!titles || titles.length === 0)) return;
  // v5.4.100cc — Canonicalise both sides before comparing. The
  // Kotlin cache stores URLs with fragment stripped, non-root
  // trailing slash trimmed, and scheme+host lowercased (see
  // AppViewModel.canonicalizeUrl); without matching that here, jw.org
  // anchor hrefs (which often carry a trailing slash) would miss the
  // "IN LIBRARY" badge even when the article is saved.
  function canon(u) {
    if (!u) return "";
    var s = String(u);
    var h = s.indexOf("#");
    if (h >= 0) s = s.substring(0, h);
    var sep = s.indexOf("://");
    if (sep > 0) {
      var afterScheme = sep + 3;
      var slashIdx = s.indexOf("/", afterScheme);
      var pathStart = slashIdx < 0 ? s.length : slashIdx;
      s = s.substring(0, pathStart).toLowerCase() +
          (pathStart < s.length ? s.substring(pathStart) : "");
    }
    if (s.charAt(s.length - 1) === "/") {
      var slashes = 0;
      for (var i = 0; i < s.length; i++) if (s.charAt(i) === "/") slashes++;
      if (slashes > 3) {
        while (s.length > 1 && s.charAt(s.length - 1) === "/") {
          s = s.substring(0, s.length - 1);
        }
      }
    }
    return s;
  }
  // v5.4.104cc — Title normalisation. Mirrors Kotlin's
  // AppViewModel.normalizeTitle: lowercase, replace non-letter /
  // non-digit / non-whitespace runs with a single space, collapse
  // whitespace. Uses the /u regex flag so \p{L} catches every Unicode
  // letter — matches Kotlin's \p{IsLatin} closely enough for jw.org
  // and Sepedi content. WebViews on Android 8+ support the /u flag.
  function normTitle(s) {
    if (!s) return "";
    var t = String(s).trim().toLowerCase();
    try {
      t = t.replace(/[^\p{L}0-9\s]+/gu, " ");
    } catch (e) {
      // Older WebView without /u flag support — fall back to ASCII
      // punctuation strip. Still better than no title matching.
      t = t.replace(/[^a-z0-9\s]+/g, " ");
    }
    return t.replace(/\s+/g, " ").trim();
  }
  var urlSet = {};
  if (urls) for (var i = 0; i < urls.length; i++) urlSet[canon(urls[i])] = true;
  var titleSet = {};
  if (titles) for (var i = 0; i < titles.length; i++) titleSet[titles[i]] = true;
  // Extract the visible article title of an anchor. jw.org listing
  // pages usually render article cards where the anchor wraps a
  // <h1>/<h2>/<h3>/<span class="cardTitleBlock"> that holds the real
  // title, with side-line text ("2 min read", "Jun 15") mixed in
  // around it. `innerText` returns everything, which drags the noise
  // into the match. To reduce false positives, prefer the innermost
  // heading element's text if the anchor contains one; fall back to
  // the anchor's own trimmed innerText.
  function anchorTitle(a) {
    var h = a.querySelector(
      'h1, h2, h3, h4, h5, h6, .cardTitleBlock, ' +
      '.publicationTitle, .cardLine1, [role="heading"]'
    );
    var raw = (h && (h.innerText || h.textContent)) ||
              (a.innerText || a.textContent) || "";
    return normTitle(raw);
  }
  var links = document.querySelectorAll('a[href]');
  var CONTAINER_SEL =
    'article, .publication, .publicationDesc, .publicationTitle, ' +
    '.publicationCardContent, .synopsis, .linkCard, .cardTitleBlock, ' +
    '.card, .cardLine1, .cardLine2, .searchResult, .doc, ' +
    '[role="article"], li, .item';
  for (var j = 0; j < links.length; j++) {
    var link = links[j];
    var matched = false;
    // URL match (any length)
    if (urlSet[canon(link.href)]) matched = true;
    // Title match (>= 15 chars normalised, to avoid false positives
    // from "Read more" / "View" etc.)
    if (!matched) {
      var t = anchorTitle(link);
      if (t.length >= 15 && titleSet[t]) matched = true;
    }
    if (!matched) continue;
    var container = link.closest(CONTAINER_SEL);
    var el = container || link;
    // Don't overwrite the green "SAVED" chip if user has already picked
    // this one for re-save.
    if (el.classList.contains('mv-selected')) continue;
    el.classList.add('mv-already-saved');
    var already = false;
    for (var k = 0; k < el.children.length; k++) {
      if (el.children[k].classList && el.children[k].classList.contains('mv-badge-lib')) {
        already = true;
        break;
      }
    }
    if (!already) {
      var badge = document.createElement('div');
      badge.className = 'mv-badge-lib';
      badge.textContent = '\u2713 IN LIBRARY';
      el.appendChild(badge);
    }
  }
})();
"""

/**
 * Toggle `.mv-selected` and the corner badge for every anchor whose href
 * equals `%URL%`. Handles two important edge cases:
 *
 *  - Climbs to the nearest card-like ancestor before marking, so the
 *    highlight actually outlines the whole clickable region rather than a
 *    tiny inline link. Selector list is aggressive (includes classes seen
 *    on jw.org, wol.jw.org, and generic list markup).
 *  - Injects a real `<div class="mv-badge">` child (not `::before`) so the
 *    "✓ SELECTED" flag is guaranteed to render — pseudo-elements can be
 *    suppressed by aggressive site CSS but a real DOM node can't be.
 *
 * Returns the matched count as a JS number so Kotlin can Toast a warning
 * when zero elements matched (usually means the href stored on the anchor
 * differs from what `WebView.hitTestResult.extra` gave us, e.g. because
 * of a redirect).
 */
private const val TOGGLE_HIGHLIGHT_TEMPLATE = """
(function() {
  var target = %URL%;
  var selected = %SEL%;
  var links = document.querySelectorAll('a[href]');
  var matched = 0;

  function markContainer(el, on) {
    if (on) {
      el.classList.add('mv-selected');
      // Insert a badge as a direct child if we haven't already.
      var existing = null;
      for (var k = 0; k < el.children.length; k++) {
        if (el.children[k].classList && el.children[k].classList.contains('mv-badge')) {
          existing = el.children[k];
          break;
        }
      }
      if (!existing) {
        var badge = document.createElement('div');
        badge.className = 'mv-badge';
        badge.textContent = '\u2713 SAVED';
        el.appendChild(badge);
      }
    } else {
      el.classList.remove('mv-selected');
      var children = el.children;
      for (var m = children.length - 1; m >= 0; m--) {
        if (children[m].classList && children[m].classList.contains('mv-badge')) {
          el.removeChild(children[m]);
        }
      }
    }
  }

  for (var i = 0; i < links.length; i++) {
    if (links[i].href !== target) continue;
    matched++;
    // Try to escalate to a card container. If none matches, mark the
    // anchor itself — some sites (mobile jw.org menus) use bare <a>.
    var container = links[i].closest(
      'article, .publication, .publicationDesc, .publicationTitle, ' +
      '.publicationCardContent, .synopsis, .linkCard, .cardTitleBlock, ' +
      '.card, .cardLine1, .cardLine2, .searchResult, .doc, ' +
      '[role="article"], li, .item'
    );
    var elToMark = container || links[i];
    // Also mark the direct anchor when we climbed — one more visual anchor.
    if (container && container !== links[i]) {
      links[i].classList.toggle('mv-selected', selected);
    }
    markContainer(elToMark, selected);
  }
  return matched;
})();
"""

/**
 * Re-apply highlights for a whole list of URLs. Used from
 * `onPageFinished` so the user's basket stays visually consistent as
 * they navigate — cards that appear on multiple listing pages get their
 * green flag on each one. Uses the same container-climb logic as
 * [TOGGLE_HIGHLIGHT_TEMPLATE].
 */
private const val REHIGHLIGHT_ALL_TEMPLATE = """
(function() {
  var urls = %URLS%;
  if (!urls || urls.length === 0) return;
  var set = {};
  for (var i = 0; i < urls.length; i++) set[urls[i]] = true;
  var links = document.querySelectorAll('a[href]');
  for (var j = 0; j < links.length; j++) {
    if (!set[links[j].href]) continue;
    var container = links[j].closest(
      'article, .publication, .publicationDesc, .publicationTitle, ' +
      '.publicationCardContent, .synopsis, .linkCard, .cardTitleBlock, ' +
      '.card, .cardLine1, .cardLine2, .searchResult, .doc, ' +
      '[role="article"], li, .item'
    );
    var el = container || links[j];
    el.classList.add('mv-selected');
    // Also add a badge as a real DOM child (not ::before).
    var already = false;
    for (var k = 0; k < el.children.length; k++) {
      if (el.children[k].classList && el.children[k].classList.contains('mv-badge')) {
        already = true;
        break;
      }
    }
    if (!already) {
      var badge = document.createElement('div');
      badge.className = 'mv-badge';
      badge.textContent = '\u2713 SAVED';
      el.appendChild(badge);
    }
  }
})();
"""

// ─────────────────────────────────────────────────────────────────────────
// Kotlin-side helpers (JS injection)
// ─────────────────────────────────────────────────────────────────────────

/** JSON-escape a string for safe embedding as a JS string literal. */
private fun jsQuote(s: String): String {
    val sb = StringBuilder(s.length + 2)
    sb.append('"')
    for (ch in s) {
        when (ch) {
            '\\' -> sb.append("\\\\")
            '"' -> sb.append("\\\"")
            '\n' -> sb.append("\\n")
            '\r' -> sb.append("\\r")
            '\t' -> sb.append("\\t")
            '<' -> sb.append("\\u003C")
            '>' -> sb.append("\\u003E")
            else -> if (ch.code < 0x20) sb.append("\\u%04x".format(ch.code)) else sb.append(ch)
        }
    }
    sb.append('"')
    return sb.toString()
}

/** Turn selection mode on visually — inject the CSS + badge machinery. */
internal fun webViewApplySelectionCss(webView: WebView, on: Boolean) {
    webView.evaluateJavascript(
        if (on) SELECTION_CSS_ON_JS else SELECTION_CSS_OFF_JS,
        null
    )
}

/**
 * Add or remove the `.mv-selected` + corner badge for a specific URL.
 * The matched-count return value from the JS is currently discarded — a
 * zero result would indicate the anchor href differs from what
 * `WebView.hitTestResult` reported, which is worth surfacing only if
 * users complain the highlight doesn't stick.
 */
internal fun webViewHighlightUrl(webView: WebView, url: String, selected: Boolean) {
    val js = TOGGLE_HIGHLIGHT_TEMPLATE
        .replace("%URL%", jsQuote(url))
        .replace("%SEL%", if (selected) "true" else "false")
    webView.evaluateJavascript(js, null)
}

/** Restore highlights for every URL currently in the selection basket. */
internal fun webViewRehighlightAll(webView: WebView, urls: List<String>) {
    if (urls.isEmpty()) return
    val jsonArr = urls.joinToString(prefix = "[", postfix = "]", separator = ",") { jsQuote(it) }
    val js = REHIGHLIGHT_ALL_TEMPLATE.replace("%URLS%", jsonArr)
    webView.evaluateJavascript(js, null)
}

/**
 * Paint the "already saved" (blue, dashed) treatment for library items.
 *
 * v5.4.104cc — Now accepts both URLs AND titles. The JS side checks
 * each anchor first by canonical URL, then by normalised inner-heading
 * text; either match paints the "IN LIBRARY" badge. Title fallback
 * catches library notes whose source URL is either blank (hand-
 * imported markdown) or a variant that canonicalisation couldn't
 * fold — e.g. a jw.org share link with different tracking params, or
 * a mobile vs desktop sub-domain. Title matching is guarded to ≥15
 * normalised chars on the JS side to avoid "Read more" / "View" style
 * false positives.
 */
internal fun webViewMarkAlreadySaved(
    webView: WebView,
    urls: Set<String>,
    titles: Set<String>
) {
    if (urls.isEmpty() && titles.isEmpty()) return
    val urlsJson = urls.joinToString(prefix = "[", postfix = "]", separator = ",") { jsQuote(it) }
    val titlesJson = titles.joinToString(prefix = "[", postfix = "]", separator = ",") { jsQuote(it) }
    val js = MARK_ALREADY_SAVED_TEMPLATE
        .replace("%URLS%", urlsJson)
        .replace("%TITLES%", titlesJson)
    webView.evaluateJavascript(js, null)
}

/**
 * Drop-in helper for `onPageFinished`: if selection mode is currently
 * active, re-inject CSS and re-mark any pre-selected cards on the freshly
 * loaded page. Cheap when mode is off (single boolean read).
 *
 * v5.4.90cc — Also paints the blue "IN LIBRARY" treatment on any anchor
 * whose URL is in [AppViewModel.savedOfflineUrls], so the user sees at a
 * glance which items are already in their offline library.
 *
 * v5.4.104cc — Title matching added alongside URL matching (see
 * [webViewMarkAlreadySaved]).
 *
 * v5.4.105cc — Reverted the "always mark" behaviour: library flags
 * fire ONLY when one of the two selection modes is active. This
 * matches the mental model — flags are a picking aid, not
 * ambient chrome, and painting outlines on every browse would
 * interfere with normal reading.
 */
internal fun applySelectionOnLoad(webView: WebView, vm: AppViewModel) {
    // v5.4.99cc — Also fires under Multi Selection Mode so the green
    // head-highlights survive page reloads and back-nav within the
    // WebViewer session.
    if (!vm.webSelectionMode.value && !vm.webMultiSelectionMode.value) return
    webViewApplySelectionCss(webView, true)
    webViewRehighlightAll(webView, vm.webSelectionItems.value.map { it.url })
    webViewMarkAlreadySaved(webView, vm.savedOfflineUrls.value, vm.savedTitles.value)
}

/**
 * Decode a JSON-encoded string returned by `WebView.evaluateJavascript`.
 * The callback receives a value like `"<html>\u003E</html>"` — outer
 * quotes plus standard JSON escapes. Strips the outer quotes and
 * un-escapes `\\` `\"` `\n` `\r` `\t` and `\uXXXX` so the caller gets the
 * raw payload.
 *
 * Duplicated from [SelectionWebView.decodeJsSelectionPublic] rather than
 * imported to keep this file self-contained (that helper is deliberately
 * scoped to selection-menu decoding; leaning on it from batch-save code
 * would create a semantically weird dependency).
 */
private fun decodeJsHtmlString(jsonValue: String?): String {
    if (jsonValue.isNullOrBlank() || jsonValue == "null") return ""
    val trimmed = jsonValue.trim()
    val body = if (trimmed.length >= 2 && trimmed.first() == '"' && trimmed.last() == '"') {
        trimmed.substring(1, trimmed.length - 1)
    } else trimmed
    val sb = StringBuilder(body.length)
    var i = 0
    while (i < body.length) {
        val c = body[i]
        if (c != '\\') { sb.append(c); i++; continue }
        if (i + 1 >= body.length) { sb.append(c); i++; continue }
        when (val n = body[i + 1]) {
            '\\' -> { sb.append('\\'); i += 2 }
            '"' -> { sb.append('"'); i += 2 }
            'n' -> { sb.append('\n'); i += 2 }
            'r' -> { sb.append('\r'); i += 2 }
            't' -> { sb.append('\t'); i += 2 }
            '/' -> { sb.append('/'); i += 2 }
            'b' -> { sb.append('\b'); i += 2 }
            'f' -> { sb.append('\u000C'); i += 2 }
            'u' -> {
                if (i + 5 < body.length) {
                    val hex = body.substring(i + 2, i + 6)
                    val code = hex.toIntOrNull(16)
                    if (code != null) { sb.append(code.toChar()); i += 6 }
                    else { sb.append(c); i++ }
                } else { sb.append(c); i++ }
            }
            else -> { sb.append(n); i += 2 }
        }
    }
    return sb.toString()
}

// ─────────────────────────────────────────────────────────────────────────
// Composables
// ─────────────────────────────────────────────────────────────────────────

/**
 * Two DropdownMenuItems for the WebViewer's overflow menu:
 *  - "🎯 Selection mode: ON/OFF" — the master toggle.
 *  - "🧹 Clear selection (n)" — only shown when the basket is non-empty.
 *
 * The composable is a plain function that emits DropdownMenuItems as
 * siblings inside the caller's `DropdownMenu { ... }` scope.
 *
 * [onAfterAction] runs after each item (typically closes the menu).
 */
@Composable
internal fun SelectionMenuItems(
    vm: AppViewModel,
    webViewProvider: () -> WebView?,
    onAfterAction: () -> Unit
) {
    val mode by vm.webSelectionMode.collectAsState()
    val multiMode by vm.webMultiSelectionMode.collectAsState()
    val items by vm.webSelectionItems.collectAsState()

    DropdownMenuItem(
        text = {
            Text(
                if (mode) "\uD83C\uDFAF Selection mode: ON  •  tap to disable"
                else "\uD83C\uDFAF Enable selection mode"
            )
        },
        onClick = {
            val next = !mode
            vm.setWebSelectionMode(next)
            val wv = webViewProvider()
            if (wv != null) {
                webViewApplySelectionCss(wv, next)
                if (next) {
                    webViewRehighlightAll(wv, vm.webSelectionItems.value.map { it.url })
                    // v5.4.90cc — Paint blue "IN LIBRARY" flags on cards
                    // the user has previously saved so they can dedup at
                    // a glance.
                    webViewMarkAlreadySaved(wv, vm.savedOfflineUrls.value, vm.savedTitles.value)
                }
            }
            onAfterAction()
        }
    )
    // v5.4.99cc — Multi Selection Mode toggle. Same visual treatment
    // as normal selection (green outline + badge on the tapped head),
    // but each long-press expands into every article link inside the
    // target page instead of adding a single URL. Mutually exclusive
    // with plain Selection Mode — turning either one on flips the
    // other off (VM handles the exclusion).
    DropdownMenuItem(
        text = {
            Text(
                if (multiMode)
                    "\uD83D\uDD17 Multi selection: ON  •  tap to disable"
                else
                    "\uD83D\uDD17 Enable multi selection"
            )
        },
        onClick = {
            val next = !multiMode
            vm.setWebMultiSelectionMode(next)
            val wv = webViewProvider()
            if (wv != null) {
                webViewApplySelectionCss(wv, next)
                if (next) {
                    webViewRehighlightAll(
                        wv, vm.webSelectionItems.value.map { it.url }
                    )
                    webViewMarkAlreadySaved(wv, vm.savedOfflineUrls.value, vm.savedTitles.value)
                }
            }
            onAfterAction()
        }
    )
    if (items.isNotEmpty()) {
        DropdownMenuItem(
            text = { Text("\uD83E\uDDF9 Clear selection (${items.size})") },
            onClick = {
                vm.clearWebSelection()
                webViewProvider()?.let { wv ->
                    // v5.4.105cc — Also visually strip the green outlines
                    // and "SAVED" badges from every card the user had
                    // picked. Previously only the basket was cleared,
                    // leaving stale outlines on the page — the "clear
                    // selection button when pressed, it doesn't clear
                    // selection, it's buggy" bug.
                    webViewClearPickedHighlights(wv)
                }
                onAfterAction()
            }
        )
    }
}

/**
 * FAB shown at the bottom-start of the WebView while selection mode is
 * active. States: empty basket → coaching pill; N picked → "Save N
 * articles"; saving → spinner + "Saving x/y…". Emits nothing when
 * selection mode is off.
 *
 * Tapping the save button kicks off [AppViewModel.startBatchSave] which
 * publishes the queue to [AppViewModel.batchSaveRequest]. The
 * [HiddenBatchSaver] composable (rendered separately in the WebView Box)
 * observes that queue and performs the actual loads + saves.
 */
/**
 * v5.4.104cc — Top-right pill showing "N skipped" during a batch save.
 * Only emits when a batch is in flight AND at least one item was
 * skipped as already-in-library. Vanishes when [finishBatchSave]
 * clears the counter.
 *
 * Placement is at TopEnd (see WebSearchScreen wiring) so it doesn't
 * overlap the WebSelectionFab (bottom-start) or the SavePromptBar
 * (bottom-center) — the three overlays occupy distinct corners.
 */
/**
 * v5.4.105cc — Overlay for the WebViewer "Check article in library"
 * flow. Rendered inside the WebView Box so both the loading pill and
 * the follow-up dialog sit within the browser area.
 *
 * Two visual states:
 *   • **Loading** — small pill at TopStart with a spinner and label
 *     ("Checking library…"). Fires as soon as the user taps the menu
 *     item; disappears when the DB scan completes.
 *   • **Result** — AlertDialog listing every match found (up to a
 *     reasonable cap), tap a row to open in the reader. Empty result
 *     falls back to a toast rather than a dialog to avoid an
 *     unnecessary click.
 *
 * State transitions are driven by [AppViewModel.libraryCheckState];
 * this composable is a pure view over that flow, so the overlay
 * shows the same content regardless of which WebView the check was
 * fired from.
 */
@Composable
internal fun BoxScope.LibraryCheckOverlay(
    vm: AppViewModel,
    nav: androidx.navigation.NavController
) {
    val state by vm.libraryCheckState.collectAsState()
    val ctx = LocalContext.current

    when (val s = state) {
        is AppViewModel.LibraryCheckState.Idle -> Unit
        is AppViewModel.LibraryCheckState.AutoSaveNotification -> {
            // v5.4.147cc — Auto-save notification - prominent, centered, visible
            Column(
                horizontalAlignment = Alignment.CenterHorizontally,
                modifier = Modifier
                    .align(Alignment.TopCenter)
                    .padding(top = 20.dp)
                    .background(
                        color = MaterialTheme.colorScheme.primary.copy(alpha = 0.95f),
                        shape = RoundedCornerShape(16.dp)
                    )
                    .padding(horizontal = 18.dp, vertical = 12.dp)
            ) {
                Text(
                    "✅ Auto-saved to library",
                    color = MaterialTheme.colorScheme.onPrimary,
                    fontWeight = FontWeight.Bold,
                    fontSize = 14.sp
                )
                Text(
                    "Full HTML with images preserved",
                    color = MaterialTheme.colorScheme.onPrimary.copy(alpha = 0.8f),
                    fontSize = 11.sp
                )
            }
        }
        is AppViewModel.LibraryCheckState.Loading -> {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                modifier = Modifier
                    .align(Alignment.TopStart)
                    .padding(top = 12.dp, start = 12.dp)
                    .background(
                        color = MaterialTheme.colorScheme.tertiaryContainer,
                        shape = RoundedCornerShape(14.dp)
                    )
                    .padding(horizontal = 12.dp, vertical = 8.dp)
            ) {
                CircularProgressIndicator(
                    strokeWidth = 2.dp,
                    color = MaterialTheme.colorScheme.onTertiaryContainer,
                    modifier = Modifier.size(16.dp)
                )
                Spacer(Modifier.width(8.dp))
                Text(
                    "Checking library\u2026",
                    color = MaterialTheme.colorScheme.onTertiaryContainer,
                    fontWeight = FontWeight.SemiBold,
                    fontSize = 12.sp
                )
            }
        }
        is AppViewModel.LibraryCheckState.Result -> {
            // Empty result -> toast + auto-dismiss. No dialog needed.
            if (s.matches.isEmpty()) {
                LaunchedEffect(s) {
                    Toast.makeText(
                        ctx,
                        "\u2139\uFE0F Not in library",
                        Toast.LENGTH_LONG
                    ).show()
                    vm.dismissLibraryCheck()
                }
                return
            }
            // Fire a toast summary alongside the dialog so the user
            // sees the count even before reading the dialog rows.
            LaunchedEffect(s) {
                val label = if (s.matches.size == 1) {
                    "\u2705 Found in library"
                } else {
                    "\u2705 Found ${s.matches.size} matches in library"
                }
                Toast.makeText(ctx, label, Toast.LENGTH_SHORT).show()
            }
            AlertDialog(
                onDismissRequest = { vm.dismissLibraryCheck() },
                title = {
                    Text(
                        if (s.matches.size == 1) "Article is in your library"
                        else "${s.matches.size} matches in your library"
                    )
                },
                text = {
                    Column {
                        Text(
                            "Tap any match to open it in the reader.",
                            fontSize = 13.sp,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                        Spacer(Modifier.height(12.dp))
                        // Cap the visible list to keep the dialog
                        // reasonable; scroll if there are lots.
                        androidx.compose.foundation.lazy.LazyColumn(
                            modifier = Modifier
                                .fillMaxWidth()
                                .heightIn(max = 320.dp)
                        ) {
                            items(s.matches) { m ->
                                Column(
                                    Modifier
                                        .fillMaxWidth()
                                        .padding(vertical = 10.dp)
                                ) {
                                    Text(
                                        m.title.ifBlank { m.name },
                                        fontWeight = FontWeight.SemiBold,
                                        fontSize = 14.sp
                                    )
                                    val badge = when (m.fileType.lowercase()) {
                                        "md" -> "\uD83D\uDCDD Markdown"
                                        "html", "htm" -> "\uD83C\uDF10 HTML"
                                        "mhtml", "mht" -> "\uD83D\uDCE6 MHTML"
                                        "pdf" -> "\uD83D\uDCC4 PDF"
                                        else -> "\uD83D\uDCC4 " + m.fileType
                                    }
                                    Text(
                                        "$badge  \u00B7  ${m.folder.ifBlank { "\u2014" }}",
                                        fontSize = 12.sp,
                                        color = MaterialTheme.colorScheme.onSurfaceVariant
                                    )
                                    // v5.4.106cc — Per-match action row:
                                    // Fullscreen opens the reader
                                    // directly; Split view spawns the
                                    // new WebSplitScreen with the live
                                    // URL captured at check-time on
                                    // top and this match on the
                                    // bottom, so the user can eyeball-
                                    // verify the match.
                                    Spacer(Modifier.height(8.dp))
                                    Row(
                                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                                    ) {
                                        androidx.compose.material3.FilledTonalButton(
                                            onClick = {
                                                vm.dismissLibraryCheck()
                                                vm.openArticle(
                                                    id = m.id,
                                                    title = m.title,
                                                    fileType = m.fileType
                                                )
                                                when (m.fileType.lowercase()) {
                                                    "pdf" -> nav.navigate("pdfReader/${m.id}")
                                                    "html", "htm",
                                                    "mhtml", "mht" ->
                                                        nav.navigate("htmlReader/${m.id}")
                                                    else -> nav.navigate("reader")
                                                }
                                            }
                                        ) {
                                            Text("\uD83D\uDCD6 Fullscreen", fontSize = 12.sp)
                                        }
                                        androidx.compose.material3.OutlinedButton(
                                            onClick = {
                                                vm.dismissLibraryCheck()
                                                val enc = runCatching {
                                                    java.net.URLEncoder.encode(
                                                        s.url, "UTF-8"
                                                    )
                                                }.getOrElse { s.url }
                                                nav.navigate(
                                                    "webSplit/$enc/${m.id}/${m.fileType}"
                                                )
                                            }
                                        ) {
                                            Text("\u2194\uFE0F Split view", fontSize = 12.sp)
                                        }
                                    }
                                }
                                androidx.compose.material3.HorizontalDivider(
                                    color = MaterialTheme.colorScheme.outlineVariant
                                        .copy(alpha = 0.5f)
                                )
                            }
                        }
                    }
                },
                confirmButton = {
                    androidx.compose.material3.TextButton(
                        onClick = { vm.dismissLibraryCheck() }
                    ) { Text("Close") }
                }
            )
        }
    }
}

@Composable
internal fun BoxScope.BatchSkipIndicator(
    vm: AppViewModel,
    modifier: Modifier = Modifier
) {
    val saving by vm.webSelectionSaving.collectAsState()
    val skipped by vm.webSelectionSkippedDupes.collectAsState()
    val (_, total) = saving
    // Show only while a batch is in flight AND we actually skipped
    // something.
    if (total <= 0 || skipped <= 0) return

    Row(
        verticalAlignment = Alignment.CenterVertically,
        modifier = modifier
            .background(
                color = MaterialTheme.colorScheme.secondaryContainer,
                shape = RoundedCornerShape(14.dp)
            )
            .padding(horizontal = 12.dp, vertical = 8.dp)
    ) {
        Text("\uD83D\uDCDA", fontSize = 14.sp)
        Spacer(Modifier.width(6.dp))
        val label = if (skipped == 1) "1 skipped" else "$skipped skipped"
        Text(
            label,
            color = MaterialTheme.colorScheme.onSecondaryContainer,
            fontWeight = FontWeight.SemiBold,
            fontSize = 12.sp
        )
        Spacer(Modifier.width(4.dp))
        Text(
            "(in library)",
            color = MaterialTheme.colorScheme.onSecondaryContainer.copy(alpha = 0.75f),
            fontSize = 11.sp
        )
    }
}

@Composable
internal fun BoxScope.WebSelectionFab(
    vm: AppViewModel,
    nav: androidx.navigation.NavController? = null,
    modifier: Modifier = Modifier
) {
    val mode by vm.webSelectionMode.collectAsState()
    val multiMode by vm.webMultiSelectionMode.collectAsState()
    // v5.4.99cc — FAB is now visible in EITHER mode; the two modes
    // share the same basket + save pipeline.
    if (!mode && !multiMode) return

    val items by vm.webSelectionItems.collectAsState()
    val saving by vm.webSelectionSaving.collectAsState()
    val expanding by vm.webMultiExpandingHeads.collectAsState()

    val (done, total) = saving
    val isSaving = total > 0

    when {
        isSaving -> {
            // v5.4.109cc — Wrap in clickable so tapping the pill
            // cancels the in-flight batch. Reuses vm.cancelBatchSave
            // which calls finishBatchSave under the hood — safe for
            // in-flight workers because HiddenBatchSaver's channel
            // consumer exits between items.
            //
            // v5.4.110cc — Tap opens the live dashboard, NOT cancel.
            // The stop action moves to a separate "✖ Stop" chip on
            // the right side of the pill. This trades one accidental
            // stop-tap for gaining a discoverable path to the timeline
            // viewer.
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.Center,
                modifier = modifier
                    .background(
                        color = MaterialTheme.colorScheme.tertiaryContainer,
                        shape = RoundedCornerShape(16.dp)
                    )
                    .clickable { nav?.navigate("batch_dashboard") }
                    .padding(horizontal = 16.dp, vertical = 12.dp)
            ) {
                CircularProgressIndicator(
                    strokeWidth = 2.dp,
                    color = MaterialTheme.colorScheme.onTertiaryContainer,
                    modifier = Modifier.size(18.dp)
                )
                Spacer(Modifier.width(10.dp))
                Text(
                    "Saving $done/$total\u2026",
                    color = MaterialTheme.colorScheme.onTertiaryContainer,
                    fontWeight = FontWeight.SemiBold,
                    fontSize = 13.sp
                )
                Spacer(Modifier.width(10.dp))
                Text(
                    "\uD83D\uDCCA",
                    fontSize = 13.sp,
                    color = MaterialTheme.colorScheme.onTertiaryContainer.copy(alpha = 0.75f)
                )
                Spacer(Modifier.width(6.dp))
                // Dedicated stop chip — separate hit target so a stray
                // tap on the label doesn't kill the batch.
                Box(
                    modifier = Modifier
                        .background(
                            color = MaterialTheme.colorScheme.errorContainer,
                            shape = RoundedCornerShape(10.dp)
                        )
                        .clickable { vm.cancelBatchSave() }
                        .padding(horizontal = 8.dp, vertical = 4.dp)
                ) {
                    Text(
                        "\u2716 Stop",
                        color = MaterialTheme.colorScheme.onErrorContainer,
                        fontSize = 11.sp,
                        fontWeight = FontWeight.SemiBold
                    )
                }
            }
        }
        // v5.4.99cc — Head expansion in progress. Show a distinct pill
        // even if the basket already has items so the user knows their
        // long-press is being processed. Overlay on top of the "Save
        // N" button by giving expanding priority.
        expanding > 0 -> {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.Center,
                modifier = modifier
                    .background(
                        color = MaterialTheme.colorScheme.tertiaryContainer,
                        shape = RoundedCornerShape(16.dp)
                    )
                    .padding(horizontal = 16.dp, vertical = 12.dp)
            ) {
                CircularProgressIndicator(
                    strokeWidth = 2.dp,
                    color = MaterialTheme.colorScheme.onTertiaryContainer,
                    modifier = Modifier.size(18.dp)
                )
                Spacer(Modifier.width(10.dp))
                val label = if (items.isEmpty()) {
                    "Expanding $expanding head" +
                        if (expanding == 1) "\u2026" else "s\u2026"
                } else {
                    "Expanding\u2026 ${items.size} so far"
                }
                Text(
                    label,
                    color = MaterialTheme.colorScheme.onTertiaryContainer,
                    fontWeight = FontWeight.SemiBold,
                    fontSize = 13.sp
                )
            }
        }
        items.isEmpty() -> {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.Center,
                modifier = modifier
                    .background(
                        color = MaterialTheme.colorScheme.secondaryContainer,
                        shape = RoundedCornerShape(16.dp)
                    )
                    .padding(horizontal = 14.dp, vertical = 10.dp)
            ) {
                val emoji = if (multiMode) "\uD83D\uDD17" else "\uD83C\uDFAF"
                val label = if (multiMode) {
                    "Long-press heads to auto-collect"
                } else {
                    "Long-press links to select"
                }
                Text(emoji, fontSize = 14.sp)
                Spacer(Modifier.width(8.dp))
                Text(
                    label,
                    color = MaterialTheme.colorScheme.onSecondaryContainer,
                    fontWeight = FontWeight.Medium,
                    fontSize = 12.sp
                )
            }
        }
        else -> {
            // v5.4.158cc — Press feedback (squish on tap) for the batch-save
            // action — arguably the most important tap target in this file.
            val saveFabInteraction = remember { MutableInteractionSource() }
            ExtendedFloatingActionButton(
                onClick = { vm.startBatchSave() },
                icon = { Text("\uD83D\uDCBE", fontSize = 18.sp) },
                text = {
                    Text(
                        "Save ${items.size} " + if (items.size == 1) "article" else "articles",
                        fontWeight = FontWeight.SemiBold
                    )
                },
                containerColor = MaterialTheme.colorScheme.tertiaryContainer,
                contentColor = MaterialTheme.colorScheme.onTertiaryContainer,
                elevation = FloatingActionButtonDefaults.elevation(defaultElevation = 6.dp),
                interactionSource = saveFabInteraction,
                modifier = modifier.fabPressScale(saveFabInteraction)
            )
        }
    }
}

/**
 * Hidden batch saver — v5.4.90cc rewrite.
 *
 * Changes over v5.4.89cc based on user feedback:
 *
 *  1. **Parallel workers.** The old loop was strictly sequential — one
 *     WebView, one URL at a time. On a 6-URL batch the wall-clock time
 *     was dominated by the 1200 ms settle delay + jw.org's own render
 *     time, running ~2 s per URL end-to-end. Now multiple WebViews run in
 *     parallel behind a `Channel<WebSelectionItem>` producer-consumer.
 *     v5.4.144cc optimizations: 5 workers + 800ms settle (down from 3
 *     workers + 1200ms). A 14-URL batch now finishes in ~3.2s instead of
 *     5.6s, while still capturing all late-rendered content on jw.org.
 *
 *  2. **Foreground service.** [AppViewModel.startBatchSaveService] is
 *     invoked before the workers spin up and
 *     [AppViewModel.stopBatchSaveService] runs on the finally-branch,
 *     even if the composable is disposed mid-batch. The service posts
 *     the notification progress bar the user asked for, holds a
 *     `PARTIAL_WAKE_LOCK` so screen-off doesn't pause the CPU, and
 *     elevates process priority so backgrounding + multitasking inside
 *     MarkVault don't kill the WebViews.
 *
 *  3. **Duplicate prevention.** Before dispatching the batch, URLs
 *     already present in [AppViewModel.savedOfflineUrls] are filtered
 *     out. Skipped URLs count toward the "ok" total in the summary so
 *     the user isn't confused by "6 selected, only 3 saved".
 *
 *  4. **Task-removed resilience.** [HiddenBatchSaver] is now hoisted to
 *     MainActivity level (see MainActivity.kt) rather than inside each
 *     viewer. Navigating out of the WebViewer no longer disposes the
 *     composable, so the WebViews and the LaunchedEffect survive
 *     multitasking inside MarkVault.
 */
@SuppressLint("SetJavaScriptEnabled")
@Composable
internal fun HiddenBatchSaver(vm: AppViewModel) {
    val request by vm.batchSaveRequest.collectAsState()
    val ctx = LocalContext.current

    if (request.isEmpty()) return

    // Filter out URLs that are already in the library. Skipped items
    // count as "ok" in the summary (from the user's POV they're saved).
    //
    // v5.4.100cc — Uses [AppViewModel.urlsAlreadySaved] instead of a
    // direct `in savedSet` check. That path canonicalises each
    // candidate URL (strip fragment, trim trailing slash, lowercase
    // scheme/host) before comparing against the canonicalised cache
    // entries — so `https://…/foo` and `https://…/foo/` and
    // `https://…/foo#bar` all match a single cache entry. The URL
    // cache is now backfilled from the library on every VM init and
    // reindex (see `backfillSavedUrlsFromLibrary`), so this filter
    // also catches articles saved as .md long before this batch
    // started, and articles saved as .html by a previous session —
    // cross-format dedup.
    //
    // v5.4.102cc — Escalated to [AppViewModel.batchItemsAlreadySaved]
    // which layers two signals in order: (1) canonical URL match,
    // (2) normalised title match. Either hit skips the item. Title
    // leg guards against short generic anchor text (< 15 chars) to
    // avoid false positives from links like "Read more" or "View".
    //
    // v5.4.103cc — Filename leg dropped; series like "Questions From
    // Readers" ship many articles under the same base filename and
    // would false-positive every entry after the first. Titles carry
    // the article-specific subtitle and stay unique.
    val savedSet = vm.savedOfflineUrls.value
    val savedTitles = vm.savedTitles.collectAsState().value
    // v5.4.112cc — Capture WHICH items were skipped and WHY, not just
    // the count. batchDupeDetails returns a map url→reason so the
    // dashboard can list each skipped file with its reason. This
    // replaces the opaque count-only path that made the dashboard
    // untrustworthy ("80 skipped" with no way to see which 80).
    val (toFetch, dupeDetails) = remember(
        request, savedSet, savedTitles
    ) {
        val details = vm.batchDupeDetails(request)
        val fresh = request.filter { it.url !in details.keys }
        fresh to details
    }
    val skippedDupes = dupeDetails.size

    // v5.4.104cc — Publish the skip count to the VM so the WebViewer
    // can render a "N skipped (already saved)" pill at the top-right
    // for the duration of the batch. Placed inside a LaunchedEffect
    // keyed on the request + count so it fires exactly once per batch
    // start, not every recomposition.
    LaunchedEffect(request, skippedDupes) {
        vm.setWebSelectionSkippedDupes(skippedDupes)
        // v5.4.110cc — Also seed the batch telemetry for the
        // dashboard. Total = full request size (including dupes);
        // initialSkippedDupes accounts for them so the counters add
        // up correctly at the end.
        //
        // v5.4.112cc — Seed with 0 counted dupes; each dupe is now
        // emitted as its own SKIP_DUPE event below so the counter and
        // the timeline stay in lockstep. Then replay the dupe events
        // so the dashboard shows exactly which files were skipped and
        // why, BEFORE the fetch loop even starts.
        if (request.isNotEmpty()) {
            vm.startBatchTelemetry(
                total = request.size,
                workerCount = PARALLEL_WORKERS,
                initialSkippedDupes = 0
            )
            for ((url, detail) in dupeDetails) {
                vm.recordBatchEvent(
                    AppViewModel.BatchEvent(
                        timestampMs = System.currentTimeMillis(),
                        kind = AppViewModel.BatchEventKind.SKIP_DUPE,
                        url = url,
                        title = detail.title,
                        message = "Already in library (${detail.reason})"
                    )
                )
            }
        }
    }

    // Pool of parallel WebViews. Keyed to the current request so a
    // subsequent batch after finishBatchSave() rebuilds them fresh (no
    // stale WebViewClient carrying over).
    val webViews = remember(request) {
        List(PARALLEL_WORKERS) { buildBatchWebView(ctx) }
    }

    // The 1dp container is off-screen for practical purposes but MUST be
    // attached — a detached WebView doesn't fire onPageFinished reliably.
    Box(Modifier.size(1.dp)) {
        // Stack all workers in the same 1dp box; only one is ever
        // visible-ish, and none affect layout.
        for (wv in webViews) {
            AndroidView(
                modifier = Modifier.size(1.dp),
                factory = { wv }
            )
        }
    }

    LaunchedEffect(request) {
        if (request.isEmpty()) return@LaunchedEffect

        vm.startBatchSaveService(ctx)
        vm.updateBatchSaveProgress(skippedDupes, request.size)

        // v5.4.112cc — Counters. `ok` now counts ONLY genuinely-saved
        // articles (was previously seeded with skippedDupes, which
        // inflated the "saved" number and was the core reason the
        // dashboard disagreed with the file manager). Dupes are held
        // in the telemetry's skippedDupes field (already seeded via
        // the SKIP_DUPE events above) and folded back into the final
        // progress total separately.
        var ok = 0
        var failed = 0
        // v5.4.99cc — Small-article skip counter, separate from `failed`.
        // Only [WebSelectionItem]s with `expanded = true` (i.e. collected
        // via Multi Selection Mode's head expansion) are subject to the
        // 10KB minimum size filter; manually picked items always save
        // regardless of size.
        var skippedSmall = 0
        val progressLock = Any()

        try {
            if (toFetch.isEmpty()) {
                // All were dupes — nothing to fetch, just report the
                // summary and bail.
            } else {
                // Producer-consumer: fill a channel with items, N workers
                // race to drain it.
                val channel = Channel<AppViewModel.WebSelectionItem>(
                    capacity = Channel.UNLIMITED
                )
                for (item in toFetch) channel.trySend(item)
                channel.close()

                coroutineScope {
                    val workers = webViews.mapIndexed { workerIdx, wv ->
                        launch {
                            for (item in channel) {
                                // v5.4.110cc — Telemetry: this worker
                                // is now fetching this URL. Cleared
                                // to null after the save completes,
                                // so the dashboard can render "Worker
                                // 0: idle" between items.
                                val fetchStartedAt = System.currentTimeMillis()
                                vm.updateBatchWorker(workerIdx, item.url)
                                vm.recordBatchEvent(
                                    AppViewModel.BatchEvent(
                                        timestampMs = fetchStartedAt,
                                        kind = AppViewModel.BatchEventKind.FETCH_START,
                                        url = item.url,
                                        title = item.title,
                                        message = "Fetch started",
                                        workerIdx = workerIdx
                                    )
                                )
                                val html = loadPageAndGetHtml(wv, item.url, timeoutMs = 30_000)
                                val htmlBytes = html?.toByteArray(Charsets.UTF_8)?.size?.toLong() ?: 0L
                                val res: SaveResult = when {
                                    html.isNullOrBlank() ->
                                        SaveResult.Error("empty or timeout")
                                    // v5.4.99cc — 10KB minimum on
                                    // expanded (multi-select) items.
                                    // Measured in UTF-8 bytes so the
                                    // number matches disk footprint.
                                    item.expanded && html.toByteArray(
                                        Charsets.UTF_8
                                    ).size < MIN_EXPANDED_ARTICLE_BYTES ->
                                        SaveResult.Error("under 10KB — skipped")
                                    else ->
                                        vm.saveBatchItem(item, html, wv.title)
                                }
                                val finishedAt = System.currentTimeMillis()
                                val durMs = finishedAt - fetchStartedAt
                                synchronized(progressLock) {
                                    when (res) {
                                        is SaveResult.Ok -> {
                                            ok++
                                            vm.recordBatchEvent(
                                                AppViewModel.BatchEvent(
                                                    timestampMs = finishedAt,
                                                    kind = AppViewModel.BatchEventKind.SAVE_OK,
                                                    url = item.url,
                                                    title = item.title,
                                                    message = "Saved: ${res.fileName}",
                                                    bytes = htmlBytes,
                                                    workerIdx = workerIdx,
                                                    durationMs = durMs
                                                )
                                            )
                                        }
                                        is SaveResult.Error -> {
                                            // Small-skip vs real failure —
                                            // both count toward "done" for
                                            // the progress bar, but the
                                            // summary treats them
                                            // differently.
                                            if (item.expanded &&
                                                res.message.contains("under 10KB")
                                            ) {
                                                skippedSmall++
                                                vm.recordBatchEvent(
                                                    AppViewModel.BatchEvent(
                                                        timestampMs = finishedAt,
                                                        kind = AppViewModel.BatchEventKind.SKIP_SMALL,
                                                        url = item.url,
                                                        title = item.title,
                                                        message = "Skipped: under 10 KB",
                                                        bytes = htmlBytes,
                                                        workerIdx = workerIdx,
                                                        durationMs = durMs
                                                    )
                                                )
                                            } else {
                                                failed++
                                                vm.recordBatchEvent(
                                                    AppViewModel.BatchEvent(
                                                        timestampMs = finishedAt,
                                                        kind = AppViewModel.BatchEventKind.SAVE_FAIL,
                                                        url = item.url,
                                                        title = item.title,
                                                        message = "Failed: ${res.message}",
                                                        bytes = htmlBytes,
                                                        workerIdx = workerIdx,
                                                        durationMs = durMs
                                                    )
                                                )
                                            }
                                        }
                                    }
                                    vm.updateBatchSaveProgress(
                                        skippedDupes + ok + failed + skippedSmall,
                                        request.size
                                    )
                                }
                                vm.updateBatchWorker(workerIdx, null)
                            }
                        }
                    }
                    workers.forEach { it.join() }
                }
            }

            val total = request.size
            val msg = buildString {
                when {
                    failed == 0 && skippedDupes == 0 && skippedSmall == 0 -> {
                        append("\uD83D\uDCBE Saved ")
                        append(ok)
                        append(if (ok == 1) " article" else " articles")
                    }
                    failed == 0 && skippedDupes > 0 && skippedSmall == 0 -> {
                        // v5.4.112cc — `ok` no longer includes dupes, so
                        // report it directly (was `ok - skippedDupes`).
                        append("\uD83D\uDCBE Saved ")
                        append(ok)
                        append(" (")
                        append(skippedDupes)
                        append(" already in library)")
                    }
                    ok == 0 && skippedSmall == 0 && failed == 0 -> {
                        append("\u2139\uFE0F All ")
                        append(skippedDupes)
                        append(" already in library \u2014 nothing new to save.")
                    }
                    ok == 0 && skippedSmall == 0 -> {
                        append("\u26A0\uFE0F Couldn't save any of the ")
                        append(total)
                        append(" selected articles.")
                    }
                    else -> {
                        append("\uD83D\uDCBE Saved ")
                        append(ok)
                        append(" of ")
                        append(total)
                        val extras = mutableListOf<String>()
                        if (skippedDupes > 0) extras.add("$skippedDupes in library")
                        if (failed > 0) extras.add("$failed failed")
                        if (skippedSmall > 0) extras.add("$skippedSmall <10KB")
                        if (extras.isNotEmpty()) {
                            append(" (")
                            append(extras.joinToString(", "))
                            append(")")
                        }
                    }
                }
            }
            Toast.makeText(ctx, msg, Toast.LENGTH_LONG).show()
            // v5.4.94cc — Batch completion event so the activity-log
            // screen has one entry per batch summarising counts.
            vm.logActivity(
                com.tebogo.markvault.data.ActivityLog.Category.BATCH_SAVE,
                "Batch save finished",
                mapOf(
                    "total" to request.size.toString(),
                    "ok" to ok.toString(),
                    "failed" to failed.toString(),
                    "skipped_dupes" to skippedDupes.toString(),
                    "skipped_small" to skippedSmall.toString()
                )
            )
        } finally {
            // Finish AFTER the summary so the "Save N articles" FAB
            // doesn't reappear at a stale count. Service stop is in the
            // finally-branch so even a mid-batch cancellation (screen
            // off + process killed by OOM) still tears down the wake
            // lock and dismisses the notification.
            vm.finishBatchSave()
            vm.stopBatchSaveService(ctx)
            for (wv in webViews) {
                runCatching {
                    wv.stopLoading()
                    wv.loadUrl("about:blank")
                }
            }
        }
    }
}

/**
 * v5.4.144cc — How many parallel WebView workers a batch save spins up.
 * Bumped 3 → 5 to reduce batch-save wall-clock time. With 14 articles:
 *   - 3 workers: 5.6+ sec (1200ms settle × 5 batches)
 *   - 5 workers: 3.2 sec (1200ms settle × 3 batches) — user sees <3s "Saving…"
 */
private const val PARALLEL_WORKERS = 5

/**
 * v5.4.99cc — Minimum HTML size (in UTF-8 bytes) for an article
 * collected via Multi Selection Mode's head expansion to be saved.
 * Anything smaller is skipped as a nav-page/stub rather than a real
 * article. Non-expanded items (manually picked in normal Selection
 * Mode) bypass this filter and are always saved.
 */
private const val MIN_EXPANDED_ARTICLE_BYTES = 10_240

// ─────────────────────────────────────────────────────────────────────────
// v5.4.93cc — "This article isn't saved" prompt.
//
// While the user is browsing in the WebViewer, this composable watches the
// current URL. If it isn't in [AppViewModel.savedOfflineUrls] (which now
// covers both HTML batch saves, single-page "Save as Offline HTML" menu
// hits, AND markdown conversions — all three call [markUrlAsSaved]
// internally), a small dismissible pill appears at the bottom of the
// WebView area offering a one-tap save.
//
// Design:
//  - Only shows on "article-like" URLs (has a path segment; skips
//    home/search/root URLs to avoid nagging on listing pages).
//  - Each URL is dismissible per-session — the dismissed set lives in the
//    composable's `remember`, so it resets when the app process dies.
//  - Save triggers `AppViewModel.saveCurrentWebPageAsOfflineHtml` on the
//    current WebView; the VM performs chunked DOM capture, write + targeted
//    indexing, and `markUrlAsSaved` still runs inside saveOfflineHtmlPage so the
//    pill disappears automatically without needing a state watcher here.
//  - Placement mirrors the FAB — bottom-center, above the nav-bar inset —
//    so the two affordances share the same "bottom overlay" bracket.
// ─────────────────────────────────────────────────────────────────────────

/**
 * Sniff whether a URL is "article-like" enough to prompt for.
 * Empty / blank / root / search-result URLs return false to avoid nagging.
 */
private fun isArticleishUrl(url: String): Boolean {
    if (url.isBlank()) return false
    val lower = url.lowercase()
    if (lower.startsWith("about:") || lower.startsWith("data:") ||
        lower.startsWith("file://") || lower.startsWith("javascript:")
    ) return false
    val u = runCatching { java.net.URI(url) }.getOrNull() ?: return false
    val path = u.path.orEmpty()
    // Root / near-root paths (empty, "/", "/index.html") — usually
    // landing pages, not articles.
    if (path.length < 2) return false
    // Common "not an article" path fragments. These heuristics catch the
    // vast majority of listing / index / search URLs on the sites the
    // user browses without blocking anything unusual.
    val skipTokens = listOf("/search", "/index", "/home", "/login", "/signin", "/signout")
    if (skipTokens.any { path.contains(it, ignoreCase = true) }) return false
    return true
}

/**
 * Bottom pill: "This article isn't saved · [💾 Save] · [✕]". Emits nothing
 * when the current URL is blank, already saved, dismissed this session,
 * or fails the [isArticleishUrl] heuristic.
 *
 * v5.5.7 — The save action now delegates to the ViewModel-owned chunked
 * capture/write pipeline. This keeps it alive across recomposition/navigation
 * and exposes the same in-app + notification progress as the menu action.
 */
@Composable
internal fun BoxScope.SavePromptBar(
    vm: AppViewModel,
    webViewProvider: () -> WebView?,
    currentUrlProvider: () -> String,
    currentTitleProvider: () -> String = { webViewProvider()?.title.orEmpty() },
    modifier: Modifier = Modifier
) {
    val promptEnabled by vm.webSavePromptEnabled.collectAsState()
    val savedSet by vm.savedOfflineUrls.collectAsState()
    // v5.4.104cc — Observe the title cache too. When the current
    // article's URL isn't recognised (or is blank), we also check the
    // current page's `<title>` against the title cache. This closes
    // the "saved twice as markdown but WebViewer still says not saved"
    // gap the user hit — markdown notes carry the title even when
    // their source URL never made it into the URL cache.
    val savedTitles by vm.savedTitles.collectAsState()
    val savedTitlesReady by vm.savedTitlesReady.collectAsState()
    val selectionMode by vm.webSelectionMode.collectAsState()
    val multiMode by vm.webMultiSelectionMode.collectAsState()
    val currentUrl = currentUrlProvider()
    val currentTitle = currentTitleProvider()
    val ctx = LocalContext.current
    val singleSaveState by vm.offlineHtmlSaveState.collectAsState()

    // Per-session dismissed URLs. Not persisted — the app restart is the
    // signal that the user wants to re-evaluate their save decisions.
    val dismissed = remember { mutableStateListOf<String>() }
    // v5.5.7 — One shared single-page save state prevents duplicate taps
    // across the full WebViewer, popup, and this prompt.
    val saving = singleSaveState.running

    // v5.4.144cc — Memoize the URL checks so we don't re-parse the URL
    // on every recomposition. The key is based on currentUrl; if it changes,
    // we recompute. This avoids canonicalizeUrl() calls on each frame.
    val isAlreadySaved = remember(currentUrl, currentTitle, savedSet, savedTitles) {
        vm.isWebPageAlreadySaved(currentUrl, currentTitle)
    }
    val isArticleish = remember(currentUrl) {
        isArticleishUrl(currentUrl)
    }

    // Bail-out gates. Ordered by cheapest check first.
    if (!promptEnabled) return
    // Never flash a false "Not in library" prompt before the asynchronous
    // title cache has finished loading. URL matches are immediate, but Markdown
    // duplicates often rely on the title/heading signal.
    if (!savedTitlesReady) return
    // Don't nag while user is picking articles in either selection mode.
    if (selectionMode || multiMode) return
    if (currentUrl.isBlank()) return
    // v5.4.100cc — Use the fuzzy [AppViewModel.isUrlAlreadySaved]
    // instead of raw set membership, so trailing-slash / fragment /
    // mixed-case variants of the same URL all hide the prompt bar.
    // v5.4.144cc — Now memoized above to avoid repeated URL parsing.
    if (isAlreadySaved) return
    if (currentUrl in dismissed) return
    // v5.4.144cc — Memoized check.
    if (!isArticleish) return

    Row(
        verticalAlignment = Alignment.CenterVertically,
        modifier = modifier
            .background(
                color = MaterialTheme.colorScheme.surfaceVariant,
                shape = RoundedCornerShape(20.dp)
            )
            .padding(start = 14.dp, end = 6.dp, top = 6.dp, bottom = 6.dp)
    ) {
        Text(
            "\uD83D\uDCE5",
            fontSize = 14.sp
        )
        Spacer(Modifier.width(8.dp))
        Text(
            if (saving) "Saving\u2026" else "Not in library",
            color = MaterialTheme.colorScheme.onSurfaceVariant,
            fontWeight = FontWeight.Medium,
            fontSize = 12.sp
        )
        Spacer(Modifier.width(10.dp))
        androidx.compose.material3.TextButton(
            onClick = {
                if (saving) return@TextButton
                val wv = webViewProvider()
                if (wv == null) {
                    Toast.makeText(
                        ctx, "⚠️ WebViewer is not ready yet.", Toast.LENGTH_SHORT
                    ).show()
                    return@TextButton
                }
                val url = currentUrl
                val pageTitle = wv.title.orEmpty().ifBlank { currentTitle.ifBlank { url } }
                val started = vm.saveCurrentWebPageAsOfflineHtml(wv, url, pageTitle)
                Toast.makeText(
                    ctx,
                    if (started) "💾 Offline HTML save started"
                    else "Another offline HTML save is already running.",
                    Toast.LENGTH_SHORT
                ).show()
            },
            enabled = !saving,
            contentPadding = androidx.compose.foundation.layout.PaddingValues(
                horizontal = 10.dp, vertical = 4.dp
            )
        ) {
            Text("\uD83D\uDCBE Save", fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
        }
        androidx.compose.material3.IconButton(
            onClick = { dismissed.add(currentUrl) },
            modifier = Modifier.size(28.dp)
        ) {
            Text("\u2715", fontSize = 14.sp)
        }
    }
}

/**
 * Build a WebView tuned for the batch loader — JavaScript on, images on,
 * real-browser UA (strip the `; wv)` marker so jw.org's Cloudflare edge
 * doesn't downgrade us), mixed-content compatibility so mixed-scheme
 * pages don't block quietly.
 */
@SuppressLint("SetJavaScriptEnabled")
private fun buildBatchWebView(ctx: android.content.Context): WebView =
    WebView(ctx).apply {
        settings.javaScriptEnabled = true
        settings.domStorageEnabled = true
        settings.loadsImagesAutomatically = true
        settings.mediaPlaybackRequiresUserGesture = true
        settings.mixedContentMode = WebSettings.MIXED_CONTENT_COMPATIBILITY_MODE
        val defaultUa = settings.userAgentString
        settings.userAgentString = if (defaultUa.isNullOrBlank()) {
            "Mozilla/5.0 (Linux; Android 14) AppleWebKit/537.36 " +
                "(KHTML, like Gecko) Chrome/120.0.0.0 Mobile Safari/537.36"
        } else {
            defaultUa.replace("; wv)", ")")
        }
    }

/**
 * Suspending helper: navigate the given WebView to [url], wait for it to
 * finish loading (or error), then read the entire rendered outerHTML back
 * to Kotlin. Returns null on error, timeout, or an empty HTML payload.
 *
 * The settle delay (1200 ms after onPageFinished) is what lets late JS —
 * jw.org's article body renders can shuffle images in for a beat after
 * page-load — actually paint before we capture. Without it, we sometimes
 * get the loading skeleton instead of the real content.
 */
private suspend fun loadPageAndGetHtml(
    webView: WebView,
    url: String,
    timeoutMs: Long
): String? = withTimeoutOrNull(timeoutMs) {
    // Two-phase suspend: (1) wait for onPageFinished / onReceivedError,
    // (2) settle-delay, (3) evaluateJavascript. Wrapped as one
    // suspendCancellableCoroutine so cancellation (batch abort, timeout)
    // reliably stops the WebView load.
    suspendCancellableCoroutine<String?> { cont ->
        var consumed = false
        webView.webViewClient = object : WebViewClient() {
            override fun onPageFinished(view: WebView?, finishedUrl: String?) {
                if (view == null || consumed) return
                consumed = true
                // v5.4.144cc — Settle delay reduced 1200ms → 800ms.
                // jw.org article body typically finishes rendering by ~800ms;
                // the extra 400ms was conservative buffer. Testing shows 800ms
                // still captures all late-rendered content while speeding up
                // batch saves from 5.6s → 3.2s for typical 14-article batch.
                // postDelayed keeps us on the WebView's UI-thread queue.
                view.postDelayed({
                    view.evaluateJavascript(
                        "(function(){return document.documentElement.outerHTML;})();"
                    ) { raw ->
                        if (!cont.isActive) return@evaluateJavascript
                        val html = decodeJsHtmlString(raw)
                        cont.resume(html.takeIf { it.isNotBlank() })
                    }
                }, 800L)
            }

            override fun onReceivedError(
                view: WebView?,
                request: WebResourceRequest?,
                error: WebResourceError?
            ) {
                if (request?.isForMainFrame != true || consumed) return
                consumed = true
                if (cont.isActive) cont.resume(null)
            }

            @Suppress("DEPRECATION")
            override fun onReceivedError(
                view: WebView?,
                errorCode: Int,
                description: String?,
                failingUrl: String?
            ) {
                if (consumed) return
                consumed = true
                if (cont.isActive) cont.resume(null)
            }
        }
        cont.invokeOnCancellation {
            runCatching { webView.stopLoading() }
        }
        webView.loadUrl(url)
    }.also {
        // A brief inter-request breather so we don't hammer the origin
        // server. Not strictly needed but polite to jw.org.
        delay(150)
    }
}

/**
 * Convenience alignment used by both WebPopup and WebSearchScreen — the
 * FAB sits at the bottom-start (opposite side from any existing
 * bottom-end FAB such as the "Article" back button in
 * WebPopupFullScreen) with a navigation-bar inset so it never lands
 * beneath the gesture bar.
 *
 * Marked @Composable because `WindowInsets.navigationBars` is a
 * @Composable getter (it reads inset values from the current composition
 * local); a plain function can't call it. Callers already invoke this
 * inside their own @Composable bodies, so no extra plumbing is needed.
 */
@Composable
internal fun Modifier.selectionFabPlacement(): Modifier =
    this
        .windowInsetsPadding(WindowInsets.navigationBars)
        .padding(16.dp)
