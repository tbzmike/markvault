package com.tebogo.markvault.ui

import android.webkit.WebView
import android.widget.Toast
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.BoxScope
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.navigationBars
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.windowInsetsPadding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.ExtendedFloatingActionButton
import androidx.compose.material3.FloatingActionButtonDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.tebogo.markvault.AppViewModel
import com.tebogo.markvault.SaveResult
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject

/**
 * v5.4.87cc — "Save all articles" feature for the in-app WebViewer.
 *
 * A floating action button overlaid on the WebView. When tapped, it:
 *   1. Runs [COLLECT_ARTICLES_JS] on the currently displayed page to grab
 *      every top-level `<article>` element's outerHTML plus a best-guess
 *      title and canonical URL.
 *   2. Fans the resulting list out to [AppViewModel.saveOfflineHtmlPage]
 *      on `Dispatchers.IO` — one HTML file per detected article, stored in
 *      the same offline-imports subfolder single-page saves use.
 *   3. Updates an in-place progress badge on the FAB as each save completes
 *      (a MutableStateFlow counter — the requested "state management" hook),
 *      then fires a summary Toast on the main thread when the coroutine
 *      finishes.
 *
 * File layout is intentionally identical to the existing "Save as Offline
 * HTML" menu item, so users end up with the same self-describing `.html`
 * files (DOCTYPE + charset + `<base href>` envelope) regardless of whether
 * they saved one page or a whole listing.
 *
 * All heavy work is off the main thread — the FAB stays tappable during
 * the operation (a second tap while a batch is in flight is ignored).
 */

/**
 * Collects article-like nodes from the currently loaded page and returns a
 * JSON array of `{title, html, href}` objects. Runs entirely inside the
 * WebView's JS context; the Kotlin side just parses the resulting string.
 *
 * Selector strategy:
 *  - Primary: real `<article>` tags. That's the semantic tag jw.org uses
 *    for both individual articles AND card previews on listing pages, so it
 *    covers the common case.
 *  - Fallback: a handful of class/role selectors seen on jw.org and
 *    wol.jw.org index pages when `<article>` is absent.
 *
 * Dedup: nested matches are skipped so the outer `<article>` and its inner
 * card `<article>` don't both get saved.
 */
internal const val COLLECT_ARTICLES_JS = """
(function() {
  function pickTitle(el) {
    var h = el.querySelector('h1, h2, h3, h4, [role="heading"], .cardTitleBlock, .cardTitle, .publicationDesc, .articleTitle, .synopsis .title');
    if (h && h.textContent) {
      var t = h.textContent.replace(/\s+/g, ' ').trim();
      if (t) return t;
    }
    var linkAria = el.querySelector('a[aria-label]');
    if (linkAria) {
      var a = (linkAria.getAttribute('aria-label') || '').replace(/\s+/g, ' ').trim();
      if (a) return a;
    }
    var anyA = el.querySelector('a');
    if (anyA && anyA.textContent) {
      var l = anyA.textContent.replace(/\s+/g, ' ').trim();
      if (l) return l;
    }
    return '';
  }

  function pickHref(el) {
    var link = el.querySelector('a[href]');
    if (link && link.href) return link.href;
    return '';
  }

  var nodes = document.querySelectorAll('article');
  if (!nodes || nodes.length === 0) {
    nodes = document.querySelectorAll(
      '.publication, .articleWrapper, .searchResult, .synopsis, ' +
      '.linkCard, [role="article"]'
    );
  }

  var results = [];
  for (var i = 0; i < nodes.length; i++) {
    var el = nodes[i];
    // Skip anything nested inside an already-picked node — otherwise the
    // outer <article> and its inner card <article> both get saved as
    // duplicates.
    var skip = false;
    for (var j = 0; j < i; j++) {
      if (nodes[j].contains(el)) { skip = true; break; }
    }
    if (skip) continue;

    var title = pickTitle(el);
    if (!title) title = 'Article ' + (i + 1);
    results.push({
      title: title,
      html: el.outerHTML,
      href: pickHref(el)
    });
  }
  return JSON.stringify(results);
})();
"""

/** One detected article; ready to hand to [AppViewModel.saveOfflineHtmlPage]. */
internal data class DetectedArticle(
    val title: String,
    val html: String,
    /** Canonical URL for this article (its own anchor). Empty if none found. */
    val href: String
)

/**
 * Parse the JS-side JSON. `raw` is the exact string
 * `WebView.evaluateJavascript` handed back — a *JSON-encoded* JSON string,
 * so we unwrap the outer JSON encoding first before parsing the array.
 * Returns an empty list on any error rather than throwing; the FAB then
 * shows a Toast telling the user no articles were detected.
 */
internal fun parseDetectedArticles(raw: String?): List<DetectedArticle> {
    if (raw.isNullOrBlank() || raw == "null") return emptyList()
    return runCatching {
        // evaluateJavascript wraps string returns in JSON — decode that
        // outer layer before we look at the inner JSON array.
        val inner = JSONObject("{\"v\":$raw}").getString("v")
        val arr = JSONArray(inner)
        val out = ArrayList<DetectedArticle>(arr.length())
        for (i in 0 until arr.length()) {
            val o = arr.optJSONObject(i) ?: continue
            val html = o.optString("html", "").trim()
            if (html.isEmpty()) continue
            out.add(
                DetectedArticle(
                    title = o.optString("title", "Article ${i + 1}").trim(),
                    html = html,
                    href = o.optString("href", "").trim()
                )
            )
        }
        out
    }.getOrElse { emptyList() }
}

/** In-flight state for the FAB. Kept small so recomposition stays cheap. */
private sealed class SaveAllStage {
    object Idle : SaveAllStage()
    data class Running(val done: Int, val total: Int) : SaveAllStage()
}

/**
 * Floating action button that saves every detected article on the current
 * WebView page as a standalone offline `.html` file.
 *
 * Placement is up to the caller — pass a [Modifier] with the desired
 * `Alignment` inside the [Box] that hosts the WebView. Both WebPopup and
 * WebSearchScreen call this the same way, so the affordance looks identical
 * across the two viewers.
 *
 * The FAB owns its own coroutine — a batch save started from one composable
 * mount won't be cancelled if the user scrolls or the parent recomposes,
 * because [rememberCoroutineScope] ties it to the compose lifetime, not
 * individual keys. Tapping the FAB while a batch is already in flight is a
 * no-op (the button reads its state and skips a second launch).
 *
 * @param webViewProvider Returns the current WebView. A lambda (not the
 *    WebView itself) so the FAB always reads the latest reference — the
 *    tabbed browser swaps its WebView on tab-switch and the FAB must
 *    follow. Return null if no WebView is mounted; the button then
 *    silently no-ops.
 * @param pageUrlProvider Returns the URL currently loaded in the WebView.
 *    Used as a fallback `<base href>` for articles whose own anchor
 *    couldn't be found.
 */
@Composable
internal fun BoxScope.SaveAllArticlesFab(
    vm: AppViewModel,
    webViewProvider: () -> WebView?,
    pageUrlProvider: () -> String,
    modifier: Modifier = Modifier
) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()

    // MutableStateFlow of the completion counter as the constitution asks
    // for. We expose it to the composable via snapshotFlow → collectAsState
    // wouldn't compile without a StateFlow, so this is the right primitive
    // even though a plain `remember { mutableIntStateOf() }` would also
    // work. Advantage of the flow: the same counter could be observed
    // elsewhere (e.g. a global progress overlay) without refactoring.
    val savedCounter = remember { MutableStateFlow(0) }
    var stage by remember { mutableStateOf<SaveAllStage>(SaveAllStage.Idle) }

    // Mirror savedCounter → stage.done so the FAB label updates as each
    // article lands. snapshotFlow ties the coroutine to the composable's
    // lifetime; when it leaves the composition, the collector is cancelled.
    LaunchedEffect(Unit) {
        savedCounter.asStateFlow().collect { done ->
            val cur = stage
            if (cur is SaveAllStage.Running && cur.done != done) {
                stage = cur.copy(done = done)
            }
        }
    }

    fun launchSaveAll() {
        val cur = stage
        if (cur is SaveAllStage.Running) return  // ignore double-tap while busy
        val wv = webViewProvider() ?: run {
            Toast.makeText(ctx, "WebView isn't ready yet.", Toast.LENGTH_SHORT).show()
            return
        }
        val pageUrl = pageUrlProvider().ifBlank { wv.url ?: "" }

        wv.evaluateJavascript(COLLECT_ARTICLES_JS) { raw ->
            val articles = parseDetectedArticles(raw)
            if (articles.isEmpty()) {
                Toast.makeText(
                    ctx,
                    "\uD83D\uDD0D No articles detected on this page.",
                    Toast.LENGTH_SHORT
                ).show()
                return@evaluateJavascript
            }

            savedCounter.value = 0
            stage = SaveAllStage.Running(done = 0, total = articles.size)

            scope.launch {
                var ok = 0
                var failed = 0
                val savedNames = ArrayList<String>(articles.size)

                withContext(Dispatchers.IO) {
                    for (a in articles) {
                        val srcForBase = a.href.ifBlank { pageUrl }
                        val result = runCatching {
                            vm.saveOfflineHtmlPage(
                                sourceUrl = srcForBase,
                                title = a.title,
                                html = a.html
                            )
                        }.getOrElse { SaveResult.Error(it.message ?: "unknown") }
                        when (result) {
                            is SaveResult.Ok -> {
                                ok++
                                savedNames.add(result.fileName)
                            }
                            is SaveResult.Error -> failed++
                        }
                        // Publishes to the FAB label without blocking the IO
                        // dispatcher — MutableStateFlow's set is a plain
                        // volatile write.
                        savedCounter.value = ok + failed
                    }
                }

                // Auto-reindex so the freshly saved files appear in FTS
                // immediately — matches what the single-page "Save as
                // Offline HTML" menu item already does.
                if (ok > 0) {
                    runCatching { vm.reindex() }
                }

                stage = SaveAllStage.Idle
                val msg = buildString {
                    if (failed == 0) {
                        append("\uD83D\uDCBE Saved ")
                        append(ok)
                        append(if (ok == 1) " article" else " articles")
                    } else if (ok == 0) {
                        append("\u26A0\uFE0F Couldn't save any of the ")
                        append(articles.size)
                        append(" detected articles.")
                    } else {
                        append("\uD83D\uDCBE Saved ")
                        append(ok)
                        append(" of ")
                        append(articles.size)
                        append(" (")
                        append(failed)
                        append(" failed)")
                    }
                }
                Toast.makeText(ctx, msg, Toast.LENGTH_LONG).show()
            }
        }
    }

    when (val cur = stage) {
        is SaveAllStage.Idle -> {
            ExtendedFloatingActionButton(
                onClick = ::launchSaveAll,
                icon = { Text("\uD83D\uDCBE", fontSize = 18.sp) },
                text = { Text("Save all", fontWeight = FontWeight.SemiBold) },
                containerColor = MaterialTheme.colorScheme.tertiaryContainer,
                contentColor = MaterialTheme.colorScheme.onTertiaryContainer,
                elevation = FloatingActionButtonDefaults.elevation(defaultElevation = 6.dp),
                modifier = modifier
            )
        }
        is SaveAllStage.Running -> {
            // Non-interactive progress pill that replaces the FAB while a
            // batch is in flight. Same alignment/padding — no layout jump.
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.Center,
                modifier = modifier
                    .background(
                        color = MaterialTheme.colorScheme.tertiaryContainer,
                        shape = RoundedCornerShape(16.dp)
                    )
                    .padding(horizontal = 16.dp, vertical = 12.dp)
            ) {
                CircularProgressIndicator(
                    strokeWidth = 2.dp,
                    color = MaterialTheme.colorScheme.onTertiaryContainer,
                    modifier = Modifier.size(18.dp)
                )
                Spacer(Modifier.width(10.dp))
                Text(
                    "Saving ${cur.done}/${cur.total}\u2026",
                    color = MaterialTheme.colorScheme.onTertiaryContainer,
                    fontWeight = FontWeight.SemiBold,
                    fontSize = 13.sp
                )
            }
        }
    }
}

/**
 * Convenience alignment used by both WebPopup and WebSearchScreen — the FAB
 * sits at the bottom-start (opposite side from any existing bottom-end FAB
 * such as the "Article" back button in WebPopupFullScreen) with a
 * navigation-bar inset so it never lands beneath the gesture bar.
 */
internal fun Modifier.saveAllFabPlacement(): Modifier =
    this
        .windowInsetsPadding(WindowInsets.navigationBars)
        .padding(16.dp)
