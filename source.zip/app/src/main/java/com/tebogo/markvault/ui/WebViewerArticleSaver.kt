package com.tebogo.markvault.ui

import android.webkit.WebView
import android.widget.Toast
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.BoxScope
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.navigationBars
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.windowInsetsPadding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.ExtendedFloatingActionButton
import androidx.compose.material3.FloatingActionButtonDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.tebogo.markvault.AppViewModel
import kotlinx.coroutines.launch

/**
 * v5.4.88cc — WebViewer multi-selection helpers.
 *
 * Replaces the earlier auto-`<article>`-detection FAB (v5.4.87cc) with a
 * user-driven curation flow. See [AppViewModel] docs above
 * `webSelectionMode` for the full workflow rationale — the composables in
 * this file are the UI half of that contract.
 *
 * Three surfaces are exposed:
 *  - [SELECTION_CSS_JS] / [selection helpers] — inject/remove the outline
 *    style and the `.mv-selected` class on individual anchors.
 *  - [SelectionMenuItems] — the two DropdownMenuItems that go into the
 *    WebViewer's overflow menu (mode toggle + clear).
 *  - [WebSelectionFab] — the bottom-start FAB shown whenever selection
 *    mode is active; states are "waiting for selections", "save N",
 *    and "saving x/y".
 *
 * The composables here take no responsibility for wiring the long-press
 * itself — that lives inside each screen's existing
 * `setOnLongClickListener` because the two viewers do it slightly
 * differently. What we do provide is [applySelectionOnLoad] which the
 * caller drops straight into their `onPageFinished` to restore highlights
 * after navigation.
 */

// ─────────────────────────────────────────────────────────────────────────
// JavaScript payloads
// ─────────────────────────────────────────────────────────────────────────

/**
 * Injects (or removes) the `.mv-selected` outline stylesheet and, when
 * enabling, adds a subtle "long-press me" affordance cursor to every
 * anchor on the page. Idempotent: safe to re-run on every
 * `onPageFinished`. Called with `true` when selection mode turns on and
 * `false` when it turns off.
 */
internal const val SELECTION_CSS_ON_JS = """
(function() {
  var s = document.getElementById('mv-selection-style');
  if (!s) {
    s = document.createElement('style');
    s.id = 'mv-selection-style';
    s.textContent = '' +
      '.mv-selected, .mv-selected * { ' +
      '  background-color: rgba(76,175,80,0.18) !important; ' +
      '} ' +
      '.mv-selected { ' +
      '  outline: 3px solid #4CAF50 !important; ' +
      '  outline-offset: 2px !important; ' +
      '  border-radius: 4px !important; ' +
      '  transition: outline 0.15s ease, background-color 0.15s ease; ' +
      '} ' +
      'a[href], a[href] * { ' +
      '  -webkit-tap-highlight-color: rgba(76,175,80,0.25) !important; ' +
      '}';
    document.head.appendChild(s);
  }
})();
"""

internal const val SELECTION_CSS_OFF_JS = """
(function() {
  var s = document.getElementById('mv-selection-style');
  if (s && s.parentNode) s.parentNode.removeChild(s);
  var picked = document.querySelectorAll('.mv-selected');
  for (var i = 0; i < picked.length; i++) picked[i].classList.remove('mv-selected');
})();
"""

/**
 * Toggle the `.mv-selected` class on every anchor whose href equals the
 * given URL. The class is applied to the nearest "card-like" ancestor
 * (`<article>`, `.publication`, `<li>`, etc.) so the highlight actually
 * outlines the whole clickable region rather than a tiny inline link.
 *
 * `%URL%` and `%SEL%` are placeholders substituted from Kotlin.
 */
private const val TOGGLE_HIGHLIGHT_TEMPLATE = """
(function() {
  var target = %URL%;
  var selected = %SEL%;
  var links = document.querySelectorAll('a[href]');
  for (var i = 0; i < links.length; i++) {
    if (links[i].href !== target) continue;
    var el = links[i].closest(
      'article, .publication, .synopsis, .linkCard, .cardTitleBlock, ' +
      '.searchResult, li, .card, .item, [role="article"]'
    ) || links[i];
    if (selected) el.classList.add('mv-selected');
    else el.classList.remove('mv-selected');
  }
})();
"""

/**
 * Re-apply highlights for a list of URLs. Used from `onPageFinished` so
 * that after the user navigates while selection mode is on, previously
 * picked cards on the newly loaded page appear pre-selected. `%URLS%` is
 * substituted with a JSON array literal from Kotlin.
 */
private const val REHIGHLIGHT_ALL_TEMPLATE = """
(function() {
  var urls = %URLS%;
  if (!urls || urls.length === 0) return;
  var set = {};
  for (var i = 0; i < urls.length; i++) set[urls[i]] = true;
  var links = document.querySelectorAll('a[href]');
  for (var j = 0; j < links.length; j++) {
    if (!set[links[j].href]) continue;
    var el = links[j].closest(
      'article, .publication, .synopsis, .linkCard, .cardTitleBlock, ' +
      '.searchResult, li, .card, .item, [role="article"]'
    ) || links[j];
    el.classList.add('mv-selected');
  }
})();
"""

// ─────────────────────────────────────────────────────────────────────────
// Kotlin-side helpers (JS injection)
// ─────────────────────────────────────────────────────────────────────────

/** JSON-escape a string for safe embedding as a JS string literal. */
private fun jsQuote(s: String): String {
    val sb = StringBuilder(s.length + 2)
    sb.append('"')
    for (ch in s) {
        when (ch) {
            '\\' -> sb.append("\\\\")
            '"' -> sb.append("\\\"")
            '\n' -> sb.append("\\n")
            '\r' -> sb.append("\\r")
            '\t' -> sb.append("\\t")
            '<' -> sb.append("\\u003C")  // paranoia — never break out of <script>
            '>' -> sb.append("\\u003E")
            else -> if (ch.code < 0x20) sb.append("\\u%04x".format(ch.code)) else sb.append(ch)
        }
    }
    sb.append('"')
    return sb.toString()
}

/** Turn selection mode on visually — inject the CSS. */
internal fun webViewApplySelectionCss(webView: WebView, on: Boolean) {
    webView.evaluateJavascript(
        if (on) SELECTION_CSS_ON_JS else SELECTION_CSS_OFF_JS,
        null
    )
}

/** Add or remove the `.mv-selected` highlight for a specific URL. */
internal fun webViewHighlightUrl(webView: WebView, url: String, selected: Boolean) {
    val js = TOGGLE_HIGHLIGHT_TEMPLATE
        .replace("%URL%", jsQuote(url))
        .replace("%SEL%", if (selected) "true" else "false")
    webView.evaluateJavascript(js, null)
}

/** Restore highlights for every URL currently in the selection basket. */
internal fun webViewRehighlightAll(webView: WebView, urls: List<String>) {
    if (urls.isEmpty()) return
    val jsonArr = urls.joinToString(prefix = "[", postfix = "]", separator = ",") { jsQuote(it) }
    val js = REHIGHLIGHT_ALL_TEMPLATE.replace("%URLS%", jsonArr)
    webView.evaluateJavascript(js, null)
}

/**
 * Drop-in helper for a WebViewClient.onPageFinished: if selection mode is
 * currently active, re-inject CSS and re-mark any pre-selected cards on
 * the freshly loaded page. Cheap when mode is off (single boolean read).
 */
internal fun applySelectionOnLoad(webView: WebView, vm: AppViewModel) {
    if (!vm.webSelectionMode.value) return
    webViewApplySelectionCss(webView, true)
    webViewRehighlightAll(webView, vm.webSelectionItems.value.map { it.url })
}

// ─────────────────────────────────────────────────────────────────────────
// Composables
// ─────────────────────────────────────────────────────────────────────────

/**
 * Two DropdownMenuItems for the WebViewer's overflow menu:
 *  - "🎯 Selection mode: ON/OFF" — the master toggle.
 *  - "🧹 Clear selection (n)" — only shown when the basket is non-empty.
 *
 * The composable is a plain function that emits DropdownMenuItems as
 * siblings inside the caller's `DropdownMenu { ... }` scope, keeping the
 * menu layout consistent with the surrounding items.
 *
 * [onAfterAction] is invoked after each of the two items runs (typically
 * the caller's `menuOpen = false` — closes the menu). Kept as a callback
 * rather than a boolean so callers can also do e.g. haptic feedback.
 */
@Composable
internal fun SelectionMenuItems(
    vm: AppViewModel,
    /** Access to the current WebView for CSS injection. May return null. */
    webViewProvider: () -> WebView?,
    onAfterAction: () -> Unit
) {
    val mode by vm.webSelectionMode.collectAsState()
    val items by vm.webSelectionItems.collectAsState()

    DropdownMenuItem(
        text = {
            Text(
                if (mode) "\uD83C\uDFAF Selection mode: ON  •  tap to disable"
                else "\uD83C\uDFAF Enable selection mode"
            )
        },
        onClick = {
            val next = !mode
            vm.setWebSelectionMode(next)
            val wv = webViewProvider()
            if (wv != null) {
                webViewApplySelectionCss(wv, next)
                if (next) webViewRehighlightAll(wv, vm.webSelectionItems.value.map { it.url })
            }
            onAfterAction()
        }
    )
    if (items.isNotEmpty()) {
        DropdownMenuItem(
            text = { Text("\uD83E\uDDF9 Clear selection (${items.size})") },
            onClick = {
                vm.clearWebSelection()
                webViewProvider()?.let { webViewApplySelectionCss(it, true) }
                onAfterAction()
            }
        )
    }
}

/**
 * FAB shown at the bottom-start of the WebView while selection mode is
 * active. Three states:
 *
 *  - **Empty basket** — pill reads "🎯 Long-press links to select".
 *    Non-interactive.
 *  - **N selected** — extended FAB reads "💾 Save N articles". Tapping
 *    fires the batch fetch/save.
 *  - **Saving** — pill reads "Saving x/y…" with a spinner. Non-interactive.
 *
 * When selection mode is off, this composable emits nothing.
 *
 * Placement mirrors the earlier v5.4.87cc auto-save FAB — bottom-start,
 * navigation-bar inset padded — so muscle memory transfers. The FAB
 * appears inside the caller's Box.
 */
@Composable
internal fun BoxScope.WebSelectionFab(
    vm: AppViewModel,
    modifier: Modifier = Modifier
) {
    val mode by vm.webSelectionMode.collectAsState()
    if (!mode) return

    val items by vm.webSelectionItems.collectAsState()
    val saving by vm.webSelectionSaving.collectAsState()
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()

    val (done, total) = saving
    val isSaving = total > 0

    when {
        isSaving -> {
            // Running batch — inert progress pill.
            Row(
                verticalAlignment = androidx.compose.ui.Alignment.CenterVertically,
                horizontalArrangement = Arrangement.Center,
                modifier = modifier
                    .background(
                        color = MaterialTheme.colorScheme.tertiaryContainer,
                        shape = RoundedCornerShape(16.dp)
                    )
                    .padding(horizontal = 16.dp, vertical = 12.dp)
            ) {
                CircularProgressIndicator(
                    strokeWidth = 2.dp,
                    color = MaterialTheme.colorScheme.onTertiaryContainer,
                    modifier = Modifier.size(18.dp)
                )
                Spacer(Modifier.width(10.dp))
                Text(
                    "Saving $done/$total\u2026",
                    color = MaterialTheme.colorScheme.onTertiaryContainer,
                    fontWeight = FontWeight.SemiBold,
                    fontSize = 13.sp
                )
            }
        }
        items.isEmpty() -> {
            // Selection mode on but nothing picked yet — coaching pill.
            Row(
                verticalAlignment = androidx.compose.ui.Alignment.CenterVertically,
                horizontalArrangement = Arrangement.Center,
                modifier = modifier
                    .background(
                        color = MaterialTheme.colorScheme.secondaryContainer,
                        shape = RoundedCornerShape(16.dp)
                    )
                    .padding(horizontal = 14.dp, vertical = 10.dp)
            ) {
                Text("\uD83C\uDFAF", fontSize = 14.sp)
                Spacer(Modifier.width(8.dp))
                Text(
                    "Long-press links to select",
                    color = MaterialTheme.colorScheme.onSecondaryContainer,
                    fontWeight = FontWeight.Medium,
                    fontSize = 12.sp
                )
            }
        }
        else -> {
            // N items in basket — the "save" affordance.
            ExtendedFloatingActionButton(
                onClick = {
                    scope.launch {
                        val result = vm.batchSaveSelectedWebArticles()
                        val msg = buildString {
                            when {
                                result.failed == 0 -> {
                                    append("\uD83D\uDCBE Saved ")
                                    append(result.ok)
                                    append(if (result.ok == 1) " article" else " articles")
                                }
                                result.ok == 0 -> {
                                    append("\u26A0\uFE0F Couldn't save any of the ")
                                    append(result.total)
                                    append(" selected articles.")
                                }
                                else -> {
                                    append("\uD83D\uDCBE Saved ")
                                    append(result.ok)
                                    append(" of ")
                                    append(result.total)
                                    append(" (")
                                    append(result.failed)
                                    append(" failed)")
                                }
                            }
                        }
                        Toast.makeText(ctx, msg, Toast.LENGTH_LONG).show()
                    }
                },
                icon = { Text("\uD83D\uDCBE", fontSize = 18.sp) },
                text = {
                    Text(
                        "Save ${items.size} " + if (items.size == 1) "article" else "articles",
                        fontWeight = FontWeight.SemiBold
                    )
                },
                containerColor = MaterialTheme.colorScheme.tertiaryContainer,
                contentColor = MaterialTheme.colorScheme.onTertiaryContainer,
                elevation = FloatingActionButtonDefaults.elevation(defaultElevation = 6.dp),
                modifier = modifier
            )
        }
    }
}

/**
 * Convenience alignment used by both WebPopup and WebSearchScreen — the
 * FAB sits at the bottom-start (opposite side from any existing bottom-end
 * FAB such as the "Article" back button in WebPopupFullScreen) with a
 * navigation-bar inset so it never lands beneath the gesture bar.
 *
 * Marked @Composable because `WindowInsets.navigationBars` is a
 * @Composable getter (it reads inset values from the current composition
 * local); a plain function can't call it. Callers already invoke this
 * inside their own @Composable bodies, so no extra plumbing is needed.
 */
@Composable
internal fun Modifier.selectionFabPlacement(): Modifier =
    this
        .windowInsetsPadding(WindowInsets.navigationBars)
        .padding(16.dp)
