package com.tebogo.markvault.ui

import android.annotation.SuppressLint
import android.webkit.WebResourceRequest
import android.webkit.WebResourceError
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.Toast
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxScope
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.navigationBars
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.windowInsetsPadding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.ExtendedFloatingActionButton
import androidx.compose.material3.FloatingActionButtonDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import com.tebogo.markvault.AppViewModel
import com.tebogo.markvault.SaveResult
import kotlinx.coroutines.delay
import kotlinx.coroutines.suspendCancellableCoroutine
import kotlinx.coroutines.withTimeoutOrNull
import kotlin.coroutines.resume

/**
 * v5.4.89cc — WebViewer multi-selection helpers.
 *
 * Two important changes over v5.4.88cc based on user report:
 *
 *  1. **Highlight was invisible.** The old CSS relied on `outline` which
 *     can be clipped by ancestor `overflow: hidden` and on
 *     `background-color` which competes with the site's own
 *     `!important` rules. Replaced with a heavy multi-signal treatment:
 *     inward-drawn outline (`outline-offset: -4px` — can't be clipped),
 *     inset box-shadow, saturated background tint, AND a physical
 *     `.mv-badge` DIV child inserted in the top-left corner so there's
 *     always a "✓ SELECTED" flag even on cards with hostile CSS.
 *
 *  2. **Every save failed.** The old HTTP-based batch (v5.4.88cc)
 *     couldn't get past Cloudflare's bot heuristics on jw.org — every
 *     request returned a challenge stub instead of the real HTML. Fixed
 *     by delegating the load loop to a hidden 1dp WebView which shares
 *     Chromium's TLS session and cookie jar with the visible tab. Same
 *     WebView instance is reused across all URLs in the batch to keep
 *     memory pressure down. See [HiddenBatchSaver].
 *
 * Three composables + a handful of JS injection helpers are exported:
 *  - [SelectionMenuItems] — DropdownMenuItems for the overflow menu.
 *  - [WebSelectionFab] — the bottom-start save FAB.
 *  - [HiddenBatchSaver] — off-screen WebView that runs the batch.
 *  - [applySelectionOnLoad] — drop into `onPageFinished` to restore
 *    highlights after navigation.
 */

// ─────────────────────────────────────────────────────────────────────────
// JavaScript payloads
// ─────────────────────────────────────────────────────────────────────────

/**
 * Enable the selection-mode stylesheet on the current page. Idempotent:
 * safe to re-run on every `onPageFinished`, and safe to run repeatedly if
 * the user turns the mode on/off/on again. The CSS is deliberately
 * over-specified so it wins against sites like jw.org that heavily style
 * their own cards:
 *   - `outline-offset: -4px` draws the outline INSIDE the box so parents
 *     with `overflow: hidden` can't clip it away.
 *   - `box-shadow: inset ...` reinforces the outline with a second inner
 *     border that sites even more rarely target.
 *   - `background-color` with `!important` swamps the site's own bg
 *     rule, and the same rule is duplicated on `.mv-selected *` so
 *     children with their own opaque backgrounds don't hide the tint.
 *   - A physical `.mv-badge` DIV (inserted by JS below, not `::before`)
 *     is placed absolute-in-corner as a belt-and-braces "SELECTED" flag
 *     that survives even the weirdest CSS.
 *   - `-webkit-user-select: none` on anchors while mode is on stops the
 *     WebView from grabbing text-selection handles on long-press —
 *     otherwise the user gets the copy/paste toolbar competing with the
 *     link long-press we want.
 */
internal const val SELECTION_CSS_ON_JS = """
(function() {
  var s = document.getElementById('mv-selection-style');
  if (!s) {
    s = document.createElement('style');
    s.id = 'mv-selection-style';
    s.textContent = '' +
      '.mv-selected {' +
      '  position: relative !important;' +
      '  outline: 4px solid #22c55e !important;' +
      '  outline-offset: -4px !important;' +
      '  outline-style: solid !important;' +
      '  background-color: rgba(34,197,94,0.28) !important;' +
      '  box-shadow: inset 0 0 0 4px rgba(34,197,94,0.35), 0 0 0 4px rgba(34,197,94,0.55) !important;' +
      '  transition: none !important;' +
      '} ' +
      '.mv-selected * {' +
      '  background-color: rgba(34,197,94,0.10) !important;' +
      '} ' +
      '.mv-badge {' +
      '  position: absolute !important;' +
      '  top: 0 !important;' +
      '  left: 0 !important;' +
      '  z-index: 2147483647 !important;' +
      '  background: #16a34a !important;' +
      '  color: #ffffff !important;' +
      '  padding: 4px 10px !important;' +
      '  font-size: 12px !important;' +
      '  font-weight: 800 !important;' +
      '  font-family: -apple-system, BlinkMacSystemFont, sans-serif !important;' +
      '  border-radius: 0 0 8px 0 !important;' +
      '  box-shadow: 0 2px 6px rgba(0,0,0,0.35) !important;' +
      '  pointer-events: none !important;' +
      '  letter-spacing: 0.5px !important;' +
      '  line-height: 1 !important;' +
      '  display: block !important;' +
      '  text-transform: uppercase !important;' +
      '} ' +
      'a[href], a[href] * {' +
      '  -webkit-user-select: none !important;' +
      '  user-select: none !important;' +
      '  -webkit-touch-callout: none !important;' +
      '  -webkit-tap-highlight-color: rgba(34,197,94,0.30) !important;' +
      '}';
    (document.head || document.documentElement).appendChild(s);
  }
})();
"""

/**
 * Turn selection mode off: strip the stylesheet, remove the class from
 * everything currently marked, and delete any badge DIVs we injected.
 * Idempotent.
 */
internal const val SELECTION_CSS_OFF_JS = """
(function() {
  var s = document.getElementById('mv-selection-style');
  if (s && s.parentNode) s.parentNode.removeChild(s);
  var picked = document.querySelectorAll('.mv-selected');
  for (var i = 0; i < picked.length; i++) picked[i].classList.remove('mv-selected');
  var badges = document.querySelectorAll('.mv-badge');
  for (var j = 0; j < badges.length; j++) {
    if (badges[j].parentNode) badges[j].parentNode.removeChild(badges[j]);
  }
})();
"""

/**
 * Toggle `.mv-selected` and the corner badge for every anchor whose href
 * equals `%URL%`. Handles two important edge cases:
 *
 *  - Climbs to the nearest card-like ancestor before marking, so the
 *    highlight actually outlines the whole clickable region rather than a
 *    tiny inline link. Selector list is aggressive (includes classes seen
 *    on jw.org, wol.jw.org, and generic list markup).
 *  - Injects a real `<div class="mv-badge">` child (not `::before`) so the
 *    "✓ SELECTED" flag is guaranteed to render — pseudo-elements can be
 *    suppressed by aggressive site CSS but a real DOM node can't be.
 *
 * Returns the matched count as a JS number so Kotlin can Toast a warning
 * when zero elements matched (usually means the href stored on the anchor
 * differs from what `WebView.hitTestResult.extra` gave us, e.g. because
 * of a redirect).
 */
private const val TOGGLE_HIGHLIGHT_TEMPLATE = """
(function() {
  var target = %URL%;
  var selected = %SEL%;
  var links = document.querySelectorAll('a[href]');
  var matched = 0;

  function markContainer(el, on) {
    if (on) {
      el.classList.add('mv-selected');
      // Insert a badge as a direct child if we haven't already.
      var existing = null;
      for (var k = 0; k < el.children.length; k++) {
        if (el.children[k].classList && el.children[k].classList.contains('mv-badge')) {
          existing = el.children[k];
          break;
        }
      }
      if (!existing) {
        var badge = document.createElement('div');
        badge.className = 'mv-badge';
        badge.textContent = '\u2713 SAVED';
        el.appendChild(badge);
      }
    } else {
      el.classList.remove('mv-selected');
      var children = el.children;
      for (var m = children.length - 1; m >= 0; m--) {
        if (children[m].classList && children[m].classList.contains('mv-badge')) {
          el.removeChild(children[m]);
        }
      }
    }
  }

  for (var i = 0; i < links.length; i++) {
    if (links[i].href !== target) continue;
    matched++;
    // Try to escalate to a card container. If none matches, mark the
    // anchor itself — some sites (mobile jw.org menus) use bare <a>.
    var container = links[i].closest(
      'article, .publication, .publicationDesc, .publicationTitle, ' +
      '.publicationCardContent, .synopsis, .linkCard, .cardTitleBlock, ' +
      '.card, .cardLine1, .cardLine2, .searchResult, .doc, ' +
      '[role="article"], li, .item'
    );
    var elToMark = container || links[i];
    // Also mark the direct anchor when we climbed — one more visual anchor.
    if (container && container !== links[i]) {
      links[i].classList.toggle('mv-selected', selected);
    }
    markContainer(elToMark, selected);
  }
  return matched;
})();
"""

/**
 * Re-apply highlights for a whole list of URLs. Used from
 * `onPageFinished` so the user's basket stays visually consistent as
 * they navigate — cards that appear on multiple listing pages get their
 * green flag on each one. Uses the same container-climb logic as
 * [TOGGLE_HIGHLIGHT_TEMPLATE].
 */
private const val REHIGHLIGHT_ALL_TEMPLATE = """
(function() {
  var urls = %URLS%;
  if (!urls || urls.length === 0) return;
  var set = {};
  for (var i = 0; i < urls.length; i++) set[urls[i]] = true;
  var links = document.querySelectorAll('a[href]');
  for (var j = 0; j < links.length; j++) {
    if (!set[links[j].href]) continue;
    var container = links[j].closest(
      'article, .publication, .publicationDesc, .publicationTitle, ' +
      '.publicationCardContent, .synopsis, .linkCard, .cardTitleBlock, ' +
      '.card, .cardLine1, .cardLine2, .searchResult, .doc, ' +
      '[role="article"], li, .item'
    );
    var el = container || links[j];
    el.classList.add('mv-selected');
    // Also add a badge as a real DOM child (not ::before).
    var already = false;
    for (var k = 0; k < el.children.length; k++) {
      if (el.children[k].classList && el.children[k].classList.contains('mv-badge')) {
        already = true;
        break;
      }
    }
    if (!already) {
      var badge = document.createElement('div');
      badge.className = 'mv-badge';
      badge.textContent = '\u2713 SAVED';
      el.appendChild(badge);
    }
  }
})();
"""

// ─────────────────────────────────────────────────────────────────────────
// Kotlin-side helpers (JS injection)
// ─────────────────────────────────────────────────────────────────────────

/** JSON-escape a string for safe embedding as a JS string literal. */
private fun jsQuote(s: String): String {
    val sb = StringBuilder(s.length + 2)
    sb.append('"')
    for (ch in s) {
        when (ch) {
            '\\' -> sb.append("\\\\")
            '"' -> sb.append("\\\"")
            '\n' -> sb.append("\\n")
            '\r' -> sb.append("\\r")
            '\t' -> sb.append("\\t")
            '<' -> sb.append("\\u003C")
            '>' -> sb.append("\\u003E")
            else -> if (ch.code < 0x20) sb.append("\\u%04x".format(ch.code)) else sb.append(ch)
        }
    }
    sb.append('"')
    return sb.toString()
}

/** Turn selection mode on visually — inject the CSS + badge machinery. */
internal fun webViewApplySelectionCss(webView: WebView, on: Boolean) {
    webView.evaluateJavascript(
        if (on) SELECTION_CSS_ON_JS else SELECTION_CSS_OFF_JS,
        null
    )
}

/**
 * Add or remove the `.mv-selected` + corner badge for a specific URL.
 * The matched-count return value from the JS is currently discarded — a
 * zero result would indicate the anchor href differs from what
 * `WebView.hitTestResult` reported, which is worth surfacing only if
 * users complain the highlight doesn't stick.
 */
internal fun webViewHighlightUrl(webView: WebView, url: String, selected: Boolean) {
    val js = TOGGLE_HIGHLIGHT_TEMPLATE
        .replace("%URL%", jsQuote(url))
        .replace("%SEL%", if (selected) "true" else "false")
    webView.evaluateJavascript(js, null)
}

/** Restore highlights for every URL currently in the selection basket. */
internal fun webViewRehighlightAll(webView: WebView, urls: List<String>) {
    if (urls.isEmpty()) return
    val jsonArr = urls.joinToString(prefix = "[", postfix = "]", separator = ",") { jsQuote(it) }
    val js = REHIGHLIGHT_ALL_TEMPLATE.replace("%URLS%", jsonArr)
    webView.evaluateJavascript(js, null)
}

/**
 * Drop-in helper for `onPageFinished`: if selection mode is currently
 * active, re-inject CSS and re-mark any pre-selected cards on the freshly
 * loaded page. Cheap when mode is off (single boolean read).
 */
internal fun applySelectionOnLoad(webView: WebView, vm: AppViewModel) {
    if (!vm.webSelectionMode.value) return
    webViewApplySelectionCss(webView, true)
    webViewRehighlightAll(webView, vm.webSelectionItems.value.map { it.url })
}

/**
 * Decode a JSON-encoded string returned by `WebView.evaluateJavascript`.
 * The callback receives a value like `"<html>\u003E</html>"` — outer
 * quotes plus standard JSON escapes. Strips the outer quotes and
 * un-escapes `\\` `\"` `\n` `\r` `\t` and `\uXXXX` so the caller gets the
 * raw payload.
 *
 * Duplicated from [SelectionWebView.decodeJsSelectionPublic] rather than
 * imported to keep this file self-contained (that helper is deliberately
 * scoped to selection-menu decoding; leaning on it from batch-save code
 * would create a semantically weird dependency).
 */
private fun decodeJsHtmlString(jsonValue: String?): String {
    if (jsonValue.isNullOrBlank() || jsonValue == "null") return ""
    val trimmed = jsonValue.trim()
    val body = if (trimmed.length >= 2 && trimmed.first() == '"' && trimmed.last() == '"') {
        trimmed.substring(1, trimmed.length - 1)
    } else trimmed
    val sb = StringBuilder(body.length)
    var i = 0
    while (i < body.length) {
        val c = body[i]
        if (c != '\\') { sb.append(c); i++; continue }
        if (i + 1 >= body.length) { sb.append(c); i++; continue }
        when (val n = body[i + 1]) {
            '\\' -> { sb.append('\\'); i += 2 }
            '"' -> { sb.append('"'); i += 2 }
            'n' -> { sb.append('\n'); i += 2 }
            'r' -> { sb.append('\r'); i += 2 }
            't' -> { sb.append('\t'); i += 2 }
            '/' -> { sb.append('/'); i += 2 }
            'b' -> { sb.append('\b'); i += 2 }
            'f' -> { sb.append('\u000C'); i += 2 }
            'u' -> {
                if (i + 5 < body.length) {
                    val hex = body.substring(i + 2, i + 6)
                    val code = hex.toIntOrNull(16)
                    if (code != null) { sb.append(code.toChar()); i += 6 }
                    else { sb.append(c); i++ }
                } else { sb.append(c); i++ }
            }
            else -> { sb.append(n); i += 2 }
        }
    }
    return sb.toString()
}

// ─────────────────────────────────────────────────────────────────────────
// Composables
// ─────────────────────────────────────────────────────────────────────────

/**
 * Two DropdownMenuItems for the WebViewer's overflow menu:
 *  - "🎯 Selection mode: ON/OFF" — the master toggle.
 *  - "🧹 Clear selection (n)" — only shown when the basket is non-empty.
 *
 * The composable is a plain function that emits DropdownMenuItems as
 * siblings inside the caller's `DropdownMenu { ... }` scope.
 *
 * [onAfterAction] runs after each item (typically closes the menu).
 */
@Composable
internal fun SelectionMenuItems(
    vm: AppViewModel,
    webViewProvider: () -> WebView?,
    onAfterAction: () -> Unit
) {
    val mode by vm.webSelectionMode.collectAsState()
    val items by vm.webSelectionItems.collectAsState()

    DropdownMenuItem(
        text = {
            Text(
                if (mode) "\uD83C\uDFAF Selection mode: ON  •  tap to disable"
                else "\uD83C\uDFAF Enable selection mode"
            )
        },
        onClick = {
            val next = !mode
            vm.setWebSelectionMode(next)
            val wv = webViewProvider()
            if (wv != null) {
                webViewApplySelectionCss(wv, next)
                if (next) webViewRehighlightAll(wv, vm.webSelectionItems.value.map { it.url })
            }
            onAfterAction()
        }
    )
    if (items.isNotEmpty()) {
        DropdownMenuItem(
            text = { Text("\uD83E\uDDF9 Clear selection (${items.size})") },
            onClick = {
                vm.clearWebSelection()
                webViewProvider()?.let { webViewApplySelectionCss(it, true) }
                onAfterAction()
            }
        )
    }
}

/**
 * FAB shown at the bottom-start of the WebView while selection mode is
 * active. States: empty basket → coaching pill; N picked → "Save N
 * articles"; saving → spinner + "Saving x/y…". Emits nothing when
 * selection mode is off.
 *
 * Tapping the save button kicks off [AppViewModel.startBatchSave] which
 * publishes the queue to [AppViewModel.batchSaveRequest]. The
 * [HiddenBatchSaver] composable (rendered separately in the WebView Box)
 * observes that queue and performs the actual loads + saves.
 */
@Composable
internal fun BoxScope.WebSelectionFab(
    vm: AppViewModel,
    modifier: Modifier = Modifier
) {
    val mode by vm.webSelectionMode.collectAsState()
    if (!mode) return

    val items by vm.webSelectionItems.collectAsState()
    val saving by vm.webSelectionSaving.collectAsState()

    val (done, total) = saving
    val isSaving = total > 0

    when {
        isSaving -> {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.Center,
                modifier = modifier
                    .background(
                        color = MaterialTheme.colorScheme.tertiaryContainer,
                        shape = RoundedCornerShape(16.dp)
                    )
                    .padding(horizontal = 16.dp, vertical = 12.dp)
            ) {
                CircularProgressIndicator(
                    strokeWidth = 2.dp,
                    color = MaterialTheme.colorScheme.onTertiaryContainer,
                    modifier = Modifier.size(18.dp)
                )
                Spacer(Modifier.width(10.dp))
                Text(
                    "Saving $done/$total\u2026",
                    color = MaterialTheme.colorScheme.onTertiaryContainer,
                    fontWeight = FontWeight.SemiBold,
                    fontSize = 13.sp
                )
            }
        }
        items.isEmpty() -> {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.Center,
                modifier = modifier
                    .background(
                        color = MaterialTheme.colorScheme.secondaryContainer,
                        shape = RoundedCornerShape(16.dp)
                    )
                    .padding(horizontal = 14.dp, vertical = 10.dp)
            ) {
                Text("\uD83C\uDFAF", fontSize = 14.sp)
                Spacer(Modifier.width(8.dp))
                Text(
                    "Long-press links to select",
                    color = MaterialTheme.colorScheme.onSecondaryContainer,
                    fontWeight = FontWeight.Medium,
                    fontSize = 12.sp
                )
            }
        }
        else -> {
            ExtendedFloatingActionButton(
                onClick = { vm.startBatchSave() },
                icon = { Text("\uD83D\uDCBE", fontSize = 18.sp) },
                text = {
                    Text(
                        "Save ${items.size} " + if (items.size == 1) "article" else "articles",
                        fontWeight = FontWeight.SemiBold
                    )
                },
                containerColor = MaterialTheme.colorScheme.tertiaryContainer,
                contentColor = MaterialTheme.colorScheme.onTertiaryContainer,
                elevation = FloatingActionButtonDefaults.elevation(defaultElevation = 6.dp),
                modifier = modifier
            )
        }
    }
}

/**
 * Hidden 1dp WebView that performs the batch-save loop. Rendered inside
 * the WebViewer's Box; only occupies visible space (a single pixel in the
 * corner) while a batch is actually running — otherwise it emits nothing
 * and doesn't allocate the WebView.
 *
 * When [AppViewModel.batchSaveRequest] flips non-empty, this composable:
 *  1. Creates a private WebView with the same critical settings as the
 *     visible tabs (JS enabled, image loading on, real-browser UA so
 *     jw.org doesn't downgrade us to the low-bandwidth shim).
 *  2. Iterates the request, awaiting each page via
 *     `suspendCancellableCoroutine` wrapped around WebViewClient's
 *     `onPageFinished` / `onReceivedError`.
 *  3. Pulls `document.documentElement.outerHTML` after a short settle
 *     delay for late JS to render, hands the string to
 *     [AppViewModel.saveBatchItem].
 *  4. Publishes per-URL progress to [AppViewModel.updateBatchSaveProgress]
 *     so the FAB's "Saving x/y…" pill updates live.
 *  5. Fires the completion Toast, then calls
 *     [AppViewModel.finishBatchSave].
 *
 * Cookies + TLS session come from Chromium's shared jar, so any page the
 * user could load in a visible tab is reachable here too — including
 * Cloudflare-protected sites like jw.org.
 */
@SuppressLint("SetJavaScriptEnabled")
@Composable
internal fun HiddenBatchSaver(vm: AppViewModel) {
    val request by vm.batchSaveRequest.collectAsState()
    val ctx = LocalContext.current

    if (request.isEmpty()) return

    // WebView is created once, reused across all URLs in a batch.
    // `remember(request)` keys it to this batch — a subsequent batch after
    // finishBatchSave() will build a fresh WebView, avoiding stale
    // WebViewClient state carrying over.
    val webView = remember(request) {
        WebView(ctx).apply {
            settings.javaScriptEnabled = true
            settings.domStorageEnabled = true
            settings.loadsImagesAutomatically = true
            settings.mediaPlaybackRequiresUserGesture = true
            settings.mixedContentMode = WebSettings.MIXED_CONTENT_COMPATIBILITY_MODE
            // Real-browser UA (strip the "; wv)" WebView marker) so
            // Cloudflare / jw.org don't serve a stripped page.
            val defaultUa = settings.userAgentString
            settings.userAgentString = if (defaultUa.isNullOrBlank()) {
                "Mozilla/5.0 (Linux; Android 14) AppleWebKit/537.36 " +
                    "(KHTML, like Gecko) Chrome/120.0.0.0 Mobile Safari/537.36"
            } else {
                defaultUa.replace("; wv)", ")")
            }
        }
    }

    // The 1dp box is off-screen for practical purposes but MUST be
    // attached to the view hierarchy — a detached WebView won't fire
    // onPageFinished reliably. AndroidView handles the attach for us.
    Box(Modifier.size(1.dp)) {
        AndroidView(
            modifier = Modifier.size(1.dp),
            factory = { webView }
        )
    }

    LaunchedEffect(request) {
        if (request.isEmpty()) return@LaunchedEffect
        var ok = 0
        var failed = 0
        vm.updateBatchSaveProgress(0, request.size)

        for ((idx, item) in request.withIndex()) {
            val html = loadPageAndGetHtml(webView, item.url, timeoutMs = 30_000)
            if (html.isNullOrBlank()) {
                failed++
                vm.updateBatchSaveProgress(idx + 1, request.size)
                continue
            }
            val pageTitle = webView.title
            val res = vm.saveBatchItem(item, html, pageTitle)
            when (res) {
                is SaveResult.Ok -> ok++
                is SaveResult.Error -> failed++
            }
            vm.updateBatchSaveProgress(idx + 1, request.size)
        }

        val total = request.size
        val msg = buildString {
            when {
                failed == 0 -> {
                    append("\uD83D\uDCBE Saved ")
                    append(ok)
                    append(if (ok == 1) " article" else " articles")
                }
                ok == 0 -> {
                    append("\u26A0\uFE0F Couldn't save any of the ")
                    append(total)
                    append(" selected articles.")
                }
                else -> {
                    append("\uD83D\uDCBE Saved ")
                    append(ok)
                    append(" of ")
                    append(total)
                    append(" (")
                    append(failed)
                    append(" failed)")
                }
            }
        }
        Toast.makeText(ctx, msg, Toast.LENGTH_LONG).show()
        // Finish AFTER the toast so the state reset doesn't cause the
        // "Save N articles" FAB to briefly reappear at a stale count.
        vm.finishBatchSave()
        // Clean up the WebView — Android can be sloppy about this on
        // orientation changes, and we don't want zombie WebViews holding
        // onto the last batch's WebViewClient.
        webView.stopLoading()
        webView.loadUrl("about:blank")
    }
}

/**
 * Suspending helper: navigate the given WebView to [url], wait for it to
 * finish loading (or error), then read the entire rendered outerHTML back
 * to Kotlin. Returns null on error, timeout, or an empty HTML payload.
 *
 * The settle delay (1200 ms after onPageFinished) is what lets late JS —
 * jw.org's article body renders can shuffle images in for a beat after
 * page-load — actually paint before we capture. Without it, we sometimes
 * get the loading skeleton instead of the real content.
 */
private suspend fun loadPageAndGetHtml(
    webView: WebView,
    url: String,
    timeoutMs: Long
): String? = withTimeoutOrNull(timeoutMs) {
    // Two-phase suspend: (1) wait for onPageFinished / onReceivedError,
    // (2) settle-delay, (3) evaluateJavascript. Wrapped as one
    // suspendCancellableCoroutine so cancellation (batch abort, timeout)
    // reliably stops the WebView load.
    suspendCancellableCoroutine<String?> { cont ->
        var consumed = false
        webView.webViewClient = object : WebViewClient() {
            override fun onPageFinished(view: WebView?, finishedUrl: String?) {
                if (view == null || consumed) return
                consumed = true
                // Settle delay + outerHTML extract. postDelayed keeps us
                // on the WebView's UI-thread queue.
                view.postDelayed({
                    view.evaluateJavascript(
                        "(function(){return document.documentElement.outerHTML;})();"
                    ) { raw ->
                        if (!cont.isActive) return@evaluateJavascript
                        val html = decodeJsHtmlString(raw)
                        cont.resume(html.takeIf { it.isNotBlank() })
                    }
                }, 1200L)
            }

            override fun onReceivedError(
                view: WebView?,
                request: WebResourceRequest?,
                error: WebResourceError?
            ) {
                if (request?.isForMainFrame != true || consumed) return
                consumed = true
                if (cont.isActive) cont.resume(null)
            }

            @Suppress("DEPRECATION")
            override fun onReceivedError(
                view: WebView?,
                errorCode: Int,
                description: String?,
                failingUrl: String?
            ) {
                if (consumed) return
                consumed = true
                if (cont.isActive) cont.resume(null)
            }
        }
        cont.invokeOnCancellation {
            runCatching { webView.stopLoading() }
        }
        webView.loadUrl(url)
    }.also {
        // A brief inter-request breather so we don't hammer the origin
        // server. Not strictly needed but polite to jw.org.
        delay(150)
    }
}

/**
 * Convenience alignment used by both WebPopup and WebSearchScreen — the
 * FAB sits at the bottom-start (opposite side from any existing
 * bottom-end FAB such as the "Article" back button in
 * WebPopupFullScreen) with a navigation-bar inset so it never lands
 * beneath the gesture bar.
 *
 * Marked @Composable because `WindowInsets.navigationBars` is a
 * @Composable getter (it reads inset values from the current composition
 * local); a plain function can't call it. Callers already invoke this
 * inside their own @Composable bodies, so no extra plumbing is needed.
 */
@Composable
internal fun Modifier.selectionFabPlacement(): Modifier =
    this
        .windowInsetsPadding(WindowInsets.navigationBars)
        .padding(16.dp)
