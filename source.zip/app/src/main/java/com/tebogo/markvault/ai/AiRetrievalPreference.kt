package com.tebogo.markvault.ai

/**
 * Controls whether AI multi-query expansion is used.
 * Disabled mode keeps normal semantic search and reranking.
 */
object AiRetrievalPreference {

    private var enabled: Boolean = true

    fun setEnabled(value: Boolean) {
        enabled = value
    }

    fun isEnabled(): Boolean = enabled
}
