package com.tebogo.markvault.ui

/** UI state for T5 expansion settings. */
data class T5SettingsUiState(
    val enabled: Boolean = false,
    val installed: Boolean = false,
    val downloadProgress: Int = 0,
    val error: String? = null
)
