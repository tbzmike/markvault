package com.tebogo.markvault.search

/**
 * Static description of one on-device embedding model. Captures everything the
 * [Embedder] needs to download, identify, and load a model.
 *
 * The string [id] is also used as the DB key (`modelVersion`) for every
 * embedding row produced by this model. **Never change [id] for a model that
 * has been shipped** — doing so orphans every embedding in the database. To
 * release a new variant, add a new [ModelDescriptor] with a fresh [id].
 *
 * v4.9.0 — initial multi-model scaffolding. The catalog ships with a single
 * entry (USE Lite) but the API is designed so adding more models in future
 * app updates is a data-only change.
 */
data class ModelDescriptor(
    /** Stable identifier. Used as the DB embedding key and the active-model pref value. */
    val id: String,
    /** Human-readable name shown in Settings. */
    val displayName: String,
    /** One-line description of the model's tradeoffs. */
    val description: String,
    /** HTTPS URL the .tflite (or other native) file is fetched from on opt-in. */
    val downloadUrl: String,
    /** Filename inside the app's `filesDir` once downloaded. */
    val localFilename: String,
    /** Approximate download size in megabytes, surfaced in the download button label. */
    val approxSizeMb: Int,
    /** Output vector dimensionality. Used for sanity checks at query time. */
    val embeddingDim: Int,
)

/**
 * Catalog of known embedding models. Adding a new model is a single data-only
 * edit here — no other file needs to change. The active model is selected via
 * the `activeModelId` preference; the [Embedder] is constructed per descriptor.
 */
object ModelCatalog {

    /**
     * Universal Sentence Encoder Lite from MediaPipe. 100-dim embeddings,
     * ~25 MB on disk, runs through the MediaPipe Tasks `TextEmbedder` API.
     *
     * IMPORTANT: the [id] string is the same one v4.8.x used as a constant
     * inside [Embedder]. Preserving it means every embedding the user has
     * already built (and the already-downloaded `use_lite_embedder.tflite`
     * file) is reused without re-download or re-embedding.
     */
    val USE_LITE_V1 = ModelDescriptor(
        id = "mediapipe-use-lite-v1",
        displayName = "Universal Sentence Encoder Lite",
        description = "Lightweight 2019 baseline. 100-dim embeddings. Good general English understanding; smaller than the alternatives.",
        downloadUrl = "https://storage.googleapis.com/mediapipe-models/text_embedder/universal_sentence_encoder/float32/latest/universal_sentence_encoder.tflite",
        localFilename = "use_lite_embedder.tflite",
        approxSizeMb = 25,
        embeddingDim = 100,
    )

    /** Every known descriptor, ordered most-recommended first. */
    val all: List<ModelDescriptor> = listOf(USE_LITE_V1)

    /** Fallback when the stored pref doesn't match anything in the catalog. */
    val default: ModelDescriptor get() = USE_LITE_V1

    /** Look up by [ModelDescriptor.id]; returns null if no such model is known. */
    fun byId(id: String?): ModelDescriptor? = all.firstOrNull { it.id == id }
}
