package com.tebogo.markvault.search

/**
 * Which native runtime an embedding model uses. Different frameworks need
 * different backend implementations inside [Embedder] — MediaPipe handles its
 * own tokenization while ONNX models bring their own tokenizer files.
 */
enum class ModelFramework {
    /** MediaPipe Tasks `TextEmbedder` API — `.tflite` files. */
    MEDIAPIPE_USE,
    /** ONNX Runtime with a WordPiece BERT tokenizer — `.onnx` files plus vocab. */
    ONNX_BERT,
}

/**
 * An additional remote file that's part of installing a model — most commonly
 * a vocabulary or tokenizer file alongside the primary model weights.
 *
 * Used by [ModelDescriptor.extraFiles]. Frameworks that need extra files
 * (e.g. ONNX BERT models with WordPiece vocabs) populate this list; simpler
 * frameworks (MediaPipe USE) leave it empty.
 */
data class RemoteAsset(
    val url: String,
    val localFilename: String,
)

/**
 * Static description of one on-device embedding model. Captures everything the
 * [Embedder] needs to download, identify, and load a model.
 *
 * The string [id] is also used as the DB key (`modelVersion`) for every
 * embedding row produced by this model. **Never change [id] for a model that
 * has been shipped** — doing so orphans every embedding in the database. To
 * release a new variant, add a new [ModelDescriptor] with a fresh [id].
 *
 * v4.9.0 — initial multi-model scaffolding. The catalog ships with USE Lite
 * and a placeholder MiniLM entry.
 * v4.10.0 — MiniLM entry activated with the ONNX backend, [extraFiles] added
 * for its vocab.txt.
 */
data class ModelDescriptor(
    /** Stable identifier. Used as the DB embedding key and the active-model pref value. */
    val id: String,
    /** Human-readable name shown in Settings. */
    val displayName: String,
    /** Short label shown next to the search indicator (≤ ~12 chars). */
    val shortName: String,
    /** One-line description of the model's tradeoffs. */
    val description: String,
    /** Which native runtime this model uses. Routes to the right [Embedder] backend. */
    val framework: ModelFramework,
    /** HTTPS URL the model file is fetched from on opt-in. */
    val downloadUrl: String,
    /** Filename inside the app's `filesDir` once downloaded. */
    val localFilename: String,
    /** Approximate download size in megabytes, surfaced in the install button label. */
    val approxSizeMb: Int,
    /** Output vector dimensionality. Used for sanity checks at query time. */
    val embeddingDim: Int,
    /**
     * Whether this descriptor is currently installable. When false, the UI
     * renders it as "coming soon" and the VM refuses to activate it.
     */
    val enabled: Boolean = true,
    /**
     * Additional files needed at install time (e.g. vocab.txt for BERT
     * tokenizers). Each backend interprets these — the MediaPipe backend
     * ignores them, the ONNX BERT backend uses the first one as the vocab.
     * v4.10.0 — introduced for MiniLM.
     */
    val extraFiles: List<RemoteAsset> = emptyList(),
)

/**
 * Catalog of known embedding models. Adding a new model is a single data-only
 * edit here — no other file needs to change. The active model is selected via
 * the `activeModelId` preference; the [Embedder] is constructed per descriptor.
 */
object ModelCatalog {

    /**
     * Universal Sentence Encoder Lite from MediaPipe. 100-dim embeddings,
     * ~25 MB on disk, runs through the MediaPipe Tasks `TextEmbedder` API.
     *
     * IMPORTANT: the [id] string is the same one v4.8.x used as a constant
     * inside [Embedder]. Preserving it means every embedding the user has
     * already built (and the already-downloaded `use_lite_embedder.tflite`
     * file) is reused without re-download or re-embedding.
     */
    val USE_LITE_V1 = ModelDescriptor(
        id = "mediapipe-use-lite-v1",
        displayName = "Universal Sentence Encoder Lite",
        shortName = "USE Lite",
        description = "Lightweight 2019 baseline. 100-dim embeddings. Good general English understanding; smaller than the alternatives.",
        framework = ModelFramework.MEDIAPIPE_USE,
        downloadUrl = "https://storage.googleapis.com/mediapipe-models/text_embedder/universal_sentence_encoder/float32/latest/universal_sentence_encoder.tflite",
        localFilename = "use_lite_embedder.tflite",
        approxSizeMb = 25,
        embeddingDim = 100,
        enabled = true,
    )

    /**
     * all-MiniLM-L6-v2 from Sentence-Transformers (Xenova quantized ONNX
     * variant on Hugging Face). 384-dim embeddings, ~23 MB on disk.
     *
     * v4.10.0 — activated. Uses [ONNX_BERT][ModelFramework.ONNX_BERT] backend
     * with ONNX Runtime and an in-Kotlin WordPiece tokenizer.
     */
    val MINI_LM_L6_V2 = ModelDescriptor(
        id = "onnx-minilm-l6-v2",
        displayName = "all-MiniLM-L6-v2",
        shortName = "MiniLM-L6",
        description = "Stronger 2021 Sentence-Transformers model. 384-dim embeddings. Better retrieval quality than USE Lite on most queries.",
        framework = ModelFramework.ONNX_BERT,
        downloadUrl = "https://huggingface.co/Xenova/all-MiniLM-L6-v2/resolve/main/onnx/model_quantized.onnx",
        localFilename = "minilm_l6_v2.onnx",
        approxSizeMb = 23,
        embeddingDim = 384,
        enabled = true,
        extraFiles = listOf(
            RemoteAsset(
                url = "https://huggingface.co/sentence-transformers/all-MiniLM-L6-v2/resolve/main/vocab.txt",
                localFilename = "minilm_l6_v2_vocab.txt",
            ),
        ),
    )

    /** Every known descriptor, ordered most-recommended first. */
    val all: List<ModelDescriptor> = listOf(USE_LITE_V1, MINI_LM_L6_V2)

    /** Fallback when the stored pref doesn't match anything in the catalog. */
    val default: ModelDescriptor get() = USE_LITE_V1

    /** Look up by [ModelDescriptor.id]; returns null if no such model is known. */
    fun byId(id: String?): ModelDescriptor? = all.firstOrNull { it.id == id }
}
