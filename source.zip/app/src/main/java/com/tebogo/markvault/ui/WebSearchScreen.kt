package com.tebogo.markvault.ui

import android.annotation.SuppressLint
import android.content.Intent
import android.net.Uri
import android.os.Message
import android.view.ViewGroup
import android.webkit.WebChromeClient
import android.webkit.WebResourceRequest
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.Toast
import androidx.activity.compose.BackHandler
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.filled.KeyboardArrowLeft
import androidx.compose.material.icons.automirrored.filled.KeyboardArrowRight
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.MoreVert
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextFieldDefaults
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.key
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.runtime.snapshots.SnapshotStateList
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalSoftwareKeyboardController
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.navigation.NavController
import com.tebogo.markvault.AppViewModel
import kotlinx.coroutines.launch

/**
 * Hosts allowed by the in-app browser. www.jw.org IS in the list — earlier
 * black-screen reports turned out to be MIXED_CONTENT_NEVER_ALLOW, not host
 * filtering. With COMPATIBILITY_MODE + this list the Bible viewer and
 * Watchtower Library both load.
 */
private val ALLOWED_HOSTS = setOf(
    "jw.org", "www.jw.org", "m.jw.org",
    "wol.jw.org", "wol.jw.org.za", "tv.jw.org",
    "b.jw-cdn.org", "assetsnffrgf-a.akamaihd.net",
    "data.jw-api.org", "apps.jw.org"
)

private fun isAllowed(uri: Uri?): Boolean {
    val host = uri?.host?.lowercase() ?: return false
    return ALLOWED_HOSTS.any { host == it || host.endsWith(".$it") } ||
        host.endsWith(".jw.org") || host.endsWith(".jw-cdn.org") || host == "jw.org"
}

/**
 * State for one open tab. Each tab keeps its own URL + title; switching tabs
 * recreates the WebView (via Compose `key`) so each tab has an isolated history
 * stack. Trade-off: in-page state (scroll, form input) doesn't persist across
 * tab switches — acceptable for a first-cut multi-tab implementation.
 */
data class WebTab(val id: Long, var url: String, var title: String)

/**
 * Multi-tab in-app browser with bottom-anchored toolbar.
 *
 * Layout:
 *   ┌──────────────────────────┐
 *   │   (minimal top bar)      │  ← only Home/back to keep chrome thumb-reachable
 *   ├──────────────────────────┤
 *   │                          │
 *   │       WebView area       │  ← the active tab's content
 *   │                          │
 *   ├──────────────────────────┤
 *   │   tab strip (←  → +)     │
 *   │   address bar + nav      │
 *   │   action row             │  ← everything else lives at the bottom
 *   └──────────────────────────┘
 */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun WebSearchScreen(vm: AppViewModel, nav: NavController, url: String, label: String) {
    val ctx = LocalContext.current
    val keyboard = LocalSoftwareKeyboardController.current
    val scope = rememberCoroutineScopeSafe()

    // TASK 4: tab list now lives on the AppViewModel so it survives screen
    // navigation. ensureBrowserSession is idempotent — if the user is reopening
    // the browser after looking at a markdown note, their existing tabs are kept.
    LaunchedEffect(Unit) { vm.ensureBrowserSession(url, label) }
    val tabs: SnapshotStateList<WebTab> = vm.webTabs
    val activeTabIdx = vm.webActiveTabIdx
    if (tabs.isEmpty()) {
        // Render nothing this frame; the LaunchedEffect above will populate the list
        // and trigger recomposition with a valid active tab.
        return
    }

    // Per-tab state lives in the Compose `key` block — re-created on tab switch.
    // We track UI state at this level so the bottom bar reacts to the active tab.
    var webView by remember { mutableStateOf<WebView?>(null) }
    var loading by remember { mutableStateOf(true) }
    var progress by remember { mutableStateOf(0) }
    var addressText by remember(activeTabIdx) { mutableStateOf(tabs[activeTabIdx].url) }
    var addressFocused by remember { mutableStateOf(false) }
    var canGoBack by remember { mutableStateOf(false) }
    var canGoForward by remember { mutableStateOf(false) }

    // Find-on-page state — search field opens above the bottom toolbar.
    var findOpen by remember { mutableStateOf(false) }
    var findQuery by remember { mutableStateOf("") }

    // Bookmark state for the active URL
    var isBookmarked by remember { mutableStateOf(false) }
    LaunchedEffect(addressText) {
        isBookmarked = if (addressText.isBlank()) false
        else vm.isBookmarked(addressText)
    }

    // Menu
    var menuOpen by remember { mutableStateOf(false) }

    fun loadUrlFromAddress(raw: String) {
        val cleaned = raw.trim()
        if (cleaned.isEmpty()) return
        val target = when {
            cleaned.startsWith("http://") || cleaned.startsWith("https://") -> cleaned
            cleaned.contains(".") -> "https://$cleaned"
            else -> "https://www.jw.org/en/search/?q=" + Uri.encode(cleaned)
        }
        if (!isAllowed(Uri.parse(target))) {
            Toast.makeText(ctx, "Only jw.org family of sites are allowed", Toast.LENGTH_SHORT).show()
            return
        }
        keyboard?.hide()
        webView?.loadUrl(target)
        addressFocused = false
    }

    fun addNewTab(initialUrl: String = "https://www.jw.org/en/") {
        vm.addBrowserTab(initialUrl, "New tab")
    }

    fun closeTab(idx: Int) {
        val lastClosed = vm.closeBrowserTab(idx)
        if (lastClosed) nav.popBackStack()
    }

    BackHandler(enabled = true) {
        val wv = webView
        if (wv != null && wv.canGoBack()) wv.goBack() else nav.popBackStack()
    }

    Scaffold(
        // Minimal top bar — just home + close-browser
        topBar = {
            TopAppBar(
                title = {
                    Text(
                        "\uD83C\uDF10 ${tabs[activeTabIdx].title.take(40)}",
                        maxLines = 1, overflow = TextOverflow.Ellipsis,
                        fontSize = 13.sp
                    )
                },
                navigationIcon = {
                    IconButton(onClick = { nav.popBackStack() }) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Close browser")
                    }
                },
                actions = { HomeButton(nav) }
            )
        },
        // Bottom-anchored toolbar — tab strip, address bar, action buttons
        bottomBar = {
            BrowserBottomBar(
                tabs = tabs,
                activeTabIdx = activeTabIdx,
                onTabClick = { vm.setWebActiveTab(it) },
                onTabClose = ::closeTab,
                onAddTab = { addNewTab() },
                addressText = addressText,
                onAddressChange = { addressText = it },
                onAddressFocus = { addressFocused = it },
                onSubmit = { loadUrlFromAddress(addressText) },
                canGoBack = canGoBack,
                canGoForward = canGoForward,
                onBack = { webView?.goBack() },
                onForward = { webView?.goForward() },
                onReloadOrStop = { if (loading) webView?.stopLoading() else webView?.reload() },
                loading = loading,
                isBookmarked = isBookmarked,
                onToggleBookmark = {
                    val u = webView?.url ?: addressText
                    val t = webView?.title ?: tabs[activeTabIdx].title
                    if (isBookmarked) vm.removeBookmark(u) else vm.addBookmark(u, t)
                    isBookmarked = !isBookmarked
                },
                onOpenFind = { findOpen = true; findQuery = "" },
                menuOpen = menuOpen,
                onMenuToggle = { menuOpen = it },
                nav = nav,
                findOpen = findOpen,
                findQuery = findQuery,
                onFindChange = { findQuery = it; webView?.findAllAsync(it) },
                onFindClose = { findOpen = false; webView?.clearMatches() },
                onFindNext = { webView?.findNext(true) },
                onFindPrev = { webView?.findNext(false) },
                // TASK 2 (v4.4): save the current page as a real .html file
                // — previous implementation used saveWebArchive which only
                // produces .mhtml. Now we grab document.documentElement.outerHTML
                // via JS and write that as text/html in the library.
                onSaveOfflineHtml = {
                    val wv = webView ?: return@BrowserBottomBar
                    val title = wv.title?.takeIf { it.isNotBlank() } ?: tabs[activeTabIdx].title
                    val srcUrl = wv.url ?: tabs[activeTabIdx].url
                    wv.evaluateJavascript(
                        "(function(){return document.documentElement.outerHTML;})();"
                    ) { jsonHtml ->
                        val html = decodeJsString(jsonHtml)
                        if (html.isBlank()) {
                            Toast.makeText(ctx, "Couldn't capture the page HTML.",
                                Toast.LENGTH_SHORT).show()
                            return@evaluateJavascript
                        }
                        scope.launch {
                            val res = vm.saveOfflineHtmlPage(srcUrl, title, html)
                            val msg = when (res) {
                                is com.tebogo.markvault.SaveResult.Ok -> "\uD83D\uDCBE Saved: ${res.fileName}"
                                is com.tebogo.markvault.SaveResult.Error -> "\u26A0\uFE0F ${res.message}"
                            }
                            Toast.makeText(ctx, msg, Toast.LENGTH_LONG).show()
                        }
                    }
                },
                // TASK 3: convert current page to a markdown note in the vault
                onConvertToMarkdown = {
                    val wv = webView ?: return@BrowserBottomBar
                    val srcUrl = wv.url ?: tabs[activeTabIdx].url
                    val pageTitle = wv.title?.takeIf { it.isNotBlank() }
                        ?: tabs[activeTabIdx].title
                    // Pull current HTML via JS bridge — single-line, escape the
                    // outer quotes so the result comes back as a JSON string.
                    wv.evaluateJavascript(
                        "(function(){return document.documentElement.outerHTML;})();"
                    ) { jsonHtml ->
                        // jsonHtml is a JSON-quoted string. Strip outer quotes and
                        // un-escape the standard sequences.
                        val html = decodeJsString(jsonHtml)
                        scope.launch {
                            val res = vm.saveConvertedMarkdown(srcUrl, pageTitle, html)
                            val msg = when (res) {
                                is com.tebogo.markvault.SaveResult.Ok -> "\uD83D\uDCDD Saved: ${res.fileName}"
                                is com.tebogo.markvault.SaveResult.Error -> "\u26A0\uFE0F ${res.message}"
                            }
                            Toast.makeText(ctx, msg, Toast.LENGTH_LONG).show()
                        }
                    }
                }
            )
        }
    ) { pad ->
        Box(Modifier.padding(pad).fillMaxSize()) {
            if (loading) {
                LinearProgressIndicator(
                    progress = { (progress.coerceIn(0, 100)) / 100f },
                    modifier = Modifier.fillMaxWidth().height(2.dp).align(Alignment.TopCenter)
                )
            }
            // Recreate the WebView whenever the active tab changes.
            // The Compose `key` ensures a fresh native view per tab — isolated
            // back/forward history, no shared state. Acceptable trade-off for v1.
            key(tabs[activeTabIdx].id) {
                AndroidView(
                    modifier = Modifier.fillMaxSize(),
                    factory = { context ->
                        @SuppressLint("SetJavaScriptEnabled")
                        SelectionWebView(context).apply {
                            // TASK 5: when user taps "Search in MarkVault" in the text
                            // selection menu, hop to the Search screen with the
                            // selected text pre-filled via the pending-query channel.
                            onSearchInMarkVault = { selectedText ->
                                vm.requestPendingSearch(selectedText)
                                nav.navigate("search") { launchSingleTop = true }
                            }
                            // v4.2 — same menu also has "Search in wol.jw.org" which
                            // navigates the active tab to wol's search page.
                            onSearchInWol = { selectedText ->
                                val target = "https://wol.jw.org/en/wol/s/r1/lp-e?q=" +
                                    java.net.URLEncoder.encode(selectedText, "UTF-8")
                                loadUrl(target)
                            }
                            layoutParams = ViewGroup.LayoutParams(
                                ViewGroup.LayoutParams.MATCH_PARENT,
                                ViewGroup.LayoutParams.MATCH_PARENT
                            )
                            settings.javaScriptEnabled = true
                            settings.domStorageEnabled = true
                            settings.databaseEnabled = true
                            settings.allowFileAccess = false
                            settings.allowContentAccess = true
                            settings.loadsImagesAutomatically = true
                            settings.setSupportZoom(true)
                            settings.builtInZoomControls = true
                            settings.displayZoomControls = false
                            settings.useWideViewPort = true
                            settings.loadWithOverviewMode = true
                            settings.mediaPlaybackRequiresUserGesture = true
                            settings.setSupportMultipleWindows(true)
                            settings.javaScriptCanOpenWindowsAutomatically = true
                            settings.mixedContentMode = WebSettings.MIXED_CONTENT_COMPATIBILITY_MODE
                            settings.userAgentString = settings.userAgentString +
                                " MarkVault/3.7"

                            webViewClient = object : WebViewClient() {
                                override fun onPageStarted(
                                    view: WebView?, url: String?, favicon: android.graphics.Bitmap?
                                ) {
                                    loading = true
                                    url?.let {
                                        vm.updateBrowserTab(vm.webActiveTabIdx, url = it)
                                        if (!addressFocused) addressText = it
                                    }
                                    canGoBack = view?.canGoBack() == true
                                    canGoForward = view?.canGoForward() == true
                                }
                                override fun onPageFinished(view: WebView?, url: String?) {
                                    loading = false
                                    canGoBack = view?.canGoBack() == true
                                    canGoForward = view?.canGoForward() == true
                                    val t = view?.title.orEmpty()
                                    url?.let {
                                        if (!addressFocused) addressText = it
                                        vm.updateBrowserTab(
                                            vm.webActiveTabIdx,
                                            url = it, title = t.ifBlank { it }
                                        )
                                    }
                                    if (!url.isNullOrBlank()) vm.recordWebVisit(url, t.ifBlank { url })
                                    scope.launch { isBookmarked = vm.isBookmarked(url.orEmpty()) }
                                }
                                override fun shouldOverrideUrlLoading(
                                    view: WebView?, request: WebResourceRequest?
                                ): Boolean {
                                    val u = request?.url ?: return false
                                    if (isAllowed(u)) return false
                                    runCatching {
                                        ctx.startActivity(
                                            Intent(Intent.ACTION_VIEW, u)
                                                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                                        )
                                    }
                                    return true
                                }
                            }
                            webChromeClient = object : WebChromeClient() {
                                override fun onCreateWindow(
                                    view: WebView?, isDialog: Boolean, isUserGesture: Boolean, resultMsg: Message?
                                ): Boolean {
                                    if (resultMsg == null) return false
                                    val transport = resultMsg.obj as? WebView.WebViewTransport ?: return false
                                    transport.webView = this@apply
                                    resultMsg.sendToTarget()
                                    return true
                                }
                                override fun onProgressChanged(view: WebView?, newProgress: Int) {
                                    progress = newProgress
                                    loading = newProgress < 100
                                }
                                override fun onReceivedTitle(view: WebView?, title: String?) {
                                    if (!title.isNullOrBlank()) {
                                        vm.updateBrowserTab(vm.webActiveTabIdx, title = title)
                                    }
                                }
                            }
                            val startUrl = tabs[activeTabIdx].url
                            if (isAllowed(Uri.parse(startUrl))) loadUrl(startUrl)
                            else Toast.makeText(context, "Only jw.org is allowed here", Toast.LENGTH_SHORT).show()
                            webView = this
                        }
                    }
                )
            }
        }
    }
}

@Composable
private fun rememberCoroutineScopeSafe() = androidx.compose.runtime.rememberCoroutineScope()

/**
 * The bottom toolbar housing: tab strip, address bar, navigation arrows,
 * reload/stop, bookmark star, find-on-page entry, more menu.
 * Find-on-page bar appears just above the toolbar when activated.
 */
@Composable
private fun BrowserBottomBar(
    tabs: SnapshotStateList<WebTab>,
    activeTabIdx: Int,
    onTabClick: (Int) -> Unit,
    onTabClose: (Int) -> Unit,
    onAddTab: () -> Unit,
    addressText: String,
    onAddressChange: (String) -> Unit,
    onAddressFocus: (Boolean) -> Unit,
    onSubmit: () -> Unit,
    canGoBack: Boolean,
    canGoForward: Boolean,
    onBack: () -> Unit,
    onForward: () -> Unit,
    onReloadOrStop: () -> Unit,
    loading: Boolean,
    isBookmarked: Boolean,
    onToggleBookmark: () -> Unit,
    onOpenFind: () -> Unit,
    menuOpen: Boolean,
    onMenuToggle: (Boolean) -> Unit,
    nav: NavController,
    findOpen: Boolean,
    findQuery: String,
    onFindChange: (String) -> Unit,
    onFindClose: () -> Unit,
    onFindNext: () -> Unit,
    onFindPrev: () -> Unit,
    // TASK 2/3: pluggable actions wired from WebSearchScreen so we can reach the
    // WebView (saveWebArchive) and the VM (saveConvertedMarkdown) without
    // passing those into this private helper.
    onSaveOfflineHtml: () -> Unit = {},
    onConvertToMarkdown: () -> Unit = {}
) {
    Surface(color = MaterialTheme.colorScheme.surfaceVariant, shadowElevation = 8.dp) {
        Column(Modifier.fillMaxWidth()) {
            // Find-on-page row (appears above the toolbar when active)
            if (findOpen) {
                Row(
                    Modifier.fillMaxWidth().padding(horizontal = 8.dp, vertical = 4.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(Icons.Default.Search,
                        contentDescription = "Find",
                        tint = MaterialTheme.colorScheme.onSurfaceVariant)
                    Spacer(Modifier.width(6.dp))
                    OutlinedTextField(
                        value = findQuery,
                        onValueChange = onFindChange,
                        modifier = Modifier.weight(1f).height(46.dp),
                        placeholder = { Text("Find on page\u2026", fontSize = 13.sp) },
                        textStyle = androidx.compose.ui.text.TextStyle(fontSize = 13.sp),
                        singleLine = true,
                        keyboardOptions = KeyboardOptions(imeAction = ImeAction.Search),
                        shape = RoundedCornerShape(20.dp)
                    )
                    IconButton(onClick = onFindPrev) {
                        Icon(Icons.AutoMirrored.Filled.KeyboardArrowLeft, contentDescription = "Previous match")
                    }
                    IconButton(onClick = onFindNext) {
                        Icon(Icons.AutoMirrored.Filled.KeyboardArrowRight, contentDescription = "Next match")
                    }
                    IconButton(onClick = onFindClose) {
                        Icon(Icons.Default.Close, contentDescription = "Close find")
                    }
                }
                HorizontalDivider()
            }

            // Tab strip — horizontally scrollable list of tab chips
            Row(
                Modifier.fillMaxWidth()
                    .horizontalScroll(rememberScrollState())
                    .padding(horizontal = 6.dp, vertical = 4.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                tabs.forEachIndexed { idx, tab ->
                    val active = idx == activeTabIdx
                    Surface(
                        color = if (active) MaterialTheme.colorScheme.primaryContainer
                        else MaterialTheme.colorScheme.surface,
                        shape = RoundedCornerShape(10.dp),
                        border = androidx.compose.foundation.BorderStroke(
                            if (active) 1.5.dp else 1.dp,
                            if (active) MaterialTheme.colorScheme.primary
                            else MaterialTheme.colorScheme.outlineVariant
                        ),
                        modifier = Modifier
                            .padding(horizontal = 3.dp)
                            .clickable { onTabClick(idx) }
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                        ) {
                            Text(
                                tab.title.take(20),
                                fontSize = 12.sp,
                                fontWeight = if (active) FontWeight.SemiBold else FontWeight.Normal,
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis,
                                color = if (active) MaterialTheme.colorScheme.onPrimaryContainer
                                else MaterialTheme.colorScheme.onSurface
                            )
                            Spacer(Modifier.width(4.dp))
                            IconButton(
                                onClick = { onTabClose(idx) },
                                modifier = Modifier.size(20.dp)
                            ) {
                                Icon(Icons.Default.Close,
                                    contentDescription = "Close tab",
                                    modifier = Modifier.size(14.dp))
                            }
                        }
                    }
                }
                IconButton(onClick = onAddTab, modifier = Modifier.size(32.dp)) {
                    Icon(Icons.Default.Add, contentDescription = "New tab")
                }
            }
            HorizontalDivider()
            // Address bar row
            Row(
                Modifier.fillMaxWidth().padding(horizontal = 6.dp, vertical = 4.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                IconButton(onClick = onBack, enabled = canGoBack,
                    modifier = Modifier.size(36.dp)) {
                    Icon(Icons.AutoMirrored.Filled.KeyboardArrowLeft,
                        contentDescription = "Back",
                        tint = if (canGoBack) MaterialTheme.colorScheme.onSurface
                        else MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.4f))
                }
                IconButton(onClick = onForward, enabled = canGoForward,
                    modifier = Modifier.size(36.dp)) {
                    Icon(Icons.AutoMirrored.Filled.KeyboardArrowRight,
                        contentDescription = "Forward",
                        tint = if (canGoForward) MaterialTheme.colorScheme.onSurface
                        else MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.4f))
                }
                OutlinedTextField(
                    value = addressText,
                    onValueChange = onAddressChange,
                    singleLine = true,
                    modifier = Modifier.weight(1f).height(56.dp),
                    placeholder = { Text("Enter URL or search\u2026", fontSize = 14.sp) },
                    textStyle = androidx.compose.ui.text.TextStyle(
                        fontSize = 14.sp, fontWeight = FontWeight.Medium
                    ),
                    keyboardOptions = KeyboardOptions(imeAction = ImeAction.Go),
                    keyboardActions = KeyboardActions(onGo = { onSubmit() }),
                    shape = RoundedCornerShape(24.dp),
                    colors = TextFieldDefaults.colors(
                        focusedContainerColor = MaterialTheme.colorScheme.surface,
                        unfocusedContainerColor = MaterialTheme.colorScheme.surface
                    )
                )
                IconButton(onClick = onReloadOrStop, modifier = Modifier.size(36.dp)) {
                    Icon(
                        if (loading) Icons.Default.Close else Icons.Default.Refresh,
                        contentDescription = if (loading) "Stop" else "Reload"
                    )
                }
            }
            // Action row: bookmark, find, history, menu
            Row(
                Modifier.fillMaxWidth().padding(horizontal = 4.dp, vertical = 2.dp),
                horizontalArrangement = Arrangement.SpaceEvenly,
                verticalAlignment = Alignment.CenterVertically
            ) {
                IconButton(onClick = onToggleBookmark) {
                    // Unicode star glyphs — ☆ outline / ★ filled. Avoids needing
                    // the material-icons-extended dependency (StarBorder isn't
                    // in the core icon set).
                    Text(
                        if (isBookmarked) "\u2605" else "\u2606",
                        fontSize = 22.sp,
                        color = if (isBookmarked) Color(0xFFFFC107)
                        else MaterialTheme.colorScheme.onSurface
                    )
                }
                IconButton(onClick = onOpenFind) {
                    Icon(Icons.Default.Search, contentDescription = "Find on page")
                }
                IconButton(onClick = { nav.navigate("webBookmarks") }) {
                    Text("\uD83D\uDD16", fontSize = 18.sp)
                }
                IconButton(onClick = { nav.navigate("webHistory") }) {
                    Text("\uD83D\uDD52", fontSize = 18.sp)
                }
                Box {
                    IconButton(onClick = { onMenuToggle(true) }) {
                        Icon(Icons.Default.MoreVert, contentDescription = "More")
                    }
                    DropdownMenu(expanded = menuOpen, onDismissRequest = { onMenuToggle(false) }) {
                        DropdownMenuItem(
                            text = { Text("\uD83C\uDFE0 jw.org home") },
                            onClick = { onMenuToggle(false); onAddressChange("https://www.jw.org/en/"); onSubmit() }
                        )
                        DropdownMenuItem(
                            text = { Text("\uD83D\uDD16 Bookmarks") },
                            onClick = { onMenuToggle(false); nav.navigate("webBookmarks") }
                        )
                        DropdownMenuItem(
                            text = { Text("\uD83D\uDD52 Web history") },
                            onClick = { onMenuToggle(false); nav.navigate("webHistory") }
                        )
                        DropdownMenuItem(
                            text = { Text("\uD83D\uDCDC PDF history") },
                            onClick = { onMenuToggle(false); nav.navigate("pdfHistory") }
                        )
                        HorizontalDivider()
                        // TASK 2: archive current page as offline HTML
                        DropdownMenuItem(
                            text = { Text("\uD83D\uDCBE Save as Offline HTML") },
                            onClick = { onMenuToggle(false); onSaveOfflineHtml() }
                        )
                        // TASK 3: convert current page into a markdown note
                        DropdownMenuItem(
                            text = { Text("\uD83D\uDCDD Convert to Markdown") },
                            onClick = { onMenuToggle(false); onConvertToMarkdown() }
                        )
                        HorizontalDivider()
                        DropdownMenuItem(
                            text = { Text("\u2699\uFE0F Settings") },
                            onClick = { onMenuToggle(false); nav.navigate("settings") }
                        )
                    }
                }
            }
        }
    }
}


/**
 * Decode a JSON-encoded string returned by WebView.evaluateJavascript.
 * The callback receives a value like  `"<html>\u003E</html>"`  — outer quotes
 * plus standard JSON escapes. This helper strips the quotes and un-escapes
 * `\\` `\"` `\n` `\r` `\t` and `\uXXXX` so the caller gets the raw payload.
 */
private fun decodeJsString(jsonValue: String?): String {
    if (jsonValue.isNullOrBlank() || jsonValue == "null") return ""
    var s = jsonValue.trim()
    if (s.startsWith("\"") && s.endsWith("\"")) s = s.substring(1, s.length - 1)
    val sb = StringBuilder(s.length)
    var i = 0
    while (i < s.length) {
        val c = s[i]
        if (c == '\\' && i + 1 < s.length) {
            when (val n = s[i + 1]) {
                '"', '\\', '/' -> { sb.append(n); i += 2 }
                'n' -> { sb.append('\n'); i += 2 }
                'r' -> { sb.append('\r'); i += 2 }
                't' -> { sb.append('\t'); i += 2 }
                'b' -> { sb.append('\b'); i += 2 }
                'f' -> { sb.append('\u000C'); i += 2 }
                'u' -> {
                    if (i + 5 < s.length) {
                        val hex = s.substring(i + 2, i + 6)
                        val cp = runCatching { hex.toInt(16) }.getOrNull()
                        if (cp != null) sb.append(cp.toChar()) else sb.append(n)
                        i += 6
                    } else { sb.append(n); i += 2 }
                }
                else -> { sb.append(n); i += 2 }
            }
        } else {
            sb.append(c); i++
        }
    }
    return sb.toString()
}
