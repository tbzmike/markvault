package com.tebogo.markvault.ui

import android.annotation.SuppressLint
import android.content.Intent
import android.net.Uri
import android.os.Message
import android.view.ViewGroup
import android.webkit.WebChromeClient
import android.webkit.WebResourceRequest
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.Toast
import androidx.activity.compose.BackHandler
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.filled.KeyboardArrowLeft
import androidx.compose.material.icons.automirrored.filled.KeyboardArrowRight
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.MoreVert
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Star
import androidx.compose.material.icons.filled.StarBorder
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextFieldDefaults
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.key
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.runtime.snapshots.SnapshotStateList
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalSoftwareKeyboardController
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.navigation.NavController
import com.tebogo.markvault.AppViewModel
import kotlinx.coroutines.launch

/**
 * Hosts allowed by the in-app browser. www.jw.org IS in the list — earlier
 * black-screen reports turned out to be MIXED_CONTENT_NEVER_ALLOW, not host
 * filtering. With COMPATIBILITY_MODE + this list the Bible viewer and
 * Watchtower Library both load.
 */
private val ALLOWED_HOSTS = setOf(
    "jw.org", "www.jw.org", "m.jw.org",
    "wol.jw.org", "wol.jw.org.za", "tv.jw.org",
    "b.jw-cdn.org", "assetsnffrgf-a.akamaihd.net",
    "data.jw-api.org", "apps.jw.org"
)

private fun isAllowed(uri: Uri?): Boolean {
    val host = uri?.host?.lowercase() ?: return false
    return ALLOWED_HOSTS.any { host == it || host.endsWith(".$it") } ||
        host.endsWith(".jw.org") || host.endsWith(".jw-cdn.org") || host == "jw.org"
}

/**
 * State for one open tab. Each tab keeps its own URL + title; switching tabs
 * recreates the WebView (via Compose `key`) so each tab has an isolated history
 * stack. Trade-off: in-page state (scroll, form input) doesn't persist across
 * tab switches — acceptable for a first-cut multi-tab implementation.
 */
private data class WebTab(val id: Long, var url: String, var title: String)

/**
 * Multi-tab in-app browser with bottom-anchored toolbar.
 *
 * Layout:
 *   ┌──────────────────────────┐
 *   │   (minimal top bar)      │  ← only Home/back to keep chrome thumb-reachable
 *   ├──────────────────────────┤
 *   │                          │
 *   │       WebView area       │  ← the active tab's content
 *   │                          │
 *   ├──────────────────────────┤
 *   │   tab strip (←  → +)     │
 *   │   address bar + nav      │
 *   │   action row             │  ← everything else lives at the bottom
 *   └──────────────────────────┘
 */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun WebSearchScreen(vm: AppViewModel, nav: NavController, url: String, label: String) {
    val ctx = LocalContext.current
    val keyboard = LocalSoftwareKeyboardController.current
    val scope = rememberCoroutineScopeSafe()

    // Multi-tab state — start with the requested URL as the first (and only) tab.
    val tabs: SnapshotStateList<WebTab> = remember {
        mutableStateListOf(WebTab(System.currentTimeMillis(), url, label))
    }
    var activeTabIdx by remember { mutableStateOf(0) }

    // Per-tab state lives in the Compose `key` block — re-created on tab switch.
    // We track UI state at this level so the bottom bar reacts to the active tab.
    var webView by remember { mutableStateOf<WebView?>(null) }
    var loading by remember { mutableStateOf(true) }
    var progress by remember { mutableStateOf(0) }
    var addressText by remember(activeTabIdx) { mutableStateOf(tabs[activeTabIdx].url) }
    var addressFocused by remember { mutableStateOf(false) }
    var canGoBack by remember { mutableStateOf(false) }
    var canGoForward by remember { mutableStateOf(false) }

    // Find-on-page state — search field opens above the bottom toolbar.
    var findOpen by remember { mutableStateOf(false) }
    var findQuery by remember { mutableStateOf("") }

    // Bookmark state for the active URL
    var isBookmarked by remember { mutableStateOf(false) }
    LaunchedEffect(addressText) {
        isBookmarked = if (addressText.isBlank()) false
        else vm.isBookmarked(addressText)
    }

    // Menu
    var menuOpen by remember { mutableStateOf(false) }

    fun loadUrlFromAddress(raw: String) {
        val cleaned = raw.trim()
        if (cleaned.isEmpty()) return
        val target = when {
            cleaned.startsWith("http://") || cleaned.startsWith("https://") -> cleaned
            cleaned.contains(".") -> "https://$cleaned"
            else -> "https://www.jw.org/en/search/?q=" + Uri.encode(cleaned)
        }
        if (!isAllowed(Uri.parse(target))) {
            Toast.makeText(ctx, "Only jw.org family of sites are allowed", Toast.LENGTH_SHORT).show()
            return
        }
        keyboard?.hide()
        webView?.loadUrl(target)
        addressFocused = false
    }

    fun addNewTab(initialUrl: String = "https://www.jw.org/en/") {
        tabs.add(WebTab(System.currentTimeMillis(), initialUrl, "New tab"))
        activeTabIdx = tabs.size - 1
    }

    fun closeTab(idx: Int) {
        if (tabs.size == 1) {
            // Last tab closing — pop back to whatever opened the browser
            nav.popBackStack(); return
        }
        tabs.removeAt(idx)
        if (activeTabIdx >= tabs.size) activeTabIdx = tabs.size - 1
        else if (activeTabIdx > idx) activeTabIdx--
    }

    BackHandler(enabled = true) {
        val wv = webView
        if (wv != null && wv.canGoBack()) wv.goBack() else nav.popBackStack()
    }

    Scaffold(
        // Minimal top bar — just home + close-browser
        topBar = {
            TopAppBar(
                title = {
                    Text(
                        "\uD83C\uDF10 ${tabs[activeTabIdx].title.take(40)}",
                        maxLines = 1, overflow = TextOverflow.Ellipsis,
                        fontSize = 13.sp
                    )
                },
                navigationIcon = {
                    IconButton(onClick = { nav.popBackStack() }) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Close browser")
                    }
                },
                actions = { HomeButton(nav) }
            )
        },
        // Bottom-anchored toolbar — tab strip, address bar, action buttons
        bottomBar = {
            BrowserBottomBar(
                tabs = tabs,
                activeTabIdx = activeTabIdx,
                onTabClick = { activeTabIdx = it },
                onTabClose = ::closeTab,
                onAddTab = { addNewTab() },
                addressText = addressText,
                onAddressChange = { addressText = it },
                onAddressFocus = { addressFocused = it },
                onSubmit = { loadUrlFromAddress(addressText) },
                canGoBack = canGoBack,
                canGoForward = canGoForward,
                onBack = { webView?.goBack() },
                onForward = { webView?.goForward() },
                onReloadOrStop = { if (loading) webView?.stopLoading() else webView?.reload() },
                loading = loading,
                isBookmarked = isBookmarked,
                onToggleBookmark = {
                    val u = webView?.url ?: addressText
                    val t = webView?.title ?: tabs[activeTabIdx].title
                    if (isBookmarked) vm.removeBookmark(u) else vm.addBookmark(u, t)
                    isBookmarked = !isBookmarked
                },
                onOpenFind = { findOpen = true; findQuery = "" },
                menuOpen = menuOpen,
                onMenuToggle = { menuOpen = it },
                nav = nav,
                findOpen = findOpen,
                findQuery = findQuery,
                onFindChange = { findQuery = it; webView?.findAllAsync(it) },
                onFindClose = { findOpen = false; webView?.clearMatches() },
                onFindNext = { webView?.findNext(true) },
                onFindPrev = { webView?.findNext(false) }
            )
        }
    ) { pad ->
        Box(Modifier.padding(pad).fillMaxSize()) {
            if (loading) {
                LinearProgressIndicator(
                    progress = { (progress.coerceIn(0, 100)) / 100f },
                    modifier = Modifier.fillMaxWidth().height(2.dp).align(Alignment.TopCenter)
                )
            }
            // Recreate the WebView whenever the active tab changes.
            // The Compose `key` ensures a fresh native view per tab — isolated
            // back/forward history, no shared state. Acceptable trade-off for v1.
            key(tabs[activeTabIdx].id) {
                AndroidView(
                    modifier = Modifier.fillMaxSize(),
                    factory = { context ->
                        @SuppressLint("SetJavaScriptEnabled")
                        WebView(context).apply {
                            layoutParams = ViewGroup.LayoutParams(
                                ViewGroup.LayoutParams.MATCH_PARENT,
                                ViewGroup.LayoutParams.MATCH_PARENT
                            )
                            settings.javaScriptEnabled = true
                            settings.domStorageEnabled = true
                            settings.databaseEnabled = true
                            settings.allowFileAccess = false
                            settings.allowContentAccess = true
                            settings.loadsImagesAutomatically = true
                            settings.setSupportZoom(true)
                            settings.builtInZoomControls = true
                            settings.displayZoomControls = false
                            settings.useWideViewPort = true
                            settings.loadWithOverviewMode = true
                            settings.mediaPlaybackRequiresUserGesture = true
                            settings.setSupportMultipleWindows(true)
                            settings.javaScriptCanOpenWindowsAutomatically = true
                            settings.mixedContentMode = WebSettings.MIXED_CONTENT_COMPATIBILITY_MODE
                            settings.userAgentString = settings.userAgentString +
                                " MarkVault/3.7"

                            webViewClient = object : WebViewClient() {
                                override fun onPageStarted(
                                    view: WebView?, url: String?, favicon: android.graphics.Bitmap?
                                ) {
                                    loading = true
                                    url?.let {
                                        tabs[activeTabIdx] = tabs[activeTabIdx].copy(url = it)
                                        if (!addressFocused) addressText = it
                                    }
                                    canGoBack = view?.canGoBack() == true
                                    canGoForward = view?.canGoForward() == true
                                }
                                override fun onPageFinished(view: WebView?, url: String?) {
                                    loading = false
                                    canGoBack = view?.canGoBack() == true
                                    canGoForward = view?.canGoForward() == true
                                    val t = view?.title.orEmpty()
                                    url?.let {
                                        if (!addressFocused) addressText = it
                                        tabs[activeTabIdx] = tabs[activeTabIdx].copy(
                                            url = it, title = t.ifBlank { it }
                                        )
                                    }
                                    if (!url.isNullOrBlank()) vm.recordWebVisit(url, t.ifBlank { url })
                                    scope.launch { isBookmarked = vm.isBookmarked(url.orEmpty()) }
                                }
                                override fun shouldOverrideUrlLoading(
                                    view: WebView?, request: WebResourceRequest?
                                ): Boolean {
                                    val u = request?.url ?: return false
                                    if (isAllowed(u)) return false
                                    runCatching {
                                        ctx.startActivity(
                                            Intent(Intent.ACTION_VIEW, u)
                                                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                                        )
                                    }
                                    return true
                                }
                            }
                            webChromeClient = object : WebChromeClient() {
                                override fun onCreateWindow(
                                    view: WebView?, isDialog: Boolean, isUserGesture: Boolean, resultMsg: Message?
                                ): Boolean {
                                    if (resultMsg == null) return false
                                    val transport = resultMsg.obj as? WebView.WebViewTransport ?: return false
                                    transport.webView = this@apply
                                    resultMsg.sendToTarget()
                                    return true
                                }
                                override fun onProgressChanged(view: WebView?, newProgress: Int) {
                                    progress = newProgress
                                    loading = newProgress < 100
                                }
                                override fun onReceivedTitle(view: WebView?, title: String?) {
                                    if (!title.isNullOrBlank()) {
                                        tabs[activeTabIdx] = tabs[activeTabIdx].copy(title = title)
                                    }
                                }
                            }
                            val startUrl = tabs[activeTabIdx].url
                            if (isAllowed(Uri.parse(startUrl))) loadUrl(startUrl)
                            else Toast.makeText(context, "Only jw.org is allowed here", Toast.LENGTH_SHORT).show()
                            webView = this
                        }
                    }
                )
            }
        }
    }
}

@Composable
private fun rememberCoroutineScopeSafe() = androidx.compose.runtime.rememberCoroutineScope()

/**
 * The bottom toolbar housing: tab strip, address bar, navigation arrows,
 * reload/stop, bookmark star, find-on-page entry, more menu.
 * Find-on-page bar appears just above the toolbar when activated.
 */
@Composable
private fun BrowserBottomBar(
    tabs: SnapshotStateList<WebTab>,
    activeTabIdx: Int,
    onTabClick: (Int) -> Unit,
    onTabClose: (Int) -> Unit,
    onAddTab: () -> Unit,
    addressText: String,
    onAddressChange: (String) -> Unit,
    onAddressFocus: (Boolean) -> Unit,
    onSubmit: () -> Unit,
    canGoBack: Boolean,
    canGoForward: Boolean,
    onBack: () -> Unit,
    onForward: () -> Unit,
    onReloadOrStop: () -> Unit,
    loading: Boolean,
    isBookmarked: Boolean,
    onToggleBookmark: () -> Unit,
    onOpenFind: () -> Unit,
    menuOpen: Boolean,
    onMenuToggle: (Boolean) -> Unit,
    nav: NavController,
    findOpen: Boolean,
    findQuery: String,
    onFindChange: (String) -> Unit,
    onFindClose: () -> Unit,
    onFindNext: () -> Unit,
    onFindPrev: () -> Unit
) {
    Surface(color = MaterialTheme.colorScheme.surfaceVariant, shadowElevation = 8.dp) {
        Column(Modifier.fillMaxWidth()) {
            // Find-on-page row (appears above the toolbar when active)
            if (findOpen) {
                Row(
                    Modifier.fillMaxWidth().padding(horizontal = 8.dp, vertical = 4.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(Icons.Default.Search,
                        contentDescription = "Find",
                        tint = MaterialTheme.colorScheme.onSurfaceVariant)
                    Spacer(Modifier.width(6.dp))
                    OutlinedTextField(
                        value = findQuery,
                        onValueChange = onFindChange,
                        modifier = Modifier.weight(1f).height(46.dp),
                        placeholder = { Text("Find on page\u2026", fontSize = 13.sp) },
                        textStyle = androidx.compose.ui.text.TextStyle(fontSize = 13.sp),
                        singleLine = true,
                        keyboardOptions = KeyboardOptions(imeAction = ImeAction.Search),
                        shape = RoundedCornerShape(20.dp)
                    )
                    IconButton(onClick = onFindPrev) {
                        Icon(Icons.AutoMirrored.Filled.KeyboardArrowLeft, contentDescription = "Previous match")
                    }
                    IconButton(onClick = onFindNext) {
                        Icon(Icons.AutoMirrored.Filled.KeyboardArrowRight, contentDescription = "Next match")
                    }
                    IconButton(onClick = onFindClose) {
                        Icon(Icons.Default.Close, contentDescription = "Close find")
                    }
                }
                HorizontalDivider()
            }

            // Tab strip — horizontally scrollable list of tab chips
            Row(
                Modifier.fillMaxWidth()
                    .horizontalScroll(rememberScrollState())
                    .padding(horizontal = 6.dp, vertical = 4.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                tabs.forEachIndexed { idx, tab ->
                    val active = idx == activeTabIdx
                    Surface(
                        color = if (active) MaterialTheme.colorScheme.primaryContainer
                        else MaterialTheme.colorScheme.surface,
                        shape = RoundedCornerShape(10.dp),
                        border = androidx.compose.foundation.BorderStroke(
                            if (active) 1.5.dp else 1.dp,
                            if (active) MaterialTheme.colorScheme.primary
                            else MaterialTheme.colorScheme.outlineVariant
                        ),
                        modifier = Modifier
                            .padding(horizontal = 3.dp)
                            .clickable { onTabClick(idx) }
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                        ) {
                            Text(
                                tab.title.take(20),
                                fontSize = 12.sp,
                                fontWeight = if (active) FontWeight.SemiBold else FontWeight.Normal,
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis,
                                color = if (active) MaterialTheme.colorScheme.onPrimaryContainer
                                else MaterialTheme.colorScheme.onSurface
                            )
                            Spacer(Modifier.width(4.dp))
                            IconButton(
                                onClick = { onTabClose(idx) },
                                modifier = Modifier.size(20.dp)
                            ) {
                                Icon(Icons.Default.Close,
                                    contentDescription = "Close tab",
                                    modifier = Modifier.size(14.dp))
                            }
                        }
                    }
                }
                IconButton(onClick = onAddTab, modifier = Modifier.size(32.dp)) {
                    Icon(Icons.Default.Add, contentDescription = "New tab")
                }
            }
            HorizontalDivider()
            // Address bar row
            Row(
                Modifier.fillMaxWidth().padding(horizontal = 6.dp, vertical = 4.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                IconButton(onClick = onBack, enabled = canGoBack,
                    modifier = Modifier.size(36.dp)) {
                    Icon(Icons.AutoMirrored.Filled.KeyboardArrowLeft,
                        contentDescription = "Back",
                        tint = if (canGoBack) MaterialTheme.colorScheme.onSurface
                        else MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.4f))
                }
                IconButton(onClick = onForward, enabled = canGoForward,
                    modifier = Modifier.size(36.dp)) {
                    Icon(Icons.AutoMirrored.Filled.KeyboardArrowRight,
                        contentDescription = "Forward",
                        tint = if (canGoForward) MaterialTheme.colorScheme.onSurface
                        else MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.4f))
                }
                OutlinedTextField(
                    value = addressText,
                    onValueChange = onAddressChange,
                    singleLine = true,
                    modifier = Modifier.weight(1f).height(56.dp),
                    placeholder = { Text("Enter URL or search\u2026", fontSize = 14.sp) },
                    textStyle = androidx.compose.ui.text.TextStyle(
                        fontSize = 14.sp, fontWeight = FontWeight.Medium
                    ),
                    keyboardOptions = KeyboardOptions(imeAction = ImeAction.Go),
                    keyboardActions = KeyboardActions(onGo = { onSubmit() }),
                    shape = RoundedCornerShape(24.dp),
                    colors = TextFieldDefaults.colors(
                        focusedContainerColor = MaterialTheme.colorScheme.surface,
                        unfocusedContainerColor = MaterialTheme.colorScheme.surface
                    )
                )
                IconButton(onClick = onReloadOrStop, modifier = Modifier.size(36.dp)) {
                    Icon(
                        if (loading) Icons.Default.Close else Icons.Default.Refresh,
                        contentDescription = if (loading) "Stop" else "Reload"
                    )
                }
            }
            // Action row: bookmark, find, history, menu
            Row(
                Modifier.fillMaxWidth().padding(horizontal = 4.dp, vertical = 2.dp),
                horizontalArrangement = Arrangement.SpaceEvenly,
                verticalAlignment = Alignment.CenterVertically
            ) {
                IconButton(onClick = onToggleBookmark) {
                    Icon(
                        if (isBookmarked) Icons.Default.Star else Icons.Default.StarBorder,
                        contentDescription = if (isBookmarked) "Remove bookmark" else "Bookmark",
                        tint = if (isBookmarked) Color(0xFFFFC107)
                        else MaterialTheme.colorScheme.onSurface
                    )
                }
                IconButton(onClick = onOpenFind) {
                    Icon(Icons.Default.Search, contentDescription = "Find on page")
                }
                IconButton(onClick = { nav.navigate("webBookmarks") }) {
                    Text("\uD83D\uDD16", fontSize = 18.sp)
                }
                IconButton(onClick = { nav.navigate("webHistory") }) {
                    Text("\uD83D\uDD52", fontSize = 18.sp)
                }
                Box {
                    IconButton(onClick = { onMenuToggle(true) }) {
                        Icon(Icons.Default.MoreVert, contentDescription = "More")
                    }
                    DropdownMenu(expanded = menuOpen, onDismissRequest = { onMenuToggle(false) }) {
                        DropdownMenuItem(
                            text = { Text("\uD83C\uDFE0 jw.org home") },
                            onClick = { onMenuToggle(false); onAddressChange("https://www.jw.org/en/"); onSubmit() }
                        )
                        DropdownMenuItem(
                            text = { Text("\uD83D\uDD16 Bookmarks") },
                            onClick = { onMenuToggle(false); nav.navigate("webBookmarks") }
                        )
                        DropdownMenuItem(
                            text = { Text("\uD83D\uDD52 Web history") },
                            onClick = { onMenuToggle(false); nav.navigate("webHistory") }
                        )
                        DropdownMenuItem(
                            text = { Text("\uD83D\uDCDC PDF history") },
                            onClick = { onMenuToggle(false); nav.navigate("pdfHistory") }
                        )
                        HorizontalDivider()
                        DropdownMenuItem(
                            text = { Text("\u2699\uFE0F Settings") },
                            onClick = { onMenuToggle(false); nav.navigate("settings") }
                        )
                    }
                }
            }
        }
    }
}
