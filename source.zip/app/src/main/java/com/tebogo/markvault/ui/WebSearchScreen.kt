package com.tebogo.markvault.ui

import android.annotation.SuppressLint
import android.content.Intent
import android.net.Uri
import android.os.Message
import android.view.ViewGroup
import android.webkit.WebChromeClient
import android.webkit.WebResourceRequest
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.Toast
import androidx.activity.compose.BackHandler
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.filled.KeyboardArrowLeft
import androidx.compose.material.icons.automirrored.filled.KeyboardArrowRight
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.MoreVert
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextFieldDefaults
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalSoftwareKeyboardController
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.navigation.NavController
import com.tebogo.markvault.AppViewModel

/**
 * Hosts the only domains we'll let the in-app browser navigate to. www.jw.org IS
 * explicitly included — previous reports of "blank screen on www.jw.org" were
 * caused by MIXED_CONTENT_NEVER_ALLOW blocking required resources, not by host
 * filtering. With COMPATIBILITY_MODE plus the broader host list below, the
 * Bible viewer and Watchtower Library both load correctly.
 */
private val ALLOWED_HOSTS = setOf(
    "jw.org", "www.jw.org", "m.jw.org",
    "wol.jw.org", "wol.jw.org.za", "tv.jw.org",
    "b.jw-cdn.org", "assetsnffrgf-a.akamaihd.net",
    "data.jw-api.org", "apps.jw.org"
)

private fun isAllowed(uri: Uri?): Boolean {
    val host = uri?.host?.lowercase() ?: return false
    return ALLOWED_HOSTS.any { host == it || host.endsWith(".$it") } ||
        host.endsWith(".jw.org") || host.endsWith(".jw-cdn.org") || host == "jw.org"
}

/**
 * In-app browser screen with address bar, navigation controls, and history.
 * History is logged via [AppViewModel.recordWebVisit] every time a page finishes loading.
 *
 * Mixed-content note: jw.org's Bible viewer requires
 * [WebSettings.MIXED_CONTENT_COMPATIBILITY_MODE] to load its CSS / fonts —
 * NEVER_ALLOW was causing the "black screen on www.jw.org" symptom.
 */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun WebSearchScreen(vm: AppViewModel, nav: NavController, url: String, label: String) {
    val ctx = LocalContext.current
    val keyboard = LocalSoftwareKeyboardController.current
    var webView by remember { mutableStateOf<WebView?>(null) }
    var loading by remember { mutableStateOf(true) }
    var progress by remember { mutableStateOf(0) }
    var pageTitle by remember { mutableStateOf(label) }
    var currentUrl by remember { mutableStateOf(url) }
    var addressText by remember { mutableStateOf(url) }
    var addressFocused by remember { mutableStateOf(false) }
    var canGoBack by remember { mutableStateOf(false) }
    var canGoForward by remember { mutableStateOf(false) }
    var menuOpen by remember { mutableStateOf(false) }

    fun loadUrlFromAddress(raw: String) {
        val cleaned = raw.trim()
        if (cleaned.isEmpty()) return
        val target = when {
            cleaned.startsWith("http://") || cleaned.startsWith("https://") -> cleaned
            cleaned.contains(".") -> "https://$cleaned"
            else -> {
                // Treat as search query — route through jw.org's own site search
                "https://www.jw.org/en/search/?q=" +
                    Uri.encode(cleaned)
            }
        }
        if (!isAllowed(Uri.parse(target))) {
            Toast.makeText(ctx, "Only jw.org family of sites are allowed", Toast.LENGTH_SHORT).show()
            return
        }
        keyboard?.hide()
        webView?.loadUrl(target)
        addressFocused = false
    }

    BackHandler(enabled = canGoBack) {
        val wv = webView
        if (wv != null && wv.canGoBack()) wv.goBack() else nav.popBackStack()
    }

    Scaffold(
        topBar = {
            Column {
                TopAppBar(
                    title = {
                        Text(
                            pageTitle, maxLines = 1, overflow = TextOverflow.Ellipsis,
                            fontSize = 15.sp, fontWeight = FontWeight.SemiBold
                        )
                    },
                    navigationIcon = {
                        IconButton(onClick = { nav.popBackStack() }) {
                            Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Close")
                        }
                    },
                    actions = {
                        IconButton(onClick = { nav.navigate("webHistory") }) {
                            Text("\uD83D\uDD52", fontSize = 18.sp)
                        }
                        Box {
                            IconButton(onClick = { menuOpen = true }) {
                                Icon(Icons.Default.MoreVert, contentDescription = "More")
                            }
                            DropdownMenu(expanded = menuOpen, onDismissRequest = { menuOpen = false }) {
                                DropdownMenuItem(
                                    text = { Text("\uD83C\uDFE0 Home (jw.org)") },
                                    onClick = {
                                        menuOpen = false
                                        webView?.loadUrl("https://www.jw.org/en/")
                                    }
                                )
                                DropdownMenuItem(
                                    text = { Text("\uD83D\uDD52 Web history") },
                                    onClick = { menuOpen = false; nav.navigate("webHistory") }
                                )
                                DropdownMenuItem(
                                    text = { Text("\uD83D\uDCDC PDF history") },
                                    onClick = { menuOpen = false; nav.navigate("pdfHistory") }
                                )
                                HorizontalDivider()
                                DropdownMenuItem(
                                    text = { Text("\u2699\uFE0F Settings") },
                                    onClick = { menuOpen = false; nav.navigate("settings") }
                                )
                                DropdownMenuItem(
                                    text = { Text("\u274C Close browser") },
                                    onClick = { menuOpen = false; nav.popBackStack() }
                                )
                            }
                        }
                    }
                )
                // Address bar + nav controls
                Surface(color = MaterialTheme.colorScheme.surfaceVariant) {
                    Row(
                        Modifier.fillMaxWidth().padding(horizontal = 6.dp, vertical = 6.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        IconButton(
                            onClick = { webView?.goBack() },
                            enabled = canGoBack,
                            modifier = Modifier.size(36.dp)
                        ) {
                            Icon(Icons.AutoMirrored.Filled.KeyboardArrowLeft,
                                contentDescription = "Back",
                                tint = if (canGoBack) MaterialTheme.colorScheme.onSurface
                                else MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.4f))
                        }
                        IconButton(
                            onClick = { webView?.goForward() },
                            enabled = canGoForward,
                            modifier = Modifier.size(36.dp)
                        ) {
                            Icon(Icons.AutoMirrored.Filled.KeyboardArrowRight,
                                contentDescription = "Forward",
                                tint = if (canGoForward) MaterialTheme.colorScheme.onSurface
                                else MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.4f))
                        }
                        OutlinedTextField(
                            value = addressText,
                            onValueChange = { addressText = it },
                            singleLine = true,
                            modifier = Modifier.weight(1f).height(46.dp),
                            placeholder = { Text("Enter URL or search\u2026", fontSize = 12.sp) },
                            textStyle = androidx.compose.ui.text.TextStyle(fontSize = 13.sp),
                            keyboardOptions = KeyboardOptions(imeAction = ImeAction.Go),
                            keyboardActions = androidx.compose.foundation.text.KeyboardActions(
                                onGo = { loadUrlFromAddress(addressText) }
                            ),
                            shape = RoundedCornerShape(22.dp),
                            colors = TextFieldDefaults.colors(
                                focusedContainerColor = MaterialTheme.colorScheme.surface,
                                unfocusedContainerColor = MaterialTheme.colorScheme.surface
                            )
                        )
                        IconButton(
                            onClick = {
                                if (loading) webView?.stopLoading() else webView?.reload()
                            },
                            modifier = Modifier.size(36.dp)
                        ) {
                            Icon(
                                if (loading) Icons.Default.Close else Icons.Default.Refresh,
                                contentDescription = if (loading) "Stop" else "Reload"
                            )
                        }
                    }
                }
                if (loading) {
                    LinearProgressIndicator(
                        progress = { (progress.coerceIn(0, 100)) / 100f },
                        modifier = Modifier.fillMaxWidth().height(2.dp)
                    )
                }
            }
        }
    ) { pad ->
        AndroidView(
            modifier = Modifier.padding(pad).fillMaxSize(),
            factory = { context ->
                @SuppressLint("SetJavaScriptEnabled")
                WebView(context).apply {
                    layoutParams = ViewGroup.LayoutParams(
                        ViewGroup.LayoutParams.MATCH_PARENT,
                        ViewGroup.LayoutParams.MATCH_PARENT
                    )
                    settings.javaScriptEnabled = true
                    settings.domStorageEnabled = true
                    settings.databaseEnabled = true
                    settings.allowFileAccess = false
                    settings.allowContentAccess = true
                    settings.loadsImagesAutomatically = true
                    settings.setSupportZoom(true)
                    settings.builtInZoomControls = true
                    settings.displayZoomControls = false
                    settings.useWideViewPort = true
                    settings.loadWithOverviewMode = true
                    settings.mediaPlaybackRequiresUserGesture = true
                    settings.setSupportMultipleWindows(true)
                    settings.javaScriptCanOpenWindowsAutomatically = true
                    // FIX: NEVER_ALLOW was blocking jw.org's required HTTPS-loaded
                    // fonts/images that come from sub-CDNs and triggering the black
                    // screen. COMPATIBILITY mode lets the page render while still
                    // upgrading insecure requests where possible.
                    settings.mixedContentMode = WebSettings.MIXED_CONTENT_COMPATIBILITY_MODE
                    // Use a desktop-ish UA suffix so jw.org's Bible viewer serves
                    // the full layout instead of the minimal mobile fallback
                    // (which is sometimes the cause of "loaded but invisible").
                    settings.userAgentString = settings.userAgentString +
                        " MarkVault/3.3"

                    webViewClient = object : WebViewClient() {
                        override fun onPageStarted(
                            view: WebView?, url: String?, favicon: android.graphics.Bitmap?
                        ) {
                            loading = true
                            url?.let { currentUrl = it; if (!addressFocused) addressText = it }
                            canGoBack = view?.canGoBack() == true
                            canGoForward = view?.canGoForward() == true
                        }
                        override fun onPageFinished(view: WebView?, url: String?) {
                            loading = false
                            canGoBack = view?.canGoBack() == true
                            canGoForward = view?.canGoForward() == true
                            val t = view?.title
                            if (!t.isNullOrBlank()) pageTitle = t
                            url?.let { currentUrl = it; if (!addressFocused) addressText = it }
                            // Log to web history (de-duped by URL in the VM)
                            if (!url.isNullOrBlank()) {
                                vm.recordWebVisit(url, t ?: url)
                            }
                        }
                        override fun shouldOverrideUrlLoading(
                            view: WebView?, request: WebResourceRequest?
                        ): Boolean {
                            val u = request?.url ?: return false
                            if (isAllowed(u)) return false
                            // Off-domain → system browser
                            runCatching {
                                ctx.startActivity(
                                    Intent(Intent.ACTION_VIEW, u)
                                        .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                                )
                            }
                            return true
                        }
                    }
                    webChromeClient = object : WebChromeClient() {
                        override fun onCreateWindow(
                            view: WebView?, isDialog: Boolean, isUserGesture: Boolean, resultMsg: Message?
                        ): Boolean {
                            if (resultMsg == null) return false
                            val transport = resultMsg.obj as? WebView.WebViewTransport ?: return false
                            transport.webView = this@apply
                            resultMsg.sendToTarget()
                            return true
                        }
                        override fun onProgressChanged(view: WebView?, newProgress: Int) {
                            progress = newProgress
                            loading = newProgress < 100
                        }
                        override fun onReceivedTitle(view: WebView?, title: String?) {
                            if (!title.isNullOrBlank()) pageTitle = title
                        }
                    }
                    if (isAllowed(Uri.parse(url))) loadUrl(url)
                    else Toast.makeText(context, "Only jw.org is allowed here", Toast.LENGTH_SHORT).show()
                    webView = this
                }
            }
        )
    }
}
