package com.tebogo.markvault.ui

import android.annotation.SuppressLint
import android.content.Intent
import android.net.Uri
import android.os.Message
import android.view.ViewGroup
import android.webkit.WebChromeClient
import android.webkit.WebResourceRequest
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.Toast
import androidx.activity.compose.BackHandler
import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.ScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.filled.KeyboardArrowLeft
import androidx.compose.material.icons.automirrored.filled.KeyboardArrowRight
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.MoreVert
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextFieldDefaults
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.key
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.runtime.snapshots.SnapshotStateList
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalSoftwareKeyboardController
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.navigation.NavController
import com.tebogo.markvault.AppViewModel
import com.tebogo.markvault.data.MediaItem
import kotlinx.coroutines.launch

/**
 * Hosts allowed by the in-app browser. www.jw.org IS in the list — earlier
 * black-screen reports turned out to be MIXED_CONTENT_NEVER_ALLOW, not host
 * filtering. With COMPATIBILITY_MODE + this list the Bible viewer and
 * Watchtower Library both load.
 */
private val ALLOWED_HOSTS = setOf(
    "jw.org", "www.jw.org", "m.jw.org",
    "wol.jw.org", "wol.jw.org.za", "tv.jw.org",
    "b.jw-cdn.org", "assetsnffrgf-a.akamaihd.net",
    "data.jw-api.org", "apps.jw.org"
)

private fun isAllowed(uri: Uri?): Boolean {
    val host = uri?.host?.lowercase() ?: return false
    return ALLOWED_HOSTS.any { host == it || host.endsWith(".$it") } ||
        host.endsWith(".jw.org") || host.endsWith(".jw-cdn.org") || host == "jw.org"
}

/**
 * State for one open tab. Each tab keeps its own URL + title; switching tabs
 * recreates the WebView (via Compose `key`) so each tab has an isolated history
 * stack. Trade-off: in-page state (scroll, form input) doesn't persist across
 * tab switches — acceptable for a first-cut multi-tab implementation.
 */
data class WebTab(val id: Long, var url: String, var title: String)

/**
 * Multi-tab in-app browser with bottom-anchored toolbar.
 *
 * Layout:
 *   ┌──────────────────────────┐
 *   │   (minimal top bar)      │  ← only Home/back to keep chrome thumb-reachable
 *   ├──────────────────────────┤
 *   │                          │
 *   │       WebView area       │  ← the active tab's content
 *   │                          │
 *   ├──────────────────────────┤
 *   │   tab strip (←  → +)     │
 *   │   address bar + nav      │
 *   │   action row             │  ← everything else lives at the bottom
 *   └──────────────────────────┘
 */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun WebSearchScreen(vm: AppViewModel, nav: NavController, url: String, label: String) {
    val ctx = LocalContext.current
    val keyboard = LocalSoftwareKeyboardController.current
    val scope = rememberCoroutineScopeSafe()

    // TASK 4: tab list now lives on the AppViewModel so it survives screen
    // navigation. ensureBrowserSession is idempotent — if the user is reopening
    // the browser after looking at a markdown note, their existing tabs are kept.
    //
    // v4.12.0 — also consume any pendingWebOpen request set by Web History,
    // Web Bookmarks, or other screens. This is what makes "tap a history row
    // and actually land on that page" work even when tabs already exist.
    //
    // v5.4.13 — keyed on (url, label) NOT Unit. Without this fix, clicking a
    // second link from an offline HTML article wouldn't re-fire the effect:
    // the WebSearchScreen Composable received the new URL via its param but
    // the effect's Unit key didn't change, so ensureBrowserSession() with the
    // new URL never ran and the browser kept showing the first link. With
    // (url, label) keying, every new navigation correctly opens its target.
    LaunchedEffect(url, label) {
        vm.ensureBrowserSession(url, label)
        vm.consumePendingWebOpen()?.let { (pUrl, pLabel) ->
            vm.openInBrowser(pUrl, pLabel)
        }
    }
    val tabs: SnapshotStateList<WebTab> = vm.webTabs
    val activeTabIdx = vm.webActiveTabIdx
    if (tabs.isEmpty()) {
        // Render nothing this frame; the LaunchedEffect above will populate the list
        // and trigger recomposition with a valid active tab.
        return
    }

    // Per-tab state lives in the Compose `key` block — re-created on tab switch.
    // We track UI state at this level so the bottom bar reacts to the active tab.
    var webView by remember { mutableStateOf<WebView?>(null) }
    var loading by remember { mutableStateOf(true) }
    var progress by remember { mutableStateOf(0) }
    var addressText by remember(activeTabIdx) { mutableStateOf(tabs[activeTabIdx].url) }
    var addressFocused by remember { mutableStateOf(false) }
    var canGoBack by remember { mutableStateOf(false) }
    var canGoForward by remember { mutableStateOf(false) }

    // v5.4.96cc — Shared font-zoom + dark-overlay state, backed by the
    // same VM flows the WebPopup uses. Adjustments made here (via the two
    // new top-bar buttons) persist across the app and are picked up by
    // both viewers, so the user's reading preferences carry over.
    val webZoom by vm.webPopupTextZoom.collectAsState()
    val bottomToolbarAutoMove by vm.bottomToolbarAutoMove.collectAsStateWithLifecycle()
    val webDark by vm.webPopupDarkMode.collectAsState()

    // Find-on-page state — search field opens above the bottom toolbar.
    var findOpen by remember { mutableStateOf(false) }
    var findQuery by remember { mutableStateOf("") }

    // Bookmark state for the active URL
    var isBookmarked by remember { mutableStateOf(false) }
    LaunchedEffect(addressText) {
        isBookmarked = if (addressText.isBlank()) false
        else vm.isBookmarked(addressText)
    }

    // v5.4.235cc — Video/audio detection inside the loaded page. When a
    // <video>/<audio> element with a real src is found, a floating "Play
    // in App" button appears. Tapping it pauses the WebView's playback and
    // continues it in MarkVault's own player (background survival,
    // notification controls, fullscreen, PiP — none of which the WebView's
    // native HTML5 player has).
    var detectedMediaUrl  by remember { mutableStateOf<String?>(null) }
    var detectedMediaType by remember { mutableStateOf<String?>(null) }
    var detectedMediaCheckCount by remember { mutableStateOf(0) }

    fun detectPageMedia(view: WebView?) {
        val w = view ?: return
        w.evaluateJavascript(
            "(function(){try{" +
            "var el=document.querySelector('video[src],video>source[src],audio[src],audio>source[src]');" +
            "if(!el)return '';" +
            "var src=el.tagName==='SOURCE'?el.src:(el.src||'');" +
            "if(!src||src.indexOf('blob:')===0)return '';" +
            "var kind=(el.tagName==='SOURCE'?el.parentElement.tagName:el.tagName).toLowerCase();" +
            "return kind+'|'+src;" +
            "}catch(e){return '';}})();",
            { result ->
                val decoded = runCatching {
                    org.json.JSONTokener(result).nextValue() as? String
                }.getOrNull().orEmpty()
                if (decoded.contains('|')) {
                    val (kind, src) = decoded.split('|', limit = 2)
                    detectedMediaType = kind
                    detectedMediaUrl  = src
                } else if (detectedMediaCheckCount >= 6) {
                    // Stop showing a stale button if nothing was found
                    // after several checks (e.g. user navigated away from
                    // media-bearing content within the same tab).
                    detectedMediaUrl = null
                    detectedMediaType = null
                }
            }
        )
    }

    // Menu
    var menuOpen by remember { mutableStateOf(false) }

    // v5.1.0 — Long-press on a link in the WebView shows a small action
    // sheet with "Open in new tab" / "Copy link". State held here, set by
    // the WebView's setOnLongClickListener via HitTestResult.
    var longPressLinkUrl by remember { mutableStateOf<String?>(null) }
    // v5.4.36 — The anchor text of the long-pressed link, extracted via JS.
    var longPressLinkText by remember { mutableStateOf<String?>(null) }

    fun loadUrlFromAddress(raw: String) {
        val cleaned = raw.trim()
        if (cleaned.isEmpty()) return
        val target = when {
            cleaned.startsWith("http://") || cleaned.startsWith("https://") -> cleaned
            cleaned.contains(".") -> "https://$cleaned"
            else -> "https://www.jw.org/en/search/?q=" + Uri.encode(cleaned)
        }
        if (!isAllowed(Uri.parse(target))) {
            Toast.makeText(ctx, "Only jw.org family of sites are allowed", Toast.LENGTH_SHORT).show()
            return
        }
        keyboard?.hide()
        webView?.loadUrl(target)
        addressFocused = false
    }

    fun addNewTab(initialUrl: String = "https://www.jw.org/en/") {
        vm.addBrowserTab(initialUrl, "New tab")
    }

    fun closeTab(idx: Int) {
        val lastClosed = vm.closeBrowserTab(idx)
        if (lastClosed) nav.popBackStack()
    }

    fun closeAllTabs() {
        vm.closeAllBrowserTabs()
        nav.popBackStack()
    }

    BackHandler(enabled = true) {
        val wv = webView
        if (wv != null && wv.canGoBack()) {
            wv.goBack()
        } else {
            // v5.4.36 — No previous page in this tab: close the tab
            // to avoid piling up empty tabs. If it was the last tab,
            // closeBrowserTab pops the back stack automatically.
            val lastClosed = vm.closeBrowserTab(activeTabIdx)
            if (lastClosed) nav.popBackStack()
        }
    }

    // v5.4.145cc — Scroll-driven toolbar hiding for fullscreen mode in WebViewer
    var lastWebScrollY by remember { mutableStateOf(0) }
    var webToolbarsVisible by remember { mutableStateOf(true) }
    val enableFullscreenMode by vm.enableFullscreenMode.collectAsStateWithLifecycle()
    var relatedVideos by remember { mutableStateOf<List<com.tebogo.markvault.data.RelatedVideoMatch>>(emptyList()) }
    var showRelatedVideos by remember { mutableStateOf(false) }
    var relatedVideoPopup by remember { mutableStateOf<MediaItem?>(null) }
    LaunchedEffect(tabs[activeTabIdx].title, tabs[activeTabIdx].url) {
        val pageTitle = tabs[activeTabIdx].title
        if (pageTitle.isBlank() || pageTitle == "New tab") { relatedVideos = emptyList(); return@LaunchedEffect }
        relatedVideos = vm.findRelatedVideos(pageTitle, tabs[activeTabIdx].url, includeOnline = false)
        relatedVideos = vm.findRelatedVideos(pageTitle, tabs[activeTabIdx].url, includeOnline = true)
    }

    Scaffold(
        // Minimal top bar — just home + close-browser
        // v5.4.148cc — Instant top bar visibility (no animation delay)
        topBar = {
            if (if (enableFullscreenMode) webToolbarsVisible else true) {
            TopAppBar(
                title = {
                    Text(
                        "\uD83C\uDF10 ${tabs[activeTabIdx].title.take(40)}",
                        maxLines = 1, overflow = TextOverflow.Ellipsis,
                        fontSize = 13.sp
                    )
                },
                navigationIcon = {
                    IconButton(onClick = { nav.popBackStack() }) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Close browser")
                    }
                },
                actions = {
                    // v5.4.96cc — Font-zoom (A- / A+) and dark toggle.
                    // Same shared prefs as WebPopup — one continuous
                    // reading experience across both viewers.
                    IconButton(
                        onClick = { vm.setWebPopupTextZoom(webZoom - 10) },
                        modifier = Modifier.size(36.dp)
                    ) {
                        Text("A-", fontSize = 13.sp, fontWeight = FontWeight.SemiBold)
                    }
                    IconButton(
                        onClick = { vm.setWebPopupTextZoom(webZoom + 10) },
                        modifier = Modifier.size(36.dp)
                    ) {
                        Text("A+", fontSize = 13.sp, fontWeight = FontWeight.SemiBold)
                    }
                    IconButton(
                        onClick = { vm.setWebPopupDarkMode(!webDark) },
                        modifier = Modifier.size(36.dp)
                    ) {
                        Text(if (webDark) "\u2600\uFE0F" else "\uD83C\uDF19", fontSize = 14.sp)
                    }
                    HomeButton(nav)
                }
            )
            } // end TopAppBar if
        },
        // Bottom-anchored toolbar — tab strip, address bar, action buttons
        // v5.4.148cc — Instant bottom bar visibility (no animation delay)
        bottomBar = {
            if (if (enableFullscreenMode) webToolbarsVisible else true) {
            BrowserBottomBar(
                tabs = tabs,
                activeTabIdx = activeTabIdx,
                onTabClick = { vm.setWebActiveTab(it) },
                onTabClose = ::closeTab,
                onCloseAllTabs = ::closeAllTabs,
                onAddTab = { addNewTab() },
                addressText = addressText,
                onAddressChange = { addressText = it },
                onAddressFocus = { addressFocused = it },
                onSubmit = { loadUrlFromAddress(addressText) },
                canGoBack = canGoBack,
                canGoForward = canGoForward,
                onBack = { webView?.goBack() },
                onForward = { webView?.goForward() },
                onReloadOrStop = { if (loading) webView?.stopLoading() else webView?.reload() },
                loading = loading,
                isBookmarked = isBookmarked,
                onToggleBookmark = {
                    val u = webView?.url ?: addressText
                    val t = webView?.title ?: tabs[activeTabIdx].title
                    if (isBookmarked) vm.removeBookmark(u) else vm.addBookmark(u, t)
                    isBookmarked = !isBookmarked
                },
                onOpenFind = { findOpen = true; findQuery = "" },
                menuOpen = menuOpen,
                onMenuToggle = { menuOpen = it },
                nav = nav,
                bottomToolbarAutoMove = bottomToolbarAutoMove,
                onBottomToolbarAutoMoveChange = vm::setBottomToolbarAutoMove,
                findOpen = findOpen,
                findQuery = findQuery,
                onFindChange = { findQuery = it; webView?.findAllAsync(it) },
                onFindClose = { findOpen = false; webView?.clearMatches() },
                onFindNext = { webView?.findNext(true) },
                onFindPrev = { webView?.findNext(false) },
                // TASK 2 (v4.4): save the current page as a real .html file
                // — previous implementation used saveWebArchive which only
                // produces .mhtml. Now we grab document.documentElement.outerHTML
                // via JS and write that as text/html in the library.
                onSaveOfflineHtml = {
                    val wv = webView ?: return@BrowserBottomBar
                    val title = wv.title?.takeIf { it.isNotBlank() } ?: tabs[activeTabIdx].title
                    val srcUrl = wv.url ?: tabs[activeTabIdx].url
                    wv.evaluateJavascript(
                        "(function(){return document.documentElement.outerHTML;})();"
                    ) { jsonHtml ->
                        val html = decodeJsString(jsonHtml)
                        if (html.isBlank()) {
                            Toast.makeText(ctx, "Couldn't capture the page HTML.",
                                Toast.LENGTH_SHORT).show()
                            return@evaluateJavascript
                        }
                        scope.launch {
                            val res = vm.saveOfflineHtmlPage(srcUrl, title, html)
                            val msg = when (res) {
                                is com.tebogo.markvault.SaveResult.Ok -> {
                                    // v4.6 — auto-index so the freshly saved
                                    // .html file is searchable from global FTS
                                    // immediately, without the user having to
                                    // manually re-sync the library.
                                    // v5.4.124cc — was vm.reindex() (a full
                                    // library rescan + reconcile on every
                                    // single save); switched to indexing just
                                    // this one file, which is both cheaper and
                                    // carries none of a full sync's risk.
                                    val relPath = if (res.subfolder.isBlank()) res.fileName
                                        else "${res.subfolder}/${res.fileName}"
                                    vm.indexNewFile(res.docUri, relPath)
                                    "\uD83D\uDCBE Saved & indexed: ${res.fileName}"
                                }
                                is com.tebogo.markvault.SaveResult.Error -> "\u26A0\uFE0F ${res.message}"
                            }
                            Toast.makeText(ctx, msg, Toast.LENGTH_LONG).show()
                        }
                    }
                },
                // TASK 3: convert current page to a markdown note in the vault
                onConvertToMarkdown = {
                    val wv = webView ?: return@BrowserBottomBar
                    val srcUrl = wv.url ?: tabs[activeTabIdx].url
                    val pageTitle = wv.title?.takeIf { it.isNotBlank() }
                        ?: tabs[activeTabIdx].title
                    // Pull current HTML via JS bridge — single-line, escape the
                    // outer quotes so the result comes back as a JSON string.
                    wv.evaluateJavascript(
                        "(function(){return document.documentElement.outerHTML;})();"
                    ) { jsonHtml ->
                        // jsonHtml is a JSON-quoted string. Strip outer quotes and
                        // un-escape the standard sequences.
                        val html = decodeJsString(jsonHtml)
                        scope.launch {
                            val res = vm.saveConvertedMarkdown(srcUrl, pageTitle, html)
                            val msg = when (res) {
                                is com.tebogo.markvault.SaveResult.Ok -> {
                                    val relPath = if (res.subfolder.isBlank()) res.fileName
                                        else "${res.subfolder}/${res.fileName}"
                                    vm.indexNewFile(res.docUri, relPath)
                                    "\uD83D\uDCDD Saved & indexed: ${res.fileName}"
                                }
                                is com.tebogo.markvault.SaveResult.Error -> "\u26A0\uFE0F ${res.message}"
                            }
                            Toast.makeText(ctx, msg, Toast.LENGTH_LONG).show()
                        }
                    }
                },
                // v5.4.88cc — Inject the multi-select toggle + "Clear
                // selection" items into the browser's More menu. The
                // WebSelectionFab (bottom-start of the WebView Box, below)
                // is the paired UI that actually triggers the batch save.
                relatedVideosAvailable = relatedVideos.isNotEmpty(),
                onRelatedVideos = { showRelatedVideos = true },
                extraMenuItems = {
                    SelectionMenuItems(
                        vm = vm,
                        webViewProvider = { webView },
                        onAfterAction = { menuOpen = false }
                    )
                    // v5.4.105cc — "Check if this article is in my library"
                    // — reads the current page URL + <title> off the
                    // WebView, kicks off the multi-signal DB check, and
                    // lets the LibraryCheckOverlay handle the loading
                    // pill + result dialog. Disabled while a check is
                    // already in flight so a stray double-tap doesn't
                    // queue duplicate scans.
                    val checkState by vm.libraryCheckState.collectAsState()
                    val checking = checkState is AppViewModel.LibraryCheckState.Loading
                    DropdownMenuItem(
                        text = {
                            Text(
                                if (checking) "\u23F3 Checking\u2026"
                                else "\uD83D\uDD0D Check if in library"
                            )
                        },
                        enabled = !checking,
                        onClick = {
                            menuOpen = false
                            val wv = webView
                            val u = wv?.url.orEmpty()
                            val t = wv?.title.orEmpty()
                            
                            // v5.4.147cc — Extract HTML for auto-save feature
                            if (wv != null) {
                                menuOpen = false
                                wv.evaluateJavascript("(function() { return document.documentElement.outerHTML; })()") { html ->
                                    // Clean up the JSON-escaped string returned by evaluateJavascript
                                    val cleanHtml = html
                                        ?.removeSurrounding("\"")
                                        ?.replace("\\\"", "\"")
                                        ?.replace("\\n", "\n")
                                        ?.replace("\\t", "\t")
                                        ?.replace("\\\\", "\\")
                                        ?.trim()
                                        ?: ""
                                    
                                    if (cleanHtml.isNotBlank() && cleanHtml.length > 100) {
                                        // HTML extraction successful
                                        vm.checkArticleInLibrary(u, t, cleanHtml)
                                    } else {
                                        // HTML extraction failed or too short, proceed without it
                                        vm.checkArticleInLibrary(u, t, "")
                                    }
                                }
                            } else {
                                vm.checkArticleInLibrary(u, t, "")
                            }
                        }
                    )
                }
            )
        }
        }
    ) { pad ->
        Box(Modifier.padding(pad).fillMaxSize()) {
            if (loading) {
                LinearProgressIndicator(
                    progress = { (progress.coerceIn(0, 100)) / 100f },
                    modifier = Modifier.fillMaxWidth().height(2.dp).align(Alignment.TopCenter)
                )
            }
            // v4.13.0 — Use the VM's persistent WebView pool. The `key` block
            // around AndroidView still ensures the WebView swaps when the
            // active tab changes, but switching back to a previously-visited
            // tab restores the SAME WebView with all its state intact (scroll
            // position, form inputs, JS state). Same goes for leaving the
            // browser entirely and coming back via the bottom-bar icon.
            //
            // Pause/resume the active tab's WebView with the Composable
            // lifecycle so a backgrounded tab doesn't burn cycles on JS
            // timers.
            val activeTabId = tabs[activeTabIdx].id
            androidx.compose.runtime.DisposableEffect(activeTabId) {
                val w = vm.getOrCreateWebViewSession(
                    "tab_$activeTabId", ctx
                )
                runCatching { w.onResume() }
                onDispose {
                    (w.parent as? android.view.ViewGroup)?.removeView(w)
                    runCatching { w.onPause() }
                }
            }
            key(activeTabId) {
                AndroidView(
                    modifier = Modifier.fillMaxSize(),
                    factory = { context ->
                        @SuppressLint("SetJavaScriptEnabled")
                        val tabId = tabs[activeTabIdx].id
                        val w = vm.getOrCreateWebViewSession("tab_$tabId", context)
                        // Detach from any prior parent (might be another
                        // Composable host that was just unmounted).
                        (w.parent as? android.view.ViewGroup)?.removeView(w)
                        // True the FIRST time we touch this tab's WebView in
                        // its lifetime — subsequent mounts reuse the existing
                        // config and back/forward history.
                        val needsFirstConfig =
                            w.webViewClient == null || w.url.isNullOrBlank()

                        w.apply {
                            // TASK 5: when user taps "Search in MarkVault" in the text
                            // selection menu, hop to the Search screen with the
                            // selected text pre-filled via the pending-query channel.
                            onSearchInMarkVault = { selectedText ->
                                vm.requestPendingSearch(selectedText)
                                nav.navigate("search") { launchSingleTop = true }
                            }
                            // v4.2 — same menu also has "Search in wol.jw.org" which
                            // navigates the active tab to wol's search page.
                            onSearchInWol = { selectedText ->
                                val target = "https://wol.jw.org/en/wol/s/r1/lp-e?q=" +
                                    java.net.URLEncoder.encode(selectedText, "UTF-8")
                                loadUrl(target)
                            }
                            // v4.12.0 — two new context-menu entries:
                            //   "Search jw.org" navigates the active tab to jw.org's
                            //   site-wide search results page.
                            //   "Share" — left as `null` so SelectionWebView falls
                            //   back to ACTION_SEND, which fires the system share
                            //   sheet without any extra plumbing here.
                            onSearchInJwOrg = { selectedText ->
                                val target = "https://www.jw.org/en/search/?q=" +
                                    java.net.URLEncoder.encode(selectedText, "UTF-8")
                                loadUrl(target)
                            }
                            // onShare left null — fallbackShare() in
                            // SelectionWebView handles it via ACTION_SEND.

                            // v5.4.93cc — Drag-select handler. Fires for
                            // every new anchor the finger crosses after a
                            // long-press has entered selection mode. Same
                            // toggle-and-highlight path as the long-press
                            // itself.
                            //
                            // v5.4.99cc — Multi Mode branch: sweep-select
                            // enqueues each new anchor as a head expansion.
                            val selfWebView = this
                            onDragSelectAnchor = { href, text ->
                                if (href.isNotBlank()) {
                                    if (vm.webMultiSelectionMode.value) {
                                        vm.enqueueHeadExpansion(href, text)
                                        webViewHighlightUrl(selfWebView, href, true)
                                    } else if (vm.webSelectionMode.value) {
                                        val added = vm.toggleWebSelection(href, text)
                                        webViewHighlightUrl(selfWebView, href, added)
                                    }
                                }
                            }
                            if (needsFirstConfig) {
                                layoutParams = ViewGroup.LayoutParams(
                                    ViewGroup.LayoutParams.MATCH_PARENT,
                                    ViewGroup.LayoutParams.MATCH_PARENT
                                )
                                settings.javaScriptEnabled = true
                                settings.domStorageEnabled = true
                                settings.databaseEnabled = true
                                settings.allowFileAccess = false
                                settings.allowContentAccess = true
                                settings.loadsImagesAutomatically = true
                                settings.setSupportZoom(true)
                                settings.builtInZoomControls = true
                                settings.displayZoomControls = false
                                settings.useWideViewPort = true
                                settings.loadWithOverviewMode = true
                                settings.mediaPlaybackRequiresUserGesture = true
                                settings.setSupportMultipleWindows(true)
                                settings.javaScriptCanOpenWindowsAutomatically = true
                                settings.mixedContentMode = WebSettings.MIXED_CONTENT_COMPATIBILITY_MODE
                                settings.userAgentString = settings.userAgentString +
                                    " MarkVault/3.7"
                            }

                            // v5.1.0 — Long-press handler for links.
                            // Detects long-press on anchor / image-anchor and
                            // pops up our compose action sheet. For
                            // long-press on plain text, returning false lets
                            // the WebView's native text-selection mode run
                            // (which is what SelectionWebView wires up its
                            // custom action mode menu through).
                            // v5.4.13 — Honor the linkLongPressAction pref.
                            // When pref != "menu", bypass the action sheet
                            // and route the link straight to the chosen
                            // converter screen.
                            setOnLongClickListener { v ->
                                val webV = v as? SelectionWebView ?: return@setOnLongClickListener false
                                val hit = webV.hitTestResult
                                when (hit.type) {
                                    WebView.HitTestResult.SRC_ANCHOR_TYPE,
                                    WebView.HitTestResult.SRC_IMAGE_ANCHOR_TYPE -> {
                                        // v5.4.91cc — hit.extra is UNRELIABLE for
                                        // SRC_IMAGE_ANCHOR_TYPE — it returns the
                                        // thumbnail's `src` rather than the anchor's
                                        // `href`, which is why the v5.4.90cc batch
                                        // saves produced 641-byte thumbnail files
                                        // instead of the article pages the user
                                        // actually picked. Use the JS elementFromPoint
                                        // resolver on SelectionWebView instead — it
                                        // walks up parent nodes to find the enclosing
                                        // <a> tag and returns its href.
                                        webV.resolveAnchorAtLastTouch { resolvedHref, resolvedText ->
                                            val href = resolvedHref.ifBlank { hit.extra ?: "" }
                                            if (href.isBlank()) return@resolveAnchorAtLastTouch

                                            // v5.4.99cc — Multi Selection Mode takes precedence
                                            // over both normal Selection Mode and the
                                            // linkLongPressAction preference / action sheet.
                                            // The pressed link is treated as a head — enqueued
                                            // for background page-load + body-link extraction,
                                            // with an immediate green outline so the user
                                            // knows the long-press was accepted.
                                            if (vm.webMultiSelectionMode.value) {
                                                val text = resolvedText.ifBlank { href }
                                                vm.enqueueHeadExpansion(href, text)
                                                webViewHighlightUrl(webV, href, true)
                                                // Arm drag-select so the user can sweep across
                                                // adjacent heads without lifting the finger.
                                                webV.enableDragSelectForCurrentPress()
                                                return@resolveAnchorAtLastTouch
                                            }

                                            // Selection-mode branch takes precedence over both the
                                            // linkLongPressAction preference and the action sheet.
                                            if (vm.webSelectionMode.value) {
                                                val text = resolvedText.ifBlank { href }
                                                val added = vm.toggleWebSelection(href, text)
                                                webViewHighlightUrl(webV, href, added)
                                                // v5.4.93cc — Arm drag-select so the
                                                // user can glide across further cards.
                                                webV.enableDragSelectForCurrentPress()
                                                return@resolveAnchorAtLastTouch
                                            }

                                            val action = vm.linkLongPressAction.value
                                            when (action) {
                                                "markdown" -> {
                                                    val enc = java.net.URLEncoder.encode(href, "UTF-8")
                                                    nav.navigate("urlImport/$enc")
                                                }
                                                "pdf" -> {
                                                    val enc = java.net.URLEncoder.encode(href, "UTF-8")
                                                    nav.navigate("pdfFromUrl/$enc")
                                                }
                                                else -> {
                                                    // "menu" or any unknown value falls back to the
                                                    // existing action sheet behaviour.
                                                    longPressLinkUrl = href
                                                    longPressLinkText = resolvedText
                                                        .takeIf { it.isNotBlank() }
                                                }
                                            }
                                        }
                                        true
                                    }
                                    else -> false
                                }
                            }

                            webViewClient = object : WebViewClient() {
                                override fun onPageStarted(
                                    view: WebView?, url: String?, favicon: android.graphics.Bitmap?
                                ) {
                                    loading = true
                                    // v5.4.235cc — Clear any detection from the
                                    // previous page; the new page gets its own
                                    // fresh check in onPageFinished.
                                    detectedMediaUrl = null
                                    detectedMediaType = null
                                    detectedMediaCheckCount = 0
                                    url?.let {
                                        vm.updateBrowserTabById(tabId, url = it)
                                        if (!addressFocused) addressText = it
                                    }
                                    canGoBack = view?.canGoBack() == true
                                    canGoForward = view?.canGoForward() == true
                                }
                                override fun onPageFinished(view: WebView?, url: String?) {
                                    loading = false
                                    canGoBack = view?.canGoBack() == true
                                    canGoForward = view?.canGoForward() == true
                                    val t = view?.title.orEmpty()
                                    url?.let {
                                        if (!addressFocused) addressText = it
                                        vm.updateBrowserTabById(
                                            tabId,
                                            url = it, title = t.ifBlank { it }
                                        )
                                    }
                                    if (!url.isNullOrBlank()) vm.recordWebVisit(url, t.ifBlank { url })
                                    scope.launch { isBookmarked = vm.isBookmarked(url.orEmpty()) }
                                    // v5.4.88cc — Re-inject selection-mode CSS + repaint
                                    // highlights for any previously picked cards that
                                    // also appear on this newly loaded page. No-op when
                                    // selection mode is off.
                                    if (view != null) applySelectionOnLoad(view, vm)
                                    // v5.3.1 — Capture a thumbnail for the tab
                                    // preview. Delayed 500ms so above-the-fold
                                    // content has time to render. Tab id is
                                    // looked up just-in-time so it survives
                                    // tab-list shuffles.
                                    view?.postDelayed({
                                        if (vm.webTabs.any { it.id == tabId }) {
                                            vm.saveWebTabThumbnail(tabId, view)
                                        }
                                    }, 500L)
                                    // v5.4.235cc — Check for video/audio now, then a
                                    // few more times over the next several seconds —
                                    // JW.org's video pages often attach the actual
                                    // <video src> slightly after the page-finished
                                    // event fires.
                                    detectedMediaCheckCount = 0
                                    detectPageMedia(view)
                                }
                                override fun shouldOverrideUrlLoading(
                                    view: WebView?, request: WebResourceRequest?
                                ): Boolean {
                                    val u = request?.url ?: return false
                                    if (isAllowed(u)) return false
                                    runCatching {
                                        ctx.startActivity(
                                            Intent(Intent.ACTION_VIEW, u)
                                                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                                        )
                                    }
                                    return true
                                }
                                /**
                                 * v4.5 — catch renderer-process crashes. Must
                                 * return true so Android doesn't kill the host
                                 * app process. We drop the dead WebView; the
                                 * Compose factory will recreate one if the user
                                 * navigates back to this tab.
                                 */
                                override fun onRenderProcessGone(
                                    view: WebView?,
                                    detail: android.webkit.RenderProcessGoneDetail?
                                ): Boolean {
                                    // Remove the dead renderer-backed WebView from the VM
                                    // pool. Keeping a destroyed instance under this tab id makes
                                    // a later tab switch reattach a dead view and look like an
                                    // unexplained refresh/blank page. The logical tab itself stays.
                                    runCatching { vm.destroyWebViewSession("tab_$tabId") }
                                    Toast.makeText(
                                        ctx,
                                        "The page crashed the renderer. Tab closed.",
                                        Toast.LENGTH_LONG
                                    ).show()
                                    return true
                                }
                            }
                            webChromeClient = object : WebChromeClient() {
                                override fun onCreateWindow(
                                    view: WebView?, isDialog: Boolean, isUserGesture: Boolean, resultMsg: Message?
                                ): Boolean {
                                    // v5.1.0 — Genuine multi-tab handling for
                                    // target=_blank links and JS window.open().
                                    // Old behaviour was to send the URL into the
                                    // current WebView, which discarded the
                                    // multi-tab promise. Now we create a
                                    // throwaway WebView whose only job is to
                                    // catch the about-to-load URL via
                                    // shouldOverrideUrlLoading, then route it
                                    // into a real new tab via vm.openInBrowser.
                                    if (resultMsg == null || view == null) return false
                                    val transport = resultMsg.obj as? WebView.WebViewTransport ?: return false
                                    val temp = WebView(view.context).apply {
                                        webViewClient = object : WebViewClient() {
                                            override fun shouldOverrideUrlLoading(
                                                v: WebView?, request: WebResourceRequest?
                                            ): Boolean {
                                                val u = request?.url?.toString()
                                                if (!u.isNullOrBlank()) {
                                                    val host = request?.url?.host ?: "Link"
                                                    vm.openInBrowser(u, host)
                                                }
                                                v?.destroy()
                                                return true
                                            }
                                        }
                                    }
                                    transport.webView = temp
                                    resultMsg.sendToTarget()
                                    return true
                                }
                                override fun onProgressChanged(view: WebView?, newProgress: Int) {
                                    progress = newProgress
                                    loading = newProgress < 100
                                }
                                override fun onReceivedTitle(view: WebView?, title: String?) {
                                    if (!title.isNullOrBlank()) {
                                        vm.updateBrowserTabById(tabId, title = title)
                                    }
                                }
                            }
                            val startUrl = tabs.firstOrNull { it.id == tabId }?.url.orEmpty()
                            // v5.4.274cc — A persistent tab owns its WebView until the user
                            // closes the tab. Re-attaching after switching tabs/screens must
                            // never reload merely because tab metadata changed asynchronously.
                            // Explicit navigations call loadUrl() on the live WebView; only a
                            // brand-new/blank session consumes the stored start URL here.
                            if (needsFirstConfig && url.isNullOrBlank() && startUrl.isNotBlank()) {
                                if (isAllowed(Uri.parse(startUrl))) {
                                    // v5.4.278cc — Start a brand-new tab only after the
                                    // WebView has entered the main message queue. This avoids
                                    // doing the first jw.org navigation while AndroidView is
                                    // still constructing/reattaching its native child.
                                    post {
                                        if (this.url.isNullOrBlank() &&
                                            vm.webTabs.any { it.id == tabId }) {
                                            loading = true
                                            loadUrl(startUrl)
                                        }
                                    }
                                } else {
                                    Toast.makeText(context, "Only jw.org is allowed here", Toast.LENGTH_SHORT).show()
                                }
                            }
                            webView = this
                        }
                        // Return the (possibly-reused) WebView. AndroidView
                        // will add it as a child of the host ViewGroup; we've
                        // already detached it from any prior parent above.
                        w
                    },
                    update = { w ->
                        // v5.4.96cc — Apply the shared zoom + dark toggle
                        // reactively. Zoom lives in a native WebSettings
                        // field so setting it is a plain assignment. Dark
                        // mode is a CSS-overlay JS blob shared with
                        // WebPopup (POPUP_DARK_OVERLAY_JS /
                        // POPUP_REMOVE_OVERLAY_JS) so the two viewers
                        // paint identically.
                        w.settings.textZoom = webZoom
                        if (webDark) w.evaluateJavascript(POPUP_DARK_OVERLAY_JS, null)
                        else w.evaluateJavascript(POPUP_REMOVE_OVERLAY_JS, null)
                        
                        // v5.4.150cc — Attach scroll listener with ASYMMETRIC thresholds
                        // Hide: 20px down (prevents shake), Show: 3px up (instant)
                        if (enableFullscreenMode) {
                            w.setOnScrollChangeListener { v, _, scrollY, _, _ ->
                                // v5.4.150cc — Asymmetric thresholds:
                                // - Hide: needs 20px down (prevents feedback shake)
                                // - Show: needs only 3px up (instant response)
                                val hideThreshold = 20
                                val showThreshold = 3  // v5.4.150cc — instant show
                                val scrollDelta = scrollY - lastWebScrollY
                                
                                if (scrollDelta > hideThreshold && webToolbarsVisible) {
                                    // Scrolled DOWN enough → hide toolbar
                                    webToolbarsVisible = false
                                    lastWebScrollY = scrollY
                                } else if (scrollDelta < -showThreshold && !webToolbarsVisible) {
                                    // Scrolled UP even slightly → show toolbar INSTANTLY
                                    webToolbarsVisible = true
                                    lastWebScrollY = scrollY
                                } else if (kotlin.math.abs(scrollDelta) < 2) {
                                    // Very small movements → just keep tracking
                                    lastWebScrollY = scrollY
                                }
                                // Between 2px and hideThreshold going down: ignore (dead zone)
                            }
                        } else {
                            // When fullscreen is off, toolbars always visible
                            webToolbarsVisible = true
                            w.setOnScrollChangeListener(null)
                        }
                    }
                )
            }

            // v5.4.235cc — Bounded re-check loop: JW.org video pages often
            // attach the actual <video src> a moment after page-finished
            // fires. Checks every 1.5s for up to ~9s, then stops (avoids
            // burning battery on pages that never have media).
            LaunchedEffect(activeTabId, addressText) {
                detectedMediaCheckCount = 0
                repeat(6) {
                    kotlinx.coroutines.delay(1500L)
                    detectedMediaCheckCount++
                    detectPageMedia(webView)
                }
            }

            // v5.4.235cc — Floating "Play in App" button, shown only when
            // detectPageMedia found a real <video>/<audio> src on the
            // current page. Tapping it pauses the WebView's native
            // playback and continues in MarkVault's own player.
            val mediaUrl  = detectedMediaUrl
            val mediaKind = detectedMediaType
            if (mediaUrl != null) {
                androidx.compose.material3.ExtendedFloatingActionButton(
                    onClick = {
                        val pageTitle = webView?.title?.takeIf { it.isNotBlank() }
                            ?: tabs.getOrNull(activeTabIdx)?.title
                            ?: "Web media"
                        webView?.evaluateJavascript(
                            "(function(){try{var m=document.querySelector('video,audio');" +
                                "if(!m)return 0;var t=m.currentTime||0;m.pause();return Math.round(t*1000);" +
                                "}catch(e){return 0;}})();"
                        ) { raw ->
                            val startMs = raw.trim().trim('\"').toDoubleOrNull()?.toLong() ?: 0L
                            vm.playWebMedia(
                                MediaItem(title = pageTitle, streamUrl = mediaUrl, mediaType = mediaKind ?: "video"),
                                startMs
                            )
                            nav.navigate("mediaPlayer/0")
                        }
                    },
                    containerColor = MaterialTheme.colorScheme.primary,
                    contentColor = MaterialTheme.colorScheme.onPrimary,
                    modifier = Modifier
                        .align(Alignment.BottomEnd)
                        .padding(bottom = 84.dp, end = 12.dp)
                ) {
                    Text(if (mediaKind == "audio") "\uD83D\uDD0A" else "\u25B6", fontSize = 16.sp)
                    Spacer(Modifier.width(6.dp))
                    Text("Play in App", fontSize = 13.sp, fontWeight = FontWeight.SemiBold)
                }
            }

            // v5.4.88cc — Multi-selection FAB. Only visible while
            // selection mode is on; empty basket shows a coaching pill,
            // non-empty basket shows "Save N articles". Batch fetch/save
            // runs in a hidden WebView via AppViewModel.startBatchSave +
            // HiddenBatchSaver (v5.4.89cc — replaces the failed HTTP path).
            WebSelectionFab(
                vm = vm,
                nav = nav,
                modifier = Modifier
                    .align(Alignment.BottomStart)
                    .selectionFabPlacement()
            )
            // v5.4.104cc — Top-right pill showing how many items the
            // current batch save skipped as "already in library". Only
            // visible while a batch save is actually in flight AND at
            // least one dupe was found. Placed at TopEnd so it doesn't
            // fight the FAB (bottom-start) or SavePromptBar (bottom-
            // center); auto-hides when finishBatchSave clears the
            // counter.
            BatchSkipIndicator(
                vm = vm,
                modifier = Modifier
                    .align(Alignment.TopEnd)
                    .padding(top = 12.dp, end = 12.dp)
            )
            // v5.4.105cc — "Check if in library" flow: loading pill at
            // TopStart while the DB scan runs, AlertDialog (or empty-
            // result toast) once the check completes. Placed inside
            // this Box so both states live inside the WebView area
            // rather than as system dialogs.
            LibraryCheckOverlay(vm = vm, nav = nav)

            // v5.4.109cc — Auto-start batch save after Multi Selection
            // Mode expansion settles. Trigger conditions:
            //   • Multi mode is ON.
            //   • The expansion counter has fallen back to 0 (all
            //     long-pressed heads have loaded and reported their
            //     body links to the basket).
            //   • The basket has at least one item.
            //   • No batch save is already in flight.
            // A 1.5 s debounce lets the user long-press one more head
            // right after the previous one settled without the save
            // firing prematurely — enqueueHeadExpansion bumps the
            // counter back above 0 and the effect resets.
            //
            // Only fires under Multi Mode: plain Selection Mode is
            // manual by design (you tap what you want, you press
            // Save) so users don't get surprised.
            val autoMultiMode by vm.webMultiSelectionMode.collectAsState()
            val autoExpanding by vm.webMultiExpandingHeads.collectAsState()
            val autoSelectionItems by vm.webSelectionItems.collectAsState()
            val autoBatchInFlight by vm.batchSaveRequest.collectAsState()
            LaunchedEffect(autoMultiMode, autoExpanding, autoSelectionItems.size, autoBatchInFlight.isEmpty()) {
                if (autoMultiMode &&
                    autoExpanding == 0 &&
                    autoSelectionItems.isNotEmpty() &&
                    autoBatchInFlight.isEmpty()
                ) {
                    kotlinx.coroutines.delay(1500)
                    // Re-check state after the debounce — the user
                    // may have started another expansion mid-wait, in
                    // which case the counter is back above 0 and we
                    // must not fire.
                    if (vm.webMultiSelectionMode.value &&
                        vm.webMultiExpandingHeads.value == 0 &&
                        vm.webSelectionItems.value.isNotEmpty() &&
                        vm.batchSaveRequest.value.isEmpty()
                    ) {
                        vm.startBatchSave()
                    }
                }
            }
            // v5.4.93cc — "This article isn't saved" prompt.
            SavePromptBar(
                vm = vm,
                webViewProvider = { webView },
                currentUrlProvider = { webView?.url ?: tabs.getOrNull(activeTabIdx)?.url ?: "" },
                currentTitleProvider = { webView?.title ?: tabs.getOrNull(activeTabIdx)?.title ?: "" },
                modifier = Modifier
                    .align(Alignment.BottomCenter)
                    .selectionFabPlacement()
            )
            // v5.4.96cc — Small "back to previous article" floating
            // button at bottom-start. Users arriving here via a link
            // tap from a markdown note (or the HTML reader) can pop
            // back to the article that referenced this URL without
            // reaching up to the top bar. Hidden while the multi-
            // select FAB is present so the two don't fight for the
            // same slot; the mental model is "you're not in either
            // saving mode OR browsing-back mode, they're distinct".
            val selMode by vm.webSelectionMode.collectAsState()
            val selMultiMode by vm.webMultiSelectionMode.collectAsState()
            if (!selMode && !selMultiMode) {
                // v5.4.158cc — Press feedback (squish on tap).
                val backFabInteraction = remember { MutableInteractionSource() }
                androidx.compose.material3.SmallFloatingActionButton(
                    onClick = { nav.popBackStack() },
                    containerColor = androidx.compose.material3.MaterialTheme.colorScheme
                        .secondaryContainer,
                    contentColor = androidx.compose.material3.MaterialTheme.colorScheme
                        .onSecondaryContainer,
                    elevation = androidx.compose.material3.FloatingActionButtonDefaults
                        .elevation(defaultElevation = 4.dp),
                    interactionSource = backFabInteraction,
                    modifier = Modifier
                        .align(Alignment.BottomStart)
                        .selectionFabPlacement()
                        .fabPressScale(backFabInteraction)
                ) {
                    Icon(
                        Icons.AutoMirrored.Filled.ArrowBack,
                        contentDescription = "Back to previous article"
                    )
                }
            }
            // v5.4.90cc — HiddenBatchSaver moved to MainActivity level so
            // it survives multitasking between screens inside MarkVault.
        }
    }

    // v5.1.0 — Link long-press action sheet. Triggered by the setOnLongClickListener
    // on the WebView when HitTestResult identifies an anchor link. Lets the user
    // open the link as a NEW browser tab without disturbing the current page.
    longPressLinkUrl?.let { href ->
        androidx.compose.material3.ModalBottomSheet(
            onDismissRequest = { longPressLinkUrl = null; longPressLinkText = null }
        ) {
            Column(Modifier.fillMaxWidth().padding(horizontal = 18.dp, vertical = 8.dp)) {
                Text(
                    href,
                    fontSize = 12.sp,
                    color = androidx.compose.material3.MaterialTheme.colorScheme.onSurfaceVariant,
                    maxLines = 2,
                    overflow = androidx.compose.ui.text.style.TextOverflow.Ellipsis,
                    modifier = Modifier.padding(bottom = 8.dp)
                )
                androidx.compose.material3.TextButton(
                    onClick = {
                        val host = runCatching { Uri.parse(href).host }.getOrNull() ?: "Link"
                        vm.openInBrowser(href, host)
                        longPressLinkUrl = null; longPressLinkText = null
                    },
                    modifier = Modifier.fillMaxWidth()
                ) { Text("\uD83E\uDE9F  Open in new tab") }
                androidx.compose.material3.TextButton(
                    onClick = {
                        // Replace current tab
                        loadUrlFromAddress(href)
                        longPressLinkUrl = null; longPressLinkText = null
                    },
                    modifier = Modifier.fillMaxWidth()
                ) { Text("\u27A1\uFE0F  Open in this tab") }
                androidx.compose.material3.TextButton(
                    onClick = {
                        val cm = ctx.getSystemService(android.content.Context.CLIPBOARD_SERVICE)
                                as? android.content.ClipboardManager
                        cm?.setPrimaryClip(
                            android.content.ClipData.newPlainText("MarkVault link", href)
                        )
                        Toast.makeText(ctx, "Link copied", Toast.LENGTH_SHORT).show()
                        longPressLinkUrl = null; longPressLinkText = null
                    },
                    modifier = Modifier.fillMaxWidth()
                ) { Text("\uD83D\uDCCB  Copy link") }
                // v5.4.36 — Copy link text and search in library
                if (!longPressLinkText.isNullOrBlank()) {
                    androidx.compose.material3.TextButton(
                        onClick = {
                            val cm = ctx.getSystemService(android.content.Context.CLIPBOARD_SERVICE)
                                    as? android.content.ClipboardManager
                            cm?.setPrimaryClip(
                                android.content.ClipData.newPlainText("Link text", longPressLinkText)
                            )
                            Toast.makeText(ctx, "Link text copied", Toast.LENGTH_SHORT).show()
                            longPressLinkUrl = null; longPressLinkText = null
                        },
                        modifier = Modifier.fillMaxWidth()
                    ) { Text("\uD83D\uDCDD  Copy link text") }
                    androidx.compose.material3.TextButton(
                        onClick = {
                            val query = longPressLinkText ?: return@TextButton
                            vm.query.value = query
                            longPressLinkUrl = null; longPressLinkText = null
                            nav.navigate("search") { launchSingleTop = true }
                        },
                        modifier = Modifier.fillMaxWidth()
                    ) { Text("\uD83D\uDD0D  Search in library") }
                }
                // v5.4.13 — Convert-to-* options. Same three destinations
                // as the share-URL chooser, accessible without leaving
                // the browser.
                androidx.compose.material3.HorizontalDivider(
                    modifier = Modifier.padding(vertical = 4.dp)
                )
                androidx.compose.material3.TextButton(
                    onClick = {
                        val enc = java.net.URLEncoder.encode(href, "UTF-8")
                        longPressLinkUrl = null; longPressLinkText = null
                        nav.navigate("urlImport/$enc")
                    },
                    modifier = Modifier.fillMaxWidth()
                ) { Text("\uD83D\uDCDD  Convert to Markdown") }
                androidx.compose.material3.TextButton(
                    onClick = {
                        val enc = java.net.URLEncoder.encode(href, "UTF-8")
                        longPressLinkUrl = null; longPressLinkText = null
                        nav.navigate("pdfFromUrl/$enc")
                    },
                    modifier = Modifier.fillMaxWidth()
                ) { Text("\uD83D\uDCC4  Convert to PDF") }
            }
        }
    }

    if (showRelatedVideos) {
        Box(Modifier.fillMaxSize().padding(12.dp), contentAlignment = Alignment.BottomCenter) {
            RelatedVideosCarousel(
                vm, relatedVideos,
                onClose = { showRelatedVideos = false },
                onPlayVideo = { match ->
                    vm.playMedia(match.item)
                    relatedVideoPopup = match.item
                }
            )
        }
    }

    relatedVideoPopup?.let { media ->
        FloatingMediaPopup(
            vm = vm, title = media.title, url = media.streamUrl, mediaType = media.mediaType,
            onDismiss = { relatedVideoPopup = null },
            onOpenFullPlayer = {
                relatedVideoPopup = null
                nav.navigate("mediaPlayer/0") { launchSingleTop = true }
            }
        )
    }
}

@Composable
private fun rememberCoroutineScopeSafe() = androidx.compose.runtime.rememberCoroutineScope()

/**
 * The bottom toolbar housing: tab strip, address bar, navigation arrows,
 * reload/stop, bookmark star, find-on-page entry, more menu.
 * Find-on-page bar appears just above the toolbar when activated.
 */
@Composable
private fun BrowserBottomBar(
    tabs: SnapshotStateList<WebTab>,
    activeTabIdx: Int,
    onTabClick: (Int) -> Unit,
    onTabClose: (Int) -> Unit,
    onCloseAllTabs: () -> Unit = {},
    onAddTab: () -> Unit,
    addressText: String,
    onAddressChange: (String) -> Unit,
    onAddressFocus: (Boolean) -> Unit,
    onSubmit: () -> Unit,
    canGoBack: Boolean,
    canGoForward: Boolean,
    onBack: () -> Unit,
    onForward: () -> Unit,
    onReloadOrStop: () -> Unit,
    loading: Boolean,
    isBookmarked: Boolean,
    onToggleBookmark: () -> Unit,
    onOpenFind: () -> Unit,
    menuOpen: Boolean,
    onMenuToggle: (Boolean) -> Unit,
    nav: NavController,
    bottomToolbarAutoMove: Boolean,
    onBottomToolbarAutoMoveChange: (Boolean) -> Unit,
    findOpen: Boolean,
    findQuery: String,
    onFindChange: (String) -> Unit,
    onFindClose: () -> Unit,
    onFindNext: () -> Unit,
    onFindPrev: () -> Unit,
    // TASK 2/3: pluggable actions wired from WebSearchScreen so we can reach the
    // WebView (saveWebArchive) and the VM (saveConvertedMarkdown) without
    // passing those into this private helper.
    onSaveOfflineHtml: () -> Unit = {},
    onConvertToMarkdown: () -> Unit = {},
    relatedVideosAvailable: Boolean = false,
    onRelatedVideos: () -> Unit = {},
    // v5.4.88cc — Composable slot for additional DropdownMenuItems inserted
    // just above the Settings entry. Used to inject the selection-mode
    // toggle + "Clear selection" items from WebSearchScreen without giving
    // this private helper direct access to the AppViewModel.
    extraMenuItems: @Composable () -> Unit = {}
) {
    Surface(color = MaterialTheme.colorScheme.surfaceVariant, shadowElevation = 8.dp) {
        Column(Modifier.fillMaxWidth()) {
            // Find-on-page row (appears above the toolbar when active)
            if (findOpen) {
                Row(
                    Modifier.fillMaxWidth().padding(horizontal = 8.dp, vertical = 4.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(Icons.Default.Search,
                        contentDescription = "Find",
                        tint = MaterialTheme.colorScheme.onSurfaceVariant)
                    Spacer(Modifier.width(6.dp))
                    OutlinedTextField(
                        value = findQuery,
                        onValueChange = onFindChange,
                        modifier = Modifier.weight(1f).height(46.dp),
                        placeholder = { Text("Find on page\u2026", fontSize = 13.sp) },
                        textStyle = androidx.compose.ui.text.TextStyle(fontSize = 13.sp),
                        singleLine = true,
                        keyboardOptions = KeyboardOptions(imeAction = ImeAction.Search),
                        shape = RoundedCornerShape(20.dp)
                    )
                    IconButton(onClick = onFindPrev) {
                        Icon(Icons.AutoMirrored.Filled.KeyboardArrowLeft, contentDescription = "Previous match")
                    }
                    IconButton(onClick = onFindNext) {
                        Icon(Icons.AutoMirrored.Filled.KeyboardArrowRight, contentDescription = "Next match")
                    }
                    IconButton(onClick = onFindClose) {
                        Icon(Icons.Default.Close, contentDescription = "Close find")
                    }
                }
                HorizontalDivider()
            }

            // Tab strip — horizontally scrollable list of tab chips
            // v5.4.147cc — REORDER tabs so active tab is ALWAYS first (leftmost)
            val tabScrollState: androidx.compose.foundation.ScrollState = rememberScrollState()
            LaunchedEffect(activeTabIdx) {
                // Always scroll to the very start since active tab is now first
                tabScrollState.animateScrollTo(0)
            }
            
            // v5.4.147cc — Build reordered list: active tab first, then others in order
            val reorderedTabs = remember(tabs, activeTabIdx) {
                if (activeTabIdx in tabs.indices) {
                    val activeTab = tabs[activeTabIdx]
                    // Active tab first, then all others (excluding the active one)
                    listOf(activeTab to activeTabIdx) + 
                        tabs.mapIndexedNotNull { idx, tab ->
                            if (idx != activeTabIdx) tab to idx else null
                        }
                } else {
                    tabs.mapIndexed { idx, tab -> tab to idx }
                }
            }
            
            Row(
                Modifier.fillMaxWidth()
                    .horizontalScroll(tabScrollState)
                    .padding(horizontal = 6.dp, vertical = 4.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                reorderedTabs.forEach { (tab, originalIdx) ->
                    val active = originalIdx == activeTabIdx
                    // v5.4.147cc — Different colors for each tab based on ORIGINAL index
                    val tabColors = listOf(
                        Color(0xFF6D4C41),  // Brown
                        Color(0xFF455A64),  // Blue-grey
                        Color(0xFF558B2F),  // Green
                        Color(0xFF6A1B9A),  // Purple
                        Color(0xFFD84315),  // Orange-red
                        Color(0xFF00838F)   // Teal
                    )
                    val tabBackgroundColor = if (active) {
                        MaterialTheme.colorScheme.primaryContainer
                    } else {
                        tabColors[originalIdx % tabColors.size].copy(alpha = 0.35f)
                    }
                    // v5.4.159cc — Cross-fade background + border color instead of an
                    // instant snap when a tab becomes active/inactive. This strip uses
                    // a plain Row + forEach (not LazyRow), so Modifier.animateItem()
                    // isn't available here for position-slide the way it is in
                    // ReaderScreen's LazyRow tab strip — the existing
                    // tabScrollState.animateScrollTo(0) above already smooths the
                    // scroll-position change; this adds smooth color transitions
                    // alongside it.
                    val animatedBg by animateColorAsState(
                        targetValue = tabBackgroundColor,
                        animationSpec = tween(220),
                        label = "webTabBgColor"
                    )
                    val animatedBorderColor by animateColorAsState(
                        targetValue = if (active) MaterialTheme.colorScheme.primary
                            else tabColors[originalIdx % tabColors.size],
                        animationSpec = tween(220),
                        label = "webTabBorderColor"
                    )
                    
                    Surface(
                        color = animatedBg,
                        shape = RoundedCornerShape(10.dp),
                        border = androidx.compose.foundation.BorderStroke(
                            if (active) 2.dp else 1.dp,
                            animatedBorderColor
                        ),
                        modifier = Modifier
                            .padding(horizontal = 3.dp)
                            .clickable { onTabClick(originalIdx) }
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                        ) {
                            Text(
                                tab.title.take(20),
                                fontSize = 12.sp,
                                fontWeight = if (active) FontWeight.SemiBold else FontWeight.Normal,
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis,
                                color = if (active) MaterialTheme.colorScheme.onPrimaryContainer
                                else MaterialTheme.colorScheme.onSurface
                            )
                            Spacer(Modifier.width(4.dp))
                            IconButton(
                                onClick = { onTabClose(originalIdx) },
                                modifier = Modifier.size(20.dp)
                            ) {
                                Icon(Icons.Default.Close,
                                    contentDescription = "Close tab",
                                    modifier = Modifier.size(14.dp))
                            }
                        }
                    }
                }
                IconButton(onClick = onAddTab, modifier = Modifier.size(32.dp)) {
                    Icon(Icons.Default.Add, contentDescription = "New tab")
                }
                // v5.4.35 — Close all browser tabs at once
                if (tabs.size > 1) {
                    IconButton(onClick = onCloseAllTabs, modifier = Modifier.size(32.dp)) {
                        Icon(Icons.Default.Close, contentDescription = "Close all tabs",
                            modifier = Modifier.size(16.dp))
                    }
                }
            }
            HorizontalDivider()
            // Address bar row
            Row(
                Modifier.fillMaxWidth().padding(horizontal = 6.dp, vertical = 4.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                IconButton(onClick = onBack, enabled = canGoBack,
                    modifier = Modifier.size(36.dp)) {
                    Icon(Icons.AutoMirrored.Filled.KeyboardArrowLeft,
                        contentDescription = "Back",
                        tint = if (canGoBack) MaterialTheme.colorScheme.onSurface
                        else MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.4f))
                }
                IconButton(onClick = onForward, enabled = canGoForward,
                    modifier = Modifier.size(36.dp)) {
                    Icon(Icons.AutoMirrored.Filled.KeyboardArrowRight,
                        contentDescription = "Forward",
                        tint = if (canGoForward) MaterialTheme.colorScheme.onSurface
                        else MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.4f))
                }
                OutlinedTextField(
                    value = addressText,
                    onValueChange = onAddressChange,
                    singleLine = true,
                    modifier = Modifier.weight(1f).height(56.dp),
                    placeholder = { Text("Enter URL or search\u2026", fontSize = 14.sp) },
                    textStyle = androidx.compose.ui.text.TextStyle(
                        fontSize = 14.sp, fontWeight = FontWeight.Medium
                    ),
                    keyboardOptions = KeyboardOptions(imeAction = ImeAction.Go),
                    keyboardActions = KeyboardActions(onGo = { onSubmit() }),
                    shape = RoundedCornerShape(24.dp),
                    colors = TextFieldDefaults.colors(
                        focusedContainerColor = MaterialTheme.colorScheme.surface,
                        unfocusedContainerColor = MaterialTheme.colorScheme.surface
                    )
                )
                IconButton(onClick = onReloadOrStop, modifier = Modifier.size(36.dp)) {
                    Icon(
                        if (loading) Icons.Default.Close else Icons.Default.Refresh,
                        contentDescription = if (loading) "Stop" else "Reload"
                    )
                }
            }
            // Action row: bookmark, find, history, menu
            CircularToolbarRow(
                autoMove = bottomToolbarAutoMove,
                onAutoMoveChange = onBottomToolbarAutoMoveChange,
                modifier = Modifier.fillMaxWidth().padding(horizontal = 4.dp, vertical = 2.dp)
            ) {
                if (relatedVideosAvailable) {
                    IconButton(onClick = onRelatedVideos) { Text("🎬", fontSize = 17.sp) }
                }
                IconButton(onClick = onToggleBookmark) {
                    // Unicode star glyphs — ☆ outline / ★ filled. Avoids needing
                    // the material-icons-extended dependency (StarBorder isn't
                    // in the core icon set).
                    Text(
                        if (isBookmarked) "\u2605" else "\u2606",
                        fontSize = 22.sp,
                        color = if (isBookmarked) Color(0xFFFFC107)
                        else MaterialTheme.colorScheme.onSurface
                    )
                }
                IconButton(onClick = onOpenFind) {
                    Icon(Icons.Default.Search, contentDescription = "Find on page")
                }
                IconButton(onClick = { nav.navigate("webBookmarks") }) {
                    Text("\uD83D\uDD16", fontSize = 18.sp)
                }
                IconButton(onClick = { nav.navigate("webHistory") }) {
                    Text("\uD83D\uDD52", fontSize = 18.sp)
                }
                // v4.4.3 — Home button in browser toolbar too (user request:
                // every toolbar must have the same core buttons). Tapping it
                // pops the back stack all the way to Home; the WebView's tab
                // session lives on the VM so reopening the browser later
                // restores the exact tabs.
                IconButton(onClick = {
                    nav.popBackStack("home", inclusive = false)
                }) {
                    Text("\uD83C\uDFE0", fontSize = 18.sp)
                }
                Box {
                    IconButton(onClick = { onMenuToggle(true) }) {
                        Icon(Icons.Default.MoreVert, contentDescription = "More")
                    }
                    DropdownMenu(expanded = menuOpen, onDismissRequest = { onMenuToggle(false) }) {
                        DropdownMenuItem(
                            text = { Text("\uD83C\uDFE0 jw.org home") },
                            onClick = { onMenuToggle(false); onAddressChange("https://www.jw.org/en/"); onSubmit() }
                        )
                        DropdownMenuItem(
                            text = { Text("\uD83D\uDD16 Bookmarks") },
                            onClick = { onMenuToggle(false); nav.navigate("webBookmarks") }
                        )
                        DropdownMenuItem(
                            text = { Text("\uD83D\uDD52 Web history") },
                            onClick = { onMenuToggle(false); nav.navigate("webHistory") }
                        )
                        DropdownMenuItem(
                            text = { Text("\uD83D\uDCDC PDF history") },
                            onClick = { onMenuToggle(false); nav.navigate("pdfHistory") }
                        )
                        // v5.4.96cc — Jump to the app-wide search screen
                        // (FTS + semantic). Handy when the user is
                        // browsing an article and wants to find the same
                        // topic in their own library.
                        DropdownMenuItem(
                            text = { Text("\uD83D\uDD0D Search MarkVault") },
                            onClick = { onMenuToggle(false); nav.navigate("search") }
                        )
                        // v5.4.95cc — Activity log entry alongside the
                        // other history views, since it's where all
                        // save-related history (batch, single, MD) lives.
                        DropdownMenuItem(
                            text = { Text("\uD83D\uDCCB Activity log") },
                            onClick = { onMenuToggle(false); nav.navigate("activity_log") }
                        )
                        HorizontalDivider()
                        // TASK 2: archive current page as offline HTML
                        DropdownMenuItem(
                            text = { Text("\uD83D\uDCBE Save as Offline HTML") },
                            onClick = { onMenuToggle(false); onSaveOfflineHtml() }
                        )
                        // TASK 3: convert current page into a markdown note
                        DropdownMenuItem(
                            text = { Text("\uD83D\uDCDD Convert to Markdown") },
                            onClick = { onMenuToggle(false); onConvertToMarkdown() }
                        )
                        HorizontalDivider()
                        // v5.4.88cc — Selection-mode toggle + clear, injected
                        // by the caller so we can read the AppViewModel from
                        // inside this private helper without a direct dep.
                        extraMenuItems()
                        HorizontalDivider()
                        DropdownMenuItem(
                            text = { Text("\u2699\uFE0F Settings") },
                            onClick = { onMenuToggle(false); nav.navigate("settings") }
                        )
                    }
                }
            }
        }
    }
}


/**
 * Decode a JSON-encoded string returned by WebView.evaluateJavascript.
 * The callback receives a value like  `"<html>\u003E</html>"`  — outer quotes
 * plus standard JSON escapes. This helper strips the quotes and un-escapes
 * `\\` `\"` `\n` `\r` `\t` and `\uXXXX` so the caller gets the raw payload.
 */
private fun decodeJsString(jsonValue: String?): String {
    if (jsonValue.isNullOrBlank() || jsonValue == "null") return ""
    var s = jsonValue.trim()
    if (s.startsWith("\"") && s.endsWith("\"")) s = s.substring(1, s.length - 1)
    val sb = StringBuilder(s.length)
    var i = 0
    while (i < s.length) {
        val c = s[i]
        if (c == '\\' && i + 1 < s.length) {
            when (val n = s[i + 1]) {
                '"', '\\', '/' -> { sb.append(n); i += 2 }
                'n' -> { sb.append('\n'); i += 2 }
                'r' -> { sb.append('\r'); i += 2 }
                't' -> { sb.append('\t'); i += 2 }
                'b' -> { sb.append('\b'); i += 2 }
                'f' -> { sb.append('\u000C'); i += 2 }
                'u' -> {
                    if (i + 5 < s.length) {
                        val hex = s.substring(i + 2, i + 6)
                        val cp = runCatching { hex.toInt(16) }.getOrNull()
                        if (cp != null) sb.append(cp.toChar()) else sb.append(n)
                        i += 6
                    } else { sb.append(n); i += 2 }
                }
                else -> { sb.append(n); i += 2 }
            }
        } else {
            sb.append(c); i++
        }
    }
    return sb.toString()
}
