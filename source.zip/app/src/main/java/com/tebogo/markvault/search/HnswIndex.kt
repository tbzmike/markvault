package com.tebogo.markvault.search

import android.content.Context
import android.system.Os
import com.tebogo.markvault.data.NoteDao
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.currentCoroutineContext
import kotlinx.coroutines.ensureActive
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import kotlinx.coroutines.withContext
import java.io.ByteArrayOutputStream
import java.io.DataInputStream
import java.io.DataOutputStream
import java.io.File
import java.io.FileInputStream
import java.io.FileOutputStream
import java.util.UUID
import java.util.concurrent.ConcurrentHashMap

/** Secondary chunk-level HNSW. Full precision embeddings remain in Room. */
class HnswIndex(context: Context) {
    private val directory = context.applicationContext.filesDir
    private val handleLock = Any()
    private var handle = 0L
    private var loadedStats: IndexStats? = null
    @Volatile var isBuilding = false
        private set

    data class IndexStats(
        val modelVersion: String, val dim: Int, val connectivity: Int,
        val numVectors: Int, val buildTimestamp: Long, val embeddingCountAtBuild: Int,
        val embeddingWatermark: Long, val generation: Long, val payloadLength: Long,
        val payloadOffset: Long, val formatVersion: Int = FILE_VERSION
    )

    data class CandidateResult(
        val ids: Set<Long>, val exhaustiveRecovery: Boolean,
        val passageFrontier: Int, val scoredVectors: Long, val elapsedMs: Long,
        val graphNs: Long = 0, val recoveryNs: Long = 0, val preparationMs: Long = 0,
        val graphCpuNs: Long = 0, val sq8: Boolean = false, val graphKernel: Int = 0
    )

    companion object {
        const val FILE_VERSION = 3
        private const val PAGE_SIZE = 256
        private const val MIN_VECTORS = 500
        private val locks = ConcurrentHashMap<String, Mutex>()
        private fun safeKey(model: String) = model.replace(Regex("[^a-zA-Z0-9_-]"), "_")
        fun fileName(model: String) = "ann_hnsw_${safeKey(model)}.bin"
        fun passageKey(noteId: Long, chunkIndex: Int): Long {
            require(noteId in 1..Int.MAX_VALUE.toLong() && chunkIndex >= 0) { "Unsupported passage identity" }
            return (noteId shl 32) or (chunkIndex.toLong() and 0xffffffffL)
        }
        /** Header-only validation is also used before backup restore publishes files. */
        fun readStatsFile(file: File): IndexStats? = runCatching {
            val stream = FileInputStream(file)
            DataInputStream(stream).use { input ->
                val format = input.readInt()
                if (format !in 2..FILE_VERSION) return@use null
                val model = input.readUTF()
                val dim = input.readInt()
                val connectivity = input.readInt()
                val vectors = input.readInt()
                val built = input.readLong()
                val count = input.readInt()
                val watermark = input.readLong()
                val generation = input.readLong()
                val length = input.readLong()
                val offset = stream.channel.position()
                if (model.isBlank() || dim !in 1..2048 || connectivity != 16 || vectors < MIN_VECTORS ||
                    vectors != count || watermark < 0 || length < 1000 || offset + length != file.length() ||
                    file.name != fileName(model)) return@use null
                IndexStats(model, dim, connectivity, vectors, built, count, watermark, generation, length, offset, format)
            }
        }.getOrNull()
    }

    private fun file(model: String) = File(directory, fileName(model))
    private fun mutex(model: String) = locks.getOrPut(file(model).absolutePath) { Mutex() }
    fun stats(model: String): IndexStats? = readStatsFile(file(model))?.takeIf { it.modelVersion == model }
    fun isAvailable(model: String) = NativeHnswBridge.available && stats(model) != null
    fun nativeAvailable() = NativeHnswBridge.available

    fun unload() = synchronized(handleLock) {
        if (handle != 0L) NativeHnswBridge.close(handle)
        handle = 0
        loadedStats = null
    }

    /** Caller holds handleLock. Every use still validates the current snapshot generation. */
    private fun openLocked(stats: IndexStats): Long {
        if (loadedStats?.generation == stats.generation && loadedStats?.modelVersion == stats.modelVersion &&
            stats.formatVersion == FILE_VERSION) return 0
        val started = System.nanoTime()
        unload()
        val opened = NativeHnswBridge.create(stats.dim, 0, false)
        try {
            NativeHnswBridge.open(opened, file(stats.modelVersion).absolutePath, stats.payloadOffset, false)
            check(NativeHnswBridge.size(opened) == stats.numVectors.toLong()) { "HNSW count mismatch" }
        } catch (error: Throwable) {
            NativeHnswBridge.close(opened)
            throw error
        }
        handle = opened
        loadedStats = stats
        if (stats.formatVersion < FILE_VERSION) convertLegacyLocked(stats)
        return (System.nanoTime() - started) / 1_000_000
    }

    /** Caller holds handleLock. Never wait for a builder that may be yielding to this search. */
    private fun convertLegacyLocked(old: IndexStats) {
        val writer = mutex(old.modelVersion)
        if (!writer.tryLock()) return
        var temporary: File? = null
        var converted = 0L
        try {
            if (stats(old.modelVersion)?.generation != old.generation) return
            val length = NativeHnswBridge.serializedLength(handle)
            val generation = UUID.randomUUID().leastSignificantBits
            val built = System.currentTimeMillis()
            val header = ByteArrayOutputStream()
            DataOutputStream(header).use { output ->
                output.writeInt(FILE_VERSION); output.writeUTF(old.modelVersion); output.writeInt(old.dim)
                output.writeInt(old.connectivity); output.writeInt(old.numVectors); output.writeLong(built)
                output.writeInt(old.embeddingCountAtBuild); output.writeLong(old.embeddingWatermark)
                output.writeLong(generation); output.writeLong(length)
            }
            val target = File.createTempFile("hnsw_sq8_", ".tmp", directory)
            temporary = target
            FileOutputStream(target).use { it.write(header.toByteArray()) }
            NativeHnswBridge.append(handle, target.absolutePath)
            FileOutputStream(target, true).use { it.fd.sync() }
            check(target.length() == header.size().toLong() + length) { "SQ8 snapshot length mismatch" }
            // Release the FP16 mapping before preparing SQ8, to avoid keeping both matrices resident.
            unload()
            converted = NativeHnswBridge.create(old.dim, 0, false)
            NativeHnswBridge.open(converted, target.absolutePath, header.size().toLong(), false)
            check(NativeHnswBridge.size(converted) == old.numVectors.toLong()) { "SQ8 count mismatch" }
            Os.rename(target.absolutePath, file(old.modelVersion).absolutePath)
            handle = converted
            converted = 0
            loadedStats = old.copy(buildTimestamp = built, generation = generation, payloadLength = length,
                payloadOffset = header.size().toLong(), formatVersion = FILE_VERSION)
        } catch (error: Exception) {
            android.util.Log.e("HnswIndex", "SQ8 conversion deferred; keeping the complete FP16 snapshot", error)
            if (converted != 0L) {
                NativeHnswBridge.close(converted)
                converted = 0
            }
            if (handle == 0L) {
                val fallback = NativeHnswBridge.create(old.dim, 0, false)
                try {
                    NativeHnswBridge.open(fallback, file(old.modelVersion).absolutePath, old.payloadOffset, false)
                    check(NativeHnswBridge.size(fallback) == old.numVectors.toLong()) { "FP16 count mismatch" }
                    handle = fallback
                    loadedStats = old
                } catch (failure: Throwable) {
                    NativeHnswBridge.close(fallback)
                    throw failure
                }
            }
        } finally {
            if (converted != 0L) NativeHnswBridge.close(converted)
            temporary?.delete()
            writer.unlock()
        }
    }

    /** Prepare the selected model on IO, converting legacy graphs without re-embedding. */
    suspend fun prepare(model: String): Boolean = withContext(Dispatchers.IO) { synchronized(handleLock) {
        if (!NativeHnswBridge.available) return@synchronized false
        val stats = stats(model) ?: return@synchronized false
        try {
            openLocked(stats)
            true
        } catch (error: Exception) {
            android.util.Log.e("HnswIndex", "HNSW preparation failed; search will retry", error)
            unload()
            false
        }
    } }

    suspend fun delete(model: String) = withContext(Dispatchers.IO) {
        mutex(model).withLock {
            unload()
            val target = file(model)
            check(!target.exists() || target.delete()) { "Could not delete HNSW index" }
        }
    }

    /** Ranked unique articles, capped before the existing exact-vector scoring pass. */
    suspend fun findCandidates(query: FloatArray, model: String, articleLimit: Int, allowed: Set<Long>?): Set<Long>? =
        findCandidatesDetailed(query, model, articleLimit, allowed)?.ids

    suspend fun findCandidatesDetailed(query: FloatArray, model: String, articleLimit: Int, allowed: Set<Long>?): CandidateResult? {
        val started = System.nanoTime()
        return withContext(Dispatchers.IO) { synchronized(handleLock) {
            val stats = stats(model) ?: return@synchronized null
            if (stats.dim != query.size || !NativeHnswBridge.available) return@synchronized null
            if (allowed?.isEmpty() == true) return@synchronized CandidateResult(emptySet(), true, 0, 0, 0)
            try {
                val preparationMs = openLocked(stats)
                val target = articleLimit.coerceIn(200, 1200)
                val packet = NativeHnswBridge.findArticles(handle, query, target, minOf(200, target), allowed?.toLongArray())
                check(packet.size in 9..(target + 9) && packet[0] == 4L && packet[1] in 0L..1L &&
                    packet[2] in 0L..minOf(4800, stats.numVectors).toLong() && packet[3] >= 0L &&
                    packet[4] >= 0L && packet[5] >= 0L && packet[6] >= 0L &&
                    packet[7] in setOf(8L, 16L) && packet[8] in 0L..3L) {
                    "Invalid HNSW candidate response"
                }
                val ids = packet.drop(9).toCollection(LinkedHashSet())
                check(ids.size == packet.size - 9 && ids.all { it in 1L..Int.MAX_VALUE.toLong() && (allowed == null || it in allowed) }) {
                    "Invalid HNSW article identity or scope"
                }
                CandidateResult(ids, packet[1] == 1L, packet[2].toInt(), packet[3],
                    (System.nanoTime() - started) / 1_000_000, packet[4], packet[5], preparationMs, packet[6],
                    packet[7] == 8L, packet[8].toInt())
            } catch (error: Exception) {
                android.util.Log.e("HnswIndex", "HNSW lookup failed; using exact search", error)
                unload()
                null
            }
        } }
    }

    suspend fun synchronizeModel(
        dao: NoteDao, model: String, dim: Int, dirtyNoteIds: Set<Long> = emptySet(),
        rebuild: Boolean = false, onProgress: (Float, String) -> Unit = { _, _ -> }
    ): IndexStats = withContext(Dispatchers.IO) {
        mutex(model).withLock {
            check(NativeHnswBridge.available) { "Native HNSW library is unavailable on this device" }
            isBuilding = true
            var working = 0L
            try {
                SearchWorkPriority.awaitIdle()
                val count = dao.embeddingCount(model)
                val watermark = dao.latestEmbeddingCreatedAt(model)
                val old = stats(model)
                if (count < MIN_VECTORS) {
                    unload()
                    file(model).delete()
                    error("At least $MIN_VECTORS embedded chunks are needed")
                }
                if (!rebuild && dirtyNoteIds.isEmpty() && old?.dim == dim &&
                    old.embeddingCountAtBuild == count && old.embeddingWatermark >= watermark) return@withLock old

                var freshBuild = rebuild || old == null || old.dim != dim
                val changedNotes = HashSet<Long>()
                if (!freshBuild) {
                    onProgress(0f, "Checking changed passages…")
                    working = NativeHnswBridge.create(dim, 0, true)
                    NativeHnswBridge.open(working, file(model).absolutePath, old!!.payloadOffset, true)
                    val indexed = NativeHnswBridge.keys(working).apply { sort() }
                    val current = HashSet<Long>(count)
                    var afterNote = 0L
                    var afterChunk = -1
                    while (true) {
                        currentCoroutineContext().ensureActive()
                        SearchWorkPriority.awaitIdle()
                        val page = dao.loadHnswMetadataPage(model, afterNote, afterChunk, 2048)
                        if (page.isEmpty()) break
                        for (row in page) {
                            val key = passageKey(row.noteId, row.chunkIndex)
                            current.add(key)
                            if (row.noteId in dirtyNoteIds || row.createdAt > old.embeddingWatermark || indexed.binarySearch(key) < 0)
                                changedNotes.add(row.noteId)
                        }
                        afterNote = page.last().noteId
                        afterChunk = page.last().chunkIndex
                    }
                    check(current.size == count) { "Embeddings changed while checking HNSW; retry after indexing finishes" }
                    // Large replacements are better served by a clean graph than accumulated tombstones.
                    freshBuild = changedNotes.size > maxOf(1000, count / 8)
                    if (!freshBuild) {
                        for (key in indexed) {
                            currentCoroutineContext().ensureActive()
                            SearchWorkPriority.awaitIdle()
                            if (key !in current || (key ushr 32) in changedNotes) NativeHnswBridge.remove(working, key)
                        }
                        NativeHnswBridge.reserve(working, count)
                        var added = 0
                        for (notes in changedNotes.sorted().chunked(300)) {
                            var offset = 0
                            while (true) {
                                currentCoroutineContext().ensureActive()
                                SearchWorkPriority.awaitIdle()
                                val page = dao.loadHnswChangedVectorsPage(model, notes, PAGE_SIZE, offset)
                                if (page.isEmpty()) break
                                for (row in page) {
                                    SearchWorkPriority.awaitIdle()
                                    NativeHnswBridge.add(working, passageKey(row.noteId, row.chunkIndex), row.vector)
                                }
                                offset += page.size
                                added += page.size
                                onProgress((added.toFloat() / count).coerceAtMost(0.95f), "Updating $added passages…")
                            }
                        }
                    }
                }
                if (freshBuild) {
                    if (working != 0L) NativeHnswBridge.close(working)
                    working = 0
                    working = NativeHnswBridge.create(dim, count, true)
                    var afterNote = 0L
                    var afterChunk = -1
                    var done = 0
                    while (true) {
                        currentCoroutineContext().ensureActive()
                        SearchWorkPriority.awaitIdle()
                        val page = dao.loadHnswVectorsPage(model, afterNote, afterChunk, PAGE_SIZE)
                        if (page.isEmpty()) break
                        for (row in page) {
                            currentCoroutineContext().ensureActive()
                            SearchWorkPriority.awaitIdle()
                            NativeHnswBridge.add(working, passageKey(row.noteId, row.chunkIndex), row.vector)
                        }
                        done += page.size
                        afterNote = page.last().noteId
                        afterChunk = page.last().chunkIndex
                        onProgress((done.toFloat() / count * 0.95f).coerceAtMost(0.95f), "Building HNSW: $done / $count chunks…")
                    }
                }
                currentCoroutineContext().ensureActive()
                check(NativeHnswBridge.size(working) == count.toLong() && dao.embeddingCount(model) == count &&
                    dao.latestEmbeddingCreatedAt(model) == watermark) { "Embeddings changed during HNSW build; retry after indexing finishes" }
                onProgress(0.97f, "Saving HNSW snapshot…")
                save(working, model, dim, count, watermark)
                unload()
                onProgress(1f, "HNSW ready")
                stats(model) ?: error("HNSW snapshot validation failed")
            } finally {
                if (working != 0L) NativeHnswBridge.close(working)
                isBuilding = false
            }
        }
    }

    private suspend fun save(working: Long, model: String, dim: Int, count: Int, watermark: Long) {
        val header = ByteArrayOutputStream()
        DataOutputStream(header).use { output ->
            output.writeInt(FILE_VERSION); output.writeUTF(model); output.writeInt(dim)
            output.writeInt(16); output.writeInt(count); output.writeLong(System.currentTimeMillis())
            output.writeInt(count); output.writeLong(watermark)
            output.writeLong(UUID.randomUUID().leastSignificantBits)
            output.writeLong(NativeHnswBridge.serializedLength(working))
        }
        val temporary = File.createTempFile("hnsw_", ".tmp", directory)
        try {
            FileOutputStream(temporary).use { it.write(header.toByteArray()) }
            NativeHnswBridge.append(working, temporary.absolutePath)
            FileOutputStream(temporary, true).use { it.fd.sync() }
            currentCoroutineContext().ensureActive()
            // Atomic inode replacement: in-flight readers can finish on the old mmap.
            Os.rename(temporary.absolutePath, file(model).absolutePath)
        } finally { temporary.delete() }
    }
}
