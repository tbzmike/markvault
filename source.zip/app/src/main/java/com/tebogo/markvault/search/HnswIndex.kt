package com.tebogo.markvault.search

import android.content.Context
import android.system.Os
import com.tebogo.markvault.data.NoteDao
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.currentCoroutineContext
import kotlinx.coroutines.ensureActive
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import kotlinx.coroutines.withContext
import java.io.ByteArrayOutputStream
import java.io.DataInputStream
import java.io.DataOutputStream
import java.io.File
import java.io.FileInputStream
import java.io.FileOutputStream
import java.util.UUID
import java.util.concurrent.ConcurrentHashMap

/** Secondary chunk-level HNSW. Full precision embeddings remain in Room. */
class HnswIndex(context: Context) {
    private val directory = context.applicationContext.filesDir
    private val handleLock = Any()
    private var handle = 0L
    private var loadedStats: IndexStats? = null
    @Volatile var isBuilding = false
        private set

    data class IndexStats(
        val modelVersion: String, val dim: Int, val connectivity: Int,
        val numVectors: Int, val buildTimestamp: Long, val embeddingCountAtBuild: Int,
        val embeddingWatermark: Long, val generation: Long, val payloadLength: Long,
        val payloadOffset: Long
    )

    companion object {
        const val FILE_VERSION = 2
        private const val PAGE_SIZE = 256
        private const val MIN_VECTORS = 500
        private val locks = ConcurrentHashMap<String, Mutex>()
        private fun safeKey(model: String) = model.replace(Regex("[^a-zA-Z0-9_-]"), "_")
        fun fileName(model: String) = "ann_hnsw_${safeKey(model)}.bin"
        fun passageKey(noteId: Long, chunkIndex: Int): Long {
            require(noteId in 1..Int.MAX_VALUE.toLong() && chunkIndex >= 0) { "Unsupported passage identity" }
            return (noteId shl 32) or (chunkIndex.toLong() and 0xffffffffL)
        }
        /** Header-only validation is also used before backup restore publishes files. */
        fun readStatsFile(file: File): IndexStats? = runCatching {
            val stream = FileInputStream(file)
            DataInputStream(stream).use { input ->
                if (input.readInt() != FILE_VERSION) return@use null
                val model = input.readUTF()
                val dim = input.readInt()
                val connectivity = input.readInt()
                val vectors = input.readInt()
                val built = input.readLong()
                val count = input.readInt()
                val watermark = input.readLong()
                val generation = input.readLong()
                val length = input.readLong()
                val offset = stream.channel.position()
                if (model.isBlank() || dim !in 1..2048 || connectivity != 16 || vectors < MIN_VECTORS ||
                    vectors != count || watermark < 0 || length < 1000 || offset + length != file.length() ||
                    file.name != fileName(model)) return@use null
                IndexStats(model, dim, connectivity, vectors, built, count, watermark, generation, length, offset)
            }
        }.getOrNull()
    }

    private fun file(model: String) = File(directory, fileName(model))
    private fun mutex(model: String) = locks.getOrPut(file(model).absolutePath) { Mutex() }
    fun stats(model: String): IndexStats? = readStatsFile(file(model))?.takeIf { it.modelVersion == model }
    fun isAvailable(model: String) = NativeHnswBridge.available && stats(model) != null
    fun nativeAvailable() = NativeHnswBridge.available

    fun unload() = synchronized(handleLock) {
        if (handle != 0L) NativeHnswBridge.close(handle)
        handle = 0
        loadedStats = null
    }

    suspend fun delete(model: String) = withContext(Dispatchers.IO) {
        mutex(model).withLock {
            unload()
            val target = file(model)
            check(!target.exists() || target.delete()) { "Could not delete HNSW index" }
        }
    }

    /** Ranked unique articles, capped before the existing exact-vector scoring pass. */
    fun findCandidates(query: FloatArray, model: String, articleLimit: Int, allowed: Set<Long>?): Set<Long>? =
        synchronized(handleLock) {
            val stats = stats(model) ?: return@synchronized null
            if (stats.dim != query.size || !NativeHnswBridge.available) return@synchronized null
            try {
                if (loadedStats?.generation != stats.generation || loadedStats?.modelVersion != model) {
                    unload()
                    val opened = NativeHnswBridge.create(stats.dim, 0, false)
                    try {
                        NativeHnswBridge.open(opened, file(model).absolutePath, stats.payloadOffset, false)
                        check(NativeHnswBridge.size(opened) == stats.numVectors.toLong()) { "HNSW count mismatch" }
                    } catch (error: Throwable) {
                        NativeHnswBridge.close(opened)
                        throw error
                    }
                    handle = opened
                    loadedStats = stats
                }
                val target = articleLimit.coerceIn(200, 1200)
                val allowedIds = allowed?.toLongArray()
                var wanted = (target * 2).coerceAtLeast(512).coerceAtMost(stats.numVectors)
                var result: LinkedHashSet<Long>
                do {
                    val keys = NativeHnswBridge.search(handle, query, wanted, allowedIds)
                    result = LinkedHashSet(target)
                    for (key in keys) {
                        result.add(key ushr 32)
                        if (result.size == target) break
                    }
                    if (result.size >= target || wanted >= minOf(stats.numVectors, 4800) || keys.size < wanted) break
                    wanted = (wanted * 2).coerceAtMost(minOf(stats.numVectors, 4800))
                } while (true)
                result
            } catch (error: Exception) {
                android.util.Log.e("HnswIndex", "HNSW lookup failed; using exact search", error)
                unload()
                null
            }
        }

    suspend fun synchronizeModel(
        dao: NoteDao, model: String, dim: Int, dirtyNoteIds: Set<Long> = emptySet(),
        rebuild: Boolean = false, onProgress: (Float, String) -> Unit = { _, _ -> }
    ): IndexStats = withContext(Dispatchers.IO) {
        mutex(model).withLock {
            check(NativeHnswBridge.available) { "Native HNSW library is unavailable on this device" }
            isBuilding = true
            var working = 0L
            try {
                val count = dao.embeddingCount(model)
                val watermark = dao.latestEmbeddingCreatedAt(model)
                val old = stats(model)
                if (count < MIN_VECTORS) {
                    unload()
                    file(model).delete()
                    error("At least $MIN_VECTORS embedded chunks are needed")
                }
                if (!rebuild && dirtyNoteIds.isEmpty() && old?.dim == dim &&
                    old.embeddingCountAtBuild == count && old.embeddingWatermark >= watermark) return@withLock old

                var freshBuild = rebuild || old == null || old.dim != dim
                val changedNotes = HashSet<Long>()
                if (!freshBuild) {
                    onProgress(0f, "Checking changed passages…")
                    working = NativeHnswBridge.create(dim, 0, true)
                    NativeHnswBridge.open(working, file(model).absolutePath, old!!.payloadOffset, true)
                    val indexed = NativeHnswBridge.keys(working).apply { sort() }
                    val current = HashSet<Long>(count)
                    var afterNote = 0L
                    var afterChunk = -1
                    while (true) {
                        currentCoroutineContext().ensureActive()
                        val page = dao.loadHnswMetadataPage(model, afterNote, afterChunk, 2048)
                        if (page.isEmpty()) break
                        for (row in page) {
                            val key = passageKey(row.noteId, row.chunkIndex)
                            current.add(key)
                            if (row.noteId in dirtyNoteIds || row.createdAt > old.embeddingWatermark || indexed.binarySearch(key) < 0)
                                changedNotes.add(row.noteId)
                        }
                        afterNote = page.last().noteId
                        afterChunk = page.last().chunkIndex
                    }
                    check(current.size == count) { "Embeddings changed while checking HNSW; retry after indexing finishes" }
                    // Large replacements are better served by a clean graph than accumulated tombstones.
                    freshBuild = changedNotes.size > maxOf(1000, count / 8)
                    if (!freshBuild) {
                        for (key in indexed) {
                            currentCoroutineContext().ensureActive()
                            if (key !in current || (key ushr 32) in changedNotes) NativeHnswBridge.remove(working, key)
                        }
                        NativeHnswBridge.reserve(working, count)
                        var added = 0
                        for (notes in changedNotes.sorted().chunked(300)) {
                            var offset = 0
                            while (true) {
                                currentCoroutineContext().ensureActive()
                                val page = dao.loadHnswChangedVectorsPage(model, notes, PAGE_SIZE, offset)
                                if (page.isEmpty()) break
                                for (row in page) NativeHnswBridge.add(working, passageKey(row.noteId, row.chunkIndex), row.vector)
                                offset += page.size
                                added += page.size
                                onProgress((added.toFloat() / count).coerceAtMost(0.95f), "Updating $added passages…")
                            }
                        }
                    }
                }
                if (freshBuild) {
                    if (working != 0L) NativeHnswBridge.close(working)
                    working = 0
                    working = NativeHnswBridge.create(dim, count, true)
                    var afterNote = 0L
                    var afterChunk = -1
                    var done = 0
                    while (true) {
                        currentCoroutineContext().ensureActive()
                        val page = dao.loadHnswVectorsPage(model, afterNote, afterChunk, PAGE_SIZE)
                        if (page.isEmpty()) break
                        for (row in page) {
                            currentCoroutineContext().ensureActive()
                            NativeHnswBridge.add(working, passageKey(row.noteId, row.chunkIndex), row.vector)
                        }
                        done += page.size
                        afterNote = page.last().noteId
                        afterChunk = page.last().chunkIndex
                        onProgress((done.toFloat() / count * 0.95f).coerceAtMost(0.95f), "Building HNSW: $done / $count chunks…")
                    }
                }
                currentCoroutineContext().ensureActive()
                check(NativeHnswBridge.size(working) == count.toLong() && dao.embeddingCount(model) == count &&
                    dao.latestEmbeddingCreatedAt(model) == watermark) { "Embeddings changed during HNSW build; retry after indexing finishes" }
                onProgress(0.97f, "Saving HNSW snapshot…")
                save(working, model, dim, count, watermark)
                unload()
                onProgress(1f, "HNSW ready")
                stats(model) ?: error("HNSW snapshot validation failed")
            } finally {
                if (working != 0L) NativeHnswBridge.close(working)
                isBuilding = false
            }
        }
    }

    private suspend fun save(working: Long, model: String, dim: Int, count: Int, watermark: Long) {
        val header = ByteArrayOutputStream()
        DataOutputStream(header).use { output ->
            output.writeInt(FILE_VERSION); output.writeUTF(model); output.writeInt(dim)
            output.writeInt(16); output.writeInt(count); output.writeLong(System.currentTimeMillis())
            output.writeInt(count); output.writeLong(watermark)
            output.writeLong(UUID.randomUUID().leastSignificantBits)
            output.writeLong(NativeHnswBridge.serializedLength(working))
        }
        val temporary = File.createTempFile("hnsw_", ".tmp", directory)
        try {
            FileOutputStream(temporary).use { it.write(header.toByteArray()) }
            NativeHnswBridge.append(working, temporary.absolutePath)
            FileOutputStream(temporary, true).use { it.fd.sync() }
            currentCoroutineContext().ensureActive()
            // Atomic inode replacement: in-flight readers can finish on the old mmap.
            Os.rename(temporary.absolutePath, file(model).absolutePath)
        } finally { temporary.delete() }
    }
}
