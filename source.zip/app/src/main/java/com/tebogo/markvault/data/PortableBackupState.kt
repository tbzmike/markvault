package com.tebogo.markvault.data

import android.database.Cursor
import android.database.sqlite.SQLiteDatabase
import androidx.sqlite.db.SupportSQLiteDatabase
import java.io.DataInputStream
import java.io.DataOutputStream
import java.io.InputStream
import java.io.OutputStream

/**
 * v5.5.51: lossless, streaming transfer of the Room tables that were omitted
 * from the legacy note-only backup, plus note UI state. Requires the same
 * schema (app version); never silently drops a column or embedding model.
 * No threads, observers, caches, or services are created here.
 */
internal object PortableBackupState {
    const val EXTRA_ENTRY = "database/additional_tables.bin"
    const val UI_ENTRY = "library/note_ui.bin"
    private const val MAGIC_EXTRA = 0x4D565831 // MVX1
    private const val MAGIC_UI = 0x4D565531 // MVU1
    private const val VERSION = 1
    private const val MAX_FIELD = 256 * 1024 * 1024
    private val tables = listOf(
        "media_items", "media_embeddings", "playlists", "pdf_page_text",
        "pdf_annotations", "pdf_history", "web_bookmarks", "web_history"
    )

    private fun cols(db: SupportSQLiteDatabase, table: String): List<String> {
        val result = mutableListOf<String>()
        db.query("PRAGMA table_info($table)").use { cursor ->
            while (cursor.moveToNext()) result.add(cursor.getString(1))
        }
        require(result.isNotEmpty()) { "Missing database table: $table" }
        return result
    }

    private fun cols(db: SQLiteDatabase, table: String): List<String> {
        val result = mutableListOf<String>()
        db.rawQuery("PRAGMA table_info($table)", null).use { cursor ->
            while (cursor.moveToNext()) result.add(cursor.getString(1))
        }
        require(result.isNotEmpty()) { "Missing database table: $table" }
        return result
    }

    private fun writeText(out: DataOutputStream, text: String) {
        val b = text.toByteArray(Charsets.UTF_8)
        require(b.size <= MAX_FIELD) { "Database field too long" }
        out.writeInt(b.size)
        out.write(b)
    }
    private fun readText(input: DataInputStream): String {
        val n = input.readInt()
        require(n in 0..MAX_FIELD) { "Invalid database text size" }
        val bytes = ByteArray(n)
        input.readFully(bytes)
        return String(bytes, Charsets.UTF_8)
    }

    private fun writeField(out: DataOutputStream, cursor: Cursor, index: Int) {
        val type = cursor.getType(index)
        out.writeByte(type)
        when (type) {
            Cursor.FIELD_TYPE_NULL -> Unit
            Cursor.FIELD_TYPE_INTEGER -> out.writeLong(cursor.getLong(index))
            Cursor.FIELD_TYPE_FLOAT -> out.writeDouble(cursor.getDouble(index))
            Cursor.FIELD_TYPE_STRING -> writeText(out, cursor.getString(index))
            Cursor.FIELD_TYPE_BLOB -> {
                val bytes = cursor.getBlob(index)
                require(bytes.size <= MAX_FIELD) { "Database blob too large" }
                out.writeInt(bytes.size)
                out.write(bytes)
            }
            else -> error("Unsupported database value type: $type")
        }
    }

    private fun bindField(input: DataInputStream, statement: android.database.sqlite.SQLiteStatement, index: Int) {
        when (val type = input.readUnsignedByte()) {
            Cursor.FIELD_TYPE_NULL -> statement.bindNull(index)
            Cursor.FIELD_TYPE_INTEGER -> statement.bindLong(index, input.readLong())
            Cursor.FIELD_TYPE_FLOAT -> statement.bindDouble(index, input.readDouble())
            Cursor.FIELD_TYPE_STRING -> statement.bindString(index, readText(input))
            Cursor.FIELD_TYPE_BLOB -> {
                val size = input.readInt()
                require(size in 0..MAX_FIELD) { "Invalid database blob size" }
                statement.bindBlob(index, ByteArray(size).also { input.readFully(it) })
            }
            else -> error("Invalid backup database type: $type")
        }
    }

    fun writeExtras(db: SupportSQLiteDatabase, stream: OutputStream, onProgress: (String, Long, Long) -> Unit = { _, _, _ -> }) {
        val out = DataOutputStream(stream)
        out.writeInt(MAGIC_EXTRA)
        out.writeInt(VERSION)
        out.writeInt(tables.size)
        for (table in tables) {
            val columns = cols(db, table)
            writeText(out, table)
            out.writeInt(columns.size)
            columns.forEach { writeText(out, it) }
            var rows = 0L
            db.query("SELECT COUNT(*) FROM $table").use { if (it.moveToFirst()) rows = it.getLong(0) }
            out.writeLong(rows)
            var written = 0L
            onProgress(table, 0, rows)
            db.query("SELECT * FROM $table ORDER BY rowid").use { cursor ->
                while (cursor.moveToNext()) {
                    for (index in columns.indices) writeField(out, cursor, index)
                    written++
                    if (written % 128L == 0L || written == rows) onProgress(table, written, rows)
                }
            }
            require(rows == written) { "Table changed during backup: $table" }
        }
        out.flush()
    }

    private fun requireCompatibleColumns(table: String, backedColumns: List<String>, destinationColumns: List<String>) {
        // Migrations append columns in historical order. The named INSERT
        // binds each value in archive order, independent of destination order.
        require(backedColumns.size == backedColumns.toSet().size &&
            backedColumns.toSet() == destinationColumns.toSet()) {
            "Incompatible database schema for $table (missing: ${destinationColumns.toSet() - backedColumns.toSet()}, unknown: ${backedColumns.toSet() - destinationColumns.toSet()})"
        }
    }

    /** Read the same MVX1 stream before copying large files; no SQL mutations. */
    fun validateExtrasSchema(db: SupportSQLiteDatabase, stream: InputStream,
                             onProgress: (String, Long, Long) -> Unit = { _, _, _ -> }) {
        val input = DataInputStream(stream)
        require(input.readInt() == MAGIC_EXTRA && input.readInt() == VERSION) { "Unsupported additional-database backup" }
        require(input.readInt() == tables.size) { "Backup table count mismatch" }
        val buffer = ByteArray(128 * 1024)
        for (table in tables) {
            require(readText(input) == table) { "Backup table order mismatch" }
            val n = input.readInt()
            require(n in 1..128) { "Invalid backup column count" }
            val columns = (0 until n).map { readText(input) }
            requireCompatibleColumns(table, columns, cols(db, table))
            val rows = input.readLong()
            require(rows in 0..20_000_000L) { "Invalid row count for $table" }
            onProgress(table, 0, rows)
            var row = 0L
            while (row < rows) {
                repeat(n) {
                    val size = when (val type = input.readUnsignedByte()) {
                        Cursor.FIELD_TYPE_NULL -> 0
                        Cursor.FIELD_TYPE_INTEGER, Cursor.FIELD_TYPE_FLOAT -> 8
                        Cursor.FIELD_TYPE_STRING, Cursor.FIELD_TYPE_BLOB -> input.readInt().also {
                            require(it in 0..MAX_FIELD) { "Invalid database field size" }
                        }
                        else -> error("Invalid backup database type: $type")
                    }
                    var left = size
                    while (left > 0) {
                        // Read rather than skip: the enclosing SHA-256 stream
                        // must see every byte, including large BLOB fields.
                        val count = minOf(buffer.size, left)
                        input.readFully(buffer, 0, count)
                        left -= count
                    }
                }
                row++
                if (row % 128L == 0L || row == rows) onProgress(table, row, rows)
            }
        }
        require(input.read() == -1) { "Unexpected additional database bytes" }
    }

    /** Caller owns one database transaction with the restored note streams. */
    fun restoreExtras(db: SQLiteDatabase, stream: InputStream, onProgress: (String, Long, Long) -> Unit = { _, _, _ -> }) {
        val input = DataInputStream(stream)
        require(input.readInt() == MAGIC_EXTRA && input.readInt() == VERSION) {
            "Unsupported additional-database backup"
        }
        require(input.readInt() == tables.size) { "Backup table count mismatch" }
        for (table in tables) db.execSQL("DELETE FROM $table")
        for (expected in tables) {
            val table = readText(input)
            require(table == expected) { "Backup table order mismatch" }
            val n = input.readInt()
            require(n in 1..128) { "Invalid backup column count" }
            val backedColumns = (0 until n).map { readText(input) }
            requireCompatibleColumns(table, backedColumns, cols(db, table))
            val rows = input.readLong()
            require(rows in 0..20_000_000L) { "Invalid row count for $table" }
            val placeholders = (0 until n).joinToString(",") { "?" }
            val names = backedColumns.joinToString(",") { "`$it`" }
            val insert = db.compileStatement("INSERT INTO $table ($names) VALUES ($placeholders)")
            var i = 0L
            onProgress(table, 0, rows)
            while (i < rows) {
                insert.clearBindings()
                for (col in 1..n) bindField(input, insert, col)
                insert.executeInsert()
                i++
                if (i % 128L == 0L || i == rows) onProgress(table, i, rows)
            }
        }
    }

    fun writeNoteUi(db: SupportSQLiteDatabase, stream: OutputStream, onProgress: (Long, Long) -> Unit = { _, _ -> }) {
        val out = DataOutputStream(stream)
        out.writeInt(MAGIC_UI)
        out.writeInt(VERSION)
        var rows = 0L
        db.query("SELECT COUNT(*) FROM notes").use { if (it.moveToFirst()) rows = it.getLong(0) }
        out.writeLong(rows)
        var written = 0L
        onProgress(0, rows)
        db.query("SELECT id,lastOpened,lastScroll,favourite FROM notes ORDER BY id").use { cursor ->
            while (cursor.moveToNext()) {
                out.writeLong(cursor.getLong(0))
                out.writeLong(cursor.getLong(1))
                out.writeInt(cursor.getInt(2))
                out.writeInt(cursor.getInt(3))
                written++
                if (written % 128L == 0L || written == rows) onProgress(written, rows)
            }
        }
        out.flush()
    }

    fun restoreNoteUi(db: SQLiteDatabase, stream: InputStream) {
        val input = DataInputStream(stream)
        require(input.readInt() == MAGIC_UI && input.readInt() == VERSION) {
            "Unsupported note preferences stream"
        }
        val rows = input.readLong()
        require(rows in 0..20_000_000L) { "Invalid note state count" }
        val update = db.compileStatement("UPDATE notes SET lastOpened=?,lastScroll=?,favourite=? WHERE id=?")
        var i = 0L
        while (i < rows) {
            val noteId = input.readLong()
            val opened = input.readLong()
            val scroll = input.readInt()
            val fav = input.readInt()
            update.clearBindings()
            update.bindLong(1, opened)
            update.bindLong(2, scroll.toLong())
            update.bindLong(3, fav.toLong())
            update.bindLong(4, noteId)
            require(update.executeUpdateDelete() == 1) { "Backup note state refers to missing note $noteId" }
            i++
        }
    }
}
