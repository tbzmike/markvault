package com.tebogo.markvault.ai

/** Describes the full T5-base download job: which repo, which files. */
data class T5DownloadDescriptor(
    val id: String = "t5-base-paraphrase",
    val repoId: String = T5ModelCatalog.REPO_ID,
    val files: List<T5ModelCatalog.ModelFile> = T5ModelCatalog.requiredFiles
)
