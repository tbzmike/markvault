package com.tebogo.markvault.ai

/** Metadata used by the T5 model download/install flow. */
data class T5DownloadDescriptor(
    val id: String = "t5-base-paraphrase",
    val version: String = "1.0",
    val fileName: String = "t5-base-paraphrase.model",
    val checksum: String = "",
    val sizeBytes: Long = 0L
)
