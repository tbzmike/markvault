package com.tebogo.markvault.llm

/**
 * v5.5.40 — Small, model-independent streaming buffer for search expansions.
 *
 * Unlike chat, search only needs [target] distinct, validated one-line queries.
 * The native generator can be cancelled *after* the required complete lines
 * have arrived. The caller retains responsibility for LiteRT's callback drain
 * and engine unload; this class does not own native resources.
 */
internal class LlmStreamAccumulator(
    private val target: Int,
    private val parse: (String) -> List<String>,
    private val maxOutputChars: Int = 8192
) {
    private val output = StringBuilder()
    private var completePrefixEnd = -1

    /** Appends a streamed chunk; false means no further tokens are needed. */
    fun appendAndContinue(chunk: String): Boolean {
        if (output.length < maxOutputChars) {
            output.append(chunk, 0, minOf(chunk.length, maxOutputChars - output.length))
        }
        // Do not accept incomplete lines while deciding whether we can
        // terminate native generation early. A partially streamed sentence
        // can pass a lexical relevance test despite not being a full query.
        val newlineAt = output.lastIndexOf("\n")
        if (newlineAt >= 0 && newlineAt + 1 > completePrefixEnd) {
            completePrefixEnd = newlineAt + 1
            if (parse(output.substring(0, completePrefixEnd)).size >= target) return false
        }
        return output.length < maxOutputChars
    }

    /**
     * Normal EOF may end without a newline. On timeout/cancellation, ignore
     * the unfinished trailing line but still return earlier complete queries.
     */
    fun results(completedNormally: Boolean): List<String> =
        parse(if (completedNormally) output.toString() else {
            if (completePrefixEnd > 0) output.substring(0, completePrefixEnd) else ""
        })
}
