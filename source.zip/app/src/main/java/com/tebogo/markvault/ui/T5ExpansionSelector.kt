package com.tebogo.markvault.ui

import com.tebogo.markvault.ai.T5ExpansionMode

/** State model for the expansion selector UI. */
data class T5ExpansionSelector(
    val mode: T5ExpansionMode = T5ExpansionMode.BUILTIN,
    val t5Status: String = "Not installed",
    val t5Selectable: Boolean = false
)
