package com.tebogo.markvault.search

import java.io.File

/**
 * v4.23.0 — Catalog of on-device reranker (cross-encoder) models.
 *
 * Rerankers solve a different problem than embedders: an embedder produces
 * one vector per text, then cosine similarity gives a rough ranking. A
 * reranker takes (query, document) PAIRS and predicts directly how
 * relevant the document is to the query. The two-stage pipeline:
 *
 *   1. Embedder (cheap, applied to every document once at indexing time):
 *      cosine ranks all 14k notes → top 30 candidates per query
 *   2. Reranker (expensive, applied only to candidates at query time):
 *      cross-encoder scores each candidate vs query → final top 10
 *
 * The second stage dramatically improves precision: the model has seen
 * both texts at once and can detect whether the document actually
 * answers the question, not just whether it shares topic words.
 *
 * ## Model choice
 *
 * `ms-marco-MiniLM-L-12-v2` is the de facto industry standard reranker:
 *   - Trained on millions of (query, document, relevant?) judgments from
 *     Microsoft's MS MARCO passage-ranking dataset.
 *   - 12-layer BERT-base architecture. Small (~33 MB quantized).
 *   - The reference for "is this article actually relevant?" tasks.
 *   - Apache 2.0 license, no signup, no licence acceptance.
 *
 * We use the Xenova ONNX export — same publisher whose ONNX exports we
 * already trust for BGE-large.
 */

/**
 * Static description of a reranker model. Mirrors [ModelDescriptor]
 * intentionally; the two could in principle be unified, but keeping them
 * separate keeps the embedder code untouched.
 */
data class RerankerDescriptor(
    /** Stable identifier, e.g. "ms-marco-minilm-l12-v2". */
    val id: String,
    /** Human-readable name shown in Settings. */
    val displayName: String,
    /** Short label (e.g. "MiniLM-L12 reranker"). */
    val shortName: String,
    /** Honest 2–3 sentence description. */
    val description: String,
    /** Where to download the .onnx weights from. */
    val modelUrl: String,
    /** Where to download vocab.txt (BERT WordPiece tokenizer) from. */
    val vocabUrl: String,
    /** Local filename for the model file. */
    val modelFilename: String,
    /** Local filename for the vocab file. */
    val vocabFilename: String,
    /** Approximate model download size in megabytes (for UI). */
    val approxSizeMb: Int,
    /** Approximate RAM footprint once loaded, MB. */
    val approxRamMb: Int,
    /**
     * Maximum sequence length the model accepts (query + doc + special
     * tokens). MiniLM-L-12-v2 is 512.
     */
    val maxSeqLen: Int,
    /** True when this descriptor is offered in the UI. */
    val enabled: Boolean = true
)

object RerankerCatalog {

    /**
     * ms-marco-MiniLM-L-12-v2, quantized ONNX export.
     *
     * Quantization quality loss is minimal: the unquantized model
     * outputs scores like 9.45 / -11.16 for relevant / irrelevant pairs;
     * the quantized model outputs 9.60 / -11.14 for the same pairs.
     * Reranking depends only on relative ordering, not absolute scores,
     * so quantization is the obvious choice (~33 MB vs ~130 MB).
     */
    val MS_MARCO_MINI_LM_L12 = RerankerDescriptor(
        id = "ms-marco-minilm-l12-v2",
        displayName = "MS MARCO MiniLM-L-12 (reranker, quantized)",
        shortName = "MiniLM-L12 reranker",
        description = "A cross-encoder reranker — the industry standard " +
            "for asking 'does THIS document actually answer THIS query?'. " +
            "Re-orders semantic-search candidates so the most relevant " +
            "articles surface first. Trained on millions of search-relevance " +
            "judgments. Apache 2.0 licensed — no signup.",
        modelUrl = "https://huggingface.co/Xenova/ms-marco-MiniLM-L-12-v2/" +
            "resolve/main/onnx/model_quantized.onnx",
        vocabUrl = "https://huggingface.co/Xenova/ms-marco-MiniLM-L-12-v2/" +
            "resolve/main/vocab.txt",
        modelFilename = "ms-marco-minilm-l12-v2.q.onnx",
        vocabFilename = "ms-marco-minilm-l12-v2.vocab.txt",
        approxSizeMb = 33,
        approxRamMb = 150,
        maxSeqLen = 512,
        enabled = true
    )

    val all: List<RerankerDescriptor> = listOf(MS_MARCO_MINI_LM_L12)
    val default: RerankerDescriptor get() = MS_MARCO_MINI_LM_L12

    fun byId(id: String): RerankerDescriptor? = all.firstOrNull { it.id == id }

    /** Plausibility floor — quantized .onnx is ~33 MB so 10 MB is a safe gate. */
    const val MIN_PLAUSIBLE_MODEL_BYTES = 10_000_000L
}

/** Where the reranker model file lives on disk. */
fun RerankerDescriptor.modelFileIn(filesDir: File): File =
    File(filesDir, modelFilename)

/** Where the vocab file lives on disk. */
fun RerankerDescriptor.vocabFileIn(filesDir: File): File =
    File(filesDir, vocabFilename)

/** Whether both files are present and the model file is plausibly big enough. */
fun RerankerDescriptor.isInstalled(filesDir: File): Boolean {
    val m = modelFileIn(filesDir)
    val v = vocabFileIn(filesDir)
    return m.exists() &&
        m.length() > RerankerCatalog.MIN_PLAUSIBLE_MODEL_BYTES &&
        v.exists() && v.length() > 10_000L  // vocab.txt is ~230 KB
}
