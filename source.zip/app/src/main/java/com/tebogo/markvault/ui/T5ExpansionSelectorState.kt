package com.tebogo.markvault.ui

data class T5ExpansionSelectorState(
    val builtinEnabled: Boolean = true,
    val t5Enabled: Boolean = false,
    val status: String = "Not installed"
)
