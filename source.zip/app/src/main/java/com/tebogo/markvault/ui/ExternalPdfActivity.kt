package com.tebogo.markvault.ui

import android.content.Context
import android.net.Uri
import android.os.Bundle
import android.provider.OpenableColumns
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.ui.Modifier
import com.tebogo.markvault.MarkVaultTheme

/**
 * Handles PDFs opened from file managers, email, chat, cloud apps, etc.
 * Registered in AndroidManifest for application/pdf MIME type.
 */
class ExternalPdfActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val uri: Uri? = intent?.data
        val displayTitle = uri?.let { pdfDisplayName(this, it) } ?: "PDF"

        setContent {
            MarkVaultTheme {
                Surface(Modifier.fillMaxSize(), color = MaterialTheme.colorScheme.background) {
                    PdfViewerStandalone(
                        uri = uri,
                        titleHint = displayTitle,
                        onClose = { finish() }
                    )
                }
            }
        }
    }
}

private fun pdfDisplayName(ctx: Context, uri: Uri): String {
    if (uri.scheme == "content") {
        runCatching {
            ctx.contentResolver.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)?.use { c ->
                if (c.moveToFirst()) {
                    val idx = c.getColumnIndex(OpenableColumns.DISPLAY_NAME)
                    if (idx >= 0) return c.getString(idx).removeSuffix(".pdf").removeSuffix(".PDF")
                }
            }
        }
    }
    return uri.lastPathSegment?.substringAfterLast('/')?.removeSuffix(".pdf")?.removeSuffix(".PDF") ?: "PDF"
}
