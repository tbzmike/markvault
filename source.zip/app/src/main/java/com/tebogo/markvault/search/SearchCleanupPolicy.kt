package com.tebogo.markvault.search

/**
 * v5.5.43 — Conservative, testable gate for skipping redundant normal
 * post-search teardown. This deliberately does NOT apply to emergency,
 * explicit-reset, navigation, or process-destruction memory cleanup.
 */
object SearchCleanupPolicy {
    private const val MB = 1024L * 1024L

    fun canSkipRoutineRelease(
        llmLoaded: Boolean,
        t5Loaded: Boolean,
        heapUsed: Long,
        heapMax: Long,
        reusableSearchStack: Boolean,
        systemLowMemory: Boolean,
        availableBytes: Long,
        processPssBytes: Long
    ): Boolean {
        // LiteRT-LM can retain gigabytes of native RAM outside the Java
        // heap; it must continue to unload after a completed search.
        if (llmLoaded || t5Loaded || !reusableSearchStack || systemLowMemory) return false
        if (heapMax <= 0 || heapUsed < 0 || processPssBytes <= 0) return false
        if (heapUsed >= heapMax * 60L / 100L) return false
        // Allow substantial system headroom for article pages, HNSW maps,
        // media decoding, and the next query, independent of Java usage.
        return availableBytes >= 512L * MB && processPssBytes < availableBytes
    }
}
