package com.tebogo.markvault.ai

/**
 * Controls AI multi-query retrieval.
 * Off = normal semantic search + reranking only.
 */
object AiSearchSettings {

    private var enabled = true

    fun setEnabled(value: Boolean) {
        enabled = value
    }

    fun isEnabled(): Boolean = enabled
}
