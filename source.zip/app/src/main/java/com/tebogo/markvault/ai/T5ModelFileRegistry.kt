package com.tebogo.markvault.ai

/** Registry for required T5-base artifact files, sourced from [T5ModelCatalog]. */
object T5ModelFileRegistry {
    val requiredFiles: List<String> = T5ModelCatalog.requiredFiles.map { it.fileName }

    fun missingFiles(existing: Set<String>): List<String> =
        requiredFiles.filterNot { existing.contains(it) }
}
