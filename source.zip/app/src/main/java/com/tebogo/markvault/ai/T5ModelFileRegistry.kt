package com.tebogo.markvault.ai

/** Registry for required T5-base artifact files. */
object T5ModelFileRegistry {
    val requiredFiles = listOf(
        "model.tflite",
        "tokenizer.json",
        "config.json"
    )

    fun missingFiles(existing: Set<String>): List<String> =
        requiredFiles.filterNot { existing.contains(it) }
}
