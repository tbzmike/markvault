package com.tebogo.markvault.web

object ArticleOfflineSaver {

    data class BatchResult(
        val saved: Int,
        val failed: Int
    )

    suspend fun saveArticleBatch(
        urls: List<String>,
        saveSingle: suspend (String) -> Boolean,
        onProgress: (Int, Int) -> Unit = { _, _ -> }
    ): BatchResult {
        var saved = 0
        var failed = 0

        urls.forEachIndexed { index, url ->
            try {
                if (saveSingle(url)) saved++ else failed++
            } catch (_: Exception) {
                failed++
            }
            onProgress(index + 1, urls.size)
        }

        return BatchResult(saved, failed)
    }
}
