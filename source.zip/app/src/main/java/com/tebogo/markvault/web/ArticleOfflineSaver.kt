package com.tebogo.markvault.web

/**
 * Web article extraction/saving coordinator.
 *
 * The WebView supplies detected article URLs. Saving happens off the UI thread.
 */
object ArticleOfflineSaver {

    data class Result(
        val saved: Int,
        val failed: Int
    )

    suspend fun saveArticles(
        urls: List<String>,
        saveHtml: suspend (String) -> Boolean,
        progress: (Int, Int) -> Unit
    ): Result {
        var saved = 0
        var failed = 0

        urls.forEachIndexed { index, url ->
            if (saveHtml(url)) saved++ else failed++
            progress(index + 1, urls.size)
        }

        return Result(saved, failed)
    }
}
