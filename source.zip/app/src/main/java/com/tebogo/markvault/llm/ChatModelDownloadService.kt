package com.tebogo.markvault.llm

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.os.Build
import android.os.IBinder
import android.os.PowerManager
import androidx.core.app.NotificationCompat
import com.tebogo.markvault.MainActivity
import com.tebogo.markvault.R
import com.tebogo.markvault.data.Prefs
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.launch

/**
 * v5.4.72 — Foreground service that owns the chat model download.
 *
 * ## Pause / Resume (v5.4.72)
 *
 * The service now understands [ACTION_PAUSE]. When received:
 *
 *   1. The running download coroutine is cancelled (its `isActive` check
 *      fires on the next read-loop iteration — within milliseconds on any
 *      live connection).
 *   2. The `.part` file is **kept** — [ChatModelDownloader] no longer
 *      deletes it on cancellation.
 *   3. [ChatDownloadProgressBus.pause] is called so the UI transitions to
 *      "paused" state with the last known position preserved.
 *   4. The foreground is removed (`stopForeground(false)`) so the service
 *      can stop but the notification remains visible with a Resume button.
 *
 * When the service is next started (by the user tapping Resume or by a
 * fresh "Install" tap), [ChatModelDownloader.download] automatically detects
 * the existing `.part` file and sends `Range: bytes=N-` to continue.
 *
 * ## Cancellation vs Pause
 *
 * `ACTION_PAUSE` → cancel job, **keep** `.part`, push paused state.
 * `stopService()` from the VM (Cancel button) → cancel job, `.part` is
 * deleted by the **VM** after `stopService()` returns — the service itself
 * does not delete it, so the pause path is safe.
 */
class ChatModelDownloadService : Service() {

    private val serviceScope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
    private var downloadJob: Job? = null
    private var wakeLock: PowerManager.WakeLock? = null

    /**
     * Descriptor of the model currently being downloaded. Set at the top
     * of [runDownload]; used by [onStartCommand] to build the pause
     * notification with the correct model name.
     */
    @Volatile private var currentDescriptor: ChatModelDescriptor? = null

    override fun onCreate() {
        super.onCreate()
        createNotificationChannel()
        val pm = getSystemService(Context.POWER_SERVICE) as PowerManager
        wakeLock = pm.newWakeLock(
            PowerManager.PARTIAL_WAKE_LOCK,
            "MarkVault::ChatModelDownloadWakeLock"
        )
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {

            ACTION_PAUSE -> {
                // User tapped Pause (notification or Settings UI).
                val prog    = ChatDownloadProgressBus.progress.value
                val doneMb  = prog?.first  ?: 0
                val totalMb = prog?.second ?: currentDescriptor?.approxSizeMb ?: 0

                downloadJob?.cancel()
                ChatDownloadProgressBus.pause(doneMb, totalMb)

                // Remove foreground status but KEEP the notification so the
                // user sees the "Paused" card with a Resume button.
                @Suppress("DEPRECATION") stopForeground(false)
                updateNotification(
                    doneMb   = doneMb,
                    totalMb  = totalMb,
                    complete = false,
                    error    = null,
                    modelName = currentDescriptor?.shortName ?: "",
                    paused   = true
                )
                stopSelf()
                return START_NOT_STICKY
            }

            else -> {
                // Normal start (initial download or resume after pause/failure).
                startForeground(
                    NOTIFICATION_ID,
                    buildNotification(
                        doneMb = 0, totalMb = 0,
                        complete = false, error = null, paused = false
                    )
                )

                runCatching {
                    if (wakeLock?.isHeld != true) {
                        wakeLock?.acquire(WAKELOCK_TIMEOUT_MS)
                    }
                }

                // Re-entry guard — ignore duplicate starts while already running.
                if (downloadJob?.isActive == true) {
                    return START_REDELIVER_INTENT
                }

                downloadJob = serviceScope.launch {
                    runDownload()
                    stopSelf()
                }
                return START_REDELIVER_INTENT
            }
        }
    }

    /**
     * Main download loop. Reads the active model from Prefs, delegates to
     * [ChatModelDownloader.download] (which auto-resumes from `.part` if
     * one exists), and pushes progress to [ChatDownloadProgressBus].
     */
    private suspend fun runDownload() {
        val prefs       = Prefs(applicationContext)
        val activeId    = runCatching { prefs.chatActiveModelId.first() }
            .getOrDefault(ChatModelCatalog.default.id)
        val descriptor  = ChatModelCatalog.byId(activeId) ?: ChatModelCatalog.default
        currentDescriptor = descriptor

        // If we're resuming from a .part file, start the bus at the right
        // position so the progress bar jumps to where it left off.
        val resumeBytes = if (ChatModelDownloader.hasResumableDownload(applicationContext, descriptor)) {
            val part = java.io.File(applicationContext.filesDir, "${descriptor.localFilename}.part")
            part.length()
        } else 0L
        val totalMb     = descriptor.approxSizeMb
        val startDoneMb = (resumeBytes / 1_000_000L).toInt().coerceIn(0, totalMb)

        ChatDownloadProgressBus.start()
        ChatDownloadProgressBus.updateProgress(startDoneMb, totalMb)
        updateNotification(startDoneMb, totalMb, complete = false, error = null,
            modelName = descriptor.shortName, paused = false)

        var lastNotificationMs = 0L

        val result = ChatModelDownloader.download(applicationContext, descriptor) { fraction ->
            val doneMb = (fraction * totalMb).toInt().coerceIn(0, totalMb)
            ChatDownloadProgressBus.updateProgress(doneMb, totalMb)

            val now = System.currentTimeMillis()
            if (now - lastNotificationMs >= NOTIFICATION_UPDATE_INTERVAL_MS) {
                lastNotificationMs = now
                updateNotification(
                    doneMb   = doneMb,
                    totalMb  = totalMb,
                    complete = false,
                    error    = null,
                    modelName = descriptor.shortName,
                    paused   = false
                )
            }
        }

        if (result.isSuccess) {
            ChatDownloadProgressBus.complete()
            updateNotification(totalMb, totalMb, complete = true,
                error = null, modelName = descriptor.shortName, paused = false)
        } else {
            val err      = result.exceptionOrNull()
            val isCancel = err is kotlinx.coroutines.CancellationException
            if (isCancel) {
                // This is the coroutine's natural cancellation exit (triggered
                // by ACTION_PAUSE or stopService). The bus has already been
                // updated by the caller (pause → isPaused=true, cancel → idle
                // is called below only if we're NOT in paused state).
                if (!ChatDownloadProgressBus.isPaused.value) {
                    ChatDownloadProgressBus.idle()
                }
            } else {
                // Real failure (SocketException, EOFException, timeout, etc.).
                // The .part file is kept by the downloader so the user can
                // retry without losing progress.
                val msg = err?.message ?: "Download failed for unknown reasons"
                ChatDownloadProgressBus.fail(msg)
                updateNotification(0, totalMb, complete = true,
                    error = msg, modelName = descriptor.shortName, paused = false)
            }
        }
    }

    override fun onDestroy() {
        downloadJob?.cancel()
        serviceScope.cancel()
        runCatching {
            if (wakeLock?.isHeld == true) wakeLock?.release()
        }
        // Only reset to idle if we're genuinely still "running" — a pause has
        // already set isRunning=false, so we must not overwrite it with idle().
        if (ChatDownloadProgressBus.isRunning.value) {
            ChatDownloadProgressBus.idle()
        }
        super.onDestroy()
    }

    override fun onBind(intent: Intent?): IBinder? = null

    // ── Notification ─────────────────────────────────────────────────────

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                CHANNEL_ID,
                "Chat model download",
                NotificationManager.IMPORTANCE_LOW
            ).apply {
                description = "Progress while downloading the on-device chat model"
                setShowBadge(false)
            }
            val nm = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
            nm.createNotificationChannel(channel)
        }
    }

    private fun buildNotification(
        doneMb   : Int,
        totalMb  : Int,
        complete : Boolean,
        error    : String?,
        modelName: String = "",
        paused   : Boolean = false
    ): Notification {
        val openPi = PendingIntent.getActivity(
            this, 0,
            Intent(this, MainActivity::class.java).apply {
                flags = Intent.FLAG_ACTIVITY_SINGLE_TOP or Intent.FLAG_ACTIVITY_CLEAR_TOP
            },
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        val title: String
        val text : String
        when {
            error    != null -> {
                title = "MarkVault — download failed"
                text  = error.take(140)
            }
            complete -> {
                title = "MarkVault — chat model ready"
                text  = if (modelName.isNotBlank()) "$modelName downloaded ($totalMb MB)"
                        else "Chat model downloaded"
            }
            paused -> {
                val pct = if (totalMb > 0) (doneMb * 100 / totalMb).coerceIn(0, 100) else 0
                title = "MarkVault — download paused"
                text  = if (modelName.isNotBlank())
                            "⏸ $doneMb / $totalMb MB ($pct%) — $modelName"
                        else "⏸ $doneMb / $totalMb MB ($pct%)"
            }
            totalMb == 0 -> {
                title = "MarkVault — preparing download"
                text  = "Connecting…"
            }
            else -> {
                val pct = if (totalMb > 0) (doneMb * 100 / totalMb).coerceIn(0, 100) else 0
                title = "MarkVault — downloading chat model"
                text  = if (modelName.isNotBlank())
                            "$doneMb / $totalMb MB ($pct%) — $modelName"
                        else "$doneMb / $totalMb MB ($pct%)"
            }
        }

        val builder = NotificationCompat.Builder(this, CHANNEL_ID)
            .setSmallIcon(R.mipmap.ic_launcher)
            .setContentTitle(title)
            .setContentText(text)
            .setContentIntent(openPi)
            .setOngoing(!complete && error == null && !paused)
            .setOnlyAlertOnce(true)
            .setPriority(NotificationCompat.PRIORITY_LOW)
            .setCategory(NotificationCompat.CATEGORY_PROGRESS)

        when {
            paused -> {
                // Show progress bar at paused position + Resume action.
                if (totalMb > 0) builder.setProgress(totalMb, doneMb, false)
                val resumePi = PendingIntent.getService(
                    this, REQUEST_RESUME,
                    Intent(this, ChatModelDownloadService::class.java),
                    PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
                )
                builder.addAction(
                    android.R.drawable.ic_media_play, "Resume", resumePi
                )
            }
            !complete && error == null && totalMb > 0 -> {
                // Active download — show progress bar + Pause action.
                builder.setProgress(totalMb, doneMb, false)
                val pausePi = PendingIntent.getService(
                    this, REQUEST_PAUSE,
                    Intent(this, ChatModelDownloadService::class.java)
                        .setAction(ACTION_PAUSE),
                    PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
                )
                builder.addAction(
                    android.R.drawable.ic_media_pause, "Pause", pausePi
                )
            }
            !complete && error == null -> {
                // Indeterminate (connecting stage).
                builder.setProgress(0, 0, true)
            }
        }

        return builder.build()
    }

    private fun updateNotification(
        doneMb   : Int, totalMb  : Int, complete : Boolean,
        error    : String?, modelName: String, paused: Boolean
    ) {
        val nm = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        nm.notify(NOTIFICATION_ID,
            buildNotification(doneMb, totalMb, complete, error, modelName, paused))
    }

    companion object {
        /** Intent action: pause the in-progress download and keep the .part file. */
        const val ACTION_PAUSE = "com.tebogo.markvault.action.CHAT_DOWNLOAD_PAUSE"

        private const val CHANNEL_ID    = "markvault_chat_model_download"
        private const val NOTIFICATION_ID = 4816
        private const val REQUEST_PAUSE   = 10
        private const val REQUEST_RESUME  = 11
        private const val NOTIFICATION_UPDATE_INTERVAL_MS = 500L

        // 2-hour wakelock. The 0.6B model (~400 MB) finishes in ~15–30 min;
        // the 1.5B model (~1,600 MB) can take ~70 min at 3 Mbps.
        private const val WAKELOCK_TIMEOUT_MS = 2L * 60L * 60L * 1000L
    }
}
