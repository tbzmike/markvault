package com.tebogo.markvault.llm

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.os.Build
import android.os.IBinder
import android.os.PowerManager
import androidx.core.app.NotificationCompat
import com.tebogo.markvault.MainActivity
import com.tebogo.markvault.R
import com.tebogo.markvault.data.Prefs
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.launch

/**
 * v4.21.0 — Foreground service that owns the chat model download.
 *
 * Mirrors the design of [com.tebogo.markvault.search.EmbeddingService]:
 *
 *   - **Foreground type `dataSync`** — declared in the manifest. Tells
 *     Android this is important user-perceived work, keep me alive.
 *   - **Partial wake lock** — `MarkVault::ChatModelDownloadWakeLock`,
 *     released in `onDestroy`. 1-hour timeout safety net.
 *   - **Sticky notification** with progress — survives screen-off, shows
 *     percentage and MB / total MB.
 *   - **Bus writes** — pushes progress to [ChatDownloadProgressBus] which
 *     the AppViewModel observes for in-app UI.
 *   - **Coroutine cancellation** — scope cancel in onDestroy propagates
 *     through to the download loop, which checks `coroutineContext.isActive`
 *     each ~32 KB chunk.
 *
 * # Lifecycle
 *
 *  - `startForegroundService(intent)` → `onCreate` → `onStartCommand`
 *  - `onStartCommand` calls `startForeground()` (must, within 5s) then
 *    launches the download coroutine.
 *  - Coroutine completes → `stopSelf()` → `onDestroy` cleans up.
 *  - Or user cancels → `stopService(intent)` → `onDestroy` cancels the
 *    coroutine + releases resources.
 *
 * # Why single-instance
 *
 * The service re-entry guard prevents two concurrent downloads of the
 * same model. If `startService` is called while a download is in
 * progress, the duplicate is ignored.
 */
class ChatModelDownloadService : Service() {

    private val serviceScope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
    private var downloadJob: Job? = null
    private var wakeLock: PowerManager.WakeLock? = null

    override fun onCreate() {
        super.onCreate()
        createNotificationChannel()
        val pm = getSystemService(Context.POWER_SERVICE) as PowerManager
        wakeLock = pm.newWakeLock(
            PowerManager.PARTIAL_WAKE_LOCK,
            "MarkVault::ChatModelDownloadWakeLock"
        )
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        // Required within 5–10 seconds of startForegroundService(). The
        // download coroutine overwrites this with real progress quickly.
        startForeground(
            NOTIFICATION_ID,
            buildNotification(doneMb = 0, totalMb = 0, complete = false, error = null)
        )

        runCatching {
            if (wakeLock?.isHeld != true) {
                wakeLock?.acquire(WAKELOCK_TIMEOUT_MS)
            }
        }

        // Re-entry guard — ignore duplicate starts.
        if (downloadJob?.isActive == true) {
            return START_REDELIVER_INTENT
        }

        downloadJob = serviceScope.launch {
            runDownload()
            // Tell the OS we're done; onDestroy releases the wake lock
            // and removes the notification.
            stopSelf()
        }
        return START_REDELIVER_INTENT
    }

    /**
     * Actual download work. Picks the active chat model from Prefs,
     * downloads it via [ChatModelDownloader], pushes byte progress to
     * [ChatDownloadProgressBus] and to the notification (throttled).
     */
    private suspend fun runDownload() {
        val prefs = Prefs(applicationContext)
        val activeId = runCatching { prefs.chatActiveModelId.first() }
            .getOrDefault(ChatModelCatalog.default.id)
        val descriptor = ChatModelCatalog.byId(activeId) ?: ChatModelCatalog.default

        ChatDownloadProgressBus.start()
        val totalMb = descriptor.approxSizeMb
        ChatDownloadProgressBus.updateProgress(0, totalMb)
        updateNotification(0, totalMb, complete = false, error = null, modelName = descriptor.shortName)

        var lastNotificationMs = 0L

        val result = ChatModelDownloader.download(
            applicationContext,
            descriptor
        ) { fraction ->
            // Translate 0.0–1.0 fraction into doneMb / totalMb. Use the
            // descriptor's approxSizeMb as the denominator so the bar moves
            // smoothly even if Content-Length came back larger or smaller
            // than expected.
            val doneMb = (fraction * totalMb).toInt().coerceIn(0, totalMb)
            ChatDownloadProgressBus.updateProgress(doneMb, totalMb)

            // Throttle notification updates — the system rate-limits posts
            // and updating too aggressively wastes CPU.
            val now = System.currentTimeMillis()
            if (now - lastNotificationMs >= NOTIFICATION_UPDATE_INTERVAL_MS) {
                lastNotificationMs = now
                updateNotification(doneMb, totalMb, complete = false,
                    error = null, modelName = descriptor.shortName)
            }
        }

        if (result.isSuccess) {
            ChatDownloadProgressBus.complete()
            updateNotification(totalMb, totalMb, complete = true,
                error = null, modelName = descriptor.shortName)
        } else {
            val err = result.exceptionOrNull()
            // Cancellation isn't a "real" failure — the user (or system)
            // asked us to stop. Don't show a failure notification.
            val isCancel = err is kotlinx.coroutines.CancellationException
            if (isCancel) {
                ChatDownloadProgressBus.idle()
            } else {
                val msg = err?.message ?: "Download failed for unknown reasons"
                ChatDownloadProgressBus.fail(msg)
                updateNotification(0, totalMb, complete = true,
                    error = msg, modelName = descriptor.shortName)
            }
        }
    }

    override fun onDestroy() {
        downloadJob?.cancel()
        serviceScope.cancel()
        runCatching {
            if (wakeLock?.isHeld == true) wakeLock?.release()
        }
        // Don't override a failure state with idle() — failure messages
        // need to persist past the service stopping so the user sees
        // why it failed. Only flip to idle if we're still mid-run.
        if (ChatDownloadProgressBus.isRunning.value) {
            ChatDownloadProgressBus.idle()
        }
        super.onDestroy()
    }

    /** Not a bound service — return null. */
    override fun onBind(intent: Intent?): IBinder? = null

    // ── Notification plumbing ───────────────────────────────────────────

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                CHANNEL_ID,
                "Chat model download",
                NotificationManager.IMPORTANCE_LOW   // no sound for progress
            ).apply {
                description = "Progress while downloading the on-device chat model"
                setShowBadge(false)
            }
            val nm = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
            nm.createNotificationChannel(channel)
        }
    }

    private fun buildNotification(
        doneMb: Int,
        totalMb: Int,
        complete: Boolean,
        error: String?,
        modelName: String = ""
    ): Notification {
        val openIntent = Intent(this, MainActivity::class.java).apply {
            flags = Intent.FLAG_ACTIVITY_SINGLE_TOP or Intent.FLAG_ACTIVITY_CLEAR_TOP
        }
        val pi = PendingIntent.getActivity(
            this, 0, openIntent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        val title: String
        val text: String
        when {
            error != null -> {
                title = "MarkVault — chat model download failed"
                text = error.take(140)
            }
            complete -> {
                title = "MarkVault — chat model ready"
                text = if (modelName.isNotBlank())
                    "$modelName downloaded ($totalMb MB)"
                else
                    "Chat model downloaded"
            }
            totalMb == 0 -> {
                title = "MarkVault — preparing download"
                text = "Connecting…"
            }
            else -> {
                val pct = if (totalMb > 0) (doneMb * 100 / totalMb).coerceIn(0, 100) else 0
                title = "MarkVault — downloading chat model"
                text = if (modelName.isNotBlank())
                    "$doneMb of $totalMb MB ($pct%) — $modelName"
                else
                    "$doneMb of $totalMb MB ($pct%)"
            }
        }

        val builder = NotificationCompat.Builder(this, CHANNEL_ID)
            .setSmallIcon(R.mipmap.ic_launcher)
            .setContentTitle(title)
            .setContentText(text)
            .setContentIntent(pi)
            .setOngoing(!complete && error == null)
            .setOnlyAlertOnce(true)
            .setPriority(NotificationCompat.PRIORITY_LOW)
            .setCategory(NotificationCompat.CATEGORY_PROGRESS)

        if (!complete && error == null && totalMb > 0) {
            builder.setProgress(totalMb, doneMb, false)
        } else if (!complete && error == null) {
            // Indeterminate progress for the "preparing" stage
            builder.setProgress(0, 0, true)
        }

        return builder.build()
    }

    /** Posts an updated notification using the same channel + ID. */
    private fun updateNotification(
        doneMb: Int, totalMb: Int, complete: Boolean,
        error: String?, modelName: String
    ) {
        val nm = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        nm.notify(NOTIFICATION_ID, buildNotification(doneMb, totalMb, complete, error, modelName))
    }

    companion object {
        private const val CHANNEL_ID = "markvault_chat_model_download"
        private const val NOTIFICATION_ID = 4816   // EmbeddingService uses 4815
        private const val NOTIFICATION_UPDATE_INTERVAL_MS = 500L
        // 1-hour wakelock safety net. 530 MB on average mobile broadband
        // takes ~15–30 minutes; an hour is generous backstop.
        private const val WAKELOCK_TIMEOUT_MS = 60L * 60L * 1000L
    }
}
