package com.tebogo.markvault.ui

import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items as lazyItems
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Checkbox
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Tab
import androidx.compose.material3.TabRow
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import kotlinx.coroutines.launch

/**
 * v5.4.46 — "Talk to the Article" dialog with two switchable modes:
 *
 *   Mode 0 — **Ask AI**: feeds the current article to the on-device
 *            LLM (Qwen 3 or SmolLM2) and streams the answer in this
 *            dialog. Tapping the "Find in Article" button highlights
 *            the relevant passage inline with a flashing light-blue.
 *
 *   Mode 1 — **Semantic Search**: uses the BGE-large embedder to find the
 *            top-5 most relevant passages in the article. Tapping a result
 *            highlights it inline with a flashing light-blue.
 *
 * ## v5.4.46 changes:
 *   - Article title displayed prominently in the header
 *   - "Ask AI" label (model-agnostic) replaces "Ask Gemma"
 *   - Refresh / Retry button appears after an error or timeout
 *   - 50-second UI timeout: if onAskGemma hasn't returned in 50s the
 *     UI shows a "Taking too long — Retry?" state instead of spinning
 *     forever. The ViewModel's 45s timeout fires first normally; this
 *     is a safety net for edge cases.
 *   - Button disabled while busy to prevent double-tap
 */
@Composable
fun ArticleSemanticSearchDialog(
    articleText: String,
    articleTitle: String,
    chatModelInstalled: Boolean,
    onDismiss: () -> Unit,
    onHighlightSnippet: (snippet: String, query: String) -> Unit,
    onPerformSemanticSearch: suspend (text: String, query: String) -> List<String>?,
    onAskGemma: suspend (articleText: String, question: String) -> String?,
    onExtractHighlight: suspend (articleText: String, question: String) -> String?
) {
    var selectedTab by remember { mutableIntStateOf(if (chatModelInstalled) 0 else 1) }
    var query by remember { mutableStateOf("") }
    var useFullContent by remember { mutableStateOf(true) }

    var semanticResults by remember { mutableStateOf<List<String>?>(null) }
    var gemmaAnswer by remember { mutableStateOf<String?>(null) }
    var answerIsError by remember { mutableStateOf(false) }
    // Tab 3 state: the extracted passage (null = not run yet, "" = no match found)
    var highlightPassage by remember { mutableStateOf<String?>(null) }
    var highlightDone by remember { mutableStateOf(false) }

    var busy by remember { mutableStateOf(false) }
    val scope = rememberCoroutineScope()
    var watchdogJob by remember { mutableStateOf<kotlinx.coroutines.Job?>(null) }

    Dialog(
        onDismissRequest = onDismiss,
        properties = androidx.compose.ui.window.DialogProperties(
            usePlatformDefaultWidth = false,
            dismissOnClickOutside = true
        )
    ) {
        Surface(
            modifier = Modifier.fillMaxWidth(0.95f).padding(16.dp),
            color = MaterialTheme.colorScheme.surface,
            shape = MaterialTheme.shapes.large,
            tonalElevation = 16.dp
        ) {
            Column(
                modifier = Modifier.padding(20.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                // ── Header ──────────────────────────────────────────
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text("💭 Talk to the Article", fontSize = 18.sp, fontWeight = FontWeight.Bold)
                        Spacer(Modifier.height(2.dp))
                        Text(
                            "📄 $articleTitle",
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Medium,
                            color = MaterialTheme.colorScheme.primary,
                            maxLines = 2,
                            overflow = TextOverflow.Ellipsis
                        )
                    }
                    IconButton(onClick = onDismiss, modifier = Modifier.size(32.dp)) {
                        Icon(Icons.Default.Close, "Close", modifier = Modifier.size(20.dp))
                    }
                }

                // ── Three tabs ──────────────────────────────────────
                TabRow(
                    selectedTabIndex = selectedTab,
                    modifier = Modifier.fillMaxWidth().clip(RoundedCornerShape(8.dp))
                ) {
                    Tab(
                        selected = selectedTab == 0,
                        onClick = { selectedTab = 0; semanticResults = null; highlightPassage = null; highlightDone = false },
                        text = { Text("🧠 Ask AI", fontSize = 11.sp) }
                    )
                    Tab(
                        selected = selectedTab == 1,
                        onClick = { selectedTab = 1; gemmaAnswer = null; answerIsError = false; highlightPassage = null; highlightDone = false },
                        text = { Text("🔍 Semantic", fontSize = 11.sp) }
                    )
                    Tab(
                        selected = selectedTab == 2,
                        onClick = { selectedTab = 2; gemmaAnswer = null; answerIsError = false; semanticResults = null; highlightPassage = null; highlightDone = false },
                        text = { Text("📌 Find", fontSize = 11.sp) }
                    )
                }

                HorizontalDivider()

                // ── Tab 2 description ───────────────────────────────
                if (selectedTab == 2) {
                    Text(
                        "AI locates the exact sentence in this article that answers your question, then highlights it directly. No generated words — only original article text.",
                        fontSize = 11.sp,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        lineHeight = 15.sp
                    )
                }

                // ── Query input ─────────────────────────────────────
                OutlinedTextField(
                    value = query,
                    onValueChange = { query = it },
                    label = {
                        Text(
                            when (selectedTab) {
                                0 -> "Ask a question about this article..."
                                2 -> "What do you want to find in this article?"
                                else -> "Search this article semantically..."
                            }
                        )
                    },
                    modifier = Modifier.fillMaxWidth(),
                    enabled = !busy,
                    singleLine = true,
                    leadingIcon = { Icon(Icons.Default.Search, null) }
                )

                if (selectedTab != 2) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Checkbox(checked = useFullContent, onCheckedChange = { useFullContent = it }, enabled = !busy)
                        Text("Search full article (not just visible text)", fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                }

                // ── Action button ───────────────────────────────────
                Button(
                    onClick = {
                        watchdogJob?.cancel()
                        scope.launch {
                            busy = true
                            answerIsError = false
                            highlightDone = false

                            val timeoutMs = if (selectedTab == 2) 40_000L else 55_000L
                            watchdogJob = scope.launch {
                                kotlinx.coroutines.delay(timeoutMs)
                                if (busy) {
                                    busy = false
                                    when (selectedTab) {
                                        0 -> { gemmaAnswer = "⏱ Timed out. Try a simpler question."; answerIsError = true }
                                        2 -> { highlightPassage = ""; highlightDone = true }
                                        else -> {}
                                    }
                                }
                            }

                            try {
                                when (selectedTab) {
                                    0 -> {
                                        gemmaAnswer = null
                                        val result = onAskGemma(articleText, query.trim())
                                        if (busy) {
                                            gemmaAnswer = result
                                            answerIsError = result != null && (
                                                result.startsWith("⏱") || result.startsWith("Error:") ||
                                                result.startsWith("⚠️") || result.startsWith("Model not loaded") ||
                                                result.startsWith("Please enter")
                                            )
                                        }
                                    }
                                    1 -> {
                                        semanticResults = null
                                        semanticResults = onPerformSemanticSearch(articleText, query.trim())
                                    }
                                    2 -> {
                                        // Find & Highlight: get exact passage then immediately highlight
                                        highlightPassage = null
                                        val passage = onExtractHighlight(articleText, query.trim())
                                        if (busy) {
                                            highlightPassage = passage ?: ""
                                            highlightDone = true
                                            if (!passage.isNullOrBlank()) {
                                                // Auto-highlight and dismiss — the result IS in the article
                                                onHighlightSnippet(passage, query.trim())
                                                onDismiss()
                                            }
                                        }
                                    }
                                }
                            } catch (e: Exception) {
                                gemmaAnswer = "Error: ${e.message ?: "Unknown error"}"
                                answerIsError = true
                            } finally {
                                watchdogJob?.cancel()
                                watchdogJob = null
                                busy = false
                            }
                        }
                    },
                    modifier = Modifier.fillMaxWidth(),
                    enabled = !busy && query.trim().length >= 2 &&
                        (selectedTab == 1 || chatModelInstalled),
                    colors = ButtonDefaults.buttonColors(
                        containerColor = when (selectedTab) {
                            0 -> Color(0xFF4A90D9)
                            2 -> Color(0xFF2E7D32)
                            else -> MaterialTheme.colorScheme.primary
                        }
                    )
                ) {
                    if (busy) {
                        CircularProgressIndicator(modifier = Modifier.size(20.dp), color = MaterialTheme.colorScheme.onPrimary, strokeWidth = 2.dp)
                        Spacer(Modifier.width(8.dp))
                        Text(if (selectedTab == 2) "Locating…" else "Thinking…", fontSize = 13.sp)
                    } else {
                        Text(when (selectedTab) { 0 -> "Ask AI"; 2 -> "Find & Highlight"; else -> "Search" })
                    }
                }

                if ((selectedTab == 0 || selectedTab == 2) && !chatModelInstalled) {
                    Text("⚠️ Chat model not installed. Go to Settings → On-device chat to install.", fontSize = 11.sp, color = MaterialTheme.colorScheme.error)
                }

                // ── Results ─────────────────────────────────────────

                // Tab 0: AI answer
                if (selectedTab == 0 && gemmaAnswer != null) {
                    HorizontalDivider()
                    Text(if (answerIsError) "⚠️ Problem:" else "🧠 AI Answer:", fontSize = 12.sp, fontWeight = FontWeight.SemiBold, color = if (answerIsError) MaterialTheme.colorScheme.error else MaterialTheme.colorScheme.onSurface)
                    Surface(modifier = Modifier.fillMaxWidth().heightIn(max = 250.dp), color = if (answerIsError) Color(0xFFFCE4EC) else Color(0xFFE3F2FD), shape = MaterialTheme.shapes.small) {
                        Column(modifier = Modifier.padding(12.dp).verticalScroll(rememberScrollState())) {
                            Text(gemmaAnswer ?: "", fontSize = 12.sp, lineHeight = 16.sp)
                            Spacer(Modifier.height(8.dp))
                            if (answerIsError) {
                                Button(onClick = {
                                    scope.launch {
                                        busy = true; answerIsError = false; gemmaAnswer = null
                                        val result = onAskGemma(articleText, query.trim())
                                        gemmaAnswer = result
                                        answerIsError = result != null && (result.startsWith("⏱") || result.startsWith("Error:") || result.startsWith("⚠️") || result.startsWith("Model not loaded"))
                                        busy = false
                                    }
                                }, modifier = Modifier.fillMaxWidth(), colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.error)) {
                                    Text("🔄 Retry", fontSize = 12.sp)
                                }
                            } else {
                                Button(onClick = {
                                    val ans = gemmaAnswer ?: return@Button
                                    val first = ans.split(Regex("[.!?]")).firstOrNull { it.trim().length > 15 }?.trim() ?: ans.take(60)
                                    onHighlightSnippet(first, query); onDismiss()
                                }, modifier = Modifier.fillMaxWidth(), colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF90CAF9))) {
                                    Text("📌 Find in Article", fontSize = 12.sp)
                                }
                            }
                        }
                    }
                }

                // Tab 1: Semantic results
                if (selectedTab == 1 && semanticResults != null) {
                    HorizontalDivider()
                    Text("Matching passages (${semanticResults?.size ?: 0} found)", fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
                    if (semanticResults.isNullOrEmpty()) {
                        Box(modifier = Modifier.fillMaxWidth().padding(24.dp), contentAlignment = Alignment.Center) {
                            Text("No matches found", fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        }
                    } else {
                        LazyColumn(modifier = Modifier.fillMaxWidth().heightIn(max = 220.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                            lazyItems(semanticResults ?: emptyList()) { snippet ->
                                Surface(modifier = Modifier.fillMaxWidth().padding(horizontal = 4.dp), color = Color(0xFFE3F2FD), shape = MaterialTheme.shapes.small, onClick = { onHighlightSnippet(snippet, query); onDismiss() }) {
                                    Text(snippet, modifier = Modifier.padding(12.dp), fontSize = 11.sp, lineHeight = 14.sp)
                                }
                            }
                        }
                    }
                }

                // Tab 2: Find & Highlight result (only shown when onDismiss didn't fire — e.g. no match)
                if (selectedTab == 2 && highlightDone && highlightPassage?.isEmpty() == true) {
                    HorizontalDivider()
                    Box(modifier = Modifier.fillMaxWidth().padding(vertical = 12.dp), contentAlignment = Alignment.Center) {
                        Text(
                            "No matching passage found in this article for your question.",
                            fontSize = 12.sp,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                            lineHeight = 16.sp
                        )
                    }
                }
            }
        }
    }
}
    var selectedTab by remember { mutableIntStateOf(if (chatModelInstalled) 0 else 1) }
    var query by remember { mutableStateOf("") }
    var useFullContent by remember { mutableStateOf(true) }

    // Semantic search state
    var semanticResults by remember { mutableStateOf<List<String>?>(null) }

    // AI answer state
    var gemmaAnswer by remember { mutableStateOf<String?>(null) }
    var answerIsError by remember { mutableStateOf(false) }

    var busy by remember { mutableStateOf(false) }
    val scope = rememberCoroutineScope()

    // v5.4.56 — UI-level watchdog. LiteRT-LM's C++ inference thread
    // cannot be interrupted by Kotlin coroutine cancellation — the thread
    // physically runs native code with no suspension points during prefill.
    // This means the 45-second withTimeout in askGemmaAboutArticle may
    // never fire. Track elapsed time in the UI and force-reset busy after
    // 55 seconds so the dialog never stays stuck on "Thinking…" forever.
    var watchdogJob by remember { mutableStateOf<kotlinx.coroutines.Job?>(null) }

    Dialog(
        onDismissRequest = onDismiss,
        properties = androidx.compose.ui.window.DialogProperties(
            usePlatformDefaultWidth = false,
            dismissOnClickOutside = true
        )
    ) {
        Surface(
            modifier = Modifier
                .fillMaxWidth(0.95f)
                .padding(16.dp),
            color = MaterialTheme.colorScheme.surface,
            shape = MaterialTheme.shapes.large,
            tonalElevation = 16.dp
        ) {
            Column(
                modifier = Modifier.padding(20.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                // ── Header with article title ───────────────────────
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            "💭 Talk to the Article",
                            fontSize = 18.sp,
                            fontWeight = FontWeight.Bold
                        )
                        Spacer(Modifier.height(2.dp))
                        Text(
                            "📄 $articleTitle",
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Medium,
                            color = MaterialTheme.colorScheme.primary,
                            maxLines = 2,
                            overflow = TextOverflow.Ellipsis
                        )
                    }
                    IconButton(onClick = onDismiss, modifier = Modifier.size(32.dp)) {
                        Icon(Icons.Default.Close, "Close", modifier = Modifier.size(20.dp))
                    }
                }

                // ── Mode tabs ───────────────────────────────────────
                TabRow(
                    selectedTabIndex = selectedTab,
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(8.dp))
                ) {
                    Tab(
                        selected = selectedTab == 0,
                        onClick = {
                            selectedTab = 0
                            semanticResults = null
                        },
                        text = { Text("🧠 Ask AI", fontSize = 12.sp) }
                    )
                    Tab(
                        selected = selectedTab == 1,
                        onClick = {
                            selectedTab = 1
                            gemmaAnswer = null
                            answerIsError = false
                        },
                        text = { Text("🔍 Semantic", fontSize = 12.sp) }
                    )
                }

                HorizontalDivider()

                // ── Query input ─────────────────────────────────────
                OutlinedTextField(
                    value = query,
                    onValueChange = { query = it },
                    label = {
                        Text(
                            if (selectedTab == 0) "Ask a question about this article..."
                            else "Search this article semantically..."
                        )
                    },
                    modifier = Modifier.fillMaxWidth(),
                    enabled = !busy,
                    singleLine = true,
                    leadingIcon = { Icon(Icons.Default.Search, null) }
                )

                // ── Scope toggle (both modes) ───────────────────────
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Checkbox(
                        checked = useFullContent,
                        onCheckedChange = { useFullContent = it },
                        enabled = !busy
                    )
                    Text(
                        "Search full article (not just visible text)",
                        fontSize = 12.sp,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }

                // ── Action button ───────────────────────────────────
                Button(
                    onClick = {
                        // Cancel any in-flight watchdog from a previous tap
                        watchdogJob?.cancel()
                        scope.launch {
                            busy = true
                            answerIsError = false

                            // Start UI-level watchdog. If the job takes
                            // longer than 55 s, force-reset to unblock the UI.
                            // The ViewModel's 45 s timeout should fire first
                            // under normal conditions; this is the safety net
                            // for when LiteRT-LM's C++ thread can't be
                            // interrupted.
                            watchdogJob = scope.launch {
                                kotlinx.coroutines.delay(55_000L)
                                if (busy) {
                                    busy = false
                                    gemmaAnswer = "⏱ Timed out — the model took too long. " +
                                        "Try a simpler question or switch to SmolLM2 in Settings."
                                    answerIsError = true
                                }
                            }

                            try {
                                if (selectedTab == 0) {
                                    // Ask AI
                                    gemmaAnswer = null
                                    val result = onAskGemma(articleText, query.trim())
                                    // Only update if watchdog hasn't already written
                                    if (busy) {
                                        gemmaAnswer = result
                                        answerIsError = result != null && (
                                            result.startsWith("⏱") ||
                                            result.startsWith("Error:") ||
                                            result.startsWith("⚠️") ||
                                            result.startsWith("Model not loaded") ||
                                            result.startsWith("Please enter")
                                        )
                                    }
                                } else {
                                    // Semantic search
                                    semanticResults = null
                                    semanticResults = onPerformSemanticSearch(articleText, query.trim())
                                }
                            } catch (e: Exception) {
                                // Safety catch — askGemmaAboutArticle should
                                // never throw, but guard against any edge case
                                gemmaAnswer = "Error: ${e.message ?: "Unknown error"}"
                                answerIsError = true
                            } finally {
                                // ALWAYS reset busy, even if the watchdog fired
                                // or an exception was thrown
                                watchdogJob?.cancel()
                                watchdogJob = null
                                busy = false
                            }
                        }
                    },
                    modifier = Modifier.fillMaxWidth(),
                    enabled = !busy && query.trim().length >= 2 &&
                        (selectedTab == 1 || chatModelInstalled),
                    colors = ButtonDefaults.buttonColors(
                        containerColor = if (selectedTab == 0)
                            Color(0xFF4A90D9)
                        else
                            MaterialTheme.colorScheme.primary
                    )
                ) {
                    if (busy) {
                        CircularProgressIndicator(
                            modifier = Modifier.size(20.dp),
                            color = MaterialTheme.colorScheme.onPrimary,
                            strokeWidth = 2.dp
                        )
                        Spacer(Modifier.width(8.dp))
                        Text("Thinking…", fontSize = 13.sp)
                    } else {
                        Text(
                            if (selectedTab == 0) "Ask AI" else "Search"
                        )
                    }
                }

                // Model not installed warning
                if (selectedTab == 0 && !chatModelInstalled) {
                    Text(
                        "⚠️ Chat model not installed. Go to Settings → On-device chat to install.",
                        fontSize = 11.sp,
                        color = MaterialTheme.colorScheme.error
                    )
                }

                // ── Results area ────────────────────────────────────
                if (selectedTab == 0 && gemmaAnswer != null) {
                    // AI answer display
                    HorizontalDivider()
                    Text(
                        if (answerIsError) "⚠️ Problem:" else "🧠 AI Answer:",
                        fontSize = 12.sp,
                        fontWeight = FontWeight.SemiBold,
                        color = if (answerIsError) MaterialTheme.colorScheme.error
                                else MaterialTheme.colorScheme.onSurface
                    )
                    Surface(
                        modifier = Modifier
                            .fillMaxWidth()
                            .heightIn(max = 250.dp),
                        color = if (answerIsError) Color(0xFFFCE4EC) else Color(0xFFE3F2FD),
                        shape = MaterialTheme.shapes.small
                    ) {
                        Column(
                            modifier = Modifier
                                .padding(12.dp)
                                .verticalScroll(rememberScrollState())
                        ) {
                            Text(
                                gemmaAnswer ?: "",
                                fontSize = 12.sp,
                                lineHeight = 16.sp
                            )
                            Spacer(Modifier.height(8.dp))
                            if (answerIsError) {
                                // ── Retry button for errors/timeouts ────
                                Button(
                                    onClick = {
                                        scope.launch {
                                            busy = true
                                            answerIsError = false
                                            gemmaAnswer = null
                                            val result = onAskGemma(articleText, query.trim())
                                            gemmaAnswer = result
                                            answerIsError = result != null && (
                                                result.startsWith("⏱") ||
                                                result.startsWith("Error:") ||
                                                result.startsWith("⚠️") ||
                                                result.startsWith("Model not loaded")
                                            )
                                            busy = false
                                        }
                                    },
                                    modifier = Modifier.fillMaxWidth(),
                                    colors = ButtonDefaults.buttonColors(
                                        containerColor = MaterialTheme.colorScheme.error
                                    )
                                ) {
                                    Text("🔄 Retry", fontSize = 12.sp)
                                }
                            } else {
                                // Tap to highlight key sentence from answer
                                Button(
                                    onClick = {
                                        // Extract first sentence of answer for highlighting
                                        val ans = gemmaAnswer ?: return@Button
                                        val firstSentence = ans.split(Regex("[.!?]"))
                                            .firstOrNull { it.trim().length > 15 }
                                            ?.trim() ?: ans.take(60)
                                        onHighlightSnippet(firstSentence, query)
                                        onDismiss()
                                    },
                                    modifier = Modifier.fillMaxWidth(),
                                    colors = ButtonDefaults.buttonColors(
                                        containerColor = Color(0xFF90CAF9)
                                    )
                                ) {
                                    Text("📌 Find in Article", fontSize = 12.sp)
                                }
                            }
                        }
                    }
                }

                if (selectedTab == 1) {
                    // Semantic search results
                    if (semanticResults != null) {
                        HorizontalDivider()
                        Text(
                            "Matching passages (${semanticResults?.size ?: 0} found)",
                            fontSize = 12.sp,
                            fontWeight = FontWeight.SemiBold
                        )

                        if (semanticResults.isNullOrEmpty()) {
                            Box(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(24.dp),
                                contentAlignment = Alignment.Center
                            ) {
                                Text(
                                    "No matches found",
                                    fontSize = 12.sp,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }
                        } else {
                            LazyColumn(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .heightIn(max = 220.dp),
                                verticalArrangement = Arrangement.spacedBy(8.dp)
                            ) {
                                lazyItems(semanticResults ?: emptyList()) { snippet ->
                                    Surface(
                                        modifier = Modifier
                                            .fillMaxWidth()
                                            .padding(horizontal = 4.dp),
                                        color = Color(0xFFE3F2FD),
                                        shape = MaterialTheme.shapes.small,
                                        onClick = {
                                            onHighlightSnippet(snippet, query)
                                            onDismiss()
                                        }
                                    ) {
                                        Text(
                                            snippet,
                                            modifier = Modifier.padding(12.dp),
                                            fontSize = 11.sp,
                                            lineHeight = 14.sp
                                        )
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}
