package com.tebogo.markvault.ui

import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items as lazyItems
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Checkbox
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Tab
import androidx.compose.material3.TabRow
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import kotlinx.coroutines.launch

/**
 * v5.4.40 — "Talk to the Article" dialog with two switchable modes:
 *
 *   Mode 0 — **Ask Gemma**: feeds the current article to the on-device
 *            Gemma LLM and streams the answer in this dialog. Tapping
 *            a key phrase highlights it inline with a flashing light-blue.
 *
 *   Mode 1 — **Semantic Search**: uses the BGE-large embedder to find the
 *            top-5 most relevant passages in the article. Tapping a result
 *            highlights it inline with a flashing light-blue.
 *
 * Both modes highlight with a distinctive light-blue flash so the user can
 * immediately spot the relevant passage in the article.
 */
@Composable
fun ArticleSemanticSearchDialog(
    articleText: String,
    articleTitle: String,
    chatModelInstalled: Boolean,
    onDismiss: () -> Unit,
    onHighlightSnippet: (snippet: String, query: String) -> Unit,
    onPerformSemanticSearch: suspend (text: String, query: String) -> List<String>?,
    onAskGemma: suspend (articleText: String, question: String) -> String?
) {
    var selectedTab by remember { mutableIntStateOf(if (chatModelInstalled) 0 else 1) }
    var query by remember { mutableStateOf("") }
    var useFullContent by remember { mutableStateOf(true) }

    // Semantic search state
    var semanticResults by remember { mutableStateOf<List<String>?>(null) }

    // Gemma state
    var gemmaAnswer by remember { mutableStateOf<String?>(null) }

    var busy by remember { mutableStateOf(false) }
    val scope = rememberCoroutineScope()

    Dialog(
        onDismissRequest = onDismiss,
        properties = androidx.compose.ui.window.DialogProperties(
            usePlatformDefaultWidth = false,
            dismissOnClickOutside = true
        )
    ) {
        Surface(
            modifier = Modifier
                .fillMaxWidth(0.95f)
                .padding(16.dp),
            color = MaterialTheme.colorScheme.surface,
            shape = MaterialTheme.shapes.large,
            tonalElevation = 16.dp
        ) {
            Column(
                modifier = Modifier.padding(20.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                // ── Header ──────────────────────────────────────────
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            "💭 Talk to the Article",
                            fontSize = 18.sp,
                            fontWeight = FontWeight.Bold
                        )
                        Text(
                            articleTitle,
                            fontSize = 11.sp,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis
                        )
                    }
                    IconButton(onClick = onDismiss, modifier = Modifier.size(32.dp)) {
                        Icon(Icons.Default.Close, "Close", modifier = Modifier.size(20.dp))
                    }
                }

                // ── Mode tabs ───────────────────────────────────────
                TabRow(
                    selectedTabIndex = selectedTab,
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(8.dp))
                ) {
                    Tab(
                        selected = selectedTab == 0,
                        onClick = {
                            selectedTab = 0
                            semanticResults = null
                        },
                        text = { Text("🧠 Ask Gemma", fontSize = 12.sp) }
                    )
                    Tab(
                        selected = selectedTab == 1,
                        onClick = {
                            selectedTab = 1
                            gemmaAnswer = null
                        },
                        text = { Text("🔍 Semantic", fontSize = 12.sp) }
                    )
                }

                HorizontalDivider()

                // ── Query input ─────────────────────────────────────
                OutlinedTextField(
                    value = query,
                    onValueChange = { query = it },
                    label = {
                        Text(
                            if (selectedTab == 0) "Ask a question about this article..."
                            else "Search this article semantically..."
                        )
                    },
                    modifier = Modifier.fillMaxWidth(),
                    enabled = !busy,
                    singleLine = true,
                    leadingIcon = { Icon(Icons.Default.Search, null) }
                )

                // ── Scope toggle (both modes) ───────────────────────
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Checkbox(
                        checked = useFullContent,
                        onCheckedChange = { useFullContent = it },
                        enabled = !busy
                    )
                    Text(
                        "Search full article (not just visible text)",
                        fontSize = 12.sp,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }

                // ── Action button ───────────────────────────────────
                Button(
                    onClick = {
                        scope.launch {
                            busy = true
                            if (selectedTab == 0) {
                                // Ask Gemma
                                gemmaAnswer = null
                                gemmaAnswer = onAskGemma(articleText, query.trim())
                            } else {
                                // Semantic search
                                semanticResults = null
                                semanticResults = onPerformSemanticSearch(articleText, query.trim())
                            }
                            busy = false
                        }
                    },
                    modifier = Modifier.fillMaxWidth(),
                    enabled = !busy && query.trim().length >= 2 &&
                        (selectedTab == 1 || chatModelInstalled),
                    colors = ButtonDefaults.buttonColors(
                        containerColor = if (selectedTab == 0)
                            Color(0xFF4A90D9)
                        else
                            MaterialTheme.colorScheme.primary
                    )
                ) {
                    if (busy) {
                        CircularProgressIndicator(
                            modifier = Modifier.size(20.dp),
                            color = MaterialTheme.colorScheme.onPrimary,
                            strokeWidth = 2.dp
                        )
                    } else {
                        Text(
                            if (selectedTab == 0) "Ask Gemma" else "Search"
                        )
                    }
                }

                // Model not installed warning
                if (selectedTab == 0 && !chatModelInstalled) {
                    Text(
                        "⚠️ Gemma model not installed. Go to Settings → On-device chat to install.",
                        fontSize = 11.sp,
                        color = MaterialTheme.colorScheme.error
                    )
                }

                // ── Results area ────────────────────────────────────
                if (selectedTab == 0 && gemmaAnswer != null) {
                    // Gemma answer display
                    HorizontalDivider()
                    Text(
                        "🧠 Gemma's Answer:",
                        fontSize = 12.sp,
                        fontWeight = FontWeight.SemiBold
                    )
                    Surface(
                        modifier = Modifier
                            .fillMaxWidth()
                            .heightIn(max = 250.dp),
                        color = Color(0xFFE3F2FD),
                        shape = MaterialTheme.shapes.small
                    ) {
                        Column(
                            modifier = Modifier
                                .padding(12.dp)
                                .verticalScroll(rememberScrollState())
                        ) {
                            Text(
                                gemmaAnswer ?: "",
                                fontSize = 12.sp,
                                lineHeight = 16.sp
                            )
                            Spacer(Modifier.height(8.dp))
                            // Tap to highlight key sentence from answer
                            Button(
                                onClick = {
                                    // Extract first sentence of Gemma answer for highlighting
                                    val ans = gemmaAnswer ?: return@Button
                                    val firstSentence = ans.split(Regex("[.!?]"))
                                        .firstOrNull { it.trim().length > 15 }
                                        ?.trim() ?: ans.take(60)
                                    onHighlightSnippet(firstSentence, query)
                                    onDismiss()
                                },
                                modifier = Modifier.fillMaxWidth(),
                                colors = ButtonDefaults.buttonColors(
                                    containerColor = Color(0xFF90CAF9)
                                )
                            ) {
                                Text("📌 Find in Article", fontSize = 12.sp)
                            }
                        }
                    }
                }

                if (selectedTab == 1) {
                    // Semantic search results
                    if (semanticResults != null) {
                        HorizontalDivider()
                        Text(
                            "Matching passages (${semanticResults?.size ?: 0} found)",
                            fontSize = 12.sp,
                            fontWeight = FontWeight.SemiBold
                        )

                        if (semanticResults.isNullOrEmpty()) {
                            Box(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(24.dp),
                                contentAlignment = Alignment.Center
                            ) {
                                Text(
                                    "No matches found",
                                    fontSize = 12.sp,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }
                        } else {
                            LazyColumn(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .heightIn(max = 220.dp),
                                verticalArrangement = Arrangement.spacedBy(8.dp)
                            ) {
                                lazyItems(semanticResults ?: emptyList()) { snippet ->
                                    Surface(
                                        modifier = Modifier
                                            .fillMaxWidth()
                                            .padding(horizontal = 4.dp),
                                        color = Color(0xFFE3F2FD),
                                        shape = MaterialTheme.shapes.small,
                                        onClick = {
                                            onHighlightSnippet(snippet, query)
                                            onDismiss()
                                        }
                                    ) {
                                        Text(
                                            snippet,
                                            modifier = Modifier.padding(12.dp),
                                            fontSize = 11.sp,
                                            lineHeight = 14.sp
                                        )
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}
