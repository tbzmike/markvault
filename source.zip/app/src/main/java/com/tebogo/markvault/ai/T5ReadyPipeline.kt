package com.tebogo.markvault.ai

object T5ReadyPipeline {
    fun isReady(): Boolean {
        return T5ModelInstallStateStore.get() == T5ModelInstallState.READY
    }
}
