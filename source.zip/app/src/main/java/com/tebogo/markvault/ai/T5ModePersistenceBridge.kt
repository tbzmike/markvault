package com.tebogo.markvault.ai

/** Connects stored expansion preference with runtime selection. */
object T5ModePersistenceBridge {
    fun currentMode(): T5ExpansionMode {
        return when (T5PersistentModeStore.load()) {
            T5PersistentMode.BUILTIN -> T5ExpansionMode.BUILTIN
            T5PersistentMode.T5_BASE -> T5ExpansionMode.T5_BASE
        }
    }
}
