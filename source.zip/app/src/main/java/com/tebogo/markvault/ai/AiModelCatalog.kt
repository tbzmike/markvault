package com.tebogo.markvault.ai

data class LocalModelInfo(
    val name: String,
    val size: String,
    val installed: Boolean
)

object AiModelCatalog {
    private val models = listOf(
        LocalModelInfo(
            "Gemma 3 Qwen 0.6B",
            "Installed local retrieval model",
            true
        )
    )

    fun models(): List<LocalModelInfo> = models
}
