package com.tebogo.markvault.ai

/** Bridge from T5 expansion into the existing retrieval pipeline. */
object T5RetrievalBridge {
    fun route(expandedQueries: List<String>): List<String> {
        return expandedQueries
    }
}
