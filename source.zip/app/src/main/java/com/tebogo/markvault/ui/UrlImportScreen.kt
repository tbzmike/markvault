package com.tebogo.markvault.ui

import android.annotation.SuppressLint
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.activity.compose.BackHandler
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material3.Button
import androidx.compose.material3.Checkbox
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import com.tebogo.markvault.AppViewModel
import com.tebogo.markvault.SaveResult
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import org.json.JSONObject

/**
 * Screen that turns a shared web URL into a markdown file inside the user's vault.
 *
 * Engine: Mozilla Readability (article detection) + Turndown (HTML→Markdown). Both
 * libraries are bundled as offline assets and loaded into the hidden WebView before
 * we run our extractor.
 *
 * Flow:
 *   1. Render the URL in a hidden, JS-enabled WebView so client-side content fills in.
 *   2. Wait 1.5s for late-loading JS to settle.
 *   3. Inject Readability.js, turndown.js, and our extractor (html-to-markdown.js).
 *   4. Call MV.extract(); it returns title, url, siteName, byline, excerpt, body.
 *   5. Show the four toggleable sections (front-matter, URL, excerpt, body) in the
 *      preview, with checkboxes that the user can flip to control what's saved.
 *   6. User taps Save → write the assembled markdown into <library>/<subfolder>/<title>.md.
 */
@OptIn(ExperimentalMaterial3Api::class)
@SuppressLint("SetJavaScriptEnabled")
@Composable
fun UrlImportScreen(
    vm: AppViewModel,
    url: String,
    onClose: () -> Unit
) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    val subfolder by vm.importsSubfolder.collectAsState()
    val incFront by vm.includeFrontmatter.collectAsState()
    val incUrl by vm.includeUrl.collectAsState()
    val incExcerpt by vm.includeExcerpt.collectAsState()
    val incBody by vm.includeBody.collectAsState()

    var stage by remember { mutableStateOf(Stage.LOADING) }
    var extracted by remember { mutableStateOf<Extracted?>(null) }
    var warning by remember { mutableStateOf<String?>(null) }
    var errorMsg by remember { mutableStateOf<String?>(null) }
    var saveMsg by remember { mutableStateOf<String?>(null) }
    var showSubfolderSheet by remember { mutableStateOf(false) }

    val library = vm.libraryUri.collectAsState().value
    val hasLibrary = !library.isNullOrBlank()

    val title = extracted?.title ?: "Importing\u2026"
    val previewMarkdown = remember(extracted, incFront, incUrl, incExcerpt, incBody) {
        extracted?.let {
            assembleMarkdown(it, incFront, incUrl, incExcerpt, incBody)
        } ?: ""
    }

    BackHandler(enabled = stage == Stage.PREVIEW) { onClose() }

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Text(title, maxLines = 1, overflow = TextOverflow.Ellipsis, fontSize = 16.sp)
                },
                navigationIcon = {
                    IconButton(onClick = onClose) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Close")
                    }
                }
            )
        }
    ) { pad ->
        Column(Modifier.padding(pad).fillMaxSize().padding(horizontal = 16.dp)) {

            // --- Source URL row -------------------------------------------------
            Surface(
                color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.4f),
                shape = RoundedCornerShape(10.dp),
                modifier = Modifier.fillMaxWidth().padding(top = 8.dp)
            ) {
                Column(Modifier.padding(horizontal = 14.dp, vertical = 10.dp)) {
                    Text(
                        "\uD83C\uDF10 Source",
                        fontSize = 11.sp, fontWeight = FontWeight.SemiBold,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                    Spacer(Modifier.height(2.dp))
                    Text(
                        url, fontSize = 12.sp, maxLines = 2, overflow = TextOverflow.Ellipsis,
                        fontFamily = FontFamily.Monospace
                    )
                }
            }
            Spacer(Modifier.height(12.dp))

            // --- Body switches by stage ----------------------------------------
            when (stage) {
                Stage.LOADING -> Box(
                    Modifier.fillMaxWidth().weight(1f),
                    contentAlignment = Alignment.Center
                ) {
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        CircularProgressIndicator()
                        Spacer(Modifier.height(16.dp))
                        Text("Loading the page\u2026", color = MaterialTheme.colorScheme.onSurfaceVariant)
                        Spacer(Modifier.height(4.dp))
                        Text(
                            "Reading content then converting to markdown.",
                            fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }

                Stage.PREVIEW -> Column(Modifier.fillMaxWidth().weight(1f)) {
                    if (warning != null) {
                        Surface(
                            color = MaterialTheme.colorScheme.errorContainer.copy(alpha = 0.5f),
                            shape = RoundedCornerShape(8.dp),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Text(
                                "\u26A0\uFE0F  " + warning,
                                Modifier.padding(12.dp),
                                fontSize = 12.sp,
                                color = MaterialTheme.colorScheme.onErrorContainer
                            )
                        }
                        Spacer(Modifier.height(10.dp))
                    }

                    // Include-toggles row (matches markdownr UX)
                    Surface(
                        color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.3f),
                        shape = RoundedCornerShape(8.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Column(Modifier.padding(horizontal = 8.dp, vertical = 4.dp)) {
                            ToggleRow("Include front matter", incFront) { vm.setIncludeFrontmatter(it) }
                            ToggleRow("Include URL in content", incUrl) { vm.setIncludeUrl(it) }
                            ToggleRow("Include excerpt", incExcerpt) { vm.setIncludeExcerpt(it) }
                            ToggleRow("Include body", incBody) { vm.setIncludeBody(it) }
                        }
                    }
                    Spacer(Modifier.height(8.dp))

                    Text(
                        "Preview",
                        fontSize = 11.sp, fontWeight = FontWeight.SemiBold,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                    Spacer(Modifier.height(4.dp))
                    Surface(
                        color = MaterialTheme.colorScheme.surface,
                        shape = RoundedCornerShape(10.dp),
                        modifier = Modifier.fillMaxWidth().weight(1f)
                    ) {
                        Column(
                            Modifier.fillMaxSize().padding(12.dp)
                                .verticalScroll(rememberScrollState())
                        ) {
                            Text(
                                previewMarkdown.ifBlank { "(nothing selected to include)" },
                                fontSize = 12.sp,
                                fontFamily = FontFamily.Monospace,
                                lineHeight = 17.sp
                            )
                        }
                    }
                }

                Stage.ERROR -> Box(
                    Modifier.fillMaxWidth().weight(1f),
                    contentAlignment = Alignment.Center
                ) {
                    Column(Modifier.padding(20.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                        Text(
                            "Couldn\u2019t convert this page",
                            fontWeight = FontWeight.SemiBold, fontSize = 16.sp
                        )
                        Spacer(Modifier.height(8.dp))
                        Text(
                            errorMsg ?: "Unknown error.",
                            fontSize = 13.sp,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }
            }

            // --- Bottom action bar ---------------------------------------------
            if (stage == Stage.PREVIEW) {
                HorizontalDivider(
                    color = MaterialTheme.colorScheme.surfaceVariant,
                    modifier = Modifier.padding(vertical = 8.dp)
                )
                if (saveMsg != null) {
                    Text(
                        saveMsg!!, fontSize = 12.sp,
                        color = MaterialTheme.colorScheme.primary,
                        modifier = Modifier.padding(bottom = 6.dp)
                    )
                }
                Row(
                    Modifier.fillMaxWidth().padding(bottom = 12.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        "Folder:  " + if (subfolder.isBlank()) "Library root" else subfolder,
                        fontSize = 12.sp,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        modifier = Modifier.weight(1f).clickable { showSubfolderSheet = true }
                    )
                    OutlinedButton(onClick = { showSubfolderSheet = true }) {
                        Text("Change", fontSize = 12.sp)
                    }
                    Spacer(Modifier.width(8.dp))
                    Button(
                        enabled = hasLibrary && previewMarkdown.isNotBlank(),
                        onClick = {
                            scope.launch {
                                val r = vm.saveImportedMarkdown(
                                    title = extracted?.title ?: "Untitled",
                                    markdown = previewMarkdown,
                                    subfolder = subfolder
                                )
                                saveMsg = when (r) {
                                    is SaveResult.Ok -> {
                                        val where = if (r.subfolder.isBlank()) "library root" else r.subfolder
                                        "\u2705 Saved as \u201C${r.fileName}\u201D in $where"
                                    }
                                    is SaveResult.Error -> "\u26A0\uFE0F " + r.message
                                }
                            }
                        }
                    ) { Text("Save to vault") }
                }
                if (!hasLibrary) {
                    Text(
                        "Pick a library folder in Settings first.",
                        fontSize = 11.sp,
                        color = MaterialTheme.colorScheme.error,
                        modifier = Modifier.padding(bottom = 10.dp)
                    )
                }
            }
        }
    }

    // --- Hidden WebView that loads the URL, then runs the extractor ----------
    if (stage == Stage.LOADING) {
        Box(Modifier.size(1.dp)) {
            AndroidView<WebView>(
                modifier = Modifier.size(1.dp),
                factory = { c ->
                    WebView(c).apply {
                        settings.javaScriptEnabled = true
                        settings.domStorageEnabled = true
                        settings.loadsImagesAutomatically = true
                        settings.mediaPlaybackRequiresUserGesture = true
                        settings.mixedContentMode = WebSettings.MIXED_CONTENT_NEVER_ALLOW
                        // Real-browser User-Agent so sites don't serve a stripped page.
                        val defaultUa = settings.userAgentString
                        settings.userAgentString = if (defaultUa.isNullOrBlank()) {
                            "Mozilla/5.0 (Linux; Android) AppleWebKit/537.36 " +
                                "(KHTML, like Gecko) Chrome/120.0.0.0 Mobile Safari/537.36"
                        } else {
                            defaultUa.replace("; wv)", ")")
                        }
                        var consumed = false
                        setWebViewClient(object : WebViewClient() {
                            override fun onPageFinished(view: WebView?, finishedUrl: String?) {
                                if (view == null || consumed) return
                                consumed = true
                                scope.launch {
                                    delay(1500)  // let late JS render
                                    runExtraction(view, ctx) { result ->
                                        when (result) {
                                            is ExtractResult.Ok -> {
                                                extracted = result.data
                                                warning = result.data.warning
                                                stage = Stage.PREVIEW
                                            }
                                            is ExtractResult.Err -> {
                                                errorMsg = result.message
                                                stage = Stage.ERROR
                                            }
                                        }
                                    }
                                }
                            }
                            override fun onReceivedError(
                                view: WebView?,
                                request: android.webkit.WebResourceRequest?,
                                error: android.webkit.WebResourceError?
                            ) {
                                if (request?.isForMainFrame == true && !consumed) {
                                    consumed = true
                                    errorMsg = "Failed to load: " +
                                        (error?.description ?: "network error")
                                    stage = Stage.ERROR
                                }
                            }
                        })
                        loadUrl(url)
                    }
                }
            )
        }
    }

    // --- Subfolder editor sheet -----------------------------------------------
    if (showSubfolderSheet) {
        SubfolderEditorSheet(
            current = subfolder,
            onSave = { newVal ->
                vm.setImportsSubfolder(newVal)
                showSubfolderSheet = false
            },
            onCancel = { showSubfolderSheet = false }
        )
    }
}

// ---- Local types -----------------------------------------------------------

/** A single row with a checkbox and label. */
@Composable
private fun ToggleRow(label: String, checked: Boolean, onCheckedChange: (Boolean) -> Unit) {
    Row(
        Modifier.fillMaxWidth().clickable { onCheckedChange(!checked) }
            .padding(vertical = 2.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Checkbox(checked = checked, onCheckedChange = onCheckedChange)
        Text(label, fontSize = 13.sp)
    }
}

private enum class Stage { LOADING, PREVIEW, ERROR }

/** Decoded JSON result from MV.extract() — what we actually got back from the page. */
private data class Extracted(
    val title: String,
    val url: String,
    val siteName: String,
    val byline: String,
    val excerpt: String,
    val body: String,
    val warning: String?
)

private sealed class ExtractResult {
    data class Ok(val data: Extracted) : ExtractResult()
    data class Err(val message: String) : ExtractResult()
}

/**
 * Build the final markdown by concatenating the selected parts.
 *  - Front matter: YAML block at the top with title/source/date/byline/excerpt
 *  - URL line:     italic "*Source: <url>*" line (kept even without front matter)
 *  - Excerpt:      blockquote
 *  - Body:         the converted article
 */
private fun assembleMarkdown(
    e: Extracted,
    includeFrontmatter: Boolean,
    includeUrl: Boolean,
    includeExcerpt: Boolean,
    includeBody: Boolean
): String {
    val sb = StringBuilder()
    val today = java.text.SimpleDateFormat("yyyy-MM-dd", java.util.Locale.US)
        .format(java.util.Date())

    if (includeFrontmatter) {
        sb.append("---\n")
        sb.append("title: ").append(yamlScalar(e.title)).append('\n')
        if (e.url.isNotBlank()) sb.append("source: ").append(yamlScalar(e.url)).append('\n')
        if (e.siteName.isNotBlank()) sb.append("site: ").append(yamlScalar(e.siteName)).append('\n')
        if (e.byline.isNotBlank()) sb.append("author: ").append(yamlScalar(e.byline)).append('\n')
        sb.append("date: ").append(today).append('\n')
        if (e.excerpt.isNotBlank()) sb.append("excerpt: ").append(yamlScalar(e.excerpt)).append('\n')
        sb.append("---\n\n")
    }

    sb.append("# ").append(e.title).append("\n\n")

    if (includeUrl && e.url.isNotBlank()) {
        sb.append("*Source: ").append(e.url).append("*\n")
        sb.append("*Imported: ").append(today).append("*\n\n")
    }

    if (includeExcerpt && e.excerpt.isNotBlank()) {
        e.excerpt.split('\n').forEach { line ->
            sb.append("> ").append(line).append('\n')
        }
        sb.append('\n')
    }

    if (includeBody && e.body.isNotBlank()) {
        if (includeUrl || includeExcerpt || includeFrontmatter) sb.append("---\n\n")
        sb.append(e.body).append('\n')
    }

    return sb.toString().replace(Regex("\n{3,}"), "\n\n").trim() + "\n"
}

/** Quote a YAML scalar safely (handles colons, quotes, newlines). */
private fun yamlScalar(s: String): String {
    val flat = s.replace('\n', ' ').replace('\r', ' ').trim()
    return "\"" + flat.replace("\\", "\\\\").replace("\"", "\\\"") + "\""
}

/**
 * Load Readability + Turndown + our extractor into the WebView in sequence, then call
 * MV.extract() and parse the JSON result.
 *
 * We inject all three scripts as ONE chained string so they run in the right order
 * inside a single JS context. Each `;` is the separator.
 */
private fun runExtraction(
    view: WebView,
    ctx: android.content.Context,
    onResult: (ExtractResult) -> Unit
) {
    val readability = runCatching {
        ctx.assets.open("Readability.js").bufferedReader().use { it.readText() }
    }.getOrElse {
        onResult(ExtractResult.Err("Readability.js asset missing: ${it.message}"))
        return
    }
    val turndown = runCatching {
        ctx.assets.open("turndown.js").bufferedReader().use { it.readText() }
    }.getOrElse {
        onResult(ExtractResult.Err("turndown.js asset missing: ${it.message}"))
        return
    }
    val extractor = runCatching {
        ctx.assets.open("html-to-markdown.js").bufferedReader().use { it.readText() }
    }.getOrElse {
        onResult(ExtractResult.Err("html-to-markdown.js asset missing: ${it.message}"))
        return
    }
    // Wrap each lib in its own IIFE so any `var` declarations don't collide,
    // then call MV.extract() and return the result string.
    val payload = buildString(readability.length + turndown.length + extractor.length + 256) {
        append(readability)
        append("\n;\n")
        append(turndown)
        append("\n;\n")
        append(extractor)
        append("\n; MV.extract();")
    }
    view.evaluateJavascript(payload) { raw ->
        try {
            // raw is a JSON-encoded string of our JSON. Decode the outer wrapping first.
            val inner = JSONObject("{\"v\":$raw}").getString("v")
            val obj = JSONObject(inner)
            if (!obj.optBoolean("ok", false)) {
                onResult(ExtractResult.Err(obj.optString("error", "Unknown extractor error.")))
                return@evaluateJavascript
            }
            onResult(
                ExtractResult.Ok(
                    Extracted(
                        title = obj.optString("title", "Untitled"),
                        url = obj.optString("url", ""),
                        siteName = obj.optString("siteName", ""),
                        byline = obj.optString("byline", ""),
                        excerpt = obj.optString("excerpt", ""),
                        body = obj.optString("body", ""),
                        warning = obj.optString("warning", "").ifBlank { null }
                    )
                )
            )
        } catch (e: Exception) {
            onResult(ExtractResult.Err("Could not parse converter result: ${e.message}"))
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun SubfolderEditorSheet(
    current: String,
    onSave: (String) -> Unit,
    onCancel: () -> Unit
) {
    var text by remember { mutableStateOf(current) }
    ModalBottomSheet(onDismissRequest = onCancel) {
        Column(Modifier.padding(horizontal = 20.dp, vertical = 8.dp)) {
            Text(
                "\uD83D\uDCC1  Where to save web imports?",
                fontWeight = FontWeight.SemiBold, fontSize = 16.sp
            )
            Spacer(Modifier.height(6.dp))
            Text(
                "Subfolder inside your library. Leave blank to save to the library root.",
                fontSize = 12.sp,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
            Spacer(Modifier.height(14.dp))
            OutlinedTextField(
                value = text,
                onValueChange = { text = it.filter { ch -> ch != '/' && ch != '\\' } },
                singleLine = true,
                modifier = Modifier.fillMaxWidth(),
                placeholder = { Text("e.g. Web Clippings") },
                label = { Text("Subfolder") }
            )
            Spacer(Modifier.height(16.dp))
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.End) {
                OutlinedButton(onClick = onCancel) { Text("Cancel") }
                Spacer(Modifier.width(8.dp))
                Button(onClick = { onSave(text.trim()) }) { Text("Save") }
            }
            Spacer(Modifier.height(20.dp))
        }
    }
}
