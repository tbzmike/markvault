package com.tebogo.markvault.ui

import android.annotation.SuppressLint
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.activity.compose.BackHandler
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material3.Button
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import com.tebogo.markvault.AppViewModel
import com.tebogo.markvault.SaveResult
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import org.json.JSONObject

/**
 * Screen that turns a shared web URL into a markdown file inside the user's vault.
 *
 * Flow:
 *   1. Render the URL in a hidden, JS-enabled WebView so client-side content fills in.
 *   2. Wait for onPageFinished + a settle delay for late JS.
 *   3. Inject html-to-markdown.js (from /android_asset) and call MV.extract().
 *   4. Show the resulting markdown in a preview pane.
 *   5. User taps Save → write into <library>/<subfolder>/<title>.md.
 *
 * Honest scope: paywalls, login walls, infinite-scroll SPAs (Reddit comments, Twitter
 * threads) won't fully convert. The preview tells the user what they're getting before
 * committing to a save.
 */
@OptIn(ExperimentalMaterial3Api::class)
@SuppressLint("SetJavaScriptEnabled")
@Composable
fun UrlImportScreen(
    vm: AppViewModel,
    url: String,
    onClose: () -> Unit
) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    val subfolder by vm.importsSubfolder.collectAsState()

    var stage by remember { mutableStateOf(Stage.LOADING) }
    var title by remember { mutableStateOf("Importing…") }
    var markdown by remember { mutableStateOf("") }
    var warning by remember { mutableStateOf<String?>(null) }
    var errorMsg by remember { mutableStateOf<String?>(null) }
    var saveMsg by remember { mutableStateOf<String?>(null) }
    var showSubfolderSheet by remember { mutableStateOf(false) }

    val library = vm.libraryUri.collectAsState().value
    val hasLibrary = !library.isNullOrBlank()

    BackHandler(enabled = stage == Stage.PREVIEW) { onClose() }

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Text(
                        title,
                        maxLines = 1, overflow = TextOverflow.Ellipsis,
                        fontSize = 16.sp
                    )
                },
                navigationIcon = {
                    IconButton(onClick = onClose) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Close")
                    }
                }
            )
        }
    ) { pad ->
        Column(
            Modifier.padding(pad).fillMaxSize().padding(horizontal = 16.dp)
        ) {
            // Source URL row — always visible
            Surface(
                color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.4f),
                shape = RoundedCornerShape(10.dp),
                modifier = Modifier.fillMaxWidth().padding(top = 8.dp)
            ) {
                Column(Modifier.padding(horizontal = 14.dp, vertical = 10.dp)) {
                    Text(
                        "\uD83C\uDF10 Source",
                        fontSize = 11.sp, fontWeight = FontWeight.SemiBold,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                    Spacer(Modifier.height(2.dp))
                    Text(
                        url, fontSize = 12.sp, maxLines = 2, overflow = TextOverflow.Ellipsis,
                        fontFamily = FontFamily.Monospace
                    )
                }
            }

            Spacer(Modifier.height(12.dp))

            // Body switches by stage
            when (stage) {
                Stage.LOADING -> Box(
                    Modifier.fillMaxWidth().weight(1f),
                    contentAlignment = Alignment.Center
                ) {
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        CircularProgressIndicator()
                        Spacer(Modifier.height(16.dp))
                        Text(
                            "Loading the page\u2026",
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                        Spacer(Modifier.height(4.dp))
                        Text(
                            "Then converting to markdown.",
                            fontSize = 12.sp,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }

                Stage.PREVIEW -> Column(Modifier.fillMaxWidth().weight(1f)) {
                    if (warning != null) {
                        Surface(
                            color = MaterialTheme.colorScheme.errorContainer.copy(alpha = 0.5f),
                            shape = RoundedCornerShape(8.dp),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Text(
                                "\u26A0\uFE0F  " + warning,
                                Modifier.padding(12.dp),
                                fontSize = 12.sp,
                                color = MaterialTheme.colorScheme.onErrorContainer
                            )
                        }
                        Spacer(Modifier.height(10.dp))
                    }
                    Text(
                        "Preview",
                        fontSize = 11.sp, fontWeight = FontWeight.SemiBold,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                    Spacer(Modifier.height(4.dp))
                    Surface(
                        color = MaterialTheme.colorScheme.surface,
                        shape = RoundedCornerShape(10.dp),
                        modifier = Modifier.fillMaxWidth().weight(1f)
                    ) {
                        Column(
                            Modifier.fillMaxSize().padding(12.dp)
                                .verticalScroll(rememberScrollState())
                        ) {
                            Text(
                                markdown,
                                fontSize = 12.sp,
                                fontFamily = FontFamily.Monospace,
                                lineHeight = 17.sp
                            )
                        }
                    }
                }

                Stage.ERROR -> Box(
                    Modifier.fillMaxWidth().weight(1f),
                    contentAlignment = Alignment.Center
                ) {
                    Column(
                        Modifier.padding(20.dp),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Text(
                            "Couldn\u2019t convert this page",
                            fontWeight = FontWeight.SemiBold, fontSize = 16.sp
                        )
                        Spacer(Modifier.height(8.dp))
                        Text(
                            errorMsg ?: "Unknown error.",
                            fontSize = 13.sp,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }
            }

            // Bottom action bar
            if (stage == Stage.PREVIEW) {
                HorizontalDivider(
                    color = MaterialTheme.colorScheme.surfaceVariant,
                    modifier = Modifier.padding(vertical = 8.dp)
                )
                if (saveMsg != null) {
                    Text(
                        saveMsg!!, fontSize = 12.sp,
                        color = MaterialTheme.colorScheme.primary,
                        modifier = Modifier.padding(bottom = 6.dp)
                    )
                }
                Row(
                    Modifier.fillMaxWidth().padding(bottom = 12.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        "Folder:  " + if (subfolder.isBlank()) "Library root" else subfolder,
                        fontSize = 12.sp,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        modifier = Modifier.weight(1f).clickable { showSubfolderSheet = true }
                    )
                    OutlinedButton(onClick = { showSubfolderSheet = true }) {
                        Text("Change", fontSize = 12.sp)
                    }
                    Spacer(Modifier.width(8.dp))
                    Button(
                        enabled = hasLibrary && markdown.isNotBlank(),
                        onClick = {
                            scope.launch {
                                val r = vm.saveImportedMarkdown(title, markdown, subfolder)
                                when (r) {
                                    is SaveResult.Ok -> {
                                        val where = if (r.subfolder.isBlank()) "library root"
                                            else r.subfolder
                                        saveMsg = "\u2705 Saved as \u201C${r.fileName}\u201D in $where"
                                    }
                                    is SaveResult.Error -> {
                                        saveMsg = "\u26A0\uFE0F " + r.message
                                    }
                                }
                            }
                        }
                    ) { Text("Save to vault") }
                }
                if (!hasLibrary) {
                    Text(
                        "Pick a library folder in Settings first.",
                        fontSize = 11.sp,
                        color = MaterialTheme.colorScheme.error,
                        modifier = Modifier.padding(bottom = 10.dp)
                    )
                }
            }
        }
    }

    // Hidden WebView that does the actual page load + extraction. We keep it 1x1 instead of
    // 0x0 because some sites won't paint at zero size.
    if (stage == Stage.LOADING) {
        Box(Modifier.size(1.dp)) {
            AndroidView(
                modifier = Modifier.size(1.dp),
                factory = { c ->
                    WebView(c).apply {
                        settings.javaScriptEnabled = true
                        settings.domStorageEnabled = true
                        settings.loadsImagesAutomatically = true
                        settings.mediaPlaybackRequiresUserGesture = true
                        settings.mixedContentMode = WebSettings.MIXED_CONTENT_NEVER_ALLOW
                        // A real-browser User-Agent so sites don't serve a stripped page.
                        val defaultUa = settings.userAgentString
                        settings.userAgentString = if (defaultUa.isNullOrBlank()) {
                            "Mozilla/5.0 (Linux; Android) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Mobile Safari/537.36"
                        } else {
                            defaultUa.replace("; wv)", ")")  // drop the WebView identifier
                        }
                        // Some pages fire onPageFinished multiple times (SPAs, redirects).
                        // We only want to run the extractor once — flip this on success.
                        var extracted = false
                        webViewClient = object : WebViewClient() {
                            override fun onPageFinished(view: WebView?, finishedUrl: String?) {
                                if (view == null || extracted) return
                                extracted = true
                                scope.launch {
                                    // Settle delay so client-side JS has time to render content.
                                    delay(1500)
                                    runExtraction(view, ctx) { result ->
                                        when (result) {
                                            is ExtractResult.Ok -> {
                                                title = result.title
                                                markdown = result.markdown
                                                warning = result.warning
                                                stage = Stage.PREVIEW
                                            }
                                            is ExtractResult.Err -> {
                                                errorMsg = result.message
                                                stage = Stage.ERROR
                                            }
                                        }
                                    }
                                }
                            }
                            override fun onReceivedError(
                                view: WebView?,
                                request: android.webkit.WebResourceRequest?,
                                error: android.webkit.WebResourceError?
                            ) {
                                // Only flag main-frame errors; subresource failures are normal.
                                if (request?.isForMainFrame == true && !extracted) {
                                    extracted = true
                                    errorMsg = "Failed to load: " +
                                        (error?.description ?: "network error")
                                    stage = Stage.ERROR
                                }
                            }
                        }
                        loadUrl(url)
                    }
                }
            )
        }
    }

    // Subfolder picker sheet
    if (showSubfolderSheet) {
        SubfolderEditorSheet(
            current = subfolder,
            onSave = { newVal ->
                vm.setImportsSubfolder(newVal)
                showSubfolderSheet = false
            },
            onCancel = { showSubfolderSheet = false }
        )
    }
}

private enum class Stage { LOADING, PREVIEW, ERROR }

private sealed class ExtractResult {
    data class Ok(val title: String, val markdown: String, val warning: String?) : ExtractResult()
    data class Err(val message: String) : ExtractResult()
}

/**
 * Inject our converter script into the loaded page, call MV.extract(), and surface the JSON
 * result back to Kotlin. We load the JS as a string from /android_asset rather than via a
 * <script src="file:///..."> tag because file:// scripts are blocked from cross-origin
 * pages by WebView's security model.
 */
private fun runExtraction(
    view: WebView,
    ctx: android.content.Context,
    onResult: (ExtractResult) -> Unit
) {
    val script = runCatching {
        ctx.assets.open("html-to-markdown.js").bufferedReader().use { it.readText() }
    }.getOrElse {
        onResult(ExtractResult.Err("Converter script missing: ${it.message}"))
        return
    }
    // Inject the script, then call extract() and stringify the result so we can decode
    // it cleanly in Kotlin (single string round-trip).
    val payload = "$script\n;JSON.stringify(MV.extract());"
    view.evaluateJavascript(payload) { raw ->
        // raw is a JSON-encoded JSON string. Decode twice.
        try {
            val once = JSONObject("{\"v\":$raw}").getString("v")
            val obj = JSONObject(once)
            onResult(
                ExtractResult.Ok(
                    title = obj.optString("title", "Untitled"),
                    markdown = obj.optString("markdown", ""),
                    warning = obj.optString("warning", "").ifBlank { null }
                )
            )
        } catch (e: Exception) {
            onResult(ExtractResult.Err("Could not parse converter result: ${e.message}"))
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun SubfolderEditorSheet(
    current: String,
    onSave: (String) -> Unit,
    onCancel: () -> Unit
) {
    var text by remember { mutableStateOf(current) }
    ModalBottomSheet(onDismissRequest = onCancel) {
        Column(Modifier.padding(horizontal = 20.dp, vertical = 8.dp)) {
            Text(
                "\uD83D\uDCC1  Where to save web imports?",
                fontWeight = FontWeight.SemiBold, fontSize = 16.sp
            )
            Spacer(Modifier.height(6.dp))
            Text(
                "Subfolder inside your library. Leave blank to save to the library root.",
                fontSize = 12.sp,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
            Spacer(Modifier.height(14.dp))
            androidx.compose.material3.OutlinedTextField(
                value = text,
                onValueChange = { text = it.filter { ch -> ch != '/' && ch != '\\' } },
                singleLine = true,
                modifier = Modifier.fillMaxWidth(),
                placeholder = { Text("e.g. Web Clippings") },
                label = { Text("Subfolder") }
            )
            Spacer(Modifier.height(16.dp))
            Row(
                Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.End
            ) {
                OutlinedButton(onClick = onCancel) { Text("Cancel") }
                Spacer(Modifier.width(8.dp))
                Button(onClick = { onSave(text.trim()) }) { Text("Save") }
            }
            Spacer(Modifier.height(20.dp))
        }
    }
}
