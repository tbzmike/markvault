@file:OptIn(androidx.compose.material3.ExperimentalMaterial3Api::class)

package com.tebogo.markvault.ui

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.ListItem
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.navigation.NavController
import com.tebogo.markvault.AppViewModel
import com.tebogo.markvault.data.NoteMeta

/**
 * Read-only Obsidian-style command palette + quick switcher.
 * It deliberately reuses MarkVault's existing navigation and in-memory note metadata:
 * no vault files, index rows, embeddings, or article contents are modified here.
 */
@Composable
fun CommandPaletteScreen(vm: AppViewModel, nav: NavController) {
    var query by remember { mutableStateOf("") }
    val notes by vm.notes.collectAsStateWithLifecycle()
    val tabs by vm.tabs.collectAsStateWithLifecycle()
    val activeTab by vm.activeTab.collectAsStateWithLifecycle()
    val pinnedTabIds by vm.pinnedTabIds.collectAsStateWithLifecycle()
    val recentlyClosedReaderTabs by vm.recentlyClosedReaderTabs.collectAsStateWithLifecycle()
    val uiMode by vm.uiMode.collectAsStateWithLifecycle()
    val clipboard = LocalClipboardManager.current

    fun activeReaderRoute(): String {
        val id = vm.activeTab.value ?: return "home"
        val tab = vm.tabs.value.firstOrNull { it.id == id } ?: return "home"
        return when (tab.fileType.lowercase()) {
            "pdf" -> "pdfReader/$id"
            "html", "htm", "mhtml", "mht" -> "htmlReader/$id"
            "canvas" -> "canvas/$id"
            else -> "reader"
        }
    }

    data class Command(val label: String, val hint: String, val run: () -> Unit)
    val commands = listOf(
        Command("Search library", "Open MarkVault search") { nav.navigate("search") },
        Command("Browse files", "Open file explorer") { nav.navigate("browse") },
        Command("Media library", "Open videos, audio and playlists") { nav.navigate("jwVideos") },
        Command("Graph view", "Open vault graph") { nav.navigate("graph") },
        Command("Tags", "Browse nested tags and tagged notes") { nav.navigate("workspaceTags") },
        Command("Chat with library", "Open library chat") { nav.navigate("chat") },
        Command("Web bookmarks", "Open saved web bookmarks") { nav.navigate("webBookmarks") },
        Command("Web history", "Open browser history") { nav.navigate("webHistory") },
        Command("PDF history", "Open PDF history") { nav.navigate("pdfHistory") },
        Command("Settings", "Open MarkVault settings") { nav.navigate("settings") },
        Command("Workspace layouts", "Save or restore named workspace arrangements") {
            nav.navigate("workspaceLayouts")
        },
        Command("Workspace bookmarks", "Open note, search, graph and URL bookmarks") {
            nav.navigate("workspaceBookmarks")
        },
        Command("Properties", "Show read-only frontmatter for the active article") {
            nav.navigate("workspaceProperties")
        },
        Command("Data views", "Open Bases-style indexed metadata views") {
            nav.navigate("bases")
        },
        Command("Read-only extensions", "Open the safe built-in viewer/inspector registry") {
            nav.navigate("extensions")
        },
        Command(
            if (uiMode == "workspace") "Use standard mode" else "Use workspace mode",
            "Switch MarkVault's global layout mode"
        ) { vm.setUiMode(if (uiMode == "workspace") "standard" else "workspace") },
        Command("Previous open tab", "Move to the previous reader tab") {
            if (vm.switchTabByDirection(false)) {
                nav.navigate(activeReaderRoute()) { launchSingleTop = true }
            }
        },
        Command("Next open tab", "Move to the next reader tab") {
            if (vm.switchTabByDirection(true)) {
                nav.navigate(activeReaderRoute()) { launchSingleTop = true }
            }
        },
        Command("Close current tab", "Close the active reader tab") {
            activeTab?.let(vm::closeTab)
            nav.popBackStack()
        },
        Command("Close other tabs", "Keep only the active reader tab") {
            activeTab?.let(vm::closeOtherTabs)
            nav.popBackStack()
        },
        Command(
            if (activeTab != null && activeTab in pinnedTabIds) "Unpin current tab" else "Pin current tab",
            "Keep important reader tabs in the pinned group"
        ) {
            activeTab?.let(vm::toggleTabPinned)
            nav.popBackStack()
        },
        Command("Close tabs to right", "Close reader tabs after the active tab") {
            activeTab?.let(vm::closeTabsToRight)
            nav.popBackStack()
        },
        Command("Reopen last closed tab", "Restore the most recently closed reader tab") {
            val reopened = vm.reopenLastClosedReaderTab()
            if (reopened != null) {
                val route = when (reopened.fileType.lowercase()) {
                    "pdf" -> "pdfReader/${reopened.id}"
                    "html", "htm", "mhtml", "mht" -> "htmlReader/${reopened.id}"
                    "canvas" -> "canvas/${reopened.id}"
                    else -> "reader"
                }
                nav.navigate(route) { launchSingleTop = true }
            }
        },
        Command("Bookmark current note", "Add the active article to Workspace bookmarks") {
            val id = activeTab
            if (id != null) {
                val tab = tabs.firstOrNull { it.id == id }
                vm.addWorkspaceBookmark("note", tab?.title ?: "Note $id", id.toString(), "Reader tab")
            }
            nav.popBackStack()
        },
        Command("Bookmark current search", "Save the current library query") {
            val q = vm.query.value.trim()
            if (q.isNotEmpty()) vm.addWorkspaceBookmark("search", q, q, "Library search")
            nav.popBackStack()
        },
        Command("Copy link to current note", "Copy a read-only markvault://open deep link") {
            activeTab?.let { id ->
                clipboard.setText(AnnotatedString("markvault://open?id=$id"))
            }
            nav.popBackStack()
        },
        Command("Open current note graph", "Show the active note in graph view") {
            activeTab?.let { id ->
                nav.navigate("graph/$id") { launchSingleTop = true }
            }
        },
        Command("Close all tabs", "Close every reader tab") {
            vm.closeAllTabs()
            nav.navigate("home") { popUpTo("home") { inclusive = false }; launchSingleTop = true }
        },
        Command("Home", "Return to workspace home") {
            nav.navigate("home") { popUpTo("home") { inclusive = false }; launchSingleTop = true }
        }
    )
    val q = query.trim()
    val matchingCommands = if (q.isBlank()) commands else commands.filter {
        it.label.contains(q, true) || it.hint.contains(q, true)
    }
    val matchingNotes = remember(notes, q) {
        if (q.isBlank()) emptyList() else notes.asSequence().filter {
            it.title.contains(q, true) || it.name.contains(q, true) ||
                it.relPath.contains(q, true) || it.folder.contains(q, true)
        }.take(40).toList()
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Command palette") },
                navigationIcon = {
                    IconButton(onClick = { nav.popBackStack() }) {
                        Icon(Icons.Default.ArrowBack, contentDescription = "Back")
                    }
                }
            )
        }
    ) { pad ->
        Column(Modifier.fillMaxSize().padding(pad)) {
            OutlinedTextField(
                value = query,
                onValueChange = { query = it },
                modifier = Modifier.fillMaxWidth().padding(12.dp),
                singleLine = true,
                label = { Text("Type a command or quickly switch to a note") },
                placeholder = { Text("Search commands and files…") }
            )
            LazyColumn(Modifier.fillMaxSize()) {
                if (matchingCommands.isNotEmpty()) {
                    item {
                        Text("COMMANDS", fontWeight = FontWeight.SemiBold, modifier = Modifier.padding(16.dp, 8.dp))
                    }
                    items(matchingCommands, key = { "cmd:${it.label}" }) { command ->
                        ListItem(
                            headlineContent = { Text(command.label) },
                            supportingContent = { Text(command.hint) },
                            modifier = Modifier.clickable { command.run() }
                        )
                    }
                }
                if (matchingNotes.isNotEmpty()) {
                    item { HorizontalDivider() }
                    item {
                        Text("QUICK SWITCHER", fontWeight = FontWeight.SemiBold, modifier = Modifier.padding(16.dp, 8.dp))
                    }
                    items(matchingNotes, key = { "note:${it.id}" }) { note ->
                        QuickSwitchNote(note) {
                            vm.openArticle(note.id, note.title, fileType = note.fileType)
                            val route = when (note.fileType.lowercase()) {
                                "pdf" -> "pdfReader/${note.id}"
                                "html", "htm", "mhtml", "mht" -> "htmlReader/${note.id}"
                                "canvas" -> "canvas/${note.id}"
                                else -> "reader"
                            }
                            nav.navigate(route)
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun QuickSwitchNote(note: NoteMeta, onClick: () -> Unit) {
    ListItem(
        headlineContent = { Text(note.title.ifBlank { note.name }) },
        supportingContent = {
            Row {
                Text(note.folder.ifBlank { "Vault" })
                Spacer(Modifier.width(8.dp))
                Text("• ${note.fileType.uppercase()}")
            }
        },
        modifier = Modifier.clickable(onClick = onClick)
    )
}
