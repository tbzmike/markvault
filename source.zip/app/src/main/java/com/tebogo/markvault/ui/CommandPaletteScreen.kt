package com.tebogo.markvault.ui

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.getValue
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.navigation.NavController

private data class PaletteEntry(val title: String, val detail: String, val route: String)

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun CommandPaletteScreen(nav: NavController) {
    var query by remember { mutableStateOf("") }
    val commands = remember {
        listOf(
            PaletteEntry("Search", "Search the vault", "search"),
            PaletteEntry("Browse vault", "Open the file browser", "browse"),
            PaletteEntry("Tags", "Browse nested tags", "workspaceTags"),
            PaletteEntry("Data Views", "Open metadata filters", "workspaceData"),
            PaletteEntry("Workspace", "Open multi-pane Workspace", "workspacePanes"),
            PaletteEntry("Graph", "Open local graph", "graph"),
            PaletteEntry("Read-only extensions", "Open built-in extension registry", "extensions"),
            PaletteEntry("Media Library", "Open media browser", "jwVideos"),
            PaletteEntry("Settings", "Open settings", "settings")
        )
    }
    val shown = remember(query, commands) {
        val q = query.trim()
        if (q.isBlank()) commands else commands.filter {
            it.title.contains(q, true) || it.detail.contains(q, true)
        }
    }
    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Command Palette") },
                navigationIcon = {
                    IconButton(onClick = { nav.popBackStack() }) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back")
                    }
                }
            )
        }
    ) { pad ->
        Column(Modifier.fillMaxSize().padding(pad)) {
            OutlinedTextField(
                value = query,
                onValueChange = { query = it.take(120) },
                modifier = Modifier.fillMaxWidth().padding(10.dp),
                singleLine = true,
                label = { Text("Find a command") }
            )
            LazyColumn(Modifier.fillMaxSize()) {
                items(shown, key = { it.title }) { command ->
                    Column(
                        Modifier.fillMaxWidth().clickable {
                            nav.navigate(command.route) { launchSingleTop = true }
                        }.padding(horizontal = 16.dp, vertical = 11.dp)
                    ) {
                        Text(command.title, fontWeight = FontWeight.SemiBold)
                        Text(
                            command.detail,
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                    HorizontalDivider()
                }
            }
        }
    }
}
