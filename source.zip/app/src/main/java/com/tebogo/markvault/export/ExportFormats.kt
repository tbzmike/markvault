package com.tebogo.markvault.export

/**
 * Export format preparation layer.
 */
object ExportFormats {
    fun html(title: String, body: String): String =
        "<html><head><title>$title</title></head><body>$body</body></html>"

    fun epubSource(title: String, body: String): String = html(title, body)

    fun pdfSource(title: String, body: String): String = html(title, body)
}
