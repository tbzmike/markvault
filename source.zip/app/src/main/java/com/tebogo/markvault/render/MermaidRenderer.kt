package com.tebogo.markvault.render

/**
 * Mermaid diagram rendering foundation.
 * Converts Mermaid blocks into a renderable diagram representation.
 */
object MermaidRenderer {

    fun isMermaidBlock(language: String): Boolean {
        return language.equals("mermaid", ignoreCase = true)
    }

    fun extract(code: String): String {
        return code.trim()
    }
}
