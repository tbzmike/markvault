package com.tebogo.markvault.ui

import androidx.compose.material3.*
import androidx.compose.runtime.Composable

@Composable
fun T5InstallerCard(
    status: String,
    onInstall: () -> Unit
) {
    Card {
        Column {
            Text("T5 Model Status: $status")
            if (status != "Ready") {
                Button(onClick = onInstall) {
                    Text("Download T5-base model")
                }
            }
        }
    }
}
