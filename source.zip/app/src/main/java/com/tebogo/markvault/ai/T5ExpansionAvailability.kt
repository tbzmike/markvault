package com.tebogo.markvault.ai

/** Controls whether T5 can be selected for query expansion. */
object T5ExpansionAvailability {
    private var available = false

    fun update(value: Boolean) { available = value }
    fun isAvailable(): Boolean = available
}
