package com.tebogo.markvault.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Shape
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp

/**
 * v5.4.171cc — Shared "3D look" depth treatment, extending the styling
 * first built for the search screen's Shallow/Deep toggle (v5.4.169cc)
 * and the article-view CSS (same version) app-wide, per the follow-up
 * request that it "must be global."
 *
 * A drop shadow plus a thin, semi-transparent three-stop gradient
 * (light catching the top edge, neutral through the middle, a whisper
 * of shadow at the bottom) — layered ON TOP of whatever background the
 * element already has via chained modifiers, not replacing it. This is
 * what makes it safe to bolt onto EXISTING components (bottom bar,
 * chips, cards) via `.depth3D()` at the end of their modifier chain,
 * without needing to know or restructure that component's internals —
 * the same "layer on top, don't replace" principle used for the
 * article-view CSS gradients in v5.4.169cc.
 *
 * Deliberately static — no animation, no ongoing per-frame cost. This
 * project fixed three always-on animations for battery reasons in
 * v5.4.168cc; a global sweep touching many surfaces is exactly the
 * wrong place to reintroduce that pattern at scale. Where a caller
 * wants a press/selection reaction on top of this, compose it with the
 * transition-based patterns already used elsewhere (fabPressScale,
 * ShallowDeepToggle) rather than adding motion inside this function.
 *
 * Two entry points:
 *   Modifier.depth3D(shape, elevation) — shadow + gradient overlay
 *     only. Use when the caller already handles its own clip/background
 *     (e.g. an M3 Surface with its own `color`) and just wants the
 *     lifted-edge gloss added on top.
 *   Modifier.depth3DSurface(baseColor, shape, elevation, border) —
 *     shadow + gradient overlay AND the clip/background/border in one
 *     call, for building a raised 3D surface from scratch.
 */
fun Modifier.depth3D(
    shape: Shape = RoundedCornerShape(12.dp),
    elevation: Dp = 6.dp
): Modifier = this
    .shadow(elevation = elevation, shape = shape, clip = false)
    .background(
        brush = Brush.verticalGradient(
            listOf(
                Color.White.copy(alpha = 0.09f),
                Color.Transparent,
                Color.Black.copy(alpha = 0.05f)
            )
        ),
        shape = shape
    )

fun Modifier.depth3DSurface(
    baseColor: Color,
    shape: Shape = RoundedCornerShape(12.dp),
    elevation: Dp = 6.dp,
    borderColor: Color? = null
): Modifier {
    val base = this
        .shadow(elevation = elevation, shape = shape, clip = false)
        .background(color = baseColor, shape = shape)
        .background(
            brush = Brush.verticalGradient(
                listOf(
                    Color.White.copy(alpha = 0.10f),
                    Color.Transparent,
                    Color.Black.copy(alpha = 0.06f)
                )
            ),
            shape = shape
        )
    return if (borderColor != null) {
        base.border(width = 1.dp, color = borderColor, shape = shape)
    } else {
        base
    }
}
