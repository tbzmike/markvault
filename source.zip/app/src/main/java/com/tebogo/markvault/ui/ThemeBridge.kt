package com.tebogo.markvault.ui

import androidx.compose.material3.ColorScheme
import androidx.compose.material3.Shapes
import androidx.compose.material3.Typography
import androidx.compose.runtime.Composable
import androidx.compose.runtime.staticCompositionLocalOf
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.toArgb
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.tebogo.markvault.data.ObsidianThemePayload
import org.json.JSONObject

/** Target (non-animated) app palette, provided by MarkVaultTheme for WebView/theme bridges. */
val LocalMarkVaultTargetColorScheme = staticCompositionLocalOf<ColorScheme?> { null }
val LocalObsidianThemeVariables = staticCompositionLocalOf<Map<String, String>> { emptyMap() }

@Composable
fun obsidianUiColor(vararg names: String): Color? {
    val vars = LocalObsidianThemeVariables.current
    for (name in names) {
        val raw = vars[name] ?: continue
        parseObsidianCssColor(raw)?.let { return it }
    }
    return null
}

/** Resolve a CSS length token for native Workspace geometry. */
@Composable
fun obsidianUiDp(fallback: Dp, vararg names: String): Dp {
    val vars = LocalObsidianThemeVariables.current
    for (name in names) {
        val raw = vars[name] ?: continue
        parseObsidianCssLengthDp(raw, fallback.value)?.let { return it.dp }
    }
    return fallback
}

/** Convert Obsidian box-shadow tokens into restrained native elevation. */
@Composable
fun obsidianUiElevation(fallback: Dp, vararg names: String): Dp {
    val vars = LocalObsidianThemeVariables.current
    for (name in names) {
        val raw = vars[name] ?: continue
        val px = Regex("[-+]?[0-9]*\\.?[0-9]+px", RegexOption.IGNORE_CASE)
            .findAll(raw)
            .mapNotNull { it.value.removeSuffix("px").toFloatOrNull()?.let { value -> kotlin.math.abs(value) } }
            .maxOrNull()
        if (px != null) return px.coerceIn(0f, 16f).dp
    }
    return fallback
}

/** Shared appearance resolver used by Compose chrome and every article renderer. */
fun resolveObsidianDark(
    appearanceMode: String,
    systemDark: Boolean,
    payload: ObsidianThemePayload? = null
): Boolean {
    val requestedDark = when (appearanceMode.lowercase()) {
        "light" -> false
        "dark" -> true
        else -> systemDark
    }
    if (payload == null) return requestedDark
    return when {
        requestedDark && payload.darkVariables.isEmpty() && payload.lightVariables.isNotEmpty() -> false
        !requestedDark && payload.lightVariables.isEmpty() && payload.darkVariables.isNotEmpty() -> true
        else -> requestedDark
    }
}

private fun parseObsidianCssLengthDp(raw: String, fallback: Float): Float? {
    val value = raw.trim().lowercase().substringBefore("!important").trim()
    val match = Regex("^([-+]?[0-9]*\\.?[0-9]+)\\s*(px|dp|rem|em|%)?$", RegexOption.IGNORE_CASE).matchEntire(value)
        ?: return null
    val number = match.groupValues[1].toFloatOrNull() ?: return null
    val unit = match.groupValues[2].lowercase()
    val converted = when (unit) {
        "rem", "em" -> number * 16f
        "%" -> fallback * (number / 100f)
        else -> number
    }
    return converted.coerceIn(0f, 96f)
}

private fun parseObsidianFontWeight(raw: String?, fallback: FontWeight): FontWeight {
    val value = raw?.trim()?.lowercase() ?: return fallback
    val numeric = value.toIntOrNull()
    if (numeric != null) return FontWeight(numeric.coerceIn(100, 900))
    return when (value) {
        "thin" -> FontWeight.Thin
        "extralight", "extra-light" -> FontWeight.ExtraLight
        "light" -> FontWeight.Light
        "medium" -> FontWeight.Medium
        "semibold", "semi-bold" -> FontWeight.SemiBold
        "bold" -> FontWeight.Bold
        "extrabold", "extra-bold" -> FontWeight.ExtraBold
        "black" -> FontWeight.Black
        else -> fallback
    }
}

private fun parseObsidianTextSizeSp(raw: String?, fallback: Float): Float {
    if (raw.isNullOrBlank()) return fallback
    val value = raw.trim().lowercase().substringBefore("!important").trim()
    val match = Regex("^([-+]?[0-9]*\\.?[0-9]+)\\s*(px|sp|rem|em|%)?$", RegexOption.IGNORE_CASE).matchEntire(value)
        ?: return fallback
    val number = match.groupValues[1].toFloatOrNull() ?: return fallback
    val unit = match.groupValues[2].lowercase()
    val out = when (unit) {
        "rem" -> 16f * number
        "em" -> fallback * number
        "%" -> fallback * number / 100f
        else -> number
    }
    return out.coerceIn(8f, 40f)
}

private fun parseObsidianLineHeightSp(raw: String?, fontSize: Float): Float {
    if (raw.isNullOrBlank()) return (fontSize * 1.35f).coerceAtLeast(fontSize)
    val value = raw.trim().lowercase().substringBefore("!important").trim()
    val match = Regex("^([-+]?[0-9]*\\.?[0-9]+)\\s*(px|sp|rem|em|%)?$", RegexOption.IGNORE_CASE).matchEntire(value)
        ?: return (fontSize * 1.35f).coerceAtLeast(fontSize)
    val number = match.groupValues[1].toFloatOrNull() ?: return (fontSize * 1.35f)
    val unit = match.groupValues[2].lowercase()
    val out = when (unit) {
        "rem" -> 16f * number
        "em" -> fontSize * number
        "%" -> fontSize * number / 100f
        "px", "sp" -> number
        else -> if (number <= 4f) fontSize * number else number
    }
    return out.coerceIn(fontSize, 64f)
}

/**
 * Single bridge between MarkVault's Compose palette and article/WebView colors.
 * This keeps app chrome and rendered notes on the same theme vocabulary.
 */
fun articleThemeVariables(scheme: ColorScheme, customJson: String? = null): LinkedHashMap<String, String> {
    fun hex(c: Color): String = String.format("#%06X", 0xFFFFFF and c.toArgb())
    val vars = linkedMapOf(
        "--bg" to hex(scheme.background),
        "--fg" to hex(scheme.onBackground),
        "--heading" to hex(scheme.primary),
        "--fg-muted" to hex(scheme.onSurfaceVariant),
        "--accent" to hex(scheme.primary),
        "--rule" to hex(scheme.outlineVariant),
        "--surface" to hex(scheme.surface),
        "--surface-variant" to hex(scheme.surfaceVariant),
        "--code-bg" to hex(scheme.surfaceVariant),
        "--code-fg" to hex(scheme.onSurface),
        "--code-inline-bg" to hex(scheme.surfaceVariant),
        "--code-inline-fg" to hex(scheme.tertiary),
        "--table-head" to hex(scheme.surfaceVariant),
        "--table-border" to hex(scheme.outline),
        "--quote-bar" to hex(scheme.secondary),
        "--mark-bg" to hex(scheme.primaryContainer),
        "--mark-fg" to hex(scheme.onPrimaryContainer)
    )
    if (!customJson.isNullOrBlank()) {
        runCatching {
            val obj = JSONObject(customJson)
            obj.keys().forEach { key ->
                if (key.startsWith("--")) {
                    val value = obj.optString(key)
                    if (value.startsWith("#") && value.length in 4..9) vars[key] = value
                }
            }
        }
    }
    return vars
}

fun articleThemeJson(scheme: ColorScheme, customJson: String? = null): String =
    JSONObject(articleThemeVariables(scheme, customJson) as Map<*, *>).toString()

/**
 * v5.4.349cc — Strong, theme-resistant article body-weight rule used by both
 * the Markdown WebView and offline-HTML reader. Descendant inline elements
 * receive the selected weight too, while semantic bold text remains at least
 * 700 and code/math keep their own readable weight.
 */
fun articleBodyWeightCss(weight: Int, rootSelector: String): String {
    val w = weight.coerceIn(400, 900)
    val strong = maxOf(700, w)
    val roots = listOf(
        rootSelector,
        "$rootSelector p", "$rootSelector li", "$rootSelector dd", "$rootSelector dt",
        "$rootSelector td", "$rootSelector blockquote", "$rootSelector .callout-content",
        "$rootSelector .callout-body"
    )
    val nested = roots.drop(1).joinToString(",") { "$it *" }
    val base = roots.joinToString(",")
    return "$base,$nested{font-weight:$w!important;}" +
        "$rootSelector strong,$rootSelector b,$rootSelector strong *,$rootSelector b *{font-weight:$strong!important;}" +
        "$rootSelector pre,$rootSelector pre *,$rootSelector code,$rootSelector .katex,$rootSelector .katex *{font-weight:400!important;}"
}

fun articleThemeHtmlCss(scheme: ColorScheme, customJson: String? = null, themeName: String? = null, boldBodyText: Boolean = false, bodyTextWeight: Int = if (boldBodyText) 600 else 400, obsidianCss: String? = null, obsidianDark: Boolean = true): String {
    val v = articleThemeVariables(scheme, customJson)
    fun x(name: String) = v[name] ?: "#000000"
    val glass3d = themeName == "glass_obsidian" || themeName == "glass_crystal"
    val artifactCss = artifactArticleCss(themeName, scheme)
    val effectiveBodyWeight = bodyTextWeight.coerceIn(400, 900)
    // v5.4.349cc — Apply the adjustable Workspace weight to actual rendered
    // article text, including nested spans/links/emphasis emitted by flexmark
    // or community Obsidian themes. The former parent-only rule could be
    // overridden by descendant theme rules, making the slider appear inert.
    val bodyWeightCss = if (effectiveBodyWeight != 400 || boldBodyText) {
        articleBodyWeightCss(effectiveBodyWeight, "body")
    } else ""
    val glassCss = if (glass3d) """
        html,body{background-image:linear-gradient(145deg,${x("--bg")} 0%,${x("--surface-variant")} 52%,${x("--bg")} 100%)!important;background-attachment:fixed!important;}
        blockquote,pre,details,table{border-radius:14px!important;border:1px solid ${x("--rule")}!important;box-shadow:0 12px 28px rgba(0,0,0,.16)!important;}
        blockquote,details{background:${x("--surface")}!important;}
        img{border-radius:14px!important;box-shadow:0 12px 30px rgba(0,0,0,.16)!important;}
    """.trimIndent() else ""
    val importedObsidian = themeName == "obsidian_imported" && !obsidianCss.isNullOrBlank()
    val priority = if (importedObsidian) "" else "!important"
    val compatibilityCss = if (importedObsidian) obsidianArticleCompatibilityCss(obsidianDark) else ""
    val importedCssBlock = if (importedObsidian) {
        val variant = if (obsidianDark) "dark" else "light"
        "<style id=\"mv-obsidian-theme\">$compatibilityCss\n${obsidianCss.orEmpty()}</style>" +
            "<script id=\"mv-obsidian-class\">(function(){document.documentElement.classList.add('theme-$variant','obsidian-app');function a(){if(document.body){document.body.classList.add('theme-$variant','obsidian-app','mv-obsidian-theme','markdown-rendered','markdown-preview-view','workspace-leaf-content','markdown-reading-view','view-content','mod-active');document.body.dataset.type='markdown';document.body.dataset.mode='preview';}}if(document.readyState==='loading')document.addEventListener('DOMContentLoaded',a);else a();})();</script>"
    } else ""
    return """
        <style id="mv-global-theme">
        :root{${v.entries.joinToString("") { "${it.key}:${it.value};" }}}
        html,body{background:${x("--bg")}$priority;color:${x("--fg")}$priority;}
        body,p,li,dd,dt,td{color:${x("--fg")}$priority;}
        h1,h2,h3,h4,h5,h6,strong{color:${x("--heading")}$priority;}
        a,a:visited{color:${x("--accent")}$priority;}
        blockquote{color:${x("--fg")}$priority;border-color:${x("--quote-bar")}$priority;background:${x("--surface")}$priority;}
        pre{background:${x("--code-bg")}$priority;color:${x("--code-fg")}$priority;border-color:${x("--rule")}$priority;}
        code{color:${x("--code-inline-fg")}$priority;}
        :not(pre)>code{background:${x("--code-inline-bg")}$priority;}
        table,th,td{border-color:${x("--table-border")}$priority;}
        th{background:${x("--table-head")}$priority;color:${x("--heading")}$priority;}
        hr{border-color:${x("--rule")}$priority;}
        $bodyWeightCss
        $glassCss
        $artifactCss
        </style>
        $importedCssBlock
    """.trimIndent()
}


/**
 * Map the common Obsidian CSS-variable vocabulary onto Material 3. The original
 * CSS is still used by the article renderer; this mapping is what makes native
 * Compose Workspace chrome follow the same imported theme.
 */
fun obsidianColorSchemeFromPayload(base: ColorScheme, payload: ObsidianThemePayload?, dark: Boolean): ColorScheme {
    if (payload == null) return base
    val vars = payload.variables(dark)
    fun first(vararg names: String): String? = names.firstNotNullOfOrNull { vars[it]?.takeIf(String::isNotBlank) }
    fun color(fallback: Color, vararg names: String): Color {
        val raw = first(*names) ?: return fallback
        return parseObsidianCssColor(raw) ?: fallback
    }

    val bg = color(base.background, "--background-primary", "--background-primary-alt", "--background-modifier-form-field")
    val surface = color(base.surface, "--background-secondary", "--background-primary-alt", "--background-modifier-form-field")
    val surfaceVariant = color(base.surfaceVariant, "--background-secondary-alt", "--background-modifier-hover", "--background-modifier-active-hover")
    val fg = color(base.onBackground, "--text-normal", "--text-primary")
    val muted = color(base.onSurfaceVariant, "--text-muted", "--text-faint")
    val accent = color(base.primary, "--interactive-accent", "--text-accent", "--color-accent", "--link-color")
    val accentHover = color(base.secondary, "--interactive-accent-hover", "--text-accent-hover", "--link-color-hover")
    val heading = color(base.tertiary, "--h1-color", "--h2-color", "--text-title-h1", "--text-normal")
    val border = color(base.outline, "--background-modifier-border", "--divider-color", "--tab-outline-color")
    val borderSoft = color(base.outlineVariant, "--background-modifier-border-hover", "--background-modifier-border-focus", "--divider-color")
    val selected = color(base.primaryContainer, "--background-modifier-active-hover", "--interactive-accent", "--tab-background-active", "--background-modifier-hover")
    val selectedText = color(base.onPrimaryContainer, "--text-on-accent", "--tab-text-color-focused-active", "--text-normal")
    val secondaryContainer = color(base.secondaryContainer, "--background-modifier-hover", "--nav-item-background-active", "--background-secondary-alt")
    val onSecondaryContainer = color(base.onSecondaryContainer, "--nav-item-color-active", "--text-normal")
    val tertiaryContainer = color(base.tertiaryContainer, "--background-primary-alt", "--background-secondary-alt")
    val onTertiaryContainer = color(base.onTertiaryContainer, "--text-normal", "--text-muted")
    val error = color(base.error, "--text-error", "--background-modifier-error", "--color-red")
    val errorContainer = color(base.errorContainer, "--background-modifier-error-hover", "--background-modifier-error")
    val onError = color(bestContrast(error), "--text-on-accent", "--text-normal")
    val inverseSurface = color(base.inverseSurface, "--background-primary-alt", "--background-secondary")
    val inverseText = color(base.inverseOnSurface, "--text-normal", "--text-muted")

    return base.copy(
        primary = accent,
        onPrimary = color(bestContrast(accent), "--text-on-accent", "--text-on-accent-inverted"),
        primaryContainer = selected,
        onPrimaryContainer = selectedText,
        secondary = accentHover,
        onSecondary = bestContrast(accentHover),
        secondaryContainer = secondaryContainer,
        onSecondaryContainer = onSecondaryContainer,
        tertiary = heading,
        onTertiary = bestContrast(heading),
        tertiaryContainer = tertiaryContainer,
        onTertiaryContainer = onTertiaryContainer,
        background = bg,
        onBackground = fg,
        surface = surface,
        onSurface = fg,
        surfaceVariant = surfaceVariant,
        onSurfaceVariant = muted,
        surfaceDim = color(base.surfaceDim, "--background-primary", "--background-secondary"),
        surfaceBright = color(base.surfaceBright, "--background-primary-alt", "--background-primary"),
        surfaceContainerLowest = color(base.surfaceContainerLowest, "--background-primary", "--background-primary-alt"),
        surfaceContainerLow = color(base.surfaceContainerLow, "--background-secondary", "--background-primary-alt"),
        surfaceContainer = color(base.surfaceContainer, "--background-secondary", "--background-primary-alt"),
        surfaceContainerHigh = color(base.surfaceContainerHigh, "--background-secondary-alt", "--background-modifier-hover"),
        surfaceContainerHighest = color(base.surfaceContainerHighest, "--background-secondary-alt", "--background-modifier-hover"),
        surfaceTint = accent,
        outline = border,
        outlineVariant = borderSoft,
        error = error,
        onError = onError,
        errorContainer = errorContainer,
        onErrorContainer = color(bestContrast(errorContainer), "--text-error", "--text-normal"),
        inverseSurface = inverseSurface,
        inverseOnSurface = inverseText,
        inversePrimary = color(base.inversePrimary, "--interactive-accent-hover", "--text-accent")
    )
}

fun obsidianShapesFromPayload(payload: ObsidianThemePayload?, dark: Boolean): Shapes {
    val vars = payload?.variables(dark).orEmpty()
    fun radius(vararg keys: String, fallback: Float): Float {
        val raw = keys.firstNotNullOfOrNull { vars[it] } ?: return fallback
        val n = Regex("[-+]?[0-9]*\\.?[0-9]+").find(raw)?.value?.toFloatOrNull() ?: return fallback
        return n.coerceIn(0f, 32f)
    }
    val small = radius("--radius-s", "--input-radius", fallback = 4f)
    val medium = radius("--radius-m", "--button-radius", "--tab-radius-active", fallback = 8f)
    val large = radius("--radius-l", "--modal-radius", fallback = 12f)
    return Shapes(
        extraSmall = RoundedCornerShape(small.dp),
        small = RoundedCornerShape(small.dp),
        medium = RoundedCornerShape(medium.dp),
        large = RoundedCornerShape(large.dp),
        extraLarge = RoundedCornerShape((large * 1.5f).coerceAtMost(36f).dp)
    )
}

/**
 * Translate the typography part of common Obsidian themes into native Compose.
 * CSS font files still render directly inside article WebViews; native Android UI
 * safely maps size/weight/line-height while keeping the device font family.
 */
fun obsidianTypographyFromPayload(base: Typography, payload: ObsidianThemePayload?, dark: Boolean): Typography {
    val vars = payload?.variables(dark).orEmpty()
    if (vars.isEmpty()) return base
    fun raw(vararg keys: String): String? = keys.firstNotNullOfOrNull { vars[it]?.takeIf(String::isNotBlank) }
    fun size(fallback: Float, vararg keys: String) = parseObsidianTextSizeSp(raw(*keys), fallback).sp
    fun weight(fallback: FontWeight, vararg keys: String) = parseObsidianFontWeight(raw(*keys), fallback)

    val body = size(base.bodyMedium.fontSize.value.takeIf { it > 0 } ?: 14f, "--font-text-size", "--font-ui-medium")
    val small = size(base.bodySmall.fontSize.value.takeIf { it > 0 } ?: 12f, "--font-ui-smaller", "--font-ui-small")
    val large = size(base.bodyLarge.fontSize.value.takeIf { it > 0 } ?: 16f, "--font-ui-large", "--font-text-size")
    val bodyWeight = weight(base.bodyMedium.fontWeight ?: FontWeight.Normal, "--font-text-weight", "--font-normal")
    val interfaceWeight = weight(base.labelLarge.fontWeight ?: FontWeight.Medium, "--font-interface-weight", "--font-medium")
    val bodyLineHeight = parseObsidianLineHeightSp(raw("--line-height-normal", "--line-height"), body.value).sp

    fun headingStyle(index: Int, fallback: androidx.compose.ui.text.TextStyle): androidx.compose.ui.text.TextStyle {
        val n = index.coerceIn(1, 6)
        val fallbackSize = fallback.fontSize.value.takeIf { it > 0 } ?: when (n) { 1 -> 28f; 2 -> 24f; 3 -> 20f; 4 -> 18f; else -> 16f }
        return fallback.copy(
            fontSize = size(fallbackSize, "--h${n}-size"),
            fontWeight = weight(fallback.fontWeight ?: FontWeight.Bold, "--h${n}-weight")
        )
    }

    return base.copy(
        bodySmall = base.bodySmall.copy(fontSize = small, fontWeight = bodyWeight, lineHeight = bodyLineHeight),
        bodyMedium = base.bodyMedium.copy(fontSize = body, fontWeight = bodyWeight, lineHeight = bodyLineHeight),
        bodyLarge = base.bodyLarge.copy(fontSize = large, fontWeight = bodyWeight, lineHeight = bodyLineHeight),
        labelSmall = base.labelSmall.copy(fontSize = small, fontWeight = interfaceWeight),
        labelMedium = base.labelMedium.copy(fontSize = small, fontWeight = interfaceWeight),
        labelLarge = base.labelLarge.copy(fontSize = body, fontWeight = interfaceWeight),
        titleSmall = headingStyle(6, base.titleSmall),
        titleMedium = headingStyle(5, base.titleMedium),
        titleLarge = headingStyle(4, base.titleLarge),
        headlineSmall = headingStyle(3, base.headlineSmall),
        headlineMedium = headingStyle(2, base.headlineMedium),
        headlineLarge = headingStyle(1, base.headlineLarge),
        displaySmall = headingStyle(3, base.displaySmall),
        displayMedium = headingStyle(2, base.displayMedium),
        displayLarge = headingStyle(1, base.displayLarge)
    )
}

private fun parseObsidianCssColor(raw: String): Color? {
    val value = raw.trim().substringBefore(" !important").trim()
    if (value.isBlank() || value.startsWith("var(") || value.startsWith("color-mix(")) return null

    // Android handles hex and named CSS colors that are also Android color names.
    runCatching { Color(android.graphics.Color.parseColor(value)) }.getOrNull()?.let { return it }

    val rgb = Regex(
        """rgba?\(\s*([0-9.]+)%?\s*[, ]\s*([0-9.]+)%?\s*[, ]\s*([0-9.]+)%?(?:\s*[,/]\s*([0-9.]+)%?)?\s*\)""",
        RegexOption.IGNORE_CASE
    ).matchEntire(value)
    if (rgb != null) {
        fun channel(rawPart: String, percent: Boolean): Float {
            val n = rawPart.toFloatOrNull() ?: 0f
            return if (percent) (n / 100f).coerceIn(0f, 1f) else (n / 255f).coerceIn(0f, 1f)
        }
        val percent = value.substringBefore(')').contains('%') &&
            rgb.groupValues[1].let { value.contains("$it%") }
        val r = channel(rgb.groupValues[1], percent)
        val g = channel(rgb.groupValues[2], percent)
        val b = channel(rgb.groupValues[3], percent)
        val alphaRaw = rgb.groupValues.getOrNull(4).orEmpty()
        val a = when {
            alphaRaw.isBlank() -> 1f
            value.substringAfterLast('/').contains('%') || value.substringAfterLast(',').contains('%') ->
                (alphaRaw.toFloatOrNull() ?: 100f).div(100f).coerceIn(0f, 1f)
            else -> (alphaRaw.toFloatOrNull() ?: 1f).coerceIn(0f, 1f)
        }
        return Color(r, g, b, a)
    }

    val hsl = Regex(
        """hsla?\(\s*([-0-9.]+)(?:deg)?\s*[, ]\s*([0-9.]+)%\s*[, ]\s*([0-9.]+)%(?:\s*[,/]\s*([0-9.]+)%?)?\s*\)""",
        RegexOption.IGNORE_CASE
    ).matchEntire(value)
    if (hsl != null) {
        val h = ((hsl.groupValues[1].toFloatOrNull() ?: 0f) % 360f + 360f) % 360f
        val sat = ((hsl.groupValues[2].toFloatOrNull() ?: 0f) / 100f).coerceIn(0f, 1f)
        val light = ((hsl.groupValues[3].toFloatOrNull() ?: 0f) / 100f).coerceIn(0f, 1f)
        val alphaRaw = hsl.groupValues.getOrNull(4).orEmpty()
        val alpha = if (alphaRaw.isBlank()) 1f else {
            val n = alphaRaw.toFloatOrNull() ?: 1f
            if (value.substringAfterLast('/').contains('%') || value.substringAfterLast(',').contains('%')) (n / 100f).coerceIn(0f, 1f)
            else n.coerceIn(0f, 1f)
        }
        val c = (1f - kotlin.math.abs(2f * light - 1f)) * sat
        val x = c * (1f - kotlin.math.abs((h / 60f) % 2f - 1f))
        val m = light - c / 2f
        val (rp, gp, bp) = when {
            h < 60f -> Triple(c, x, 0f)
            h < 120f -> Triple(x, c, 0f)
            h < 180f -> Triple(0f, c, x)
            h < 240f -> Triple(0f, x, c)
            h < 300f -> Triple(x, 0f, c)
            else -> Triple(c, 0f, x)
        }
        return Color((rp + m).coerceIn(0f,1f), (gp + m).coerceIn(0f,1f), (bp + m).coerceIn(0f,1f), alpha)
    }
    return null
}

private fun bestContrast(color: Color): Color {
    val luminance = 0.2126f * color.red + 0.7152f * color.green + 0.0722f * color.blue
    return if (luminance > 0.55f) Color(0xFF101010) else Color.White
}

/** DOM aliases used by many Obsidian community themes inside MarkVault's isolated note WebView. */
fun obsidianArticleCompatibilityCss(dark: Boolean): String = """
    html { color-scheme: ${if (dark) "dark" else "light"}; }
    html, body, .app-container, .workspace-leaf-content {
        background: var(--background-primary, var(--bg));
        color: var(--text-normal, var(--fg));
    }
    body {
        --file-line-width: var(--line-width, 100%);
        --metadata-display-reading: block;
        font-family: var(--font-text, var(--font-interface, system-ui, sans-serif));
        font-size: var(--font-text-size, inherit);
    }
    #content.markdown-rendered,
    #content.markdown-preview-view,
    #content.workspace-leaf-content,
    .markdown-source-view.mod-cm6 .cm-scroller {
        background: var(--background-primary, var(--bg));
        color: var(--text-normal, var(--fg));
        font-family: var(--font-text, var(--font-interface, inherit));
        line-height: var(--line-height-normal, 1.6);
    }

    #content p, #content li, #content dd, #content dt, #content td {
        color: var(--text-normal, var(--fg));
    }
    #content strong, #content b { color: var(--bold-color, var(--text-normal, var(--fg))); }
    #content em, #content i { color: var(--italic-color, inherit); }

    #content h1 { color: var(--h1-color, var(--text-normal, var(--heading))); font-family: var(--h1-font, inherit); font-size: var(--h1-size, 2em); font-weight: var(--h1-weight, 700); }
    #content h2 { color: var(--h2-color, var(--text-normal, var(--heading))); font-family: var(--h2-font, inherit); font-size: var(--h2-size, 1.6em); font-weight: var(--h2-weight, 700); }
    #content h3 { color: var(--h3-color, var(--text-normal, var(--heading))); font-family: var(--h3-font, inherit); font-size: var(--h3-size, 1.35em); font-weight: var(--h3-weight, 650); }
    #content h4 { color: var(--h4-color, var(--text-normal, var(--heading))); font-family: var(--h4-font, inherit); font-size: var(--h4-size, 1.15em); font-weight: var(--h4-weight, 650); }
    #content h5 { color: var(--h5-color, var(--text-normal, var(--heading))); font-family: var(--h5-font, inherit); font-size: var(--h5-size, 1.05em); font-weight: var(--h5-weight, 650); }
    #content h6 { color: var(--h6-color, var(--text-muted, var(--heading))); font-family: var(--h6-font, inherit); font-size: var(--h6-size, 1em); font-weight: var(--h6-weight, 650); }

    #content a.wikilink, #content a.internal-link {
        color: var(--link-color, var(--text-accent, var(--accent)));
        text-decoration-color: var(--link-decoration-color, currentColor);
        text-decoration-thickness: var(--link-decoration-thickness, auto);
    }
    #content a.external-link {
        color: var(--link-external-color, var(--link-color, var(--accent)));
        text-decoration-color: var(--link-external-decoration-color, currentColor);
    }
    #content a:hover {
        color: var(--link-color-hover, var(--text-accent-hover, var(--interactive-accent-hover, currentColor)));
    }

    #content blockquote {
        color: var(--blockquote-color, var(--text-normal, var(--fg)));
        border-inline-start-color: var(--blockquote-border-color, var(--interactive-accent, var(--quote-bar)));
        border-inline-start-width: var(--blockquote-border-thickness, 2px);
        background: var(--blockquote-background-color, transparent);
        font-style: var(--blockquote-font-style, normal);
    }

    #content code, #content pre {
        font-family: var(--font-monospace, ui-monospace, monospace);
    }
    #content pre {
        background: var(--code-background, var(--background-secondary, var(--code-bg)));
        color: var(--code-normal, var(--text-normal, var(--code-fg)));
        border-color: var(--background-modifier-border, var(--rule));
        border-radius: var(--code-radius, var(--radius-s, 4px));
    }
    #content :not(pre) > code {
        background: var(--code-background, var(--background-secondary, var(--code-inline-bg)));
        color: var(--code-normal, var(--code-inline-fg));
        border-radius: var(--code-radius, var(--radius-s, 4px));
    }

    #content table {
        border-color: var(--table-border-color, var(--background-modifier-border, var(--table-border)));
        background: var(--table-background, transparent);
    }
    #content th, #content td {
        border-color: var(--table-border-color, var(--background-modifier-border, var(--table-border)));
    }
    #content th {
        background: var(--table-header-background, var(--background-secondary, var(--table-head)));
        color: var(--table-header-color, var(--text-normal, var(--fg)));
        font-weight: var(--table-header-weight, 600);
    }
    #content tr:hover td { background: var(--table-row-background-hover, var(--background-modifier-hover, transparent)); }

    #content hr {
        border-color: var(--hr-color, var(--background-modifier-border, var(--rule)));
        border-width: var(--hr-thickness, 1px) 0 0;
    }
    #content mark {
        background: var(--text-highlight-bg, var(--mark-bg));
        color: var(--text-highlight-fg, var(--mark-fg));
    }
    #content ::selection {
        background: var(--text-selection, var(--interactive-accent));
        color: var(--text-on-accent, inherit);
    }

    #content .callout {
        background: rgba(var(--callout-color, var(--interactive-accent-rgb, 120,100,220)), var(--callout-background-alpha, .1));
        border-color: rgba(var(--callout-color, var(--interactive-accent-rgb, 120,100,220)), var(--callout-border-opacity, .4));
        border-radius: var(--callout-radius, var(--radius-m, 8px));
        border-width: var(--callout-border-width, 1px);
    }
    #content .callout-title {
        color: rgb(var(--callout-color, var(--interactive-accent-rgb, 120,100,220)));
        font-weight: var(--callout-title-weight, 600);
    }
    #content .callout-content, #content .callout-body { color: var(--text-normal, var(--fg)); }

    #content input[type="checkbox"] { accent-color: var(--checkbox-color, var(--interactive-accent)); }
    #content input[type="checkbox"]:checked { background: var(--checkbox-color, var(--interactive-accent)); }
    #content del { color: var(--text-muted, var(--fg-muted)); text-decoration-color: var(--text-faint, currentColor); }

    #content .tag, #content a.tag {
        color: var(--tag-color, var(--text-accent, var(--accent)));
        background: var(--tag-background, var(--background-secondary, var(--surface)));
        border: var(--tag-border-width, 0) solid var(--tag-border-color, var(--background-modifier-border, transparent));
        border-radius: var(--tag-radius, var(--radius-s, 4px));
        font-size: var(--tag-size, .9em);
        font-weight: var(--tag-weight, 500);
    }

    #content img {
        border-radius: var(--image-radius, 0);
        opacity: var(--image-opacity, 1);
    }
    #content details {
        background: var(--background-secondary, transparent);
        border-color: var(--background-modifier-border, var(--rule));
        border-radius: var(--radius-s, 4px);
    }

    /* Advanced Obsidian reading-view structures. */
    #content .metadata-container, #content .frontmatter, #content .frontmatter-container,
    #content .metadata-properties, #content .metadata-property {
        background: var(--metadata-background, var(--background-secondary, transparent));
        color: var(--metadata-label-text-color, var(--text-muted, var(--fg-muted)));
        border-color: var(--metadata-divider-color, var(--background-modifier-border, var(--rule)));
        border-radius: var(--metadata-property-radius, var(--radius-s, 4px));
    }
    #content .metadata-property-key, #content .metadata-property-key-input {
        color: var(--metadata-label-text-color, var(--text-muted, var(--fg-muted)));
        font-weight: var(--metadata-label-font-weight, 600);
    }
    #content .metadata-property-value, #content .metadata-property-value-input {
        color: var(--metadata-input-text-color, var(--text-normal, var(--fg)));
    }

    #content .markdown-embed, #content .internal-embed, #content .markdown-embed-placeholder {
        background: var(--embed-background, var(--background-secondary, transparent));
        border: var(--embed-border-left, 2px solid var(--interactive-accent, var(--accent)));
        border-radius: var(--embed-radius, var(--radius-s, 4px));
        color: var(--text-normal, var(--fg));
    }
    #content .markdown-embed-title, #content .embed-title {
        color: var(--embed-title-color, var(--text-muted, var(--fg-muted)));
        font-size: var(--embed-title-font-size, .85em);
        font-weight: var(--embed-title-font-weight, 600);
    }

    #content .footnotes, #content .footnote-section {
        border-color: var(--footnote-divider-color, var(--background-modifier-border, var(--rule)));
        color: var(--text-muted, var(--fg-muted));
    }
    #content .footnote-ref, #content .footnote-backref {
        color: var(--link-color, var(--text-accent, var(--accent)));
    }

    #content li.task, #content .task-list-item {
        color: var(--text-normal, var(--fg));
    }
    #content li.task.done, #content .task-list-item.is-checked {
        color: var(--checklist-done-color, var(--text-muted, var(--fg-muted)));
        text-decoration-color: var(--checklist-done-decoration-color, currentColor);
    }
    #content li.task .box, #content .task-list-item-checkbox {
        border-color: var(--checkbox-border-color, var(--text-muted, var(--fg-muted)));
        border-radius: var(--checkbox-radius, var(--radius-s, 4px));
        background: var(--checkbox-marker-color, transparent);
    }
    #content li.task.done .box, #content .task-list-item-checkbox:checked {
        background: var(--checkbox-color, var(--interactive-accent, var(--accent)));
        border-color: var(--checkbox-color, var(--interactive-accent, var(--accent)));
    }

    #content ul, #content ol { --list-marker-color: var(--list-marker-color, var(--text-muted, var(--fg-muted))); }
    #content li::marker { color: var(--list-marker-color, var(--text-muted, var(--fg-muted))); }
    #content sup, #content sub { color: var(--text-muted, var(--fg-muted)); }
    #content .math, #content .katex { color: var(--text-normal, var(--fg)); }
    #content .mermaid { background: var(--background-primary, var(--bg)); color: var(--text-normal, var(--fg)); }

    /* Obsidian-compatible aliases for MarkVault-generated structures. */
    #content .callout.cl-note { --callout-color: var(--callout-note, 68,138,255); }
    #content .callout.cl-info { --callout-color: var(--callout-info, 0,184,212); }
    #content .callout.cl-tip { --callout-color: var(--callout-tip, 0,191,165); }
    #content .callout.cl-warning { --callout-color: var(--callout-warning, 255,145,0); }
    #content .callout.cl-danger, #content .callout.cl-error { --callout-color: var(--callout-error, 255,82,82); }
    #content .callout.cl-success { --callout-color: var(--callout-success, 0,200,83); }
    #content .callout.cl-question { --callout-color: var(--callout-question, 100,181,246); }
    #content .callout.cl-quote { --callout-color: var(--callout-quote, 158,158,158); }
""".trimIndent()

/** Build a Compose scheme from the Theme Creator's persisted CSS palette. */
fun customColorSchemeFromJson(base: ColorScheme, json: String?): ColorScheme {
    if (json.isNullOrBlank()) return base
    val obj = runCatching { JSONObject(json) }.getOrNull() ?: return base
    fun parse(key: String, fallback: Color): Color {
        val raw = obj.optString(key, "")
        if (!raw.startsWith("#")) return fallback
        return runCatching {
            Color(android.graphics.Color.parseColor(raw))
        }.getOrElse { fallback }
    }
    val bg = parse("--bg", base.background)
    val fg = parse("--fg", base.onBackground)
    val heading = parse("--heading", base.primary)
    val muted = parse("--fg-muted", base.onSurfaceVariant)
    val accent = parse("--accent", base.primary)
    val rule = parse("--rule", base.outlineVariant)
    val surface = parse("--surface", parse("--code-bg", base.surface))
    val surfaceVariant = parse("--surface-variant", parse("--code-inline-bg", base.surfaceVariant))
    val tableHead = parse("--table-head", base.primaryContainer)
    val tableBorder = parse("--table-border", base.outline)
    val quote = parse("--quote-bar", base.secondary)
    return base.copy(
        primary = accent,
        onPrimary = bg,
        primaryContainer = tableHead,
        onPrimaryContainer = heading,
        secondary = quote,
        onSecondary = bg,
        tertiary = heading,
        onTertiary = bg,
        background = bg,
        onBackground = fg,
        surface = surface,
        onSurface = fg,
        surfaceVariant = surfaceVariant,
        onSurfaceVariant = muted,
        outline = tableBorder,
        outlineVariant = rule
    )
}
