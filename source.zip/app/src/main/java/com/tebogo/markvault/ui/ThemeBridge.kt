package com.tebogo.markvault.ui

import androidx.compose.material3.ColorScheme
import androidx.compose.material3.Shapes
import androidx.compose.runtime.Composable
import androidx.compose.runtime.staticCompositionLocalOf
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.toArgb
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.ui.unit.dp
import com.tebogo.markvault.data.ObsidianThemePayload
import org.json.JSONObject

/** Target (non-animated) app palette, provided by MarkVaultTheme for WebView/theme bridges. */
val LocalMarkVaultTargetColorScheme = staticCompositionLocalOf<ColorScheme?> { null }
val LocalObsidianThemeVariables = staticCompositionLocalOf<Map<String, String>> { emptyMap() }

@Composable
fun obsidianUiColor(vararg names: String): Color? {
    val vars = LocalObsidianThemeVariables.current
    for (name in names) {
        val raw = vars[name] ?: continue
        parseObsidianCssColor(raw)?.let { return it }
    }
    return null
}

/**
 * Single bridge between MarkVault's Compose palette and article/WebView colors.
 * This keeps app chrome and rendered notes on the same theme vocabulary.
 */
fun articleThemeVariables(scheme: ColorScheme, customJson: String? = null): LinkedHashMap<String, String> {
    fun hex(c: Color): String = String.format("#%06X", 0xFFFFFF and c.toArgb())
    val vars = linkedMapOf(
        "--bg" to hex(scheme.background),
        "--fg" to hex(scheme.onBackground),
        "--heading" to hex(scheme.primary),
        "--fg-muted" to hex(scheme.onSurfaceVariant),
        "--accent" to hex(scheme.primary),
        "--rule" to hex(scheme.outlineVariant),
        "--surface" to hex(scheme.surface),
        "--surface-variant" to hex(scheme.surfaceVariant),
        "--code-bg" to hex(scheme.surfaceVariant),
        "--code-fg" to hex(scheme.onSurface),
        "--code-inline-bg" to hex(scheme.surfaceVariant),
        "--code-inline-fg" to hex(scheme.tertiary),
        "--table-head" to hex(scheme.surfaceVariant),
        "--table-border" to hex(scheme.outline),
        "--quote-bar" to hex(scheme.secondary),
        "--mark-bg" to hex(scheme.primaryContainer),
        "--mark-fg" to hex(scheme.onPrimaryContainer)
    )
    if (!customJson.isNullOrBlank()) {
        runCatching {
            val obj = JSONObject(customJson)
            obj.keys().forEach { key ->
                if (key.startsWith("--")) {
                    val value = obj.optString(key)
                    if (value.startsWith("#") && value.length in 4..9) vars[key] = value
                }
            }
        }
    }
    return vars
}

fun articleThemeJson(scheme: ColorScheme, customJson: String? = null): String =
    JSONObject(articleThemeVariables(scheme, customJson) as Map<*, *>).toString()

fun articleThemeHtmlCss(scheme: ColorScheme, customJson: String? = null, themeName: String? = null, boldBodyText: Boolean = false, obsidianCss: String? = null, obsidianDark: Boolean = true): String {
    val v = articleThemeVariables(scheme, customJson)
    fun x(name: String) = v[name] ?: "#000000"
    val glass3d = themeName == "glass_obsidian" || themeName == "glass_crystal"
    val artifactCss = artifactArticleCss(themeName, scheme)
    val bodyWeightCss = if (boldBodyText) "body,p,li,dd,dt,td{font-weight:600!important;}" else ""
    val glassCss = if (glass3d) """
        html,body{background-image:linear-gradient(145deg,${x("--bg")} 0%,${x("--surface-variant")} 52%,${x("--bg")} 100%)!important;background-attachment:fixed!important;}
        blockquote,pre,details,table{border-radius:14px!important;border:1px solid ${x("--rule")}!important;box-shadow:0 12px 28px rgba(0,0,0,.16)!important;}
        blockquote,details{background:${x("--surface")}!important;}
        img{border-radius:14px!important;box-shadow:0 12px 30px rgba(0,0,0,.16)!important;}
    """.trimIndent() else ""
    val importedObsidian = themeName == "obsidian_imported" && !obsidianCss.isNullOrBlank()
    val priority = if (importedObsidian) "" else "!important"
    val compatibilityCss = if (importedObsidian) obsidianArticleCompatibilityCss(obsidianDark) else ""
    val importedCssBlock = if (importedObsidian) {
        val variant = if (obsidianDark) "dark" else "light"
        "<style id=\"mv-obsidian-theme\">$compatibilityCss\n${obsidianCss.orEmpty()}</style>" +
            "<script id=\"mv-obsidian-class\">(function(){document.documentElement.classList.add('theme-$variant','obsidian-app');function a(){if(document.body)document.body.classList.add('theme-$variant','obsidian-app','mv-obsidian-theme');}if(document.readyState==='loading')document.addEventListener('DOMContentLoaded',a);else a();})();</script>"
    } else ""
    return """
        <style id="mv-global-theme">
        :root{${v.entries.joinToString("") { "${it.key}:${it.value};" }}}
        html,body{background:${x("--bg")}$priority;color:${x("--fg")}$priority;}
        body,p,li,dd,dt,td{color:${x("--fg")}$priority;}
        h1,h2,h3,h4,h5,h6,strong{color:${x("--heading")}$priority;}
        a,a:visited{color:${x("--accent")}$priority;}
        blockquote{color:${x("--fg")}$priority;border-color:${x("--quote-bar")}$priority;background:${x("--surface")}$priority;}
        pre{background:${x("--code-bg")}$priority;color:${x("--code-fg")}$priority;border-color:${x("--rule")}$priority;}
        code{color:${x("--code-inline-fg")}$priority;}
        :not(pre)>code{background:${x("--code-inline-bg")}$priority;}
        table,th,td{border-color:${x("--table-border")}$priority;}
        th{background:${x("--table-head")}$priority;color:${x("--heading")}$priority;}
        hr{border-color:${x("--rule")}$priority;}
        $bodyWeightCss
        $glassCss
        $artifactCss
        </style>
        $importedCssBlock
    """.trimIndent()
}


/**
 * Map the common Obsidian CSS-variable vocabulary onto Material 3. The original
 * CSS is still used by the article renderer; this mapping is what makes native
 * Compose Workspace chrome follow the same imported theme.
 */
fun obsidianColorSchemeFromPayload(base: ColorScheme, payload: ObsidianThemePayload?, dark: Boolean): ColorScheme {
    if (payload == null) return base
    val vars = payload.variables(dark)
    fun first(vararg names: String): String? = names.firstNotNullOfOrNull { vars[it]?.takeIf(String::isNotBlank) }
    fun color(fallback: Color, vararg names: String): Color {
        val raw = first(*names) ?: return fallback
        return parseObsidianCssColor(raw) ?: fallback
    }

    val bg = color(base.background, "--background-primary", "--background-primary-alt", "--background-modifier-form-field")
    val surface = color(base.surface, "--background-secondary", "--background-primary-alt", "--background-modifier-form-field")
    val surfaceVariant = color(base.surfaceVariant, "--background-secondary-alt", "--background-modifier-hover", "--background-modifier-active-hover")
    val fg = color(base.onBackground, "--text-normal", "--text-primary")
    val muted = color(base.onSurfaceVariant, "--text-muted", "--text-faint")
    val accent = color(base.primary, "--interactive-accent", "--text-accent", "--color-accent", "--link-color")
    val accentHover = color(base.secondary, "--interactive-accent-hover", "--text-accent-hover", "--link-color-hover")
    val heading = color(base.tertiary, "--h1-color", "--h2-color", "--text-title-h1", "--text-normal")
    val border = color(base.outline, "--background-modifier-border", "--divider-color", "--tab-outline-color")
    val borderSoft = color(base.outlineVariant, "--background-modifier-border-hover", "--background-modifier-border-focus", "--divider-color")
    val selected = color(base.primaryContainer, "--background-modifier-active-hover", "--interactive-accent", "--tab-background-active")
    val selectedText = color(base.onPrimaryContainer, "--text-on-accent", "--text-normal")

    return base.copy(
        primary = accent,
        onPrimary = color(bestContrast(accent), "--text-on-accent", "--text-on-accent-inverted"),
        primaryContainer = selected,
        onPrimaryContainer = selectedText,
        secondary = accentHover,
        onSecondary = bestContrast(accentHover),
        tertiary = heading,
        onTertiary = bestContrast(heading),
        background = bg,
        onBackground = fg,
        surface = surface,
        onSurface = fg,
        surfaceVariant = surfaceVariant,
        onSurfaceVariant = muted,
        outline = border,
        outlineVariant = borderSoft
    )
}

fun obsidianShapesFromPayload(payload: ObsidianThemePayload?, dark: Boolean): Shapes {
    val vars = payload?.variables(dark).orEmpty()
    fun radius(vararg keys: String, fallback: Float): Float {
        val raw = keys.firstNotNullOfOrNull { vars[it] } ?: return fallback
        val n = Regex("[-+]?[0-9]*\\.?[0-9]+").find(raw)?.value?.toFloatOrNull() ?: return fallback
        return n.coerceIn(0f, 32f)
    }
    val small = radius("--radius-s", "--input-radius", fallback = 4f)
    val medium = radius("--radius-m", "--button-radius", "--tab-radius-active", fallback = 8f)
    val large = radius("--radius-l", "--modal-radius", fallback = 12f)
    return Shapes(
        extraSmall = RoundedCornerShape(small.dp),
        small = RoundedCornerShape(small.dp),
        medium = RoundedCornerShape(medium.dp),
        large = RoundedCornerShape(large.dp),
        extraLarge = RoundedCornerShape((large * 1.5f).coerceAtMost(36f).dp)
    )
}

private fun parseObsidianCssColor(raw: String): Color? {
    val value = raw.trim().substringBefore(" !important").trim()
    return runCatching { Color(android.graphics.Color.parseColor(value)) }.getOrNull()
}

private fun bestContrast(color: Color): Color {
    val luminance = 0.2126f * color.red + 0.7152f * color.green + 0.0722f * color.blue
    return if (luminance > 0.55f) Color(0xFF101010) else Color.White
}

/** DOM aliases used by many Obsidian community themes inside MarkVault's isolated note WebView. */
fun obsidianArticleCompatibilityCss(dark: Boolean): String = """
    html { color-scheme: ${if (dark) "dark" else "light"}; }
    body { background: var(--background-primary, var(--bg)); color: var(--text-normal, var(--fg)); }
    #content.markdown-rendered, #content.markdown-preview-view {
        background: var(--background-primary, var(--bg)); color: var(--text-normal, var(--fg));
        font-family: var(--font-text, var(--font-interface, inherit));
    }
    #content a.wikilink, #content a.internal-link { color: var(--link-color, var(--text-accent, var(--accent))); }
    #content a.external-link { color: var(--link-external-color, var(--link-color, var(--accent))); }
    #content h1 { color: var(--h1-color, var(--text-normal, var(--heading))); font-family: var(--h1-font, inherit); }
    #content h2 { color: var(--h2-color, var(--text-normal, var(--heading))); font-family: var(--h2-font, inherit); }
    #content h3 { color: var(--h3-color, var(--text-normal, var(--heading))); }
    #content h4 { color: var(--h4-color, var(--text-normal, var(--heading))); }
    #content h5 { color: var(--h5-color, var(--text-normal, var(--heading))); }
    #content h6 { color: var(--h6-color, var(--text-normal, var(--heading))); }
    #content blockquote { border-color: var(--blockquote-border-color, var(--interactive-accent, var(--quote-bar))); }
    #content table { border-color: var(--table-border-color, var(--background-modifier-border, var(--table-border))); }
    #content th { background: var(--table-header-background, var(--background-secondary, var(--table-head))); }
    #content code { font-family: var(--font-monospace, monospace); }
    #content .callout { --callout-color: var(--interactive-accent-rgb, 120, 100, 220); }
""".trimIndent()

/** Build a Compose scheme from the Theme Creator's persisted CSS palette. */
fun customColorSchemeFromJson(base: ColorScheme, json: String?): ColorScheme {
    if (json.isNullOrBlank()) return base
    val obj = runCatching { JSONObject(json) }.getOrNull() ?: return base
    fun parse(key: String, fallback: Color): Color {
        val raw = obj.optString(key, "")
        if (!raw.startsWith("#")) return fallback
        return runCatching {
            Color(android.graphics.Color.parseColor(raw))
        }.getOrElse { fallback }
    }
    val bg = parse("--bg", base.background)
    val fg = parse("--fg", base.onBackground)
    val heading = parse("--heading", base.primary)
    val muted = parse("--fg-muted", base.onSurfaceVariant)
    val accent = parse("--accent", base.primary)
    val rule = parse("--rule", base.outlineVariant)
    val surface = parse("--surface", parse("--code-bg", base.surface))
    val surfaceVariant = parse("--surface-variant", parse("--code-inline-bg", base.surfaceVariant))
    val tableHead = parse("--table-head", base.primaryContainer)
    val tableBorder = parse("--table-border", base.outline)
    val quote = parse("--quote-bar", base.secondary)
    return base.copy(
        primary = accent,
        onPrimary = bg,
        primaryContainer = tableHead,
        onPrimaryContainer = heading,
        secondary = quote,
        onSecondary = bg,
        tertiary = heading,
        onTertiary = bg,
        background = bg,
        onBackground = fg,
        surface = surface,
        onSurface = fg,
        surfaceVariant = surfaceVariant,
        onSurfaceVariant = muted,
        outline = tableBorder,
        outlineVariant = rule
    )
}
