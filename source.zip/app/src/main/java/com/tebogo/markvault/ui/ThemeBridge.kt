package com.tebogo.markvault.ui

import androidx.compose.material3.ColorScheme
import androidx.compose.material3.Shapes
import androidx.compose.runtime.Composable
import androidx.compose.runtime.staticCompositionLocalOf
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.toArgb
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.ui.unit.dp
import com.tebogo.markvault.data.ObsidianThemePayload
import org.json.JSONObject

/** Target (non-animated) app palette, provided by MarkVaultTheme for WebView/theme bridges. */
val LocalMarkVaultTargetColorScheme = staticCompositionLocalOf<ColorScheme?> { null }
val LocalObsidianThemeVariables = staticCompositionLocalOf<Map<String, String>> { emptyMap() }

@Composable
fun obsidianUiColor(vararg names: String): Color? {
    val vars = LocalObsidianThemeVariables.current
    for (name in names) {
        val raw = vars[name] ?: continue
        parseObsidianCssColor(raw)?.let { return it }
    }
    return null
}

/**
 * Single bridge between MarkVault's Compose palette and article/WebView colors.
 * This keeps app chrome and rendered notes on the same theme vocabulary.
 */
fun articleThemeVariables(scheme: ColorScheme, customJson: String? = null): LinkedHashMap<String, String> {
    fun hex(c: Color): String = String.format("#%06X", 0xFFFFFF and c.toArgb())
    val vars = linkedMapOf(
        "--bg" to hex(scheme.background),
        "--fg" to hex(scheme.onBackground),
        "--heading" to hex(scheme.primary),
        "--fg-muted" to hex(scheme.onSurfaceVariant),
        "--accent" to hex(scheme.primary),
        "--rule" to hex(scheme.outlineVariant),
        "--surface" to hex(scheme.surface),
        "--surface-variant" to hex(scheme.surfaceVariant),
        "--code-bg" to hex(scheme.surfaceVariant),
        "--code-fg" to hex(scheme.onSurface),
        "--code-inline-bg" to hex(scheme.surfaceVariant),
        "--code-inline-fg" to hex(scheme.tertiary),
        "--table-head" to hex(scheme.surfaceVariant),
        "--table-border" to hex(scheme.outline),
        "--quote-bar" to hex(scheme.secondary),
        "--mark-bg" to hex(scheme.primaryContainer),
        "--mark-fg" to hex(scheme.onPrimaryContainer)
    )
    if (!customJson.isNullOrBlank()) {
        runCatching {
            val obj = JSONObject(customJson)
            obj.keys().forEach { key ->
                if (key.startsWith("--")) {
                    val value = obj.optString(key)
                    if (value.startsWith("#") && value.length in 4..9) vars[key] = value
                }
            }
        }
    }
    return vars
}

fun articleThemeJson(scheme: ColorScheme, customJson: String? = null): String =
    JSONObject(articleThemeVariables(scheme, customJson) as Map<*, *>).toString()

fun articleThemeHtmlCss(scheme: ColorScheme, customJson: String? = null, themeName: String? = null, boldBodyText: Boolean = false, obsidianCss: String? = null, obsidianDark: Boolean = true): String {
    val v = articleThemeVariables(scheme, customJson)
    fun x(name: String) = v[name] ?: "#000000"
    val glass3d = themeName == "glass_obsidian" || themeName == "glass_crystal"
    val artifactCss = artifactArticleCss(themeName, scheme)
    val bodyWeightCss = if (boldBodyText) "body,p,li,dd,dt,td{font-weight:600!important;}" else ""
    val glassCss = if (glass3d) """
        html,body{background-image:linear-gradient(145deg,${x("--bg")} 0%,${x("--surface-variant")} 52%,${x("--bg")} 100%)!important;background-attachment:fixed!important;}
        blockquote,pre,details,table{border-radius:14px!important;border:1px solid ${x("--rule")}!important;box-shadow:0 12px 28px rgba(0,0,0,.16)!important;}
        blockquote,details{background:${x("--surface")}!important;}
        img{border-radius:14px!important;box-shadow:0 12px 30px rgba(0,0,0,.16)!important;}
    """.trimIndent() else ""
    val importedObsidian = themeName == "obsidian_imported" && !obsidianCss.isNullOrBlank()
    val priority = if (importedObsidian) "" else "!important"
    val compatibilityCss = if (importedObsidian) obsidianArticleCompatibilityCss(obsidianDark) else ""
    val importedCssBlock = if (importedObsidian) {
        val variant = if (obsidianDark) "dark" else "light"
        "<style id=\"mv-obsidian-theme\">$compatibilityCss\n${obsidianCss.orEmpty()}</style>" +
            "<script id=\"mv-obsidian-class\">(function(){document.documentElement.classList.add('theme-$variant','obsidian-app');function a(){if(document.body){document.body.classList.add('theme-$variant','obsidian-app','mv-obsidian-theme','markdown-rendered','markdown-preview-view','workspace-leaf-content','markdown-reading-view','view-content','mod-active');document.body.dataset.type='markdown';document.body.dataset.mode='preview';}}if(document.readyState==='loading')document.addEventListener('DOMContentLoaded',a);else a();})();</script>"
    } else ""
    return """
        <style id="mv-global-theme">
        :root{${v.entries.joinToString("") { "${it.key}:${it.value};" }}}
        html,body{background:${x("--bg")}$priority;color:${x("--fg")}$priority;}
        body,p,li,dd,dt,td{color:${x("--fg")}$priority;}
        h1,h2,h3,h4,h5,h6,strong{color:${x("--heading")}$priority;}
        a,a:visited{color:${x("--accent")}$priority;}
        blockquote{color:${x("--fg")}$priority;border-color:${x("--quote-bar")}$priority;background:${x("--surface")}$priority;}
        pre{background:${x("--code-bg")}$priority;color:${x("--code-fg")}$priority;border-color:${x("--rule")}$priority;}
        code{color:${x("--code-inline-fg")}$priority;}
        :not(pre)>code{background:${x("--code-inline-bg")}$priority;}
        table,th,td{border-color:${x("--table-border")}$priority;}
        th{background:${x("--table-head")}$priority;color:${x("--heading")}$priority;}
        hr{border-color:${x("--rule")}$priority;}
        $bodyWeightCss
        $glassCss
        $artifactCss
        </style>
        $importedCssBlock
    """.trimIndent()
}


/**
 * Map the common Obsidian CSS-variable vocabulary onto Material 3. The original
 * CSS is still used by the article renderer; this mapping is what makes native
 * Compose Workspace chrome follow the same imported theme.
 */
fun obsidianColorSchemeFromPayload(base: ColorScheme, payload: ObsidianThemePayload?, dark: Boolean): ColorScheme {
    if (payload == null) return base
    val vars = payload.variables(dark)
    fun first(vararg names: String): String? = names.firstNotNullOfOrNull { vars[it]?.takeIf(String::isNotBlank) }
    fun color(fallback: Color, vararg names: String): Color {
        val raw = first(*names) ?: return fallback
        return parseObsidianCssColor(raw) ?: fallback
    }

    val bg = color(base.background, "--background-primary", "--background-primary-alt", "--background-modifier-form-field")
    val surface = color(base.surface, "--background-secondary", "--background-primary-alt", "--background-modifier-form-field")
    val surfaceVariant = color(base.surfaceVariant, "--background-secondary-alt", "--background-modifier-hover", "--background-modifier-active-hover")
    val fg = color(base.onBackground, "--text-normal", "--text-primary")
    val muted = color(base.onSurfaceVariant, "--text-muted", "--text-faint")
    val accent = color(base.primary, "--interactive-accent", "--text-accent", "--color-accent", "--link-color")
    val accentHover = color(base.secondary, "--interactive-accent-hover", "--text-accent-hover", "--link-color-hover")
    val heading = color(base.tertiary, "--h1-color", "--h2-color", "--text-title-h1", "--text-normal")
    val border = color(base.outline, "--background-modifier-border", "--divider-color", "--tab-outline-color")
    val borderSoft = color(base.outlineVariant, "--background-modifier-border-hover", "--background-modifier-border-focus", "--divider-color")
    val selected = color(base.primaryContainer, "--background-modifier-active-hover", "--interactive-accent", "--tab-background-active", "--background-modifier-hover")
    val selectedText = color(base.onPrimaryContainer, "--text-on-accent", "--tab-text-color-focused-active", "--text-normal")
    val error = color(base.error, "--text-error", "--background-modifier-error", "--color-red")
    val errorContainer = color(base.errorContainer, "--background-modifier-error-hover", "--background-modifier-error")
    val onError = color(bestContrast(error), "--text-on-accent", "--text-normal")
    val inverseSurface = color(base.inverseSurface, "--background-primary-alt", "--background-secondary")
    val inverseText = color(base.inverseOnSurface, "--text-normal", "--text-muted")

    return base.copy(
        primary = accent,
        onPrimary = color(bestContrast(accent), "--text-on-accent", "--text-on-accent-inverted"),
        primaryContainer = selected,
        onPrimaryContainer = selectedText,
        secondary = accentHover,
        onSecondary = bestContrast(accentHover),
        tertiary = heading,
        onTertiary = bestContrast(heading),
        background = bg,
        onBackground = fg,
        surface = surface,
        onSurface = fg,
        surfaceVariant = surfaceVariant,
        onSurfaceVariant = muted,
        outline = border,
        outlineVariant = borderSoft,
        error = error,
        onError = onError,
        errorContainer = errorContainer,
        onErrorContainer = color(bestContrast(errorContainer), "--text-error", "--text-normal"),
        inverseSurface = inverseSurface,
        inverseOnSurface = inverseText,
        inversePrimary = color(base.inversePrimary, "--interactive-accent-hover", "--text-accent")
    )
}

fun obsidianShapesFromPayload(payload: ObsidianThemePayload?, dark: Boolean): Shapes {
    val vars = payload?.variables(dark).orEmpty()
    fun radius(vararg keys: String, fallback: Float): Float {
        val raw = keys.firstNotNullOfOrNull { vars[it] } ?: return fallback
        val n = Regex("[-+]?[0-9]*\\.?[0-9]+").find(raw)?.value?.toFloatOrNull() ?: return fallback
        return n.coerceIn(0f, 32f)
    }
    val small = radius("--radius-s", "--input-radius", fallback = 4f)
    val medium = radius("--radius-m", "--button-radius", "--tab-radius-active", fallback = 8f)
    val large = radius("--radius-l", "--modal-radius", fallback = 12f)
    return Shapes(
        extraSmall = RoundedCornerShape(small.dp),
        small = RoundedCornerShape(small.dp),
        medium = RoundedCornerShape(medium.dp),
        large = RoundedCornerShape(large.dp),
        extraLarge = RoundedCornerShape((large * 1.5f).coerceAtMost(36f).dp)
    )
}

private fun parseObsidianCssColor(raw: String): Color? {
    val value = raw.trim().substringBefore(" !important").trim()
    if (value.isBlank() || value.startsWith("var(") || value.startsWith("color-mix(")) return null

    // Android handles hex and named CSS colors that are also Android color names.
    runCatching { Color(android.graphics.Color.parseColor(value)) }.getOrNull()?.let { return it }

    val rgb = Regex(
        """rgba?\(\s*([0-9.]+)%?\s*[, ]\s*([0-9.]+)%?\s*[, ]\s*([0-9.]+)%?(?:\s*[,/]\s*([0-9.]+)%?)?\s*\)""",
        RegexOption.IGNORE_CASE
    ).matchEntire(value)
    if (rgb != null) {
        fun channel(rawPart: String, percent: Boolean): Float {
            val n = rawPart.toFloatOrNull() ?: 0f
            return if (percent) (n / 100f).coerceIn(0f, 1f) else (n / 255f).coerceIn(0f, 1f)
        }
        val percent = value.substringBefore(')').contains('%') &&
            rgb.groupValues[1].let { value.contains("$it%") }
        val r = channel(rgb.groupValues[1], percent)
        val g = channel(rgb.groupValues[2], percent)
        val b = channel(rgb.groupValues[3], percent)
        val alphaRaw = rgb.groupValues.getOrNull(4).orEmpty()
        val a = when {
            alphaRaw.isBlank() -> 1f
            value.substringAfterLast('/').contains('%') || value.substringAfterLast(',').contains('%') ->
                (alphaRaw.toFloatOrNull() ?: 100f).div(100f).coerceIn(0f, 1f)
            else -> (alphaRaw.toFloatOrNull() ?: 1f).coerceIn(0f, 1f)
        }
        return Color(r, g, b, a)
    }

    val hsl = Regex(
        """hsla?\(\s*([-0-9.]+)(?:deg)?\s*[, ]\s*([0-9.]+)%\s*[, ]\s*([0-9.]+)%(?:\s*[,/]\s*([0-9.]+)%?)?\s*\)""",
        RegexOption.IGNORE_CASE
    ).matchEntire(value)
    if (hsl != null) {
        val h = ((hsl.groupValues[1].toFloatOrNull() ?: 0f) % 360f + 360f) % 360f
        val sat = ((hsl.groupValues[2].toFloatOrNull() ?: 0f) / 100f).coerceIn(0f, 1f)
        val light = ((hsl.groupValues[3].toFloatOrNull() ?: 0f) / 100f).coerceIn(0f, 1f)
        val alphaRaw = hsl.groupValues.getOrNull(4).orEmpty()
        val alpha = if (alphaRaw.isBlank()) 1f else {
            val n = alphaRaw.toFloatOrNull() ?: 1f
            if (value.substringAfterLast('/').contains('%') || value.substringAfterLast(',').contains('%')) (n / 100f).coerceIn(0f, 1f)
            else n.coerceIn(0f, 1f)
        }
        val c = (1f - kotlin.math.abs(2f * light - 1f)) * sat
        val x = c * (1f - kotlin.math.abs((h / 60f) % 2f - 1f))
        val m = light - c / 2f
        val (rp, gp, bp) = when {
            h < 60f -> Triple(c, x, 0f)
            h < 120f -> Triple(x, c, 0f)
            h < 180f -> Triple(0f, c, x)
            h < 240f -> Triple(0f, x, c)
            h < 300f -> Triple(x, 0f, c)
            else -> Triple(c, 0f, x)
        }
        return Color((rp + m).coerceIn(0f,1f), (gp + m).coerceIn(0f,1f), (bp + m).coerceIn(0f,1f), alpha)
    }
    return null
}

private fun bestContrast(color: Color): Color {
    val luminance = 0.2126f * color.red + 0.7152f * color.green + 0.0722f * color.blue
    return if (luminance > 0.55f) Color(0xFF101010) else Color.White
}

/** DOM aliases used by many Obsidian community themes inside MarkVault's isolated note WebView. */
fun obsidianArticleCompatibilityCss(dark: Boolean): String = """
    html { color-scheme: ${if (dark) "dark" else "light"}; }
    html, body, .app-container, .workspace-leaf-content {
        background: var(--background-primary, var(--bg));
        color: var(--text-normal, var(--fg));
    }
    body {
        --file-line-width: var(--line-width, 100%);
        --metadata-display-reading: block;
        font-family: var(--font-text, var(--font-interface, system-ui, sans-serif));
        font-size: var(--font-text-size, inherit);
    }
    #content.markdown-rendered,
    #content.markdown-preview-view,
    #content.workspace-leaf-content,
    .markdown-source-view.mod-cm6 .cm-scroller {
        background: var(--background-primary, var(--bg));
        color: var(--text-normal, var(--fg));
        font-family: var(--font-text, var(--font-interface, inherit));
        line-height: var(--line-height-normal, 1.6);
    }

    #content p, #content li, #content dd, #content dt, #content td {
        color: var(--text-normal, var(--fg));
    }
    #content strong, #content b { color: var(--bold-color, var(--text-normal, var(--fg))); }
    #content em, #content i { color: var(--italic-color, inherit); }

    #content h1 { color: var(--h1-color, var(--text-normal, var(--heading))); font-family: var(--h1-font, inherit); font-size: var(--h1-size, 2em); font-weight: var(--h1-weight, 700); }
    #content h2 { color: var(--h2-color, var(--text-normal, var(--heading))); font-family: var(--h2-font, inherit); font-size: var(--h2-size, 1.6em); font-weight: var(--h2-weight, 700); }
    #content h3 { color: var(--h3-color, var(--text-normal, var(--heading))); font-family: var(--h3-font, inherit); font-size: var(--h3-size, 1.35em); font-weight: var(--h3-weight, 650); }
    #content h4 { color: var(--h4-color, var(--text-normal, var(--heading))); font-family: var(--h4-font, inherit); font-size: var(--h4-size, 1.15em); font-weight: var(--h4-weight, 650); }
    #content h5 { color: var(--h5-color, var(--text-normal, var(--heading))); font-family: var(--h5-font, inherit); font-size: var(--h5-size, 1.05em); font-weight: var(--h5-weight, 650); }
    #content h6 { color: var(--h6-color, var(--text-muted, var(--heading))); font-family: var(--h6-font, inherit); font-size: var(--h6-size, 1em); font-weight: var(--h6-weight, 650); }

    #content a.wikilink, #content a.internal-link {
        color: var(--link-color, var(--text-accent, var(--accent)));
        text-decoration-color: var(--link-decoration-color, currentColor);
        text-decoration-thickness: var(--link-decoration-thickness, auto);
    }
    #content a.external-link {
        color: var(--link-external-color, var(--link-color, var(--accent)));
        text-decoration-color: var(--link-external-decoration-color, currentColor);
    }
    #content a:hover {
        color: var(--link-color-hover, var(--text-accent-hover, var(--interactive-accent-hover, currentColor)));
    }

    #content blockquote {
        color: var(--blockquote-color, var(--text-normal, var(--fg)));
        border-inline-start-color: var(--blockquote-border-color, var(--interactive-accent, var(--quote-bar)));
        border-inline-start-width: var(--blockquote-border-thickness, 2px);
        background: var(--blockquote-background-color, transparent);
        font-style: var(--blockquote-font-style, normal);
    }

    #content code, #content pre {
        font-family: var(--font-monospace, ui-monospace, monospace);
    }
    #content pre {
        background: var(--code-background, var(--background-secondary, var(--code-bg)));
        color: var(--code-normal, var(--text-normal, var(--code-fg)));
        border-color: var(--background-modifier-border, var(--rule));
        border-radius: var(--code-radius, var(--radius-s, 4px));
    }
    #content :not(pre) > code {
        background: var(--code-background, var(--background-secondary, var(--code-inline-bg)));
        color: var(--code-normal, var(--code-inline-fg));
        border-radius: var(--code-radius, var(--radius-s, 4px));
    }

    #content table {
        border-color: var(--table-border-color, var(--background-modifier-border, var(--table-border)));
        background: var(--table-background, transparent);
    }
    #content th, #content td {
        border-color: var(--table-border-color, var(--background-modifier-border, var(--table-border)));
    }
    #content th {
        background: var(--table-header-background, var(--background-secondary, var(--table-head)));
        color: var(--table-header-color, var(--text-normal, var(--fg)));
        font-weight: var(--table-header-weight, 600);
    }
    #content tr:hover td { background: var(--table-row-background-hover, var(--background-modifier-hover, transparent)); }

    #content hr {
        border-color: var(--hr-color, var(--background-modifier-border, var(--rule)));
        border-width: var(--hr-thickness, 1px) 0 0;
    }
    #content mark {
        background: var(--text-highlight-bg, var(--mark-bg));
        color: var(--text-highlight-fg, var(--mark-fg));
    }
    #content ::selection {
        background: var(--text-selection, var(--interactive-accent));
        color: var(--text-on-accent, inherit);
    }

    #content .callout {
        background: rgba(var(--callout-color, var(--interactive-accent-rgb, 120,100,220)), var(--callout-background-alpha, .1));
        border-color: rgba(var(--callout-color, var(--interactive-accent-rgb, 120,100,220)), var(--callout-border-opacity, .4));
        border-radius: var(--callout-radius, var(--radius-m, 8px));
        border-width: var(--callout-border-width, 1px);
    }
    #content .callout-title {
        color: rgb(var(--callout-color, var(--interactive-accent-rgb, 120,100,220)));
        font-weight: var(--callout-title-weight, 600);
    }
    #content .callout-content, #content .callout-body { color: var(--text-normal, var(--fg)); }

    #content input[type="checkbox"] { accent-color: var(--checkbox-color, var(--interactive-accent)); }
    #content input[type="checkbox"]:checked { background: var(--checkbox-color, var(--interactive-accent)); }
    #content del { color: var(--text-muted, var(--fg-muted)); text-decoration-color: var(--text-faint, currentColor); }

    #content .tag, #content a.tag {
        color: var(--tag-color, var(--text-accent, var(--accent)));
        background: var(--tag-background, var(--background-secondary, var(--surface)));
        border: var(--tag-border-width, 0) solid var(--tag-border-color, var(--background-modifier-border, transparent));
        border-radius: var(--tag-radius, var(--radius-s, 4px));
        font-size: var(--tag-size, .9em);
        font-weight: var(--tag-weight, 500);
    }

    #content img {
        border-radius: var(--image-radius, 0);
        opacity: var(--image-opacity, 1);
    }
    #content details {
        background: var(--background-secondary, transparent);
        border-color: var(--background-modifier-border, var(--rule));
        border-radius: var(--radius-s, 4px);
    }

    /* Obsidian-compatible aliases for MarkVault-generated structures. */
    #content .callout.cl-note { --callout-color: var(--callout-note, 68,138,255); }
    #content .callout.cl-info { --callout-color: var(--callout-info, 0,184,212); }
    #content .callout.cl-tip { --callout-color: var(--callout-tip, 0,191,165); }
    #content .callout.cl-warning { --callout-color: var(--callout-warning, 255,145,0); }
    #content .callout.cl-danger, #content .callout.cl-error { --callout-color: var(--callout-error, 255,82,82); }
    #content .callout.cl-success { --callout-color: var(--callout-success, 0,200,83); }
    #content .callout.cl-question { --callout-color: var(--callout-question, 100,181,246); }
    #content .callout.cl-quote { --callout-color: var(--callout-quote, 158,158,158); }
""".trimIndent()

/** Build a Compose scheme from the Theme Creator's persisted CSS palette. */
fun customColorSchemeFromJson(base: ColorScheme, json: String?): ColorScheme {
    if (json.isNullOrBlank()) return base
    val obj = runCatching { JSONObject(json) }.getOrNull() ?: return base
    fun parse(key: String, fallback: Color): Color {
        val raw = obj.optString(key, "")
        if (!raw.startsWith("#")) return fallback
        return runCatching {
            Color(android.graphics.Color.parseColor(raw))
        }.getOrElse { fallback }
    }
    val bg = parse("--bg", base.background)
    val fg = parse("--fg", base.onBackground)
    val heading = parse("--heading", base.primary)
    val muted = parse("--fg-muted", base.onSurfaceVariant)
    val accent = parse("--accent", base.primary)
    val rule = parse("--rule", base.outlineVariant)
    val surface = parse("--surface", parse("--code-bg", base.surface))
    val surfaceVariant = parse("--surface-variant", parse("--code-inline-bg", base.surfaceVariant))
    val tableHead = parse("--table-head", base.primaryContainer)
    val tableBorder = parse("--table-border", base.outline)
    val quote = parse("--quote-bar", base.secondary)
    return base.copy(
        primary = accent,
        onPrimary = bg,
        primaryContainer = tableHead,
        onPrimaryContainer = heading,
        secondary = quote,
        onSecondary = bg,
        tertiary = heading,
        onTertiary = bg,
        background = bg,
        onBackground = fg,
        surface = surface,
        onSurface = fg,
        surfaceVariant = surfaceVariant,
        onSurfaceVariant = muted,
        outline = tableBorder,
        outlineVariant = rule
    )
}
