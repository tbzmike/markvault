package com.tebogo.markvault.ui

import androidx.compose.material3.ColorScheme
import androidx.compose.runtime.staticCompositionLocalOf
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.toArgb
import org.json.JSONObject

/** Target (non-animated) app palette, provided by MarkVaultTheme for WebView/theme bridges. */
val LocalMarkVaultTargetColorScheme = staticCompositionLocalOf<ColorScheme?> { null }

/**
 * Single bridge between MarkVault's Compose palette and article/WebView colors.
 * This keeps app chrome and rendered notes on the same theme vocabulary.
 */
fun articleThemeVariables(scheme: ColorScheme, customJson: String? = null): LinkedHashMap<String, String> {
    fun hex(c: Color): String = String.format("#%06X", 0xFFFFFF and c.toArgb())
    val vars = linkedMapOf(
        "--bg" to hex(scheme.background),
        "--fg" to hex(scheme.onBackground),
        "--heading" to hex(scheme.primary),
        "--fg-muted" to hex(scheme.onSurfaceVariant),
        "--accent" to hex(scheme.primary),
        "--rule" to hex(scheme.outlineVariant),
        "--surface" to hex(scheme.surface),
        "--surface-variant" to hex(scheme.surfaceVariant),
        "--code-bg" to hex(scheme.surfaceVariant),
        "--code-fg" to hex(scheme.onSurface),
        "--code-inline-bg" to hex(scheme.surfaceVariant),
        "--code-inline-fg" to hex(scheme.tertiary),
        "--table-head" to hex(scheme.surfaceVariant),
        "--table-border" to hex(scheme.outline),
        "--quote-bar" to hex(scheme.secondary),
        "--mark-bg" to hex(scheme.primaryContainer),
        "--mark-fg" to hex(scheme.onPrimaryContainer)
    )
    if (!customJson.isNullOrBlank()) {
        runCatching {
            val obj = JSONObject(customJson)
            obj.keys().forEach { key ->
                if (key.startsWith("--")) {
                    val value = obj.optString(key)
                    if (value.startsWith("#") && value.length in 4..9) vars[key] = value
                }
            }
        }
    }
    return vars
}

fun articleThemeJson(scheme: ColorScheme, customJson: String? = null): String =
    JSONObject(articleThemeVariables(scheme, customJson) as Map<*, *>).toString()

fun articleThemeHtmlCss(scheme: ColorScheme, customJson: String? = null, themeName: String? = null): String {
    val v = articleThemeVariables(scheme, customJson)
    fun x(name: String) = v[name] ?: "#000000"
    val glass3d = themeName == "glass_obsidian" || themeName == "glass_crystal"
    val material4d = themeName?.startsWith("material_") == true
    val materialCss = if (material4d) """
        html,body{background-image:linear-gradient(180deg,rgba(255,255,255,.20),rgba(0,0,0,.025)),repeating-linear-gradient(0deg,transparent 0,transparent 3px,rgba(80,55,25,.018) 4px)!important;background-color:${x("--bg")}!important;background-attachment:fixed!important;}
        body{letter-spacing:.006em!important;text-rendering:optimizeLegibility!important;}
        h1{color:${x("--heading")}!important;text-shadow:0 1px 0 rgba(255,255,255,.55)!important;}
        h2{color:${x("--quote-bar")}!important;} h3,h5{color:${x("--accent")}!important;} h4,h6{color:${x("--code-inline-fg")}!important;}
        a,a:visited{font-weight:600!important;text-decoration-color:${x("--quote-bar")}!important;text-decoration-thickness:1.5px!important;}
        blockquote{border-left:5px solid ${x("--quote-bar")}!important;border-radius:5px 13px 13px 5px!important;background:linear-gradient(135deg,${x("--surface")} 0%,${x("--surface-variant")} 100%)!important;box-shadow:0 7px 18px rgba(45,35,20,.12),inset 0 1px 0 rgba(255,255,255,.72)!important;}
        pre,details,table{border:1px solid ${x("--rule")}!important;border-radius:10px!important;box-shadow:0 8px 18px rgba(45,35,20,.10),inset 0 1px 0 rgba(255,255,255,.65)!important;}
        pre,details{background:linear-gradient(145deg,${x("--surface")} 0%,${x("--surface-variant")} 145%)!important;}
        th{background:linear-gradient(180deg,${x("--table-head")},${x("--surface-variant")})!important;}
        mark{border-radius:3px!important;padding:0 .12em!important;box-shadow:inset 0 -1px 0 rgba(0,0,0,.10)!important;}
        img{border-radius:8px!important;border:1px solid ${x("--rule")}!important;box-shadow:0 10px 24px rgba(45,35,20,.16)!important;}
        hr{height:1px!important;border:0!important;background:linear-gradient(90deg,transparent,${x("--rule")},transparent)!important;}
        li::marker{color:${x("--quote-bar")}!important;}
    """.trimIndent() else ""
    val glassCss = if (glass3d) """
        html,body{background-image:linear-gradient(145deg,${x("--bg")} 0%,${x("--surface-variant")} 52%,${x("--bg")} 100%)!important;background-attachment:fixed!important;}
        blockquote,pre,details,table{border-radius:14px!important;border:1px solid ${x("--rule")}!important;box-shadow:0 12px 28px rgba(0,0,0,.16)!important;}
        blockquote,details{background:${x("--surface")}!important;}
        img{border-radius:14px!important;box-shadow:0 12px 30px rgba(0,0,0,.16)!important;}
    """.trimIndent() else ""
    return """
        <style id="mv-global-theme">
        :root{${v.entries.joinToString("") { "${it.key}:${it.value};" }}}
        html,body{background:${x("--bg")}!important;color:${x("--fg")}!important;}
        body,p,li,dd,dt,td{color:${x("--fg")}!important;}
        h1,h2,h3,h4,h5,h6,strong{color:${x("--heading")}!important;}
        a,a:visited{color:${x("--accent")}!important;}
        blockquote{color:${x("--fg")}!important;border-color:${x("--quote-bar")}!important;background:${x("--surface")}!important;}
        pre{background:${x("--code-bg")}!important;color:${x("--code-fg")}!important;border-color:${x("--rule")}!important;}
        code{color:${x("--code-inline-fg")}!important;}
        :not(pre)>code{background:${x("--code-inline-bg")}!important;}
        table,th,td{border-color:${x("--table-border")}!important;}
        th{background:${x("--table-head")}!important;color:${x("--heading")}!important;}
        hr{border-color:${x("--rule")}!important;}
        $glassCss
        $materialCss
        </style>
    """.trimIndent()
}

/** Build a Compose scheme from the Theme Creator's persisted CSS palette. */
fun customColorSchemeFromJson(base: ColorScheme, json: String?): ColorScheme {
    if (json.isNullOrBlank()) return base
    val obj = runCatching { JSONObject(json) }.getOrNull() ?: return base
    fun parse(key: String, fallback: Color): Color {
        val raw = obj.optString(key, "")
        if (!raw.startsWith("#")) return fallback
        return runCatching {
            Color(android.graphics.Color.parseColor(raw))
        }.getOrElse { fallback }
    }
    val bg = parse("--bg", base.background)
    val fg = parse("--fg", base.onBackground)
    val heading = parse("--heading", base.primary)
    val muted = parse("--fg-muted", base.onSurfaceVariant)
    val accent = parse("--accent", base.primary)
    val rule = parse("--rule", base.outlineVariant)
    val surface = parse("--surface", parse("--code-bg", base.surface))
    val surfaceVariant = parse("--surface-variant", parse("--code-inline-bg", base.surfaceVariant))
    val tableHead = parse("--table-head", base.primaryContainer)
    val tableBorder = parse("--table-border", base.outline)
    val quote = parse("--quote-bar", base.secondary)
    return base.copy(
        primary = accent,
        onPrimary = bg,
        primaryContainer = tableHead,
        onPrimaryContainer = heading,
        secondary = quote,
        onSecondary = bg,
        tertiary = heading,
        onTertiary = bg,
        background = bg,
        onBackground = fg,
        surface = surface,
        onSurface = fg,
        surfaceVariant = surfaceVariant,
        onSurfaceVariant = muted,
        outline = tableBorder,
        outlineVariant = rule
    )
}
