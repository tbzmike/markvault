package com.tebogo.markvault.ui

import androidx.compose.material3.ColorScheme
import androidx.compose.runtime.staticCompositionLocalOf
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.toArgb
import org.json.JSONObject

/** Target (non-animated) app palette, provided by MarkVaultTheme for WebView/theme bridges. */
val LocalMarkVaultTargetColorScheme = staticCompositionLocalOf<ColorScheme?> { null }

/**
 * Single bridge between MarkVault's Compose palette and article/WebView colors.
 * This keeps app chrome and rendered notes on the same theme vocabulary.
 */
fun articleThemeVariables(scheme: ColorScheme, customJson: String? = null): LinkedHashMap<String, String> {
    fun hex(c: Color): String = String.format("#%06X", 0xFFFFFF and c.toArgb())
    val vars = linkedMapOf(
        "--bg" to hex(scheme.background),
        "--fg" to hex(scheme.onBackground),
        "--heading" to hex(scheme.primary),
        "--fg-muted" to hex(scheme.onSurfaceVariant),
        "--accent" to hex(scheme.primary),
        "--rule" to hex(scheme.outlineVariant),
        "--surface" to hex(scheme.surface),
        "--surface-variant" to hex(scheme.surfaceVariant),
        "--code-bg" to hex(scheme.surfaceVariant),
        "--code-fg" to hex(scheme.onSurface),
        "--code-inline-bg" to hex(scheme.surfaceVariant),
        "--code-inline-fg" to hex(scheme.tertiary),
        "--table-head" to hex(scheme.surfaceVariant),
        "--table-border" to hex(scheme.outline),
        "--quote-bar" to hex(scheme.secondary),
        "--mark-bg" to hex(scheme.primaryContainer),
        "--mark-fg" to hex(scheme.onPrimaryContainer)
    )
    if (!customJson.isNullOrBlank()) {
        runCatching {
            val obj = JSONObject(customJson)
            obj.keys().forEach { key ->
                if (key.startsWith("--")) {
                    val value = obj.optString(key)
                    if (value.startsWith("#") && value.length in 4..9) vars[key] = value
                }
            }
        }
    }
    return vars
}

fun articleThemeJson(scheme: ColorScheme, customJson: String? = null): String =
    JSONObject(articleThemeVariables(scheme, customJson) as Map<*, *>).toString()

fun articleThemeHtmlCss(scheme: ColorScheme, customJson: String? = null): String {
    val v = articleThemeVariables(scheme, customJson)
    fun x(name: String) = v[name] ?: "#000000"
    return """
        <style id="mv-global-theme">
        :root{${v.entries.joinToString("") { "${it.key}:${it.value};" }}}
        html,body{background:${x("--bg")}!important;color:${x("--fg")}!important;}
        body,p,li,dd,dt,td{color:${x("--fg")}!important;}
        h1,h2,h3,h4,h5,h6,strong{color:${x("--heading")}!important;}
        a,a:visited{color:${x("--accent")}!important;}
        blockquote{color:${x("--fg")}!important;border-color:${x("--quote-bar")}!important;background:${x("--surface")}!important;}
        pre{background:${x("--code-bg")}!important;color:${x("--code-fg")}!important;border-color:${x("--rule")}!important;}
        code{color:${x("--code-inline-fg")}!important;}
        :not(pre)>code{background:${x("--code-inline-bg")}!important;}
        table,th,td{border-color:${x("--table-border")}!important;}
        th{background:${x("--table-head")}!important;color:${x("--heading")}!important;}
        hr{border-color:${x("--rule")}!important;}
        </style>
    """.trimIndent()
}

/** Build a Compose scheme from the Theme Creator's persisted CSS palette. */
fun customColorSchemeFromJson(base: ColorScheme, json: String?): ColorScheme {
    if (json.isNullOrBlank()) return base
    val obj = runCatching { JSONObject(json) }.getOrNull() ?: return base
    fun parse(key: String, fallback: Color): Color {
        val raw = obj.optString(key, "")
        if (!raw.startsWith("#")) return fallback
        return runCatching {
            Color(android.graphics.Color.parseColor(raw))
        }.getOrElse { fallback }
    }
    val bg = parse("--bg", base.background)
    val fg = parse("--fg", base.onBackground)
    val heading = parse("--heading", base.primary)
    val muted = parse("--fg-muted", base.onSurfaceVariant)
    val accent = parse("--accent", base.primary)
    val rule = parse("--rule", base.outlineVariant)
    val surface = parse("--surface", parse("--code-bg", base.surface))
    val surfaceVariant = parse("--surface-variant", parse("--code-inline-bg", base.surfaceVariant))
    val tableHead = parse("--table-head", base.primaryContainer)
    val tableBorder = parse("--table-border", base.outline)
    val quote = parse("--quote-bar", base.secondary)
    return base.copy(
        primary = accent,
        onPrimary = bg,
        primaryContainer = tableHead,
        onPrimaryContainer = heading,
        secondary = quote,
        onSecondary = bg,
        tertiary = heading,
        onTertiary = bg,
        background = bg,
        onBackground = fg,
        surface = surface,
        onSurface = fg,
        surfaceVariant = surfaceVariant,
        onSurfaceVariant = muted,
        outline = tableBorder,
        outlineVariant = rule
    )
}
