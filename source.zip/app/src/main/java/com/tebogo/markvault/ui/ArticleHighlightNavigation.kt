package com.tebogo.markvault.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.KeyboardArrowDown
import androidx.compose.material.icons.filled.KeyboardArrowUp
import androidx.compose.material.icons.filled.Close
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.style.TextAlign
import android.webkit.WebView
import kotlinx.coroutines.Job
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

/**
 * 5.5.50: owns an individual article's optional semantic-highlighting job.
 * Cancellation is not simply a visual dismiss: it cancels the coroutine,
 * gates all pending WebView callbacks, and stops deferred JavaScript scrolling.
 * A fresh controller is created for each opened article/tab.
 */
internal class ArticleHighlightLoadController {
    @Volatile var cancelled: Boolean = false
        private set
    private var semanticJob: Job? = null

    fun track(job: Job) {
        if (cancelled) {
            job.cancel()
        } else {
            // A page reload must not leave its previous semantic pass running.
            semanticJob?.cancel()
            semanticJob = job
        }
    }

    fun cancel(view: WebView?) {
        cancelled = true
        semanticJob?.cancel()
        semanticJob = null
        view?.evaluateJavascript(
            "window.__mvHighlightCancelled=true;window.__mvHighlightNavManual=true;",
            null
        )
    }
}

/** Centered, high-contrast, explicitly cancellable loading dialog. */
@Composable
internal fun HighlightLoadingIndicator(
    onCancel: () -> Unit,
    modifier: Modifier = Modifier
) {
    Box(
        modifier = modifier.fillMaxSize().background(Color.Black.copy(alpha = 0.48f)),
        contentAlignment = Alignment.Center
    ) {
        Surface(
            modifier = Modifier.padding(horizontal = 24.dp).widthIn(max = 360.dp),
            shape = RoundedCornerShape(24.dp),
            color = Color(0xFF162D47),
            contentColor = Color.White,
            shadowElevation = 16.dp
        ) {
            Column(
                modifier = Modifier.padding(horizontal = 24.dp, vertical = 16.dp),
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.End
                ) {
                    IconButton(onClick = onCancel, modifier = Modifier.size(42.dp)) {
                        Icon(Icons.Default.Close, contentDescription = "Cancel loading highlights", tint = Color.White)
                    }
                }
                CircularProgressIndicator(
                    modifier = Modifier.size(34.dp),
                    color = Color(0xFF8DDCFF),
                    strokeWidth = 3.dp
                )
                Text(
                    text = "Loading highlights",
                    fontSize = 22.sp,
                    lineHeight = 28.sp,
                    fontWeight = FontWeight.Bold,
                    color = Color.White,
                    textAlign = TextAlign.Center
                )
                Text(
                    text = "Please be patient/wait 🙏",
                    fontSize = 17.sp,
                    lineHeight = 24.sp,
                    fontWeight = FontWeight.Medium,
                    color = Color.White,
                    textAlign = TextAlign.Center
                )
            }
        }
    }
}

/** Previous/next controls for the highlight nodes currently painted in a reader. */
@Composable
internal fun HighlightNavigationControls(
    onPrevious: () -> Unit,
    onNext: () -> Unit,
    modifier: Modifier = Modifier
) {
    Surface(
        modifier = modifier,
        shape = RoundedCornerShape(18.dp),
        color = MaterialTheme.colorScheme.secondaryContainer.copy(alpha = 0.96f),
        contentColor = MaterialTheme.colorScheme.onSecondaryContainer,
        tonalElevation = 3.dp,
        shadowElevation = 6.dp
    ) {
        Row(
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(2.dp)
        ) {
            IconButton(onClick = onPrevious, modifier = Modifier.size(44.dp)) {
                Icon(
                    Icons.Default.KeyboardArrowUp,
                    contentDescription = "Previous highlighted passage"
                )
            }
            IconButton(onClick = onNext, modifier = Modifier.size(44.dp)) {
                Icon(
                    Icons.Default.KeyboardArrowDown,
                    contentDescription = "Next highlighted passage"
                )
            }
        }
    }
}

/**
 * 5.5.51: The navigation stream represents *visible individual highlights*,
 * not ancestor containers around multiple nested hits. An outer semantic block
 * is navigated only when it has no smaller highlighted descendants.
 * A DOM rebuild may replace elements while keeping the same ordered matches:
 * retaining the previous ordinal prevents a delayed count probe from jumping
 * navigation back to the first highlight. No services/polling/timers.
 */
private fun highlightNodesJs(safeSelector: String): String = """
    function visibleHits() {
      var all = Array.prototype.slice.call(document.querySelectorAll($safeSelector));
      return all.filter(function(hit){
        if (!hit || !hit.isConnected || !hit.getClientRects || !hit.getClientRects().length) return false;
        // Navigate the actual marked passages, not a broad parent that
        // contains several separately highlighted passages.
        if (hit.querySelector && hit.querySelector($safeSelector)) return false;
        return true;
      });
    }
    function resolveHighlightIndex(hits) {
      var idx = hits.indexOf(window.__mvHighlightNavTarget);
      if (idx >= 0) return idx;
      var previous = window.__mvHighlightNavIndex;
      if (typeof previous === 'number' && previous >= 0 && isFinite(previous))
        return Math.min(Math.floor(previous), hits.length - 1);
      return -1;
    }
""".trimIndent()

internal fun articleHighlightCountJs(selector: String): String {
    val safeSelector = org.json.JSONObject.quote(selector)
    return """
        (function(){
          try {
            if (window.__mvHighlightCancelled) return 0;
            ${highlightNodesJs(safeSelector)}
            var hits = visibleHits();
            if (!hits.length) {
              window.__mvHighlightNavIndex = -1;
              window.__mvHighlightNavTarget = null;
              return 0;
            }
            var idx = resolveHighlightIndex(hits);
            window.__mvHighlightNavIndex = idx;
            window.__mvHighlightNavTarget = idx < 0 ? null : hits[idx];
            return hits.length;
          } catch(e) { return 0; }
        })()
    """.trimIndent()
}

/** Exactly one DOM match per user arrow press; no deferred scroll. */
internal fun articleHighlightNavigateJs(selector: String, direction: Int): String {
    val safeSelector = org.json.JSONObject.quote(selector)
    val step = if (direction < 0) -1 else 1
    return """
        (function(){
          try {
            if (window.__mvHighlightCancelled) return 0;
            ${highlightNodesJs(safeSelector)}
            var hits = visibleHits();
            if (!hits.length) {
              window.__mvHighlightNavIndex = -1;
              window.__mvHighlightNavTarget = null;
              return 0;
            }
            window.__mvHighlightNavManual = true;
            var previous = resolveHighlightIndex(hits);
            var idx = previous < 0 ? ($step > 0 ? 0 : hits.length - 1) :
                      (previous + ($step) + hits.length) % hits.length;
            var target = hits[idx];
            var old = window.__mvHighlightNavDecoratedTarget;
            if (old && old !== target && old.style) {
              old.style.outline = window.__mvHighlightNavOldOutline || '';
              old.style.outlineOffset = window.__mvHighlightNavOldOffset || '';
            }
            window.__mvHighlightNavIndex = idx;
            window.__mvHighlightNavTarget = target;
            if (target) {
              // Make adjacent highlights in the same viewport visibly distinct.
              if (old !== target) {
                window.__mvHighlightNavOldOutline = target.style.outline;
                window.__mvHighlightNavOldOffset = target.style.outlineOffset;
              }
              window.__mvHighlightNavDecoratedTarget = target;
              target.style.outline = '3px solid #FFB300';
              target.style.outlineOffset = '3px';
              var rect = target.getBoundingClientRect();
              var y = (window.pageYOffset || document.documentElement.scrollTop || 0) +
                rect.top + rect.height / 2 - window.innerHeight / 2;
              // Two-argument scrollTo avoids CSS 'smooth' behavior and the
              // overlapping animation that looked like a multi-hit jump.
              window.scrollTo(0, Math.max(0, Math.round(y)));
            }
            return hits.length;
          } catch(e) { return 0; }
        })()
    """.trimIndent()
}
