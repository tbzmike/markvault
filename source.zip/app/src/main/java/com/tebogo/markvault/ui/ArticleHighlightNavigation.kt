package com.tebogo.markvault.ui

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.KeyboardArrowDown
import androidx.compose.material.icons.filled.KeyboardArrowUp
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

/**
 * v5.5.19 — Shared article-highlight status/navigation UI used by both the
 * Markdown reader and the offline-HTML reader.
 *
 * Keeping this in one place prevents the two WebView readers from drifting:
 * both readers show the same temporary loading state and only expose the
 * previous/next controls after their live DOM confirms that highlight nodes
 * actually exist.
 */
@Composable
internal fun HighlightLoadingIndicator(
    modifier: Modifier = Modifier
) {
    Surface(
        modifier = modifier,
        shape = RoundedCornerShape(18.dp),
        color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.96f),
        contentColor = MaterialTheme.colorScheme.onSurfaceVariant,
        tonalElevation = 4.dp,
        shadowElevation = 5.dp
    ) {
        Row(
            modifier = Modifier.padding(horizontal = 12.dp, vertical = 8.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            CircularProgressIndicator(
                modifier = Modifier.size(16.dp),
                strokeWidth = 2.dp
            )
            Text(
                text = "Loading highlights…",
                fontSize = 12.sp,
                fontWeight = FontWeight.SemiBold
            )
        }
    }
}

/** Previous/next controls for the highlight nodes currently painted in a reader. */
@Composable
internal fun HighlightNavigationControls(
    onPrevious: () -> Unit,
    onNext: () -> Unit,
    modifier: Modifier = Modifier
) {
    Surface(
        modifier = modifier,
        shape = RoundedCornerShape(18.dp),
        color = MaterialTheme.colorScheme.secondaryContainer.copy(alpha = 0.96f),
        contentColor = MaterialTheme.colorScheme.onSecondaryContainer,
        tonalElevation = 3.dp,
        shadowElevation = 6.dp
    ) {
        Row(
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(2.dp)
        ) {
            IconButton(onClick = onPrevious, modifier = Modifier.size(44.dp)) {
                Icon(
                    Icons.Default.KeyboardArrowUp,
                    contentDescription = "Previous highlighted passage"
                )
            }
            IconButton(onClick = onNext, modifier = Modifier.size(44.dp)) {
                Icon(
                    Icons.Default.KeyboardArrowDown,
                    contentDescription = "Next highlighted passage"
                )
            }
        }
    }
}

/**
 * Probe only the primary article highlights. LLM trace overlays are excluded:
 * the arrows are intended to navigate the result passage itself, not every
 * auxiliary paraphrase tint.
 */
internal fun articleHighlightCountJs(selector: String): String {
    val safeSelector = org.json.JSONObject.quote(selector)
    return """
        (function(){
          try {
            var hits = document.querySelectorAll($safeSelector);
            var count = hits ? hits.length : 0;
            window.__mvHighlightNavIndex = count > 0 ? 0 : -1;
            return count;
          } catch(e) {
            window.__mvHighlightNavIndex = -1;
            return 0;
          }
        })()
    """.trimIndent()
}

/**
 * Scroll to the previous/next *highlight*, not by an arbitrary page amount.
 * The index lives in the WebView document so both buttons remain coherent even
 * across Compose recompositions. Navigation wraps at the first/last highlight.
 */
internal fun articleHighlightNavigateJs(selector: String, direction: Int): String {
    val safeSelector = org.json.JSONObject.quote(selector)
    val step = if (direction < 0) -1 else 1
    return """
        (function(){
          try {
            var hits = Array.prototype.slice.call(document.querySelectorAll($safeSelector));
            if (!hits.length) { window.__mvHighlightNavIndex = -1; return 0; }
            var idx = Number(window.__mvHighlightNavIndex);
            if (!isFinite(idx) || idx < 0 || idx >= hits.length) idx = 0;
            idx = (idx + ($step) + hits.length) % hits.length;
            window.__mvHighlightNavIndex = idx;
            var target = hits[idx];
            if (!target) return hits.length;
            try { target.scrollIntoView({behavior:'smooth', block:'center'}); }
            catch(e) { try { target.scrollIntoView(); } catch(_){} }
            try {
              target.classList.add('flash');
              target.classList.add('mv-semantic-flash');
              setTimeout(function(){
                try {
                  target.classList.remove('flash');
                  target.classList.remove('mv-semantic-flash');
                } catch(_){}
              }, 1200);
            } catch(_){}
            return hits.length;
          } catch(e) { return 0; }
        })()
    """.trimIndent()
}
