package com.tebogo.markvault.ai

/** Releases T5 runtime resources after use. */
object T5MemoryCleanup {
    private var loaded = false

    fun markLoaded() { loaded = true }

    fun cleanup() {
        loaded = false
        System.gc()
    }

    fun isLoaded(): Boolean = loaded
}
