package com.tebogo.markvault.ui

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.RadioButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateMapOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.tebogo.markvault.AppViewModel

/**
 * App-wide theme picker dialog. Triggered from the overflow menu so themes are
 * reachable from any screen, not just the article reader.
 *
 * Picking a theme drives BOTH:
 *   • Article viewer (WebView CSS `theme-*` body class)
 *   • Compose app chrome (top bars, surfaces — via MarkVaultTheme in MainActivity)
 */
@Composable
fun ThemePickerDialog(vm: AppViewModel, onDismiss: () -> Unit) {
    val current by vm.theme.collectAsStateWithLifecycle()
    val customJson by vm.customThemeJson.collectAsStateWithLifecycle()
    var creatorOpen by remember { mutableStateOf(false) }
    if (creatorOpen) {
        GlobalThemeCreatorDialog(
            vm = vm,
            onDismiss = { creatorOpen = false },
            onApplied = { creatorOpen = false; onDismiss() }
        )
        return
    }
    val options = listOf(
        ThemeOption("dark",              "\uD83C\uDF11 Dark (grey)",        Color(0xFF1C2026)),
        ThemeOption("black",             "\u26AB AMOLED black",             Color(0xFF000000)),
        ThemeOption("hicontrast-dark",   "\u26A1 High-contrast dark",       Color(0xFF000000)),
        ThemeOption("ocean",             "\uD83C\uDF0A Ocean",              Color(0xFF0D2030)),
        ThemeOption("forest",            "\uD83C\uDF32 Forest",             Color(0xFF142219)),
        ThemeOption("obsidian",          "\uD83E\uDEA8 Obsidian",           Color(0xFF1E1E1E)),
        ThemeOption("sepia",             "\uD83D\uDCDC Sepia",              Color(0xFFF4ECD8)),
        ThemeOption("dark_sepia",        "\uD83D\uDCDC Dark sepia",         Color(0xFF3A3028)),
        ThemeOption("cream",             "\uD83E\uDD5B Cream",              Color(0xFFFDF6E3)),
        // v4.16.0 — Light grey theme: a softer alternative to "Light"
        // (pure white) for users who find white too glaring but still
        // want a light background. Dark text on light grey, AAA contrast.
        ThemeOption("light_grey",        "\uD83E\uDEA8 Light grey",         Color(0xFFDDE1E5)),
        ThemeOption("grey",              "\u2B1C Grey",                      Color(0xFF606468)),
        ThemeOption("sky_blue",          "\uD83C\uDF24 Sky blue",           Color(0xFFD6EAFF)),
        ThemeOption("light",             "\u2600\uFE0F Light",              Color(0xFFFFFFFF)),
        ThemeOption("hicontrast-light",  "\u26A1 High-contrast light",      Color(0xFFFFFFFF)),
        // v5.4.114cc — Expressive theme pack.
        ThemeOption("expr_indigo",       "\uD83D\uDD8B\uFE0F Expressive indigo", Color(0xFF15151A)),
        ThemeOption("expr_violet",       "\uD83D\uDD2E Expressive violet",  Color(0xFFFDF7FF)),
        ThemeOption("expr_ember",        "\uD83D\uDD25 Expressive ember",   Color(0xFF1A140F)),
        ThemeOption("expr_rose",         "\uD83C\uDF39 Expressive rose",    Color(0xFFFFF8F7)),
        ThemeOption("custom",            "\uD83C\uDFA8 Custom theme",       customThemeSwatch(customJson))
    )
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("\uD83C\uDFA8 Theme") },
        text = {
            Column(
                Modifier.heightIn(max = 480.dp)
                    .verticalScroll(rememberScrollState())
            ) {
                options.forEach { opt ->
                    Row(
                        Modifier.fillMaxWidth()
                            .clickable {
                                vm.setTheme(opt.id)
                                onDismiss()
                            }
                            .padding(vertical = 8.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        RadioButton(
                            selected = current == opt.id,
                            onClick = {
                                vm.setTheme(opt.id)
                                onDismiss()
                            }
                        )
                        Surface(
                            color = opt.swatch,
                            shape = CircleShape,
                            modifier = Modifier.width(28.dp).height(28.dp)
                        ) {}
                        Spacer(Modifier.width(12.dp))
                        Text(opt.label, fontSize = 15.sp,
                            fontWeight = if (current == opt.id) FontWeight.SemiBold else FontWeight.Normal)
                    }
                }
            }
        },
        confirmButton = {
            Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                TextButton(onClick = { creatorOpen = true }) { Text("Create / edit custom") }
                TextButton(onClick = onDismiss) { Text("Done") }
            }
        }
    )
}

private data class ThemeOption(val id: String, val label: String, val swatch: Color)

private fun customThemeSwatch(json: String): Color {
    return runCatching {
        val bg = org.json.JSONObject(json).optString("--bg", "#1E1E1E")
        Color(android.graphics.Color.parseColor(bg))
    }.getOrElse { Color(0xFF1E1E1E) }
}

/** App-wide Theme Creator. Values are persisted and feed both MaterialTheme and article CSS. */
@Composable
private fun GlobalThemeCreatorDialog(
    vm: AppViewModel,
    onDismiss: () -> Unit,
    onApplied: () -> Unit
) {
    val saved by vm.customThemeJson.collectAsStateWithLifecycle()
    val base = LocalMarkVaultTargetColorScheme.current ?: MaterialTheme.colorScheme
    val initial = remember(saved, base) {
        articleThemeVariables(base, saved.takeIf { it.isNotBlank() })
    }
    val draft = remember(saved) {
        mutableStateMapOf<String, String>().apply { putAll(initial) }
    }
    val labels = listOf(
        "--bg" to "App / article background",
        "--fg" to "Main text",
        "--heading" to "Headings",
        "--fg-muted" to "Muted text",
        "--accent" to "Accent / links",
        "--rule" to "Dividers",
        "--surface" to "Cards / surfaces",
        "--surface-variant" to "Secondary surfaces",
        "--code-bg" to "Code block background",
        "--code-fg" to "Code block text",
        "--code-inline-bg" to "Inline code background",
        "--code-inline-fg" to "Inline code text",
        "--table-head" to "Table header",
        "--table-border" to "Table border",
        "--quote-bar" to "Quote / secondary accent",
        "--mark-bg" to "Highlight background",
        "--mark-fg" to "Highlight text"
    )
    var error by remember { mutableStateOf<String?>(null) }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("🎨 Global Theme Creator") },
        text = {
            Column(
                Modifier.heightIn(max = 560.dp).verticalScroll(rememberScrollState()),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Text(
                    "One palette drives MarkVault UI, Markdown, HTML articles, tables, code and text colors.",
                    fontSize = 12.sp,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
                labels.forEach { (key, label) ->
                    val value = draft[key] ?: "#000000"
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Box(
                            Modifier.size(30.dp)
                                .background(parseThemeColor(value), RoundedCornerShape(6.dp))
                                .border(1.dp, MaterialTheme.colorScheme.outline, RoundedCornerShape(6.dp))
                        )
                        Spacer(Modifier.width(8.dp))
                        OutlinedTextField(
                            value = value,
                            onValueChange = { next ->
                                if (next.length <= 9) draft[key] = next
                            },
                            label = { Text(label) },
                            singleLine = true,
                            modifier = Modifier.weight(1f)
                        )
                    }
                }
                if (error != null) Text(error!!, color = MaterialTheme.colorScheme.error, fontSize = 12.sp)
            }
        },
        confirmButton = {
            TextButton(onClick = {
                val invalid = labels.firstOrNull { (key, _) -> !isValidThemeHex(draft[key].orEmpty()) }
                if (invalid != null) {
                    error = "Invalid color for ${invalid.second}. Use #RRGGBB or #AARRGGBB."
                } else {
                    val json = org.json.JSONObject(draft as Map<*, *>).toString()
                    vm.setCustomThemeJson(json)
                    vm.setTheme("custom")
                    onApplied()
                }
            }) { Text("Apply globally") }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Cancel") } }
    )
}

private fun parseThemeColor(value: String): Color =
    runCatching { Color(android.graphics.Color.parseColor(value)) }.getOrElse { Color.Transparent }

private fun isValidThemeHex(value: String): Boolean =
    runCatching {
        android.graphics.Color.parseColor(value)
        value.matches(Regex("^#[0-9A-Fa-f]{6}([0-9A-Fa-f]{2})?$"))
    }.getOrDefault(false)

