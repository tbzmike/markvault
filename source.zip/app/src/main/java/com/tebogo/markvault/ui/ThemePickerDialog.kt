package com.tebogo.markvault.ui

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.RadioButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.tebogo.markvault.AppViewModel

/**
 * App-wide theme picker dialog. Triggered from the overflow menu so themes are
 * reachable from any screen, not just the article reader.
 *
 * Picking a theme drives BOTH:
 *   • Article viewer (WebView CSS `theme-*` body class)
 *   • Compose app chrome (top bars, surfaces — via MarkVaultTheme in MainActivity)
 */
@Composable
fun ThemePickerDialog(vm: AppViewModel, onDismiss: () -> Unit) {
    val current by vm.theme.collectAsStateWithLifecycle()
    val options = listOf(
        ThemeOption("dark",   "\uD83C\uDF11 Dark (grey)",   Color(0xFF1C2026)),
        ThemeOption("black",  "\u26AB AMOLED black",        Color(0xFF000000)),
        ThemeOption("sepia",  "\uD83D\uDCDC Sepia",         Color(0xFFF4ECD8)),
        ThemeOption("light",  "\u2600\uFE0F Light",         Color(0xFFFFFFFF))
    )
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("\uD83C\uDFA8 Theme") },
        text = {
            Column {
                options.forEach { opt ->
                    Row(
                        Modifier.fillMaxWidth()
                            .clickable {
                                vm.setTheme(opt.id)
                                onDismiss()
                            }
                            .padding(vertical = 8.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        RadioButton(
                            selected = current == opt.id,
                            onClick = {
                                vm.setTheme(opt.id)
                                onDismiss()
                            }
                        )
                        Surface(
                            color = opt.swatch,
                            shape = CircleShape,
                            modifier = Modifier.width(28.dp).height(28.dp)
                        ) {}
                        Spacer(Modifier.width(12.dp))
                        Text(opt.label, fontSize = 15.sp,
                            fontWeight = if (current == opt.id) FontWeight.SemiBold else FontWeight.Normal)
                    }
                }
            }
        },
        confirmButton = {
            TextButton(onClick = onDismiss) { Text("Done") }
        }
    )
}

private data class ThemeOption(val id: String, val label: String, val swatch: Color)
