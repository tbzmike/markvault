package com.tebogo.markvault.ui

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.RadioButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.tebogo.markvault.AppViewModel

/**
 * App-wide theme picker dialog. Triggered from the overflow menu so themes are
 * reachable from any screen, not just the article reader.
 *
 * Picking a theme drives BOTH:
 *   • Article viewer (WebView CSS `theme-*` body class)
 *   • Compose app chrome (top bars, surfaces — via MarkVaultTheme in MainActivity)
 */
@Composable
fun ThemePickerDialog(vm: AppViewModel, onDismiss: () -> Unit) {
    val current by vm.theme.collectAsStateWithLifecycle()
    val options = listOf(
        ThemeOption("dark",              "\uD83C\uDF11 Dark (grey)",        Color(0xFF1C2026)),
        ThemeOption("black",             "\u26AB AMOLED black",             Color(0xFF000000)),
        ThemeOption("hicontrast-dark",   "\u26A1 High-contrast dark",       Color(0xFF000000)),
        ThemeOption("ocean",             "\uD83C\uDF0A Ocean",              Color(0xFF0D2030)),
        ThemeOption("forest",            "\uD83C\uDF32 Forest",             Color(0xFF142219)),
        ThemeOption("sepia",             "\uD83D\uDCDC Sepia",              Color(0xFFF4ECD8)),
        ThemeOption("dark_sepia",        "\uD83D\uDCDC Dark sepia",         Color(0xFF3A3028)),
        ThemeOption("cream",             "\uD83E\uDD5B Cream",              Color(0xFFFDF6E3)),
        // v4.16.0 — Light grey theme: a softer alternative to "Light"
        // (pure white) for users who find white too glaring but still
        // want a light background. Dark text on light grey, AAA contrast.
        ThemeOption("light_grey",        "\uD83E\uDEA8 Light grey",         Color(0xFFDDE1E5)),
        ThemeOption("grey",              "\u2B1C Grey",                      Color(0xFF606468)),
        ThemeOption("sky_blue",          "\uD83C\uDF24 Sky blue",           Color(0xFFD6EAFF)),
        ThemeOption("light",             "\u2600\uFE0F Light",              Color(0xFFFFFFFF)),
        ThemeOption("hicontrast-light",  "\u26A1 High-contrast light",      Color(0xFFFFFFFF))
    )
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("\uD83C\uDFA8 Theme") },
        text = {
            Column(
                Modifier.heightIn(max = 480.dp)
                    .verticalScroll(rememberScrollState())
            ) {
                options.forEach { opt ->
                    Row(
                        Modifier.fillMaxWidth()
                            .clickable {
                                vm.setTheme(opt.id)
                                onDismiss()
                            }
                            .padding(vertical = 8.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        RadioButton(
                            selected = current == opt.id,
                            onClick = {
                                vm.setTheme(opt.id)
                                onDismiss()
                            }
                        )
                        Surface(
                            color = opt.swatch,
                            shape = CircleShape,
                            modifier = Modifier.width(28.dp).height(28.dp)
                        ) {}
                        Spacer(Modifier.width(12.dp))
                        Text(opt.label, fontSize = 15.sp,
                            fontWeight = if (current == opt.id) FontWeight.SemiBold else FontWeight.Normal)
                    }
                }
            }
        },
        confirmButton = {
            TextButton(onClick = onDismiss) { Text("Done") }
        }
    )
}

private data class ThemeOption(val id: String, val label: String, val swatch: Color)
