package com.tebogo.markvault.data

import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

/**
 * Process-local projection state shared by PlaybackService and the phone UI.
 *
 * Android Auto controls the same MediaLibrarySession/ExoPlayer as MarkVault's
 * phone UI.  The service owns controller connections, so it is the only place
 * that can reliably say whether a car media browser is currently attached.
 */
object PlaybackRouteState {
    private val _androidAutoConnected = MutableStateFlow(false)
    val androidAutoConnected: StateFlow<Boolean> = _androidAutoConnected.asStateFlow()

    internal fun setAndroidAutoConnected(connected: Boolean) {
        _androidAutoConnected.value = connected
    }
}
