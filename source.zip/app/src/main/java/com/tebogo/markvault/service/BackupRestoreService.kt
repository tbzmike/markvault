package com.tebogo.markvault.service

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.IBinder
import android.os.PowerManager
import androidx.core.app.NotificationCompat
import androidx.core.content.ContextCompat
import com.tebogo.markvault.BuildConfig
import com.tebogo.markvault.MainActivity
import com.tebogo.markvault.R
import com.tebogo.markvault.data.BackupManager
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch

data class BackupRestoreStatus(
    val running: Boolean = false,
    val isRestore: Boolean = false,
    val message: String? = null,
    val percent: Int? = null,
    val succeeded: Boolean? = null
)

/** Process-local status shared by the foreground service and Settings UI. */
object BackupRestoreOperation {
    private val mutableStatus = MutableStateFlow(BackupRestoreStatus())
    val status: StateFlow<BackupRestoreStatus> = mutableStatus.asStateFlow()

    internal fun started(isRestore: Boolean) {
        mutableStatus.value = BackupRestoreStatus(
            running = true,
            isRestore = isRestore,
            message = if (isRestore) "Starting restore…" else "Starting backup…",
            percent = 0
        )
    }

    internal fun progressed(isRestore: Boolean, progress: BackupManager.Progress) {
        mutableStatus.value = BackupRestoreStatus(
            running = true,
            isRestore = isRestore,
            message = progress.detail.ifBlank { progress.phase },
            percent = progress.percent
        )
    }

    internal fun stopping(isRestore: Boolean) {
        mutableStatus.value = BackupRestoreStatus(
            running = true,
            isRestore = isRestore,
            message = "Stopping safely…"
        )
    }

    internal fun finished(isRestore: Boolean, succeeded: Boolean, message: String) {
        mutableStatus.value = BackupRestoreStatus(
            running = false,
            isRestore = isRestore,
            message = message,
            percent = if (succeeded) 100 else null,
            succeeded = succeeded
        )
    }
}

/**
 * Foreground owner for explicit Backup / Restore operations.
 *
 * The operation survives normal activity/background/screen-off transitions and
 * holds a partial wake lock while work is active. The notification exposes an
 * explicit Stop action; no Activity/Compose coroutine owns the operation.
 */
class BackupRestoreService : Service() {
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
    private var operationJob: Job? = null
    private var wakeLock: PowerManager.WakeLock? = null
    @Volatile private var stopRequested = false
    @Volatile private var currentOperationIsRestore = false

    override fun onCreate() {
        super.onCreate()
        createChannel()
        val pm = getSystemService(Context.POWER_SERVICE) as PowerManager
        wakeLock = pm.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "MarkVault:BackupRestore")
            .apply { setReferenceCounted(false) }
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_STOP -> requestStop()
            ACTION_BACKUP -> startOperation(isRestore = false, uri = intent.data)
            ACTION_RESTORE -> startOperation(isRestore = true, uri = intent.data)
        }
        return START_NOT_STICKY
    }

    private fun startOperation(isRestore: Boolean, uri: Uri?) {
        if (uri == null || operationJob?.isActive == true) return
        stopRequested = false
        currentOperationIsRestore = isRestore
        BackupRestoreOperation.started(isRestore)
        ensureWakeLock()
        startForeground(
            NOTIFICATION_ID,
            buildNotification(
                title = if (isRestore) "Restoring MarkVault" else "Backing up MarkVault",
                text = "Starting…",
                percent = 0,
                indeterminate = true
            )
        )

        operationJob = scope.launch {
            val result = try {
                if (isRestore) {
                    BackupManager.applyBackup(
                        this@BackupRestoreService,
                        uri,
                        onProgress = { progress -> updateProgress(true, progress) },
                        shouldStop = { stopRequested }
                    )
                } else {
                    BackupManager.createBackup(
                        this@BackupRestoreService,
                        uri,
                        BuildConfig.VERSION_NAME,
                        onProgress = { progress -> updateProgress(false, progress) },
                        shouldStop = { stopRequested }
                    )
                }
            } catch (_: CancellationException) {
                false
            } catch (_: BackupManager.BackupStoppedException) {
                false
            } catch (t: Throwable) {
                android.util.Log.e(TAG, "Backup/restore foreground operation failed", t)
                false
            }

            val failureReason = BackupManager.lastFailureReason
            val stopped = !result && (
                failureReason == "Backup stopped by user." ||
                    failureReason == "Restore stopped by user." ||
                    (stopRequested && failureReason == null)
            )
            val title = when {
                stopped -> "Operation stopped"
                result && isRestore -> "Restore complete"
                result -> "Backup complete"
                isRestore -> "Restore failed"
                else -> "Backup failed"
            }
            val detail = when {
                stopped -> "Stopped by you. Existing MarkVault data was kept safe."
                result && isRestore -> "MarkVault data restored. Reopen the app."
                result -> "Backup saved and verified."
                isRestore -> failureReason
                    ?: "Restore was not completed. Existing data was kept or rolled back."
                else -> failureReason ?: "Backup could not be completed."
            }
            BackupRestoreOperation.finished(isRestore, result, detail)
            postFinal(title, detail)
            releaseWakeLock()
            stopForeground(STOP_FOREGROUND_REMOVE)
            stopSelf()

            // A successful restore stages DataStore for a cold start. A failed
            // attempt that closed Room also needs a cold restart because the
            // existing ViewModel holds DAOs from the closed database instance.
            if (isRestore && (result || BackupManager.restartRequiredAfterRestoreAttempt)) {
                android.os.Process.killProcess(android.os.Process.myPid())
            }
        }
    }

    private fun updateProgress(isRestore: Boolean, progress: BackupManager.Progress) {
        BackupRestoreOperation.progressed(isRestore, progress)
        val nm = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        nm.notify(
            NOTIFICATION_ID,
            buildNotification(
                title = if (isRestore) "Restoring MarkVault" else "Backing up MarkVault",
                text = progress.detail.ifBlank { progress.phase },
                percent = progress.percent,
                indeterminate = progress.percent == null
            )
        )
    }

    private fun requestStop() {
        stopRequested = true
        BackupRestoreOperation.stopping(currentOperationIsRestore)
        val nm = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        nm.notify(
            NOTIFICATION_ID,
            buildNotification("Stopping safely…", "Finishing the current safe point…", null, true, allowStop = false)
        )
    }

    private fun buildNotification(
        title: String,
        text: String,
        percent: Int?,
        indeterminate: Boolean,
        allowStop: Boolean = true
    ): Notification {
        val openPi = PendingIntent.getActivity(
            this,
            0,
            Intent(this, MainActivity::class.java).apply {
                flags = Intent.FLAG_ACTIVITY_SINGLE_TOP or Intent.FLAG_ACTIVITY_CLEAR_TOP
            },
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        val builder = NotificationCompat.Builder(this, CHANNEL_ID)
            .setSmallIcon(R.mipmap.ic_launcher)
            .setContentTitle(title)
            .setContentText(text)
            .setContentIntent(openPi)
            .setOngoing(allowStop)
            .setOnlyAlertOnce(true)
            .setCategory(NotificationCompat.CATEGORY_PROGRESS)
            .setPriority(NotificationCompat.PRIORITY_LOW)

        if (indeterminate || percent == null) builder.setProgress(0, 0, true)
        else builder.setProgress(100, percent.coerceIn(0, 100), false)

        if (allowStop) {
            val stopPi = PendingIntent.getService(
                this,
                1,
                Intent(this, BackupRestoreService::class.java).setAction(ACTION_STOP),
                PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
            )
            builder.addAction(android.R.drawable.ic_menu_close_clear_cancel, "Stop", stopPi)
        }
        return builder.build()
    }

    private fun postFinal(title: String, text: String) {
        val nm = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        nm.notify(
            NOTIFICATION_ID_RESULT,
            NotificationCompat.Builder(this, CHANNEL_ID)
                .setSmallIcon(R.mipmap.ic_launcher)
                .setContentTitle(title)
                .setContentText(text)
                .setStyle(NotificationCompat.BigTextStyle().bigText(text))
                .setAutoCancel(true)
                .setPriority(NotificationCompat.PRIORITY_DEFAULT)
                .build()
        )
    }

    private fun ensureWakeLock() {
        val lock = wakeLock ?: return
        if (!lock.isHeld) lock.acquire(12L * 60L * 60L * 1000L)
    }

    private fun releaseWakeLock() {
        if (wakeLock?.isHeld == true) runCatching { wakeLock?.release() }
    }

    private fun createChannel() {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.O) return
        val nm = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        nm.createNotificationChannel(
            NotificationChannel(CHANNEL_ID, "Backup and restore", NotificationManager.IMPORTANCE_LOW).apply {
                description = "Backup and restore progress"
            }
        )
    }

    override fun onDestroy() {
        if (operationJob?.isActive == true) stopRequested = true
        releaseWakeLock()
        scope.cancel()
        super.onDestroy()
    }

    override fun onBind(intent: Intent?): IBinder? = null

    companion object {
        private const val TAG = "MV-BackupRestoreSvc"
        private const val CHANNEL_ID = "markvault_backup_restore"
        private const val NOTIFICATION_ID = 4830
        private const val NOTIFICATION_ID_RESULT = 4831
        const val ACTION_BACKUP = "com.tebogo.markvault.action.BACKUP"
        const val ACTION_RESTORE = "com.tebogo.markvault.action.RESTORE"
        const val ACTION_STOP = "com.tebogo.markvault.action.STOP_BACKUP_RESTORE"

        fun startBackup(context: Context, uri: Uri) {
            val intent = Intent(context, BackupRestoreService::class.java)
                .setAction(ACTION_BACKUP)
                .setData(uri)
                .addFlags(Intent.FLAG_GRANT_WRITE_URI_PERMISSION or Intent.FLAG_GRANT_READ_URI_PERMISSION)
            ContextCompat.startForegroundService(context, intent)
        }

        fun startRestore(context: Context, uri: Uri) {
            val intent = Intent(context, BackupRestoreService::class.java)
                .setAction(ACTION_RESTORE)
                .setData(uri)
                .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
            ContextCompat.startForegroundService(context, intent)
        }
    }
}
