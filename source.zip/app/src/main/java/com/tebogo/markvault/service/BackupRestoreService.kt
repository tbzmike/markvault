package com.tebogo.markvault.service

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.IBinder
import android.os.PowerManager
import androidx.core.app.NotificationCompat
import androidx.core.content.ContextCompat
import com.tebogo.markvault.BuildConfig
import com.tebogo.markvault.MainActivity
import com.tebogo.markvault.R
import com.tebogo.markvault.data.BackupManager
import com.tebogo.markvault.data.BackupSelection
import com.tebogo.markvault.data.BackupModelSelection
import java.io.File
import java.util.UUID
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.launch

/**
 * Owns backup/restore independently of Compose so an explicit user operation
 * continues when Settings leaves composition, the app is backgrounded, or the
 * screen turns off. A foreground data-sync notification and partial wake lock
 * remain active only for the lifetime of the operation.
 */
class BackupRestoreService : Service() {
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
    private var operationJob: Job? = null
    private var wakeLock: PowerManager.WakeLock? = null
    private var pauseGate = RestorePauseGate()
    @Volatile private var stopRequested = false
    private var requestId = ""
    private fun journal() = jobJournal(this)
    private var lastNotificationPercent = -1
    private var lastNotificationStage = ""

    override fun onCreate() {
        super.onCreate()
        createChannel()
        val pm = getSystemService(Context.POWER_SERVICE) as PowerManager
        wakeLock = pm.newWakeLock(
            PowerManager.PARTIAL_WAKE_LOCK,
            "MarkVault:BackupRestore"
        ).apply { setReferenceCounted(false) }
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        val action = intent?.action ?: run { stopSelf(startId); return START_NOT_STICKY }
        if (action == ACTION_PAUSE || action == ACTION_RESUME || action == ACTION_STOP) {
            if (operationJob?.isActive != true) {
                stopSelf(startId)
                return START_NOT_STICKY
            }
            val state = BackupRestoreOperationState.state.value
            if (intent.getStringExtra(EXTRA_REQUEST_ID) != requestId || !state.running || stopRequested) return START_NOT_STICKY
            if (action == ACTION_STOP) {
                stopRequested = true
                BackupRestoreOperationState.stopping()
                pauseGate.close()
                updateForeground("Stopping at a safe checkpoint…", state.percent)
            } else {
                val requested = action == ACTION_PAUSE
                pauseGate.request(requested) {
                    BackupRestoreOperationState.pauseState(requested, state.paused)
                    val nm = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
                    nm.notify(NOTIFICATION_ID_PROGRESS, buildProgressNotification(
                        if (requested) "Pausing at a safe checkpoint…" else "Resuming…", state.percent))
                }
            }
            return START_NOT_STICKY
        }
        if (operationJob?.isActive == true) return START_NOT_STICKY
        val uri = intent.data
        val id = intent.getStringExtra(EXTRA_REQUEST_ID)
        // Never automatically redeliver a destructive or lengthy operation.
        // Old builds' pending intents have no request ID and are not replayed.
        if (uri == null || id.isNullOrBlank() || flags and START_FLAG_REDELIVERY != 0 ||
            BackupJobJournal.read(journal())?.id == id || (action != ACTION_BACKUP && action != ACTION_RESTORE)) {
            stopSelf(startId)
            return START_NOT_STICKY
        }
        val selection = intent.getIntExtra(EXTRA_COMPONENTS, BackupSelection.ALL)
        val models = intent.getIntExtra(EXTRA_MODELS, BackupModelSelection.ALL)
        requestId = id
        pauseGate = RestorePauseGate()
        stopRequested = false
        lastNotificationPercent = -1
        lastNotificationStage = ""
        val kind = if (action == ACTION_BACKUP) BackupRestoreKind.BACKUP else BackupRestoreKind.RESTORE
        BackupRestoreOperationState.start(kind, "Preparing ${kind.name.lowercase()}…")
        beginForeground("Preparing ${kind.name.lowercase()}…", 0)
        // Record before I/O, so process death does not look like a completed job.
        try {
            BackupJobJournal.write(journal(), BackupJobJournal.Record(id, kind.name, "Running", "Operation started"))
        } catch (e: Exception) {
            finishOperation(kind, false, "Cannot safely record operation state: ${e.message.orEmpty()}", "Failed")
            return START_NOT_STICKY
        }
        acquireWakeLock()
        operationJob = scope.launch {
            val ok = if (kind == BackupRestoreKind.BACKUP) {
                BackupManager.createBackup(this@BackupRestoreService, uri, BuildConfig.VERSION_NAME, selection, models) { p ->
                    progress(kind, p.stage, p.percent, p.completed, p.total)
                }
            } else {
                BackupManager.applyBackup(this@BackupRestoreService, uri, selection, models) { p ->
                    progress(kind, p.stage, p.percent, p.completed, p.total)
                }
            }
            val partial = ok && kind == BackupRestoreKind.RESTORE && BackupManager.restoreHadDeferredComponents()
            val stage = when { partial -> "Partial"; ok -> "Complete"; stopRequested -> "Stopped"; else -> "Failed" }
            val message = when {
                ok && kind == BackupRestoreKind.BACKUP -> "Backup saved and verified."
                ok -> BackupManager.lastRestoreSummaryMessage() ?: "Restore completed and verified."
                stopRequested && kind == BackupRestoreKind.BACKUP -> "Backup stopped. An unfinished ZIP is not a verified backup; start a new backup."
                stopRequested -> "Restore stopped. Verified files remain; select the same ZIP and destination to reuse them."
                kind == BackupRestoreKind.BACKUP -> "Backup failed — ${BackupManager.lastBackupErrorMessage() ?: "unknown error"}"
                else -> "Restore failed — ${BackupManager.lastRestoreErrorMessage() ?: "current data retained"}"
            }
            // Persist the terminal result before stopping or restarting the process.
            finishOperation(kind, ok, message, stage, restart = ok && kind == BackupRestoreKind.RESTORE)
        }
        return START_NOT_STICKY
    }

    private fun progress(kind: BackupRestoreKind, stage: String, percent: Int, done: Long, total: Long) {
        if (percent < 100) pauseGate.checkpoint(onPaused = {
            BackupRestoreOperationState.pauseState(true, true)
            releaseWakeLock()
            val nm = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
            nm.notify(NOTIFICATION_ID_PROGRESS, buildProgressNotification("${kind.name.lowercase().replaceFirstChar { it.uppercase() }} paused", percent))
        }, onResumed = {
            acquireWakeLock()
            BackupRestoreOperationState.pauseState(false, false)
            lastNotificationPercent = -1
        })
        BackupRestoreOperationState.progress(kind, stage, percent, done, total)
        updateForeground("$stage $percent%", percent)
    }

    private fun finishOperation(kind: BackupRestoreKind, success: Boolean, message: String, stage: String, restart: Boolean = false) {
        val persisted = runCatching {
            BackupJobJournal.write(journal(), BackupJobJournal.Record(requestId, kind.name, stage, message))
        }.isSuccess
        val result = if (persisted) message else "$message (Could not persist job status; no automatic restart.)"
        BackupRestoreOperationState.finish(kind, success, result, stage)
        postResult(kind, stage, result)
        releaseWakeLock()
        stopForeground(STOP_FOREGROUND_REMOVE)
        // The result has already been durably recorded; no redelivered jobs.
        stopSelf()
        if (restart && persisted) android.os.Process.killProcess(android.os.Process.myPid())
    }

    private fun acquireWakeLock() {
        val lock = wakeLock ?: return
        if (!lock.isHeld) lock.acquire(12 * 60 * 60 * 1000L)
    }

    private fun releaseWakeLock() {
        if (wakeLock?.isHeld == true) runCatching { wakeLock?.release() }
    }

    private fun beginForeground(text: String, percent: Int) {
        startForeground(NOTIFICATION_ID_PROGRESS, buildProgressNotification(text, percent))
    }

    private fun updateForeground(text: String, percent: Int) {
        val normalized = percent.coerceIn(0, 100)
        if (normalized == lastNotificationPercent && text.substringBefore("  ") == lastNotificationStage) return
        lastNotificationPercent = normalized
        lastNotificationStage = text.substringBefore("  ")
        val nm = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        nm.notify(NOTIFICATION_ID_PROGRESS, buildProgressNotification(text, normalized))
    }

    private fun buildProgressNotification(text: String, percent: Int): Notification {
        val tap = PendingIntent.getActivity(
            this,
            0,
            Intent(this, MainActivity::class.java).apply {
                flags = Intent.FLAG_ACTIVITY_SINGLE_TOP or Intent.FLAG_ACTIVITY_CLEAR_TOP
            },
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        val builder = NotificationCompat.Builder(this, CHANNEL_ID)
            .setSmallIcon(R.mipmap.ic_launcher)
            .setContentTitle("MarkVault backup & restore")
            .setContentText(text)
            .setContentIntent(tap)
            .setOngoing(true)
            .setOnlyAlertOnce(true)
            .setPriority(NotificationCompat.PRIORITY_LOW)
            .setCategory(NotificationCompat.CATEGORY_PROGRESS)
            .setProgress(100, percent.coerceIn(0, 100), false)
        if (BackupRestoreOperationState.state.value.running && !stopRequested) {
            val paused = BackupRestoreOperationState.state.value.pauseRequested || BackupRestoreOperationState.state.value.paused
            val action = if (paused) ACTION_RESUME else ACTION_PAUSE
            val control = PendingIntent.getService(this, if (paused) 3 else 2,
                Intent(this, BackupRestoreService::class.java).setAction(action).putExtra(EXTRA_REQUEST_ID, requestId),
                PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
            builder.addAction(R.mipmap.ic_launcher, if (paused) "Resume" else "Pause", control)
            val stop = PendingIntent.getService(this, 4, Intent(this, BackupRestoreService::class.java)
                .setAction(ACTION_STOP).putExtra(EXTRA_REQUEST_ID, requestId), PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
            builder.addAction(R.mipmap.ic_launcher, "Stop", stop)
        }
        return builder.build()
    }

    private fun postResult(kind: BackupRestoreKind, stage: String, text: String) {
        val nm = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        val tap = PendingIntent.getActivity(
            this,
            1,
            Intent(this, MainActivity::class.java).apply {
                flags = Intent.FLAG_ACTIVITY_SINGLE_TOP or Intent.FLAG_ACTIVITY_CLEAR_TOP
            },
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        val title = "${kind.name.lowercase().replaceFirstChar { it.uppercase() }} ${stage.lowercase()}"
        nm.notify(
            NOTIFICATION_ID_RESULT,
            NotificationCompat.Builder(this, CHANNEL_ID)
                .setSmallIcon(R.mipmap.ic_launcher)
                .setContentTitle(title)
                .setContentText(text)
                .setStyle(NotificationCompat.BigTextStyle().bigText(text))
                .setContentIntent(tap)
                .setAutoCancel(true)
                .setPriority(NotificationCompat.PRIORITY_DEFAULT)
                .build()
        )
    }

    private fun createChannel() {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.O) return
        val nm = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        nm.createNotificationChannel(
            NotificationChannel(
                CHANNEL_ID,
                "Backup and restore",
                NotificationManager.IMPORTANCE_LOW
            ).apply {
                description = "Persistent progress for MarkVault backup and restore"
            }
        )
    }

    override fun onDestroy() {
        pauseGate.close()
        releaseWakeLock()
        operationJob?.cancel()
        scope.cancel()
        super.onDestroy()
    }

    override fun onBind(intent: Intent?): IBinder? = null

    companion object {
        private const val CHANNEL_ID = "markvault_backup_restore"
        private const val NOTIFICATION_ID_PROGRESS = 7401
        private const val NOTIFICATION_ID_RESULT = 7402
        const val ACTION_BACKUP = "com.tebogo.markvault.action.BACKUP"
        const val ACTION_RESTORE = "com.tebogo.markvault.action.RESTORE"

        const val ACTION_PAUSE = "com.tebogo.markvault.action.RESTORE_PAUSE"
        const val ACTION_RESUME = "com.tebogo.markvault.action.RESTORE_RESUME"
        const val ACTION_STOP = "com.tebogo.markvault.action.BACKUP_RESTORE_STOP"
        private const val EXTRA_REQUEST_ID = "backup_request_id"
        private const val EXTRA_MODELS = "backup_model_selection"
        private fun jobJournal(context: Context) = File(context.filesDir, "restore_state/job.properties")
        fun recoverLastStatus(context: Context) = BackupRestoreOperationState.recover(jobJournal(context))
        private const val EXTRA_COMPONENTS = "backup_components"
        fun controlRestore(context: Context, pause: Boolean) {
            val id = BackupJobJournal.read(jobJournal(context))?.takeIf { it.status == "Running" }?.id ?: return
            context.startService(Intent(context, BackupRestoreService::class.java).setAction(if (pause) ACTION_PAUSE else ACTION_RESUME).putExtra(EXTRA_REQUEST_ID, id))
        }

        fun stopOperation(context: Context) {
            val id = BackupJobJournal.read(jobJournal(context))?.takeIf { it.status == "Running" }?.id ?: return
            context.startService(Intent(context, BackupRestoreService::class.java).setAction(ACTION_STOP).putExtra(EXTRA_REQUEST_ID, id))
        }

        fun startBackup(context: Context, uri: Uri, selection: Int = BackupSelection.ALL, models: Int = BackupModelSelection.ALL) {
            val intent = Intent(context, BackupRestoreService::class.java).apply {
                action = ACTION_BACKUP
                data = uri
                putExtra(EXTRA_COMPONENTS, selection)
                putExtra(EXTRA_MODELS, models)
                putExtra(EXTRA_REQUEST_ID, UUID.randomUUID().toString())
                addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_WRITE_URI_PERMISSION)
            }
            ContextCompat.startForegroundService(context, intent)
        }

        fun startRestore(context: Context, uri: Uri, selection: Int = BackupSelection.ALL, models: Int = BackupModelSelection.ALL) {
            val intent = Intent(context, BackupRestoreService::class.java).apply {
                action = ACTION_RESTORE
                data = uri
                putExtra(EXTRA_COMPONENTS, selection)
                putExtra(EXTRA_MODELS, models)
                putExtra(EXTRA_REQUEST_ID, UUID.randomUUID().toString())
                addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
            }
            ContextCompat.startForegroundService(context, intent)
        }
    }
}
