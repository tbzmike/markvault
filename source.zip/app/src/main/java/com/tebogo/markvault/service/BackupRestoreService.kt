package com.tebogo.markvault.service

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.IBinder
import android.os.PowerManager
import androidx.core.app.NotificationCompat
import androidx.core.content.ContextCompat
import com.tebogo.markvault.BuildConfig
import com.tebogo.markvault.MainActivity
import com.tebogo.markvault.R
import com.tebogo.markvault.data.BackupManager
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

/**
 * Owns backup/restore independently of Compose so an explicit user operation
 * continues when Settings leaves composition, the app is backgrounded, or the
 * screen turns off. A foreground data-sync notification and partial wake lock
 * remain active only for the lifetime of the operation.
 */
class BackupRestoreService : Service() {
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
    private var operationJob: Job? = null
    private var wakeLock: PowerManager.WakeLock? = null
    private var lastNotificationPercent = -1
    private var lastNotificationStage = ""

    override fun onCreate() {
        super.onCreate()
        createChannel()
        val pm = getSystemService(Context.POWER_SERVICE) as PowerManager
        wakeLock = pm.newWakeLock(
            PowerManager.PARTIAL_WAKE_LOCK,
            "MarkVault:BackupRestore"
        ).apply { setReferenceCounted(false) }
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        val action = intent?.action ?: return START_NOT_STICKY
        val uri = intent.data ?: return START_NOT_STICKY
        if (operationJob?.isActive == true) return START_REDELIVER_INTENT

        when (action) {
            ACTION_BACKUP -> startBackup(uri)
            ACTION_RESTORE -> startRestore(uri)
            else -> return START_NOT_STICKY
        }
        return START_REDELIVER_INTENT
    }

    private fun startBackup(uri: Uri) {
        val kind = BackupRestoreKind.BACKUP
        BackupRestoreOperationState.start(kind, "Preparing backup…")
        beginForeground("Preparing backup…", 0)
        acquireWakeLock()
        operationJob = scope.launch {
            val ok = BackupManager.createBackup(
                this@BackupRestoreService,
                uri,
                BuildConfig.VERSION_NAME
            ) { p ->
                BackupRestoreOperationState.progress(kind, p.stage, p.percent, p.completed, p.total)
                updateForeground("${p.stage} ${p.percent}%", p.percent)
            }
            val message = if (ok) {
                "Backup saved and verified."
            } else {
                BackupManager.lastBackupErrorMessage()?.let { "Backup failed — $it" }
                    ?: "Backup failed."
            }
            finishOperation(kind, ok, message)
        }
    }

    private fun startRestore(uri: Uri) {
        val kind = BackupRestoreKind.RESTORE
        BackupRestoreOperationState.start(kind, "Preparing restore…")
        beginForeground("Preparing restore…", 0)
        acquireWakeLock()
        operationJob = scope.launch {
            val ok = BackupManager.applyBackup(this@BackupRestoreService, uri) { p ->
                BackupRestoreOperationState.progress(kind, p.stage, p.percent, p.completed, p.total)
                updateForeground("${p.stage} ${p.percent}%", p.percent)
            }
            val summary = BackupManager.lastRestoreSummaryMessage()
            val message = if (ok) summary ?: "Restore completed and verified."
            else BackupManager.lastRestoreErrorMessage()?.let { "Restore failed — $it" }
                ?: "Restore failed — current data was kept."
            if (ok) {
                BackupRestoreOperationState.finish(kind, true, message)
                postResult(kind, true, message)
                releaseWakeLock()
                stopForeground(STOP_FOREGROUND_REMOVE)
                // Settings are staged and deliberately applied only on a cold
                // process start. Keep this service alive for one brief beat so
                // the 100% state/result notification is published before the
                // process is intentionally closed.
                delay(1_200L)
                android.os.Process.killProcess(android.os.Process.myPid())
            } else {
                finishOperation(kind, false, message)
            }
        }
    }

    private fun finishOperation(kind: BackupRestoreKind, success: Boolean, message: String) {
        BackupRestoreOperationState.finish(kind, success, message)
        postResult(kind, success, message)
        releaseWakeLock()
        stopForeground(STOP_FOREGROUND_REMOVE)
        stopSelf()
    }

    private fun acquireWakeLock() {
        val lock = wakeLock ?: return
        if (!lock.isHeld) lock.acquire(12 * 60 * 60 * 1000L)
    }

    private fun releaseWakeLock() {
        if (wakeLock?.isHeld == true) runCatching { wakeLock?.release() }
    }

    private fun beginForeground(text: String, percent: Int) {
        startForeground(NOTIFICATION_ID_PROGRESS, buildProgressNotification(text, percent))
    }

    private fun updateForeground(text: String, percent: Int) {
        val normalized = percent.coerceIn(0, 100)
        if (normalized == lastNotificationPercent && text.substringBefore("  ") == lastNotificationStage) return
        lastNotificationPercent = normalized
        lastNotificationStage = text.substringBefore("  ")
        val nm = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        nm.notify(NOTIFICATION_ID_PROGRESS, buildProgressNotification(text, normalized))
    }

    private fun buildProgressNotification(text: String, percent: Int): Notification {
        val tap = PendingIntent.getActivity(
            this,
            0,
            Intent(this, MainActivity::class.java).apply {
                flags = Intent.FLAG_ACTIVITY_SINGLE_TOP or Intent.FLAG_ACTIVITY_CLEAR_TOP
            },
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        return NotificationCompat.Builder(this, CHANNEL_ID)
            .setSmallIcon(R.mipmap.ic_launcher)
            .setContentTitle("MarkVault backup & restore")
            .setContentText(text)
            .setContentIntent(tap)
            .setOngoing(true)
            .setOnlyAlertOnce(true)
            .setPriority(NotificationCompat.PRIORITY_LOW)
            .setCategory(NotificationCompat.CATEGORY_PROGRESS)
            .setProgress(100, percent.coerceIn(0, 100), false)
            .build()
    }

    private fun postResult(kind: BackupRestoreKind, success: Boolean, text: String) {
        val nm = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        val tap = PendingIntent.getActivity(
            this,
            1,
            Intent(this, MainActivity::class.java).apply {
                flags = Intent.FLAG_ACTIVITY_SINGLE_TOP or Intent.FLAG_ACTIVITY_CLEAR_TOP
            },
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        val title = when {
            kind == BackupRestoreKind.BACKUP && success -> "Backup complete"
            kind == BackupRestoreKind.RESTORE && success -> "Restore complete"
            kind == BackupRestoreKind.BACKUP -> "Backup failed"
            else -> "Restore failed"
        }
        nm.notify(
            NOTIFICATION_ID_RESULT,
            NotificationCompat.Builder(this, CHANNEL_ID)
                .setSmallIcon(R.mipmap.ic_launcher)
                .setContentTitle(title)
                .setContentText(text)
                .setStyle(NotificationCompat.BigTextStyle().bigText(text))
                .setContentIntent(tap)
                .setAutoCancel(true)
                .setPriority(NotificationCompat.PRIORITY_DEFAULT)
                .build()
        )
    }

    private fun createChannel() {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.O) return
        val nm = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        nm.createNotificationChannel(
            NotificationChannel(
                CHANNEL_ID,
                "Backup and restore",
                NotificationManager.IMPORTANCE_LOW
            ).apply {
                description = "Persistent progress for MarkVault backup and restore"
            }
        )
    }

    override fun onDestroy() {
        releaseWakeLock()
        operationJob?.cancel()
        scope.cancel()
        super.onDestroy()
    }

    override fun onBind(intent: Intent?): IBinder? = null

    companion object {
        private const val CHANNEL_ID = "markvault_backup_restore"
        private const val NOTIFICATION_ID_PROGRESS = 7401
        private const val NOTIFICATION_ID_RESULT = 7402
        const val ACTION_BACKUP = "com.tebogo.markvault.action.BACKUP"
        const val ACTION_RESTORE = "com.tebogo.markvault.action.RESTORE"

        fun startBackup(context: Context, uri: Uri) {
            val intent = Intent(context, BackupRestoreService::class.java).apply {
                action = ACTION_BACKUP
                data = uri
                addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_WRITE_URI_PERMISSION)
            }
            ContextCompat.startForegroundService(context, intent)
        }

        fun startRestore(context: Context, uri: Uri) {
            val intent = Intent(context, BackupRestoreService::class.java).apply {
                action = ACTION_RESTORE
                data = uri
                addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
            }
            ContextCompat.startForegroundService(context, intent)
        }
    }
}
