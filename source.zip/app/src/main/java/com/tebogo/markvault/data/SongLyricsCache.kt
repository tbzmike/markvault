package com.tebogo.markvault.data

import android.content.Context
import android.text.Html
import android.util.Log
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.ensureActive
import kotlinx.coroutines.withContext
import org.json.JSONObject
import java.io.File
import java.net.HttpURLConnection
import java.net.URI
import java.net.URL
import java.security.MessageDigest
import java.text.Normalizer
import kotlin.coroutines.coroutineContext

/**
 * Disk cache + resolver for JW.org song lyrics.
 *
 * v5.4.281cc — The resolver no longer drives a hidden WebView or guesses a
 * single page slug and waits for DOM callbacks.  JW.org publishes numbered
 * "Sing Out Joyfully" songs and named Original Songs as ordinary linked
 * article pages.  We therefore resolve the exact article from the official
 * collection page (number + title when available), fetch that article, extract
 * its visible song words, and cache the result.  This is deterministic and
 * independent of WebView rendering timing.
 */
data class CachedSongLyrics(
    val text: String,
    val sourceUrl: String,
    val cachedAt: Long
)

object SongLyricsCache {
    private const val DIR_NAME = "song_lyrics"
    private const val CONNECT_TIMEOUT_MS = 10_000
    private const val READ_TIMEOUT_MS = 10_000
    private const val TAG = "SongLyricsCache"
    private const val USER_AGENT = "Mozilla/5.0 (Linux; Android 16) AppleWebKit/537.36 Chrome/140 Mobile Safari/537.36 MarkVault/5.4"

    suspend fun load(context: Context, item: MediaItem): CachedSongLyrics? = withContext(Dispatchers.IO) {
        val file = cacheFile(context, item)
        if (!file.isFile) return@withContext null
        runCatching {
            val json = JSONObject(file.readText(Charsets.UTF_8))
            val text = json.optString("text").trim()
            if (text.isBlank()) return@runCatching null
            CachedSongLyrics(
                text = text,
                sourceUrl = json.optString("sourceUrl"),
                cachedAt = json.optLong("cachedAt", file.lastModified())
            )
        }.getOrNull()
    }

    suspend fun save(context: Context, item: MediaItem, lyrics: CachedSongLyrics) = withContext(Dispatchers.IO) {
        val file = cacheFile(context, item)
        file.parentFile?.mkdirs()
        val temp = File(file.parentFile, file.name + ".tmp")
        val json = JSONObject()
            .put("title", item.title)
            .put("jwKey", item.jwKey)
            .put("text", lyrics.text)
            .put("sourceUrl", lyrics.sourceUrl)
            .put("cachedAt", lyrics.cachedAt)
        temp.writeText(json.toString(), Charsets.UTF_8)
        if (!temp.renameTo(file)) {
            file.writeText(json.toString(), Charsets.UTF_8)
            temp.delete()
        }
    }

    fun isLyricsEligible(item: MediaItem): Boolean {
        if (!item.mediaType.equals("audio", ignoreCase = true)) return false
        val category = item.category.lowercase()
        val key = item.jwKey.lowercase()
        return category.contains("song") ||
            category.contains("music") ||
            category.contains("sjj") ||
            key.contains("sjj") ||
            key.contains("song")
    }

    /**
     * Resolve the currently-playing song to its official JW.org words.
     *
     * Resolution order is chosen from the media metadata, not from a fixed
     * assumption.  Numbered/sjj media search the numbered songbook first;
     * other songs search Original Songs first.  The other official collection
     * is still tried as a fallback.
     */
    suspend fun fetchFromJw(item: MediaItem): CachedSongLyrics? = withContext(Dispatchers.IO) {
        if (!isLyricsEligible(item)) return@withContext null
        val title = cleanMediaTitle(item.title)
        if (title.isBlank()) return@withContext null

        val locale = inferJwLocale(item)
        val numberHint = extractSongNumber(item)
        val looksNumberedSong = numberHint != null ||
            item.jwKey.contains("sjj", ignoreCase = true) ||
            item.category.contains("sjj", ignoreCase = true) ||
            item.category.contains("sing out", ignoreCase = true)

        val resolvers: List<suspend () -> CachedSongLyrics?> = if (looksNumberedSong) {
            listOf(
                { resolveFromCollection(title, numberHint, songbookCollectionUrl(locale), Collection.SING_OUT_JOYFULLY) },
                { resolveOriginalSong(title, locale) }
            )
        } else {
            listOf(
                { resolveOriginalSong(title, locale) },
                { resolveFromCollection(title, numberHint, songbookCollectionUrl(locale), Collection.SING_OUT_JOYFULLY) }
            )
        }

        for (resolver in resolvers) {
            coroutineContext.ensureActive()
            val result = try {
                resolver()
            } catch (cancelled: CancellationException) {
                throw cancelled
            } catch (_: Exception) {
                null
            }
            if (result != null) return@withContext result
        }
        null
    }

    private suspend fun resolveOriginalSong(title: String, locale: String): CachedSongLyrics? {
        coroutineContext.ensureActive()

        // Fast path for the normal English/localized Original Song URL shape.
        // If JW.org uses a different localized slug, the collection lookup
        // immediately below resolves the real link instead.
        val direct = originalSongCandidateUrl(title)
        fetchLyricsArticle(direct, title)?.let { return it }

        return resolveFromCollection(
            title = title,
            numberHint = null,
            collectionUrl = originalSongsCollectionUrl(locale),
            collection = Collection.ORIGINAL_SONGS
        )
    }

    private suspend fun resolveFromCollection(
        title: String,
        numberHint: Int?,
        collectionUrl: String,
        collection: Collection
    ): CachedSongLyrics? {
        coroutineContext.ensureActive()
        val page = httpGet(collectionUrl) ?: return null
        val links = extractLinks(page.html, page.finalUrl)
        val wanted = normalizeTitle(title)
        if (wanted.isBlank()) return null

        val best = links
            .asSequence()
            .filter { link ->
                when (collection) {
                    Collection.ORIGINAL_SONGS -> link.url.contains("/library/music-songs/original-songs/", ignoreCase = true)
                    Collection.SING_OUT_JOYFULLY -> link.url.contains("/library/music-songs/sing-out-joyfully/", ignoreCase = true)
                }
            }
            .map { link -> link to matchScore(link.text, wanted, numberHint, collection) }
            .filter { it.second > 0 }
            .maxByOrNull { it.second }
            ?.first
            ?: run {
                Log.d(TAG, "No collection match: title=$title number=$numberHint collection=$collection")
                return null
            }

        Log.d(TAG, "Resolved lyrics article: title=$title number=$numberHint -> ${best.url}")
        return fetchLyricsArticle(best.url, title)
    }

    private suspend fun fetchLyricsArticle(url: String, title: String): CachedSongLyrics? {
        coroutineContext.ensureActive()
        val page = httpGet(url) ?: return null
        val text = htmlToVisibleText(page.html)
        val wanted = normalizeTitle(title)
        val titlePresent = text.lineSequence().any { line ->
            val normalized = normalizeTitle(removeSongNumberDecorations(line.trim()))
            normalized == wanted || normalized.endsWith(" $wanted")
        }
        if (!titlePresent) return null
        val lyrics = extractLyricsFromVisibleText(text, title) ?: return null
        return CachedSongLyrics(
            text = lyrics,
            sourceUrl = page.finalUrl,
            cachedAt = System.currentTimeMillis()
        )
    }

    private fun matchScore(
        linkText: String,
        wantedTitle: String,
        numberHint: Int?,
        collection: Collection
    ): Int {
        val number = leadingSongNumber(linkText)
        val linkTitle = normalizeTitle(removeSongNumberDecorations(linkText))
        if (linkTitle.isBlank()) return 0

        var score = 0
        if (linkTitle == wantedTitle) score += 100
        else if (linkTitle.contains(wantedTitle) || wantedTitle.contains(linkTitle)) score += 45
        else {
            val wantedWords = wantedTitle.split(' ').filter { it.length > 2 }.toSet()
            val linkWords = linkTitle.split(' ').filter { it.length > 2 }.toSet()
            if (wantedWords.isNotEmpty()) {
                val overlap = wantedWords.intersect(linkWords).size
                score += (overlap * 30) / wantedWords.size
            }
        }

        if (numberHint != null) {
            if (number == numberHint) score += 150
            else if (collection == Collection.SING_OUT_JOYFULLY && number != null) score -= 40
        }
        return score
    }

    private fun extractLinks(html: String, baseUrl: String): List<PageLink> {
        val regex = Regex(
            "<a\\b[^>]*?href\\s*=\\s*([\\\"'])(.*?)\\1[^>]*>(.*?)</a>",
            setOf(RegexOption.IGNORE_CASE, RegexOption.DOT_MATCHES_ALL)
        )
        return regex.findAll(html).mapNotNull { match ->
            val rawHref = decodeHtml(match.groupValues[2]).trim()
            if (rawHref.isBlank() || rawHref.startsWith("#") || rawHref.startsWith("javascript:", true)) return@mapNotNull null
            val absolute = runCatching { URI(baseUrl).resolve(rawHref).toString() }.getOrNull() ?: return@mapNotNull null
            if (!absolute.startsWith("https://www.jw.org/", ignoreCase = true)) return@mapNotNull null
            val text = htmlToVisibleText(match.groupValues[3]).replace(Regex("\\s+"), " ").trim()
            if (text.isBlank()) null else PageLink(absolute, text)
        }.toList()
    }

    private fun httpGet(url: String): HttpPage? {
        var connection: HttpURLConnection? = null
        return try {
            connection = URL(url).openConnection() as HttpURLConnection
            connection.instanceFollowRedirects = true
            connection.connectTimeout = CONNECT_TIMEOUT_MS
            connection.readTimeout = READ_TIMEOUT_MS
            connection.setRequestProperty("Accept", "text/html,application/xhtml+xml")
            connection.setRequestProperty("Accept-Language", "en-US,en;q=0.9")
            connection.setRequestProperty("User-Agent", USER_AGENT)
            val code = connection.responseCode
            if (code !in 200..299) return null
            val html = connection.inputStream.bufferedReader(Charsets.UTF_8).use { it.readText() }
            HttpPage(html = html, finalUrl = connection.url.toString())
        } catch (_: Exception) {
            null
        } finally {
            connection?.disconnect()
        }
    }

    private fun htmlToVisibleText(html: String): String = Html.fromHtml(
        html,
        Html.FROM_HTML_MODE_LEGACY
    ).toString()

    private fun decodeHtml(value: String): String = Html.fromHtml(
        value,
        Html.FROM_HTML_MODE_LEGACY
    ).toString()

    /** Extract only the song words from a JW.org song article's visible text. */
    private fun extractLyricsFromVisibleText(raw: String, title: String): String? {
        if (raw.isBlank()) return null
        val lines = raw
            .replace("\r", "")
            .split('\n')
            .map { it.trim() }

        val stopAt = lines.indexOfFirst { line ->
            line.equals("Sorry, the media player failed to load.", ignoreCase = true) ||
                line.equals("Download This Video", ignoreCase = true) ||
                line.equals("DOWNLOAD OPTIONS", ignoreCase = true) ||
                line.startsWith("(See also", ignoreCase = true) ||
                line.equals("Previous", ignoreCase = true)
        }.let { if (it >= 0) it else lines.size }
        if (stopAt <= 0) return null

        val numberedVerse = Regex("^(?:[•·]\\s*)?(\\d+)\\.\\s*(?:\\1\\.\\s*)?\\S.*")
        val sectionLine = Regex(
            "^\\((?:(?:PRE-)?CHORUS(?:\\s+\\d+)?|BRIDGE(?:\\s+\\d+)?|VERSE(?:\\s+\\d+)?|INTRO|OUTRO|REFRAIN)\\)$",
            RegexOption.IGNORE_CASE
        )

        var startAt = lines.indexOfFirst { line -> numberedVerse.matches(line) || sectionLine.matches(line) }
        if (startAt < 0 || startAt >= stopAt) return null

        // Reject an accidental numbered navigation/menu line by requiring a
        // second lyric-like line reasonably close to the first candidate.
        val hasContinuation = (startAt + 1 until minOf(stopAt, startAt + 8)).any { idx ->
            val line = lines[idx]
            line.isNotBlank() &&
                !line.equals("Play", true) &&
                !line.equals("Select an Audio Recording", true) &&
                !line.equals("Download", true)
        }
        if (!hasContinuation) return null

        val titleNorm = normalizeTitle(title)
        val body = lines.subList(startAt, stopAt)
            .dropWhile { it.isBlank() }
            .filterNot { line ->
                line.equals("Lead Sheet", ignoreCase = true) ||
                    line.equals("PLAY", ignoreCase = true) ||
                    line.equals("Select an Audio Recording", ignoreCase = true) ||
                    normalizeTitle(line) == titleNorm
            }
            .map { line ->
                line.replace(Regex("^(?:[•·]\\s*)?(\\d+)\\.\\s+\\1\\.\\s*"), "$1. ")
            }
            .toMutableList()

        while (body.isNotEmpty() && body.first().isBlank()) body.removeAt(0)
        while (body.isNotEmpty() && body.last().isBlank()) body.removeAt(body.lastIndex)

        val meaningful = body.count { line -> line.isNotBlank() && !sectionLine.matches(line) }
        if (meaningful < 2) return null

        return buildString {
            var previousBlank = false
            body.forEach { line ->
                val blank = line.isBlank()
                if (blank && previousBlank) return@forEach
                if (isNotEmpty()) append('\n')
                append(line)
                previousBlank = blank
            }
        }.trim().takeIf { it.isNotBlank() }
    }

    private fun songbookCollectionUrl(locale: String) =
        "https://www.jw.org/finder?srcid=jwlshare&wtlocale=$locale&prefer=lang&pub=sjj"

    private fun originalSongsCollectionUrl(locale: String): String {
        // English is the media API's current default. For another locale the
        // JW finder is allowed to redirect to that language's site path; if a
        // localized Original Songs path is unavailable, English is the safe
        // official fallback and title matching still prevents a wrong song.
        return if (locale == "E") {
            "https://www.jw.org/en/library/music-songs/original-songs/"
        } else {
            "https://www.jw.org/en/library/music-songs/original-songs/"
        }
    }

    private fun originalSongCandidateUrl(title: String): String {
        val ascii = Normalizer.normalize(title, Normalizer.Form.NFD)
            .replace(Regex("\\p{M}+"), "")
        val slug = ascii
            .replace(Regex("[‘’“”\\\"'`]+"), "")
            .replace(Regex("[^A-Za-z0-9]+"), "-")
            .trim('-')
        // Current media API is English (E). Collection lookup below is the
        // authoritative fallback, so this direct URL is only a fast path.
        return "https://www.jw.org/en/library/music-songs/original-songs/$slug/"
    }

    private fun extractSongNumber(item: MediaItem): Int? {
        val sources = listOf(item.jwKey, item.category, item.title)
        val explicit = Regex("(?i)(?:sjj|song)[^0-9]{0,12}(\\d{1,3})")
        for (source in sources) {
            val number = explicit.find(source)?.groupValues?.getOrNull(1)?.toIntOrNull()
            if (number != null && number in 1..300) return number
        }
        if (item.jwKey.contains("sjj", true) || item.category.contains("sjj", true)) {
            val number = Regex("(?:^|[_-])(\\d{1,3})(?:[_-]|$)")
                .find(item.jwKey)?.groupValues?.getOrNull(1)?.toIntOrNull()
            if (number != null && number in 1..300) return number
        }
        return leadingSongNumber(item.title)
    }

    private fun leadingSongNumber(raw: String): Int? = Regex(
        "^\\s*(?:song\\s*)?(\\d{1,3})(?:\\s*[.\\-–—:]|\\s+)",
        RegexOption.IGNORE_CASE
    ).find(raw)?.groupValues?.getOrNull(1)?.toIntOrNull()

    private fun removeSongNumberDecorations(raw: String): String = raw
        .replace(Regex("^\\s*(?:song\\s*)?\\d{1,3}(?:\\s*[.\\-–—:]|\\s+)", RegexOption.IGNORE_CASE), "")
        .replace(Regex("\\s*\\(\\s*song\\s*\\d{1,3}\\s*\\)\\s*$", RegexOption.IGNORE_CASE), "")
        .trim()

    private fun cleanMediaTitle(raw: String): String = removeSongNumberDecorations(raw)
        .replace(Regex("\\s*[|–—-]\\s*(?:JW\\.ORG|Original Songs?|Sing Out Joyfully).*$", RegexOption.IGNORE_CASE), "")
        .trim()

    private fun inferJwLocale(item: MediaItem): String {
        val candidates = listOf(item.streamUrl, item.localPath, item.jwKey)
        for (candidate in candidates) {
            val token = Regex("(?:^|[_/-])([A-Z]{1,4})(?:[_./-]|$)")
                .find(candidate)?.groupValues?.getOrNull(1)
            if (!token.isNullOrBlank() && token.length in 1..4) return token
        }
        return "E"
    }

    private fun cacheFile(context: Context, item: MediaItem): File {
        val stableKey = item.jwKey.ifBlank { normalizeTitle(item.title) }
        val digest = MessageDigest.getInstance("SHA-256")
            .digest(stableKey.toByteArray(Charsets.UTF_8))
            .joinToString("") { "%02x".format(it) }
        return File(File(context.filesDir, DIR_NAME), "$digest.json")
    }

    fun normalizeTitle(raw: String): String = Normalizer.normalize(raw, Normalizer.Form.NFD)
        .replace(Regex("\\p{M}+"), "")
        .lowercase()
        .replace(Regex("[\\u2018\\u2019\\u201C\\u201D\\\"'`]+"), "")
        .replace(Regex("[^\\p{L}\\p{N}]+"), " ")
        .trim()
        .replace(Regex("\\s+"), " ")

    private enum class Collection { ORIGINAL_SONGS, SING_OUT_JOYFULLY }
    private data class HttpPage(val html: String, val finalUrl: String)
    private data class PageLink(val url: String, val text: String)
}
