package com.tebogo.markvault.data

import android.content.Context
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONObject
import java.io.File
import java.security.MessageDigest

/**
 * Small disk cache for JW.org song lyrics.
 *
 * Lyrics are deliberately kept outside Room: they are optional web-derived
 * presentation data, not part of the vault/media index schema. This avoids a
 * database migration for a feature that can always be rebuilt from JW.org.
 */
data class CachedSongLyrics(
    val text: String,
    val sourceUrl: String,
    val cachedAt: Long
)

object SongLyricsCache {
    private const val DIR_NAME = "song_lyrics"

    suspend fun load(context: Context, item: MediaItem): CachedSongLyrics? = withContext(Dispatchers.IO) {
        val file = cacheFile(context, item)
        if (!file.isFile) return@withContext null
        runCatching {
            val json = JSONObject(file.readText(Charsets.UTF_8))
            val text = json.optString("text").trim()
            if (text.isBlank()) return@runCatching null
            CachedSongLyrics(
                text = text,
                sourceUrl = json.optString("sourceUrl"),
                cachedAt = json.optLong("cachedAt", file.lastModified())
            )
        }.getOrNull()
    }

    suspend fun save(context: Context, item: MediaItem, lyrics: CachedSongLyrics) = withContext(Dispatchers.IO) {
        val file = cacheFile(context, item)
        file.parentFile?.mkdirs()
        val temp = File(file.parentFile, file.name + ".tmp")
        val json = JSONObject()
            .put("title", item.title)
            .put("jwKey", item.jwKey)
            .put("text", lyrics.text)
            .put("sourceUrl", lyrics.sourceUrl)
            .put("cachedAt", lyrics.cachedAt)
        temp.writeText(json.toString(), Charsets.UTF_8)
        if (!temp.renameTo(file)) {
            file.writeText(json.toString(), Charsets.UTF_8)
            temp.delete()
        }
    }

    fun isLyricsEligible(item: MediaItem): Boolean {
        if (!item.mediaType.equals("audio", ignoreCase = true)) return false
        // Media rows saved by older MarkVault builds can have incomplete source
        // metadata even though their JW natural key/category is intact. Do not
        // hide lyrics solely because that optional source string is missing.
        val category = item.category.lowercase()
        val key = item.jwKey.lowercase()
        return category.contains("song") ||
            category.contains("music") ||
            category.contains("sjj") ||
            key.contains("sjj") ||
            key.contains("song")
    }

    private fun cacheFile(context: Context, item: MediaItem): File {
        val stableKey = item.jwKey.ifBlank { normalizeTitle(item.title) }
        val digest = MessageDigest.getInstance("SHA-256")
            .digest(stableKey.toByteArray(Charsets.UTF_8))
            .joinToString("") { "%02x".format(it) }
        return File(File(context.filesDir, DIR_NAME), "$digest.json")
    }

    fun normalizeTitle(raw: String): String = raw
        .lowercase()
        .replace(Regex("[\\u2018\\u2019\\u201C\\u201D\\\"'`]+"), "")
        .replace(Regex("[^\\p{L}\\p{N}]+"), " ")
        .trim()
        .replace(Regex("\\s+"), " ")
}
