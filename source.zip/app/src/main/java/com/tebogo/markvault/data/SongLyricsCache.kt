package com.tebogo.markvault.data

import android.content.Context
import android.text.Html
import android.util.Log
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.ensureActive
import kotlinx.coroutines.withContext
import org.json.JSONObject
import java.io.File
import java.net.HttpURLConnection
import java.net.URI
import java.net.URL
import java.security.MessageDigest
import java.text.Normalizer
import kotlin.coroutines.coroutineContext

/**
 * Disk cache + resolver for JW.org song lyrics.
 *
 * v5.4.281cc — The resolver no longer drives a hidden WebView or guesses a
 * single page slug and waits for DOM callbacks.  JW.org publishes numbered
 * "Sing Out Joyfully" songs and named Original Songs as ordinary linked
 * article pages.  We therefore resolve the exact article from the official
 * collection page (number + title when available), fetch that article, extract
 * its visible song words, and cache the result.  This is deterministic and
 * independent of WebView rendering timing.
 */
data class TimedLyricLine(
    val text: String,
    val isSection: Boolean,
    val startMs: Long,
    val endMs: Long
)

data class CachedSongLyrics(
    val text: String,
    val sourceUrl: String,
    val cachedAt: Long,
    val timedLines: List<TimedLyricLine> = emptyList()
)

object SongLyricsCache {
    private const val DIR_NAME = "song_lyrics"
    private const val CONNECT_TIMEOUT_MS = 10_000
    private const val READ_TIMEOUT_MS = 10_000
    private const val TAG = "SongLyricsCache"
    private const val USER_AGENT = "Mozilla/5.0 (Linux; Android 16) AppleWebKit/537.36 Chrome/140 Mobile Safari/537.36 MarkVault/5.4"

    suspend fun load(context: Context, item: MediaItem): CachedSongLyrics? = withContext(Dispatchers.IO) {
        val file = cacheFile(context, item)
        if (!file.isFile) return@withContext null
        runCatching {
            val json = JSONObject(file.readText(Charsets.UTF_8))
            val text = json.optString("text").trim()
            if (text.isBlank()) return@runCatching null
            val timed = mutableListOf<TimedLyricLine>()
            val arr = json.optJSONArray("timedLines")
            if (arr != null) for (i in 0 until arr.length()) {
                val o = arr.optJSONObject(i) ?: continue
                timed += TimedLyricLine(
                    text = o.optString("text"),
                    isSection = o.optBoolean("isSection", false),
                    startMs = o.optLong("startMs", 0L),
                    endMs = o.optLong("endMs", 0L)
                )
            }
            CachedSongLyrics(
                text = text,
                sourceUrl = json.optString("sourceUrl"),
                cachedAt = json.optLong("cachedAt", file.lastModified()),
                timedLines = timed
            )
        }.getOrNull()
    }

    suspend fun save(context: Context, item: MediaItem, lyrics: CachedSongLyrics) = withContext(Dispatchers.IO) {
        val file = cacheFile(context, item)
        file.parentFile?.mkdirs()
        val temp = File(file.parentFile, file.name + ".tmp")
        val json = JSONObject()
            .put("title", item.title)
            .put("jwKey", item.jwKey)
            .put("contentLanguage", item.contentLanguage.ifBlank { "E" })
            .put("text", lyrics.text)
            .put("sourceUrl", lyrics.sourceUrl)
            .put("cachedAt", lyrics.cachedAt)
            .put("timedLines", org.json.JSONArray().apply {
                lyrics.timedLines.forEach { line ->
                    put(JSONObject()
                        .put("text", line.text)
                        .put("isSection", line.isSection)
                        .put("startMs", line.startMs)
                        .put("endMs", line.endMs))
                }
            })
        temp.writeText(json.toString(), Charsets.UTF_8)
        if (!temp.renameTo(file)) {
            file.writeText(json.toString(), Charsets.UTF_8)
            temp.delete()
        }
    }

    fun isLyricsEligible(item: MediaItem): Boolean {
        if (!item.mediaType.equals("audio", ignoreCase = true)) return false
        val category = item.category.lowercase()
        val key = item.jwKey.lowercase()
        return category.contains("song") ||
            category.contains("music") ||
            category.contains("sjj") ||
            key.contains("sjj") ||
            key.contains("song")
    }

    /**
     * Resolve the currently-playing song to its official JW.org words.
     *
     * Resolution order is chosen from the media metadata, not from a fixed
     * assumption.  Numbered/sjj media search the numbered songbook first;
     * other songs search Original Songs first.  The other official collection
     * is still tried as a fallback.
     */
    suspend fun fetchFromJw(item: MediaItem): CachedSongLyrics? = withContext(Dispatchers.IO) {
        if (!isLyricsEligible(item)) return@withContext null
        val title = cleanMediaTitle(item.title)
        if (title.isBlank()) return@withContext null

        // v5.4.355cc — Lyrics follow the media edition itself.  The mediator
        // language code is persisted on every MediaItem; do not re-infer it
        // from a CDN URL (which made non-English playback fall back to E).
        val languageCode = item.contentLanguage.ifBlank { inferJwLocale(item) }
        val webLocale = resolveWebLocale(languageCode)
        val numberHint = extractSongNumber(item)
        val looksNumberedSong = numberHint != null ||
            item.jwKey.contains("sjj", ignoreCase = true) ||
            item.category.contains("sjj", ignoreCase = true) ||
            item.category.contains("sing out", ignoreCase = true)

        val resolvers: List<suspend () -> CachedSongLyrics?> = if (looksNumberedSong) {
            listOf(
                { resolveNumberedSong(title, numberHint, languageCode, webLocale) },
                { resolveFromCollection(title, numberHint, songbookCollectionUrl(languageCode), Collection.SING_OUT_JOYFULLY) },
                { resolveOriginalSong(title, languageCode, webLocale) }
            )
        } else {
            listOf(
                { resolveOriginalSong(title, languageCode, webLocale) },
                { resolveFromCollection(title, numberHint, songbookCollectionUrl(languageCode), Collection.SING_OUT_JOYFULLY) }
            )
        }

        for (resolver in resolvers) {
            coroutineContext.ensureActive()
            val result = try {
                resolver()
            } catch (cancelled: CancellationException) {
                throw cancelled
            } catch (_: Exception) {
                null
            }
            if (result != null) return@withContext result.withBestTiming(item)
        }
        null
    }


    private suspend fun resolveNumberedSong(
        title: String,
        numberHint: Int?,
        languageCode: String,
        webLocale: String
    ): CachedSongLyrics? {
        if (numberHint == null) return null
        // Most stable language-independent route: JW finder resolves the same
        // sjj track into the requested language, regardless of translated URL paths.
        val finder = "https://www.jw.org/finder?srcid=jwlshare&wtlocale=${languageCode.ifBlank { "E" }}&prefer=lang&pub=sjj&track=$numberHint"
        fetchLyricsArticle(finder, title)?.let { return it }

        // Fast direct path for English; for every other language the collection
        // resolver below follows JW's own localized links instead of guessing paths.
        if (webLocale.equals("en", true)) {
            val slug = slugify(title)
            fetchLyricsArticle("https://www.jw.org/en/library/music-songs/sing-out-joyfully/$numberHint-$slug/", title)
                ?.let { return it }
        }
        return null
    }

    private suspend fun resolveOriginalSong(
        title: String,
        languageCode: String,
        webLocale: String
    ): CachedSongLyrics? {
        coroutineContext.ensureActive()

        // Fast path for the localized JW.org Original Songs URL. The web
        // locale comes from the mediator language catalogue, not from a
        // hard-coded language table. Collection lookup remains authoritative.
        val direct = originalSongCandidateUrl(title, webLocale)
        fetchLyricsArticle(direct, title)?.let { return it }

        return resolveFromCollection(
            title = title,
            numberHint = null,
            collectionUrl = originalSongsCollectionUrl(languageCode, webLocale),
            collection = Collection.ORIGINAL_SONGS
        )
    }

    private suspend fun resolveFromCollection(
        title: String,
        numberHint: Int?,
        collectionUrl: String,
        collection: Collection
    ): CachedSongLyrics? {
        coroutineContext.ensureActive()
        val page = httpGet(collectionUrl) ?: return null
        val links = extractLinks(page.html, page.finalUrl)
        val wanted = normalizeTitle(title)
        if (wanted.isBlank()) return null

        val best = links
            .asSequence()
            .filter { link ->
                // JW translates URL path segments (for example Sepedi uses
                // /laeprari/mmino-dikoša/opela-o-thabile/). Restrict to JW.org
                // article links, then score by song number/title instead of English paths.
                runCatching { URI(link.url).host?.endsWith("jw.org", ignoreCase = true) == true }.getOrDefault(false)
            }
            .map { link -> link to matchScore(link.text, wanted, numberHint, collection) }
            .filter { it.second > 0 }
            .maxByOrNull { it.second }
            ?.first
            ?: run {
                Log.d(TAG, "No collection match: title=$title number=$numberHint collection=$collection")
                return null
            }

        Log.d(TAG, "Resolved lyrics article: title=$title number=$numberHint -> ${best.url}")
        return fetchLyricsArticle(best.url, title)
    }

    private suspend fun fetchLyricsArticle(url: String, title: String): CachedSongLyrics? {
        coroutineContext.ensureActive()
        val page = httpGet(url) ?: return null
        val text = htmlToVisibleText(page.html)
        val lyrics = extractLyricsFromVisibleText(text, title) ?: return null
        return CachedSongLyrics(
            text = lyrics,
            sourceUrl = page.finalUrl,
            cachedAt = System.currentTimeMillis()
        )
    }

    private fun matchScore(
        linkText: String,
        wantedTitle: String,
        numberHint: Int?,
        collection: Collection
    ): Int {
        val number = leadingSongNumber(linkText)
        val linkTitle = normalizeTitle(removeSongNumberDecorations(linkText))
        if (linkTitle.isBlank()) return 0

        var score = 0
        if (linkTitle == wantedTitle) score += 100
        else if (linkTitle.contains(wantedTitle) || wantedTitle.contains(linkTitle)) score += 45
        else {
            val wantedWords = wantedTitle.split(' ').filter { it.length > 2 }.toSet()
            val linkWords = linkTitle.split(' ').filter { it.length > 2 }.toSet()
            if (wantedWords.isNotEmpty()) {
                val overlap = wantedWords.intersect(linkWords).size
                score += (overlap * 30) / wantedWords.size
            }
        }

        if (numberHint != null) {
            if (number == numberHint) score += 150
            else if (collection == Collection.SING_OUT_JOYFULLY && number != null) score -= 40
        }
        return score
    }

    private fun extractLinks(html: String, baseUrl: String): List<PageLink> {
        val regex = Regex(
            "<a\\b[^>]*?href\\s*=\\s*([\\\"'])(.*?)\\1[^>]*>(.*?)</a>",
            setOf(RegexOption.IGNORE_CASE, RegexOption.DOT_MATCHES_ALL)
        )
        return regex.findAll(html).mapNotNull { match ->
            val rawHref = decodeHtml(match.groupValues[2]).trim()
            if (rawHref.isBlank() || rawHref.startsWith("#") || rawHref.startsWith("javascript:", true)) return@mapNotNull null
            val absolute = runCatching { URI(baseUrl).resolve(rawHref).toString() }.getOrNull() ?: return@mapNotNull null
            if (!absolute.startsWith("https://www.jw.org/", ignoreCase = true)) return@mapNotNull null
            val text = htmlToVisibleText(match.groupValues[3]).replace(Regex("\\s+"), " ").trim()
            if (text.isBlank()) null else PageLink(absolute, text)
        }.toList()
    }

    private fun httpGet(url: String): HttpPage? {
        var connection: HttpURLConnection? = null
        return try {
            connection = URL(url).openConnection() as HttpURLConnection
            connection.instanceFollowRedirects = true
            connection.connectTimeout = CONNECT_TIMEOUT_MS
            connection.readTimeout = READ_TIMEOUT_MS
            connection.setRequestProperty("Accept", "text/html,application/xhtml+xml")
            connection.setRequestProperty("Accept-Language", "*")
            connection.setRequestProperty("User-Agent", USER_AGENT)
            val code = connection.responseCode
            if (code !in 200..299) return null
            val html = connection.inputStream.bufferedReader(Charsets.UTF_8).use { it.readText() }
            HttpPage(html = html, finalUrl = connection.url.toString())
        } catch (_: Exception) {
            null
        } finally {
            connection?.disconnect()
        }
    }

    private fun htmlToVisibleText(html: String): String = Html.fromHtml(
        html,
        Html.FROM_HTML_MODE_LEGACY
    ).toString()

    private fun decodeHtml(value: String): String = Html.fromHtml(
        value,
        Html.FROM_HTML_MODE_LEGACY
    ).toString()

    /** Extract only the song words from a JW.org song article's visible text. */
    private fun extractLyricsFromVisibleText(raw: String, title: String): String? {
        if (raw.isBlank()) return null
        val lines = raw
            .replace("\r", "")
            .split('\n')
            .map { it.trim() }

        val stopAt = lines.indexOfFirst { line ->
            line.equals("Sorry, the media player failed to load.", ignoreCase = true) ||
                line.equals("Download This Video", ignoreCase = true) ||
                line.equals("DOWNLOAD OPTIONS", ignoreCase = true) ||
                line.startsWith("(See also", ignoreCase = true) ||
                line.equals("Previous", ignoreCase = true)
        }.let { if (it >= 0) it else lines.size }
        if (stopAt <= 0) return null

        val numberedVerse = Regex("^(?:[•·]\\s*)?(\\d+)\\.\\s*(?:\\1\\.\\s*)?\\S.*")
        val sectionLine = Regex(
            "^\\((?:(?:PRE-)?CHORUS(?:\\s+\\d+)?|BRIDGE(?:\\s+\\d+)?|VERSE(?:\\s+\\d+)?|INTRO|OUTRO|REFRAIN)\\)$",
            RegexOption.IGNORE_CASE
        )

        var startAt = lines.indexOfFirst { line -> numberedVerse.matches(line) || sectionLine.matches(line) }
        if (startAt < 0 || startAt >= stopAt) return null

        // Localized JW songbook pages can end the lyric body with a
        // parenthesized scripture-reference line. Detect its structure rather
        // than English words such as "See also" so pages such as the verified
        // Sepedi "Bona le ..." form stop before the media/download/footer UI.
        val localizedReferenceStop = (startAt + 1 until stopAt).firstOrNull { idx ->
            val line = lines[idx]
            line.startsWith("(") && line.endsWith(")") &&
                line.any(Char::isDigit) &&
                (line.contains(':') || line.contains(';'))
        }
        val lyricsStopAt = localizedReferenceStop ?: stopAt

        // Reject an accidental numbered navigation/menu line by requiring a
        // second lyric-like line reasonably close to the first candidate.
        val hasContinuation = (startAt + 1 until minOf(stopAt, startAt + 8)).any { idx ->
            val line = lines[idx]
            line.isNotBlank() &&
                !line.equals("Play", true) &&
                !line.equals("Select an Audio Recording", true) &&
                !line.equals("Download", true)
        }
        if (!hasContinuation) return null

        val titleNorm = normalizeTitle(title)
        val body = lines.subList(startAt, lyricsStopAt)
            .dropWhile { it.isBlank() }
            .filterNot { line ->
                line.equals("Lead Sheet", ignoreCase = true) ||
                    line.equals("PLAY", ignoreCase = true) ||
                    line.equals("Select an Audio Recording", ignoreCase = true) ||
                    normalizeTitle(line) == titleNorm
            }
            .map { line ->
                line.replace(Regex("^(?:[•·]\\s*)?(\\d+)\\.\\s+\\1\\.\\s*"), "$1. ")
            }
            .toMutableList()

        while (body.isNotEmpty() && body.first().isBlank()) body.removeAt(0)
        while (body.isNotEmpty() && body.last().isBlank()) body.removeAt(body.lastIndex)

        val meaningful = body.count { line -> line.isNotBlank() && !sectionLine.matches(line) }
        if (meaningful < 2) return null

        return buildString {
            var previousBlank = false
            body.forEach { line ->
                val blank = line.isBlank()
                if (blank && previousBlank) return@forEach
                if (isNotEmpty()) append('\n')
                append(line)
                previousBlank = blank
            }
        }.trim().takeIf { it.isNotBlank() }
    }

    private fun songbookCollectionUrl(locale: String) =
        "https://www.jw.org/finder?srcid=jwlshare&wtlocale=$locale&prefer=lang&pub=sjj"

    private fun originalSongsCollectionUrl(languageCode: String, webLocale: String): String {
        // Prefer the locale-specific collection.  When the mediator does not
        // expose a web locale, finder still carries the exact JW language code
        // and redirects according to JW's own language mapping.
        return if (webLocale.isNotBlank()) {
            "https://www.jw.org/$webLocale/library/music-songs/original-songs/"
        } else {
            "https://www.jw.org/finder?srcid=jwlshare&wtlocale=$languageCode&prefer=lang"
        }
    }

    private fun originalSongCandidateUrl(title: String, webLocale: String): String {
        val slug = slugify(title)
        // Collection lookup below is authoritative; this is only a fast path.
        val locale = webLocale.ifBlank { "en" }
        return "https://www.jw.org/$locale/library/music-songs/original-songs/$slug/"
    }

    private fun slugify(title: String): String {
        val ascii = Normalizer.normalize(title, Normalizer.Form.NFD)
            .replace(Regex("\\p{M}+"), "")
        return ascii
            .replace(Regex("[‘’“”\"'`]+"), "")
            .replace(Regex("[^A-Za-z0-9]+"), "-")
            .trim('-')
            .lowercase()
    }

    private fun isSectionLabelAnyLanguage(text: String): Boolean {
        val t = text.trim()
        if (!t.startsWith("(") || !t.endsWith(")") || t.length > 48) return false
        val inner = t.substring(1, t.length - 1).trim()
        if (inner.isBlank() || inner.any(Char::isDigit)) return false
        return inner.any(Char::isLetter) && inner.none { it == ':' || it == ';' }
    }


    private suspend fun CachedSongLyrics.withBestTiming(item: MediaItem): CachedSongLyrics {
        if (timedLines.isNotEmpty()) return this
        if (item.subtitleUrl.isNotBlank()) {
            val exact = fetchTimedTrack(item.subtitleUrl)
            if (exact.isNotEmpty()) return copy(timedLines = exact)
        }
        return withTiming(item.durationMs)
    }

    private fun fetchTimedTrack(url: String): List<TimedLyricLine> {
        var connection: HttpURLConnection? = null
        return try {
            connection = URL(url).openConnection() as HttpURLConnection
            connection.instanceFollowRedirects = true
            connection.connectTimeout = CONNECT_TIMEOUT_MS
            connection.readTimeout = READ_TIMEOUT_MS
            connection.setRequestProperty("User-Agent", USER_AGENT)
            val code = connection.responseCode
            if (code !in 200..299) return emptyList()
            val raw = connection.inputStream.bufferedReader(Charsets.UTF_8).use { it.readText() }
            parseWebVtt(raw)
        } catch (_: Exception) {
            emptyList()
        } finally {
            connection?.disconnect()
        }
    }

    private fun parseWebVtt(raw: String): List<TimedLyricLine> {
        fun ms(value: String): Long? {
            val parts = value.trim().replace(',', '.').split(':')
            if (parts.size !in 2..3) return null
            return runCatching {
                val seconds = parts.last().toDouble()
                val minutes = parts[parts.size - 2].toLong()
                val hours = if (parts.size == 3) parts[0].toLong() else 0L
                ((hours * 3600 + minutes * 60) * 1000L + seconds * 1000.0).toLong()
            }.getOrNull()
        }
        val lines = raw.replace("\r", "").lines()
        val out = mutableListOf<TimedLyricLine>()
        var i = 0
        while (i < lines.size) {
            val timing = lines[i].trim()
            if (!timing.contains("-->")) { i++; continue }
            val pair = timing.split("-->", limit = 2)
            val start = ms(pair[0])
            val end = ms(pair[1].trim().substringBefore(' '))
            i++
            val text = buildString {
                while (i < lines.size && lines[i].isNotBlank()) {
                    val clean = Html.fromHtml(lines[i].replace(Regex("<[^>]+>"), ""), Html.FROM_HTML_MODE_LEGACY).toString().trim()
                    if (clean.isNotBlank()) { if (isNotEmpty()) append(' '); append(clean) }
                    i++
                }
            }.trim()
            if (start != null && end != null && end > start && text.isNotBlank()) {
                out += TimedLyricLine(text, false, start, end)
            }
        }
        return out
    }

    private fun CachedSongLyrics.withTiming(durationMs: Long): CachedSongLyrics {
        if (timedLines.isNotEmpty() || durationMs <= 0L) return this
        val raw = text.lineSequence().map { it.trim() }.filter { it.isNotEmpty() }.toList()
        if (raw.isEmpty()) return this
        val sung = raw.filterNot(::isSectionLabelAnyLanguage)
        if (sung.isEmpty()) return this
        val introMs = (durationMs * 0.035).toLong().coerceIn(1_000L, 10_000L)
        val outroMs = (durationMs * 0.015).toLong().coerceIn(500L, 5_000L)
        val usableMs = (durationMs - introMs - outroMs).coerceAtLeast(sung.size * 450L)
        fun weight(line: String): Double {
            val words = line.split(Regex("\\s+")).filter { it.isNotBlank() }
            val letters = line.count(Char::isLetter).coerceAtLeast(words.size)
            val punctuation = when {
                line.endsWith("…") -> 6.0
                line.endsWith(".") || line.endsWith("!") || line.endsWith("?") -> 4.0
                line.endsWith(",") || line.endsWith(";") || line.endsWith(":") -> 2.0
                else -> 0.0
            }
            return letters / 4.0 + punctuation + 1.0
        }
        val weights = sung.map(::weight)
        val total = weights.sum().coerceAtLeast(1.0)
        var sungIndex = 0
        var cursor = introMs
        val timed = raw.map { line ->
            if (isSectionLabelAnyLanguage(line)) {
                TimedLyricLine(line, true, cursor, cursor)
            } else {
                val w = weights[sungIndex++]
                val slice = if (sungIndex == sung.size)
                    (durationMs - outroMs - cursor).coerceAtLeast(450L)
                else (usableMs * (w / total)).toLong().coerceAtLeast(450L)
                TimedLyricLine(line, false, cursor, (cursor + slice).coerceAtMost(durationMs)).also { cursor = it.endMs }
            }
        }
        return copy(timedLines = timed)
    }

    private fun extractSongNumber(item: MediaItem): Int? {
        val sources = listOf(item.jwKey, item.category, item.title)
        val explicit = Regex("(?i)(?:sjj|song)[^0-9]{0,12}(\\d{1,3})")
        for (source in sources) {
            val number = explicit.find(source)?.groupValues?.getOrNull(1)?.toIntOrNull()
            if (number != null && number in 1..300) return number
        }
        if (item.jwKey.contains("sjj", true) || item.category.contains("sjj", true)) {
            val number = Regex("(?:^|[_-])(\\d{1,3})(?:[_-]|$)")
                .find(item.jwKey)?.groupValues?.getOrNull(1)?.toIntOrNull()
            if (number != null && number in 1..300) return number
        }
        return leadingSongNumber(item.title)
    }

    private fun leadingSongNumber(raw: String): Int? = Regex(
        "^\\s*(?:song\\s*)?(\\d{1,3})(?:\\s*[.\\-–—:]|\\s+)",
        RegexOption.IGNORE_CASE
    ).find(raw)?.groupValues?.getOrNull(1)?.toIntOrNull()

    private fun removeSongNumberDecorations(raw: String): String = raw
        .replace(Regex("^\\s*(?:song\\s*)?\\d{1,3}(?:\\s*[.\\-–—:]|\\s+)", RegexOption.IGNORE_CASE), "")
        .replace(Regex("\\s*\\(\\s*song\\s*\\d{1,3}\\s*\\)\\s*$", RegexOption.IGNORE_CASE), "")
        .trim()

    private fun cleanMediaTitle(raw: String): String = removeSongNumberDecorations(raw)
        .replace(Regex("\\s*[|–—-]\\s*(?:JW\\.ORG|Original Songs?|Sing Out Joyfully).*$", RegexOption.IGNORE_CASE), "")
        .trim()

    private suspend fun resolveWebLocale(languageCode: String): String {
        if (languageCode.isBlank()) return "en"
        return runCatching {
            com.tebogo.markvault.network.JwMediaApi.languages(languageCode)
                .firstOrNull { it.code.equals(languageCode, ignoreCase = true) }
                ?.locale
                .orEmpty()
        }.getOrDefault("").ifBlank { if (languageCode == "E") "en" else "" }
    }

    private fun inferJwLocale(item: MediaItem): String {
        item.contentLanguage.takeIf { it.isNotBlank() }?.let { return it }
        val candidates = listOf(item.streamUrl, item.localPath, item.jwKey)
        for (candidate in candidates) {
            val token = Regex("(?:^|[_/-])([A-Z]{1,4})(?:[_./-]|$)")
                .find(candidate)?.groupValues?.getOrNull(1)
            if (!token.isNullOrBlank() && token.length in 1..4) return token
        }
        return "E"
    }

    private fun cacheFile(context: Context, item: MediaItem): File {
        // Language is part of identity: the same language-agnostic JW media
        // key can have different lyrics in every language edition.
        val stableKey = item.jwKey.ifBlank { normalizeTitle(item.title) }
        val language = item.contentLanguage.ifBlank { "E" }
        val digest = MessageDigest.getInstance("SHA-256")
            .digest("$language|$stableKey".toByteArray(Charsets.UTF_8))
            .joinToString("") { "%02x".format(it) }
        return File(File(context.filesDir, DIR_NAME), "$digest.json")
    }

    fun normalizeTitle(raw: String): String = Normalizer.normalize(raw, Normalizer.Form.NFD)
        .replace(Regex("\\p{M}+"), "")
        .lowercase()
        .replace(Regex("[\\u2018\\u2019\\u201C\\u201D\\\"'`]+"), "")
        .replace(Regex("[^\\p{L}\\p{N}]+"), " ")
        .trim()
        .replace(Regex("\\s+"), " ")

    private enum class Collection { ORIGINAL_SONGS, SING_OUT_JOYFULLY }
    private data class HttpPage(val html: String, val finalUrl: String)
    private data class PageLink(val url: String, val text: String)
}
