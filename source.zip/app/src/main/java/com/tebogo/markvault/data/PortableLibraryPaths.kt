package com.tebogo.markvault.data

import java.util.Locale

/**
 * Deterministic, storage-provider-independent archive names for SAF siblings.
 * Some DocumentsProviders allow two different document IDs to have the same
 * display name in one folder. A ZIP and a new phone's filesystem cannot.
 * Preserve both documents using unique names only *in the portable copy*.
 * No changes are made to the user's source documents.
 */
internal object PortableLibraryPaths {
    data class Child(val documentId: String, val displayName: String)
    data class Assigned(val child: Child, val archiveName: String)

    fun assign(children: List<Child>): List<Assigned> {
        // A provider can report the same document ID more than once. That is
        // a duplicated directory listing, not another document to back up.
        val distinct = children.sortedWith(
            compareBy<Child>({ it.displayName.lowercase(Locale.ROOT) }, { it.documentId }, { it.displayName })
        ).distinctBy { it.documentId }
        val reserved = distinct.mapTo(HashSet()) { it.displayName.lowercase(Locale.ROOT) }
        val used = HashSet<String>()
        return distinct.map { child ->
            val key = child.displayName.lowercase(Locale.ROOT)
            val name = if (used.add(key)) child.displayName else {
                val dot = child.displayName.lastIndexOf('.')
                val stem = if (dot > 0) child.displayName.substring(0, dot) else child.displayName
                val ext = if (dot > 0) child.displayName.substring(dot) else ""
                var suffix = 2
                var candidate: String
                do {
                    candidate = "$stem (MarkVault copy $suffix)$ext"
                    suffix++
                } while (candidate.lowercase(Locale.ROOT) in reserved ||
                    !used.add(candidate.lowercase(Locale.ROOT)))
                candidate
            }
            Assigned(child, name)
        }
    }
}
