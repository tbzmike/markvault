package com.tebogo.markvault.ui

/** UI state holder for T5 model download status. */
data class T5ModelDownloadState(
    val installed: Boolean = false,
    val progress: Int = 0
)
