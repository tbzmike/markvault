package com.tebogo.markvault.search

import ai.onnxruntime.OnnxTensor
import ai.onnxruntime.OrtEnvironment
import ai.onnxruntime.OrtSession
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.async
import kotlinx.coroutines.awaitAll
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.currentCoroutineContext
import kotlinx.coroutines.ensureActive
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import kotlinx.coroutines.withContext
import java.io.File
import java.nio.LongBuffer
import java.util.concurrent.atomic.AtomicInteger

/** Independent batch-one sessions: the selected model, tokenizer and 256-token cap stay identical. */
class BlueRerankEngine(private val filesDir: File) {
    private data class Pool(
        val key: String,
        val tokenizer: BertTokenizer,
        val sessions: List<OrtSession>
    ) {
        fun close() { sessions.forEach { runCatching { it.close() } } }
    }

    private val requestLock = Mutex()
    private val stateLock = Any()
    private var generation = 0L
    private var pool: Pool? = null
    private var busy = false
    val loadedWorkers: Int get() = synchronized(stateLock) { pool?.sessions?.size ?: 0 }

    /** Never close a native session during a forward pass, including emergency memory release. */
    fun unload() {
        val idle = synchronized(stateLock) {
            generation++
            if (busy) null else pool.also { pool = null }
        }
        idle?.close()
    }

    suspend fun prepare(descriptor: RerankerDescriptor, revision: String, workers: Int): Boolean =
        withContext(Dispatchers.IO) {
            requestLock.withLock { withPool(descriptor, revision, workers) { true } ?: false }
        }

    suspend fun scoreBatch(
        descriptor: RerankerDescriptor,
        revision: String,
        workers: Int,
        query: String,
        docs: List<String>,
        onCompleted: (Int) -> Unit = {}
    ): FloatArray? = withContext(Dispatchers.IO) {
        if (query.isBlank() || docs.isEmpty()) return@withContext null
        requestLock.withLock {
            withPool(descriptor, revision, workers) { selected ->
                val result = FloatArray(docs.size) { Float.NaN }
                val completed = AtomicInteger()
                coroutineScope {
                    selected.sessions.mapIndexed { worker, session ->
                        async(Dispatchers.IO) {
                            // Exactly one coroutine owns each session. No dynamic-quantization padding/batching.
                            for (i in worker until docs.size step selected.sessions.size) {
                                currentCoroutineContext().ensureActive()
                                if (docs[i].isNotBlank()) {
                                    result[i] = runCatching {
                                        val enc = selected.tokenizer.encodePair(query, docs[i], minOf(descriptor.maxSeqLen, 256))
                                        if (enc.inputIds.size < 4) Float.NaN else forward(session, enc)
                                    }.getOrDefault(Float.NaN)
                                }
                                currentCoroutineContext().ensureActive()
                                synchronized(completed) { onCompleted(completed.incrementAndGet()) }
                            }
                        }
                    }.awaitAll()
                }
                result
            }
        }
    }

    private suspend fun <T> withPool(
        descriptor: RerankerDescriptor,
        revision: String,
        workers: Int,
        action: suspend (Pool) -> T
    ): T? {
        currentCoroutineContext().ensureActive()
        val count = workers.coerceIn(1, 4)
        val key = "${descriptor.id}:$revision:$count"
        val epoch = synchronized(stateLock) { generation }
        var selected = synchronized(stateLock) { pool?.takeIf { it.key == key } }
        if (selected == null) {
            val old = synchronized(stateLock) { pool.also { pool = null } }
            old?.close()
            if (!descriptor.isInstalled(filesDir)) return null
            val sessions = ArrayList<OrtSession>(count)
            try {
                val vocab = BertTokenizer.buildVocabMap(descriptor.vocabFileIn(filesDir).readLines())
                if (!BertTokenizer.isVocabUsable(vocab)) return null
                val tokenizer = BertTokenizer(vocab)
                repeat(count) {
                    currentCoroutineContext().ensureActive()
                    OrtSession.SessionOptions().use { opts ->
                        opts.setIntraOpNumThreads(1)
                        opts.addConfigEntry("session.intra_op.allow_spinning", "0")
                        // ALL_OPT and memory patterns remain at the original defaults.
                        sessions += OrtEnvironment.getEnvironment().createSession(descriptor.modelFileIn(filesDir).absolutePath, opts)
                    }
                }
                selected = Pool(key, tokenizer, sessions)
            } catch (t: Throwable) {
                sessions.forEach { runCatching { it.close() } }
                if (t is kotlinx.coroutines.CancellationException) throw t
                return null
            }
        }
        val ready = selected ?: return null
        val accepted = synchronized(stateLock) {
            if (generation != epoch) false else { pool = ready; busy = true; true }
        }
        if (!accepted) { ready.close(); return null }
        try {
            return action(ready)
        } finally {
            val retired = synchronized(stateLock) {
                busy = false
                if (generation != epoch) pool.also { pool = null } else null
            }
            retired?.close()
        }
    }

    private fun forward(session: OrtSession, enc: BertTokenizer.PairEncoding): Float {
        val env = OrtEnvironment.getEnvironment()
        val shape = longArrayOf(1, enc.inputIds.size.toLong())
        return OnnxTensor.createTensor(env, LongBuffer.wrap(LongArray(enc.inputIds.size) { enc.inputIds[it].toLong() }), shape).use { ids ->
            OnnxTensor.createTensor(env, LongBuffer.wrap(LongArray(enc.attentionMask.size) { enc.attentionMask[it].toLong() }), shape).use { mask ->
                OnnxTensor.createTensor(env, LongBuffer.wrap(LongArray(enc.tokenTypeIds.size) { enc.tokenTypeIds[it].toLong() }), shape).use { types ->
                    session.run(mapOf("input_ids" to ids, "attention_mask" to mask, "token_type_ids" to types)).use { results ->
                        @Suppress("UNCHECKED_CAST")
                        val values = results[0].value as? Array<FloatArray> ?: return@use 0f
                        values[0][0]
                    }
                }
            }
        }
    }
}
