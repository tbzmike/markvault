package com.tebogo.markvault.ui

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.Card
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.navigation.NavController
import com.tebogo.markvault.AppViewModel
import java.text.DateFormat
import java.util.Date

/**
 * v5.4.373cc — The five newest completed result sets persisted on internal
 * storage. Opening one restores the exact saved hit order/scores without
 * re-running semantic search or the reranker.
 */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SavedSearchesScreen(vm: AppViewModel, nav: NavController) {
    val sessions by vm.savedSearchSessions.collectAsStateWithLifecycle()
    val uiMode by vm.uiMode.collectAsStateWithLifecycle()
    val workspace = uiMode == "workspace"

    LaunchedEffect(Unit) { vm.refreshSavedSearchSessions() }

    Scaffold(
        topBar = {
            if (!workspace) {
                TopAppBar(
                    title = { Text("Saved search results") },
                    navigationIcon = {
                        IconButton(onClick = { nav.popBackStack() }) { Text("←", fontSize = 24.sp) }
                    }
                )
            }
        },
        bottomBar = {
            if (!workspace) MarkVaultBottomBar(nav = nav, vm = vm)
        }
    ) { padding ->
        if (sessions.isEmpty()) {
            Column(
                Modifier.fillMaxSize().padding(padding).padding(24.dp),
                verticalArrangement = Arrangement.Center
            ) {
                Text("📥 No saved searches yet", fontWeight = FontWeight.Bold, fontSize = 18.sp)
                Text(
                    "Completed submitted searches are saved automatically. Up to five result sets are kept so they survive process death.",
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    modifier = Modifier.padding(top = 8.dp)
                )
            }
        } else {
            LazyColumn(
                Modifier.fillMaxSize().padding(padding).padding(horizontal = 12.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                item {
                    Text(
                        "📥 Saved searches · ${sessions.size}/5",
                        fontSize = 18.sp,
                        fontWeight = FontWeight.Bold,
                        modifier = Modifier.padding(vertical = 12.dp)
                    )
                }
                items(sessions, key = { it.id }) { session ->
                    Card(
                        onClick = {
                            vm.restoreSavedSearchSession(session.id)
                            nav.navigate("search") { launchSingleTop = true }
                        },
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Column(Modifier.fillMaxWidth().padding(14.dp)) {
                            Text(
                                session.query.ifBlank { "Untitled search" },
                                fontWeight = FontWeight.SemiBold,
                                maxLines = 2,
                                overflow = TextOverflow.Ellipsis
                            )
                            val scopeLabel = if (session.dualMode) "Dual" else when (session.scope) {
                                "first20k" -> "1st 20K"
                                "second20k" -> "2nd scope"
                                "all" -> "All notes"
                                else -> session.scope
                            }
                            Text(
                                "${session.hits.size} result${if (session.hits.size == 1) "" else "s"} · " +
                                    formatDuration(session.durationMs) + " · $scopeLabel" +
                                    if (session.rerankEnabled) " · reranked" else "",
                                fontSize = 12.sp,
                                color = MaterialTheme.colorScheme.onSurfaceVariant,
                                modifier = Modifier.padding(top = 5.dp)
                            )
                            Text(
                                DateFormat.getDateTimeInstance(DateFormat.MEDIUM, DateFormat.SHORT)
                                    .format(Date(session.createdAt)),
                                fontSize = 11.sp,
                                color = MaterialTheme.colorScheme.onSurfaceVariant,
                                modifier = Modifier.padding(top = 3.dp)
                            )
                            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.End) {
                                TextButton(onClick = { vm.deleteSavedSearchSession(session.id) }) {
                                    Text("Delete")
                                }
                                Spacer(Modifier.width(4.dp))
                                TextButton(onClick = {
                                    vm.restoreSavedSearchSession(session.id)
                                    nav.navigate("search") { launchSingleTop = true }
                                }) {
                                    Text("Open results")
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

private fun formatDuration(ms: Long): String {
    if (ms <= 0L) return "time unavailable"
    val totalSeconds = ms / 1000.0
    return if (totalSeconds < 60.0) {
        if (totalSeconds < 10.0) "%.1f s".format(totalSeconds) else "%.0f s".format(totalSeconds)
    } else {
        val mins = (ms / 60_000L)
        val secs = (ms % 60_000L) / 1000L
        "${mins}m ${secs}s"
    }
}
