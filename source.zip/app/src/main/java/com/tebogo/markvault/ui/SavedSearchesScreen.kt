package com.tebogo.markvault.ui

import android.content.res.Configuration
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalConfiguration
import androidx.compose.ui.draw.clip
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.navigation.NavController
import com.tebogo.markvault.AppViewModel
import com.tebogo.markvault.search.SavedSearchSession
import com.tebogo.markvault.search.SessionMeta
import java.text.DateFormat
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale

/**
 * v5.5.0 — Saved search results screen with two persistent view modes:
 *   • List view — most recent 50, with dedicated search bar
 *   • Calendar view — month/week/day with color-coded day badges
 *
 * Works in both standard (phone) and workspace (tablet) UI modes.
 */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SavedSearchesScreen(vm: AppViewModel, nav: NavController) {
    val uiMode by vm.uiMode.collectAsStateWithLifecycle()
    val workspace = uiMode == "workspace"
    val isLandscape = LocalConfiguration.current.orientation == Configuration.ORIENTATION_LANDSCAPE
    val wideSideLayout = workspace && isLandscape
    val viewMode by vm.savedSearchViewMode.collectAsStateWithLifecycle()
    val allMeta by vm.savedSearchMeta.collectAsStateWithLifecycle()
    val allSessions by vm.allSavedSessions.collectAsStateWithLifecycle()

    var searchQuery by remember { mutableStateOf("") }

    LaunchedEffect(Unit) {
        vm.refreshSavedSearchMeta()
        vm.refreshAllSavedSessions()
    }

    Scaffold(
        topBar = {
            if (!workspace) {
                TopAppBar(
                    title = { Text("📥 Saved searches · ${allMeta.size}") },
                    navigationIcon = {
                        IconButton(onClick = { nav.popBackStack() }) { Text("←", fontSize = 24.sp) }
                    },
                    actions = {
                        // View mode toggle chips
                        FilterChip(
                            selected = viewMode == "list",
                            onClick = { vm.setSavedSearchViewMode("list") },
                            label = { Text("📋", fontSize = 14.sp) }
                        )
                        Spacer(Modifier.width(4.dp))
                        FilterChip(
                            selected = viewMode == "calendar",
                            onClick = { vm.setSavedSearchViewMode("calendar") },
                            label = { Text("📅", fontSize = 14.sp) }
                        )
                    }
                )
            }
        },
        bottomBar = {
            if (!workspace) MarkVaultBottomBar(nav = nav, vm = vm)
        }
    ) { padding ->
        Column(
            Modifier
                .fillMaxSize()
                .padding(padding)
        ) {
            // Workspace mode: inline header with toggle
            if (workspace) {
                Row(
                    Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 16.dp, vertical = 8.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        "📥 Saved searches · ${allMeta.size}",
                        fontSize = 18.sp,
                        fontWeight = FontWeight.Bold,
                        modifier = Modifier.weight(1f)
                    )
                    FilterChip(
                        selected = viewMode == "list",
                        onClick = { vm.setSavedSearchViewMode("list") },
                        label = { Text("📋 List", fontSize = 13.sp) }
                    )
                    Spacer(Modifier.width(6.dp))
                    FilterChip(
                        selected = viewMode == "calendar",
                        onClick = { vm.setSavedSearchViewMode("calendar") },
                        label = { Text("📅 Calendar", fontSize = 13.sp) }
                    )
                }
            }

            // Dedicated search bar
            OutlinedTextField(
                value = searchQuery,
                onValueChange = { searchQuery = it },
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 12.dp, vertical = 4.dp),
                placeholder = { Text("Search saved results…") },
                singleLine = true,
                leadingIcon = { Icon(Icons.Default.Search, contentDescription = null) },
                trailingIcon = {
                    if (searchQuery.isNotEmpty()) {
                        IconButton(onClick = { searchQuery = "" }) {
                            Icon(Icons.Default.Close, contentDescription = "Clear")
                        }
                    }
                }
            )

            if (allMeta.isEmpty()) {
                Column(
                    Modifier
                        .fillMaxSize()
                        .padding(24.dp),
                    verticalArrangement = Arrangement.Center
                ) {
                    Text("📥 No saved searches yet", fontWeight = FontWeight.Bold, fontSize = 18.sp)
                    Text(
                        "Completed submitted searches are saved automatically and kept for up to 6 months.",
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        modifier = Modifier.padding(top = 8.dp)
                    )
                }
            } else if (viewMode == "calendar") {
                CalendarView(
                    allMeta = allMeta,
                    searchQuery = searchQuery,
                    vm = vm,
                    nav = nav,
                    wideSideLayout = wideSideLayout
                )
            } else {
                ListView(
                    allSessions = allSessions,
                    searchQuery = searchQuery,
                    vm = vm,
                    nav = nav
                )
            }
        }
    }
}

// ── List View ───────────────────────────────────────────────────────────

@Composable
private fun ListView(
    allSessions: List<SavedSearchSession>,
    searchQuery: String,
    vm: AppViewModel,
    nav: NavController
) {
    val filtered = remember(allSessions, searchQuery) {
        val q = searchQuery.trim().lowercase()
        val base = if (q.isEmpty()) allSessions else allSessions.filter {
            it.query.lowercase().contains(q)
        }
        base.take(50)
    }

    if (filtered.isEmpty()) {
        Column(Modifier.padding(24.dp)) {
            Text(
                if (searchQuery.isNotBlank()) "No matches for \"$searchQuery\""
                else "No saved searches",
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
        }
    } else {
        LazyColumn(
            Modifier
                .fillMaxSize()
                .padding(horizontal = 12.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            item {
                Text(
                    if (filtered.size < allSessions.size)
                        "Showing ${filtered.size} of ${allSessions.size}"
                    else if (allSessions.size <= 50)
                        "${allSessions.size} saved searches"
                    else
                        "Showing 50 of ${allSessions.size}",
                    fontSize = 12.sp,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    modifier = Modifier.padding(vertical = 6.dp)
                )
            }
            items(filtered, key = { it.id }) { session ->
                SessionCard(session = session, vm = vm, nav = nav)
            }
            item { Spacer(Modifier.height(16.dp)) }
        }
    }
}

// ── Calendar View ───────────────────────────────────────────────────────

@Composable
private fun CalendarView(
    allMeta: List<SessionMeta>,
    searchQuery: String,
    vm: AppViewModel,
    nav: NavController,
    wideSideLayout: Boolean
) {
    var calendarMode by remember { mutableStateOf("month") } // month, week, day
    var currentCal by remember { mutableStateOf(Calendar.getInstance()) }
    var selectedDaySessions by remember { mutableStateOf<List<SavedSearchSession>>(emptyList()) }
    var selectedDayLabel by remember { mutableStateOf("") }
    var calendarExpanded by remember { mutableStateOf(true) }

    // Filter meta by search query
    val filteredMeta = remember(allMeta, searchQuery) {
        val q = searchQuery.trim().lowercase()
        if (q.isEmpty()) allMeta else allMeta.filter { it.query.lowercase().contains(q) }
    }

    // Group by day (yyyy-MM-dd) for badge counting
    val dayFormat = remember { SimpleDateFormat("yyyy-MM-dd", Locale.US) }
    val countByDay = remember(filteredMeta) {
        filteredMeta.groupBy { dayFormat.format(Date(it.createdAt)) }
            .mapValues { it.value.size }
    }

    // Helper: trigger day load
    val onDaySelected: (Int, Int, Int) -> Unit = { year, month, day ->
        val c = Calendar.getInstance().apply { set(year, month, day, 0, 0, 0); set(Calendar.MILLISECOND, 0) }
        val start = c.timeInMillis
        c.add(Calendar.DAY_OF_YEAR, 1)
        val end = c.timeInMillis
        selectedDayLabel = SimpleDateFormat("d MMMM yyyy", Locale.getDefault()).format(Date(start))
        vm.loadSessionsForDay(start, end) { selectedDaySessions = it }
    }

    if (wideSideLayout) {
        // ── Landscape workspace: compact calendar left, results right ─
        Row(Modifier.fillMaxSize()) {
            // Left pane — compact calendar
            Column(
                Modifier
                    .width(280.dp)
                    .fillMaxHeight()
                    .padding(start = 8.dp, end = 4.dp)
            ) {
                CalendarControls(
                    calendarMode = calendarMode,
                    onModeChange = { calendarMode = it },
                    currentCal = currentCal,
                    onCalChange = { currentCal = it },
                    compact = true
                )
                CalendarBody(
                    calendarMode = calendarMode,
                    currentCal = currentCal,
                    countByDay = countByDay,
                    dayFormat = dayFormat,
                    vm = vm,
                    onDaySelected = onDaySelected,
                    compact = true
                )
            }

            // Right pane — selected day results
            Column(
                Modifier
                    .weight(1f)
                    .fillMaxHeight()
                    .padding(start = 4.dp, end = 8.dp)
            ) {
                if (selectedDaySessions.isNotEmpty()) {
                    Text(
                        "📅 $selectedDayLabel · ${selectedDaySessions.size} result${if (selectedDaySessions.size != 1) "s" else ""}",
                        fontWeight = FontWeight.Bold,
                        fontSize = 14.sp,
                        modifier = Modifier.padding(vertical = 6.dp)
                    )
                    LazyColumn(
                        Modifier.fillMaxSize(),
                        verticalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        items(selectedDaySessions, key = { it.id }) { session ->
                            SessionCard(session = session, vm = vm, nav = nav)
                        }
                        item { Spacer(Modifier.height(16.dp)) }
                    }
                } else {
                    Column(
                        Modifier.fillMaxSize().padding(24.dp),
                        verticalArrangement = Arrangement.Center,
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Text("📅", fontSize = 32.sp)
                        Spacer(Modifier.height(8.dp))
                        Text(
                            "Tap a day on the calendar to see its saved searches",
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                            textAlign = TextAlign.Center
                        )
                    }
                }
            }
        }
    } else {
        // ── Phone / portrait workspace: stacked with collapsible calendar
        Column(Modifier.fillMaxSize()) {
            // Collapsible calendar header
            Row(
                Modifier
                    .fillMaxWidth()
                    .clickable { calendarExpanded = !calendarExpanded }
                    .padding(horizontal = 12.dp, vertical = 8.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    if (calendarExpanded) "▼ Calendar" else "▶ Calendar",
                    fontWeight = FontWeight.Bold,
                    fontSize = 14.sp,
                    modifier = Modifier.weight(1f)
                )
                if (selectedDayLabel.isNotBlank()) {
                    Text(
                        selectedDayLabel,
                        fontSize = 12.sp,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }

            if (calendarExpanded) {
                CalendarControls(
                    calendarMode = calendarMode,
                    onModeChange = { calendarMode = it },
                    currentCal = currentCal,
                    onCalChange = { currentCal = it },
                    compact = false
                )
                CalendarBody(
                    calendarMode = calendarMode,
                    currentCal = currentCal,
                    countByDay = countByDay,
                    dayFormat = dayFormat,
                    vm = vm,
                    onDaySelected = onDaySelected,
                    compact = false
                )
            }

            // Selected day sessions
            if (selectedDaySessions.isNotEmpty()) {
                Text(
                    selectedDayLabel,
                    fontWeight = FontWeight.Bold,
                    fontSize = 14.sp,
                    modifier = Modifier.padding(horizontal = 16.dp, vertical = 6.dp)
                )
                LazyColumn(
                    Modifier
                        .fillMaxSize()
                        .padding(horizontal = 12.dp),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    items(selectedDaySessions, key = { it.id }) { session ->
                        SessionCard(session = session, vm = vm, nav = nav)
                    }
                    item { Spacer(Modifier.height(16.dp)) }
                }
            } else if (calendarMode == "day") {
                Column(Modifier.padding(24.dp)) {
                    Text(
                        "No saved searches on this day",
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }
        }
    }
}

// ── Calendar Controls (chips + nav) ─────────────────────────────────────

@Composable
private fun CalendarControls(
    calendarMode: String,
    onModeChange: (String) -> Unit,
    currentCal: Calendar,
    onCalChange: (Calendar) -> Unit,
    compact: Boolean
) {
    // Mode chips
    Row(
        Modifier
            .fillMaxWidth()
            .padding(horizontal = if (compact) 4.dp else 12.dp, vertical = 4.dp),
        horizontalArrangement = Arrangement.spacedBy(4.dp)
    ) {
        listOf("month" to "Month", "week" to "Week", "day" to "Day").forEach { (key, label) ->
            FilterChip(
                selected = calendarMode == key,
                onClick = { onModeChange(key) },
                label = { Text(label, fontSize = if (compact) 12.sp else 13.sp) }
            )
        }
    }

    // Navigation row
    Row(
        Modifier
            .fillMaxWidth()
            .padding(horizontal = if (compact) 4.dp else 12.dp, vertical = 2.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        TextButton(onClick = {
            onCalChange((currentCal.clone() as Calendar).apply {
                when (calendarMode) {
                    "month" -> add(Calendar.MONTH, -1)
                    "week" -> add(Calendar.WEEK_OF_YEAR, -1)
                    "day" -> add(Calendar.DAY_OF_YEAR, -1)
                }
            })
        }) { Text("◀", fontSize = if (compact) 14.sp else 16.sp) }

        Text(
            when (calendarMode) {
                "month" -> SimpleDateFormat("MMMM yyyy", Locale.getDefault()).format(currentCal.time)
                "week" -> {
                    val wk = (currentCal.clone() as Calendar).apply { set(Calendar.DAY_OF_WEEK, firstDayOfWeek) }
                    val wkEnd = (wk.clone() as Calendar).apply { add(Calendar.DAY_OF_YEAR, 6) }
                    "${SimpleDateFormat("d MMM", Locale.getDefault()).format(wk.time)} – ${SimpleDateFormat("d MMM", Locale.getDefault()).format(wkEnd.time)}"
                }
                else -> SimpleDateFormat("EEE, d MMM yyyy", Locale.getDefault()).format(currentCal.time)
            },
            fontWeight = FontWeight.Bold,
            fontSize = if (compact) 13.sp else 15.sp,
            modifier = Modifier.weight(1f),
            textAlign = TextAlign.Center
        )

        TextButton(onClick = {
            onCalChange((currentCal.clone() as Calendar).apply {
                when (calendarMode) {
                    "month" -> add(Calendar.MONTH, 1)
                    "week" -> add(Calendar.WEEK_OF_YEAR, 1)
                    "day" -> add(Calendar.DAY_OF_YEAR, 1)
                }
            })
        }) { Text("▶", fontSize = if (compact) 14.sp else 16.sp) }
    }
}

// ── Calendar Body (grid/strip/day) ──────────────────────────────────────

@Composable
private fun CalendarBody(
    calendarMode: String,
    currentCal: Calendar,
    countByDay: Map<String, Int>,
    dayFormat: SimpleDateFormat,
    vm: AppViewModel,
    onDaySelected: (Int, Int, Int) -> Unit,
    compact: Boolean
) {
    when (calendarMode) {
        "month" -> MonthGrid(
            cal = currentCal,
            countByDay = countByDay,
            dayFormat = dayFormat,
            onDayClick = onDaySelected,
            compact = compact
        )
        "week" -> WeekStrip(
            cal = currentCal,
            countByDay = countByDay,
            dayFormat = dayFormat,
            onDayClick = onDaySelected,
            compact = compact
        )
        "day" -> {
            val c = currentCal.clone() as Calendar
            c.set(Calendar.HOUR_OF_DAY, 0); c.set(Calendar.MINUTE, 0); c.set(Calendar.SECOND, 0); c.set(Calendar.MILLISECOND, 0)
            val start = c.timeInMillis
            c.add(Calendar.DAY_OF_YEAR, 1)
            val end = c.timeInMillis
            val key = dayFormat.format(Date(start))
            val count = countByDay[key] ?: 0
            LaunchedEffect(start) {
                onDaySelected(
                    currentCal.get(Calendar.YEAR),
                    currentCal.get(Calendar.MONTH),
                    currentCal.get(Calendar.DAY_OF_MONTH)
                )
            }
            Text(
                "$count saved search${if (count != 1) "es" else ""} on this day",
                fontSize = if (compact) 12.sp else 13.sp,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                modifier = Modifier.padding(horizontal = if (compact) 8.dp else 16.dp, vertical = 4.dp)
            )
        }
    }
}

// ── Month Grid ──────────────────────────────────────────────────────────

@Composable
private fun MonthGrid(
    cal: Calendar,
    countByDay: Map<String, Int>,
    dayFormat: SimpleDateFormat,
    onDayClick: (Int, Int, Int) -> Unit,
    compact: Boolean = false
) {
    val year = cal.get(Calendar.YEAR)
    val month = cal.get(Calendar.MONTH)
    val today = Calendar.getInstance()

    val firstOfMonth = Calendar.getInstance().apply { set(year, month, 1) }
    val daysInMonth = firstOfMonth.getActualMaximum(Calendar.DAY_OF_MONTH)
    val startDow = firstOfMonth.get(Calendar.DAY_OF_WEEK) // Sunday=1

    val hPad = if (compact) 4.dp else 8.dp
    val cellHeight = if (compact) 36.dp else 44.dp
    val dayFontSize = if (compact) 12.sp else 14.sp
    val badgeSize = if (compact) 14.dp else 18.dp
    val badgeFontSize = if (compact) 8.sp else 10.sp

    // Day-of-week headers
    Row(
        Modifier
            .fillMaxWidth()
            .padding(horizontal = hPad),
        horizontalArrangement = Arrangement.SpaceEvenly
    ) {
        listOf("S", "M", "T", "W", "T", "F", "S").forEach { d ->
            Text(
                d, fontSize = if (compact) 10.sp else 12.sp,
                fontWeight = FontWeight.Bold,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                modifier = Modifier.weight(1f),
                textAlign = TextAlign.Center
            )
        }
    }

    // Day cells
    val cells = mutableListOf<Int?>()
    for (i in 1 until startDow) cells.add(null)
    for (d in 1..daysInMonth) cells.add(d)
    while (cells.size % 7 != 0) cells.add(null)

    cells.chunked(7).forEach { week ->
        Row(
            Modifier
                .fillMaxWidth()
                .padding(horizontal = hPad, vertical = 2.dp),
            horizontalArrangement = Arrangement.SpaceEvenly
        ) {
            week.forEach { day ->
                Box(
                    Modifier
                        .weight(1f)
                        .height(cellHeight)
                        .clip(RoundedCornerShape(6.dp))
                        .then(
                            if (day != null) Modifier.clickable { onDayClick(year, month, day) }
                            else Modifier
                        ),
                    contentAlignment = Alignment.Center
                ) {
                    if (day != null) {
                        val key = dayFormat.format(
                            Calendar.getInstance().apply { set(year, month, day) }.time
                        )
                        val count = countByDay[key] ?: 0
                        val isToday = today.get(Calendar.YEAR) == year &&
                            today.get(Calendar.MONTH) == month &&
                            today.get(Calendar.DAY_OF_MONTH) == day

                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                            Text(
                                "$day",
                                fontSize = dayFontSize,
                                fontWeight = if (isToday) FontWeight.Bold else FontWeight.Normal,
                                color = if (isToday) MaterialTheme.colorScheme.primary
                                        else MaterialTheme.colorScheme.onSurface
                            )
                            if (count > 0) {
                                Box(
                                    Modifier
                                        .size(badgeSize)
                                        .clip(CircleShape)
                                        .background(MaterialTheme.colorScheme.primary),
                                    contentAlignment = Alignment.Center
                                ) {
                                    Text(
                                        "$count",
                                        fontSize = badgeFontSize,
                                        fontWeight = FontWeight.Bold,
                                        color = MaterialTheme.colorScheme.onPrimary
                                    )
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

// ── Week Strip ──────────────────────────────────────────────────────────

@Composable
private fun WeekStrip(
    cal: Calendar,
    countByDay: Map<String, Int>,
    dayFormat: SimpleDateFormat,
    onDayClick: (Int, Int, Int) -> Unit,
    compact: Boolean = false
) {
    val today = Calendar.getInstance()
    val weekStart = (cal.clone() as Calendar).apply { set(Calendar.DAY_OF_WEEK, firstDayOfWeek) }

    Row(
        Modifier
            .fillMaxWidth()
            .padding(horizontal = if (compact) 4.dp else 8.dp, vertical = 4.dp),
        horizontalArrangement = Arrangement.SpaceEvenly
    ) {
        for (i in 0..6) {
            val dayCal = (weekStart.clone() as Calendar).apply { add(Calendar.DAY_OF_YEAR, i) }
            val year = dayCal.get(Calendar.YEAR)
            val month = dayCal.get(Calendar.MONTH)
            val day = dayCal.get(Calendar.DAY_OF_MONTH)
            val key = dayFormat.format(dayCal.time)
            val count = countByDay[key] ?: 0
            val isToday = today.get(Calendar.YEAR) == year &&
                today.get(Calendar.MONTH) == month &&
                today.get(Calendar.DAY_OF_MONTH) == day
            val dowLabel = SimpleDateFormat("EEE", Locale.getDefault()).format(dayCal.time)

            Column(
                Modifier
                    .weight(1f)
                    .clip(RoundedCornerShape(8.dp))
                    .clickable { onDayClick(year, month, day) }
                    .padding(vertical = 8.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Text(
                    dowLabel, fontSize = 11.sp,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
                Text(
                    "$day", fontSize = 16.sp,
                    fontWeight = if (isToday) FontWeight.Bold else FontWeight.Normal,
                    color = if (isToday) MaterialTheme.colorScheme.primary
                            else MaterialTheme.colorScheme.onSurface
                )
                if (count > 0) {
                    Box(
                        Modifier
                            .size(20.dp)
                            .clip(CircleShape)
                            .background(MaterialTheme.colorScheme.primary),
                        contentAlignment = Alignment.Center
                    ) {
                        Text(
                            "$count", fontSize = 10.sp,
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.onPrimary
                        )
                    }
                }
            }
        }
    }
}

// ── Session Card (shared by both views) ─────────────────────────────────

@Composable
private fun SessionCard(
    session: SavedSearchSession,
    vm: AppViewModel,
    nav: NavController
) {
    // v5.5.15 — Only searches where Question Awareness actually participated
    // in answering a detected question receive the visual question card. A
    // merely-enabled toggle is intentionally not enough to avoid misleading
    // users about how the saved result set was produced.
    val questionAnswered = session.questionAwarenessEnabled && session.queryDetectedAsQuestion && session.questionAwarenessUsed && session.questionAwareQueries.isNotEmpty()
    val detailColor = if (questionAnswered) {
        MaterialTheme.colorScheme.onTertiaryContainer.copy(alpha = 0.78f)
    } else {
        MaterialTheme.colorScheme.onSurfaceVariant
    }
    val accentColor = if (questionAnswered) {
        MaterialTheme.colorScheme.onTertiaryContainer
    } else {
        MaterialTheme.colorScheme.primary
    }

    Card(
        onClick = {
            vm.restoreSavedSearchSession(session.id)
            nav.navigate("search") { launchSingleTop = true }
        },
        modifier = Modifier.fillMaxWidth(),
        colors = if (questionAnswered) {
            CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.tertiaryContainer)
        } else {
            CardDefaults.cardColors()
        }
    ) {
        Box(Modifier.fillMaxWidth()) {
            if (questionAnswered) {
                Text(
                    "?",
                    modifier = Modifier
                        .align(Alignment.CenterEnd)
                        .padding(end = 18.dp),
                    fontSize = 96.sp,
                    lineHeight = 96.sp,
                    fontWeight = FontWeight.Black,
                    color = MaterialTheme.colorScheme.onTertiaryContainer.copy(alpha = 0.10f)
                )
            }
            Column(Modifier.fillMaxWidth().padding(14.dp)) {
            Text(
                session.query.ifBlank { "Untitled search" },
                fontWeight = FontWeight.SemiBold,
                color = if (questionAnswered) MaterialTheme.colorScheme.onTertiaryContainer else MaterialTheme.colorScheme.onSurface,
                maxLines = 2,
                overflow = TextOverflow.Ellipsis
            )
            val scopeLabel = savedSessionScopeLabel(session)
            Text(
                "${session.hits.size} result${if (session.hits.size == 1) "" else "s"} · " +
                    formatDuration(session.durationMs) + " · ${session.searchType}",
                fontSize = 12.sp,
                color = detailColor,
                modifier = Modifier.padding(top = 5.dp)
            )
            if (session.metadataVersion >= 2 && session.stopped) {
                Text(
                    savedSessionStoppedLabel(session),
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Bold,
                    color = accentColor,
                    modifier = Modifier.padding(top = 3.dp)
                )
            }
            Text(
                "📚 Scope: $scopeLabel",
                fontSize = 11.sp,
                color = detailColor,
                modifier = Modifier.padding(top = 3.dp)
            )
            if (session.metadataVersion >= 2) {
                Text(
                    "🧬 Semantic: ${if (session.semanticEnabled) "on" else "off"} · " +
                        "🎯 Accurate search: ${if (session.accurateSearchUsed) "used" else "not used"}",
                    fontSize = 11.sp,
                    color = detailColor,
                    modifier = Modifier.padding(top = 3.dp)
                )
                Text(
                    savedSessionAnnLabel(session),
                    fontSize = 11.sp,
                    color = detailColor,
                    modifier = Modifier.padding(top = 3.dp)
                )
                Text(
                    savedSessionRerankerLabel(session),
                    fontSize = 11.sp,
                    color = detailColor,
                    modifier = Modifier.padding(top = 3.dp)
                )
                if (session.metadataVersion >= 3) {
                    Text(
                        savedSessionQuestionAwarenessLabel(session),
                        fontSize = 11.sp,
                        color = detailColor,
                        modifier = Modifier.padding(top = 3.dp)
                    )
                    if (session.questionAwarenessEnabled && session.queryDetectedAsQuestion &&
                        session.questionAwarenessUsed && session.questionAwareQueries.isNotEmpty()) {
                        Text(
                            "Answer-oriented queries: ${session.questionAwareQueries.joinToString(" · ")}",
                            fontSize = 11.sp,
                            color = detailColor,
                            maxLines = 3,
                            overflow = TextOverflow.Ellipsis,
                            modifier = Modifier.padding(top = 3.dp)
                        )
                    }
                }
            } else {
                Text(
                    "ℹ Detailed execution metadata unavailable (saved before 5.5.14)",
                    fontSize = 10.sp,
                    color = detailColor,
                    modifier = Modifier.padding(top = 3.dp)
                )
            }
            Text(
                if (session.llmUsed)
                    "🧠 LLM: used${if (session.llmEngine.isNotBlank()) " · ${session.llmEngine}" else ""}"
                else "🧠 LLM: not used",
                fontSize = 11.sp,
                color = accentColor,
                modifier = Modifier.padding(top = 3.dp)
            )
            if (session.expansions.isNotEmpty()) {
                Text(
                    "Expansions: ${session.expansions.joinToString(" · ")}",
                    fontSize = 11.sp,
                    color = detailColor,
                    maxLines = 3,
                    overflow = TextOverflow.Ellipsis,
                    modifier = Modifier.padding(top = 3.dp)
                )
            }
            Text(
                DateFormat.getDateTimeInstance(DateFormat.MEDIUM, DateFormat.SHORT)
                    .format(Date(session.createdAt)),
                fontSize = 11.sp,
                color = detailColor,
                modifier = Modifier.padding(top = 3.dp)
            )
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.End) {
                TextButton(onClick = {
                    vm.deleteSavedSearchSession(session.id)
                    vm.refreshSavedSearchMeta()
                    vm.refreshAllSavedSessions()
                }) { Text("Delete") }
                Spacer(Modifier.width(4.dp))
                TextButton(onClick = {
                    vm.restoreSavedSearchSession(session.id)
                    nav.navigate("search") { launchSingleTop = true }
                }) { Text("Open results") }
            }
            }
        }
    }
}

private fun savedSessionNoteCount(count: Int): String =
    if (count <= 0) "size unavailable" else java.text.NumberFormat.getIntegerInstance().format(count)

private fun savedSessionCompactCount(count: Int): String {
    if (count <= 0) return "scope"
    if (count < 1_000) return count.toString()
    return "${((count + 500) / 1_000).coerceAtLeast(1)}K"
}

private fun savedSessionScopeLabel(session: SavedSearchSession): String {
    if (session.metadataVersion < 2) {
        return if (session.dualMode) "Dual mode" else when (session.scope) {
            "first20k" -> "1st 20K"
            "second20k" -> "2nd scope"
            "all" -> "All notes"
            else -> session.scope
        }
    }
    val scopeCount = savedSessionNoteCount(session.scopeNoteCount)
    return if (session.dualMode) {
        "Dual mode · all ${savedSessionNoteCount(session.totalNoteCount)} notes"
    } else when (session.scope) {
        "first20k" -> "1st 20K · $scopeCount notes"
        "second20k" -> "2nd ${savedSessionCompactCount(session.scopeNoteCount)} · $scopeCount notes"
        "all" -> "All notes · ${savedSessionNoteCount(session.totalNoteCount)} notes"
        else -> "${session.scope.ifBlank { "All notes" }} · $scopeCount notes"
    }
}

private fun savedSessionStoppedLabel(session: SavedSearchSession): String {
    val pct = session.stoppedAtPercent?.let { "$it%" } ?: "unknown progress"
    val work = if (session.stoppedAtTotal > 0) {
        " (${java.text.NumberFormat.getIntegerInstance().format(session.stoppedAtDone)} / " +
            "${java.text.NumberFormat.getIntegerInstance().format(session.stoppedAtTotal)})"
    } else ""
    val finalization = if (session.rerankApplied) "found results reranked + saved" else "found results finalized + saved"
    return "⏹ Stopped at $pct$work · $finalization"
}

private fun savedSessionAnnLabel(session: SavedSearchSession): String = when {
    session.annUsed -> "⚡ Quick ANN: used"
    session.annEnabled -> "⚡ Quick ANN: enabled · not used (exact/fallback path)"
    else -> "⚡ Quick ANN: off"
}

private fun savedSessionRerankerLabel(session: SavedSearchSession): String {
    val engine = session.rerankerEngine.takeIf { it.isNotBlank() }?.let { " · $it" }.orEmpty()
    return when {
        session.rerankApplied -> "↕ Reranker: applied$engine"
        session.rerankEnabled -> "↕ Reranker: enabled · not applied$engine"
        else -> "↕ Reranker: off"
    }
}

private fun savedSessionQuestionAwarenessLabel(session: SavedSearchSession): String {
    val detected = if (session.queryDetectedAsQuestion) "question: yes" else "question: no"
    val type = session.questionType.takeIf { it.isNotBlank() }?.let { " · type: $it" }.orEmpty()
    val actuallyUsed = session.questionAwarenessEnabled &&
        session.queryDetectedAsQuestion && session.questionAwarenessUsed &&
        session.questionAwareQueries.isNotEmpty()
    return when {
        actuallyUsed -> "❓ Question Awareness: used · $detected$type"
        session.questionAwarenessEnabled -> "❓ Question Awareness: on · not used · $detected$type"
        else -> "❓ Question Awareness: off · $detected$type"
    }
}

private fun formatDuration(ms: Long): String {
    if (ms <= 0L) return "time unavailable"
    val totalSeconds = ms / 1000.0
    return if (totalSeconds < 60.0) {
        if (totalSeconds < 10.0) "%.1f s".format(totalSeconds) else "%.0f s".format(totalSeconds)
    } else {
        val mins = (ms / 60_000L)
        val secs = (ms % 60_000L) / 1000L
        "${mins}m ${secs}s"
    }
}
