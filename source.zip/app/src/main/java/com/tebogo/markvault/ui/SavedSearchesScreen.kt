package com.tebogo.markvault.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.Card
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.navigation.NavController
import com.tebogo.markvault.AppViewModel
import com.tebogo.markvault.search.SavedSearchSession
import com.tebogo.markvault.search.SessionMeta
import java.text.DateFormat
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale

/**
 * v5.5.0 — Saved search results screen with two persistent view modes:
 *   • List view — most recent 50, with dedicated search bar
 *   • Calendar view — month/week/day with color-coded day badges
 *
 * Works in both standard (phone) and workspace (tablet) UI modes.
 */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SavedSearchesScreen(vm: AppViewModel, nav: NavController) {
    val uiMode by vm.uiMode.collectAsStateWithLifecycle()
    val workspace = uiMode == "workspace"
    val viewMode by vm.savedSearchViewMode.collectAsStateWithLifecycle()
    val allMeta by vm.savedSearchMeta.collectAsStateWithLifecycle()
    val allSessions by vm.allSavedSessions.collectAsStateWithLifecycle()

    var searchQuery by remember { mutableStateOf("") }

    LaunchedEffect(Unit) {
        vm.refreshSavedSearchMeta()
        vm.refreshAllSavedSessions()
    }

    Scaffold(
        topBar = {
            if (!workspace) {
                TopAppBar(
                    title = { Text("📥 Saved searches · ${allMeta.size}") },
                    navigationIcon = {
                        IconButton(onClick = { nav.popBackStack() }) { Text("←", fontSize = 24.sp) }
                    },
                    actions = {
                        // View mode toggle chips
                        FilterChip(
                            selected = viewMode == "list",
                            onClick = { vm.setSavedSearchViewMode("list") },
                            label = { Text("📋", fontSize = 14.sp) }
                        )
                        Spacer(Modifier.width(4.dp))
                        FilterChip(
                            selected = viewMode == "calendar",
                            onClick = { vm.setSavedSearchViewMode("calendar") },
                            label = { Text("📅", fontSize = 14.sp) }
                        )
                    }
                )
            }
        },
        bottomBar = {
            if (!workspace) MarkVaultBottomBar(nav = nav, vm = vm)
        }
    ) { padding ->
        Column(
            Modifier
                .fillMaxSize()
                .padding(padding)
        ) {
            // Workspace mode: inline header with toggle
            if (workspace) {
                Row(
                    Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 16.dp, vertical = 8.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        "📥 Saved searches · ${allMeta.size}",
                        fontSize = 18.sp,
                        fontWeight = FontWeight.Bold,
                        modifier = Modifier.weight(1f)
                    )
                    FilterChip(
                        selected = viewMode == "list",
                        onClick = { vm.setSavedSearchViewMode("list") },
                        label = { Text("📋 List", fontSize = 13.sp) }
                    )
                    Spacer(Modifier.width(6.dp))
                    FilterChip(
                        selected = viewMode == "calendar",
                        onClick = { vm.setSavedSearchViewMode("calendar") },
                        label = { Text("📅 Calendar", fontSize = 13.sp) }
                    )
                }
            }

            // Dedicated search bar
            OutlinedTextField(
                value = searchQuery,
                onValueChange = { searchQuery = it },
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 12.dp, vertical = 4.dp),
                placeholder = { Text("Search saved results…") },
                singleLine = true,
                leadingIcon = { Icon(Icons.Default.Search, contentDescription = null) },
                trailingIcon = {
                    if (searchQuery.isNotEmpty()) {
                        IconButton(onClick = { searchQuery = "" }) {
                            Icon(Icons.Default.Close, contentDescription = "Clear")
                        }
                    }
                }
            )

            if (allMeta.isEmpty()) {
                Column(
                    Modifier
                        .fillMaxSize()
                        .padding(24.dp),
                    verticalArrangement = Arrangement.Center
                ) {
                    Text("📥 No saved searches yet", fontWeight = FontWeight.Bold, fontSize = 18.sp)
                    Text(
                        "Completed submitted searches are saved automatically and kept for up to 6 months.",
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        modifier = Modifier.padding(top = 8.dp)
                    )
                }
            } else if (viewMode == "calendar") {
                CalendarView(
                    allMeta = allMeta,
                    searchQuery = searchQuery,
                    vm = vm,
                    nav = nav,
                    workspace = workspace
                )
            } else {
                ListView(
                    allSessions = allSessions,
                    searchQuery = searchQuery,
                    vm = vm,
                    nav = nav
                )
            }
        }
    }
}

// ── List View ───────────────────────────────────────────────────────────

@Composable
private fun ListView(
    allSessions: List<SavedSearchSession>,
    searchQuery: String,
    vm: AppViewModel,
    nav: NavController
) {
    val filtered = remember(allSessions, searchQuery) {
        val q = searchQuery.trim().lowercase()
        val base = if (q.isEmpty()) allSessions else allSessions.filter {
            it.query.lowercase().contains(q)
        }
        base.take(50)
    }

    if (filtered.isEmpty()) {
        Column(Modifier.padding(24.dp)) {
            Text(
                if (searchQuery.isNotBlank()) "No matches for \"$searchQuery\""
                else "No saved searches",
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
        }
    } else {
        LazyColumn(
            Modifier
                .fillMaxSize()
                .padding(horizontal = 12.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            item {
                Text(
                    "Showing ${filtered.size} of ${allSessions.size}",
                    fontSize = 12.sp,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    modifier = Modifier.padding(vertical = 6.dp)
                )
            }
            items(filtered, key = { it.id }) { session ->
                SessionCard(session = session, vm = vm, nav = nav)
            }
            item { Spacer(Modifier.height(16.dp)) }
        }
    }
}

// ── Calendar View ───────────────────────────────────────────────────────

@Composable
private fun CalendarView(
    allMeta: List<SessionMeta>,
    searchQuery: String,
    vm: AppViewModel,
    nav: NavController,
    workspace: Boolean
) {
    var calendarMode by remember { mutableStateOf("month") } // month, week, day
    var currentCal by remember { mutableStateOf(Calendar.getInstance()) }
    var selectedDaySessions by remember { mutableStateOf<List<SavedSearchSession>>(emptyList()) }
    var selectedDayLabel by remember { mutableStateOf("") }

    // Filter meta by search query
    val filteredMeta = remember(allMeta, searchQuery) {
        val q = searchQuery.trim().lowercase()
        if (q.isEmpty()) allMeta else allMeta.filter { it.query.lowercase().contains(q) }
    }

    // Group by day (yyyy-MM-dd) for badge counting
    val dayFormat = remember { SimpleDateFormat("yyyy-MM-dd", Locale.US) }
    val countByDay = remember(filteredMeta) {
        filteredMeta.groupBy { dayFormat.format(Date(it.createdAt)) }
            .mapValues { it.value.size }
    }

    Column(Modifier.fillMaxSize()) {
        // Calendar mode chips
        Row(
            Modifier
                .fillMaxWidth()
                .padding(horizontal = 12.dp, vertical = 4.dp),
            horizontalArrangement = Arrangement.spacedBy(6.dp)
        ) {
            listOf("month" to "Month", "week" to "Week", "day" to "Day").forEach { (key, label) ->
                FilterChip(
                    selected = calendarMode == key,
                    onClick = { calendarMode = key },
                    label = { Text(label, fontSize = 13.sp) }
                )
            }
        }

        // Navigation row
        Row(
            Modifier
                .fillMaxWidth()
                .padding(horizontal = 12.dp, vertical = 4.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            TextButton(onClick = {
                currentCal = (currentCal.clone() as Calendar).apply {
                    when (calendarMode) {
                        "month" -> add(Calendar.MONTH, -1)
                        "week" -> add(Calendar.WEEK_OF_YEAR, -1)
                        "day" -> add(Calendar.DAY_OF_YEAR, -1)
                    }
                }
            }) { Text("◀") }

            Text(
                when (calendarMode) {
                    "month" -> SimpleDateFormat("MMMM yyyy", Locale.getDefault()).format(currentCal.time)
                    "week" -> {
                        val wk = (currentCal.clone() as Calendar).apply { set(Calendar.DAY_OF_WEEK, firstDayOfWeek) }
                        val wkEnd = (wk.clone() as Calendar).apply { add(Calendar.DAY_OF_YEAR, 6) }
                        "${SimpleDateFormat("d MMM", Locale.getDefault()).format(wk.time)} – ${SimpleDateFormat("d MMM yyyy", Locale.getDefault()).format(wkEnd.time)}"
                    }
                    else -> SimpleDateFormat("EEEE, d MMMM yyyy", Locale.getDefault()).format(currentCal.time)
                },
                fontWeight = FontWeight.Bold,
                fontSize = 15.sp,
                modifier = Modifier.weight(1f),
                textAlign = TextAlign.Center
            )

            TextButton(onClick = {
                currentCal = (currentCal.clone() as Calendar).apply {
                    when (calendarMode) {
                        "month" -> add(Calendar.MONTH, 1)
                        "week" -> add(Calendar.WEEK_OF_YEAR, 1)
                        "day" -> add(Calendar.DAY_OF_YEAR, 1)
                    }
                }
            }) { Text("▶") }
        }

        // Calendar grid or day detail
        when (calendarMode) {
            "month" -> MonthGrid(
                cal = currentCal,
                countByDay = countByDay,
                dayFormat = dayFormat,
                onDayClick = { year, month, day ->
                    val c = Calendar.getInstance().apply { set(year, month, day, 0, 0, 0); set(Calendar.MILLISECOND, 0) }
                    val start = c.timeInMillis
                    c.add(Calendar.DAY_OF_YEAR, 1)
                    val end = c.timeInMillis
                    selectedDayLabel = SimpleDateFormat("d MMMM yyyy", Locale.getDefault()).format(Date(start))
                    vm.loadSessionsForDay(start, end) { selectedDaySessions = it }
                }
            )
            "week" -> WeekStrip(
                cal = currentCal,
                countByDay = countByDay,
                dayFormat = dayFormat,
                onDayClick = { year, month, day ->
                    val c = Calendar.getInstance().apply { set(year, month, day, 0, 0, 0); set(Calendar.MILLISECOND, 0) }
                    val start = c.timeInMillis
                    c.add(Calendar.DAY_OF_YEAR, 1)
                    val end = c.timeInMillis
                    selectedDayLabel = SimpleDateFormat("d MMMM yyyy", Locale.getDefault()).format(Date(start))
                    vm.loadSessionsForDay(start, end) { selectedDaySessions = it }
                }
            )
            "day" -> {
                val c = currentCal.clone() as Calendar
                c.set(Calendar.HOUR_OF_DAY, 0); c.set(Calendar.MINUTE, 0); c.set(Calendar.SECOND, 0); c.set(Calendar.MILLISECOND, 0)
                val start = c.timeInMillis
                c.add(Calendar.DAY_OF_YEAR, 1)
                val end = c.timeInMillis
                val key = dayFormat.format(Date(start))
                val count = countByDay[key] ?: 0
                LaunchedEffect(start) {
                    vm.loadSessionsForDay(start, end) { selectedDaySessions = it }
                    selectedDayLabel = SimpleDateFormat("d MMMM yyyy", Locale.getDefault()).format(Date(start))
                }
                Text(
                    "$count saved search${if (count != 1) "es" else ""} on this day",
                    fontSize = 13.sp,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    modifier = Modifier.padding(horizontal = 16.dp, vertical = 4.dp)
                )
            }
        }

        // Selected day sessions
        if (selectedDaySessions.isNotEmpty()) {
            Text(
                selectedDayLabel,
                fontWeight = FontWeight.Bold,
                fontSize = 14.sp,
                modifier = Modifier.padding(horizontal = 16.dp, vertical = 6.dp)
            )
            LazyColumn(
                Modifier
                    .fillMaxSize()
                    .padding(horizontal = 12.dp),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                items(selectedDaySessions, key = { it.id }) { session ->
                    SessionCard(session = session, vm = vm, nav = nav)
                }
                item { Spacer(Modifier.height(16.dp)) }
            }
        } else if (calendarMode == "day") {
            Column(Modifier.padding(24.dp)) {
                Text(
                    "No saved searches on this day",
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
        }
    }
}

// ── Month Grid ──────────────────────────────────────────────────────────

@Composable
private fun MonthGrid(
    cal: Calendar,
    countByDay: Map<String, Int>,
    dayFormat: SimpleDateFormat,
    onDayClick: (Int, Int, Int) -> Unit
) {
    val year = cal.get(Calendar.YEAR)
    val month = cal.get(Calendar.MONTH)
    val today = Calendar.getInstance()

    val firstOfMonth = Calendar.getInstance().apply { set(year, month, 1) }
    val daysInMonth = firstOfMonth.getActualMaximum(Calendar.DAY_OF_MONTH)
    val startDow = firstOfMonth.get(Calendar.DAY_OF_WEEK) // Sunday=1

    // Day-of-week headers
    Row(
        Modifier
            .fillMaxWidth()
            .padding(horizontal = 8.dp),
        horizontalArrangement = Arrangement.SpaceEvenly
    ) {
        listOf("S", "M", "T", "W", "T", "F", "S").forEach { d ->
            Text(
                d, fontSize = 12.sp,
                fontWeight = FontWeight.Bold,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                modifier = Modifier.weight(1f),
                textAlign = TextAlign.Center
            )
        }
    }

    // Day cells
    val cells = mutableListOf<Int?>()
    for (i in 1 until startDow) cells.add(null)
    for (d in 1..daysInMonth) cells.add(d)
    while (cells.size % 7 != 0) cells.add(null)

    cells.chunked(7).forEach { week ->
        Row(
            Modifier
                .fillMaxWidth()
                .padding(horizontal = 8.dp, vertical = 2.dp),
            horizontalArrangement = Arrangement.SpaceEvenly
        ) {
            week.forEach { day ->
                Box(
                    Modifier
                        .weight(1f)
                        .height(44.dp)
                        .clip(RoundedCornerShape(6.dp))
                        .then(
                            if (day != null) Modifier.clickable { onDayClick(year, month, day) }
                            else Modifier
                        ),
                    contentAlignment = Alignment.Center
                ) {
                    if (day != null) {
                        val key = dayFormat.format(
                            Calendar.getInstance().apply { set(year, month, day) }.time
                        )
                        val count = countByDay[key] ?: 0
                        val isToday = today.get(Calendar.YEAR) == year &&
                            today.get(Calendar.MONTH) == month &&
                            today.get(Calendar.DAY_OF_MONTH) == day

                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                            Text(
                                "$day",
                                fontSize = 14.sp,
                                fontWeight = if (isToday) FontWeight.Bold else FontWeight.Normal,
                                color = if (isToday) MaterialTheme.colorScheme.primary
                                        else MaterialTheme.colorScheme.onSurface
                            )
                            if (count > 0) {
                                Box(
                                    Modifier
                                        .size(18.dp)
                                        .clip(CircleShape)
                                        .background(MaterialTheme.colorScheme.primary),
                                    contentAlignment = Alignment.Center
                                ) {
                                    Text(
                                        "$count",
                                        fontSize = 10.sp,
                                        fontWeight = FontWeight.Bold,
                                        color = MaterialTheme.colorScheme.onPrimary
                                    )
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

// ── Week Strip ──────────────────────────────────────────────────────────

@Composable
private fun WeekStrip(
    cal: Calendar,
    countByDay: Map<String, Int>,
    dayFormat: SimpleDateFormat,
    onDayClick: (Int, Int, Int) -> Unit
) {
    val today = Calendar.getInstance()
    val weekStart = (cal.clone() as Calendar).apply { set(Calendar.DAY_OF_WEEK, firstDayOfWeek) }

    Row(
        Modifier
            .fillMaxWidth()
            .padding(horizontal = 8.dp, vertical = 4.dp),
        horizontalArrangement = Arrangement.SpaceEvenly
    ) {
        for (i in 0..6) {
            val dayCal = (weekStart.clone() as Calendar).apply { add(Calendar.DAY_OF_YEAR, i) }
            val year = dayCal.get(Calendar.YEAR)
            val month = dayCal.get(Calendar.MONTH)
            val day = dayCal.get(Calendar.DAY_OF_MONTH)
            val key = dayFormat.format(dayCal.time)
            val count = countByDay[key] ?: 0
            val isToday = today.get(Calendar.YEAR) == year &&
                today.get(Calendar.MONTH) == month &&
                today.get(Calendar.DAY_OF_MONTH) == day
            val dowLabel = SimpleDateFormat("EEE", Locale.getDefault()).format(dayCal.time)

            Column(
                Modifier
                    .weight(1f)
                    .clip(RoundedCornerShape(8.dp))
                    .clickable { onDayClick(year, month, day) }
                    .padding(vertical = 8.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Text(
                    dowLabel, fontSize = 11.sp,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
                Text(
                    "$day", fontSize = 16.sp,
                    fontWeight = if (isToday) FontWeight.Bold else FontWeight.Normal,
                    color = if (isToday) MaterialTheme.colorScheme.primary
                            else MaterialTheme.colorScheme.onSurface
                )
                if (count > 0) {
                    Box(
                        Modifier
                            .size(20.dp)
                            .clip(CircleShape)
                            .background(MaterialTheme.colorScheme.primary),
                        contentAlignment = Alignment.Center
                    ) {
                        Text(
                            "$count", fontSize = 10.sp,
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.onPrimary
                        )
                    }
                }
            }
        }
    }
}

// ── Session Card (shared by both views) ─────────────────────────────────

@Composable
private fun SessionCard(
    session: SavedSearchSession,
    vm: AppViewModel,
    nav: NavController
) {
    Card(
        onClick = {
            vm.restoreSavedSearchSession(session.id)
            nav.navigate("search") { launchSingleTop = true }
        },
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(Modifier.fillMaxWidth().padding(14.dp)) {
            Text(
                session.query.ifBlank { "Untitled search" },
                fontWeight = FontWeight.SemiBold,
                maxLines = 2,
                overflow = TextOverflow.Ellipsis
            )
            val scopeLabel = if (session.dualMode) "Dual" else when (session.scope) {
                "first20k" -> "1st 20K"
                "second20k" -> "2nd scope"
                "all" -> "All notes"
                else -> session.scope
            }
            Text(
                "${session.hits.size} result${if (session.hits.size == 1) "" else "s"} · " +
                    formatDuration(session.durationMs) + " · ${session.searchType} · $scopeLabel" +
                    if (session.rerankEnabled) " · reranked" else "",
                fontSize = 12.sp,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                modifier = Modifier.padding(top = 5.dp)
            )
            if (session.llmUsed) {
                Text(
                    "LLM used${if (session.llmEngine.isNotBlank()) " · ${session.llmEngine}" else ""}",
                    fontSize = 11.sp,
                    color = MaterialTheme.colorScheme.primary,
                    modifier = Modifier.padding(top = 3.dp)
                )
            }
            if (session.expansions.isNotEmpty()) {
                Text(
                    "Expansions: ${session.expansions.joinToString(" · ")}",
                    fontSize = 11.sp,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    maxLines = 3,
                    overflow = TextOverflow.Ellipsis,
                    modifier = Modifier.padding(top = 3.dp)
                )
            }
            Text(
                DateFormat.getDateTimeInstance(DateFormat.MEDIUM, DateFormat.SHORT)
                    .format(Date(session.createdAt)),
                fontSize = 11.sp,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                modifier = Modifier.padding(top = 3.dp)
            )
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.End) {
                TextButton(onClick = {
                    vm.deleteSavedSearchSession(session.id)
                    vm.refreshSavedSearchMeta()
                    vm.refreshAllSavedSessions()
                }) { Text("Delete") }
                Spacer(Modifier.width(4.dp))
                TextButton(onClick = {
                    vm.restoreSavedSearchSession(session.id)
                    nav.navigate("search") { launchSingleTop = true }
                }) { Text("Open results") }
            }
        }
    }
}

private fun formatDuration(ms: Long): String {
    if (ms <= 0L) return "time unavailable"
    val totalSeconds = ms / 1000.0
    return if (totalSeconds < 60.0) {
        if (totalSeconds < 10.0) "%.1f s".format(totalSeconds) else "%.0f s".format(totalSeconds)
    } else {
        val mins = (ms / 60_000L)
        val secs = (ms % 60_000L) / 1000L
        "${mins}m ${secs}s"
    }
}
