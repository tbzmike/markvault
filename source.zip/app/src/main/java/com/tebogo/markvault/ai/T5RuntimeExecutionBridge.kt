package com.tebogo.markvault.ai

/** Connects tokenizer -> inference -> provider execution flow. */
class T5RuntimeExecutionBridge(
    private val tokenizer: T5Tokenizer,
    private val engine: T5InferenceEngine
) {
    suspend fun generate(query: String): List<String> {
        // T5InferenceEngine already performs tokenization internally.
        // Keep this bridge compatible with the existing engine API.
        val generated = engine.generate(query)
        return generated
            .split("\n", "|", ";")
            .map { it.trim() }
            .filter { it.isNotEmpty() }
    }
}
