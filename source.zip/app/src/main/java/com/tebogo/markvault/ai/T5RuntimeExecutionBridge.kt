package com.tebogo.markvault.ai

/** Connects tokenizer -> inference -> provider execution flow. */
class T5RuntimeExecutionBridge(
    private val tokenizer: T5Tokenizer,
    private val engine: T5InferenceEngine
) {
    suspend fun generate(query: String): List<String> {
        val tokens = tokenizer.encode(query)
        return engine.generate(tokens)
    }
}
