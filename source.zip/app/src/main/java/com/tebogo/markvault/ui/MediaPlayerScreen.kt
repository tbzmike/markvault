package com.tebogo.markvault.ui

import android.app.Activity
import android.content.pm.ActivityInfo
import android.os.Build
import android.util.Rational
import android.view.View
import android.widget.FrameLayout
import androidx.activity.compose.BackHandler
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.text.selection.SelectionContainer
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.media3.common.C
import androidx.media3.common.Player
import androidx.media3.common.TrackSelectionOverride
import androidx.media3.ui.PlayerView
import com.tebogo.markvault.AppViewModel
import com.tebogo.markvault.data.CachedSongLyrics
import com.tebogo.markvault.data.MediaItem
import com.tebogo.markvault.data.SongLyricsCache
import coil.compose.AsyncImage
import kotlinx.coroutines.launch

/**
 * v5.4.233cc — Full-screen media player.
 *
 * Attaches to the SHARED MediaController (owned by PlaybackService) rather
 * than creating its own ExoPlayer — playback already started (from
 * wherever the user tapped Play) survives this screen opening, closing,
 * or the app backgrounding entirely, and the system notification keeps
 * working regardless of whether this screen is even open.
 *
 * Features: play/pause/seek (via PlayerView's built-in controls),
 * fullscreen (landscape + hidden system bars), Picture-in-Picture,
 * BackHandler exits fullscreen before navigating back, audio/subtitle
 * track selection.
 */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun MediaPlayerScreen(
    vm: AppViewModel,
    nav: androidx.navigation.NavController,
    mediaId: Long
) {
    val ctx      = LocalContext.current
    val activity = remember(ctx) { ctx as? Activity }
    val item     by vm.nowPlayingMedia.collectAsStateWithLifecycle()
    val androidAutoConnected by vm.androidAutoConnected.collectAsStateWithLifecycle()
    val immersiveViewEnabled by vm.immersiveViewEnabled.collectAsStateWithLifecycle()
    val bulkCaptionState by vm.bulkCaptionDownloadState.collectAsStateWithLifecycle()

    // v5.4.233cc — Poll for the shared controller becoming ready (async
    // connection to PlaybackService). No local ExoPlayer is created here.
    var controller by remember { mutableStateOf<Player?>(null) }
    LaunchedEffect(Unit) {
        var waited = 0
        while (controller == null && waited < 3000) {
            controller = vm.getMediaController()
            if (controller == null) {
                kotlinx.coroutines.delay(50L)
                waited += 50
            }
        }
    }

    // v5.4.233cc — Surface playback failures instead of failing silently.
    var playerError by remember { mutableStateOf<String?>(null) }

    // ── Track state (for the track-selection dialog) + error listener ──────
    var currentTracks by remember { mutableStateOf<androidx.media3.common.Tracks?>(null) }
    DisposableEffect(controller) {
        val c = controller
        if (c == null) return@DisposableEffect onDispose {}
        currentTracks = c.currentTracks
        playerError = null
        val listener = object : Player.Listener {
            override fun onTracksChanged(tracks: androidx.media3.common.Tracks) {
                currentTracks = tracks
            }
            override fun onPlayerError(error: androidx.media3.common.PlaybackException) {
                playerError = error.message ?: "Playback failed"
            }
        }
        c.addListener(listener)
        onDispose { c.removeListener(listener) }
    }
    val audioGroups = remember(currentTracks) {
        currentTracks?.groups?.filter { it.type == C.TRACK_TYPE_AUDIO && it.isSupported } ?: emptyList()
    }
    val textGroups = remember(currentTracks) {
        currentTracks?.groups?.filter { it.type == C.TRACK_TYPE_TEXT && it.isSupported } ?: emptyList()
    }
    val hasSelectableTracks = audioGroups.size + textGroups.size > 0

    // ── Fullscreen / PiP state ──────────────────────────────────────────────
    var isFullscreen by remember { mutableStateOf(false) }
    var showFullscreenText by rememberSaveable { mutableStateOf(true) }
    var showTrackDialog by remember { mutableStateOf(false) }
    // v5.4.255cc — Now Playing Queue sheet toggle.
    var showQueueSheet by remember { mutableStateOf(false) }
    val relatedScope = rememberCoroutineScope()
    var showRelatedArticles by remember { mutableStateOf(false) }
    var relatedArticles by remember { mutableStateOf<List<com.tebogo.markvault.data.RelatedArticleMatch>>(emptyList()) }
    var relatedArticlesBusy by remember { mutableStateOf(false) }

    // v5.4.279cc — Song lyrics use the otherwise-empty lower half of the
    // audio player. Cached copies live in app-internal storage so reopening
    // a song does not hit JW.org again. Cache misses are resolved directly
    // from the official JW.org song collection/article pages on Dispatchers.IO;
    // playback itself never owns or waits on a hidden WebView.
    var lyrics by remember(item?.id, item?.jwKey, item?.contentLanguage) { mutableStateOf<CachedSongLyrics?>(null) }
    var lyricsState by remember(item?.id, item?.jwKey, item?.contentLanguage) { mutableStateOf(LyricsLoadState.HIDDEN) }
    LaunchedEffect(item?.id, item?.jwKey, item?.contentLanguage, item?.title, item?.category, item?.streamUrl) {
        val current = item
        if (current == null || !SongLyricsCache.isLyricsEligible(current)) {
            lyrics = null
            lyricsState = LyricsLoadState.HIDDEN
            return@LaunchedEffect
        }
        lyricsState = LyricsLoadState.LOADING
        val cached = SongLyricsCache.load(ctx, current)
        if (cached != null) {
            lyrics = cached
            lyricsState = LyricsLoadState.READY
            return@LaunchedEffect
        }

        lyrics = null
        lyricsState = LyricsLoadState.FETCHING
        val fetched = SongLyricsCache.fetchFromJw(current)
        if (fetched != null) {
            SongLyricsCache.save(ctx, current, fetched)
            // The player may have advanced while the network request was in flight.
            val active = item
            if (active != null && active.id == current.id && active.jwKey == current.jwKey && active.contentLanguage == current.contentLanguage) {
                lyrics = fetched
                lyricsState = LyricsLoadState.READY
            }
        } else {
            val active = item
            if (active != null && active.id == current.id && active.jwKey == current.jwKey && active.contentLanguage == current.contentLanguage) {
                lyricsState = LyricsLoadState.UNAVAILABLE
            }
        }
    }
    // v5.4.296cc — Audio karaoke clock. SongLyricsCache currently stores the
    // authoritative JW.org lyric text but no lyric timestamps, so karaoke mode
    // derives a stable line timeline from the actual player duration. The clock
    // only runs for lyric-eligible audio and does not touch PlaybackService.
    var karaokeEnabled by rememberSaveable { mutableStateOf(true) }
    var karaokePlaybackPositionMs by remember(item?.id, item?.jwKey, item?.contentLanguage) { mutableLongStateOf(0L) }
    var karaokeDurationMs by remember(item?.id, item?.jwKey, item?.contentLanguage) { mutableLongStateOf(0L) }
    LaunchedEffect(controller, item?.id, item?.jwKey, item?.contentLanguage, item?.mediaType, item?.durationMs) {
        val c = controller
        val current = item
        if (c == null || current == null || !SongLyricsCache.isLyricsEligible(current)) {
            karaokePlaybackPositionMs = 0L
            karaokeDurationMs = 0L
            return@LaunchedEffect
        }
        while (true) {
            karaokePlaybackPositionMs = c.currentPosition.coerceAtLeast(0L)
            val playerDuration = c.duration
            karaokeDurationMs = when {
                playerDuration > 0L && playerDuration != C.TIME_UNSET -> playerDuration
                current.durationMs > 0L -> current.durationMs
                else -> 0L
            }
            kotlinx.coroutines.delay(350L)
        }
    }

    // v5.4.290cc — Video transcript display. The transcript is written by
    // PlaybackService / complete VTT extraction, then observed here independently
    // of the article-search pipeline. Polling is deliberately lightweight and only
    // active while a video is the current media item.
    var videoTranscript by remember(item?.id, item?.jwKey) {
        mutableStateOf<com.tebogo.markvault.data.VideoTranscriptStore.Transcript?>(null)
    }
    var transcriptTextSize by rememberSaveable { mutableStateOf(16f) }
    LaunchedEffect(item?.id, item?.jwKey, item?.mediaType) {
        val current = item
        if (current == null || !current.mediaType.equals("video", ignoreCase = true)) {
            videoTranscript = null
            return@LaunchedEffect
        }
        while (true) {
            videoTranscript = com.tebogo.markvault.data.VideoTranscriptStore.load(ctx, current)
            // v5.4.386cc — A partial playback-captured transcript can later be
            // replaced by the bulk/full VTT downloader. Keep polling until the
            // immutable complete copy arrives, then stop touching storage.
            if (videoTranscript?.complete == true) break
            kotlinx.coroutines.delay(1_500L)
        }
    }

    // v5.4.295cc — Keep a lightweight playback clock for the interactive
    // transcript. This only polls while the full player is showing a video; it
    // does not alter PlaybackService, caption capture, or the search pipeline.
    var transcriptPlaybackPositionMs by remember(item?.id, item?.jwKey, item?.contentLanguage) { mutableLongStateOf(0L) }
    LaunchedEffect(controller, item?.id, item?.jwKey, item?.mediaType) {
        val c = controller
        val current = item
        if (c == null || current == null || !current.mediaType.equals("video", ignoreCase = true)) {
            transcriptPlaybackPositionMs = 0L
            return@LaunchedEffect
        }
        while (true) {
            transcriptPlaybackPositionMs = c.currentPosition.coerceAtLeast(0L)
            kotlinx.coroutines.delay(400L)
        }
    }

    // v5.4.235cc — Video quality picker. qualityOptions is "label\turl" per
    // line, highest resolution first (see JwMediaApi.allQualityOptions).
    var showQualityDialog by remember { mutableStateOf(false) }
    val qualityChoices = remember(item?.qualityOptions) {
        item?.qualityOptions.orEmpty()
            .split("\n")
            .mapNotNull { line ->
                val parts = line.split("\t", limit = 2)
                if (parts.size == 2 && parts[1].isNotBlank()) parts[0] to parts[1] else null
            }
    }

    fun enterFullscreen() {
        isFullscreen = true
        activity?.requestedOrientation = ActivityInfo.SCREEN_ORIENTATION_SENSOR_LANDSCAPE
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
            activity?.window?.insetsController?.hide(android.view.WindowInsets.Type.systemBars())
        } else {
            @Suppress("DEPRECATION")
            activity?.window?.decorView?.systemUiVisibility = (
                View.SYSTEM_UI_FLAG_FULLSCREEN or
                View.SYSTEM_UI_FLAG_HIDE_NAVIGATION or
                View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY
            )
        }
    }

    fun exitFullscreen() {
        isFullscreen = false
        activity?.requestedOrientation = ActivityInfo.SCREEN_ORIENTATION_UNSPECIFIED
        if (!immersiveViewEnabled) {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
                activity?.window?.insetsController?.show(android.view.WindowInsets.Type.systemBars())
            } else {
                @Suppress("DEPRECATION")
                activity?.window?.decorView?.systemUiVisibility = View.SYSTEM_UI_FLAG_VISIBLE
            }
        }
    }

    /**
     * v5.4.235cc — Switch playback to a different quality URL, preserving
     * the current playback position so switching feels seamless rather
     * than restarting from zero.
     */
    fun switchQuality(url: String) {
        val c = controller ?: return
        val resumeAt = c.currentPosition.coerceAtLeast(0L)
        val wasPlaying = c.isPlaying
        val exo = androidx.media3.common.MediaItem.Builder()
            .setUri(url)
            .apply {
                item?.mimeType?.takeIf { it.isNotBlank() }?.let { setMimeType(it) }
                item?.id?.let { setMediaId(it.toString()) }
                val current = item
                if (current != null && current.subtitleUrl.isNotBlank() &&
                    current.mediaType.equals("video", ignoreCase = true)) {
                    val subtitle = androidx.media3.common.MediaItem.SubtitleConfiguration.Builder(
                        android.net.Uri.parse(current.subtitleUrl)
                    )
                        .setMimeType(androidx.media3.common.MimeTypes.TEXT_VTT)
                        .setSelectionFlags(androidx.media3.common.C.SELECTION_FLAG_DEFAULT)
                        .build()
                    setSubtitleConfigurations(listOf(subtitle))
                }
            }
            .setMediaMetadata(
                androidx.media3.common.MediaMetadata.Builder()
                    .setTitle(item?.title ?: "")
                    .build()
            )
            .build()
        c.setMediaItem(exo, resumeAt)
        c.prepare()
        c.playWhenReady = wasPlaying
    }

    fun shareMedia() {
        val m = item ?: return
        val shareUrl = m.localPath.ifBlank { m.streamUrl }
        if (shareUrl.isBlank()) return
        val text = if (m.title.isNotBlank()) "${m.title}\n$shareUrl" else shareUrl
        val sendIntent = android.content.Intent(android.content.Intent.ACTION_SEND).apply {
            type = "text/plain"
            putExtra(android.content.Intent.EXTRA_TEXT, text)
            if (m.title.isNotBlank()) putExtra(android.content.Intent.EXTRA_SUBJECT, m.title)
        }
        runCatching {
            ctx.startActivity(android.content.Intent.createChooser(sendIntent, "Share"))
        }
    }

    fun transcriptPlainText(): String {
        val transcript = videoTranscript ?: return ""
        return buildTimedTranscriptParagraphs(transcript.cues).joinToString("\n\n") { paragraph ->
            "[${formatTranscriptTimestamp(paragraph.startMs)}] ${paragraph.text}"
        }
    }

    fun copyTranscript() {
        val text = transcriptPlainText()
        if (text.isBlank()) return
        val clipboard = ctx.getSystemService(android.content.Context.CLIPBOARD_SERVICE) as? android.content.ClipboardManager
        clipboard?.setPrimaryClip(android.content.ClipData.newPlainText("Video captions", text))
        android.widget.Toast.makeText(ctx, "Captions copied", android.widget.Toast.LENGTH_SHORT).show()
    }

    fun shareTranscript() {
        val text = transcriptPlainText()
        if (text.isBlank()) return
        val title = item?.title.orEmpty()
        val sendIntent = android.content.Intent(android.content.Intent.ACTION_SEND).apply {
            type = "text/plain"
            putExtra(android.content.Intent.EXTRA_TEXT, if (title.isBlank()) text else "$title\n\n$text")
            if (title.isNotBlank()) putExtra(android.content.Intent.EXTRA_SUBJECT, "$title captions")
        }
        runCatching { ctx.startActivity(android.content.Intent.createChooser(sendIntent, "Share captions")) }
    }

    BackHandler(enabled = isFullscreen) { exitFullscreen() }

    if (isFullscreen) {
        Box(modifier = Modifier.fillMaxSize().background(Color.Black)) {
            AndroidView(
                factory = { c ->
                    PlayerView(c).apply {
                        this.player = controller
                        useController = true
                        setFullscreenButtonClickListener { _ -> exitFullscreen() }
                        layoutParams = FrameLayout.LayoutParams(
                            FrameLayout.LayoutParams.MATCH_PARENT,
                            FrameLayout.LayoutParams.MATCH_PARENT
                        )
                    }
                },
                update = { it.player = controller },
                modifier = Modifier.fillMaxSize()
            )

            // v5.4.393cc — TV-friendly fullscreen text layer. CC/lyrics remain
            // readable without leaving fullscreen and the controls are ordinary
            // focusable Material buttons, so D-pad/remote navigation works.
            val fullscreenHasText = if (item?.mediaType.equals("video", true))
                videoTranscript?.cues?.isNotEmpty() == true else lyricsState == LyricsLoadState.READY
            if (fullscreenHasText) {
                Row(
                    modifier = Modifier.align(Alignment.TopEnd).padding(18.dp),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    FilledTonalButton(onClick = { showFullscreenText = !showFullscreenText }) {
                        Text(if (showFullscreenText) "Hide ${if (item?.mediaType.equals("video", true)) "CC" else "Lyrics"}"
                             else "Show ${if (item?.mediaType.equals("video", true)) "CC" else "Lyrics"}")
                    }
                    FilledTonalButton(onClick = { exitFullscreen() }) { Text("Exit ⛶") }
                }
            }
            if (showFullscreenText && fullscreenHasText) {
                if (item?.mediaType.equals("video", true)) {
                    FullscreenTranscriptOverlay(
                        transcript = videoTranscript,
                        playbackPositionMs = transcriptPlaybackPositionMs,
                        onSeekTo = { position -> controller?.seekTo(position) },
                        modifier = Modifier.align(Alignment.CenterEnd)
                    )
                } else {
                    FullscreenLyricsOverlay(
                        lyrics = lyrics,
                        playbackPositionMs = karaokePlaybackPositionMs,
                        durationMs = karaokeDurationMs,
                        onSeekTo = { position -> controller?.seekTo(position) },
                        modifier = Modifier.align(Alignment.CenterEnd)
                    )
                }
            }
        }
    } else {
        Scaffold(
            topBar = {
                TopAppBar(
                    title = { Text(item?.title ?: "Media Player", maxLines = 1, fontSize = 15.sp) },
                    navigationIcon = {
                        IconButton(onClick = { nav.popBackStack() }) {
                            Text("\u2190", fontSize = 20.sp)
                        }
                    },
                    actions = {
                        // v5.4.261cc — CastButton now delegates discovery,
                        // route selection, and session UI to Google's official
                        // MediaRouteButton/CastButtonFactory integration.
                        CastButton()
                        // v5.4.254cc — Favourite toggle for the currently
                        // playing item, right next to Cast so it's reachable
                        // while actually watching/listening — the most
                        // natural place to favourite something.
                        item?.let { m ->
                            IconButton(onClick = { vm.toggleMediaFavourite(m) }) {
                                Text(
                                    if (m.isFavourite == 1) "\u2B50" else "\u2606",
                                    fontSize = 20.sp
                                )
                            }
                        }
                        if (item?.mediaType == "video") {
                            IconButton(onClick = {
                                val current = item ?: return@IconButton
                                relatedArticlesBusy = true
                                showRelatedArticles = true
                                relatedScope.launch {
                                    relatedArticles = vm.findRelatedArticles(current)
                                    relatedArticlesBusy = false
                                }
                            }) { Text("📖", fontSize = 18.sp) }
                        }
                        // Picture-in-Picture (Android 8+)
                        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                            IconButton(onClick = {
                                activity?.let { act ->
                                    @Suppress("NewApi")
                                    val params = android.app.PictureInPictureParams.Builder()
                                        .setAspectRatio(Rational(16, 9))
                                        .apply {
                                            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
                                                setAutoEnterEnabled(true)
                                            }
                                        }
                                        .build()
                                    act.enterPictureInPictureMode(params)
                                }
                            }) {
                                Text("\u2922", fontSize = 18.sp)
                            }
                        }
                        if (hasSelectableTracks) {
                            IconButton(onClick = { showTrackDialog = true }) {
                                Text("CC", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                            }
                        }
                        // v5.4.235cc — Video quality picker. Only shown when
                        // more than one resolution is actually available.
                        if (qualityChoices.size > 1) {
                            IconButton(onClick = { showQualityDialog = true }) {
                                Text("\u2699", fontSize = 16.sp)
                            }
                        }
                        // v5.4.235cc — Share the media link via the system
                        // share sheet.
                        IconButton(onClick = { shareMedia() }) {
                            Text("\u2197", fontSize = 16.sp)
                        }
                    }
                )
            }
        ) { pad ->
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(pad)
                    .verticalScroll(rememberScrollState())
            ) {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .then(
                            if (item?.mediaType == "video") Modifier.aspectRatio(16f / 9f)
                            else Modifier.height(200.dp)
                        )
                        .background(Color.Black)
                ) {
                    // v5.4.355cc — Audio has no video frames, so use the JW
                    // thumbnail as the visual background behind Media3's
                    // transport controls instead of leaving this area black.
                    val currentItem = item
                    if (currentItem != null && currentItem.mediaType.equals("audio", ignoreCase = true) && currentItem.thumbnailUrl.isNotBlank()) {
                        AsyncImage(
                            model = currentItem.thumbnailUrl,
                            contentDescription = currentItem.title,
                            contentScale = ContentScale.Crop,
                            modifier = Modifier.fillMaxSize()
                        )
                        Box(Modifier.fillMaxSize().background(Color.Black.copy(alpha = 0.38f)))
                    }
                    if (controller == null) {
                        Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                            CircularProgressIndicator(color = Color.White)
                        }
                    } else {
                        AndroidView(
                            factory = { c ->
                                PlayerView(c).apply {
                                    this.player = controller
                                    useController = true
                                    setBackgroundColor(android.graphics.Color.TRANSPARENT)
                                    setShutterBackgroundColor(android.graphics.Color.TRANSPARENT)
                                    videoSurfaceView?.visibility = if (item?.mediaType.equals("audio", ignoreCase = true)) View.INVISIBLE else View.VISIBLE
                                    setFullscreenButtonClickListener { _ -> enterFullscreen() }
                                    layoutParams = FrameLayout.LayoutParams(
                                        FrameLayout.LayoutParams.MATCH_PARENT,
                                        FrameLayout.LayoutParams.MATCH_PARENT
                                    )
                                }
                            },
                            update = {
                                it.player = controller
                                // SurfaceView is opaque by default; hide it for audio so
                                // the JW thumbnail behind the transport controls is visible.
                                it.videoSurfaceView?.visibility = if (item?.mediaType.equals("audio", ignoreCase = true)) View.INVISIBLE else View.VISIBLE
                            },
                            modifier = Modifier.fillMaxSize()
                        )
                    }
                }

                playerError?.let { err ->
                    Surface(
                        color = MaterialTheme.colorScheme.errorContainer,
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Text(
                            "\u26A0\uFE0F $err",
                            color = MaterialTheme.colorScheme.onErrorContainer,
                            fontSize = 13.sp,
                            modifier = Modifier.padding(12.dp)
                        )
                    }
                }

                // v5.4.255cc — Queue transport controls. Continuous play
                // (auto-advance through a multi-item queue) is Media3's
                // own default Player behavior once vm.playQueue()/
                // playMediaFromList() loads more than one item — these
                // buttons expose manual control over that same queue, and
                // work identically whether the active player is local or
                // Chromecast (both implement the same Player interface;
                // PlaybackService carries the whole queue across on
                // cast connect/disconnect).
                if (item != null) {
                    val shuffleOn by vm.shuffleEnabled.collectAsStateWithLifecycle()
                    val repeatModeState by vm.repeatMode.collectAsStateWithLifecycle()
                    val queueState by vm.currentQueue.collectAsStateWithLifecycle()
                    Row(
                        modifier = Modifier.fillMaxWidth().padding(vertical = 4.dp),
                        horizontalArrangement = Arrangement.SpaceEvenly,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        IconButton(onClick = { vm.toggleShuffle() }) {
                            Text(
                                "\uD83D\uDD00",
                                fontSize = 18.sp,
                                color = if (shuffleOn) MaterialTheme.colorScheme.primary
                                        else MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                        IconButton(onClick = { vm.playPreviousInQueue() }) {
                            Text("\u23EE", fontSize = 20.sp)
                        }
                        IconButton(onClick = { vm.playNextInQueue() }) {
                            Text("\u23ED", fontSize = 20.sp)
                        }
                        IconButton(onClick = { vm.cycleRepeatMode() }) {
                            Text(
                                if (repeatModeState == androidx.media3.common.Player.REPEAT_MODE_ONE) "\uD83D\uDD02" else "\uD83D\uDD01",
                                fontSize = 18.sp,
                                color = if (repeatModeState != androidx.media3.common.Player.REPEAT_MODE_OFF) MaterialTheme.colorScheme.primary
                                        else MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                        IconButton(onClick = { showQueueSheet = true }) {
                            Text(
                                "\u2630",
                                fontSize = 18.sp,
                                color = if (queueState.size > 1) MaterialTheme.colorScheme.primary
                                        else MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    }
                }

                item?.let { m ->
                    Column(modifier = Modifier.padding(16.dp)) {
                        Text(m.title, fontWeight = FontWeight.Bold, fontSize = 17.sp)
                        if (m.description.isNotBlank()) {
                            Spacer(Modifier.height(6.dp))
                            Text(m.description, fontSize = 13.sp,
                                color = MaterialTheme.colorScheme.onSurfaceVariant)
                        }
                        if (m.scriptureRefs.isNotBlank()) {
                            Spacer(Modifier.height(6.dp))
                            Text("\uD83D\uDCD6 ${m.scriptureRefs}", fontSize = 12.sp,
                                color = MaterialTheme.colorScheme.primary)
                        }
                        if (m.category.isNotBlank()) {
                            Spacer(Modifier.height(4.dp))
                            Text(m.category, fontSize = 11.sp,
                                color = MaterialTheme.colorScheme.onSurfaceVariant)
                        }
                        Spacer(Modifier.height(4.dp))
                        Text(
                            if (androidAutoConnected)
                                "🚘 Playing on Android Auto — phone controls and lyrics stay synchronized"
                            else
                                "🔊 Playing in background — controls available in your notification panel",
                            fontSize = 11.sp,
                            color = if (androidAutoConnected) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }

                    if (SongLyricsCache.isLyricsEligible(m)) {
                        LyricsPanel(
                            lyrics = lyrics,
                            state = lyricsState,
                            karaokeEnabled = karaokeEnabled,
                            playbackPositionMs = karaokePlaybackPositionMs,
                            durationMs = karaokeDurationMs,
                            onToggleKaraoke = { karaokeEnabled = !karaokeEnabled },
                            onSeekTo = { positionMs -> controller?.seekTo(positionMs.coerceAtLeast(0L)) }
                        )
                    }

                    if (m.mediaType.equals("video", ignoreCase = true)) {
                        VideoTranscriptPanel(
                            transcript = videoTranscript,
                            textSizeSp = transcriptTextSize,
                            playbackPositionMs = transcriptPlaybackPositionMs,
                            onSeekTo = { positionMs -> controller?.seekTo(positionMs.coerceAtLeast(0L)) },
                            onSmaller = { transcriptTextSize = (transcriptTextSize - 1f).coerceAtLeast(11f) },
                            onLarger = { transcriptTextSize = (transcriptTextSize + 1f).coerceAtMost(28f) },
                            bulkState = bulkCaptionState,
                            onDownloadAllCaptions = { vm.downloadAllVideoCaptions() },
                            onCancelBulkDownload = { vm.cancelAllVideoCaptionDownload() },
                            onCopyTranscript = ::copyTranscript,
                            onShareTranscript = ::shareTranscript
                        )
                    }

                }
            }
        }
    }

    if (showTrackDialog) {
        AlertDialog(
            onDismissRequest = { showTrackDialog = false },
            title = { Text("Select Track") },
            text = {
                LazyColumn {
                    if (audioGroups.isNotEmpty()) {
                        item { Text("\uD83D\uDD0A Audio", fontWeight = FontWeight.SemiBold,
                            fontSize = 12.sp, modifier = Modifier.padding(vertical = 4.dp)) }
                        audioGroups.forEach { group ->
                            items(group.length) { trackIndex ->
                                val fmt      = group.getTrackFormat(trackIndex)
                                val selected = group.isTrackSelected(trackIndex)
                                val label    = fmt.label?.ifBlank { null }
                                    ?: fmt.language?.ifBlank { null }
                                    ?: "Audio ${trackIndex + 1}"
                                Row(
                                    modifier = Modifier.fillMaxWidth().padding(vertical = 4.dp),
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    RadioButton(selected = selected, onClick = {
                                        controller?.let { c ->
                                            c.trackSelectionParameters = c.trackSelectionParameters.buildUpon()
                                                .setOverrideForType(
                                                    TrackSelectionOverride(group.mediaTrackGroup, listOf(trackIndex))
                                                ).build()
                                        }
                                    })
                                    Text(label, fontSize = 14.sp)
                                }
                            }
                        }
                    }
                    if (textGroups.isNotEmpty()) {
                        item { Text("\uD83D\uDCAC Subtitles", fontWeight = FontWeight.SemiBold,
                            fontSize = 12.sp, modifier = Modifier.padding(vertical = 4.dp)) }
                        item {
                            Row(
                                modifier = Modifier.fillMaxWidth().padding(vertical = 4.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                val noneSelected = textGroups.none { g ->
                                    (0 until g.length).any { g.isTrackSelected(it) }
                                }
                                RadioButton(selected = noneSelected, onClick = {
                                    controller?.let { c ->
                                        c.trackSelectionParameters = c.trackSelectionParameters.buildUpon()
                                            .clearOverridesOfType(C.TRACK_TYPE_TEXT)
                                            .setTrackTypeDisabled(C.TRACK_TYPE_TEXT, true)
                                            .build()
                                    }
                                })
                                Text("Off", fontSize = 14.sp)
                            }
                        }
                        textGroups.forEach { group ->
                            items(group.length) { trackIndex ->
                                val fmt      = group.getTrackFormat(trackIndex)
                                val selected = group.isTrackSelected(trackIndex)
                                val label    = fmt.label?.ifBlank { null }
                                    ?: fmt.language?.ifBlank { null }
                                    ?: "Subtitle ${trackIndex + 1}"
                                Row(
                                    modifier = Modifier.fillMaxWidth().padding(vertical = 4.dp),
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    RadioButton(selected = selected, onClick = {
                                        controller?.let { c ->
                                            c.trackSelectionParameters = c.trackSelectionParameters.buildUpon()
                                                .setTrackTypeDisabled(C.TRACK_TYPE_TEXT, false)
                                                .setOverrideForType(
                                                    TrackSelectionOverride(group.mediaTrackGroup, listOf(trackIndex))
                                                ).build()
                                        }
                                    })
                                    Text(label, fontSize = 14.sp)
                                }
                            }
                        }
                    }
                }
            },
            confirmButton = {
                TextButton(onClick = { showTrackDialog = false }) { Text("Done") }
            }
        )
    }

    // v5.4.235cc — Video quality picker dialog.
    if (showQualityDialog) {
        AlertDialog(
            onDismissRequest = { showQualityDialog = false },
            title = { Text("Video Quality") },
            text = {
                Column {
                    qualityChoices.forEach { (label, url) ->
                        val isCurrent = item?.streamUrl == url
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(vertical = 4.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            RadioButton(
                                selected = isCurrent,
                                onClick = {
                                    switchQuality(url)
                                    showQualityDialog = false
                                }
                            )
                            Text(label, fontSize = 14.sp)
                        }
                    }
                }
            },
            confirmButton = {
                TextButton(onClick = { showQualityDialog = false }) { Text("Done") }
            }
        )
    }

    // v5.4.255cc — Now Playing Queue sheet.
    if (showRelatedArticles) {
        Box(Modifier.fillMaxSize().padding(12.dp), contentAlignment = Alignment.BottomCenter) {
            if (relatedArticlesBusy) CircularProgressIndicator()
            else RelatedArticlesCarousel(vm, nav, item?.title.orEmpty(), relatedArticles, onClose = { showRelatedArticles = false })
        }
    }

    if (showQueueSheet) {
        NowPlayingQueueSheet(vm = vm, onDismiss = { showQueueSheet = false })
    }
}


@Composable
private fun FullscreenTranscriptOverlay(
    transcript: com.tebogo.markvault.data.VideoTranscriptStore.Transcript?,
    playbackPositionMs: Long,
    onSeekTo: (Long) -> Unit,
    modifier: Modifier = Modifier
) {
    val paragraphs = remember(transcript) { buildTimedTranscriptParagraphs(transcript?.cues.orEmpty()) }
    if (paragraphs.isEmpty()) return
    val active = paragraphs.indexOfLast { it.startMs <= playbackPositionMs }.coerceAtLeast(0)
    val state = rememberLazyListState()
    LaunchedEffect(active) { if (active in paragraphs.indices) state.animateScrollToItem((active - 1).coerceAtLeast(0)) }
    Surface(
        modifier = modifier.fillMaxHeight(0.72f).widthIn(min = 320.dp, max = 480.dp).padding(20.dp),
        color = Color.Black.copy(alpha = 0.78f),
        shape = MaterialTheme.shapes.large
    ) {
        Column(Modifier.padding(16.dp)) {
            Text("CC • Captions", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 18.sp)
            Spacer(Modifier.height(8.dp))
            LazyColumn(state = state, verticalArrangement = Arrangement.spacedBy(6.dp)) {
                itemsIndexed(paragraphs, key = { i, p -> "fs_${p.startMs}_$i" }) { index, paragraph ->
                    val selected = index == active
                    Surface(
                        modifier = Modifier.fillMaxWidth().clickable { onSeekTo(paragraph.startMs) },
                        color = if (selected) MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.96f) else Color.Transparent,
                        shape = MaterialTheme.shapes.medium
                    ) {
                        Text(
                            "${formatTranscriptTimestamp(paragraph.startMs)}  ${paragraph.text}",
                            modifier = Modifier.padding(10.dp),
                            color = if (selected) MaterialTheme.colorScheme.onPrimaryContainer else Color.White,
                            fontWeight = if (selected) FontWeight.Bold else FontWeight.Normal,
                            fontSize = if (selected) 18.sp else 16.sp,
                            lineHeight = 23.sp
                        )
                    }
                }
            }
        }
    }
}

@Composable
private fun FullscreenLyricsOverlay(
    lyrics: CachedSongLyrics?,
    playbackPositionMs: Long,
    durationMs: Long,
    onSeekTo: (Long) -> Unit,
    modifier: Modifier = Modifier
) {
    val lines = remember(lyrics?.text, lyrics?.timedLines, durationMs) {
        if (!lyrics?.timedLines.isNullOrEmpty()) lyrics!!.timedLines.map { KaraokeLine(it.text, it.isSection, it.startMs, it.endMs) }
        else buildKaraokeLines(lyrics?.text.orEmpty(), durationMs)
    }
    if (lines.isEmpty()) return
    val active = lines.indexOfLast { !it.isSection && playbackPositionMs >= it.startMs && playbackPositionMs < it.endMs }
    val state = rememberLazyListState()
    LaunchedEffect(active) { if (active >= 0) state.animateScrollToItem((active - 2).coerceAtLeast(0)) }
    Surface(
        modifier = modifier.fillMaxHeight(0.72f).widthIn(min = 320.dp, max = 500.dp).padding(20.dp),
        color = Color.Black.copy(alpha = 0.78f),
        shape = MaterialTheme.shapes.large
    ) {
        Column(Modifier.padding(16.dp)) {
            Text("♫ Lyrics", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 18.sp)
            Spacer(Modifier.height(8.dp))
            LazyColumn(state = state, verticalArrangement = Arrangement.spacedBy(4.dp)) {
                itemsIndexed(lines, key = { i, line -> "lyric_${i}_${line.text.hashCode()}" }) { index, line ->
                    val selected = index == active && !line.isSection
                    Surface(
                        modifier = Modifier.fillMaxWidth().clickable(enabled = !line.isSection) { onSeekTo(line.startMs) },
                        color = if (selected) MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.96f) else Color.Transparent,
                        shape = MaterialTheme.shapes.medium
                    ) {
                        Text(
                            line.text,
                            modifier = Modifier.padding(horizontal = 10.dp, vertical = 7.dp),
                            color = if (selected) MaterialTheme.colorScheme.onPrimaryContainer else Color.White,
                            fontSize = if (selected) 20.sp else 17.sp,
                            fontWeight = if (line.isSection || selected) FontWeight.Bold else FontWeight.Normal,
                            lineHeight = 25.sp
                        )
                    }
                }
            }
        }
    }
}

@Composable
private fun VideoTranscriptPanel(
    transcript: com.tebogo.markvault.data.VideoTranscriptStore.Transcript?,
    textSizeSp: Float,
    playbackPositionMs: Long,
    onSeekTo: (Long) -> Unit,
    onSmaller: () -> Unit,
    onLarger: () -> Unit,
    bulkState: com.tebogo.markvault.BulkCaptionDownloadState,
    onDownloadAllCaptions: () -> Unit,
    onCancelBulkDownload: () -> Unit,
    onCopyTranscript: () -> Unit,
    onShareTranscript: () -> Unit
) {
    Surface(
        modifier = Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 8.dp),
        shape = MaterialTheme.shapes.large,
        tonalElevation = 2.dp,
        color = MaterialTheme.colorScheme.surfaceContainerLow
    ) {
        Column(modifier = Modifier.padding(18.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(
                    "Video transcript",
                    fontSize = 18.sp,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.primary,
                    modifier = Modifier.weight(1f)
                )
                TextButton(onClick = onSmaller, contentPadding = PaddingValues(horizontal = 8.dp)) {
                    Text("A−", fontWeight = FontWeight.Bold)
                }
                Text("${textSizeSp.toInt()}sp", fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                TextButton(onClick = onLarger, contentPadding = PaddingValues(horizontal = 8.dp)) {
                    Text("A+", fontWeight = FontWeight.Bold)
                }
            }
            Spacer(Modifier.height(8.dp))
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                FilledTonalButton(
                    onClick = if (bulkState.running) onCancelBulkDownload else onDownloadAllCaptions,
                    modifier = Modifier.weight(1f)
                ) {
                    Text(if (bulkState.running) "■ Cancel all CC" else "⬇ Download all CC", fontSize = 12.sp)
                }
                TextButton(onClick = onCopyTranscript, enabled = transcript?.cues?.isNotEmpty() == true) {
                    Text("Copy", fontSize = 12.sp)
                }
                TextButton(onClick = onShareTranscript, enabled = transcript?.cues?.isNotEmpty() == true) {
                    Text("Share", fontSize = 12.sp)
                }
            }
            if (bulkState.running || bulkState.message.isNotBlank()) {
                Spacer(Modifier.height(8.dp))
                if (bulkState.running && bulkState.discoveredVideos > 0) {
                    val progress = (bulkState.processedVideos.toFloat() / bulkState.discoveredVideos.toFloat()).coerceIn(0f, 1f)
                    LinearProgressIndicator(progress = { progress }, modifier = Modifier.fillMaxWidth())
                    Spacer(Modifier.height(4.dp))
                }
                Text(
                    bulkState.message + if (bulkState.currentTitle.isNotBlank()) "\n${bulkState.currentTitle.take(80)}" else "",
                    fontSize = 11.sp,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
            Spacer(Modifier.height(8.dp))
            if (transcript == null || transcript.cues.isEmpty()) {
                Text(
                    "Caption text will appear here when CC is captured or extracted.",
                    fontSize = 13.sp,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            } else {
                val timedParagraphs = remember(transcript) { buildTimedTranscriptParagraphs(transcript.cues) }
                val listState = rememberLazyListState()
                var followPlayback by remember(transcript) { mutableStateOf(true) }
                var autoScrollInProgress by remember(transcript) { mutableStateOf(false) }
                val activeIndex = remember(playbackPositionMs, timedParagraphs) {
                    timedParagraphs.indexOfLast { it.startMs <= playbackPositionMs }.coerceAtLeast(0)
                }

                LaunchedEffect(listState.isScrollInProgress) {
                    if (listState.isScrollInProgress && !autoScrollInProgress) {
                        followPlayback = false
                    }
                }
                LaunchedEffect(activeIndex, followPlayback, timedParagraphs.size) {
                    if (followPlayback && timedParagraphs.isNotEmpty() && activeIndex in timedParagraphs.indices) {
                        autoScrollInProgress = true
                        try {
                            listState.animateScrollToItem(activeIndex, scrollOffset = -24)
                        } finally {
                            autoScrollInProgress = false
                        }
                    }
                }

                if (!followPlayback) {
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.End) {
                        FilledTonalButton(onClick = { followPlayback = true }) {
                            Text("▶ Follow playback", fontSize = 12.sp)
                        }
                    }
                    Spacer(Modifier.height(6.dp))
                }

                LazyColumn(
                    state = listState,
                    modifier = Modifier.fillMaxWidth().heightIn(max = 420.dp),
                    verticalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    itemsIndexed(
                        items = timedParagraphs,
                        key = { index, paragraph -> "${paragraph.startMs}:$index" }
                    ) { index, paragraph ->
                        val isActive = index == activeIndex
                        Surface(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clickable {
                                    followPlayback = true
                                    onSeekTo(paragraph.startMs)
                                },
                            shape = MaterialTheme.shapes.medium,
                            color = if (isActive) MaterialTheme.colorScheme.primaryContainer
                                    else Color.Transparent,
                            tonalElevation = if (isActive) 2.dp else 0.dp
                        ) {
                            Column(Modifier.padding(horizontal = 10.dp, vertical = 8.dp)) {
                                Text(
                                    text = formatTranscriptTimestamp(paragraph.startMs),
                                    fontSize = (textSizeSp * 0.78f).coerceAtLeast(10f).sp,
                                    fontWeight = FontWeight.Bold,
                                    color = if (isActive) MaterialTheme.colorScheme.onPrimaryContainer
                                            else MaterialTheme.colorScheme.primary
                                )
                                Spacer(Modifier.height(3.dp))
                                SelectionContainer {
                                    Text(
                                        text = paragraph.text,
                                        fontSize = textSizeSp.sp,
                                        lineHeight = (textSizeSp * 1.45f).sp,
                                        fontWeight = if (isActive) FontWeight.SemiBold else FontWeight.Normal,
                                        color = if (isActive) MaterialTheme.colorScheme.onPrimaryContainer
                                                else MaterialTheme.colorScheme.onSurface
                                    )
                                }
                            }
                        }
                    }
                }
                Spacer(Modifier.height(10.dp))
                Text(
                    if (transcript.complete) "Complete caption track • tap any paragraph to seek • saved for search"
                    else "Capturing captions as this video plays • tap any paragraph to seek • saved for search",
                    fontSize = 11.sp,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
        }
    }
}

private data class TimedTranscriptParagraph(
    val startMs: Long,
    val text: String
)

/**
 * Groups the small cues produced by VTT/CC into readable timestamped paragraphs.
 * A paragraph ends at sentence punctuation, a noticeable speech gap, or after a
 * small number of cues so long caption tracks remain easy to scan.
 */
private fun buildTimedTranscriptParagraphs(
    cues: List<com.tebogo.markvault.data.VideoTranscriptStore.Cue>
): List<TimedTranscriptParagraph> {
    if (cues.isEmpty()) return emptyList()

    val result = mutableListOf<TimedTranscriptParagraph>()
    var paragraphStart = cues.first().startMs.coerceAtLeast(0L)
    val text = StringBuilder()
    var cueCount = 0
    var previousEnd = cues.first().startMs

    fun flush() {
        val clean = text.toString().replace(Regex("\\s+"), " ").trim()
        if (clean.isNotBlank()) result += TimedTranscriptParagraph(paragraphStart, clean)
        text.clear()
        cueCount = 0
    }

    cues.forEach { cue ->
        val cleanCue = cue.text.replace(Regex("\\s+"), " ").trim()
        if (cleanCue.isBlank()) return@forEach

        val gapMs = (cue.startMs - previousEnd).coerceAtLeast(0L)
        if (text.isNotEmpty() && gapMs >= 1_800L) {
            flush()
            paragraphStart = cue.startMs.coerceAtLeast(0L)
        } else if (text.isEmpty()) {
            paragraphStart = cue.startMs.coerceAtLeast(0L)
        }

        if (text.isNotEmpty()) text.append(' ')
        text.append(cleanCue)
        cueCount++
        previousEnd = cue.endMs.coerceAtLeast(cue.startMs)

        val sentenceEnded = cleanCue.lastOrNull() in listOf('.', '!', '?')
        if ((sentenceEnded && cueCount >= 2) || cueCount >= 4) flush()
    }
    flush()
    return result
}

private fun formatTranscriptTimestamp(positionMs: Long): String {
    val totalSeconds = positionMs.coerceAtLeast(0L) / 1_000L
    val hours = totalSeconds / 3_600L
    val minutes = (totalSeconds % 3_600L) / 60L
    val seconds = totalSeconds % 60L
    return if (hours > 0L) {
        "[%d:%02d:%02d]".format(hours, minutes, seconds)
    } else {
        "[%02d:%02d]".format(minutes, seconds)
    }
}

private enum class LyricsLoadState { HIDDEN, LOADING, FETCHING, READY, UNAVAILABLE }

private data class KaraokeLine(
    val text: String,
    val isSection: Boolean,
    val startMs: Long,
    val endMs: Long
)

private fun isLyricsSectionLabel(text: String): Boolean = text.matches(
    Regex(
        "^\\((?:(?:PRE-)?CHORUS(?:\\s+\\d+)?|BRIDGE(?:\\s+\\d+)?|VERSE(?:\\s+\\d+)?|INTRO|OUTRO|REFRAIN)\\)$",
        RegexOption.IGNORE_CASE
    )
)

/**
 * Builds a deterministic line timeline for plain JW.org lyrics.
 *
 * The lyric cache contains text, not timed-lyric metadata. We therefore reserve
 * a small intro/outro margin and distribute the playable span across sung lines
 * using word count as the weight. Section labels remain visible but never become
 * active karaoke lines. This gives karaoke mode a real progressing highlight
 * without altering the audio or inventing persistent timestamp metadata.
 */
private fun buildKaraokeLines(text: String, durationMs: Long): List<KaraokeLine> {
    val raw = text.lineSequence().map { it.trim() }.filter { it.isNotEmpty() }.toList()
    if (raw.isEmpty()) return emptyList()
    val sung = raw.filterNot(::isLyricsSectionLabel)
    if (sung.isEmpty() || durationMs <= 0L)
        return raw.map { KaraokeLine(it, isLyricsSectionLabel(it), 0L, 0L) }

    // v5.4.297cc — Better automatic alignment for untimed JW lyrics. Instead
    // of word-count alone, estimate sung duration from vowel groups (a useful
    // proxy for syllables), long words, punctuation pauses and section breaks.
    // Keep margins conservative so short songs do not lose a large percentage
    // of their timeline. Exact timed lyrics, if JW supplies them in future,
    // can replace this estimator without changing the UI.
    val introMs = (durationMs * 0.035).toLong().coerceIn(1_000L, 10_000L)
    val outroMs = (durationMs * 0.015).toLong().coerceIn(500L, 5_000L)
    val usableMs = (durationMs - introMs - outroMs).coerceAtLeast(sung.size * 450L)

    fun weight(line: String): Double {
        val words = line.split(Regex("\\s+")).filter { it.isNotBlank() }
        val syllableLike = Regex("(?i)[aeiouy]+")
            .findAll(line).count().coerceAtLeast(words.size)
        val longWordExtra = words.count { it.count(Char::isLetter) >= 8 } * 0.30
        val punctuationPause = when {
            line.endsWith("…") -> 1.10
            line.endsWith(".") || line.endsWith("!") || line.endsWith("?") -> 0.75
            line.endsWith(",") || line.endsWith(";") || line.endsWith(":") -> 0.35
            else -> 0.0
        }
        return syllableLike + longWordExtra + punctuationPause + 0.8
    }

    val weights = sung.map(::weight)
    val totalWeight = weights.sum().coerceAtLeast(1.0)
    var sungIndex = 0
    var cursor = introMs
    var previousWasSection = false
    return raw.map { line ->
        if (isLyricsSectionLabel(line)) {
            previousWasSection = true
            KaraokeLine(line, true, cursor, cursor)
        } else {
            if (previousWasSection && sungIndex > 0) {
                // Small musical breath at verse/chorus boundaries.
                cursor = (cursor + (durationMs * 0.004).toLong().coerceAtMost(1_200L))
                    .coerceAtMost(durationMs - outroMs)
            }
            previousWasSection = false
            val w = weights[sungIndex++]
            val slice = if (sungIndex == sung.size)
                (durationMs - outroMs - cursor).coerceAtLeast(450L)
            else
                (usableMs * (w / totalWeight)).toLong().coerceAtLeast(450L)
            KaraokeLine(line, false, cursor, (cursor + slice).coerceAtMost(durationMs)).also {
                cursor = it.endMs
            }
        }
    }
}

@Composable
private fun LyricsPanel(
    lyrics: CachedSongLyrics?,
    state: LyricsLoadState,
    karaokeEnabled: Boolean,
    playbackPositionMs: Long,
    durationMs: Long,
    onToggleKaraoke: () -> Unit,
    onSeekTo: (Long) -> Unit
) {
    val listState = rememberLazyListState()
    val karaokeLines = remember(lyrics?.text, lyrics?.timedLines, durationMs) {
        if (!lyrics?.timedLines.isNullOrEmpty()) {
            lyrics!!.timedLines.map { KaraokeLine(it.text, it.isSection, it.startMs, it.endMs) }
        } else {
            buildKaraokeLines(lyrics?.text.orEmpty(), durationMs)
        }
    }
    val activeIndex = remember(karaokeEnabled, karaokeLines, playbackPositionMs) {
        if (!karaokeEnabled || durationMs <= 0L) -1
        else karaokeLines.indexOfLast { line ->
            !line.isSection && playbackPositionMs >= line.startMs && playbackPositionMs < line.endMs
        }
    }

    LaunchedEffect(karaokeEnabled, activeIndex) {
        if (karaokeEnabled && activeIndex >= 0) {
            val target = (activeIndex - 2).coerceAtLeast(0)
            listState.animateScrollToItem(target)
        }
    }

    Surface(
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 16.dp, vertical = 8.dp),
        shape = MaterialTheme.shapes.large,
        tonalElevation = 2.dp,
        color = MaterialTheme.colorScheme.surfaceContainerLow
    ) {
        Column(modifier = Modifier.padding(18.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Text(
                    text = "Lyrics",
                    fontSize = 18.sp,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.primary
                )
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(
                        text = "Karaoke",
                        fontSize = 12.sp,
                        color = if (karaokeEnabled) MaterialTheme.colorScheme.primary
                                else MaterialTheme.colorScheme.onSurfaceVariant
                    )
                    Spacer(Modifier.width(6.dp))
                    Switch(
                        checked = karaokeEnabled,
                        onCheckedChange = { onToggleKaraoke() }
                    )
                }
            }
            Spacer(Modifier.height(10.dp))
            when (state) {
                LyricsLoadState.LOADING, LyricsLoadState.FETCHING -> {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        CircularProgressIndicator(
                            modifier = Modifier.size(20.dp),
                            strokeWidth = 2.dp
                        )
                        Spacer(Modifier.width(10.dp))
                        Text(
                            "Loading words from JW.ORG…",
                            fontSize = 13.sp,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }
                LyricsLoadState.READY -> {
                    if (karaokeEnabled && durationMs <= 0L) {
                        Text(
                            "Karaoke will start when the player reports the song duration.",
                            fontSize = 11.sp,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                            modifier = Modifier.padding(bottom = 8.dp)
                        )
                    }
                    LazyColumn(
                        state = listState,
                        modifier = Modifier
                            .fillMaxWidth()
                            .heightIn(max = 360.dp),
                        contentPadding = PaddingValues(vertical = 4.dp),
                        verticalArrangement = Arrangement.spacedBy(4.dp)
                    ) {
                        itemsIndexed(
                            items = karaokeLines,
                            key = { index, line -> "${index}_${line.text.hashCode()}" }
                        ) { index, line ->
                            val active = karaokeEnabled && index == activeIndex && !line.isSection
                            Surface(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .clickable(enabled = karaokeEnabled && !line.isSection && line.startMs > 0L) {
                                        onSeekTo(line.startMs)
                                    },
                                shape = MaterialTheme.shapes.medium,
                                color = if (active) MaterialTheme.colorScheme.primaryContainer
                                        else Color.Transparent
                            ) {
                                Column(
                                    modifier = Modifier.padding(
                                        horizontal = if (active) 10.dp else 2.dp,
                                        vertical = if (active) 8.dp else 3.dp
                                    )
                                ) {
                                    if (!line.isSection && line.startMs >= 0L) {
                                        Text(
                                            text = (if (lyrics?.timingExact == true) "" else "~") +
                                                formatTranscriptTimestamp(line.startMs),
                                            fontSize = 10.sp,
                                            fontWeight = FontWeight.Bold,
                                            color = if (active) MaterialTheme.colorScheme.onPrimaryContainer
                                                    else MaterialTheme.colorScheme.primary.copy(alpha = 0.82f)
                                        )
                                        Spacer(Modifier.height(2.dp))
                                    }
                                    Text(
                                        text = line.text,
                                        fontSize = if (line.isSection) 13.sp else if (active) 18.sp else 16.sp,
                                        lineHeight = if (active) 27.sp else 24.sp,
                                        fontWeight = when {
                                            line.isSection -> FontWeight.Bold
                                            active -> FontWeight.Bold
                                            karaokeEnabled && index < activeIndex -> FontWeight.Normal
                                            else -> FontWeight.Normal
                                        },
                                        color = when {
                                            line.isSection -> MaterialTheme.colorScheme.primary
                                            active -> MaterialTheme.colorScheme.onPrimaryContainer
                                            karaokeEnabled && activeIndex >= 0 && index < activeIndex ->
                                                MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.65f)
                                            else -> MaterialTheme.colorScheme.onSurface
                                        }
                                    )
                                }
                            }
                        }
                    }
                    if (!lyrics?.sourceUrl.isNullOrBlank()) {
                        Spacer(Modifier.height(12.dp))
                        Text(
                            when {
                                lyrics?.timingExact == true -> "JW timed lyrics • Cached from JW.ORG"
                                !lyrics?.timedLines.isNullOrEmpty() -> "~ estimated timing • Lyrics cached from JW.ORG"
                                else -> "Lyrics cached from JW.ORG"
                            },
                            fontSize = 11.sp,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }
                LyricsLoadState.UNAVAILABLE -> Text(
                    "Lyrics could not be found for this song.",
                    fontSize = 13.sp,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
                LyricsLoadState.HIDDEN -> Unit
            }
        }
    }
}
