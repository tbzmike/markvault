package com.tebogo.markvault.ui

import android.app.Activity
import android.content.pm.ActivityInfo
import android.os.Build
import android.util.Rational
import android.view.View
import android.widget.FrameLayout
import androidx.activity.compose.BackHandler
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.PictureInPicture
import androidx.compose.material.icons.filled.Subtitles
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.media3.common.C
import androidx.media3.common.MediaItem as ExoMediaItem
import androidx.media3.common.Player
import androidx.media3.common.TrackSelectionOverride
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.ui.PlayerView
import com.tebogo.markvault.AppViewModel

/**
 * v5.4.215cc — Full-featured media player.
 *
 * Features:
 *   • All standard controls via PlayerView.useController = true
 *     (play/pause, seek bar, +10s / -10s, duration, speed, auto-hide)
 *   • Fullscreen button → landscape orientation + hidden system bars
 *   • BackHandler exits fullscreen before navigating back
 *   • Picture-in-Picture (Android 8+) via toolbar button
 *   • Landscape auto-rotate when fullscreen is entered
 *   • Track selection dialog for subtitles and audio tracks
 */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun MediaPlayerScreen(
    vm: AppViewModel,
    nav: androidx.navigation.NavController,
    mediaId: Long
) {
    val ctx      = LocalContext.current
    val activity = remember(ctx) { ctx as? Activity }
    val item     by vm.nowPlayingMedia.collectAsStateWithLifecycle()

    // ── Player ────────────────────────────────────────────────────────────────
    val player = remember { ExoPlayer.Builder(ctx).build() }
    DisposableEffect(Unit) {
        onDispose {
            item?.let { vm.updateMediaPlayback(it.id, player.currentPosition) }
            player.release()
        }
    }

    LaunchedEffect(mediaId) {
        val url = item?.localPath?.ifBlank { null } ?: item?.streamUrl ?: return@LaunchedEffect
        player.setMediaItem(ExoMediaItem.fromUri(url))
        player.prepare()
        item?.resumePositionMs?.takeIf { it > 0 }?.let { player.seekTo(it) }
        player.playWhenReady = true
    }

    // ── Track state (observed via Player.Listener) ─────────────────────────
    var currentTracks by remember { mutableStateOf(player.currentTracks) }
    DisposableEffect(player) {
        val listener = object : Player.Listener {
            override fun onTracksChanged(tracks: androidx.media3.common.Tracks) {
                currentTracks = tracks
            }
        }
        player.addListener(listener)
        onDispose { player.removeListener(listener) }
    }

    val audioGroups = remember(currentTracks) {
        currentTracks.groups.filter { it.type == C.TRACK_TYPE_AUDIO && it.isSupported }
    }
    val textGroups = remember(currentTracks) {
        currentTracks.groups.filter { it.type == C.TRACK_TYPE_TEXT && it.isSupported }
    }
    val hasSelectableTracks = audioGroups.size + textGroups.size > 0

    // ── Fullscreen / PiP state ────────────────────────────────────────────
    var isFullscreen by remember { mutableStateOf(false) }
    var showTrackDialog by remember { mutableStateOf(false) }

    // ── Helpers ────────────────────────────────────────────────────────────
    fun enterFullscreen() {
        isFullscreen = true
        activity?.requestedOrientation = ActivityInfo.SCREEN_ORIENTATION_SENSOR_LANDSCAPE
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
            activity?.window?.insetsController?.hide(
                android.view.WindowInsets.Type.systemBars()
            )
        } else {
            @Suppress("DEPRECATION")
            activity?.window?.decorView?.systemUiVisibility = (
                View.SYSTEM_UI_FLAG_FULLSCREEN or
                View.SYSTEM_UI_FLAG_HIDE_NAVIGATION or
                View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY
            )
        }
    }

    fun exitFullscreen() {
        isFullscreen = false
        activity?.requestedOrientation = ActivityInfo.SCREEN_ORIENTATION_UNSPECIFIED
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
            activity?.window?.insetsController?.show(
                android.view.WindowInsets.Type.systemBars()
            )
        } else {
            @Suppress("DEPRECATION")
            activity?.window?.decorView?.systemUiVisibility = View.SYSTEM_UI_FLAG_VISIBLE
        }
    }

    // Back press in fullscreen → exit fullscreen first
    BackHandler(enabled = isFullscreen) { exitFullscreen() }

    // ── Main UI ────────────────────────────────────────────────────────────
    if (isFullscreen) {
        // Pure fullscreen: only the PlayerView, no Scaffold chrome
        Box(modifier = Modifier.fillMaxSize().background(Color.Black)) {
            AndroidView(
                factory = { c ->
                    PlayerView(c).apply {
                        this.player = player
                        useController = true
                        setFullscreenButtonClickListener { _ -> exitFullscreen() }
                        layoutParams = FrameLayout.LayoutParams(
                            FrameLayout.LayoutParams.MATCH_PARENT,
                            FrameLayout.LayoutParams.MATCH_PARENT
                        )
                    }
                },
                modifier = Modifier.fillMaxSize()
            )
        }
    } else {
        Scaffold(
            topBar = {
                TopAppBar(
                    title = {
                        Text(item?.title ?: "Media Player", maxLines = 1, fontSize = 15.sp)
                    },
                    navigationIcon = {
                        IconButton(onClick = {
                            item?.let { vm.updateMediaPlayback(it.id, player.currentPosition) }
                            nav.popBackStack()
                        }) { Icon(Icons.Default.ArrowBack, contentDescription = "Back") }
                    },
                    actions = {
                        // Picture-in-Picture button (Android 8+)
                        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                            IconButton(onClick = {
                                activity?.let { act ->
                                    @Suppress("NewApi")
                                    val params = android.app.PictureInPictureParams.Builder()
                                        .setAspectRatio(Rational(16, 9))
                                        .apply {
                                            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
                                                setAutoEnterEnabled(true)
                                            }
                                        }
                                        .build()
                                    act.enterPictureInPictureMode(params)
                                }
                            }) {
                                Icon(
                                    Icons.Default.PictureInPicture,
                                    contentDescription = "Picture in Picture"
                                )
                            }
                        }
                        // Track selection button (subtitles / audio language)
                        if (hasSelectableTracks) {
                            IconButton(onClick = { showTrackDialog = true }) {
                                Icon(Icons.Default.Subtitles, contentDescription = "Tracks")
                            }
                        }
                    }
                )
            }
        ) { pad ->
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(pad)
                    .verticalScroll(rememberScrollState())
            ) {
                // ── Player surface ──────────────────────────────────────────
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .then(
                            if (item?.mediaType == "video") Modifier.aspectRatio(16f / 9f)
                            else Modifier.height(200.dp)
                        )
                        .background(Color.Black)
                ) {
                    AndroidView(
                        factory = { c ->
                            PlayerView(c).apply {
                                this.player = player
                                useController = true
                                // Fullscreen button → landscape + hidden bars
                                setFullscreenButtonClickListener { _ -> enterFullscreen() }
                                layoutParams = FrameLayout.LayoutParams(
                                    FrameLayout.LayoutParams.MATCH_PARENT,
                                    FrameLayout.LayoutParams.MATCH_PARENT
                                )
                            }
                        },
                        modifier = Modifier.fillMaxSize()
                    )
                }

                // ── Metadata ────────────────────────────────────────────────
                item?.let { m ->
                    Column(modifier = Modifier.padding(16.dp)) {
                        Text(m.title, fontWeight = FontWeight.Bold, fontSize = 17.sp)
                        if (m.description.isNotBlank()) {
                            Spacer(Modifier.height(6.dp))
                            Text(m.description, fontSize = 13.sp,
                                color = MaterialTheme.colorScheme.onSurfaceVariant)
                        }
                        if (m.scriptureRefs.isNotBlank()) {
                            Spacer(Modifier.height(6.dp))
                            Text("📖 ${m.scriptureRefs}", fontSize = 12.sp,
                                color = MaterialTheme.colorScheme.primary)
                        }
                        if (m.category.isNotBlank()) {
                            Spacer(Modifier.height(4.dp))
                            Text(m.category, fontSize = 11.sp,
                                color = MaterialTheme.colorScheme.onSurfaceVariant)
                        }
                    }
                }
            }
        }
    }

    // ── Track selection dialog ─────────────────────────────────────────────
    if (showTrackDialog) {
        AlertDialog(
            onDismissRequest = { showTrackDialog = false },
            title = { Text("Select Track") },
            text = {
                LazyColumn {
                    if (audioGroups.isNotEmpty()) {
                        item { Text("🔊 Audio", fontWeight = FontWeight.SemiBold,
                            fontSize = 12.sp, modifier = Modifier.padding(vertical = 4.dp)) }
                        audioGroups.forEach { group ->
                            items(group.length) { trackIndex ->
                                val fmt      = group.getTrackFormat(trackIndex)
                                val selected = group.isTrackSelected(trackIndex)
                                val label    = fmt.label?.ifBlank { null }
                                    ?: fmt.language?.ifBlank { null }
                                    ?: "Audio ${trackIndex + 1}"
                                Row(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .padding(vertical = 4.dp),
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    RadioButton(selected = selected, onClick = {
                                        player.trackSelectionParameters =
                                            player.trackSelectionParameters.buildUpon()
                                                .setOverrideForType(
                                                    TrackSelectionOverride(
                                                        group.mediaTrackGroup, listOf(trackIndex)
                                                    )
                                                ).build()
                                    })
                                    Text(label, fontSize = 14.sp)
                                }
                            }
                        }
                    }
                    if (textGroups.isNotEmpty()) {
                        item { Text("💬 Subtitles", fontWeight = FontWeight.SemiBold,
                            fontSize = 12.sp, modifier = Modifier.padding(vertical = 4.dp)) }
                        // "Off" option
                        item {
                            Row(
                                modifier = Modifier.fillMaxWidth().padding(vertical = 4.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                val noneSelected = textGroups.none { g ->
                                    (0 until g.length).any { g.isTrackSelected(it) }
                                }
                                RadioButton(selected = noneSelected, onClick = {
                                    player.trackSelectionParameters =
                                        player.trackSelectionParameters.buildUpon()
                                            .clearOverridesOfType(C.TRACK_TYPE_TEXT)
                                            .setTrackTypeDisabled(C.TRACK_TYPE_TEXT, true)
                                            .build()
                                })
                                Text("Off", fontSize = 14.sp)
                            }
                        }
                        textGroups.forEach { group ->
                            items(group.length) { trackIndex ->
                                val fmt      = group.getTrackFormat(trackIndex)
                                val selected = group.isTrackSelected(trackIndex)
                                val label    = fmt.label?.ifBlank { null }
                                    ?: fmt.language?.ifBlank { null }
                                    ?: "Subtitle ${trackIndex + 1}"
                                Row(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .padding(vertical = 4.dp),
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    RadioButton(selected = selected, onClick = {
                                        player.trackSelectionParameters =
                                            player.trackSelectionParameters.buildUpon()
                                                .setTrackTypeDisabled(C.TRACK_TYPE_TEXT, false)
                                                .setOverrideForType(
                                                    TrackSelectionOverride(
                                                        group.mediaTrackGroup, listOf(trackIndex)
                                                    )
                                                ).build()
                                    })
                                    Text(label, fontSize = 14.sp)
                                }
                            }
                        }
                    }
                }
            },
            confirmButton = {
                TextButton(onClick = { showTrackDialog = false }) { Text("Done") }
            }
        )
    }
}
