package com.tebogo.markvault.ui

import android.app.Activity
import android.content.pm.ActivityInfo
import android.os.Build
import android.util.Rational
import android.view.View
import android.widget.FrameLayout
import androidx.activity.compose.BackHandler
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.media3.common.C
import androidx.media3.common.Player
import androidx.media3.common.TrackSelectionOverride
import androidx.media3.ui.PlayerView
import com.tebogo.markvault.AppViewModel
import com.tebogo.markvault.data.CachedSongLyrics
import com.tebogo.markvault.data.MediaItem
import com.tebogo.markvault.data.SongLyricsCache

/**
 * v5.4.233cc — Full-screen media player.
 *
 * Attaches to the SHARED MediaController (owned by PlaybackService) rather
 * than creating its own ExoPlayer — playback already started (from
 * wherever the user tapped Play) survives this screen opening, closing,
 * or the app backgrounding entirely, and the system notification keeps
 * working regardless of whether this screen is even open.
 *
 * Features: play/pause/seek (via PlayerView's built-in controls),
 * fullscreen (landscape + hidden system bars), Picture-in-Picture,
 * BackHandler exits fullscreen before navigating back, audio/subtitle
 * track selection.
 */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun MediaPlayerScreen(
    vm: AppViewModel,
    nav: androidx.navigation.NavController,
    mediaId: Long
) {
    val ctx      = LocalContext.current
    val activity = remember(ctx) { ctx as? Activity }
    val item     by vm.nowPlayingMedia.collectAsStateWithLifecycle()

    // v5.4.233cc — Poll for the shared controller becoming ready (async
    // connection to PlaybackService). No local ExoPlayer is created here.
    var controller by remember { mutableStateOf<Player?>(null) }
    LaunchedEffect(Unit) {
        var waited = 0
        while (controller == null && waited < 3000) {
            controller = vm.getMediaController()
            if (controller == null) {
                kotlinx.coroutines.delay(50L)
                waited += 50
            }
        }
    }

    // v5.4.233cc — Surface playback failures instead of failing silently.
    var playerError by remember { mutableStateOf<String?>(null) }

    // ── Track state (for the track-selection dialog) + error listener ──────
    var currentTracks by remember { mutableStateOf<androidx.media3.common.Tracks?>(null) }
    DisposableEffect(controller) {
        val c = controller
        if (c == null) return@DisposableEffect onDispose {}
        currentTracks = c.currentTracks
        playerError = null
        val listener = object : Player.Listener {
            override fun onTracksChanged(tracks: androidx.media3.common.Tracks) {
                currentTracks = tracks
            }
            override fun onPlayerError(error: androidx.media3.common.PlaybackException) {
                playerError = error.message ?: "Playback failed"
            }
        }
        c.addListener(listener)
        onDispose { c.removeListener(listener) }
    }
    val audioGroups = remember(currentTracks) {
        currentTracks?.groups?.filter { it.type == C.TRACK_TYPE_AUDIO && it.isSupported } ?: emptyList()
    }
    val textGroups = remember(currentTracks) {
        currentTracks?.groups?.filter { it.type == C.TRACK_TYPE_TEXT && it.isSupported } ?: emptyList()
    }
    val hasSelectableTracks = audioGroups.size + textGroups.size > 0

    // ── Fullscreen / PiP state ──────────────────────────────────────────────
    var isFullscreen by remember { mutableStateOf(false) }
    var showTrackDialog by remember { mutableStateOf(false) }
    // v5.4.255cc — Now Playing Queue sheet toggle.
    var showQueueSheet by remember { mutableStateOf(false) }

    // v5.4.279cc — Song lyrics use the otherwise-empty lower half of the
    // audio player. Cached copies live in app-internal storage so reopening
    // a song does not hit JW.org again. Cache misses are resolved directly
    // from the official JW.org song collection/article pages on Dispatchers.IO;
    // playback itself never owns or waits on a hidden WebView.
    var lyrics by remember(item?.id, item?.jwKey) { mutableStateOf<CachedSongLyrics?>(null) }
    var lyricsState by remember(item?.id, item?.jwKey) { mutableStateOf(LyricsLoadState.HIDDEN) }
    LaunchedEffect(item?.id, item?.jwKey, item?.title, item?.category, item?.streamUrl) {
        val current = item
        if (current == null || !SongLyricsCache.isLyricsEligible(current)) {
            lyrics = null
            lyricsState = LyricsLoadState.HIDDEN
            return@LaunchedEffect
        }
        lyricsState = LyricsLoadState.LOADING
        val cached = SongLyricsCache.load(ctx, current)
        if (cached != null) {
            lyrics = cached
            lyricsState = LyricsLoadState.READY
            return@LaunchedEffect
        }

        lyrics = null
        lyricsState = LyricsLoadState.FETCHING
        val fetched = SongLyricsCache.fetchFromJw(current)
        if (fetched != null) {
            SongLyricsCache.save(ctx, current, fetched)
            // The player may have advanced while the network request was in flight.
            val active = item
            if (active != null && active.id == current.id && active.jwKey == current.jwKey) {
                lyrics = fetched
                lyricsState = LyricsLoadState.READY
            }
        } else {
            val active = item
            if (active != null && active.id == current.id && active.jwKey == current.jwKey) {
                lyricsState = LyricsLoadState.UNAVAILABLE
            }
        }
    }
    // v5.4.290cc — Video transcript display. The transcript is written by
    // PlaybackService / complete VTT extraction, then observed here independently
    // of the article-search pipeline. Polling is deliberately lightweight and only
    // active while a video is the current media item.
    var videoTranscript by remember(item?.id, item?.jwKey) {
        mutableStateOf<com.tebogo.markvault.data.VideoTranscriptStore.Transcript?>(null)
    }
    var transcriptTextSize by rememberSaveable { mutableStateOf(16f) }
    LaunchedEffect(item?.id, item?.jwKey, item?.mediaType) {
        val current = item
        if (current == null || !current.mediaType.equals("video", ignoreCase = true)) {
            videoTranscript = null
            return@LaunchedEffect
        }
        while (true) {
            videoTranscript = com.tebogo.markvault.data.VideoTranscriptStore.load(ctx, current)
            kotlinx.coroutines.delay(1_000L)
        }
    }

    // v5.4.235cc — Video quality picker. qualityOptions is "label\turl" per
    // line, highest resolution first (see JwMediaApi.allQualityOptions).
    var showQualityDialog by remember { mutableStateOf(false) }
    val qualityChoices = remember(item?.qualityOptions) {
        item?.qualityOptions.orEmpty()
            .split("\n")
            .mapNotNull { line ->
                val parts = line.split("\t", limit = 2)
                if (parts.size == 2 && parts[1].isNotBlank()) parts[0] to parts[1] else null
            }
    }

    fun enterFullscreen() {
        isFullscreen = true
        activity?.requestedOrientation = ActivityInfo.SCREEN_ORIENTATION_SENSOR_LANDSCAPE
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
            activity?.window?.insetsController?.hide(android.view.WindowInsets.Type.systemBars())
        } else {
            @Suppress("DEPRECATION")
            activity?.window?.decorView?.systemUiVisibility = (
                View.SYSTEM_UI_FLAG_FULLSCREEN or
                View.SYSTEM_UI_FLAG_HIDE_NAVIGATION or
                View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY
            )
        }
    }

    fun exitFullscreen() {
        isFullscreen = false
        activity?.requestedOrientation = ActivityInfo.SCREEN_ORIENTATION_UNSPECIFIED
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
            activity?.window?.insetsController?.show(android.view.WindowInsets.Type.systemBars())
        } else {
            @Suppress("DEPRECATION")
            activity?.window?.decorView?.systemUiVisibility = View.SYSTEM_UI_FLAG_VISIBLE
        }
    }

    /**
     * v5.4.235cc — Switch playback to a different quality URL, preserving
     * the current playback position so switching feels seamless rather
     * than restarting from zero.
     */
    fun switchQuality(url: String) {
        val c = controller ?: return
        val resumeAt = c.currentPosition.coerceAtLeast(0L)
        val wasPlaying = c.isPlaying
        val exo = androidx.media3.common.MediaItem.Builder()
            .setUri(url)
            .apply {
                item?.mimeType?.takeIf { it.isNotBlank() }?.let { setMimeType(it) }
                item?.id?.let { setMediaId(it.toString()) }
                val current = item
                if (current != null && current.subtitleUrl.isNotBlank() &&
                    current.mediaType.equals("video", ignoreCase = true)) {
                    val subtitle = androidx.media3.common.MediaItem.SubtitleConfiguration.Builder(
                        android.net.Uri.parse(current.subtitleUrl)
                    )
                        .setMimeType(androidx.media3.common.MimeTypes.TEXT_VTT)
                        .setSelectionFlags(androidx.media3.common.C.SELECTION_FLAG_DEFAULT)
                        .build()
                    setSubtitleConfigurations(listOf(subtitle))
                }
            }
            .setMediaMetadata(
                androidx.media3.common.MediaMetadata.Builder()
                    .setTitle(item?.title ?: "")
                    .build()
            )
            .build()
        c.setMediaItem(exo, resumeAt)
        c.prepare()
        c.playWhenReady = wasPlaying
    }

    fun shareMedia() {
        val m = item ?: return
        val shareUrl = m.localPath.ifBlank { m.streamUrl }
        if (shareUrl.isBlank()) return
        val text = if (m.title.isNotBlank()) "${m.title}\n$shareUrl" else shareUrl
        val sendIntent = android.content.Intent(android.content.Intent.ACTION_SEND).apply {
            type = "text/plain"
            putExtra(android.content.Intent.EXTRA_TEXT, text)
            if (m.title.isNotBlank()) putExtra(android.content.Intent.EXTRA_SUBJECT, m.title)
        }
        runCatching {
            ctx.startActivity(android.content.Intent.createChooser(sendIntent, "Share"))
        }
    }

    BackHandler(enabled = isFullscreen) { exitFullscreen() }

    if (isFullscreen) {
        Box(modifier = Modifier.fillMaxSize().background(Color.Black)) {
            AndroidView(
                factory = { c ->
                    PlayerView(c).apply {
                        this.player = controller
                        useController = true
                        setFullscreenButtonClickListener { _ -> exitFullscreen() }
                        layoutParams = FrameLayout.LayoutParams(
                            FrameLayout.LayoutParams.MATCH_PARENT,
                            FrameLayout.LayoutParams.MATCH_PARENT
                        )
                    }
                },
                update = { it.player = controller },
                modifier = Modifier.fillMaxSize()
            )
        }
    } else {
        Scaffold(
            topBar = {
                TopAppBar(
                    title = { Text(item?.title ?: "Media Player", maxLines = 1, fontSize = 15.sp) },
                    navigationIcon = {
                        IconButton(onClick = { nav.popBackStack() }) {
                            Text("\u2190", fontSize = 20.sp)
                        }
                    },
                    actions = {
                        // v5.4.261cc — CastButton now delegates discovery,
                        // route selection, and session UI to Google's official
                        // MediaRouteButton/CastButtonFactory integration.
                        CastButton()
                        // v5.4.254cc — Favourite toggle for the currently
                        // playing item, right next to Cast so it's reachable
                        // while actually watching/listening — the most
                        // natural place to favourite something.
                        item?.let { m ->
                            IconButton(onClick = { vm.toggleMediaFavourite(m) }) {
                                Text(
                                    if (m.isFavourite == 1) "\u2B50" else "\u2606",
                                    fontSize = 20.sp
                                )
                            }
                        }
                        // Picture-in-Picture (Android 8+)
                        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                            IconButton(onClick = {
                                activity?.let { act ->
                                    @Suppress("NewApi")
                                    val params = android.app.PictureInPictureParams.Builder()
                                        .setAspectRatio(Rational(16, 9))
                                        .apply {
                                            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
                                                setAutoEnterEnabled(true)
                                            }
                                        }
                                        .build()
                                    act.enterPictureInPictureMode(params)
                                }
                            }) {
                                Text("\u2922", fontSize = 18.sp)
                            }
                        }
                        if (hasSelectableTracks) {
                            IconButton(onClick = { showTrackDialog = true }) {
                                Text("CC", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                            }
                        }
                        // v5.4.235cc — Video quality picker. Only shown when
                        // more than one resolution is actually available.
                        if (qualityChoices.size > 1) {
                            IconButton(onClick = { showQualityDialog = true }) {
                                Text("\u2699", fontSize = 16.sp)
                            }
                        }
                        // v5.4.235cc — Share the media link via the system
                        // share sheet.
                        IconButton(onClick = { shareMedia() }) {
                            Text("\u2197", fontSize = 16.sp)
                        }
                    }
                )
            }
        ) { pad ->
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(pad)
                    .verticalScroll(rememberScrollState())
            ) {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .then(
                            if (item?.mediaType == "video") Modifier.aspectRatio(16f / 9f)
                            else Modifier.height(200.dp)
                        )
                        .background(Color.Black)
                ) {
                    if (controller == null) {
                        Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                            CircularProgressIndicator(color = Color.White)
                        }
                    } else {
                        AndroidView(
                            factory = { c ->
                                PlayerView(c).apply {
                                    this.player = controller
                                    useController = true
                                    setFullscreenButtonClickListener { _ -> enterFullscreen() }
                                    layoutParams = FrameLayout.LayoutParams(
                                        FrameLayout.LayoutParams.MATCH_PARENT,
                                        FrameLayout.LayoutParams.MATCH_PARENT
                                    )
                                }
                            },
                            update = { it.player = controller },
                            modifier = Modifier.fillMaxSize()
                        )
                    }
                }

                playerError?.let { err ->
                    Surface(
                        color = MaterialTheme.colorScheme.errorContainer,
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Text(
                            "\u26A0\uFE0F $err",
                            color = MaterialTheme.colorScheme.onErrorContainer,
                            fontSize = 13.sp,
                            modifier = Modifier.padding(12.dp)
                        )
                    }
                }

                // v5.4.255cc — Queue transport controls. Continuous play
                // (auto-advance through a multi-item queue) is Media3's
                // own default Player behavior once vm.playQueue()/
                // playMediaFromList() loads more than one item — these
                // buttons expose manual control over that same queue, and
                // work identically whether the active player is local or
                // Chromecast (both implement the same Player interface;
                // PlaybackService carries the whole queue across on
                // cast connect/disconnect).
                if (item != null) {
                    val shuffleOn by vm.shuffleEnabled.collectAsStateWithLifecycle()
                    val repeatModeState by vm.repeatMode.collectAsStateWithLifecycle()
                    val queueState by vm.currentQueue.collectAsStateWithLifecycle()
                    Row(
                        modifier = Modifier.fillMaxWidth().padding(vertical = 4.dp),
                        horizontalArrangement = Arrangement.SpaceEvenly,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        IconButton(onClick = { vm.toggleShuffle() }) {
                            Text(
                                "\uD83D\uDD00",
                                fontSize = 18.sp,
                                color = if (shuffleOn) MaterialTheme.colorScheme.primary
                                        else MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                        IconButton(onClick = { vm.playPreviousInQueue() }) {
                            Text("\u23EE", fontSize = 20.sp)
                        }
                        IconButton(onClick = { vm.playNextInQueue() }) {
                            Text("\u23ED", fontSize = 20.sp)
                        }
                        IconButton(onClick = { vm.cycleRepeatMode() }) {
                            Text(
                                if (repeatModeState == androidx.media3.common.Player.REPEAT_MODE_ONE) "\uD83D\uDD02" else "\uD83D\uDD01",
                                fontSize = 18.sp,
                                color = if (repeatModeState != androidx.media3.common.Player.REPEAT_MODE_OFF) MaterialTheme.colorScheme.primary
                                        else MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                        IconButton(onClick = { showQueueSheet = true }) {
                            Text(
                                "\u2630",
                                fontSize = 18.sp,
                                color = if (queueState.size > 1) MaterialTheme.colorScheme.primary
                                        else MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    }
                }

                item?.let { m ->
                    Column(modifier = Modifier.padding(16.dp)) {
                        Text(m.title, fontWeight = FontWeight.Bold, fontSize = 17.sp)
                        if (m.description.isNotBlank()) {
                            Spacer(Modifier.height(6.dp))
                            Text(m.description, fontSize = 13.sp,
                                color = MaterialTheme.colorScheme.onSurfaceVariant)
                        }
                        if (m.scriptureRefs.isNotBlank()) {
                            Spacer(Modifier.height(6.dp))
                            Text("\uD83D\uDCD6 ${m.scriptureRefs}", fontSize = 12.sp,
                                color = MaterialTheme.colorScheme.primary)
                        }
                        if (m.category.isNotBlank()) {
                            Spacer(Modifier.height(4.dp))
                            Text(m.category, fontSize = 11.sp,
                                color = MaterialTheme.colorScheme.onSurfaceVariant)
                        }
                        Spacer(Modifier.height(4.dp))
                        Text(
                            "\uD83D\uDD0A Playing in background \u2014 controls available in your notification panel",
                            fontSize = 11.sp,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }

                    if (SongLyricsCache.isLyricsEligible(m)) {
                        LyricsPanel(lyrics = lyrics, state = lyricsState)
                    }

                    if (m.mediaType.equals("video", ignoreCase = true)) {
                        VideoTranscriptPanel(
                            transcript = videoTranscript,
                            textSizeSp = transcriptTextSize,
                            onSmaller = { transcriptTextSize = (transcriptTextSize - 1f).coerceAtLeast(11f) },
                            onLarger = { transcriptTextSize = (transcriptTextSize + 1f).coerceAtMost(28f) }
                        )
                    }

                }
            }
        }
    }

    if (showTrackDialog) {
        AlertDialog(
            onDismissRequest = { showTrackDialog = false },
            title = { Text("Select Track") },
            text = {
                LazyColumn {
                    if (audioGroups.isNotEmpty()) {
                        item { Text("\uD83D\uDD0A Audio", fontWeight = FontWeight.SemiBold,
                            fontSize = 12.sp, modifier = Modifier.padding(vertical = 4.dp)) }
                        audioGroups.forEach { group ->
                            items(group.length) { trackIndex ->
                                val fmt      = group.getTrackFormat(trackIndex)
                                val selected = group.isTrackSelected(trackIndex)
                                val label    = fmt.label?.ifBlank { null }
                                    ?: fmt.language?.ifBlank { null }
                                    ?: "Audio ${trackIndex + 1}"
                                Row(
                                    modifier = Modifier.fillMaxWidth().padding(vertical = 4.dp),
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    RadioButton(selected = selected, onClick = {
                                        controller?.let { c ->
                                            c.trackSelectionParameters = c.trackSelectionParameters.buildUpon()
                                                .setOverrideForType(
                                                    TrackSelectionOverride(group.mediaTrackGroup, listOf(trackIndex))
                                                ).build()
                                        }
                                    })
                                    Text(label, fontSize = 14.sp)
                                }
                            }
                        }
                    }
                    if (textGroups.isNotEmpty()) {
                        item { Text("\uD83D\uDCAC Subtitles", fontWeight = FontWeight.SemiBold,
                            fontSize = 12.sp, modifier = Modifier.padding(vertical = 4.dp)) }
                        item {
                            Row(
                                modifier = Modifier.fillMaxWidth().padding(vertical = 4.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                val noneSelected = textGroups.none { g ->
                                    (0 until g.length).any { g.isTrackSelected(it) }
                                }
                                RadioButton(selected = noneSelected, onClick = {
                                    controller?.let { c ->
                                        c.trackSelectionParameters = c.trackSelectionParameters.buildUpon()
                                            .clearOverridesOfType(C.TRACK_TYPE_TEXT)
                                            .setTrackTypeDisabled(C.TRACK_TYPE_TEXT, true)
                                            .build()
                                    }
                                })
                                Text("Off", fontSize = 14.sp)
                            }
                        }
                        textGroups.forEach { group ->
                            items(group.length) { trackIndex ->
                                val fmt      = group.getTrackFormat(trackIndex)
                                val selected = group.isTrackSelected(trackIndex)
                                val label    = fmt.label?.ifBlank { null }
                                    ?: fmt.language?.ifBlank { null }
                                    ?: "Subtitle ${trackIndex + 1}"
                                Row(
                                    modifier = Modifier.fillMaxWidth().padding(vertical = 4.dp),
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    RadioButton(selected = selected, onClick = {
                                        controller?.let { c ->
                                            c.trackSelectionParameters = c.trackSelectionParameters.buildUpon()
                                                .setTrackTypeDisabled(C.TRACK_TYPE_TEXT, false)
                                                .setOverrideForType(
                                                    TrackSelectionOverride(group.mediaTrackGroup, listOf(trackIndex))
                                                ).build()
                                        }
                                    })
                                    Text(label, fontSize = 14.sp)
                                }
                            }
                        }
                    }
                }
            },
            confirmButton = {
                TextButton(onClick = { showTrackDialog = false }) { Text("Done") }
            }
        )
    }

    // v5.4.235cc — Video quality picker dialog.
    if (showQualityDialog) {
        AlertDialog(
            onDismissRequest = { showQualityDialog = false },
            title = { Text("Video Quality") },
            text = {
                Column {
                    qualityChoices.forEach { (label, url) ->
                        val isCurrent = item?.streamUrl == url
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(vertical = 4.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            RadioButton(
                                selected = isCurrent,
                                onClick = {
                                    switchQuality(url)
                                    showQualityDialog = false
                                }
                            )
                            Text(label, fontSize = 14.sp)
                        }
                    }
                }
            },
            confirmButton = {
                TextButton(onClick = { showQualityDialog = false }) { Text("Done") }
            }
        )
    }

    // v5.4.255cc — Now Playing Queue sheet.
    if (showQueueSheet) {
        NowPlayingQueueSheet(vm = vm, onDismiss = { showQueueSheet = false })
    }
}


@Composable
private fun VideoTranscriptPanel(
    transcript: com.tebogo.markvault.data.VideoTranscriptStore.Transcript?,
    textSizeSp: Float,
    onSmaller: () -> Unit,
    onLarger: () -> Unit
) {
    Surface(
        modifier = Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 8.dp),
        shape = MaterialTheme.shapes.large,
        tonalElevation = 2.dp,
        color = MaterialTheme.colorScheme.surfaceContainerLow
    ) {
        Column(modifier = Modifier.padding(18.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(
                    "Video transcript",
                    fontSize = 18.sp,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.primary,
                    modifier = Modifier.weight(1f)
                )
                TextButton(onClick = onSmaller, contentPadding = PaddingValues(horizontal = 8.dp)) {
                    Text("A−", fontWeight = FontWeight.Bold)
                }
                Text("${textSizeSp.toInt()}sp", fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                TextButton(onClick = onLarger, contentPadding = PaddingValues(horizontal = 8.dp)) {
                    Text("A+", fontWeight = FontWeight.Bold)
                }
            }
            Spacer(Modifier.height(8.dp))
            if (transcript == null || transcript.cues.isEmpty()) {
                Text(
                    "Caption text will appear here when CC is captured or extracted.",
                    fontSize = 13.sp,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            } else {
                // v5.4.291cc — Present the already-saved timed caption cues as
                // readable transcript paragraphs instead of one continuous text dump.
                // No transcript/search data is rewritten: both complete VTT captions and
                // playback-captured captions already persist start/end timestamps.
                val timedParagraphs = remember(transcript) {
                    buildTimedTranscriptParagraphs(transcript.cues)
                }
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .heightIn(max = 420.dp)
                        .verticalScroll(rememberScrollState())
                ) {
                    timedParagraphs.forEachIndexed { index, paragraph ->
                        Text(
                            text = formatTranscriptTimestamp(paragraph.startMs),
                            fontSize = (textSizeSp * 0.78f).coerceAtLeast(10f).sp,
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.primary
                        )
                        Spacer(Modifier.height(3.dp))
                        Text(
                            text = paragraph.text,
                            fontSize = textSizeSp.sp,
                            lineHeight = (textSizeSp * 1.45f).sp,
                            color = MaterialTheme.colorScheme.onSurface
                        )
                        if (index != timedParagraphs.lastIndex) {
                            Spacer(Modifier.height(14.dp))
                        }
                    }
                }
                Spacer(Modifier.height(10.dp))
                Text(
                    if (transcript.complete) "Complete caption track • saved for search"
                    else "Capturing captions as this video plays • saved for search",
                    fontSize = 11.sp,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
        }
    }
}

private data class TimedTranscriptParagraph(
    val startMs: Long,
    val text: String
)

/**
 * Groups the small cues produced by VTT/CC into readable timestamped paragraphs.
 * A paragraph ends at sentence punctuation, a noticeable speech gap, or after a
 * small number of cues so long caption tracks remain easy to scan.
 */
private fun buildTimedTranscriptParagraphs(
    cues: List<com.tebogo.markvault.data.VideoTranscriptStore.Cue>
): List<TimedTranscriptParagraph> {
    if (cues.isEmpty()) return emptyList()

    val result = mutableListOf<TimedTranscriptParagraph>()
    var paragraphStart = cues.first().startMs.coerceAtLeast(0L)
    val text = StringBuilder()
    var cueCount = 0
    var previousEnd = cues.first().startMs

    fun flush() {
        val clean = text.toString().replace(Regex("\\s+"), " ").trim()
        if (clean.isNotBlank()) result += TimedTranscriptParagraph(paragraphStart, clean)
        text.clear()
        cueCount = 0
    }

    cues.forEach { cue ->
        val cleanCue = cue.text.replace(Regex("\\s+"), " ").trim()
        if (cleanCue.isBlank()) return@forEach

        val gapMs = (cue.startMs - previousEnd).coerceAtLeast(0L)
        if (text.isNotEmpty() && gapMs >= 1_800L) {
            flush()
            paragraphStart = cue.startMs.coerceAtLeast(0L)
        } else if (text.isEmpty()) {
            paragraphStart = cue.startMs.coerceAtLeast(0L)
        }

        if (text.isNotEmpty()) text.append(' ')
        text.append(cleanCue)
        cueCount++
        previousEnd = cue.endMs.coerceAtLeast(cue.startMs)

        val sentenceEnded = cleanCue.lastOrNull() in listOf('.', '!', '?')
        if ((sentenceEnded && cueCount >= 2) || cueCount >= 4) flush()
    }
    flush()
    return result
}

private fun formatTranscriptTimestamp(positionMs: Long): String {
    val totalSeconds = positionMs.coerceAtLeast(0L) / 1_000L
    val hours = totalSeconds / 3_600L
    val minutes = (totalSeconds % 3_600L) / 60L
    val seconds = totalSeconds % 60L
    return if (hours > 0L) {
        "[%d:%02d:%02d]".format(hours, minutes, seconds)
    } else {
        "[%02d:%02d]".format(minutes, seconds)
    }
}

private enum class LyricsLoadState { HIDDEN, LOADING, FETCHING, READY, UNAVAILABLE }

@Composable
private fun LyricsPanel(lyrics: CachedSongLyrics?, state: LyricsLoadState) {
    Surface(
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 16.dp, vertical = 8.dp),
        shape = MaterialTheme.shapes.large,
        tonalElevation = 2.dp,
        color = MaterialTheme.colorScheme.surfaceContainerLow
    ) {
        Column(modifier = Modifier.padding(18.dp)) {
            Text(
                text = "Lyrics",
                fontSize = 18.sp,
                fontWeight = FontWeight.Bold,
                color = MaterialTheme.colorScheme.primary
            )
            Spacer(Modifier.height(10.dp))
            when (state) {
                LyricsLoadState.LOADING, LyricsLoadState.FETCHING -> {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        CircularProgressIndicator(
                            modifier = Modifier.size(20.dp),
                            strokeWidth = 2.dp
                        )
                        Spacer(Modifier.width(10.dp))
                        Text(
                            "Loading words from JW.ORG…",
                            fontSize = 13.sp,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }
                LyricsLoadState.READY -> {
                    lyrics?.text.orEmpty().lineSequence().forEach { line ->
                        val trimmed = line.trim()
                        if (trimmed.isEmpty()) {
                            Spacer(Modifier.height(7.dp))
                        } else {
                            val section = trimmed.matches(
                                Regex("^\\((?:(?:PRE-)?CHORUS(?:\\s+\\d+)?|BRIDGE(?:\\s+\\d+)?|VERSE(?:\\s+\\d+)?|INTRO|OUTRO|REFRAIN)\\)$", RegexOption.IGNORE_CASE)
                            )
                            Text(
                                text = trimmed,
                                fontSize = if (section) 13.sp else 16.sp,
                                lineHeight = 24.sp,
                                fontWeight = if (section) FontWeight.Bold else FontWeight.Normal,
                                color = if (section) MaterialTheme.colorScheme.primary
                                        else MaterialTheme.colorScheme.onSurface
                            )
                        }
                    }
                    if (!lyrics?.sourceUrl.isNullOrBlank()) {
                        Spacer(Modifier.height(12.dp))
                        Text(
                            "Cached from JW.ORG",
                            fontSize = 11.sp,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }
                LyricsLoadState.UNAVAILABLE -> Text(
                    "Lyrics could not be found for this song.",
                    fontSize = 13.sp,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
                LyricsLoadState.HIDDEN -> Unit
            }
        }
    }
}
