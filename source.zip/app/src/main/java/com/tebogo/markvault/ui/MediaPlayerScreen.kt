package com.tebogo.markvault.ui

import android.view.ViewGroup.LayoutParams.MATCH_PARENT
import android.widget.FrameLayout
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.media3.common.MediaItem as ExoMediaItem
import androidx.media3.common.Player
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.ui.PlayerView
import com.tebogo.markvault.AppViewModel
import com.tebogo.markvault.data.MediaItem
import kotlinx.coroutines.delay

/**
 * v5.4.212cc — Full-screen media player for JW.org videos and audio files.
 * Uses ExoPlayer via Media3 for streaming and local playback.
 * Persists resume position on pause/dispose.
 */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun MediaPlayerScreen(
    vm: AppViewModel,
    nav: androidx.navigation.NavController,
    mediaId: Long
) {
    val ctx    = LocalContext.current
    val nowPlaying by vm.nowPlayingMedia.collectAsStateWithLifecycle()

    // v5.4.232cc — Surface playback failures instead of failing silently.
    // Previously a blank streamUrl (or a genuine network/codec error) left
    // the user staring at a black screen with no explanation.
    var playerError by remember { mutableStateOf<String?>(null) }

    // Build ExoPlayer once, release on dispose
    val player = remember {
        ExoPlayer.Builder(ctx).build()
    }
    DisposableEffect(player) {
        val listener = object : Player.Listener {
            override fun onPlayerError(error: androidx.media3.common.PlaybackException) {
                playerError = error.message ?: "Playback failed"
            }
        }
        player.addListener(listener)
        onDispose {
            player.removeListener(listener)
            val pos = player.currentPosition
            nowPlaying?.let { vm.updateMediaPlayback(it.id, pos) }
            player.release()
        }
    }

    // Load media item and start playback
    LaunchedEffect(mediaId) {
        val item: MediaItem = nowPlaying ?: run {
            playerError = "Media item not found."
            return@LaunchedEffect
        }
        val playUrl = item.localPath.ifBlank { item.streamUrl }
        if (playUrl.isBlank()) {
            playerError = "No playable stream found for this item."
            return@LaunchedEffect
        }
        playerError = null
        val exoItem = ExoMediaItem.fromUri(playUrl)
        player.setMediaItem(exoItem)
        player.prepare()
        // Restore resume position
        if (item.resumePositionMs > 0) {
            player.seekTo(item.resumePositionMs)
        }
        player.playWhenReady = true
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Text(
                        nowPlaying?.title ?: "Media Player",
                        maxLines = 1,
                        fontSize = 15.sp
                    )
                },
                navigationIcon = {
                    IconButton(onClick = {
                        val pos = player.currentPosition
                        nowPlaying?.let { vm.updateMediaPlayback(it.id, pos) }
                        nav.popBackStack()
                    }) {
                        Icon(Icons.Default.ArrowBack, contentDescription = "Back")
                    }
                }
            )
        }
    ) { pad ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(pad)
                .verticalScroll(rememberScrollState())
        ) {
            // Video view (hidden for audio-only)
            val isAudio = nowPlaying?.mediaType == "audio"
            if (!isAudio) {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .aspectRatio(16f / 9f)
                        .background(Color.Black)
                ) {
                    AndroidView(
                        factory = {
                            PlayerView(it).apply {
                                this.player = player
                                layoutParams = FrameLayout.LayoutParams(MATCH_PARENT, MATCH_PARENT)
                                useController = true
                            }
                        },
                        modifier = Modifier.fillMaxSize()
                    )
                }
            } else {
                // Audio — show large thumbnail + compact controls
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(220.dp)
                        .background(MaterialTheme.colorScheme.surfaceVariant),
                    contentAlignment = Alignment.Center
                ) {
                    AndroidView(
                        factory = {
                            PlayerView(it).apply {
                                this.player = player
                                useController = true
                            }
                        },
                        modifier = Modifier.fillMaxWidth().height(220.dp)
                    )
                }
            }

            // v5.4.232cc — Visible error banner instead of silent failure.
            playerError?.let { err ->
                Surface(
                    color = MaterialTheme.colorScheme.errorContainer,
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Text(
                        "\u26A0\uFE0F $err",
                        color = MaterialTheme.colorScheme.onErrorContainer,
                        fontSize = 13.sp,
                        modifier = Modifier.padding(12.dp)
                    )
                }
            }

            // Metadata
            nowPlaying?.let { item ->
                Spacer(Modifier.height(12.dp))
                Column(modifier = Modifier.padding(horizontal = 16.dp)) {
                    Text(
                        item.title,
                        fontWeight = FontWeight.Bold,
                        fontSize = 17.sp
                    )
                    if (item.description.isNotBlank()) {
                        Spacer(Modifier.height(6.dp))
                        Text(
                            item.description,
                            fontSize = 13.sp,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                    if (item.scriptureRefs.isNotBlank()) {
                        Spacer(Modifier.height(6.dp))
                        Text(
                            "📖 ${item.scriptureRefs}",
                            fontSize = 12.sp,
                            color = MaterialTheme.colorScheme.primary
                        )
                    }
                    if (item.category.isNotBlank()) {
                        Spacer(Modifier.height(4.dp))
                        Text(
                            item.category,
                            fontSize = 11.sp,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }
            }
        }
    }
}
