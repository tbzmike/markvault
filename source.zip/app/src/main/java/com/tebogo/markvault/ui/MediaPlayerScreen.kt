package com.tebogo.markvault.ui

import android.widget.FrameLayout
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.media3.common.MediaItem as ExoMediaItem
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.ui.PlayerView
import com.tebogo.markvault.AppViewModel

/** v5.4.212cc — Full-screen media player using ExoPlayer / Media3. */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun MediaPlayerScreen(
    vm: AppViewModel,
    nav: androidx.navigation.NavController,
    mediaId: Long
) {
    val ctx     = LocalContext.current
    val item    by vm.nowPlayingMedia.collectAsStateWithLifecycle()

    val player = remember { ExoPlayer.Builder(ctx).build() }
    DisposableEffect(Unit) {
        onDispose {
            item?.let { vm.updateMediaPlayback(it.id, player.currentPosition) }
            player.release()
        }
    }

    LaunchedEffect(mediaId) {
        val playUrl = item?.localPath?.ifBlank { null } ?: item?.streamUrl ?: return@LaunchedEffect
        player.setMediaItem(ExoMediaItem.fromUri(playUrl))
        player.prepare()
        item?.resumePositionMs?.takeIf { it > 0 }?.let { player.seekTo(it) }
        player.playWhenReady = true
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text(item?.title ?: "Media Player", maxLines = 1, fontSize = 15.sp) },
                navigationIcon = {
                    IconButton(onClick = {
                        item?.let { vm.updateMediaPlayback(it.id, player.currentPosition) }
                        nav.popBackStack()
                    }) { Icon(Icons.Default.ArrowBack, contentDescription = "Back") }
                }
            )
        }
    ) { pad ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(pad)
                .verticalScroll(rememberScrollState())
        ) {
            // Video or audio player surface
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .then(
                        if (item?.mediaType == "video")
                            Modifier.aspectRatio(16f / 9f)
                        else
                            Modifier.height(200.dp)
                    )
                    .background(Color.Black)
            ) {
                AndroidView(
                    factory = { c ->
                        PlayerView(c).apply {
                            this.player = player
                            useController = true
                            layoutParams = FrameLayout.LayoutParams(
                                FrameLayout.LayoutParams.MATCH_PARENT,
                                FrameLayout.LayoutParams.MATCH_PARENT
                            )
                        }
                    },
                    modifier = Modifier.fillMaxSize()
                )
            }

            // Metadata
            item?.let { m ->
                Column(modifier = Modifier.padding(16.dp)) {
                    Text(m.title, fontWeight = FontWeight.Bold, fontSize = 17.sp)
                    if (m.description.isNotBlank()) {
                        Spacer(Modifier.height(6.dp))
                        Text(m.description, fontSize = 13.sp,
                            color = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                    if (m.scriptureRefs.isNotBlank()) {
                        Spacer(Modifier.height(6.dp))
                        Text("📖 ${m.scriptureRefs}", fontSize = 12.sp,
                            color = MaterialTheme.colorScheme.primary)
                    }
                    if (m.category.isNotBlank()) {
                        Spacer(Modifier.height(4.dp))
                        Text(m.category, fontSize = 11.sp,
                            color = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                }
            }
        }
    }
}
