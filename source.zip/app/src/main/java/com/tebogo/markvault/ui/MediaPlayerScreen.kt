package com.tebogo.markvault.ui

import android.app.Activity
import android.content.pm.ActivityInfo
import android.os.Build
import android.util.Rational
import android.view.View
import android.widget.FrameLayout
import android.webkit.WebResourceRequest
import android.webkit.WebResourceError
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.activity.compose.BackHandler
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.media3.common.C
import androidx.media3.common.Player
import androidx.media3.common.TrackSelectionOverride
import androidx.media3.ui.PlayerView
import com.tebogo.markvault.AppViewModel
import com.tebogo.markvault.data.CachedSongLyrics
import com.tebogo.markvault.data.MediaItem
import com.tebogo.markvault.data.SongLyricsCache
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import org.json.JSONTokener
import org.json.JSONObject
import java.text.Normalizer

/**
 * v5.4.233cc — Full-screen media player.
 *
 * Attaches to the SHARED MediaController (owned by PlaybackService) rather
 * than creating its own ExoPlayer — playback already started (from
 * wherever the user tapped Play) survives this screen opening, closing,
 * or the app backgrounding entirely, and the system notification keeps
 * working regardless of whether this screen is even open.
 *
 * Features: play/pause/seek (via PlayerView's built-in controls),
 * fullscreen (landscape + hidden system bars), Picture-in-Picture,
 * BackHandler exits fullscreen before navigating back, audio/subtitle
 * track selection.
 */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun MediaPlayerScreen(
    vm: AppViewModel,
    nav: androidx.navigation.NavController,
    mediaId: Long
) {
    val ctx      = LocalContext.current
    val activity = remember(ctx) { ctx as? Activity }
    val item     by vm.nowPlayingMedia.collectAsStateWithLifecycle()

    // v5.4.233cc — Poll for the shared controller becoming ready (async
    // connection to PlaybackService). No local ExoPlayer is created here.
    var controller by remember { mutableStateOf<Player?>(null) }
    LaunchedEffect(Unit) {
        var waited = 0
        while (controller == null && waited < 3000) {
            controller = vm.getMediaController()
            if (controller == null) {
                kotlinx.coroutines.delay(50L)
                waited += 50
            }
        }
    }

    // v5.4.233cc — Surface playback failures instead of failing silently.
    var playerError by remember { mutableStateOf<String?>(null) }

    // ── Track state (for the track-selection dialog) + error listener ──────
    var currentTracks by remember { mutableStateOf<androidx.media3.common.Tracks?>(null) }
    DisposableEffect(controller) {
        val c = controller
        if (c == null) return@DisposableEffect onDispose {}
        currentTracks = c.currentTracks
        playerError = null
        val listener = object : Player.Listener {
            override fun onTracksChanged(tracks: androidx.media3.common.Tracks) {
                currentTracks = tracks
            }
            override fun onPlayerError(error: androidx.media3.common.PlaybackException) {
                playerError = error.message ?: "Playback failed"
            }
        }
        c.addListener(listener)
        onDispose { c.removeListener(listener) }
    }
    val audioGroups = remember(currentTracks) {
        currentTracks?.groups?.filter { it.type == C.TRACK_TYPE_AUDIO && it.isSupported } ?: emptyList()
    }
    val textGroups = remember(currentTracks) {
        currentTracks?.groups?.filter { it.type == C.TRACK_TYPE_TEXT && it.isSupported } ?: emptyList()
    }
    val hasSelectableTracks = audioGroups.size + textGroups.size > 0

    // ── Fullscreen / PiP state ──────────────────────────────────────────────
    var isFullscreen by remember { mutableStateOf(false) }
    var showTrackDialog by remember { mutableStateOf(false) }
    // v5.4.255cc — Now Playing Queue sheet toggle.
    var showQueueSheet by remember { mutableStateOf(false) }

    // v5.4.279cc — Song lyrics use the otherwise-empty lower half of the
    // audio player. Cached copies live in app-internal storage so reopening
    // a song does not hit JW.org again. A hidden WebView is created only
    // while a cache miss is being resolved, then destroyed immediately.
    val lyricsScope = rememberCoroutineScope()
    var lyrics by remember(item?.id, item?.jwKey) { mutableStateOf<CachedSongLyrics?>(null) }
    var lyricsState by remember(item?.id, item?.jwKey) { mutableStateOf(LyricsLoadState.HIDDEN) }
    LaunchedEffect(item?.id, item?.jwKey, item?.title, item?.category) {
        val current = item
        if (current == null || !SongLyricsCache.isLyricsEligible(current)) {
            lyrics = null
            lyricsState = LyricsLoadState.HIDDEN
            return@LaunchedEffect
        }
        lyricsState = LyricsLoadState.LOADING
        val cached = withContext(Dispatchers.IO) { SongLyricsCache.load(ctx, current) }
        if (cached != null) {
            lyrics = cached
            lyricsState = LyricsLoadState.READY
        } else {
            lyrics = null
            lyricsState = LyricsLoadState.FETCHING
        }
    }
    // v5.4.235cc — Video quality picker. qualityOptions is "label\turl" per
    // line, highest resolution first (see JwMediaApi.allQualityOptions).
    var showQualityDialog by remember { mutableStateOf(false) }
    val qualityChoices = remember(item?.qualityOptions) {
        item?.qualityOptions.orEmpty()
            .split("\n")
            .mapNotNull { line ->
                val parts = line.split("\t", limit = 2)
                if (parts.size == 2 && parts[1].isNotBlank()) parts[0] to parts[1] else null
            }
    }

    fun enterFullscreen() {
        isFullscreen = true
        activity?.requestedOrientation = ActivityInfo.SCREEN_ORIENTATION_SENSOR_LANDSCAPE
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
            activity?.window?.insetsController?.hide(android.view.WindowInsets.Type.systemBars())
        } else {
            @Suppress("DEPRECATION")
            activity?.window?.decorView?.systemUiVisibility = (
                View.SYSTEM_UI_FLAG_FULLSCREEN or
                View.SYSTEM_UI_FLAG_HIDE_NAVIGATION or
                View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY
            )
        }
    }

    fun exitFullscreen() {
        isFullscreen = false
        activity?.requestedOrientation = ActivityInfo.SCREEN_ORIENTATION_UNSPECIFIED
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
            activity?.window?.insetsController?.show(android.view.WindowInsets.Type.systemBars())
        } else {
            @Suppress("DEPRECATION")
            activity?.window?.decorView?.systemUiVisibility = View.SYSTEM_UI_FLAG_VISIBLE
        }
    }

    /**
     * v5.4.235cc — Switch playback to a different quality URL, preserving
     * the current playback position so switching feels seamless rather
     * than restarting from zero.
     */
    fun switchQuality(url: String) {
        val c = controller ?: return
        val resumeAt = c.currentPosition.coerceAtLeast(0L)
        val wasPlaying = c.isPlaying
        val exo = androidx.media3.common.MediaItem.Builder()
            .setUri(url)
            .apply {
                item?.mimeType?.takeIf { it.isNotBlank() }?.let { setMimeType(it) }
                item?.id?.let { setMediaId(it.toString()) }
            }
            .setMediaMetadata(
                androidx.media3.common.MediaMetadata.Builder()
                    .setTitle(item?.title ?: "")
                    .build()
            )
            .build()
        c.setMediaItem(exo, resumeAt)
        c.prepare()
        c.playWhenReady = wasPlaying
    }

    fun shareMedia() {
        val m = item ?: return
        val shareUrl = m.localPath.ifBlank { m.streamUrl }
        if (shareUrl.isBlank()) return
        val text = if (m.title.isNotBlank()) "${m.title}\n$shareUrl" else shareUrl
        val sendIntent = android.content.Intent(android.content.Intent.ACTION_SEND).apply {
            type = "text/plain"
            putExtra(android.content.Intent.EXTRA_TEXT, text)
            if (m.title.isNotBlank()) putExtra(android.content.Intent.EXTRA_SUBJECT, m.title)
        }
        runCatching {
            ctx.startActivity(android.content.Intent.createChooser(sendIntent, "Share"))
        }
    }

    BackHandler(enabled = isFullscreen) { exitFullscreen() }

    if (isFullscreen) {
        Box(modifier = Modifier.fillMaxSize().background(Color.Black)) {
            AndroidView(
                factory = { c ->
                    PlayerView(c).apply {
                        this.player = controller
                        useController = true
                        setFullscreenButtonClickListener { _ -> exitFullscreen() }
                        layoutParams = FrameLayout.LayoutParams(
                            FrameLayout.LayoutParams.MATCH_PARENT,
                            FrameLayout.LayoutParams.MATCH_PARENT
                        )
                    }
                },
                update = { it.player = controller },
                modifier = Modifier.fillMaxSize()
            )
        }
    } else {
        Scaffold(
            topBar = {
                TopAppBar(
                    title = { Text(item?.title ?: "Media Player", maxLines = 1, fontSize = 15.sp) },
                    navigationIcon = {
                        IconButton(onClick = { nav.popBackStack() }) {
                            Text("\u2190", fontSize = 20.sp)
                        }
                    },
                    actions = {
                        // v5.4.261cc — CastButton now delegates discovery,
                        // route selection, and session UI to Google's official
                        // MediaRouteButton/CastButtonFactory integration.
                        CastButton()
                        // v5.4.254cc — Favourite toggle for the currently
                        // playing item, right next to Cast so it's reachable
                        // while actually watching/listening — the most
                        // natural place to favourite something.
                        item?.let { m ->
                            IconButton(onClick = { vm.toggleMediaFavourite(m) }) {
                                Text(
                                    if (m.isFavourite == 1) "\u2B50" else "\u2606",
                                    fontSize = 20.sp
                                )
                            }
                        }
                        // Picture-in-Picture (Android 8+)
                        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                            IconButton(onClick = {
                                activity?.let { act ->
                                    @Suppress("NewApi")
                                    val params = android.app.PictureInPictureParams.Builder()
                                        .setAspectRatio(Rational(16, 9))
                                        .apply {
                                            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
                                                setAutoEnterEnabled(true)
                                            }
                                        }
                                        .build()
                                    act.enterPictureInPictureMode(params)
                                }
                            }) {
                                Text("\u2922", fontSize = 18.sp)
                            }
                        }
                        if (hasSelectableTracks) {
                            IconButton(onClick = { showTrackDialog = true }) {
                                Text("CC", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                            }
                        }
                        // v5.4.235cc — Video quality picker. Only shown when
                        // more than one resolution is actually available.
                        if (qualityChoices.size > 1) {
                            IconButton(onClick = { showQualityDialog = true }) {
                                Text("\u2699", fontSize = 16.sp)
                            }
                        }
                        // v5.4.235cc — Share the media link via the system
                        // share sheet.
                        IconButton(onClick = { shareMedia() }) {
                            Text("\u2197", fontSize = 16.sp)
                        }
                    }
                )
            }
        ) { pad ->
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(pad)
                    .verticalScroll(rememberScrollState())
            ) {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .then(
                            if (item?.mediaType == "video") Modifier.aspectRatio(16f / 9f)
                            else Modifier.height(200.dp)
                        )
                        .background(Color.Black)
                ) {
                    if (controller == null) {
                        Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                            CircularProgressIndicator(color = Color.White)
                        }
                    } else {
                        AndroidView(
                            factory = { c ->
                                PlayerView(c).apply {
                                    this.player = controller
                                    useController = true
                                    setFullscreenButtonClickListener { _ -> enterFullscreen() }
                                    layoutParams = FrameLayout.LayoutParams(
                                        FrameLayout.LayoutParams.MATCH_PARENT,
                                        FrameLayout.LayoutParams.MATCH_PARENT
                                    )
                                }
                            },
                            update = { it.player = controller },
                            modifier = Modifier.fillMaxSize()
                        )
                    }
                }

                playerError?.let { err ->
                    Surface(
                        color = MaterialTheme.colorScheme.errorContainer,
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Text(
                            "\u26A0\uFE0F $err",
                            color = MaterialTheme.colorScheme.onErrorContainer,
                            fontSize = 13.sp,
                            modifier = Modifier.padding(12.dp)
                        )
                    }
                }

                // v5.4.255cc — Queue transport controls. Continuous play
                // (auto-advance through a multi-item queue) is Media3's
                // own default Player behavior once vm.playQueue()/
                // playMediaFromList() loads more than one item — these
                // buttons expose manual control over that same queue, and
                // work identically whether the active player is local or
                // Chromecast (both implement the same Player interface;
                // PlaybackService carries the whole queue across on
                // cast connect/disconnect).
                if (item != null) {
                    val shuffleOn by vm.shuffleEnabled.collectAsStateWithLifecycle()
                    val repeatModeState by vm.repeatMode.collectAsStateWithLifecycle()
                    val queueState by vm.currentQueue.collectAsStateWithLifecycle()
                    Row(
                        modifier = Modifier.fillMaxWidth().padding(vertical = 4.dp),
                        horizontalArrangement = Arrangement.SpaceEvenly,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        IconButton(onClick = { vm.toggleShuffle() }) {
                            Text(
                                "\uD83D\uDD00",
                                fontSize = 18.sp,
                                color = if (shuffleOn) MaterialTheme.colorScheme.primary
                                        else MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                        IconButton(onClick = { vm.playPreviousInQueue() }) {
                            Text("\u23EE", fontSize = 20.sp)
                        }
                        IconButton(onClick = { vm.playNextInQueue() }) {
                            Text("\u23ED", fontSize = 20.sp)
                        }
                        IconButton(onClick = { vm.cycleRepeatMode() }) {
                            Text(
                                if (repeatModeState == androidx.media3.common.Player.REPEAT_MODE_ONE) "\uD83D\uDD02" else "\uD83D\uDD01",
                                fontSize = 18.sp,
                                color = if (repeatModeState != androidx.media3.common.Player.REPEAT_MODE_OFF) MaterialTheme.colorScheme.primary
                                        else MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                        IconButton(onClick = { showQueueSheet = true }) {
                            Text(
                                "\u2630",
                                fontSize = 18.sp,
                                color = if (queueState.size > 1) MaterialTheme.colorScheme.primary
                                        else MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    }
                }

                item?.let { m ->
                    Column(modifier = Modifier.padding(16.dp)) {
                        Text(m.title, fontWeight = FontWeight.Bold, fontSize = 17.sp)
                        if (m.description.isNotBlank()) {
                            Spacer(Modifier.height(6.dp))
                            Text(m.description, fontSize = 13.sp,
                                color = MaterialTheme.colorScheme.onSurfaceVariant)
                        }
                        if (m.scriptureRefs.isNotBlank()) {
                            Spacer(Modifier.height(6.dp))
                            Text("\uD83D\uDCD6 ${m.scriptureRefs}", fontSize = 12.sp,
                                color = MaterialTheme.colorScheme.primary)
                        }
                        if (m.category.isNotBlank()) {
                            Spacer(Modifier.height(4.dp))
                            Text(m.category, fontSize = 11.sp,
                                color = MaterialTheme.colorScheme.onSurfaceVariant)
                        }
                        Spacer(Modifier.height(4.dp))
                        Text(
                            "\uD83D\uDD0A Playing in background \u2014 controls available in your notification panel",
                            fontSize = 11.sp,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }

                    if (SongLyricsCache.isLyricsEligible(m)) {
                        LyricsPanel(lyrics = lyrics, state = lyricsState)
                    }

                    if (lyricsState == LyricsLoadState.FETCHING) {
                        LyricsFetchWebView(
                            item = m,
                            onLyrics = { fetched ->
                                // Ignore a late callback from a song the user has
                                // already skipped, but still cache it for later.
                                lyricsScope.launch {
                                    withContext(Dispatchers.IO) { SongLyricsCache.save(ctx, m, fetched) }
                                    val active = item
                                    if (active != null &&
                                        active.id == m.id && active.jwKey == m.jwKey) {
                                        lyrics = fetched
                                        lyricsState = LyricsLoadState.READY
                                    }
                                }
                            },
                            onUnavailable = {
                                val active = item
                                if (active != null && active.id == m.id && active.jwKey == m.jwKey) {
                                    lyricsState = LyricsLoadState.UNAVAILABLE
                                }
                            }
                        )
                    }
                }
            }
        }
    }

    if (showTrackDialog) {
        AlertDialog(
            onDismissRequest = { showTrackDialog = false },
            title = { Text("Select Track") },
            text = {
                LazyColumn {
                    if (audioGroups.isNotEmpty()) {
                        item { Text("\uD83D\uDD0A Audio", fontWeight = FontWeight.SemiBold,
                            fontSize = 12.sp, modifier = Modifier.padding(vertical = 4.dp)) }
                        audioGroups.forEach { group ->
                            items(group.length) { trackIndex ->
                                val fmt      = group.getTrackFormat(trackIndex)
                                val selected = group.isTrackSelected(trackIndex)
                                val label    = fmt.label?.ifBlank { null }
                                    ?: fmt.language?.ifBlank { null }
                                    ?: "Audio ${trackIndex + 1}"
                                Row(
                                    modifier = Modifier.fillMaxWidth().padding(vertical = 4.dp),
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    RadioButton(selected = selected, onClick = {
                                        controller?.let { c ->
                                            c.trackSelectionParameters = c.trackSelectionParameters.buildUpon()
                                                .setOverrideForType(
                                                    TrackSelectionOverride(group.mediaTrackGroup, listOf(trackIndex))
                                                ).build()
                                        }
                                    })
                                    Text(label, fontSize = 14.sp)
                                }
                            }
                        }
                    }
                    if (textGroups.isNotEmpty()) {
                        item { Text("\uD83D\uDCAC Subtitles", fontWeight = FontWeight.SemiBold,
                            fontSize = 12.sp, modifier = Modifier.padding(vertical = 4.dp)) }
                        item {
                            Row(
                                modifier = Modifier.fillMaxWidth().padding(vertical = 4.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                val noneSelected = textGroups.none { g ->
                                    (0 until g.length).any { g.isTrackSelected(it) }
                                }
                                RadioButton(selected = noneSelected, onClick = {
                                    controller?.let { c ->
                                        c.trackSelectionParameters = c.trackSelectionParameters.buildUpon()
                                            .clearOverridesOfType(C.TRACK_TYPE_TEXT)
                                            .setTrackTypeDisabled(C.TRACK_TYPE_TEXT, true)
                                            .build()
                                    }
                                })
                                Text("Off", fontSize = 14.sp)
                            }
                        }
                        textGroups.forEach { group ->
                            items(group.length) { trackIndex ->
                                val fmt      = group.getTrackFormat(trackIndex)
                                val selected = group.isTrackSelected(trackIndex)
                                val label    = fmt.label?.ifBlank { null }
                                    ?: fmt.language?.ifBlank { null }
                                    ?: "Subtitle ${trackIndex + 1}"
                                Row(
                                    modifier = Modifier.fillMaxWidth().padding(vertical = 4.dp),
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    RadioButton(selected = selected, onClick = {
                                        controller?.let { c ->
                                            c.trackSelectionParameters = c.trackSelectionParameters.buildUpon()
                                                .setTrackTypeDisabled(C.TRACK_TYPE_TEXT, false)
                                                .setOverrideForType(
                                                    TrackSelectionOverride(group.mediaTrackGroup, listOf(trackIndex))
                                                ).build()
                                        }
                                    })
                                    Text(label, fontSize = 14.sp)
                                }
                            }
                        }
                    }
                }
            },
            confirmButton = {
                TextButton(onClick = { showTrackDialog = false }) { Text("Done") }
            }
        )
    }

    // v5.4.235cc — Video quality picker dialog.
    if (showQualityDialog) {
        AlertDialog(
            onDismissRequest = { showQualityDialog = false },
            title = { Text("Video Quality") },
            text = {
                Column {
                    qualityChoices.forEach { (label, url) ->
                        val isCurrent = item?.streamUrl == url
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(vertical = 4.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            RadioButton(
                                selected = isCurrent,
                                onClick = {
                                    switchQuality(url)
                                    showQualityDialog = false
                                }
                            )
                            Text(label, fontSize = 14.sp)
                        }
                    }
                }
            },
            confirmButton = {
                TextButton(onClick = { showQualityDialog = false }) { Text("Done") }
            }
        )
    }

    // v5.4.255cc — Now Playing Queue sheet.
    if (showQueueSheet) {
        NowPlayingQueueSheet(vm = vm, onDismiss = { showQueueSheet = false })
    }
}


private enum class LyricsLoadState { HIDDEN, LOADING, FETCHING, READY, UNAVAILABLE }

@Composable
private fun LyricsPanel(lyrics: CachedSongLyrics?, state: LyricsLoadState) {
    Surface(
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 16.dp, vertical = 8.dp),
        shape = MaterialTheme.shapes.large,
        tonalElevation = 2.dp,
        color = MaterialTheme.colorScheme.surfaceContainerLow
    ) {
        Column(modifier = Modifier.padding(18.dp)) {
            Text(
                text = "Lyrics",
                fontSize = 18.sp,
                fontWeight = FontWeight.Bold,
                color = MaterialTheme.colorScheme.primary
            )
            Spacer(Modifier.height(10.dp))
            when (state) {
                LyricsLoadState.LOADING, LyricsLoadState.FETCHING -> {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        CircularProgressIndicator(
                            modifier = Modifier.size(20.dp),
                            strokeWidth = 2.dp
                        )
                        Spacer(Modifier.width(10.dp))
                        Text(
                            "Loading words from JW.ORG…",
                            fontSize = 13.sp,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }
                LyricsLoadState.READY -> {
                    lyrics?.text.orEmpty().lineSequence().forEach { line ->
                        val trimmed = line.trim()
                        if (trimmed.isEmpty()) {
                            Spacer(Modifier.height(7.dp))
                        } else {
                            val section = trimmed.matches(
                                Regex("^\\((?:PRE-)?CHORUS|BRIDGE|VERSE|INTRO|OUTRO\\)$", RegexOption.IGNORE_CASE)
                            )
                            Text(
                                text = trimmed,
                                fontSize = if (section) 13.sp else 16.sp,
                                lineHeight = 24.sp,
                                fontWeight = if (section) FontWeight.Bold else FontWeight.Normal,
                                color = if (section) MaterialTheme.colorScheme.primary
                                        else MaterialTheme.colorScheme.onSurface
                            )
                        }
                    }
                    if (!lyrics?.sourceUrl.isNullOrBlank()) {
                        Spacer(Modifier.height(12.dp))
                        Text(
                            "Cached from JW.ORG",
                            fontSize = 11.sp,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }
                LyricsLoadState.UNAVAILABLE -> Text(
                    "Lyrics could not be found for this song.",
                    fontSize = 13.sp,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
                LyricsLoadState.HIDDEN -> Unit
            }
        }
    }
}

/**
 * v5.4.280cc — Resolve lyrics from the actual JW.org song pages.
 *
 * The old implementation evaluated the DOM once in onPageFinished(). JW.org
 * hydrates parts of its music pages after that callback, so a perfectly valid
 * song page could still look empty at the instant MarkVault inspected it.
 * This resolver keeps the tiny WebView attached, retries the DOM after page
 * hydration, and knows both official song collections:
 *   • Original Songs
 *   • “Sing Out Joyfully” to Jehovah (pub=sjj)
 *
 * No lyric text is synthesized. Only text visibly published on JW.org is
 * accepted and then cached by SongLyricsCache.
 */
@Composable
private fun LyricsFetchWebView(
    item: MediaItem,
    onLyrics: (CachedSongLyrics) -> Unit,
    onUnavailable: () -> Unit
) {
    val context = LocalContext.current
    val targetTitle = item.title
    val directOriginalUrl = remember(targetTitle) { jwSongCandidateUrl(targetTitle) }
    val originalIndexUrl = "https://www.jw.org/en/library/music-songs/original-songs/"
    val songbookFinderUrl = remember(item.streamUrl) {
        val locale = inferJwLocale(item.streamUrl)
        "https://www.jw.org/finder?srcid=jwlshare&wtlocale=$locale&prefer=lang&pub=sjj"
    }
    val webView = remember(item.id, item.jwKey) { WebView(context) }
    var finished by remember(item.id, item.jwKey) { mutableStateOf(false) }
    var stage by remember(item.id, item.jwKey) { mutableIntStateOf(0) }
    var pageGeneration by remember(item.id, item.jwKey) { mutableIntStateOf(0) }

    val stages = remember(directOriginalUrl, originalIndexUrl, songbookFinderUrl) {
        listOf(directOriginalUrl, originalIndexUrl, songbookFinderUrl)
    }

    fun advanceStage() {
        if (finished) return
        if (stage + 1 < stages.size) {
            stage += 1
            pageGeneration += 1
            webView.loadUrl(stages[stage])
        } else {
            finished = true
            onUnavailable()
        }
    }

    fun findSongLinkInCollection(view: WebView, generation: Int, retry: Int = 0) {
        if (finished || generation != pageGeneration) return
        val wanted = JSONObject.quote(SongLyricsCache.normalizeTitle(targetTitle))
        val script = """
            (function() {
              const wanted = $wanted;
              const norm = (s) => (s || '').normalize('NFD')
                .replace(/\p{M}/gu, '')
                .toLowerCase()
                .replace(/[‘’“”\"'`]/g, '')
                .replace(/[^\p{L}\p{N}]+/gu, ' ')
                .trim()
                .replace(/\s+/g, ' ');
              const links = Array.from(document.querySelectorAll('a[href]')).filter(a => {
                const h = a.href || '';
                return h.includes('/library/music-songs/original-songs/') ||
                       h.includes('/library/music-songs/sing-out-joyfully/');
              });
              const exact = links.find(a => norm(a.textContent) === wanted);
              const close = exact || links.find(a => {
                const n = norm(a.textContent);
                return n && wanted && (n.includes(wanted) || wanted.includes(n));
              });
              return close ? close.href : '';
            })();
        """.trimIndent()
        view.evaluateJavascript(script) { encoded ->
            if (finished || generation != pageGeneration) return@evaluateJavascript
            val found = decodeJavascriptString(encoded)
            if (found.startsWith("https://www.jw.org/")) {
                pageGeneration += 1
                view.loadUrl(found)
            } else if (retry < 5) {
                val delays = longArrayOf(350L, 700L, 1200L, 2000L, 3200L, 4500L)
                view.postDelayed({ findSongLinkInCollection(view, generation, retry + 1) }, delays[retry])
            } else {
                advanceStage()
            }
        }
    }

    fun inspectSongPage(view: WebView, url: String, generation: Int, retry: Int = 0) {
        if (finished || generation != pageGeneration) return
        view.evaluateJavascript(
            "(function(){const m=document.querySelector('main');return m?m.innerText:'';})();"
        ) { encoded ->
            if (finished || generation != pageGeneration) return@evaluateJavascript
            val pageText = decodeJavascriptString(encoded)
            val parsed = extractLyricsFromJwPage(pageText, targetTitle)
            if (!parsed.isNullOrBlank()) {
                finished = true
                onLyrics(
                    CachedSongLyrics(
                        text = parsed,
                        sourceUrl = url,
                        cachedAt = System.currentTimeMillis()
                    )
                )
            } else if (retry < 5) {
                val delays = longArrayOf(350L, 700L, 1200L, 2000L, 3200L, 4500L)
                view.postDelayed({ inspectSongPage(view, url, generation, retry + 1) }, delays[retry])
            } else {
                advanceStage()
            }
        }
    }

    DisposableEffect(webView) {
        webView.settings.apply {
            javaScriptEnabled = true
            domStorageEnabled = true
            databaseEnabled = true
            allowFileAccess = false
            allowContentAccess = true
            loadsImagesAutomatically = false
            mediaPlaybackRequiresUserGesture = true
            mixedContentMode = WebSettings.MIXED_CONTENT_COMPATIBILITY_MODE
            userAgentString = userAgentString + " MarkVault/5.4"
        }
        webView.webViewClient = object : WebViewClient() {
            override fun onPageFinished(view: WebView, url: String) {
                if (finished) return
                val generation = ++pageGeneration
                val clean = url.substringBefore('#').substringBefore('?').trimEnd('/')
                val isOriginalIndex = clean.endsWith("/library/music-songs/original-songs")
                val isSongbookIndex = clean.endsWith("/library/music-songs/sing-out-joyfully") ||
                    url.contains("pub=sjj", ignoreCase = true)
                if (isOriginalIndex || isSongbookIndex) {
                    findSongLinkInCollection(view, generation)
                } else {
                    inspectSongPage(view, url, generation)
                }
            }

            override fun onReceivedError(
                view: WebView,
                request: WebResourceRequest,
                error: WebResourceError
            ) {
                if (request.isForMainFrame) advanceStage()
            }
        }
        webView.loadUrl(stages.first())
        onDispose {
            finished = true
            pageGeneration += 1
            runCatching { webView.stopLoading() }
            runCatching { webView.loadUrl("about:blank") }
            runCatching { webView.removeAllViews() }
            runCatching { webView.destroy() }
        }
    }

    AndroidView(
        factory = { webView },
        modifier = Modifier.size(1.dp)
    )
}

private fun jwSongCandidateUrl(title: String): String {
    val ascii = Normalizer.normalize(title, Normalizer.Form.NFD)
        .replace(Regex("\\p{M}+"), "")
    val slug = ascii
        .replace(Regex("[‘’“”\\\"'`]+"), "")
        .replace(Regex("[^A-Za-z0-9]+"), "-")
        .trim('-')
    return "https://www.jw.org/en/library/music-songs/original-songs/$slug/"
}

private fun inferJwLocale(streamUrl: String): String {
    if (streamUrl.isBlank()) return "E"
    val path = runCatching { android.net.Uri.parse(streamUrl).lastPathSegment.orEmpty() }
        .getOrDefault("")
    val token = Regex("(?:^|[_-])([A-Z]{1,4})(?:[_-])")
        .find(path)?.groupValues?.getOrNull(1)
    return token?.takeIf { it.length in 1..4 } ?: "E"
}
private fun decodeJavascriptString(encoded: String?): String {
    if (encoded.isNullOrBlank() || encoded == "null") return ""
    return runCatching { JSONTokener(encoded).nextValue() as? String }
        .getOrNull()
        .orEmpty()
}

/**
 * JW.org song pages expose the song words in main.innerText between the
 * download/lead-sheet header and the media/download-options footer. Parsing
 * that stable visible-text boundary is intentionally less coupled to CSS
 * class names, which JW.org can change without changing page semantics.
 */
private fun extractLyricsFromJwPage(raw: String, title: String): String? {
    if (raw.isBlank()) return null
    val lines = raw
        .replace("\r", "")
        .split('\n')
        .map { it.trim() }

    val stopAt = lines.indexOfFirst { line ->
        line.equals("Sorry, the media player failed to load.", ignoreCase = true) ||
            line.equals("Download This Video", ignoreCase = true) ||
            line.equals("DOWNLOAD OPTIONS", ignoreCase = true) ||
            line.startsWith("(See also", ignoreCase = true)
    }.let { if (it >= 0) it else lines.size }
    if (stopAt <= 0) return null

    val downloadAt = lines.indexOfFirst { it.equals("Download:", ignoreCase = true) }
    val numberedVerse = Regex("^\\d+\\.\\s+(?:\\d+\\.\\s+)?\\S.*")
    val sectionLine = Regex(
        "^\\((?:PRE-)?CHORUS|BRIDGE|VERSE|INTRO|OUTRO\\)$",
        RegexOption.IGNORE_CASE
    )

    val startAt = when {
        downloadAt >= 0 && downloadAt < stopAt -> downloadAt + 1
        else -> lines.indexOfFirst { line -> numberedVerse.matches(line) || sectionLine.matches(line) }
    }
    if (startAt < 0 || startAt >= stopAt) return null

    val titleNorm = SongLyricsCache.normalizeTitle(title)
    val body = lines.subList(startAt, stopAt)
        .dropWhile { line ->
            line.isBlank() ||
                line.equals("Lead Sheet", ignoreCase = true) ||
                line.equals("PLAY", ignoreCase = true) ||
                line.equals("Select an Audio Recording", ignoreCase = true) ||
                SongLyricsCache.normalizeTitle(line) == titleNorm
        }
        .filterNot { line ->
            line.equals("Lead Sheet", ignoreCase = true) ||
                line.equals("PLAY", ignoreCase = true) ||
                line.equals("Select an Audio Recording", ignoreCase = true)
        }
        .map { line ->
            line.replace(Regex("^(\\d+)\\.\\s+\\1\\.\\s*"), "$1. ")
        }
        .toMutableList()

    while (body.isNotEmpty() && body.first().isBlank()) body.removeAt(0)
    while (body.isNotEmpty() && body.last().isBlank()) body.removeAt(body.lastIndex)

    val meaningful = body.count { line ->
        line.isNotBlank() && !sectionLine.matches(line)
    }
    if (meaningful < 2) return null

    return buildString {
        var previousBlank = false
        body.forEach { line ->
            val blank = line.isBlank()
            if (blank && previousBlank) return@forEach
            if (isNotEmpty()) append('\n')
            append(line)
            previousBlank = blank
        }
    }.trim().takeIf { it.isNotBlank() }
}
