package com.tebogo.markvault.ui

import android.app.Activity
import android.content.pm.ActivityInfo
import android.os.Build
import android.util.Rational
import android.view.View
import android.widget.FrameLayout
import androidx.activity.compose.BackHandler
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.media3.common.C
import androidx.media3.common.Player
import androidx.media3.common.TrackSelectionOverride
import androidx.media3.ui.PlayerView
import androidx.mediarouter.app.MediaRouteButton
import com.google.android.gms.cast.framework.CastButtonFactory
import com.tebogo.markvault.AppViewModel

/**
 * v5.4.233cc — Full-screen media player.
 *
 * Attaches to the SHARED MediaController (owned by PlaybackService) rather
 * than creating its own ExoPlayer — playback already started (from
 * wherever the user tapped Play) survives this screen opening, closing,
 * or the app backgrounding entirely, and the system notification keeps
 * working regardless of whether this screen is even open.
 *
 * Features: play/pause/seek (via PlayerView's built-in controls),
 * fullscreen (landscape + hidden system bars), Picture-in-Picture,
 * BackHandler exits fullscreen before navigating back, audio/subtitle
 * track selection.
 */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun MediaPlayerScreen(
    vm: AppViewModel,
    nav: androidx.navigation.NavController,
    mediaId: Long
) {
    val ctx      = LocalContext.current
    val activity = remember(ctx) { ctx as? Activity }
    val item     by vm.nowPlayingMedia.collectAsStateWithLifecycle()

    // v5.4.233cc — Poll for the shared controller becoming ready (async
    // connection to PlaybackService). No local ExoPlayer is created here.
    var controller by remember { mutableStateOf<Player?>(null) }
    LaunchedEffect(Unit) {
        var waited = 0
        while (controller == null && waited < 3000) {
            controller = vm.getMediaController()
            if (controller == null) {
                kotlinx.coroutines.delay(50L)
                waited += 50
            }
        }
    }

    // v5.4.233cc — Surface playback failures instead of failing silently.
    var playerError by remember { mutableStateOf<String?>(null) }

    // ── Track state (for the track-selection dialog) + error listener ──────
    var currentTracks by remember { mutableStateOf<androidx.media3.common.Tracks?>(null) }
    DisposableEffect(controller) {
        val c = controller
        if (c == null) return@DisposableEffect onDispose {}
        currentTracks = c.currentTracks
        playerError = null
        val listener = object : Player.Listener {
            override fun onTracksChanged(tracks: androidx.media3.common.Tracks) {
                currentTracks = tracks
            }
            override fun onPlayerError(error: androidx.media3.common.PlaybackException) {
                playerError = error.message ?: "Playback failed"
            }
        }
        c.addListener(listener)
        onDispose { c.removeListener(listener) }
    }
    val audioGroups = remember(currentTracks) {
        currentTracks?.groups?.filter { it.type == C.TRACK_TYPE_AUDIO && it.isSupported } ?: emptyList()
    }
    val textGroups = remember(currentTracks) {
        currentTracks?.groups?.filter { it.type == C.TRACK_TYPE_TEXT && it.isSupported } ?: emptyList()
    }
    val hasSelectableTracks = audioGroups.size + textGroups.size > 0

    // ── Fullscreen / PiP state ──────────────────────────────────────────────
    var isFullscreen by remember { mutableStateOf(false) }
    var showTrackDialog by remember { mutableStateOf(false) }
    // v5.4.235cc — Video quality picker. qualityOptions is "label\turl" per
    // line, highest resolution first (see JwMediaApi.allQualityOptions).
    var showQualityDialog by remember { mutableStateOf(false) }
    val qualityChoices = remember(item?.qualityOptions) {
        item?.qualityOptions.orEmpty()
            .split("\n")
            .mapNotNull { line ->
                val parts = line.split("\t", limit = 2)
                if (parts.size == 2 && parts[1].isNotBlank()) parts[0] to parts[1] else null
            }
    }

    fun enterFullscreen() {
        isFullscreen = true
        activity?.requestedOrientation = ActivityInfo.SCREEN_ORIENTATION_SENSOR_LANDSCAPE
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
            activity?.window?.insetsController?.hide(android.view.WindowInsets.Type.systemBars())
        } else {
            @Suppress("DEPRECATION")
            activity?.window?.decorView?.systemUiVisibility = (
                View.SYSTEM_UI_FLAG_FULLSCREEN or
                View.SYSTEM_UI_FLAG_HIDE_NAVIGATION or
                View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY
            )
        }
    }

    fun exitFullscreen() {
        isFullscreen = false
        activity?.requestedOrientation = ActivityInfo.SCREEN_ORIENTATION_UNSPECIFIED
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
            activity?.window?.insetsController?.show(android.view.WindowInsets.Type.systemBars())
        } else {
            @Suppress("DEPRECATION")
            activity?.window?.decorView?.systemUiVisibility = View.SYSTEM_UI_FLAG_VISIBLE
        }
    }

    /**
     * v5.4.235cc — Switch playback to a different quality URL, preserving
     * the current playback position so switching feels seamless rather
     * than restarting from zero.
     */
    fun switchQuality(url: String) {
        val c = controller ?: return
        val resumeAt = c.currentPosition.coerceAtLeast(0L)
        val wasPlaying = c.isPlaying
        val exo = androidx.media3.common.MediaItem.Builder()
            .setUri(url)
            .apply { item?.id?.let { setMediaId(it.toString()) } }
            .setMediaMetadata(
                androidx.media3.common.MediaMetadata.Builder()
                    .setTitle(item?.title ?: "")
                    .build()
            )
            .build()
        c.setMediaItem(exo, resumeAt)
        c.prepare()
        c.playWhenReady = wasPlaying
    }

    fun shareMedia() {
        val m = item ?: return
        val shareUrl = m.localPath.ifBlank { m.streamUrl }
        if (shareUrl.isBlank()) return
        val text = if (m.title.isNotBlank()) "${m.title}\n$shareUrl" else shareUrl
        val sendIntent = android.content.Intent(android.content.Intent.ACTION_SEND).apply {
            type = "text/plain"
            putExtra(android.content.Intent.EXTRA_TEXT, text)
            if (m.title.isNotBlank()) putExtra(android.content.Intent.EXTRA_SUBJECT, m.title)
        }
        runCatching {
            ctx.startActivity(android.content.Intent.createChooser(sendIntent, "Share"))
        }
    }

    BackHandler(enabled = isFullscreen) { exitFullscreen() }

    if (isFullscreen) {
        Box(modifier = Modifier.fillMaxSize().background(Color.Black)) {
            AndroidView(
                factory = { c ->
                    PlayerView(c).apply {
                        this.player = controller
                        useController = true
                        setFullscreenButtonClickListener { _ -> exitFullscreen() }
                        layoutParams = FrameLayout.LayoutParams(
                            FrameLayout.LayoutParams.MATCH_PARENT,
                            FrameLayout.LayoutParams.MATCH_PARENT
                        )
                    }
                },
                update = { it.player = controller },
                modifier = Modifier.fillMaxSize()
            )
        }
    } else {
        Scaffold(
            topBar = {
                TopAppBar(
                    title = { Text(item?.title ?: "Media Player", maxLines = 1, fontSize = 15.sp) },
                    navigationIcon = {
                        IconButton(onClick = { nav.popBackStack() }) {
                            Text("\u2190", fontSize = 20.sp)
                        }
                    },
                    actions = {
                        // v5.4.247cc — Chromecast button. MediaRouteButton is
                        // a platform View that handles Cast device discovery,
                        // the route-picker dialog, and Cast session management
                        // automatically. It is invisible when no Cast devices
                        // are discovered on the local network, so it adds zero
                        // visual noise when Chromecast is not in use.
                        AndroidView(
                            factory = { viewCtx ->
                                MediaRouteButton(viewCtx).also { btn ->
                                    CastButtonFactory.setUpMediaRouteButton(viewCtx, btn)
                                }
                            },
                            modifier = Modifier.size(48.dp)
                        )
                        // Picture-in-Picture (Android 8+)
                        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                            IconButton(onClick = {
                                activity?.let { act ->
                                    @Suppress("NewApi")
                                    val params = android.app.PictureInPictureParams.Builder()
                                        .setAspectRatio(Rational(16, 9))
                                        .apply {
                                            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
                                                setAutoEnterEnabled(true)
                                            }
                                        }
                                        .build()
                                    act.enterPictureInPictureMode(params)
                                }
                            }) {
                                Text("\u2922", fontSize = 18.sp)
                            }
                        }
                        if (hasSelectableTracks) {
                            IconButton(onClick = { showTrackDialog = true }) {
                                Text("CC", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                            }
                        }
                        // v5.4.235cc — Video quality picker. Only shown when
                        // more than one resolution is actually available.
                        if (qualityChoices.size > 1) {
                            IconButton(onClick = { showQualityDialog = true }) {
                                Text("\u2699", fontSize = 16.sp)
                            }
                        }
                        // v5.4.235cc — Share the media link via the system
                        // share sheet.
                        IconButton(onClick = { shareMedia() }) {
                            Text("\u2197", fontSize = 16.sp)
                        }
                    }
                )
            }
        ) { pad ->
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(pad)
                    .verticalScroll(rememberScrollState())
            ) {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .then(
                            if (item?.mediaType == "video") Modifier.aspectRatio(16f / 9f)
                            else Modifier.height(200.dp)
                        )
                        .background(Color.Black)
                ) {
                    if (controller == null) {
                        Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                            CircularProgressIndicator(color = Color.White)
                        }
                    } else {
                        AndroidView(
                            factory = { c ->
                                PlayerView(c).apply {
                                    this.player = controller
                                    useController = true
                                    setFullscreenButtonClickListener { _ -> enterFullscreen() }
                                    layoutParams = FrameLayout.LayoutParams(
                                        FrameLayout.LayoutParams.MATCH_PARENT,
                                        FrameLayout.LayoutParams.MATCH_PARENT
                                    )
                                }
                            },
                            update = { it.player = controller },
                            modifier = Modifier.fillMaxSize()
                        )
                    }
                }

                playerError?.let { err ->
                    Surface(
                        color = MaterialTheme.colorScheme.errorContainer,
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Text(
                            "\u26A0\uFE0F $err",
                            color = MaterialTheme.colorScheme.onErrorContainer,
                            fontSize = 13.sp,
                            modifier = Modifier.padding(12.dp)
                        )
                    }
                }

                item?.let { m ->
                    Column(modifier = Modifier.padding(16.dp)) {
                        Text(m.title, fontWeight = FontWeight.Bold, fontSize = 17.sp)
                        if (m.description.isNotBlank()) {
                            Spacer(Modifier.height(6.dp))
                            Text(m.description, fontSize = 13.sp,
                                color = MaterialTheme.colorScheme.onSurfaceVariant)
                        }
                        if (m.scriptureRefs.isNotBlank()) {
                            Spacer(Modifier.height(6.dp))
                            Text("\uD83D\uDCD6 ${m.scriptureRefs}", fontSize = 12.sp,
                                color = MaterialTheme.colorScheme.primary)
                        }
                        if (m.category.isNotBlank()) {
                            Spacer(Modifier.height(4.dp))
                            Text(m.category, fontSize = 11.sp,
                                color = MaterialTheme.colorScheme.onSurfaceVariant)
                        }
                        Spacer(Modifier.height(4.dp))
                        Text(
                            "\uD83D\uDD0A Playing in background \u2014 controls available in your notification panel",
                            fontSize = 11.sp,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }
            }
        }
    }

    if (showTrackDialog) {
        AlertDialog(
            onDismissRequest = { showTrackDialog = false },
            title = { Text("Select Track") },
            text = {
                LazyColumn {
                    if (audioGroups.isNotEmpty()) {
                        item { Text("\uD83D\uDD0A Audio", fontWeight = FontWeight.SemiBold,
                            fontSize = 12.sp, modifier = Modifier.padding(vertical = 4.dp)) }
                        audioGroups.forEach { group ->
                            items(group.length) { trackIndex ->
                                val fmt      = group.getTrackFormat(trackIndex)
                                val selected = group.isTrackSelected(trackIndex)
                                val label    = fmt.label?.ifBlank { null }
                                    ?: fmt.language?.ifBlank { null }
                                    ?: "Audio ${trackIndex + 1}"
                                Row(
                                    modifier = Modifier.fillMaxWidth().padding(vertical = 4.dp),
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    RadioButton(selected = selected, onClick = {
                                        controller?.let { c ->
                                            c.trackSelectionParameters = c.trackSelectionParameters.buildUpon()
                                                .setOverrideForType(
                                                    TrackSelectionOverride(group.mediaTrackGroup, listOf(trackIndex))
                                                ).build()
                                        }
                                    })
                                    Text(label, fontSize = 14.sp)
                                }
                            }
                        }
                    }
                    if (textGroups.isNotEmpty()) {
                        item { Text("\uD83D\uDCAC Subtitles", fontWeight = FontWeight.SemiBold,
                            fontSize = 12.sp, modifier = Modifier.padding(vertical = 4.dp)) }
                        item {
                            Row(
                                modifier = Modifier.fillMaxWidth().padding(vertical = 4.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                val noneSelected = textGroups.none { g ->
                                    (0 until g.length).any { g.isTrackSelected(it) }
                                }
                                RadioButton(selected = noneSelected, onClick = {
                                    controller?.let { c ->
                                        c.trackSelectionParameters = c.trackSelectionParameters.buildUpon()
                                            .clearOverridesOfType(C.TRACK_TYPE_TEXT)
                                            .setTrackTypeDisabled(C.TRACK_TYPE_TEXT, true)
                                            .build()
                                    }
                                })
                                Text("Off", fontSize = 14.sp)
                            }
                        }
                        textGroups.forEach { group ->
                            items(group.length) { trackIndex ->
                                val fmt      = group.getTrackFormat(trackIndex)
                                val selected = group.isTrackSelected(trackIndex)
                                val label    = fmt.label?.ifBlank { null }
                                    ?: fmt.language?.ifBlank { null }
                                    ?: "Subtitle ${trackIndex + 1}"
                                Row(
                                    modifier = Modifier.fillMaxWidth().padding(vertical = 4.dp),
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    RadioButton(selected = selected, onClick = {
                                        controller?.let { c ->
                                            c.trackSelectionParameters = c.trackSelectionParameters.buildUpon()
                                                .setTrackTypeDisabled(C.TRACK_TYPE_TEXT, false)
                                                .setOverrideForType(
                                                    TrackSelectionOverride(group.mediaTrackGroup, listOf(trackIndex))
                                                ).build()
                                        }
                                    })
                                    Text(label, fontSize = 14.sp)
                                }
                            }
                        }
                    }
                }
            },
            confirmButton = {
                TextButton(onClick = { showTrackDialog = false }) { Text("Done") }
            }
        )
    }

    // v5.4.235cc — Video quality picker dialog.
    if (showQualityDialog) {
        AlertDialog(
            onDismissRequest = { showQualityDialog = false },
            title = { Text("Video Quality") },
            text = {
                Column {
                    qualityChoices.forEach { (label, url) ->
                        val isCurrent = item?.streamUrl == url
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(vertical = 4.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            RadioButton(
                                selected = isCurrent,
                                onClick = {
                                    switchQuality(url)
                                    showQualityDialog = false
                                }
                            )
                            Text(label, fontSize = 14.sp)
                        }
                    }
                }
            },
            confirmButton = {
                TextButton(onClick = { showQualityDialog = false }) { Text("Done") }
            }
        )
    }
}
