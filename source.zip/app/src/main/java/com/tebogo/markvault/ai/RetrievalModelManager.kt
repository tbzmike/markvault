package com.tebogo.markvault.ai

/**
 * v5.4.74cc — Bookkeeping stub for which retrieval model is currently
 * marked active. Kept intentionally minimal: no external caller reads the
 * enum value today, but the stub gives the AI settings UI a stable
 * symbol to bind to. The enum member reflects the model actually shipped
 * in [com.tebogo.markvault.llm.ChatModelCatalog].
 */
object RetrievalModelManager {
    enum class Model {
        QWEN25_3B
    }

    private var activeModel = Model.QWEN25_3B

    fun setModel(model: Model) {
        activeModel = model
    }

    fun current(): Model = activeModel
}
