package com.tebogo.markvault.ai

import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock

/**
 * v5.4.60 — Tracks retrieval model selection and protects heavy inference.
 */
object RetrievalModelManager {

    enum class Model {
        QWEN2_5_1_5B,
        QWEN3_0_6B,
        PHI4_MINI,
        QWEN3_4B
    }

    private var activeModel = Model.QWEN2_5_1_5B

    private val inferenceMutex = Mutex()

    fun setModel(model: Model) {
        activeModel = model
    }

    fun current(): Model = activeModel

    suspend fun <T> withInferenceLock(block: suspend () -> T): T {
        return inferenceMutex.withLock {
            block()
        }
    }
}
