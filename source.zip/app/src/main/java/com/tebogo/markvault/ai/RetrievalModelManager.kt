package com.tebogo.markvault.ai

object RetrievalModelManager {
    enum class Model {
        GEMMA3_QWEN_0_6B
    }

    private var activeModel = Model.GEMMA3_QWEN_0_6B

    fun setModel(model: Model) {
        activeModel = model
    }

    fun current(): Model = activeModel
}
