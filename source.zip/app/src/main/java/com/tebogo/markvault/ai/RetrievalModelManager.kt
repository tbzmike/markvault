package com.tebogo.markvault.ai

object RetrievalModelManager {

    enum class Model {
        GEMMA3_GEMMA3_QWEN_0_6B_0_6B,
        SMOLLM2_360M
    }

    private var activeModel = Model.GEMMA3_GEMMA3_QWEN_0_6B_0_6B

    fun setModel(model: Model) {
        activeModel = model
    }

    fun current(): Model = activeModel
}
