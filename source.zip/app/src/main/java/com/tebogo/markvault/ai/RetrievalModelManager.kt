package com.tebogo.markvault.ai

import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.asStateFlow

/**
 * v5.4.60 — Retrieval model manager.
 *
 * Update 2:
 * Adds unified model selection support.
 */
object RetrievalModelManager {

    enum class Model {
        QWEN2_5_1_5B,
        QWEN3_0_6B,
        PHI4_MINI,
        QWEN3_4B
    }

    private var activeModel = Model.QWEN2_5_1_5B

    private val _activeModelFlow = MutableStateFlow(activeModel)
    val activeModelFlow = _activeModelFlow.asStateFlow()

    private val inferenceMutex = Mutex()

    fun setModel(model: Model) {
        activeModel = model
        _activeModelFlow.value = model
    }

    fun current(): Model = activeModel

    suspend fun <T> withInferenceLock(block: suspend () -> T): T {
        return inferenceMutex.withLock {
            block()
        }
    }
}
