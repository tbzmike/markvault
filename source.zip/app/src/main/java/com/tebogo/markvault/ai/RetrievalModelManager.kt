package com.tebogo.markvault.ai

/**
 * Retrieval model selection foundation.
 * Supports switching between installed local models.
 */
object RetrievalModelManager {

    enum class Model {
        GEMMA_3,
        QWEN,
        SMOLLM2_360M
    }

    private var activeModel: Model = Model.GEMMA_3

    fun setModel(model: Model) {
        activeModel = model
    }

    fun current(): Model = activeModel
}
