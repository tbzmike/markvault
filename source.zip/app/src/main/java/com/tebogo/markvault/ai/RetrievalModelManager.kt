package com.tebogo.markvault.ai

/**
 * v5.4.120cc — Bookkeeping stub for which retrieval model is currently
 * marked active. Kept intentionally minimal: no external caller reads the
 * enum value today, but the stub gives the AI settings UI a stable
 * symbol to bind to. The enum member reflects the model actually shipped
 * in [com.tebogo.markvault.llm.ChatModelCatalog].
 *
 * v5.4.120cc: replaced PHI4_MINI with QWEN3_4B to mirror the removal of
 * Phi-4-mini and Qwen3 0.6B from ChatModelCatalog and the addition of
 * Qwen3-4B-Instruct-2507 as the heavy option.
 */
object RetrievalModelManager {
    enum class Model {
        QWEN3_4B
    }

    private var activeModel = Model.QWEN3_4B

    fun setModel(model: Model) {
        activeModel = model
    }

    fun current(): Model = activeModel
}
