package com.tebogo.markvault.ai

/**
 * v5.4.59 — Tracks which on-device retrieval model is currently active for
 * multi-query expansion. Maps to the corresponding [ChatModelDescriptor] id
 * in [com.tebogo.markvault.llm.ChatModelCatalog].
 */
object RetrievalModelManager {
    enum class Model {
        QWEN3_0_6B,
        QWEN3_4B
    }

    private var activeModel = Model.QWEN3_0_6B

    fun setModel(model: Model) {
        activeModel = model
    }

    fun current(): Model = activeModel
}
