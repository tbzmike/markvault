package com.tebogo.markvault.ai

/**
 * Single local LLM used for multi-query RAG retrieval.
 */
object RetrievalModelManager {

    enum class Model {
        GEMMA3_GEMMA3_QWEN_0_6B_0_6B
    }

    private var activeModel = Model.GEMMA3_GEMMA3_QWEN_0_6B_0_6B

    fun setModel(model: Model) {
        activeModel = model
    }

    fun current(): Model = activeModel
}
