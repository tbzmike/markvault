package com.tebogo.markvault.ai

import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.asStateFlow

/**
 * v5.4.73 — Retrieval model manager with inference mutex.
 */
object RetrievalModelManager {

    enum class Model {
        QWEN3_0_6B,
        QWEN2_5_1_5B,
        QWEN3_4B,
        PHI4_MINI
    }

    private var activeModel = Model.QWEN3_0_6B

    private val _activeModelFlow = MutableStateFlow(activeModel)
    val activeModelFlow = _activeModelFlow.asStateFlow()

    private val inferenceMutex = Mutex()

    fun setModel(model: Model) {
        activeModel = model
        _activeModelFlow.value = model
    }

    fun current(): Model = activeModel

    suspend fun <T> withInferenceLock(block: suspend () -> T): T {
        return inferenceMutex.withLock { block() }
    }
}
