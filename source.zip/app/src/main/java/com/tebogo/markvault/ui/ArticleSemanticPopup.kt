package com.tebogo.markvault.ui

import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.selection.SelectionContainer
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Close
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.SmallFloatingActionButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.tebogo.markvault.AppViewModel
import kotlinx.coroutines.delay
import kotlin.math.roundToInt

/**
 * v5.4.129cc — In-article semantic-search popup.
 *
 * Shown after the user taps the 🧠 brain button on the reader toolbar
 * and the ViewModel has ranked passages by cosine similarity to the
 * current query. The popup:
 *
 *   • Types the found passages out top-to-bottom, roughly word-by-word,
 *     so it feels like the answer is being composed on the fly.
 *   • Is scrollable and its content is selectable (long-press to copy)
 *     so users can lift a phrase into another app.
 *   • Has a title bar with a — minimize button and an × close button.
 *   • The title bar is drag-handle: press-and-drag to reposition anywhere
 *     on screen. The popup remembers where you left it during the same
 *     open, so scrolling the article underneath doesn't reset its spot.
 *
 * When minimized, the popup collapses into a compact pill anchored to
 * the bottom of the reader (see [MinimizedPopupPill]). The reader's
 * brain button pulses gently while a minimized popup exists — a
 * heartbeat-style "you have one waiting" nudge — via [PumpingBrainFab].
 */

@Composable
fun ArticlePopupOverlay(
    query: String,
    passages: List<String>,
    onClose: () -> Unit,
    onMinimize: () -> Unit,
    onCycleBlur: () -> Unit = {},
    onOpenArticle: (() -> Unit)? = null,
    onOpenUrl: ((String) -> Unit)? = null,
    // v5.4.141cc — Mode toggle: HIGHLIGHTS (semantic passages, default)
    // or LLM_SUMMARY (key-point bullet list from the on-device LLM).
    // The two chips in the sub-header row switch between them; the
    // caller owns the state via [onToggleMode].
    mode: AppViewModel.ArticlePopupMode = AppViewModel.ArticlePopupMode.HIGHLIGHTS,
    onToggleMode: () -> Unit = {},
    modifier: Modifier = Modifier
) {
    // v5.4.141cc — Mode-aware joining:
    //   HIGHLIGHTS   → passages separated by a thin horizontal rule so
    //                  each excerpt reads as a distinct pull-quote.
    //   LLM_SUMMARY → passages are already numbered bullet lines from
    //                  the LLM; join with a single newline only.
    val fullText: String = remember(passages, mode) {
        when (mode) {
            AppViewModel.ArticlePopupMode.LLM_SUMMARY ->
                passages.joinToString(separator = "\n")
            AppViewModel.ArticlePopupMode.HIGHLIGHTS ->
                passages.joinToString(separator = "\n\n\u2500 \u2500 \u2500\n\n")
        }
    }

    // v5.4.130cc — Parse the markdown ONCE per new passage set so
    // formatting spans (bold, italic, links, colors) stay attached
    // to their characters as the typewriter reveals them.
    val linkColor: Color = MaterialTheme.colorScheme.primary
    val annotated: AnnotatedString = remember(fullText, linkColor, onOpenUrl) {
        PopupMarkdownRenderer.render(
            rawText = fullText,
            linkColor = linkColor,
            onLinkClick = onOpenUrl
        )
    }
    val plainText: String = remember(annotated) { annotated.text }

    // Persistent drag offset. Reset on query change (new search = fresh position).
    var offsetX by remember(query) { mutableStateOf(0f) }
    var offsetY by remember(query) { mutableStateOf(0f) }

    // Typewriter state — progress in PLAIN-TEXT index space.
    var visibleLength by remember(plainText) { mutableIntStateOf(0) }
    var typingDone by remember(plainText) { mutableStateOf(false) }

    // v5.4.141cc — Shared scroll state hoisted out of SelectionContainer
    // so the LaunchedEffect below can drive it.  Must be remembered
    // independently of the Column so recompositions don't reset position.
    val scrollState = androidx.compose.foundation.rememberScrollState()

    // v5.4.141cc — Auto-scroll: chase the typewriter cursor to the
    // bottom of revealed text after every word so the user always sees
    // the latest output without manually scrolling.  Only fires while
    // typing is in progress; once done the user can freely scroll.
    LaunchedEffect(visibleLength) {
        if (!typingDone) {
            scrollState.animateScrollTo(scrollState.maxValue)
        }
    }

    LaunchedEffect(plainText) {
        visibleLength = 0
        typingDone = false
        if (plainText.isEmpty()) {
            typingDone = true
            return@LaunchedEffect
        }
        val len: Int = plainText.length
        var i = 0
        while (i < len) {
            while (i < len && plainText[i].isWhitespace()) i++
            while (i < len && !plainText[i].isWhitespace()) i++
            visibleLength = i
            val last: Char = if (i > 0) plainText[i - 1] else ' '
            // v5.4.131cc — Delays tuned to avoid accessibility-tree OOM.
            val pause: Long = when (last) {
                '.', '!', '?' -> 160L
                ',', ';', ':' -> 90L
                '\u2500' -> 320L
                '\n' -> 200L
                else -> 45L
            }
            delay(pause)
        }
        visibleLength = len
        typingDone = true
    }

    // Clip AnnotatedString to visibleLength — spans remain attached.
    val displayAnnotated: AnnotatedString = remember(visibleLength, annotated) {
        val cap: Int = visibleLength.coerceAtMost(annotated.length)
        if (cap <= 0) AnnotatedString("") else annotated.subSequence(0, cap)
    }

    // v5.4.141cc — Mode label shown in the sub-header chips.
    val isHighlights = mode == AppViewModel.ArticlePopupMode.HIGHLIGHTS

    Surface(
        modifier = modifier
            .offset { IntOffset(offsetX.roundToInt(), offsetY.roundToInt()) }
            .widthIn(min = 260.dp, max = 380.dp)
            .heightIn(min = 200.dp, max = 500.dp)
            .border(
                width = 2.dp,
                color = MaterialTheme.colorScheme.primary.copy(alpha = 0.55f),
                shape = RoundedCornerShape(18.dp)
            ),
        shape = RoundedCornerShape(18.dp),
        color = MaterialTheme.colorScheme.surface,
        tonalElevation = 10.dp,
        shadowElevation = 18.dp
    ) {
        Column {
            // ── Title bar — drag handle + open-article + blur + minimize + close ──
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .pointerInput(query) {
                        detectDragGestures { _, drag ->
                            offsetX += drag.x
                            offsetY += drag.y
                        }
                    }
                    .padding(start = 14.dp, end = 6.dp, top = 8.dp, bottom = 4.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "\uD83D\uDD0D  " + query,
                    fontWeight = FontWeight.Bold,
                    fontSize = 15.sp,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis,
                    modifier = Modifier
                        .padding(end = 4.dp)
                        .fillMaxWidth(0.50f)
                )
                Spacer(Modifier.width(2.dp))
                if (onOpenArticle != null) {
                    IconButton(onClick = onOpenArticle, modifier = Modifier.size(32.dp)) {
                        Text(text = "\uD83D\uDCD6", fontSize = 16.sp)  // 📖
                    }
                }
                IconButton(onClick = onCycleBlur, modifier = Modifier.size(32.dp)) {
                    Text(text = "\uD83C\uDF2B\uFE0F", fontSize = 15.sp)  // 🌫️
                }
                IconButton(onClick = onMinimize, modifier = Modifier.size(32.dp)) {
                    Text(
                        text = "\u2013",
                        fontSize = 22.sp,
                        fontWeight = FontWeight.Bold,
                        modifier = Modifier.padding(bottom = 6.dp)
                    )
                }
                IconButton(onClick = onClose, modifier = Modifier.size(32.dp)) {
                    Icon(imageVector = Icons.Filled.Close, contentDescription = "Close")
                }
            }

            // ── v5.4.141cc — Mode-toggle sub-header row ──────────────────────
            // Two compact chips below the title bar. The active mode chip is
            // filled (primary container); the inactive one is outlined/ghost.
            // Tapping the inactive chip calls [onToggleMode] which triggers the
            // appropriate backend (semantic search or LLM summary) and replaces
            // the popup content. Mutually exclusive: only one is ever "on".
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 12.dp, vertical = 4.dp),
                horizontalArrangement = Arrangement.spacedBy(8.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                // Chip: Highlights (Mode A)
                val hlBg = if (isHighlights)
                    MaterialTheme.colorScheme.primaryContainer
                else
                    MaterialTheme.colorScheme.surfaceVariant
                val hlFg = if (isHighlights)
                    MaterialTheme.colorScheme.onPrimaryContainer
                else
                    MaterialTheme.colorScheme.onSurfaceVariant

                Box(
                    modifier = Modifier
                        .background(hlBg, RoundedCornerShape(20.dp))
                        .clickable(enabled = !isHighlights, onClick = onToggleMode)
                        .padding(horizontal = 10.dp, vertical = 5.dp)
                ) {
                    Text(
                        text = "\u2728 Highlights",
                        fontSize = 11.sp,
                        fontWeight = if (isHighlights) FontWeight.Bold else FontWeight.Normal,
                        color = hlFg
                    )
                }

                // Chip: AI Summary (Mode B)
                val sumBg = if (!isHighlights)
                    MaterialTheme.colorScheme.primaryContainer
                else
                    MaterialTheme.colorScheme.surfaceVariant
                val sumFg = if (!isHighlights)
                    MaterialTheme.colorScheme.onPrimaryContainer
                else
                    MaterialTheme.colorScheme.onSurfaceVariant

                Box(
                    modifier = Modifier
                        .background(sumBg, RoundedCornerShape(20.dp))
                        .clickable(enabled = isHighlights, onClick = onToggleMode)
                        .padding(horizontal = 10.dp, vertical = 5.dp)
                ) {
                    Text(
                        text = "\uD83E\uDD16 AI Summary",
                        fontSize = 11.sp,
                        fontWeight = if (!isHighlights) FontWeight.Bold else FontWeight.Normal,
                        color = sumFg
                    )
                }
            }

            HorizontalDivider(
                thickness = 0.6.dp,
                color = MaterialTheme.colorScheme.outlineVariant
            )

            // ── Scrollable + selectable content ──────────────────────────────
            // scrollState is hoisted above so LaunchedEffect can drive it.
            SelectionContainer {
                Column(
                    modifier = Modifier
                        .verticalScroll(scrollState)
                        .padding(horizontal = 16.dp, vertical = 14.dp)
                ) {
                    Text(
                        text = displayAnnotated,
                        fontSize = 15.sp,
                        lineHeight = 22.sp,
                        color = MaterialTheme.colorScheme.onSurface
                    )
                    if (!typingDone) {
                        Text(
                            text = "\u258A",
                            color = MaterialTheme.colorScheme.primary,
                            fontSize = 15.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }
                }
            }
        }
    }
}

/**
 * Loading state — shown briefly while the embedder is chunking + scoring.
 * On a typical article this is well under a second, so the indicator is
 * intentionally lightweight (no separate typewriter progress).
 */
@Composable
fun ArticlePopupLoading(
    query: String,
    onCancel: () -> Unit,
    modifier: Modifier = Modifier
) {
    Surface(
        modifier = modifier
            .widthIn(min = 240.dp, max = 340.dp),
        shape = RoundedCornerShape(18.dp),
        color = MaterialTheme.colorScheme.surface,
        tonalElevation = 8.dp,
        shadowElevation = 14.dp
    ) {
        Row(
            modifier = Modifier.padding(
                start = 16.dp, end = 8.dp, top = 12.dp, bottom = 12.dp
            ),
            verticalAlignment = Alignment.CenterVertically
        ) {
            CircularProgressIndicator(
                modifier = Modifier.size(18.dp),
                strokeWidth = 2.dp
            )
            Spacer(Modifier.width(12.dp))
            Text(
                text = "Reading article for \u201C" + query + "\u201D\u2026",
                fontSize = 14.sp,
                maxLines = 2,
                overflow = TextOverflow.Ellipsis,
                modifier = Modifier.fillMaxWidth(0.72f)
            )
            Spacer(Modifier.width(4.dp))
            IconButton(onClick = onCancel, modifier = Modifier.size(32.dp)) {
                Icon(Icons.Filled.Close, contentDescription = "Cancel")
            }
        }
    }
}

/**
 * Empty state — shown when the semantic pass ran but no passage cleared
 * the similarity threshold. Non-blocking, self-dismisses after 2 seconds
 * OR when the user taps close.
 */
@Composable
fun ArticlePopupEmpty(
    query: String,
    onClose: () -> Unit,
    modifier: Modifier = Modifier
) {
    LaunchedEffect(query) {
        delay(2400L)
        onClose()
    }
    Surface(
        modifier = modifier
            .widthIn(min = 240.dp, max = 340.dp),
        shape = RoundedCornerShape(18.dp),
        color = MaterialTheme.colorScheme.surface,
        tonalElevation = 8.dp,
        shadowElevation = 14.dp
    ) {
        Row(
            modifier = Modifier.padding(
                start = 16.dp, end = 8.dp, top = 12.dp, bottom = 12.dp
            ),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                text = "\uD83E\uDD14",
                fontSize = 18.sp
            )
            Spacer(Modifier.width(12.dp))
            Text(
                text = "No strongly matching passages for \u201C" + query + "\u201D",
                fontSize = 14.sp,
                maxLines = 3,
                overflow = TextOverflow.Ellipsis,
                modifier = Modifier.fillMaxWidth(0.78f)
            )
            IconButton(onClick = onClose, modifier = Modifier.size(28.dp)) {
                Icon(Icons.Filled.Close, contentDescription = "Close")
            }
        }
    }
}

/**
 * Minimized pill anchored to the bottom of the reader. Tap the pill body
 * to maximize; tap the × to dismiss the popup entirely.
 */
@Composable
fun MinimizedPopupPill(
    query: String,
    onMaximize: () -> Unit,
    onClose: () -> Unit,
    modifier: Modifier = Modifier
) {
    Surface(
        modifier = modifier
            .heightIn(min = 40.dp)
            .widthIn(max = 260.dp)
            .clickable(onClick = onMaximize),
        shape = RoundedCornerShape(20.dp),
        color = MaterialTheme.colorScheme.primaryContainer,
        tonalElevation = 4.dp,
        shadowElevation = 6.dp
    ) {
        Row(
            modifier = Modifier.padding(start = 14.dp, end = 4.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(6.dp)
        ) {
            Text(
                text = "\uD83E\uDDE0",
                fontSize = 15.sp,
                modifier = Modifier.padding(vertical = 8.dp)
            )
            Text(
                text = query,
                fontSize = 13.sp,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis,
                color = MaterialTheme.colorScheme.onPrimaryContainer,
                modifier = Modifier
                    .padding(vertical = 8.dp)
                    .widthIn(max = 170.dp)
            )
            IconButton(
                onClick = onClose,
                modifier = Modifier.size(32.dp)
            ) {
                Icon(
                    Icons.Filled.Close,
                    contentDescription = "Close",
                    modifier = Modifier.size(16.dp)
                )
            }
        }
    }
}

/**
 * Brain-emoji FAB. When [pulsing] is true, scales up and down like a
 * heartbeat — used to alert the user that a popup is minimized and
 * waiting. When [pulsing] is false, the FAB is static.
 *
 * The heartbeat cadence is intentionally not perfectly smooth — a
 * brief "double-thump" then rest, roughly matching a real pulse.
 */
@Composable
fun PumpingBrainFab(
    pulsing: Boolean,
    busy: Boolean,
    onClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    val transition = rememberInfiniteTransition(label = "brain-pulse")
    val scale: Float by transition.animateFloat(
        initialValue = 1.0f,
        targetValue = if (pulsing) 1.16f else 1.0f,
        animationSpec = infiniteRepeatable(
            animation = tween(
                durationMillis = 620,
                easing = FastOutSlowInEasing
            ),
            repeatMode = RepeatMode.Reverse
        ),
        label = "brain-scale"
    )
    SmallFloatingActionButton(
        onClick = onClick,
        modifier = modifier,
        containerColor = MaterialTheme.colorScheme.tertiaryContainer
    ) {
        if (busy) {
            CircularProgressIndicator(
                modifier = Modifier.size(16.dp),
                strokeWidth = 2.dp
            )
        } else {
            Text(
                text = "\uD83E\uDDE0",
                fontSize = 16.sp,
                modifier = Modifier.graphicsLayer(
                    scaleX = if (pulsing) scale else 1.0f,
                    scaleY = if (pulsing) scale else 1.0f
                )
            )
        }
    }
}

/**
 * v5.4.132cc — Pumping-heart FAB for the SearchScreen bottom-left.
 *
 * Same animation as [PumpingBrainFab] but shows a heart instead of a
 * brain. Used to trigger the multi-article popup — pulls the top-N
 * currently-displayed search results, extracts semantic passages
 * from each, and shows them in the same typewriter popup the reader
 * screens use. Always pulses by default (it's an invitation, not a
 * status indicator) — pass [pulsing] = false to hold it still.
 */
@Composable
fun PumpingHeartFab(
    pulsing: Boolean,
    busy: Boolean,
    onClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    val transition = rememberInfiniteTransition(label = "heart-pulse")
    val scale: Float by transition.animateFloat(
        initialValue = 1.0f,
        targetValue = if (pulsing) 1.18f else 1.0f,
        animationSpec = infiniteRepeatable(
            animation = tween(
                durationMillis = 560,
                easing = FastOutSlowInEasing
            ),
            repeatMode = RepeatMode.Reverse
        ),
        label = "heart-scale"
    )
    SmallFloatingActionButton(
        onClick = onClick,
        modifier = modifier,
        containerColor = MaterialTheme.colorScheme.errorContainer
    ) {
        if (busy) {
            CircularProgressIndicator(
                modifier = Modifier.size(16.dp),
                strokeWidth = 2.dp
            )
        } else {
            Text(
                text = "\uD83D\uDC97",  // 💗 sparkling heart — reads better than the plain ❤️
                fontSize = 16.sp,
                modifier = Modifier.graphicsLayer(
                    scaleX = if (pulsing) scale else 1.0f,
                    scaleY = if (pulsing) scale else 1.0f
                )
            )
        }
    }
}
