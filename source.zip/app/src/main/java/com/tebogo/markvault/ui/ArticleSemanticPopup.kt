package com.tebogo.markvault.ui

import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.ui.layout.onGloballyPositioned
import androidx.compose.ui.layout.boundsInWindow
import androidx.compose.ui.platform.LocalConfiguration
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.selection.SelectionContainer
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Close
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Slider
import androidx.compose.material3.SmallFloatingActionButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.tebogo.markvault.AppViewModel
import kotlinx.coroutines.delay
import kotlin.math.roundToInt

/**
 * v5.4.129cc — In-article semantic-search popup.
 *
 * Shown after the user taps the 🧠 brain button on the reader toolbar
 * and the ViewModel has ranked passages by cosine similarity to the
 * current query. The popup:
 *
 *   • Types the found passages out top-to-bottom, roughly word-by-word,
 *     so it feels like the answer is being composed on the fly.
 *   • Is scrollable and its content is selectable (long-press to copy)
 *     so users can lift a phrase into another app.
 *   • Has a title bar with a — minimize button and an × close button.
 *   • The title bar is drag-handle: press-and-drag to reposition anywhere
 *     on screen. The popup remembers where you left it during the same
 *     open, so scrolling the article underneath doesn't reset its spot.
 *
 * When minimized, the popup collapses into a compact pill anchored to
 * the bottom of the reader (see [MinimizedPopupPill]). The reader's
 * brain button pulses gently while a minimized popup exists — a
 * heartbeat-style "you have one waiting" nudge — via [PumpingBrainFab].
 */

@Composable
fun ArticlePopupOverlay(
    query: String,
    passages: List<String>,
    onClose: () -> Unit,
    onMinimize: () -> Unit,
    onCycleBlur: () -> Unit = {},
    onOpenArticle: (() -> Unit)? = null,
    onOpenUrl: ((String) -> Unit)? = null,
    // v5.4.141cc — Mode toggle: HIGHLIGHTS (semantic passages, default)
    // or LLM_SUMMARY (key-point bullet list from the on-device LLM).
    // The two chips in the sub-header row switch between them; the
    // caller owns the state via [onToggleMode].
    mode: AppViewModel.ArticlePopupMode = AppViewModel.ArticlePopupMode.HIGHLIGHTS,
    onToggleMode: () -> Unit = {},
    // v5.4.150cc — Typing speed is now owned by the ViewModel and persisted
    // to DataStore so the slider survives app exit. Callers observe
    // vm.popupTypingSpeed and pass the value + a write-back lambda here.
    typingSpeed: Float = 1.0f,
    onTypingSpeedChange: (Float) -> Unit = {},
    modifier: Modifier = Modifier
) {
    // v5.4.141cc — Mode-aware joining:
    //   HIGHLIGHTS   → passages separated by a thin horizontal rule so
    //                  each excerpt reads as a distinct pull-quote.
    //   LLM_SUMMARY → passages are already numbered bullet lines from
    //                  the LLM; join with a single newline only.
    val fullText: String = remember(passages, mode) {
        when (mode) {
            AppViewModel.ArticlePopupMode.LLM_SUMMARY ->
                passages.joinToString(separator = "\n")
            AppViewModel.ArticlePopupMode.HIGHLIGHTS ->
                passages.joinToString(separator = "\n\n\u2500 \u2500 \u2500\n\n")
        }
    }

    // v5.4.130cc — Parse the markdown ONCE per new passage set so
    // formatting spans (bold, italic, links, colors) stay attached
    // to their characters as the typewriter reveals them.
    val linkColor: Color = MaterialTheme.colorScheme.primary
    val annotated: AnnotatedString = remember(fullText, linkColor, onOpenUrl) {
        PopupMarkdownRenderer.render(
            rawText = fullText,
            linkColor = linkColor,
            onLinkClick = onOpenUrl
        )
    }
    val plainText: String = remember(annotated) { annotated.text }

    // Persistent drag offset. Reset on query change (new search = fresh position).
    var offsetX by remember(query) { mutableStateOf(0f) }
    var offsetY by remember(query) { mutableStateOf(0f) }

    // Typewriter state — progress in PLAIN-TEXT index space.
    var visibleLength by remember(plainText) { mutableIntStateOf(0) }
    var typingDone by remember(plainText) { mutableStateOf(false) }

    // v5.4.150cc — typingSpeed is now a parameter backed by ViewModel/DataStore.
    // The local remember {} was removed so the persisted value is always used
    // and changes are written back via onTypingSpeedChange → vm.setPopupTypingSpeed.

    // v5.4.141cc — Shared scroll state hoisted out of SelectionContainer
    // so the LaunchedEffect below can drive it.  Must be remembered
    // independently of the Column so recompositions don't reset position.
    val scrollState = androidx.compose.foundation.rememberScrollState()

    // v5.4.141cc — Auto-scroll: chase the typewriter cursor to the
    // bottom of revealed text after every word so the user always sees
    // the latest output without manually scrolling.  Only fires while
    // typing is in progress; once done the user can freely scroll.
    LaunchedEffect(visibleLength) {
        if (!typingDone) {
            scrollState.animateScrollTo(scrollState.maxValue)
        }
    }

    LaunchedEffect(plainText) {
        visibleLength = 0
        typingDone = false
        if (plainText.isEmpty()) {
            typingDone = true
            return@LaunchedEffect
        }
        val len: Int = plainText.length
        var i = 0
        while (i < len) {
            while (i < len && plainText[i].isWhitespace()) i++
            while (i < len && !plainText[i].isWhitespace()) i++
            visibleLength = i
            val last: Char = if (i > 0) plainText[i - 1] else ' '
            // v5.4.131cc — Delays tuned to avoid accessibility-tree OOM.
            // v5.4.145cc — Divided by typingSpeed so the slider takes
            // effect immediately on the next word without restarting the
            // coroutine. typingSpeed is read fresh every iteration.
            val baseMs: Long = when (last) {
                '.', '!', '?' -> 160L
                ',', ';', ':' -> 90L
                '\u2500' -> 320L
                '\n' -> 200L
                else -> 45L
            }
            val pause: Long = (baseMs / typingSpeed).toLong().coerceAtLeast(8L)
            delay(pause)
        }
        visibleLength = len
        typingDone = true
    }

    // Clip AnnotatedString to visibleLength — spans remain attached.
    val displayAnnotated: AnnotatedString = remember(visibleLength, annotated) {
        val cap: Int = visibleLength.coerceAtMost(annotated.length)
        if (cap <= 0) AnnotatedString("") else annotated.subSequence(0, cap)
    }

    // v5.4.141cc — Mode label shown in the sub-header chips.
    val isHighlights = mode == AppViewModel.ArticlePopupMode.HIGHLIGHTS

    Surface(
        modifier = modifier
            .offset { IntOffset(offsetX.roundToInt(), offsetY.roundToInt()) }
            .widthIn(min = 260.dp, max = 380.dp)
            .heightIn(min = 200.dp, max = 500.dp)
            .border(
                width = 2.dp,
                color = MaterialTheme.colorScheme.primary.copy(alpha = 0.55f),
                shape = RoundedCornerShape(18.dp)
            ),
        shape = RoundedCornerShape(18.dp),
        color = MaterialTheme.colorScheme.surface,
        tonalElevation = 10.dp,
        shadowElevation = 18.dp
    ) {
        Column {
            // ── Title bar — drag handle + open-article + blur + minimize + close ──
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .pointerInput(query) {
                        detectDragGestures { _, drag ->
                            offsetX += drag.x
                            offsetY += drag.y
                        }
                    }
                    .padding(start = 14.dp, end = 6.dp, top = 8.dp, bottom = 4.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "\uD83D\uDD0D  " + query,
                    fontWeight = FontWeight.Bold,
                    fontSize = 15.sp,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis,
                    modifier = Modifier
                        .padding(end = 4.dp)
                        .fillMaxWidth(0.50f)
                )
                Spacer(Modifier.width(2.dp))
                if (onOpenArticle != null) {
                    IconButton(onClick = onOpenArticle, modifier = Modifier.size(32.dp)) {
                        Text(text = "\uD83D\uDCD6", fontSize = 16.sp)  // 📖
                    }
                }
                IconButton(onClick = onCycleBlur, modifier = Modifier.size(32.dp)) {
                    Text(text = "\uD83C\uDF2B\uFE0F", fontSize = 15.sp)  // 🌫️
                }
                IconButton(onClick = onMinimize, modifier = Modifier.size(32.dp)) {
                    Text(
                        text = "\u2013",
                        fontSize = 22.sp,
                        fontWeight = FontWeight.Bold,
                        modifier = Modifier.padding(bottom = 6.dp)
                    )
                }
                IconButton(onClick = onClose, modifier = Modifier.size(32.dp)) {
                    Icon(imageVector = Icons.Filled.Close, contentDescription = "Close")
                }
            }

            // ── v5.4.141cc — Mode-toggle sub-header row ──────────────────────
            // Two compact chips below the title bar. The active mode chip is
            // filled (primary container); the inactive one is outlined/ghost.
            // Tapping the inactive chip calls [onToggleMode] which triggers the
            // appropriate backend (semantic search or LLM summary) and replaces
            // the popup content. Mutually exclusive: only one is ever "on".
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 12.dp, vertical = 4.dp),
                horizontalArrangement = Arrangement.spacedBy(8.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                // Chip: Highlights (Mode A)
                val hlBg = if (isHighlights)
                    MaterialTheme.colorScheme.primaryContainer
                else
                    MaterialTheme.colorScheme.surfaceVariant
                val hlFg = if (isHighlights)
                    MaterialTheme.colorScheme.onPrimaryContainer
                else
                    MaterialTheme.colorScheme.onSurfaceVariant

                Box(
                    modifier = Modifier
                        .background(hlBg, RoundedCornerShape(20.dp))
                        .clickable(enabled = !isHighlights, onClick = onToggleMode)
                        .padding(horizontal = 10.dp, vertical = 5.dp)
                ) {
                    Text(
                        text = "\u2728 Highlights",
                        fontSize = 11.sp,
                        fontWeight = if (isHighlights) FontWeight.Bold else FontWeight.Normal,
                        color = hlFg
                    )
                }

                // Chip: AI Summary (Mode B)
                val sumBg = if (!isHighlights)
                    MaterialTheme.colorScheme.primaryContainer
                else
                    MaterialTheme.colorScheme.surfaceVariant
                val sumFg = if (!isHighlights)
                    MaterialTheme.colorScheme.onPrimaryContainer
                else
                    MaterialTheme.colorScheme.onSurfaceVariant

                Box(
                    modifier = Modifier
                        .background(sumBg, RoundedCornerShape(20.dp))
                        .clickable(enabled = isHighlights, onClick = onToggleMode)
                        .padding(horizontal = 10.dp, vertical = 5.dp)
                ) {
                    Text(
                        text = "\uD83E\uDD16 AI Summary",
                        fontSize = 11.sp,
                        fontWeight = if (!isHighlights) FontWeight.Bold else FontWeight.Normal,
                        color = sumFg
                    )
                }
            }

            // ── v5.4.147cc — Typing-speed control (expanded range) ──────────
            // Compact slider row below the mode chips. Adjusts the typewriter
            // delay multiplier live — no restart needed. 0.1× is fastest
            // (quick reading pace); 2.0× is slowest pace for detailed reading.
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(start = 12.dp, end = 12.dp, top = 2.dp, bottom = 2.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                Text(
                    text = "\uD83D\uDC22",  // 🐢 slow end
                    fontSize = 12.sp
                )
                Slider(
                    value = typingSpeed,
                    onValueChange = { onTypingSpeedChange(it) },
                    valueRange = 0.1f..2.0f,
                    steps = 19,  // v5.4.147cc — 20 discrete steps (0.1, 0.2, 0.3... 2.0)
                    modifier = Modifier.weight(1f)
                )
                Text(
                    text = "\u26A1",  // ⚡ fast end
                    fontSize = 12.sp
                )
                Text(
                    text = "${"%.1f".format(typingSpeed)}\u00D7",  // e.g. 1.0×
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Medium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    modifier = Modifier.width(30.dp)
                )
            }

            HorizontalDivider(
                thickness = 0.6.dp,
                color = MaterialTheme.colorScheme.outlineVariant
            )

            // ── Scrollable + selectable content ──────────────────────────────
            // scrollState is hoisted above so LaunchedEffect can drive it.
            SelectionContainer {
                Column(
                    modifier = Modifier
                        .verticalScroll(scrollState)
                        .padding(horizontal = 16.dp, vertical = 14.dp)
                ) {
                    Text(
                        text = displayAnnotated,
                        fontSize = 15.sp,
                        lineHeight = 22.sp,
                        color = MaterialTheme.colorScheme.onSurface
                    )
                    if (!typingDone) {
                        Text(
                            text = "\u258A",
                            color = MaterialTheme.colorScheme.primary,
                            fontSize = 15.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }
                }
            }
        }
    }
}

/**
 * Loading state — shown briefly while the embedder is chunking + scoring.
 * On a typical article this is well under a second, so the indicator is
 * intentionally lightweight (no separate typewriter progress).
 */
@Composable
fun ArticlePopupLoading(
    query: String,
    onCancel: () -> Unit,
    modifier: Modifier = Modifier
) {
    Surface(
        modifier = modifier
            .widthIn(min = 240.dp, max = 340.dp),
        shape = RoundedCornerShape(18.dp),
        color = MaterialTheme.colorScheme.surface,
        tonalElevation = 8.dp,
        shadowElevation = 14.dp
    ) {
        Row(
            modifier = Modifier.padding(
                start = 16.dp, end = 8.dp, top = 12.dp, bottom = 12.dp
            ),
            verticalAlignment = Alignment.CenterVertically
        ) {
            CircularProgressIndicator(
                modifier = Modifier.size(18.dp),
                strokeWidth = 2.dp
            )
            Spacer(Modifier.width(12.dp))
            Text(
                text = "Reading article for \u201C" + query + "\u201D\u2026",
                fontSize = 14.sp,
                maxLines = 2,
                overflow = TextOverflow.Ellipsis,
                modifier = Modifier.fillMaxWidth(0.72f)
            )
            Spacer(Modifier.width(4.dp))
            IconButton(onClick = onCancel, modifier = Modifier.size(32.dp)) {
                Icon(Icons.Filled.Close, contentDescription = "Cancel")
            }
        }
    }
}

/**
 * Empty state — shown when the semantic pass ran but no passage cleared
 * the similarity threshold. Non-blocking, self-dismisses after 2 seconds
 * OR when the user taps close.
 */
@Composable
fun ArticlePopupEmpty(
    query: String,
    onClose: () -> Unit,
    modifier: Modifier = Modifier
) {
    LaunchedEffect(query) {
        delay(2400L)
        onClose()
    }
    Surface(
        modifier = modifier
            .widthIn(min = 240.dp, max = 340.dp),
        shape = RoundedCornerShape(18.dp),
        color = MaterialTheme.colorScheme.surface,
        tonalElevation = 8.dp,
        shadowElevation = 14.dp
    ) {
        Row(
            modifier = Modifier.padding(
                start = 16.dp, end = 8.dp, top = 12.dp, bottom = 12.dp
            ),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                text = "\uD83E\uDD14",
                fontSize = 18.sp
            )
            Spacer(Modifier.width(12.dp))
            Text(
                text = "No strongly matching passages for \u201C" + query + "\u201D",
                fontSize = 14.sp,
                maxLines = 3,
                overflow = TextOverflow.Ellipsis,
                modifier = Modifier.fillMaxWidth(0.78f)
            )
            IconButton(onClick = onClose, modifier = Modifier.size(28.dp)) {
                Icon(Icons.Filled.Close, contentDescription = "Close")
            }
        }
    }
}

/**
 * Minimized pill anchored to the bottom of the reader. Tap the pill body
 * to maximize; tap the × to dismiss the popup entirely.
 */
@Composable
fun MinimizedPopupPill(
    query: String,
    onMaximize: () -> Unit,
    onClose: () -> Unit,
    modifier: Modifier = Modifier
) {
    Surface(
        modifier = modifier
            .heightIn(min = 40.dp)
            .widthIn(max = 260.dp)
            .clickable(onClick = onMaximize),
        shape = RoundedCornerShape(20.dp),
        color = MaterialTheme.colorScheme.primaryContainer,
        tonalElevation = 4.dp,
        shadowElevation = 6.dp
    ) {
        Row(
            modifier = Modifier.padding(start = 14.dp, end = 4.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(6.dp)
        ) {
            Text(
                text = "\uD83E\uDDE0",
                fontSize = 15.sp,
                modifier = Modifier.padding(vertical = 8.dp)
            )
            Text(
                text = query,
                fontSize = 13.sp,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis,
                color = MaterialTheme.colorScheme.onPrimaryContainer,
                modifier = Modifier
                    .padding(vertical = 8.dp)
                    .widthIn(max = 170.dp)
            )
            IconButton(
                onClick = onClose,
                modifier = Modifier.size(32.dp)
            ) {
                Icon(
                    Icons.Filled.Close,
                    contentDescription = "Close",
                    modifier = Modifier.size(16.dp)
                )
            }
        }
    }
}

// ── v5.4.142cc — Multi-bubble system ──────────────────────────────────────

/**
 * A minimized popup rendered as a small draggable floating pill.
 *
 * Behaviour:
 *   • Tap → restore to a full popup window (calls [onRestore]).
 *   • Drag freely to reposition anywhere on screen.
 *   • Drag toward the bottom (within ~130 dp of the screen's lower edge)
 *     → the [BubbleCloseZone] appears at the bottom of the parent Box;
 *     the caller shows it by reacting to [onNearBottomChanged].
 *   • Release while close zone is visible → user taps left X (this only)
 *     or right X (all) from the zone itself.
 *
 * [startOffsetX] / [startOffsetY] initialise the position for stacking
 * multiple bubbles without overlap.
 */
@Composable
fun DraggableBubble(
    bubble: AppViewModel.PopupBubble,
    startOffsetX: Float = 0f,
    startOffsetY: Float = 0f,
    onRestore: () -> Unit,
    onNearBottomChanged: (Boolean) -> Unit,
    modifier: Modifier = Modifier
) {
    val density = LocalDensity.current
    val config = LocalConfiguration.current
    val screenHeightPx = with(density) { config.screenHeightDp.dp.toPx() }
    // Threshold: bottom 130 dp of the screen triggers the close zone.
    val closeThresholdPx = screenHeightPx - with(density) { 130.dp.toPx() }

    var offsetX by remember(bubble.id) { mutableStateOf(startOffsetX) }
    var offsetY by remember(bubble.id) { mutableStateOf(startOffsetY) }

    Surface(
        modifier = modifier
            .offset { IntOffset(offsetX.roundToInt(), offsetY.roundToInt()) }
            .onGloballyPositioned { coords ->
                val bounds = coords.boundsInWindow()
                onNearBottomChanged(bounds.center.y > closeThresholdPx)
            }
            .pointerInput(bubble.id) {
                detectDragGestures(
                    onDragEnd = {
                        // Re-evaluate near-bottom on pointer up so the
                        // zone hides when the bubble is not released at
                        // the bottom.  The onGloballyPositioned callback
                        // fires one more time after layout settles; this
                        // is a belt-and-suspenders clear.
                    }
                ) { _, drag ->
                    offsetX += drag.x
                    offsetY += drag.y
                }
            }
            .clickable(onClick = onRestore)
            .heightIn(min = 44.dp)
            .widthIn(min = 120.dp, max = 200.dp),
        shape = RoundedCornerShape(22.dp),
        color = MaterialTheme.colorScheme.primaryContainer,
        tonalElevation = 6.dp,
        shadowElevation = 10.dp
    ) {
        Row(
            modifier = Modifier.padding(horizontal = 12.dp, vertical = 10.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(6.dp)
        ) {
            Text("\uD83E\uDDE0", fontSize = 14.sp)   // 🧠
            Text(
                text = bubble.query,
                fontSize = 12.sp,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis,
                color = MaterialTheme.colorScheme.onPrimaryContainer,
                modifier = Modifier.widthIn(max = 120.dp)
            )
        }
    }
}

/**
 * Bottom-of-screen overlay that appears when a bubble is dragged near
 * the bottom. Shows two close targets:
 *   • Left  ✕  →  close only the dragged bubble.
 *   • Right ✕  →  close all active bubbles AND the current full popup.
 *
 * Visibility is controlled with a plain [if] guard so we don't depend on
 * androidx.compose.animation (which is not a direct dependency of this module).
 */
@Composable
fun BubbleCloseZone(
    visible: Boolean,
    onCloseThis: () -> Unit,
    onCloseAll: () -> Unit,
    modifier: Modifier = Modifier
) {
    if (!visible) return
    Row(
        modifier = modifier
            .fillMaxWidth()
            .background(
                color = MaterialTheme.colorScheme.errorContainer.copy(alpha = 0.93f),
                shape = RoundedCornerShape(topStart = 20.dp, topEnd = 20.dp)
            )
            .padding(horizontal = 20.dp, vertical = 14.dp),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        // Left: close this bubble only
        Column(
            horizontalAlignment = Alignment.CenterHorizontally,
            modifier = Modifier.clickable(onClick = onCloseThis)
        ) {
            Icon(
                Icons.Filled.Close,
                contentDescription = "Close this window",
                tint = MaterialTheme.colorScheme.onErrorContainer,
                modifier = Modifier.size(26.dp)
            )
            Text(
                text = "This",
                fontSize = 10.sp,
                color = MaterialTheme.colorScheme.onErrorContainer
            )
        }

        Text(
            text = "\u2B07 Drop to close",
            fontSize = 12.sp,
            color = MaterialTheme.colorScheme.onErrorContainer
        )

        // Right: close all bubbles + current full popup
        Column(
            horizontalAlignment = Alignment.CenterHorizontally,
            modifier = Modifier.clickable(onClick = onCloseAll)
        ) {
            Icon(
                Icons.Filled.Close,
                contentDescription = "Close all windows",
                tint = MaterialTheme.colorScheme.onErrorContainer,
                modifier = Modifier.size(26.dp)
            )
            Text(
                text = "All",
                fontSize = 10.sp,
                color = MaterialTheme.colorScheme.onErrorContainer
            )
        }
    }
}

/**
 * heartbeat — used to alert the user that a popup is minimized and
 * waiting. When [pulsing] is false, the FAB is static.
 *
 * The heartbeat cadence is intentionally not perfectly smooth — a
 * brief "double-thump" then rest, roughly matching a real pulse.
 */
@Composable
fun PumpingBrainFab(
    pulsing: Boolean,
    busy: Boolean,
    onClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    val transition = rememberInfiniteTransition(label = "brain-pulse")
    val scale: Float by transition.animateFloat(
        initialValue = 1.0f,
        targetValue = if (pulsing) 1.16f else 1.0f,
        animationSpec = infiniteRepeatable(
            animation = tween(
                durationMillis = 620,
                easing = FastOutSlowInEasing
            ),
            repeatMode = RepeatMode.Reverse
        ),
        label = "brain-scale"
    )
    // v5.4.158cc — Press feedback (squish on tap) layers on top of the
    // existing ambient pulse above — they animate different things (outer
    // container scale vs. inner emoji scale) so they combine cleanly.
    val fabInteraction = remember { MutableInteractionSource() }
    SmallFloatingActionButton(
        onClick = onClick,
        interactionSource = fabInteraction,
        modifier = modifier.fabPressScale(fabInteraction),
        containerColor = MaterialTheme.colorScheme.tertiaryContainer
    ) {
        if (busy) {
            CircularProgressIndicator(
                modifier = Modifier.size(16.dp),
                strokeWidth = 2.dp
            )
        } else {
            Text(
                text = "\uD83E\uDDE0",
                fontSize = 16.sp,
                modifier = Modifier.graphicsLayer(
                    scaleX = if (pulsing) scale else 1.0f,
                    scaleY = if (pulsing) scale else 1.0f
                )
            )
        }
    }
}

/**
 * v5.4.132cc — Pumping-heart FAB for the SearchScreen bottom-left.
 *
 * Same animation as [PumpingBrainFab] but shows a heart instead of a
 * brain. Used to trigger the multi-article popup — pulls the top-N
 * currently-displayed search results, extracts semantic passages
 * from each, and shows them in the same typewriter popup the reader
 * screens use. Always pulses by default (it's an invitation, not a
 * status indicator) — pass [pulsing] = false to hold it still.
 */
@Composable
fun PumpingHeartFab(
    pulsing: Boolean,
    busy: Boolean,
    onClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    val transition = rememberInfiniteTransition(label = "heart-pulse")
    val scale: Float by transition.animateFloat(
        initialValue = 1.0f,
        targetValue = if (pulsing) 1.18f else 1.0f,
        animationSpec = infiniteRepeatable(
            animation = tween(
                durationMillis = 560,
                easing = FastOutSlowInEasing
            ),
            repeatMode = RepeatMode.Reverse
        ),
        label = "heart-scale"
    )
    // v5.4.158cc — Press feedback (squish on tap), same as PumpingBrainFab.
    val fabInteraction = remember { MutableInteractionSource() }
    SmallFloatingActionButton(
        onClick = onClick,
        interactionSource = fabInteraction,
        modifier = modifier.fabPressScale(fabInteraction),
        containerColor = MaterialTheme.colorScheme.errorContainer
    ) {
        if (busy) {
            CircularProgressIndicator(
                modifier = Modifier.size(16.dp),
                strokeWidth = 2.dp
            )
        } else {
            Text(
                text = "\uD83D\uDC97",  // 💗 sparkling heart — reads better than the plain ❤️
                fontSize = 16.sp,
                modifier = Modifier.graphicsLayer(
                    scaleX = if (pulsing) scale else 1.0f,
                    scaleY = if (pulsing) scale else 1.0f
                )
            )
        }
    }
}
