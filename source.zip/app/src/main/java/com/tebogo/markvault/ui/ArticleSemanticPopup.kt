package com.tebogo.markvault.ui

import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.selection.SelectionContainer
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Close
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.SmallFloatingActionButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.delay
import kotlin.math.roundToInt

/**
 * v5.4.129cc — In-article semantic-search popup.
 *
 * Shown after the user taps the 🧠 brain button on the reader toolbar
 * and the ViewModel has ranked passages by cosine similarity to the
 * current query. The popup:
 *
 *   • Types the found passages out top-to-bottom, roughly word-by-word,
 *     so it feels like the answer is being composed on the fly.
 *   • Is scrollable and its content is selectable (long-press to copy)
 *     so users can lift a phrase into another app.
 *   • Has a title bar with a — minimize button and an × close button.
 *   • The title bar is drag-handle: press-and-drag to reposition anywhere
 *     on screen. The popup remembers where you left it during the same
 *     open, so scrolling the article underneath doesn't reset its spot.
 *
 * When minimized, the popup collapses into a compact pill anchored to
 * the bottom of the reader (see [MinimizedPopupPill]). The reader's
 * brain button pulses gently while a minimized popup exists — a
 * heartbeat-style "you have one waiting" nudge — via [PumpingBrainFab].
 */

@Composable
fun ArticlePopupOverlay(
    query: String,
    passages: List<String>,
    onClose: () -> Unit,
    onMinimize: () -> Unit,
    modifier: Modifier = Modifier
) {
    // Concatenate passages with a soft separator between them so the
    // typewriter has a natural pause between distinct excerpts.
    val fullText: String = remember(passages) {
        passages.joinToString(separator = "\n\n\u2026\n\n")
    }

    // Persistent drag offset for the whole popup. Reset when the query
    // changes — new search = fresh position.
    var offsetX by remember(query) { mutableStateOf(0f) }
    var offsetY by remember(query) { mutableStateOf(0f) }

    // Typewriter progress. Recomputes when fullText changes.
    var visibleLength by remember(fullText) { mutableIntStateOf(0) }
    var typingDone by remember(fullText) { mutableStateOf(false) }

    LaunchedEffect(fullText) {
        visibleLength = 0
        typingDone = false
        if (fullText.isEmpty()) {
            typingDone = true
            return@LaunchedEffect
        }
        // Emit token by token. A "token" is a run of non-whitespace
        // followed by the trailing whitespace so word spacing stays
        // intact. Each iteration reveals the next token, then pauses.
        val len = fullText.length
        var i = 0
        while (i < len) {
            // Skip and reveal any leading whitespace as one atomic block
            while (i < len && fullText[i].isWhitespace()) i++
            // Reveal the next word (non-whitespace run)
            while (i < len && !fullText[i].isWhitespace()) i++
            visibleLength = i
            val last = if (i > 0) fullText[i - 1] else ' '
            val pause: Long = when (last) {
                '.', '!', '?' -> 90L
                ',', ';', ':' -> 45L
                '\u2026' -> 260L
                '\n' -> 140L
                else -> 22L
            }
            delay(pause)
        }
        visibleLength = len
        typingDone = true
    }

    val displayText: String = remember(visibleLength, fullText) {
        if (visibleLength >= fullText.length) fullText
        else fullText.substring(0, visibleLength)
    }

    Surface(
        modifier = modifier
            .offset { IntOffset(offsetX.roundToInt(), offsetY.roundToInt()) }
            .widthIn(min = 260.dp, max = 380.dp)
            .heightIn(min = 200.dp, max = 460.dp),
        shape = RoundedCornerShape(18.dp),
        color = MaterialTheme.colorScheme.surface,
        tonalElevation = 8.dp,
        shadowElevation = 14.dp
    ) {
        Column {
            // Title bar — drag handle + minimize + close
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .pointerInput(query) {
                        detectDragGestures { _, drag ->
                            offsetX += drag.x
                            offsetY += drag.y
                        }
                    }
                    .padding(start = 14.dp, end = 6.dp, top = 8.dp, bottom = 8.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "\uD83D\uDD0D  " + query,
                    fontWeight = FontWeight.SemiBold,
                    fontSize = 15.sp,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis,
                    modifier = Modifier
                        .padding(end = 8.dp)
                        .fillMaxWidth(0.68f)
                )
                Spacer(Modifier.width(4.dp))
                // Minimize (— glyph). Uses a Text glyph rather than a
                // Material icon because a proper "minimize" icon isn't
                // in the default icon set and adding the extended set
                // would balloon the APK.
                IconButton(
                    onClick = onMinimize,
                    modifier = Modifier.size(32.dp)
                ) {
                    Text(
                        text = "\u2013",
                        fontSize = 22.sp,
                        fontWeight = FontWeight.Bold,
                        modifier = Modifier.padding(bottom = 6.dp)
                    )
                }
                IconButton(
                    onClick = onClose,
                    modifier = Modifier.size(32.dp)
                ) {
                    Icon(
                        imageVector = Icons.Filled.Close,
                        contentDescription = "Close"
                    )
                }
            }
            HorizontalDivider(
                thickness = 0.6.dp,
                color = MaterialTheme.colorScheme.outlineVariant
            )
            // Scrollable + selectable content
            SelectionContainer {
                Column(
                    modifier = Modifier
                        .verticalScroll(rememberScrollState())
                        .padding(horizontal = 16.dp, vertical = 14.dp)
                ) {
                    Text(
                        text = displayText,
                        fontSize = 15.sp,
                        lineHeight = 22.sp,
                        color = MaterialTheme.colorScheme.onSurface
                    )
                    if (!typingDone) {
                        Text(
                            text = "\u258A",
                            color = MaterialTheme.colorScheme.primary,
                            fontSize = 15.sp
                        )
                    }
                }
            }
        }
    }
}

/**
 * Loading state — shown briefly while the embedder is chunking + scoring.
 * On a typical article this is well under a second, so the indicator is
 * intentionally lightweight (no separate typewriter progress).
 */
@Composable
fun ArticlePopupLoading(
    query: String,
    onCancel: () -> Unit,
    modifier: Modifier = Modifier
) {
    Surface(
        modifier = modifier
            .widthIn(min = 240.dp, max = 340.dp),
        shape = RoundedCornerShape(18.dp),
        color = MaterialTheme.colorScheme.surface,
        tonalElevation = 8.dp,
        shadowElevation = 14.dp
    ) {
        Row(
            modifier = Modifier.padding(
                start = 16.dp, end = 8.dp, top = 12.dp, bottom = 12.dp
            ),
            verticalAlignment = Alignment.CenterVertically
        ) {
            CircularProgressIndicator(
                modifier = Modifier.size(18.dp),
                strokeWidth = 2.dp
            )
            Spacer(Modifier.width(12.dp))
            Text(
                text = "Reading article for \u201C" + query + "\u201D\u2026",
                fontSize = 14.sp,
                maxLines = 2,
                overflow = TextOverflow.Ellipsis,
                modifier = Modifier.fillMaxWidth(0.72f)
            )
            Spacer(Modifier.width(4.dp))
            IconButton(onClick = onCancel, modifier = Modifier.size(32.dp)) {
                Icon(Icons.Filled.Close, contentDescription = "Cancel")
            }
        }
    }
}

/**
 * Empty state — shown when the semantic pass ran but no passage cleared
 * the similarity threshold. Non-blocking, self-dismisses after 2 seconds
 * OR when the user taps close.
 */
@Composable
fun ArticlePopupEmpty(
    query: String,
    onClose: () -> Unit,
    modifier: Modifier = Modifier
) {
    LaunchedEffect(query) {
        delay(2400L)
        onClose()
    }
    Surface(
        modifier = modifier
            .widthIn(min = 240.dp, max = 340.dp),
        shape = RoundedCornerShape(18.dp),
        color = MaterialTheme.colorScheme.surface,
        tonalElevation = 8.dp,
        shadowElevation = 14.dp
    ) {
        Row(
            modifier = Modifier.padding(
                start = 16.dp, end = 8.dp, top = 12.dp, bottom = 12.dp
            ),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                text = "\uD83E\uDD14",
                fontSize = 18.sp
            )
            Spacer(Modifier.width(12.dp))
            Text(
                text = "No strongly matching passages for \u201C" + query + "\u201D",
                fontSize = 14.sp,
                maxLines = 3,
                overflow = TextOverflow.Ellipsis,
                modifier = Modifier.fillMaxWidth(0.78f)
            )
            IconButton(onClick = onClose, modifier = Modifier.size(28.dp)) {
                Icon(Icons.Filled.Close, contentDescription = "Close")
            }
        }
    }
}

/**
 * Minimized pill anchored to the bottom of the reader. Tap the pill body
 * to maximize; tap the × to dismiss the popup entirely.
 */
@Composable
fun MinimizedPopupPill(
    query: String,
    onMaximize: () -> Unit,
    onClose: () -> Unit,
    modifier: Modifier = Modifier
) {
    Surface(
        modifier = modifier
            .heightIn(min = 40.dp)
            .widthIn(max = 260.dp)
            .clickable(onClick = onMaximize),
        shape = RoundedCornerShape(20.dp),
        color = MaterialTheme.colorScheme.primaryContainer,
        tonalElevation = 4.dp,
        shadowElevation = 6.dp
    ) {
        Row(
            modifier = Modifier.padding(start = 14.dp, end = 4.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(6.dp)
        ) {
            Text(
                text = "\uD83E\uDDE0",
                fontSize = 15.sp,
                modifier = Modifier.padding(vertical = 8.dp)
            )
            Text(
                text = query,
                fontSize = 13.sp,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis,
                color = MaterialTheme.colorScheme.onPrimaryContainer,
                modifier = Modifier
                    .padding(vertical = 8.dp)
                    .widthIn(max = 170.dp)
            )
            IconButton(
                onClick = onClose,
                modifier = Modifier.size(32.dp)
            ) {
                Icon(
                    Icons.Filled.Close,
                    contentDescription = "Close",
                    modifier = Modifier.size(16.dp)
                )
            }
        }
    }
}

/**
 * Brain-emoji FAB. When [pulsing] is true, scales up and down like a
 * heartbeat — used to alert the user that a popup is minimized and
 * waiting. When [pulsing] is false, the FAB is static.
 *
 * The heartbeat cadence is intentionally not perfectly smooth — a
 * brief "double-thump" then rest, roughly matching a real pulse.
 */
@Composable
fun PumpingBrainFab(
    pulsing: Boolean,
    busy: Boolean,
    onClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    val transition = rememberInfiniteTransition(label = "brain-pulse")
    val scale: Float by transition.animateFloat(
        initialValue = 1.0f,
        targetValue = if (pulsing) 1.16f else 1.0f,
        animationSpec = infiniteRepeatable(
            animation = tween(
                durationMillis = 620,
                easing = FastOutSlowInEasing
            ),
            repeatMode = RepeatMode.Reverse
        ),
        label = "brain-scale"
    )
    SmallFloatingActionButton(
        onClick = onClick,
        modifier = modifier,
        containerColor = MaterialTheme.colorScheme.tertiaryContainer
    ) {
        if (busy) {
            CircularProgressIndicator(
                modifier = Modifier.size(16.dp),
                strokeWidth = 2.dp
            )
        } else {
            Text(
                text = "\uD83E\uDDE0",
                fontSize = 16.sp,
                modifier = Modifier.graphicsLayer(
                    scaleX = if (pulsing) scale else 1.0f,
                    scaleY = if (pulsing) scale else 1.0f
                )
            )
        }
    }
}
