package com.tebogo.markvault.ai

data class T5SearchRuntimeTrace(
    val query: String,
    val mode: String,
    val expandedQueries: List<String>,
    val inferenceTimeMs: Long,
    val fallbackReason: String? = null
)
