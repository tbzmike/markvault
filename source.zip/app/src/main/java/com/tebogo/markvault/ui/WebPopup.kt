@file:OptIn(androidx.compose.material3.ExperimentalMaterial3Api::class)

package com.tebogo.markvault.ui

import android.content.Context
import android.net.Uri
import android.view.MotionEvent
import android.webkit.WebResourceRequest
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.statusBars
import androidx.compose.foundation.layout.navigationBars
import androidx.compose.foundation.layout.windowInsetsPadding
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.filled.KeyboardArrowLeft
import androidx.compose.material.icons.automirrored.filled.KeyboardArrowRight
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.MoreVert
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.ExtendedFloatingActionButton
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.rememberModalBottomSheetState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import kotlinx.coroutines.launch
import androidx.webkit.WebSettingsCompat
import androidx.webkit.WebViewFeature
import com.tebogo.markvault.AppViewModel

/**
 * Hosts of pages we keep inside the in-app WebView popup. (Used here AND in ReaderScreen.)
 */
private val JW_HOST_SUFFIXES = listOf(
    "jw.org", "wol.jw.org", "tv.jw.org", "jw-cdn.org", "akamaihd.net"
)

internal fun isJwHostUri(uri: Uri): Boolean {
    val host = uri.host?.lowercase() ?: return false
    return JW_HOST_SUFFIXES.any { host == it || host.endsWith(".$it") }
}

/**
 * In-app fullscreen WebView. Used by all WebViewer launches.
 * already has its own scroll-state but wants to overlay a popup browser.
 *
 * Fixes that ship with v2.2:
 *  - Scrolling works: touch listener requests parent disallow-intercept on DOWN/MOVE
 *  - Dark mode toggle via WebSettingsCompat.setAlgorithmicDarkeningAllowed
 *  - Adjustable text zoom (A− / A+) saved to the ViewModel
 *  - "Full screen" preserves WebView state via saveState/restoreState (no reload)
 *  - Internal JW navigation stays inside the popup; external links go to the system browser
 *
 * @param url       URL to load on first composition (or after a restoreState)
 * @param onClose   Called when the user dismisses the sheet
 * @param onPromote Called when the user taps "Full screen" — the popup hands its state Bundle
 *                  back via [AppViewModel.webStateBundle] and the caller navigates to the
 *                  full-screen route.
 */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun WebPopupFullScreen(
    vm: AppViewModel,
    url: String,
    onClose: () -> Unit,
    onShrink: (url: String, label: String) -> Unit,
    onOpenBookmarks: () -> Unit = {},
    // v4.12.0 — fullscreen WebViewer implementation.
    onOpenWebHistory: () -> Unit = {},
    onOpenPdfHistory: () -> Unit = {},
    onOpenSettings: () -> Unit = {},
    /**
     * v5.4.85cc — Invoked when the user taps the floating "Article"
     * FAB overlaid on the bottom of the full-screen viewer. In the
     * simplest wiring this behaves like [onClose] (pops the back
     * stack back to the calling article); reserved as a separate
     * callback so the routing decision lives in MainActivity and
     * can be extended without churning this composable's signature.
     */
    onReturnToArticle: () -> Unit = onClose
) {
    val hostNow = remember(url) {
        runCatching { Uri.parse(url).host ?: "jw.org" }.getOrElse { "jw.org" }
    }
    Box(Modifier.fillMaxSize()) {
        Column(
            Modifier
                .fillMaxSize()
                // CRITICAL FIX: pad below the system status bar so the toolbar isn't
                // overlapping the notification area (the icons were unclickable
                // because they sat under the system clock + battery icons).
                .windowInsetsPadding(WindowInsets.statusBars)
        ) {
            WebPopupContents(
                vm = vm,
                urlInitial = url,
                host = hostNow,
                onClose = onClose,
                onPromote = onShrink,   // here "promote" means "shrink back to popup"
                onOpenBookmarks = onOpenBookmarks,
                onOpenWebHistory = onOpenWebHistory,
                onOpenPdfHistory = onOpenPdfHistory,
                onOpenSettings = onOpenSettings,
                fullScreen = true
            )
        }
        // v5.4.85cc — "Article" FAB overlaid at bottom-end. Padded away
        // from the nav bar via WindowInsets so it never sits *under*
        // the gesture / three-button system UI. Extended-FAB variant
        // is used (icon + text) for maximum discoverability — the
        // whole point of this affordance is that the user doesn't
        // have to know which of the toolbar buttons up top means
        // "close and go back to my article".
        ExtendedFloatingActionButton(
            onClick = onReturnToArticle,
            icon = {
                androidx.compose.material3.Icon(
                    Icons.AutoMirrored.Filled.ArrowBack,
                    contentDescription = null
                )
            },
            text = { androidx.compose.material3.Text("Article") },
            modifier = Modifier
                .align(Alignment.BottomEnd)
                .windowInsetsPadding(WindowInsets.navigationBars)
                .padding(16.dp)
        )
    }
}

/**
 * Inner body: toolbar + WebView. Both popup and full-screen variants share this.
 * Declared as a ColumnScope extension so the `.weight(1f)` in full-screen mode compiles.
 */
@Composable
private fun ColumnScope.WebPopupContents(
    vm: AppViewModel,
    urlInitial: String,
    host: String,
    onClose: () -> Unit,
    onPromote: (url: String, label: String) -> Unit,
    onOpenBookmarks: () -> Unit,
    // v4.12.0 — three new navigation callbacks needed to deliver feature parity
    // with the full-screen browser via the popup's new overflow menu.
    onOpenWebHistory: () -> Unit,
    onOpenPdfHistory: () -> Unit,
    onOpenSettings: () -> Unit,
    fullScreen: Boolean
) {
    val ctx = androidx.compose.ui.platform.LocalContext.current
    val scope = rememberCoroutineScope()  // v4.12.0 — for Save / Convert callbacks
    val zoom by vm.webPopupTextZoom.collectAsState()
    val dark by vm.webPopupDarkMode.collectAsState()
    // Hold a reference to the WebView so toolbar buttons can call into it
    var web by remember { androidx.compose.runtime.mutableStateOf<WebView?>(null) }
    // v4.12.0 — overflow-menu open state
    var menuOpen by remember { androidx.compose.runtime.mutableStateOf(false) }
    // Editable URL bar state — kept in sync with the WebView via onPageStarted/onPageFinished
    var addressText by remember { androidx.compose.runtime.mutableStateOf(urlInitial) }
    var addressFocused by remember { androidx.compose.runtime.mutableStateOf(false) }
    var canGoBack by remember { androidx.compose.runtime.mutableStateOf(false) }
    var canGoForward by remember { androidx.compose.runtime.mutableStateOf(false) }
    val keyboard = androidx.compose.ui.platform.LocalSoftwareKeyboardController.current

    // v4.2 — popup long-press link sheet state. Declared at function scope so
    // both the AndroidView's onLinkLongPress callback (inside the nested Box)
    // AND the ModalBottomSheet rendered later in this composable can see it.
    // Previously this lived inside the Box scope and the sheet rendering
    // failed to compile because the variable was out of scope.
    var popupLinkLongPress by remember {
        androidx.compose.runtime.mutableStateOf<Pair<String, String>?>(null)
    }

    fun submitAddress() {
        val raw = addressText.trim()
        if (raw.isEmpty()) return
        val target = when {
            raw.startsWith("http://") || raw.startsWith("https://") -> raw
            raw.contains(".") -> "https://$raw"
            else -> "https://www.jw.org/en/search/?q=" + Uri.encode(raw)
        }
        if (!isJwHostUri(Uri.parse(target))) {
            android.widget.Toast.makeText(
                ctx, "Only jw.org family of sites are allowed",
                android.widget.Toast.LENGTH_SHORT
            ).show()
            return
        }
        keyboard?.hide()
        web?.loadUrl(target)
        addressFocused = false
    }

    // Track bookmark state for the URL currently shown in the popup.
    // Re-checked whenever the URL changes (after navigation, fullscreen toggle, etc).
    var isBookmarked by remember { mutableStateOf(false) }
    var currentUrl by remember { mutableStateOf(urlInitial) }
    LaunchedEffect(currentUrl) {
        isBookmarked = if (currentUrl.isBlank()) false
        else vm.isBookmarked(currentUrl)
    }

    // Toolbar — Row 1: action buttons (refresh, external link, A-, A+, fullscreen, close)
    Row(
        Modifier.fillMaxWidth().padding(start = 14.dp, end = 0.dp, top = 4.dp, bottom = 0.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(
            "\uD83C\uDF10  $host", fontWeight = FontWeight.SemiBold, fontSize = 13.sp,
            modifier = Modifier.weight(1f), maxLines = 1, overflow = TextOverflow.Ellipsis,
            color = MaterialTheme.colorScheme.onSurfaceVariant
        )
        // Refresh the current page in the popup
        IconButton(onClick = { web?.reload() }) {
            Icon(Icons.Default.Refresh, contentDescription = "Refresh")
        }
        // ★ Save as favourite — toggles bookmark for the current URL
        IconButton(onClick = {
            val u = web?.url ?: currentUrl
            val t = web?.title ?: host
            if (isBookmarked) vm.removeBookmark(u) else vm.addBookmark(u, t)
            isBookmarked = !isBookmarked
        }) {
            Text(
                if (isBookmarked) "\u2605" else "\u2606",
                fontSize = 20.sp,
                color = if (isBookmarked) androidx.compose.ui.graphics.Color(0xFFFFC107)
                else MaterialTheme.colorScheme.onSurface
            )
        }
        // Text zoom A− / A+
        TextButton(
            onClick = { vm.setWebPopupTextZoom(zoom - 10) },
            contentPadding = PaddingValues(horizontal = 6.dp)
        ) { Text("A\u2212", fontSize = 13.sp) }
        TextButton(
            onClick = { vm.setWebPopupTextZoom(zoom + 10) },
            contentPadding = PaddingValues(horizontal = 6.dp)
        ) { Text("A+", fontSize = 13.sp) }
        // Toggle between popup and full-screen, preserving state
        IconButton(onClick = {
            val w = web
            if (w != null) {
                val bundle = android.os.Bundle()
                w.saveState(bundle)
                vm.webStateBundle = bundle
            }
            val u = w?.url ?: urlInitial
            onPromote(u, host)
        }) {
            Text(
                if (fullScreen) "\u2924" else "\u2922",
                fontSize = 16.sp,
                fontWeight = FontWeight.Bold
            )
        }
        // v4.4.3 — Home button in popup too so the toolbar matches the rest
        // of the app. Closes the popup AND pops back to home.
        IconButton(onClick = {
            onClose()
            // popBackStack happens via the parent host on the next compose.
        }) {
            Text("\uD83C\uDFE0", fontSize = 16.sp)
        }
        IconButton(onClick = onClose) {
            Icon(Icons.Default.Close, contentDescription = "Close")
        }
        // ── v4.12.0 — Overflow menu ────────────────────────────────────────
        // Brings popup feature-parity with the full-screen browser without
        // bloating the visible toolbar. Items match WebSearchScreen's menu
        // exactly so the experience is identical regardless of which mode
        // you're in. Also brings back External-browser, Bookmarks-list, and
        // Dark-mode toggle which were removed from the visible row to
        // declutter (per the user's "less cluttered, more features" ask).
        Box {
            IconButton(onClick = { menuOpen = true }) {
                Icon(Icons.Default.MoreVert, contentDescription = "More")
            }
            DropdownMenu(
                expanded = menuOpen,
                onDismissRequest = { menuOpen = false }
            ) {
                DropdownMenuItem(
                    text = { Text("\uD83C\uDFE0 jw.org home") },
                    onClick = {
                        menuOpen = false
                        web?.loadUrl("https://www.jw.org/en/")
                    }
                )
                DropdownMenuItem(
                    text = { Text(if (dark) "\u263C Light mode" else "\uD83C\uDF19 Dark mode") },
                    onClick = {
                        menuOpen = false
                        vm.setWebPopupDarkMode(!dark)
                    }
                )
                DropdownMenuItem(
                    text = { Text("\u2197 Open in external browser") },
                    onClick = {
                        menuOpen = false
                        val target = web?.url ?: urlInitial
                        runCatching {
                            val intent = android.content.Intent(
                                android.content.Intent.ACTION_VIEW, Uri.parse(target)
                            ).addFlags(android.content.Intent.FLAG_ACTIVITY_NEW_TASK)
                            ctx.startActivity(intent)
                        }
                    }
                )
                HorizontalDivider()
                DropdownMenuItem(
                    text = { Text("\uD83D\uDD16 Bookmarks") },
                    onClick = { menuOpen = false; onOpenBookmarks() }
                )
                DropdownMenuItem(
                    text = { Text("\uD83D\uDD52 Web history") },
                    onClick = { menuOpen = false; onOpenWebHistory() }
                )
                DropdownMenuItem(
                    text = { Text("\uD83D\uDCDC PDF history") },
                    onClick = { menuOpen = false; onOpenPdfHistory() }
                )
                HorizontalDivider()
                // v4.12.0 — Save the current page as an offline HTML note in
                // the library. Same logic as the full-screen browser, just
                // invoked from inside the popup. Toast feedback fires even
                // after popup dismissal, so it's safe to close on success.
                DropdownMenuItem(
                    text = { Text("\uD83D\uDCBE Save as Offline HTML") },
                    onClick = {
                        menuOpen = false
                        val w = web ?: return@DropdownMenuItem
                        val srcUrl = w.url ?: urlInitial
                        val title = w.title?.takeIf { it.isNotBlank() } ?: host
                        w.evaluateJavascript(
                            "(function(){return document.documentElement.outerHTML;})();"
                        ) { jsonHtml ->
                            val html = decodeJsSelectionPublic(jsonHtml)
                            if (html.isBlank()) {
                                android.widget.Toast.makeText(
                                    ctx, "Couldn't capture the page HTML.",
                                    android.widget.Toast.LENGTH_SHORT
                                ).show()
                                return@evaluateJavascript
                            }
                            scope.launch {
                                val res = vm.saveOfflineHtmlPage(srcUrl, title, html)
                                val msg = when (res) {
                                    is com.tebogo.markvault.SaveResult.Ok -> {
                                        vm.reindex()
                                        "\uD83D\uDCBE Saved & indexed: ${res.fileName}"
                                    }
                                    is com.tebogo.markvault.SaveResult.Error -> "\u26A0\uFE0F ${res.message}"
                                }
                                android.widget.Toast.makeText(
                                    ctx, msg, android.widget.Toast.LENGTH_LONG
                                ).show()
                            }
                        }
                    }
                )
                DropdownMenuItem(
                    text = { Text("\uD83D\uDCDD Convert to Markdown") },
                    onClick = {
                        menuOpen = false
                        val w = web ?: return@DropdownMenuItem
                        val srcUrl = w.url ?: urlInitial
                        val title = w.title?.takeIf { it.isNotBlank() } ?: host
                        w.evaluateJavascript(
                            "(function(){return document.documentElement.outerHTML;})();"
                        ) { jsonHtml ->
                            val html = decodeJsSelectionPublic(jsonHtml)
                            scope.launch {
                                val res = vm.saveConvertedMarkdown(srcUrl, title, html)
                                val msg = when (res) {
                                    is com.tebogo.markvault.SaveResult.Ok -> {
                                        vm.reindex()
                                        "\uD83D\uDCDD Saved & indexed: ${res.fileName}"
                                    }
                                    is com.tebogo.markvault.SaveResult.Error -> "\u26A0\uFE0F ${res.message}"
                                }
                                android.widget.Toast.makeText(
                                    ctx, msg, android.widget.Toast.LENGTH_LONG
                                ).show()
                            }
                        }
                    }
                )
                HorizontalDivider()
                DropdownMenuItem(
                    text = { Text("\u2699\uFE0F Settings") },
                    onClick = { menuOpen = false; onOpenSettings() }
                )
            }
        }
    }

    // Toolbar — Row 2: back / forward + editable URL field. Gives the popup
    // a real-browser feel; user can navigate within jw.org without leaving the popup.
    Row(
        Modifier.fillMaxWidth().padding(horizontal = 8.dp, vertical = 4.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        IconButton(
            onClick = { web?.goBack() },
            enabled = canGoBack,
            modifier = Modifier.size(32.dp)
        ) {
            Icon(Icons.AutoMirrored.Filled.KeyboardArrowLeft,
                contentDescription = "Back",
                tint = if (canGoBack) MaterialTheme.colorScheme.onSurface
                else MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.4f))
        }
        IconButton(
            onClick = { web?.goForward() },
            enabled = canGoForward,
            modifier = Modifier.size(32.dp)
        ) {
            Icon(Icons.AutoMirrored.Filled.KeyboardArrowRight,
                contentDescription = "Forward",
                tint = if (canGoForward) MaterialTheme.colorScheme.onSurface
                else MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.4f))
        }
        androidx.compose.material3.OutlinedTextField(
            value = addressText,
            onValueChange = { addressText = it },
            singleLine = true,
            modifier = Modifier.weight(1f).height(54.dp),
            placeholder = { Text("URL or search\u2026", fontSize = 14.sp) },
            textStyle = androidx.compose.ui.text.TextStyle(
                fontSize = 14.sp,
                fontWeight = FontWeight.Medium
            ),
            keyboardOptions = androidx.compose.foundation.text.KeyboardOptions(
                imeAction = androidx.compose.ui.text.input.ImeAction.Go
            ),
            keyboardActions = androidx.compose.foundation.text.KeyboardActions(
                onGo = { submitAddress() }
            ),
            shape = androidx.compose.foundation.shape.RoundedCornerShape(22.dp),
            colors = androidx.compose.material3.TextFieldDefaults.colors(
                focusedContainerColor = MaterialTheme.colorScheme.surface,
                unfocusedContainerColor = MaterialTheme.colorScheme.surface
            )
        )
    }

    // v4.13.0 — Pause/resume the persistent popup WebView with the
    // Composable's lifecycle. When the popup mounts (sheet opened or
    // promoted) we resume; when it unmounts (sheet dismissed, mode toggled)
    // we pause. Keeps JS timers and other background work from running
    // while the WebView isn't visible.
    androidx.compose.runtime.DisposableEffect(Unit) {
        val w = vm.getOrCreateWebViewSession("popup", ctx)
        runCatching { w.onResume() }
        onDispose {
            // Detach from current parent so the next mount can re-attach
            // cleanly to a different ViewGroup (sheet ↔ full-screen).
            (w.parent as? android.view.ViewGroup)?.removeView(w)
            runCatching { w.onPause() }
        }
    }

    // WebView host. In popup mode, constrain height; in full-screen mode, fill the parent.
    val webBoxModifier = if (fullScreen)
        Modifier.fillMaxWidth().weight(1f)
    else
        Modifier.fillMaxWidth().heightIn(min = 360.dp, max = 720.dp)

    Box(webBoxModifier) {
        AndroidView(
            modifier = Modifier.fillMaxSize(),
            factory = { c ->
                val w = createPopupWebView(
                    c, vm, dark, zoom, urlInitial,
                    onWebReady = { web = it },
                    onNavState = { u, _, back, fwd ->
                        if (!addressFocused && u.isNotEmpty()) addressText = u
                        canGoBack = back
                        canGoForward = fwd
                        // Update currentUrl so bookmark state stays in sync as the
                        // user navigates inside the popup. This callback runs in
                        // WebPopupContents' scope, so `currentUrl` is visible here
                        // (unlike inside createPopupWebView).
                        if (u.isNotEmpty()) currentUrl = u
                    },
                    onSearchInMarkVault = { text ->
                        // Push the selection through the VM's pending-query channel;
                        // the Search screen consumes it on next entry.
                        vm.requestPendingSearch(text)
                        // Close the popup so the navigation host can show Search.
                        // Direct nav-to-Search would need a NavController which we
                        // don't have here — MainActivity observes pendingSearch.
                        onClose()
                    },
                    onSearchInWol = { text ->
                        val target = "https://wol.jw.org/en/wol/s/r1/lp-e?q=" +
                            java.net.URLEncoder.encode(text, "UTF-8")
                        // Load directly in this same popup — no need to dismiss.
                        web?.loadUrl(target)
                    },
                    // v4.12.0 — two new selection-menu actions also wired here
                    // so popup ↔ full-screen have the same menu vocabulary.
                    onSearchInJwOrg = { text ->
                        val target = "https://www.jw.org/en/search/?q=" +
                            java.net.URLEncoder.encode(text, "UTF-8")
                        web?.loadUrl(target)
                    },
                    // onShare left null → SelectionWebView falls back to
                    // ACTION_SEND, which produces the system share sheet.
                    onLinkLongPress = { url, text ->
                        popupLinkLongPress = url to text
                    }
                )
                // v4.13.0 — Critical for persistent WebView: detach from any
                // prior parent (e.g., the previous mode's container) before
                // AndroidView attaches this view to the new ViewGroup.
                // Without this, Android throws "View already has a parent".
                (w.parent as? android.view.ViewGroup)?.removeView(w)
                w
            },
            update = { w ->
                // Apply zoom changes when textZoom state changes.
                w.settings.textZoom = zoom
                // Re-apply the dark overlay LIVE on every recomposition so toggling
                // the moon button takes effect immediately (no page reload needed).
                if (dark) w.evaluateJavascript(POPUP_DARK_OVERLAY_JS, null)
                else w.evaluateJavascript(POPUP_REMOVE_OVERLAY_JS, null)
            }
        )
    }

    // In popup mode reserve a small bottom inset for the drag handle area
    if (!fullScreen) Spacer(Modifier.height(8.dp))

    // v4.2 — bottom-of-popup action sheet shown when the user long-presses a
    // link in the popup's WebView. Mirrors the markdown-reader experience:
    // Open externally / Copy / Search in wol.jw.org.
    //
    // NOTE: we intentionally avoid the `(longUrl, longText) ->` destructuring
    // form here. Kotlin can't always pick between the Pair component2() and
    // various Array/List component2() extensions on the call site, which made
    // the previous compile fail. Explicit .first / .second is unambiguous.
    val pendingLongPress = popupLinkLongPress
    if (pendingLongPress != null) {
        val longUrl = pendingLongPress.first
        val longText = pendingLongPress.second
        ModalBottomSheet(onDismissRequest = { popupLinkLongPress = null }) {
            Column(Modifier.fillMaxWidth().padding(horizontal = 18.dp, vertical = 8.dp)) {
                Text(
                    longText.ifBlank { longUrl },
                    fontSize = 14.sp,
                    fontWeight = FontWeight.SemiBold,
                    maxLines = 2,
                    overflow = TextOverflow.Ellipsis
                )
                Text(
                    longUrl,
                    fontSize = 11.sp,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis,
                    modifier = Modifier.padding(top = 2.dp)
                )
                Spacer(Modifier.height(10.dp))
                androidx.compose.material3.TextButton(
                    onClick = {
                        web?.loadUrl(longUrl)
                        popupLinkLongPress = null
                    },
                    modifier = Modifier.fillMaxWidth()
                ) { Text("\uD83D\uDD17  Open in this popup") }
                androidx.compose.material3.TextButton(
                    onClick = {
                        runCatching {
                            val clip = ctx.getSystemService(android.content.Context.CLIPBOARD_SERVICE)
                                as? android.content.ClipboardManager
                            clip?.setPrimaryClip(android.content.ClipData.newPlainText("url", longUrl))
                        }
                        popupLinkLongPress = null
                    },
                    modifier = Modifier.fillMaxWidth()
                ) { Text("\uD83D\uDCCB  Copy link") }
                androidx.compose.material3.TextButton(
                    onClick = {
                        runCatching {
                            ctx.startActivity(
                                android.content.Intent(
                                    android.content.Intent.ACTION_VIEW,
                                    Uri.parse(longUrl)
                                ).addFlags(android.content.Intent.FLAG_ACTIVITY_NEW_TASK)
                            )
                        }
                        popupLinkLongPress = null
                    },
                    modifier = Modifier.fillMaxWidth()
                ) { Text("\uD83C\uDF10  Open in system browser") }
                androidx.compose.material3.TextButton(
                    onClick = {
                        val q = if (longText.length > 1) longText else longUrl
                        val target = "https://wol.jw.org/en/wol/s/r1/lp-e?q=" +
                            java.net.URLEncoder.encode(q, "UTF-8")
                        web?.loadUrl(target)
                        popupLinkLongPress = null
                    },
                    modifier = Modifier.fillMaxWidth()
                ) { Text("\uD83D\uDD0D  Search in wol.jw.org") }
                Spacer(Modifier.height(16.dp))
            }
        }
    }
}

/**
 * Build the WebView with all our custom settings, the touch-pass-through that fixes the
 * bottom-sheet scroll bug, and state restoration where available.
 */
private fun createPopupWebView(
    c: Context,
    vm: AppViewModel,
    dark: Boolean,
    zoom: Int,
    urlInitial: String,
    onWebReady: (WebView) -> Unit,
    onNavState: ((url: String, title: String, canBack: Boolean, canFwd: Boolean) -> Unit)? = null,
    // v4.2 — text-selection menu callbacks (Search in MarkVault / Search in wol.jw.org)
    onSearchInMarkVault: ((String) -> Unit)? = null,
    onSearchInWol: ((String) -> Unit)? = null,
    // v4.12.0 — two extra selection-menu callbacks (Search jw.org / Share)
    onSearchInJwOrg: ((String) -> Unit)? = null,
    onShare: ((String) -> Unit)? = null,
    // v4.2 — long-press link callback (forwards URL + text to caller)
    onLinkLongPress: ((url: String, text: String) -> Unit)? = null
): WebView {
    // v4.13.0 — Persistent WebView for the popup session. Same WebView
    // instance for sheet and promoted full-screen, so scroll position, form
    // inputs, and JavaScript state survive transitions. The boolean
    // [needsFirstConfig] flag below catches the genuinely-first-time case so
    // we apply settings + load URL only once.
    val webView = vm.getOrCreateWebViewSession("popup", c)
    val needsFirstConfig = webView.webViewClient == null ||
        webView.url.isNullOrBlank()

    return webView.apply {
        // ── Selection-menu callbacks ────────────────────────────────────────
        // Re-wired on every mount because the lambdas close over the current
        // Composable's vm / nav references, which can go stale across
        // navigation.
        this.onSearchInMarkVault = onSearchInMarkVault
        this.onSearchInWol = onSearchInWol
        this.onSearchInJwOrg = onSearchInJwOrg
        this.onShare = onShare

        // ── Long-press link handler ────────────────────────────────────────
        // Same reasoning: closes over the popupLinkLongPress state hosted in
        // the Composable, must re-wire.
        setOnLongClickListener {
            val hit = hitTestResult
            val type = hit.type
            val isAnchor = type == WebView.HitTestResult.SRC_ANCHOR_TYPE ||
                type == WebView.HitTestResult.SRC_IMAGE_ANCHOR_TYPE
            if (isAnchor && onLinkLongPress != null) {
                val href = hit.extra ?: return@setOnLongClickListener false
                val esc = href.replace("\\", "\\\\").replace("'", "\\'")
                evaluateJavascript(
                    "(function(){var as=document.querySelectorAll('a');" +
                    "for(var i=0;i<as.length;i++){if(as[i].href==='$esc')" +
                    "return as[i].textContent.replace(/\\s+/g,' ').trim();}return '';})();"
                ) { result ->
                    val text = decodeJsSelectionPublic(result)
                    onLinkLongPress.invoke(href, text)
                }
                return@setOnLongClickListener true
            }
            false
        }

        // ── Touch interception fix for the bottom-sheet host ────────────────
        // Re-wired every time because the parent ViewGroup is different in
        // bottom-sheet host vs full-screen host.
        setOnTouchListener { v, ev ->
            when (ev.actionMasked) {
                MotionEvent.ACTION_DOWN,
                MotionEvent.ACTION_MOVE,
                MotionEvent.ACTION_POINTER_DOWN ->
                    v.parent?.requestDisallowInterceptTouchEvent(true)
                MotionEvent.ACTION_UP,
                MotionEvent.ACTION_CANCEL ->
                    v.parent?.requestDisallowInterceptTouchEvent(false)
            }
            false  // never consume — let the WebView handle the gesture itself
        }

        // ── webViewClient — re-wired every mount because it captures `c`
        // (Context) and `vm` references that change across navigation.
        webViewClient = object : WebViewClient() {
            override fun shouldOverrideUrlLoading(
                view: WebView?, request: WebResourceRequest?
            ): Boolean {
                val u = request?.url ?: return false
                if (isJwHostUri(u)) return false
                runCatching {
                    val intent = android.content.Intent(android.content.Intent.ACTION_VIEW, u)
                        .addFlags(android.content.Intent.FLAG_ACTIVITY_NEW_TASK)
                    c.startActivity(intent)
                }
                return true
            }

            override fun onPageStarted(
                view: WebView?, url: String?, favicon: android.graphics.Bitmap?
            ) {
                onNavState?.invoke(
                    url ?: "", view?.title ?: "",
                    view?.canGoBack() == true, view?.canGoForward() == true
                )
            }

            override fun onPageFinished(view: WebView?, url: String?) {
                view?.evaluateJavascript(LINK_TAP_HIGHLIGHT_JS, null)
                if (dark) {
                    view?.evaluateJavascript(POPUP_DARK_OVERLAY_JS, null)
                } else {
                    view?.evaluateJavascript(POPUP_REMOVE_OVERLAY_JS, null)
                }
                onNavState?.invoke(
                    url ?: "", view?.title ?: "",
                    view?.canGoBack() == true, view?.canGoForward() == true
                )
                if (!url.isNullOrBlank()) {
                    vm.recordWebVisit(url, view?.title ?: url)
                }
            }

            override fun onRenderProcessGone(
                view: WebView?,
                detail: android.webkit.RenderProcessGoneDetail?
            ): Boolean {
                // v4.13.0 — if the persistent popup WebView's renderer dies,
                // drop it from the pool so the next mount creates a fresh one.
                runCatching { vm.destroyWebViewSession("popup") }
                return true
            }
        }

        // Apply the live zoom on every mount (cheap; the user may have
        // changed it since the last mount).
        settings.textZoom = zoom

        // ── One-time configuration for a brand-new WebView ────────────────
        if (needsFirstConfig) {
            settings.javaScriptEnabled = true
            settings.domStorageEnabled = true
            settings.databaseEnabled = true
            settings.allowFileAccess = false
            settings.allowContentAccess = true
            settings.loadsImagesAutomatically = true
            settings.setSupportZoom(true)
            settings.builtInZoomControls = true
            settings.displayZoomControls = false
            settings.useWideViewPort = true
            settings.loadWithOverviewMode = true
            settings.mediaPlaybackRequiresUserGesture = true
            settings.mixedContentMode = WebSettings.MIXED_CONTENT_COMPATIBILITY_MODE
            settings.userAgentString = settings.userAgentString + " MarkVault/3.4"
        }

        // ── URL loading policy ─────────────────────────────────────────────
        // Only load the requested URL when it differs from what the WebView
        // is already showing, with trailing-slash normalisation to avoid
        // pointless reloads of effectively-the-same page. This is what makes
        // "promote/shrink" feel like the same continuous browsing session
        // instead of a reload.
        val currentUrl = this.url?.trimEnd('/')
        val requestedUrl = urlInitial.trimEnd('/')
        if (needsFirstConfig || currentUrl != requestedUrl) {
            loadUrl(urlInitial)
        }

        onWebReady(this)
    }
}

/** Wrap the dark-mode API safely (feature-detected). */
private fun applyAlgorithmicDarkening(w: WebView, dark: Boolean) {
    runCatching {
        if (WebViewFeature.isFeatureSupported(WebViewFeature.ALGORITHMIC_DARKENING)) {
            WebSettingsCompat.setAlgorithmicDarkeningAllowed(w.settings, dark)
        } else if (WebViewFeature.isFeatureSupported(WebViewFeature.FORCE_DARK)) {
            // Legacy fallback for older WebViews
            @Suppress("DEPRECATION")
            WebSettingsCompat.setForceDark(
                w.settings,
                if (dark) WebSettingsCompat.FORCE_DARK_ON else WebSettingsCompat.FORCE_DARK_OFF
            )
        }
    }
}

/**
 * Injected on every page load. Adds a yellow tap-highlight to whichever <a> the user tapped
 * last, clears it when the user taps elsewhere (plain text or another link). The IIFE makes
 * itself idempotent so re-injection on hash-changes doesn't double-bind listeners.
 *
 * Colour is a translucent amber that stays readable in both light pages (dark text) and
 * dark pages (light text under algorithmic darkening).
 */
/**
 * Injects a single <style> element with `id="mv-dark-overlay"` to tint the page
 * background + text to match the user's dark app theme. Surgical — only colour
 * variables. jw.org's own layout, fonts, and images stay untouched.
 * Idempotent — safe to call on every onPageFinished.
 */
private val POPUP_DARK_OVERLAY_JS = """
(function() {
  var existing = document.getElementById('mv-dark-overlay');
  if (existing) return;
  var s = document.createElement('style');
  s.id = 'mv-dark-overlay';
  s.textContent = "" +
    "html, body { background-color: #1c2026 !important; color: #e2e6ec !important; }" +
    "div, section, article, main, header, footer, aside, nav, " +
    "p, li, span, td, th, dd, dt, label { background-color: transparent !important; color: inherit !important; }" +
    "h1, h2, h3, h4, h5, h6 { color: #f4f7fa !important; }" +
    "a, a:link { color: #8ab4f8 !important; }" +
    "a:visited { color: #c58af9 !important; }";
  document.head.appendChild(s);
})();
""".trimIndent()

/** Removes the dark overlay when user toggles back to light mode. */
private val POPUP_REMOVE_OVERLAY_JS = """
(function() {
  var el = document.getElementById('mv-dark-overlay');
  if (el) el.remove();
})();
""".trimIndent()

private val LINK_TAP_HIGHLIGHT_JS = """
(function(){
  if (window.__mvLinkTapInstalled) return;
  window.__mvLinkTapInstalled = true;
  try {
    var style = document.createElement('style');
    style.id = 'mv-link-tap-style';
    style.textContent =
      '.mv-tapped{background-color:rgba(255,217,0,0.30)!important;'+
      'outline:2px solid rgba(255,193,7,0.65)!important;'+
      'border-radius:3px;'+
      'transition:background-color 120ms,outline-color 120ms;}';
    (document.head || document.documentElement).appendChild(style);

    var lastTapped = null;
    function clearLast(){
      if (lastTapped) {
        lastTapped.classList.remove('mv-tapped');
        lastTapped = null;
      }
    }
    // Click delegation — capture phase so we see it before any page handlers
    document.addEventListener('click', function(e){
      var t = e.target;
      // Walk up to find an <a> ancestor (image-in-link case)
      var anchor = null;
      while (t && t !== document.body) {
        if (t.tagName === 'A') { anchor = t; break; }
        t = t.parentNode;
      }
      clearLast();
      if (anchor) {
        anchor.classList.add('mv-tapped');
        lastTapped = anchor;
      }
    }, true);
  } catch (err) { /* ignore */ }
})();
""".trimIndent()

