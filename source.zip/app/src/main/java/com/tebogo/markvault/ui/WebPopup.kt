@file:OptIn(androidx.compose.material3.ExperimentalMaterial3Api::class)

package com.tebogo.markvault.ui

import android.content.Context
import android.net.Uri
import android.view.MotionEvent
import android.webkit.WebResourceRequest
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.statusBars
import androidx.compose.foundation.layout.windowInsetsPadding
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.KeyboardArrowLeft
import androidx.compose.material.icons.automirrored.filled.KeyboardArrowRight
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.rememberModalBottomSheetState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.webkit.WebSettingsCompat
import androidx.webkit.WebViewFeature
import com.tebogo.markvault.AppViewModel

/**
 * Hosts of pages we keep inside the in-app WebView popup. (Used here AND in ReaderScreen.)
 */
private val JW_HOST_SUFFIXES = listOf(
    "jw.org", "wol.jw.org", "tv.jw.org", "jw-cdn.org", "akamaihd.net"
)

internal fun isJwHostUri(uri: Uri): Boolean {
    val host = uri.host?.lowercase() ?: return false
    return JW_HOST_SUFFIXES.any { host == it || host.endsWith(".$it") }
}

/**
 * In-app WebView popup rendered as a bottom sheet. Use [WebPopupSheet] from anywhere that
 * already has its own scroll-state but wants to overlay a popup browser.
 *
 * Fixes that ship with v2.2:
 *  - Scrolling works: touch listener requests parent disallow-intercept on DOWN/MOVE
 *  - Dark mode toggle via WebSettingsCompat.setAlgorithmicDarkeningAllowed
 *  - Adjustable text zoom (A− / A+) saved to the ViewModel
 *  - "Full screen" preserves WebView state via saveState/restoreState (no reload)
 *  - Internal JW navigation stays inside the popup; external links go to the system browser
 *
 * @param url       URL to load on first composition (or after a restoreState)
 * @param onClose   Called when the user dismisses the sheet
 * @param onPromote Called when the user taps "Full screen" — the popup hands its state Bundle
 *                  back via [AppViewModel.webStateBundle] and the caller navigates to the
 *                  full-screen route.
 */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun WebPopupSheet(
    vm: AppViewModel,
    url: String,
    onClose: () -> Unit,
    onPromote: (url: String, label: String) -> Unit,
    onOpenBookmarks: () -> Unit = {}
) {
    val sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true)
    val hostNow = remember(url) {
        runCatching { Uri.parse(url).host ?: "jw.org" }.getOrElse { "jw.org" }
    }
    ModalBottomSheet(
        onDismissRequest = onClose,
        sheetState = sheetState,
        modifier = Modifier.fillMaxWidth()
    ) {
        WebPopupContents(
            vm = vm,
            urlInitial = url,
            host = hostNow,
            onClose = onClose,
            onPromote = onPromote,
            onOpenBookmarks = onOpenBookmarks,
            fullScreen = false
        )
    }
}

/**
 * Full-screen variant of the in-app browser. Renders the same WebView host + toolbar but
 * sized to fill the parent. Used by the navigation route `web_popup_full/{url}`.
 */
@Composable
fun WebPopupFullScreen(
    vm: AppViewModel,
    url: String,
    onClose: () -> Unit,
    onShrink: (url: String, label: String) -> Unit,
    onOpenBookmarks: () -> Unit = {}
) {
    val hostNow = remember(url) {
        runCatching { Uri.parse(url).host ?: "jw.org" }.getOrElse { "jw.org" }
    }
    Column(
        Modifier
            .fillMaxSize()
            // CRITICAL FIX: pad below the system status bar so the toolbar isn't
            // overlapping the notification area (the icons were unclickable
            // because they sat under the system clock + battery icons).
            .windowInsetsPadding(WindowInsets.statusBars)
    ) {
        WebPopupContents(
            vm = vm,
            urlInitial = url,
            host = hostNow,
            onClose = onClose,
            onPromote = onShrink,   // here "promote" means "shrink back to popup"
            onOpenBookmarks = onOpenBookmarks,
            fullScreen = true
        )
    }
}

/**
 * Inner body: toolbar + WebView. Both popup and full-screen variants share this.
 * Declared as a ColumnScope extension so the `.weight(1f)` in full-screen mode compiles.
 */
@Composable
private fun ColumnScope.WebPopupContents(
    vm: AppViewModel,
    urlInitial: String,
    host: String,
    onClose: () -> Unit,
    onPromote: (url: String, label: String) -> Unit,
    onOpenBookmarks: () -> Unit,
    fullScreen: Boolean
) {
    val ctx = androidx.compose.ui.platform.LocalContext.current
    val zoom by vm.webPopupTextZoom.collectAsState()
    val dark by vm.webPopupDarkMode.collectAsState()
    // Hold a reference to the WebView so toolbar buttons can call into it
    var web by remember { androidx.compose.runtime.mutableStateOf<WebView?>(null) }
    // Editable URL bar state — kept in sync with the WebView via onPageStarted/onPageFinished
    var addressText by remember { androidx.compose.runtime.mutableStateOf(urlInitial) }
    var addressFocused by remember { androidx.compose.runtime.mutableStateOf(false) }
    var canGoBack by remember { androidx.compose.runtime.mutableStateOf(false) }
    var canGoForward by remember { androidx.compose.runtime.mutableStateOf(false) }
    val keyboard = androidx.compose.ui.platform.LocalSoftwareKeyboardController.current

    // v4.2 — popup long-press link sheet state. Declared at function scope so
    // both the AndroidView's onLinkLongPress callback (inside the nested Box)
    // AND the ModalBottomSheet rendered later in this composable can see it.
    // Previously this lived inside the Box scope and the sheet rendering
    // failed to compile because the variable was out of scope.
    var popupLinkLongPress by remember {
        androidx.compose.runtime.mutableStateOf<Pair<String, String>?>(null)
    }

    fun submitAddress() {
        val raw = addressText.trim()
        if (raw.isEmpty()) return
        val target = when {
            raw.startsWith("http://") || raw.startsWith("https://") -> raw
            raw.contains(".") -> "https://$raw"
            else -> "https://www.jw.org/en/search/?q=" + Uri.encode(raw)
        }
        if (!isJwHostUri(Uri.parse(target))) {
            android.widget.Toast.makeText(
                ctx, "Only jw.org family of sites are allowed",
                android.widget.Toast.LENGTH_SHORT
            ).show()
            return
        }
        keyboard?.hide()
        web?.loadUrl(target)
        addressFocused = false
    }

    // Track bookmark state for the URL currently shown in the popup.
    // Re-checked whenever the URL changes (after navigation, fullscreen toggle, etc).
    var isBookmarked by remember { mutableStateOf(false) }
    var currentUrl by remember { mutableStateOf(urlInitial) }
    LaunchedEffect(currentUrl) {
        isBookmarked = if (currentUrl.isBlank()) false
        else vm.isBookmarked(currentUrl)
    }

    // Toolbar — Row 1: action buttons (refresh, external link, A-, A+, fullscreen, close)
    Row(
        Modifier.fillMaxWidth().padding(start = 14.dp, end = 0.dp, top = 4.dp, bottom = 0.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(
            "\uD83C\uDF10  $host", fontWeight = FontWeight.SemiBold, fontSize = 13.sp,
            modifier = Modifier.weight(1f), maxLines = 1, overflow = TextOverflow.Ellipsis,
            color = MaterialTheme.colorScheme.onSurfaceVariant
        )
        // Refresh the current page in the popup
        IconButton(onClick = { web?.reload() }) {
            Icon(Icons.Default.Refresh, contentDescription = "Refresh")
        }
        // Open the current page in the system default browser
        IconButton(onClick = {
            val target = web?.url ?: urlInitial
            runCatching {
                val intent = android.content.Intent(
                    android.content.Intent.ACTION_VIEW, Uri.parse(target)
                ).addFlags(android.content.Intent.FLAG_ACTIVITY_NEW_TASK)
                ctx.startActivity(intent)
            }
        }) {
            // ↗ glyph — works on every Android since it's a unicode arrow rather than a vector icon
            Text("\u2197", fontSize = 18.sp, fontWeight = FontWeight.Bold)
        }
        // ★ Save as favourite — toggles bookmark for the current URL
        IconButton(onClick = {
            val u = web?.url ?: currentUrl
            val t = web?.title ?: host
            if (isBookmarked) vm.removeBookmark(u) else vm.addBookmark(u, t)
            isBookmarked = !isBookmarked
        }) {
            Text(
                if (isBookmarked) "\u2605" else "\u2606",
                fontSize = 20.sp,
                color = if (isBookmarked) androidx.compose.ui.graphics.Color(0xFFFFC107)
                else MaterialTheme.colorScheme.onSurface
            )
        }
        // 🔖 Open the bookmarks list screen
        IconButton(onClick = onOpenBookmarks) {
            Text("\uD83D\uDD16", fontSize = 18.sp)
        }
        // Dark mode toggle
        IconButton(onClick = { vm.setWebPopupDarkMode(!dark) }) {
            Text(if (dark) "\u263C" else "\uD83C\uDF19", fontSize = 16.sp)
        }
        // Text zoom A− / A+
        TextButton(
            onClick = { vm.setWebPopupTextZoom(zoom - 10) },
            contentPadding = PaddingValues(horizontal = 6.dp)
        ) { Text("A\u2212", fontSize = 13.sp) }
        TextButton(
            onClick = { vm.setWebPopupTextZoom(zoom + 10) },
            contentPadding = PaddingValues(horizontal = 6.dp)
        ) { Text("A+", fontSize = 13.sp) }
        // Toggle between popup and full-screen, preserving state
        IconButton(onClick = {
            val w = web
            if (w != null) {
                val bundle = android.os.Bundle()
                w.saveState(bundle)
                vm.webStateBundle = bundle
            }
            val u = w?.url ?: urlInitial
            onPromote(u, host)
        }) {
            Text(
                if (fullScreen) "\u2924" else "\u2922",
                fontSize = 16.sp,
                fontWeight = FontWeight.Bold
            )
        }
        // v4.4.3 — Home button in popup too so the toolbar matches the rest
        // of the app. Closes the popup AND pops back to home.
        IconButton(onClick = {
            onClose()
            // popBackStack happens via the parent host on the next compose.
        }) {
            Text("\uD83C\uDFE0", fontSize = 16.sp)
        }
        IconButton(onClick = onClose) {
            Icon(Icons.Default.Close, contentDescription = "Close")
        }
    }

    // Toolbar — Row 2: back / forward + editable URL field. Gives the popup
    // a real-browser feel; user can navigate within jw.org without leaving the popup.
    Row(
        Modifier.fillMaxWidth().padding(horizontal = 8.dp, vertical = 4.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        IconButton(
            onClick = { web?.goBack() },
            enabled = canGoBack,
            modifier = Modifier.size(32.dp)
        ) {
            Icon(Icons.AutoMirrored.Filled.KeyboardArrowLeft,
                contentDescription = "Back",
                tint = if (canGoBack) MaterialTheme.colorScheme.onSurface
                else MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.4f))
        }
        IconButton(
            onClick = { web?.goForward() },
            enabled = canGoForward,
            modifier = Modifier.size(32.dp)
        ) {
            Icon(Icons.AutoMirrored.Filled.KeyboardArrowRight,
                contentDescription = "Forward",
                tint = if (canGoForward) MaterialTheme.colorScheme.onSurface
                else MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.4f))
        }
        androidx.compose.material3.OutlinedTextField(
            value = addressText,
            onValueChange = { addressText = it },
            singleLine = true,
            modifier = Modifier.weight(1f).height(54.dp),
            placeholder = { Text("URL or search\u2026", fontSize = 14.sp) },
            textStyle = androidx.compose.ui.text.TextStyle(
                fontSize = 14.sp,
                fontWeight = FontWeight.Medium
            ),
            keyboardOptions = androidx.compose.foundation.text.KeyboardOptions(
                imeAction = androidx.compose.ui.text.input.ImeAction.Go
            ),
            keyboardActions = androidx.compose.foundation.text.KeyboardActions(
                onGo = { submitAddress() }
            ),
            shape = androidx.compose.foundation.shape.RoundedCornerShape(22.dp),
            colors = androidx.compose.material3.TextFieldDefaults.colors(
                focusedContainerColor = MaterialTheme.colorScheme.surface,
                unfocusedContainerColor = MaterialTheme.colorScheme.surface
            )
        )
    }

    // WebView host. In popup mode, constrain height; in full-screen mode, fill the parent.
    val webBoxModifier = if (fullScreen)
        Modifier.fillMaxWidth().weight(1f)
    else
        Modifier.fillMaxWidth().heightIn(min = 360.dp, max = 720.dp)

    Box(webBoxModifier) {
        AndroidView(
            modifier = Modifier.fillMaxSize(),
            factory = { c ->
                createPopupWebView(
                    c, vm, dark, zoom, urlInitial,
                    onWebReady = { web = it },
                    onNavState = { u, _, back, fwd ->
                        if (!addressFocused && u.isNotEmpty()) addressText = u
                        canGoBack = back
                        canGoForward = fwd
                        // Update currentUrl so bookmark state stays in sync as the
                        // user navigates inside the popup. This callback runs in
                        // WebPopupContents' scope, so `currentUrl` is visible here
                        // (unlike inside createPopupWebView).
                        if (u.isNotEmpty()) currentUrl = u
                    },
                    onSearchInMarkVault = { text ->
                        // Push the selection through the VM's pending-query channel;
                        // the Search screen consumes it on next entry.
                        vm.requestPendingSearch(text)
                        // Close the popup so the navigation host can show Search.
                        // Direct nav-to-Search would need a NavController which we
                        // don't have here — MainActivity observes pendingSearch.
                        onClose()
                    },
                    onSearchInWol = { text ->
                        val target = "https://wol.jw.org/en/wol/s/r1/lp-e?q=" +
                            java.net.URLEncoder.encode(text, "UTF-8")
                        // Load directly in this same popup — no need to dismiss.
                        web?.loadUrl(target)
                    },
                    onLinkLongPress = { url, text ->
                        popupLinkLongPress = url to text
                    }
                )
            },
            update = { w ->
                // Apply zoom changes when textZoom state changes.
                w.settings.textZoom = zoom
                // Re-apply the dark overlay LIVE on every recomposition so toggling
                // the moon button takes effect immediately (no page reload needed).
                if (dark) w.evaluateJavascript(POPUP_DARK_OVERLAY_JS, null)
                else w.evaluateJavascript(POPUP_REMOVE_OVERLAY_JS, null)
            }
        )
    }

    // In popup mode reserve a small bottom inset for the drag handle area
    if (!fullScreen) Spacer(Modifier.height(8.dp))

    // v4.2 — bottom-of-popup action sheet shown when the user long-presses a
    // link in the popup's WebView. Mirrors the markdown-reader experience:
    // Open externally / Copy / Search in wol.jw.org.
    //
    // NOTE: we intentionally avoid the `(longUrl, longText) ->` destructuring
    // form here. Kotlin can't always pick between the Pair component2() and
    // various Array/List component2() extensions on the call site, which made
    // the previous compile fail. Explicit .first / .second is unambiguous.
    val pendingLongPress = popupLinkLongPress
    if (pendingLongPress != null) {
        val longUrl = pendingLongPress.first
        val longText = pendingLongPress.second
        ModalBottomSheet(onDismissRequest = { popupLinkLongPress = null }) {
            Column(Modifier.fillMaxWidth().padding(horizontal = 18.dp, vertical = 8.dp)) {
                Text(
                    longText.ifBlank { longUrl },
                    fontSize = 14.sp,
                    fontWeight = FontWeight.SemiBold,
                    maxLines = 2,
                    overflow = TextOverflow.Ellipsis
                )
                Text(
                    longUrl,
                    fontSize = 11.sp,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis,
                    modifier = Modifier.padding(top = 2.dp)
                )
                Spacer(Modifier.height(10.dp))
                androidx.compose.material3.TextButton(
                    onClick = {
                        web?.loadUrl(longUrl)
                        popupLinkLongPress = null
                    },
                    modifier = Modifier.fillMaxWidth()
                ) { Text("\uD83D\uDD17  Open in this popup") }
                androidx.compose.material3.TextButton(
                    onClick = {
                        runCatching {
                            val clip = ctx.getSystemService(android.content.Context.CLIPBOARD_SERVICE)
                                as? android.content.ClipboardManager
                            clip?.setPrimaryClip(android.content.ClipData.newPlainText("url", longUrl))
                        }
                        popupLinkLongPress = null
                    },
                    modifier = Modifier.fillMaxWidth()
                ) { Text("\uD83D\uDCCB  Copy link") }
                androidx.compose.material3.TextButton(
                    onClick = {
                        runCatching {
                            ctx.startActivity(
                                android.content.Intent(
                                    android.content.Intent.ACTION_VIEW,
                                    Uri.parse(longUrl)
                                ).addFlags(android.content.Intent.FLAG_ACTIVITY_NEW_TASK)
                            )
                        }
                        popupLinkLongPress = null
                    },
                    modifier = Modifier.fillMaxWidth()
                ) { Text("\uD83C\uDF10  Open in system browser") }
                androidx.compose.material3.TextButton(
                    onClick = {
                        val q = if (longText.length > 1) longText else longUrl
                        val target = "https://wol.jw.org/en/wol/s/r1/lp-e?q=" +
                            java.net.URLEncoder.encode(q, "UTF-8")
                        web?.loadUrl(target)
                        popupLinkLongPress = null
                    },
                    modifier = Modifier.fillMaxWidth()
                ) { Text("\uD83D\uDD0D  Search in wol.jw.org") }
                Spacer(Modifier.height(16.dp))
            }
        }
    }
}

/**
 * Build the WebView with all our custom settings, the touch-pass-through that fixes the
 * bottom-sheet scroll bug, and state restoration where available.
 */
private fun createPopupWebView(
    c: Context,
    vm: AppViewModel,
    dark: Boolean,
    zoom: Int,
    urlInitial: String,
    onWebReady: (WebView) -> Unit,
    onNavState: ((url: String, title: String, canBack: Boolean, canFwd: Boolean) -> Unit)? = null,
    // v4.2 — text-selection menu callbacks (Search in MarkVault / Search in wol.jw.org)
    onSearchInMarkVault: ((String) -> Unit)? = null,
    onSearchInWol: ((String) -> Unit)? = null,
    // v4.2 — long-press link callback (forwards URL + text to caller)
    onLinkLongPress: ((url: String, text: String) -> Unit)? = null
): WebView {
    return SelectionWebView(c).apply {
        // Wire the text-selection menu actions — same SelectionWebView used by
        // the full-screen browser, ensures the menu items appear consistently
        // in both popup and fullscreen.
        this.onSearchInMarkVault = onSearchInMarkVault
        this.onSearchInWol = onSearchInWol
        // Long-press a link → ask the JS for the anchor's text + href, then
        // forward to the caller which shows the bottom-sheet action menu.
        setOnLongClickListener {
            val hit = hitTestResult
            val type = hit.type
            val isAnchor = type == WebView.HitTestResult.SRC_ANCHOR_TYPE ||
                type == WebView.HitTestResult.SRC_IMAGE_ANCHOR_TYPE
            if (isAnchor && onLinkLongPress != null) {
                val href = hit.extra ?: return@setOnLongClickListener false
                val esc = href.replace("\\", "\\\\").replace("'", "\\'")
                evaluateJavascript(
                    "(function(){var as=document.querySelectorAll('a');" +
                    "for(var i=0;i<as.length;i++){if(as[i].href==='$esc')" +
                    "return as[i].textContent.replace(/\\s+/g,' ').trim();}return '';})();"
                ) { result ->
                    val text = decodeJsSelectionPublic(result)
                    onLinkLongPress.invoke(href, text)
                }
                return@setOnLongClickListener true
            }
            false
        }
        settings.javaScriptEnabled = true
        settings.domStorageEnabled = true
        settings.databaseEnabled = true
        settings.allowFileAccess = false
        settings.allowContentAccess = true
        settings.loadsImagesAutomatically = true
        settings.setSupportZoom(true)
        settings.builtInZoomControls = true
        settings.displayZoomControls = false
        settings.useWideViewPort = true
        settings.loadWithOverviewMode = true
        settings.textZoom = zoom
        settings.mediaPlaybackRequiresUserGesture = true
        settings.mixedContentMode = WebSettings.MIXED_CONTENT_COMPATIBILITY_MODE
        // Same UA suffix as the main browser so jw.org's Bible viewer serves
        // the full layout instead of a stripped fallback that can render blank.
        settings.userAgentString = settings.userAgentString + " MarkVault/3.4"
        // IMPORTANT — DO NOT enable algorithmic darkening / force-dark here.
        // jw.org has its OWN dark-mode handling (via the prefers-color-scheme
        // media query). Combining it with WebView force-dark produces
        // dark text on a dark background → the "black scripture popup" symptom
        // on www.jw.org. The popup always renders jw.org in its own colours;
        // the user can flip jw.org's built-in theme picker if they want dark.
        // The `dark` parameter is kept in the signature for backwards
        // compatibility with callers; it is intentionally unused.

        // === The scroll bug fix ===
        // ModalBottomSheet's draggable container intercepts vertical touches by default.
        // Tell the parent to leave touch events alone while the user is interacting with
        // the WebView. This is the canonical Android way to nest a scrollable view inside
        // a draggable parent.
        setOnTouchListener { v, ev ->
            when (ev.actionMasked) {
                MotionEvent.ACTION_DOWN,
                MotionEvent.ACTION_MOVE,
                MotionEvent.ACTION_POINTER_DOWN ->
                    v.parent?.requestDisallowInterceptTouchEvent(true)
                MotionEvent.ACTION_UP,
                MotionEvent.ACTION_CANCEL ->
                    v.parent?.requestDisallowInterceptTouchEvent(false)
            }
            false  // never consume — let the WebView handle the gesture itself
        }

        webViewClient = object : WebViewClient() {
            override fun shouldOverrideUrlLoading(
                view: WebView?, request: WebResourceRequest?
            ): Boolean {
                val u = request?.url ?: return false
                // Keep navigation inside the popup if it stays on JW domains;
                // otherwise hand off to the system browser.
                if (isJwHostUri(u)) return false
                runCatching {
                    val intent = android.content.Intent(android.content.Intent.ACTION_VIEW, u)
                        .addFlags(android.content.Intent.FLAG_ACTIVITY_NEW_TASK)
                    c.startActivity(intent)
                }
                return true
            }

            override fun onPageStarted(
                view: WebView?, url: String?, favicon: android.graphics.Bitmap?
            ) {
                onNavState?.invoke(
                    url ?: "", view?.title ?: "",
                    view?.canGoBack() == true, view?.canGoForward() == true
                )
            }

            override fun onPageFinished(view: WebView?, url: String?) {
                // Install link-tap highlight: clicked anchors get a yellow tint until the user
                // taps plain text or another link. Idempotent — checks if already installed.
                view?.evaluateJavascript(LINK_TAP_HIGHLIGHT_JS, null)
                // Theme sync — inject a small CSS overlay that tints background +
                // text to match the user's app theme. Surgical (just colour vars),
                // so jw.org's own layout / fonts / images stay intact. This brings
                // back the dark-mode-button behaviour without re-triggering the
                // black-screen bug that algorithmic darkening caused.
                if (dark) {
                    view?.evaluateJavascript(POPUP_DARK_OVERLAY_JS, null)
                } else {
                    view?.evaluateJavascript(POPUP_REMOVE_OVERLAY_JS, null)
                }
                onNavState?.invoke(
                    url ?: "", view?.title ?: "",
                    view?.canGoBack() == true, view?.canGoForward() == true
                )
                if (!url.isNullOrBlank()) {
                    vm.recordWebVisit(url, view?.title ?: url)
                }
                // Note: currentUrl (in WebPopupContents) is updated via onNavState,
                // which receives the url just before this. That's our scope-safe path
                // — `currentUrl` itself isn't in scope here (we're inside createPopupWebView).
            }

            /**
             * v4.5 — popup-side renderer-crash handler. Same rule: return true
             * so Android doesn't kill the app. The popup's WebView is dropped
             * silently; the user can close the popup and reopen it to get a
             * fresh renderer.
             */
            override fun onRenderProcessGone(
                view: WebView?,
                detail: android.webkit.RenderProcessGoneDetail?
            ): Boolean {
                runCatching { view?.destroy() }
                return true
            }
        }

        // Restore state if the previous popup/full-screen handed off a bundle; otherwise load
        // the URL fresh. This is what makes "Full screen ↔ shrink" feel instant.
        val saved = vm.consumeWebState()
        if (saved != null && !saved.isEmpty) {
            val restored = restoreState(saved)
            // restoreState returns the WebBackForwardList if successful, null otherwise
            if (restored == null) {
                loadUrl(urlInitial)
            }
        } else {
            loadUrl(urlInitial)
        }

        onWebReady(this)
    }
}

/** Wrap the dark-mode API safely (feature-detected). */
private fun applyAlgorithmicDarkening(w: WebView, dark: Boolean) {
    runCatching {
        if (WebViewFeature.isFeatureSupported(WebViewFeature.ALGORITHMIC_DARKENING)) {
            WebSettingsCompat.setAlgorithmicDarkeningAllowed(w.settings, dark)
        } else if (WebViewFeature.isFeatureSupported(WebViewFeature.FORCE_DARK)) {
            // Legacy fallback for older WebViews
            @Suppress("DEPRECATION")
            WebSettingsCompat.setForceDark(
                w.settings,
                if (dark) WebSettingsCompat.FORCE_DARK_ON else WebSettingsCompat.FORCE_DARK_OFF
            )
        }
    }
}

/**
 * Injected on every page load. Adds a yellow tap-highlight to whichever <a> the user tapped
 * last, clears it when the user taps elsewhere (plain text or another link). The IIFE makes
 * itself idempotent so re-injection on hash-changes doesn't double-bind listeners.
 *
 * Colour is a translucent amber that stays readable in both light pages (dark text) and
 * dark pages (light text under algorithmic darkening).
 */
/**
 * Injects a single <style> element with `id="mv-dark-overlay"` to tint the page
 * background + text to match the user's dark app theme. Surgical — only colour
 * variables. jw.org's own layout, fonts, and images stay untouched.
 * Idempotent — safe to call on every onPageFinished.
 */
private val POPUP_DARK_OVERLAY_JS = """
(function() {
  var existing = document.getElementById('mv-dark-overlay');
  if (existing) return;
  var s = document.createElement('style');
  s.id = 'mv-dark-overlay';
  s.textContent = "" +
    "html, body { background-color: #1c2026 !important; color: #e2e6ec !important; }" +
    "div, section, article, main, header, footer, aside, nav, " +
    "p, li, span, td, th, dd, dt, label { background-color: transparent !important; color: inherit !important; }" +
    "h1, h2, h3, h4, h5, h6 { color: #f4f7fa !important; }" +
    "a, a:link { color: #8ab4f8 !important; }" +
    "a:visited { color: #c58af9 !important; }";
  document.head.appendChild(s);
})();
""".trimIndent()

/** Removes the dark overlay when user toggles back to light mode. */
private val POPUP_REMOVE_OVERLAY_JS = """
(function() {
  var el = document.getElementById('mv-dark-overlay');
  if (el) el.remove();
})();
""".trimIndent()

private val LINK_TAP_HIGHLIGHT_JS = """
(function(){
  if (window.__mvLinkTapInstalled) return;
  window.__mvLinkTapInstalled = true;
  try {
    var style = document.createElement('style');
    style.id = 'mv-link-tap-style';
    style.textContent =
      '.mv-tapped{background-color:rgba(255,217,0,0.30)!important;'+
      'outline:2px solid rgba(255,193,7,0.65)!important;'+
      'border-radius:3px;'+
      'transition:background-color 120ms,outline-color 120ms;}';
    (document.head || document.documentElement).appendChild(style);

    var lastTapped = null;
    function clearLast(){
      if (lastTapped) {
        lastTapped.classList.remove('mv-tapped');
        lastTapped = null;
      }
    }
    // Click delegation — capture phase so we see it before any page handlers
    document.addEventListener('click', function(e){
      var t = e.target;
      // Walk up to find an <a> ancestor (image-in-link case)
      var anchor = null;
      while (t && t !== document.body) {
        if (t.tagName === 'A') { anchor = t; break; }
        t = t.parentNode;
      }
      clearLast();
      if (anchor) {
        anchor.classList.add('mv-tapped');
        lastTapped = anchor;
      }
    }, true);
  } catch (err) { /* ignore */ }
})();
""".trimIndent()

