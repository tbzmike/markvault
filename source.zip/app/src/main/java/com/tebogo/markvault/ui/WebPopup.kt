package com.tebogo.markvault.ui

import android.content.Context
import android.net.Uri
import android.view.MotionEvent
import android.webkit.WebResourceRequest
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.rememberModalBottomSheetState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.webkit.WebSettingsCompat
import androidx.webkit.WebViewFeature
import com.tebogo.markvault.AppViewModel

/**
 * Hosts of pages we keep inside the in-app WebView popup. (Used here AND in ReaderScreen.)
 */
private val JW_HOST_SUFFIXES = listOf(
    "jw.org", "wol.jw.org", "tv.jw.org", "jw-cdn.org", "akamaihd.net"
)

internal fun isJwHostUri(uri: Uri): Boolean {
    val host = uri.host?.lowercase() ?: return false
    return JW_HOST_SUFFIXES.any { host == it || host.endsWith(".$it") }
}

/**
 * In-app WebView popup rendered as a bottom sheet. Use [WebPopupSheet] from anywhere that
 * already has its own scroll-state but wants to overlay a popup browser.
 *
 * Fixes that ship with v2.2:
 *  - Scrolling works: touch listener requests parent disallow-intercept on DOWN/MOVE
 *  - Dark mode toggle via WebSettingsCompat.setAlgorithmicDarkeningAllowed
 *  - Adjustable text zoom (A− / A+) saved to the ViewModel
 *  - "Full screen" preserves WebView state via saveState/restoreState (no reload)
 *  - Internal JW navigation stays inside the popup; external links go to the system browser
 *
 * @param url       URL to load on first composition (or after a restoreState)
 * @param onClose   Called when the user dismisses the sheet
 * @param onPromote Called when the user taps "Full screen" — the popup hands its state Bundle
 *                  back via [AppViewModel.webStateBundle] and the caller navigates to the
 *                  full-screen route.
 */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun WebPopupSheet(
    vm: AppViewModel,
    url: String,
    onClose: () -> Unit,
    onPromote: (url: String, label: String) -> Unit
) {
    val sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true)
    val hostNow = remember(url) {
        runCatching { Uri.parse(url).host ?: "jw.org" }.getOrElse { "jw.org" }
    }
    ModalBottomSheet(
        onDismissRequest = onClose,
        sheetState = sheetState,
        modifier = Modifier.fillMaxWidth()
    ) {
        WebPopupContents(
            vm = vm,
            urlInitial = url,
            host = hostNow,
            onClose = onClose,
            onPromote = onPromote,
            fullScreen = false
        )
    }
}

/**
 * Full-screen variant of the in-app browser. Renders the same WebView host + toolbar but
 * sized to fill the parent. Used by the navigation route `web_popup_full/{url}`.
 */
@Composable
fun WebPopupFullScreen(
    vm: AppViewModel,
    url: String,
    onClose: () -> Unit,
    onShrink: (url: String, label: String) -> Unit
) {
    val hostNow = remember(url) {
        runCatching { Uri.parse(url).host ?: "jw.org" }.getOrElse { "jw.org" }
    }
    Column(Modifier.fillMaxSize()) {
        WebPopupContents(
            vm = vm,
            urlInitial = url,
            host = hostNow,
            onClose = onClose,
            onPromote = onShrink,   // here "promote" means "shrink back to popup"
            fullScreen = true
        )
    }
}

/**
 * Inner body: toolbar + WebView. Both popup and full-screen variants share this.
 * Declared as a ColumnScope extension so the `.weight(1f)` in full-screen mode compiles.
 */
@Composable
private fun ColumnScope.WebPopupContents(
    vm: AppViewModel,
    urlInitial: String,
    host: String,
    onClose: () -> Unit,
    onPromote: (url: String, label: String) -> Unit,
    fullScreen: Boolean
) {
    val ctx = androidx.compose.ui.platform.LocalContext.current
    val zoom by vm.webPopupTextZoom.collectAsState()
    val dark by vm.webPopupDarkMode.collectAsState()
    // Hold a reference to the WebView so toolbar buttons can call into it
    var web by remember { androidx.compose.runtime.mutableStateOf<WebView?>(null) }

    // Toolbar
    Row(
        Modifier.fillMaxWidth().padding(start = 14.dp, end = 0.dp, top = 4.dp, bottom = 4.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(
            "\uD83C\uDF10  $host", fontWeight = FontWeight.SemiBold, fontSize = 14.sp,
            modifier = Modifier.weight(1f), maxLines = 1, overflow = TextOverflow.Ellipsis
        )
        // Refresh the current page in the popup
        IconButton(onClick = { web?.reload() }) {
            Icon(Icons.Default.Refresh, contentDescription = "Refresh")
        }
        // Open the current page in the system default browser
        IconButton(onClick = {
            val target = web?.url ?: urlInitial
            runCatching {
                val intent = android.content.Intent(
                    android.content.Intent.ACTION_VIEW, Uri.parse(target)
                ).addFlags(android.content.Intent.FLAG_ACTIVITY_NEW_TASK)
                ctx.startActivity(intent)
            }
        }) {
            // ↗ glyph — works on every Android since it's a unicode arrow rather than a vector icon
            Text("\u2197", fontSize = 18.sp, fontWeight = FontWeight.Bold)
        }
        // Dark mode toggle
        IconButton(onClick = { vm.setWebPopupDarkMode(!dark) }) {
            Text(if (dark) "\u263C" else "\uD83C\uDF19", fontSize = 16.sp)
        }
        // Text zoom A− / A+
        TextButton(
            onClick = { vm.setWebPopupTextZoom(zoom - 10) },
            contentPadding = PaddingValues(horizontal = 6.dp)
        ) { Text("A\u2212", fontSize = 13.sp) }
        TextButton(
            onClick = { vm.setWebPopupTextZoom(zoom + 10) },
            contentPadding = PaddingValues(horizontal = 6.dp)
        ) { Text("A+", fontSize = 13.sp) }
        // Toggle between popup and full-screen, preserving state
        IconButton(onClick = {
            val w = web
            if (w != null) {
                val bundle = android.os.Bundle()
                w.saveState(bundle)
                vm.webStateBundle = bundle
            }
            val u = w?.url ?: urlInitial
            onPromote(u, host)
        }) {
            Text(
                if (fullScreen) "\u2924" else "\u2922",
                fontSize = 16.sp,
                fontWeight = FontWeight.Bold
            )
        }
        IconButton(onClick = onClose) {
            Icon(Icons.Default.Close, contentDescription = "Close")
        }
    }

    // WebView host. In popup mode, constrain height; in full-screen mode, fill the parent.
    val webBoxModifier = if (fullScreen)
        Modifier.fillMaxWidth().weight(1f)
    else
        Modifier.fillMaxWidth().heightIn(min = 360.dp, max = 720.dp)

    Box(webBoxModifier) {
        AndroidView(
            modifier = Modifier.fillMaxSize(),
            factory = { c ->
                createPopupWebView(c, vm, dark, zoom, urlInitial, onWebReady = { web = it })
            },
            update = { w ->
                // Apply zoom/dark toggles when their state changes
                w.settings.textZoom = zoom
                applyAlgorithmicDarkening(w, dark)
            }
        )
    }

    // In popup mode reserve a small bottom inset for the drag handle area
    if (!fullScreen) Spacer(Modifier.height(8.dp))
}

/**
 * Build the WebView with all our custom settings, the touch-pass-through that fixes the
 * bottom-sheet scroll bug, and state restoration where available.
 */
private fun createPopupWebView(
    c: Context,
    vm: AppViewModel,
    dark: Boolean,
    zoom: Int,
    urlInitial: String,
    onWebReady: (WebView) -> Unit
): WebView {
    return WebView(c).apply {
        settings.javaScriptEnabled = true
        settings.domStorageEnabled = true
        settings.loadsImagesAutomatically = true
        settings.setSupportZoom(true)
        settings.builtInZoomControls = true
        settings.displayZoomControls = false
        settings.useWideViewPort = true
        settings.loadWithOverviewMode = true
        settings.textZoom = zoom
        settings.mediaPlaybackRequiresUserGesture = true
        settings.mixedContentMode = WebSettings.MIXED_CONTENT_COMPATIBILITY_MODE
        applyAlgorithmicDarkening(this, dark)

        // === The scroll bug fix ===
        // ModalBottomSheet's draggable container intercepts vertical touches by default.
        // Tell the parent to leave touch events alone while the user is interacting with
        // the WebView. This is the canonical Android way to nest a scrollable view inside
        // a draggable parent.
        setOnTouchListener { v, ev ->
            when (ev.actionMasked) {
                MotionEvent.ACTION_DOWN,
                MotionEvent.ACTION_MOVE,
                MotionEvent.ACTION_POINTER_DOWN ->
                    v.parent?.requestDisallowInterceptTouchEvent(true)
                MotionEvent.ACTION_UP,
                MotionEvent.ACTION_CANCEL ->
                    v.parent?.requestDisallowInterceptTouchEvent(false)
            }
            false  // never consume — let the WebView handle the gesture itself
        }

        webViewClient = object : WebViewClient() {
            override fun shouldOverrideUrlLoading(
                view: WebView?, request: WebResourceRequest?
            ): Boolean {
                val u = request?.url ?: return false
                // Keep navigation inside the popup if it stays on JW domains;
                // otherwise hand off to the system browser.
                if (isJwHostUri(u)) return false
                runCatching {
                    val intent = android.content.Intent(android.content.Intent.ACTION_VIEW, u)
                        .addFlags(android.content.Intent.FLAG_ACTIVITY_NEW_TASK)
                    c.startActivity(intent)
                }
                return true
            }

            override fun onPageFinished(view: WebView?, url: String?) {
                // Install link-tap highlight: clicked anchors get a yellow tint until the user
                // taps plain text or another link. Idempotent — checks if already installed.
                view?.evaluateJavascript(LINK_TAP_HIGHLIGHT_JS, null)
            }
        }

        // Restore state if the previous popup/full-screen handed off a bundle; otherwise load
        // the URL fresh. This is what makes "Full screen ↔ shrink" feel instant.
        val saved = vm.consumeWebState()
        if (saved != null && !saved.isEmpty) {
            val restored = restoreState(saved)
            // restoreState returns the WebBackForwardList if successful, null otherwise
            if (restored == null) {
                loadUrl(urlInitial)
            }
        } else {
            loadUrl(urlInitial)
        }

        onWebReady(this)
    }
}

/** Wrap the dark-mode API safely (feature-detected). */
private fun applyAlgorithmicDarkening(w: WebView, dark: Boolean) {
    runCatching {
        if (WebViewFeature.isFeatureSupported(WebViewFeature.ALGORITHMIC_DARKENING)) {
            WebSettingsCompat.setAlgorithmicDarkeningAllowed(w.settings, dark)
        } else if (WebViewFeature.isFeatureSupported(WebViewFeature.FORCE_DARK)) {
            // Legacy fallback for older WebViews
            @Suppress("DEPRECATION")
            WebSettingsCompat.setForceDark(
                w.settings,
                if (dark) WebSettingsCompat.FORCE_DARK_ON else WebSettingsCompat.FORCE_DARK_OFF
            )
        }
    }
}

/**
 * Injected on every page load. Adds a yellow tap-highlight to whichever <a> the user tapped
 * last, clears it when the user taps elsewhere (plain text or another link). The IIFE makes
 * itself idempotent so re-injection on hash-changes doesn't double-bind listeners.
 *
 * Colour is a translucent amber that stays readable in both light pages (dark text) and
 * dark pages (light text under algorithmic darkening).
 */
private val LINK_TAP_HIGHLIGHT_JS = """
(function(){
  if (window.__mvLinkTapInstalled) return;
  window.__mvLinkTapInstalled = true;
  try {
    var style = document.createElement('style');
    style.id = 'mv-link-tap-style';
    style.textContent =
      '.mv-tapped{background-color:rgba(255,217,0,0.30)!important;'+
      'outline:2px solid rgba(255,193,7,0.65)!important;'+
      'border-radius:3px;'+
      'transition:background-color 120ms,outline-color 120ms;}';
    (document.head || document.documentElement).appendChild(style);

    var lastTapped = null;
    function clearLast(){
      if (lastTapped) {
        lastTapped.classList.remove('mv-tapped');
        lastTapped = null;
      }
    }
    // Click delegation — capture phase so we see it before any page handlers
    document.addEventListener('click', function(e){
      var t = e.target;
      // Walk up to find an <a> ancestor (image-in-link case)
      var anchor = null;
      while (t && t !== document.body) {
        if (t.tagName === 'A') { anchor = t; break; }
        t = t.parentNode;
      }
      clearLast();
      if (anchor) {
        anchor.classList.add('mv-tapped');
        lastTapped = anchor;
      }
    }, true);
  } catch (err) { /* ignore */ }
})();
""".trimIndent()

