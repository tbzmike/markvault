@file:OptIn(androidx.compose.material3.ExperimentalMaterial3Api::class)

package com.tebogo.markvault.ui

import android.content.Context
import android.net.Uri
import android.view.MotionEvent
import android.webkit.WebResourceRequest
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.statusBars
import androidx.compose.foundation.layout.navigationBars
import androidx.compose.foundation.layout.windowInsetsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.offset
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.filled.KeyboardArrowLeft
import androidx.compose.material.icons.automirrored.filled.KeyboardArrowRight
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.MoreVert
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.ExtendedFloatingActionButton
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.rememberModalBottomSheetState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.runtime.key
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.zIndex
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.activity.compose.BackHandler
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.background
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.shape.RoundedCornerShape
import kotlinx.coroutines.launch
import androidx.webkit.WebSettingsCompat
import androidx.webkit.WebViewFeature
import com.tebogo.markvault.AppViewModel
import com.tebogo.markvault.data.MediaItem

/**
 * Hosts of pages we keep inside the in-app WebView popup. (Used here AND in ReaderScreen.)
 */
private val JW_HOST_SUFFIXES = listOf(
    "jw.org", "wol.jw.org", "tv.jw.org", "jw-cdn.org", "akamaihd.net"
)

internal fun isJwHostUri(uri: Uri): Boolean {
    val host = uri.host?.lowercase() ?: return false
    return JW_HOST_SUFFIXES.any { host == it || host.endsWith(".$it") }
}

/**
 * In-app WebView popup rendered as a bottom sheet. Use [WebPopupSheet] from anywhere that
 * already has its own scroll-state but wants to overlay a popup browser.
 *
 * Fixes that ship with v2.2:
 *  - Scrolling works: touch listener requests parent disallow-intercept on DOWN/MOVE
 *  - Dark mode toggle via WebSettingsCompat.setAlgorithmicDarkeningAllowed
 *  - Adjustable text zoom (A− / A+) saved to the ViewModel
 *  - "Full screen" preserves WebView state via saveState/restoreState (no reload)
 *  - Internal JW navigation stays inside the popup; external links go to the system browser
 *
 * @param url       URL to load on first composition (or after a restoreState)
 * @param onClose   Called when the user dismisses the sheet
 * @param onPromote Called when the user taps "Full screen" — the popup hands its state Bundle
 *                  back via [AppViewModel.webStateBundle] and the caller navigates to the
 *                  full-screen route.
 */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun WebPopupSheet(
    vm: AppViewModel,
    url: String,
    onClose: () -> Unit,
    onPromote: (url: String, label: String) -> Unit,
    onOpenBookmarks: () -> Unit = {},
    // v4.12.0 — three new navigation callbacks for the popup overflow menu.
    // Default no-ops keep older callers compiling unchanged.
    onOpenWebHistory: () -> Unit = {},
    onOpenPdfHistory: () -> Unit = {},
    onOpenSettings: () -> Unit = {},
    // v5.4.95cc — activity-log entry in the overflow menu, since it's
    // where every "article saved" event lands.
    onOpenActivityLog: () -> Unit = {}
) {
    val sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true)
    val hostNow = remember(url) {
        runCatching { Uri.parse(url).host ?: "jw.org" }.getOrElse { "jw.org" }
    }
    ModalBottomSheet(
        onDismissRequest = onClose,
        sheetState = sheetState,
        modifier = Modifier.fillMaxWidth()
    ) {
        WebPopupContents(
            vm = vm,
            urlInitial = url,
            host = hostNow,
            onClose = onClose,
            onPromote = onPromote,
            onOpenBookmarks = onOpenBookmarks,
            onOpenWebHistory = onOpenWebHistory,
            onOpenPdfHistory = onOpenPdfHistory,
            onOpenSettings = onOpenSettings,
            onOpenActivityLog = onOpenActivityLog,
            fullScreen = false
        )
    }
}

/**
 * Full-screen variant of the in-app browser. Renders the same WebView host + toolbar but
 * sized to fill the parent. Used by the navigation route `web_popup_full/{url}`.
 *
 * v5.4.85cc — A floating "Article" button is overlaid at the bottom-end
 * so the user can return to whichever article they tapped the link
 * from without hunting for the small toolbar Close button. Wired to
 * a dedicated [onReturnToArticle] callback (rather than reusing
 * [onClose]) so MainActivity can later diverge the two — e.g. adding
 * WebView-state preservation on "return to article" without changing
 * plain-close semantics.
 */
@Composable
fun WebPopupFullScreen(
    vm: AppViewModel,
    url: String,
    onClose: () -> Unit,
    onShrink: (url: String, label: String) -> Unit,
    onOpenBookmarks: () -> Unit = {},
    // v4.12.0 — see WebPopupSheet.
    onOpenWebHistory: () -> Unit = {},
    onOpenPdfHistory: () -> Unit = {},
    onOpenSettings: () -> Unit = {},
    // v5.4.95cc — see WebPopupSheet.
    onOpenActivityLog: () -> Unit = {},
    /**
     * v5.4.85cc — Invoked when the user taps the floating "Article"
     * FAB overlaid on the bottom of the full-screen viewer. In the
     * simplest wiring this behaves like [onClose] (pops the back
     * stack back to the calling article); reserved as a separate
     * callback so the routing decision lives in MainActivity and
     * can be extended without churning this composable's signature.
     */
    onReturnToArticle: () -> Unit = onClose
) {
    val hostNow = remember(url) {
        runCatching { Uri.parse(url).host ?: "jw.org" }.getOrElse { "jw.org" }
    }
    val popupModeEnabled by vm.webViewerPopupEnabled.collectAsState()
    Box(Modifier.fillMaxSize()) {
        Column(
            Modifier
                .fillMaxSize()
                // CRITICAL FIX: pad below the system status bar so the toolbar isn't
                // overlapping the notification area (the icons were unclickable
                // because they sat under the system clock + battery icons).
                .windowInsetsPadding(WindowInsets.statusBars)
        ) {
            WebPopupContents(
                vm = vm,
                urlInitial = url,
                host = hostNow,
                onClose = onClose,
                onPromote = onShrink,   // here "promote" means "shrink back to popup"
                allowPromote = popupModeEnabled,
                onOpenBookmarks = onOpenBookmarks,
                onOpenWebHistory = onOpenWebHistory,
                onOpenPdfHistory = onOpenPdfHistory,
                onOpenSettings = onOpenSettings,
                onOpenActivityLog = onOpenActivityLog,
                fullScreen = true
            )
        }
        // v5.4.85cc — "Article" FAB overlaid at bottom-end. Padded away
        // from the nav bar via WindowInsets so it never sits *under*
        // the gesture / three-button system UI. Extended-FAB variant
        // is used (icon + text) for maximum discoverability — the
        // whole point of this affordance is that the user doesn't
        // have to know which of the toolbar buttons up top means
        // "close and go back to my article".
        // v5.4.158cc — Press feedback (squish on tap).
        val returnFabInteraction = remember { MutableInteractionSource() }
        ExtendedFloatingActionButton(
            onClick = onReturnToArticle,
            icon = {
                androidx.compose.material3.Icon(
                    Icons.AutoMirrored.Filled.ArrowBack,
                    contentDescription = null
                )
            },
            text = { androidx.compose.material3.Text("Article") },
            interactionSource = returnFabInteraction,
            modifier = Modifier
                .align(Alignment.BottomEnd)
                .windowInsetsPadding(WindowInsets.navigationBars)
                .padding(16.dp)
                .fabPressScale(returnFabInteraction)
        )
    }
}


/**
 * v5.4.272cc — Global in-app floating WebViewer host.
 *
 * Each logical window owns a stable WebView session (`floating_popup_<id>`).
 * Moving, resizing, minimizing and maximizing only change Compose chrome; the
 * native WebView itself is never replaced, so history/scroll/JS state survive.
 * Multiple windows are supported by [AppViewModel.webPopupWindows].
 */
@Composable
fun FloatingWebViewerHost(
    vm: AppViewModel,
    onOpenBookmarks: () -> Unit = {},
    onOpenWebHistory: () -> Unit = {},
    onOpenPdfHistory: () -> Unit = {},
    onOpenSettings: () -> Unit = {},
    onOpenActivityLog: () -> Unit = {}
) {
    val windows = vm.webPopupWindows
    val allowMaximize by vm.webViewerFullScreenEnabled.collectAsState()
    BackHandler(enabled = windows.isNotEmpty()) {
        vm.handleFloatingWebBack()
    }

    BoxWithConstraints(Modifier.fillMaxSize()) {
        val screenW = maxWidth.value
        val screenH = maxHeight.value
        val density = androidx.compose.ui.platform.LocalDensity.current

        windows.forEachIndexed { index, window ->
            key(window.id) {
                val cascade = ((window.id - 1L) % 6L).toFloat() * 18f
                var x by remember(window.id) {
                    androidx.compose.runtime.mutableFloatStateOf((18f + cascade).coerceAtMost(screenW * 0.22f))
                }
                var y by remember(window.id) {
                    androidx.compose.runtime.mutableFloatStateOf((54f + cascade).coerceAtMost(screenH * 0.25f))
                }
                var width by remember(window.id) {
                    androidx.compose.runtime.mutableFloatStateOf((screenW * 0.90f).coerceAtLeast(280f).coerceAtMost(screenW))
                }
                var height by remember(window.id) {
                    androidx.compose.runtime.mutableFloatStateOf((screenH * 0.72f).coerceAtLeast(360f).coerceAtMost(screenH))
                }

                // Screen-size/configuration changes must never strand the window off-screen.
                LaunchedEffect(screenW, screenH, window.maximized, window.minimized) {
                    width = width.coerceIn(220f.coerceAtMost(screenW), screenW.coerceAtLeast(1f))
                    height = height.coerceIn(48f.coerceAtMost(screenH), screenH.coerceAtLeast(1f))
                    x = x.coerceIn(0f, (screenW - if (window.minimized) 220f.coerceAtMost(screenW) else width).coerceAtLeast(0f))
                    y = y.coerceIn(0f, (screenH - if (window.minimized) 48f.coerceAtMost(screenH) else height).coerceAtLeast(0f))
                }

                val sessionId = "floating_popup_${window.id}"
                val host = remember(window.url) {
                    runCatching { Uri.parse(window.url).host ?: "Web" }.getOrElse { "Web" }
                }

                if (window.minimized) {
                    val miniW = 220f.coerceAtMost(screenW)
                    val miniH = 48f.coerceAtMost(screenH)
                    androidx.compose.material3.Surface(
                        modifier = Modifier
                            .zIndex(index.toFloat() + 100f)
                            .offset {
                                IntOffset(
                                    with(density) { x.dp.roundToPx() },
                                    with(density) { y.dp.roundToPx() }
                                )
                            }
                            .size(miniW.dp, miniH.dp)
                            .pointerInput(window.id, screenW, screenH) {
                                detectDragGestures(
                                    onDragStart = { vm.bringWebPopupWindowToFront(window.id) }
                                ) { change, amount ->
                                    change.consume()
                                    val dx = with(density) { amount.x.toDp().value }
                                    val dy = with(density) { amount.y.toDp().value }
                                    x = (x + dx).coerceIn(0f, (screenW - miniW).coerceAtLeast(0f))
                                    y = (y + dy).coerceIn(0f, (screenH - miniH).coerceAtLeast(0f))
                                }
                            },
                        shape = RoundedCornerShape(18.dp),
                        tonalElevation = 10.dp,
                        shadowElevation = 12.dp
                    ) {
                        Row(
                            Modifier.fillMaxSize().padding(start = 12.dp, end = 4.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                "🌐 $host",
                                modifier = Modifier.weight(1f),
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis,
                                fontWeight = FontWeight.SemiBold,
                                fontSize = 12.sp
                            )
                            IconButton(onClick = { vm.setWebPopupWindowMinimized(window.id, false) }) {
                                Text("▣", fontWeight = FontWeight.Bold)
                            }
                            IconButton(onClick = { vm.closeWebPopupWindow(window.id) }) {
                                Icon(Icons.Default.Close, contentDescription = "Close popup")
                            }
                        }
                    }
                } else {
                    val popupModifier = if (window.maximized) {
                        Modifier
                            .fillMaxSize()
                            .windowInsetsPadding(WindowInsets.statusBars)
                            .windowInsetsPadding(WindowInsets.navigationBars)
                    } else {
                        Modifier
                            .offset {
                                IntOffset(
                                    with(density) { x.dp.roundToPx() },
                                    with(density) { y.dp.roundToPx() }
                                )
                            }
                            .size(width.dp, height.dp)
                    }

                    val windowShape = if (window.maximized) RoundedCornerShape(0.dp) else RoundedCornerShape(18.dp)
                    val windowBorder = if (window.maximized) null else BorderStroke(
                        5.dp,
                        Brush.linearGradient(
                            listOf(
                                MaterialTheme.colorScheme.primary,
                                MaterialTheme.colorScheme.tertiary,
                                MaterialTheme.colorScheme.secondary,
                                MaterialTheme.colorScheme.primary
                            )
                        )
                    )
                    androidx.compose.material3.Surface(
                        modifier = popupModifier.zIndex(index.toFloat() + 100f),
                        shape = windowShape,
                        border = windowBorder,
                        tonalElevation = if (window.maximized) 0.dp else 10.dp,
                        shadowElevation = if (window.maximized) 0.dp else 14.dp,
                        color = MaterialTheme.colorScheme.surface
                    ) {
                        Box(Modifier.fillMaxSize()) {
                        Column(Modifier.fillMaxSize()) {
                            // Draggable title bar. In maximized mode it remains as window
                            // controls but dragging is intentionally disabled.
                            Row(
                                Modifier
                                    .fillMaxWidth()
                                    .height(44.dp)
                                    .background(MaterialTheme.colorScheme.surfaceVariant)
                                    .pointerInput(window.id, window.maximized, screenW, screenH, width, height) {
                                        if (!window.maximized) {
                                            detectDragGestures(
                                                onDragStart = { vm.bringWebPopupWindowToFront(window.id) }
                                            ) { change, amount ->
                                                change.consume()
                                                val dx = with(density) { amount.x.toDp().value }
                                                val dy = with(density) { amount.y.toDp().value }
                                                x = (x + dx).coerceIn(0f, (screenW - width).coerceAtLeast(0f))
                                                y = (y + dy).coerceIn(0f, (screenH - height).coerceAtLeast(0f))
                                            }
                                        }
                                    }
                                    .padding(start = 12.dp, end = 4.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text(
                                    "🌐 $host",
                                    modifier = Modifier.weight(1f),
                                    maxLines = 1,
                                    overflow = TextOverflow.Ellipsis,
                                    fontWeight = FontWeight.SemiBold,
                                    fontSize = 12.sp
                                )
                                IconButton(onClick = { vm.setWebPopupWindowMinimized(window.id, true) }) {
                                    Text("—", fontWeight = FontWeight.Bold, fontSize = 18.sp)
                                }
                                IconButton(
                                    onClick = { vm.setWebPopupWindowMaximized(window.id, !window.maximized) },
                                    enabled = allowMaximize
                                ) {
                                    Text(if (window.maximized) "❐" else "□", fontWeight = FontWeight.Bold, fontSize = 18.sp)
                                }
                                IconButton(onClick = { vm.closeWebPopupWindow(window.id) }) {
                                    Icon(Icons.Default.Close, contentDescription = "Close popup")
                                }
                            }

                            WebPopupContents(
                                vm = vm,
                                urlInitial = window.url,
                                host = host,
                                onClose = { vm.closeWebPopupWindow(window.id) },
                                onPromote = { _, _ ->
                                    vm.setWebPopupWindowMaximized(window.id, !window.maximized)
                                },
                                sessionId = sessionId,
                                navigationRequestSerial = window.navigationSerial,
                                showModeControls = false,
                                onOpenBookmarks = {
                                    vm.setWebPopupWindowMinimized(window.id, true)
                                    onOpenBookmarks()
                                },
                                onOpenWebHistory = {
                                    vm.setWebPopupWindowMinimized(window.id, true)
                                    onOpenWebHistory()
                                },
                                onOpenPdfHistory = {
                                    vm.setWebPopupWindowMinimized(window.id, true)
                                    onOpenPdfHistory()
                                },
                                onOpenSettings = {
                                    vm.setWebPopupWindowMinimized(window.id, true)
                                    onOpenSettings()
                                },
                                onOpenActivityLog = {
                                    vm.setWebPopupWindowMinimized(window.id, true)
                                    onOpenActivityLog()
                                },
                                // Floating windows always let the shared WebView body
                                // consume the remaining resizable space; window.maximized
                                // changes only the outer surface dimensions.
                                fullScreen = true
                            )
                        }

                        // Bottom-right resize grip. The WebView stays mounted; only its
                        // parent surface dimensions change.
                        if (!window.maximized) {
                            Box(
                                Modifier
                                    .align(Alignment.BottomEnd)
                                    .size(30.dp)
                                    .background(MaterialTheme.colorScheme.primary.copy(alpha = 0.18f))
                                    .pointerInput(window.id, screenW, screenH, x, y) {
                                        detectDragGestures(
                                            onDragStart = { vm.bringWebPopupWindowToFront(window.id) }
                                        ) { change, amount ->
                                            change.consume()
                                            val dw = with(density) { amount.x.toDp().value }
                                            val dh = with(density) { amount.y.toDp().value }
                                            val minW = 280f.coerceAtMost(screenW)
                                            val minH = 320f.coerceAtMost(screenH)
                                            width = (width + dw).coerceIn(minW, (screenW - x).coerceAtLeast(minW))
                                            height = (height + dh).coerceIn(minH, (screenH - y).coerceAtLeast(minH))
                                        }
                                    },
                                contentAlignment = Alignment.Center
                            ) {
                                Text("↘", fontWeight = FontWeight.Bold, fontSize = 16.sp)
                            }
                        }
                        }
                    }
                }
            }
        }
    }
}

/**
 * Inner body: toolbar + WebView. Both popup and full-screen variants share this.
 * Declared as a ColumnScope extension so the `.weight(1f)` in full-screen mode compiles.
 */
@Composable
private fun ColumnScope.WebPopupContents(
    vm: AppViewModel,
    urlInitial: String,
    host: String,
    onClose: () -> Unit,
    onPromote: (url: String, label: String) -> Unit,
    sessionId: String = "popup",
    navigationRequestSerial: Long? = null,
    showModeControls: Boolean = true,
    allowPromote: Boolean = true,
    onOpenBookmarks: () -> Unit,
    // v4.12.0 — three new navigation callbacks needed to deliver feature parity
    // with the full-screen browser via the popup's new overflow menu.
    onOpenWebHistory: () -> Unit,
    onOpenPdfHistory: () -> Unit,
    onOpenSettings: () -> Unit,
    // v5.4.95cc — new menu entry for the activity log.
    onOpenActivityLog: () -> Unit,
    fullScreen: Boolean
) {
    val ctx = androidx.compose.ui.platform.LocalContext.current
    val scope = rememberCoroutineScope()  // v4.12.0 — for Save / Convert callbacks
    val zoom by vm.webPopupTextZoom.collectAsState()
    val dark by vm.webPopupDarkMode.collectAsState()
    // Hold a reference to the WebView so toolbar buttons can call into it
    var web by remember { androidx.compose.runtime.mutableStateOf<WebView?>(null) }
    // v5.4.297cc — Keep the popup/full-screen WebViewer feature-parity with
    // WebSearchScreen: detect HTML5 media and hand it to the shared player.
    var detectedMediaUrl by remember(sessionId) { mutableStateOf<String?>(null) }
    var detectedMediaType by remember(sessionId) { mutableStateOf<String?>(null) }

    fun detectPopupMedia(view: WebView?) {
        val w = view ?: return
        w.evaluateJavascript(
            "(function(){try{" +
                "var el=document.querySelector('video[src],video>source[src],audio[src],audio>source[src]');" +
                "if(!el)return '';" +
                "var src=el.tagName==='SOURCE'?el.src:(el.src||'');" +
                "if(!src||src.indexOf('blob:')===0)return '';" +
                "var kind=(el.tagName==='SOURCE'?el.parentElement.tagName:el.tagName).toLowerCase();" +
                "return kind+'|'+src;" +
                "}catch(e){return '';}})();",
        ) { result ->
            val decoded = runCatching { org.json.JSONTokener(result).nextValue() as? String }
                .getOrNull().orEmpty()
            if (decoded.contains('|')) {
                val parts = decoded.split('|', limit = 2)
                detectedMediaType = parts[0]
                detectedMediaUrl = parts[1]
            } else {
                detectedMediaType = null
                detectedMediaUrl = null
            }
        }
    }
    // v4.12.0 — overflow-menu open state
    var menuOpen by remember { androidx.compose.runtime.mutableStateOf(false) }
    // Editable URL bar state — kept in sync with the WebView via onPageStarted/onPageFinished
    var addressText by remember { androidx.compose.runtime.mutableStateOf(urlInitial) }
    var addressFocused by remember { androidx.compose.runtime.mutableStateOf(false) }
    var canGoBack by remember { androidx.compose.runtime.mutableStateOf(false) }
    var canGoForward by remember { androidx.compose.runtime.mutableStateOf(false) }
    val keyboard = androidx.compose.ui.platform.LocalSoftwareKeyboardController.current

    // v4.2 — popup long-press link sheet state. Declared at function scope so
    // both the AndroidView's onLinkLongPress callback (inside the nested Box)
    // AND the ModalBottomSheet rendered later in this composable can see it.
    // Previously this lived inside the Box scope and the sheet rendering
    // failed to compile because the variable was out of scope.
    var popupLinkLongPress by remember {
        androidx.compose.runtime.mutableStateOf<Pair<String, String>?>(null)
    }

    fun submitAddress() {
        val raw = addressText.trim()
        if (raw.isEmpty()) return
        val target = when {
            raw.startsWith("http://") || raw.startsWith("https://") -> raw
            raw.contains(".") -> "https://$raw"
            else -> "https://www.jw.org/en/search/?q=" + Uri.encode(raw)
        }
        if (!isJwHostUri(Uri.parse(target))) {
            android.widget.Toast.makeText(
                ctx, "Only jw.org family of sites are allowed",
                android.widget.Toast.LENGTH_SHORT
            ).show()
            return
        }
        keyboard?.hide()
        web?.loadUrl(target)
        addressFocused = false
    }

    // Track bookmark state for the URL currently shown in the popup.
    // Re-checked whenever the URL changes (after navigation, fullscreen toggle, etc).
    var isBookmarked by remember { mutableStateOf(false) }
    var currentUrl by remember { mutableStateOf(urlInitial) }
    var currentTitle by remember { mutableStateOf("") }
    var relatedVideos by remember(sessionId) { mutableStateOf<List<com.tebogo.markvault.data.RelatedVideoMatch>>(emptyList()) }
    var showRelatedVideos by remember(sessionId) { mutableStateOf(false) }
    var relatedVideoPopup by remember(sessionId) { mutableStateOf<MediaItem?>(null) }
    LaunchedEffect(currentTitle, currentUrl) {
        if (currentTitle.isBlank()) { relatedVideos = emptyList(); return@LaunchedEffect }
        relatedVideos = vm.findRelatedVideos(currentTitle, currentUrl, includeOnline = false)
        relatedVideos = vm.findRelatedVideos(currentTitle, currentUrl, includeOnline = true)
    }
    LaunchedEffect(currentUrl) {
        isBookmarked = if (currentUrl.isBlank()) false
        else vm.isBookmarked(currentUrl)
    }

    // Toolbar — Row 1: action buttons (refresh, external link, A-, A+, fullscreen, close)
    Row(
        Modifier.fillMaxWidth().padding(start = 14.dp, end = 0.dp, top = 4.dp, bottom = 0.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(
            "\uD83C\uDF10  $host", fontWeight = FontWeight.SemiBold, fontSize = 13.sp,
            modifier = Modifier.weight(1f), maxLines = 1, overflow = TextOverflow.Ellipsis,
            color = MaterialTheme.colorScheme.onSurfaceVariant
        )
        if (relatedVideos.isNotEmpty()) {
            IconButton(onClick = { showRelatedVideos = true }) { Text("🎬", fontSize = 17.sp) }
        }
        // Refresh the current page in the popup
        IconButton(onClick = { web?.reload() }) {
            Icon(Icons.Default.Refresh, contentDescription = "Refresh")
        }
        // ★ Save as favourite — toggles bookmark for the current URL
        IconButton(onClick = {
            val u = web?.url ?: currentUrl
            val t = web?.title ?: host
            if (isBookmarked) vm.removeBookmark(u) else vm.addBookmark(u, t)
            isBookmarked = !isBookmarked
        }) {
            Text(
                if (isBookmarked) "\u2605" else "\u2606",
                fontSize = 20.sp,
                color = if (isBookmarked) androidx.compose.ui.graphics.Color(0xFFFFC107)
                else MaterialTheme.colorScheme.onSurface
            )
        }
        // Text zoom A− / A+
        TextButton(
            onClick = { vm.setWebPopupTextZoom(zoom - 10) },
            contentPadding = PaddingValues(horizontal = 6.dp)
        ) { Text("A\u2212", fontSize = 13.sp) }
        TextButton(
            onClick = { vm.setWebPopupTextZoom(zoom + 10) },
            contentPadding = PaddingValues(horizontal = 6.dp)
        ) { Text("A+", fontSize = 13.sp) }
        // Toggle between popup and full-screen, preserving state. Floating
        // windows own this control in their draggable title bar, so they hide
        // the duplicate toolbar button while keeping the same WebView engine.
        if (showModeControls && allowPromote) {
            IconButton(onClick = {
                val w = web
                if (w != null) {
                    val bundle = android.os.Bundle()
                    w.saveState(bundle)
                    vm.webStateBundle = bundle
                }
                val u = w?.url ?: urlInitial
                onPromote(u, host)
            }) {
                Text(
                    if (fullScreen) "\u2924" else "\u2922",
                    fontSize = 16.sp,
                    fontWeight = FontWeight.Bold
                )
            }
        }
        // v4.4.3 — Home button in popup too so the toolbar matches the rest
        // of the app. Closes the popup AND pops back to home.
        IconButton(onClick = {
            onClose()
            // popBackStack happens via the parent host on the next compose.
        }) {
            Text("\uD83C\uDFE0", fontSize = 16.sp)
        }
        if (showModeControls) {
            IconButton(onClick = onClose) {
                Icon(Icons.Default.Close, contentDescription = "Close")
            }
        }
        // ── v4.12.0 — Overflow menu ────────────────────────────────────────
        // Brings popup feature-parity with the full-screen browser without
        // bloating the visible toolbar. Items match WebSearchScreen's menu
        // exactly so the experience is identical regardless of which mode
        // you're in. Also brings back External-browser, Bookmarks-list, and
        // Dark-mode toggle which were removed from the visible row to
        // declutter (per the user's "less cluttered, more features" ask).
        Box {
            IconButton(onClick = { menuOpen = true }) {
                Icon(Icons.Default.MoreVert, contentDescription = "More")
            }
            DropdownMenu(
                modifier = Modifier.fourDMenuChrome(),
                expanded = menuOpen,
                onDismissRequest = { menuOpen = false }
            ) {
                DropdownMenuItem(
                    text = { Text("\uD83C\uDFE0 jw.org home") },
                    onClick = {
                        menuOpen = false
                        web?.loadUrl("https://www.jw.org/en/")
                    }
                )
                DropdownMenuItem(
                    text = { Text(if (dark) "\u263C Light mode" else "\uD83C\uDF19 Dark mode") },
                    onClick = {
                        menuOpen = false
                        vm.setWebPopupDarkMode(!dark)
                    }
                )
                DropdownMenuItem(
                    text = { Text("\u2197 Open in external browser") },
                    onClick = {
                        menuOpen = false
                        val target = web?.url ?: urlInitial
                        runCatching {
                            val intent = android.content.Intent(
                                android.content.Intent.ACTION_VIEW, Uri.parse(target)
                            ).addFlags(android.content.Intent.FLAG_ACTIVITY_NEW_TASK)
                            ctx.startActivity(intent)
                        }
                    }
                )
                HorizontalDivider()
                DropdownMenuItem(
                    text = { Text("\uD83D\uDD16 Bookmarks") },
                    onClick = { menuOpen = false; onOpenBookmarks() }
                )
                DropdownMenuItem(
                    text = { Text("\uD83D\uDD52 Web history") },
                    onClick = { menuOpen = false; onOpenWebHistory() }
                )
                DropdownMenuItem(
                    text = { Text("\uD83D\uDCDC PDF history") },
                    onClick = { menuOpen = false; onOpenPdfHistory() }
                )
                HorizontalDivider()
                // v4.12.0 — Save the current page as an offline HTML note in
                // the library. Same logic as the full-screen browser, just
                // invoked from inside the popup. Toast feedback fires even
                // after popup dismissal, so it's safe to close on success.
                DropdownMenuItem(
                    text = { Text("\uD83D\uDCBE Save as Offline HTML") },
                    onClick = {
                        menuOpen = false
                        val w = web ?: return@DropdownMenuItem
                        val srcUrl = w.url ?: urlInitial
                        val title = w.title?.takeIf { it.isNotBlank() } ?: host
                        w.evaluateJavascript(
                            "(function(){return document.documentElement.outerHTML;})();"
                        ) { jsonHtml ->
                            val html = decodeJsSelectionPublic(jsonHtml)
                            if (html.isBlank()) {
                                android.widget.Toast.makeText(
                                    ctx, "Couldn't capture the page HTML.",
                                    android.widget.Toast.LENGTH_SHORT
                                ).show()
                                return@evaluateJavascript
                            }
                            scope.launch {
                                val res = vm.saveOfflineHtmlPage(srcUrl, title, html)
                                val msg = when (res) {
                                    is com.tebogo.markvault.SaveResult.Ok -> {
                                        val relPath = if (res.subfolder.isBlank()) res.fileName
                                            else "${res.subfolder}/${res.fileName}"
                                        vm.indexNewFile(res.docUri, relPath)
                                        "\uD83D\uDCBE Saved & indexed: ${res.fileName}"
                                    }
                                    is com.tebogo.markvault.SaveResult.Error -> "\u26A0\uFE0F ${res.message}"
                                }
                                android.widget.Toast.makeText(
                                    ctx, msg, android.widget.Toast.LENGTH_LONG
                                ).show()
                            }
                        }
                    }
                )
                DropdownMenuItem(
                    text = { Text("\uD83D\uDCDD Convert to Markdown") },
                    onClick = {
                        menuOpen = false
                        val w = web ?: return@DropdownMenuItem
                        val srcUrl = w.url ?: urlInitial
                        val title = w.title?.takeIf { it.isNotBlank() } ?: host
                        w.evaluateJavascript(
                            "(function(){return document.documentElement.outerHTML;})();"
                        ) { jsonHtml ->
                            val html = decodeJsSelectionPublic(jsonHtml)
                            scope.launch {
                                val res = vm.saveConvertedMarkdown(srcUrl, title, html)
                                val msg = when (res) {
                                    is com.tebogo.markvault.SaveResult.Ok -> {
                                        val relPath = if (res.subfolder.isBlank()) res.fileName
                                            else "${res.subfolder}/${res.fileName}"
                                        vm.indexNewFile(res.docUri, relPath)
                                        "\uD83D\uDCDD Saved & indexed: ${res.fileName}"
                                    }
                                    is com.tebogo.markvault.SaveResult.Error -> "\u26A0\uFE0F ${res.message}"
                                }
                                android.widget.Toast.makeText(
                                    ctx, msg, android.widget.Toast.LENGTH_LONG
                                ).show()
                            }
                        }
                    }
                )
                HorizontalDivider()
                // v5.4.88cc — Multi-select toggle + clear. When enabled,
                // long-pressing links no longer opens the per-link action
                // sheet; instead each link is marked (green outline) and
                // added to the batch-save basket handled by the
                // WebSelectionFab overlay.
                SelectionMenuItems(
                    vm = vm,
                    webViewProvider = { web },
                    onAfterAction = { menuOpen = false }
                )
                HorizontalDivider()
                // v5.4.95cc — Activity log entry. Sits above Settings
                // because that's where every "article saved" event
                // lands — the user opens it to see which pages they
                // saved from this WebViewer session (and every prior
                // one, including batch saves).
                DropdownMenuItem(
                    text = { Text("\uD83D\uDCCB Activity log") },
                    onClick = { menuOpen = false; onOpenActivityLog() }
                )
                DropdownMenuItem(
                    text = { Text("\u2699\uFE0F Settings") },
                    onClick = { menuOpen = false; onOpenSettings() }
                )
            }
        }
    }

    if (showRelatedVideos) {
        RelatedVideosCarousel(
            vm, relatedVideos,
            onClose = { showRelatedVideos = false },
            onPlayVideo = { match ->
                vm.playMedia(match.item)
                relatedVideoPopup = match.item
            }
        )
    }

    relatedVideoPopup?.let { media ->
        FloatingMediaPopup(
            vm = vm, title = media.title, url = media.streamUrl, mediaType = media.mediaType,
            onDismiss = { relatedVideoPopup = null }
        )
    }

    // Toolbar — Row 2: back / forward + editable URL field. Gives the popup
    // a real-browser feel; user can navigate within jw.org without leaving the popup.
    Row(
        Modifier.fillMaxWidth().padding(horizontal = 8.dp, vertical = 4.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        IconButton(
            onClick = {
                val w = web
                if (w?.canGoBack() == true) w.goBack() else onClose()
            },
            modifier = Modifier.size(32.dp)
        ) {
            Icon(
                Icons.AutoMirrored.Filled.KeyboardArrowLeft,
                contentDescription = if (canGoBack) "Back" else "Close popup",
                tint = MaterialTheme.colorScheme.onSurface
            )
        }
        IconButton(
            onClick = { web?.goForward() },
            enabled = canGoForward,
            modifier = Modifier.size(32.dp)
        ) {
            Icon(Icons.AutoMirrored.Filled.KeyboardArrowRight,
                contentDescription = "Forward",
                tint = if (canGoForward) MaterialTheme.colorScheme.onSurface
                else MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.4f))
        }
        androidx.compose.material3.OutlinedTextField(
            value = addressText,
            onValueChange = { addressText = it },
            singleLine = true,
            modifier = Modifier.weight(1f).height(54.dp),
            placeholder = { Text("URL or search\u2026", fontSize = 14.sp) },
            textStyle = androidx.compose.ui.text.TextStyle(
                fontSize = 14.sp,
                fontWeight = FontWeight.Medium
            ),
            keyboardOptions = androidx.compose.foundation.text.KeyboardOptions(
                imeAction = androidx.compose.ui.text.input.ImeAction.Go
            ),
            keyboardActions = androidx.compose.foundation.text.KeyboardActions(
                onGo = { submitAddress() }
            ),
            shape = androidx.compose.foundation.shape.RoundedCornerShape(22.dp),
            colors = androidx.compose.material3.TextFieldDefaults.colors(
                focusedContainerColor = MaterialTheme.colorScheme.surface,
                unfocusedContainerColor = MaterialTheme.colorScheme.surface
            )
        )
    }

    // v4.13.0 — Pause/resume the persistent popup WebView with the
    // Composable's lifecycle. When the popup mounts (sheet opened or
    // promoted) we resume; when it unmounts (sheet dismissed, mode toggled)
    // we pause. Keeps JS timers and other background work from running
    // while the WebView isn't visible.
    androidx.compose.runtime.DisposableEffect(sessionId) {
        val w = vm.getOrCreateWebViewSession(sessionId, ctx)
        runCatching { w.onResume() }
        onDispose {
            // Detach from current parent so the next mount can re-attach
            // cleanly to a different ViewGroup (sheet ↔ full-screen).
            (w.parent as? android.view.ViewGroup)?.removeView(w)
            runCatching { w.onPause() }
        }
    }

    // WebView host. In popup mode, constrain height; in full-screen mode, fill the parent.
    val webBoxModifier = if (fullScreen)
        Modifier.fillMaxWidth().weight(1f)
    else
        Modifier.fillMaxWidth().heightIn(min = 360.dp, max = 720.dp)

    // JW pages often attach their media element after onPageFinished. Re-check
    // briefly after navigation, exactly as the full WebViewer does.
    LaunchedEffect(addressText, web) {
        detectedMediaUrl = null
        detectedMediaType = null
        repeat(6) {
            kotlinx.coroutines.delay(1500L)
            detectPopupMedia(web)
            if (detectedMediaUrl != null) return@LaunchedEffect
        }
    }

    Box(webBoxModifier) {
        AndroidView(
            modifier = Modifier.fillMaxSize(),
            factory = { c ->
                val w = createPopupWebView(
                    c, vm, dark, zoom, urlInitial, sessionId, navigationRequestSerial,
                    onWebReady = { web = it },
                    onNavState = { u, title, back, fwd ->
                        if (!addressFocused && u.isNotEmpty()) addressText = u
                        canGoBack = back
                        canGoForward = fwd
                        // Update currentUrl so bookmark state stays in sync as the
                        // user navigates inside the popup. This callback runs in
                        // WebPopupContents' scope, so `currentUrl` is visible here
                        // (unlike inside createPopupWebView).
                        if (u.isNotEmpty()) currentUrl = u
                        if (title.isNotBlank()) currentTitle = title
                    },
                    onSearchInMarkVault = { text ->
                        // Push the selection through the VM's pending-query channel;
                        // the Search screen consumes it on next entry.
                        vm.requestPendingSearch(text)
                        // Close the popup so the navigation host can show Search.
                        // Direct nav-to-Search would need a NavController which we
                        // don't have here — MainActivity observes pendingSearch.
                        onClose()
                    },
                    onSearchInWol = { text ->
                        val target = "https://wol.jw.org/en/wol/s/r1/lp-e?q=" +
                            java.net.URLEncoder.encode(text, "UTF-8")
                        // Load directly in this same popup — no need to dismiss.
                        web?.loadUrl(target)
                    },
                    // v4.12.0 — two new selection-menu actions also wired here
                    // so popup ↔ full-screen have the same menu vocabulary.
                    onSearchInJwOrg = { text ->
                        val target = "https://www.jw.org/en/search/?q=" +
                            java.net.URLEncoder.encode(text, "UTF-8")
                        web?.loadUrl(target)
                    },
                    // onShare left null → SelectionWebView falls back to
                    // ACTION_SEND, which produces the system share sheet.
                    onLinkLongPress = { url, text ->
                        // v5.4.88cc — Selection-mode branch. When the
                        // user has toggled "🎯 Enable selection mode" on,
                        // long-pressing a link toggles it in/out of the
                        // batch-save basket and paints (or clears) the
                        // green outline via JS, instead of surfacing the
                        // usual per-link action sheet. Normal behaviour
                        // returns as soon as selection mode is off.
                        //
                        // v5.4.99cc — Multi Selection Mode takes
                        // priority. Instead of adding ONE URL, the
                        // long-pressed link is treated as a "head" —
                        // enqueued for background page-load + body-link
                        // extraction (see HiddenHeadExpander in
                        // MultiSelectionExpander.kt). The head itself
                        // gets the green outline immediately so the
                        // user knows their long-press was accepted
                        // even while the expansion is still fetching.
                        if (vm.webMultiSelectionMode.value) {
                            vm.enqueueHeadExpansion(url, text)
                            web?.let { webViewHighlightUrl(it, url, true) }
                        } else if (vm.webSelectionMode.value) {
                            val added = vm.toggleWebSelection(url, text)
                            web?.let { webViewHighlightUrl(it, url, added) }
                        } else {
                            popupLinkLongPress = url to text
                        }
                    }
                )
                // v4.13.0 — Critical for persistent WebView: detach from any
                // prior parent (e.g., the previous mode's container) before
                // AndroidView attaches this view to the new ViewGroup.
                // Without this, Android throws "View already has a parent".
                (w.parent as? android.view.ViewGroup)?.removeView(w)
                w
            },
            update = { w ->
                // Apply zoom changes when textZoom state changes.
                w.settings.textZoom = zoom
                // Reuse-one-popup mode can change urlInitial while this exact
                // WebView stays mounted. A navigation serial changes only for a
                // NEW link request, never for resize/minimize/maximize/remount or
                // server redirects, so those presentation changes cannot reload it.
                if (navigationRequestSerial != null && urlInitial.isNotBlank() &&
                    vm.shouldHandleWebViewNavigationSerial(sessionId, navigationRequestSerial)
                ) {
                    w.loadUrl(urlInitial)
                }
                // Re-apply the dark overlay LIVE on every recomposition so toggling
                // the moon button takes effect immediately (no page reload needed).
                if (dark) w.evaluateJavascript(POPUP_DARK_OVERLAY_JS, null)
                else w.evaluateJavascript(POPUP_REMOVE_OVERLAY_JS, null)
            }
        )
        // v5.4.297cc — Same Play in App hand-off in floating and promoted
        // WebViewer modes. Pause the page first so two audio streams can never
        // play at once, then use MarkVault's existing shared PlaybackService.
        detectedMediaUrl?.let { mediaUrl ->
            ExtendedFloatingActionButton(
                onClick = {
                    val title = web?.title?.takeIf { it.isNotBlank() } ?: currentTitle.ifBlank { "Web media" }
                    web?.evaluateJavascript(
                        "(function(){try{var m=document.querySelector('video,audio');" +
                            "if(!m)return 0;var t=m.currentTime||0;m.pause();return Math.round(t*1000);" +
                            "}catch(e){return 0;}})();"
                    ) { raw ->
                        val startMs = raw.trim().trim('\"').toDoubleOrNull()?.toLong() ?: 0L
                        vm.playWebMedia(
                            MediaItem(title = title, streamUrl = mediaUrl, mediaType = detectedMediaType ?: "video"),
                            startMs
                        )
                    }
                    // Keep the WebViewer available; playback immediately moves to
                    // the persistent built-in player/mini-player and can be expanded.
                },
                containerColor = MaterialTheme.colorScheme.primary,
                contentColor = MaterialTheme.colorScheme.onPrimary,
                modifier = Modifier.align(Alignment.BottomEnd).padding(end = 12.dp, bottom = 82.dp)
            ) {
                Text(if (detectedMediaType == "audio") "🔊" else "▶", fontSize = 16.sp)
                Spacer(Modifier.width(6.dp))
                Text("Play in App", fontWeight = FontWeight.SemiBold, fontSize = 13.sp)
            }
        }
        // v5.4.88cc — Multi-selection FAB. Only visible while
        // selection mode is on; shows either "Long-press links to select"
        // (empty basket), "Save N articles" (basket non-empty), or a
        // "Saving x/y…" pill while the batch fetch runs. When mode is off,
        // the composable emits nothing so the WebView is unobstructed.
        WebSelectionFab(
            vm = vm,
            modifier = Modifier
                .align(Alignment.BottomStart)
                .selectionFabPlacement()
        )
        // v5.4.93cc — "This article isn't saved" prompt, bottom-center
        // above the nav bar. Emits nothing while in selection mode, on
        // blank / dismissed / already-saved URLs, or on non-article
        // pages (listings, search results).
        SavePromptBar(
            vm = vm,
            webViewProvider = { web },
            currentUrlProvider = { currentUrl },
            currentTitleProvider = { currentTitle.ifBlank { web?.title.orEmpty() } },
            modifier = Modifier
                .align(Alignment.BottomCenter)
                .selectionFabPlacement()
        )
        // v5.4.90cc — HiddenBatchSaver moved to MainActivity level so it
        // survives multitasking between screens inside MarkVault.
    }

    // In popup mode reserve a small bottom inset for the drag handle area
    if (!fullScreen) Spacer(Modifier.height(8.dp))

    // v4.2 — bottom-of-popup action sheet shown when the user long-presses a
    // link in the popup's WebView. Mirrors the markdown-reader experience:
    // Open externally / Copy / Search in wol.jw.org.
    //
    // NOTE: we intentionally avoid the `(longUrl, longText) ->` destructuring
    // form here. Kotlin can't always pick between the Pair component2() and
    // various Array/List component2() extensions on the call site, which made
    // the previous compile fail. Explicit .first / .second is unambiguous.
    val pendingLongPress = popupLinkLongPress
    if (pendingLongPress != null) {
        val longUrl = pendingLongPress.first
        val longText = pendingLongPress.second
        ModalBottomSheet(onDismissRequest = { popupLinkLongPress = null }) {
            Column(Modifier.fillMaxWidth().padding(horizontal = 18.dp, vertical = 8.dp)) {
                Text(
                    longText.ifBlank { longUrl },
                    fontSize = 14.sp,
                    fontWeight = FontWeight.SemiBold,
                    maxLines = 2,
                    overflow = TextOverflow.Ellipsis
                )
                Text(
                    longUrl,
                    fontSize = 11.sp,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis,
                    modifier = Modifier.padding(top = 2.dp)
                )
                Spacer(Modifier.height(10.dp))
                androidx.compose.material3.TextButton(
                    onClick = {
                        web?.loadUrl(longUrl)
                        popupLinkLongPress = null
                    },
                    modifier = Modifier.fillMaxWidth()
                ) { Text("\uD83D\uDD17  Open in this popup") }
                androidx.compose.material3.TextButton(
                    onClick = {
                        runCatching {
                            val clip = ctx.getSystemService(android.content.Context.CLIPBOARD_SERVICE)
                                as? android.content.ClipboardManager
                            clip?.setPrimaryClip(android.content.ClipData.newPlainText("url", longUrl))
                        }
                        popupLinkLongPress = null
                    },
                    modifier = Modifier.fillMaxWidth()
                ) { Text("\uD83D\uDCCB  Copy link") }
                androidx.compose.material3.TextButton(
                    onClick = {
                        runCatching {
                            ctx.startActivity(
                                android.content.Intent(
                                    android.content.Intent.ACTION_VIEW,
                                    Uri.parse(longUrl)
                                ).addFlags(android.content.Intent.FLAG_ACTIVITY_NEW_TASK)
                            )
                        }
                        popupLinkLongPress = null
                    },
                    modifier = Modifier.fillMaxWidth()
                ) { Text("\uD83C\uDF10  Open in system browser") }
                androidx.compose.material3.TextButton(
                    onClick = {
                        val q = if (longText.length > 1) longText else longUrl
                        val target = "https://wol.jw.org/en/wol/s/r1/lp-e?q=" +
                            java.net.URLEncoder.encode(q, "UTF-8")
                        web?.loadUrl(target)
                        popupLinkLongPress = null
                    },
                    modifier = Modifier.fillMaxWidth()
                ) { Text("\uD83D\uDD0D  Search in wol.jw.org") }
                Spacer(Modifier.height(16.dp))
            }
        }
    }
}

/**
 * Build the WebView with all our custom settings, the touch-pass-through that fixes the
 * bottom-sheet scroll bug, and state restoration where available.
 */
private fun createPopupWebView(
    c: Context,
    vm: AppViewModel,
    dark: Boolean,
    zoom: Int,
    urlInitial: String,
    sessionId: String = "popup",
    navigationRequestSerial: Long? = null,
    onWebReady: (WebView) -> Unit,
    onNavState: ((url: String, title: String, canBack: Boolean, canFwd: Boolean) -> Unit)? = null,
    // v4.2 — text-selection menu callbacks (Search in MarkVault / Search in wol.jw.org)
    onSearchInMarkVault: ((String) -> Unit)? = null,
    onSearchInWol: ((String) -> Unit)? = null,
    // v4.12.0 — two extra selection-menu callbacks (Search jw.org / Share)
    onSearchInJwOrg: ((String) -> Unit)? = null,
    onShare: ((String) -> Unit)? = null,
    // v4.2 — long-press link callback (forwards URL + text to caller)
    onLinkLongPress: ((url: String, text: String) -> Unit)? = null
): WebView {
    // v4.13.0 — Persistent WebView for the popup session. Same WebView
    // instance for sheet and promoted full-screen, so scroll position, form
    // inputs, and JavaScript state survive transitions. The boolean
    // [needsFirstConfig] flag below catches the genuinely-first-time case so
    // we apply settings + load URL only once.
    val webView = vm.getOrCreateWebViewSession(sessionId, c)
    val needsFirstConfig = webView.webViewClient == null ||
        webView.url.isNullOrBlank()

    return webView.apply {
        // ── Selection-menu callbacks ────────────────────────────────────────
        // Re-wired on every mount because the lambdas close over the current
        // Composable's vm / nav references, which can go stale across
        // navigation.
        this.onSearchInMarkVault = onSearchInMarkVault
        this.onSearchInWol = onSearchInWol
        this.onSearchInJwOrg = onSearchInJwOrg
        this.onShare = onShare

        // v5.4.93cc — Drag-select handler. Once a long-press has entered
        // selection mode and drag-select is armed, each new anchor the
        // finger crosses fires this callback. It reuses the same
        // toggle-and-highlight path as the long-press to keep behaviour
        // identical across "tap-each" and "swipe" input styles.
        //
        // v5.4.99cc — Multi Mode branch added. While the user is
        // sweeping across a list, each new anchor is enqueued as a
        // head expansion (so the user can grab, say, six monthly
        // listings by long-press-and-drag down a page).
        val selfWebView = this
        this.onDragSelectAnchor = { href, text ->
            if (href.isNotBlank()) {
                if (vm.webMultiSelectionMode.value) {
                    vm.enqueueHeadExpansion(href, text)
                    webViewHighlightUrl(selfWebView, href, true)
                } else if (vm.webSelectionMode.value) {
                    val added = vm.toggleWebSelection(href, text)
                    webViewHighlightUrl(selfWebView, href, added)
                }
            }
        }

        // ── Long-press link handler ────────────────────────────────────────
        // Same reasoning: closes over the popupLinkLongPress state hosted in
        // the Composable, must re-wire.
        setOnLongClickListener {
            val hit = hitTestResult
            val type = hit.type
            val isAnchor = type == WebView.HitTestResult.SRC_ANCHOR_TYPE ||
                type == WebView.HitTestResult.SRC_IMAGE_ANCHOR_TYPE
            if (isAnchor && onLinkLongPress != null) {
                // v5.4.91cc — HitTestResult.getExtra() returns the IMAGE
                // src for SRC_IMAGE_ANCHOR_TYPE, not the enclosing anchor
                // href. Use resolveAnchorAtLastTouch to bounce through
                // document.elementFromPoint and get the real anchor URL
                // + text. Falls back to hit.extra ONLY if the JS lookup
                // returns nothing (which shouldn't happen for a genuine
                // anchor long-press but keeps the old behaviour on
                // exotic pages just in case).
                resolveAnchorAtLastTouch { resolvedHref, resolvedText ->
                    val href = resolvedHref.ifBlank { hit.extra ?: "" }
                    if (href.isBlank()) return@resolveAnchorAtLastTouch
                    onLinkLongPress.invoke(href, resolvedText)
                    // v5.4.93cc — If the caller entered selection mode as
                    // part of handling this long-press, arm drag-select
                    // so the user can glide across subsequent cards
                    // without lifting a finger.
                    // v5.4.99cc — Also arm in Multi Selection Mode so
                    // the same swipe-across-heads gesture works there.
                    if (vm.webSelectionMode.value ||
                        vm.webMultiSelectionMode.value
                    ) {
                        enableDragSelectForCurrentPress()
                    }
                }
                return@setOnLongClickListener true
            }
            false
        }

        // ── Touch interception fix for the bottom-sheet host ────────────────
        // Re-wired every time because the parent ViewGroup is different in
        // bottom-sheet host vs full-screen host.
        setOnTouchListener { v, ev ->
            when (ev.actionMasked) {
                MotionEvent.ACTION_DOWN,
                MotionEvent.ACTION_MOVE,
                MotionEvent.ACTION_POINTER_DOWN ->
                    v.parent?.requestDisallowInterceptTouchEvent(true)
                MotionEvent.ACTION_UP,
                MotionEvent.ACTION_CANCEL ->
                    v.parent?.requestDisallowInterceptTouchEvent(false)
            }
            false  // never consume — let the WebView handle the gesture itself
        }

        // ── webViewClient — re-wired every mount because it captures `c`
        // (Context) and `vm` references that change across navigation.
        webViewClient = object : WebViewClient() {
            override fun shouldOverrideUrlLoading(
                view: WebView?, request: WebResourceRequest?
            ): Boolean {
                val u = request?.url ?: return false
                if (isJwHostUri(u)) return false
                runCatching {
                    val intent = android.content.Intent(android.content.Intent.ACTION_VIEW, u)
                        .addFlags(android.content.Intent.FLAG_ACTIVITY_NEW_TASK)
                    c.startActivity(intent)
                }
                return true
            }

            override fun onPageStarted(
                view: WebView?, url: String?, favicon: android.graphics.Bitmap?
            ) {
                onNavState?.invoke(
                    url ?: "", view?.title ?: "",
                    view?.canGoBack() == true, view?.canGoForward() == true
                )
            }

            override fun onPageFinished(view: WebView?, url: String?) {
                view?.evaluateJavascript(LINK_TAP_HIGHLIGHT_JS, null)
                if (dark) {
                    view?.evaluateJavascript(POPUP_DARK_OVERLAY_JS, null)
                } else {
                    view?.evaluateJavascript(POPUP_REMOVE_OVERLAY_JS, null)
                }
                // v5.4.88cc — Re-inject selection-mode CSS + repaint
                // highlights for any previously picked cards that also
                // appear on this newly-loaded page. No-op when selection
                // mode is off, so cost is one boolean read.
                if (view != null) applySelectionOnLoad(view, vm)
                onNavState?.invoke(
                    url ?: "", view?.title ?: "",
                    view?.canGoBack() == true, view?.canGoForward() == true
                )
                if (!url.isNullOrBlank()) {
                    vm.recordWebVisit(url, view?.title ?: url)
                }
            }

            override fun onRenderProcessGone(
                view: WebView?,
                detail: android.webkit.RenderProcessGoneDetail?
            ): Boolean {
                // v4.13.0 — if the persistent popup WebView's renderer dies,
                // drop it from the pool so the next mount creates a fresh one.
                runCatching { vm.destroyWebViewSession(sessionId) }
                return true
            }
        }

        // Apply the live zoom on every mount (cheap; the user may have
        // changed it since the last mount).
        settings.textZoom = zoom

        // ── One-time configuration for a brand-new WebView ────────────────
        if (needsFirstConfig) {
            // Keep floating and full-screen WebViewer on the same rendering
            // configuration.  jw.org's Study Bible is JavaScript-heavy and
            // may use auxiliary window/navigation APIs while constructing the
            // scripture pane, so a reduced popup configuration can leave the
            // site chrome visible while the scripture body never mounts.
            layoutParams = android.view.ViewGroup.LayoutParams(
                android.view.ViewGroup.LayoutParams.MATCH_PARENT,
                android.view.ViewGroup.LayoutParams.MATCH_PARENT
            )
            settings.javaScriptEnabled = true
            settings.domStorageEnabled = true
            settings.databaseEnabled = true
            settings.allowFileAccess = false
            settings.allowContentAccess = true
            settings.loadsImagesAutomatically = true
            settings.setSupportZoom(true)
            settings.builtInZoomControls = true
            settings.displayZoomControls = false
            settings.useWideViewPort = true
            settings.loadWithOverviewMode = true
            settings.mediaPlaybackRequiresUserGesture = true
            settings.setSupportMultipleWindows(true)
            settings.javaScriptCanOpenWindowsAutomatically = true
            settings.mixedContentMode = WebSettings.MIXED_CONTENT_COMPATIBILITY_MODE
            settings.userAgentString = settings.userAgentString + " MarkVault/3.7"

            // Match the full-screen viewer's WebChromeClient support.  Keep
            // target=_blank/window.open navigation inside this SAME popup
            // session so scripture navigation does not create a second engine.
            webChromeClient = object : android.webkit.WebChromeClient() {
                override fun onCreateWindow(
                    view: WebView?, isDialog: Boolean, isUserGesture: Boolean,
                    resultMsg: android.os.Message?
                ): Boolean {
                    if (resultMsg == null || view == null) return false
                    val transport = resultMsg.obj as? WebView.WebViewTransport ?: return false
                    val temp = WebView(view.context).apply {
                        webViewClient = object : WebViewClient() {
                            override fun shouldOverrideUrlLoading(
                                v: WebView?, request: WebResourceRequest?
                            ): Boolean {
                                val target = request?.url
                                if (target != null && isJwHostUri(target)) {
                                    // Route to the persistent popup, not the
                                    // temporary transport WebView.
                                    webView.loadUrl(target.toString())
                                }
                                v?.destroy()
                                return true
                            }
                        }
                    }
                    transport.webView = temp
                    resultMsg.sendToTarget()
                    return true
                }
            }
        }

        // ── URL loading policy ─────────────────────────────────────────────
        // Floating windows provide a navigation serial, allowing presentation
        // changes to reattach this exact WebView without reloading it. Legacy
        // sheet/direct-fullscreen callers have no serial and keep the existing
        // URL-based behaviour.
        if (navigationRequestSerial != null) {
            val newRequest = vm.shouldHandleWebViewNavigationSerial(
                sessionId, navigationRequestSerial
            )
            if (urlInitial.isNotBlank() && (needsFirstConfig || newRequest)) {
                loadUrl(urlInitial)
            }
        } else {
            val currentUrl = this.url?.trimEnd('/')
            val requestedUrl = urlInitial.trimEnd('/')
            if (urlInitial.isNotBlank() && (needsFirstConfig || currentUrl != requestedUrl)) {
                loadUrl(urlInitial)
            }
        }

        onWebReady(this)
    }
}

/** Wrap the dark-mode API safely (feature-detected). */
private fun applyAlgorithmicDarkening(w: WebView, dark: Boolean) {
    runCatching {
        if (WebViewFeature.isFeatureSupported(WebViewFeature.ALGORITHMIC_DARKENING)) {
            WebSettingsCompat.setAlgorithmicDarkeningAllowed(w.settings, dark)
        } else if (WebViewFeature.isFeatureSupported(WebViewFeature.FORCE_DARK)) {
            // Legacy fallback for older WebViews
            @Suppress("DEPRECATION")
            WebSettingsCompat.setForceDark(
                w.settings,
                if (dark) WebSettingsCompat.FORCE_DARK_ON else WebSettingsCompat.FORCE_DARK_OFF
            )
        }
    }
}

/**
 * Injected on every page load. Adds a yellow tap-highlight to whichever <a> the user tapped
 * last, clears it when the user taps elsewhere (plain text or another link). The IIFE makes
 * itself idempotent so re-injection on hash-changes doesn't double-bind listeners.
 *
 * Colour is a translucent amber that stays readable in both light pages (dark text) and
 * dark pages (light text under algorithmic darkening).
 */
/**
 * Injects a single <style> element with `id="mv-dark-overlay"` to tint the page
 * background + text to match the user's dark app theme. Surgical — only colour
 * variables. jw.org's own layout, fonts, and images stay untouched.
 * Idempotent — safe to call on every onPageFinished.
 */
// v5.4.96cc — Bumped from `private` to `internal` so WebSearchScreen can
// reuse the exact same dark overlay + zoom application code as the popup
// (identical rendering, no double implementation to keep in sync).
internal val POPUP_DARK_OVERLAY_JS = """
(function() {
  var existing = document.getElementById('mv-dark-overlay');
  if (existing) return;
  var s = document.createElement('style');
  s.id = 'mv-dark-overlay';
  s.textContent = "" +
    // Base dark: page background + default text color for anything
    // that inherits from body.
    "html, body { background-color: #1c2026 !important; color: #e2e6ec !important; } " +
    // Text-carrying elements inherit the light color. NOTE (v5.4.98cc):
    // containers (div, section, aside, article, header, footer, nav)
    // used to be forced `background-color: transparent !important` here.
    // That was making jw.org's Bible-study cross-reference popovers
    // (rendered as <aside> elements with their own solid background)
    // see-through, so the popover text bled through onto the main
    // article body — the "sidebar mixed with other text" rendering
    // the user hit on the /study-bible/ page. Removed the container
    // override entirely; sites with their own dark mode (jw.org) keep
    // their popover backgrounds intact, sites without dark mode still
    // get the base dark page + light text below.
    "p, li, span, td, th, dd, dt, label, blockquote " +
    "{ color: inherit !important; } " +
    "h1, h2, h3, h4, h5, h6 { color: #f4f7fa !important; } " +
    "a, a:link { color: #8ab4f8 !important; } " +
    "a:visited { color: #c58af9 !important; }";
  document.head.appendChild(s);
})();
""".trimIndent()

/** Removes the dark overlay when user toggles back to light mode. */
internal val POPUP_REMOVE_OVERLAY_JS = """
(function() {
  var el = document.getElementById('mv-dark-overlay');
  if (el) el.remove();
})();
""".trimIndent()

private val LINK_TAP_HIGHLIGHT_JS = """
(function(){
  if (window.__mvLinkTapInstalled) return;
  window.__mvLinkTapInstalled = true;
  try {
    var style = document.createElement('style');
    style.id = 'mv-link-tap-style';
    style.textContent =
      '.mv-tapped{background-color:rgba(255,217,0,0.30)!important;'+
      'outline:2px solid rgba(255,193,7,0.65)!important;'+
      'border-radius:3px;'+
      'transition:background-color 120ms,outline-color 120ms;}';
    (document.head || document.documentElement).appendChild(style);

    var lastTapped = null;
    function clearLast(){
      if (lastTapped) {
        lastTapped.classList.remove('mv-tapped');
        lastTapped = null;
      }
    }
    // Click delegation — capture phase so we see it before any page handlers
    document.addEventListener('click', function(e){
      var t = e.target;
      // Walk up to find an <a> ancestor (image-in-link case)
      var anchor = null;
      while (t && t !== document.body) {
        if (t.tagName === 'A') { anchor = t; break; }
        t = t.parentNode;
      }
      clearLast();
      if (anchor) {
        anchor.classList.add('mv-tapped');
        lastTapped = anchor;
      }
    }, true);
  } catch (err) { /* ignore */ }
})();
""".trimIndent()

