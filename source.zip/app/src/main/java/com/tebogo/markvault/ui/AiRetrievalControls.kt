package com.tebogo.markvault.ui

import androidx.compose.material3.*
import androidx.compose.runtime.*
import com.tebogo.markvault.ai.AiSearchSettings
import com.tebogo.markvault.ai.AiModelCatalog

@Composable
fun AiSearchToggle() {
    var enabled by remember { mutableStateOf(AiSearchSettings.isEnabled()) }

    Switch(
        checked = enabled,
        onCheckedChange = {
            enabled = it
            AiSearchSettings.setEnabled(it)
        }
    )
}

@Composable
fun AiModelList() {
    Column {
        AiModelCatalog.models().forEach { model ->
            Text(
                text = "${model.name} ${if (model.installed) "✓" else ""}",
                style = MaterialTheme.typography.bodyLarge
            )
        }
    }
}
