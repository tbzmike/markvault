package com.tebogo.markvault.search

import java.util.Locale

/** Disjoint completed search stages, so saved reports can explain total latency. */
class SearchTimings {
    private val milliseconds = linkedMapOf<String, Long>()

    @Synchronized fun add(stage: String, elapsedMs: Long) {
        milliseconds[stage] = (milliseconds[stage] ?: 0L) + elapsedMs.coerceAtLeast(0L)
    }

    @Synchronized fun summary(totalMs: Long): String {
        if (milliseconds.isEmpty()) return ""
        val stages = LinkedHashMap(milliseconds)
        stages["Other retrieval"] = (totalMs - stages.values.sum()).coerceAtLeast(0L)
        return stages.entries.joinToString(" · ") { (stage, duration) ->
            "$stage ${String.format(Locale.ROOT, "%.2f", duration / 1000.0)}s"
        }
    }
}
