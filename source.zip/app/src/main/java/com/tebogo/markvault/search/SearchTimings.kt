package com.tebogo.markvault.search

import java.util.Locale

/** Completed search stages; interval union accounts for parallel retrieval without double counting. */
class SearchTimings {
    private val milliseconds = linkedMapOf<String, Long>()
    private val intervals = arrayListOf<Pair<Long, Long>>()
    private var untrackedMs = 0L

    @Synchronized fun add(stage: String, elapsedMs: Long, startedAtMs: Long? = null) {
        val duration = elapsedMs.coerceAtLeast(0L)
        milliseconds[stage] = (milliseconds[stage] ?: 0L) + duration
        if (startedAtMs != null && startedAtMs >= 0L) intervals += startedAtMs to (startedAtMs + duration)
        else untrackedMs += duration
    }

    @Synchronized fun summary(totalMs: Long): String {
        if (milliseconds.isEmpty()) return ""
        val stages = LinkedHashMap(milliseconds)
        var coveredMs = 0L
        var end = Long.MIN_VALUE
        for ((start, stop) in intervals.sortedBy { it.first }) {
            coveredMs += (stop - maxOf(start, end)).coerceAtLeast(0L)
            end = maxOf(end, stop)
        }
        stages["Other retrieval"] = (totalMs - coveredMs - untrackedMs).coerceAtLeast(0L)
        val overlap = intervals.sumOf { it.second - it.first } > coveredMs
        return stages.entries.joinToString(" · ") { (stage, duration) ->
            "$stage ${String.format(Locale.ROOT, "%.2f", duration / 1000.0)}s"
        } + if (overlap) " · Stages overlap" else ""
    }
}
