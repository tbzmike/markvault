package com.tebogo.markvault.data

import android.content.Context
import android.net.Uri
import android.util.Base64
import org.json.JSONObject
import java.io.File
import java.io.FileOutputStream
import java.util.zip.ZipInputStream
import kotlin.math.roundToInt

/** Metadata shown in MarkVault's Obsidian-theme manager. */
data class ObsidianThemeInfo(
    val id: String,
    val name: String,
    val author: String = "",
    val version: String = "",
    val cssBytes: Long = 0L,
    val lightVariables: Int = 0,
    val darkVariables: Int = 0
)

/** Fully loaded theme. Files live in app-private storage, never in the user's vault. */
data class ObsidianThemePayload(
    val info: ObsidianThemeInfo,
    val css: String,
    val lightVariables: Map<String, String>,
    val darkVariables: Map<String, String>
) {
    fun variables(dark: Boolean): Map<String, String> {
        val preferred = if (dark) darkVariables else lightVariables
        val alternate = if (dark) lightVariables else darkVariables
        return if (preferred.isNotEmpty()) preferred else alternate
    }
}

/**
 * v5.4.337cc — Obsidian community-theme compatibility storage/parser.
 *
 * Imported theme files are isolated under filesDir/obsidian_themes. No method in
 * this class receives the vault URI or writes note/library files. ZIP extraction
 * is bounded and path-checked so importing a theme cannot escape that directory.
 */
class ObsidianThemeManager(private val context: Context) {
    private val root: File get() = File(context.filesDir, "obsidian_themes").apply { mkdirs() }

    fun listInstalled(): List<ObsidianThemeInfo> = root.listFiles()
        ?.filter { it.isDirectory }
        ?.mapNotNull { readInfo(it) }
        ?.sortedBy { it.name.lowercase() }
        ?: emptyList()

    fun load(id: String?): ObsidianThemePayload? {
        if (id.isNullOrBlank()) return null
        val dir = safeThemeDir(id) ?: return null
        if (!dir.isDirectory) return null
        val cssFile = findThemeCss(dir) ?: return null
        val rawCss = runCatching { cssFile.readText() }.getOrNull() ?: return null
        val expandedCss = inlineLocalImports(rawCss, cssFile.parentFile ?: dir, dir, 0)
        val safeCss = rewriteAssetsAndSanitize(expandedCss, cssFile.parentFile ?: dir, dir)
        val light = extractVariables(safeCss, dark = false)
        val dark = extractVariables(safeCss, dark = true)
        val baseInfo = readInfo(dir) ?: return null
        return ObsidianThemePayload(
            info = baseInfo.copy(
                cssBytes = safeCss.toByteArray().size.toLong(),
                lightVariables = light.size,
                darkVariables = dark.size
            ),
            css = safeCss,
            lightVariables = light,
            darkVariables = dark
        )
    }

    fun importTheme(uri: Uri): Result<ObsidianThemeInfo> = runCatching {
        val displayName = queryDisplayName(uri) ?: "obsidian-theme"
        val stage = File(context.cacheDir, "obsidian_theme_import_${System.nanoTime()}")
        stage.deleteRecursively()
        stage.mkdirs()
        try {
            context.contentResolver.openInputStream(uri).use { input ->
                requireNotNull(input) { "Unable to open selected theme file." }
                if (displayName.endsWith(".zip", true)) {
                    extractZipSafely(input, stage)
                } else {
                    val safeName = displayName.substringAfterLast('/').substringAfterLast('\\').ifBlank { "theme.css" }
                    val out = File(stage, if (safeName.endsWith(".css", true)) safeName else "theme.css")
                    FileOutputStream(out).use { input.copyTo(it) }
                }
            }

            val cssFile = findThemeCss(stage)
                ?: throw IllegalArgumentException("No theme.css or CSS file was found in this theme.")
            if (cssFile.length() > MAX_CSS_BYTES) {
                throw IllegalArgumentException("Theme CSS is too large (${cssFile.length()} bytes).")
            }

            val manifestFile = stage.walkTopDown().firstOrNull { it.isFile && it.name.equals("manifest.json", true) }
            val manifest = manifestFile?.let { runCatching { JSONObject(it.readText()) }.getOrNull() }
            val name = manifest?.optString("name")?.takeIf { it.isNotBlank() }
                ?: displayName.substringBeforeLast('.').ifBlank { "Imported Obsidian Theme" }
            val requestedId = manifest?.optString("id")?.takeIf { it.isNotBlank() } ?: name
            val id = uniqueId(slug(requestedId))
            val target = File(root, id)
            target.mkdirs()

            // Preserve the relative theme package (CSS + local fonts/images) in app-private storage.
            stage.copyRecursively(target, overwrite = true)
            val storedCss = findThemeCss(target) ?: error("Theme CSS copy failed.")
            val normalizedManifest = JSONObject().apply {
                put("id", id)
                put("name", name)
                put("author", manifest?.optString("author") ?: "")
                put("version", manifest?.optString("version") ?: "")
                put("sourceName", displayName)
                put("cssRelativePath", storedCss.relativeTo(target).invariantSeparatorsPath)
            }
            File(target, "markvault-theme.json").writeText(normalizedManifest.toString(2))
            load(id)?.info ?: throw IllegalStateException("Imported theme could not be parsed.")
        } finally {
            stage.deleteRecursively()
        }
    }

    fun delete(id: String): Boolean {
        val dir = safeThemeDir(id) ?: return false
        return dir.exists() && dir.deleteRecursively()
    }

    private fun readInfo(dir: File): ObsidianThemeInfo? {
        val css = findThemeCss(dir) ?: return null
        val mvManifest = File(dir, "markvault-theme.json")
        val obj = runCatching { if (mvManifest.isFile) JSONObject(mvManifest.readText()) else JSONObject() }.getOrElse { JSONObject() }
        val original = dir.walkTopDown().firstOrNull { it.isFile && it.name.equals("manifest.json", true) }
            ?.let { runCatching { JSONObject(it.readText()) }.getOrNull() }
        val name = obj.optString("name").ifBlank { original?.optString("name").orEmpty() }.ifBlank { dir.name }
        val author = obj.optString("author").ifBlank { original?.optString("author").orEmpty() }
        val version = obj.optString("version").ifBlank { original?.optString("version").orEmpty() }
        return ObsidianThemeInfo(dir.name, name, author, version, css.length())
    }

    private fun findThemeCss(dir: File): File? {
        val marker = File(dir, "markvault-theme.json")
        if (marker.isFile) {
            val relative = runCatching { JSONObject(marker.readText()).optString("cssRelativePath") }.getOrNull()
            if (!relative.isNullOrBlank()) {
                val f = File(dir, relative)
                if (f.isFile && f.extension.equals("css", true)) return f
            }
        }
        return dir.walkTopDown().firstOrNull { it.isFile && it.name.equals("theme.css", true) }
            ?: dir.walkTopDown().firstOrNull { it.isFile && it.extension.equals("css", true) }
    }

    private fun safeThemeDir(id: String): File? {
        if (id.isBlank() || id.contains('/') || id.contains('\\') || id.contains("..")) return null
        val dir = File(root, id)
        val rootPath = root.canonicalFile.toPath()
        val path = runCatching { dir.canonicalFile.toPath() }.getOrNull() ?: return null
        return if (path.startsWith(rootPath)) dir else null
    }

    private fun uniqueId(base: String): String {
        var id = base.ifBlank { "theme" }
        var n = 2
        while (File(root, id).exists()) id = "${base.ifBlank { "theme" }}-$n".also { n++ }
        return id
    }

    private fun slug(raw: String): String = raw.lowercase()
        .replace(Regex("[^a-z0-9._-]+"), "-")
        .trim('-', '.', '_')
        .take(80)

    private fun queryDisplayName(uri: Uri): String? {
        return runCatching {
            context.contentResolver.query(uri, arrayOf(android.provider.OpenableColumns.DISPLAY_NAME), null, null, null)
                ?.use { c -> if (c.moveToFirst()) c.getString(0) else null }
        }.getOrNull()
    }

    private fun extractZipSafely(input: java.io.InputStream, target: File) {
        var total = 0L
        ZipInputStream(input.buffered()).use { zip ->
            while (true) {
                val entry = zip.nextEntry ?: break
                val normalized = entry.name.replace('\\', '/').trimStart('/')
                if (normalized.isBlank() || normalized.contains("../") || normalized == "..") {
                    zip.closeEntry(); continue
                }
                val out = File(target, normalized)
                val targetPath = target.canonicalFile.toPath()
                val outPath = out.canonicalFile.toPath()
                if (!outPath.startsWith(targetPath)) {
                    zip.closeEntry(); continue
                }
                if (entry.isDirectory) {
                    out.mkdirs()
                } else {
                    out.parentFile?.mkdirs()
                    FileOutputStream(out).use { fos ->
                        val buffer = ByteArray(16 * 1024)
                        var fileBytes = 0L
                        while (true) {
                            val read = zip.read(buffer)
                            if (read <= 0) break
                            fileBytes += read
                            total += read
                            if (fileBytes > MAX_ENTRY_BYTES || total > MAX_PACKAGE_BYTES) {
                                throw IllegalArgumentException("Theme package is too large.")
                            }
                            fos.write(buffer, 0, read)
                        }
                    }
                }
                zip.closeEntry()
            }
        }
    }

    private fun inlineLocalImports(css: String, baseDir: File, themeRoot: File, depth: Int): String {
        if (depth >= 4) return css
        val importRegex = Regex("@import\\s+(?:url\\()?['\\\"]?([^'\\\")\\s;]+)['\\\"]?\\)?\\s*;", RegexOption.IGNORE_CASE)
        return importRegex.replace(css) { match ->
            val raw = match.groupValues[1]
            if (raw.startsWith("http:", true) || raw.startsWith("https:", true) || raw.startsWith("//")) return@replace ""
            val f = File(baseDir, raw.substringBefore('?').substringBefore('#'))
            val safe = runCatching { f.canonicalFile }.getOrNull()
            val rootCanonical = runCatching { themeRoot.canonicalFile }.getOrNull()
            if (safe == null || rootCanonical == null || !safe.toPath().startsWith(rootCanonical.toPath()) || !safe.isFile || safe.length() > MAX_CSS_BYTES) ""
            else rewriteAssetsAndSanitize(
                inlineLocalImports(safe.readText(), safe.parentFile ?: baseDir, themeRoot, depth + 1),
                safe.parentFile ?: baseDir,
                themeRoot
            )
        }
    }

    private fun rewriteAssetsAndSanitize(css: String, baseDir: File, themeRoot: File): String {
        // No remote imports/scripts. CSS can style only the isolated article WebView;
        // local theme assets are inlined so fonts/backgrounds continue to work offline.
        var out = css
            .replace(Regex("@import\\s+url\\([^)]*(?:https?:)?//[^)]*\\)\\s*;?", RegexOption.IGNORE_CASE), "")
            .replace(Regex("@import\\s+['\\\"](?:https?:)?//[^'\\\"]+['\\\"]\\s*;?", RegexOption.IGNORE_CASE), "")
            .replace(Regex("javascript\\s*:", RegexOption.IGNORE_CASE), "")
        val urlRegex = Regex("url\\(([^)]+)\\)", RegexOption.IGNORE_CASE)
        out = urlRegex.replace(out) { m ->
            val raw = m.groupValues[1].trim().trim('\'', '"')
            if (raw.isBlank() || raw.startsWith("data:", true) || raw.startsWith("http:", true) ||
                raw.startsWith("https:", true) || raw.startsWith("//") || raw.startsWith("#")) {
                if (raw.startsWith("http", true) || raw.startsWith("//")) "url()" else m.value
            } else {
                val file = File(baseDir, raw.substringBefore('?').substringBefore('#'))
                val safe = runCatching { file.canonicalFile }.getOrNull()
                val rootCanonical = runCatching { themeRoot.canonicalFile }.getOrNull()
                if (safe == null || rootCanonical == null || !safe.toPath().startsWith(rootCanonical.toPath()) ||
                    !safe.isFile || safe.length() > MAX_INLINE_ASSET_BYTES) {
                    "url()"
                } else {
                    val mime = mimeFor(safe.extension)
                    val encoded = Base64.encodeToString(safe.readBytes(), Base64.NO_WRAP)
                    "url(\"data:$mime;base64,$encoded\")"
                }
            }
        }
        return out
    }

    private fun mimeFor(ext: String): String = when (ext.lowercase()) {
        "woff2" -> "font/woff2"
        "woff" -> "font/woff"
        "ttf" -> "font/ttf"
        "otf" -> "font/otf"
        "png" -> "image/png"
        "jpg", "jpeg" -> "image/jpeg"
        "gif" -> "image/gif"
        "svg" -> "image/svg+xml"
        "webp" -> "image/webp"
        else -> "application/octet-stream"
    }

    /** Extract :root/common vars, then overlay the requested Obsidian appearance block. */
    private fun extractVariables(css: String, dark: Boolean): LinkedHashMap<String, String> {
        val common = linkedMapOf<String, String>()
        val variant = linkedMapOf<String, String>()
        val blockRegex = Regex("([^{}]+)\\{([^{}]*)}", setOf(RegexOption.DOT_MATCHES_ALL))
        blockRegex.findAll(stripComments(css)).forEach { m ->
            val selectors = m.groupValues[1].trim().lowercase()
            val declarations = parseDeclarations(m.groupValues[2])
            if (selectors.contains(":root") || selectors == "body" || selectors.contains(".app-container")) common.putAll(declarations)
            val hit = if (dark) selectors.contains(".theme-dark") else selectors.contains(".theme-light")
            if (hit) variant.putAll(declarations)
        }
        common.putAll(variant)
        val resolved = linkedMapOf<String, String>()
        common.forEach { (key, _) -> resolveVariable(key, common, mutableSetOf())?.let { resolved[key] = normalizeColorValue(it) } }
        return resolved
    }

    private fun parseDeclarations(body: String): Map<String, String> {
        val out = linkedMapOf<String, String>()
        body.split(';').forEach { decl ->
            val colon = decl.indexOf(':')
            if (colon <= 0) return@forEach
            val key = decl.substring(0, colon).trim()
            if (!key.startsWith("--")) return@forEach
            val value = decl.substring(colon + 1).trim().removeSuffix("!important").trim()
            if (value.isNotBlank()) out[key] = value
        }
        return out
    }

    private fun resolveVariable(key: String, vars: Map<String, String>, visiting: MutableSet<String>): String? {
        if (!visiting.add(key)) return null
        var value = vars[key] ?: return null
        val varRegex = Regex("var\\(\\s*(--[A-Za-z0-9_-]+)(?:\\s*,\\s*([^)]*))?\\)")
        var guard = 0
        while (guard++ < 12 && varRegex.containsMatchIn(value)) {
            value = varRegex.replace(value) { match ->
                val dep = match.groupValues[1]
                val fallback = match.groupValues.getOrNull(2).orEmpty()
                resolveVariable(dep, vars, visiting.toMutableSet()) ?: fallback
            }
        }
        return value.trim()
    }

    private fun normalizeColorValue(raw: String): String {
        val value = raw.trim()
        val rgb = Regex("rgba?\\(\\s*(\\d{1,3})\\s*,\\s*(\\d{1,3})\\s*,\\s*(\\d{1,3})(?:\\s*,\\s*([0-9.]+))?\\s*\\)", RegexOption.IGNORE_CASE)
            .matchEntire(value)
        if (rgb != null) {
            val r = rgb.groupValues[1].toInt().coerceIn(0, 255)
            val g = rgb.groupValues[2].toInt().coerceIn(0, 255)
            val b = rgb.groupValues[3].toInt().coerceIn(0, 255)
            val a = rgb.groupValues[4].takeIf { it.isNotBlank() }?.toFloatOrNull()?.coerceIn(0f, 1f)
            return if (a == null || a >= .999f) String.format("#%02X%02X%02X", r, g, b)
            else String.format("#%02X%02X%02X%02X", (a * 255).roundToInt(), r, g, b)
        }
        return value
    }

    private fun stripComments(css: String): String = css.replace(Regex("/\\*.*?\\*/", RegexOption.DOT_MATCHES_ALL), "")

    companion object {
        private const val MAX_CSS_BYTES = 5L * 1024L * 1024L
        private const val MAX_ENTRY_BYTES = 8L * 1024L * 1024L
        private const val MAX_PACKAGE_BYTES = 32L * 1024L * 1024L
        private const val MAX_INLINE_ASSET_BYTES = 2L * 1024L * 1024L
    }
}
