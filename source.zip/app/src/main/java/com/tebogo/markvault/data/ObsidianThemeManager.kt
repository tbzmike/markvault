package com.tebogo.markvault.data

import android.content.Context
import android.net.Uri
import android.util.Base64
import org.json.JSONObject
import org.json.JSONArray
import java.io.File
import java.io.FileOutputStream
import java.net.URL
import java.net.HttpURLConnection
import java.util.zip.ZipInputStream
import kotlin.math.roundToInt

/** Metadata shown in MarkVault's Obsidian-theme manager. */
data class ObsidianThemeInfo(
    val id: String,
    val name: String,
    val author: String = "",
    val version: String = "",
    val sourceRepo: String = "",
    val cssBytes: Long = 0L,
    val lightVariables: Int = 0,
    val darkVariables: Int = 0
)

/** Official Obsidian community-theme registry entry. */
data class ObsidianCommunityTheme(
    val name: String,
    val author: String,
    val repo: String,
    val screenshot: String = "",
    val modes: List<String> = emptyList(),
    val legacy: Boolean = false
)

/** How much of an imported theme can be translated into MarkVault-native UI. */
data class ObsidianCompatibilityReport(
    val themeId: String,
    val totalVariables: Int,
    val mappedVariables: Int,
    val totalSelectors: Int,
    val recognizedSelectors: Int,
    val scorePercent: Int,
    val unsupportedSamples: List<String>
)

/** Fully loaded theme. Files live in app-private storage, never in the user's vault. */
data class ObsidianThemePayload(
    val info: ObsidianThemeInfo,
    val css: String,
    val lightVariables: Map<String, String>,
    val darkVariables: Map<String, String>
) {
    fun variables(dark: Boolean): Map<String, String> {
        val preferred = if (dark) darkVariables else lightVariables
        val alternate = if (dark) lightVariables else darkVariables
        return if (preferred.isNotEmpty()) preferred else alternate
    }
}

/**
 * v5.4.337cc — Obsidian community-theme compatibility storage/parser.
 *
 * Imported theme files are isolated under filesDir/obsidian_themes. No method in
 * this class receives the vault URI or writes note/library files. ZIP extraction
 * is bounded and path-checked so importing a theme cannot escape that directory.
 */
class ObsidianThemeManager(private val context: Context) {
    private val root: File get() = File(context.filesDir, "obsidian_themes").apply { mkdirs() }

    fun listInstalled(): List<ObsidianThemeInfo> = root.listFiles()
        ?.filter { it.isDirectory }
        ?.mapNotNull { readInfo(it) }
        ?.sortedBy { it.name.lowercase() }
        ?: emptyList()

    fun load(id: String?): ObsidianThemePayload? {
        if (id.isNullOrBlank()) return null
        val dir = safeThemeDir(id) ?: return null
        if (!dir.isDirectory) return null
        val cssFile = findThemeCss(dir) ?: return null
        val rawCss = runCatching { cssFile.readText() }.getOrNull() ?: return null
        val expandedCss = inlineLocalImports(rawCss, cssFile.parentFile ?: dir, dir, 0)
        val safeCss = rewriteAssetsAndSanitize(expandedCss, cssFile.parentFile ?: dir, dir)
        val light = extractVariables(safeCss, dark = false)
        val dark = extractVariables(safeCss, dark = true)
        val baseInfo = readInfo(dir) ?: return null
        return ObsidianThemePayload(
            info = baseInfo.copy(
                cssBytes = safeCss.toByteArray().size.toLong(),
                lightVariables = light.size,
                darkVariables = dark.size
            ),
            css = safeCss,
            lightVariables = light,
            darkVariables = dark
        )
    }

    /**
     * Apply a MarkVault-only variable profile on top of the original theme.
     * The original imported files are never rewritten. Overrides are validated
     * and appended after the source CSS so both native Compose mappings and the
     * isolated article WebView see the same final values.
     */
    fun applyOverrides(payload: ObsidianThemePayload?, overrides: Map<String, String>): ObsidianThemePayload? {
        if (payload == null || overrides.isEmpty()) return payload
        val clean = linkedMapOf<String, String>()
        overrides.forEach { (rawKey, rawValue) ->
            val key = rawKey.trim()
            val value = sanitizeOverrideValue(rawValue)
            if (SAFE_VARIABLE.matches(key) && value != null) clean[key] = value
        }
        if (clean.isEmpty()) return payload
        val block = clean.entries.joinToString(separator = "") { "${it.key}:${it.value};" }
        val css = payload.css + "\n/* MarkVault per-theme overrides */\n:root,.theme-light,.theme-dark{$block}\n"
        return payload.copy(
            css = css,
            lightVariables = LinkedHashMap(payload.lightVariables).apply { putAll(clean) },
            darkVariables = LinkedHashMap(payload.darkVariables).apply { putAll(clean) }
        )
    }

    /**
     * Report what can be mapped rather than pretending every Obsidian-specific
     * plugin selector has a native MarkVault equivalent.
     */
    fun compatibilityReport(id: String): ObsidianCompatibilityReport? {
        val payload = load(id) ?: return null
        val variableNames = (payload.lightVariables.keys + payload.darkVariables.keys).toSet()
        val mapped = variableNames.count { it in MAPPED_VARIABLES }
        val selectorRegex = Regex("([^{}]+)\\{", setOf(RegexOption.DOT_MATCHES_ALL))
        val selectors = selectorRegex.findAll(stripComments(payload.css))
            .map { it.groupValues[1].trim() }
            .filter { it.isNotBlank() && !it.startsWith("@") }
            .toList()
        val recognized = selectors.count { selector ->
            RECOGNIZED_SELECTOR_HINTS.any { hint -> selector.contains(hint, ignoreCase = true) }
        }
        val variableScore = if (variableNames.isEmpty()) 100 else (mapped * 100 / variableNames.size)
        val selectorScore = if (selectors.isEmpty()) 100 else (recognized * 100 / selectors.size)
        val score = ((variableScore * 2 + selectorScore) / 3).coerceIn(0, 100)
        val unsupported = selectors.asSequence()
            .filterNot { selector -> RECOGNIZED_SELECTOR_HINTS.any { hint -> selector.contains(hint, ignoreCase = true) } }
            .map { it.replace(Regex("\\s+"), " ").take(140) }
            .distinct()
            .take(8)
            .toList()
        return ObsidianCompatibilityReport(
            themeId = id,
            totalVariables = variableNames.size,
            mappedVariables = mapped,
            totalSelectors = selectors.size,
            recognizedSelectors = recognized,
            scorePercent = score,
            unsupportedSamples = unsupported
        )
    }

    fun importTheme(uri: Uri): Result<ObsidianThemeInfo> = runCatching {
        val displayName = queryDisplayName(uri) ?: "obsidian-theme"
        val stage = File(context.cacheDir, "obsidian_theme_import_${System.nanoTime()}")
        stage.deleteRecursively()
        stage.mkdirs()
        try {
            context.contentResolver.openInputStream(uri).use { input ->
                requireNotNull(input) { "Unable to open selected theme file." }
                if (displayName.endsWith(".zip", true)) {
                    extractZipSafely(input, stage)
                } else {
                    val safeName = displayName.substringAfterLast('/').substringAfterLast('\\').ifBlank { "theme.css" }
                    val out = File(stage, if (safeName.endsWith(".css", true)) safeName else "theme.css")
                    FileOutputStream(out).use { input.copyTo(it) }
                }
            }

            val cssFile = findThemeCss(stage)
                ?: throw IllegalArgumentException("No theme.css or CSS file was found in this theme.")
            if (cssFile.length() > MAX_CSS_BYTES) {
                throw IllegalArgumentException("Theme CSS is too large (${cssFile.length()} bytes).")
            }

            val manifestFile = stage.walkTopDown().firstOrNull { it.isFile && it.name.equals("manifest.json", true) }
            val manifest = manifestFile?.let { runCatching { JSONObject(it.readText()) }.getOrNull() }
            val name = manifest?.optString("name")?.takeIf { it.isNotBlank() }
                ?: displayName.substringBeforeLast('.').ifBlank { "Imported Obsidian Theme" }
            val requestedId = manifest?.optString("id")?.takeIf { it.isNotBlank() } ?: name
            val id = uniqueId(slug(requestedId))
            val target = File(root, id)
            target.mkdirs()

            // Preserve the relative theme package (CSS + local fonts/images) in app-private storage.
            stage.copyRecursively(target, overwrite = true)
            val storedCss = findThemeCss(target) ?: error("Theme CSS copy failed.")
            val normalizedManifest = JSONObject().apply {
                put("id", id)
                put("name", name)
                put("author", manifest?.optString("author") ?: "")
                put("version", manifest?.optString("version") ?: "")
                put("sourceRepo", "")
                put("sourceName", displayName)
                put("cssRelativePath", storedCss.relativeTo(target).invariantSeparatorsPath)
            }
            File(target, "markvault-theme.json").writeText(normalizedManifest.toString(2))
            load(id)?.info ?: throw IllegalStateException("Imported theme could not be parsed.")
        } finally {
            stage.deleteRecursively()
        }
    }


    /**
     * Fetch the official Obsidian community-theme directory. This reads only
     * Obsidian's public registry and never sends vault/library information.
     */
    fun fetchCommunityCatalog(): Result<List<ObsidianCommunityTheme>> = runCatching {
        val text = downloadText(COMMUNITY_REGISTRY_URL, MAX_REGISTRY_BYTES)
        val arr = JSONArray(text)
        buildList {
            for (i in 0 until arr.length()) {
                val obj = arr.optJSONObject(i) ?: continue
                val repo = obj.optString("repo").trim()
                if (!SAFE_REPO.matches(repo)) continue
                val modesJson = obj.optJSONArray("modes")
                val modes = buildList {
                    if (modesJson != null) for (j in 0 until modesJson.length()) {
                        val mode = modesJson.optString(j)
                        if (mode.isNotBlank()) add(mode)
                    }
                }
                add(
                    ObsidianCommunityTheme(
                        name = obj.optString("name").ifBlank { repo.substringAfter('/') },
                        author = obj.optString("author"),
                        repo = repo,
                        screenshot = obj.optString("screenshot"),
                        modes = modes,
                        legacy = obj.optBoolean("legacy", false)
                    )
                )
            }
        }.sortedBy { it.name.lowercase() }
    }

    /**
     * Install directly from an entry in Obsidian's official community registry.
     * Uses only validated public theme repository/release URLs. Downloads are
     * staged and parsed before the installed theme is replaced or activated.
     */
    fun installCommunityTheme(entry: ObsidianCommunityTheme): Result<ObsidianThemeInfo> = runCatching {
        require(SAFE_REPO.matches(entry.repo)) { "Invalid community theme repository." }
        installFromRepo(entry.repo, entry.name, entry.author, replaceId = null, preferArchive = entry.legacy)
    }

    /** Update an installed community theme in place while keeping its MarkVault id. */
    fun updateCommunityTheme(id: String): Result<ObsidianThemeInfo> = runCatching {
        val dir = safeThemeDir(id) ?: error("Theme not found.")
        val marker = File(dir, "markvault-theme.json")
        val meta = if (marker.isFile) JSONObject(marker.readText()) else JSONObject()
        val repo = meta.optString("sourceRepo")
        require(SAFE_REPO.matches(repo)) { "This theme was imported manually and has no community update source." }
        val name = meta.optString("name").ifBlank { id }
        val author = meta.optString("author")
        installFromRepo(repo, name, author, replaceId = id, preferArchive = true)
    }

    private fun installFromRepo(
        repo: String,
        fallbackName: String,
        fallbackAuthor: String,
        replaceId: String?,
        preferArchive: Boolean
    ): ObsidianThemeInfo {
        require(SAFE_REPO.matches(repo)) { "Invalid community theme repository." }
        val resolvedBranch = resolveDefaultBranchOrNull(repo)
        val refs = buildList {
            resolvedBranch?.let { add(it) }
            add("main")
            add("master")
            add("HEAD")
        }.distinct()

        var lastError: Throwable? = null

        // Modern Obsidian themes are canonically installed from the GitHub release
        // whose tag matches the version in manifest.json. Resolve that path first,
        // matching Obsidian's own theme directory behavior.
        if (!preferArchive) {
            for (ref in refs) {
                try {
                    val manifestText = downloadTextFromCandidates(
                        communityFileUrls(repo, ref, "manifest.json"),
                        MAX_MANIFEST_BYTES
                    )
                    val manifest = JSONObject(manifestText)
                    val version = manifest.optString("version").trim()
                    if (version.isBlank()) continue
                    val css = downloadTextFromCandidates(
                        communityReleaseUrls(repo, version, "theme.css"),
                        MAX_CSS_BYTES
                    )
                    require(css.isNotBlank()) { "Released theme.css is empty." }
                    val stage = File(context.cacheDir, "obsidian_theme_release_${System.nanoTime()}")
                    stage.mkdirs()
                    try {
                        val cssFile = File(stage, "theme.css").also { it.writeText(css) }
                        File(stage, "manifest.json").writeText(manifestText)
                        return commitDownloadedTheme(
                            stage = stage,
                            cssFile = cssFile,
                            manifest = manifest,
                            fallbackName = fallbackName,
                            fallbackAuthor = fallbackAuthor,
                            repo = repo,
                            sourceRef = "release:$version",
                            replaceId = replaceId
                        )
                    } finally {
                        stage.deleteRecursively()
                    }
                } catch (t: Throwable) {
                    lastError = t
                }
            }
        }

        // Repository archives are the most compatible path: they preserve fonts,
        // images, imported CSS, and legacy themes whose stylesheet is not named
        // theme.css (for example everforest.css).
        val archiveRefs = refs.filter { it != "HEAD" }
        if (preferArchive || archiveRefs.isNotEmpty()) {
            for (ref in archiveRefs) {
                val stage = File(context.cacheDir, "obsidian_theme_archive_${System.nanoTime()}")
                stage.mkdirs()
                try {
                    val bytes = downloadBytesFromCandidates(communityArchiveUrls(repo, ref), MAX_REPO_ARCHIVE_BYTES)
                    java.io.ByteArrayInputStream(bytes).use { extractZipSafely(it, stage) }
                    val cssFile = findThemeCss(stage) ?: error("Repository archive contains no usable CSS theme file.")
                    require(cssFile.length() in 1..MAX_CSS_BYTES) { "Theme CSS is empty or too large." }
                    val manifestFile = stage.walkTopDown().firstOrNull {
                        it.isFile && it.name.equals("manifest.json", true)
                    }
                    val manifest = manifestFile?.let { runCatching { JSONObject(it.readText()) }.getOrNull() } ?: JSONObject()
                    return commitDownloadedTheme(
                        stage = stage,
                        cssFile = cssFile,
                        manifest = manifest,
                        fallbackName = fallbackName,
                        fallbackAuthor = fallbackAuthor,
                        repo = repo,
                        sourceRef = ref,
                        replaceId = replaceId
                    )
                } catch (t: Throwable) {
                    lastError = t
                } finally {
                    stage.deleteRecursively()
                }
            }
        }

        // Direct-file fallback for modern repositories and cases where archive
        // delivery is blocked. theme.css is preferred, but legacy filename
        // candidates are also tried before giving up.
        for (ref in refs) {
            val stage = File(context.cacheDir, "obsidian_theme_direct_${System.nanoTime()}")
            stage.mkdirs()
            try {
                val manifestText = runCatching {
                    downloadTextFromCandidates(communityFileUrls(repo, ref, "manifest.json"), MAX_MANIFEST_BYTES)
                }.getOrDefault("{}")
                val manifest = runCatching { JSONObject(manifestText) }.getOrElse { JSONObject() }
                val cssNames = buildList {
                    add("theme.css")
                    val repoName = repo.substringAfter('/').removePrefix("obsidian-").removePrefix("obsidian_")
                    add("$repoName.css")
                    add("${slug(fallbackName)}.css")
                    add("everforest.css") // historical registry theme compatibility
                }.distinct()
                var cssText: String? = null
                var cssName: String? = null
                var cssError: Throwable? = null
                for (name in cssNames) {
                    try {
                        cssText = downloadTextFromCandidates(communityFileUrls(repo, ref, name), MAX_CSS_BYTES)
                        cssName = name
                        break
                    } catch (t: Throwable) {
                        cssError = t
                    }
                }
                val css = cssText ?: throw cssError ?: error("No downloadable CSS file was found.")
                require(css.isNotBlank()) { "Downloaded theme CSS is empty." }
                val storedCss = File(stage, cssName ?: "theme.css").also { it.writeText(css) }
                File(stage, "manifest.json").writeText(manifestText)
                return commitDownloadedTheme(
                    stage = stage,
                    cssFile = storedCss,
                    manifest = manifest,
                    fallbackName = fallbackName,
                    fallbackAuthor = fallbackAuthor,
                    repo = repo,
                    sourceRef = ref,
                    replaceId = replaceId
                )
            } catch (t: Throwable) {
                lastError = t
            } finally {
                stage.deleteRecursively()
            }
        }

        throw IllegalStateException(
            "Could not download a usable theme after retries, alternate hosts, branch fallbacks, archive discovery, and legacy CSS discovery. ${lastError?.message ?: "Unknown network error."}",
            lastError
        )
    }

    private fun commitDownloadedTheme(
        stage: File,
        cssFile: File,
        manifest: JSONObject,
        fallbackName: String,
        fallbackAuthor: String,
        repo: String,
        sourceRef: String,
        replaceId: String?
    ): ObsidianThemeInfo {
        val name = manifest.optString("name").ifBlank { fallbackName.ifBlank { repo.substringAfter('/') } }
        val author = manifest.optString("author").ifBlank { fallbackAuthor }
        val version = manifest.optString("version")
        val id = replaceId ?: uniqueId(slug(manifest.optString("id").ifBlank { name }))
        val target = safeThemeDir(id) ?: error("Invalid theme id.")
        val cssRelative = cssFile.relativeTo(stage).invariantSeparatorsPath
        val normalized = JSONObject().apply {
            put("id", id)
            put("name", name)
            put("author", author)
            put("version", version)
            put("sourceRepo", repo)
            put("sourceName", repo)
            put("sourceRef", sourceRef)
            put("cssRelativePath", cssRelative)
        }
        File(stage, "markvault-theme.json").writeText(normalized.toString(2))

        val backup = if (replaceId != null && target.exists()) {
            File(context.cacheDir, "obsidian_theme_backup_${System.nanoTime()}").also {
                target.copyRecursively(it, overwrite = true)
            }
        } else null
        return try {
            target.deleteRecursively()
            target.mkdirs()
            stage.copyRecursively(target, overwrite = true)
            val payload = load(id) ?: error("Downloaded theme could not be parsed by MarkVault.")
            require(payload.css.isNotBlank()) { "Downloaded theme produced no usable CSS." }
            payload.info
        } catch (t: Throwable) {
            target.deleteRecursively()
            if (backup?.exists() == true) backup.copyRecursively(target, overwrite = true)
            throw t
        } finally {
            backup?.deleteRecursively()
        }
    }

    private fun communityReleaseUrls(repo: String, version: String, fileName: String): List<String> {
        require(SAFE_REPO.matches(repo)) { "Invalid community theme repository." }
        require(SAFE_THEME_VERSION.matches(version)) { "Invalid theme version." }
        require(fileName == "theme.css" || fileName == "manifest.json") { "Invalid release theme file." }
        val encodedVersion = java.net.URLEncoder.encode(version, "UTF-8").replace("+", "%20")
        val tags = buildList {
            add(encodedVersion)
            if (!version.startsWith("v", true)) add("v$encodedVersion")
        }.distinct()
        return tags.map { tag -> "https://github.com/$repo/releases/download/$tag/$fileName" }
    }

    private fun communityArchiveUrls(repo: String, ref: String): List<String> {
        require(SAFE_REPO.matches(repo)) { "Invalid community theme repository." }
        require(SAFE_GIT_REF.matches(ref)) { "Invalid Git reference." }
        val encodedRef = java.net.URLEncoder.encode(ref, "UTF-8").replace("+", "%20")
        return listOf(
            "https://codeload.github.com/$repo/zip/refs/heads/$encodedRef",
            "https://github.com/$repo/archive/refs/heads/$encodedRef.zip"
        )
    }

    private fun communityFileUrls(repo: String, ref: String, fileName: String): List<String> {
        require(SAFE_REPO.matches(repo)) { "Invalid community theme repository." }
        require(SAFE_GIT_REF.matches(ref)) { "Invalid Git reference." }
        require(SAFE_THEME_FILE.matches(fileName)) { "Invalid theme file." }
        val encodedRef = java.net.URLEncoder.encode(ref, "UTF-8").replace("+", "%20")
        return buildList {
            // GitHub raw CDN is primary.
            add("https://raw.githubusercontent.com/$repo/$encodedRef/$fileName")
            // GitHub's normal host is an independent route and commonly survives
            // transient raw.githubusercontent.com edge failures.
            if (ref != "HEAD") {
                add("https://github.com/$repo/raw/refs/heads/$encodedRef/$fileName")
            }
            // jsDelivr mirrors public GitHub repositories and is used only as a
            // final availability fallback for the same public theme files.
            add("https://cdn.jsdelivr.net/gh/$repo@$encodedRef/$fileName")
        }.distinct()
    }

    private fun resolveDefaultBranchOrNull(repo: String): String? {
        require(SAFE_REPO.matches(repo)) { "Invalid community theme repository." }
        return runCatching {
            val metadata = downloadTextWithRetry("https://api.github.com/repos/$repo", MAX_REPO_METADATA_BYTES, attempts = 2)
            JSONObject(metadata).optString("default_branch").trim()
                .takeIf { it.isNotBlank() && SAFE_GIT_REF.matches(it) }
        }.getOrNull()
    }

    private fun downloadBytesFromCandidates(urls: List<String>, maxBytes: Long): ByteArray {
        var lastError: Throwable? = null
        for (url in urls) {
            try {
                return downloadBytesWithRetry(url, maxBytes, attempts = 3)
            } catch (t: Throwable) {
                lastError = t
            }
        }
        throw IllegalStateException(lastError?.message ?: "All theme archive endpoints failed.", lastError)
    }

    private fun downloadBytesWithRetry(url: String, maxBytes: Long, attempts: Int): ByteArray {
        var lastError: Throwable? = null
        val safeAttempts = attempts.coerceIn(1, 4)
        repeat(safeAttempts) { attempt ->
            try {
                return downloadBytesOnce(url, maxBytes)
            } catch (t: Throwable) {
                lastError = t
                val retryable = t is java.net.SocketTimeoutException ||
                    t is java.net.ConnectException ||
                    t is java.net.UnknownHostException ||
                    (t is ThemeHttpException && t.code in RETRYABLE_HTTP_CODES)
                if (!retryable || attempt == safeAttempts - 1) throw t
                try {
                    Thread.sleep(RETRY_BACKOFF_MS[attempt.coerceAtMost(RETRY_BACKOFF_MS.lastIndex)])
                } catch (_: InterruptedException) {
                    Thread.currentThread().interrupt()
                    throw t
                }
            }
        }
        throw lastError ?: IllegalStateException("Theme archive download failed.")
    }

    private fun downloadBytesOnce(url: String, maxBytes: Long): ByteArray {
        var conn: HttpURLConnection? = null
        return try {
            conn = (URL(url).openConnection() as HttpURLConnection).apply {
                connectTimeout = 15_000
                readTimeout = 35_000
                instanceFollowRedirects = true
                requestMethod = "GET"
                setRequestProperty("User-Agent", "MarkVault-ObsidianThemeBridge/1.0")
                setRequestProperty("Accept", "application/zip,application/octet-stream,*/*")
                setRequestProperty("Cache-Control", "no-cache")
            }
            val code = conn.responseCode
            if (code !in 200..299) throw ThemeHttpException(code, "Theme archive server returned HTTP $code.")
            val declared = conn.contentLengthLong
            require(declared < 0 || declared <= maxBytes) { "Downloaded theme archive is too large." }
            conn.inputStream.buffered().use { input ->
                val out = java.io.ByteArrayOutputStream()
                val buffer = ByteArray(16 * 1024)
                var total = 0L
                while (true) {
                    val n = input.read(buffer)
                    if (n <= 0) break
                    total += n
                    require(total <= maxBytes) { "Downloaded theme archive is too large." }
                    out.write(buffer, 0, n)
                }
                out.toByteArray()
            }
        } finally {
            conn?.disconnect()
        }
    }

    private fun downloadTextFromCandidates(urls: List<String>, maxBytes: Long): String {
        var lastError: Throwable? = null
        for (url in urls) {
            try {
                return downloadTextWithRetry(url, maxBytes, attempts = 3)
            } catch (t: Throwable) {
                lastError = t
            }
        }
        throw IllegalStateException(lastError?.message ?: "All theme download endpoints failed.", lastError)
    }

    private fun downloadText(url: String, maxBytes: Long): String =
        downloadTextWithRetry(url, maxBytes, attempts = 3)

    private fun downloadTextWithRetry(url: String, maxBytes: Long, attempts: Int): String {
        var lastError: Throwable? = null
        val safeAttempts = attempts.coerceIn(1, 4)
        repeat(safeAttempts) { attempt ->
            try {
                return downloadTextOnce(url, maxBytes)
            } catch (t: Throwable) {
                lastError = t
                val retryable = t is java.net.SocketTimeoutException ||
                    t is java.net.ConnectException ||
                    t is java.net.UnknownHostException ||
                    (t is ThemeHttpException && t.code in RETRYABLE_HTTP_CODES)
                if (!retryable || attempt == safeAttempts - 1) throw t
                try {
                    Thread.sleep(RETRY_BACKOFF_MS[attempt.coerceAtMost(RETRY_BACKOFF_MS.lastIndex)])
                } catch (_: InterruptedException) {
                    Thread.currentThread().interrupt()
                    throw t
                }
            }
        }
        throw lastError ?: IllegalStateException("Theme download failed.")
    }

    private fun downloadTextOnce(url: String, maxBytes: Long): String {
        var conn: HttpURLConnection? = null
        return try {
            conn = (URL(url).openConnection() as HttpURLConnection).apply {
                connectTimeout = 15_000
                readTimeout = 30_000
                instanceFollowRedirects = true
                requestMethod = "GET"
                setRequestProperty("User-Agent", "MarkVault-ObsidianThemeBridge/1.0")
                setRequestProperty("Accept", "application/json,text/css,text/plain,*/*")
                setRequestProperty("Cache-Control", "no-cache")
            }
            val code = conn.responseCode
            if (code !in 200..299) {
                throw ThemeHttpException(code, "Theme server returned HTTP $code.")
            }
            val declared = conn.contentLengthLong
            require(declared < 0 || declared <= maxBytes) { "Downloaded theme file is too large." }
            conn.inputStream.buffered().use { input ->
                val out = java.io.ByteArrayOutputStream()
                val buffer = ByteArray(16 * 1024)
                var total = 0L
                while (true) {
                    val n = input.read(buffer)
                    if (n <= 0) break
                    total += n
                    require(total <= maxBytes) { "Downloaded theme file is too large." }
                    out.write(buffer, 0, n)
                }
                out.toString(Charsets.UTF_8.name())
            }
        } finally {
            conn?.disconnect()
        }
    }

    private class ThemeHttpException(val code: Int, message: String) : java.io.IOException(message)

    fun delete(id: String): Boolean {
        val dir = safeThemeDir(id) ?: return false
        return dir.exists() && dir.deleteRecursively()
    }

    private fun readInfo(dir: File): ObsidianThemeInfo? {
        val css = findThemeCss(dir) ?: return null
        val mvManifest = File(dir, "markvault-theme.json")
        val obj = runCatching { if (mvManifest.isFile) JSONObject(mvManifest.readText()) else JSONObject() }.getOrElse { JSONObject() }
        val original = dir.walkTopDown().firstOrNull { it.isFile && it.name.equals("manifest.json", true) }
            ?.let { runCatching { JSONObject(it.readText()) }.getOrNull() }
        val name = obj.optString("name").ifBlank { original?.optString("name").orEmpty() }.ifBlank { dir.name }
        val author = obj.optString("author").ifBlank { original?.optString("author").orEmpty() }
        val version = obj.optString("version").ifBlank { original?.optString("version").orEmpty() }
        val sourceRepo = obj.optString("sourceRepo")
        return ObsidianThemeInfo(
            id = dir.name,
            name = name,
            author = author,
            version = version,
            sourceRepo = sourceRepo,
            cssBytes = css.length()
        )
    }

    private fun findThemeCss(dir: File): File? {
        val marker = File(dir, "markvault-theme.json")
        if (marker.isFile) {
            val relative = runCatching { JSONObject(marker.readText()).optString("cssRelativePath") }.getOrNull()
            if (!relative.isNullOrBlank()) {
                val f = File(dir, relative)
                if (f.isFile && f.extension.equals("css", true)) return f
            }
        }
        return dir.walkTopDown().firstOrNull { it.isFile && it.name.equals("theme.css", true) }
            ?: dir.walkTopDown().firstOrNull { it.isFile && it.extension.equals("css", true) }
    }

    private fun safeThemeDir(id: String): File? {
        if (id.isBlank() || id.contains('/') || id.contains('\\') || id.contains("..")) return null
        val dir = File(root, id)
        val rootPath = root.canonicalFile.toPath()
        val path = runCatching { dir.canonicalFile.toPath() }.getOrNull() ?: return null
        return if (path.startsWith(rootPath)) dir else null
    }

    private fun uniqueId(base: String): String {
        var id = base.ifBlank { "theme" }
        var n = 2
        while (File(root, id).exists()) id = "${base.ifBlank { "theme" }}-$n".also { n++ }
        return id
    }

    private fun slug(raw: String): String = raw.lowercase()
        .replace(Regex("[^a-z0-9._-]+"), "-")
        .trim('-', '.', '_')
        .take(80)

    private fun queryDisplayName(uri: Uri): String? {
        return runCatching {
            context.contentResolver.query(uri, arrayOf(android.provider.OpenableColumns.DISPLAY_NAME), null, null, null)
                ?.use { c -> if (c.moveToFirst()) c.getString(0) else null }
        }.getOrNull()
    }

    private fun extractZipSafely(input: java.io.InputStream, target: File) {
        var total = 0L
        ZipInputStream(input.buffered()).use { zip ->
            while (true) {
                val entry = zip.nextEntry ?: break
                val normalized = entry.name.replace('\\', '/').trimStart('/')
                if (normalized.isBlank() || normalized.contains("../") || normalized == "..") {
                    zip.closeEntry(); continue
                }
                val out = File(target, normalized)
                val targetPath = target.canonicalFile.toPath()
                val outPath = out.canonicalFile.toPath()
                if (!outPath.startsWith(targetPath)) {
                    zip.closeEntry(); continue
                }
                if (entry.isDirectory) {
                    out.mkdirs()
                } else {
                    out.parentFile?.mkdirs()
                    FileOutputStream(out).use { fos ->
                        val buffer = ByteArray(16 * 1024)
                        var fileBytes = 0L
                        while (true) {
                            val read = zip.read(buffer)
                            if (read <= 0) break
                            fileBytes += read
                            total += read
                            if (fileBytes > MAX_ENTRY_BYTES || total > MAX_PACKAGE_BYTES) {
                                throw IllegalArgumentException("Theme package is too large.")
                            }
                            fos.write(buffer, 0, read)
                        }
                    }
                }
                zip.closeEntry()
            }
        }
    }

    private fun inlineLocalImports(css: String, baseDir: File, themeRoot: File, depth: Int): String {
        if (depth >= 4) return css
        val importRegex = Regex("@import\\s+(?:url\\()?['\\\"]?([^'\\\")\\s;]+)['\\\"]?\\)?\\s*;", RegexOption.IGNORE_CASE)
        return importRegex.replace(css) { match ->
            val raw = match.groupValues[1]
            if (raw.startsWith("http:", true) || raw.startsWith("https:", true) || raw.startsWith("//")) return@replace ""
            val f = File(baseDir, raw.substringBefore('?').substringBefore('#'))
            val safe = runCatching { f.canonicalFile }.getOrNull()
            val rootCanonical = runCatching { themeRoot.canonicalFile }.getOrNull()
            if (safe == null || rootCanonical == null || !safe.toPath().startsWith(rootCanonical.toPath()) || !safe.isFile || safe.length() > MAX_CSS_BYTES) ""
            else rewriteAssetsAndSanitize(
                inlineLocalImports(safe.readText(), safe.parentFile ?: baseDir, themeRoot, depth + 1),
                safe.parentFile ?: baseDir,
                themeRoot
            )
        }
    }

    private fun rewriteAssetsAndSanitize(css: String, baseDir: File, themeRoot: File): String {
        // No remote imports/scripts. CSS can style only the isolated article WebView;
        // local theme assets are inlined so fonts/backgrounds continue to work offline.
        var out = css
            .replace(Regex("@import\\s+url\\([^)]*(?:https?:)?//[^)]*\\)\\s*;?", RegexOption.IGNORE_CASE), "")
            .replace(Regex("@import\\s+['\\\"](?:https?:)?//[^'\\\"]+['\\\"]\\s*;?", RegexOption.IGNORE_CASE), "")
            .replace(Regex("javascript\\s*:", RegexOption.IGNORE_CASE), "")
        val urlRegex = Regex("url\\(([^)]+)\\)", RegexOption.IGNORE_CASE)
        out = urlRegex.replace(out) { m ->
            val raw = m.groupValues[1].trim().trim('\'', '"')
            if (raw.isBlank() || raw.startsWith("data:", true) || raw.startsWith("http:", true) ||
                raw.startsWith("https:", true) || raw.startsWith("//") || raw.startsWith("#")) {
                if (raw.startsWith("http", true) || raw.startsWith("//")) "url()" else m.value
            } else {
                val file = File(baseDir, raw.substringBefore('?').substringBefore('#'))
                val safe = runCatching { file.canonicalFile }.getOrNull()
                val rootCanonical = runCatching { themeRoot.canonicalFile }.getOrNull()
                if (safe == null || rootCanonical == null || !safe.toPath().startsWith(rootCanonical.toPath()) ||
                    !safe.isFile || safe.length() > MAX_INLINE_ASSET_BYTES) {
                    "url()"
                } else {
                    val mime = mimeFor(safe.extension)
                    val encoded = Base64.encodeToString(safe.readBytes(), Base64.NO_WRAP)
                    "url(\"data:$mime;base64,$encoded\")"
                }
            }
        }
        return out
    }

    private fun mimeFor(ext: String): String = when (ext.lowercase()) {
        "woff2" -> "font/woff2"
        "woff" -> "font/woff"
        "ttf" -> "font/ttf"
        "otf" -> "font/otf"
        "png" -> "image/png"
        "jpg", "jpeg" -> "image/jpeg"
        "gif" -> "image/gif"
        "svg" -> "image/svg+xml"
        "webp" -> "image/webp"
        else -> "application/octet-stream"
    }

    /** Extract :root/common vars, then overlay the requested Obsidian appearance block. */
    private fun extractVariables(css: String, dark: Boolean): LinkedHashMap<String, String> {
        val common = linkedMapOf<String, String>()
        val variant = linkedMapOf<String, String>()
        val blockRegex = Regex("([^{}]+)\\{([^{}]*)\\}", setOf(RegexOption.DOT_MATCHES_ALL))
        blockRegex.findAll(stripComments(css)).forEach { m ->
            val selectors = m.groupValues[1].trim().lowercase()
            val declarations = parseDeclarations(m.groupValues[2])
            if (selectors.contains(":root") || selectors == "body" || selectors.contains(".app-container")) common.putAll(declarations)
            val hit = if (dark) selectors.contains(".theme-dark") else selectors.contains(".theme-light")
            if (hit) variant.putAll(declarations)
        }
        common.putAll(variant)
        val resolved = linkedMapOf<String, String>()
        common.forEach { (key, _) -> resolveVariable(key, common, mutableSetOf())?.let { resolved[key] = normalizeColorValue(it) } }
        return resolved
    }

    private fun parseDeclarations(body: String): Map<String, String> {
        val out = linkedMapOf<String, String>()
        body.split(';').forEach { decl ->
            val colon = decl.indexOf(':')
            if (colon <= 0) return@forEach
            val key = decl.substring(0, colon).trim()
            if (!key.startsWith("--")) return@forEach
            val value = decl.substring(colon + 1).trim().removeSuffix("!important").trim()
            if (value.isNotBlank()) out[key] = value
        }
        return out
    }

    private fun resolveVariable(key: String, vars: Map<String, String>, visiting: MutableSet<String>): String? {
        if (!visiting.add(key)) return null
        var value = vars[key] ?: return null
        val varRegex = Regex("var\\(\\s*(--[A-Za-z0-9_-]+)(?:\\s*,\\s*([^)]*))?\\)")
        var guard = 0
        while (guard++ < 12 && varRegex.containsMatchIn(value)) {
            value = varRegex.replace(value) { match ->
                val dep = match.groupValues[1]
                val fallback = match.groupValues.getOrNull(2).orEmpty()
                resolveVariable(dep, vars, visiting.toMutableSet()) ?: fallback
            }
        }
        return value.trim()
    }

    private fun normalizeColorValue(raw: String): String {
        val value = raw.trim()
        val rgb = Regex("rgba?\\(\\s*(\\d{1,3})\\s*,\\s*(\\d{1,3})\\s*,\\s*(\\d{1,3})(?:\\s*,\\s*([0-9.]+))?\\s*\\)", RegexOption.IGNORE_CASE)
            .matchEntire(value)
        if (rgb != null) {
            val r = rgb.groupValues[1].toInt().coerceIn(0, 255)
            val g = rgb.groupValues[2].toInt().coerceIn(0, 255)
            val b = rgb.groupValues[3].toInt().coerceIn(0, 255)
            val a = rgb.groupValues[4].takeIf { it.isNotBlank() }?.toFloatOrNull()?.coerceIn(0f, 1f)
            return if (a == null || a >= .999f) String.format("#%02X%02X%02X", r, g, b)
            else String.format("#%02X%02X%02X%02X", (a * 255).roundToInt(), r, g, b)
        }
        return value
    }

    private fun sanitizeOverrideValue(raw: String): String? {
        val value = raw.trim().take(220)
        if (value.isBlank()) return null
        val lower = value.lowercase()
        if (';' in value || '{' in value || '}' in value ||
            "javascript:" in lower || "expression(" in lower || "@import" in lower ||
            "url(" in lower) return null
        return value
    }

    private fun stripComments(css: String): String = css.replace(Regex("/\\*.*?\\*/", RegexOption.DOT_MATCHES_ALL), "")

    companion object {
        private val SAFE_VARIABLE = Regex("^--[A-Za-z0-9_-]+$")
        private val MAPPED_VARIABLES = setOf(
            "--background-primary", "--background-primary-alt", "--background-secondary", "--background-secondary-alt",
            "--background-modifier-border", "--background-modifier-border-hover", "--background-modifier-border-focus",
            "--background-modifier-hover", "--background-modifier-active-hover", "--background-modifier-form-field",
            "--text-normal", "--text-muted", "--text-faint", "--text-accent", "--text-accent-hover", "--text-on-accent",
            "--interactive-accent", "--interactive-accent-hover", "--color-accent", "--link-color", "--link-color-hover",
            "--h1-color", "--h2-color", "--h3-color", "--h4-color", "--h5-color", "--h6-color",
            "--tab-background", "--tab-background-active", "--tab-text-color", "--tab-text-color-active",
            "--tab-text-color-focused-active", "--tab-outline-color", "--tab-outline-width", "--tab-radius", "--tab-radius-active",
            "--ribbon-background", "--nav-item-background-active", "--nav-item-color", "--nav-item-color-active",
            "--nav-item-radius", "--titlebar-background", "--sidebar-background", "--status-bar-background",
            "--divider-color", "--radius-s", "--radius-m", "--radius-l", "--input-radius", "--button-radius",
            "--modal-radius", "--card-radius", "--image-radius", "--shadow-xs", "--shadow-s", "--shadow-l",
            "--font-text-size", "--font-ui-smaller", "--font-ui-small", "--font-ui-medium", "--font-ui-large",
            "--font-text-weight", "--font-interface-weight", "--line-height-normal", "--line-height",
            "--h1-size", "--h2-size", "--h3-size", "--h4-size", "--h5-size", "--h6-size",
            "--h1-weight", "--h2-weight", "--h3-weight", "--h4-weight", "--h5-weight", "--h6-weight",
            "--tag-color", "--tag-background", "--tag-border-color", "--tag-radius",
            "--blockquote-color", "--blockquote-border-color", "--blockquote-background-color",
            "--code-background", "--code-normal", "--table-border-color", "--table-header-background", "--table-row-background-hover",
            "--text-highlight-bg", "--text-selection", "--checkbox-color", "--checkbox-border-color", "--checkbox-radius",
            "--hr-color", "--metadata-background", "--metadata-label-text-color", "--metadata-divider-color", "--metadata-property-radius",
            "--embed-background", "--embed-title-color", "--embed-radius", "--footnote-divider-color",
            "--list-marker-color", "--checklist-done-color"
        )
        private val RECOGNIZED_SELECTOR_HINTS = listOf(
            ":root", ".theme-light", ".theme-dark", "body", ".app-container", ".workspace",
            ".workspace-tab", ".workspace-leaf", ".workspace-ribbon", ".side-dock", ".nav-",
            ".markdown-rendered", ".markdown-preview-view", ".markdown-reading-view", "#content",
            " h1", " h2", " h3", " h4", " h5", " h6", "blockquote", "table", "code", "pre",
            ".callout", ".tag", ".internal-link", ".external-link", "input[type=\"checkbox\"]",
            ".metadata-", ".frontmatter", ".markdown-embed", ".internal-embed", ".footnote", ".task-list-item",
            ".katex", ".mermaid"
        )
        private const val COMMUNITY_REGISTRY_URL =
            "https://raw.githubusercontent.com/obsidianmd/obsidian-releases/HEAD/community-css-themes.json"
        private val SAFE_REPO = Regex("^[A-Za-z0-9_.-]+/[A-Za-z0-9_.-]+$")
        private val SAFE_GIT_REF = Regex("^[A-Za-z0-9._/-]+$")
        private val SAFE_THEME_FILE = Regex("^[A-Za-z0-9_.-]+\\.(?:css|json)$", RegexOption.IGNORE_CASE)
        private val SAFE_THEME_VERSION = Regex("^[A-Za-z0-9._+-]+$")
        private const val MAX_REPO_METADATA_BYTES = 512L * 1024L
        private const val MAX_REPO_ARCHIVE_BYTES = 24L * 1024L * 1024L
        private const val MAX_REGISTRY_BYTES = 2L * 1024L * 1024L
        private const val MAX_MANIFEST_BYTES = 256L * 1024L
        private const val MAX_CSS_BYTES = 5L * 1024L * 1024L
        private const val MAX_ENTRY_BYTES = 8L * 1024L * 1024L
        private const val MAX_PACKAGE_BYTES = 32L * 1024L * 1024L
        private const val MAX_INLINE_ASSET_BYTES = 2L * 1024L * 1024L
        private val RETRYABLE_HTTP_CODES = setOf(408, 425, 429, 500, 502, 503, 504)
        private val RETRY_BACKOFF_MS = longArrayOf(700L, 1_500L, 3_000L, 5_000L)
    }
}
