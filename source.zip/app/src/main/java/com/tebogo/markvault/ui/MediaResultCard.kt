package com.tebogo.markvault.ui

import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.focusable
import androidx.compose.foundation.background
import androidx.compose.foundation.basicMarquee
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.focus.onFocusChanged
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import com.tebogo.markvault.data.MediaItem

/** Format ms → "28:30" */
private fun formatMediaDuration(ms: Long): String {
    if (ms <= 0) return ""
    val total = ms / 1000
    val h = total / 3600
    val m = (total % 3600) / 60
    val s = total % 60
    return if (h > 0) "%d:%02d:%02d".format(h, m, s) else "%d:%02d".format(m, s)
}

/**
 * v5.4.250cc — Format an upload-date epoch-millis value → "12 Aug 2026".
 * Empty string for 0/unknown (older cached rows from before this field
 * existed, or a source with no publish date) so the metadata row simply
 * omits the date rather than showing a misleading "1 Jan 1970".
 */
private fun formatUploadDate(ms: Long): String {
    if (ms <= 0) return ""
    return runCatching {
        java.time.Instant.ofEpochMilli(ms)
            .atZone(java.time.ZoneId.systemDefault())
            .toLocalDate()
            .format(java.time.format.DateTimeFormatter.ofPattern("d MMM yyyy"))
    }.getOrDefault("")
}

/**
 * v5.4.212cc — Card shown for a JW.org media item in search results.
 * Shows thumbnail, title, duration, and a Play button.
 *
 * v5.4.254cc — onToggleFavourite is nullable and defaults to null so
 * every existing call site (JwVideoBrowseScreen, HomeScreen) compiles
 * unchanged; passing a non-null callback shows a star toggle in the
 * card's top-right corner.
 *
 * v5.4.255cc — onLongPress, same nullable-default pattern: long-pressing
 * the card (anywhere on it, not just the star) triggers it — screens
 * wire this to show MediaLongPressMenu (Favourite + Add to Playlist).
 */
@OptIn(ExperimentalFoundationApi::class)
@Composable
fun MediaResultCard(
    item: MediaItem,
    onPlay: () -> Unit,
    modifier: Modifier = Modifier,
    onToggleFavourite: (() -> Unit)? = null,
    onLongPress: (() -> Unit)? = null,
    tabletPosterLayout: Boolean = false,
    tvFriendly: Boolean = false
) {
    var hasTvFocus by remember { mutableStateOf(false) }
    Card(
        modifier = modifier
            .fillMaxWidth()
            .onFocusChanged { hasTvFocus = it.isFocused }
            .focusable(enabled = tvFriendly)
            .combinedClickable(
                onClick = onPlay,
                onLongClick = onLongPress
            ),
        shape = RoundedCornerShape(obsidianUiDp(10.dp, "--radius-m", "--card-radius")),
        border = if (tvFriendly && hasTvFocus) BorderStroke(3.dp, MaterialTheme.colorScheme.primary) else null,
        elevation = CardDefaults.cardElevation(defaultElevation = if (tvFriendly && hasTvFocus) 8.dp else obsidianUiElevation(2.dp, "--shadow-s", "--shadow-xs"))
    ) {
        if (tabletPosterLayout) {
            // v5.4.324cc — Tablet media card: large, stable 16:9 artwork with
            // metadata and an infinitely scrolling single-line title underneath.
            // The image never stretches when Workspace side panels open.
            Column(Modifier.fillMaxWidth().padding(6.dp)) {
                Box(Modifier.fillMaxWidth().aspectRatio(16f / 9f)) {
                    if (item.thumbnailUrl.isNotBlank()) {
                        AsyncImage(
                            model = item.thumbnailUrl, contentDescription = item.title,
                            contentScale = ContentScale.Crop,
                            modifier = Modifier.fillMaxSize().clip(RoundedCornerShape(obsidianUiDp(8.dp, "--image-radius", "--radius-m")))
                        )
                    } else {
                        Box(
                            Modifier.fillMaxSize().clip(RoundedCornerShape(obsidianUiDp(8.dp, "--image-radius", "--radius-m")))
                                .background(MaterialTheme.colorScheme.surfaceVariant),
                            contentAlignment = Alignment.Center
                        ) { Text(if (item.mediaType == "audio") "🎵" else "🎬", fontSize = 34.sp) }
                    }
                    if (onToggleFavourite != null) {
                        Surface(
                            modifier = Modifier.align(Alignment.TopEnd).padding(4.dp),
                            shape = RoundedCornerShape(16.dp),
                            color = MaterialTheme.colorScheme.surface.copy(alpha = 0.86f)
                        ) {
                            IconButton(onClick = onToggleFavourite, modifier = Modifier.size(32.dp)) {
                                Text(if (item.isFavourite == 1) "⭐" else "☆", fontSize = 17.sp)
                            }
                        }
                    }
                }
                Spacer(Modifier.height(5.dp))
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(if (item.mediaType == "audio") "🎵 AUDIO" else "🎬 VIDEO",
                        fontSize = 10.sp, fontWeight = FontWeight.SemiBold, color = MaterialTheme.colorScheme.primary)
                    val duration = formatMediaDuration(item.durationMs)
                    if (duration.isNotBlank()) {
                        Spacer(Modifier.width(7.dp)); Text("· $duration", fontSize = 10.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                    val date = formatUploadDate(item.uploadDate)
                    if (date.isNotBlank()) {
                        Spacer(Modifier.width(7.dp)); Text("· $date", fontSize = 10.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                }
                Spacer(Modifier.height(3.dp))
                Text(
                    item.title,
                    modifier = Modifier.fillMaxWidth().basicMarquee(iterations = Int.MAX_VALUE),
                    maxLines = 1, softWrap = false,
                    fontWeight = FontWeight.Medium, fontSize = 12.sp
                )
                if (item.description.isNotBlank()) {
                    Text(
                        item.description, fontSize = 11.sp, maxLines = 2,
                        overflow = TextOverflow.Ellipsis,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
                if (item.scriptureRefs.isNotBlank()) {
                    Text("📖 ${item.scriptureRefs}", fontSize = 10.sp,
                        color = MaterialTheme.colorScheme.primary, maxLines = 1, overflow = TextOverflow.Ellipsis)
                }
            }
        } else Box {
            Row(
                modifier = Modifier.padding(10.dp),
                verticalAlignment = Alignment.Top,
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                // Thumbnail
                if (item.thumbnailUrl.isNotBlank()) {
                    AsyncImage(
                        model = item.thumbnailUrl,
                        contentDescription = null,
                        contentScale = ContentScale.Crop,
                        modifier = Modifier
                            .size(width = 100.dp, height = 64.dp)
                            .clip(RoundedCornerShape(obsidianUiDp(6.dp, "--image-radius", "--radius-s")))
                    )
                } else {
                    Box(
                        modifier = Modifier
                            .size(width = 100.dp, height = 64.dp)
                            .clip(RoundedCornerShape(obsidianUiDp(6.dp, "--image-radius", "--radius-s")))
                            .background(MaterialTheme.colorScheme.surfaceVariant),
                        contentAlignment = Alignment.Center
                    ) {
                        Text(if (item.mediaType == "audio") "🎵" else "🎬", fontSize = 28.sp)
                    }
                }

                // Info
                Column(modifier = Modifier.weight(1f)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text(
                            if (item.mediaType == "audio") "🎵" else "🎬",
                            fontSize = 12.sp
                        )
                        Spacer(Modifier.width(4.dp))
                        Text(
                            item.mediaType.uppercase(),
                            fontSize = 10.sp,
                            color = MaterialTheme.colorScheme.primary,
                            fontWeight = FontWeight.SemiBold
                        )
                        if (item.durationMs > 0) {
                            Spacer(Modifier.width(6.dp))
                            Text(
                                formatMediaDuration(item.durationMs),
                                fontSize = 10.sp,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                        // v5.4.250cc — Upload date, when known.
                        val uploadDateLabel = formatUploadDate(item.uploadDate)
                        if (uploadDateLabel.isNotBlank()) {
                            Spacer(Modifier.width(6.dp))
                            Text(
                                "\u00B7 $uploadDateLabel",
                                fontSize = 10.sp,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                        if (onToggleFavourite != null) {
                            // Reserve space so the title/description column
                            // doesn't run under the star button below.
                            Spacer(Modifier.width(28.dp))
                        }
                    }
                    Spacer(Modifier.height(3.dp))
                    Text(
                        item.title,
                        fontWeight = FontWeight.Medium,
                        fontSize = 13.sp,
                        maxLines = 2,
                        overflow = TextOverflow.Ellipsis
                    )
                    if (item.description.isNotBlank()) {
                        Text(
                            item.description,
                            fontSize = 11.sp,
                            maxLines = 2,
                            overflow = TextOverflow.Ellipsis,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                    if (item.scriptureRefs.isNotBlank()) {
                        Text(
                            "📖 ${item.scriptureRefs}",
                            fontSize = 10.sp,
                            color = MaterialTheme.colorScheme.primary,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis
                        )
                    }
                }
            }
            // v5.4.254cc — Favourite star, top-right corner overlay —
            // doesn't disturb the existing Row layout above at all.
            if (onToggleFavourite != null) {
                IconButton(
                    onClick = onToggleFavourite,
                    modifier = Modifier.align(Alignment.TopEnd).size(32.dp)
                ) {
                    Text(
                        if (item.isFavourite == 1) "\u2B50" else "\u2606",
                        fontSize = 16.sp
                    )
                }
            }
        }
    }
}
