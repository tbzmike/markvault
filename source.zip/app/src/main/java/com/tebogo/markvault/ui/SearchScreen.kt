package com.tebogo.markvault.ui

import androidx.compose.foundation.clickable
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.foundation.border
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.background
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.DropdownMenu
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.derivedStateOf
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.compose.runtime.remember
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.SpanStyle
import androidx.compose.ui.text.buildAnnotatedString
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.text.withStyle
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.navigation.NavController
import com.tebogo.markvault.AppViewModel
import com.tebogo.markvault.SearchMode
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.material3.VerticalDivider

@OptIn(ExperimentalMaterial3Api::class, ExperimentalFoundationApi::class)
@Composable
fun SearchScreen(vm: AppViewModel, nav: NavController) {
    val query by vm.query.collectAsStateWithLifecycle()
    val mode by vm.mode.collectAsStateWithLifecycle()
    val quotePhrase by vm.quotePhrase.collectAsStateWithLifecycle()
    // v5.4.146cc — Needed in onValueChange to cancel in-flight searches
    // on keystroke when live search is OFF.
    val liveSearchEnabled by vm.liveSearchEnabled.collectAsStateWithLifecycle()
    val isSearchBusy by vm.searchBusy.collectAsStateWithLifecycle()

    // v5.4.13 — Auto-wrap the search query in quotes when the exact-phrase
    // toggle is enabled (and unwrap when it's disabled). This makes the
    // search field visibly reflect the toggle state, restoring the old
    // behaviour the user expected. Without this, enabling the toggle
    // changed nothing visible — search was still wrapping internally, but
    // the lack of any UI feedback made it feel like the toggle did
    // nothing.
    //
    // Guarded against feedback loops: we only write back when the
    // expected wrapped form differs from the current value, so writing
    // the same value doesn't trigger another LaunchedEffect run.
    LaunchedEffect(quotePhrase) {
        val current = query.trim()
        if (current.length < 2) return@LaunchedEffect
        val alreadyQuoted = current.startsWith("\"") && current.endsWith("\"")
        val newValue = when {
            quotePhrase && !alreadyQuoted -> "\"$current\""
            !quotePhrase && alreadyQuoted -> current.removeSurrounding("\"")
            else -> current
        }
        if (newValue != query) {
            vm.query.value = newValue
        }
    }
    val results by vm.results.collectAsStateWithLifecycle()
    // v5.4.6 — Manual rerank overlay. If the user has tapped the
    // "Rerank these results" button and the rerank applies to the
    // current query, we render the reranked order instead of the base
    // results. The check is just a string-equality on the query — if
    // the user types more, the overlay's query stops matching and the
    // base results take over.
    val manualRerank by vm.manualRerankResult.collectAsStateWithLifecycle()
    val manualRerankBusy by vm.manualRerankInProgress.collectAsStateWithLifecycle()
    val rerankerInstalled by vm.rerankerInstalled.collectAsStateWithLifecycle()
    // v5.4.77cc — Which hit ids in the current results appeared only
    // through LLM-paraphrased sub-queries (never via the original
    // tokens or Kotlin synonym expander). Read from the VM's
    // side-channel StateFlow instead of a field on SearchHit so
    // SearchHit stays a pure DB projection (avoids Room 2.8.4 KSP
    // strictness). Painted as the "✨ AI" chip on the matching rows.
    val llmMatchedIds by vm.llmMatchedHitIds.collectAsStateWithLifecycle()
    // v5.4.79cc — Master AI multi-query toggle state, driving the
    // pumping-brain button at the right edge of the search bar. When on,
    // the brain animates (indicates the LLM is available to think about
    // this query) and every submitted search is routed through the
    // expander. When off, the brain sits static/dim and search behaves
    // as pure FTS + BGE semantic + reranker.
    val aiLlmOn by vm.aiLlmSearchEnabled.collectAsStateWithLifecycle()
    val displayedResults: List<com.tebogo.markvault.data.SearchHit> = manualRerank?.let { (rq, rhits) ->
        if (rq == query.trim()) rhits else null
    } ?: results
    // v5.4.6 / v5.4.141cc — Manual rerank button is visible whenever:
    //   • the reranker model is installed
    //   • there are results to rerank
    //   • the query is long enough (≥ 2 chars)
    //   • the current view isn't already the manual-rerank output for this query
    // The previous guard `&& (!rerankEnabled || rerankSubmitOnly)` permanently hid
    // the button when auto-rerank was fully enabled, making it unreachable. Removed.
    val showManualRerankButton: Boolean = rerankerInstalled
        && displayedResults.isNotEmpty()
        && query.trim().length >= 2
        && manualRerank?.first != query.trim()
    val topicMatches by vm.topicMatches.collectAsStateWithLifecycle()
    val recentSearches by vm.recentSearches.collectAsStateWithLifecycle()

    // v5.4.111cc — "Get accurate results" chip flash driver. The
    // animatable pulses 0→1→0 three times whenever a search completes
    // (searchBusy transitions from true to false with results present),
    // producing the green-tint + slight-scale pulse without hiding the
    // chip. The chip reads `accurateFlashPulse` for its container
    // colour + scale. Guarded so it only fires on a genuine
    // busy→done transition, not on every recomposition.
    val accurateFlash = remember { androidx.compose.animation.core.Animatable(0f) }
    val accurateFlashPulse = accurateFlash.value
    val searchBusyForFlash by vm.searchBusy.collectAsStateWithLifecycle()
    var prevSearchBusy by remember { mutableStateOf(false) }
    LaunchedEffect(searchBusyForFlash) {
        // Detect the falling edge: was busy, now idle.
        if (prevSearchBusy && !searchBusyForFlash) {
            // Only flash if there's something to celebrate — i.e. the
            // query is a real search, not a cleared box.
            if (vm.query.value.trim().length >= 2) {
                accurateFlash.snapTo(0f)
                repeat(3) {
                    accurateFlash.animateTo(
                        1f,
                        animationSpec = androidx.compose.animation.core.tween(
                            220, easing = androidx.compose.animation.core.FastOutSlowInEasing
                        )
                    )
                    accurateFlash.animateTo(
                        0f,
                        animationSpec = androidx.compose.animation.core.tween(
                            260, easing = androidx.compose.animation.core.FastOutSlowInEasing
                        )
                    )
                }
            }
        }
        prevSearchBusy = searchBusyForFlash
    }

    // v5.4.111cc — Collapsible "top utilities" (search bar + mode
    // segments + chip row). Two ways to reclaim vertical space for
    // results:
    //   • Auto-hide on scroll: scrolling the results list DOWN
    //     collapses them; scrolling UP (even a little) or reaching the
    //     top brings them back. Standard reading-app pattern.
    //   • Manual handle: a slim always-visible bar with a chevron the
    //     user can tap to force-collapse / force-expand regardless of
    //     scroll.
    // The hoisted LazyListState drives the auto behaviour; a manual
    // override flag takes precedence when the user taps the handle.
    val resultsListState = androidx.compose.foundation.lazy.rememberLazyListState()
    var topUtilitiesExpanded by remember { mutableStateOf(true) }
    // Manual override: null = follow scroll; true/false = user forced.
    var manualOverride by remember { mutableStateOf<Boolean?>(null) }
    // Track scroll to auto-collapse. We watch firstVisibleItemIndex +
    // scrollOffset to infer direction.
    var lastScrollIndex by remember { mutableStateOf(0) }
    var lastScrollOffset by remember { mutableStateOf(0) }
    // v5.4.145cc — Fullscreen mode toggle: when OFF (default), utilities
    // always show. When ON, they hide/show with scroll.
    val enableFullscreenMode by vm.enableFullscreenMode.collectAsStateWithLifecycle()
    
    LaunchedEffect(
        resultsListState.firstVisibleItemIndex,
        resultsListState.firstVisibleItemScrollOffset,
        enableFullscreenMode
    ) {
        val idx = resultsListState.firstVisibleItemIndex
        val off = resultsListState.firstVisibleItemScrollOffset
        val scrolledDown = idx > lastScrollIndex ||
            (idx == lastScrollIndex && off > lastScrollOffset + 8)
        val scrolledUp = idx < lastScrollIndex ||
            (idx == lastScrollIndex && off < lastScrollOffset - 8)
        val atTop = idx == 0 && off < 4
        
        // Only apply scroll-driven hiding if fullscreen mode is enabled
        if (enableFullscreenMode) {
            // Any deliberate scroll clears the manual override so the auto
            // behaviour resumes — the manual handle is a one-shot nudge,
            // not a permanent lock.
            if (scrolledDown && topUtilitiesExpanded && !atTop) {
                topUtilitiesExpanded = false
                manualOverride = null
            } else if ((scrolledUp || atTop) && !topUtilitiesExpanded) {
                topUtilitiesExpanded = true
                manualOverride = null
            }
        } else {
            // When fullscreen mode is OFF, always keep utilities visible
            topUtilitiesExpanded = true
            manualOverride = null
        }
        lastScrollIndex = idx
        lastScrollOffset = off
    }
    // Manual override wins when set.
    val showTopUtilities = manualOverride ?: topUtilitiesExpanded

    // v5.3.1 — Read keyword-filter pref at the top so it's available to
    // the LazyListScope content block (which is NOT @Composable and
    // can't call collectAsStateWithLifecycle itself).
    val keywordFilterOn by vm.keywordFilterEnabled.collectAsStateWithLifecycle()
    val focus = remember { FocusRequester() }

    // v4.7 — long-press on a search result triggers an action sheet (open in
    // split, open externally, share, convert, open in graph).
    var longPressTarget by remember { mutableStateOf<SearchHit?>(null) }
    // Split-view picker: after user picks "Open in split view", we show a
    // dialog listing every OTHER open tab to pair this one with.
    var splitPickerTarget by remember { mutableStateOf<SearchHit?>(null) }
    // Convert-to dialog: user chose "Convert" → asks which target format.
    var convertTarget by remember { mutableStateOf<SearchHit?>(null) }

    // TASK 5: if the user opened Search via "Search in MarkVault" from the
    // browser's text-selection menu, consume that pending query exactly once.
    LaunchedEffect(Unit) {
        vm.consumePendingSearch()?.let { vm.query.value = it }
    }

    // v5.4.33 — Detect tablet+workspace before Scaffold so TopAppBar
    // can be hidden (vertical space is precious in landscape).
    val screenWidthDp = androidx.compose.ui.platform.LocalConfiguration.current.screenWidthDp
    val isTabletWidth = screenWidthDp >= 600
    val uiModeSearch by vm.uiMode.collectAsStateWithLifecycle()
    val hideTopBar = uiModeSearch == "workspace" && isTabletWidth

    Scaffold(
        topBar = {
            // v5.4.207cc — Column wrapper: TopAppBar + full-width dual strip below it.
            // The strip is NOT inside the TopAppBar measurement, so it never gets
            // constrained by the title slot and can display full chunk numbers.
            Column {
            if (!hideTopBar) {
            var modelMenuExpanded by remember { mutableStateOf(false) }

            TopAppBar(
                title = {
                    // v4.9.0 — semantic-search active indicator (green dot when on
                    // AND embeddings exist, white circle otherwise).
                    // v4.9.1 — added compact model short-name next to the dot so
                    // the user sees at a glance which embedding model is in use.
                    val semOn by vm.semanticEnabled.collectAsStateWithLifecycle()
                    val embedReady by vm.embeddingCount.collectAsStateWithLifecycle()
                    val activeId by vm.activeModelId.collectAsStateWithLifecycle()
                    val active = vm.availableModels.firstOrNull { it.id == activeId }
                    var modelMenuExpanded by remember { mutableStateOf(false) }
                    val dot = if (semOn && embedReady > 0) "\uD83D\uDFE2" else "\u26AA"
                    // v5.4.145cc — Hide embedding selector if user disables it
                    val hideEmbeddingSelector by vm.hideEmbeddingSelector.collectAsStateWithLifecycle()
                    // Title: just the search indicator and model selector.
                    // The dual LED strip lives BELOW the TopAppBar (full-width, no clipping).
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text("\uD83D\uDD0D Search  $dot")
                        if (!hideEmbeddingSelector && semOn && embedReady > 0 && active != null) {
                            androidx.compose.foundation.layout.Spacer(Modifier.width(8.dp))
                            Text(
                                active.shortName + " ▾",
                                fontSize = 11.sp,
                                color = androidx.compose.material3.MaterialTheme
                                    .colorScheme.onSurfaceVariant,
                                modifier = Modifier.clickable { modelMenuExpanded = true }
                            )
                            DropdownMenu(
                                expanded = modelMenuExpanded,
                                onDismissRequest = { modelMenuExpanded = false }
                            ) {
                                vm.availableModels.forEach { model ->
                                    DropdownMenuItem(
                                        text = { Text(model.shortName) },
                                        onClick = {
                                            vm.setActiveModelId(model.id)
                                            modelMenuExpanded = false
                                        }
                                    )
                                }
                            }
                        }
                    }
                },
                // v4.24.0 — Live percentage progress indicator. Shows
                // while the cross-encoder is busy scoring candidate
                // documents (a 3–5 s pass per search). When idle, nothing
                // displays. Useful so the user knows the app is still
                // working and roughly how much longer they'll wait.
                actions = {
                    val rerankPct     by vm.rerankProgress.collectAsStateWithLifecycle()
                    val showRerankPct by vm.showRerankProgress.collectAsStateWithLifecycle()
                    // Dual LED panel is now in the title Row (no clipping from actions slot).
                    if (rerankPct != null && showRerankPct) {
                        val pct = (rerankPct!! * 100).toInt().coerceIn(0, 100)
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            modifier = Modifier.padding(end = 12.dp)
                        ) {
                            androidx.compose.material3.CircularProgressIndicator(
                                progress = { rerankPct!! },
                                modifier = Modifier.width(16.dp).height(16.dp),
                                strokeWidth = 2.dp
                            )
                            androidx.compose.foundation.layout.Spacer(Modifier.width(6.dp))
                            Text(
                                "$pct%",
                                fontSize = 11.sp,
                                fontWeight = FontWeight.SemiBold,
                                color = androidx.compose.material3.MaterialTheme
                                    .colorScheme.onSurfaceVariant
                            )
                        }
                    }
                }
            )
            } // end if (!hideTopBar)

            // v5.4.207cc — Full-width dual strip. Outside TopAppBar = full screen width, no clipping.
            val dualStripOn   by vm.semanticDualMode.collectAsStateWithLifecycle()
            val semStripOn    by vm.semanticEnabled.collectAsStateWithLifecycle()
            val embedStripRdy by vm.embeddingCount.collectAsStateWithLifecycle()
            val firstChunksS  by vm.firstScopeChunks.collectAsStateWithLifecycle()
            val secondChunksS by vm.secondScopeChunks.collectAsStateWithLifecycle()
            val loadingScopeS by vm.loadingScope.collectAsStateWithLifecycle()
            if (semStripOn && embedStripRdy > 0) {
                val fmtFirst  = if (firstChunksS  > 0) "%,d".format(firstChunksS)  else null
                val fmtSecond = if (secondChunksS > 0) "%,d".format(secondChunksS) else null
                val fmtTotal  = if (firstChunksS  > 0 && secondChunksS > 0)
                    "%,d".format(firstChunksS + secondChunksS) else null
                val stripText = when {
                    loadingScopeS == "first20k"  ->
                        "\u26A1 Dual  \u00B7  \u23F3 Loading 1st 20k\u2026"
                    loadingScopeS == "second20k" && fmtFirst != null ->
                        "\u26A1 Dual  \u00B7  1st: $fmtFirst  \u00B7  \u23F3 Loading 2nd\u2026"
                    loadingScopeS == "second20k" ->
                        "\u26A1 Dual  \u00B7  \u23F3 Loading 2nd batch\u2026"
                    fmtFirst != null && fmtSecond != null ->
                        "\u26A1 Dual  \u00B7  1st: $fmtFirst  \u00B7  2nd: $fmtSecond  =  $fmtTotal"
                    fmtFirst != null ->
                        "\u26A1 Dual  \u00B7  1st: $fmtFirst  \u00B7  2nd: \u23F3"
                    dualStripOn -> "\u26A1 Dual ON  \u2014  search to load scopes"
                    else        -> "\u26A1 Dual  \u2014  tap to enable"
                }
                androidx.compose.material3.Surface(
                    color = if (dualStripOn)
                        MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.7f)
                    else
                        MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.45f),
                    modifier = Modifier.fillMaxWidth()
                        .clickable { vm.setSemanticDualMode(!dualStripOn) }
                ) {
                    Text(
                        stripText,
                        fontSize = 10.sp,
                        fontWeight = if (dualStripOn) FontWeight.SemiBold else FontWeight.Normal,
                        color = if (dualStripOn)
                            MaterialTheme.colorScheme.primary
                        else
                            MaterialTheme.colorScheme.onSurfaceVariant,
                        modifier = Modifier.padding(horizontal = 12.dp, vertical = 5.dp)
                    )
                }
            }
            } // end Column
        },
        bottomBar = {
            // v5.4.148cc — Instant bottom toolbar visibility (no animation delay)
            val enableFullscreenMode by vm.enableFullscreenMode.collectAsStateWithLifecycle()
            val bottomBarVisible = if (enableFullscreenMode) showTopUtilities else true
            if (bottomBarVisible) {
                MarkVaultBottomBar(nav = nav, vm = vm)
            }
        }
    ) { pad ->
        // v5.4.30 — Tablet 2-column split.
        val leftColWidth = 280.dp

        Row(Modifier.padding(pad).fillMaxSize()) {
            if (isTabletWidth) {
                SearchTabletRecentsPanel(
                    vm = vm,
                    recentSearches = recentSearches,
                    modifier = Modifier.width(leftColWidth).fillMaxHeight()
                )
                androidx.compose.material3.VerticalDivider()
            }
            Column(Modifier.weight(1f).fillMaxHeight()) {
            // v5.4.111cc — Collapsible top utilities. AnimatedVisibility
            // wraps the search bar + mode segments + chip row so they
            // slide away on scroll-down and return on scroll-up. See the
            // showTopUtilities driver above.
            //
            // v5.4.145cc — Search bar visibility now controlled by both
            // showTopUtilities (scroll-driven) and hideSearchBarOnScroll toggle.
            // When hideSearchBarOnScroll is OFF (default), search bar always shows.
            // When ON, search bar hides with scroll like the other elements.
            val hideSearchBarOnScroll by vm.hideSearchBarOnScroll.collectAsStateWithLifecycle()
            val searchBarVisible = if (hideSearchBarOnScroll) showTopUtilities else true
            
            androidx.compose.animation.AnimatedVisibility(visible = searchBarVisible) {
            OutlinedTextField(
                value = query,
                onValueChange = {
                    // v5.4.146cc — When live search is OFF and a submit-driven
                    // search is in flight, cancel it the moment the user types.
                    // This stops the expensive embedding / rerank / LLM pipeline
                    // immediately; results stay visible (cancel handler returns
                    // the last known set). The user can now compose their next
                    // query and press Enter/Search when ready.
                    if (!liveSearchEnabled && isSearchBusy) {
                        vm.cancelCurrentSearch()
                    }
                    vm.query.value = it
                },
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(
                        horizontal = if (isTabletWidth) 6.dp else 16.dp,
                        vertical = if (isTabletWidth) 2.dp else 8.dp
                    )
                    .focusRequester(focus),
                placeholder = {
                    Text(
                        if (mode == SearchMode.TITLES) "Search note names\u2026"
                        else "Search inside all notes\u2026"
                    )
                },
                singleLine = true,
                // v5.4.1 — Keyboard "Search" action fires submitSearch() so
                // users can deliberately trigger a search even when live
                // search is disabled in Settings.
                keyboardOptions = androidx.compose.foundation.text.KeyboardOptions(
                    imeAction = androidx.compose.ui.text.input.ImeAction.Search
                ),
                keyboardActions = androidx.compose.foundation.text.KeyboardActions(
                    onSearch = { vm.submitSearch() }
                ),
                trailingIcon = {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        // v5.4.79cc — Pumping-brain toggle for AI
                        // multi-query retrieval. When on, the brain
                        // pulses to signal "the LLM is thinking about
                        // this query"; when off, it sits dim and
                        // static. Tap flips
                        // [AppViewModel.setAiLlmSearchEnabled], same
                        // preference the Settings-screen switch writes
                        // to, so both surfaces stay in sync.
                        PumpingBrainToggle(
                            active = aiLlmOn,
                            onToggle = { vm.setAiLlmSearchEnabled(!aiLlmOn) }
                        )
                        if (query.isNotEmpty()) {
                            IconButton(onClick = { vm.query.value = "" }) {
                                Icon(Icons.Default.Close, contentDescription = "Clear")
                            }
                        }
                        // v5.4.1 — Always-visible submit button. Same effect
                        // as the keyboard's Search action but reachable
                        // without opening the IME. Especially useful when
                        // Live search is OFF.
                        IconButton(onClick = { vm.submitSearch() }) {
                            Icon(Icons.Default.Search, contentDescription = "Run search")
                        }
                    }
                }
            )
            LaunchedEffect(Unit) { focus.requestFocus() }
            } // end search bar AnimatedVisibility
            
            // v5.4.111cc — Segments and chip row hide/show with scroll
            androidx.compose.animation.AnimatedVisibility(visible = showTopUtilities) {
            Column(Modifier.fillMaxWidth()) {
            ShallowDeepToggle(
                mode = mode,
                onModeChange = { vm.mode.value = it },
                modifier = Modifier.fillMaxWidth().padding(horizontal = if (isTabletWidth) 6.dp else 16.dp)
            )

            // v5.4.33 — All filter chips in one compact scrollable row
            // to eliminate wasted vertical space. Semantic, Rerank,
            // progress toggles, and exact-phrase all sit side by side.
            //
            // v5.4.111cc — Each chip is now individually hidable via
            // Settings (chipSemantic / chipRerank / chipRerankPct /
            // chipSemanticPct / chipAccurate — all default ON). The
            // "exact phrase" chip was renamed to "Get accurate
            // results" (label only — the underlying quotePhrase
            // toggle and its exact-phrase FTS behaviour are
            // unchanged), and flashes green + slightly larger for a
            // few seconds after results land.
            //
            // v5.4.145cc — Entire chip row can be hidden via Settings
            // (hideSearchChips toggle).
            val hideSearchChips by vm.hideSearchChips.collectAsStateWithLifecycle()
            if (!hideSearchChips) {
            run {
                val semOnRow by vm.semanticEnabled.collectAsStateWithLifecycle()
                val rerankInstalled by vm.rerankerInstalled.collectAsStateWithLifecycle()
                val rerankOn by vm.rerankEnabled.collectAsStateWithLifecycle()
                val rerankBusy by vm.rerankActive.collectAsStateWithLifecycle()
                val showRerankPctChip by vm.showRerankProgress.collectAsStateWithLifecycle()
                val showSemPctChip by vm.showSemanticProgress.collectAsStateWithLifecycle()
                // Visibility toggles.
                val vChipSemantic by vm.chipSemantic.collectAsStateWithLifecycle()
                val vChipRerank by vm.chipRerank.collectAsStateWithLifecycle()
                val vChipRerankPct by vm.chipRerankPct.collectAsStateWithLifecycle()
                val vChipSemanticPct by vm.chipSemanticPct.collectAsStateWithLifecycle()
                val vChipAccurate by vm.chipAccurate.collectAsStateWithLifecycle()
                // v5.4.193cc — Two dynamic scope chips.
                // 1st 20k  = most recently modified 20k articles (fixed).
                // 2nd batch = ALL articles beyond the first 20k (no upper cap).
                //   Label shows actual count so the user sees e.g. "30k" when
                //   the library grows to 50k total articles.
                val semanticScope by vm.semanticScope.collectAsStateWithLifecycle()
                // v5.4.196cc — Dual mode toggle (must be at composable scope).
                val semanticDualMode by vm.semanticDualMode.collectAsStateWithLifecycle()

                // Compute second-batch count from total embedded article count.
                var totalEmbeddedArticles by remember { mutableStateOf(0) }
                LaunchedEffect(Unit) {
                    totalEmbeddedArticles = vm.distinctEmbeddedNoteCount()
                }
                val secondBatchCount = maxOf(0, totalEmbeddedArticles - 20_000)
                val secondLabel = when {
                    secondBatchCount >= 1_000 -> "\uD83D\uDCDA 2nd ${secondBatchCount / 1_000}k"
                    secondBatchCount > 0      -> "\uD83D\uDCDA 2nd ${secondBatchCount}"
                    else                      -> "\uD83D\uDCDA 2nd batch"
                }

                LazyRow(
                    Modifier
                        .fillMaxWidth()
                        .padding(vertical = 2.dp),
                    horizontalArrangement = Arrangement.spacedBy(6.dp),
                    contentPadding = PaddingValues(horizontal = if (isTabletWidth) 6.dp else 14.dp)
                ) {
                    if (vChipSemantic) {
                        item {
                            androidx.compose.material3.FilterChip(
                                selected = semOnRow,
                                onClick = { vm.setSemanticEnabled(!semOnRow) },
                                label = {
                                    Text(
                                        if (semOnRow) "\uD83E\uDDE0 Semantic ON" else "\uD83E\uDDE0 OFF",
                                        fontSize = 11.sp
                                    )
                                }
                            )
                        }
                    }
                    if (vChipRerank) {
                        item {
                            if (rerankInstalled) {
                                androidx.compose.material3.FilterChip(
                                    selected = rerankOn,
                                    onClick = { vm.setRerankEnabled(!rerankOn) },
                                    label = {
                                        Text(
                                            if (rerankOn) "\uD83C\uDFAF Rerank ON" else "\uD83C\uDFAF OFF",
                                            fontSize = 11.sp
                                        )
                                    }
                                )
                            } else {
                                androidx.compose.material3.FilterChip(
                                    selected = false,
                                    onClick = { nav.navigate("settings") },
                                    label = { Text("\uD83C\uDFAF Install rerank", fontSize = 11.sp) }
                                )
                            }
                        }
                    }
                    if (rerankBusy) {
                        item {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                androidx.compose.material3.CircularProgressIndicator(
                                    modifier = Modifier.width(14.dp).height(14.dp),
                                    strokeWidth = 2.dp
                                )
                                Spacer(Modifier.width(4.dp))
                                Text("Reranking\u2026", fontSize = 10.sp,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant)
                            }
                        }
                    }
                    if (vChipRerankPct) {
                        item {
                            androidx.compose.material3.FilterChip(
                                selected = showRerankPctChip,
                                onClick = { vm.setShowRerankProgress(!showRerankPctChip) },
                                label = { Text(if (showRerankPctChip) "Rerank %" else "Rerank % off", fontSize = 10.sp) }
                            )
                        }
                    }
                    if (vChipSemanticPct) {
                        item {
                            androidx.compose.material3.FilterChip(
                                selected = showSemPctChip,
                                onClick = { vm.setShowSemanticProgress(!showSemPctChip) },
                                label = { Text(if (showSemPctChip) "Semantic %" else "Semantic % off", fontSize = 10.sp) }
                            )
                        }
                    }
                    // v5.4.186cc — Semantic scope selector. Shows when semantic
                    // is ON. Lets the user pick how many articles are included
                    // in the semantic index: 5k / 10k / 20k / All. Choosing a
                    // larger scope gives better recall but slower first search
                    // (index builds on demand, cached for the session).
                    if (semOnRow) {
                        val scopeOptions = listOf(
                            "first20k"  to "\uD83D\uDCDA 1st 20k",
                            "second20k" to secondLabel,
                            "all"       to "\uD83D\uDCDA All notes"
                        )
                        scopeOptions.forEach { (mode, label) ->
                            item {
                                androidx.compose.material3.FilterChip(
                                    selected = semanticScope == mode && !semanticDualMode,
                                    onClick  = {
                                        if (semanticDualMode) vm.setSemanticDualMode(false)
                                        vm.setSemanticScope(mode)
                                    },
                                    label    = { Text(label, fontSize = 11.sp) }
                                )
                            }
                        }
                        // Status chip — shows loading / loaded / idle state.
                        item {
                            val loadStatus by vm.scopeLoadStatus.collectAsStateWithLifecycle()
                            val warming   by vm.semanticIndexWarming.collectAsStateWithLifecycle()
                            val dualActive = semanticDualMode
                            val scopeLabel = when {
                                dualActive                        -> "1st + 2nd"
                                semanticScope == "first20k"       -> "1st 20k"
                                semanticScope == "second20k"      -> secondLabel.removePrefix("\uD83D\uDCDA ").trim()
                                else                              -> "All notes"
                            }
                            val (icon, text) = when {
                                warming -> "\u23F3" to "Loading $scopeLabel\u2026"
                                loadStatus.startsWith("loaded:") -> {
                                    val n = loadStatus.removePrefix("loaded:").toIntOrNull() ?: 0
                                    "\u2705" to "$scopeLabel: $n chunks ready"
                                }
                                else -> "\u26AA" to "$scopeLabel: search to load"
                            }
                            androidx.compose.material3.AssistChip(
                                onClick = {},
                                label  = { Text("$icon $text", fontSize = 10.sp) }
                            )
                        }
                    }
                    // v5.4.111cc — "Get accurate results" chip (was
                    // "exact phrase"). Label + visual treatment only —
                    // still drives vm.quotePhrase exactly as before.
                    // After a search completes, accurateFlash pulses a
                    // green tint + slight scale-up ~3× then settles,
                    // WITHOUT hiding the chip.
                    if (mode == SearchMode.CONTENT && vChipAccurate) {
                        item {
                            // Flash animation: driven by accurateFlashKey
                            // which bumps each time results land. When it
                            // changes, run a short repeating green pulse.
                            val flashActive = accurateFlashPulse > 0f
                            val greenTint = androidx.compose.ui.graphics.lerp(
                                MaterialTheme.colorScheme.surfaceVariant,
                                androidx.compose.ui.graphics.Color(0xFF43A047),
                                accurateFlashPulse
                            )
                            val scale = 1f + 0.12f * accurateFlashPulse
                            if (flashActive) {
                                // Flashing: override container + label
                                // to the green pulse tint. We supply
                                // Color.Transparent for the states we
                                // don't care about so we never have to
                                // read the private default-color
                                // properties back off the colors object.
                                androidx.compose.material3.FilterChip(
                                    selected = quotePhrase,
                                    onClick = { vm.quotePhrase.value = !quotePhrase },
                                    modifier = Modifier.graphicsLayer {
                                        scaleX = scale
                                        scaleY = scale
                                    },
                                    colors = androidx.compose.material3.FilterChipDefaults.filterChipColors(
                                        containerColor = greenTint,
                                        labelColor = androidx.compose.ui.graphics.Color.White,
                                        selectedContainerColor = greenTint,
                                        selectedLabelColor = androidx.compose.ui.graphics.Color.White
                                    ),
                                    label = {
                                        Text(
                                            if (quotePhrase) "\u2705 Get accurate results"
                                            else "\u2B1C Get accurate results",
                                            fontSize = 11.sp,
                                            fontWeight = FontWeight.Bold
                                        )
                                    }
                                )
                            } else {
                                // Idle: plain default-styled chip, no
                                // colors override, no scale.
                                androidx.compose.material3.FilterChip(
                                    selected = quotePhrase,
                                    onClick = { vm.quotePhrase.value = !quotePhrase },
                                    label = {
                                        Text(
                                            if (quotePhrase) "\u2705 Get accurate results"
                                            else "\u2B1C Get accurate results",
                                            fontSize = 11.sp
                                        )
                                    }
                                )
                            }
                        }
                    }
                }
            }
            } // end if (!hideSearchChips)
            } // end inner Column (top utilities)
            } // end AnimatedVisibility

            // v5.4.111cc — Manual collapse handle. A slim always-visible
            // bar with a chevron: tap to force-toggle the top utilities
            // regardless of scroll. Gives a discoverable, deterministic
            // way to bring the search bar back after it auto-hid, or to
            // hide it on demand. Setting manualOverride to the opposite
            // of the current visibility; the next scroll clears the
            // override so auto behaviour resumes.
            Row(
                Modifier
                    .fillMaxWidth()
                    .height(20.dp)
                    .clickable {
                        manualOverride = !showTopUtilities
                        // Keep the auto-state in sync so a subsequent
                        // scroll doesn't immediately flip it back.
                        topUtilitiesExpanded = !showTopUtilities
                    },
                horizontalArrangement = Arrangement.Center,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    if (showTopUtilities) "\u25B2 hide search bar"
                    else "\u25BC show search bar",
                    fontSize = 10.sp,
                    color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.7f)
                )
            }

            if (topicMatches.isNotEmpty()) {
                Text(
                    "Jump to topic",
                    Modifier.padding(start = 20.dp, top = 10.dp, bottom = 2.dp),
                    fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant
                )
                LazyRow(
                    Modifier.fillMaxWidth().padding(vertical = 4.dp),
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    contentPadding = PaddingValues(horizontal = 16.dp)
                ) {
                    items(topicMatches, key = { it.key }) { t ->
                        Surface(
                            color = MaterialTheme.colorScheme.primary.copy(alpha = 0.18f),
                            shape = RoundedCornerShape(20.dp),
                            modifier = Modifier.clickable { nav.navigate("topic/${t.key}") }
                        ) {
                            Text(
                                "${t.emoji} ${t.label} \u00B7 ${t.count}",
                                Modifier.padding(horizontal = 14.dp, vertical = 8.dp),
                                fontSize = 13.sp, fontWeight = FontWeight.Medium
                            )
                        }
                    }
                }
            }

            val trimmed = query.trim()
            val showingRecents = trimmed.length < 2
            val noMatches = !showingRecents && displayedResults.isEmpty() && topicMatches.isEmpty()

            // v5.4.33 — Animated search indicator. Shows while search
            // is running, using the user's chosen style.
            val searchBusy by vm.searchBusy.collectAsStateWithLifecycle()
            val indicatorStyle by vm.searchIndicatorStyle.collectAsStateWithLifecycle()
            if (searchBusy && !showingRecents) {
                Row(
                    Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 20.dp, vertical = 6.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.Center
                ) {
                    when (indicatorStyle) {
                        "hourglass" -> {
                            // Animated hourglass: rotates between ⏳ and ⌛
                            val inf = rememberInfiniteTransition(label = "hg")
                            val phase by inf.animateFloat(
                                initialValue = 0f,
                                targetValue = 1f,
                                animationSpec = infiniteRepeatable(
                                    tween(800, easing = LinearEasing),
                                    repeatMode = RepeatMode.Restart
                                ), label = "hg"
                            )
                            Text(
                                if (phase < 0.5f) "\u23F3" else "\u231B",
                                fontSize = 20.sp
                            )
                            Spacer(Modifier.width(8.dp))
                            Text("Searching\u2026", fontSize = 12.sp,
                                color = MaterialTheme.colorScheme.onSurfaceVariant)
                        }
                        "book" -> {
                            // Animated book flipping pages: cycles through book emojis
                            val inf = rememberInfiniteTransition(label = "bk")
                            val phase by inf.animateFloat(
                                initialValue = 0f,
                                targetValue = 4f,
                                animationSpec = infiniteRepeatable(
                                    tween(1600, easing = LinearEasing),
                                    repeatMode = RepeatMode.Restart
                                ), label = "bk"
                            )
                            val bookEmoji = when (phase.toInt() % 4) {
                                0 -> "\uD83D\uDCD6"  // open book
                                1 -> "\uD83D\uDCD8"  // green book
                                2 -> "\uD83D\uDCD9"  // blue book
                                else -> "\uD83D\uDCD7" // orange book
                            }
                            Text(bookEmoji, fontSize = 20.sp)
                            Spacer(Modifier.width(8.dp))
                            Text("Flipping pages\u2026", fontSize = 12.sp,
                                color = MaterialTheme.colorScheme.onSurfaceVariant)
                        }
                        else -> {
                            // Percentage (default): circular progress with rerank %
                            val rerankPctInd by vm.rerankProgress.collectAsStateWithLifecycle()
                            if (rerankPctInd != null) {
                                val pctVal = (rerankPctInd!! * 100).toInt().coerceIn(0, 100)
                                androidx.compose.material3.CircularProgressIndicator(
                                    progress = { rerankPctInd!! },
                                    modifier = Modifier.size(18.dp),
                                    strokeWidth = 2.dp
                                )
                                Spacer(Modifier.width(6.dp))
                                Text("$pctVal%", fontSize = 12.sp,
                                    fontWeight = FontWeight.SemiBold,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant)
                            } else {
                                androidx.compose.material3.CircularProgressIndicator(
                                    modifier = Modifier.size(18.dp),
                                    strokeWidth = 2.dp
                                )
                                Spacer(Modifier.width(6.dp))
                                Text("Searching\u2026", fontSize = 12.sp,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant)
                            }
                        }
                    }
                }
            }

            // v5.4.160cc — Scroll-driven parallax on the results-count label.
            //
            // MarkVault has no "article header image" (it's a text-heavy
            // note app), so this adapts the same idea to what actually
            // exists here: this label sits statically above the results
            // LazyColumn (outside the showTopUtilities collapsible block
            // above, so this is fully independent of that existing
            // show/hide logic — zero interaction risk with it). As the
            // user begins scrolling the results, the label drifts upward
            // and fades slightly at a DIFFERENT rate than the list itself
            // — the classic parallax "background moves slower/differently
            // than foreground content" effect.
            //
            // Bounded deliberately: parallaxRaw only tracks scroll offset
            // while still on the very first item (index 0), and locks at
            // its fully-receded resting value once the user has scrolled
            // past it. This means the effect never runs away or produces
            // a nonsensical value for arbitrarily long scrolls — it's a
            // one-time "recede as you begin reading" motion, not a
            // continuously-reactive transform across the whole list.
            val parallaxRaw by remember {
                derivedStateOf {
                    if (resultsListState.firstVisibleItemIndex == 0) {
                        resultsListState.firstVisibleItemScrollOffset.toFloat().coerceIn(0f, 120f)
                    } else {
                        120f
                    }
                }
            }
            Text(
                text = when {
                    showingRecents -> if (recentSearches.isEmpty()) {
                        if (mode == SearchMode.CONTENT)
                            "Tip: try a topic like \"death\" or wrap text in \"quotes\" for an exact phrase."
                        else "Type at least 2 letters."
                    } else "Recent searches"
                    noMatches -> "No matches in your library."
                    else -> "${displayedResults.size} result(s)"
                },
                modifier = Modifier
                    .padding(horizontal = 20.dp, vertical = 6.dp)
                    .graphicsLayer {
                        translationY = -parallaxRaw * 0.4f
                        alpha = 1f - (parallaxRaw / 120f) * 0.5f
                    },
                fontSize = 12.sp,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )

            // v5.4.31 — weight(1f) + fillMaxWidth() instead of
            // fillMaxSize(). In a Column, fillMaxSize on a child
            // without weight() doesn't reliably claim remaining
            // vertical space — siblings above (search bar + chip rows)
            // consumed it in landscape, leaving results with 0
            // effective height. weight(1f) is the canonical fix.
            //
            // v5.4.111cc — Hoisted state drives the collapsible top
            // utilities' auto-hide on scroll.
            // v5.4.157cc — Tracks which result ids have already played their
            // stagger-in animation. A plain (non-state) MutableSet is
            // correct here: it's read once per item via remember(hit.id) at
            // composition time and mutated from a coroutine side-effect, so
            // it never needs to trigger recomposition itself. Persists for
            // the life of this LazyColumn call site — i.e. reset only when
            // SearchScreen itself is torn down and recreated (navigating
            // away and back), not on every keystroke/refilter. Without this,
            // every character typed would replay the fade-in for results
            // that already faded in on a previous keystroke.
            val animatedResultIds = remember { mutableSetOf<Long>() }
            LazyColumn(
                state = resultsListState,
                modifier = Modifier.weight(1f).fillMaxWidth()
            ) {
                if (showingRecents) {
                    // Persisted list of past clicks. Each card keeps the originally-searched query
                    // so we can highlight matched words in its title/path.
                    if (recentSearches.isNotEmpty()) {
                        // v5.4.126cc — Filter out query-only sentinels (noteId = -1).
                        // Those entries are recorded by recordSubmittedQuery() so they
                        // appear in HomeScreen's recent-query chips, but they have no
                        // linked article and must not appear as article-navigation cards.
                        items(recentSearches.filter { it.noteId >= 0 }, key = { "rs-${it.noteId}-${it.ts}" }) { rs ->
                            val toks = remember(rs.query) {
                                rs.query.split(Regex("\\s+"))
                                    .map { it.trim() }.filter { it.isNotEmpty() }.take(6)
                            }
                            Surface(
                                color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.18f),
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(horizontal = 8.dp, vertical = 5.dp),
                                shape = RoundedCornerShape(10.dp)
                            ) {
                                Column(
                                    Modifier
                                        .fillMaxWidth()
                                        .clickable {
                                            val lower = rs.relPath.lowercase()
                                            // Replay the original query as a highlight on every reader.
                                            // v5.4.10 — Preserve the exact-phrase flag so the
                                            // reader's highlight pass treats "1 percent" as
                                            // one phrase instead of two terms.
                                            val rawH = rs.query.trim()
                                            if (rawH.isNotEmpty()) {
                                                val isPhrase = rawH.startsWith("\"") && rawH.endsWith("\"")
                                                vm.setPendingHighlight(rawH, isPhrase = isPhrase)
                                                vm.markOpenedFromSearch()
                                            }
                                            when {
                                                lower.endsWith(".pdf") -> {
                                                    vm.openArticle(rs.noteId, rs.title, fileType = "pdf")
                                                    nav.navigate("pdfReader/${rs.noteId}")
                                                }
                                                lower.endsWith(".mhtml") || lower.endsWith(".mht") -> {
                                                    vm.openArticle(rs.noteId, rs.title, fileType = "mhtml")
                                                    nav.navigate("htmlReader/${rs.noteId}")
                                                }
                                                lower.endsWith(".html") || lower.endsWith(".htm") -> {
                                                    vm.openArticle(rs.noteId, rs.title, fileType = "html")
                                                    nav.navigate("htmlReader/${rs.noteId}")
                                                }
                                                else -> {
                                                    vm.openArticle(rs.noteId, rs.title)
                                                    nav.navigate("reader") { launchSingleTop = true }
                                                }
                                            }
                                        }
                                        .padding(horizontal = 12.dp, vertical = 16.dp)
                                ) {
                                    Row(verticalAlignment = Alignment.CenterVertically) {
                                        Text("\uD83D\uDD52", fontSize = 11.sp)
                                        Spacer(Modifier.width(6.dp))
                                        Text(
                                            rs.query, fontSize = 11.sp,
                                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                                            fontWeight = FontWeight.Medium,
                                            maxLines = 1, overflow = TextOverflow.Ellipsis
                                        )
                                    }
                                    Spacer(Modifier.height(2.dp))
                                    Text(
                                        highlightTerms(cleanTitleForDisplay(rs.title), toks),
                                        fontWeight = FontWeight.SemiBold,
                                        fontSize = 14.sp,
                                        maxLines = 2, overflow = TextOverflow.Ellipsis,
                                        lineHeight = 18.sp
                                    )
                                    Text(
                                        highlightTerms(rs.relPath, toks),
                                        fontSize = 11.sp,
                                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                                        maxLines = 2, overflow = TextOverflow.Ellipsis
                                    )
                                    // v4.6 — readable date+time for every recent
                                    // search entry. User asked: "search history
                                    // must have timestamps (date and time opened)".
                                    Text(
                                        formatRecentTimestamp(rs.ts),
                                        fontSize = 10.sp,
                                        color = MaterialTheme.colorScheme.primary,
                                        maxLines = 1
                                    )
                                }
                            }
                            HistoryBoldDivider()
                        }
                        item {
                            Text(
                                "Clear recent searches",
                                Modifier
                                    .fillMaxWidth()
                                    .clickable { vm.clearRecentSearches() }
                                    .padding(horizontal = 20.dp, vertical = 14.dp),
                                fontSize = 12.sp,
                                color = MaterialTheme.colorScheme.primary
                            )
                        }
                    }
                } else if (noMatches) {
                    item { WebSearchPrompt(trimmed, vm) }
                } else {
                    // Active search with results. Compute highlight tokens once per query.
                    // v5.4.14 — strip surrounding quotes from the trimmed
                    // query for tokenization. The exact-phrase toggle's
                    // auto-wrap turns the query into '"who is god"', and
                    // split-on-whitespace then gives ['"who', 'is', 'god"']
                    // — the leading/trailing quotes stick to first/last
                    // tokens and every downstream substring check fails.
                    val cleanedQuery = trimmed.removeSurrounding("\"").trim()
                    val highlightTokens = cleanedQuery.split(Regex("\\s+"))
                        .map { it.trim() }.filter { it.isNotEmpty() }.take(6)

                    // v5.4.76cc — LLM paraphrase terms for THIS query,
                    // if the on-device expander has recorded any. Feed
                    // them into the snippet renderer so words the LLM
                    // surfaced pick up a softer lavender background,
                    // mirroring the article-body `.llm-hit` treatment.
                    // Empty when the toggle is off, the model isn't
                    // installed, the query hasn't been submitted yet
                    // in this session, or the expander returned
                    // nothing.
                    val llmExpansionRecord =
                        com.tebogo.markvault.ai.LlmExpansionHistory.get(cleanedQuery)
                    val llmHighlightTokens: List<String> = llmExpansionRecord
                        ?.paraphrases.orEmpty()
                        .flatMap { it.split(Regex("\\s+")) }
                        .map { it.trim() }
                        .filter { it.length >= 3 }
                        .distinctBy { it.lowercase() }
                        .take(24)

                    // v5.4.14 — Keyword filter, redefined.
                    //
                    // What the user actually meant by "keyword filter"
                    // all along: a result must contain at least one
                    // consecutive 2-word PHRASE from the query — not
                    // just any 2 distinct query words scattered through
                    // the document. The previous "2 distinct words"
                    // rule let results pass that had "abraham" in one
                    // paragraph and "covenant" in a totally unrelated
                    // section, which is the noise the user wanted gone.
                    //
                    // Algorithm: take consecutive bigrams from the
                    // (cleaned, non-stopword-filtered) query tokens, and
                    // require any one to appear as a literal substring
                    // in the result's title or snippet. The snippet's
                    // FTS marker characters (⟦…⟧) are stripped before
                    // the substring check so they don't break matches.
                    //
                    // Single-word queries: filter is a no-op (nothing to
                    // form a bigram with).
                    val filterTokens = highlightTokens
                        .map { it.lowercase().replace(Regex("[^\\p{L}\\p{N}]"), "") }
                        .filter { it.isNotEmpty() }
                    val bigrams = if (filterTokens.size >= 2) {
                        (0 until filterTokens.size - 1).map { i ->
                            "${filterTokens[i]} ${filterTokens[i + 1]}"
                        }
                    } else emptyList()
                    val filteredResults = if (!keywordFilterOn || bigrams.isEmpty()) {
                        displayedResults
                    } else {
                        displayedResults.filter { hit ->
                            val haystack = (hit.title + " " + hit.snippet)
                                .replace("\u27E6", "")
                                .replace("\u27E7", "")
                                .lowercase()
                            bigrams.any { bg -> haystack.contains(bg) }
                        }
                    }
                    val hiddenCount = displayedResults.size - filteredResults.size

                    // v4.7.7 — always show the jw.org / wol.jw.org buttons,
                    // even when local matches exist. The user wants to be able
                    // to one-tap escalate to external search whenever they
                    // want, not just when the library comes up empty.
                    item { WebSearchPrompt(trimmed, vm) }
                    // v5.4.6 — Manual rerank trigger. Shows above the
                    // result rows when reranker is installed and the
                    // current view hasn't been reranked yet for this
                    // query. Tap → reorders results in place using the
                    // cross-encoder. Hidden once applied (until query
                    // changes again). Also shown with a tiny "reranked"
                    // ribbon if the current view IS the manual-rerank
                    // output, so the user knows what they're looking at.
                    // v5.4.16 — Keyword filter toggle chip, sits at the
                    // top of the results list next to (above) the rerank
                    // banner. Lets the user flip the filter on/off
                    // without going into Settings. Showing the current
                    // state in the chip label keeps the affordance
                    // obvious.
                    item {
                        androidx.compose.foundation.layout.Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(horizontal = 14.dp, vertical = 4.dp),
                            horizontalArrangement = androidx.compose.foundation.layout.Arrangement.spacedBy(8.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            androidx.compose.material3.FilterChip(
                                selected = keywordFilterOn,
                                onClick = {
                                    vm.setKeywordFilterEnabled(!keywordFilterOn)
                                },
                                label = {
                                    Text(
                                        if (keywordFilterOn)
                                            "\uD83E\uDDF9 Keyword filter: ON"
                                        else
                                            "\uD83E\uDDF9 Keyword filter: OFF",
                                        fontSize = 12.sp
                                    )
                                }
                            )
                            if (hiddenCount > 0 && keywordFilterOn) {
                                Text(
                                    "$hiddenCount hidden",
                                    fontSize = 11.sp,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }
                        }
                    }
                    if (showManualRerankButton) {
                        item {
                            ManualRerankBanner(
                                inProgress = manualRerankBusy,
                                onTap = { vm.manuallyRerankCurrentResults() }
                            )
                        }
                    } else if (manualRerank?.first == trimmed) {
                        item {
                            Text(
                                "\u2728 Reranked for relevance",
                                fontSize = 11.sp,
                                color = MaterialTheme.colorScheme.primary,
                                modifier = Modifier.padding(
                                    horizontal = 14.dp, vertical = 4.dp
                                )
                            )
                        }
                    }
                    // Discoverability hint — tells the user that long-press
                    // is available. Tucked above the results list so it's
                    // visible exactly when they need it.
                    item {
                        Text(
                            "\uD83D\uDCA1 Tap to open · long-press for more options",
                            fontSize = 11.sp,
                            color = MaterialTheme.colorScheme.primary,
                            modifier = Modifier.padding(horizontal = 14.dp, vertical = 6.dp)
                        )
                    }
                    // v4.17.0 — Transparency: tell the user when matches were
                    // filtered out so the list doesn't feel silently shorter
                    // than expected. Only shown when ≥1 result was hidden.
                    if (hiddenCount > 0) {
                        item {
                            Text(
                                "\uD83D\uDD0E ${hiddenCount} weak match${if (hiddenCount == 1) "" else "es"} hidden \u00B7 needs at least 2 matching words",
                                fontSize = 11.sp,
                                color = MaterialTheme.colorScheme.onSurfaceVariant,
                                modifier = Modifier.padding(horizontal = 14.dp, vertical = 4.dp)
                            )
                        }
                    }
                    itemsIndexed(filteredResults, key = { _, item -> item.id }) { index, hit ->
                        // v5.4.157cc — Staggered fade + slide-up entrance.
                        // Each result starts at alpha 0 / offset 24dp down,
                        // then animates to alpha 1 / offset 0 with a small
                        // per-index delay so results cascade in rather than
                        // dumping onto screen at once. Delay is capped at
                        // 300ms (10 items) so long result lists don't make
                        // the tail of the list wait ages to appear.
                        val alreadyAnimated = remember(hit.id) { hit.id in animatedResultIds }
                        val entranceProgress = remember(hit.id) { Animatable(if (alreadyAnimated) 1f else 0f) }
                        LaunchedEffect(hit.id) {
                            if (!alreadyAnimated) {
                                delay((index * 30L).coerceAtMost(300L))
                                entranceProgress.animateTo(1f, animationSpec = tween(280))
                                animatedResultIds.add(hit.id)
                            }
                        }
                        Surface(
                            color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.18f),
                            // v5.4.171cc — "3D look" extended to result cards.
                            // shadowElevation is Surface's OWN native property
                            // (not a bolted-on overlay), so it's guaranteed to
                            // render correctly regardless of the card's
                            // semi-transparent color — unlike a gradient
                            // layered outside the Surface, which risks being
                            // covered by the Surface's own background paint.
                            // Kept modest (3dp) since many cards stack in the
                            // same list; a heavier shadow per-card would look
                            // cluttered rather than "raised."
                            shadowElevation = 3.dp,
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(horizontal = 8.dp, vertical = 5.dp)
                                .graphicsLayer {
                                    alpha = entranceProgress.value
                                    translationY = (1f - entranceProgress.value) * 24.dp.toPx()
                                },
                            shape = RoundedCornerShape(10.dp)
                        ) {
                            // v4.7.4 — switched from combinedClickable to direct
                            // pointerInput + detectTapGestures. The former works
                            // most of the time but can be eaten by LazyColumn's
                            // scroll gesture detector on some devices, causing
                            // the long-press to silently never fire. The latter
                            // gives explicit control. Haptic feedback on long-
                            // press also gives the user immediate confirmation
                            // that the gesture was detected.
                            val haptic = androidx.compose.ui.platform.LocalHapticFeedback.current
                            Column(
                                Modifier
                                    .fillMaxWidth()
                                    .pointerInput(hit.id) {
                                        detectTapGestures(
                                            onTap = {
                                                vm.recordSearchClick(trimmed, hit.id, hit.title, hit.relPath)
                                                // v5.3.0 — Pass just the query.
                                                // The reader's new
                                                // sentence-level highlighter
                                                // extracts distinctive terms
                                                // from the query and
                                                // highlights whole sentences
                                                // containing them.
                                                // v5.4.10 — Also preserves
                                                // exact-phrase flag.
                                                if (trimmed.isNotEmpty()) {
                                                    val isPhrase = trimmed.startsWith("\"") && trimmed.endsWith("\"")
                                                    vm.setPendingHighlight(
                                                        trimmed,
                                                        isPhrase = isPhrase,
                                                        snippet = hit.snippet
                                                    )
                                                    vm.markOpenedFromSearch()
                                                }
                                                when (hit.fileType) {
                                                    "pdf" -> {
                                                        vm.openArticle(hit.id, hit.title, fileType = "pdf")
                                                        nav.navigate("pdfReader/${hit.id}")
                                                    }
                                                    "mhtml", "html" -> {
                                                        vm.openArticle(hit.id, hit.title, fileType = hit.fileType)
                                                        nav.navigate("htmlReader/${hit.id}")
                                                    }
                                                    else -> {
                                                        vm.openArticle(hit.id, hit.title)
                                                        nav.navigate("reader") { launchSingleTop = true }
                                                    }
                                                }
                                            },
                                            onLongPress = {
                                                // Haptic buzz so the user knows the press registered.
                                                haptic.performHapticFeedback(
                                                    androidx.compose.ui.hapticfeedback.HapticFeedbackType.LongPress
                                                )
                                                longPressTarget = SearchHit(
                                                    id = hit.id, title = hit.title,
                                                    relPath = hit.relPath, fileType = hit.fileType
                                                )
                                            }
                                        )
                                    }
                                    // v4.14.0 — more vertical breathing room between
                                    // result rows. The bolder divider already makes
                                    // boundaries clear; adding generous padding keeps
                                    // each card from feeling cramped.
                                    .padding(horizontal = 12.dp, vertical = if (isTabletWidth) 10.dp else 18.dp)
                            ) {
                                // v4.7.6 — clean the title for display so URLs
                                // embedded in markdown link syntax like
                                //   # [Am I a Perfectionist?](https://.../teenager/...)
                                // don't crowd out the visible text. We highlight
                                // matches inside the cleaned title. If the search
                                // term matched somewhere that's NOT visible
                                // (the URL was stripped, or the term lives in
                                // a long part that gets truncated), we render
                                // a small context snippet below so the user can
                                // see WHERE the match was found.
                                val displayTitle = cleanTitleForDisplay(hit.title)
                                // v4.24.0 — Relevance percentage chip,
                                // top-right of the card. Only shown when
                                // semantic search contributed a score
                                // (i.e. when reranker probability or
                                // BGE-large cosine is available). For
                                // keyword-only matches we hide it — a
                                // misleading percentage is worse than none.
                                val isLlmMatched = hit.id in llmMatchedIds
                                if (hit.score != null || isLlmMatched) {
                                    Row(
                                        Modifier.fillMaxWidth(),
                                        horizontalArrangement = androidx.compose.foundation.layout.Arrangement.End,
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        if (isLlmMatched) {
                                            // v5.4.76cc — Trace chip:
                                            // this row was surfaced by
                                            // the LLM's paraphrase of
                                            // the user's query, not the
                                            // original tokens. Kept
                                            // small and lavender so it
                                            // reads as an ambient
                                            // marker, not a shout.
                                            AiTraceChip()
                                            Spacer(Modifier.width(6.dp))
                                        }
                                        if (hit.score != null) {
                                            ChatRelevanceChip(hit.score)
                                        }
                                    }
                                    Spacer(Modifier.height(4.dp))
                                }
                                val titleHasMatch = highlightTokens.any {
                                    displayTitle.contains(it, ignoreCase = true)
                                }
                                val pathHasMatch = highlightTokens.any {
                                    hit.relPath.contains(it, ignoreCase = true)
                                }
                                Text(
                                    highlightTerms(displayTitle, highlightTokens),
                                    fontWeight = FontWeight.SemiBold,
                                    maxLines = 2,
                                    overflow = TextOverflow.Ellipsis,
                                    lineHeight = 18.sp
                                )
                                Text(
                                    highlightTerms(hit.relPath, highlightTokens),
                                    fontSize = 11.sp,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                                    maxLines = 2,
                                    overflow = TextOverflow.Ellipsis
                                )
                                if (!titleHasMatch && !pathHasMatch) {
                                    // The match must be living in the URL we
                                    // just stripped from the title (or in the
                                    // file name). Compute a tight context
                                    // window around the first match in the raw
                                    // title + name so it's still visible.
                                    val context = matchContextSnippet(
                                        "${hit.title} ${hit.relPath}",
                                        highlightTokens
                                    )
                                    if (context != null) {
                                        Spacer(Modifier.height(2.dp))
                                        Text(
                                            highlightTerms(context, highlightTokens),
                                            fontSize = 11.sp,
                                            color = MaterialTheme.colorScheme.primary,
                                            maxLines = 1,
                                            overflow = TextOverflow.Ellipsis
                                        )
                                    }
                                }
                                if (hit.snippet.isNotBlank()) {
                                    Spacer(Modifier.height(4.dp))
                                    // v4.24.0 — Phrase-level highlighting:
                                    // sentences containing 2+ query terms get
                                    // a background tint; sentences with only
                                    // 1 incidental match are NOT highlighted.
                                    // Avoids the previous "every common word
                                    // is yellow" noise that made bad matches
                                    // look like good ones.
                                    Text(
                                        highlightSentences(hit.snippet, highlightTokens, llmHighlightTokens),
                                        fontSize = 13.sp,
                                        lineHeight = 18.sp
                                    )
                                }
                            }
                        }
                        // Bolder dividing line between search results
                        HistoryBoldDivider()
                    }
                }
                item { Spacer(Modifier.height(24.dp)) }
            }
        }
        } // v5.4.30 — close outer Row
    }

    // v4.7 — long-press action sheet on search results.
    longPressTarget?.let { hit ->
        SearchResultActionSheet(
            hit = hit,
            vm = vm,
            nav = nav,
            onDismiss = { longPressTarget = null },
            onPickSplitPair = {
                splitPickerTarget = hit
                longPressTarget = null
            },
            onPickConvert = {
                convertTarget = hit
                longPressTarget = null
            }
        )
    }

    splitPickerTarget?.let { hit ->
        SplitPartnerPickerDialog(
            hit = hit,
            vm = vm,
            nav = nav,
            onDismiss = { splitPickerTarget = null }
        )
    }

    convertTarget?.let { hit ->
        ConvertTargetDialog(
            hit = hit,
            vm = vm,
            onDismiss = { convertTarget = null }
        )
    }

    // ── v5.4.132cc — Multi-article pumping-heart popup overlay ──
    // A pumping 💗 FAB anchored to bottom-start (above the reader
    // toolbar) fires the multi-article popup: it collects the top-N
    // articles from the current search results, extracts semantic
    // passages from each, and shows them in the same typewriter
    // popup the reader screens use. Top-N is user-configurable via
    // vm.popupArticlesTopN (default 1). The overlay Box sits ABOVE
    // the Scaffold in draw order so its children render on top of
    // the results list without blocking touches elsewhere.
    val ssPopupState by vm.articlePopupState.collectAsStateWithLifecycle()
    val ssTopN by vm.popupArticlesTopN.collectAsStateWithLifecycle()
    // v5.4.150cc — Typing speed persisted across app exit.
    val ssPopupTypingSpeed by vm.popupTypingSpeed.collectAsStateWithLifecycle()
    val ssPopupSlot: com.tebogo.markvault.AppViewModel.ArticlePopupState = ssPopupState
    val ssHasMinimized: Boolean =
        ssPopupSlot is com.tebogo.markvault.AppViewModel.ArticlePopupState.Visible &&
            ssPopupSlot.minimized
    val ssIsLoading: Boolean =
        ssPopupSlot is com.tebogo.markvault.AppViewModel.ArticlePopupState.Loading
    val ssCurrentQuery by vm.query.collectAsStateWithLifecycle()

    androidx.compose.foundation.layout.Box(
        Modifier.fillMaxSize()
    ) {
        // Show the heart FAB when there are search results AND we have
        // a query to run. The `pulsing` cadence continues either way —
        // that's the visual invitation the user asked for.
        val hasQueryForHeart: Boolean = ssCurrentQuery.trim()
            .removeSurrounding("\"").trim().length >= 2
        val hasHitsForHeart: Boolean = displayedResults.isNotEmpty()
        if (hasQueryForHeart && hasHitsForHeart) {
            PumpingHeartFab(
                // Pulse always so the user notices it. If a popup is
                // minimized, keep pulsing — same "you have one waiting"
                // signal as the brain button in the readers.
                pulsing = true,
                busy = ssIsLoading,
                onClick = {
                    // If a popup is already minimized, tapping the
                    // heart brings it back rather than starting a new
                    // multi-article search.
                    if (ssHasMinimized) {
                        vm.maximizeArticlePopup()
                        return@PumpingHeartFab
                    }
                    val q: String = ssCurrentQuery.trim()
                        .removeSurrounding("\"").trim()
                    if (q.length < 2) return@PumpingHeartFab
                    val hits: List<com.tebogo.markvault.data.SearchHit> =
                        displayedResults
                    if (hits.isEmpty()) return@PumpingHeartFab
                    vm.findAndShowMultiArticlePopup(q, hits, ssTopN)
                },
                modifier = Modifier
                    .align(Alignment.BottomStart)
                    // 80 dp bottom padding lifts the FAB above the
                    // bottom toolbar so it isn't obscured.
                    .padding(start = 16.dp, bottom = 80.dp)
            )
        }

        // v5.4.146cc — "Search on jw.org" floating button, centered above toolbar
        val showJwSearchButton by vm.showJwSearchButton.collectAsStateWithLifecycle()
        val hasQueryForJw: Boolean = ssCurrentQuery.trim()
            .removeSurrounding("\"").trim().length >= 2
        val hasHitsForJw: Boolean = displayedResults.isNotEmpty()
        val isSearchBusyJw = isSearchBusy  // From outer scope
        
        if (showJwSearchButton && hasQueryForJw && hasHitsForJw && !isSearchBusyJw) {
            val encQuery = java.net.URLEncoder.encode(ssCurrentQuery.trim(), "UTF-8")
            Surface(
                color = MaterialTheme.colorScheme.primary.copy(alpha = 0.95f),
                shape = RoundedCornerShape(16.dp),
                modifier = Modifier
                    .align(Alignment.BottomCenter)
                    .padding(bottom = 90.dp)
                    .clickable {
                        vm.requestWebPopup("https://www.jw.org/en/search/?q=$encQuery")
                    }
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    modifier = Modifier.padding(horizontal = 16.dp, vertical = 10.dp)
                ) {
                    Text(
                        "🔍 Search on jw.org",
                        color = MaterialTheme.colorScheme.onPrimary,
                        fontWeight = FontWeight.SemiBold,
                        fontSize = 13.sp
                    )
                }
            }
        }

        // v5.4.181cc — "Jump to top" floating button. Search results can
        // load in a way that leaves the user scrolled past the top of
        // the list without a clear way back up short of a long manual
        // swipe — this surfaces once they've scrolled down INTO actual
        // results and gives a one-tap way back to the top of the list.
        // Positioned bottom-end so it doesn't collide with the heart FAB
        // (bottom-start) or "Search on jw.org" (bottom-center).
        val showJumpToTop by remember {
            derivedStateOf {
                resultsListState.firstVisibleItemIndex > 0 && displayedResults.isNotEmpty()
            }
        }
        if (showJumpToTop) {
            val jumpScope = androidx.compose.runtime.rememberCoroutineScope()
            Surface(
                color = MaterialTheme.colorScheme.secondaryContainer.copy(alpha = 0.95f),
                shape = RoundedCornerShape(16.dp),
                shadowElevation = 4.dp,
                modifier = Modifier
                    .align(Alignment.BottomEnd)
                    .padding(end = 16.dp, bottom = 90.dp)
                    .clickable {
                        jumpScope.launch { resultsListState.animateScrollToItem(0) }
                    }
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    modifier = Modifier.padding(horizontal = 14.dp, vertical = 10.dp)
                ) {
                    Text(
                        "🔝 Top",
                        color = MaterialTheme.colorScheme.onSecondaryContainer,
                        fontWeight = FontWeight.SemiBold,
                        fontSize = 13.sp
                    )
                }
            }
        }

        // Popup rendering — same four-state pattern as the readers.
        when (ssPopupSlot) {
            is com.tebogo.markvault.AppViewModel.ArticlePopupState.Loading -> {
                ArticlePopupLoading(
                    query = ssPopupSlot.query,
                    onCancel = { vm.closeArticlePopup() },
                    modifier = Modifier
                        .align(Alignment.BottomCenter)
                        .padding(bottom = 80.dp, start = 16.dp, end = 16.dp)
                )
            }
            is com.tebogo.markvault.AppViewModel.ArticlePopupState.Empty -> {
                ArticlePopupEmpty(
                    query = ssPopupSlot.query,
                    onClose = { vm.closeArticlePopup() },
                    modifier = Modifier
                        .align(Alignment.BottomCenter)
                        .padding(bottom = 80.dp, start = 16.dp, end = 16.dp)
                )
            }
            is com.tebogo.markvault.AppViewModel.ArticlePopupState.Visible -> {
                if (ssPopupSlot.minimized) {
                    MinimizedPopupPill(
                        query = ssPopupSlot.query,
                        onMaximize = { vm.maximizeArticlePopup() },
                        onClose = { vm.closeArticlePopup() },
                        modifier = Modifier
                            .align(Alignment.BottomStart)
                            .padding(start = 16.dp, bottom = 140.dp)
                    )
                } else {
                    ArticlePopupOverlay(
                        query = ssPopupSlot.query,
                        passages = ssPopupSlot.passages,
                        onClose = { vm.closeArticlePopup() },
                        onMinimize = { vm.minimizeArticlePopup() },
                        onCycleBlur = { vm.cycleArticlePopupBlur() },
                        // v5.4.135cc — Route "📖 Open" through the same
                        // fileType-based navigation the primary tap uses.
                        onOpenArticle = ssPopupSlot.openableFileType?.let { ft ->
                            {
                                val nid: Long = ssPopupSlot.noteId
                                // Look up title from displayedResults so
                                // openArticle records the right label.
                                val title: String = displayedResults
                                    .firstOrNull { it.id == nid }
                                    ?.title
                                    ?: ""
                                vm.closeArticlePopup()
                                when (ft.lowercase()) {
                                    "html", "mhtml" -> {
                                        vm.openArticle(nid, title, fileType = ft)
                                        runCatching { nav.navigate("htmlReader/$nid") }
                                    }
                                    "pdf" -> {
                                        vm.openArticle(nid, title, fileType = ft)
                                        runCatching { nav.navigate("pdfReader/$nid") }
                                    }
                                    else -> {
                                        vm.openArticle(nid, title)
                                        runCatching { nav.navigate("reader") { launchSingleTop = true } }
                                    }
                                }
                            }
                        },
                        // v5.4.135cc — URL links (scripture refs, footnotes,
                        // etc.) open in the in-app WebView instead of the
                        // system browser. Same URL-encode + navigate("web/…")
                        // pattern used by HtmlReaderScreen's link click
                        // handler.
                        onOpenUrl = { url ->
                            runCatching {
                                val encUrl = java.net.URLEncoder.encode(url, "UTF-8")
                                val label: String = runCatching {
                                    android.net.Uri.parse(url).host ?: "Link"
                                }.getOrDefault("Link")
                                val encLabel = java.net.URLEncoder.encode(label, "UTF-8")
                                nav.navigate("web/$encUrl/$encLabel")
                            }
                        },
                        // v5.4.150cc — Wire mode and AI toggle so the AI chip
                        // is pressable in SearchScreen. Use the cached article text
                        // (set by findAndShowArticlePassages) — avoids a DB reload.
                        mode = ssPopupSlot.mode,
                        onToggleMode = {
                            val slotNoteId = ssPopupSlot.noteId
                            val slotQuery  = ssPopupSlot.query
                            val slotText   = vm.cachedArticleTextForPopup
                            vm.toggleArticlePopupMode(slotNoteId, slotText, slotQuery)
                        },
                        // v5.4.150cc — Typing speed backed by DataStore.
                        typingSpeed = ssPopupTypingSpeed,
                        onTypingSpeedChange = { vm.setPopupTypingSpeed(it) },
                        // v5.4.150cc — Start at bottom-center.
                        modifier = Modifier
                            .align(Alignment.BottomCenter)
                            .padding(bottom = 80.dp, start = 12.dp, end = 12.dp)
                    )
                }
            }
            is com.tebogo.markvault.AppViewModel.ArticlePopupState.Hidden -> {
                // Nothing rendered
            }
        }
    }
}

/** Lightweight shadow of a search hit we can pass to dialog state. */
private data class SearchHit(
    val id: Long,
    val title: String,
    val relPath: String,
    val fileType: String
)

/**
 * Action sheet shown on long-press of a search result. Offers:
 *   • Open in split view (then picks the partner)
 *   • Open externally
 *   • Share
 *   • Convert (auto-detects valid target types)
 *   • Open in graph
 */
@OptIn(androidx.compose.material3.ExperimentalMaterial3Api::class)
@Composable
private fun SearchResultActionSheet(
    hit: SearchHit,
    vm: AppViewModel,
    nav: NavController,
    onDismiss: () -> Unit,
    onPickSplitPair: () -> Unit,
    onPickConvert: () -> Unit
) {
    val ctx = androidx.compose.ui.platform.LocalContext.current
    androidx.compose.material3.ModalBottomSheet(onDismissRequest = onDismiss) {
        Column(Modifier.fillMaxWidth().padding(horizontal = 18.dp, vertical = 8.dp)) {
            Text(
                hit.title.ifBlank { hit.relPath },
                fontSize = 15.sp,
                fontWeight = FontWeight.SemiBold,
                maxLines = 2,
                overflow = TextOverflow.Ellipsis
            )
            Text(
                "Type: ${hit.fileType.uppercase()}",
                fontSize = 12.sp,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                modifier = Modifier.padding(top = 2.dp)
            )
            Spacer(Modifier.height(10.dp))
            // v5.4.132cc — In-article semantic search. Sets a pending
            // query, opens the reader, and the reader auto-triggers
            // the smart popup once the article's content is loaded.
            //
            // v5.4.135cc — Fixed: was calling vm.openSync(id) which
            // only loads the Note record — it does NOT set the active
            // tab, so ReaderScreen's LaunchedEffect(activeTab) never
            // fired for the new article and the popup never opened.
            // The primary-tap pattern (line 823-ish) uses openArticle,
            // which is the one that actually sets activeTab. Mirroring
            // that here fixes the "menu closes but nothing happens" bug.
            androidx.compose.material3.TextButton(
                onClick = {
                    onDismiss()
                    val q = vm.query.value.trim().removeSurrounding("\"").trim()
                    if (q.length >= 2) {
                        vm.setPendingPopupQuery(q)
                    }
                    when (hit.fileType.lowercase()) {
                        "html", "mhtml" -> {
                            vm.openArticle(hit.id, hit.title, fileType = hit.fileType)
                            runCatching { nav.navigate("htmlReader/${hit.id}") }
                        }
                        "pdf" -> {
                            vm.openArticle(hit.id, hit.title, fileType = hit.fileType)
                            runCatching { nav.navigate("pdfReader/${hit.id}") }
                        }
                        else -> {
                            vm.openArticle(hit.id, hit.title)
                            runCatching { nav.navigate("reader") { launchSingleTop = true } }
                        }
                    }
                },
                modifier = Modifier.fillMaxWidth()
            ) { Text("\uD83E\uDDE0  Search in article (semantic)") }
            androidx.compose.material3.TextButton(
                onClick = onPickSplitPair,
                modifier = Modifier.fillMaxWidth()
            ) { Text("\uD83E\uDE9F  Open in split view") }
            androidx.compose.material3.TextButton(
                onClick = {
                    onDismiss()
                    val note = vm.openSync(hit.id)
                    val uri = note?.uri?.let { runCatching { android.net.Uri.parse(it) }.getOrNull() }
                    uri?.let {
                        runCatching {
                            ctx.startActivity(
                                android.content.Intent(android.content.Intent.ACTION_VIEW, it)
                                    .addFlags(android.content.Intent.FLAG_GRANT_READ_URI_PERMISSION)
                            )
                        }
                    }
                },
                modifier = Modifier.fillMaxWidth()
            ) { Text("\u2197  Open externally") }
            androidx.compose.material3.TextButton(
                onClick = {
                    onDismiss()
                    val note = vm.openSync(hit.id)
                    val uri = note?.uri?.let { runCatching { android.net.Uri.parse(it) }.getOrNull() }
                    uri?.let {
                        runCatching {
                            val mime = when (hit.fileType) {
                                "pdf" -> "application/pdf"
                                "mhtml", "html" -> "text/html"
                                else -> "text/markdown"
                            }
                            ctx.startActivity(android.content.Intent.createChooser(
                                android.content.Intent(android.content.Intent.ACTION_SEND)
                                    .setType(mime)
                                    .putExtra(android.content.Intent.EXTRA_STREAM, it)
                                    .addFlags(android.content.Intent.FLAG_GRANT_READ_URI_PERMISSION),
                                "Share file"
                            ))
                        }
                    }
                },
                modifier = Modifier.fillMaxWidth()
            ) { Text("\u2709\uFE0F  Share") }
            androidx.compose.material3.TextButton(
                onClick = onPickConvert,
                modifier = Modifier.fillMaxWidth()
            ) { Text("\uD83D\uDD04  Convert\u2026") }
            androidx.compose.material3.TextButton(
                onClick = {
                    onDismiss()
                    nav.navigate("graph") { launchSingleTop = true }
                },
                modifier = Modifier.fillMaxWidth()
            ) { Text("\uD83D\uDD78\uFE0F  Open in graph") }

            // v5.1.0 — Open in a new browser tab. For notes that have an
            // original online URL (HTML articles saved from the web), this
            // routes through the persistent multi-tab WebView so the user
            // can keep their current screen and have the article open in
            // the background. For MD / PDF notes without a URL, the option
            // is hidden — they have nothing meaningful to "open in browser".
            androidx.compose.material3.TextButton(
                onClick = {
                    val note = vm.openSync(hit.id)
                    val uri = note?.uri?.let { runCatching { android.net.Uri.parse(it) }.getOrNull() }
                    val urlStr = uri?.toString()
                    if (urlStr != null &&
                        (urlStr.startsWith("http://") || urlStr.startsWith("https://"))) {
                        vm.openInBrowser(urlStr, uri.host ?: "Link")
                    }
                    onDismiss()
                },
                modifier = Modifier.fillMaxWidth()
            ) { Text("\uD83E\uDE9F  Open in new browser tab") }
            Spacer(Modifier.height(16.dp))
        }
    }
}

/** After user picks "Open in split view", we list the other open tabs to pair with. */
@Composable
private fun SplitPartnerPickerDialog(
    hit: SearchHit,
    vm: AppViewModel,
    nav: NavController,
    onDismiss: () -> Unit
) {
    val tabs by vm.tabs.collectAsStateWithLifecycle()
    val partners = tabs.filter { it.id != hit.id }
    androidx.compose.material3.AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Open in split view with…") },
        text = {
            if (partners.isEmpty()) {
                Text(
                    "Open another file first, then come back here to pair them.",
                    fontSize = 13.sp
                )
            } else {
                Column {
                    partners.forEach { p ->
                        androidx.compose.material3.TextButton(
                            onClick = {
                                onDismiss()
                                nav.navigate(
                                    "splitReader/${hit.id}/${hit.fileType}/${p.id}/${p.fileType}"
                                )
                            },
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Text(
                                p.title.ifBlank { "Untitled" },
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis
                            )
                        }
                    }
                }
            }
        },
        confirmButton = {
            androidx.compose.material3.TextButton(onClick = onDismiss) { Text("Cancel") }
        }
    )
}

/**
 * Convert dialog — offers target file types based on the source. The actual
 * conversion logic lives on the VM (placeholder for v4.7). The UI is wired
 * end-to-end so the next iteration only needs to fill in the conversion bodies.
 */
@Composable
private fun ConvertTargetDialog(
    hit: SearchHit,
    vm: AppViewModel,
    onDismiss: () -> Unit
) {
    val ctx = androidx.compose.ui.platform.LocalContext.current
    val scope = androidx.compose.runtime.rememberCoroutineScope()
    // Available target types based on source. If the source is markdown, you
    // can go to HTML or PDF. From HTML/MHTML, you can go to Markdown or PDF.
    // From PDF, you can go to Markdown or HTML.
    val targets = when (hit.fileType) {
        "md" -> listOf("html" to "HTML (.html)", "pdf" to "PDF (.pdf)")
        "html", "mhtml" -> listOf("md" to "Markdown (.md)", "pdf" to "PDF (.pdf)")
        "pdf" -> listOf("md" to "Markdown (.md)", "html" to "HTML (.html)")
        else -> emptyList()
    }
    androidx.compose.material3.AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Convert to…") },
        text = {
            Column {
                Text(
                    "Pick a target format. The new file lands in your library and is automatically indexed.",
                    fontSize = 12.sp,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    modifier = Modifier.padding(bottom = 8.dp)
                )
                targets.forEach { (typeId, label) ->
                    androidx.compose.material3.TextButton(
                        onClick = {
                            onDismiss()
                            scope.launch {
                                val res = vm.convertNote(hit.id, hit.fileType, typeId)
                                val msg = when (res) {
                                    is com.tebogo.markvault.SaveResult.Ok -> {
                                        val relPath = if (res.subfolder.isBlank()) res.fileName
                                            else "${res.subfolder}/${res.fileName}"
                                        vm.indexNewFile(res.docUri, relPath)
                                        "\u2705 Saved: ${res.fileName}"
                                    }
                                    is com.tebogo.markvault.SaveResult.Error ->
                                        "\u26A0\uFE0F ${res.message}"
                                }
                                android.widget.Toast.makeText(
                                    ctx, msg, android.widget.Toast.LENGTH_LONG
                                ).show()
                            }
                        },
                        modifier = Modifier.fillMaxWidth()
                    ) { Text(label) }
                }
            }
        },
        confirmButton = {
            androidx.compose.material3.TextButton(onClick = onDismiss) { Text("Cancel") }
        }
    )
}

@Composable
private fun WebSearchPrompt(query: String, vm: AppViewModel) {
    val encQuery = remember(query) {
        runCatching { java.net.URLEncoder.encode(query, "UTF-8") }.getOrElse { query }
    }
    // v5.4.145cc — Check if web search buttons should be hidden
    
    // v5.4.147cc — Removed "Search on jw.org?" query preview section to save screen space
    // Users now see the floating "Search on jw.org" button instead at bottom of results
}

@Composable
private fun WebSearchButton(label: String, onClick: () -> Unit) {
    Surface(
        color = MaterialTheme.colorScheme.primary.copy(alpha = 0.18f),
        shape = RoundedCornerShape(8.dp),
        modifier = Modifier.fillMaxWidth().clickable(onClick = onClick)
    ) {
        Text(
            label,
            Modifier.padding(horizontal = 12.dp, vertical = 8.dp),
            fontWeight = FontWeight.Medium, fontSize = 12.sp
        )
    }
}

private fun highlightSnippet(s: String): AnnotatedString = buildAnnotatedString {
    val parts = s.split("\u27E6")
    parts.forEachIndexed { idx, part ->
        if (idx == 0) {
            append(part)
        } else {
            val end = part.indexOf('\u27E7')
            if (end >= 0) {
                // v4.14.0 — bold italic instead of yellow background.
                // Keeps matches visually prominent but doesn't make the list
                // look "ransom-note" busy. The yellow highlight stays in
                // articles (.md / .html / .pdf) where it makes sense.
                withStyle(
                    SpanStyle(
                        fontWeight = FontWeight.Bold,
                        fontStyle = androidx.compose.ui.text.font.FontStyle.Italic
                    )
                ) {
                    append(part.substring(0, end))
                }
                append(part.substring(end + 1))
            } else {
                append(part)
            }
        }
    }
}

/**
 * Highlight every occurrence of each search token inside [text] (case-insensitive).
 * Overlapping / adjacent matches are merged so we never produce nested or jagged spans.
 */
private fun highlightTerms(text: String, terms: List<String>): AnnotatedString {
    if (terms.isEmpty() || text.isEmpty()) return AnnotatedString(text)
    val lower = text.lowercase()
    // Collect every match range across every token
    val ranges = ArrayList<IntRange>()
    for (term in terms) {
        val needle = term.lowercase()
        if (needle.isEmpty()) continue
        var from = 0
        while (from <= lower.length - needle.length) {
            val found = lower.indexOf(needle, from)
            if (found < 0) break
            ranges.add(found until (found + needle.length))
            from = found + needle.length
        }
    }
    if (ranges.isEmpty()) return AnnotatedString(text)
    // Sort and merge overlapping/adjacent ranges into a clean span list
    ranges.sortBy { it.first }
    val merged = ArrayList<IntRange>()
    var cur = ranges[0]
    for (i in 1 until ranges.size) {
        val r = ranges[i]
        cur = if (r.first <= cur.last + 1) cur.first..maxOf(cur.last, r.last)
        else { merged.add(cur); r }
    }
    merged.add(cur)
    // Build the styled string in a single pass
    return buildAnnotatedString {
        var pos = 0
        // v4.14.0 — same bold-italic-not-yellow style as highlightSnippet.
        val emph = SpanStyle(
            fontWeight = FontWeight.Bold,
            fontStyle = androidx.compose.ui.text.font.FontStyle.Italic
        )
        for (r in merged) {
            if (r.first > pos) append(text.substring(pos, r.first))
            withStyle(emph) { append(text.substring(r.first, r.last + 1)) }
            pos = r.last + 1
        }
        if (pos < text.length) append(text.substring(pos))
    }
}

/**
 * Format a recent-search timestamp as something like "Today 14:32",
 * "Yesterday 09:15", or "Mon 18 Nov · 11:48" for older entries. Mirrors the
 * style we use on Recent cards on Home so the search history reads consistently.
 */
private fun formatRecentTimestamp(ts: Long): String {
    if (ts <= 0L) return ""
    val now = System.currentTimeMillis()
    val diff = now - ts
    val cal = java.util.Calendar.getInstance().apply { timeInMillis = ts }
    val today = java.util.Calendar.getInstance()
    val sameDay = cal.get(java.util.Calendar.YEAR) == today.get(java.util.Calendar.YEAR) &&
        cal.get(java.util.Calendar.DAY_OF_YEAR) == today.get(java.util.Calendar.DAY_OF_YEAR)
    val timeFmt = java.text.SimpleDateFormat("HH:mm", java.util.Locale.getDefault())
    val time = timeFmt.format(java.util.Date(ts))
    if (sameDay) return "Today · $time"
    val yesterday = java.util.Calendar.getInstance().apply {
        timeInMillis = now
        add(java.util.Calendar.DAY_OF_YEAR, -1)
    }
    val isYesterday = cal.get(java.util.Calendar.YEAR) == yesterday.get(java.util.Calendar.YEAR) &&
        cal.get(java.util.Calendar.DAY_OF_YEAR) == yesterday.get(java.util.Calendar.DAY_OF_YEAR)
    if (isYesterday) return "Yesterday · $time"
    val dateFmt = if (diff < 365L * 24 * 60 * 60 * 1000)
        java.text.SimpleDateFormat("EEE d MMM", java.util.Locale.getDefault())
    else
        java.text.SimpleDateFormat("d MMM yyyy", java.util.Locale.getDefault())
    return "${dateFmt.format(java.util.Date(ts))} · $time"
}

/**
 * Clean a stored title for display. Strips:
 *   • YAML frontmatter remnants
 *   • Markdown image syntax `![alt](url)`
 *   • Markdown link syntax `[text](url)` → keeps just `text`
 *   • Obsidian wikilinks `[[Target|Alias]]` → keeps alias if present, else target
 *   • Heading hashes, bold/italic markers
 *
 * This is the same idea as HomeScreen.stripMarkdownNoise but limited to one
 * line and kept private to this file so I don't break HomeScreen's existing
 * cleanup pipeline. Both functions can diverge if needed.
 *
 * The reason this matters for search results: the indexer captures the first
 * `# Heading` line verbatim, including any markdown link syntax. So a heading
 * like `# [Am I a Perfectionist? | Young People Ask](https://.../teenager/...)`
 * gets stored with the URL inside. When displayed on one truncated line, the
 * URL eats the visible space and any highlighted match in the URL is hidden
 * past the ellipsis. Stripping the link wrapper at display time keeps the
 * visible text clean and lets the highlighter mark matches in the part the
 * user can actually see.
 */
private fun cleanTitleForDisplay(raw: String): String {
    var t = raw.trim()
    if (t.startsWith("---")) {
        val end = t.indexOf("---", 3)
        if (end > 0) t = t.substring(end + 3).trim()
    }
    t = t
        .replace(Regex("^#+\\s+"), "")
        .replace(Regex("!\\[[^\\]]*]\\([^)]*\\)"), "")
        .replace(Regex("\\[([^\\]]+)]\\([^)]*\\)"), "$1")
        .replace(Regex("\\[\\[([^\\[\\]|#^\\n]+)(?:#[^\\[\\]|\\n]*)?(?:\\^[^\\[\\]|\\n]*)?(?:\\|([^\\[\\]\\n]+))?]]")) { m ->
            m.groupValues[2].ifBlank { m.groupValues[1] }
        }
        .replace(Regex("\\*\\*([^*]+)\\*\\*"), "$1")
        .replace(Regex("__([^_]+)__"), "$1")
        .replace(Regex("`([^`]+)`"), "$1")
        .replace(Regex("\\s+"), " ")
        .trim()
    return t.ifBlank { raw.trim() }
}

/**
 * Given a long text and a list of search terms, return a ~70-character window
 * centred on the first occurrence of any term — with "…" prefixes/suffixes
 * when the window doesn't span the full text. Returns null if no term is
 * found.
 *
 * Used as a fallback "found in URL" hint when the cleaned title and path
 * don't contain a visible match but the original raw title did (typically
 * inside a markdown link URL that got stripped).
 */
private fun matchContextSnippet(haystack: String, needles: List<String>): String? {
    if (haystack.isEmpty() || needles.isEmpty()) return null
    val lower = haystack.lowercase()
    var firstIdx = -1
    var firstLen = 0
    for (n in needles) {
        val needle = n.lowercase()
        if (needle.isEmpty()) continue
        val idx = lower.indexOf(needle)
        if (idx >= 0 && (firstIdx < 0 || idx < firstIdx)) {
            firstIdx = idx
            firstLen = needle.length
        }
    }
    if (firstIdx < 0) return null
    val window = 70
    val before = (window - firstLen) / 2
    val start = (firstIdx - before).coerceAtLeast(0)
    val end = (firstIdx + firstLen + before).coerceAtMost(haystack.length)
    val prefix = if (start > 0) "… " else ""
    val suffix = if (end < haystack.length) " …" else ""
    return prefix + haystack.substring(start, end) + suffix
}

/**
 * v4.17.0 — Stopword list used by the multi-word match filter.
 *
 * Words here don't count toward the "result must contain at least 2 meaningful
 * matches" threshold. Without this, a query like
 *   "what happened to the holy ones"
 * would treat "what", "the", "to" as searchable content and skew the count.
 *
 * Mirrors the JS-side FALLBACK_STOPWORDS in render.js, extended with the
 * common interrogative pronouns ("what", "who", "when", etc.) that almost
 * always appear in natural-language questions but never carry the user's
 * actual intent.
 */
private val SEARCH_RESULT_STOPWORDS = setOf(
    // Articles & basic prepositions
    "the", "a", "an", "of", "to", "in", "on", "for", "at", "by",
    "with", "from", "as", "into", "onto", "upon", "about", "between", "among",
    // Conjunctions
    "and", "or", "but", "if", "so", "than", "then", "because",
    // Be / have / do auxiliaries
    "is", "are", "was", "were", "be", "been", "being",
    "do", "does", "did", "doing", "done",
    "has", "have", "had", "having",
    "will", "would", "shall", "should", "can", "could", "may", "might", "must",
    // Pronouns
    "it", "its", "this", "that", "these", "those",
    "i", "me", "my", "we", "us", "our",
    "you", "your", "he", "him", "his", "she", "her", "they", "them", "their",
    // Common interrogatives
    "what", "who", "whom", "whose", "when", "where", "why", "how", "which"
)

/**
 * v4.24.0 — Relevance percentage chip shown at the top-right of each
 * search result. Color-codes the match strength so the user gets a
 * quick visual read:
 *
 *   ≥75% — strong match, green tint
 *   55–74% — medium, blue tint (M3 primary container)
 *   <55% — weak, neutral surfaceVariant
 *
 * The exact thresholds are tuned for BGE-large cosine values, which
 * typically land in [0.40, 0.85] for related content. With the reranker
 * on, the score is a sigmoid-of-logit so genuine matches push much
 * higher (often 0.90+).
 */
@androidx.compose.runtime.Composable
private fun ChatRelevanceChip(score: Float) {
    val pct = (score.coerceIn(0f, 1f) * 100).toInt()
    val bg = when {
        pct >= 75 -> androidx.compose.ui.graphics.Color(0xFF1F8B3F).copy(alpha = 0.22f)
        pct >= 55 -> androidx.compose.material3.MaterialTheme.colorScheme.primaryContainer
        else -> androidx.compose.material3.MaterialTheme.colorScheme.surfaceVariant
    }
    val fg = when {
        pct >= 75 -> androidx.compose.ui.graphics.Color(0xFF155724)
        pct >= 55 -> androidx.compose.material3.MaterialTheme.colorScheme.onPrimaryContainer
        else -> androidx.compose.material3.MaterialTheme.colorScheme.onSurfaceVariant
    }
    androidx.compose.foundation.layout.Box(
        modifier = androidx.compose.ui.Modifier
            .background(bg, androidx.compose.foundation.shape.RoundedCornerShape(8.dp))
            .padding(horizontal = 8.dp, vertical = 3.dp)
    ) {
        Text(
            "$pct%",
            fontSize = 11.sp,
            fontWeight = FontWeight.Bold,
            color = fg
        )
    }
}

/**
 * v5.4.76cc — Small lavender chip painted on a search result row when
 * the row was reachable *only* through an LLM-paraphrased sub-query,
 * never through the user's original tokens or the Kotlin synonym
 * expander. Matches the same lavender used for
 * `.llm-hit` inside articles and for the softer snippet overlay on
 * this screen, so the visual trace is coherent from result → snippet →
 * article body.
 */
@androidx.compose.runtime.Composable
private fun AiTraceChip() {
    val bg = androidx.compose.ui.graphics.Color(0xFFA78BFA).copy(alpha = 0.22f)
    val fg = androidx.compose.ui.graphics.Color(0xFF6D28D9)
    androidx.compose.foundation.layout.Box(
        modifier = androidx.compose.ui.Modifier
            .background(bg, androidx.compose.foundation.shape.RoundedCornerShape(8.dp))
            .padding(horizontal = 8.dp, vertical = 3.dp)
    ) {
        Text(
            "\u2728 AI",
            fontSize = 11.sp,
            fontWeight = FontWeight.Bold,
            color = fg
        )
    }
}

/**
 * v5.4.79cc — The pumping-brain toggle sitting at the right edge of the
 * Search screen's search bar. Serves two roles simultaneously:
 *
 *   1. **Ambient status indicator.** When [active] is true and the LLM
 *      multi-query path will fire on the next submit, the brain pulses
 *      (scales 1.0 ↔ 1.22 on a ~700 ms loop) — a visual "the AI is
 *      awake and about to think about this" signal. When [active] is
 *      false, the brain sits static and dimmed to about 40% alpha.
 *
 *   2. **In-line toggle.** Tapping calls [onToggle], which flips
 *      [AppViewModel.aiLlmSearchEnabled]. This is the *same*
 *      preference the Settings-screen switch writes, so the two
 *      surfaces stay coherent — flipping the Settings switch will
 *      update the brain immediately, and vice versa.
 *
 * The brain is rendered as the unicode emoji "🧠" so we avoid pulling
 * in an icon-font asset just for one glyph. The pulse is implemented
 * via [androidx.compose.animation.core.rememberInfiniteTransition] +
 * [androidx.compose.animation.core.animateFloat], gated on [active] so
 * it fully stops when off (no CPU cost while dim).
 */
@androidx.compose.runtime.Composable
private fun PumpingBrainToggle(
    active: Boolean,
    onToggle: () -> Unit
) {
    // v5.4.81cc — Manual per-frame pulse instead of
    // `rememberInfiniteTransition` / `animateFloat`. The infinite
    // transition variant in v5.4.79cc–v5.4.80cc lived inside the
    // OutlinedTextField's `trailingIcon` slot, which recomposes on
    // every keystroke while typing. That combination surfaces enough
    // edge cases across Compose versions (animation reset on
    // recomposition, reversed-repeat with initialValue==targetValue,
    // subcomposition disposal timing) that it was the leading
    // suspect for the "app crashes on typing" report. Rewriting the
    // pulse as `LaunchedEffect(active) { while (isActive) withFrameNanos {…} }`
    // sidesteps all of that: the effect is keyed on `active` so it
    // starts once when the toggle turns on and cancels cleanly when
    // the toggle turns off or the composable leaves the composition;
    // typing-time recompositions leave the effect alone.
    var scale by androidx.compose.runtime.remember {
        androidx.compose.runtime.mutableStateOf(1f)
    }
    androidx.compose.runtime.LaunchedEffect(active) {
        if (!active) {
            scale = 1f
            return@LaunchedEffect
        }
        val start = androidx.compose.runtime.withFrameNanos { it }
        while (true) {
            // withFrameNanos suspends until the next animation frame and
            // cooperatively throws CancellationException if the enclosing
            // LaunchedEffect is cancelled — no separate isActive check
            // needed, the loop unwinds naturally on toggle-off or
            // composable disposal.
            val now = androidx.compose.runtime.withFrameNanos { it }
            val elapsedMs = (now - start) / 1_000_000L
            // Half-sine bounce every 1.4s: 1.00 → 1.22 → 1.00.
            val phase = (elapsedMs % 1400L) / 1400.0
            val pulse = kotlin.math.sin(phase * 2 * Math.PI)
                .coerceAtLeast(0.0)
            scale = (1.0 + 0.22 * pulse).toFloat()
        }
    }
    IconButton(
        onClick = onToggle,
        modifier = Modifier
            .size(44.dp)
            .graphicsLayer(
                scaleX = scale,
                scaleY = scale,
                alpha = if (active) 1f else 0.40f
            )
    ) {
        Text(
            text = "\uD83E\uDDE0",  // 🧠 brain emoji
            fontSize = 24.sp
        )
    }
}

/**
 * v4.24.0 — Phrase-level snippet highlighting.
 *
 * Splits text into sentences and highlights ONLY sentences that contain
 * 2+ distinct query terms. Sentences with 1 incidental match get no
 * highlight at all. This is the opposite of the previous per-word
 * highlighter: previously every "the" and "was" lit up yellow, which
 * made truly irrelevant results visually indistinguishable from
 * genuinely-relevant ones.
 *
 * Within highlighted sentences, the matched terms themselves get a
 * stronger bold-italic style so the user can still see what matched
 * inside the broader context.
 *
 * v5.4.133cc — AI (LLM) sentence-level highlighting.
 *
 * Previously the LLM/AI highlighting painted only individual matched
 * words in lavender, scattering isolated word highlights across the
 * snippet — which looked like random noise and made the AI signal hard
 * to read. The fix mirrors the primary-term logic: if a sentence
 * contains at least one LLM paraphrase term, the WHOLE sentence gets a
 * lavender background. Individual bold-italic marks are still drawn
 * inside the sentence so the exact matching phrase is obvious within
 * the broader highlighted context. Sentences with no LLM term get no
 * AI highlight at all — no word-by-word scatter.
 *
 * Combined sentences (primary 2+ terms AND an LLM term) receive the
 * primary yellow background; the yellow signal is dominant.
 */
@androidx.compose.runtime.Composable
private fun highlightSentences(
    text: String,
    terms: List<String>,
    llmTerms: List<String> = emptyList()
): androidx.compose.ui.text.AnnotatedString {
    val termsLower = terms.map { it.lowercase() }
        .filter { it.length >= 3 }   // skip stopword-sized noise
        .distinct()
    // v5.4.76cc — LLM paraphrase terms get their own filtered/lowered
    // list, applied *in addition to* the primary term highlighting.
    // Longest-first so a paraphrase like "friendship with God" wins
    // over "friendship" when both are candidates for wrapping.
    val llmTermsLower = llmTerms.map { it.lowercase().trim() }
        .filter { it.length >= 3 }
        .distinct()
        .sortedByDescending { it.length }

    if (termsLower.isEmpty() && llmTermsLower.isEmpty()) {
        return androidx.compose.ui.text.AnnotatedString(text)
    }

    val highlightBg = androidx.compose.material3.MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.55f)
    val llmHighlightBg = androidx.compose.ui.graphics.Color(0xFFA78BFA).copy(alpha = 0.32f)

    return androidx.compose.ui.text.buildAnnotatedString {
        // Sentence splitter — punctuation followed by whitespace. Keeps
        // the punctuation with the preceding sentence (lookbehind). Also
        // splits on newline boundaries because markdown snippets often
        // come back as separate lines without terminal punctuation.
        val parts = text.split(Regex("(?<=[.!?])\\s+|\\n+"))
        for ((idx, raw) in parts.withIndex()) {
            val sentence = raw
            val lower = sentence.lowercase()
            val distinctMatches = termsLower.count { it in lower }
            // v5.4.133cc — sentence-level AI match: does this sentence
            // contain at least one LLM paraphrase term? If yes, the
            // whole sentence is a relevant AI-surfaced statement and
            // should be highlighted as a unit, not word-by-word.
            val hasLlmMatch = llmTermsLower.any { it in lower }

            when {
                distinctMatches >= 2 -> {
                    // Primary phrase match — yellow background covers the
                    // whole sentence; yellow is the dominant signal even
                    // when an LLM term also appears. Bold-italic the
                    // matched terms inside it; LLM terms get no extra
                    // decoration on top of yellow.
                    withStyle(
                        androidx.compose.ui.text.SpanStyle(background = highlightBg)
                    ) {
                        appendWithTermStyle(sentence, termsLower, llmTermsLower, androidx.compose.ui.graphics.Color.Transparent)
                    }
                }
                hasLlmMatch -> {
                    // v5.4.133cc — AI sentence match: whole sentence gets
                    // lavender background. Within it, bold-italic the LLM
                    // terms so the user can see exactly what phrase the AI
                    // matched, inside the broader highlighted context.
                    // No more scattered per-word lavender blobs.
                    withStyle(
                        androidx.compose.ui.text.SpanStyle(background = llmHighlightBg)
                    ) {
                        appendWithTermStyle(sentence, emptyList(), llmTermsLower, androidx.compose.ui.graphics.Color.Transparent)
                    }
                }
                else -> {
                    // No match of any kind — plain text, no highlight.
                    append(sentence)
                }
            }
            if (idx < parts.size - 1) append(" ")
        }
    }
}

/**
 * Append [text] to the builder, with each occurrence of any term in
 * [termsLower] rendered as bold-italic. Used inside [highlightSentences]
 * for matched sentences so the matched terms stand out within the
 * highlighted background.
 *
 * v5.4.76cc — Also paints each occurrence of any [llmTermsLower] entry
 * with a softer lavender background so LLM-surfaced words are
 * visually distinct from both plain text and the primary
 * yellow-highlighted terms. LLM background is only applied when the
 * span is not already part of a bold-italic primary-term match — a
 * word never wears both stripes at once, keeping the yellow primary
 * signal dominant when both would apply.
 */
private fun androidx.compose.ui.text.AnnotatedString.Builder.appendWithTermStyle(
    text: String,
    termsLower: List<String>,
    llmTermsLower: List<String> = emptyList(),
    llmBg: androidx.compose.ui.graphics.Color =
        androidx.compose.ui.graphics.Color.Transparent
) {
    val lower = text.lowercase()
    var i = 0
    while (i < text.length) {
        // Find the earliest primary-term match at position i or later.
        var bestStart = text.length
        var bestEnd = text.length
        var bestKind = 0  // 0=none, 1=primary term, 2=llm term
        for (term in termsLower) {
            val idx = lower.indexOf(term, i)
            if (idx >= 0 && idx < bestStart) {
                bestStart = idx
                bestEnd = idx + term.length
                bestKind = 1
            }
        }
        // If we found no primary match, look for the earliest LLM term
        // match instead. Primary wins on ties in position because a
        // yellow "term-hit" is a stronger signal than a lavender
        // "llm-hit".
        if (bestKind == 0 && llmTermsLower.isNotEmpty()) {
            for (term in llmTermsLower) {
                val idx = lower.indexOf(term, i)
                if (idx >= 0 && idx < bestStart) {
                    bestStart = idx
                    bestEnd = idx + term.length
                    bestKind = 2
                }
            }
        }
        if (bestStart >= text.length) {
            append(text.substring(i))
            return
        }
        if (bestStart > i) append(text.substring(i, bestStart))
        if (bestKind == 2) {
            // v5.4.133cc — LLM paraphrase match inside a sentence.
            // When llmBg is Transparent the sentence already has a
            // lavender background (sentence-level AI highlight), so we
            // use bold-italic to mark the matched phrase within it —
            // consistent with how primary terms are marked within their
            // yellow sentence. When llmBg is opaque we are in a
            // non-sentence-highlighted path (legacy fallback) and paint
            // the per-word background as before.
            if (llmBg == androidx.compose.ui.graphics.Color.Transparent) {
                withStyle(
                    androidx.compose.ui.text.SpanStyle(
                        fontWeight = FontWeight.Bold,
                        fontStyle = androidx.compose.ui.text.font.FontStyle.Italic
                    )
                ) {
                    append(text.substring(bestStart, bestEnd))
                }
            } else {
                withStyle(
                    androidx.compose.ui.text.SpanStyle(background = llmBg)
                ) {
                    append(text.substring(bestStart, bestEnd))
                }
            }
        } else {
            withStyle(
                androidx.compose.ui.text.SpanStyle(
                    fontWeight = FontWeight.Bold,
                    fontStyle = androidx.compose.ui.text.font.FontStyle.Italic
                )
            ) {
                append(text.substring(bestStart, bestEnd))
            }
        }
        i = bestEnd
    }
}

/**
 * v5.4.6 — Manual rerank banner.
 *
 * A prominent button placed at the top of the results list (above the
 * long-press hint, below the WebSearchPrompt) inviting the user to
 * apply the cross-encoder rerank to the currently displayed results.
 *
 * Two states:
 *   • Idle    — "✨ Rerank these results for relevance"  (tappable)
 *   • Working — "🔄 Reranking..."                       (shows spinner,
 *                                                         tap disabled)
 *
 * Visibility is controlled by the caller (showManualRerankButton); this
 * composable just renders whatever the caller passes.
 */
@androidx.compose.runtime.Composable
private fun ManualRerankBanner(
    inProgress: Boolean,
    onTap: () -> Unit
) {
    androidx.compose.material3.Surface(
        color = androidx.compose.material3.MaterialTheme.colorScheme.primaryContainer,
        shape = androidx.compose.foundation.shape.RoundedCornerShape(12.dp),
        tonalElevation = 2.dp,
        modifier = androidx.compose.ui.Modifier
            .fillMaxWidth()
            .padding(horizontal = 14.dp, vertical = 6.dp)
            .clickable(enabled = !inProgress) { onTap() }
    ) {
        androidx.compose.foundation.layout.Row(
            modifier = androidx.compose.ui.Modifier
                .fillMaxWidth()
                .padding(horizontal = 14.dp, vertical = 10.dp),
            verticalAlignment = androidx.compose.ui.Alignment.CenterVertically
        ) {
            androidx.compose.foundation.layout.Column(
                modifier = androidx.compose.ui.Modifier.weight(1f)
            ) {
                Text(
                    text = if (inProgress)
                        "\uD83D\uDD04  Reranking results\u2026"
                    else
                        "\u2728  Rerank these results for relevance",
                    fontSize = 13.sp,
                    fontWeight = androidx.compose.ui.text.font.FontWeight.SemiBold,
                    color = androidx.compose.material3.MaterialTheme.colorScheme.onPrimaryContainer
                )
                Text(
                    text = if (inProgress)
                        "Cross-encoder is scoring the top candidates."
                    else
                        "Re-order the top 8 using the cross-encoder. Tap to apply.",
                    fontSize = 11.sp,
                    color = androidx.compose.material3.MaterialTheme.colorScheme.onPrimaryContainer
                        .copy(alpha = 0.75f),
                    lineHeight = 14.sp
                )
            }
            androidx.compose.foundation.layout.Spacer(
                androidx.compose.ui.Modifier.width(10.dp)
            )
            if (inProgress) {
                androidx.compose.material3.CircularProgressIndicator(
                    modifier = androidx.compose.ui.Modifier.size(20.dp),
                    strokeWidth = 2.dp,
                    color = androidx.compose.material3.MaterialTheme.colorScheme.onPrimaryContainer
                )
            } else {
                Text(
                    "\u27A4",
                    fontSize = 18.sp,
                    color = androidx.compose.material3.MaterialTheme.colorScheme.onPrimaryContainer
                )
            }
        }
    }
}

/**
 * v5.4.30 — Persistent recent-searches panel shown at tablet width in
 * SearchScreen's left column. Uses only existing state (vm.recentSearches
 * + vm.query) so it's low-risk: tapping a row sets the search bar's text
 * and the main pipeline reacts as normal.
 *
 * Recent searches are de-duplicated by query string so a query that hit
 * five different notes shows as one row, ordered newest-first.
 */
@androidx.compose.runtime.Composable
private fun SearchTabletRecentsPanel(
    vm: com.tebogo.markvault.AppViewModel,
    recentSearches: List<com.tebogo.markvault.RecentSearch>,
    modifier: Modifier = Modifier
) {
    val uniqueQueries = androidx.compose.runtime.remember(recentSearches) {
        val seen = linkedSetOf<String>()
        recentSearches.forEach { rs -> seen.add(rs.query) }
        seen.toList()
    }
    Column(
        modifier = modifier
            .background(MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.25f))
            .padding(14.dp)
    ) {
        Text(
            "\uD83D\uDD53 Recent searches",
            fontSize = 15.sp,
            fontWeight = FontWeight.Bold,
            color = MaterialTheme.colorScheme.onSurface
        )
        Spacer(Modifier.height(4.dp))
        Text(
            if (uniqueQueries.isEmpty())
                "None yet. Recent searches will show here as you use them."
            else
                "${uniqueQueries.size} \u00B7 tap to re-run",
            fontSize = 11.sp,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
            lineHeight = 15.sp
        )
        Spacer(Modifier.height(12.dp))
        if (uniqueQueries.isNotEmpty()) {
            LazyColumn(Modifier.weight(1f).fillMaxWidth()) {
                items(uniqueQueries, key = { it }) { q ->
                    Surface(
                        color = androidx.compose.ui.graphics.Color.Transparent,
                        shape = RoundedCornerShape(8.dp),
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(vertical = 2.dp)
                            .clickable { vm.query.value = q }
                    ) {
                        Text(
                            q,
                            Modifier.padding(horizontal = 10.dp, vertical = 8.dp),
                            fontSize = 13.sp,
                            color = MaterialTheme.colorScheme.onSurface,
                            maxLines = 2,
                            overflow = TextOverflow.Ellipsis
                        )
                    }
                }
            }
        }
    }
}

/**
 * v5.4.169cc — Custom 3D-styled search-mode toggle, replacing the stock
 * Material3 SegmentedButton (which only exposes flat color slots — no
 * gradient or shadow customization surface, so it can't produce genuine
 * depth). "Shallow search" = SearchMode.TITLES (searches only note
 * titles — less data scanned, faster, hence "shallow"). "Deep search" =
 * SearchMode.CONTENT (searches full note content — hence "deep"). This
 * is purely a relabeling of the existing two modes; the SearchMode enum
 * and all underlying search logic are completely unchanged.
 *
 * Each segment renders as a glossy "raised button": a two-stop vertical
 * gradient (bright top edge catching light, darker toward the bottom),
 * a lifted drop shadow, and a thin light-catching top border — all
 * brighter and more saturated on the selected segment than the
 * unselected one, per the request that "the selected one must ...
 * be brighter."
 *
 * The "must animate" part plays as a brief pop/bounce exactly ONCE when
 * a segment BECOMES selected, then settles to a static brighter state —
 * it does not loop or re-trigger while simply staying selected. This is
 * a deliberate choice: v5.4.168cc just fixed three always-on
 * rememberInfiniteTransition animations that ran continuously and
 * measurably drained battery; introducing a fourth one here to satisfy
 * "must animate" would undo that fix for the price of this one control.
 * A transition-triggered animation (via animateColorAsState / a
 * one-shot Animatable spring, both of which settle and stop requesting
 * frames) delivers the same felt "it animates" moment without an
 * ongoing cost.
 */
@Composable
private fun ShallowDeepToggle(
    mode: SearchMode,
    onModeChange: (SearchMode) -> Unit,
    modifier: Modifier = Modifier
) {
    val uiAnim = UiAnim.prefs
    Row(
        modifier
            .clip(RoundedCornerShape(14.dp))
            .background(
                Brush.verticalGradient(
                    listOf(
                        MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.55f),
                        MaterialTheme.colorScheme.surface.copy(alpha = 0.85f)
                    )
                )
            )
            .border(
                width = 1.dp,
                color = MaterialTheme.colorScheme.outline.copy(alpha = 0.4f),
                shape = RoundedCornerShape(14.dp)
            )
            .padding(4.dp)
    ) {
        ToggleSegment(
            label = "\uD83D\uDCD1 Shallow search",
            selected = mode == SearchMode.TITLES,
            onClick = { onModeChange(SearchMode.TITLES) },
            uiAnim = uiAnim,
            modifier = Modifier.weight(1f)
        )
        Spacer(Modifier.width(4.dp))
        ToggleSegment(
            label = "\uD83D\uDD0E Deep search",
            selected = mode == SearchMode.CONTENT,
            onClick = { onModeChange(SearchMode.CONTENT) },
            uiAnim = uiAnim,
            modifier = Modifier.weight(1f)
        )
    }
}

@Composable
private fun ToggleSegment(
    label: String,
    selected: Boolean,
    onClick: () -> Unit,
    uiAnim: UiAnimPrefs,
    modifier: Modifier = Modifier
) {
    // One-time pop when this segment BECOMES selected — see the doc
    // comment on ShallowDeepToggle above for why this is transition-
    // triggered rather than a continuous loop.
    val popScale = remember { Animatable(1f) }
    LaunchedEffect(selected) {
        if (selected && uiAnim.enabled) {
            popScale.snapTo(0.92f)
            popScale.animateTo(
                targetValue = 1f,
                animationSpec = spring(
                    dampingRatio = Spring.DampingRatioMediumBouncy,
                    stiffness = Spring.StiffnessMedium
                )
            )
        } else {
            popScale.snapTo(1f)
        }
    }
    val fadeMs = uiAnim.scaledDurationMs(220)
    val bgTop by animateColorAsState(
        targetValue = if (selected) MaterialTheme.colorScheme.primary.copy(alpha = 0.95f)
            else MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f),
        animationSpec = tween(fadeMs),
        label = "toggleBgTop"
    )
    val bgBottom by animateColorAsState(
        targetValue = if (selected) MaterialTheme.colorScheme.primary.copy(alpha = 0.65f)
            else MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.25f),
        animationSpec = tween(fadeMs),
        label = "toggleBgBottom"
    )
    val textColor by animateColorAsState(
        targetValue = if (selected) MaterialTheme.colorScheme.onPrimary
            else MaterialTheme.colorScheme.onSurfaceVariant,
        animationSpec = tween(fadeMs),
        label = "toggleText"
    )
    Box(
        modifier
            .graphicsLayer { scaleX = popScale.value; scaleY = popScale.value }
            .then(
                if (selected) Modifier.shadow(6.dp, RoundedCornerShape(10.dp), clip = false)
                else Modifier
            )
            .clip(RoundedCornerShape(10.dp))
            .background(Brush.verticalGradient(listOf(bgTop, bgBottom)))
            .then(
                if (selected)
                    Modifier.border(1.dp, Color.White.copy(alpha = 0.25f), RoundedCornerShape(10.dp))
                else Modifier
            )
            .clickable(onClick = onClick)
            .padding(vertical = 10.dp),
        contentAlignment = Alignment.Center
    ) {
        Text(
            label,
            color = textColor,
            fontWeight = if (selected) FontWeight.Bold else FontWeight.Normal,
            fontSize = 13.sp
        )
    }
}
