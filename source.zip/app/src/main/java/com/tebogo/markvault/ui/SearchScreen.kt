package com.tebogo.markvault.ui

import androidx.compose.foundation.basicMarquee
import androidx.compose.foundation.clickable
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInVertically
import androidx.compose.animation.slideOutVertically
import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.foundation.border
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.foundation.background
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.DropdownMenu
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.derivedStateOf
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.compose.runtime.remember
import androidx.compose.runtime.snapshotFlow
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.saveable.rememberSaveable
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.platform.LocalFocusManager
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.graphics.luminance
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.SpanStyle
import androidx.compose.ui.text.buildAnnotatedString
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.text.withStyle
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.compose.LocalLifecycleOwner
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.repeatOnLifecycle
import kotlinx.coroutines.isActive
import androidx.navigation.NavController
import com.tebogo.markvault.AppViewModel
import com.tebogo.markvault.SearchMode
import com.tebogo.markvault.search.ModelDescriptor
import com.tebogo.markvault.search.QueryContribution
import com.tebogo.markvault.search.ResultQueryProvenance
import com.tebogo.markvault.search.ResultQuerySource
import com.tebogo.markvault.search.QueryExpansionPresentation
import com.tebogo.markvault.search.VisibleExpansionQuery
import com.tebogo.markvault.ai.QuerySource
import com.tebogo.markvault.ai.QueryPlanHistory
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.material3.VerticalDivider

@OptIn(ExperimentalMaterial3Api::class, ExperimentalFoundationApi::class)
@Composable
fun SearchScreen(vm: AppViewModel, nav: NavController) {
    val query by vm.query.collectAsStateWithLifecycle()
    val mode by vm.mode.collectAsStateWithLifecycle()
    val quotePhrase by vm.quotePhrase.collectAsStateWithLifecycle()
    // v5.4.146cc — Needed in onValueChange to cancel in-flight searches
    // on keystroke when live search is OFF.
    val liveSearchEnabled by vm.liveSearchEnabled.collectAsStateWithLifecycle()
    val isSearchBusy by vm.searchBusy.collectAsStateWithLifecycle()

    // v5.4.13 — Auto-wrap the search query in quotes when the exact-phrase
    // toggle is enabled (and unwrap when it's disabled). This makes the
    // search field visibly reflect the toggle state, restoring the old
    // behaviour the user expected. Without this, enabling the toggle
    // changed nothing visible — search was still wrapping internally, but
    // the lack of any UI feedback made it feel like the toggle did
    // nothing.
    //
    // Guarded against feedback loops: we only write back when the
    // expected wrapped form differs from the current value, so writing
    // the same value doesn't trigger another LaunchedEffect run.
    LaunchedEffect(quotePhrase) {
        val current = query.trim()
        if (current.length < 2) return@LaunchedEffect
        val alreadyQuoted = current.startsWith("\"") && current.endsWith("\"")
        val newValue = when {
            quotePhrase && !alreadyQuoted -> "\"$current\""
            !quotePhrase && alreadyQuoted -> current.removeSurrounding("\"")
            else -> current
        }
        if (newValue != query) {
            vm.query.value = newValue
        }
    }
    val results by vm.results.collectAsStateWithLifecycle()
    val lastSearchDurationMs by vm.lastSearchDurationMs.collectAsStateWithLifecycle()
    // v5.4.6 — Manual rerank overlay. If the user has tapped the
    // "Rerank these results" button and the rerank applies to the
    // current query, we render the reranked order instead of the base
    // results. The check is just a string-equality on the query — if
    // the user types more, the overlay's query stops matching and the
    // base results take over.
    val manualRerank by vm.manualRerankResult.collectAsStateWithLifecycle()
    val manualRerankBusy by vm.manualRerankInProgress.collectAsStateWithLifecycle()
    val rerankerInstalled by vm.rerankerInstalled.collectAsStateWithLifecycle()
    // v5.4.77cc — Which hit ids in the current results appeared only
    // through LLM-paraphrased sub-queries (never via the original
    // tokens or Kotlin synonym expander). Read from the VM's
    // side-channel StateFlow instead of a field on SearchHit so
    // SearchHit stays a pure DB projection (avoids Room 2.8.4 KSP
    // strictness). Painted as the "✨ AI" chip on the matching rows.
    val llmMatchedIds by vm.llmMatchedHitIds.collectAsStateWithLifecycle()
    val resultScopeById by vm.resultScopeById.collectAsStateWithLifecycle()
    val resultQueryProvenanceById by vm.resultQueryProvenance.collectAsStateWithLifecycle()
    // Reactive history covers every issued expansion source (LLM, synonyms,
    // T5 and Question Awareness); LlmExpansionHistory alone never did.
    val recordedQueryPlans by QueryPlanHistory.entries.collectAsStateWithLifecycle()
    val savedSessions by vm.savedSearchSessions.collectAsStateWithLifecycle()
    val activeSavedSearchId by vm.activeSavedSearchSessionId.collectAsStateWithLifecycle()
    val activeSavedIndex = savedSessions.indexOfFirst { it.id == activeSavedSearchId }
    // Saved-search paging deliberately uses floating buttons instead of a
    // full-screen swipe detector. This keeps the result list, vertical scroll,
    // result long-press, and Android Back gesture completely independent.
    val previousSavedSession = if (activeSavedIndex >= 0) savedSessions.getOrNull(activeSavedIndex + 1) else null
    val nextSavedSession = if (activeSavedIndex >= 0) savedSessions.getOrNull(activeSavedIndex - 1) else null
    val activeSavedSession = savedSessions.getOrNull(activeSavedIndex)
    // v5.4.79cc — Master AI multi-query toggle state, driving the
    // pumping-brain button at the right edge of the search bar. When on,
    // the brain animates (indicates the LLM is available to think about
    // this query) and every submitted search is routed through the
    // expander. When off, the brain sits static/dim and search behaves
    // as pure FTS + BGE semantic + reranker.
    val aiLlmOn by vm.aiLlmSearchEnabled.collectAsStateWithLifecycle()
    val annFastOn by vm.annSearchEnabled.collectAsStateWithLifecycle()
    val hnswFastOn by vm.hnswSearchEnabled.collectAsStateWithLifecycle()
    val questionAwarenessOn by vm.questionAwarenessEnabled.collectAsStateWithLifecycle()
    val displayedResults: List<com.tebogo.markvault.data.SearchHit> = manualRerank?.let { (rq, rhits) ->
        if (rq == query.trim()) rhits else null
    } ?: results
    // v5.4.6 / v5.4.141cc — Manual rerank button is visible whenever:
    //   • the reranker model is installed
    //   • there are results to rerank
    //   • the query is long enough (≥ 2 chars)
    //   • the current view isn't already the manual-rerank output for this query
    // The previous guard `&& (!rerankEnabled || rerankSubmitOnly)` permanently hid
    // the button when auto-rerank was fully enabled, making it unreachable. Removed.
    val showManualRerankButton: Boolean = rerankerInstalled
        && displayedResults.isNotEmpty()
        && query.trim().length >= 2
        && manualRerank?.first != query.trim()
    val topicMatches by vm.topicMatches.collectAsStateWithLifecycle()
    val recentSearches by vm.recentSearches.collectAsStateWithLifecycle()

    // v5.4.251cc — Media (video/audio) search results for this screen.
    // Deliberately an INDEPENDENT LaunchedEffect with its own debounce,
    // not woven into the note-text `results` StateFlow pipeline above
    // (a complex, already-tuned combine/flatMapLatest chain) — this
    // addition cannot regress that already-verified pipeline in any way.
    //
    // vm.searchMedia() already implements offline-first-then-online:
    // it reads the local media_items cache (mediaDao.searchLocal, works
    // with no network) immediately, THEN issues a live JW.org search and
    // upserts any new results back into that same cache — one shared
    // offline index, growing every time media is searched OR browsed
    // (see JwVideoBrowseScreen.kt's matching vm.cacheMediaItems() calls).
    val localMediaResults by vm.mediaSearchResults.collectAsStateWithLifecycle()
    val onlineMediaResults by vm.jwSearchResults.collectAsStateWithLifecycle()
    val captionVideoResults by vm.captionVideoResults.collectAsStateWithLifecycle()

    // v5.4.390cc — HARD isolation from the article/thesis search pipeline.
    // Media and CC lookup are allowed to start only AFTER the foreground article
    // search has finished. When searchBusy flips true this LaunchedEffect is
    // cancelled immediately, so captions/JW media cannot compete with loading the
    // first/second 20k embedding scope. Once article results are ready, matching
    // videos/audio are resolved independently and rendered in the top media row.
    LaunchedEffect(query, isSearchBusy) {
        val q = query.trim()
        if (q.length < 2) {
            vm.searchCaptionVideos("")
            vm.searchMedia("")
            return@LaunchedEffect
        }
        if (isSearchBusy) {
            // Remove stale media from the previous query while foreground search
            // owns resources. Do not start ANY caption/media lookup yet.
            vm.searchCaptionVideos("")
            vm.searchMedia("")
            return@LaunchedEffect
        }
        // The main live-search debounce is 220 ms. Wait beyond it so a newly
        // typed query gets a chance to enter searchBusy first; that state change
        // cancels this effect before any media/CC work can start. After a completed
        // article search, the same delay is merely a low-cost post-search yield.
        // v5.5.43 — Let freshly published article cards settle before
        // local-caption and network-media lookup begin. With the old 360 ms
        // delay, media DB/network work overlapped the 1.5-second model cleanup
        // and the user's first scroll. This remains cancellable whenever the
        // query changes or a new foreground article search starts.
        delay(2_300L)
        vm.searchCaptionVideos(q)
        delay(80L)
        vm.searchMedia(q)
    }
    // Merge caption videos + local metadata + online metadata only for UI.
    // by jwKey so a query that matches both shows each item once — the
    // online copy wins on conflict since it may carry a fresher
    // thumbnail/stream URL than what was cached.
    val combinedMediaResults: List<com.tebogo.markvault.data.MediaItem> = remember(captionVideoResults, localMediaResults, onlineMediaResults) {
        val byKey = LinkedHashMap<String, com.tebogo.markvault.data.MediaItem>()
        // Caption matches are first and keep their exact timestamp/snippet.
        captionVideoResults.forEach { byKey[it.jwKey.ifBlank { it.title }] = it }
        localMediaResults.forEach { local ->
            val key = local.jwKey.ifBlank { local.title }
            byKey.putIfAbsent(key, local)
        }
        onlineMediaResults.forEach { online ->
            val key = online.jwKey.ifBlank { online.title }
            val existing = byKey[key]
            // v5.4.387cc — A local transcript hit carries the matched caption
            // snippet + exact playback timestamp. Do not let the same online
            // JW metadata row erase those two search-result-only fields.
            if (existing == null ||
                !existing.description.startsWith(com.tebogo.markvault.data.VideoTranscriptStore.RESULT_PREFIX)) {
                byKey[key] = online
            }
        }
        byKey.values.toList()
    }
    // v5.4.255cc — Long-press target for the media carousel/panel below —
    // "long press from all interfaces where media appears" must give the
    // Favourite/Add-to-Playlist menu here too, not just the browse screen.
    var longPressMediaItem by remember { mutableStateOf<com.tebogo.markvault.data.MediaItem?>(null) }

    // v5.4.111cc — "Get accurate results" chip flash driver. The
    // animatable pulses 0→1→0 three times whenever a search completes
    // (searchBusy transitions from true to false with results present),
    // producing the green-tint + slight-scale pulse without hiding the
    // chip. The chip reads `accurateFlashPulse` for its container
    // colour + scale. Guarded so it only fires on a genuine
    // busy→done transition, not on every recomposition.
    val accurateFlash = remember { androidx.compose.animation.core.Animatable(0f) }
    val accurateFlashPulse = accurateFlash.value
    val searchBusyForFlash by vm.searchBusy.collectAsStateWithLifecycle()
    var prevSearchBusy by remember { mutableStateOf(false) }
    LaunchedEffect(searchBusyForFlash) {
        // Detect the falling edge: was busy, now idle.
        if (prevSearchBusy && !searchBusyForFlash) {
            // Only flash if there's something to celebrate — i.e. the
            // query is a real search, not a cleared box.
            if (vm.query.value.trim().length >= 2) {
                accurateFlash.snapTo(0f)
                repeat(3) {
                    accurateFlash.animateTo(
                        1f,
                        animationSpec = androidx.compose.animation.core.tween(
                            220, easing = androidx.compose.animation.core.FastOutSlowInEasing
                        )
                    )
                    accurateFlash.animateTo(
                        0f,
                        animationSpec = androidx.compose.animation.core.tween(
                            260, easing = androidx.compose.animation.core.FastOutSlowInEasing
                        )
                    )
                }
            }
        }
        prevSearchBusy = searchBusyForFlash
    }

    // v5.4.335cc — Resolve Workspace/tablet mode before the scroll-collapse
    // controller. Workspace Search always auto-collapses the full search-control
    // stack so recent searches/results can reclaim its vertical space.
    val screenWidthDp = androidx.compose.ui.platform.LocalConfiguration.current.screenWidthDp
    val isTabletWidth = screenWidthDp >= 600
    val uiModeSearch by vm.uiMode.collectAsStateWithLifecycle()
    val forceTabletUi by vm.forceWorkspaceTabletUi.collectAsStateWithLifecycle()
    val workspaceTabletUi = uiModeSearch == "workspace" && (isTabletWidth || forceTabletUi)

    // v5.4.111cc — Collapsible "top utilities" (search bar + mode
    // segments + chip row). Two ways to reclaim vertical space for
    // results:
    //   • Auto-hide on scroll: scrolling the results list DOWN
    //     collapses them; scrolling UP (even a little) or reaching the
    //     top brings them back. Standard reading-app pattern.
    //   • Manual handle: a slim always-visible bar with a chevron the
    //     user can tap to force-collapse / force-expand regardless of
    //     scroll.
    // The hoisted LazyListState drives the auto behaviour; a manual
    // override flag takes precedence when the user taps the handle.
    val resultsListState = androidx.compose.foundation.lazy.rememberLazyListState()
    var topUtilitiesExpanded by remember { mutableStateOf(true) }
    // Manual override: null = follow scroll; true/false = user forced.
    var manualOverride by remember { mutableStateOf<Boolean?>(null) }
    // v5.4.367cc — Prevent the bars' own layout change from being
    // misread as an opposite user scroll and causing a hide/show loop.
    var toolbarVisibilityChangedAt by remember { mutableStateOf(0L) }

    // Standard Search keeps the existing fullscreen preference. Workspace Search
    // always uses scroll-driven collapse because the persistent Workspace shell
    // already provides navigation while the controls are hidden.
    val enableFullscreenMode by vm.enableFullscreenMode.collectAsStateWithLifecycle()
    val autoCollapseSearchControls = workspaceTabletUi || enableFullscreenMode

    // Observe scrolling from the coroutine, so each pixel does not invalidate SearchScreen.
    LaunchedEffect(resultsListState, autoCollapseSearchControls) {
        if (!autoCollapseSearchControls) {
            topUtilitiesExpanded = true
            manualOverride = null
            return@LaunchedEffect
        }
        val tracker = SearchScrollTracker(
            resultsListState.firstVisibleItemIndex,
            resultsListState.firstVisibleItemScrollOffset
        )
        snapshotFlow {
            resultsListState.firstVisibleItemIndex to resultsListState.firstVisibleItemScrollOffset
        }.collect { (idx, off) ->
            val now = android.os.SystemClock.elapsedRealtime()
            tracker.update(idx, off, topUtilitiesExpanded, toolbarVisibilityChangedAt, now)?.let { expanded ->
                topUtilitiesExpanded = expanded
                manualOverride = null
                toolbarVisibilityChangedAt = now
            }
        }
    }
    // Manual override wins when set.
    val showTopUtilities = manualOverride ?: topUtilitiesExpanded

    // v5.3.1 — Read keyword-filter pref at the top so it's available to
    // the LazyListScope content block (which is NOT @Composable and
    // can't call collectAsStateWithLifecycle itself).
    val keywordFilterOn by vm.keywordFilterEnabled.collectAsStateWithLifecycle()
    val cleanedPresentationQuery = query.trim().removeSurrounding("\"").trim()
    val presentationParaphrases = com.tebogo.markvault.ai.LlmExpansionHistory
        .get(cleanedPresentationQuery)?.paraphrases.orEmpty()
    val resultPresentation = remember(query.trim(), displayedResults, keywordFilterOn, presentationParaphrases) {
        searchResultPresentation(query.trim(), displayedResults, keywordFilterOn, presentationParaphrases)
    }
    val focus = remember { FocusRequester() }
    val focusManager = LocalFocusManager.current
    var savedSearchBarUnlocked by remember { mutableStateOf(false) }
    val savedSearchBarLocked = activeSavedSearchId != null && !savedSearchBarUnlocked

    // A restored saved search is a viewer first: no tap-focus or keyboard.
    // Long-press is the only unlock path. Switching sessions always locks
    // again and clears focus from the previous saved query.
    LaunchedEffect(activeSavedSearchId) {
        savedSearchBarUnlocked = false
        if (activeSavedSearchId != null) focusManager.clearFocus()
    }
    // v5.4.380cc — Do not request focus during saved-card dismissal.
    // The editable field is conditionally composed only after the shatter/unlock
    // transition, so requesting focus from the same state change can run before
    // FocusRequester is attached and crash Compose. Unlocking simply reveals
    // the normal field; the user can tap it to focus/bring up the keyboard.

    // v4.7 — long-press on a search result triggers an action sheet (open in
    // split, open externally, share, convert, open in graph).
    var longPressTarget by remember { mutableStateOf<SearchHit?>(null) }
    // Split-view picker: after user picks "Open in split view", we show a
    // dialog listing every OTHER open tab to pair this one with.
    var splitPickerTarget by remember { mutableStateOf<SearchHit?>(null) }
    // Convert-to dialog: user chose "Convert" → asks which target format.
    var convertTarget by remember { mutableStateOf<SearchHit?>(null) }

    // TASK 5: if the user opened Search via "Search in MarkVault" from the
    // browser's text-selection menu, consume that pending query exactly once.
    LaunchedEffect(Unit) {
        vm.consumePendingSearch()?.let { vm.query.value = it }
    }

    // v5.4.33 — Workspace/tablet mode is resolved above before the
    // scroll-collapse controller so the same state drives both layout and hiding.
    val hideTopBar = workspaceTabletUi
    var tabletRecentsOpen by rememberSaveable { mutableStateOf(false) }

    // v5.4.225cc — Deferred navigation to JW.org video browse screen.
    // State lives HERE (composable scope, not inside a LazyColumn item) so
    // the 500ms delay actually lets the GC run after freeMemoryForNavigation()
    // before Compose allocates memory for the new screen.
    var videosClicked by remember { mutableStateOf(false) }
    LaunchedEffect(videosClicked) {
        if (videosClicked) {
            kotlinx.coroutines.delay(500L)
            nav.navigate("jwVideos")
            videosClicked = false
        }
    }

    // v5.4.231cc — Media badge tap state, hoisted to composable scope (NOT
    // inside the LazyColumn item block — internal state there corrupts
    // recomposition per prior lessons). Frees memory before the
    // FloatingMediaPopup creates its ExoPlayer inline over the still-fully-
    // composed SearchScreen (LazyColumn results + any loaded semantic index).
    var pendingBadgeTitle by remember { mutableStateOf<String?>(null) }
    var pendingBadgeUrl   by remember { mutableStateOf<String?>(null) }
    var pendingBadgeKind  by remember { mutableStateOf<String?>(null) }
    LaunchedEffect(pendingBadgeUrl) {
        val url = pendingBadgeUrl
        if (url != null) {
            vm.freeMemoryForNavigation()
            kotlinx.coroutines.delay(400L)
            vm.requestMediaPopup(pendingBadgeTitle ?: "Media", url, pendingBadgeKind ?: "video")
            pendingBadgeTitle = null
            pendingBadgeUrl = null
            pendingBadgeKind = null
        }
    }

    Scaffold(
        topBar = {
            // v5.4.207cc — Column wrapper: TopAppBar + full-width dual strip below it.
            // The strip is NOT inside the TopAppBar measurement, so it never gets
            // constrained by the title slot and can display full chunk numbers.
            Column {
            if (!hideTopBar) {
            var modelMenuExpanded by remember { mutableStateOf(false) }

            TopAppBar(
                title = {
                    // v4.9.0 — semantic-search active indicator (green dot when on
                    // AND embeddings exist, white circle otherwise).
                    // v4.9.1 — added compact model short-name next to the dot so
                    // the user sees at a glance which embedding model is in use.
                    val semOn by vm.semanticEnabled.collectAsStateWithLifecycle()
                    val embedReady by vm.embeddingCount.collectAsStateWithLifecycle()
                    val activeId by vm.activeModelId.collectAsStateWithLifecycle()
                    val active = vm.availableModels.firstOrNull { it.id == activeId }
                    var modelMenuExpanded by remember { mutableStateOf(false) }
                    val dot = if (semOn && embedReady > 0) "\uD83D\uDFE2" else "\u26AA"
                    // v5.4.145cc — Hide embedding selector if user disables it
                    val hideEmbeddingSelector by vm.hideEmbeddingSelector.collectAsStateWithLifecycle()
                    // Title: just the search indicator and model selector.
                    // The dual LED strip lives BELOW the TopAppBar (full-width, no clipping).
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text("\uD83D\uDD0D Search  $dot")
                        if (!hideEmbeddingSelector && semOn && embedReady > 0 && active != null) {
                            androidx.compose.foundation.layout.Spacer(Modifier.width(8.dp))
                            LifecycleAwareMarqueeText(
                                text = searchEmbeddingModelLabel(active) + " ▾",
                                fontSize = 11.sp,
                                color = androidx.compose.material3.MaterialTheme
                                    .colorScheme.onSurfaceVariant,
                                fontWeight = FontWeight.Normal,
                                modifier = Modifier
                                    .widthIn(max = 132.dp)
                                    .clickable { modelMenuExpanded = true }
                            )
                            DropdownMenu(
                                expanded = modelMenuExpanded,
                                onDismissRequest = { modelMenuExpanded = false }
                            ) {
                                vm.availableModels.forEach { model ->
                                    DropdownMenuItem(
                                        text = { LifecycleAwareMarqueeText(searchEmbeddingModelLabel(model), modifier = Modifier.fillMaxWidth()) },
                                        onClick = {
                                            vm.setActiveModelId(model.id)
                                            modelMenuExpanded = false
                                        }
                                    )
                                }
                            }
                        }
                    }
                },
                // v4.24.0 — Live percentage progress indicator. Shows
                // while the cross-encoder is busy scoring candidate
                // documents (a 3–5 s pass per search). When idle, nothing
                // displays. Useful so the user knows the app is still
                // working and roughly how much longer they'll wait.
                actions = {
                    val rerankPct     by vm.rerankProgress.collectAsStateWithLifecycle()
                    val showRerankPct by vm.showRerankProgress.collectAsStateWithLifecycle()
                    // v5.4.237cc — Compact inline RAM readout, sitting
                    // naturally inside the TopAppBar actions row (which the
                    // Scaffold already correctly positions below the status
                    // bar) instead of a floating Popup, which ignored
                    // window insets and rendered over the status bar.
                    com.tebogo.markvault.ui.MemoryOverlay()
                    // v5.4.226cc — Locally collect semOn + embedReady for the Videos
                    // button. The versions in the title slot are in a different lambda
                    // scope and cannot be referenced from here.
                    val semOnAction by vm.semanticEnabled.collectAsStateWithLifecycle()
                    val embedReadyAction by vm.embeddingCount.collectAsStateWithLifecycle()
                    // v5.4.225cc — JW.org Videos shortcut in toolbar.
                    // Uses videosClicked state (declared at composable scope below) so
                    // the actual navigation happens after a 500ms delay giving the GC
                    // time to reclaim the semantic index before Compose allocates the
                    // new screen — preventing the OOM crash from the chip row approach.
                    if (semOnAction && embedReadyAction > 0) {
                        IconButton(onClick = {
                            vm.freeMemoryForNavigation()
                            videosClicked = true
                        }) {
                            Text("\uD83C\uDFA5", fontSize = 18.sp)
                        }
                    }
                    // Dual LED panel is now in the title Row (no clipping from actions slot).
                    if (rerankPct != null && showRerankPct) {
                        val pct = (rerankPct!! * 100).toInt().coerceIn(0, 100)
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            modifier = Modifier.padding(end = 12.dp)
                        ) {
                            androidx.compose.material3.CircularProgressIndicator(
                                progress = { rerankPct!! },
                                modifier = Modifier.width(16.dp).height(16.dp),
                                strokeWidth = 2.dp
                            )
                            androidx.compose.foundation.layout.Spacer(Modifier.width(6.dp))
                            Text(
                                "$pct%",
                                fontSize = 11.sp,
                                fontWeight = FontWeight.SemiBold,
                                color = androidx.compose.material3.MaterialTheme
                                    .colorScheme.onSurfaceVariant
                            )
                        }
                    }
                }
            )
            } // end if (!hideTopBar)

            // v5.4.207cc — Full-width dual strip. Outside TopAppBar = full screen width, no clipping.
            val dualStripOn   by vm.semanticDualMode.collectAsStateWithLifecycle()
            val semStripOn    by vm.semanticEnabled.collectAsStateWithLifecycle()
            val embedStripRdy by vm.embeddingCount.collectAsStateWithLifecycle()
            val firstChunksS  by vm.firstScopeChunks.collectAsStateWithLifecycle()
            val secondChunksS by vm.secondScopeChunks.collectAsStateWithLifecycle()
            val loadingScopeS by vm.loadingScope.collectAsStateWithLifecycle()
            val memPauseActive by vm.memoryPauseActive.collectAsStateWithLifecycle()
            if (semStripOn && embedStripRdy > 0 && !savedSearchBarLocked) {
                val fmtFirst  = if (firstChunksS  > 0) "%,d".format(firstChunksS)  else null
                val fmtSecond = if (secondChunksS > 0) "%,d".format(secondChunksS) else null
                val fmtTotal  = if (firstChunksS  > 0 && secondChunksS > 0)
                    "%,d".format(firstChunksS + secondChunksS) else null
                val stripText = when {
                    // v5.4.230cc — Memory pause takes priority over all other states.
                    memPauseActive -> "\u23F8\uFE0F High memory \u2014 clearing\u2026"
                    loadingScopeS == "first20k"  ->
                        "\u26A1 Dual  \u00B7  \u23F3 Loading 1st 20k\u2026"
                    loadingScopeS == "second20k" && fmtFirst != null ->
                        "\u26A1 Dual  \u00B7  1st: $fmtFirst  \u00B7  \u23F3 Loading 2nd\u2026"
                    loadingScopeS == "second20k" ->
                        "\u26A1 Dual  \u00B7  \u23F3 Loading 2nd batch\u2026"
                    fmtFirst != null && fmtSecond != null ->
                        "\u26A1 Dual  \u00B7  1st: $fmtFirst  \u00B7  2nd: $fmtSecond  =  $fmtTotal"
                    fmtFirst != null ->
                        "\u26A1 Dual  \u00B7  1st: $fmtFirst  \u00B7  2nd: \u23F3"
                    dualStripOn -> "\u26A1 Dual ON  \u2014  search to load scopes"
                    else        -> "\u26A1 Dual  \u2014  tap to enable \u00B7 hold to reset memory"
                }
                val haptic = androidx.compose.ui.platform.LocalHapticFeedback.current
                androidx.compose.material3.Surface(
                    color = when {
                        memPauseActive -> MaterialTheme.colorScheme.errorContainer.copy(alpha = 0.75f)
                        dualStripOn    -> MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.7f)
                        else           -> MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.45f)
                    },
                    modifier = Modifier.fillMaxWidth()
                        .combinedClickable(
                            onClick = { vm.setSemanticDualMode(!dualStripOn) },
                            onLongClick = {
                                haptic.performHapticFeedback(
                                    androidx.compose.ui.hapticfeedback.HapticFeedbackType.LongPress
                                )
                                vm.hardResetMemory()
                            }
                        )
                ) {
                    Text(
                        stripText,
                        fontSize = 10.sp,
                        fontWeight = if (dualStripOn || memPauseActive) FontWeight.SemiBold else FontWeight.Normal,
                        color = when {
                            memPauseActive -> MaterialTheme.colorScheme.onErrorContainer
                            dualStripOn    -> MaterialTheme.colorScheme.primary
                            else           -> MaterialTheme.colorScheme.onSurfaceVariant
                        },
                        modifier = Modifier.padding(horizontal = 12.dp, vertical = 5.dp)
                    )
                }
            }
            // v5.4.241cc — Removed: the custom in-app banner this used to
            // show is now dead code — every memory-cleanup path uses a
            // real, measured Toast (showMemoryClearedToast) instead, so
            // there's one consistent confirmation mechanism everywhere,
            // not a static message on this one specific path.
            } // end Column
        },
        bottomBar = {
            // v5.4.148cc — Instant bottom toolbar visibility (no animation delay)
            val enableFullscreenMode by vm.enableFullscreenMode.collectAsStateWithLifecycle()
            val bottomBarVisible = if (enableFullscreenMode) showTopUtilities else true
            if (bottomBarVisible && !hideTopBar) {
                MarkVaultBottomBar(nav = nav, vm = vm)
            }
        }
    ) { pad ->
        // v5.4.30 — Tablet 2-column split.
        val leftColWidth = if (screenWidthDp >= 1000) 280.dp else 220.dp

        Row(Modifier.padding(pad).fillMaxSize()) {
            if ((isTabletWidth || workspaceTabletUi) && !hideTopBar) {
                SearchTabletRecentsPanel(
                    vm = vm,
                    recentSearches = recentSearches,
                    modifier = Modifier.width(leftColWidth).fillMaxHeight()
                )
                androidx.compose.material3.VerticalDivider()
            }
            Column(Modifier.weight(1f).fillMaxHeight()) {
            if (savedSearchBarLocked && activeSavedSession != null) {
                SavedSearchHeaderCard(
                    report = activeSavedSession,
                    onUnlock = { savedSearchBarUnlocked = true }
                )
            } else {
            if (hideTopBar) {
                androidx.compose.animation.AnimatedVisibility(visible = showTopUtilities) {
                val semOnWorkspace by vm.semanticEnabled.collectAsStateWithLifecycle()
                val embedReadyWorkspace by vm.embeddingCount.collectAsStateWithLifecycle()
                val activeModelIdWorkspace by vm.activeModelId.collectAsStateWithLifecycle()
                val hideEmbeddingWorkspace by vm.hideEmbeddingSelector.collectAsStateWithLifecycle()
                val activeModelWorkspace = vm.availableModels.firstOrNull { it.id == activeModelIdWorkspace }
                var workspaceModelMenu by remember { mutableStateOf(false) }
                Surface(
                    color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.35f),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Row(
                        Modifier.fillMaxWidth().padding(horizontal = 8.dp, vertical = 4.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text("🔎 Search", fontWeight = FontWeight.SemiBold, fontSize = 13.sp)
                        if (!hideEmbeddingWorkspace && semOnWorkspace && embedReadyWorkspace > 0 && activeModelWorkspace != null) {
                            Spacer(Modifier.width(8.dp))
                            Box {
                                Surface(
                                    color = MaterialTheme.colorScheme.primaryContainer,
                                    shape = RoundedCornerShape(14.dp)
                                ) {
                                    LifecycleAwareMarqueeText(
                                        text = "🧠 ${searchEmbeddingModelLabel(activeModelWorkspace)} ▾",
                                        modifier = Modifier
                                            .widthIn(max = 146.dp)
                                            .clickable { workspaceModelMenu = true }
                                            .padding(horizontal = 10.dp, vertical = 6.dp),
                                        fontSize = 10.sp,
                                        fontWeight = FontWeight.SemiBold,
                                        color = MaterialTheme.colorScheme.onPrimaryContainer
                                    )
                                }
                                DropdownMenu(expanded = workspaceModelMenu, onDismissRequest = { workspaceModelMenu = false }) {
                                    vm.availableModels.forEach { model ->
                                        DropdownMenuItem(
                                            text = { LifecycleAwareMarqueeText(searchEmbeddingModelLabel(model), modifier = Modifier.fillMaxWidth()) },
                                            onClick = { vm.setActiveModelId(model.id); workspaceModelMenu = false }
                                        )
                                    }
                                }
                            }
                        }
                        Spacer(Modifier.weight(1f))
                        TextButton(onClick = { tabletRecentsOpen = !tabletRecentsOpen }) {
                            Text(if (tabletRecentsOpen) "Hide recents" else "Recent searches", fontSize = 10.sp)
                        }
                        IconButton(onClick = {
                            vm.freeMemoryForNavigation()
                            videosClicked = true
                        }, modifier = Modifier.size(34.dp)) {
                            Text("🎬", fontSize = 16.sp)
                        }
                    }
                }
                } // end Workspace Search/model/Recent/media AnimatedVisibility
            }
            // v5.4.111cc — Collapsible top utilities. AnimatedVisibility
            // wraps the search bar + mode segments + chip row so they
            // slide away on scroll-down and return on scroll-up. See the
            // showTopUtilities driver above.
            //
            // v5.4.145cc — Search bar visibility now controlled by both
            // showTopUtilities (scroll-driven) and hideSearchBarOnScroll toggle.
            // When hideSearchBarOnScroll is OFF (default), search bar always shows.
            // When ON, search bar hides with scroll like the other elements.
            val hideSearchBarOnScroll by vm.hideSearchBarOnScroll.collectAsStateWithLifecycle()
            val searchBarVisible = when {
                workspaceTabletUi -> showTopUtilities
                hideSearchBarOnScroll -> showTopUtilities
                else -> true
            }
            
            androidx.compose.animation.AnimatedVisibility(visible = searchBarVisible) {
            OutlinedTextField(
                value = query,
                onValueChange = { newValue ->
                    if (!savedSearchBarLocked) {
                        // v5.4.146cc — When live search is OFF and a submit-driven
                        // search is in flight, cancel it the moment the user types.
                        // This stops the expensive embedding / rerank / LLM pipeline
                        // immediately; results stay visible (cancel handler returns
                        // the last known set). The user can now compose their next
                        // query and press Enter/Search when ready.
                        if (!liveSearchEnabled && isSearchBusy) {
                            vm.cancelCurrentSearch()
                        }
                        vm.query.value = newValue
                    }
                },
                readOnly = savedSearchBarLocked,
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(
                        horizontal = if (isTabletWidth || workspaceTabletUi) 6.dp else 16.dp,
                        vertical = if (isTabletWidth || workspaceTabletUi) 2.dp else 8.dp
                    )
                    .focusRequester(focus)
                    .pointerInput(savedSearchBarLocked) {
                        if (savedSearchBarLocked) {
                            detectTapGestures(
                                onTap = { focusManager.clearFocus() },
                                onLongPress = { savedSearchBarUnlocked = true }
                            )
                        }
                    },
                placeholder = {
                    Text(
                        if (mode == SearchMode.TITLES) "Search note names\u2026"
                        else "Search inside all notes\u2026"
                    )
                },
                singleLine = true,
                // v5.4.1 — Keyboard "Search" action fires submitSearch() so
                // users can deliberately trigger a search even when live
                // search is disabled in Settings.
                keyboardOptions = androidx.compose.foundation.text.KeyboardOptions(
                    imeAction = androidx.compose.ui.text.input.ImeAction.Search
                ),
                keyboardActions = androidx.compose.foundation.text.KeyboardActions(
                    onSearch = { vm.submitSearch() }
                ),
                trailingIcon = {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        // v5.5.0 — Fast search (ANN) toggle. Lights up
                        // when enabled + index available. Tap toggles.
                        // Dim when off or index not built.
                        val annAvailable = vm.isAnnIndexAvailable()
                        IconButton(
                            onClick = {
                                if (annAvailable) vm.setAnnSearchEnabled(!annFastOn)
                            },
                            modifier = Modifier
                                .size(40.dp)
                                .graphicsLayer(
                                    alpha = if (annFastOn && annAvailable) 1f else 0.35f
                                )
                        ) {
                            Text("⚡", fontSize = 18.sp)
                        }
                        IconButton(
                            onClick = { vm.setHnswSearchEnabled(!hnswFastOn) },
                            enabled = vm.hnswIndex.nativeAvailable(),
                            modifier = Modifier.size(40.dp).semantics {
                                contentDescription = "Blue HNSW secondary ANN: " +
                                    if (hnswFastOn) "on" else "off"
                            }
                        ) {
                            val blue = androidx.compose.ui.graphics.Color(0xFF2196F3)
                            Text("H", color = blue.copy(alpha = if (hnswFastOn) 1f else 0.5f),
                                fontSize = 17.sp, fontWeight = androidx.compose.ui.text.font.FontWeight.Bold,
                                modifier = Modifier.border(1.dp, blue, RoundedCornerShape(6.dp))
                                    .padding(horizontal = 5.dp, vertical = 1.dp))
                        }
                        PumpingBrainToggle(
                            active = aiLlmOn,
                            onToggle = { vm.setAiLlmSearchEnabled(!aiLlmOn) }
                        )
                        if (query.isNotEmpty()) {
                            IconButton(onClick = { vm.query.value = "" }) {
                                Icon(Icons.Default.Close, contentDescription = "Clear")
                            }
                        }
                        // v5.4.1 — Always-visible submit button. Same effect
                        // as the keyboard's Search action but reachable
                        // without opening the IME. Especially useful when
                        // Live search is OFF.
                        IconButton(onClick = { vm.submitSearch() }) {
                            Icon(Icons.Default.Search, contentDescription = "Run search")
                        }
                    }
                }
            )
            LaunchedEffect(activeSavedSearchId) {
                if (activeSavedSearchId == null) focus.requestFocus()
            }
            } // end search bar AnimatedVisibility

            // v5.5.14 — Dedicated Question Awareness control sits directly under
            // the search field and remains independent of the optional filter-chip
            // visibility setting. It affects Deep/content retrieval only.
            androidx.compose.animation.AnimatedVisibility(
                visible = searchBarVisible && !savedSearchBarLocked
            ) {
                Row(
                    Modifier.fillMaxWidth().padding(
                        start = if (isTabletWidth || workspaceTabletUi) 8.dp else 18.dp,
                        end = if (isTabletWidth || workspaceTabletUi) 8.dp else 18.dp,
                        bottom = 2.dp
                    ),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    androidx.compose.material3.FilterChip(
                        selected = questionAwarenessOn,
                        onClick = { vm.setQuestionAwarenessEnabled(!questionAwarenessOn) },
                        label = {
                            Text(
                                if (questionAwarenessOn) "❓ Question Awareness ON" else "❓ Question Awareness OFF",
                                fontSize = 11.sp,
                                fontWeight = if (questionAwarenessOn) FontWeight.SemiBold else FontWeight.Normal
                            )
                        }
                    )
                    Spacer(Modifier.width(8.dp))
                    Text(
                        if (mode == SearchMode.CONTENT)
                            "Detects questions and searches for answer-shaped wording"
                        else "Used in Deep search",
                        fontSize = 10.sp,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                }
            }
            
            // v5.4.111cc — Segments and chip row hide/show with scroll
            androidx.compose.animation.AnimatedVisibility(visible = showTopUtilities) {
            Column(Modifier.fillMaxWidth()) {
            ShallowDeepToggle(
                mode = mode,
                onModeChange = { vm.mode.value = it },
                modifier = Modifier.fillMaxWidth().padding(horizontal = if (isTabletWidth || workspaceTabletUi) 6.dp else 16.dp)
            )

            // v5.4.33 — All filter chips in one compact scrollable row
            // to eliminate wasted vertical space. Semantic, Rerank,
            // progress toggles, and exact-phrase all sit side by side.
            //
            // v5.4.111cc — Each chip is now individually hidable via
            // Settings (chipSemantic / chipRerank / chipRerankPct /
            // chipSemanticPct / chipAccurate — all default ON). The
            // "exact phrase" chip was renamed to "Get accurate
            // results" (label only — the underlying quotePhrase
            // toggle and its exact-phrase FTS behaviour are
            // unchanged), and flashes green + slightly larger for a
            // few seconds after results land.
            //
            // v5.4.145cc — Entire chip row can be hidden via Settings
            // (hideSearchChips toggle).
            val hideSearchChips by vm.hideSearchChips.collectAsStateWithLifecycle()
            if (!hideSearchChips) {
            run {
                val semOnRow by vm.semanticEnabled.collectAsStateWithLifecycle()
                val rerankInstalled by vm.rerankerInstalled.collectAsStateWithLifecycle()
                val rerankOn by vm.rerankEnabled.collectAsStateWithLifecycle()
                val rerankBusy by vm.rerankActive.collectAsStateWithLifecycle()
                val showRerankPctChip by vm.showRerankProgress.collectAsStateWithLifecycle()
                val showSemPctChip by vm.showSemanticProgress.collectAsStateWithLifecycle()
                // Visibility toggles.
                val vChipSemantic by vm.chipSemantic.collectAsStateWithLifecycle()
                val vChipRerank by vm.chipRerank.collectAsStateWithLifecycle()
                val vChipRerankPct by vm.chipRerankPct.collectAsStateWithLifecycle()
                val vChipSemanticPct by vm.chipSemanticPct.collectAsStateWithLifecycle()
                val vChipAccurate by vm.chipAccurate.collectAsStateWithLifecycle()
                // v5.4.193cc — Two dynamic scope chips.
                // 1st 20k  = most recently modified 20k articles (fixed).
                // 2nd batch = ALL articles beyond the first 20k (no upper cap).
                //   Label shows actual count so the user sees e.g. "30k" when
                //   the library grows to 50k total articles.
                val semanticScope by vm.semanticScope.collectAsStateWithLifecycle()
                // v5.4.196cc — Dual mode toggle (must be at composable scope).
                val semanticDualMode by vm.semanticDualMode.collectAsStateWithLifecycle()

                // Compute second-batch count from total embedded article count.
                var totalEmbeddedArticles by remember { mutableStateOf(0) }
                LaunchedEffect(Unit) {
                    totalEmbeddedArticles = vm.distinctEmbeddedNoteCount()
                }
                val secondBatchCount = maxOf(0, totalEmbeddedArticles - 20_000)
                val secondLabel = when {
                    secondBatchCount >= 1_000 -> "\uD83D\uDCDA 2nd ${secondBatchCount / 1_000}k"
                    secondBatchCount > 0      -> "\uD83D\uDCDA 2nd ${secondBatchCount}"
                    else                      -> "\uD83D\uDCDA 2nd batch"
                }

                LazyRow(
                    Modifier
                        .fillMaxWidth()
                        .padding(vertical = 2.dp),
                    horizontalArrangement = Arrangement.spacedBy(6.dp),
                    contentPadding = PaddingValues(horizontal = if (isTabletWidth || workspaceTabletUi) 6.dp else 14.dp)
                ) {
                    if (vChipSemantic) {
                        item {
                            androidx.compose.material3.FilterChip(
                                selected = semOnRow,
                                onClick = { vm.setSemanticEnabled(!semOnRow) },
                                label = {
                                    Text(
                                        if (semOnRow) "\uD83E\uDDE0 Semantic ON" else "\uD83E\uDDE0 OFF",
                                        fontSize = 11.sp
                                    )
                                }
                            )
                        }
                    }
                    if (vChipRerank) {
                        item {
                            if (rerankInstalled) {
                                androidx.compose.material3.FilterChip(
                                    selected = rerankOn,
                                    onClick = { vm.setRerankEnabled(!rerankOn) },
                                    label = {
                                        Text(
                                            if (rerankOn) "\uD83C\uDFAF Rerank ON" else "\uD83C\uDFAF OFF",
                                            fontSize = 11.sp
                                        )
                                    }
                                )
                            } else {
                                androidx.compose.material3.FilterChip(
                                    selected = false,
                                    onClick = { nav.navigate("settings") },
                                    label = { Text("\uD83C\uDFAF Install rerank", fontSize = 11.sp) }
                                )
                            }
                        }
                    }
                    if (rerankBusy) {
                        item {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                androidx.compose.material3.CircularProgressIndicator(
                                    modifier = Modifier.width(14.dp).height(14.dp),
                                    strokeWidth = 2.dp
                                )
                                Spacer(Modifier.width(4.dp))
                                Text("Reranking\u2026", fontSize = 10.sp,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant)
                            }
                        }
                    }
                    if (vChipRerankPct) {
                        item {
                            androidx.compose.material3.FilterChip(
                                selected = showRerankPctChip,
                                onClick = { vm.setShowRerankProgress(!showRerankPctChip) },
                                label = { Text(if (showRerankPctChip) "Rerank %" else "Rerank % off", fontSize = 10.sp) }
                            )
                        }
                    }
                    if (vChipSemanticPct) {
                        item {
                            androidx.compose.material3.FilterChip(
                                selected = showSemPctChip,
                                onClick = { vm.setShowSemanticProgress(!showSemPctChip) },
                                label = { Text(if (showSemPctChip) "Semantic %" else "Semantic % off", fontSize = 10.sp) }
                            )
                        }
                    }
                    // v5.4.186cc — Semantic scope selector. Shows when semantic
                    // is ON. Lets the user pick how many articles are included
                    // in the semantic index: 5k / 10k / 20k / All. Choosing a
                    // larger scope gives better recall but slower first search
                    // (index builds on demand, cached for the session).
                    if (semOnRow) {
                        val scopeOptions = listOf(
                            "first20k"  to "\uD83D\uDCDA 1st 20k",
                            "second20k" to secondLabel,
                            "all"       to "\uD83D\uDCDA All notes"
                        )
                        scopeOptions.forEach { (mode, label) ->
                            item {
                                androidx.compose.material3.FilterChip(
                                    selected = semanticScope == mode && !semanticDualMode,
                                    onClick  = {
                                        if (semanticDualMode) vm.setSemanticDualMode(false)
                                        vm.setSemanticScope(mode)
                                    },
                                    label    = { Text(label, fontSize = 11.sp) }
                                )
                            }
                        }
                        // Status chip — shows loading / loaded / idle state.
                        item {
                            val loadStatus by vm.scopeLoadStatus.collectAsStateWithLifecycle()
                            val warming   by vm.semanticIndexWarming.collectAsStateWithLifecycle()
                            val dualActive = semanticDualMode
                            val scopeLabel = when {
                                dualActive                        -> "1st + 2nd"
                                semanticScope == "first20k"       -> "1st 20k"
                                semanticScope == "second20k"      -> secondLabel.removePrefix("\uD83D\uDCDA ").trim()
                                else                              -> "All notes"
                            }
                            val (icon, text) = when {
                                warming -> "\u23F3" to "Loading $scopeLabel\u2026"
                                loadStatus.startsWith("loaded:") -> {
                                    val n = loadStatus.removePrefix("loaded:").toIntOrNull() ?: 0
                                    "\u2705" to "$scopeLabel: $n chunks ready"
                                }
                                else -> "\u26AA" to "$scopeLabel: search to load"
                            }
                            androidx.compose.material3.AssistChip(
                                onClick = {},
                                label  = { Text("$icon $text", fontSize = 10.sp) }
                            )
                        }
                    }
                    // v5.4.111cc — "Get accurate results" chip (was
                    // "exact phrase"). Label + visual treatment only —
                    // still drives vm.quotePhrase exactly as before.
                    // After a search completes, accurateFlash pulses a
                    // green tint + slight scale-up ~3× then settles,
                    // WITHOUT hiding the chip.
                    if (mode == SearchMode.CONTENT && vChipAccurate) {
                        item {
                            // Flash animation: driven by accurateFlashKey
                            // which bumps each time results land. When it
                            // changes, run a short repeating green pulse.
                            val flashActive = accurateFlashPulse > 0f
                            val greenTint = androidx.compose.ui.graphics.lerp(
                                MaterialTheme.colorScheme.surfaceVariant,
                                androidx.compose.ui.graphics.Color(0xFF43A047),
                                accurateFlashPulse
                            )
                            val scale = 1f + 0.12f * accurateFlashPulse
                            if (flashActive) {
                                // Flashing: override container + label
                                // to the green pulse tint. We supply
                                // Color.Transparent for the states we
                                // don't care about so we never have to
                                // read the private default-color
                                // properties back off the colors object.
                                androidx.compose.material3.FilterChip(
                                    selected = quotePhrase,
                                    onClick = { vm.quotePhrase.value = !quotePhrase },
                                    modifier = Modifier.graphicsLayer {
                                        scaleX = scale
                                        scaleY = scale
                                    },
                                    colors = androidx.compose.material3.FilterChipDefaults.filterChipColors(
                                        containerColor = greenTint,
                                        labelColor = androidx.compose.ui.graphics.Color.White,
                                        selectedContainerColor = greenTint,
                                        selectedLabelColor = androidx.compose.ui.graphics.Color.White
                                    ),
                                    label = {
                                        Text(
                                            if (quotePhrase) "\u2705 Get accurate results"
                                            else "\u2B1C Get accurate results",
                                            fontSize = 11.sp,
                                            fontWeight = FontWeight.Bold
                                        )
                                    }
                                )
                            } else {
                                // Idle: plain default-styled chip, no
                                // colors override, no scale.
                                androidx.compose.material3.FilterChip(
                                    selected = quotePhrase,
                                    onClick = { vm.quotePhrase.value = !quotePhrase },
                                    label = {
                                        Text(
                                            if (quotePhrase) "\u2705 Get accurate results"
                                            else "\u2B1C Get accurate results",
                                            fontSize = 11.sp
                                        )
                                    }
                                )
                            }
                        }
                    }
                }
            }
            } // end if (!hideSearchChips)
            } // end inner Column (top utilities)
            } // end AnimatedVisibility
            } // end live-search controls / saved-search header switch

            // v5.4.111cc — Manual collapse handle. A slim always-visible
            // bar with a chevron: tap to force-toggle the top utilities
            // regardless of scroll. Gives a discoverable, deterministic
            // way to bring the search bar back after it auto-hid, or to
            // hide it on demand. Setting manualOverride to the opposite
            // of the current visibility; the next scroll clears the
            // override so auto behaviour resumes.
            // v5.4.335cc — An automatic scroll-collapse removes even the slim
            // handle so the result list receives every reclaimed pixel. A manual
            // collapse keeps the reveal handle available.
            if (!savedSearchBarLocked && (showTopUtilities || manualOverride == false)) {
            Row(
                Modifier
                    .fillMaxWidth()
                    .height(20.dp)
                    .clickable {
                        manualOverride = !showTopUtilities
                        // Keep the auto-state in sync so a subsequent
                        // scroll doesn't immediately flip it back.
                        topUtilitiesExpanded = !showTopUtilities
                    },
                horizontalArrangement = Arrangement.Center,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    if (showTopUtilities) "\u25B2 hide search bar"
                    else "\u25BC show search bar",
                    fontSize = 10.sp,
                    color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.7f)
                )
            }
            }

            if (topicMatches.isNotEmpty()) {
                Text(
                    "Jump to topic",
                    Modifier.padding(start = 20.dp, top = 10.dp, bottom = 2.dp),
                    fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant
                )
                LazyRow(
                    Modifier.fillMaxWidth().padding(vertical = 4.dp),
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    contentPadding = PaddingValues(horizontal = 16.dp)
                ) {
                    items(topicMatches, key = { it.key }) { t ->
                        Surface(
                            color = MaterialTheme.colorScheme.primary.copy(alpha = 0.18f),
                            shape = RoundedCornerShape(20.dp),
                            modifier = Modifier.clickable { nav.navigate("topic/${t.key}") }
                        ) {
                            Text(
                                "${t.emoji} ${t.label} \u00B7 ${t.count}",
                                Modifier.padding(horizontal = 14.dp, vertical = 8.dp),
                                fontSize = 13.sp, fontWeight = FontWeight.Medium
                            )
                        }
                    }
                }
            }

            val trimmed = query.trim()
            val showingRecents = trimmed.length < 2
            val noMatches = !showingRecents && displayedResults.isEmpty() && topicMatches.isEmpty()

            // v5.4.33 — Animated search indicator. Shows while search
            // is running, using the user's chosen style.
            val searchBusy by vm.searchBusy.collectAsStateWithLifecycle()
            val indicatorStyle by vm.searchIndicatorStyle.collectAsStateWithLifecycle()
            if (searchBusy && !showingRecents) {
                Row(
                    Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 20.dp, vertical = 6.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.Center
                ) {
                    when (indicatorStyle) {
                        "hourglass" -> {
                            // Animated hourglass: rotates between ⏳ and ⌛
                            val inf = rememberInfiniteTransition(label = "hg")
                            val phase by inf.animateFloat(
                                initialValue = 0f,
                                targetValue = 1f,
                                animationSpec = infiniteRepeatable(
                                    tween(800, easing = LinearEasing),
                                    repeatMode = RepeatMode.Restart
                                ), label = "hg"
                            )
                            Text(
                                if (phase < 0.5f) "\u23F3" else "\u231B",
                                fontSize = 20.sp
                            )
                            Spacer(Modifier.width(8.dp))
                            Text("Searching\u2026", fontSize = 12.sp,
                                color = MaterialTheme.colorScheme.onSurfaceVariant)
                        }
                        "book" -> {
                            // Animated book flipping pages: cycles through book emojis
                            val inf = rememberInfiniteTransition(label = "bk")
                            val phase by inf.animateFloat(
                                initialValue = 0f,
                                targetValue = 4f,
                                animationSpec = infiniteRepeatable(
                                    tween(1600, easing = LinearEasing),
                                    repeatMode = RepeatMode.Restart
                                ), label = "bk"
                            )
                            val bookEmoji = when (phase.toInt() % 4) {
                                0 -> "\uD83D\uDCD6"  // open book
                                1 -> "\uD83D\uDCD8"  // green book
                                2 -> "\uD83D\uDCD9"  // blue book
                                else -> "\uD83D\uDCD7" // orange book
                            }
                            Text(bookEmoji, fontSize = 20.sp)
                            Spacer(Modifier.width(8.dp))
                            Text("Flipping pages\u2026", fontSize = 12.sp,
                                color = MaterialTheme.colorScheme.onSurfaceVariant)
                        }
                        "large_percentage" -> {
                            // v5.4.286cc — Large search progress style. This remains
                            // an additional presentation option. Its central percentage
                            // is now driven by the actual retrieval scan, while the wheel
                            // keeps spinning and the line below reports throughput.
                            val searchPct by vm.searchWorkProgress.collectAsStateWithLifecycle()
                            val searchDone by vm.searchWorkDone.collectAsStateWithLifecycle()
                            val searchTotal by vm.searchWorkTotal.collectAsStateWithLifecycle()
                            val searchRate by vm.searchWorkRate.collectAsStateWithLifecycle()
                            val searchUnit by vm.searchWorkUnit.collectAsStateWithLifecycle()
                            val searchStage by vm.searchWorkStage.collectAsStateWithLifecycle()
                            val rerankPctInd by vm.rerankProgress.collectAsStateWithLifecycle()
                            // Large % is intentionally the REAL retrieval-scan
                            // percentage, not the old reranker-only percentage. The
                            // reranker is shown as a secondary stage so the main count
                            // never jumps backwards from 100% to 0%.
                            val activePct = searchPct
                            val pctVal = activePct?.let {
                                (it * 100).toInt().coerceIn(0, 100)
                            }
                            val spinTransition = rememberInfiniteTransition(label = "largeSearchSpin")
                            val spinDegrees by spinTransition.animateFloat(
                                initialValue = 0f,
                                targetValue = 360f,
                                animationSpec = infiniteRepeatable(
                                    tween(1150, easing = LinearEasing),
                                    repeatMode = RepeatMode.Restart
                                ),
                                label = "largeSearchSpinDegrees"
                            )
                            Surface(
                                shape = RoundedCornerShape(24.dp),
                                color = MaterialTheme.colorScheme.surfaceVariant,
                                tonalElevation = 6.dp,
                                shadowElevation = 4.dp,
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(horizontal = 4.dp, vertical = 8.dp)
                            ) {
                                Column(
                                    horizontalAlignment = Alignment.CenterHorizontally,
                                    verticalArrangement = Arrangement.Center,
                                    modifier = Modifier.padding(vertical = 18.dp, horizontal = 20.dp)
                                ) {
                                    Box(
                                        modifier = Modifier.size(84.dp),
                                        contentAlignment = Alignment.Center
                                    ) {
                                        if (activePct != null) {
                                            androidx.compose.material3.CircularProgressIndicator(
                                                progress = { activePct!!.coerceIn(0f, 1f) },
                                                modifier = Modifier
                                                    .fillMaxSize()
                                                    .graphicsLayer { rotationZ = spinDegrees },
                                                strokeWidth = 7.dp,
                                                color = MaterialTheme.colorScheme.primary
                                            )
                                        } else {
                                            androidx.compose.material3.CircularProgressIndicator(
                                                modifier = Modifier
                                                    .fillMaxSize()
                                                    .graphicsLayer { rotationZ = spinDegrees },
                                                strokeWidth = 7.dp,
                                                color = MaterialTheme.colorScheme.primary
                                            )
                                        }
                                        Text(
                                            text = pctVal?.let { "$it%" } ?: "…",
                                            fontSize = if (pctVal != null) 22.sp else 26.sp,
                                            fontWeight = FontWeight.Bold,
                                            color = MaterialTheme.colorScheme.onSurface
                                        )
                                    }
                                    Spacer(Modifier.height(10.dp))
                                    Text(
                                        text = if (rerankPctInd != null)
                                            "Scan complete • reranking ${(rerankPctInd!! * 100).toInt().coerceIn(0, 100)}%…"
                                        else searchStage,
                                        fontSize = 14.sp,
                                        fontWeight = FontWeight.SemiBold,
                                        color = MaterialTheme.colorScheme.onSurface
                                    )
                                    Text(
                                        text = if (searchTotal > 0) {
                                            val rateText = if (searchRate >= 10f)
                                                String.format(java.util.Locale.US, "%.0f", searchRate)
                                            else String.format(java.util.Locale.US, "%.1f", searchRate)
                                            val remaining = (searchTotal - searchDone).coerceAtLeast(0)
                                            val etaText = if (searchRate > 0.1f && remaining > 0) {
                                                val seconds = (remaining / searchRate).toInt().coerceAtLeast(1)
                                                "  •  ~${seconds}s left"
                                            } else ""
                                            "${searchDone.coerceAtMost(searchTotal)} / $searchTotal $searchUnit  •  $rateText $searchUnit/s$etaText"
                                        } else {
                                            "Preparing measurable search work…"
                                        },
                                        fontSize = 12.sp,
                                        color = MaterialTheme.colorScheme.onSurfaceVariant
                                    )
                                }
                            }
                        }
                        else -> {
                            // Percentage (default): circular progress with rerank %
                            val rerankPctInd by vm.rerankProgress.collectAsStateWithLifecycle()
                            if (rerankPctInd != null) {
                                val pctVal = (rerankPctInd!! * 100).toInt().coerceIn(0, 100)
                                androidx.compose.material3.CircularProgressIndicator(
                                    progress = { rerankPctInd!! },
                                    modifier = Modifier.size(18.dp),
                                    strokeWidth = 2.dp
                                )
                                Spacer(Modifier.width(6.dp))
                                Text("$pctVal%", fontSize = 12.sp,
                                    fontWeight = FontWeight.SemiBold,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant)
                            } else {
                                androidx.compose.material3.CircularProgressIndicator(
                                    modifier = Modifier.size(18.dp),
                                    strokeWidth = 2.dp
                                )
                                Spacer(Modifier.width(6.dp))
                                Text("Searching\u2026", fontSize = 12.sp,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant)
                            }
                        }
                    }
                }
                // v5.5.14 — Stop Search is graceful: halt retrieval at the next
                // safe boundary, then rerank and save the candidates already found.
                Row(
                    Modifier.fillMaxWidth().padding(top = 4.dp),
                    horizontalArrangement = Arrangement.Center
                ) {
                    androidx.compose.material3.TextButton(
                        onClick = { vm.stopCurrentSearchGracefully() }
                    ) {
                        Text(
                            "⏹ Stop search",
                            fontSize = 13.sp,
                            color = MaterialTheme.colorScheme.error
                        )
                    }
                }
            }

            // v5.4.160cc — Scroll-driven parallax on the results-count label.
            //
            // MarkVault has no "article header image" (it's a text-heavy
            // note app), so this adapts the same idea to what actually
            // exists here: this label sits statically above the results
            // LazyColumn (outside the showTopUtilities collapsible block
            // above, so this is fully independent of that existing
            // show/hide logic — zero interaction risk with it). As the
            // user begins scrolling the results, the label drifts upward
            // and fades slightly at a DIFFERENT rate than the list itself
            // — the classic parallax "background moves slower/differently
            // than foreground content" effect.
            //
            // Bounded deliberately: parallaxRaw only tracks scroll offset
            // while still on the very first item (index 0), and locks at
            // its fully-receded resting value once the user has scrolled
            // past it. This means the effect never runs away or produces
            // a nonsensical value for arbitrarily long scrolls — it's a
            // one-time "recede as you begin reading" motion, not a
            // continuously-reactive transform across the whole list.
            val parallaxRaw by remember {
                derivedStateOf {
                    if (resultsListState.firstVisibleItemIndex == 0) {
                        resultsListState.firstVisibleItemScrollOffset.toFloat().coerceIn(0f, 120f)
                    } else {
                        120f
                    }
                }
            }
            Text(
                text = when {
                    showingRecents -> if (recentSearches.isEmpty()) {
                        if (mode == SearchMode.CONTENT)
                            "Tip: try a topic like \"death\" or wrap text in \"quotes\" for an exact phrase."
                        else "Type at least 2 letters."
                    } else "Recent searches"
                    noMatches -> buildString {
                        append("No matches in your library.")
                        lastSearchDurationMs?.let { ms ->
                            append(" · ")
                            append(formatSearchDuration(ms))
                        }
                    }
                    else -> buildString {
                        append("${displayedResults.size} result(s)")
                        lastSearchDurationMs?.let { ms ->
                            append(" · ")
                            append(formatSearchDuration(ms))
                        }
                    }
                },
                modifier = Modifier
                    .padding(horizontal = 20.dp, vertical = 6.dp)
                    .graphicsLayer {
                        translationY = -parallaxRaw * 0.4f
                        alpha = 1f - (parallaxRaw / 120f) * 0.5f
                    },
                fontSize = 12.sp,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )

            // Restored query legend is attached to the results header rather
            // than the scroll-collapsing toolbar. It stays reachable in both
            // the normal and tablet/workspace search presentations.
            if (!showingRecents && !isSearchBusy) {
                val expansionQueries = if (activeSavedSession != null) {
                    QueryExpansionPresentation.fromSaved(
                        provenance = resultQueryProvenanceById.values,
                        savedExpansions = activeSavedSession.session.expansions,
                        questionAwareQueries = activeSavedSession.session.questionAwareQueries
                    )
                } else {
                    val plan = recordedQueryPlans[cleanedPresentationQuery.lowercase()]
                    QueryExpansionPresentation.fromPlan(
                        plan?.generated.orEmpty().map { generated ->
                            generated.text to generated.source.toResultQuerySource()
                        }
                    )
                }
                if (expansionQueries.isNotEmpty()) {
                    QueryExpansionLegend(
                        originalQuery = cleanedPresentationQuery,
                        expansions = expansionQueries,
                        saved = activeSavedSession != null
                    )
                }
            }

            // v5.4.31 — weight(1f) + fillMaxWidth() instead of
            // fillMaxSize(). In a Column, fillMaxSize on a child
            // without weight() doesn't reliably claim remaining
            // vertical space — siblings above (search bar + chip rows)
            // consumed it in landscape, leaving results with 0
            // effective height. weight(1f) is the canonical fix.
            //
            // v5.4.111cc — Hoisted state drives the collapsible top
            // utilities' auto-hide on scroll.
            // v5.4.157cc — Tracks which result ids have already played their
            // stagger-in animation. A plain (non-state) MutableSet is
            // correct here: it's read once per item via remember(hit.id) at
            // composition time and mutated from a coroutine side-effect, so
            // it never needs to trigger recomposition itself. Persists for
            // the life of this LazyColumn call site — i.e. reset only when
            // SearchScreen itself is torn down and recreated (navigating
            // away and back), not on every keystroke/refilter. Without this,
            // every character typed would replay the fade-in for results
            // that already faded in on a previous keystroke.
            val animatedResultIds = remember { mutableSetOf<Long>() }

            Box(
                Modifier
                    .weight(1f)
                    .fillMaxWidth()
            ) {
            LazyColumn(
                state = resultsListState,
                modifier = Modifier.fillMaxSize()
            ) {
                // v5.4.388cc — Matching videos/caption hits are always the first
                // result row in Global Search, ahead of article results.
                if (!showingRecents && query.trim().length >= 2 && combinedMediaResults.isNotEmpty()) {
                    item {
                        MediaSearchCarousel(
                            items = combinedMediaResults,
                            onItemClick = { vm.requestMediaPopup(it) },
                            onItemLongPress = { longPressMediaItem = it }
                        )
                    }
                }
                if (showingRecents) {
                    // Persisted list of past clicks. Each card keeps the originally-searched query
                    // so we can highlight matched words in its title/path.
                    if (recentSearches.isNotEmpty()) {
                        // v5.4.126cc — Filter out query-only sentinels (noteId = -1).
                        // Those entries are recorded by recordSubmittedQuery() so they
                        // appear in HomeScreen's recent-query chips, but they have no
                        // linked article and must not appear as article-navigation cards.
                        items(recentSearches.filter { it.noteId >= 0 }, key = { "rs-${it.noteId}-${it.ts}" }) { rs ->
                            val toks = remember(rs.query) {
                                rs.query.split(Regex("\\s+"))
                                    .map { it.trim() }.filter { it.isNotEmpty() }.take(6)
                            }
                            Surface(
                                color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.18f),
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(horizontal = 8.dp, vertical = 5.dp),
                                shape = RoundedCornerShape(10.dp)
                            ) {
                                Column(
                                    Modifier
                                        .fillMaxWidth()
                                        .clickable {
                                            val lower = rs.relPath.lowercase()
                                            // Replay the original query as a highlight on every reader.
                                            // v5.4.10 — Preserve the exact-phrase flag so the
                                            // reader's highlight pass treats "1 percent" as
                                            // one phrase instead of two terms.
                                            val rawH = rs.query.trim()
                                            if (rawH.isNotEmpty()) {
                                                val isPhrase = rawH.startsWith("\"") && rawH.endsWith("\"")
                                                vm.setPendingHighlight(rawH, isPhrase = isPhrase)
                                                vm.markOpenedFromSearch()
                                            }
                                            when {
                                                lower.endsWith(".pdf") -> {
                                                    vm.openArticle(rs.noteId, rs.title, fileType = "pdf")
                                                    nav.navigate("pdfReader/${rs.noteId}")
                                                }
                                                lower.endsWith(".mhtml") || lower.endsWith(".mht") -> {
                                                    vm.openArticle(rs.noteId, rs.title, fileType = "mhtml")
                                                    nav.navigate("htmlReader/${rs.noteId}")
                                                }
                                                lower.endsWith(".html") || lower.endsWith(".htm") -> {
                                                    vm.openArticle(rs.noteId, rs.title, fileType = "html")
                                                    nav.navigate("htmlReader/${rs.noteId}")
                                                }
                                                lower.endsWith(".canvas") -> {
                                                    vm.openArticle(rs.noteId, rs.title, fileType = "canvas")
                                                    nav.navigate("canvas/${rs.noteId}")
                                                }
                                                else -> {
                                                    vm.openArticle(rs.noteId, rs.title)
                                                    nav.navigate("reader") { launchSingleTop = true }
                                                }
                                            }
                                        }
                                        .padding(horizontal = 12.dp, vertical = 16.dp)
                                ) {
                                    Row(verticalAlignment = Alignment.CenterVertically) {
                                        Text("\uD83D\uDD52", fontSize = 11.sp)
                                        Spacer(Modifier.width(6.dp))
                                        Text(
                                            rs.query, fontSize = 11.sp,
                                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                                            fontWeight = FontWeight.Medium,
                                            maxLines = 1, overflow = TextOverflow.Ellipsis
                                        )
                                    }
                                    Spacer(Modifier.height(2.dp))
                                    Text(
                                        highlightTerms(cleanTitleForDisplay(rs.title), toks),
                                        fontWeight = FontWeight.SemiBold,
                                        fontSize = 14.sp,
                                        maxLines = 2, overflow = TextOverflow.Ellipsis,
                                        lineHeight = 18.sp
                                    )
                                    Text(
                                        highlightTerms(rs.relPath, toks),
                                        fontSize = 11.sp,
                                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                                        maxLines = 2, overflow = TextOverflow.Ellipsis
                                    )
                                    // v4.6 — readable date+time for every recent
                                    // search entry. User asked: "search history
                                    // must have timestamps (date and time opened)".
                                    Text(
                                        buildString {
                                            append(formatRecentTimestamp(rs.ts))
                                            if (rs.durationMs > 0L) {
                                                append(" · Search took ")
                                                append(formatSearchDuration(rs.durationMs))
                                            }
                                        },
                                        fontSize = 10.sp,
                                        color = MaterialTheme.colorScheme.primary,
                                        maxLines = 1
                                    )
                                }
                            }
                            HistoryBoldDivider()
                        }
                        item {
                            Text(
                                "Clear recent searches",
                                Modifier
                                    .fillMaxWidth()
                                    .clickable { vm.clearRecentSearches() }
                                    .padding(horizontal = 20.dp, vertical = 14.dp),
                                fontSize = 12.sp,
                                color = MaterialTheme.colorScheme.primary
                            )
                        }
                    }
                } else if (noMatches) {
                    item { WebSearchPrompt(trimmed, vm) }
                } else {
                    val highlightTokens = resultPresentation.highlightTokens
                    val llmHighlightTokens = resultPresentation.llmHighlightTokens
                    val filteredResults = resultPresentation.filteredResults
                    val hiddenCount = resultPresentation.hiddenCount

                    // v4.7.7 — always show the jw.org / wol.jw.org buttons,
                    // even when local matches exist. The user wants to be able
                    // to one-tap escalate to external search whenever they
                    // want, not just when the library comes up empty.
                    item { WebSearchPrompt(trimmed, vm) }
                    // v5.4.6 — Manual rerank trigger. Shows above the
                    // result rows when reranker is installed and the
                    // current view hasn't been reranked yet for this
                    // query. Tap → reorders results in place using the
                    // cross-encoder. Hidden once applied (until query
                    // changes again). Also shown with a tiny "reranked"
                    // ribbon if the current view IS the manual-rerank
                    // output, so the user knows what they're looking at.
                    // v5.4.16 — Keyword filter toggle chip, sits at the
                    // top of the results list next to (above) the rerank
                    // banner. Lets the user flip the filter on/off
                    // without going into Settings. Showing the current
                    // state in the chip label keeps the affordance
                    // obvious.
                    item {
                        androidx.compose.foundation.layout.Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(horizontal = 14.dp, vertical = 4.dp),
                            horizontalArrangement = androidx.compose.foundation.layout.Arrangement.spacedBy(8.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            androidx.compose.material3.FilterChip(
                                selected = keywordFilterOn,
                                onClick = {
                                    vm.setKeywordFilterEnabled(!keywordFilterOn)
                                },
                                label = {
                                    Text(
                                        if (keywordFilterOn)
                                            "\uD83E\uDDF9 Keyword filter: ON"
                                        else
                                            "\uD83E\uDDF9 Keyword filter: OFF",
                                        fontSize = 12.sp
                                    )
                                }
                            )
                            if (hiddenCount > 0 && keywordFilterOn) {
                                Text(
                                    "$hiddenCount hidden",
                                    fontSize = 11.sp,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }
                        }
                    }
                    if (showManualRerankButton) {
                        item {
                            ManualRerankBanner(
                                inProgress = manualRerankBusy,
                                onTap = { vm.manuallyRerankCurrentResults() }
                            )
                        }
                    } else if (manualRerank?.first == trimmed) {
                        item {
                            Text(
                                "\u2728 Reranked for relevance",
                                fontSize = 11.sp,
                                color = MaterialTheme.colorScheme.primary,
                                modifier = Modifier.padding(
                                    horizontal = 14.dp, vertical = 4.dp
                                )
                            )
                        }
                    }
                    // Discoverability hint — tells the user that long-press
                    // is available. Tucked above the results list so it's
                    // visible exactly when they need it.
                    item {
                        Text(
                            "\uD83D\uDCA1 Tap to open · long-press for more options",
                            fontSize = 11.sp,
                            color = MaterialTheme.colorScheme.primary,
                            modifier = Modifier.padding(horizontal = 14.dp, vertical = 6.dp)
                        )
                    }
                    // v4.17.0 — Transparency: tell the user when matches were
                    // filtered out so the list doesn't feel silently shorter
                    // than expected. Only shown when ≥1 result was hidden.
                    if (hiddenCount > 0) {
                        item {
                            Text(
                                "\uD83D\uDD0E ${hiddenCount} weak match${if (hiddenCount == 1) "" else "es"} hidden \u00B7 needs at least 2 matching words",
                                fontSize = 11.sp,
                                color = MaterialTheme.colorScheme.onSurfaceVariant,
                                modifier = Modifier.padding(horizontal = 14.dp, vertical = 4.dp)
                            )
                        }
                    }
                    itemsIndexed(filteredResults, key = { _, item -> item.id }) { index, hit ->
                        // v5.4.157cc — Staggered fade + slide-up entrance.
                        // Each result starts at alpha 0 / offset 24dp down,
                        // then animates to alpha 1 / offset 0 with a small
                        // per-index delay so results cascade in rather than
                        // dumping onto screen at once. Delay is capped at
                        // 300ms (10 items) so long result lists don't make
                        // the tail of the list wait ages to appear.
                        val resultAnim = UiAnim.prefs
                        val alreadyAnimated = remember(hit.id) { hit.id in animatedResultIds }
                        val entranceProgress = remember(hit.id) {
                            Animatable(if (alreadyAnimated || !resultAnim.enabled) 1f else 0f)
                        }
                        LaunchedEffect(hit.id, resultAnim.enabled, resultAnim.speed) {
                            if (hit.id !in animatedResultIds && resultAnim.enabled) {
                                delay((index.toLong() * resultAnim.scaledDurationMs(30))
                                    .coerceAtMost(resultAnim.scaledDurationMs(300).toLong()))
                                entranceProgress.animateTo(1f, animationSpec = tween(resultAnim.scaledDurationMs(280)))
                            } else entranceProgress.snapTo(1f)
                            animatedResultIds.add(hit.id)
                        }
                        val artifactThemeName = LocalArtifactThemeName.current
                        // v5.5.41 — Alternate two *opaque*, theme-derived result
                        // backgrounds. Previous cards used the same mostly-
                        // transparent tint, making adjacent results indistinct.
                        // Blending a little of the theme's readable foreground
                        // into its surface keeps text contrast high in dark,
                        // AMOLED, light, artifact and user-imported themes.
                        // This is independent of query-expansion chip colors.
                        val resultColors = MaterialTheme.colorScheme
                        // Some legacy/custom palettes have low foreground-
                        // surface contrast (notably the mid-grey theme). Lift
                        // or deepen only these card surfaces, rather than
                        // changing app-wide colors or putting pale text on a
                        // pale tile. Both card shades share the safe base.
                        val baseCardSurface = if (
                            resultCardContrast(resultColors.onSurface, resultColors.surface) < 5.3f
                        ) {
                            androidx.compose.ui.graphics.lerp(
                                resultColors.surface,
                                if (resultColors.onSurface.luminance() > resultColors.surface.luminance())
                                    Color.Black else Color.White,
                                0.55f
                            )
                        } else resultColors.surface
                        val darkResultCards = baseCardSurface.luminance() < 0.45f
                        val resultSurfaceColor = androidx.compose.ui.graphics.lerp(
                            baseCardSurface,
                            resultColors.onSurface,
                            if (index % 2 == 0) {
                                if (darkResultCards) 0.035f else 0.020f
                            } else {
                                if (darkResultCards) 0.145f else 0.095f
                            }
                        )
                        // Metadata normally uses the theme's quieter text.
                        // Fall back to its high-contrast body text only on
                        // palettes where the quiet color would be unreadable.
                        val resultSecondaryTextColor = if (
                            resultCardContrast(resultColors.onSurfaceVariant, resultSurfaceColor) >= 4.5f
                        ) resultColors.onSurfaceVariant else resultColors.onSurface
                        // Keep last-completed result labels intact through a
                        // cancelled search; merely hide them during an in-flight
                        // search to avoid momentarily painting old-query colors.
                        val hitProvenance = if (isSearchBusy) null
                            else resultQueryProvenanceById[hit.id]
                        val primaryExpansionNumber = hitProvenance?.primary?.expansionNumber
                        val expansionPalette = primaryExpansionNumber?.let {
                            resultExpansionPalette(it)
                        }
                        val resultShape = if (isArtifactTheme(artifactThemeName)) {
                            when (index % 3) {
                                0 -> RoundedCornerShape(topStart = 7.dp, topEnd = 16.dp, bottomEnd = 12.dp, bottomStart = 9.dp)
                                1 -> RoundedCornerShape(topStart = 14.dp, topEnd = 8.dp, bottomEnd = 15.dp, bottomStart = 8.dp)
                                else -> RoundedCornerShape(12.dp)
                            }
                        } else RoundedCornerShape(obsidianUiDp(10.dp, "--radius-m", "--card-radius", "--nav-item-radius"))
                        // v5.5.42 — An unmistakable, full 3dp outline on EVERY
                        // result, rather than the faint 1.5dp/2dp outline.
                        // Keep the original expansion accent when it is legible
                        // against the card; otherwise use the theme's high-
                        // contrast onSurface color. All provenance chips keep
                        // their own expansion colors regardless of this fallback.
                        val resultBorderColor = expansionPalette?.accent?.takeIf {
                            resultCardContrast(it, resultSurfaceColor) >= 3f
                        } ?: resultColors.onSurface
                        Surface(
                            color = resultSurfaceColor,
                            contentColor = resultColors.onSurface,
                            border = androidx.compose.foundation.BorderStroke(
                                width = 3.dp,
                                color = resultBorderColor
                            ),
                            // v5.4.171cc — "3D look" extended to result cards.
                            // shadowElevation is Surface's OWN native property
                            // (not a bolted-on overlay), so it's guaranteed to
                            // render correctly regardless of the card's
                            // semi-transparent color — unlike a gradient
                            // layered outside the Surface, which risks being
                            // covered by the Surface's own background paint.
                            // Small shadows stop at the card rather than
                            // visually bridging the now-obvious gutters.
                            shadowElevation = 2.dp,
                            modifier = Modifier
                                .fillMaxWidth()
                                // The gutter is outside the Surface and border,
                                // exposing actual list background between cards.
                                // No full-width divider crosses this empty gap.
                                .padding(start = 14.dp, top = if (index == 0) 8.dp else 3.dp, end = 14.dp, bottom = 20.dp)
                                .graphicsLayer {
                                    alpha = if (resultAnim.enabled) entranceProgress.value else 1f
                                    translationY = if (resultAnim.enabled) (1f - entranceProgress.value) * 24.dp.toPx() else 0f
                                },
                            shape = resultShape
                        ) {
                            // v4.7.4 — switched from combinedClickable to direct
                            // pointerInput + detectTapGestures. The former works
                            // most of the time but can be eaten by LazyColumn's
                            // scroll gesture detector on some devices, causing
                            // the long-press to silently never fire. The latter
                            // gives explicit control. Haptic feedback on long-
                            // press also gives the user immediate confirmation
                            // that the gesture was detected.
                            val haptic = androidx.compose.ui.platform.LocalHapticFeedback.current
                            Column(
                                Modifier
                                    .fillMaxWidth()
                                    .pointerInput(hit.id) {
                                        detectTapGestures(
                                            onTap = {
                                                vm.recordSearchClick(trimmed, hit.id, hit.title, hit.relPath)
                                                // v5.3.0 — Pass just the query.
                                                // The reader's new
                                                // sentence-level highlighter
                                                // extracts distinctive terms
                                                // from the query and
                                                // highlights whole sentences
                                                // containing them.
                                                // v5.4.10 — Also preserves
                                                // exact-phrase flag.
                                                if (trimmed.isNotEmpty()) {
                                                    val isPhrase = trimmed.startsWith("\"") && trimmed.endsWith("\"")
                                                    vm.setPendingHighlight(
                                                        trimmed,
                                                        isPhrase = isPhrase,
                                                        snippet = hit.snippet
                                                    )
                                                    vm.markOpenedFromSearch()
                                                }
                                                when (hit.fileType.lowercase()) {
                                                    "pdf" -> {
                                                        vm.openArticle(hit.id, hit.title, fileType = "pdf")
                                                        nav.navigate("pdfReader/${hit.id}")
                                                    }
                                                    "mhtml", "mht", "html", "htm" -> {
                                                        vm.openArticle(hit.id, hit.title, fileType = hit.fileType)
                                                        nav.navigate("htmlReader/${hit.id}")
                                                    }
                                                    "canvas" -> {
                                                        vm.openArticle(hit.id, hit.title, fileType = "canvas")
                                                        nav.navigate("canvas/${hit.id}")
                                                    }
                                                    else -> {
                                                        vm.openArticle(hit.id, hit.title)
                                                        nav.navigate("reader") { launchSingleTop = true }
                                                    }
                                                }
                                            },
                                            onLongPress = {
                                                // Haptic buzz so the user knows the press registered.
                                                haptic.performHapticFeedback(
                                                    androidx.compose.ui.hapticfeedback.HapticFeedbackType.LongPress
                                                )
                                                longPressTarget = SearchHit(
                                                    id = hit.id, title = hit.title,
                                                    relPath = hit.relPath, fileType = hit.fileType,
                                                    snippet = hit.snippet
                                                )
                                            }
                                        )
                                    }
                                    // v4.14.0 — more vertical breathing room between
                                    // result rows. The bolder divider already makes
                                    // boundaries clear; adding generous padding keeps
                                    // each card from feeling cramped.
                                    .padding(horizontal = 12.dp, vertical = if (isTabletWidth || workspaceTabletUi) 10.dp else 18.dp)
                            ) {
                                // Rank follows the currently VISIBLE order,
                                // including keyword filtering, saved sessions
                                // and manual reranking (never the database id).
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                                ) {
                                    Surface(
                                        color = resultColors.primaryContainer,
                                        contentColor = resultColors.onPrimaryContainer,
                                        shape = RoundedCornerShape(7.dp)
                                    ) {
                                        Text(
                                            text = "#${index + 1}",
                                            modifier = Modifier.padding(horizontal = 10.dp, vertical = 5.dp),
                                            fontWeight = FontWeight.Bold,
                                            fontSize = 14.sp
                                        )
                                    }
                                    Text(
                                        text = "Search result",
                                        fontSize = 11.sp,
                                        color = resultSecondaryTextColor
                                    )
                                }
                                Spacer(Modifier.height(9.dp))
                                if (hitProvenance != null) {
                                    SearchResultProvenanceBlock(
                                        resultId = hit.id,
                                        provenance = hitProvenance,
                                        secondaryTextColor = resultSecondaryTextColor
                                    )
                                    Spacer(Modifier.height(8.dp))
                                }
                                // v4.7.6 — clean the title for display so URLs
                                // embedded in markdown link syntax like
                                //   # [Am I a Perfectionist?](https://.../teenager/...)
                                // don't crowd out the visible text. We highlight
                                // matches inside the cleaned title. If the search
                                // term matched somewhere that's NOT visible
                                // (the URL was stripped, or the term lives in
                                // a long part that gets truncated), we render
                                // a small context snippet below so the user can
                                // see WHERE the match was found.
                                val displayTitle = cleanTitleForDisplay(hit.title)
                                // v4.24.0 — Relevance percentage chip,
                                // top-right of the card. Only shown when
                                // semantic search contributed a score
                                // (i.e. when reranker probability or
                                // BGE-large cosine is available). For
                                // keyword-only matches we hide it — a
                                // misleading percentage is worse than none.
                                val isLlmMatched = hit.id in llmMatchedIds
                                val scopeBadge = resultScopeById[hit.id]
                                if (hit.score != null || isLlmMatched || scopeBadge != null) {
                                    Row(
                                        Modifier.fillMaxWidth(),
                                        horizontalArrangement = androidx.compose.foundation.layout.Arrangement.End,
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        if (scopeBadge != null) {
                                            androidx.compose.material3.Surface(
                                                color = MaterialTheme.colorScheme.secondaryContainer.copy(alpha = 0.85f),
                                                shape = RoundedCornerShape(7.dp)
                                            ) {
                                                Text(
                                                    if (scopeBadge == "first20k") "1st 20K" else "2nd 22K",
                                                    fontSize = 10.sp,
                                                    fontWeight = FontWeight.Bold,
                                                    modifier = Modifier.padding(horizontal = 7.dp, vertical = 3.dp)
                                                )
                                            }
                                            Spacer(Modifier.width(6.dp))
                                        }
                                        if (isLlmMatched) {
                                            // v5.4.76cc — Trace chip:
                                            // this row was surfaced by
                                            // the LLM's paraphrase of
                                            // the user's query, not the
                                            // original tokens. Kept
                                            // small and lavender so it
                                            // reads as an ambient
                                            // marker, not a shout.
                                            AiTraceChip()
                                            Spacer(Modifier.width(6.dp))
                                        }
                                        if (hit.score != null) {
                                            ChatRelevanceChip(hit.score)
                                        }
                                    }
                                    Spacer(Modifier.height(4.dp))
                                }
                                val titleHasMatch = highlightTokens.any {
                                    displayTitle.contains(it, ignoreCase = true)
                                }
                                val pathHasMatch = highlightTokens.any {
                                    hit.relPath.contains(it, ignoreCase = true)
                                }
                                Text(
                                    highlightTerms(displayTitle, highlightTokens),
                                    fontWeight = FontWeight.SemiBold,
                                    maxLines = 2,
                                    overflow = TextOverflow.Ellipsis,
                                    lineHeight = 18.sp
                                )
                                Text(
                                    highlightTerms(hit.relPath, highlightTokens),
                                    fontSize = 11.sp,
                                    color = resultSecondaryTextColor,
                                    maxLines = 2,
                                    overflow = TextOverflow.Ellipsis
                                )
                                if (!titleHasMatch && !pathHasMatch) {
                                    // The match must be living in the URL we
                                    // just stripped from the title (or in the
                                    // file name). Compute a tight context
                                    // window around the first match in the raw
                                    // title + name so it's still visible.
                                    val context = matchContextSnippet(
                                        "${hit.title} ${hit.relPath}",
                                        highlightTokens
                                    )
                                    if (context != null) {
                                        Spacer(Modifier.height(2.dp))
                                        Text(
                                            highlightTerms(context, highlightTokens),
                                            fontSize = 11.sp,
                                            color = MaterialTheme.colorScheme.primary,
                                            maxLines = 1,
                                            overflow = TextOverflow.Ellipsis
                                        )
                                    }
                                }
                                if (hit.snippet.isNotBlank()) {
                                    Spacer(Modifier.height(4.dp))
                                    // v4.24.0 — Phrase-level highlighting:
                                    // sentences containing 2+ query terms get
                                    // a background tint; sentences with only
                                    // 1 incidental match are NOT highlighted.
                                    // Avoids the previous "every common word
                                    // is yellow" noise that made bad matches
                                    // look like good ones.
                                    Text(
                                        highlightSentences(hit.snippet, highlightTokens, llmHighlightTokens),
                                        fontSize = 13.sp,
                                        lineHeight = 18.sp
                                    )
                                }
                                // v5.4.228cc — Media badges. Scan title+snippet
                                // for video/audio URLs and show tappable buttons
                                // that open the FloatingMediaPopup.
                                val mediaHits = remember(hit.id, hit.snippet) {
                                    com.tebogo.markvault.util.MediaLinkDetector
                                        .detect(hit.title + "\n" + hit.snippet)
                                }
                                if (mediaHits.isNotEmpty()) {
                                    Spacer(Modifier.height(8.dp))
                                    Row(
                                        horizontalArrangement = Arrangement.spacedBy(6.dp),
                                        modifier = Modifier.fillMaxWidth()
                                    ) {
                                        mediaHits.forEach { m ->
                                            androidx.compose.material3.Surface(
                                                onClick = {
                                                    pendingBadgeTitle = hit.title
                                                    pendingBadgeKind  = m.kind
                                                    pendingBadgeUrl   = m.url
                                                },
                                                color = MaterialTheme.colorScheme.surfaceVariant
                                                    .copy(alpha = 0.6f),
                                                shape = androidx.compose.foundation.shape.RoundedCornerShape(obsidianUiDp(6.dp, "--radius-s", "--button-radius")),
                                                modifier = Modifier.weight(1f)
                                            ) {
                                                Row(
                                                    modifier = Modifier.padding(horizontal = 8.dp, vertical = 6.dp),
                                                    verticalAlignment = Alignment.CenterVertically,
                                                    horizontalArrangement = Arrangement.spacedBy(4.dp)
                                                ) {
                                                    Text(
                                                        if (m.kind == "audio") "\uD83D\uDD0A" else "\u25B6",
                                                        fontSize = 12.sp
                                                    )
                                                    val label = if (m.kind == "audio")
                                                        "Listen to Audio" else "Watch Video"
                                                    val minsSuffix = if (m.estimatedMinutes > 0)
                                                        " (${m.estimatedMinutes} min)" else ""
                                                    Text(
                                                        label + minsSuffix,
                                                        fontSize = 11.sp,
                                                        maxLines = 1,
                                                        overflow = TextOverflow.Ellipsis
                                                    )
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                        }
                        // v5.5.42: Do not draw HistoryBoldDivider() here.
                        // Full-width rules made otherwise separated result
                        // cards appear to belong to one continuous panel.
                        // The real 20dp outside-card gutter is above.
                    }
                }
                item { Spacer(Modifier.height(24.dp)) }
            } // end LazyColumn

            // Floating saved-search navigation is intentionally button-based.
            // It never participates in gesture arbitration, so it cannot hide
            // results, steal vertical scrolling, or conflict with Android Back.
            if (activeSavedSearchId != null) {
                previousSavedSession?.let { target ->
                    Surface(
                        modifier = Modifier
                            .align(Alignment.CenterStart)
                            .padding(start = 6.dp)
                            .size(46.dp)
                            .clickable { vm.restoreSavedSearchSession(target.id) },
                        shape = RoundedCornerShape(23.dp),
                        color = MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.94f),
                        shadowElevation = 6.dp
                    ) {
                        Box(contentAlignment = Alignment.Center) {
                            Text(
                                "‹",
                                fontSize = 30.sp,
                                fontWeight = FontWeight.Bold,
                                color = MaterialTheme.colorScheme.onPrimaryContainer
                            )
                        }
                    }
                }
                nextSavedSession?.let { target ->
                    Surface(
                        modifier = Modifier
                            .align(Alignment.CenterEnd)
                            .padding(end = 6.dp)
                            .size(46.dp)
                            .clickable { vm.restoreSavedSearchSession(target.id) },
                        shape = RoundedCornerShape(23.dp),
                        color = MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.94f),
                        shadowElevation = 6.dp
                    ) {
                        Box(contentAlignment = Alignment.Center) {
                            Text(
                                "›",
                                fontSize = 30.sp,
                                fontWeight = FontWeight.Bold,
                                color = MaterialTheme.colorScheme.onPrimaryContainer
                            )
                        }
                    }
                }
            }
            } // end saved-results Box
        }
            // v5.4.251cc — Thin vertical media panel, tablet width only —
            // mirrors SearchTabletRecentsPanel's left-side pattern above,
            // just on the right and much narrower ("thinner window next
            // to the search results").
            if ((isTabletWidth || workspaceTabletUi) && !hideTopBar && query.trim().length >= 2 && combinedMediaResults.isNotEmpty()) {
                androidx.compose.material3.VerticalDivider()
                MediaSearchSidePanel(
                    items = combinedMediaResults,
                    onItemClick = { vm.requestMediaPopup(it) },
                    onItemLongPress = { longPressMediaItem = it },
                    modifier = Modifier.width(160.dp).fillMaxHeight()
                )
            }
        } // v5.4.30 — close outer Row
    }

    // v5.4.324cc — In Workspace the recent-searches panel is an overlay sheet,
    // not a fixed 220/280dp column. Search results therefore keep the full
    // centre width even when history is being consulted.
    if (hideTopBar && tabletRecentsOpen) {
        ModalBottomSheet(onDismissRequest = { tabletRecentsOpen = false }) {
            SearchTabletRecentsPanel(
                vm = vm,
                recentSearches = recentSearches,
                modifier = Modifier.fillMaxWidth().height(480.dp)
            )
            Spacer(Modifier.height(12.dp))
        }
    }

    // v5.4.228cc — Floating media popup player
    val mediaPopupReq by vm.mediaPopupRequest.collectAsStateWithLifecycle()
    mediaPopupReq?.let { req ->
        com.tebogo.markvault.ui.FloatingMediaPopup(
            vm        = vm,
            title     = req.title,
            url       = req.url,
            mediaType = req.mediaType,
            onDismiss = { vm.dismissMediaPopup() },
            onOpenFullPlayer = {
                vm.dismissMediaPopup()
                nav.navigate("mediaPlayer/0") { launchSingleTop = true }
            }
        )
    }

    // v5.4.255cc — Long-press menu (Favourite / Add to Playlist) for the
    // media carousel/panel above — same state+render pattern as the
    // existing longPressTarget/SearchResultActionSheet below, for notes.
    longPressMediaItem?.let { media ->
        MediaLongPressMenu(vm = vm, item = media, onDismiss = { longPressMediaItem = null })
    }

    // v4.7 — long-press action sheet on search results.
    longPressTarget?.let { hit ->
        SearchResultActionSheet(
            hit = hit,
            vm = vm,
            nav = nav,
            onDismiss = { longPressTarget = null },
            onPickSplitPair = {
                splitPickerTarget = hit
                longPressTarget = null
            },
            onPickConvert = {
                convertTarget = hit
                longPressTarget = null
            }
        )
    }

    splitPickerTarget?.let { hit ->
        SplitPartnerPickerDialog(
            hit = hit,
            vm = vm,
            nav = nav,
            onDismiss = { splitPickerTarget = null }
        )
    }

    convertTarget?.let { hit ->
        ConvertTargetDialog(
            hit = hit,
            vm = vm,
            onDismiss = { convertTarget = null }
        )
    }

    // ── v5.4.132cc — Multi-article pumping-heart popup overlay ──
    // A pumping 💗 FAB anchored to bottom-start (above the reader
    // toolbar) fires the multi-article popup: it collects the top-N
    // articles from the current search results, extracts semantic
    // passages from each, and shows them in the same typewriter
    // popup the reader screens use. Top-N is user-configurable via
    // vm.popupArticlesTopN (default 1). The overlay Box sits ABOVE
    // the Scaffold in draw order so its children render on top of
    // the results list without blocking touches elsewhere.
    val ssPopupState by vm.articlePopupState.collectAsStateWithLifecycle()
    val ssTopN by vm.popupArticlesTopN.collectAsStateWithLifecycle()
    // v5.4.150cc — Typing speed persisted across app exit.
    val ssPopupTypingSpeed by vm.popupTypingSpeed.collectAsStateWithLifecycle()
    val ssPopupSlot: com.tebogo.markvault.AppViewModel.ArticlePopupState = ssPopupState
    val ssHasMinimized: Boolean =
        ssPopupSlot is com.tebogo.markvault.AppViewModel.ArticlePopupState.Visible &&
            ssPopupSlot.minimized
    val ssIsLoading: Boolean =
        ssPopupSlot is com.tebogo.markvault.AppViewModel.ArticlePopupState.Loading
    val ssCurrentQuery by vm.query.collectAsStateWithLifecycle()

    androidx.compose.foundation.layout.Box(
        Modifier.fillMaxSize()
    ) {
        // Show the heart FAB when there are search results AND we have
        // a query to run. The `pulsing` cadence continues either way —
        // that's the visual invitation the user asked for.
        val hasQueryForHeart: Boolean = ssCurrentQuery.trim()
            .removeSurrounding("\"").trim().length >= 2
        val hasHitsForHeart: Boolean = displayedResults.isNotEmpty()
        if (hasQueryForHeart && hasHitsForHeart) {
            PumpingHeartFab(
                // Pulse always so the user notices it. If a popup is
                // minimized, keep pulsing — same "you have one waiting"
                // signal as the brain button in the readers.
                pulsing = true,
                busy = ssIsLoading,
                onClick = {
                    // If a popup is already minimized, tapping the
                    // heart brings it back rather than starting a new
                    // multi-article search.
                    if (ssHasMinimized) {
                        vm.maximizeArticlePopup()
                        return@PumpingHeartFab
                    }
                    val q: String = ssCurrentQuery.trim()
                        .removeSurrounding("\"").trim()
                    if (q.length < 2) return@PumpingHeartFab
                    val hits: List<com.tebogo.markvault.data.SearchHit> =
                        displayedResults
                    if (hits.isEmpty()) return@PumpingHeartFab
                    vm.findAndShowMultiArticlePopup(q, hits, ssTopN)
                },
                modifier = Modifier
                    .align(Alignment.BottomStart)
                    // 80 dp bottom padding lifts the FAB above the
                    // bottom toolbar so it isn't obscured.
                    .padding(start = 16.dp, bottom = 80.dp)
            )
        }

        // v5.4.146cc — "Search on jw.org" floating button, centered above toolbar
        val showJwSearchButton by vm.showJwSearchButton.collectAsStateWithLifecycle()
        val hasQueryForJw: Boolean = ssCurrentQuery.trim()
            .removeSurrounding("\"").trim().length >= 2
        val hasHitsForJw: Boolean = displayedResults.isNotEmpty()
        val isSearchBusyJw = isSearchBusy  // From outer scope
        
        if (showJwSearchButton && hasQueryForJw && hasHitsForJw && !isSearchBusyJw) {
            val encQuery = java.net.URLEncoder.encode(ssCurrentQuery.trim(), "UTF-8")
            Surface(
                color = MaterialTheme.colorScheme.primary.copy(alpha = 0.95f),
                shape = RoundedCornerShape(16.dp),
                modifier = Modifier
                    .align(Alignment.BottomCenter)
                    .padding(bottom = 90.dp)
                    .clickable {
                        vm.requestWebPopup("https://www.jw.org/en/search/?q=$encQuery")
                    }
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    modifier = Modifier.padding(horizontal = 16.dp, vertical = 10.dp)
                ) {
                    Text(
                        "🔍 Search on jw.org",
                        color = MaterialTheme.colorScheme.onPrimary,
                        fontWeight = FontWeight.SemiBold,
                        fontSize = 13.sp
                    )
                }
            }
        }

        // v5.4.181cc — "Jump to top" floating button. Search results can
        // load in a way that leaves the user scrolled past the top of
        // the list without a clear way back up short of a long manual
        // swipe — this surfaces once they've scrolled down INTO actual
        // results and gives a one-tap way back to the top of the list.
        // Positioned bottom-end so it doesn't collide with the heart FAB
        // (bottom-start) or "Search on jw.org" (bottom-center).
        val showJumpToTop by remember {
            derivedStateOf {
                resultsListState.firstVisibleItemIndex > 0 && displayedResults.isNotEmpty()
            }
        }
        if (showJumpToTop) {
            val jumpScope = androidx.compose.runtime.rememberCoroutineScope()
            AnimatedJumpToTop(
                onClick = { jumpScope.launch { resultsListState.animateScrollToItem(0) } },
                modifier = Modifier
                    .align(Alignment.BottomCenter)
                    // Sit immediately above the centered JW.org search pill,
                    // leaving both controls fully visible and independently tappable.
                    .padding(bottom = 146.dp)
            )
        }

        // Popup rendering — same four-state pattern as the readers.
        when (ssPopupSlot) {
            is com.tebogo.markvault.AppViewModel.ArticlePopupState.Loading -> {
                ArticlePopupLoading(
                    query = ssPopupSlot.query,
                    onCancel = { vm.closeArticlePopup() },
                    modifier = Modifier
                        .align(Alignment.BottomCenter)
                        .padding(bottom = 80.dp, start = 16.dp, end = 16.dp)
                )
            }
            is com.tebogo.markvault.AppViewModel.ArticlePopupState.Empty -> {
                ArticlePopupEmpty(
                    query = ssPopupSlot.query,
                    onClose = { vm.closeArticlePopup() },
                    modifier = Modifier
                        .align(Alignment.BottomCenter)
                        .padding(bottom = 80.dp, start = 16.dp, end = 16.dp)
                )
            }
            is com.tebogo.markvault.AppViewModel.ArticlePopupState.Visible -> {
                if (ssPopupSlot.minimized) {
                    MinimizedPopupPill(
                        query = ssPopupSlot.query,
                        onMaximize = { vm.maximizeArticlePopup() },
                        onClose = { vm.closeArticlePopup() },
                        modifier = Modifier
                            .align(Alignment.BottomStart)
                            .padding(start = 16.dp, bottom = 140.dp)
                    )
                } else {
                    ArticlePopupOverlay(
                        query = ssPopupSlot.query,
                        passages = ssPopupSlot.passages,
                        onClose = { vm.closeArticlePopup() },
                        onMinimize = { vm.minimizeArticlePopup() },
                        onCycleBlur = { vm.cycleArticlePopupBlur() },
                        // v5.4.135cc — Route "📖 Open" through the same
                        // fileType-based navigation the primary tap uses.
                        onOpenArticle = ssPopupSlot.openableFileType?.let { ft ->
                            {
                                val nid: Long = ssPopupSlot.noteId
                                // Look up title from displayedResults so
                                // openArticle records the right label.
                                val title: String = displayedResults
                                    .firstOrNull { it.id == nid }
                                    ?.title
                                    ?: ""
                                vm.closeArticlePopup()
                                when (ft.lowercase()) {
                                    "html", "htm", "mhtml", "mht" -> {
                                        vm.openArticle(nid, title, fileType = ft)
                                        runCatching { nav.navigate("htmlReader/$nid") }
                                    }
                                    "canvas" -> {
                                        vm.openArticle(nid, title, fileType = "canvas")
                                        runCatching { nav.navigate("canvas/$nid") }
                                    }
                                    "pdf" -> {
                                        vm.openArticle(nid, title, fileType = ft)
                                        runCatching { nav.navigate("pdfReader/$nid") }
                                    }
                                    else -> {
                                        vm.openArticle(nid, title)
                                        runCatching { nav.navigate("reader") { launchSingleTop = true } }
                                    }
                                }
                            }
                        },
                        // URL links (scripture refs, footnotes, etc.) are sent
                        // through the global WebViewer request so Settings can
                        // choose floating-popup, full-screen, or system-browser
                        // presentation without changing this search UI.
                        onOpenUrl = { url ->
                            vm.requestWebPopup(url)
                        },
                        // v5.4.150cc — Wire mode and AI toggle so the AI chip
                        // is pressable in SearchScreen. Use the cached article text
                        // (set by findAndShowArticlePassages) — avoids a DB reload.
                        mode = ssPopupSlot.mode,
                        onToggleMode = {
                            val slotNoteId = ssPopupSlot.noteId
                            val slotQuery  = ssPopupSlot.query
                            val slotText   = vm.cachedArticleTextForPopup
                            vm.toggleArticlePopupMode(slotNoteId, slotText, slotQuery)
                        },
                        // v5.4.150cc — Typing speed backed by DataStore.
                        typingSpeed = ssPopupTypingSpeed,
                        onTypingSpeedChange = { vm.setPopupTypingSpeed(it) },
                        // v5.4.150cc — Start at bottom-center.
                        modifier = Modifier
                            .align(Alignment.BottomCenter)
                            .padding(bottom = 80.dp, start = 12.dp, end = 12.dp)
                    )
                }
            }
            is com.tebogo.markvault.AppViewModel.ArticlePopupState.Hidden -> {
                // Nothing rendered
            }
        }
    }
}

/** WCAG contrast ratio for the dynamically themed search-result tiles. */
private fun resultCardContrast(foreground: Color, background: Color): Float {
    val front = foreground.luminance()
    val back = background.luminance()
    return (maxOf(front, back) + 0.05f) / (minOf(front, back) + 0.05f)
}

private data class ResultExpansionPalette(
    val accent: Color,
    val container: Color,
    val onContainer: Color
)

/**
 * v5.5.23 — A deterministic color per expansion number with separate dark and
 * light tonal ranges. Foreground is selected from measured luminance, so these
 * labels remain readable under app themes instead of relying on a fixed yellow.
 */
@Composable
private fun resultExpansionPalette(expansionNumber: Int): ResultExpansionPalette {
    val number = expansionNumber.coerceAtLeast(1)
    val darkSurface = MaterialTheme.colorScheme.surface.luminance() < 0.45f
    // Golden-angle spacing keeps adjacent and later expansion numbers distinct.
    val hue = ((number - 1) * 137.508f + 272f) % 360f
    val accent = Color.hsl(
        hue = hue,
        saturation = if (darkSurface) 0.76f else 0.78f,
        lightness = if (darkSurface) 0.68f else 0.38f
    )
    val container = Color.hsl(
        hue = hue,
        saturation = if (darkSurface) 0.46f else 0.55f,
        lightness = if (darkSurface) 0.22f else 0.92f
    )
    val onContainer = if (container.luminance() > 0.50f) {
        Color(0xFF111116)
    } else {
        Color(0xFFF8F8FC)
    }
    return ResultExpansionPalette(accent, container, onContainer)
}

private fun QuerySource.toResultQuerySource(): ResultQuerySource = when (this) {
    QuerySource.ORIGINAL -> ResultQuerySource.ORIGINAL
    QuerySource.QUESTION_AWARENESS -> ResultQuerySource.QUESTION_AWARENESS
    QuerySource.SYNONYM -> ResultQuerySource.SYNONYM
    QuerySource.LLM -> ResultQuerySource.LLM
    QuerySource.T5 -> ResultQuerySource.T5
}

/** One compact, clickable expansion line for *every* configured engine. */
@Composable
private fun QueryExpansionLegend(
    originalQuery: String,
    expansions: List<VisibleExpansionQuery>,
    saved: Boolean
) {
    var expanded by rememberSaveable(originalQuery, saved) { mutableStateOf(false) }
    Surface(
        color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.32f),
        shape = RoundedCornerShape(10.dp),
        modifier = Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 4.dp)
    ) {
        Column(Modifier.padding(horizontal = 10.dp, vertical = 5.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth().clickable { expanded = !expanded }
                    .padding(vertical = 6.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    "🧩 Query expansions (${expansions.size})",
                    fontSize = 12.sp,
                    fontWeight = FontWeight.SemiBold,
                    color = MaterialTheme.colorScheme.onSurface,
                    modifier = Modifier.weight(1f)
                )
                Text(
                    if (expanded) "▾ Hide queries" else "▸ Show queries",
                    fontSize = 11.sp,
                    color = MaterialTheme.colorScheme.primary
                )
            }
            AnimatedVisibility(visible = expanded, enter = fadeIn(), exit = fadeOut()) {
                Column(verticalArrangement = Arrangement.spacedBy(5.dp)) {
                    Text(
                        "🔎 Original — “$originalQuery”",
                        fontSize = 11.sp,
                        color = MaterialTheme.colorScheme.onSurface
                    )
                    expansions.forEach { entry ->
                        val palette = entry.number?.let { resultExpansionPalette(it) }
                        Surface(
                            color = palette?.container
                                ?: MaterialTheme.colorScheme.surfaceVariant,
                            contentColor = palette?.onContainer
                                ?: MaterialTheme.colorScheme.onSurfaceVariant,
                            shape = RoundedCornerShape(7.dp)
                        ) {
                            Column(Modifier.fillMaxWidth().padding(horizontal = 9.dp, vertical = 7.dp)) {
                                Text(
                                    "${entry.source?.provenanceGlyph() ?: "🧩"} " +
                                        "${entry.number?.let { "Expansion $it" } ?: "Recorded expansion"}" +
                                        " · ${entry.source?.displayName ?: "Source not stored"}",
                                    fontWeight = FontWeight.SemiBold,
                                    fontSize = 11.sp
                                )
                                Text(
                                    "“${entry.text}”",
                                    fontSize = 11.sp,
                                    lineHeight = 15.sp
                                )
                            }
                        }
                    }
                }
            }
        }
    }
}

private fun ResultQuerySource.provenanceGlyph(): String = when (this) {
    ResultQuerySource.ORIGINAL -> "🔎"
    ResultQuerySource.QUESTION_AWARENESS -> "❓"
    ResultQuerySource.SYNONYM -> "🔁"
    ResultQuerySource.LLM -> "🤖"
    ResultQuerySource.T5 -> "🧠"
}

/**
 * Shows the strongest contributing query immediately and keeps every other
 * retrieval contributor available in a collapsible, fully-auditable section.
 */
@Composable
private fun SearchResultProvenanceBlock(
    resultId: Long,
    provenance: ResultQueryProvenance,
    secondaryTextColor: Color
) {
    val primary = provenance.primary ?: return
    val ordered = provenance.orderedContributions
    val otherContributors = ordered.filterNot { it.queryId == primary.queryId }
    val expansionCount = ordered.count { !it.isOriginal }
    var expanded by rememberSaveable(resultId, provenance.primaryQueryId) {
        mutableStateOf(false)
    }

    if (primary.isOriginal) {
        Column(Modifier.fillMaxWidth()) {
            Text(
                "🔎 Matched original query — “${primary.queryText}”",
                fontSize = 12.sp,
                fontWeight = FontWeight.Bold,
                color = MaterialTheme.colorScheme.onSurface
            )
            Text(
                primary.retrievalPathLabel,
                fontSize = 10.sp,
                color = secondaryTextColor
            )
        }
    } else {
        val palette = resultExpansionPalette(primary.expansionNumber ?: 1)
        Surface(
            color = palette.container,
            contentColor = palette.onContainer,
            shape = RoundedCornerShape(9.dp),
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(Modifier.padding(horizontal = 10.dp, vertical = 8.dp)) {
                Text(
                    "${primary.source.provenanceGlyph()} ${primary.displayLabel} — “${primary.queryText}”",
                    fontSize = 12.sp,
                    lineHeight = 16.sp,
                    fontWeight = FontWeight.Bold
                )
                Text(
                    "${primary.source.displayName} · ${primary.retrievalPathLabel}",
                    fontSize = 10.sp,
                    lineHeight = 14.sp,
                    color = palette.onContainer.copy(alpha = 0.82f)
                )
            }
        }
    }

    if (otherContributors.isNotEmpty() && !expanded) {
        // Multiple source hits retain *all* their colors, even if original
        // query evidence was the strongest and the card has no colored border.
        Column(
            modifier = Modifier.fillMaxWidth().padding(top = 5.dp),
            verticalArrangement = Arrangement.spacedBy(4.dp)
        ) {
            otherContributors.forEach { contribution ->
                val palette = contribution.expansionNumber?.let { resultExpansionPalette(it) }
                Surface(
                    color = palette?.container ?: MaterialTheme.colorScheme.surfaceVariant,
                    contentColor = palette?.onContainer ?: MaterialTheme.colorScheme.onSurfaceVariant,
                    shape = RoundedCornerShape(6.dp)
                ) {
                    Text(
                        "${contribution.source.provenanceGlyph()} ${contribution.displayLabel}" +
                            " · ${contribution.source.displayName} — “${contribution.queryText}”",
                        modifier = Modifier.fillMaxWidth().padding(horizontal = 8.dp, vertical = 4.dp),
                        fontSize = 10.sp,
                        lineHeight = 14.sp,
                        maxLines = 2,
                        overflow = TextOverflow.Ellipsis
                    )
                }
            }
        }
    }

    if (expansionCount > 0) {
        TextButton(
            onClick = { expanded = !expanded },
            contentPadding = PaddingValues(horizontal = 0.dp, vertical = 2.dp)
        ) {
            Text(
                "${if (expanded) "▾" else "▸"} Expansions ($expansionCount) · ${ordered.size} contributing quer${if (ordered.size == 1) "y" else "ies"}",
                fontSize = 10.sp,
                fontWeight = FontWeight.SemiBold
            )
        }

        AnimatedVisibility(
            visible = expanded,
            enter = fadeIn(),
            exit = fadeOut()
        ) {
            Column(
                modifier = Modifier.fillMaxWidth(),
                verticalArrangement = Arrangement.spacedBy(5.dp)
            ) {
                ordered.forEach { contribution ->
                    ProvenanceContributionRow(contribution)
                }
            }
        }
    }
}

@Composable
private fun ProvenanceContributionRow(contribution: QueryContribution) {
    val palette = contribution.expansionNumber?.let { resultExpansionPalette(it) }
    val container = palette?.container
        ?: MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.62f)
    val foreground = palette?.onContainer ?: MaterialTheme.colorScheme.onSurfaceVariant
    Surface(
        color = container,
        contentColor = foreground,
        shape = RoundedCornerShape(7.dp),
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(Modifier.padding(horizontal = 9.dp, vertical = 6.dp)) {
            Text(
                "${contribution.source.provenanceGlyph()} ${contribution.displayLabel} — “${contribution.queryText}”",
                fontSize = 11.sp,
                lineHeight = 15.sp,
                fontWeight = FontWeight.SemiBold
            )
            Text(
                "${contribution.source.displayName} · ${contribution.retrievalPathLabel}",
                fontSize = 10.sp,
                lineHeight = 14.sp,
                color = foreground.copy(alpha = 0.82f)
            )
        }
    }
}

/** Lightweight shadow of a search hit we can pass to dialog state. */
@Composable
private fun SavedSearchHeaderCard(
    report: com.tebogo.markvault.search.SavedSearchReport,
    onUnlock: () -> Unit
) {
    val session = report.session
    val scope = rememberCoroutineScope()
    val shatter = remember(session.id) { Animatable(0f) }
    var shattering by remember(session.id) { mutableStateOf(false) }
    val dateText = remember(session.createdAt) {
        java.text.DateFormat.getDateTimeInstance(
            java.text.DateFormat.MEDIUM,
            java.text.DateFormat.SHORT
        ).format(java.util.Date(session.createdAt))
    }
    val scopeText = savedSearchScopeLabel(session)
    val expansionUsed = session.expansions.isNotEmpty()
    val expansionMethod = when {
        !expansionUsed -> "Not used"
        session.llmUsed && session.llmEngine.isNotBlank() -> "LLM · ${session.llmEngine}"
        session.llmUsed -> "LLM"
        else -> "Query expansion"
    }
    val progress = shatter.value.coerceIn(0f, 1f)
    // v5.5.15 — Keep the question identity visible after opening a saved
    // result set. This uses persisted execution evidence, not query punctuation
    // alone, so the watermark means Question Awareness was actually used.
    val questionAnswered = session.questionAwarenessEnabled && session.queryDetectedAsQuestion && session.questionAwarenessUsed && session.questionAwareQueries.isNotEmpty()
    val savedCardColor = if (questionAnswered) {
        MaterialTheme.colorScheme.tertiaryContainer.copy(alpha = 0.96f)
    } else {
        MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.96f)
    }
    val savedDetailColor = if (questionAnswered) {
        MaterialTheme.colorScheme.onTertiaryContainer.copy(alpha = 0.78f)
    } else {
        MaterialTheme.colorScheme.onSurfaceVariant
    }
    val savedAccentColor = if (questionAnswered) {
        MaterialTheme.colorScheme.onTertiaryContainer
    } else {
        MaterialTheme.colorScheme.primary
    }

    Box(
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 8.dp, vertical = 6.dp)
    ) {
        Surface(
            modifier = Modifier
                .fillMaxWidth()
                .graphicsLayer {
                    alpha = 1f - progress
                    scaleX = 1f - (0.035f * progress)
                    scaleY = 1f - (0.035f * progress)
                }
                .pointerInput(session.id, shattering) {
                    detectTapGestures(
                        onLongPress = {
                            if (!shattering) {
                                shattering = true
                                scope.launch {
                                    shatter.animateTo(
                                        targetValue = 1f,
                                        animationSpec = tween(620, easing = FastOutSlowInEasing)
                                    )
                                    onUnlock()
                                }
                            }
                        }
                    )
                },
            color = savedCardColor,
            shape = RoundedCornerShape(18.dp),
            shadowElevation = 10.dp,
            tonalElevation = 4.dp
        ) {
            Box(Modifier.fillMaxWidth()) {
                if (questionAnswered) {
                    Text(
                        "?",
                        modifier = Modifier
                            .align(Alignment.CenterEnd)
                            .padding(end = 18.dp),
                        fontSize = 104.sp,
                        lineHeight = 104.sp,
                        fontWeight = FontWeight.Black,
                        color = MaterialTheme.colorScheme.onTertiaryContainer.copy(alpha = 0.10f)
                    )
                }
                Column(Modifier.padding(horizontal = 14.dp, vertical = 12.dp)) {
                Text(
                    "📥 Saved search",
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Bold,
                    color = savedAccentColor
                )
                Text(
                    session.query,
                    fontSize = 18.sp,
                    fontWeight = FontWeight.Bold,
                    maxLines = 2,
                    overflow = TextOverflow.Ellipsis
                )
                Spacer(Modifier.height(5.dp))
                Text(
                    "${session.searchType} · $dateText",
                    fontSize = 11.sp,
                    color = savedDetailColor
                )
                if (session.metadataVersion >= 2 && session.stopped) {
                    Text(
                        savedSearchStoppedLabel(session),
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        color = savedAccentColor
                    )
                }
                Text(
                    "⏱ Search time: ${formatSearchDuration(session.durationMs)}",
                    fontSize = 11.sp,
                    color = savedDetailColor
                )
                Text(
                    "📚 Scope: $scopeText",
                    fontSize = 11.sp,
                    color = savedDetailColor
                )
                if (session.metadataVersion >= 2) {
                    Text(
                        "🧬 Semantic: ${if (session.semanticEnabled) "on" else "off"} · " +
                            "🎯 Accurate search: ${if (session.accurateSearchUsed) "used" else "not used"}",
                        fontSize = 11.sp,
                        color = savedDetailColor
                    )
                    Text(
                        savedSearchAnnLabel(session),
                        fontSize = 11.sp,
                        color = if (session.hnswEnabled || session.hnswUsed)
                            androidx.compose.ui.graphics.Color(0xFF2196F3) else savedDetailColor
                    )
                    if (session.timingSummary.isNotBlank()) {
                        Text(session.timingSummary, fontSize = 11.sp, color = savedDetailColor)
                    }
                    Text(
                        savedSearchRerankerLabel(session),
                        fontSize = 11.sp,
                        color = savedDetailColor
                    )
                    if (session.metadataVersion >= 3) {
                        Text(
                            savedSearchQuestionAwarenessLabel(session),
                            fontSize = 11.sp,
                            color = savedDetailColor
                        )
                        if (session.questionAwarenessEnabled && session.queryDetectedAsQuestion &&
                            session.questionAwarenessUsed && session.questionAwareQueries.isNotEmpty()) {
                            Text(
                                "Answer-oriented queries: ${session.questionAwareQueries.joinToString(" · ")}",
                                fontSize = 11.sp,
                                color = savedDetailColor,
                                maxLines = 4,
                                overflow = TextOverflow.Ellipsis
                            )
                        }
                    }
                } else {
                    Text(
                        "ℹ Detailed execution metadata unavailable (saved before 5.5.14)",
                        fontSize = 10.sp,
                        color = savedDetailColor.copy(alpha = 0.78f)
                    )
                }
                Text(
                    if (session.llmUsed)
                        "🧠 LLM: used${if (session.llmEngine.isNotBlank()) " · ${session.llmEngine}" else ""}"
                    else "🧠 LLM: not used",
                    fontSize = 11.sp,
                    color = savedAccentColor
                )
                Text(
                    "🧩 Expansion: $expansionMethod",
                    fontSize = 11.sp,
                    color = savedDetailColor
                )
                if (session.expansions.isNotEmpty()) {
                    Text(
                        "Expansion queries: ${session.expansions.joinToString(" · ")}",
                        fontSize = 11.sp,
                        color = savedDetailColor,
                        maxLines = 4,
                        overflow = TextOverflow.Ellipsis
                    )
                }
                if (session.metadataVersion >= 4) {
                    Text(
                        "🔗 Per-result query provenance: ${report.provenanceCount} / ${report.hitCount} results",
                        fontSize = 11.sp,
                        color = savedDetailColor
                    )
                }
                Spacer(Modifier.height(4.dp))
                Text(
                    "Long-press to break this card and start a new search",
                    fontSize = 10.sp,
                    color = savedDetailColor.copy(alpha = 0.72f)
                )
                }
            }
        }

        // Lightweight glass-shatter effect: translucent fragments burst away
        // from the card while the original card fades. This is purely visual
        // and does not wrap or intercept the result list below.
        if (progress > 0f) {
            val shards = listOf(
                Triple(-1f, -1f, -22f), Triple(-0.5f, -1f, 18f), Triple(0.2f, -1f, -14f), Triple(0.9f, -1f, 24f),
                Triple(-1f, -0.15f, 16f), Triple(-0.35f, -0.1f, -28f), Triple(0.35f, -0.05f, 22f), Triple(1f, -0.2f, -18f),
                Triple(-0.9f, 0.9f, -24f), Triple(-0.25f, 1f, 30f), Triple(0.35f, 0.95f, -20f), Triple(0.95f, 0.85f, 26f)
            )
            shards.forEachIndexed { index, (dx, dy, rotation) ->
                val shardWidth = if (index % 3 == 0) 54.dp else 42.dp
                val shardHeight = if (index % 2 == 0) 30.dp else 24.dp
                Box(
                    Modifier
                        .align(Alignment.Center)
                        .size(shardWidth, shardHeight)
                        .graphicsLayer {
                            translationX = dx * 145f * progress
                            translationY = dy * 105f * progress + (35f * progress * progress)
                            rotationZ = rotation * progress
                            alpha = (1f - progress).coerceIn(0f, 1f)
                            scaleX = 1f - (0.25f * progress)
                            scaleY = 1f - (0.25f * progress)
                        }
                        .background(
                            MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.48f),
                            RoundedCornerShape(5.dp)
                        )
                        .border(
                            1.dp,
                            MaterialTheme.colorScheme.onSurface.copy(alpha = 0.20f),
                            RoundedCornerShape(5.dp)
                        )
                )
            }
        }
    }
}

private data class SearchHit(
    val id: Long,
    val title: String,
    val relPath: String,
    val fileType: String,
    val snippet: String
)

/**
 * Action sheet shown on long-press of a search result. Offers:
 *   • Open in split view (then picks the partner)
 *   • Open externally
 *   • Share
 *   • Convert (auto-detects valid target types)
 *   • Open in graph
 */
@OptIn(androidx.compose.material3.ExperimentalMaterial3Api::class)
@Composable
private fun SearchResultActionSheet(
    hit: SearchHit,
    vm: AppViewModel,
    nav: NavController,
    onDismiss: () -> Unit,
    onPickSplitPair: () -> Unit,
    onPickConvert: () -> Unit
) {
    val ctx = androidx.compose.ui.platform.LocalContext.current
    androidx.compose.material3.ModalBottomSheet(onDismissRequest = onDismiss) {
        Column(Modifier.fillMaxWidth().padding(horizontal = 18.dp, vertical = 8.dp)) {
            Text(
                hit.title.ifBlank { hit.relPath },
                fontSize = 15.sp,
                fontWeight = FontWeight.SemiBold,
                maxLines = 2,
                overflow = TextOverflow.Ellipsis
            )
            Text(
                "Type: ${hit.fileType.uppercase()}",
                fontSize = 12.sp,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                modifier = Modifier.padding(top = 2.dp)
            )
            Spacer(Modifier.height(10.dp))
            // v5.4.132cc — In-article semantic search. Sets a pending
            // query, opens the reader, and the reader auto-triggers
            // the smart popup once the article's content is loaded.
            //
            // v5.4.135cc — Fixed: was calling vm.openSync(id) which
            // only loads the Note record — it does NOT set the active
            // tab, so ReaderScreen's LaunchedEffect(activeTab) never
            // fired for the new article and the popup never opened.
            // The primary-tap pattern (line 823-ish) uses openArticle,
            // which is the one that actually sets activeTab. Mirroring
            // that here fixes the "menu closes but nothing happens" bug.
            androidx.compose.material3.TextButton(
                onClick = {
                    onDismiss()
                    val rawQuery = vm.query.value.trim()
                    val q = rawQuery.removeSurrounding("\"").trim()
                    if (q.length >= 2) {
                        // v5.4.307cc — The semantic action must carry BOTH the
                        // popup request and the same pending highlight payload
                        // that a normal search-result tap uses. The readers
                        // build the smart-popup text from those highlighted
                        // ranges, so queuing only the popup query opened the
                        // article without anything for the popup to display.
                        val isPhrase = rawQuery.startsWith("\"") && rawQuery.endsWith("\"")
                        vm.setPendingHighlight(
                            rawQuery,
                            isPhrase = isPhrase,
                            snippet = hit.snippet
                        )
                        vm.markOpenedFromSearch()
                        vm.setPendingPopupQuery(q)
                    }
                    when (hit.fileType.lowercase()) {
                        "html", "htm", "mhtml", "mht" -> {
                            vm.openArticle(hit.id, hit.title, fileType = hit.fileType)
                            runCatching { nav.navigate("htmlReader/${hit.id}") }
                        }
                        "canvas" -> {
                            vm.openArticle(hit.id, hit.title, fileType = "canvas")
                            runCatching { nav.navigate("canvas/${hit.id}") }
                        }
                        "pdf" -> {
                            vm.openArticle(hit.id, hit.title, fileType = hit.fileType)
                            runCatching { nav.navigate("pdfReader/${hit.id}") }
                        }
                        else -> {
                            vm.openArticle(hit.id, hit.title)
                            runCatching { nav.navigate("reader") { launchSingleTop = true } }
                        }
                    }
                },
                modifier = Modifier.fillMaxWidth()
            ) { Text("\uD83E\uDDE0  Search in article (semantic)") }
            androidx.compose.material3.TextButton(
                onClick = onPickSplitPair,
                modifier = Modifier.fillMaxWidth()
            ) { Text("\uD83E\uDE9F  Open in split view") }
            androidx.compose.material3.TextButton(
                onClick = {
                    onDismiss()
                    val note = vm.openSync(hit.id)
                    val uri = note?.uri?.let { runCatching { android.net.Uri.parse(it) }.getOrNull() }
                    uri?.let {
                        runCatching {
                            ctx.startActivity(
                                android.content.Intent(android.content.Intent.ACTION_VIEW, it)
                                    .addFlags(android.content.Intent.FLAG_GRANT_READ_URI_PERMISSION)
                            )
                        }
                    }
                },
                modifier = Modifier.fillMaxWidth()
            ) { Text("\u2197  Open externally") }
            androidx.compose.material3.TextButton(
                onClick = {
                    onDismiss()
                    val note = vm.openSync(hit.id)
                    val uri = note?.uri?.let { runCatching { android.net.Uri.parse(it) }.getOrNull() }
                    uri?.let {
                        runCatching {
                            val mime = when (hit.fileType) {
                                "pdf" -> "application/pdf"
                                "mhtml", "html" -> "text/html"
                                else -> "text/markdown"
                            }
                            ctx.startActivity(android.content.Intent.createChooser(
                                android.content.Intent(android.content.Intent.ACTION_SEND)
                                    .setType(mime)
                                    .putExtra(android.content.Intent.EXTRA_STREAM, it)
                                    .addFlags(android.content.Intent.FLAG_GRANT_READ_URI_PERMISSION),
                                "Share file"
                            ))
                        }
                    }
                },
                modifier = Modifier.fillMaxWidth()
            ) { Text("\u2709\uFE0F  Share") }
            androidx.compose.material3.TextButton(
                onClick = onPickConvert,
                modifier = Modifier.fillMaxWidth()
            ) { Text("\uD83D\uDD04  Convert\u2026") }
            androidx.compose.material3.TextButton(
                onClick = {
                    onDismiss()
                    nav.navigate("graph") { launchSingleTop = true }
                },
                modifier = Modifier.fillMaxWidth()
            ) { Text("\uD83D\uDD78\uFE0F  Open in graph") }

            // v5.1.0 — Open in a new browser tab. For notes that have an
            // original online URL (HTML articles saved from the web), this
            // routes through the persistent multi-tab WebView so the user
            // can keep their current screen and have the article open in
            // the background. For MD / PDF notes without a URL, the option
            // is hidden — they have nothing meaningful to "open in browser".
            androidx.compose.material3.TextButton(
                onClick = {
                    val note = vm.openSync(hit.id)
                    val uri = note?.uri?.let { runCatching { android.net.Uri.parse(it) }.getOrNull() }
                    val urlStr = uri?.toString()
                    if (urlStr != null &&
                        (urlStr.startsWith("http://") || urlStr.startsWith("https://"))) {
                        vm.openInBrowser(urlStr, uri.host ?: "Link")
                    }
                    onDismiss()
                },
                modifier = Modifier.fillMaxWidth()
            ) { Text("\uD83E\uDE9F  Open in new browser tab") }
            Spacer(Modifier.height(16.dp))
        }
    }
}

/** After user picks "Open in split view", we list the other open tabs to pair with. */
@Composable
private fun SplitPartnerPickerDialog(
    hit: SearchHit,
    vm: AppViewModel,
    nav: NavController,
    onDismiss: () -> Unit
) {
    val tabs by vm.tabs.collectAsStateWithLifecycle()
    val partners = tabs.filter { it.id != hit.id }
    androidx.compose.material3.AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Open in split view with…") },
        text = {
            if (partners.isEmpty()) {
                Text(
                    "Open another file first, then come back here to pair them.",
                    fontSize = 13.sp
                )
            } else {
                Column {
                    partners.forEach { p ->
                        androidx.compose.material3.TextButton(
                            onClick = {
                                onDismiss()
                                nav.navigate(
                                    "splitReader/${hit.id}/${hit.fileType}/${p.id}/${p.fileType}"
                                )
                            },
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Text(
                                p.title.ifBlank { "Untitled" },
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis
                            )
                        }
                    }
                }
            }
        },
        confirmButton = {
            androidx.compose.material3.TextButton(onClick = onDismiss) { Text("Cancel") }
        }
    )
}

/**
 * Convert dialog — offers target file types based on the source. The actual
 * conversion logic lives on the VM (placeholder for v4.7). The UI is wired
 * end-to-end so the next iteration only needs to fill in the conversion bodies.
 */
@Composable
private fun ConvertTargetDialog(
    hit: SearchHit,
    vm: AppViewModel,
    onDismiss: () -> Unit
) {
    val ctx = androidx.compose.ui.platform.LocalContext.current
    val scope = androidx.compose.runtime.rememberCoroutineScope()
    // Available target types based on source. If the source is markdown, you
    // can go to HTML or PDF. From HTML/MHTML, you can go to Markdown or PDF.
    // From PDF, you can go to Markdown or HTML.
    val targets = when (hit.fileType) {
        "md" -> listOf("html" to "HTML (.html)", "pdf" to "PDF (.pdf)")
        "html", "mhtml" -> listOf("md" to "Markdown (.md)", "pdf" to "PDF (.pdf)")
        "pdf" -> listOf("md" to "Markdown (.md)", "html" to "HTML (.html)")
        else -> emptyList()
    }
    androidx.compose.material3.AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Convert to…") },
        text = {
            Column {
                Text(
                    "Pick a target format. The new file lands in your library and is automatically indexed.",
                    fontSize = 12.sp,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    modifier = Modifier.padding(bottom = 8.dp)
                )
                targets.forEach { (typeId, label) ->
                    androidx.compose.material3.TextButton(
                        onClick = {
                            onDismiss()
                            scope.launch {
                                val res = vm.convertNote(hit.id, hit.fileType, typeId)
                                val msg = when (res) {
                                    is com.tebogo.markvault.SaveResult.Ok -> {
                                        val relPath = if (res.subfolder.isBlank()) res.fileName
                                            else "${res.subfolder}/${res.fileName}"
                                        vm.indexNewFile(res.docUri, relPath)
                                        "\u2705 Saved: ${res.fileName}"
                                    }
                                    is com.tebogo.markvault.SaveResult.Error ->
                                        "\u26A0\uFE0F ${res.message}"
                                }
                                android.widget.Toast.makeText(
                                    ctx, msg, android.widget.Toast.LENGTH_LONG
                                ).show()
                            }
                        },
                        modifier = Modifier.fillMaxWidth()
                    ) { Text(label) }
                }
            }
        },
        confirmButton = {
            androidx.compose.material3.TextButton(onClick = onDismiss) { Text("Cancel") }
        }
    )
}

@Composable
private fun WebSearchPrompt(query: String, vm: AppViewModel) {
    val encQuery = remember(query) {
        runCatching { java.net.URLEncoder.encode(query, "UTF-8") }.getOrElse { query }
    }
    // v5.4.145cc — Check if web search buttons should be hidden
    
    // v5.4.147cc — Removed "Search on jw.org?" query preview section to save screen space
    // Users now see the floating "Search on jw.org" button instead at bottom of results
}

@Composable
private fun WebSearchButton(label: String, onClick: () -> Unit) {
    Surface(
        color = MaterialTheme.colorScheme.primary.copy(alpha = 0.18f),
        shape = RoundedCornerShape(8.dp),
        modifier = Modifier.fillMaxWidth().clickable(onClick = onClick)
    ) {
        Text(
            label,
            Modifier.padding(horizontal = 12.dp, vertical = 8.dp),
            fontWeight = FontWeight.Medium, fontSize = 12.sp
        )
    }
}

private fun highlightSnippet(s: String): AnnotatedString = buildAnnotatedString {
    val parts = s.split("\u27E6")
    parts.forEachIndexed { idx, part ->
        if (idx == 0) {
            append(part)
        } else {
            val end = part.indexOf('\u27E7')
            if (end >= 0) {
                // v4.14.0 — bold italic instead of yellow background.
                // Keeps matches visually prominent but doesn't make the list
                // look "ransom-note" busy. The yellow highlight stays in
                // articles (.md / .html / .pdf) where it makes sense.
                withStyle(
                    SpanStyle(
                        fontWeight = FontWeight.Bold,
                        fontStyle = androidx.compose.ui.text.font.FontStyle.Italic
                    )
                ) {
                    append(part.substring(0, end))
                }
                append(part.substring(end + 1))
            } else {
                append(part)
            }
        }
    }
}

/**
 * Highlight every occurrence of each search token inside [text] (case-insensitive).
 * Overlapping / adjacent matches are merged so we never produce nested or jagged spans.
 */
private fun highlightTerms(text: String, terms: List<String>): AnnotatedString {
    if (terms.isEmpty() || text.isEmpty()) return AnnotatedString(text)
    val lower = text.lowercase()
    // Collect every match range across every token
    val ranges = ArrayList<IntRange>()
    for (term in terms) {
        val needle = term.lowercase()
        if (needle.isEmpty()) continue
        var from = 0
        while (from <= lower.length - needle.length) {
            val found = lower.indexOf(needle, from)
            if (found < 0) break
            ranges.add(found until (found + needle.length))
            from = found + needle.length
        }
    }
    if (ranges.isEmpty()) return AnnotatedString(text)
    // Sort and merge overlapping/adjacent ranges into a clean span list
    ranges.sortBy { it.first }
    val merged = ArrayList<IntRange>()
    var cur = ranges[0]
    for (i in 1 until ranges.size) {
        val r = ranges[i]
        cur = if (r.first <= cur.last + 1) cur.first..maxOf(cur.last, r.last)
        else { merged.add(cur); r }
    }
    merged.add(cur)
    // Build the styled string in a single pass
    return buildAnnotatedString {
        var pos = 0
        // v4.14.0 — same bold-italic-not-yellow style as highlightSnippet.
        val emph = SpanStyle(
            fontWeight = FontWeight.Bold,
            fontStyle = androidx.compose.ui.text.font.FontStyle.Italic
        )
        for (r in merged) {
            if (r.first > pos) append(text.substring(pos, r.first))
            withStyle(emph) { append(text.substring(r.first, r.last + 1)) }
            pos = r.last + 1
        }
        if (pos < text.length) append(text.substring(pos))
    }
}

private fun savedSearchNoteCount(count: Int): String =
    if (count <= 0) "size unavailable" else java.text.NumberFormat.getIntegerInstance().format(count)

private fun savedSearchCompactCount(count: Int): String {
    if (count <= 0) return "scope"
    if (count < 1_000) return count.toString()
    val roundedThousands = ((count + 500) / 1_000).coerceAtLeast(1)
    return "${roundedThousands}K"
}

private fun savedSearchScopeLabel(session: com.tebogo.markvault.search.SavedSearchSession): String {
    if (session.metadataVersion < 2) {
        return if (session.dualMode) "Dual mode" else when (session.scope) {
            "first20k" -> "1st 20K"
            "second20k" -> "2nd scope"
            else -> "All notes"
        }
    }
    val scopeCount = savedSearchNoteCount(session.scopeNoteCount)
    return if (session.dualMode) {
        "Dual mode · all ${savedSearchNoteCount(session.totalNoteCount)} notes"
    } else when (session.scope) {
        "first20k" -> "1st 20K · $scopeCount notes"
        "second20k" -> "2nd ${savedSearchCompactCount(session.scopeNoteCount)} · $scopeCount notes"
        "all" -> "All notes · ${savedSearchNoteCount(session.totalNoteCount)} notes"
        else -> "${session.scope.ifBlank { "All notes" }} · $scopeCount notes"
    }
}

private fun savedSearchStoppedLabel(session: com.tebogo.markvault.search.SavedSearchSession): String {
    val pct = session.stoppedAtPercent?.let { "$it%" } ?: "unknown progress"
    val work = if (session.stoppedAtTotal > 0) {
        " (${java.text.NumberFormat.getIntegerInstance().format(session.stoppedAtDone)} / " +
            "${java.text.NumberFormat.getIntegerInstance().format(session.stoppedAtTotal)})"
    } else ""
    val finalization = if (session.rerankApplied) "found results reranked + saved" else "found results finalized + saved"
    return "⏹ Stopped at $pct$work · $finalization"
}

private fun savedSearchAnnLabel(session: com.tebogo.markvault.search.SavedSearchSession): String = when {
    session.hnswUsed -> "Blue HNSW: used"
    session.hnswEnabled -> "Blue HNSW: enabled · exact fallback"
    session.annUsed -> "⚡ Quick ANN: used"
    session.annEnabled -> "⚡ Quick ANN: enabled · not used (exact/fallback path)"
    else -> "⚡ Quick ANN: off"
}

private fun savedSearchRerankerLabel(session: com.tebogo.markvault.search.SavedSearchSession): String {
    val engine = session.rerankerEngine.takeIf { it.isNotBlank() }?.let { " · $it" }.orEmpty()
    return when {
        session.rerankApplied -> "↕ Reranker: applied$engine"
        session.rerankEnabled -> "↕ Reranker: enabled · not applied$engine"
        else -> "↕ Reranker: off"
    }
}

private fun savedSearchQuestionAwarenessLabel(session: com.tebogo.markvault.search.SavedSearchSession): String {
    val detected = if (session.queryDetectedAsQuestion) "question: yes" else "question: no"
    val type = session.questionType.takeIf { it.isNotBlank() }?.let { " · type: $it" }.orEmpty()
    val actuallyUsed = session.questionAwarenessEnabled &&
        session.queryDetectedAsQuestion && session.questionAwarenessUsed &&
        session.questionAwareQueries.isNotEmpty()
    return when {
        actuallyUsed -> "❓ Question Awareness: used · $detected$type"
        session.questionAwarenessEnabled -> "❓ Question Awareness: on · not used · $detected$type"
        else -> "❓ Question Awareness: off · $detected$type"
    }
}

private fun formatSearchDuration(ms: Long): String {
    val safe = ms.coerceAtLeast(0L)
    return when {
        safe < 1_000L -> "${safe} ms"
        safe < 60_000L -> {
            val seconds = safe / 1_000.0
            if (seconds < 10.0) String.format(java.util.Locale.getDefault(), "%.1f s", seconds)
            else "${safe / 1_000L} s"
        }
        else -> {
            val minutes = safe / 60_000L
            val seconds = (safe % 60_000L) / 1_000L
            "${minutes}m ${seconds}s"
        }
    }
}

/**
 * Format a recent-search timestamp as something like "Today 14:32",
 * "Yesterday 09:15", or "Mon 18 Nov · 11:48" for older entries. Mirrors the
 * style we use on Recent cards on Home so the search history reads consistently.
 */
private fun formatRecentTimestamp(ts: Long): String {
    if (ts <= 0L) return ""
    val now = System.currentTimeMillis()
    val diff = now - ts
    val cal = java.util.Calendar.getInstance().apply { timeInMillis = ts }
    val today = java.util.Calendar.getInstance()
    val sameDay = cal.get(java.util.Calendar.YEAR) == today.get(java.util.Calendar.YEAR) &&
        cal.get(java.util.Calendar.DAY_OF_YEAR) == today.get(java.util.Calendar.DAY_OF_YEAR)
    val timeFmt = java.text.SimpleDateFormat("HH:mm", java.util.Locale.getDefault())
    val time = timeFmt.format(java.util.Date(ts))
    if (sameDay) return "Today · $time"
    val yesterday = java.util.Calendar.getInstance().apply {
        timeInMillis = now
        add(java.util.Calendar.DAY_OF_YEAR, -1)
    }
    val isYesterday = cal.get(java.util.Calendar.YEAR) == yesterday.get(java.util.Calendar.YEAR) &&
        cal.get(java.util.Calendar.DAY_OF_YEAR) == yesterday.get(java.util.Calendar.DAY_OF_YEAR)
    if (isYesterday) return "Yesterday · $time"
    val dateFmt = if (diff < 365L * 24 * 60 * 60 * 1000)
        java.text.SimpleDateFormat("EEE d MMM", java.util.Locale.getDefault())
    else
        java.text.SimpleDateFormat("d MMM yyyy", java.util.Locale.getDefault())
    return "${dateFmt.format(java.util.Date(ts))} · $time"
}

/**
 * Clean a stored title for display. Strips:
 *   • YAML frontmatter remnants
 *   • Markdown image syntax `![alt](url)`
 *   • Markdown link syntax `[text](url)` → keeps just `text`
 *   • Obsidian wikilinks `[[Target|Alias]]` → keeps alias if present, else target
 *   • Heading hashes, bold/italic markers
 *
 * This is the same idea as HomeScreen.stripMarkdownNoise but limited to one
 * line and kept private to this file so I don't break HomeScreen's existing
 * cleanup pipeline. Both functions can diverge if needed.
 *
 * The reason this matters for search results: the indexer captures the first
 * `# Heading` line verbatim, including any markdown link syntax. So a heading
 * like `# [Am I a Perfectionist? | Young People Ask](https://.../teenager/...)`
 * gets stored with the URL inside. When displayed on one truncated line, the
 * URL eats the visible space and any highlighted match in the URL is hidden
 * past the ellipsis. Stripping the link wrapper at display time keeps the
 * visible text clean and lets the highlighter mark matches in the part the
 * user can actually see.
 */
private fun cleanTitleForDisplay(raw: String): String {
    var t = raw.trim()
    if (t.startsWith("---")) {
        val end = t.indexOf("---", 3)
        if (end > 0) t = t.substring(end + 3).trim()
    }
    t = t
        .replace(Regex("^#+\\s+"), "")
        .replace(Regex("!\\[[^\\]]*]\\([^)]*\\)"), "")
        .replace(Regex("\\[([^\\]]+)]\\([^)]*\\)"), "$1")
        .replace(Regex("\\[\\[([^\\[\\]|#^\\n]+)(?:#[^\\[\\]|\\n]*)?(?:\\^[^\\[\\]|\\n]*)?(?:\\|([^\\[\\]\\n]+))?]]")) { m ->
            m.groupValues[2].ifBlank { m.groupValues[1] }
        }
        .replace(Regex("\\*\\*([^*]+)\\*\\*"), "$1")
        .replace(Regex("__([^_]+)__"), "$1")
        .replace(Regex("`([^`]+)`"), "$1")
        .replace(Regex("\\s+"), " ")
        .trim()
    return t.ifBlank { raw.trim() }
}

/**
 * Given a long text and a list of search terms, return a ~70-character window
 * centred on the first occurrence of any term — with "…" prefixes/suffixes
 * when the window doesn't span the full text. Returns null if no term is
 * found.
 *
 * Used as a fallback "found in URL" hint when the cleaned title and path
 * don't contain a visible match but the original raw title did (typically
 * inside a markdown link URL that got stripped).
 */
private fun matchContextSnippet(haystack: String, needles: List<String>): String? {
    if (haystack.isEmpty() || needles.isEmpty()) return null
    val lower = haystack.lowercase()
    var firstIdx = -1
    var firstLen = 0
    for (n in needles) {
        val needle = n.lowercase()
        if (needle.isEmpty()) continue
        val idx = lower.indexOf(needle)
        if (idx >= 0 && (firstIdx < 0 || idx < firstIdx)) {
            firstIdx = idx
            firstLen = needle.length
        }
    }
    if (firstIdx < 0) return null
    val window = 70
    val before = (window - firstLen) / 2
    val start = (firstIdx - before).coerceAtLeast(0)
    val end = (firstIdx + firstLen + before).coerceAtMost(haystack.length)
    val prefix = if (start > 0) "… " else ""
    val suffix = if (end < haystack.length) " …" else ""
    return prefix + haystack.substring(start, end) + suffix
}

/**
 * v4.17.0 — Stopword list used by the multi-word match filter.
 *
 * Words here don't count toward the "result must contain at least 2 meaningful
 * matches" threshold. Without this, a query like
 *   "what happened to the holy ones"
 * would treat "what", "the", "to" as searchable content and skew the count.
 *
 * Mirrors the JS-side FALLBACK_STOPWORDS in render.js, extended with the
 * common interrogative pronouns ("what", "who", "when", etc.) that almost
 * always appear in natural-language questions but never carry the user's
 * actual intent.
 */
private val SEARCH_RESULT_STOPWORDS = setOf(
    // Articles & basic prepositions
    "the", "a", "an", "of", "to", "in", "on", "for", "at", "by",
    "with", "from", "as", "into", "onto", "upon", "about", "between", "among",
    // Conjunctions
    "and", "or", "but", "if", "so", "than", "then", "because",
    // Be / have / do auxiliaries
    "is", "are", "was", "were", "be", "been", "being",
    "do", "does", "did", "doing", "done",
    "has", "have", "had", "having",
    "will", "would", "shall", "should", "can", "could", "may", "might", "must",
    // Pronouns
    "it", "its", "this", "that", "these", "those",
    "i", "me", "my", "we", "us", "our",
    "you", "your", "he", "him", "his", "she", "her", "they", "them", "their",
    // Common interrogatives
    "what", "who", "whom", "whose", "when", "where", "why", "how", "which"
)

/**
 * v4.24.0 — Relevance percentage chip shown at the top-right of each
 * search result. Color-codes the match strength so the user gets a
 * quick visual read:
 *
 *   ≥75% — strong match, green tint
 *   55–74% — medium, blue tint (M3 primary container)
 *   <55% — weak, neutral surfaceVariant
 *
 * The exact thresholds are tuned for BGE-large cosine values, which
 * typically land in [0.40, 0.85] for related content. With the reranker
 * on, the score is a sigmoid-of-logit so genuine matches push much
 * higher (often 0.90+).
 */
@androidx.compose.runtime.Composable
private fun ChatRelevanceChip(score: Float) {
    val pct = (score.coerceIn(0f, 1f) * 100).toInt()
    val bg = when {
        pct >= 75 -> androidx.compose.ui.graphics.Color(0xFF1F8B3F).copy(alpha = 0.22f)
        pct >= 55 -> androidx.compose.material3.MaterialTheme.colorScheme.primaryContainer
        else -> androidx.compose.material3.MaterialTheme.colorScheme.surfaceVariant
    }
    val fg = when {
        pct >= 75 -> androidx.compose.ui.graphics.Color(0xFF155724)
        pct >= 55 -> androidx.compose.material3.MaterialTheme.colorScheme.onPrimaryContainer
        else -> androidx.compose.material3.MaterialTheme.colorScheme.onSurfaceVariant
    }
    androidx.compose.foundation.layout.Box(
        modifier = androidx.compose.ui.Modifier
            .background(bg, androidx.compose.foundation.shape.RoundedCornerShape(8.dp))
            .padding(horizontal = 8.dp, vertical = 3.dp)
    ) {
        Text(
            "$pct%",
            fontSize = 11.sp,
            fontWeight = FontWeight.Bold,
            color = fg
        )
    }
}

/**
 * v5.4.76cc — Small lavender chip painted on a search result row when
 * the row was reachable *only* through an LLM-paraphrased sub-query,
 * never through the user's original tokens or the Kotlin synonym
 * expander. Matches the same lavender used for
 * `.llm-hit` inside articles and for the softer snippet overlay on
 * this screen, so the visual trace is coherent from result → snippet →
 * article body.
 */
@androidx.compose.runtime.Composable
private fun AiTraceChip() {
    val bg = androidx.compose.ui.graphics.Color(0xFFA78BFA).copy(alpha = 0.22f)
    val fg = androidx.compose.ui.graphics.Color(0xFF6D28D9)
    androidx.compose.foundation.layout.Box(
        modifier = androidx.compose.ui.Modifier
            .background(bg, androidx.compose.foundation.shape.RoundedCornerShape(8.dp))
            .padding(horizontal = 8.dp, vertical = 3.dp)
    ) {
        Text(
            "\u2728 AI",
            fontSize = 11.sp,
            fontWeight = FontWeight.Bold,
            color = fg
        )
    }
}

private fun searchEmbeddingModelLabel(model: ModelDescriptor): String = when (model.id) {
    "mediapipe-use-lite-v1" -> "Fast Thinker"
    "onnx-minilm-l6-v2" -> "Medium Thinker"
    "onnx-bge-base-en-v15" -> "Deep Thinking"
    "onnx-bge-large-en-v15" -> "Deep Research"
    else -> model.displayName
}

/**
 * Full model label for the Search UI. It scrolls only when the text is wider
 * than its container, and the marquee is removed whenever the Search screen's
 * lifecycle is below STARTED so no background animation can consume battery.
 */
@OptIn(ExperimentalFoundationApi::class)
@Composable
private fun LifecycleAwareMarqueeText(
    text: String,
    modifier: Modifier = Modifier,
    fontSize: androidx.compose.ui.unit.TextUnit = androidx.compose.ui.unit.TextUnit.Unspecified,
    fontWeight: FontWeight? = null,
    color: Color = Color.Unspecified
) {
    val lifecycleOwner = LocalLifecycleOwner.current
    var marqueeEnabled by remember(lifecycleOwner) {
        mutableStateOf(lifecycleOwner.lifecycle.currentState.isAtLeast(Lifecycle.State.STARTED))
    }

    LaunchedEffect(lifecycleOwner) {
        lifecycleOwner.lifecycle.repeatOnLifecycle(Lifecycle.State.STARTED) {
            marqueeEnabled = true
            try {
                kotlinx.coroutines.awaitCancellation()
            } finally {
                marqueeEnabled = false
            }
        }
    }

    Text(
        text = text,
        modifier = modifier.then(
            if (marqueeEnabled) Modifier.basicMarquee(iterations = Int.MAX_VALUE) else Modifier
        ),
        maxLines = 1,
        softWrap = false,
        overflow = TextOverflow.Clip,
        fontSize = fontSize,
        fontWeight = fontWeight,
        color = color
    )
}

/**
 * v5.4.79cc — The pumping-brain toggle sitting at the right edge of the
 * Search screen's search bar. Serves two roles simultaneously:
 *
 *   1. **Ambient status indicator.** When [active] is true and the LLM
 *      multi-query path will fire on the next submit, the brain pulses
 *      (scales 1.0 ↔ 1.22 on a ~700 ms loop) — a visual "the AI is
 *      awake and about to think about this" signal. When [active] is
 *      false, the brain sits static and dimmed to about 40% alpha.
 *
 *   2. **In-line toggle.** Tapping calls [onToggle], which flips
 *      [AppViewModel.aiLlmSearchEnabled]. This is the *same*
 *      preference the Settings-screen switch writes, so the two
 *      surfaces stay coherent — flipping the Settings switch will
 *      update the brain immediately, and vice versa.
 *
 * The brain is rendered as the unicode emoji "🧠" so we avoid pulling
 * in an icon-font asset just for one glyph. The pulse is implemented
 * via [androidx.compose.animation.core.rememberInfiniteTransition] +
 * [androidx.compose.animation.core.animateFloat], gated on [active] so
 * it fully stops when off (no CPU cost while dim).
 */
@androidx.compose.runtime.Composable
private fun PumpingBrainToggle(
    active: Boolean,
    onToggle: () -> Unit
) {
    // v5.4.81cc — Manual per-frame pulse instead of
    // `rememberInfiniteTransition` / `animateFloat`. The infinite
    // transition variant in v5.4.79cc–v5.4.80cc lived inside the
    // OutlinedTextField's `trailingIcon` slot, which recomposes on
    // every keystroke while typing. That combination surfaces enough
    // edge cases across Compose versions (animation reset on
    // recomposition, reversed-repeat with initialValue==targetValue,
    // subcomposition disposal timing) that it was the leading
    // suspect for the "app crashes on typing" report. Rewriting the
    // pulse as `LaunchedEffect(active) { while (isActive) withFrameNanos {…} }`
    // sidesteps all of that: the effect is keyed on `active` so it
    // starts once when the toggle turns on and cancels cleanly when
    // the toggle turns off or the composable leaves the composition;
    // typing-time recompositions leave the effect alone.
    val lifecycleOwner = LocalLifecycleOwner.current
    var pulseHigh by androidx.compose.runtime.remember(active) {
        androidx.compose.runtime.mutableStateOf(false)
    }
    androidx.compose.runtime.LaunchedEffect(active, lifecycleOwner) {
        if (!active) {
            pulseHigh = false
            return@LaunchedEffect
        }
        lifecycleOwner.lifecycle.repeatOnLifecycle(Lifecycle.State.STARTED) {
            while (isActive) {
                pulseHigh = !pulseHigh
                kotlinx.coroutines.delay(900L)
            }
        }
    }
    // v5.4.365cc — Preserve the awake-brain pulse without a full-time
    // withFrameNanos loop. The animation only renders for a short transition.
    val scale by animateFloatAsState(
        targetValue = if (active && pulseHigh) 1.18f else 1f,
        animationSpec = tween(220, easing = FastOutSlowInEasing),
        label = "brain-low-power-pulse"
    )
    IconButton(
        onClick = onToggle,
        modifier = Modifier
            .size(44.dp)
            .graphicsLayer(
                scaleX = scale,
                scaleY = scale,
                alpha = if (active) 1f else 0.40f
            )
    ) {
        Text(
            text = "\uD83E\uDDE0",  // 🧠 brain emoji
            fontSize = 24.sp
        )
    }
}

/**
 * v4.24.0 — Phrase-level snippet highlighting.
 *
 * Splits text into sentences and highlights ONLY sentences that contain
 * 2+ distinct query terms. Sentences with 1 incidental match get no
 * highlight at all. This is the opposite of the previous per-word
 * highlighter: previously every "the" and "was" lit up yellow, which
 * made truly irrelevant results visually indistinguishable from
 * genuinely-relevant ones.
 *
 * Within highlighted sentences, the matched terms themselves get a
 * stronger bold-italic style so the user can still see what matched
 * inside the broader context.
 *
 * v5.4.133cc — AI (LLM) sentence-level highlighting.
 *
 * Previously the LLM/AI highlighting painted only individual matched
 * words in lavender, scattering isolated word highlights across the
 * snippet — which looked like random noise and made the AI signal hard
 * to read. The fix mirrors the primary-term logic: if a sentence
 * contains at least one LLM paraphrase term, the WHOLE sentence gets a
 * lavender background. Individual bold-italic marks are still drawn
 * inside the sentence so the exact matching phrase is obvious within
 * the broader highlighted context. Sentences with no LLM term get no
 * AI highlight at all — no word-by-word scatter.
 *
 * Combined sentences (primary 2+ terms AND an LLM term) receive the
 * primary yellow background; the yellow signal is dominant.
 */
@androidx.compose.runtime.Composable
private fun highlightSentences(
    text: String,
    terms: List<String>,
    llmTerms: List<String> = emptyList()
): androidx.compose.ui.text.AnnotatedString {
    val highlightBg = androidx.compose.material3.MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.55f)
    return remember(text, terms, llmTerms, highlightBg) {
        buildHighlightedSentences(text, terms, llmTerms, highlightBg)
    }
}

private fun buildHighlightedSentences(
    text: String,
    terms: List<String>,
    llmTerms: List<String>,
    highlightBg: androidx.compose.ui.graphics.Color
): androidx.compose.ui.text.AnnotatedString {
    val termsLower = terms.map { it.lowercase() }
        .filter { it.length >= 3 }   // skip stopword-sized noise
        .distinct()
    // v5.4.76cc — LLM paraphrase terms get their own filtered/lowered
    // list, applied *in addition to* the primary term highlighting.
    // Longest-first so a paraphrase like "friendship with God" wins
    // over "friendship" when both are candidates for wrapping.
    val llmTermsLower = llmTerms.map { it.lowercase().trim() }
        .filter { it.length >= 3 }
        .distinct()
        .sortedByDescending { it.length }

    if (termsLower.isEmpty() && llmTermsLower.isEmpty()) {
        return androidx.compose.ui.text.AnnotatedString(text)
    }

    val llmHighlightBg = androidx.compose.ui.graphics.Color(0xFFA78BFA).copy(alpha = 0.32f)

    return androidx.compose.ui.text.buildAnnotatedString {
        // Sentence splitter — punctuation followed by whitespace. Keeps
        // the punctuation with the preceding sentence (lookbehind). Also
        // splits on newline boundaries because markdown snippets often
        // come back as separate lines without terminal punctuation.
        val parts = text.split(Regex("(?<=[.!?])\\s+|\\n+"))
        for ((idx, raw) in parts.withIndex()) {
            val sentence = raw
            val lower = sentence.lowercase()
            val distinctMatches = termsLower.count { it in lower }
            // v5.4.133cc — sentence-level AI match: does this sentence
            // contain at least one LLM paraphrase term? If yes, the
            // whole sentence is a relevant AI-surfaced statement and
            // should be highlighted as a unit, not word-by-word.
            val hasLlmMatch = llmTermsLower.any { it in lower }

            when {
                distinctMatches >= 2 -> {
                    // Primary phrase match — yellow background covers the
                    // whole sentence; yellow is the dominant signal even
                    // when an LLM term also appears. Bold-italic the
                    // matched terms inside it; LLM terms get no extra
                    // decoration on top of yellow.
                    withStyle(
                        androidx.compose.ui.text.SpanStyle(background = highlightBg)
                    ) {
                        appendWithTermStyle(sentence, termsLower, llmTermsLower, androidx.compose.ui.graphics.Color.Transparent)
                    }
                }
                hasLlmMatch -> {
                    // v5.4.133cc — AI sentence match: whole sentence gets
                    // lavender background. Within it, bold-italic the LLM
                    // terms so the user can see exactly what phrase the AI
                    // matched, inside the broader highlighted context.
                    // No more scattered per-word lavender blobs.
                    withStyle(
                        androidx.compose.ui.text.SpanStyle(background = llmHighlightBg)
                    ) {
                        appendWithTermStyle(sentence, emptyList(), llmTermsLower, androidx.compose.ui.graphics.Color.Transparent)
                    }
                }
                else -> {
                    // No match of any kind — plain text, no highlight.
                    append(sentence)
                }
            }
            if (idx < parts.size - 1) append(" ")
        }
    }
}

/**
 * Append [text] to the builder, with each occurrence of any term in
 * [termsLower] rendered as bold-italic. Used inside [highlightSentences]
 * for matched sentences so the matched terms stand out within the
 * highlighted background.
 *
 * v5.4.76cc — Also paints each occurrence of any [llmTermsLower] entry
 * with a softer lavender background so LLM-surfaced words are
 * visually distinct from both plain text and the primary
 * yellow-highlighted terms. LLM background is only applied when the
 * span is not already part of a bold-italic primary-term match — a
 * word never wears both stripes at once, keeping the yellow primary
 * signal dominant when both would apply.
 */
private fun androidx.compose.ui.text.AnnotatedString.Builder.appendWithTermStyle(
    text: String,
    termsLower: List<String>,
    llmTermsLower: List<String> = emptyList(),
    llmBg: androidx.compose.ui.graphics.Color =
        androidx.compose.ui.graphics.Color.Transparent
) {
    val lower = text.lowercase()
    var i = 0
    while (i < text.length) {
        // Find the earliest primary-term match at position i or later.
        var bestStart = text.length
        var bestEnd = text.length
        var bestKind = 0  // 0=none, 1=primary term, 2=llm term
        for (term in termsLower) {
            val idx = lower.indexOf(term, i)
            if (idx >= 0 && idx < bestStart) {
                bestStart = idx
                bestEnd = idx + term.length
                bestKind = 1
            }
        }
        // If we found no primary match, look for the earliest LLM term
        // match instead. Primary wins on ties in position because a
        // yellow "term-hit" is a stronger signal than a lavender
        // "llm-hit".
        if (bestKind == 0 && llmTermsLower.isNotEmpty()) {
            for (term in llmTermsLower) {
                val idx = lower.indexOf(term, i)
                if (idx >= 0 && idx < bestStart) {
                    bestStart = idx
                    bestEnd = idx + term.length
                    bestKind = 2
                }
            }
        }
        if (bestStart >= text.length) {
            append(text.substring(i))
            return
        }
        if (bestStart > i) append(text.substring(i, bestStart))
        if (bestKind == 2) {
            // v5.4.133cc — LLM paraphrase match inside a sentence.
            // When llmBg is Transparent the sentence already has a
            // lavender background (sentence-level AI highlight), so we
            // use bold-italic to mark the matched phrase within it —
            // consistent with how primary terms are marked within their
            // yellow sentence. When llmBg is opaque we are in a
            // non-sentence-highlighted path (legacy fallback) and paint
            // the per-word background as before.
            if (llmBg == androidx.compose.ui.graphics.Color.Transparent) {
                withStyle(
                    androidx.compose.ui.text.SpanStyle(
                        fontWeight = FontWeight.Bold,
                        fontStyle = androidx.compose.ui.text.font.FontStyle.Italic
                    )
                ) {
                    append(text.substring(bestStart, bestEnd))
                }
            } else {
                withStyle(
                    androidx.compose.ui.text.SpanStyle(background = llmBg)
                ) {
                    append(text.substring(bestStart, bestEnd))
                }
            }
        } else {
            withStyle(
                androidx.compose.ui.text.SpanStyle(
                    fontWeight = FontWeight.Bold,
                    fontStyle = androidx.compose.ui.text.font.FontStyle.Italic
                )
            ) {
                append(text.substring(bestStart, bestEnd))
            }
        }
        i = bestEnd
    }
}

/**
 * v5.4.271cc — Manual rerank banner.
 *
 * A prominent button placed at the top of the results list (above the
 * long-press hint, below the WebSearchPrompt) inviting the user to
 * apply the SAME cross-encoder rerank to the currently displayed results.
 *
 * The idle label is intentionally user-facing rather than technical:
 *   • Idle    — "Not satisfied with results, click here!!" (tappable)
 *   • Working — "🔄 Reranking results…"                  (shows spinner,
 *                                                         tap disabled)
 *
 * The attention pulse is deliberately FINITE (three pulses when the banner
 * appears), rather than an infinite transition. This keeps the requested
 * animation without introducing a permanent foreground battery drain.
 * Visibility and rerank behaviour remain controlled by the existing caller.
 */
@androidx.compose.runtime.Composable
private fun ManualRerankBanner(
    inProgress: Boolean,
    onTap: () -> Unit
) {
    val attentionPulse = remember { Animatable(1f) }

    LaunchedEffect(inProgress) {
        attentionPulse.snapTo(1f)
        if (!inProgress) {
            repeat(3) {
                attentionPulse.animateTo(
                    1.025f,
                    animationSpec = tween(durationMillis = 320)
                )
                attentionPulse.animateTo(
                    1f,
                    animationSpec = tween(durationMillis = 320)
                )
            }
        }
    }

    androidx.compose.material3.Surface(
        color = androidx.compose.material3.MaterialTheme.colorScheme.primaryContainer,
        shape = androidx.compose.foundation.shape.RoundedCornerShape(12.dp),
        tonalElevation = 2.dp,
        modifier = androidx.compose.ui.Modifier
            .fillMaxWidth()
            .padding(horizontal = 14.dp, vertical = 6.dp)
            .graphicsLayer {
                scaleX = attentionPulse.value
                scaleY = attentionPulse.value
            }
            .clickable(enabled = !inProgress) { onTap() }
    ) {
        androidx.compose.foundation.layout.Row(
            modifier = androidx.compose.ui.Modifier
                .fillMaxWidth()
                .padding(horizontal = 14.dp, vertical = 10.dp),
            verticalAlignment = androidx.compose.ui.Alignment.CenterVertically
        ) {
            androidx.compose.foundation.layout.Column(
                modifier = androidx.compose.ui.Modifier.weight(1f)
            ) {
                Text(
                    text = if (inProgress)
                        "\uD83D\uDD04  Reranking results\u2026"
                    else
                        "Not satisfied with results, click here!!",
                    fontSize = 13.sp,
                    fontWeight = androidx.compose.ui.text.font.FontWeight.Bold,
                    color = androidx.compose.material3.MaterialTheme.colorScheme.onPrimaryContainer
                )
                Text(
                    text = if (inProgress)
                        "Cross-encoder is scoring the top candidates."
                    else
                        "Re-order the top 8 using the cross-encoder. Tap to apply.",
                    fontSize = 11.sp,
                    color = androidx.compose.material3.MaterialTheme.colorScheme.onPrimaryContainer
                        .copy(alpha = 0.75f),
                    lineHeight = 14.sp
                )
            }
            androidx.compose.foundation.layout.Spacer(
                androidx.compose.ui.Modifier.width(10.dp)
            )
            if (inProgress) {
                androidx.compose.material3.CircularProgressIndicator(
                    modifier = androidx.compose.ui.Modifier.size(20.dp),
                    strokeWidth = 2.dp,
                    color = androidx.compose.material3.MaterialTheme.colorScheme.onPrimaryContainer
                )
            } else {
                Text(
                    "\u27A4",
                    fontSize = 18.sp,
                    fontWeight = androidx.compose.ui.text.font.FontWeight.Bold,
                    color = androidx.compose.material3.MaterialTheme.colorScheme.onPrimaryContainer
                )
            }
        }
    }
}

/**
 * v5.4.30 — Persistent recent-searches panel shown at tablet width in
 * SearchScreen's left column. Uses only existing state (vm.recentSearches
 * + vm.query) so it's low-risk: tapping a row sets the search bar's text
 * and the main pipeline reacts as normal.
 *
 * Recent searches are de-duplicated by query string so a query that hit
 * five different notes shows as one row, ordered newest-first.
 */
@androidx.compose.runtime.Composable
private fun SearchTabletRecentsPanel(
    vm: com.tebogo.markvault.AppViewModel,
    recentSearches: List<com.tebogo.markvault.RecentSearch>,
    modifier: Modifier = Modifier
) {
    val uniqueSearches = androidx.compose.runtime.remember(recentSearches) {
        val seen = linkedSetOf<String>()
        recentSearches.filter { rs -> seen.add(rs.query.lowercase()) }
    }
    Column(
        modifier = modifier
            .background(MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.25f))
            .padding(14.dp)
    ) {
        Text(
            "\uD83D\uDD53 Recent searches",
            fontSize = 15.sp,
            fontWeight = FontWeight.Bold,
            color = MaterialTheme.colorScheme.onSurface
        )
        Spacer(Modifier.height(4.dp))
        Text(
            if (uniqueSearches.isEmpty())
                "None yet. Recent searches will show here as you use them."
            else
                "${uniqueSearches.size} \u00B7 tap to re-run",
            fontSize = 11.sp,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
            lineHeight = 15.sp
        )
        Spacer(Modifier.height(12.dp))
        if (uniqueSearches.isNotEmpty()) {
            LazyColumn(Modifier.weight(1f).fillMaxWidth()) {
                items(uniqueSearches, key = { "${it.query}-${it.ts}" }) { rs ->
                    Surface(
                        color = androidx.compose.ui.graphics.Color.Transparent,
                        shape = RoundedCornerShape(8.dp),
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(vertical = 2.dp)
                            .clickable { vm.query.value = rs.query }
                    ) {
                        Column(Modifier.padding(horizontal = 10.dp, vertical = 8.dp)) {
                            Text(
                                rs.query,
                                fontSize = 13.sp,
                                color = MaterialTheme.colorScheme.onSurface,
                                maxLines = 2,
                                overflow = TextOverflow.Ellipsis
                            )
                            if (rs.durationMs > 0L) {
                                Text(
                                    "Search took ${formatSearchDuration(rs.durationMs)}",
                                    fontSize = 10.sp,
                                    color = MaterialTheme.colorScheme.primary,
                                    maxLines = 1
                                )
                            }
                        }
                    }
                }
            }
        }
    }
}

/**
 * v5.4.169cc — Custom 3D-styled search-mode toggle, replacing the stock
 * Material3 SegmentedButton (which only exposes flat color slots — no
 * gradient or shadow customization surface, so it can't produce genuine
 * depth). "Shallow search" = SearchMode.TITLES (searches only note
 * titles — less data scanned, faster, hence "shallow"). "Deep search" =
 * SearchMode.CONTENT (searches full note content — hence "deep"). This
 * is purely a relabeling of the existing two modes; the SearchMode enum
 * and all underlying search logic are completely unchanged.
 *
 * Each segment renders as a glossy "raised button": a two-stop vertical
 * gradient (bright top edge catching light, darker toward the bottom),
 * a lifted drop shadow, and a thin light-catching top border — all
 * brighter and more saturated on the selected segment than the
 * unselected one, per the request that "the selected one must ...
 * be brighter."
 *
 * The "must animate" part plays as a brief pop/bounce exactly ONCE when
 * a segment BECOMES selected, then settles to a static brighter state —
 * it does not loop or re-trigger while simply staying selected. This is
 * a deliberate choice: v5.4.168cc just fixed three always-on
 * rememberInfiniteTransition animations that ran continuously and
 * measurably drained battery; introducing a fourth one here to satisfy
 * "must animate" would undo that fix for the price of this one control.
 * A transition-triggered animation (via animateColorAsState / a
 * one-shot Animatable spring, both of which settle and stop requesting
 * frames) delivers the same felt "it animates" moment without an
 * ongoing cost.
 */
@Composable
private fun ShallowDeepToggle(
    mode: SearchMode,
    onModeChange: (SearchMode) -> Unit,
    modifier: Modifier = Modifier
) {
    val uiAnim = UiAnim.prefs
    Row(
        modifier
            .clip(RoundedCornerShape(14.dp))
            .background(
                Brush.verticalGradient(
                    listOf(
                        MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.55f),
                        MaterialTheme.colorScheme.surface.copy(alpha = 0.85f)
                    )
                )
            )
            .border(
                width = 1.dp,
                color = MaterialTheme.colorScheme.outline.copy(alpha = 0.4f),
                shape = RoundedCornerShape(14.dp)
            )
            .padding(4.dp)
    ) {
        ToggleSegment(
            label = "\uD83D\uDCD1 Shallow search",
            selected = mode == SearchMode.TITLES,
            onClick = { onModeChange(SearchMode.TITLES) },
            uiAnim = uiAnim,
            modifier = Modifier.weight(1f)
        )
        Spacer(Modifier.width(4.dp))
        ToggleSegment(
            label = "\uD83D\uDD0E Deep search",
            selected = mode == SearchMode.CONTENT,
            onClick = { onModeChange(SearchMode.CONTENT) },
            uiAnim = uiAnim,
            modifier = Modifier.weight(1f)
        )
    }
}

@Composable
private fun ToggleSegment(
    label: String,
    selected: Boolean,
    onClick: () -> Unit,
    uiAnim: UiAnimPrefs,
    modifier: Modifier = Modifier
) {
    // One-time pop when this segment BECOMES selected — see the doc
    // comment on ShallowDeepToggle above for why this is transition-
    // triggered rather than a continuous loop.
    val popScale = remember { Animatable(1f) }
    LaunchedEffect(selected) {
        if (selected && uiAnim.enabled) {
            popScale.snapTo(0.92f)
            popScale.animateTo(
                targetValue = 1f,
                animationSpec = spring(
                    dampingRatio = Spring.DampingRatioMediumBouncy,
                    stiffness = Spring.StiffnessMedium
                )
            )
        } else {
            popScale.snapTo(1f)
        }
    }
    val fadeMs = uiAnim.scaledDurationMs(220)
    val bgTop by animateColorAsState(
        targetValue = if (selected) MaterialTheme.colorScheme.primary.copy(alpha = 0.95f)
            else MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f),
        animationSpec = tween(fadeMs),
        label = "toggleBgTop"
    )
    val bgBottom by animateColorAsState(
        targetValue = if (selected) MaterialTheme.colorScheme.primary.copy(alpha = 0.65f)
            else MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.25f),
        animationSpec = tween(fadeMs),
        label = "toggleBgBottom"
    )
    val textColor by animateColorAsState(
        targetValue = if (selected) MaterialTheme.colorScheme.onPrimary
            else MaterialTheme.colorScheme.onSurfaceVariant,
        animationSpec = tween(fadeMs),
        label = "toggleText"
    )
    Box(
        modifier
            .graphicsLayer { scaleX = popScale.value; scaleY = popScale.value }
            .then(
                if (selected) Modifier.shadow(6.dp, RoundedCornerShape(10.dp), clip = false)
                else Modifier
            )
            .clip(RoundedCornerShape(10.dp))
            .background(Brush.verticalGradient(listOf(bgTop, bgBottom)))
            .then(
                if (selected)
                    Modifier.border(1.dp, Color.White.copy(alpha = 0.25f), RoundedCornerShape(10.dp))
                else Modifier
            )
            .clickable(onClick = onClick)
            .padding(vertical = 10.dp),
        contentAlignment = Alignment.Center
    ) {
        Text(
            label,
            color = textColor,
            fontWeight = if (selected) FontWeight.Bold else FontWeight.Normal,
            fontSize = 13.sp
        )
    }
}
