package com.tebogo.markvault.ui

import androidx.compose.foundation.clickable
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Close
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SegmentedButton
import androidx.compose.material3.SegmentedButtonDefaults
import androidx.compose.material3.SingleChoiceSegmentedButtonRow
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.compose.runtime.remember
import kotlinx.coroutines.launch
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.SpanStyle
import androidx.compose.ui.text.buildAnnotatedString
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.text.withStyle
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.navigation.NavController
import com.tebogo.markvault.AppViewModel
import com.tebogo.markvault.SearchMode

@OptIn(ExperimentalMaterial3Api::class, ExperimentalFoundationApi::class)
@Composable
fun SearchScreen(vm: AppViewModel, nav: NavController) {
    val query by vm.query.collectAsStateWithLifecycle()
    val mode by vm.mode.collectAsStateWithLifecycle()
    val quotePhrase by vm.quotePhrase.collectAsStateWithLifecycle()
    val results by vm.results.collectAsStateWithLifecycle()
    val topicMatches by vm.topicMatches.collectAsStateWithLifecycle()
    val recentSearches by vm.recentSearches.collectAsStateWithLifecycle()
    val focus = remember { FocusRequester() }

    // v4.7 — long-press on a search result triggers an action sheet (open in
    // split, open externally, share, convert, open in graph).
    var longPressTarget by remember { mutableStateOf<SearchHit?>(null) }
    // Split-view picker: after user picks "Open in split view", we show a
    // dialog listing every OTHER open tab to pair this one with.
    var splitPickerTarget by remember { mutableStateOf<SearchHit?>(null) }
    // Convert-to dialog: user chose "Convert" → asks which target format.
    var convertTarget by remember { mutableStateOf<SearchHit?>(null) }

    // TASK 5: if the user opened Search via "Search in MarkVault" from the
    // browser's text-selection menu, consume that pending query exactly once.
    LaunchedEffect(Unit) {
        vm.consumePendingSearch()?.let { vm.query.value = it }
    }

    Scaffold(
        topBar = {
            TopAppBar(title = {
                // v4.9.0 — semantic-search active indicator (green dot when on
                // AND embeddings exist, white circle otherwise).
                // v4.9.1 — added compact model short-name next to the dot so
                // the user sees at a glance which embedding model is in use.
                val semOn by vm.semanticEnabled.collectAsStateWithLifecycle()
                val embedReady by vm.embeddingCount.collectAsStateWithLifecycle()
                val activeId by vm.activeModelId.collectAsStateWithLifecycle()
                val active = vm.availableModels.firstOrNull { it.id == activeId }
                val dot = if (semOn && embedReady > 0) "\uD83D\uDFE2" else "\u26AA"
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text("\uD83D\uDD0D Search  $dot")
                    if (semOn && embedReady > 0 && active != null) {
                        androidx.compose.foundation.layout.Spacer(
                            Modifier.width(8.dp)
                        )
                        Text(
                            active.shortName,
                            fontSize = 11.sp,
                            color = androidx.compose.material3.MaterialTheme
                                .colorScheme.onSurfaceVariant
                        )
                    }
                }
            })
        },
        bottomBar = { MarkVaultBottomBar(nav = nav, vm = vm) }
    ) { pad ->
        Column(Modifier.padding(pad).fillMaxSize()) {
            OutlinedTextField(
                value = query,
                onValueChange = { vm.query.value = it },
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp, vertical = 8.dp)
                    .focusRequester(focus),
                placeholder = {
                    Text(
                        if (mode == SearchMode.TITLES) "Search note names\u2026"
                        else "Search inside all notes\u2026"
                    )
                },
                singleLine = true,
                trailingIcon = {
                    if (query.isNotEmpty()) {
                        IconButton(onClick = { vm.query.value = "" }) {
                            Icon(Icons.Default.Close, contentDescription = "Clear")
                        }
                    }
                }
            )
            LaunchedEffect(Unit) { focus.requestFocus() }

            SingleChoiceSegmentedButtonRow(
                Modifier.fillMaxWidth().padding(horizontal = 16.dp)
            ) {
                SegmentedButton(
                    selected = mode == SearchMode.TITLES,
                    onClick = { vm.mode.value = SearchMode.TITLES },
                    shape = SegmentedButtonDefaults.itemShape(0, 2)
                ) { Text("\uD83D\uDCD1 Titles") }
                SegmentedButton(
                    selected = mode == SearchMode.CONTENT,
                    onClick = { vm.mode.value = SearchMode.CONTENT },
                    shape = SegmentedButtonDefaults.itemShape(1, 2)
                ) { Text("\uD83D\uDD0E Full text") }
            }

            // v4.23.0 — Compact toggle chips for Semantic + Rerank.
            // Lets the user A/B compare result quality across:
            //   1. Pure keyword (both OFF)
            //   2. + Semantic similarity (Semantic ON, Rerank OFF)
            //   3. + Cross-encoder rerank (both ON — best quality, 3–5 s)
            // Reranker chip degrades gracefully when not installed —
            // tapping it navigates to Settings so the user can install.
            run {
                val semOnRow by vm.semanticEnabled.collectAsStateWithLifecycle()
                val rerankInstalled by vm.rerankerInstalled.collectAsStateWithLifecycle()
                val rerankOn by vm.rerankEnabled.collectAsStateWithLifecycle()
                val rerankBusy by vm.rerankActive.collectAsStateWithLifecycle()
                Row(
                    Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 16.dp, vertical = 6.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = androidx.compose.foundation.layout.Arrangement.spacedBy(8.dp)
                ) {
                    androidx.compose.material3.FilterChip(
                        selected = semOnRow,
                        onClick = { vm.setSemanticEnabled(!semOnRow) },
                        label = {
                            Text(
                                if (semOnRow) "\uD83E\uDDE0 Semantic ON" else "\uD83E\uDDE0 Semantic OFF",
                                fontSize = 12.sp
                            )
                        }
                    )
                    if (rerankInstalled) {
                        androidx.compose.material3.FilterChip(
                            selected = rerankOn,
                            onClick = { vm.setRerankEnabled(!rerankOn) },
                            label = {
                                Text(
                                    if (rerankOn) "\uD83C\uDFAF Rerank ON" else "\uD83C\uDFAF Rerank OFF",
                                    fontSize = 12.sp
                                )
                            }
                        )
                    } else {
                        androidx.compose.material3.FilterChip(
                            selected = false,
                            onClick = { nav.navigate("settings") },
                            label = {
                                Text(
                                    "\uD83C\uDFAF Install rerank",
                                    fontSize = 12.sp
                                )
                            }
                        )
                    }
                    if (rerankBusy) {
                        androidx.compose.foundation.layout.Spacer(Modifier.width(4.dp))
                        androidx.compose.material3.CircularProgressIndicator(
                            modifier = Modifier
                                .width(14.dp)
                                .height(14.dp),
                            strokeWidth = 2.dp
                        )
                        androidx.compose.foundation.layout.Spacer(Modifier.width(4.dp))
                        Text(
                            "Reranking\u2026",
                            fontSize = 11.sp,
                            color = androidx.compose.material3.MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }
            }

            // Quote-phrase toggle — only meaningful in CONTENT mode.
            // When ON, the query is wrapped in quotes for an exact-phrase FTS match.
            if (mode == SearchMode.CONTENT) {
                Row(
                    Modifier
                        .fillMaxWidth()
                        .padding(start = 18.dp, end = 18.dp, top = 8.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Surface(
                        modifier = Modifier
                            .clickable { vm.quotePhrase.value = !quotePhrase }
                            .padding(end = 8.dp),
                        color = if (quotePhrase)
                            MaterialTheme.colorScheme.primary.copy(alpha = 0.22f)
                        else MaterialTheme.colorScheme.surfaceVariant,
                        shape = RoundedCornerShape(14.dp),
                        border = if (quotePhrase)
                            androidx.compose.foundation.BorderStroke(
                                1.dp, MaterialTheme.colorScheme.primary
                            ) else null
                    ) {
                        Row(
                            Modifier.padding(horizontal = 12.dp, vertical = 6.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                if (quotePhrase) "\u2705" else "\u2B1C",
                                fontSize = 11.sp
                            )
                            Spacer(Modifier.width(6.dp))
                            Text(
                                "\"exact phrase\"",
                                fontSize = 12.sp,
                                fontWeight = if (quotePhrase) FontWeight.SemiBold else FontWeight.Normal,
                                color = if (quotePhrase)
                                    MaterialTheme.colorScheme.primary
                                else MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    }
                    Text(
                        if (quotePhrase) "matches the whole phrase only"
                        else "tap to match the whole phrase only",
                        fontSize = 11.sp,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        maxLines = 1, overflow = TextOverflow.Ellipsis
                    )
                }
            }

            if (topicMatches.isNotEmpty()) {
                Text(
                    "Jump to topic",
                    Modifier.padding(start = 20.dp, top = 10.dp, bottom = 2.dp),
                    fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant
                )
                LazyRow(
                    Modifier.fillMaxWidth().padding(vertical = 4.dp),
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    contentPadding = PaddingValues(horizontal = 16.dp)
                ) {
                    items(topicMatches, key = { it.key }) { t ->
                        Surface(
                            color = MaterialTheme.colorScheme.primary.copy(alpha = 0.18f),
                            shape = RoundedCornerShape(20.dp),
                            modifier = Modifier.clickable { nav.navigate("topic/${t.key}") }
                        ) {
                            Text(
                                "${t.emoji} ${t.label} \u00B7 ${t.count}",
                                Modifier.padding(horizontal = 14.dp, vertical = 8.dp),
                                fontSize = 13.sp, fontWeight = FontWeight.Medium
                            )
                        }
                    }
                }
            }

            val trimmed = query.trim()
            val showingRecents = trimmed.length < 2
            val noMatches = !showingRecents && results.isEmpty() && topicMatches.isEmpty()

            Text(
                text = when {
                    showingRecents -> if (recentSearches.isEmpty()) {
                        if (mode == SearchMode.CONTENT)
                            "Tip: try a topic like \"death\" or wrap text in \"quotes\" for an exact phrase."
                        else "Type at least 2 letters."
                    } else "Recent searches"
                    noMatches -> "No matches in your library."
                    else -> "${results.size} result(s)"
                },
                modifier = Modifier.padding(horizontal = 20.dp, vertical = 6.dp),
                fontSize = 12.sp,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )

            LazyColumn(Modifier.fillMaxSize()) {
                if (showingRecents) {
                    // Persisted list of past clicks. Each card keeps the originally-searched query
                    // so we can highlight matched words in its title/path.
                    if (recentSearches.isNotEmpty()) {
                        items(recentSearches, key = { "rs-${it.noteId}-${it.ts}" }) { rs ->
                            val toks = remember(rs.query) {
                                rs.query.split(Regex("\\s+"))
                                    .map { it.trim() }.filter { it.isNotEmpty() }.take(6)
                            }
                            Surface(
                                color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.18f),
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(horizontal = 10.dp, vertical = 3.dp),
                                shape = RoundedCornerShape(10.dp)
                            ) {
                                Column(
                                    Modifier
                                        .fillMaxWidth()
                                        .clickable {
                                            val lower = rs.relPath.lowercase()
                                            // Replay the original query as a highlight on every reader.
                                            val h = rs.query.trim().removeSurrounding("\"")
                                            if (h.isNotEmpty()) vm.pendingHighlight = h
                                            when {
                                                lower.endsWith(".pdf") -> {
                                                    vm.openArticle(rs.noteId, rs.title, fileType = "pdf")
                                                    nav.navigate("pdfReader/${rs.noteId}")
                                                }
                                                lower.endsWith(".mhtml") || lower.endsWith(".mht") -> {
                                                    vm.openArticle(rs.noteId, rs.title, fileType = "mhtml")
                                                    nav.navigate("htmlReader/${rs.noteId}")
                                                }
                                                lower.endsWith(".html") || lower.endsWith(".htm") -> {
                                                    vm.openArticle(rs.noteId, rs.title, fileType = "html")
                                                    nav.navigate("htmlReader/${rs.noteId}")
                                                }
                                                else -> {
                                                    vm.openArticle(rs.noteId, rs.title)
                                                    nav.navigate("reader") { launchSingleTop = true }
                                                }
                                            }
                                        }
                                        .padding(horizontal = 12.dp, vertical = 16.dp)
                                ) {
                                    Row(verticalAlignment = Alignment.CenterVertically) {
                                        Text("\uD83D\uDD52", fontSize = 11.sp)
                                        Spacer(Modifier.width(6.dp))
                                        Text(
                                            rs.query, fontSize = 11.sp,
                                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                                            fontWeight = FontWeight.Medium,
                                            maxLines = 1, overflow = TextOverflow.Ellipsis
                                        )
                                    }
                                    Spacer(Modifier.height(2.dp))
                                    Text(
                                        highlightTerms(cleanTitleForDisplay(rs.title), toks),
                                        fontWeight = FontWeight.SemiBold,
                                        fontSize = 14.sp,
                                        maxLines = 1, overflow = TextOverflow.Ellipsis
                                    )
                                    Text(
                                        highlightTerms(rs.relPath, toks),
                                        fontSize = 11.sp,
                                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                                        maxLines = 1, overflow = TextOverflow.Ellipsis
                                    )
                                    // v4.6 — readable date+time for every recent
                                    // search entry. User asked: "search history
                                    // must have timestamps (date and time opened)".
                                    Text(
                                        formatRecentTimestamp(rs.ts),
                                        fontSize = 10.sp,
                                        color = MaterialTheme.colorScheme.primary,
                                        maxLines = 1
                                    )
                                }
                            }
                            HistoryBoldDivider()
                        }
                        item {
                            Text(
                                "Clear recent searches",
                                Modifier
                                    .fillMaxWidth()
                                    .clickable { vm.clearRecentSearches() }
                                    .padding(horizontal = 20.dp, vertical = 14.dp),
                                fontSize = 12.sp,
                                color = MaterialTheme.colorScheme.primary
                            )
                        }
                    }
                } else if (noMatches) {
                    item { WebSearchPrompt(trimmed, vm) }
                } else {
                    // Active search with results. Compute highlight tokens once per query.
                    val highlightTokens = trimmed.split(Regex("\\s+"))
                        .map { it.trim() }.filter { it.isNotEmpty() }.take(6)

                    // v4.17.0 — Multi-word match filter.
                    //
                    // The user's complaint: a query like
                    //   "what happened to the holy ones"
                    // was bringing up results where only one meaningful word
                    // (e.g. just "holy") appeared in the hit. Those are weak
                    // matches that clutter the list.
                    //
                    // Rule: when the query contains 2+ meaningful (non-stopword)
                    // words, a result must contain at least 2 distinct
                    // meaningful query words to be shown. Single-meaningful-word
                    // queries fall through unchanged because there's nothing
                    // to filter on.
                    //
                    // Caveat: pure-semantic results that happen to have ≤ 1
                    // keyword overlap get filtered too. In practice nearly all
                    // semantically related docs share vocabulary with the
                    // query, so the loss is small. If this proves too strict
                    // we can add a Settings toggle.
                    val meaningfulQueryTokens = highlightTokens
                        .map { it.lowercase().trim() }
                        .filter { it.length >= 2 && it !in SEARCH_RESULT_STOPWORDS }
                        .distinct()
                    val filteredResults = if (meaningfulQueryTokens.size < 2) {
                        results
                    } else {
                        results.filter { hit ->
                            // Build the haystack from everything we display
                            // on the row, plus the FTS snippet (which already
                            // contains the densest match cluster).
                            val haystack = buildString {
                                append(hit.title.lowercase()).append(' ')
                                append(hit.relPath.lowercase()).append(' ')
                                append(hit.snippet.lowercase())
                            }
                            val distinctMatches = meaningfulQueryTokens.count { tok ->
                                haystack.contains(tok)
                            }
                            distinctMatches >= 2
                        }
                    }
                    val hiddenCount = results.size - filteredResults.size

                    // v4.7.7 — always show the jw.org / wol.jw.org buttons,
                    // even when local matches exist. The user wants to be able
                    // to one-tap escalate to external search whenever they
                    // want, not just when the library comes up empty.
                    item { WebSearchPrompt(trimmed, vm) }
                    // Discoverability hint — tells the user that long-press
                    // is available. Tucked above the results list so it's
                    // visible exactly when they need it.
                    item {
                        Text(
                            "\uD83D\uDCA1 Tap to open · long-press for more options",
                            fontSize = 11.sp,
                            color = MaterialTheme.colorScheme.primary,
                            modifier = Modifier.padding(horizontal = 14.dp, vertical = 6.dp)
                        )
                    }
                    // v4.17.0 — Transparency: tell the user when matches were
                    // filtered out so the list doesn't feel silently shorter
                    // than expected. Only shown when ≥1 result was hidden.
                    if (hiddenCount > 0) {
                        item {
                            Text(
                                "\uD83D\uDD0E ${hiddenCount} weak match${if (hiddenCount == 1) "" else "es"} hidden \u00B7 needs at least 2 matching words",
                                fontSize = 11.sp,
                                color = MaterialTheme.colorScheme.onSurfaceVariant,
                                modifier = Modifier.padding(horizontal = 14.dp, vertical = 4.dp)
                            )
                        }
                    }
                    items(filteredResults, key = { it.id }) { hit ->
                        Surface(
                            color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.18f),
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(horizontal = 10.dp, vertical = 3.dp),
                            shape = RoundedCornerShape(10.dp)
                        ) {
                            // v4.7.4 — switched from combinedClickable to direct
                            // pointerInput + detectTapGestures. The former works
                            // most of the time but can be eaten by LazyColumn's
                            // scroll gesture detector on some devices, causing
                            // the long-press to silently never fire. The latter
                            // gives explicit control. Haptic feedback on long-
                            // press also gives the user immediate confirmation
                            // that the gesture was detected.
                            val haptic = androidx.compose.ui.platform.LocalHapticFeedback.current
                            Column(
                                Modifier
                                    .fillMaxWidth()
                                    .pointerInput(hit.id) {
                                        detectTapGestures(
                                            onTap = {
                                                vm.recordSearchClick(trimmed, hit.id, hit.title, hit.relPath)
                                                val toHighlight = trimmed.removeSurrounding("\"")
                                                if (toHighlight.isNotEmpty()) {
                                                    vm.pendingHighlight = toHighlight
                                                }
                                                when (hit.fileType) {
                                                    "pdf" -> {
                                                        vm.openArticle(hit.id, hit.title, fileType = "pdf")
                                                        nav.navigate("pdfReader/${hit.id}")
                                                    }
                                                    "mhtml", "html" -> {
                                                        vm.openArticle(hit.id, hit.title, fileType = hit.fileType)
                                                        nav.navigate("htmlReader/${hit.id}")
                                                    }
                                                    else -> {
                                                        vm.openArticle(hit.id, hit.title)
                                                        nav.navigate("reader") { launchSingleTop = true }
                                                    }
                                                }
                                            },
                                            onLongPress = {
                                                // Haptic buzz so the user knows the press registered.
                                                haptic.performHapticFeedback(
                                                    androidx.compose.ui.hapticfeedback.HapticFeedbackType.LongPress
                                                )
                                                longPressTarget = SearchHit(
                                                    id = hit.id, title = hit.title,
                                                    relPath = hit.relPath, fileType = hit.fileType
                                                )
                                            }
                                        )
                                    }
                                    // v4.14.0 — more vertical breathing room between
                                    // result rows. The bolder divider already makes
                                    // boundaries clear; adding generous padding keeps
                                    // each card from feeling cramped.
                                    .padding(horizontal = 12.dp, vertical = 18.dp)
                            ) {
                                // v4.7.6 — clean the title for display so URLs
                                // embedded in markdown link syntax like
                                //   # [Am I a Perfectionist?](https://.../teenager/...)
                                // don't crowd out the visible text. We highlight
                                // matches inside the cleaned title. If the search
                                // term matched somewhere that's NOT visible
                                // (the URL was stripped, or the term lives in
                                // a long part that gets truncated), we render
                                // a small context snippet below so the user can
                                // see WHERE the match was found.
                                val displayTitle = cleanTitleForDisplay(hit.title)
                                val titleHasMatch = highlightTokens.any {
                                    displayTitle.contains(it, ignoreCase = true)
                                }
                                val pathHasMatch = highlightTokens.any {
                                    hit.relPath.contains(it, ignoreCase = true)
                                }
                                Text(
                                    highlightTerms(displayTitle, highlightTokens),
                                    fontWeight = FontWeight.SemiBold,
                                    maxLines = 1,
                                    overflow = TextOverflow.Ellipsis
                                )
                                Text(
                                    highlightTerms(hit.relPath, highlightTokens),
                                    fontSize = 11.sp,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                                    maxLines = 1,
                                    overflow = TextOverflow.Ellipsis
                                )
                                if (!titleHasMatch && !pathHasMatch) {
                                    // The match must be living in the URL we
                                    // just stripped from the title (or in the
                                    // file name). Compute a tight context
                                    // window around the first match in the raw
                                    // title + name so it's still visible.
                                    val context = matchContextSnippet(
                                        "${hit.title} ${hit.relPath}",
                                        highlightTokens
                                    )
                                    if (context != null) {
                                        Spacer(Modifier.height(2.dp))
                                        Text(
                                            highlightTerms(context, highlightTokens),
                                            fontSize = 11.sp,
                                            color = MaterialTheme.colorScheme.primary,
                                            maxLines = 1,
                                            overflow = TextOverflow.Ellipsis
                                        )
                                    }
                                }
                                if (hit.snippet.isNotBlank()) {
                                    Spacer(Modifier.height(4.dp))
                                    Text(highlightSnippet(hit.snippet), fontSize = 13.sp, lineHeight = 18.sp)
                                }
                            }
                        }
                        // Bolder dividing line between search results
                        HistoryBoldDivider()
                    }
                }
                item { Spacer(Modifier.height(24.dp)) }
            }
        }
    }

    // v4.7 — long-press action sheet on search results.
    longPressTarget?.let { hit ->
        SearchResultActionSheet(
            hit = hit,
            vm = vm,
            nav = nav,
            onDismiss = { longPressTarget = null },
            onPickSplitPair = {
                splitPickerTarget = hit
                longPressTarget = null
            },
            onPickConvert = {
                convertTarget = hit
                longPressTarget = null
            }
        )
    }

    splitPickerTarget?.let { hit ->
        SplitPartnerPickerDialog(
            hit = hit,
            vm = vm,
            nav = nav,
            onDismiss = { splitPickerTarget = null }
        )
    }

    convertTarget?.let { hit ->
        ConvertTargetDialog(
            hit = hit,
            vm = vm,
            onDismiss = { convertTarget = null }
        )
    }
}

/** Lightweight shadow of a search hit we can pass to dialog state. */
private data class SearchHit(
    val id: Long,
    val title: String,
    val relPath: String,
    val fileType: String
)

/**
 * Action sheet shown on long-press of a search result. Offers:
 *   • Open in split view (then picks the partner)
 *   • Open externally
 *   • Share
 *   • Convert (auto-detects valid target types)
 *   • Open in graph
 */
@OptIn(androidx.compose.material3.ExperimentalMaterial3Api::class)
@Composable
private fun SearchResultActionSheet(
    hit: SearchHit,
    vm: AppViewModel,
    nav: NavController,
    onDismiss: () -> Unit,
    onPickSplitPair: () -> Unit,
    onPickConvert: () -> Unit
) {
    val ctx = androidx.compose.ui.platform.LocalContext.current
    androidx.compose.material3.ModalBottomSheet(onDismissRequest = onDismiss) {
        Column(Modifier.fillMaxWidth().padding(horizontal = 18.dp, vertical = 8.dp)) {
            Text(
                hit.title.ifBlank { hit.relPath },
                fontSize = 15.sp,
                fontWeight = FontWeight.SemiBold,
                maxLines = 2,
                overflow = TextOverflow.Ellipsis
            )
            Text(
                "Type: ${hit.fileType.uppercase()}",
                fontSize = 12.sp,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                modifier = Modifier.padding(top = 2.dp)
            )
            Spacer(Modifier.height(10.dp))
            androidx.compose.material3.TextButton(
                onClick = onPickSplitPair,
                modifier = Modifier.fillMaxWidth()
            ) { Text("\uD83E\uDE9F  Open in split view") }
            androidx.compose.material3.TextButton(
                onClick = {
                    onDismiss()
                    val note = vm.openSync(hit.id)
                    val uri = note?.uri?.let { runCatching { android.net.Uri.parse(it) }.getOrNull() }
                    uri?.let {
                        runCatching {
                            ctx.startActivity(
                                android.content.Intent(android.content.Intent.ACTION_VIEW, it)
                                    .addFlags(android.content.Intent.FLAG_GRANT_READ_URI_PERMISSION)
                            )
                        }
                    }
                },
                modifier = Modifier.fillMaxWidth()
            ) { Text("\u2197  Open externally") }
            androidx.compose.material3.TextButton(
                onClick = {
                    onDismiss()
                    val note = vm.openSync(hit.id)
                    val uri = note?.uri?.let { runCatching { android.net.Uri.parse(it) }.getOrNull() }
                    uri?.let {
                        runCatching {
                            val mime = when (hit.fileType) {
                                "pdf" -> "application/pdf"
                                "mhtml", "html" -> "text/html"
                                else -> "text/markdown"
                            }
                            ctx.startActivity(android.content.Intent.createChooser(
                                android.content.Intent(android.content.Intent.ACTION_SEND)
                                    .setType(mime)
                                    .putExtra(android.content.Intent.EXTRA_STREAM, it)
                                    .addFlags(android.content.Intent.FLAG_GRANT_READ_URI_PERMISSION),
                                "Share file"
                            ))
                        }
                    }
                },
                modifier = Modifier.fillMaxWidth()
            ) { Text("\u2709\uFE0F  Share") }
            androidx.compose.material3.TextButton(
                onClick = onPickConvert,
                modifier = Modifier.fillMaxWidth()
            ) { Text("\uD83D\uDD04  Convert\u2026") }
            androidx.compose.material3.TextButton(
                onClick = {
                    onDismiss()
                    nav.navigate("graph") { launchSingleTop = true }
                },
                modifier = Modifier.fillMaxWidth()
            ) { Text("\uD83D\uDD78\uFE0F  Open in graph") }
            Spacer(Modifier.height(16.dp))
        }
    }
}

/** After user picks "Open in split view", we list the other open tabs to pair with. */
@Composable
private fun SplitPartnerPickerDialog(
    hit: SearchHit,
    vm: AppViewModel,
    nav: NavController,
    onDismiss: () -> Unit
) {
    val tabs by vm.tabs.collectAsStateWithLifecycle()
    val partners = tabs.filter { it.id != hit.id }
    androidx.compose.material3.AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Open in split view with…") },
        text = {
            if (partners.isEmpty()) {
                Text(
                    "Open another file first, then come back here to pair them.",
                    fontSize = 13.sp
                )
            } else {
                Column {
                    partners.forEach { p ->
                        androidx.compose.material3.TextButton(
                            onClick = {
                                onDismiss()
                                nav.navigate(
                                    "splitReader/${hit.id}/${hit.fileType}/${p.id}/${p.fileType}"
                                )
                            },
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Text(
                                p.title.ifBlank { "Untitled" },
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis
                            )
                        }
                    }
                }
            }
        },
        confirmButton = {
            androidx.compose.material3.TextButton(onClick = onDismiss) { Text("Cancel") }
        }
    )
}

/**
 * Convert dialog — offers target file types based on the source. The actual
 * conversion logic lives on the VM (placeholder for v4.7). The UI is wired
 * end-to-end so the next iteration only needs to fill in the conversion bodies.
 */
@Composable
private fun ConvertTargetDialog(
    hit: SearchHit,
    vm: AppViewModel,
    onDismiss: () -> Unit
) {
    val ctx = androidx.compose.ui.platform.LocalContext.current
    val scope = androidx.compose.runtime.rememberCoroutineScope()
    // Available target types based on source. If the source is markdown, you
    // can go to HTML or PDF. From HTML/MHTML, you can go to Markdown or PDF.
    // From PDF, you can go to Markdown or HTML.
    val targets = when (hit.fileType) {
        "md" -> listOf("html" to "HTML (.html)", "pdf" to "PDF (.pdf)")
        "html", "mhtml" -> listOf("md" to "Markdown (.md)", "pdf" to "PDF (.pdf)")
        "pdf" -> listOf("md" to "Markdown (.md)", "html" to "HTML (.html)")
        else -> emptyList()
    }
    androidx.compose.material3.AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Convert to…") },
        text = {
            Column {
                Text(
                    "Pick a target format. The new file lands in your library and is automatically indexed.",
                    fontSize = 12.sp,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    modifier = Modifier.padding(bottom = 8.dp)
                )
                targets.forEach { (typeId, label) ->
                    androidx.compose.material3.TextButton(
                        onClick = {
                            onDismiss()
                            scope.launch {
                                val res = vm.convertNote(hit.id, hit.fileType, typeId)
                                val msg = when (res) {
                                    is com.tebogo.markvault.SaveResult.Ok ->
                                        "\u2705 Saved: ${res.fileName}"
                                    is com.tebogo.markvault.SaveResult.Error ->
                                        "\u26A0\uFE0F ${res.message}"
                                }
                                android.widget.Toast.makeText(
                                    ctx, msg, android.widget.Toast.LENGTH_LONG
                                ).show()
                            }
                        },
                        modifier = Modifier.fillMaxWidth()
                    ) { Text(label) }
                }
            }
        },
        confirmButton = {
            androidx.compose.material3.TextButton(onClick = onDismiss) { Text("Cancel") }
        }
    )
}

@Composable
private fun WebSearchPrompt(query: String, vm: AppViewModel) {
    val encQuery = remember(query) {
        runCatching { java.net.URLEncoder.encode(query, "UTF-8") }.getOrElse { query }
    }
    Column(Modifier.fillMaxWidth().padding(horizontal = 20.dp, vertical = 12.dp)) {
        Text(
            "Search on jw.org?",
            fontWeight = FontWeight.SemiBold,
            fontSize = 15.sp
        )
        Spacer(Modifier.height(4.dp))
        Text(
            "Nothing matched \"$query\" in your library. You can look it up online \u2014 we only allow jw.org and wol.jw.org here.",
            fontSize = 13.sp, lineHeight = 18.sp,
            color = MaterialTheme.colorScheme.onSurfaceVariant
        )
        Spacer(Modifier.height(12.dp))
        WebSearchButton("\uD83C\uDF10  jw.org") {
            vm.requestWebPopup("https://www.jw.org/en/search/?q=$encQuery")
        }
        Spacer(Modifier.height(8.dp))
        WebSearchButton("\uD83D\uDCDA  wol.jw.org (Watchtower library)") {
            vm.requestWebPopup("https://wol.jw.org/en/wol/s/r1/lp-e?q=$encQuery")
        }
        Spacer(Modifier.height(8.dp))
        WebSearchButton("\uD83C\uDFAC  Videos on jw.org") {
            vm.requestWebPopup("https://www.jw.org/en/search/?q=$encQuery&insight%5BsearchType%5D%5B%5D=videos")
        }
    }
}

@Composable
private fun WebSearchButton(label: String, onClick: () -> Unit) {
    Surface(
        color = MaterialTheme.colorScheme.primary.copy(alpha = 0.18f),
        shape = RoundedCornerShape(10.dp),
        modifier = Modifier.fillMaxWidth().clickable(onClick = onClick)
    ) {
        Text(
            label,
            Modifier.padding(horizontal = 16.dp, vertical = 13.dp),
            fontWeight = FontWeight.Medium, fontSize = 14.sp
        )
    }
}

private fun highlightSnippet(s: String): AnnotatedString = buildAnnotatedString {
    val parts = s.split("\u27E6")
    parts.forEachIndexed { idx, part ->
        if (idx == 0) {
            append(part)
        } else {
            val end = part.indexOf('\u27E7')
            if (end >= 0) {
                // v4.14.0 — bold italic instead of yellow background.
                // Keeps matches visually prominent but doesn't make the list
                // look "ransom-note" busy. The yellow highlight stays in
                // articles (.md / .html / .pdf) where it makes sense.
                withStyle(
                    SpanStyle(
                        fontWeight = FontWeight.Bold,
                        fontStyle = androidx.compose.ui.text.font.FontStyle.Italic
                    )
                ) {
                    append(part.substring(0, end))
                }
                append(part.substring(end + 1))
            } else {
                append(part)
            }
        }
    }
}

/**
 * Highlight every occurrence of each search token inside [text] (case-insensitive).
 * Overlapping / adjacent matches are merged so we never produce nested or jagged spans.
 */
private fun highlightTerms(text: String, terms: List<String>): AnnotatedString {
    if (terms.isEmpty() || text.isEmpty()) return AnnotatedString(text)
    val lower = text.lowercase()
    // Collect every match range across every token
    val ranges = ArrayList<IntRange>()
    for (term in terms) {
        val needle = term.lowercase()
        if (needle.isEmpty()) continue
        var from = 0
        while (from <= lower.length - needle.length) {
            val found = lower.indexOf(needle, from)
            if (found < 0) break
            ranges.add(found until (found + needle.length))
            from = found + needle.length
        }
    }
    if (ranges.isEmpty()) return AnnotatedString(text)
    // Sort and merge overlapping/adjacent ranges into a clean span list
    ranges.sortBy { it.first }
    val merged = ArrayList<IntRange>()
    var cur = ranges[0]
    for (i in 1 until ranges.size) {
        val r = ranges[i]
        cur = if (r.first <= cur.last + 1) cur.first..maxOf(cur.last, r.last)
        else { merged.add(cur); r }
    }
    merged.add(cur)
    // Build the styled string in a single pass
    return buildAnnotatedString {
        var pos = 0
        // v4.14.0 — same bold-italic-not-yellow style as highlightSnippet.
        val emph = SpanStyle(
            fontWeight = FontWeight.Bold,
            fontStyle = androidx.compose.ui.text.font.FontStyle.Italic
        )
        for (r in merged) {
            if (r.first > pos) append(text.substring(pos, r.first))
            withStyle(emph) { append(text.substring(r.first, r.last + 1)) }
            pos = r.last + 1
        }
        if (pos < text.length) append(text.substring(pos))
    }
}

/**
 * Format a recent-search timestamp as something like "Today 14:32",
 * "Yesterday 09:15", or "Mon 18 Nov · 11:48" for older entries. Mirrors the
 * style we use on Recent cards on Home so the search history reads consistently.
 */
private fun formatRecentTimestamp(ts: Long): String {
    if (ts <= 0L) return ""
    val now = System.currentTimeMillis()
    val diff = now - ts
    val cal = java.util.Calendar.getInstance().apply { timeInMillis = ts }
    val today = java.util.Calendar.getInstance()
    val sameDay = cal.get(java.util.Calendar.YEAR) == today.get(java.util.Calendar.YEAR) &&
        cal.get(java.util.Calendar.DAY_OF_YEAR) == today.get(java.util.Calendar.DAY_OF_YEAR)
    val timeFmt = java.text.SimpleDateFormat("HH:mm", java.util.Locale.getDefault())
    val time = timeFmt.format(java.util.Date(ts))
    if (sameDay) return "Today · $time"
    val yesterday = java.util.Calendar.getInstance().apply {
        timeInMillis = now
        add(java.util.Calendar.DAY_OF_YEAR, -1)
    }
    val isYesterday = cal.get(java.util.Calendar.YEAR) == yesterday.get(java.util.Calendar.YEAR) &&
        cal.get(java.util.Calendar.DAY_OF_YEAR) == yesterday.get(java.util.Calendar.DAY_OF_YEAR)
    if (isYesterday) return "Yesterday · $time"
    val dateFmt = if (diff < 365L * 24 * 60 * 60 * 1000)
        java.text.SimpleDateFormat("EEE d MMM", java.util.Locale.getDefault())
    else
        java.text.SimpleDateFormat("d MMM yyyy", java.util.Locale.getDefault())
    return "${dateFmt.format(java.util.Date(ts))} · $time"
}

/**
 * Clean a stored title for display. Strips:
 *   • YAML frontmatter remnants
 *   • Markdown image syntax `![alt](url)`
 *   • Markdown link syntax `[text](url)` → keeps just `text`
 *   • Obsidian wikilinks `[[Target|Alias]]` → keeps alias if present, else target
 *   • Heading hashes, bold/italic markers
 *
 * This is the same idea as HomeScreen.stripMarkdownNoise but limited to one
 * line and kept private to this file so I don't break HomeScreen's existing
 * cleanup pipeline. Both functions can diverge if needed.
 *
 * The reason this matters for search results: the indexer captures the first
 * `# Heading` line verbatim, including any markdown link syntax. So a heading
 * like `# [Am I a Perfectionist? | Young People Ask](https://.../teenager/...)`
 * gets stored with the URL inside. When displayed on one truncated line, the
 * URL eats the visible space and any highlighted match in the URL is hidden
 * past the ellipsis. Stripping the link wrapper at display time keeps the
 * visible text clean and lets the highlighter mark matches in the part the
 * user can actually see.
 */
private fun cleanTitleForDisplay(raw: String): String {
    var t = raw.trim()
    if (t.startsWith("---")) {
        val end = t.indexOf("---", 3)
        if (end > 0) t = t.substring(end + 3).trim()
    }
    t = t
        .replace(Regex("^#+\\s+"), "")
        .replace(Regex("!\\[[^\\]]*]\\([^)]*\\)"), "")
        .replace(Regex("\\[([^\\]]+)]\\([^)]*\\)"), "$1")
        .replace(Regex("\\[\\[([^\\[\\]|#^\\n]+)(?:#[^\\[\\]|\\n]*)?(?:\\^[^\\[\\]|\\n]*)?(?:\\|([^\\[\\]\\n]+))?]]")) { m ->
            m.groupValues[2].ifBlank { m.groupValues[1] }
        }
        .replace(Regex("\\*\\*([^*]+)\\*\\*"), "$1")
        .replace(Regex("__([^_]+)__"), "$1")
        .replace(Regex("`([^`]+)`"), "$1")
        .replace(Regex("\\s+"), " ")
        .trim()
    return t.ifBlank { raw.trim() }
}

/**
 * Given a long text and a list of search terms, return a ~70-character window
 * centred on the first occurrence of any term — with "…" prefixes/suffixes
 * when the window doesn't span the full text. Returns null if no term is
 * found.
 *
 * Used as a fallback "found in URL" hint when the cleaned title and path
 * don't contain a visible match but the original raw title did (typically
 * inside a markdown link URL that got stripped).
 */
private fun matchContextSnippet(haystack: String, needles: List<String>): String? {
    if (haystack.isEmpty() || needles.isEmpty()) return null
    val lower = haystack.lowercase()
    var firstIdx = -1
    var firstLen = 0
    for (n in needles) {
        val needle = n.lowercase()
        if (needle.isEmpty()) continue
        val idx = lower.indexOf(needle)
        if (idx >= 0 && (firstIdx < 0 || idx < firstIdx)) {
            firstIdx = idx
            firstLen = needle.length
        }
    }
    if (firstIdx < 0) return null
    val window = 70
    val before = (window - firstLen) / 2
    val start = (firstIdx - before).coerceAtLeast(0)
    val end = (firstIdx + firstLen + before).coerceAtMost(haystack.length)
    val prefix = if (start > 0) "… " else ""
    val suffix = if (end < haystack.length) " …" else ""
    return prefix + haystack.substring(start, end) + suffix
}

/**
 * v4.17.0 — Stopword list used by the multi-word match filter.
 *
 * Words here don't count toward the "result must contain at least 2 meaningful
 * matches" threshold. Without this, a query like
 *   "what happened to the holy ones"
 * would treat "what", "the", "to" as searchable content and skew the count.
 *
 * Mirrors the JS-side FALLBACK_STOPWORDS in render.js, extended with the
 * common interrogative pronouns ("what", "who", "when", etc.) that almost
 * always appear in natural-language questions but never carry the user's
 * actual intent.
 */
private val SEARCH_RESULT_STOPWORDS = setOf(
    // Articles & basic prepositions
    "the", "a", "an", "of", "to", "in", "on", "for", "at", "by",
    "with", "from", "as", "into", "onto", "upon", "about", "between", "among",
    // Conjunctions
    "and", "or", "but", "if", "so", "than", "then", "because",
    // Be / have / do auxiliaries
    "is", "are", "was", "were", "be", "been", "being",
    "do", "does", "did", "doing", "done",
    "has", "have", "had", "having",
    "will", "would", "shall", "should", "can", "could", "may", "might", "must",
    // Pronouns
    "it", "its", "this", "that", "these", "those",
    "i", "me", "my", "we", "us", "our",
    "you", "your", "he", "him", "his", "she", "her", "they", "them", "their",
    // Common interrogatives
    "what", "who", "whom", "whose", "when", "where", "why", "how", "which"
)
