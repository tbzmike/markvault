package com.tebogo.markvault.ui

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

/**
 * v5.4.10 — Three-option chooser shown when the user shares a URL to
 * MarkVault. Replaces the silent auto-convert-to-markdown behaviour.
 *
 * Options:
 *   • 📄 Convert to PDF       — uses Android's WebView print adapter
 *                                to render the page as PDF, saved into
 *                                the user's library.
 *   • 📝 Convert to Markdown  — existing Readability + Turndown flow.
 *   • 🌐 View live website    — opens in the in-app browser.
 */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun UrlShareChooserScreen(
    url: String,
    onConvertToPdf: () -> Unit,
    onConvertToMarkdown: () -> Unit,
    onViewLive: () -> Unit,
    onCancel: () -> Unit
) {
    val host = runCatching {
        android.net.Uri.parse(url).host ?: url
    }.getOrElse { url }

    Scaffold { pad ->
        Column(
            modifier = Modifier
                .padding(pad)
                .fillMaxSize()
                .padding(20.dp),
            verticalArrangement = Arrangement.Center
        ) {
            Text(
                "What would you like to do?",
                fontSize = 20.sp,
                fontWeight = FontWeight.Bold,
                color = MaterialTheme.colorScheme.onSurface
            )
            Spacer(Modifier.height(6.dp))
            Text(
                host,
                fontSize = 13.sp,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                maxLines = 2,
                overflow = TextOverflow.Ellipsis
            )
            Spacer(Modifier.height(8.dp))
            Text(
                url,
                fontSize = 11.sp,
                color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.65f),
                maxLines = 3,
                overflow = TextOverflow.Ellipsis
            )
            Spacer(Modifier.height(24.dp))

            ChooserOption(
                emoji = "\uD83D\uDCC4",
                title = "Convert to PDF",
                subtitle = "Save as a PDF file in your library. Preserves layout, " +
                    "images, and styling. Best for archival and offline reference.",
                onTap = onConvertToPdf
            )
            Spacer(Modifier.height(10.dp))
            ChooserOption(
                emoji = "\uD83D\uDCDD",
                title = "Convert to Markdown",
                subtitle = "Extracts the article text via Readability, converts to " +
                    "clean .md. Searchable, editable, blends with your vault.",
                onTap = onConvertToMarkdown
            )
            Spacer(Modifier.height(10.dp))
            ChooserOption(
                emoji = "\uD83C\uDF10",
                title = "View live website",
                subtitle = "Open in the in-app browser. No conversion, no saving — " +
                    "just read it now.",
                onTap = onViewLive
            )

            Spacer(Modifier.height(24.dp))
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.End
            ) {
                TextButton(onClick = onCancel) {
                    Text("Cancel")
                }
            }
        }
    }
}

@Composable
private fun ChooserOption(
    emoji: String,
    title: String,
    subtitle: String,
    onTap: () -> Unit
) {
    Surface(
        color = MaterialTheme.colorScheme.surfaceVariant,
        shape = RoundedCornerShape(14.dp),
        tonalElevation = 2.dp,
        modifier = Modifier
            .fillMaxWidth()
            .clickable { onTap() }
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(emoji, fontSize = 30.sp)
            Spacer(Modifier.width(14.dp))
            Column(modifier = Modifier.fillMaxWidth()) {
                Text(
                    title,
                    fontSize = 15.sp,
                    fontWeight = FontWeight.SemiBold,
                    color = MaterialTheme.colorScheme.onSurface
                )
                Spacer(Modifier.height(2.dp))
                Text(
                    subtitle,
                    fontSize = 12.sp,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    lineHeight = 16.sp
                )
            }
        }
    }
}
