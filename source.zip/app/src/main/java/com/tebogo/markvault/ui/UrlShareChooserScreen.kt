package com.tebogo.markvault.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import com.tebogo.markvault.AppViewModel
import com.tebogo.markvault.data.MediaItem

/**
 * v5.4.10 — Chooser shown when the user shares a URL to MarkVault.
 *
 * Options:
 *   • 📄 Convert to PDF       — Android's WebView print adapter.
 *   • 📝 Convert to Markdown  — Readability + Turndown flow.
 *   • 🌐 View live website    — in-app browser.
 *   • ▶ Play Video/Audio      — v5.4.235cc: shown ONLY when the shared URL
 *     is detected as a video/audio link. Resolved via
 *     AppViewModel.resolveMediaInfoOnly() (same detection MarkVault uses
 *     everywhere else — MediaLinkDetector + the verified fuzzy search),
 *     showing the real title/thumbnail/duration before the user commits.
 */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun UrlShareChooserScreen(
    vm: AppViewModel,
    url: String,
    onConvertToPdf: () -> Unit,
    onConvertToMarkdown: () -> Unit,
    onViewLive: () -> Unit,
    onPlayMedia: (MediaItem) -> Unit,
    onCancel: () -> Unit
) {
    val host = runCatching {
        android.net.Uri.parse(url).host ?: url
    }.getOrElse { url }

    // v5.4.235cc — Detect video/audio in the background. Doesn't block the
    // other 3 options from showing immediately; the 4th option fades in
    // once (if) resolution completes.
    var mediaInfo by remember { mutableStateOf<MediaItem?>(null) }
    var checkingMedia by remember { mutableStateOf(true) }
    LaunchedEffect(url) {
        mediaInfo = runCatching { vm.resolveMediaInfoOnly(url) }.getOrNull()
        checkingMedia = false
    }

    Scaffold { pad ->
        Column(
            modifier = Modifier
                .padding(pad)
                .fillMaxSize()
                .padding(20.dp),
            verticalArrangement = Arrangement.Center
        ) {
            Text(
                "What would you like to do?",
                fontSize = 20.sp,
                fontWeight = FontWeight.Bold,
                color = MaterialTheme.colorScheme.onSurface
            )
            Spacer(Modifier.height(6.dp))
            Text(
                host,
                fontSize = 13.sp,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                maxLines = 2,
                overflow = TextOverflow.Ellipsis
            )
            Spacer(Modifier.height(8.dp))
            Text(
                url,
                fontSize = 11.sp,
                color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.65f),
                maxLines = 3,
                overflow = TextOverflow.Ellipsis
            )
            Spacer(Modifier.height(24.dp))

            // v5.4.235cc — Video/audio option first when detected — it's
            // the most specific, most likely intent when present.
            val info = mediaInfo
            if (checkingMedia) {
                Row(
                    modifier = Modifier.fillMaxWidth().padding(vertical = 4.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    CircularProgressIndicator(modifier = Modifier.size(14.dp), strokeWidth = 2.dp)
                    Spacer(Modifier.width(8.dp))
                    Text(
                        "Checking for video/audio\u2026",
                        fontSize = 12.sp,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
                Spacer(Modifier.height(10.dp))
            } else if (info != null) {
                MediaChooserOption(info = info, onTap = { onPlayMedia(info) })
                Spacer(Modifier.height(10.dp))
            }

            ChooserOption(
                emoji = "\uD83D\uDCC4",
                title = "Convert to PDF",
                subtitle = "Save as a PDF file in your library. Preserves layout, " +
                    "images, and styling. Best for archival and offline reference.",
                onTap = onConvertToPdf
            )
            Spacer(Modifier.height(10.dp))
            ChooserOption(
                emoji = "\uD83D\uDCDD",
                title = "Convert to Markdown",
                subtitle = "Extracts the article text via Readability, converts to " +
                    "clean .md. Searchable, editable, blends with your vault.",
                onTap = onConvertToMarkdown
            )
            Spacer(Modifier.height(10.dp))
            ChooserOption(
                emoji = "\uD83C\uDF10",
                title = "View live website",
                subtitle = "Open in the in-app browser. No conversion, no saving — " +
                    "just read it now.",
                onTap = onViewLive
            )

            Spacer(Modifier.height(24.dp))
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.End
            ) {
                TextButton(onClick = onCancel) {
                    Text("Cancel")
                }
            }
        }
    }
}

/** Format ms → "28:30" (local — avoids depending on another file's private helper). */
private fun formatChooserDuration(ms: Long): String {
    if (ms <= 0L) return ""
    val s = ms / 1000; val m = s / 60; val sec = s % 60
    return "%d:%02d".format(m, sec)
}

/**
 * v5.4.235cc — Richer chooser card for detected video/audio: shows a real
 * thumbnail (when available) plus title and duration, so the user can
 * confirm this is the right content before tapping.
 */
@Composable
private fun MediaChooserOption(info: MediaItem, onTap: () -> Unit) {
    Surface(
        color = MaterialTheme.colorScheme.primaryContainer,
        shape = RoundedCornerShape(14.dp),
        tonalElevation = 3.dp,
        modifier = Modifier
            .fillMaxWidth()
            .clickable { onTap() }
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            if (info.thumbnailUrl.isNotBlank()) {
                AsyncImage(
                    model = info.thumbnailUrl,
                    contentDescription = null,
                    contentScale = ContentScale.Crop,
                    modifier = Modifier.size(52.dp).clip(RoundedCornerShape(8.dp))
                )
            } else {
                Box(
                    modifier = Modifier.size(52.dp).clip(RoundedCornerShape(8.dp))
                        .background(MaterialTheme.colorScheme.surfaceVariant),
                    contentAlignment = Alignment.Center
                ) {
                    Text(if (info.mediaType == "audio") "\uD83D\uDD0A" else "\u25B6", fontSize = 26.sp)
                }
            }
            Spacer(Modifier.width(14.dp))
            Column(modifier = Modifier.weight(1f)) {
                Text(
                    if (info.mediaType == "audio") "Play Audio" else "Play Video",
                    fontSize = 15.sp,
                    fontWeight = FontWeight.SemiBold,
                    color = MaterialTheme.colorScheme.onPrimaryContainer
                )
                Spacer(Modifier.height(2.dp))
                Text(
                    info.title,
                    fontSize = 12.sp,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis,
                    color = MaterialTheme.colorScheme.onPrimaryContainer
                )
                if (info.durationMs > 0) {
                    Text(
                        formatChooserDuration(info.durationMs),
                        fontSize = 11.sp,
                        color = MaterialTheme.colorScheme.onPrimaryContainer.copy(alpha = 0.75f)
                    )
                }
            }
        }
    }
}

@Composable
private fun ChooserOption(
    emoji: String,
    title: String,
    subtitle: String,
    onTap: () -> Unit
) {
    Surface(
        color = MaterialTheme.colorScheme.surfaceVariant,
        shape = RoundedCornerShape(14.dp),
        tonalElevation = 2.dp,
        modifier = Modifier
            .fillMaxWidth()
            .clickable { onTap() }
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(emoji, fontSize = 30.sp)
            Spacer(Modifier.width(14.dp))
            Column(modifier = Modifier.fillMaxWidth()) {
                Text(
                    title,
                    fontSize = 15.sp,
                    fontWeight = FontWeight.SemiBold,
                    color = MaterialTheme.colorScheme.onSurface
                )
                Spacer(Modifier.height(2.dp))
                Text(
                    subtitle,
                    fontSize = 12.sp,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    lineHeight = 16.sp
                )
            }
        }
    }
}
