package com.tebogo.markvault.ui

import android.annotation.SuppressLint
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import coil.compose.AsyncImage
import com.tebogo.markvault.AppViewModel
import com.tebogo.markvault.data.MediaItem
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import org.json.JSONObject

/**
 * v5.4.10 — Chooser shown when the user shares a URL to MarkVault.
 *
 * Options:
 *   • 📄 Convert to PDF       — Android's WebView print adapter.
 *   • 📝 Convert to Markdown  — Readability + Turndown flow.
 *   • 🌐 View live website    — in-app browser.
 *   • ▶ Play Video/Audio      — v5.4.235cc: shown ONLY when the shared URL
 *     is detected as a video/audio link. Resolved via
 *     AppViewModel.resolveMediaInfoOnly() (same detection MarkVault uses
 *     everywhere else — MediaLinkDetector + the verified fuzzy search),
 *     showing the real title/thumbnail/duration before the user commits.
 */
@OptIn(ExperimentalMaterial3Api::class)
@SuppressLint("SetJavaScriptEnabled")
@Composable
fun UrlShareChooserScreen(
    vm: AppViewModel,
    url: String,
    onConvertToPdf: () -> Unit,
    onConvertToMarkdown: () -> Unit,
    onViewLive: () -> Unit,
    onPlayMedia: (MediaItem) -> Unit,
    onCancel: () -> Unit
) {
    val scope = rememberCoroutineScope()
    val host = runCatching {
        android.net.Uri.parse(url).host ?: url
    }.getOrElse { url }

    // v5.4.253cc — Two-stage media detection:
    //   1. FAST: vm.resolveMediaInfoOnly() — direct file URLs, PageMediaResolver's
    //      raw-HTML scan, and the offline-cache-by-key lookup. Instant when it
    //      works; free of network cost beyond one page fetch.
    //   2. SLOW FALLBACK (this version's fix): JW.org "finder" links land on a
    //      JS-rendered SPA shell with nothing in the raw server HTML for stage 1
    //      to find (confirmed by fetching an actual finder URL and inspecting its
    //      redirect target) — exactly why stage 1 alone kept coming up empty for
    //      these links. Real JS execution is required, which means a REAL WebView,
    //      not a raw HTTP fetch. Reuses the exact hidden-WebView pattern
    //      UrlImportScreen.kt already uses for Readability extraction (same
    //      settings, same onPageFinished + settle-delay shape) — proven, already
    //      working in this app — just with different extraction JS.
    //
    // Both stages run BEFORE the "Checking…" indicator clears, so the 4th option
    // only ever appears once, fully formed — never a flash of "nothing found"
    // before the slow path finishes.
    var mediaInfo by remember { mutableStateOf<MediaItem?>(null) }
    var checkingMedia by remember { mutableStateOf(true) }
    var checkingStage by remember { mutableStateOf(1) }   // 1 = fast check, 2 = extracting page
    var needsWebFallback by remember { mutableStateOf(false) }

    LaunchedEffect(url) {
        checkingStage = 1
        val fast = runCatching { vm.resolveMediaInfoOnly(url) }.getOrNull()
        if (fast != null) {
            mediaInfo = fast
            checkingMedia = false
        } else if (com.tebogo.markvault.util.MediaLinkDetector.classifySingleUrl(url) != null) {
            // Classified as video/audio, but the fast path found nothing —
            // hand off to the hidden WebView below.
            checkingStage = 2
            needsWebFallback = true
        } else {
            checkingMedia = false
        }
    }

    Scaffold { pad ->
        Column(
            modifier = Modifier
                .padding(pad)
                .fillMaxSize()
                .padding(20.dp),
            verticalArrangement = Arrangement.Center
        ) {
            Text(
                "What would you like to do?",
                fontSize = 20.sp,
                fontWeight = FontWeight.Bold,
                color = MaterialTheme.colorScheme.onSurface
            )
            Spacer(Modifier.height(6.dp))
            Text(
                host,
                fontSize = 13.sp,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                maxLines = 2,
                overflow = TextOverflow.Ellipsis
            )
            Spacer(Modifier.height(8.dp))
            Text(
                url,
                fontSize = 11.sp,
                color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.65f),
                maxLines = 3,
                overflow = TextOverflow.Ellipsis
            )
            Spacer(Modifier.height(24.dp))

            // v5.4.253cc — Stage-aware label: "Checking…" during the fast
            // path, "Extracting…" once the hidden WebView is doing real
            // work — the app indicating loading/extraction is happening,
            // not just a spinner with no explanation.
            val info = mediaInfo
            if (checkingMedia) {
                Row(
                    modifier = Modifier.fillMaxWidth().padding(vertical = 4.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    CircularProgressIndicator(modifier = Modifier.size(14.dp), strokeWidth = 2.dp)
                    Spacer(Modifier.width(8.dp))
                    Text(
                        if (checkingStage == 2) "Extracting video/audio\u2026" else "Checking for video/audio\u2026",
                        fontSize = 12.sp,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
                Spacer(Modifier.height(10.dp))
            } else if (info != null) {
                MediaChooserOption(info = info, onTap = { onPlayMedia(info) })
                Spacer(Modifier.height(10.dp))
            }

            ChooserOption(
                emoji = "\uD83D\uDCC4",
                title = "Convert to PDF",
                subtitle = "Save as a PDF file in your library. Preserves layout, " +
                    "images, and styling. Best for archival and offline reference.",
                onTap = onConvertToPdf
            )
            Spacer(Modifier.height(10.dp))
            ChooserOption(
                emoji = "\uD83D\uDCDD",
                title = "Convert to Markdown",
                subtitle = "Extracts the article text via Readability, converts to " +
                    "clean .md. Searchable, editable, blends with your vault.",
                onTap = onConvertToMarkdown
            )
            Spacer(Modifier.height(10.dp))
            ChooserOption(
                emoji = "\uD83C\uDF10",
                title = "View live website",
                subtitle = "Open in the in-app browser. No conversion, no saving — " +
                    "just read it now.",
                onTap = onViewLive
            )

            Spacer(Modifier.height(24.dp))
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.End
            ) {
                TextButton(onClick = onCancel) {
                    Text("Cancel")
                }
            }
        }
    }

    // v5.4.253cc — Hidden WebView fallback: real JS execution for JW.org
    // "finder" links, which land on a client-rendered SPA shell with no
    // usable markup in the raw server HTML (confirmed by direct testing —
    // that's why stage 1 above finds nothing for these). Same hidden-
    // WebView shape UrlImportScreen.kt already uses and relies on — same
    // settings, same onPageFinished + settle-delay pattern — just
    // different extraction JS. 1dp box keeps it fully invisible; the
    // "Extracting…" text above is what the user actually sees.
    if (needsWebFallback) {
        Box(Modifier.size(1.dp)) {
            AndroidView(
                modifier = Modifier.size(1.dp),
                factory = { c ->
                    WebView(c).apply {
                        settings.javaScriptEnabled = true
                        settings.domStorageEnabled = true
                        settings.loadsImagesAutomatically = true
                        settings.mediaPlaybackRequiresUserGesture = true
                        settings.mixedContentMode = WebSettings.MIXED_CONTENT_NEVER_ALLOW
                        val defaultUa = settings.userAgentString
                        settings.userAgentString = if (defaultUa.isNullOrBlank()) {
                            "Mozilla/5.0 (Linux; Android) AppleWebKit/537.36 " +
                                "(KHTML, like Gecko) Chrome/120.0.0.0 Mobile Safari/537.36"
                        } else {
                            defaultUa.replace("; wv)", ")")
                        }
                        var consumed = false
                        webViewClient = object : WebViewClient() {
                            override fun onPageFinished(view: WebView?, finishedUrl: String?) {
                                if (view == null || consumed) return
                                consumed = true
                                scope.launch {
                                    delay(1500)  // let the SPA hydrate/render
                                    extractMediaFromLivePage(view, vm, scope) { first ->
                                        if (first != null) {
                                            mediaInfo = first
                                            checkingMedia = false
                                            return@extractMediaFromLivePage
                                        }
                                        // Nothing resolved yet — best-effort:
                                        // simulate a tap on the likely play
                                        // trigger, give the resulting network
                                        // activity a moment, then check once more.
                                        scope.launch {
                                            delay(1800)
                                            extractMediaFromLivePage(view, vm, scope) { second ->
                                                mediaInfo = second
                                                checkingMedia = false
                                            }
                                        }
                                    }
                                }
                            }
                            override fun onReceivedError(
                                view: WebView?,
                                request: android.webkit.WebResourceRequest?,
                                error: android.webkit.WebResourceError?
                            ) {
                                if (request?.isForMainFrame == true && !consumed) {
                                    consumed = true
                                    checkingMedia = false
                                }
                            }
                        }
                        loadUrl(url)
                    }
                }
            )
        }
    }
}

/**
 * v5.4.253cc — Probe the live, JS-hydrated page for playable media. Scans
 * (in order): a rendered <video>/<audio> src, JW.org's data-json-src
 * manifest pointer (parsed the same way PageMediaResolver already parses
 * it — same field names, one consistent extraction), and a rendered
 * data-mediaid/data-video-mediaid natural key (checked against the offline
 * cache, same as the query-parameter case). If none of those are present
 * yet, taps the most likely play-trigger element as a best-effort nudge —
 * this part is inherently a heuristic (there's no documented contract for
 * a third-party page's DOM), not a guaranteed mechanism, which is why the
 * caller re-checks afterward rather than trusting the click blindly.
 */
private fun extractMediaFromLivePage(
    view: WebView,
    vm: AppViewModel,
    scope: kotlinx.coroutines.CoroutineScope,
    onResult: (MediaItem?) -> Unit
) {
    val js = """
        (function() {
          function findMedia() {
            var v = document.querySelector('video[src], video source[src]');
            if (v) {
              var vs = v.getAttribute('src');
              if (vs) return {kind:'src', url: vs, mediaType:'video'};
            }
            var a = document.querySelector('audio[src], audio source[src]');
            if (a) {
              var as_ = a.getAttribute('src');
              if (as_) return {kind:'src', url: as_, mediaType:'audio'};
            }
            var jsonEl = document.querySelector('[data-json-src]');
            if (jsonEl) {
              var j = jsonEl.getAttribute('data-json-src');
              if (j) return {kind:'jsonSrc', url: j};
            }
            var midEl = document.querySelector('[data-mediaid], [data-video-mediaid]');
            if (midEl) {
              var mid = midEl.getAttribute('data-mediaid') || midEl.getAttribute('data-video-mediaid');
              if (mid) return {kind:'mediaId', id: mid};
            }
            return null;
          }
          var found = findMedia();
          var clicked = false;
          if (!found) {
            var btn = document.querySelector(
              '[data-mediaid], [data-video-mediaid], button[class*="play"], [class*="video"][role="button"], video, .jw-video'
            );
            if (btn) { btn.click(); clicked = true; }
          }
          var ogTitleEl = document.querySelector('meta[property="og:title"]');
          var ogImgEl = document.querySelector('meta[property="og:image"]');
          return JSON.stringify({
            found: found,
            clicked: clicked,
            title: (ogTitleEl && ogTitleEl.content) || document.title || '',
            thumb: (ogImgEl && ogImgEl.content) || ''
          });
        })();
    """.trimIndent()

    view.evaluateJavascript(js) { raw ->
        scope.launch {
            val result = runCatching {
                val inner = JSONObject("{\"v\":$raw}").getString("v")
                val obj = JSONObject(inner)
                val title = obj.optString("title", "").ifBlank { "Shared media" }
                val thumb = obj.optString("thumb", "")
                val found = obj.optJSONObject("found")
                when (found?.optString("kind")) {
                    "src" -> MediaItem(
                        title = title,
                        streamUrl = found.optString("url"),
                        mediaType = found.optString("mediaType", "video"),
                        thumbnailUrl = thumb
                    )
                    // v5.4.253cc — Same field names PageMediaResolver already
                    // verified against real JW.org responses (progressive-
                    // DownloadURL primary, url fallback). Kept as a small,
                    // LOCAL fetch+parse here rather than reaching into
                    // PageMediaResolver.kt's private function — zero risk to
                    // that already-verified file.
                    "jsonSrc" -> {
                        val jsonUrl = found.optString("url").replace("&amp;", "&")
                        fetchJsonSrcMedia(jsonUrl, title, thumb)
                    }
                    // A natural key revealed by the HYDRATED DOM — distinct
                    // from stage 1's query-parameter key check (this is a
                    // different key, only visible after real JS execution).
                    "mediaId" -> {
                        val mid = found.optString("id")
                        if (mid.isNotBlank()) vm.lookupCachedMediaByKey(mid) else null
                    }
                    else -> null
                }
            }.getOrNull()
            onResult(result)
        }
    }
}

/**
 * v5.4.253cc — Minimal, LOCAL JSON-manifest fetch+parse for the data-json-src
 * pointer the live-page JS may reveal. Same field names PageMediaResolver's
 * own jsonSrcMedia() already parses (progressiveDownloadURL primary, url
 * fallback) — one consistent extraction — but kept as its own small function
 * here so PageMediaResolver.kt itself needs zero changes.
 */
private suspend fun fetchJsonSrcMedia(jsonUrl: String, fallbackTitle: String, fallbackThumb: String): MediaItem? =
    kotlinx.coroutines.withContext(kotlinx.coroutines.Dispatchers.IO) {
        runCatching {
            val conn = java.net.URL(jsonUrl).openConnection() as java.net.HttpURLConnection
            conn.connectTimeout = 12_000
            conn.readTimeout = 12_000
            conn.setRequestProperty("Accept", "application/json,*/*")
            val body = if (conn.responseCode == 200) {
                conn.inputStream.bufferedReader().readText()
            } else {
                return@runCatching null
            }
            val json = JSONObject(body)
            val media = json.optJSONObject("media")
                ?: json.optJSONArray("media")?.optJSONObject(0)
                ?: json
            val files = media.optJSONArray("files") ?: return@runCatching null
            var bestUrl = ""; var bestRes = -1
            for (i in 0 until files.length()) {
                val f = files.optJSONObject(i) ?: continue
                val fileUrl = f.optString("progressiveDownloadURL").ifBlank { f.optString("url") }
                if (fileUrl.isBlank()) continue
                val label = f.optString("label", "")
                val res = label.trimEnd('p').toIntOrNull() ?: f.optInt("frameHeight", 0)
                if (bestUrl.isEmpty()) { bestUrl = fileUrl; bestRes = res }
                else if (res in (bestRes + 1)..720) { bestUrl = fileUrl; bestRes = res }
            }
            if (bestUrl.isBlank()) return@runCatching null
            val title = media.optString("title").ifBlank { fallbackTitle }
            val type = media.optString("type").ifBlank {
                if (bestUrl.endsWith(".mp3", true) || bestUrl.endsWith(".m4a", true)) "audio" else "video"
            }
            MediaItem(title = title, streamUrl = bestUrl, mediaType = type, thumbnailUrl = fallbackThumb)
        }.getOrNull()
    }

/** Format ms → "28:30" (local — avoids depending on another file's private helper). */
private fun formatChooserDuration(ms: Long): String {
    if (ms <= 0L) return ""
    val s = ms / 1000; val m = s / 60; val sec = s % 60
    return "%d:%02d".format(m, sec)
}

/**
 * v5.4.235cc — Richer chooser card for detected video/audio: shows a real
 * thumbnail (when available) plus title and duration, so the user can
 * confirm this is the right content before tapping.
 */
@Composable
private fun MediaChooserOption(info: MediaItem, onTap: () -> Unit) {
    Surface(
        color = MaterialTheme.colorScheme.primaryContainer,
        shape = RoundedCornerShape(14.dp),
        tonalElevation = 3.dp,
        modifier = Modifier
            .fillMaxWidth()
            .clickable { onTap() }
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            if (info.thumbnailUrl.isNotBlank()) {
                AsyncImage(
                    model = info.thumbnailUrl,
                    contentDescription = null,
                    contentScale = ContentScale.Crop,
                    modifier = Modifier.size(52.dp).clip(RoundedCornerShape(8.dp))
                )
            } else {
                Box(
                    modifier = Modifier.size(52.dp).clip(RoundedCornerShape(8.dp))
                        .background(MaterialTheme.colorScheme.surfaceVariant),
                    contentAlignment = Alignment.Center
                ) {
                    Text(if (info.mediaType == "audio") "\uD83D\uDD0A" else "\u25B6", fontSize = 26.sp)
                }
            }
            Spacer(Modifier.width(14.dp))
            Column(modifier = Modifier.weight(1f)) {
                Text(
                    if (info.mediaType == "audio") "Play Audio" else "Play Video",
                    fontSize = 15.sp,
                    fontWeight = FontWeight.SemiBold,
                    color = MaterialTheme.colorScheme.onPrimaryContainer
                )
                Spacer(Modifier.height(2.dp))
                Text(
                    info.title,
                    fontSize = 12.sp,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis,
                    color = MaterialTheme.colorScheme.onPrimaryContainer
                )
                if (info.durationMs > 0) {
                    Text(
                        formatChooserDuration(info.durationMs),
                        fontSize = 11.sp,
                        color = MaterialTheme.colorScheme.onPrimaryContainer.copy(alpha = 0.75f)
                    )
                }
            }
        }
    }
}

@Composable
private fun ChooserOption(
    emoji: String,
    title: String,
    subtitle: String,
    onTap: () -> Unit
) {
    Surface(
        color = MaterialTheme.colorScheme.surfaceVariant,
        shape = RoundedCornerShape(14.dp),
        tonalElevation = 2.dp,
        modifier = Modifier
            .fillMaxWidth()
            .clickable { onTap() }
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(emoji, fontSize = 30.sp)
            Spacer(Modifier.width(14.dp))
            Column(modifier = Modifier.fillMaxWidth()) {
                Text(
                    title,
                    fontSize = 15.sp,
                    fontWeight = FontWeight.SemiBold,
                    color = MaterialTheme.colorScheme.onSurface
                )
                Spacer(Modifier.height(2.dp))
                Text(
                    subtitle,
                    fontSize = 12.sp,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    lineHeight = 16.sp
                )
            }
        }
    }
}
