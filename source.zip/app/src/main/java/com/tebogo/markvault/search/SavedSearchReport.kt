package com.tebogo.markvault.search

/** Browsing keeps execution metadata and counts; opening still loads the exact saved results. */
data class SavedSearchReport(
    val session: SavedSearchSession,
    val hitCount: Int,
    val provenanceCount: Int
) {
    val id: String get() = session.id
    val query: String get() = session.query
    val createdAt: Long get() = session.createdAt

    fun metadata(): SessionMeta = SessionMeta(
        id, query, createdAt, hitCount, session.searchType, session.durationMs
    )

    companion object {
        fun from(session: SavedSearchSession): SavedSearchReport = SavedSearchReport(
            session.copy(hits = emptyList(), hitScopes = emptyMap(), hitProvenance = emptyMap()),
            session.hits.size,
            session.hitProvenance.size
        )
    }
}
