package com.tebogo.markvault.ai

import ai.onnxruntime.OnnxTensor
import ai.onnxruntime.OrtEnvironment
import ai.onnxruntime.OrtSession
import android.content.Context
import android.util.Log
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File

/**
 * Runs T5-base encoder/decoder ONNX inference for query paraphrasing.
 *
 * Uses the plain (non-KV-cached) `decoder_model.onnx` graph rather than
 * `decoder_model_merged.onnx`: the merged/cached graph's exact
 * past_key_values plumbing varies by exporter version and is hard to get
 * right without being able to run and inspect it directly. The plain
 * decoder recomputes attention over the whole generated-so-far sequence
 * on every step -- slower for long output, but its input contract
 * (`input_ids`, `encoder_hidden_states`, `encoder_attention_mask`) is
 * standard and far less likely to be silently wrong.
 *
 * Real input/output tensor names for an Optimum seq2seq ONNX export are
 * well-documented and used here, but were not directly verified against
 * this exact graph (no way to execute ONNX Runtime in this environment).
 * [logGraphIO] dumps the actual names ONNX Runtime reports at session-load
 * time to Logcat specifically so a mismatch is immediately diagnosable on
 * a real device instead of failing silently or crashing deep in `run()`.
 */
class T5InferenceEngine private constructor(
    private val tokenizer: T5Tokenizer,
    private val encoderSession: OrtSession,
    private val decoderSession: OrtSession,
    private val env: OrtEnvironment
) {
    companion object {
        private const val TAG = "T5InferenceEngine"
        private const val MAX_NEW_TOKENS = 64
        private const val DECODER_START_TOKEN_ID = 0 // T5 uses pad (0) as decoder_start_token_id

        /** Loads sessions + tokenizer from already-downloaded files, or null if unavailable. */
        fun loadFrom(context: Context): T5InferenceEngine? {
            return try {
                val modelDir = File(context.filesDir, "models/t5-base")
                val encoderFile = File(modelDir, T5ModelCatalog.ENCODER.fileName)
                val decoderFile = File(modelDir, T5ModelCatalog.DECODER.fileName)
                if (!encoderFile.exists() || !decoderFile.exists()) return null

                val tokenizer = T5Tokenizer(context)
                if (!tokenizer.load()) return null

                val env = OrtEnvironment.getEnvironment()
                val options = OrtSession.SessionOptions()
                val encoderSession = env.createSession(encoderFile.absolutePath, options)
                val decoderSession = env.createSession(decoderFile.absolutePath, options)
                logGraphIO(encoderSession, "encoder")
                logGraphIO(decoderSession, "decoder")

                T5ResourceManager.markLoaded()
                T5MemoryCleanup.markLoaded()
                T5InferenceEngine(tokenizer, encoderSession, decoderSession, env)
            } catch (e: Exception) {
                Log.e(TAG, "Failed to load T5 ONNX sessions", e)
                null
            }
        }

        private fun logGraphIO(session: OrtSession, label: String) {
            Log.d(TAG, "$label inputs=${session.inputNames} outputs=${session.outputNames}")
        }
    }

    /**
     * Generates a paraphrase for [input] on [Dispatchers.IO], using
     * unweighted greedy (argmax) decoding token-by-token until an
     * end-of-sequence token or [MAX_NEW_TOKENS] is reached.
     */
    suspend fun generate(input: String): String = withContext(Dispatchers.IO) {
        val inputIds = tokenizer.encode(input)
        val attentionMask = LongArray(inputIds.size) { 1L }

        val encoderHidden = runEncoder(inputIds, attentionMask)
        val outputTokens = runDecoderGreedy(encoderHidden, attentionMask, inputIds.size)
        tokenizer.decode(outputTokens)
    }

    private fun runEncoder(inputIds: IntArray, attentionMask: LongArray): OnnxTensor {
        val idsTensor = OnnxTensor.createTensor(env, arrayOf(inputIds.map { it.toLong() }.toLongArray()))
        val maskTensor = OnnxTensor.createTensor(env, arrayOf(attentionMask))
        idsTensor.use { ids ->
            maskTensor.use { mask ->
                encoderSession.run(mapOf("input_ids" to ids, "attention_mask" to mask)).use { result ->
                    val hidden = result.iterator().next().value.value as Array<*>
                    // Copy out of the pooled result before it's closed.
                    return cloneFloatTensor(hidden)
                }
            }
        }
    }

    @Suppress("UNCHECKED_CAST")
    private fun cloneFloatTensor(nested: Array<*>): OnnxTensor {
        // nested shape: [batch=1][seq_len][hidden_dim] of Float
        val batch = nested as Array<Array<FloatArray>>
        return OnnxTensor.createTensor(env, batch)
    }

    private fun runDecoderGreedy(
        encoderHidden: OnnxTensor,
        encoderAttentionMask: LongArray,
        encoderSeqLen: Int
    ): IntArray {
        val encMaskTensor = OnnxTensor.createTensor(env, arrayOf(encoderAttentionMask))
        val generated = ArrayList<Long>()
        generated.add(DECODER_START_TOKEN_ID.toLong())

        try {
            var eosSeen = false
            var step = 0
            while (!eosSeen && step < MAX_NEW_TOKENS) {
                val decoderIdsTensor = OnnxTensor.createTensor(env, arrayOf(generated.toLongArray()))
                val nextId = decoderIdsTensor.use { ids ->
                    decoderSession.run(
                        mapOf(
                            "input_ids" to ids,
                            "encoder_hidden_states" to encoderHidden,
                            "encoder_attention_mask" to encMaskTensor
                        )
                    ).use { result ->
                        argmaxLastStep(result.iterator().next().value.value as Array<*>)
                    }
                }
                generated.add(nextId.toLong())
                step++
                if (nextId == 1) eosSeen = true // T5 eos_token_id is conventionally 1 (</s>)
            }
        } finally {
            encMaskTensor.close()
            encoderHidden.close()
        }
        return generated.map { it.toInt() }.toIntArray()
    }

    @Suppress("UNCHECKED_CAST")
    private fun argmaxLastStep(logits: Array<*>): Int {
        // logits shape: [batch=1][seq_len][vocab_size]
        val batch = logits as Array<Array<FloatArray>>
        val lastStepLogits = batch[0].last()
        var bestIdx = 0
        var bestVal = Float.NEGATIVE_INFINITY
        for (i in lastStepLogits.indices) {
            if (lastStepLogits[i] > bestVal) {
                bestVal = lastStepLogits[i]
                bestIdx = i
            }
        }
        return bestIdx
    }

    fun close() {
        try { encoderSession.close() } catch (_: Exception) {}
        try { decoderSession.close() } catch (_: Exception) {}
        T5ResourceManager.release()
        T5MemoryCleanup.cleanup()
    }
}
