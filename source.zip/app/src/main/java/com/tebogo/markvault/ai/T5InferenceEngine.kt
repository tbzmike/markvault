package com.tebogo.markvault.ai

/**
 * T5 inference engine bridge.
 * Keeps model execution isolated from retrieval code.
 */
class T5InferenceEngine(
    private val runner: suspend (IntArray) -> IntArray
) {
    private val tokenizer = T5Tokenizer()

    suspend fun generate(input: String): String {
        val output = runner(tokenizer.encode(input))
        return tokenizer.decode(output)
    }
}
