package com.tebogo.markvault.ai

import ai.onnxruntime.OnnxTensor
import ai.onnxruntime.OrtEnvironment
import ai.onnxruntime.OrtSession
import android.content.Context
import android.util.Log
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File

/**
 * Runs T5-base encoder/decoder ONNX inference for query paraphrasing.
 *
 * Uses the plain (non-KV-cached) `decoder_model.onnx` graph rather than
 * `decoder_model_merged.onnx`: the merged/cached graph's exact
 * past_key_values plumbing varies by exporter version and is hard to get
 * right without being able to run and inspect it directly. The plain
 * decoder recomputes attention over the whole generated-so-far sequence
 * on every step -- slower for long output, but its input contract
 * (`input_ids`, `encoder_hidden_states`, `encoder_attention_mask`) is
 * standard and far less likely to be silently wrong.
 *
 * Real input/output tensor names for an Optimum seq2seq ONNX export are
 * well-documented and used here, but were not directly verified against
 * this exact graph (no way to execute ONNX Runtime in this environment).
 * [logGraphIO] dumps the actual names ONNX Runtime reports at session-load
 * time to Logcat specifically so a mismatch is immediately diagnosable on
 * a real device instead of failing silently or crashing deep in `run()`.
 */
class T5InferenceEngine private constructor(
    private val tokenizer: T5Tokenizer,
    private val encoderSession: OrtSession,
    private val decoderSession: OrtSession,
    private val env: OrtEnvironment
) {
    private val random = kotlin.random.Random(System.nanoTime())

    companion object {
        private const val TAG = "T5InferenceEngine"
        private const val MAX_NEW_TOKENS = 64
        private const val DECODER_START_TOKEN_ID = 0 // T5 uses pad (0) as decoder_start_token_id

        /** Loads sessions + tokenizer from already-downloaded files, or null if unavailable. */
        fun loadFrom(context: Context): T5InferenceEngine? {
            return try {
                val modelDir = File(context.filesDir, "models/t5-base")
                val encoderFile = File(modelDir, T5ModelCatalog.ENCODER.fileName)
                val decoderFile = File(modelDir, T5ModelCatalog.DECODER.fileName)
                if (!encoderFile.exists() || !decoderFile.exists()) return null

                val tokenizer = T5Tokenizer(context)
                if (!tokenizer.load()) return null

                val env = OrtEnvironment.getEnvironment()
                val options = OrtSession.SessionOptions()
                val encoderSession = env.createSession(encoderFile.absolutePath, options)
                val decoderSession = env.createSession(decoderFile.absolutePath, options)
                logGraphIO(encoderSession, "encoder")
                logGraphIO(decoderSession, "decoder")

                T5ResourceManager.markLoaded()
                T5MemoryCleanup.markLoaded()
                T5InferenceEngine(tokenizer, encoderSession, decoderSession, env)
            } catch (e: Exception) {
                Log.e(TAG, "Failed to load T5 ONNX sessions", e)
                null
            }
        }

        private fun logGraphIO(session: OrtSession, label: String) {
            Log.d(TAG, "$label inputs=${session.inputNames} outputs=${session.outputNames}")
        }
    }

    /**
     * Generates one paraphrase for [input] on [Dispatchers.IO].
     *
     * [temperature] == 0f uses greedy (argmax) decoding: fully
     * deterministic, same input always produces the same output. Values
     * > 0f sample from the softmax distribution instead.
     */
    suspend fun generate(input: String, temperature: Float = 0f): String = withContext(Dispatchers.IO) {
        val inputIds = tokenizer.encode(input)
        val attentionMask = LongArray(inputIds.size) { 1L }
        val encoderHidden = runEncoder(inputIds, attentionMask)
        try {
            val outputTokens = decodeOnce(encoderHidden, attentionMask, temperature)
            tokenizer.decode(outputTokens)
        } finally {
            encoderHidden.close()
        }
    }

    /**
     * Generates up to [count] distinct paraphrases of [input], running
     * the encoder exactly ONCE and reusing its output across every decode
     * attempt -- calling [generate] `count` times would redundantly
     * re-encode the identical input on every attempt, roughly doubling
     * the work for no benefit, since the encoder pass doesn't depend on
     * decoding temperature.
     *
     * First attempt is deterministic (temperature 0); later attempts use
     * rising sampling temperature so repeat attempts on the same input
     * have a real chance of differing. May return fewer than [count] if
     * [maxAttempts] is exhausted first (duplicate/empty outputs don't
     * count against the [count] target but do count against the attempt
     * budget).
     */
    suspend fun generateMany(
        input: String,
        count: Int,
        maxAttempts: Int
    ): List<String> = withContext(Dispatchers.IO) {
        if (count <= 0) return@withContext emptyList()
        val inputIds = tokenizer.encode(input)
        val attentionMask = LongArray(inputIds.size) { 1L }
        val encoderHidden = runEncoder(inputIds, attentionMask)
        val results = LinkedHashSet<String>()
        try {
            var attempt = 0
            while (results.size < count && attempt < maxAttempts) {
                val temperature = if (attempt == 0) {
                    0f
                } else {
                    (0.6f + 0.1f * (attempt - 1)).coerceAtMost(1.4f)
                }
                val tokens = decodeOnce(encoderHidden, attentionMask, temperature)
                attempt++
                val text = tokenizer.decode(tokens).trim()
                if (text.isNotEmpty()) results.add(text)
            }
        } finally {
            encoderHidden.close()
        }
        results.toList()
    }

    private fun runEncoder(inputIds: IntArray, attentionMask: LongArray): OnnxTensor {
        val idsTensor = OnnxTensor.createTensor(env, arrayOf(inputIds.map { it.toLong() }.toLongArray()))
        val maskTensor = OnnxTensor.createTensor(env, arrayOf(attentionMask))
        idsTensor.use { ids ->
            maskTensor.use { mask ->
                encoderSession.run(mapOf("input_ids" to ids, "attention_mask" to mask)).use { result ->
                    val hidden = result.iterator().next().value.value as Array<*>
                    // Copy out of the pooled result before it's closed.
                    return cloneFloatTensor(hidden)
                }
            }
        }
    }

    @Suppress("UNCHECKED_CAST")
    private fun cloneFloatTensor(nested: Array<*>): OnnxTensor {
        // nested shape: [batch=1][seq_len][hidden_dim] of Float
        val batch = nested as Array<Array<FloatArray>>
        return OnnxTensor.createTensor(env, batch)
    }

    /**
     * Runs one full decode pass against an already-computed encoder
     * output. Does NOT close [encoderHidden] -- the caller owns its
     * lifecycle since it may be reused across multiple decode attempts
     * (see [generateMany]).
     */
    private fun decodeOnce(
        encoderHidden: OnnxTensor,
        encoderAttentionMask: LongArray,
        temperature: Float
    ): IntArray {
        val encMaskTensor = OnnxTensor.createTensor(env, arrayOf(encoderAttentionMask))
        val generated = ArrayList<Long>()
        generated.add(DECODER_START_TOKEN_ID.toLong())

        try {
            var eosSeen = false
            var step = 0
            while (!eosSeen && step < MAX_NEW_TOKENS) {
                val decoderIdsTensor = OnnxTensor.createTensor(env, arrayOf(generated.toLongArray()))
                val nextId = decoderIdsTensor.use { ids ->
                    decoderSession.run(
                        mapOf(
                            "input_ids" to ids,
                            "encoder_hidden_states" to encoderHidden,
                            "encoder_attention_mask" to encMaskTensor
                        )
                    ).use { result ->
                        val logits = result.iterator().next().value.value as Array<*>
                        if (temperature > 0f) sampleLastStep(logits, temperature) else argmaxLastStep(logits)
                    }
                }
                generated.add(nextId.toLong())
                step++
                if (nextId == 1) eosSeen = true // T5 eos_token_id is conventionally 1 (</s>)
            }
        } finally {
            encMaskTensor.close()
        }
        return generated.map { it.toInt() }.toIntArray()
    }

    @Suppress("UNCHECKED_CAST")
    private fun argmaxLastStep(logits: Array<*>): Int {
        // logits shape: [batch=1][seq_len][vocab_size]
        val batch = logits as Array<Array<FloatArray>>
        val lastStepLogits = batch[0].last()
        var bestIdx = 0
        var bestVal = Float.NEGATIVE_INFINITY
        for (i in lastStepLogits.indices) {
            if (lastStepLogits[i] > bestVal) {
                bestVal = lastStepLogits[i]
                bestIdx = i
            }
        }
        return bestIdx
    }

    @Suppress("UNCHECKED_CAST")
    private fun sampleLastStep(logits: Array<*>, temperature: Float): Int {
        // logits shape: [batch=1][seq_len][vocab_size]. Softmax over
        // logits/temperature, then sample -- higher temperature means
        // flatter distribution, more variety between repeated calls.
        val batch = logits as Array<Array<FloatArray>>
        val lastStepLogits = batch[0].last()
        val scaled = FloatArray(lastStepLogits.size) { lastStepLogits[it] / temperature }
        val maxLogit = scaled.max()
        var sum = 0.0
        val expValues = DoubleArray(scaled.size) { i ->
            val e = kotlin.math.exp((scaled[i] - maxLogit).toDouble())
            sum += e
            e
        }
        val r = random.nextDouble() * sum
        var cumulative = 0.0
        for (i in expValues.indices) {
            cumulative += expValues[i]
            if (cumulative >= r) return i
        }
        return expValues.indices.last()
    }

    fun close() {
        try { encoderSession.close() } catch (_: Exception) {}
        try { decoderSession.close() } catch (_: Exception) {}
        T5ResourceManager.release()
        T5MemoryCleanup.cleanup()
    }
}
