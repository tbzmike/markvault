package com.tebogo.markvault.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.RowScope
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.BottomAppBar
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextField
import androidx.compose.material3.TextFieldDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.navigation.NavController
import com.tebogo.markvault.AppViewModel

/**
 * v5.0.0 — The bottom area of every full-screen surface.
 *
 * Layout (top → bottom):
 *   [persistent compact search field — appears above everything else]
 *   [icon row: back, extras, tabs, browser, home, chat, overflow]
 *
 * Putting a persistent search field at the bottom means the user can
 * launch a search from any screen without first navigating to Home or
 * Search. Tapping the field sets [vm.query] and navigates to "search".
 */
@OptIn(androidx.compose.material3.ExperimentalMaterial3Api::class)
@Composable
fun MarkVaultBottomBar(
    nav: NavController,
    vm: AppViewModel? = null,
    showBack: Boolean = true,
    showBrowser: Boolean = true,
    onBackOverride: (() -> Unit)? = null,
    extraActions: @Composable RowScope.() -> Unit = {}
) {
    Column(Modifier.fillMaxWidth()) {
        // v5.0.0 — Persistent compact search field. Appears on EVERY screen
        // that uses this bottom bar so the user can start a search without
        // first navigating somewhere. Tapping enter sets vm.query and
        // navigates to the full search screen.
        if (vm != null) {
            BottomSearchField(vm = vm, nav = nav)
        }
        BottomAppBar(
            modifier = Modifier.padding(0.dp),
            actions = {
                if (showBack) {
                    IconButton(onClick = {
                        onBackOverride?.invoke() ?: nav.popBackStack()
                    }) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back")
                    }
                }
                extraActions()
                if (vm != null) {
                    TabSwitcherButton(vm, nav)
                }
                if (showBrowser) {
                    IconButton(onClick = {
                        val encUrl = java.net.URLEncoder.encode("https://www.jw.org", "UTF-8")
                        val encLabel = java.net.URLEncoder.encode("jw.org", "UTF-8")
                        nav.navigate("web/$encUrl/$encLabel") {
                            launchSingleTop = true
                        }
                    }) {
                        Text("\uD83C\uDF10", fontSize = 18.sp)
                    }
                }
                HomeButton(nav)
                IconButton(onClick = {
                    nav.navigate("chat") { launchSingleTop = true }
                }) {
                    Text("\uD83D\uDCAC", fontSize = 18.sp)
                }
                OverflowMenu(nav, vm)
            }
        )
    }
}

/**
 * v5.0.0 — The persistent compact search field shown above the icon row.
 *
 * Local state holds the in-progress text; on Enter we write to [vm.query]
 * (so the SearchScreen picks it up) and navigate. Backed by a Surface
 * with rounded corners and slight elevation to make it visually distinct
 * from the rest of the bottom area.
 */
@OptIn(androidx.compose.material3.ExperimentalMaterial3Api::class)
@Composable
private fun BottomSearchField(vm: AppViewModel, nav: NavController) {
    var text by remember { mutableStateOf("") }
    Surface(
        color = MaterialTheme.colorScheme.surface,
        shape = RoundedCornerShape(20.dp),
        tonalElevation = 3.dp,
        shadowElevation = 2.dp,
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 8.dp, vertical = 4.dp)
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Icon(
                Icons.Default.Search,
                contentDescription = null,
                tint = MaterialTheme.colorScheme.onSurfaceVariant,
                modifier = Modifier.padding(start = 12.dp)
            )
            TextField(
                value = text,
                onValueChange = { text = it },
                placeholder = { Text("Search\u2026", fontSize = 13.sp) },
                singleLine = true,
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(end = 4.dp),
                colors = TextFieldDefaults.colors(
                    focusedContainerColor = Color.Transparent,
                    unfocusedContainerColor = Color.Transparent,
                    disabledContainerColor = Color.Transparent,
                    focusedIndicatorColor = Color.Transparent,
                    unfocusedIndicatorColor = Color.Transparent
                ),
                keyboardOptions = KeyboardOptions(imeAction = ImeAction.Search),
                keyboardActions = KeyboardActions(
                    onSearch = {
                        val q = text.trim()
                        if (q.isNotEmpty()) {
                            vm.query.value = q
                            text = ""
                            nav.navigate("search") { launchSingleTop = true }
                        }
                    }
                )
            )
        }
    }
}
