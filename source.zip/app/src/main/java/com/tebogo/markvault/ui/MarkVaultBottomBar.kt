package com.tebogo.markvault.ui

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.RowScope
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.ui.graphics.graphicsLayer
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.BottomAppBar
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TextField
import androidx.compose.material3.TextFieldDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.navigation.NavController
import com.tebogo.markvault.AppViewModel

/**
 * v5.0.0 — The bottom area of every full-screen surface.
 *
 * Layout (top → bottom):
 *   [persistent compact search field — appears above everything else]
 *   [icon row: back, extras, tabs, browser, home, chat, overflow]
 *
 * Putting a persistent search field at the bottom means the user can
 * launch a search from any screen without first navigating to Home or
 * Search. Tapping the field sets [vm.query] and navigates to "search".
 */
@OptIn(androidx.compose.material3.ExperimentalMaterial3Api::class)
@Composable
fun MarkVaultBottomBar(
    nav: NavController,
    vm: AppViewModel? = null,
    showBack: Boolean = true,
    showBrowser: Boolean = true,
    onBackOverride: (() -> Unit)? = null,
    extraActions: @Composable RowScope.() -> Unit = {}
) {
    // v5.4.32 — Detect workspace + tablet width for the compact
    // centered bar variant. Reduces vertical footprint from ~80dp to
    // ~48dp and centers icons instead of right-aligning them, matching
    // the reference tablet UI. Standard mode + narrow width keep the
    // existing thumb-reachable right-aligned taller bar.
    val screenWidthDp = androidx.compose.ui.platform.LocalConfiguration.current.screenWidthDp
    val isTabletWidth = screenWidthDp >= 600
    val uiMode = vm?.uiMode?.collectAsStateWithLifecycle()?.value ?: "standard"
    val compactBar = uiMode == "workspace" && isTabletWidth

    Column(Modifier.fillMaxWidth()) {
        // v5.3.0 — Floating tabs button above the toolbar (Chrome-style).
        // Only renders when 2+ browser tabs are open. Tap opens a
        // full-screen preview.
        if (vm != null) {
            FloatingTabsButton(vm, nav)
        }
        if (compactBar) {
            androidx.compose.material3.Surface(
                color = androidx.compose.material3.BottomAppBarDefaults.containerColor,
                modifier = Modifier.fillMaxWidth()
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(48.dp)
                        .padding(horizontal = 8.dp),
                    verticalAlignment = androidx.compose.ui.Alignment.CenterVertically,
                    horizontalArrangement = androidx.compose.foundation.layout.Arrangement.Center
                ) {
                    if (showBack) {
                        IconButton(onClick = {
                            onBackOverride?.invoke() ?: nav.popBackStack()
                        }) {
                            Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back")
                        }
                    }
                    extraActions()
                    if (vm != null) TabSwitcherButton(vm, nav)
                    if (showBrowser) BrowserButton(vm = vm, nav = nav)
                    HomeButton(nav)
                    if (vm != null) {
                        val chatReady by vm.chatModelInstalled.collectAsStateWithLifecycle()
                        if (chatReady) {
                            IconButton(onClick = {
                                nav.navigate("chat") { launchSingleTop = true }
                            }) {
                                Text("\uD83D\uDCAC", fontSize = 18.sp)
                            }
                        }
                    }
                    OverflowMenu(nav, vm)
                    PumpingSearchButton(nav)
                }
            }
        } else {
        BottomAppBar(
            modifier = Modifier.padding(0.dp),
            actions = {
                // v5.2.0 — Right-align icons. Spacer with weight(1f) pushes
                // everything that follows toward the right edge of the bar,
                // which is closer to the user's thumb on a phone.
                Spacer(Modifier.weight(1f))
                if (showBack) {
                    IconButton(onClick = {
                        onBackOverride?.invoke() ?: nav.popBackStack()
                    }) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back")
                    }
                }
                extraActions()
                if (vm != null) {
                    TabSwitcherButton(vm, nav)
                }
                if (showBrowser) {
                    BrowserButton(vm = vm, nav = nav)
                }
                HomeButton(nav)
                // v5.2.0 — Hide the chat icon entirely when the chat model
                // isn't installed. Showing a feature button that crashes the
                // app when tapped is worse than not showing it at all. The
                // chat model is back inside Settings → On-device chat for
                // anyone who wants to install it.
                if (vm != null) {
                    val chatReady by vm.chatModelInstalled.collectAsStateWithLifecycle()
                    if (chatReady) {
                        IconButton(onClick = {
                            nav.navigate("chat") { launchSingleTop = true }
                        }) {
                            Text("\uD83D\uDCAC", fontSize = 18.sp)
                        }
                    }
                }
                OverflowMenu(nav, vm)
                // v5.3.0 — Pumping search button. Bigger and brighter
                // than other icons; rightmost = closest to right thumb.
                PumpingSearchButton(nav)
            }
        )
        }
    }
}

/**
 * v5.3.0 — Bigger, brighter, heart-pumping search button.
 *
 * Lives at the rightmost position of the bottom toolbar (thumb-friendly
 * on a phone) and is the visually-dominant action: ~50% larger than the
 * other icons, primary-color tint, and a continuous gentle scale pulse
 * so it reads as the most important affordance on the screen. Tap →
 * navigate to the Search screen.
 */
@Composable
private fun PumpingSearchButton(nav: NavController) {
    val pump = rememberInfiniteTransition(label = "search-pump")
    val scale by pump.animateFloat(
        initialValue = 1f,
        targetValue = 1.18f,
        animationSpec = infiniteRepeatable(
            animation = tween(durationMillis = 750),
            repeatMode = RepeatMode.Reverse
        ),
        label = "search-pump-scale"
    )
    IconButton(
        onClick = { nav.navigate("search") { launchSingleTop = true } },
        modifier = Modifier
            .size(56.dp)
            .graphicsLayer { scaleX = scale; scaleY = scale }
    ) {
        Icon(
            Icons.Default.Search,
            contentDescription = "Search",
            tint = MaterialTheme.colorScheme.primary,
            modifier = Modifier.size(30.dp)
        )
    }
}

/**
 * v5.3.0 — Globe button. Simplified: always navigates to the browser
 * screen. Tab management (preview, switch, close) lives on the floating
 * tabs button above the toolbar (see FloatingTabsButton).
 */
@Composable
private fun BrowserButton(
    vm: AppViewModel?,
    nav: NavController
) {
    IconButton(onClick = {
        val tabs = vm?.webTabs
        if (tabs.isNullOrEmpty()) {
            val encUrl = java.net.URLEncoder.encode("https://www.jw.org", "UTF-8")
            val encLabel = java.net.URLEncoder.encode("jw.org", "UTF-8")
            nav.navigate("web/$encUrl/$encLabel") { launchSingleTop = true }
        } else {
            val activeIdx = vm.webActiveTabIdx.coerceIn(0, tabs.size - 1)
            val active = tabs[activeIdx]
            val encUrl = java.net.URLEncoder.encode(active.url, "UTF-8")
            val encLabel = java.net.URLEncoder.encode(active.title.ifBlank { "Tab" }, "UTF-8")
            nav.navigate("web/$encUrl/$encLabel") { launchSingleTop = true }
        }
    }) {
        Text("\uD83C\uDF10", fontSize = 18.sp)
    }
}

/**
 * v5.3.0 — Floating tabs button hovering above the toolbar.
 *
 * Only renders when 2+ browser tabs are open. Shows the tab count and,
 * when tapped, opens TabPreviewDialog — a Chrome-style preview of all
 * open tabs as cards, in a grid that respects the user's orientation
 * preference. Positioned on the right side of the screen for
 * thumb-friendliness.
 */
@Composable
private fun FloatingTabsButton(
    vm: AppViewModel,
    nav: NavController
) {
    var previewOpen by remember { mutableStateOf(false) }
    val tabCount = vm.webTabs.size
    // v5.4.0 — Always visible. Even with zero web tabs the button shows
    // and tapping opens the preview overlay (which then shows an empty
    // state with a "+ Open browser" CTA).

    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(end = 12.dp, bottom = 4.dp),
        horizontalArrangement = androidx.compose.foundation.layout.Arrangement.End
    ) {
        Surface(
            color = MaterialTheme.colorScheme.primary,
            shape = RoundedCornerShape(percent = 50),
            shadowElevation = 8.dp,
            tonalElevation = 6.dp,
            modifier = Modifier.clickable {
                // v5.3.1 — Best-effort capture of the currently-visible
                // browser tab right before showing previews, so the cell
                // for the active tab shows fresh content rather than the
                // last-onPageFinished snapshot (which may be 30s stale).
                val activeIdx = vm.webActiveTabIdx
                val activeId = vm.webTabs.getOrNull(activeIdx)?.id
                if (activeId != null) {
                    val view = vm.peekActiveWebView()
                    if (view != null) vm.saveWebTabThumbnail(activeId, view)
                }
                previewOpen = true
            }
        ) {
            Row(
                modifier = Modifier.padding(horizontal = 14.dp, vertical = 8.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text("\uD83D\uDDC2", fontSize = 16.sp)
                Spacer(Modifier.width(6.dp))
                Text(
                    "$tabCount tabs",
                    fontSize = 13.sp,
                    fontWeight = FontWeight.SemiBold,
                    color = MaterialTheme.colorScheme.onPrimary
                )
            }
        }
    }

    if (previewOpen) {
        TabPreviewDialog(
            vm = vm,
            nav = nav,
            onDismiss = { previewOpen = false }
        )
    }
}

/**
 * v5.3.0 — Chrome-style tab preview overlay.
 *
 * Full-screen Dialog showing every open browser tab as a card. Each card
 * has title, host, a coloured placeholder header, and a close button.
 * Tapping a card switches to that tab and dismisses the dialog.
 *
 * Layout follows AppViewModel.tabsPreviewOrientation:
 *   - "vertical"   = LazyColumn of pairs (2 cards per row, scrolls down)
 *   - "horizontal" = LazyRow (swipe side-to-side through full-height cards)
 *
 * Setting toggled from Settings (Browser tabs section).
 */
@Composable
private fun TabPreviewDialog(
    vm: AppViewModel,
    nav: NavController,
    onDismiss: () -> Unit
) {
    val orientation by vm.tabsPreviewOrientation.collectAsStateWithLifecycle()
    androidx.compose.ui.window.Dialog(
        onDismissRequest = onDismiss,
        properties = androidx.compose.ui.window.DialogProperties(
            usePlatformDefaultWidth = false
        )
    ) {
        Surface(
            color = MaterialTheme.colorScheme.surface,
            modifier = Modifier
                .fillMaxSize()
                .padding(8.dp),
            shape = RoundedCornerShape(16.dp)
        ) {
            Column(Modifier.fillMaxSize()) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 16.dp, vertical = 10.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        "\uD83D\uDDC2  ${vm.webTabs.size} open tabs",
                        fontSize = 17.sp,
                        fontWeight = FontWeight.Bold,
                        modifier = Modifier.weight(1f)
                    )
                    IconButton(onClick = onDismiss) {
                        Text("\u2715", fontSize = 18.sp)
                    }
                }
                androidx.compose.material3.HorizontalDivider()
                Box(
                    modifier = Modifier
                        .weight(1f)
                        .fillMaxWidth()
                ) {
                    if (vm.webTabs.isEmpty()) {
                        // v5.4.0 — Empty state. The button is always visible
                        // (even with 0 tabs) so the dialog must handle the
                        // no-tabs case gracefully.
                        Column(
                            modifier = Modifier
                                .fillMaxSize()
                                .padding(28.dp),
                            verticalArrangement = androidx.compose.foundation.layout.Arrangement.Center,
                            horizontalAlignment = Alignment.CenterHorizontally
                        ) {
                            Text("\uD83C\uDF10", fontSize = 64.sp)
                            Spacer(Modifier.height(14.dp))
                            Text(
                                "No browser tabs",
                                fontSize = 17.sp,
                                fontWeight = FontWeight.SemiBold
                            )
                            Spacer(Modifier.height(6.dp))
                            Text(
                                "Open jw.org or wol.jw.org and the tab will appear here.",
                                fontSize = 13.sp,
                                color = MaterialTheme.colorScheme.onSurfaceVariant,
                                textAlign = androidx.compose.ui.text.style.TextAlign.Center
                            )
                            Spacer(Modifier.height(20.dp))
                            androidx.compose.material3.Button(onClick = {
                                onDismiss()
                                val encUrl = java.net.URLEncoder.encode("https://www.jw.org", "UTF-8")
                                val encLabel = java.net.URLEncoder.encode("jw.org", "UTF-8")
                                nav.navigate("web/$encUrl/$encLabel") { launchSingleTop = true }
                            }) {
                                Text("\uD83C\uDF10  Open browser")
                            }
                        }
                    } else if (orientation == "horizontal") {
                        TabPreviewHorizontal(vm, nav, onDismiss)
                    } else {
                        TabPreviewVertical(vm, nav, onDismiss)
                    }
                }
                androidx.compose.material3.HorizontalDivider()
                TextButton(
                    onClick = {
                        onDismiss()
                        val encUrl = java.net.URLEncoder.encode("https://www.jw.org", "UTF-8")
                        val encLabel = java.net.URLEncoder.encode("jw.org", "UTF-8")
                        nav.navigate("web/$encUrl/$encLabel") { launchSingleTop = true }
                    },
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(8.dp)
                ) { Text("\u2795  New tab (jw.org)") }
            }
        }
    }
}

@Composable
private fun TabPreviewVertical(
    vm: AppViewModel,
    nav: NavController,
    onDismiss: () -> Unit
) {
    val tabs = vm.webTabs
    val pairs = remember(tabs.size) {
        val out = mutableListOf<Pair<Int, Int?>>()
        var i = 0
        while (i < tabs.size) {
            out.add(i to if (i + 1 < tabs.size) i + 1 else null)
            i += 2
        }
        out
    }
    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(10.dp),
        verticalArrangement = androidx.compose.foundation.layout.Arrangement.spacedBy(10.dp)
    ) {
        items(pairs) { (a, b) ->
            Row(
                Modifier.fillMaxWidth(),
                horizontalArrangement = androidx.compose.foundation.layout.Arrangement.spacedBy(10.dp)
            ) {
                TabPreviewCard(
                    vm = vm, nav = nav, idx = a,
                    onDismiss = onDismiss,
                    modifier = Modifier.weight(1f)
                )
                if (b != null) {
                    TabPreviewCard(
                        vm = vm, nav = nav, idx = b,
                        onDismiss = onDismiss,
                        modifier = Modifier.weight(1f)
                    )
                } else {
                    Spacer(Modifier.weight(1f))
                }
            }
        }
    }
}

@Composable
private fun TabPreviewHorizontal(
    vm: AppViewModel,
    nav: NavController,
    onDismiss: () -> Unit
) {
    LazyRow(
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(10.dp),
        horizontalArrangement = androidx.compose.foundation.layout.Arrangement.spacedBy(10.dp)
    ) {
        itemsIndexed(vm.webTabs.toList()) { idx, _ ->
            TabPreviewCard(
                vm = vm, nav = nav, idx = idx,
                onDismiss = onDismiss,
                modifier = Modifier
                    .width(260.dp)
                    .fillMaxHeight()
            )
        }
    }
}

@Composable
private fun TabPreviewCard(
    vm: AppViewModel,
    nav: NavController,
    idx: Int,
    onDismiss: () -> Unit,
    modifier: Modifier = Modifier
) {
    if (idx !in vm.webTabs.indices) return
    val tab = vm.webTabs[idx]
    val host = remember(tab.url) {
        runCatching { android.net.Uri.parse(tab.url).host ?: "Link" }.getOrDefault("Link")
    }
    val isActive = idx == vm.webActiveTabIdx
    val hue = remember(tab.url) { ((tab.url.hashCode() and 0x7fffffff) % 360).toFloat() }
    val placeholderColor = Color.hsv(hue, 0.45f, 0.55f)
    // v5.3.1 — Look up a captured screenshot of this tab if we have one.
    // Decoded each composition because vm.webTabThumbnails is a
    // SnapshotStateMap (so the cell recomposes when a fresh capture lands).
    val thumbBytes = vm.webTabThumbnails[tab.id]
    val thumbBitmap: androidx.compose.ui.graphics.ImageBitmap? =
        remember(tab.id, thumbBytes?.size) {
            if (thumbBytes == null) null
            else runCatching {
                val bm = android.graphics.BitmapFactory.decodeByteArray(
                    thumbBytes, 0, thumbBytes.size
                ) ?: return@runCatching null
                bm.asImageBitmap()
            }.getOrNull()
        }

    Surface(
        color = MaterialTheme.colorScheme.surfaceVariant,
        shape = RoundedCornerShape(12.dp),
        tonalElevation = if (isActive) 6.dp else 2.dp,
        shadowElevation = if (isActive) 8.dp else 3.dp,
        border = if (isActive)
            BorderStroke(2.dp, MaterialTheme.colorScheme.primary)
        else null,
        modifier = modifier
    ) {
        Column(Modifier.fillMaxWidth()) {
            Box(
                Modifier
                    .fillMaxWidth()
                    .height(150.dp)
                    .background(placeholderColor)
                    .clickable {
                        vm.setWebActiveTab(idx)
                        onDismiss()
                        val encUrl = java.net.URLEncoder.encode(tab.url, "UTF-8")
                        val encLabel = java.net.URLEncoder.encode(
                            tab.title.ifBlank { "Tab" }, "UTF-8"
                        )
                        nav.navigate("web/$encUrl/$encLabel") { launchSingleTop = true }
                    },
                contentAlignment = Alignment.Center
            ) {
                if (thumbBitmap != null) {
                    androidx.compose.foundation.Image(
                        bitmap = thumbBitmap,
                        contentDescription = "Thumbnail of ${tab.title.ifBlank { host }}",
                        contentScale = androidx.compose.ui.layout.ContentScale.Crop,
                        modifier = Modifier.fillMaxSize()
                    )
                } else {
                    Text("\uD83C\uDF10", fontSize = 38.sp)
                }
            }
            Row(
                Modifier
                    .fillMaxWidth()
                    .padding(start = 10.dp, end = 4.dp, top = 6.dp, bottom = 6.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column(Modifier.weight(1f)) {
                    Text(
                        tab.title.ifBlank { host },
                        fontSize = 13.sp,
                        fontWeight = FontWeight.SemiBold,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis,
                        color = MaterialTheme.colorScheme.onSurface
                    )
                    Text(
                        host,
                        fontSize = 10.sp,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                }
                IconButton(
                    onClick = { vm.closeBrowserTab(idx) },
                    modifier = Modifier.size(32.dp)
                ) {
                    Text("\u2715", fontSize = 14.sp)
                }
            }
        }
    }
}
