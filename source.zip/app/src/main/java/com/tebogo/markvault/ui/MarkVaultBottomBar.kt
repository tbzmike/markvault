package com.tebogo.markvault.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.RowScope
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.ui.graphics.graphicsLayer
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.BottomAppBar
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextField
import androidx.compose.material3.TextFieldDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.navigation.NavController
import com.tebogo.markvault.AppViewModel

/**
 * v5.0.0 — The bottom area of every full-screen surface.
 *
 * Layout (top → bottom):
 *   [persistent compact search field — appears above everything else]
 *   [icon row: back, extras, tabs, browser, home, chat, overflow]
 *
 * Putting a persistent search field at the bottom means the user can
 * launch a search from any screen without first navigating to Home or
 * Search. Tapping the field sets [vm.query] and navigates to "search".
 */
@OptIn(androidx.compose.material3.ExperimentalMaterial3Api::class)
@Composable
fun MarkVaultBottomBar(
    nav: NavController,
    vm: AppViewModel? = null,
    showBack: Boolean = true,
    showBrowser: Boolean = true,
    onBackOverride: (() -> Unit)? = null,
    extraActions: @Composable RowScope.() -> Unit = {}
) {
    Column(Modifier.fillMaxWidth()) {
        // v5.0.0 — Persistent compact search field. Appears on EVERY screen
        // that uses this bottom bar so the user can start a search without
        // first navigating somewhere. Tapping enter sets vm.query and
        // navigates to the full search screen.
        if (vm != null) {
            BottomSearchField(vm = vm, nav = nav)
        }
        BottomAppBar(
            modifier = Modifier.padding(0.dp),
            actions = {
                // v5.2.0 — Right-align icons. Spacer with weight(1f) pushes
                // everything that follows toward the right edge of the bar,
                // which is closer to the user's thumb on a phone.
                Spacer(Modifier.weight(1f))
                if (showBack) {
                    IconButton(onClick = {
                        onBackOverride?.invoke() ?: nav.popBackStack()
                    }) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back")
                    }
                }
                extraActions()
                if (vm != null) {
                    TabSwitcherButton(vm, nav)
                }
                if (showBrowser) {
                    BrowserButtonWithTabsPreview(vm = vm, nav = nav)
                }
                HomeButton(nav)
                // v5.2.0 — Hide the chat icon entirely when the chat model
                // isn't installed. Showing a feature button that crashes the
                // app when tapped is worse than not showing it at all. The
                // chat model is back inside Settings → On-device chat for
                // anyone who wants to install it.
                if (vm != null) {
                    val chatReady by vm.chatModelInstalled.collectAsStateWithLifecycle()
                    if (chatReady) {
                        IconButton(onClick = {
                            nav.navigate("chat") { launchSingleTop = true }
                        }) {
                            Text("\uD83D\uDCAC", fontSize = 18.sp)
                        }
                    }
                }
                OverflowMenu(nav, vm)
            }
        )
    }
}

/**
 * v5.0.0 — The persistent compact search field shown above the icon row.
 *
 * Local state holds the in-progress text; on Enter we write to [vm.query]
 * (so the SearchScreen picks it up) and navigate. Backed by a Surface
 * with rounded corners and slight elevation to make it visually distinct
 * from the rest of the bottom area.
 */
@OptIn(androidx.compose.material3.ExperimentalMaterial3Api::class)
@Composable
private fun BottomSearchField(vm: AppViewModel, nav: NavController) {
    var text by remember { mutableStateOf("") }

    // v5.2.0 — Subtle "heart-pumping" animation. The whole pill gently
    // scales between 1.00 and 1.04 over 800ms, giving the search field a
    // gentle living/breathing presence so the user notices it as the
    // primary call-to-action on any screen.
    val pump = rememberInfiniteTransition(
        label = "search-pump"
    )
    val scale by pump.animateFloat(
        initialValue = 1f,
        targetValue = 1.04f,
        animationSpec = infiniteRepeatable(
            animation = tween(
                durationMillis = 800
            ),
            repeatMode = RepeatMode.Reverse
        ),
        label = "search-pump-scale"
    )

    Surface(
        color = MaterialTheme.colorScheme.surface,
        shape = RoundedCornerShape(22.dp),
        tonalElevation = 4.dp,
        shadowElevation = 3.dp,
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 8.dp, vertical = 6.dp)
            .graphicsLayer {
                scaleX = scale
                scaleY = scale
            }
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Icon(
                Icons.Default.Search,
                contentDescription = null,
                tint = MaterialTheme.colorScheme.primary,
                modifier = Modifier.padding(start = 14.dp)
            )
            TextField(
                value = text,
                onValueChange = { text = it },
                placeholder = { Text("Search\u2026", fontSize = 15.sp) },
                singleLine = true,
                textStyle = androidx.compose.ui.text.TextStyle(fontSize = 15.sp),
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(end = 4.dp),
                colors = TextFieldDefaults.colors(
                    focusedContainerColor = Color.Transparent,
                    unfocusedContainerColor = Color.Transparent,
                    disabledContainerColor = Color.Transparent,
                    focusedIndicatorColor = Color.Transparent,
                    unfocusedIndicatorColor = Color.Transparent
                ),
                keyboardOptions = KeyboardOptions(imeAction = ImeAction.Search),
                keyboardActions = KeyboardActions(
                    onSearch = {
                        val q = text.trim()
                        if (q.isNotEmpty()) {
                            vm.query.value = q
                            text = ""
                            nav.navigate("search") { launchSingleTop = true }
                        }
                    }
                )
            )
        }
    }
}

/**
 * v5.1.0 — Globe button that conditionally shows a tab picker.
 *
 * Behaviour:
 *   - 0 tabs open  → opens jw.org as the first browser tab
 *   - 1 tab open   → navigates straight into the browser screen (that one tab)
 *   - 2+ tabs open → shows a bottom sheet listing all open tabs with
 *                    titles, URLs, an open icon, and a close button (×).
 *                    The user picks which tab to open or closes any
 *                    they don't want anymore.
 *
 * The tab list itself lives on the [AppViewModel.webTabs] state; closing
 * a tab calls [AppViewModel.closeBrowserTab]; switching to a tab calls
 * [AppViewModel.setWebActiveTab] then navigates into the browser.
 */
@OptIn(androidx.compose.material3.ExperimentalMaterial3Api::class)
@Composable
private fun BrowserButtonWithTabsPreview(
    vm: AppViewModel?,
    nav: androidx.navigation.NavController
) {
    var pickerOpen by remember { mutableStateOf(false) }

    androidx.compose.material3.IconButton(onClick = {
        val tabs = vm?.webTabs
        when {
            tabs.isNullOrEmpty() -> {
                val encUrl = java.net.URLEncoder.encode("https://www.jw.org", "UTF-8")
                val encLabel = java.net.URLEncoder.encode("jw.org", "UTF-8")
                nav.navigate("web/$encUrl/$encLabel") {
                    launchSingleTop = true
                }
            }
            tabs.size == 1 -> {
                val t = tabs[0]
                val encUrl = java.net.URLEncoder.encode(t.url, "UTF-8")
                val encLabel = java.net.URLEncoder.encode(t.title.ifBlank { "Tab" }, "UTF-8")
                nav.navigate("web/$encUrl/$encLabel") {
                    launchSingleTop = true
                }
            }
            else -> {
                pickerOpen = true
            }
        }
    }) {
        // Show "🌐" plus a small badge with the tab count when >1 tab open.
        // The badge gives a glanceable sense that there are multiple
        // sessions to pick from.
        val tabCount = vm?.webTabs?.size ?: 0
        if (tabCount > 1) {
            androidx.compose.foundation.layout.Box(
                contentAlignment = androidx.compose.ui.Alignment.Center
            ) {
                Text("\uD83C\uDF10", fontSize = 18.sp)
                androidx.compose.material3.Surface(
                    color = androidx.compose.material3.MaterialTheme.colorScheme.primary,
                    shape = androidx.compose.foundation.shape.CircleShape,
                    modifier = androidx.compose.ui.Modifier
                        .size(14.dp)
                        .offset(x = 8.dp, y = (-8).dp)
                ) {
                    androidx.compose.foundation.layout.Box(
                        contentAlignment = androidx.compose.ui.Alignment.Center,
                        modifier = androidx.compose.ui.Modifier
                            .fillMaxSize()
                    ) {
                        Text(
                            "$tabCount",
                            fontSize = 9.sp,
                            color = androidx.compose.material3.MaterialTheme.colorScheme.onPrimary
                        )
                    }
                }
            }
        } else {
            Text("\uD83C\uDF10", fontSize = 18.sp)
        }
    }

    if (pickerOpen && vm != null) {
        androidx.compose.material3.ModalBottomSheet(
            onDismissRequest = { pickerOpen = false }
        ) {
            Column(
                modifier = androidx.compose.ui.Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 14.dp, vertical = 8.dp)
            ) {
                Text(
                    "Open browser tabs (${vm.webTabs.size})",
                    fontSize = 14.sp,
                    fontWeight = androidx.compose.ui.text.font.FontWeight.SemiBold,
                    modifier = androidx.compose.ui.Modifier.padding(bottom = 8.dp)
                )
                vm.webTabs.forEachIndexed { idx, tab ->
                    Row(
                        modifier = androidx.compose.ui.Modifier
                            .fillMaxWidth()
                            .padding(vertical = 4.dp),
                        verticalAlignment = androidx.compose.ui.Alignment.CenterVertically
                    ) {
                        androidx.compose.material3.Surface(
                            color = androidx.compose.material3.MaterialTheme.colorScheme.surfaceVariant,
                            shape = androidx.compose.foundation.shape.RoundedCornerShape(8.dp),
                            modifier = androidx.compose.ui.Modifier
                                .weight(1f)
                                .clickable {
                                    vm.setWebActiveTab(idx)
                                    pickerOpen = false
                                    val encUrl = java.net.URLEncoder.encode(tab.url, "UTF-8")
                                    val encLabel = java.net.URLEncoder.encode(
                                        tab.title.ifBlank { "Tab" }, "UTF-8"
                                    )
                                    nav.navigate("web/$encUrl/$encLabel") {
                                        launchSingleTop = true
                                    }
                                }
                        ) {
                            Column(
                                modifier = androidx.compose.ui.Modifier
                                    .padding(horizontal = 12.dp, vertical = 10.dp)
                            ) {
                                Text(
                                    tab.title.ifBlank { tab.url },
                                    fontSize = 14.sp,
                                    fontWeight = androidx.compose.ui.text.font.FontWeight.SemiBold,
                                    maxLines = 1,
                                    overflow = androidx.compose.ui.text.style.TextOverflow.Ellipsis
                                )
                                Text(
                                    tab.url,
                                    fontSize = 11.sp,
                                    color = androidx.compose.material3.MaterialTheme.colorScheme.onSurfaceVariant,
                                    maxLines = 1,
                                    overflow = androidx.compose.ui.text.style.TextOverflow.Ellipsis
                                )
                            }
                        }
                        androidx.compose.material3.IconButton(
                            onClick = { vm.closeBrowserTab(idx) }
                        ) {
                            Text("\u2715", fontSize = 16.sp)
                        }
                    }
                }
                androidx.compose.foundation.layout.Spacer(
                    androidx.compose.ui.Modifier.height(8.dp)
                )
                androidx.compose.material3.TextButton(
                    onClick = {
                        pickerOpen = false
                        val encUrl = java.net.URLEncoder.encode("https://www.jw.org", "UTF-8")
                        val encLabel = java.net.URLEncoder.encode("jw.org", "UTF-8")
                        nav.navigate("web/$encUrl/$encLabel") { launchSingleTop = true }
                    },
                    modifier = androidx.compose.ui.Modifier.fillMaxWidth()
                ) { Text("\u2795  New tab (jw.org)") }
            }
        }
    }
}
