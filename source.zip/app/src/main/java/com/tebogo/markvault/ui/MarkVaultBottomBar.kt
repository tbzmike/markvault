package com.tebogo.markvault.ui

import androidx.compose.foundation.layout.RowScope
import androidx.compose.foundation.layout.padding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material3.BottomAppBar
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.navigation.NavController
import com.tebogo.markvault.AppViewModel

/**
 * The standard bottom toolbar used by every full-screen surface in the app.
 *
 * Layout (left → right):
 *   [← back]   <extraActions>   [🏠 home]   [⋮ overflow]
 *
 * Putting the toolbar at the bottom keeps every action within thumb reach on
 * modern tall phones — far more comfortable than reaching up to a `TopAppBar`
 * sitting near the status bar.
 *
 * Screens supply their own per-screen icons via [extraActions]. The back / home /
 * overflow controls are universal so they're always present.
 *
 * @param showBack false on Home (where there's nothing to go back to)
 * @param onBackOverride a custom back handler — use when popBackStack isn't right
 */
@Composable
fun MarkVaultBottomBar(
    nav: NavController,
    vm: AppViewModel? = null,
    showBack: Boolean = true,
    onBackOverride: (() -> Unit)? = null,
    extraActions: @Composable RowScope.() -> Unit = {}
) {
    BottomAppBar(
        modifier = Modifier.padding(0.dp),
        actions = {
            if (showBack) {
                IconButton(onClick = {
                    onBackOverride?.invoke() ?: nav.popBackStack()
                }) {
                    Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back")
                }
            }
            extraActions()
            HomeButton(nav)
            OverflowMenu(nav, vm)
        }
    )
}
