package com.tebogo.markvault.ui

import androidx.compose.foundation.layout.RowScope
import androidx.compose.foundation.layout.padding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material3.BottomAppBar
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.navigation.NavController
import com.tebogo.markvault.AppViewModel

/**
 * The standard bottom toolbar used by every full-screen surface in the app.
 *
 * Layout (left → right):
 *   [← back]   <extraActions>   [\uD83C\uDF10 browser]   [\uD83C\uDFE0 home]   [\u22EE overflow]
 *
 * Putting the toolbar at the bottom keeps every action within thumb reach on
 * modern tall phones — far more comfortable than reaching up to a `TopAppBar`
 * sitting near the status bar.
 *
 * The browser button (TASK 4) is now part of the default toolbar set so jw.org
 * is reachable from every screen with one tap. Its tab session lives on the VM
 * so reopening the browser brings back the exact tabs the user had open.
 *
 * Screens supply their own per-screen icons via [extraActions]. The back / home /
 * overflow controls are universal so they're always present.
 *
 * @param showBack false on Home (where there's nothing to go back to)
 * @param onBackOverride a custom back handler — use when popBackStack isn't right
 * @param showBrowser set false on the WebSearchScreen itself so we don't loop
 */
@Composable
fun MarkVaultBottomBar(
    nav: NavController,
    vm: AppViewModel? = null,
    showBack: Boolean = true,
    showBrowser: Boolean = true,
    onBackOverride: (() -> Unit)? = null,
    extraActions: @Composable RowScope.() -> Unit = {}
) {
    BottomAppBar(
        modifier = Modifier.padding(0.dp),
        actions = {
            if (showBack) {
                IconButton(onClick = {
                    onBackOverride?.invoke() ?: nav.popBackStack()
                }) {
                    Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back")
                }
            }
            extraActions()
            if (showBrowser) {
                // TASK 4: persistent browser launcher — accessible from every screen,
                // just like the Home button. Tabs survive the round-trip thanks to
                // VM-hosted session state.
                IconButton(onClick = {
                    val encUrl = java.net.URLEncoder.encode("https://www.jw.org", "UTF-8")
                    val encLabel = java.net.URLEncoder.encode("jw.org", "UTF-8")
                    nav.navigate("web/$encUrl/$encLabel") {
                        launchSingleTop = true
                    }
                }) {
                    Text("\uD83C\uDF10", fontSize = 18.sp)
                }
            }
            HomeButton(nav)
            OverflowMenu(nav, vm)
        }
    )
}
