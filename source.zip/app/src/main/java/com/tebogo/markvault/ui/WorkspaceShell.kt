package com.tebogo.markvault.ui

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.basicMarquee
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.gestures.detectDragGesturesAfterLongPress
import androidx.compose.foundation.gestures.detectHorizontalDragGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.layout.wrapContentHeight
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Menu
import androidx.compose.material.icons.filled.MoreVert
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.VerticalDivider
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.rotate
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalConfiguration
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.input.key.Key
import androidx.compose.ui.input.key.KeyEventType
import androidx.compose.ui.input.key.isCtrlPressed
import androidx.compose.ui.input.key.isMetaPressed
import androidx.compose.ui.input.key.key
import androidx.compose.ui.input.key.onPreviewKeyEvent
import androidx.compose.ui.input.key.type
import androidx.compose.ui.text.font.FontStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.withContext
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.navigation.NavController
import androidx.navigation.compose.currentBackStackEntryAsState
import com.tebogo.markvault.AppViewModel
import com.tebogo.markvault.TabInfo
import com.tebogo.markvault.data.NoteMeta
import com.tebogo.markvault.data.Note
import com.tebogo.markvault.data.LinkedNote
import com.tebogo.markvault.OutlineItem
import com.tebogo.markvault.data.TopicCard

/**
 * v5.4.324cc — Obsidian-style tablet Workspace shell with protected centre-pane layout.
 *
 * This is deliberately a *layout* layer, not a second navigation stack.  The
 * existing NavHost remains the single source of truth for screen navigation,
 * while the shell adds the pieces that make Workspace mode behave like a
 * tablet/desktop workspace: ribbon, collapsible navigator, document tabs and
 * a right inspector frame.  Standard mode bypasses this composable entirely.
 */
@Composable
fun WorkspaceTabletShell(
    vm: AppViewModel,
    nav: NavController,
    content: @Composable () -> Unit
) {
    val uiMode by vm.uiMode.collectAsStateWithLifecycle()
    val forceTabletUi by vm.forceWorkspaceTabletUi.collectAsStateWithLifecycle()
    val configuration = LocalConfiguration.current
    val nativeTablet = configuration.screenWidthDp >= 600
    val tablet = nativeTablet || forceTabletUi
    if (uiMode != "workspace" || !tablet) {
        content()
        return
    }

    val tabs by vm.tabs.collectAsStateWithLifecycle()
    val activeTab by vm.activeTab.collectAsStateWithLifecycle()
    val pinnedTabIds by vm.workspacePinnedTabIds.collectAsStateWithLifecycle()
    val recentlyClosedTabs by vm.recentlyClosedTabs.collectAsStateWithLifecycle()
    val recent by vm.recent.collectAsStateWithLifecycle()
    val notes by vm.notes.collectAsStateWithLifecycle()
    val favourites by vm.favouriteNotes.collectAsStateWithLifecycle()
    val favouriteIds by vm.favouriteIds.collectAsStateWithLifecycle()
    val topics by vm.topics.collectAsStateWithLifecycle()
    val workspaceSearchResults by vm.results.collectAsStateWithLifecycle()
    val navigatorOpen by vm.workspaceNavOpen.collectAsStateWithLifecycle()
    val navigatorSection by vm.workspaceNavSection.collectAsStateWithLifecycle()
    val compactRows by vm.workspaceCompact.collectAsStateWithLifecycle()
    val storedNavigatorWidth by vm.workspaceNavWidth.collectAsStateWithLifecycle()
    val storedInspectorWidth by vm.workspaceInspectorWidth.collectAsStateWithLifecycle()
    val inspectorOpen by vm.workspaceInspectorOpen.collectAsStateWithLifecycle()
    val workspaceBoldText by vm.workspaceBoldText.collectAsStateWithLifecycle()
    val immersiveViewEnabled by vm.immersiveViewEnabled.collectAsStateWithLifecycle()
    // v5.4.324cc — Protect the centre workspace. On normal tablets the side
    // panes are overlays (Obsidian tablet behaviour) so opening Files/Inspector
    // never crushes an article, Search, Graph, or Media Library into a narrow
    // strip. Only very wide windows dock panes beside the document.
    val dockSidePanels = nativeTablet && configuration.screenWidthDp >= 1400
    // Forced tablet UI keeps the same tablet components on narrow portrait/landscape screens,
    // but scales overlay panels to the available canvas instead of falling back to phone UI.
    val forcedNarrow = forceTabletUi && !nativeTablet
    val narrowSafeWidth = (configuration.screenWidthDp - 44f).coerceAtLeast(220f)
    val narrowNavigatorFloor = minOf(260f, narrowSafeWidth)
    val narrowInspectorFloor = minOf(270f, narrowSafeWidth)
    val minNavigatorWidth = if (forcedNarrow) (configuration.screenWidthDp * 0.76f).coerceIn(narrowNavigatorFloor, narrowSafeWidth) else 380f
    val minInspectorWidth = if (forcedNarrow) (configuration.screenWidthDp * 0.80f).coerceIn(narrowInspectorFloor, narrowSafeWidth) else 400f
    val maxNavigatorWidth = if (forcedNarrow) {
        (configuration.screenWidthDp * 0.88f).coerceIn(minNavigatorWidth, narrowSafeWidth)
    } else {
        maxOf(minNavigatorWidth, (configuration.screenWidthDp * 0.62f).coerceAtMost(560f))
    }
    val maxInspectorWidth = if (forcedNarrow) {
        (configuration.screenWidthDp * 0.90f).coerceIn(minInspectorWidth, narrowSafeWidth)
    } else {
        maxOf(minInspectorWidth, (configuration.screenWidthDp * 0.62f).coerceAtMost(580f))
    }
    var navigatorWidth by rememberSaveable { mutableStateOf(storedNavigatorWidth.coerceIn(minNavigatorWidth, maxNavigatorWidth)) }
    var inspectorWidth by rememberSaveable { mutableStateOf(storedInspectorWidth.coerceIn(minInspectorWidth, maxInspectorWidth)) }
    val backStackEntry by nav.currentBackStackEntryAsState()
    val route = backStackEntry?.destination?.route.orEmpty()

    var commandPaletteOpen by rememberSaveable { mutableStateOf(false) }
    var verticalEdgeTabs by rememberSaveable { mutableStateOf(false) }

    LaunchedEffect(storedNavigatorWidth, maxNavigatorWidth) {
        navigatorWidth = storedNavigatorWidth.coerceIn(minNavigatorWidth, maxNavigatorWidth)
    }
    LaunchedEffect(storedInspectorWidth, maxInspectorWidth) {
        inspectorWidth = storedInspectorWidth.coerceIn(minInspectorWidth, maxInspectorWidth)
    }
    LaunchedEffect(route) {
        val contentRoute = route.startsWith("reader") || route.startsWith("pdfReader") ||
            route.startsWith("htmlReader") || route.startsWith("splitReader") ||
            route == "search" || route == "jwVideos" || route == "workspacePanes" || route.startsWith("mediaPlayer")
        if (contentRoute) {
            if (navigatorOpen) vm.setWorkspaceNavOpen(false)
            if (inspectorOpen) vm.setWorkspaceInspectorOpen(false)
        }
    }

    fun setNavigatorOpen(open: Boolean) {
        if (open && !dockSidePanels && inspectorOpen) vm.setWorkspaceInspectorOpen(false)
        vm.setWorkspaceNavOpen(open)
    }
    fun setInspectorOpen(open: Boolean) {
        if (open && !dockSidePanels && navigatorOpen) vm.setWorkspaceNavOpen(false)
        vm.setWorkspaceInspectorOpen(open)
    }
    fun selectNavigatorSection(section: String) {
        vm.setWorkspaceNavSection(section)
        if (!navigatorOpen) setNavigatorOpen(true)
    }

    val workspaceRootModifier = if (immersiveViewEnabled) {
        Modifier.fillMaxSize()
    } else {
        Modifier.fillMaxSize().statusBarsPadding()
    }
    Surface(
        modifier = workspaceRootModifier
            .onPreviewKeyEvent { event ->
                val openShortcut = event.type == KeyEventType.KeyDown &&
                    (event.isCtrlPressed || event.isMetaPressed) && event.key == Key.P
                if (openShortcut) {
                    commandPaletteOpen = true
                    true
                } else false
            },
        color = MaterialTheme.colorScheme.background
    ) {
        Column(Modifier.fillMaxSize()) {
            WorkspaceDocumentBar(
                tabs = tabs,
                activeTab = activeTab,
                pinnedTabIds = pinnedTabIds,
                recentlyClosedTabs = recentlyClosedTabs,
                route = route,
                navigatorOpen = navigatorOpen,
                inspectorOpen = inspectorOpen,
                boldText = workspaceBoldText,
                verticalEdgeTabs = verticalEdgeTabs,
                onToggleVerticalEdgeTabs = { verticalEdgeTabs = !verticalEdgeTabs },
                onToggleNavigator = { setNavigatorOpen(!navigatorOpen) },
                onToggleInspector = { setInspectorOpen(!inspectorOpen) },
                onToggleBold = { vm.setWorkspaceBoldText(!workspaceBoldText) },
                onOpenHome = { nav.navigate("home") { launchSingleTop = true } },
                onOpenPanes = { nav.navigate("workspacePanes") { launchSingleTop = true } },
                onSelectTab = { tab -> openWorkspaceTab(vm, nav, tab) },
                onSplitWith = { partner ->
                    tabs.firstOrNull { it.id == activeTab }?.let { left ->
                        vm.setActiveTab(left.id)
                        nav.navigate("splitReader/${left.id}/${left.fileType}/${partner.id}/${partner.fileType}") {
                            launchSingleTop = true
                        }
                    }
                },
                onCloseTab = vm::closeTab,
                onTogglePin = vm::toggleWorkspaceTabPinned,
                onMoveTab = vm::moveTab,
                onCloseOthers = vm::closeOtherTabs,
                onCloseRight = vm::closeTabsToRight,
                onReopenClosed = { tab ->
                    vm.reopenClosedTab(tab.id)
                    openWorkspaceTab(vm, nav, tab)
                }
            )
            HorizontalDivider(color = MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.65f))
            WorkspaceContextBar(
                activeNote = activeTab?.let { id -> notes.firstOrNull { it.id == id } },
                activeTab = tabs.firstOrNull { it.id == activeTab },
                openTabCount = tabs.size,
                splitActive = route.startsWith("splitReader"),
                onShowInFiles = { selectNavigatorSection("files") }
            )

            if (dockSidePanels) {
                // Very-wide layout: side panes may dock because the document can
                // still retain a useful reading width.
                Row(Modifier.weight(1f).fillMaxWidth()) {
                    WorkspaceRibbon(
                        selectedRoute = route,
                        navigatorOpen = navigatorOpen,
                        onToggleNavigator = { setNavigatorOpen(!navigatorOpen) },
                        onHome = { nav.navigate("home") { launchSingleTop = true } },
                        onSearch = { nav.navigate("search") { launchSingleTop = true } },
                        onBrowse = { selectNavigatorSection("files") },
                        onGraph = { nav.navigate("graph") { launchSingleTop = true } },
                        onMedia = { nav.navigate("jwVideos") { launchSingleTop = true } },
                        onWeb = { openWorkspaceBrowser(vm, nav) },
                        onCommandPalette = { commandPaletteOpen = true },
                        onSettings = { nav.navigate("settings") { launchSingleTop = true } }
                    )
                    if (verticalEdgeTabs && tabs.isNotEmpty()) {
                        WorkspaceVerticalEdgeTabs(
                            tabs = tabs,
                            activeTab = activeTab,
                            pinnedTabIds = pinnedTabIds,
                            onSelectTab = { tab -> openWorkspaceTab(vm, nav, tab) },
                            onCloseTab = vm::closeTab
                        )
                    }
                    if (navigatorOpen) {
                        WorkspaceNavigator(
                            widthDp = navigatorWidth, notes = notes, tabs = tabs, activeTab = activeTab,
                            recent = recent, favourites = favourites, favouriteIds = favouriteIds, topics = topics,
                            searchResults = workspaceSearchResults,
                            section = navigatorSection, compactRows = compactRows, onSection = ::selectNavigatorSection,
                            onToggleCompact = { vm.setWorkspaceCompact(!compactRows) },
                            onSelectTab = { tab -> openWorkspaceTab(vm, nav, tab) }, onCloseTab = vm::closeTab,
                            onOpenNote = { note -> vm.openArticle(note.id, note.title, fileType = note.fileType); openWorkspaceTab(vm, nav, TabInfo(note.id, note.title, note.fileType)) },
                            onOpenRecent = { id, title, fileType -> vm.openArticle(id, title, fileType = fileType); openWorkspaceTab(vm, nav, TabInfo(id, title, fileType)) },
                            onToggleFavourite = vm::toggleFavourite, onOpenTopic = { key -> nav.navigate("topic/$key") { launchSingleTop = true } },
                            onOpenResult = { hit -> vm.openArticle(hit.id, hit.title, fileType = hit.fileType); openWorkspaceTab(vm, nav, TabInfo(hit.id, hit.title, hit.fileType)) },
                            onNewTab = { nav.navigate("home") { launchSingleTop = true } }
                        )
                        WorkspaceResizeHandle("Resize workspace navigator",
                            onDeltaDp = { delta -> navigatorWidth = (navigatorWidth + delta).coerceIn(minNavigatorWidth, maxNavigatorWidth) },
                            onDragFinished = { vm.setWorkspaceNavWidth(navigatorWidth) })
                    }
                    Box(Modifier.weight(1f).fillMaxHeight()) { content() }
                    if (inspectorOpen) {
                        WorkspaceResizeHandle("Resize workspace inspector",
                            onDeltaDp = { delta -> inspectorWidth = (inspectorWidth - delta).coerceIn(minInspectorWidth, maxInspectorWidth) },
                            onDragFinished = { vm.setWorkspaceInspectorWidth(inspectorWidth) })
                        WorkspaceInspector(
                            widthDp = inspectorWidth, vm = vm, activeTab = tabs.firstOrNull { it.id == activeTab },
                            onOpenLinkedNote = { id, title -> vm.openArticle(id, title, com.tebogo.markvault.OpenSource.LINK); openWorkspaceTab(vm, nav, TabInfo(id, title, "md")) },
                            onSearch = { nav.navigate("search") { launchSingleTop = true } },
                            onChat = { nav.navigate("chat") { launchSingleTop = true } },
                            onGraph = { activeTab?.let { nav.navigate("graph/$it") { launchSingleTop = true } } ?: nav.navigate("graph") { launchSingleTop = true } },
                            onClose = { setInspectorOpen(false) }
                        )
                    }
                }
            } else {
                // Tablet/ordinary landscape: one persistent ribbon plus a full-width
                // centre canvas. Side panes float above it instead of consuming it.
                Row(Modifier.weight(1f).fillMaxWidth()) {
                    WorkspaceRibbon(
                        selectedRoute = route, navigatorOpen = navigatorOpen,
                        onToggleNavigator = { setNavigatorOpen(!navigatorOpen) },
                        onHome = { nav.navigate("home") { launchSingleTop = true } },
                        onSearch = { nav.navigate("search") { launchSingleTop = true } },
                        onBrowse = { selectNavigatorSection("files") },
                        onGraph = { nav.navigate("graph") { launchSingleTop = true } },
                        onMedia = { nav.navigate("jwVideos") { launchSingleTop = true } },
                        onWeb = { openWorkspaceBrowser(vm, nav) },
                        onCommandPalette = { commandPaletteOpen = true },
                        onSettings = { nav.navigate("settings") { launchSingleTop = true } }
                    )
                    if (verticalEdgeTabs && tabs.isNotEmpty()) {
                        WorkspaceVerticalEdgeTabs(
                            tabs = tabs,
                            activeTab = activeTab,
                            pinnedTabIds = pinnedTabIds,
                            onSelectTab = { tab -> openWorkspaceTab(vm, nav, tab) },
                            onCloseTab = vm::closeTab
                        )
                    }
                    Box(Modifier.weight(1f).fillMaxHeight()) {
                        content()
                        if (navigatorOpen) {
                            Surface(
                                modifier = Modifier.align(Alignment.TopStart).fillMaxHeight(),
                                color = MaterialTheme.colorScheme.surface,
                                tonalElevation = 6.dp, shadowElevation = 12.dp
                            ) {
                                Row(Modifier.fillMaxHeight()) {
                                    WorkspaceNavigator(
                                        widthDp = navigatorWidth, notes = notes, tabs = tabs, activeTab = activeTab,
                                        recent = recent, favourites = favourites, favouriteIds = favouriteIds, topics = topics,
                                        searchResults = workspaceSearchResults,
                                        section = navigatorSection, compactRows = compactRows, onSection = ::selectNavigatorSection,
                                        onToggleCompact = { vm.setWorkspaceCompact(!compactRows) },
                                        onSelectTab = { tab -> openWorkspaceTab(vm, nav, tab) }, onCloseTab = vm::closeTab,
                                        onOpenNote = { note -> vm.openArticle(note.id, note.title, fileType = note.fileType); openWorkspaceTab(vm, nav, TabInfo(note.id, note.title, note.fileType)) },
                                        onOpenRecent = { id, title, fileType -> vm.openArticle(id, title, fileType = fileType); openWorkspaceTab(vm, nav, TabInfo(id, title, fileType)) },
                                        onToggleFavourite = vm::toggleFavourite, onOpenTopic = { key -> nav.navigate("topic/$key") { launchSingleTop = true } },
                                        onOpenResult = { hit -> vm.openArticle(hit.id, hit.title, fileType = hit.fileType); openWorkspaceTab(vm, nav, TabInfo(hit.id, hit.title, hit.fileType)) },
                                        onNewTab = { nav.navigate("home") { launchSingleTop = true } }
                                    )
                                    WorkspaceResizeHandle("Resize workspace navigator",
                                        onDeltaDp = { delta -> navigatorWidth = (navigatorWidth + delta).coerceIn(minNavigatorWidth, maxNavigatorWidth) },
                                        onDragFinished = { vm.setWorkspaceNavWidth(navigatorWidth) })
                                }
                            }
                        }
                        if (inspectorOpen) {
                            Surface(
                                modifier = Modifier.align(Alignment.TopEnd).fillMaxHeight(),
                                color = MaterialTheme.colorScheme.surface,
                                tonalElevation = 6.dp, shadowElevation = 12.dp
                            ) {
                                Row(Modifier.fillMaxHeight()) {
                                    WorkspaceResizeHandle("Resize workspace inspector",
                                        onDeltaDp = { delta -> inspectorWidth = (inspectorWidth - delta).coerceIn(minInspectorWidth, maxInspectorWidth) },
                                        onDragFinished = { vm.setWorkspaceInspectorWidth(inspectorWidth) })
                                    WorkspaceInspector(
                                        widthDp = inspectorWidth, vm = vm, activeTab = tabs.firstOrNull { it.id == activeTab },
                                        onOpenLinkedNote = { id, title -> vm.openArticle(id, title, com.tebogo.markvault.OpenSource.LINK); openWorkspaceTab(vm, nav, TabInfo(id, title, "md")) },
                                        onSearch = { nav.navigate("search") { launchSingleTop = true } },
                                        onChat = { nav.navigate("chat") { launchSingleTop = true } },
                                        onGraph = { activeTab?.let { nav.navigate("graph/$it") { launchSingleTop = true } } ?: nav.navigate("graph") { launchSingleTop = true } },
                                        onClose = { setInspectorOpen(false) }
                                    )
                                }
                            }
                        }
                    }
                }
            }
            WorkspaceStatusBar(
                activeNote = activeTab?.let { id -> notes.firstOrNull { it.id == id } },
                openTabCount = tabs.size,
                pinnedCount = pinnedTabIds.size,
                splitActive = route.startsWith("splitReader"),
                navigatorOpen = navigatorOpen,
                inspectorOpen = inspectorOpen
            )
        }
    }


    if (commandPaletteOpen) {
        WorkspaceCommandPalette(
            notes = notes,
            tabs = tabs,
            activeTab = activeTab,
            favouriteIds = favouriteIds,
            recent = recent,
            pinnedTabIds = pinnedTabIds,
            recentlyClosedTabs = recentlyClosedTabs,
            navigatorOpen = navigatorOpen,
            inspectorOpen = inspectorOpen,
            onDismiss = { commandPaletteOpen = false },
            onOpenNote = { note ->
                vm.openArticle(note.id, note.title, fileType = note.fileType)
                openWorkspaceTab(vm, nav, TabInfo(note.id, note.title, note.fileType))
                commandPaletteOpen = false
            },
            onOpenHome = { nav.navigate("home") { launchSingleTop = true }; commandPaletteOpen = false },
            onOpenSearch = { nav.navigate("search") { launchSingleTop = true }; commandPaletteOpen = false },
            onOpenGraph = { nav.navigate("graph") { launchSingleTop = true }; commandPaletteOpen = false },
            onOpenMedia = { nav.navigate("jwVideos") { launchSingleTop = true }; commandPaletteOpen = false },
            onOpenChat = { nav.navigate("chat") { launchSingleTop = true }; commandPaletteOpen = false },
            onOpenWeb = { openWorkspaceBrowser(vm, nav); commandPaletteOpen = false },
            onOpenPanes = { nav.navigate("workspacePanes") { launchSingleTop = true }; commandPaletteOpen = false },
            onOpenSettings = { nav.navigate("settings") { launchSingleTop = true }; commandPaletteOpen = false },
            onOpenFiles = { selectNavigatorSection("files"); commandPaletteOpen = false },
            onToggleNavigator = { setNavigatorOpen(!navigatorOpen); commandPaletteOpen = false },
            onToggleInspector = { setInspectorOpen(!inspectorOpen); commandPaletteOpen = false },
            onTogglePin = { id -> vm.toggleWorkspaceTabPinned(id); commandPaletteOpen = false },
            onCloseActive = { id -> vm.closeTab(id); commandPaletteOpen = false },
            onReopenLast = { tab ->
                vm.reopenClosedTab(tab.id)
                openWorkspaceTab(vm, nav, tab)
                commandPaletteOpen = false
            }
        )
    }
}


@Composable
private fun WorkspaceResizeHandle(
    contentDescription: String,
    onDeltaDp: (Float) -> Unit,
    onDragFinished: () -> Unit
) {
    val density = LocalDensity.current.density
    Surface(
        color = MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.35f),
        modifier = Modifier
            .width(6.dp)
            .fillMaxHeight()
            .pointerInput(contentDescription, density) {
                detectHorizontalDragGestures(
                    onDragEnd = onDragFinished,
                    onDragCancel = onDragFinished,
                    onHorizontalDrag = { change, dragAmount ->
                        change.consume()
                        onDeltaDp(dragAmount / density)
                    }
                )
            }
    ) {}
}

@Composable
private fun WorkspaceContextBar(
    activeNote: NoteMeta?,
    activeTab: TabInfo?,
    openTabCount: Int,
    splitActive: Boolean,
    onShowInFiles: () -> Unit
) {
    Row(
        Modifier
            .fillMaxWidth()
            .height(30.dp)
            .background(MaterialTheme.colorScheme.surface.copy(alpha = 0.96f))
            .padding(horizontal = 10.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        val type = activeTab?.let { workspaceFileGlyph(it.fileType) }
        if (type != null) {
            Text(type, fontSize = 8.sp, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary)
            Spacer(Modifier.width(7.dp))
        }
        if (activeNote != null) {
            Text(
                activeNote.relPath.ifBlank { activeNote.title },
                modifier = Modifier
                    .weight(1f)
                    .clip(RoundedCornerShape(5.dp))
                    .clickable(onClick = onShowInFiles)
                    .padding(horizontal = 3.dp, vertical = 3.dp),
                maxLines = 1,
                overflow = TextOverflow.Ellipsis,
                fontSize = 10.sp,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
        } else {
            Text(
                "Workspace",
                modifier = Modifier.weight(1f),
                fontSize = 10.sp,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
        }
        if (splitActive) {
            Text("SPLIT", fontSize = 8.sp, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.tertiary)
            Spacer(Modifier.width(8.dp))
        }
        Text("$openTabCount tabs", fontSize = 9.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
    }
    HorizontalDivider(color = MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.4f))
}

@Composable
private fun WorkspaceStatusBar(
    activeNote: NoteMeta?,
    openTabCount: Int,
    pinnedCount: Int,
    splitActive: Boolean,
    navigatorOpen: Boolean,
    inspectorOpen: Boolean
) {
    HorizontalDivider(color = MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.45f))
    Row(
        Modifier
            .fillMaxWidth()
            .height(24.dp)
            .background(MaterialTheme.colorScheme.surface)
            .padding(horizontal = 10.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(
            activeNote?.folder?.ifBlank { "Vault" } ?: "Vault",
            modifier = Modifier.weight(1f),
            maxLines = 1,
            overflow = TextOverflow.Ellipsis,
            fontSize = 9.sp,
            color = MaterialTheme.colorScheme.onSurfaceVariant
        )
        if (splitActive) Text("2 panes  ·  ", fontSize = 9.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
        Text("$openTabCount open", fontSize = 9.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
        if (pinnedCount > 0) Text("  ·  $pinnedCount pinned", fontSize = 9.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
        Text(
            "  ·  ${if (navigatorOpen) "nav" else "nav hidden"}  ·  ${if (inspectorOpen) "inspector" else "inspector hidden"}",
            fontSize = 9.sp,
            color = MaterialTheme.colorScheme.onSurfaceVariant
        )
    }
}

private fun openWorkspaceBrowser(vm: AppViewModel, nav: NavController) {
    val tabs = vm.webTabs
    val active = if (tabs.isEmpty()) null else tabs[vm.webActiveTabIdx.coerceIn(0, tabs.lastIndex)]
    val url = active?.url ?: "https://www.jw.org"
    val label = active?.title?.ifBlank { "Tab" } ?: "jw.org"
    val encUrl = java.net.URLEncoder.encode(url, "UTF-8")
    val encLabel = java.net.URLEncoder.encode(label, "UTF-8")
    nav.navigate("web/$encUrl/$encLabel") { launchSingleTop = true }
}

private fun openWorkspaceTab(vm: AppViewModel, nav: NavController, tab: TabInfo) {
    vm.setActiveTab(tab.id)
    when (tab.fileType.lowercase()) {
        "pdf" -> nav.navigate("pdfReader/${tab.id}") { launchSingleTop = true }
        "html", "htm", "mhtml" -> nav.navigate("htmlReader/${tab.id}") { launchSingleTop = true }
        else -> nav.navigate("reader") { launchSingleTop = true }
    }
}

@Composable
private fun WorkspaceDocumentBar(
    tabs: List<TabInfo>,
    activeTab: Long?,
    pinnedTabIds: Set<Long>,
    recentlyClosedTabs: List<TabInfo>,
    route: String,
    navigatorOpen: Boolean,
    inspectorOpen: Boolean,
    boldText: Boolean,
    verticalEdgeTabs: Boolean,
    onToggleVerticalEdgeTabs: () -> Unit,
    onToggleNavigator: () -> Unit,
    onToggleInspector: () -> Unit,
    onToggleBold: () -> Unit,
    onOpenHome: () -> Unit,
    onOpenPanes: () -> Unit,
    onSelectTab: (TabInfo) -> Unit,
    onSplitWith: (TabInfo) -> Unit,
    onCloseTab: (Long) -> Unit,
    onTogglePin: (Long) -> Unit,
    onMoveTab: (Long, Int) -> Unit,
    onCloseOthers: (Long) -> Unit,
    onCloseRight: (Long) -> Unit,
    onReopenClosed: (TabInfo) -> Unit
) {
    val scroll = rememberScrollState()
    var splitMenuOpen by remember { mutableStateOf(false) }
    var reopenMenuOpen by remember { mutableStateOf(false) }
    var allTabsMenuOpen by remember { mutableStateOf(false) }
    val activeDocument = tabs.firstOrNull { it.id == activeTab }
    val splitPartners = if (activeDocument == null) emptyList() else tabs.filter { it.id != activeDocument.id }
    Row(
        Modifier.fillMaxWidth().height(46.dp).background(MaterialTheme.colorScheme.surface),
        verticalAlignment = Alignment.CenterVertically
    ) {
        IconButton(onClick = onToggleNavigator, modifier = Modifier.size(40.dp)) {
            Icon(Icons.Default.Menu, contentDescription = if (navigatorOpen) "Close workspace navigator" else "Open workspace navigator")
        }
        Text(
            "MarkVault",
            fontSize = 13.sp,
            fontWeight = FontWeight.SemiBold,
            color = MaterialTheme.colorScheme.onSurface,
            modifier = Modifier.padding(end = 8.dp)
        )
        VerticalDivider(Modifier.height(24.dp), color = MaterialTheme.colorScheme.outlineVariant)

        Row(
            Modifier.weight(1f).horizontalScroll(scroll).padding(horizontal = 4.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            val routeIsReader = route.startsWith("reader") || route.startsWith("pdfReader") ||
                route.startsWith("htmlReader") || route.startsWith("splitReader")
            if (!routeIsReader) {
                WorkspaceViewTab(
                    label = workspaceRouteLabel(route),
                    selected = true,
                    onClick = {},
                    onClose = null
                )
            }
            if (!verticalEdgeTabs) tabs.forEachIndexed { index, tab ->
                WorkspaceViewTab(
                    label = tab.title,
                    selected = routeIsReader && tab.id == activeTab,
                    pinned = tab.id in pinnedTabIds,
                    canMoveLeft = index > 0,
                    canMoveRight = index < tabs.lastIndex,
                    canCloseRight = index < tabs.lastIndex,
                    canSplitBeside = activeDocument != null && activeDocument.id != tab.id,
                    leading = when (tab.fileType.lowercase()) {
                        "pdf" -> "PDF"
                        "html", "htm", "mhtml" -> "WEB"
                        else -> "MD"
                    },
                    onClick = { onSelectTab(tab) },
                    onClose = { onCloseTab(tab.id) },
                    onTogglePin = { onTogglePin(tab.id) },
                    onMove = { direction -> onMoveTab(tab.id, direction) },
                    onCloseOthers = { onCloseOthers(tab.id) },
                    onCloseRight = { onCloseRight(tab.id) },
                    onSplitBeside = { onSplitWith(tab) }
                )
                if (tab.id in pinnedTabIds && tabs.getOrNull(index + 1)?.id !in pinnedTabIds) {
                    VerticalDivider(
                        Modifier.height(22.dp).padding(horizontal = 3.dp),
                        color = MaterialTheme.colorScheme.primary.copy(alpha = 0.45f)
                    )
                }
            }
            if (!verticalEdgeTabs && tabs.size > 3) {
                Box {
                    Text(
                        "▾ ${tabs.size}",
                        modifier = Modifier
                            .clip(RoundedCornerShape(6.dp))
                            .clickable { allTabsMenuOpen = true }
                            .padding(horizontal = 7.dp, vertical = 7.dp),
                        fontSize = 10.sp,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                    DropdownMenu(expanded = allTabsMenuOpen, onDismissRequest = { allTabsMenuOpen = false }) {
                        tabs.forEach { listed ->
                            DropdownMenuItem(
                                text = {
                                    Row(verticalAlignment = Alignment.CenterVertically) {
                                        if (listed.id in pinnedTabIds) {
                                            Text("◆", fontSize = 8.sp, color = MaterialTheme.colorScheme.tertiary)
                                            Spacer(Modifier.width(5.dp))
                                        }
                                        Text(listed.title.ifBlank { "Untitled" }, maxLines = 1, overflow = TextOverflow.Ellipsis)
                                    }
                                },
                                onClick = { allTabsMenuOpen = false; onSelectTab(listed) }
                            )
                        }
                    }
                }
            }
            Box {
                Surface(
                    color = if (route.startsWith("splitReader")) MaterialTheme.colorScheme.secondaryContainer else Color.Transparent,
                    shape = RoundedCornerShape(6.dp)
                ) {
                    Text(
                        "◫ Split",
                        modifier = Modifier
                            .clip(RoundedCornerShape(6.dp))
                            .clickable(enabled = splitPartners.isNotEmpty()) { splitMenuOpen = true }
                            .padding(horizontal = 9.dp, vertical = 7.dp),
                        fontSize = 11.sp,
                        fontWeight = FontWeight.SemiBold,
                        color = if (splitPartners.isNotEmpty()) MaterialTheme.colorScheme.onSurface else MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.45f)
                    )
                }
                DropdownMenu(expanded = splitMenuOpen, onDismissRequest = { splitMenuOpen = false }) {
                    splitPartners.forEach { partner ->
                        DropdownMenuItem(
                            text = {
                                Column {
                                    Text(partner.title.ifBlank { "Untitled" }, maxLines = 1, overflow = TextOverflow.Ellipsis)
                                    Text(workspaceFileGlyph(partner.fileType), fontSize = 9.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                }
                            },
                            onClick = { splitMenuOpen = false; onSplitWith(partner) }
                        )
                    }
                }
            }
            Surface(color = if (route == "workspacePanes") MaterialTheme.colorScheme.tertiaryContainer else Color.Transparent, shape = RoundedCornerShape(6.dp)) {
                Text(
                    "▦ Panes",
                    modifier = Modifier.clip(RoundedCornerShape(6.dp)).clickable(onClick = onOpenPanes).padding(horizontal = 9.dp, vertical = 7.dp),
                    fontSize = 11.sp,
                    fontWeight = FontWeight.SemiBold,
                    color = MaterialTheme.colorScheme.onSurface
                )
            }
            if (recentlyClosedTabs.isNotEmpty()) {
                Box {
                    Surface(color = Color.Transparent, shape = RoundedCornerShape(6.dp)) {
                        Text(
                            "↶",
                            modifier = Modifier
                                .clip(RoundedCornerShape(6.dp))
                                .clickable { reopenMenuOpen = true }
                                .padding(horizontal = 8.dp, vertical = 7.dp),
                            fontSize = 16.sp,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                    DropdownMenu(expanded = reopenMenuOpen, onDismissRequest = { reopenMenuOpen = false }) {
                        recentlyClosedTabs.forEach { closed ->
                            DropdownMenuItem(
                                text = {
                                    Column {
                                        Text(closed.title.ifBlank { "Untitled" }, maxLines = 1, overflow = TextOverflow.Ellipsis)
                                        Text("Reopen · ${workspaceFileGlyph(closed.fileType)}", fontSize = 9.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                    }
                                },
                                onClick = { reopenMenuOpen = false; onReopenClosed(closed) }
                            )
                        }
                    }
                }
            }
            IconButton(onClick = onOpenHome, modifier = Modifier.size(34.dp)) {
                Icon(Icons.Default.Add, contentDescription = "New workspace tab", modifier = Modifier.size(17.dp))
            }
        }

        MemoryOverlay()
        Surface(
            color = if (boldText) MaterialTheme.colorScheme.primaryContainer else Color.Transparent,
            shape = RoundedCornerShape(16.dp),
            modifier = Modifier.padding(horizontal = 2.dp)
        ) {
            Text(
                "B",
                modifier = Modifier.clickable(onClick = onToggleBold).padding(horizontal = 9.dp, vertical = 6.dp),
                fontSize = 12.sp,
                fontWeight = FontWeight.Bold,
                color = if (boldText) MaterialTheme.colorScheme.onPrimaryContainer else MaterialTheme.colorScheme.onSurfaceVariant
            )
        }
        Surface(
            color = if (verticalEdgeTabs) MaterialTheme.colorScheme.secondaryContainer else Color.Transparent,
            shape = RoundedCornerShape(7.dp),
            modifier = Modifier.padding(horizontal = 2.dp)
        ) {
            Text(
                if (verticalEdgeTabs) "▥" else "▤",
                modifier = Modifier.clickable(onClick = onToggleVerticalEdgeTabs).padding(horizontal = 8.dp, vertical = 6.dp),
                fontSize = 13.sp,
                fontWeight = FontWeight.Bold,
                color = if (verticalEdgeTabs) MaterialTheme.colorScheme.onSecondaryContainer else MaterialTheme.colorScheme.onSurfaceVariant
            )
        }
        VerticalDivider(Modifier.height(24.dp), color = MaterialTheme.colorScheme.outlineVariant)
        Surface(
            color = if (inspectorOpen) MaterialTheme.colorScheme.secondaryContainer else Color.Transparent,
            shape = RoundedCornerShape(7.dp),
            modifier = Modifier.padding(horizontal = 4.dp)
        ) {
            IconButton(onClick = onToggleInspector, modifier = Modifier.size(34.dp)) {
                Icon(Icons.Default.MoreVert, contentDescription = if (inspectorOpen) "Close inspector" else "Open inspector", modifier = Modifier.size(18.dp))
            }
        }
    }
}

@OptIn(ExperimentalFoundationApi::class)
@Composable
private fun WorkspaceViewTab(
    label: String,
    selected: Boolean,
    pinned: Boolean = false,
    canMoveLeft: Boolean = false,
    canMoveRight: Boolean = false,
    canCloseRight: Boolean = false,
    canSplitBeside: Boolean = false,
    leading: String? = null,
    onClick: () -> Unit,
    onClose: (() -> Unit)? = null,
    onTogglePin: () -> Unit = {},
    onMove: (Int) -> Unit = {},
    onCloseOthers: () -> Unit = {},
    onCloseRight: () -> Unit = {},
    onSplitBeside: () -> Unit = {}
) {
    var menuOpen by remember { mutableStateOf(false) }
    var dragX by remember { mutableStateOf(0f) }
    Box {
        Surface(
            color = if (selected) MaterialTheme.colorScheme.primaryContainer else MaterialTheme.colorScheme.surface,
            contentColor = if (selected) MaterialTheme.colorScheme.onPrimaryContainer else MaterialTheme.colorScheme.onSurface,
            shape = RoundedCornerShape(8.dp),
            border = BorderStroke(
                width = if (selected) 2.dp else 1.dp,
                color = if (selected) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.outline
            ),
            tonalElevation = if (selected) 3.dp else 1.dp,
            shadowElevation = if (selected) 3.dp else 1.dp,
            modifier = Modifier
                .height(36.dp)
                .widthIn(min = 104.dp, max = 230.dp)
                .padding(horizontal = 3.dp)
                .pointerInput(label, canMoveLeft, canMoveRight) {
                    detectDragGesturesAfterLongPress(
                        onDragStart = { dragX = 0f },
                        onDragEnd = { dragX = 0f },
                        onDragCancel = { dragX = 0f },
                        onDrag = { change, amount ->
                            change.consume()
                            dragX += amount.x
                            if (dragX >= 44f && canMoveRight) {
                                onMove(1)
                                dragX = 0f
                            } else if (dragX <= -44f && canMoveLeft) {
                                onMove(-1)
                                dragX = 0f
                            }
                        }
                    )
                }
        ) {
            Row(
                Modifier.clickable(onClick = onClick).padding(start = 8.dp, end = 1.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                if (pinned) {
                    Text("◆", fontSize = 8.sp, color = MaterialTheme.colorScheme.tertiary)
                    Spacer(Modifier.width(4.dp))
                }
                if (leading != null) {
                    Text(leading, fontSize = 8.sp, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary)
                    Spacer(Modifier.width(5.dp))
                }
                Text(
                    label,
                    modifier = Modifier.weight(1f, fill = false),
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis,
                    fontSize = 11.sp,
                    fontWeight = if (selected) FontWeight.SemiBold else FontWeight.Normal,
                    color = if (selected) MaterialTheme.colorScheme.onPrimaryContainer else MaterialTheme.colorScheme.onSurfaceVariant
                )
                if (onClose != null) {
                    Text(
                        "⋮",
                        modifier = Modifier
                            .clip(RoundedCornerShape(5.dp))
                            .clickable { menuOpen = true }
                            .padding(horizontal = 5.dp, vertical = 6.dp),
                        fontSize = 14.sp,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                    IconButton(onClick = onClose, modifier = Modifier.size(24.dp)) {
                        Icon(Icons.Default.Close, contentDescription = "Close tab", modifier = Modifier.size(12.dp))
                    }
                } else {
                    Spacer(Modifier.width(7.dp))
                }
            }
        }
        if (onClose != null) DropdownMenu(expanded = menuOpen, onDismissRequest = { menuOpen = false }) {
            DropdownMenuItem(
                text = { Text(if (pinned) "Unpin tab" else "Pin tab") },
                onClick = { menuOpen = false; onTogglePin() }
            )
            DropdownMenuItem(
                text = { Text("Move left") },
                enabled = canMoveLeft,
                onClick = { menuOpen = false; onMove(-1) }
            )
            DropdownMenuItem(
                text = { Text("Move right") },
                enabled = canMoveRight,
                onClick = { menuOpen = false; onMove(1) }
            )
            if (canSplitBeside) {
                DropdownMenuItem(
                    text = { Text("Open beside active") },
                    onClick = { menuOpen = false; onSplitBeside() }
                )
            }
            HorizontalDivider()
            DropdownMenuItem(
                text = { Text("Close tab") },
                onClick = { menuOpen = false; onClose?.invoke() }
            )
            DropdownMenuItem(
                text = { Text("Close other tabs") },
                onClick = { menuOpen = false; onCloseOthers() }
            )
            DropdownMenuItem(
                text = { Text("Close tabs to the right") },
                enabled = canCloseRight,
                onClick = { menuOpen = false; onCloseRight() }
            )
        }
    }
}


@OptIn(ExperimentalFoundationApi::class)
@Composable
private fun WorkspaceVerticalEdgeTabs(
    tabs: List<TabInfo>,
    activeTab: Long?,
    pinnedTabIds: Set<Long>,
    onSelectTab: (TabInfo) -> Unit,
    onCloseTab: (Long) -> Unit
) {
    Column(
        Modifier
            .width(58.dp)
            .fillMaxHeight()
            .background(MaterialTheme.colorScheme.surface)
            .verticalScroll(rememberScrollState())
            .padding(vertical = 4.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        tabs.forEach { tab ->
            val selected = tab.id == activeTab
            Surface(
                color = if (selected) MaterialTheme.colorScheme.primaryContainer else MaterialTheme.colorScheme.surface,
                shape = RoundedCornerShape(7.dp),
                border = BorderStroke(
                    if (selected) 2.dp else 1.dp,
                    if (selected) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.outline
                ),
                tonalElevation = if (selected) 3.dp else 1.dp,
                modifier = Modifier
                    .padding(vertical = 3.dp)
                    .width(56.dp)
                    .height(280.dp)
                    .combinedClickable(
                        onClick = { onSelectTab(tab) },
                        onLongClick = { onCloseTab(tab.id) }
                    )
            ) {
                Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                    Text(
                        text = (if (tab.id in pinnedTabIds) "◆ " else "") + tab.title.ifBlank { "Untitled" },
                        modifier = Modifier
                            .rotate(-90f)
                            .width(260.dp)
                            .basicMarquee(iterations = Int.MAX_VALUE),
                        maxLines = 1,
                        fontSize = 13.sp,
                        fontWeight = FontWeight.Black,
                        color = if (selected) MaterialTheme.colorScheme.onPrimaryContainer else MaterialTheme.colorScheme.onSurface
                    )
                }
            }
        }
    }
}


@Composable
private fun WorkspaceRibbon(
    selectedRoute: String,
    navigatorOpen: Boolean,
    onToggleNavigator: () -> Unit,
    onHome: () -> Unit,
    onSearch: () -> Unit,
    onBrowse: () -> Unit,
    onGraph: () -> Unit,
    onMedia: () -> Unit,
    onWeb: () -> Unit,
    onCommandPalette: () -> Unit,
    onSettings: () -> Unit
) {
    Column(
        Modifier.width(58.dp).fillMaxHeight().background(MaterialTheme.colorScheme.surface),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        WorkspaceRibbonButton("☰", "Navigator", navigatorOpen, onToggleNavigator)
        Spacer(Modifier.height(6.dp))
        WorkspaceRibbonButton("⌂", "Home", selectedRoute == "home", onHome)
        WorkspaceRibbonButton("⌕", "Search", selectedRoute == "search", onSearch)
        WorkspaceRibbonButton("▤", "Library", selectedRoute == "browse", onBrowse)
        WorkspaceRibbonButton("◇", "Graph", selectedRoute == "graph", onGraph)
        WorkspaceRibbonButton("▶", "Media Library", selectedRoute == "jwVideos" || selectedRoute.startsWith("mediaPlayer"), onMedia)
        WorkspaceRibbonButton("◎", "Web", selectedRoute.startsWith("web"), onWeb)
        Spacer(Modifier.height(6.dp))
        WorkspaceRibbonButton("⌘", "Command palette", false, onCommandPalette)
        Spacer(Modifier.weight(1f))
        WorkspaceRibbonButton("⚙", "Settings", selectedRoute == "settings", onSettings)
        Spacer(Modifier.height(6.dp))
    }
}

@Composable
private fun WorkspaceRibbonButton(
    symbol: String,
    description: String,
    selected: Boolean,
    onClick: () -> Unit
) {
    Surface(
        color = if (selected) MaterialTheme.colorScheme.primaryContainer else Color.Transparent,
        shape = RoundedCornerShape(9.dp),
        modifier = Modifier.padding(vertical = 3.dp).size(54.dp).clip(RoundedCornerShape(10.dp)).clickable(onClick = onClick)
    ) {
        Box(contentAlignment = Alignment.Center) {
            Text(
                symbol,
                fontSize = if (symbol == "⚙") 25.sp else 27.sp,
                fontWeight = FontWeight.Black,
                color = if (selected) MaterialTheme.colorScheme.onPrimaryContainer else MaterialTheme.colorScheme.onSurface
            )
        }
    }
}


private data class WorkspacePaletteCommand(
    val id: String,
    val symbol: String,
    val label: String,
    val detail: String,
    val action: () -> Unit
)

private fun rankWorkspaceQuickOpen(
    notes: List<NoteMeta>,
    query: String,
    favouriteIds: Set<Long>,
    tabs: List<TabInfo>,
    recent: List<com.tebogo.markvault.data.RecentNote>
): List<NoteMeta> {
    val q = query.trim().lowercase()
    val openIds = tabs.mapTo(HashSet()) { it.id }
    val recentRank = recent.take(120).mapIndexed { index, item -> item.id to (240 - index).coerceAtLeast(40) }.toMap()
    val queryTokens = if (q.isBlank()) emptyList() else com.tebogo.markvault.search.QueryExpander.contentTokens(q)
    return notes.asSequence().mapNotNull { note ->
        val title = note.title.lowercase()
        val name = note.name.lowercase()
        val path = note.relPath.lowercase()
        var score = 0
        if (note.id in favouriteIds) score += 500
        if (note.id in openIds) score += 420
        score += recentRank[note.id] ?: 0
        if (q.isBlank()) {
            if (score == 0) return@mapNotNull null
        } else {
            when {
                title == q -> score += 1500
                title.startsWith(q) -> score += 1050
                name.startsWith(q) -> score += 900
                title.contains(q) -> score += 760
                name.contains(q) -> score += 650
                path.contains(q) -> score += 480
                else -> {
                    val fuzzy = com.tebogo.markvault.search.QueryExpander.fuzzyBoost("${note.title} ${note.name}", queryTokens)
                    if (fuzzy <= 0) return@mapNotNull null
                    score += fuzzy * 12
                }
            }
        }
        note to score
    }.sortedWith(
        compareByDescending<Pair<NoteMeta, Int>> { it.second }
            .thenBy { it.first.title.lowercase() }
    ).take(50).map { it.first }.toList()
}

@Composable
private fun WorkspaceCommandPalette(
    notes: List<NoteMeta>,
    tabs: List<TabInfo>,
    activeTab: Long?,
    favouriteIds: Set<Long>,
    recent: List<com.tebogo.markvault.data.RecentNote>,
    pinnedTabIds: Set<Long>,
    recentlyClosedTabs: List<TabInfo>,
    navigatorOpen: Boolean,
    inspectorOpen: Boolean,
    onDismiss: () -> Unit,
    onOpenNote: (NoteMeta) -> Unit,
    onOpenHome: () -> Unit,
    onOpenSearch: () -> Unit,
    onOpenGraph: () -> Unit,
    onOpenMedia: () -> Unit,
    onOpenChat: () -> Unit,
    onOpenWeb: () -> Unit,
    onOpenPanes: () -> Unit,
    onOpenSettings: () -> Unit,
    onOpenFiles: () -> Unit,
    onToggleNavigator: () -> Unit,
    onToggleInspector: () -> Unit,
    onTogglePin: (Long) -> Unit,
    onCloseActive: (Long) -> Unit,
    onReopenLast: (TabInfo) -> Unit
) {
    var query by rememberSaveable { mutableStateOf("") }
    var selectedIndex by remember { mutableStateOf(0) }
    var fileMatches by remember { mutableStateOf(emptyList<NoteMeta>()) }
    val focusRequester = remember { FocusRequester() }
    val active = tabs.firstOrNull { it.id == activeTab }
    val commandQuery = query.trim().removePrefix(">").trim()
    val commandMode = query.trimStart().startsWith(">")

    val commands = listOfNotNull(
        WorkspacePaletteCommand("home", "⌂", "Go to Home", "Workspace home", onOpenHome),
        WorkspacePaletteCommand("files", "▤", "Open file explorer", "Show the vault navigator", onOpenFiles),
        WorkspacePaletteCommand("search", "⌕", "Search library", "Open full library search", onOpenSearch),
        WorkspacePaletteCommand("chat", "●", "Chat with library", "Open AI library chat", onOpenChat),
        WorkspacePaletteCommand("graph", "◇", "Open graph view", "Explore note connections", onOpenGraph),
        WorkspacePaletteCommand("media", "▶", "Open Media Library", "JW.org video/audio browser, playlists and playback", onOpenMedia),
        WorkspacePaletteCommand("web", "◎", "Open web viewer", "Open the Workspace browser", onOpenWeb),
        WorkspacePaletteCommand("panes", "▦", "Open advanced pane workspace", "Split right/down, pane tabs, locks and saved layouts", onOpenPanes),
        WorkspacePaletteCommand("navigator", "☰", if (navigatorOpen) "Hide left navigator" else "Show left navigator", "Toggle Workspace left pane", onToggleNavigator),
        WorkspacePaletteCommand("inspector", "⋮", if (inspectorOpen) "Hide right inspector" else "Show right inspector", "Toggle Workspace context pane", onToggleInspector),
        active?.let { tab ->
            WorkspacePaletteCommand(
                "pin", "◆",
                if (tab.id in pinnedTabIds) "Unpin active tab" else "Pin active tab",
                tab.title,
                { onTogglePin(tab.id) }
            )
        },
        active?.let { tab -> WorkspacePaletteCommand("close", "×", "Close active tab", tab.title, { onCloseActive(tab.id) }) },
        recentlyClosedTabs.firstOrNull()?.let { tab ->
            WorkspacePaletteCommand("reopen", "↶", "Reopen closed tab", tab.title, { onReopenLast(tab) })
        },
        WorkspacePaletteCommand("settings", "⚙", "Open Settings", "MarkVault settings", onOpenSettings)
    )

    val matchingCommands = remember(commands.map { it.id + it.label }, commandQuery) {
        if (commandQuery.isBlank()) commands
        else {
            val tokens = com.tebogo.markvault.search.QueryExpander.contentTokens(commandQuery)
            commands.mapNotNull { command ->
                val text = "${command.label} ${command.detail}".lowercase()
                val score = when {
                    command.label.equals(commandQuery, true) -> 1000
                    command.label.startsWith(commandQuery, true) -> 800
                    text.contains(commandQuery.lowercase()) -> 600
                    else -> com.tebogo.markvault.search.QueryExpander.fuzzyBoost(text, tokens) * 10
                }
                if (score > 0) command to score else null
            }.sortedByDescending { it.second }.map { it.first }
        }
    }

    LaunchedEffect(query, notes, favouriteIds, tabs, recent) {
        delay(90)
        fileMatches = if (commandMode) emptyList() else withContext(Dispatchers.Default) {
            rankWorkspaceQuickOpen(notes, query, favouriteIds, tabs, recent)
        }
        selectedIndex = 0
    }

    val commandCount = matchingCommands.size
    val totalCount = commandCount + fileMatches.size
    fun activate(index: Int) {
        if (index !in 0 until totalCount) return
        if (index < commandCount) matchingCommands[index].action()
        else onOpenNote(fileMatches[index - commandCount])
    }

    Dialog(onDismissRequest = onDismiss) {
        Surface(
            modifier = Modifier
                .fillMaxWidth()
                .widthIn(max = 720.dp)
                .wrapContentHeight()
                .onPreviewKeyEvent { event ->
                    if (event.type != KeyEventType.KeyDown) return@onPreviewKeyEvent false
                    when (event.key) {
                        Key.DirectionDown -> {
                            if (totalCount > 0) selectedIndex = (selectedIndex + 1).coerceAtMost(totalCount - 1)
                            true
                        }
                        Key.DirectionUp -> {
                            if (totalCount > 0) selectedIndex = (selectedIndex - 1).coerceAtLeast(0)
                            true
                        }
                        Key.Enter -> { activate(selectedIndex); true }
                        Key.Escape -> { onDismiss(); true }
                        else -> false
                    }
                },
            color = MaterialTheme.colorScheme.surface,
            shape = RoundedCornerShape(16.dp),
            tonalElevation = 8.dp,
            shadowElevation = 16.dp
        ) {
            Column(Modifier.fillMaxWidth().padding(10.dp)) {
                OutlinedTextField(
                    value = query,
                    onValueChange = { query = it },
                    modifier = Modifier.fillMaxWidth().focusRequester(focusRequester),
                    singleLine = true,
                    label = { Text("Quick open or command") },
                    placeholder = { Text("Type a note, or > for commands") },
                    leadingIcon = { Text(if (commandMode) "⌘" else "⌕", fontSize = 18.sp) }
                )
                LaunchedEffect(Unit) { focusRequester.requestFocus() }
                Row(
                    Modifier.fillMaxWidth().padding(horizontal = 6.dp, vertical = 6.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        if (commandMode) "COMMANDS" else "QUICK SWITCHER",
                        fontSize = 9.sp,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.primary
                    )
                    Spacer(Modifier.weight(1f))
                    Text("↑↓ navigate  ·  Enter open  ·  Esc close", fontSize = 9.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
                HorizontalDivider(color = MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.6f))
                LazyColumn(Modifier.fillMaxWidth().height(420.dp)) {
                    if (matchingCommands.isNotEmpty()) {
                        item {
                            Text(
                                "COMMANDS",
                                modifier = Modifier.padding(start = 10.dp, top = 9.dp, bottom = 4.dp),
                                fontSize = 9.sp,
                                fontWeight = FontWeight.Bold,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                        items(matchingCommands.size, key = { "cmd:${matchingCommands[it].id}" }) { index ->
                            val command = matchingCommands[index]
                            WorkspacePaletteRow(
                                symbol = command.symbol,
                                title = command.label,
                                detail = command.detail,
                                selected = selectedIndex == index,
                                onClick = command.action
                            )
                        }
                    }
                    if (!commandMode && fileMatches.isNotEmpty()) {
                        item {
                            Text(
                                "FILES",
                                modifier = Modifier.padding(start = 10.dp, top = 9.dp, bottom = 4.dp),
                                fontSize = 9.sp,
                                fontWeight = FontWeight.Bold,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                        items(fileMatches.size, key = { "file:${fileMatches[it].id}" }) { fileIndex ->
                            val note = fileMatches[fileIndex]
                            val absoluteIndex = commandCount + fileIndex
                            val badges = buildList {
                                if (note.id in tabs.map { it.id }.toSet()) add("OPEN")
                                if (note.id in favouriteIds) add("★")
                            }.joinToString(" · ")
                            WorkspacePaletteRow(
                                symbol = workspaceFileGlyph(note.fileType),
                                title = note.title.ifBlank { note.name },
                                detail = listOf(note.folder.ifBlank { "Vault root" }, badges).filter { it.isNotBlank() }.joinToString("  ·  "),
                                selected = selectedIndex == absoluteIndex,
                                onClick = { onOpenNote(note) }
                            )
                        }
                    }
                    if (totalCount == 0) {
                        item {
                            Column(
                                Modifier.fillMaxWidth().padding(vertical = 34.dp),
                                horizontalAlignment = Alignment.CenterHorizontally
                            ) {
                                Text("No matching notes or commands", color = MaterialTheme.colorScheme.onSurfaceVariant)
                                Text("Try a shorter phrase or type > to browse commands", fontSize = 10.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun WorkspacePaletteRow(
    symbol: String,
    title: String,
    detail: String,
    selected: Boolean,
    onClick: () -> Unit
) {
    Surface(
        color = if (selected) MaterialTheme.colorScheme.primaryContainer else Color.Transparent,
        shape = RoundedCornerShape(8.dp),
        modifier = Modifier.fillMaxWidth().padding(horizontal = 3.dp, vertical = 1.dp).clickable(onClick = onClick)
    ) {
        Row(
            Modifier.fillMaxWidth().padding(horizontal = 9.dp, vertical = 8.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Box(Modifier.width(42.dp), contentAlignment = Alignment.Center) {
                Text(symbol, fontSize = 12.sp, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary)
            }
            Column(Modifier.weight(1f)) {
                Text(title, maxLines = 1, overflow = TextOverflow.Ellipsis, fontSize = 12.sp, fontWeight = FontWeight.Medium)
                if (detail.isNotBlank()) {
                    Text(detail, maxLines = 1, overflow = TextOverflow.Ellipsis, fontSize = 9.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
            }
        }
    }
}

private data class WorkspaceExplorerIndex(
    val notesByFolder: Map<String, List<NoteMeta>>,
    val childFolders: Map<String, List<String>>
)

private sealed interface WorkspaceExplorerRow {
    val key: String
    data class Folder(val path: String, val depth: Int, val expanded: Boolean) : WorkspaceExplorerRow {
        override val key: String = "folder:$path"
    }
    data class File(val note: NoteMeta, val depth: Int) : WorkspaceExplorerRow {
        override val key: String = "file:${note.id}"
    }
}

private fun normaliseWorkspaceFolder(folder: String): String =
    folder.replace('\\', '/').trim('/').replace(Regex("/+"), "/")

private fun buildWorkspaceExplorerIndex(notes: List<NoteMeta>): WorkspaceExplorerIndex {
    val notesByFolder = LinkedHashMap<String, MutableList<NoteMeta>>()
    val children = LinkedHashMap<String, LinkedHashSet<String>>()
    children.getOrPut("") { linkedSetOf() }

    notes.forEach { note ->
        val folder = normaliseWorkspaceFolder(note.folder)
        notesByFolder.getOrPut(folder) { mutableListOf() }.add(note)
        if (folder.isNotBlank()) {
            val parts = folder.split('/').filter { it.isNotBlank() }
            var parent = ""
            parts.forEach { part ->
                val path = if (parent.isEmpty()) part else "$parent/$part"
                children.getOrPut(parent) { linkedSetOf() }.add(path)
                children.getOrPut(path) { linkedSetOf() }
                parent = path
            }
        }
    }
    val sortedNotes = notesByFolder.mapValues { (_, list) ->
        list.sortedWith(compareBy<NoteMeta>({ it.title.lowercase() }, { it.relPath.lowercase() }))
    }
    val sortedChildren = children.mapValues { (_, list) ->
        list.sortedBy { it.substringAfterLast('/').lowercase() }
    }
    return WorkspaceExplorerIndex(sortedNotes, sortedChildren)
}

private fun flattenWorkspaceTree(
    index: WorkspaceExplorerIndex,
    expanded: Set<String>
): List<WorkspaceExplorerRow> {
    val rows = ArrayList<WorkspaceExplorerRow>()
    fun appendFolder(parent: String, depth: Int) {
        index.childFolders[parent].orEmpty().forEach { path ->
            val isExpanded = path in expanded
            rows += WorkspaceExplorerRow.Folder(path, depth, isExpanded)
            if (isExpanded) {
                index.notesByFolder[path].orEmpty().forEach { rows += WorkspaceExplorerRow.File(it, depth + 1) }
                appendFolder(path, depth + 1)
            }
        }
    }
    index.notesByFolder[""].orEmpty().forEach { rows += WorkspaceExplorerRow.File(it, 0) }
    appendFolder("", 0)
    return rows
}

private fun folderAncestors(folder: String): Set<String> {
    val normalized = normaliseWorkspaceFolder(folder)
    if (normalized.isBlank()) return emptySet()
    val out = LinkedHashSet<String>()
    var path = ""
    normalized.split('/').filter { it.isNotBlank() }.forEach { part ->
        path = if (path.isEmpty()) part else "$path/$part"
        out += path
    }
    return out
}

@Composable
private fun WorkspaceNavigator(
    widthDp: Float,
    notes: List<NoteMeta>,
    tabs: List<TabInfo>,
    activeTab: Long?,
    recent: List<com.tebogo.markvault.data.RecentNote>,
    favourites: List<NoteMeta>,
    favouriteIds: Set<Long>,
    topics: List<TopicCard>,
    searchResults: List<com.tebogo.markvault.data.SearchHit>,
    section: String,
    compactRows: Boolean,
    onSection: (String) -> Unit,
    onToggleCompact: () -> Unit,
    onSelectTab: (TabInfo) -> Unit,
    onCloseTab: (Long) -> Unit,
    onOpenNote: (NoteMeta) -> Unit,
    onOpenRecent: (Long, String, String) -> Unit,
    onToggleFavourite: (Long) -> Unit,
    onOpenTopic: (String) -> Unit,
    onOpenResult: (com.tebogo.markvault.data.SearchHit) -> Unit,
    onNewTab: () -> Unit
) {
    val index = remember(notes) { buildWorkspaceExplorerIndex(notes) }
    var query by rememberSaveable { mutableStateOf("") }
    var expandedFolders by remember { mutableStateOf(emptySet<String>()) }

    LaunchedEffect(activeTab, notes) {
        val active = activeTab?.let { id -> notes.firstOrNull { it.id == id } }
        if (active != null) expandedFolders = expandedFolders + folderAncestors(active.folder)
    }

    val visibleTree = remember(index, expandedFolders) { flattenWorkspaceTree(index, expandedFolders) }
    val filteredNotes = remember(notes, query) {
        val q = query.trim()
        if (q.isBlank()) emptyList()
        else notes.asSequence().filter { note ->
            note.title.contains(q, ignoreCase = true) ||
                note.name.contains(q, ignoreCase = true) ||
                note.relPath.contains(q, ignoreCase = true)
        }.take(400).toList()
    }

    Column(
        Modifier.width(widthDp.dp).fillMaxHeight().background(MaterialTheme.colorScheme.surface.copy(alpha = 0.985f))
    ) {
        Row(
            Modifier.fillMaxWidth().height(68.dp).padding(start = 16.dp, end = 10.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column(Modifier.weight(1f)) {
                Text("VAULT", fontSize = 14.sp, fontWeight = FontWeight.Black, color = MaterialTheme.colorScheme.primary)
                Text(
                    "${notes.size} indexed files",
                    fontSize = 15.sp,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
            Surface(
                color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.65f),
                shape = RoundedCornerShape(6.dp),
                modifier = Modifier.clickable(onClick = onToggleCompact)
            ) {
                Text(
                    if (compactRows) "Compact" else "Comfort",
                    Modifier.padding(horizontal = 7.dp, vertical = 5.dp),
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Bold
                )
            }
        }
        HorizontalDivider(color = MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.65f))

        Row(
            Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()).padding(horizontal = 6.dp, vertical = 5.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(3.dp)
        ) {
            NavigatorSectionButton("Files", section == "files") { onSection("files") }
            NavigatorSectionButton("★ Bookmarks", section == "favourites") { onSection("favourites") }
            NavigatorSectionButton("Recent", section == "recent") { onSection("recent") }
            NavigatorSectionButton("Topics", section == "topics") { onSection("topics") }
            NavigatorSectionButton("Tabs", section == "tabs") { onSection("tabs") }
            NavigatorSectionButton("Results", section == "results") { onSection("results") }
        }
        HorizontalDivider(color = MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.65f))

        when (section) {
            "tabs" -> WorkspaceTabsSection(tabs, activeTab, compactRows, onSelectTab, onCloseTab)
            "results" -> WorkspaceSearchResultsSection(searchResults, activeTab, onOpenResult)
            "favourites" -> WorkspaceNoteListSection(
                title = "FAVOURITES",
                notes = favourites,
                activeTab = activeTab,
                favouriteIds = favouriteIds,
                compactRows = compactRows,
                emptyText = "No favourite notes yet",
                onOpenNote = onOpenNote,
                onToggleFavourite = onToggleFavourite
            )
            "recent" -> WorkspaceRecentSection(recent, activeTab, compactRows, onOpenRecent)
            "topics" -> WorkspaceTopicsSection(topics, onOpenTopic)
            else -> {
                OutlinedTextField(
                    value = query,
                    onValueChange = { query = it },
                    modifier = Modifier.fillMaxWidth().padding(horizontal = 8.dp, vertical = 7.dp),
                    singleLine = true,
                    placeholder = { Text("Filter vault…", fontSize = 13.sp, fontWeight = FontWeight.Medium) },
                    leadingIcon = { Text("⌕", fontSize = 15.sp, color = MaterialTheme.colorScheme.onSurfaceVariant) },
                    trailingIcon = if (query.isNotEmpty()) {
                        { Text("×", Modifier.clickable { query = "" }.padding(7.dp), fontSize = 16.sp) }
                    } else null,
                    textStyle = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.Medium)
                )
                if (query.isNotBlank()) {
                    Text(
                        if (filteredNotes.size >= 400) "MATCHES · first 400" else "MATCHES · ${filteredNotes.size}",
                        Modifier.padding(horizontal = 12.dp, vertical = 2.dp),
                        fontSize = 9.sp,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                    LazyColumn(Modifier.weight(1f).fillMaxWidth().padding(horizontal = 5.dp)) {
                        items(filteredNotes, key = { "workspace-filter-${it.id}" }) { note ->
                            WorkspaceFileRow(
                                note = note,
                                depth = 0,
                                active = note.id == activeTab,
                                favourite = note.id in favouriteIds,
                                compact = compactRows,
                                showPath = true,
                                onOpen = { onOpenNote(note) },
                                onToggleFavourite = { onToggleFavourite(note.id) }
                            )
                        }
                    }
                } else {
                    LazyColumn(Modifier.weight(1f).fillMaxWidth().padding(horizontal = 4.dp, vertical = 3.dp)) {
                        items(visibleTree, key = { it.key }) { row ->
                            when (row) {
                                is WorkspaceExplorerRow.Folder -> WorkspaceFolderRow(
                                    row = row,
                                    compact = compactRows,
                                    onToggle = {
                                        expandedFolders = if (row.path in expandedFolders) {
                                            expandedFolders - row.path
                                        } else expandedFolders + row.path
                                    }
                                )
                                is WorkspaceExplorerRow.File -> WorkspaceFileRow(
                                    note = row.note,
                                    depth = row.depth,
                                    active = row.note.id == activeTab,
                                    favourite = row.note.id in favouriteIds,
                                    compact = compactRows,
                                    showPath = false,
                                    onOpen = { onOpenNote(row.note) },
                                    onToggleFavourite = { onToggleFavourite(row.note.id) }
                                )
                            }
                        }
                    }
                }
            }
        }

        HorizontalDivider(color = MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.65f))
        Row(
            Modifier.fillMaxWidth().clickable(onClick = onNewTab).padding(horizontal = 11.dp, vertical = 9.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Icon(Icons.Default.Add, contentDescription = null, modifier = Modifier.size(15.dp))
            Spacer(Modifier.width(7.dp))
            Text("Open another view", fontSize = 13.sp, fontWeight = FontWeight.SemiBold)
        }
    }
}

@Composable
private fun WorkspaceFolderRow(row: WorkspaceExplorerRow.Folder, compact: Boolean, onToggle: () -> Unit) {
    val height = if (compact) 27.dp else 34.dp
    Row(
        Modifier.fillMaxWidth().height(height).clip(RoundedCornerShape(5.dp)).clickable(onClick = onToggle)
            .padding(start = (6 + row.depth * 13).dp, end = 5.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(if (row.expanded) "⌄" else "›", fontSize = 13.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
        Spacer(Modifier.width(3.dp))
        Text("▰", fontSize = 11.sp, color = MaterialTheme.colorScheme.primary.copy(alpha = 0.78f))
        Spacer(Modifier.width(6.dp))
        Text(
            row.path.substringAfterLast('/'),
            Modifier.weight(1f),
            maxLines = 1,
            overflow = TextOverflow.Ellipsis,
            fontSize = if (compact) 12.sp else 14.sp,
            fontWeight = FontWeight.SemiBold
        )
    }
}

@OptIn(ExperimentalFoundationApi::class)
@Composable
private fun WorkspaceFileRow(
    note: NoteMeta,
    depth: Int,
    active: Boolean,
    favourite: Boolean,
    compact: Boolean,
    showPath: Boolean,
    onOpen: () -> Unit,
    onToggleFavourite: () -> Unit
) {
    var menuOpen by remember { mutableStateOf(false) }
    val rowHeight = if (showPath) (if (compact) 39.dp else 47.dp) else (if (compact) 28.dp else 36.dp)
    Box {
        Surface(
            color = if (active) MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.68f) else Color.Transparent,
            shape = RoundedCornerShape(6.dp),
            modifier = Modifier.fillMaxWidth().padding(vertical = 1.dp)
                .combinedClickable(onClick = onOpen, onLongClick = { menuOpen = true })
        ) {
            Row(
                Modifier.height(rowHeight).padding(start = (8 + depth * 13).dp, end = 5.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    workspaceFileGlyph(note.fileType),
                    color = if (active) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurfaceVariant,
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Bold
                )
                Spacer(Modifier.width(6.dp))
                Column(Modifier.weight(1f)) {
                    Text(
                        note.title.ifBlank { note.name },
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis,
                        fontSize = if (compact) 12.sp else 14.sp,
                        fontWeight = if (active) FontWeight.Bold else FontWeight.Medium,
                        color = if (active) MaterialTheme.colorScheme.onPrimaryContainer else MaterialTheme.colorScheme.onSurface
                    )
                    if (showPath) {
                        Text(
                            note.relPath,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis,
                            fontSize = 10.sp,
                            fontWeight = FontWeight.Medium,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                            fontStyle = FontStyle.Italic
                        )
                    }
                }
                if (favourite) Text("★", fontSize = 10.sp, color = MaterialTheme.colorScheme.tertiary)
            }
        }
        DropdownMenu(expanded = menuOpen, onDismissRequest = { menuOpen = false }) {
            DropdownMenuItem(text = { Text("Open") }, onClick = { menuOpen = false; onOpen() })
            DropdownMenuItem(
                text = { Text(if (favourite) "Remove from favourites" else "Add to favourites") },
                onClick = { menuOpen = false; onToggleFavourite() }
            )
        }
    }
}

@Composable
private fun ColumnScope.WorkspaceNoteListSection(
    title: String,
    notes: List<NoteMeta>,
    activeTab: Long?,
    favouriteIds: Set<Long>,
    compactRows: Boolean,
    emptyText: String,
    onOpenNote: (NoteMeta) -> Unit,
    onToggleFavourite: (Long) -> Unit
) {
    Text(title, Modifier.padding(start = 12.dp, top = 9.dp, bottom = 3.dp), fontSize = 9.sp, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.onSurfaceVariant)
    if (notes.isEmpty()) {
        Box(Modifier.weight(1f).fillMaxWidth(), contentAlignment = Alignment.Center) {
            Text(emptyText, fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
    } else {
        LazyColumn(Modifier.weight(1f).fillMaxWidth().padding(horizontal = 5.dp)) {
            items(notes, key = { "workspace-note-${it.id}" }) { note ->
                WorkspaceFileRow(
                    note = note, depth = 0, active = note.id == activeTab,
                    favourite = note.id in favouriteIds, compact = compactRows, showPath = true,
                    onOpen = { onOpenNote(note) }, onToggleFavourite = { onToggleFavourite(note.id) }
                )
            }
        }
    }
}

@Composable
private fun ColumnScope.WorkspaceRecentSection(
    recent: List<com.tebogo.markvault.data.RecentNote>,
    activeTab: Long?,
    compactRows: Boolean,
    onOpenRecent: (Long, String, String) -> Unit
) {
    Text("RECENT FILES", Modifier.padding(start = 12.dp, top = 9.dp, bottom = 3.dp), fontSize = 9.sp, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.onSurfaceVariant)
    LazyColumn(Modifier.weight(1f).fillMaxWidth().padding(horizontal = 5.dp)) {
        items(recent, key = { "workspace-recent-${it.id}" }) { item ->
            val selected = item.id == activeTab
            Surface(
                color = if (selected) MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.68f) else Color.Transparent,
                shape = RoundedCornerShape(6.dp),
                modifier = Modifier.fillMaxWidth().padding(vertical = 1.dp).clickable { onOpenRecent(item.id, item.title, item.fileType) }
            ) {
                Row(
                    Modifier.padding(horizontal = 8.dp, vertical = if (compactRows) 6.dp else 9.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(workspaceFileGlyph(item.fileType), fontSize = 11.sp, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary)
                    Spacer(Modifier.width(7.dp))
                    Column(Modifier.weight(1f)) {
                        Text(item.title, maxLines = 1, overflow = TextOverflow.Ellipsis, fontSize = if (compactRows) 10.sp else 11.sp)
                        if (!compactRows && item.folder.isNotBlank()) Text(item.folder, maxLines = 1, overflow = TextOverflow.Ellipsis, fontSize = 8.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                }
            }
        }
    }
}

@Composable
private fun ColumnScope.WorkspaceTopicsSection(topics: List<TopicCard>, onOpenTopic: (String) -> Unit) {
    Text("TOPICS", Modifier.padding(start = 12.dp, top = 9.dp, bottom = 3.dp), fontSize = 9.sp, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.onSurfaceVariant)
    LazyColumn(Modifier.weight(1f).fillMaxWidth().padding(horizontal = 5.dp)) {
        items(topics, key = { "workspace-topic-${it.key}" }) { topic ->
            Row(
                Modifier.fillMaxWidth().clip(RoundedCornerShape(6.dp)).clickable { onOpenTopic(topic.key) }.padding(horizontal = 8.dp, vertical = 8.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(topic.emoji, fontSize = 13.sp)
                Spacer(Modifier.width(7.dp))
                Text(topic.label, Modifier.weight(1f), fontSize = 11.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                Text(topic.count.toString(), fontSize = 9.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
        }
    }
}

@Composable
private fun ColumnScope.WorkspaceSearchResultsSection(
    results: List<com.tebogo.markvault.data.SearchHit>,
    activeTab: Long?,
    onOpen: (com.tebogo.markvault.data.SearchHit) -> Unit
) {
    Text(
        "SEARCH RESULTS · ${results.size}",
        Modifier.padding(horizontal = 12.dp, vertical = 8.dp),
        fontSize = 9.sp, fontWeight = FontWeight.Bold,
        color = MaterialTheme.colorScheme.onSurfaceVariant
    )
    if (results.isEmpty()) {
        Text("Run a search to populate this panel.", Modifier.padding(12.dp),
            fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
    } else {
        LazyColumn(Modifier.weight(1f).fillMaxWidth().padding(horizontal = 6.dp)) {
            items(results, key = { "workspace-result-${it.id}" }) { hit ->
                Surface(
                    color = if (hit.id == activeTab) MaterialTheme.colorScheme.primaryContainer else Color.Transparent,
                    shape = RoundedCornerShape(8.dp),
                    modifier = Modifier.fillMaxWidth().padding(vertical = 2.dp).clickable { onOpen(hit) }
                ) {
                    Column(Modifier.padding(horizontal = 8.dp, vertical = 7.dp)) {
                        Text(hit.title, maxLines = 2, overflow = TextOverflow.Ellipsis, fontSize = 11.sp,
                            fontWeight = if (hit.id == activeTab) FontWeight.SemiBold else FontWeight.Normal)
                        if (hit.snippet.isNotBlank()) {
                            Text(hit.snippet, maxLines = 2, overflow = TextOverflow.Ellipsis, fontSize = 9.sp,
                                color = MaterialTheme.colorScheme.onSurfaceVariant)
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun ColumnScope.WorkspaceTabsSection(
    tabs: List<TabInfo>, activeTab: Long?, compactRows: Boolean,
    onSelectTab: (TabInfo) -> Unit, onCloseTab: (Long) -> Unit
) {
    Text("OPEN TABS", Modifier.padding(start = 12.dp, top = 9.dp, bottom = 3.dp), fontSize = 9.sp, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.onSurfaceVariant)
    LazyColumn(Modifier.weight(1f).fillMaxWidth().padding(horizontal = 5.dp)) {
        items(tabs, key = { "workspace-tab-${it.id}" }) { tab ->
            val selected = tab.id == activeTab
            Surface(
                color = if (selected) MaterialTheme.colorScheme.secondaryContainer.copy(alpha = 0.72f) else Color.Transparent,
                shape = RoundedCornerShape(6.dp),
                modifier = Modifier.fillMaxWidth().padding(vertical = 1.dp)
            ) {
                Row(
                    Modifier.clickable { onSelectTab(tab) }.padding(start = 8.dp).height(if (compactRows) 30.dp else 38.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(workspaceFileGlyph(tab.fileType), fontSize = 10.sp, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary)
                    Spacer(Modifier.width(6.dp))
                    Text(tab.title, Modifier.weight(1f), maxLines = 1, overflow = TextOverflow.Ellipsis, fontSize = if (compactRows) 10.sp else 11.sp, fontWeight = if (selected) FontWeight.SemiBold else FontWeight.Normal)
                    IconButton(onClick = { onCloseTab(tab.id) }, modifier = Modifier.size(27.dp)) {
                        Icon(Icons.Default.Close, contentDescription = "Close ${tab.title}", modifier = Modifier.size(12.dp))
                    }
                }
            }
        }
    }
}

private fun workspaceFileGlyph(fileType: String): String = when (fileType.lowercase()) {
    "pdf" -> "PDF"
    "html", "htm", "mhtml" -> "◇"
    else -> "≡"
}

@Composable
private fun NavigatorSectionButton(label: String, selected: Boolean, onClick: () -> Unit) {
    Surface(
        color = if (selected) MaterialTheme.colorScheme.surfaceVariant else Color.Transparent,
        shape = RoundedCornerShape(7.dp),
        modifier = Modifier.clickable(onClick = onClick)
    ) {
        Text(
            label,
            Modifier.padding(horizontal = 12.dp, vertical = 8.dp),
            fontSize = 15.sp,
            fontWeight = if (selected) FontWeight.Black else FontWeight.Bold,
            color = if (selected) MaterialTheme.colorScheme.onSurface else MaterialTheme.colorScheme.onSurfaceVariant
        )
    }
}

@Composable
private fun WorkspaceInspector(
    widthDp: Float,
    vm: AppViewModel,
    activeTab: TabInfo?,
    onOpenLinkedNote: (Long, String) -> Unit,
    onSearch: () -> Unit,
    onChat: () -> Unit,
    onGraph: () -> Unit,
    onClose: () -> Unit
) {
    var section by rememberSaveable { mutableStateOf("outline") }
    var note by remember(activeTab?.id) { mutableStateOf<Note?>(null) }
    var forwardLinks by remember(activeTab?.id) { mutableStateOf<List<LinkedNote>>(emptyList()) }
    var backlinks by remember(activeTab?.id) { mutableStateOf<List<LinkedNote>>(emptyList()) }

    LaunchedEffect(activeTab?.id) {
        val id = activeTab?.id
        if (id == null) {
            note = null
            forwardLinks = emptyList()
            backlinks = emptyList()
        } else {
            note = vm.noteById(id)
            forwardLinks = vm.loadForwardLinks(id)
            backlinks = vm.loadBacklinks(id)
        }
    }

    val outline: List<OutlineItem> = remember(note?.id, note?.lastModified) {
        note?.takeIf { it.fileType.equals("md", true) }
            ?.let { AppViewModel.parseOutline(it.content) }
            ?: emptyList()
    }

    Column(
        Modifier.width(widthDp.dp).fillMaxHeight().background(MaterialTheme.colorScheme.surface)
    ) {
        Row(
            Modifier.fillMaxWidth().height(42.dp).padding(start = 10.dp, end = 5.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text("Inspector", Modifier.weight(1f), fontSize = 18.sp, fontWeight = FontWeight.Black)
            IconButton(onClick = onClose, modifier = Modifier.size(30.dp)) {
                Icon(Icons.Default.Close, contentDescription = "Close inspector", modifier = Modifier.size(20.dp))
            }
        }
        HorizontalDivider(color = MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.65f))

        Row(
            Modifier.fillMaxWidth().padding(horizontal = 7.dp, vertical = 7.dp),
            horizontalArrangement = Arrangement.spacedBy(4.dp)
        ) {
            WorkspaceInspectorTab("Outline", "outline", section, Modifier.weight(1f)) { section = "outline" }
            WorkspaceInspectorTab("Links", "links", section, Modifier.weight(1f)) { section = "links" }
            WorkspaceInspectorTab("Info", "info", section, Modifier.weight(1f)) { section = "info" }
            WorkspaceInspectorTab("Props", "properties", section, Modifier.weight(1f)) { section = "properties" }
            WorkspaceInspectorTab("AI", "ai", section, Modifier.weight(1f)) { section = "ai" }
        }

        HorizontalDivider(color = MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.45f))

        if (activeTab == null) {
            Column(Modifier.fillMaxSize().padding(12.dp)) {
                Text("WORKSPACE", fontSize = 11.sp, fontWeight = FontWeight.Black, color = MaterialTheme.colorScheme.onSurfaceVariant)
                Text("No document tab is active.", Modifier.padding(top = 7.dp, bottom = 12.dp), fontSize = 14.sp, fontWeight = FontWeight.Medium)
                WorkspaceInspectorAction("⌕", "Search library", onSearch)
                WorkspaceInspectorAction("◇", "Graph view", onGraph)
                WorkspaceInspectorAction("AI", "AI workspace", onChat)
            }
        } else {
            Column(Modifier.fillMaxWidth().padding(horizontal = 10.dp, vertical = 8.dp)) {
                Text(
                    activeTab.title,
                    fontSize = 14.sp,
                    fontWeight = FontWeight.Bold,
                    maxLines = 2,
                    overflow = TextOverflow.Ellipsis
                )
                val typeLabel = when (activeTab.fileType.lowercase()) {
                    "pdf" -> "PDF document"
                    "html", "htm", "mhtml" -> "Web document"
                    else -> "Markdown note"
                }
                Text(typeLabel, fontSize = 11.sp, fontWeight = FontWeight.Medium, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }

            when (section) {
                "links" -> WorkspaceInspectorLinks(
                    forwardLinks = forwardLinks,
                    backlinks = backlinks,
                    onOpenLinkedNote = onOpenLinkedNote
                )
                "info" -> WorkspaceInspectorInfo(note = note, outlineCount = outline.size, linkCount = forwardLinks.size + backlinks.size)
                "properties" -> WorkspaceInspectorProperties(note)
                "ai" -> WorkspaceInspectorAi(onSearch = onSearch, onChat = onChat, onGraph = onGraph)
                else -> WorkspaceInspectorOutline(outline = outline, fileType = activeTab.fileType)
            }
        }
    }
}

@Composable
private fun WorkspaceInspectorTab(
    label: String,
    id: String,
    selected: String,
    modifier: Modifier = Modifier,
    onClick: () -> Unit
) {
    val active = selected == id
    Surface(
        modifier = modifier.height(30.dp).clip(RoundedCornerShape(7.dp)).clickable(onClick = onClick),
        color = if (active) MaterialTheme.colorScheme.secondaryContainer else Color.Transparent,
        shape = RoundedCornerShape(7.dp)
    ) {
        Box(contentAlignment = Alignment.Center) {
            Text(
                label,
                fontSize = 11.sp,
                fontWeight = if (active) FontWeight.Bold else FontWeight.SemiBold,
                color = if (active) MaterialTheme.colorScheme.onSecondaryContainer else MaterialTheme.colorScheme.onSurfaceVariant
            )
        }
    }
}

@Composable
private fun WorkspaceInspectorOutline(outline: List<OutlineItem>, fileType: String) {
    if (!fileType.equals("md", true)) {
        Box(Modifier.fillMaxSize().padding(14.dp), contentAlignment = Alignment.TopStart) {
            Text(
                "Outline is available for Markdown notes. HTML and PDF keep their existing document-specific outline tools.",
                fontSize = 12.sp,
                fontWeight = FontWeight.Medium,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
        }
        return
    }
    if (outline.isEmpty()) {
        Box(Modifier.fillMaxSize().padding(14.dp), contentAlignment = Alignment.TopStart) {
            Text("No headings in this note.", fontSize = 12.sp, fontWeight = FontWeight.Medium, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
        return
    }
    LazyColumn(Modifier.fillMaxSize().padding(horizontal = 6.dp, vertical = 4.dp)) {
        items(outline, key = { item: OutlineItem -> "outline-${item.index}-${item.title}" }) { item: OutlineItem ->
            Row(
                Modifier.fillMaxWidth().padding(
                    start = (6 + ((item.level - 1).coerceIn(0, 5) * 10)).dp,
                    end = 6.dp,
                    top = 5.dp,
                    bottom = 5.dp
                ),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text("•", fontSize = 12.sp, color = MaterialTheme.colorScheme.primary)
                Spacer(Modifier.width(6.dp))
                Text(
                    item.title,
                    fontSize = if (item.level <= 2) 13.sp else 12.sp,
                    fontWeight = if (item.level <= 2) FontWeight.Bold else FontWeight.Medium,
                    maxLines = 2,
                    overflow = TextOverflow.Ellipsis
                )
            }
        }
    }
}

@Composable
private fun WorkspaceInspectorLinks(
    forwardLinks: List<LinkedNote>,
    backlinks: List<LinkedNote>,
    onOpenLinkedNote: (Long, String) -> Unit
) {
    if (forwardLinks.isEmpty() && backlinks.isEmpty()) {
        Box(Modifier.fillMaxSize().padding(14.dp), contentAlignment = Alignment.TopStart) {
            Text("No resolved links or backlinks for this note.", fontSize = 12.sp, fontWeight = FontWeight.Medium, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
        return
    }
    LazyColumn(Modifier.fillMaxSize().padding(horizontal = 7.dp, vertical = 5.dp)) {
        if (forwardLinks.isNotEmpty()) {
            item {
                Text("OUTGOING · ${forwardLinks.size}", Modifier.padding(5.dp), fontSize = 11.sp, fontWeight = FontWeight.Black, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
            items(forwardLinks, key = { link: LinkedNote -> "out-${link.id}" }) { link: LinkedNote ->
                WorkspaceInspectorLinkedNote("→", link, onOpenLinkedNote)
            }
        }
        if (backlinks.isNotEmpty()) {
            item {
                Text("BACKLINKS · ${backlinks.size}", Modifier.padding(start = 5.dp, top = 10.dp, end = 5.dp, bottom = 5.dp), fontSize = 11.sp, fontWeight = FontWeight.Black, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
            items(backlinks, key = { link: LinkedNote -> "back-${link.id}" }) { link: LinkedNote ->
                WorkspaceInspectorLinkedNote("←", link, onOpenLinkedNote)
            }
        }
    }
}

@Composable
private fun WorkspaceInspectorLinkedNote(
    symbol: String,
    link: LinkedNote,
    onOpenLinkedNote: (Long, String) -> Unit
) {
    Row(
        Modifier.fillMaxWidth().clip(RoundedCornerShape(7.dp)).clickable {
            onOpenLinkedNote(link.id, link.title)
        }.padding(horizontal = 7.dp, vertical = 7.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(symbol, fontSize = 13.sp, color = MaterialTheme.colorScheme.primary)
        Spacer(Modifier.width(7.dp))
        Text(link.title, Modifier.weight(1f), fontSize = 12.sp, fontWeight = FontWeight.Medium, maxLines = 2, overflow = TextOverflow.Ellipsis)
    }
}

@Composable
private fun WorkspaceInspectorInfo(note: Note?, outlineCount: Int, linkCount: Int) {
    if (note == null) {
        Text("Loading document information…", Modifier.padding(14.dp), fontSize = 10.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
        return
    }
    LazyColumn(Modifier.fillMaxSize().padding(horizontal = 10.dp, vertical = 6.dp)) {
        item { WorkspaceInfoRow("Type", note.fileType.uppercase()) }
        item { WorkspaceInfoRow("Folder", note.folder.ifBlank { "Vault root" }) }
        item { WorkspaceInfoRow("Path", note.relPath.ifBlank { note.name }) }
        item { WorkspaceInfoRow("Size", workspaceFileSize(note.size)) }
        if (note.fileType.equals("md", true)) {
            item { WorkspaceInfoRow("Headings", outlineCount.toString()) }
            item { WorkspaceInfoRow("Connections", linkCount.toString()) }
        }
        item { WorkspaceInfoRow("Modified", java.text.DateFormat.getDateTimeInstance(java.text.DateFormat.MEDIUM, java.text.DateFormat.SHORT).format(java.util.Date(note.lastModified))) }
    }
}

@Composable
private fun WorkspaceInspectorProperties(note: Note?) {
    val properties = remember(note?.id, note?.lastModified) {
        val content = note?.content.orEmpty()
        if (!content.startsWith("---")) emptyList() else {
            val end = content.indexOf("\n---", startIndex = 3)
            if (end <= 3) emptyList() else content.substring(3, end).lineSequence().mapNotNull { line ->
                val colon = line.indexOf(':')
                if (colon <= 0) null else line.substring(0, colon).trim().takeIf { it.isNotBlank() }?.let { key -> key to line.substring(colon + 1).trim() }
            }.toList()
        }
    }
    if (note == null) {
        Text("Loading properties…", Modifier.padding(14.dp), fontSize = 11.sp)
        return
    }
    if (properties.isEmpty()) {
        Column(Modifier.fillMaxSize().padding(12.dp)) {
            Text("PROPERTIES", fontSize = 11.sp, fontWeight = FontWeight.Black, color = MaterialTheme.colorScheme.onSurfaceVariant)
            Text("No YAML/frontmatter properties found in this note.", Modifier.padding(top = 8.dp), fontSize = 12.sp, fontWeight = FontWeight.Medium)
        }
        return
    }
    LazyColumn(Modifier.fillMaxSize().padding(horizontal = 10.dp, vertical = 6.dp)) {
        items(properties, key = { it.first }) { property -> WorkspaceInfoRow(property.first, property.second.ifBlank { "—" }) }
    }
}

@Composable
private fun WorkspaceInfoRow(label: String, value: String) {
    Column(Modifier.fillMaxWidth().padding(vertical = 6.dp)) {
        Text(label.uppercase(), fontSize = 10.sp, fontWeight = FontWeight.Black, color = MaterialTheme.colorScheme.onSurfaceVariant)
        Text(value, Modifier.padding(top = 2.dp), fontSize = 12.sp, fontWeight = FontWeight.Medium, maxLines = 4, overflow = TextOverflow.Ellipsis)
    }
    HorizontalDivider(color = MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.35f))
}

@Composable
private fun WorkspaceInspectorAi(onSearch: () -> Unit, onChat: () -> Unit, onGraph: () -> Unit) {
    Column(Modifier.fillMaxWidth().padding(10.dp)) {
        Text("CONTEXT TOOLS", fontSize = 11.sp, fontWeight = FontWeight.Black, color = MaterialTheme.colorScheme.onSurfaceVariant)
        Spacer(Modifier.height(5.dp))
        WorkspaceInspectorAction("AI", "Chat with library", onChat)
        WorkspaceInspectorAction("⌕", "Semantic / library search", onSearch)
        WorkspaceInspectorAction("◇", "Explore connections in graph", onGraph)
        Spacer(Modifier.height(10.dp))
        Text(
            "In-article Smart Popup and AI Summary remain attached to the active reader so they keep the current highlighted passage and article context.",
            fontSize = 11.sp,
            fontWeight = FontWeight.Medium,
            color = MaterialTheme.colorScheme.onSurfaceVariant
        )
    }
}

private fun workspaceFileSize(bytes: Long): String = when {
    bytes >= 1024L * 1024L -> String.format(java.util.Locale.US, "%.1f MB", bytes / (1024.0 * 1024.0))
    bytes >= 1024L -> String.format(java.util.Locale.US, "%.1f KB", bytes / 1024.0)
    else -> "$bytes B"
}

@Composable
private fun WorkspaceInspectorAction(symbol: String, label: String, onClick: () -> Unit) {
    Row(
        Modifier.fillMaxWidth().clip(RoundedCornerShape(7.dp)).clickable(onClick = onClick).padding(horizontal = 7.dp, vertical = 8.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(symbol, fontSize = 12.sp, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary)
        Spacer(Modifier.width(8.dp))
        Text(label, fontSize = 13.sp, fontWeight = FontWeight.SemiBold)
    }
}

private fun workspaceRouteLabel(route: String): String = when {
    route == "home" -> "Home"
    route == "search" -> "Search"
    route == "browse" -> "Library"
    route == "graph" -> "Graph"
    route == "settings" -> "Settings"
    route == "chat" -> "AI Chat"
    route == "workspacePanes" -> "Workspace Panes"
    route.startsWith("web") -> "Web"
    route.startsWith("topic") -> "Topics"
    route.startsWith("media") -> "Media"
    route.isBlank() -> "Workspace"
    else -> route.substringBefore('/').replaceFirstChar { it.uppercase() }
}
