package com.tebogo.markvault.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Menu
import androidx.compose.material.icons.filled.MoreVert
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.VerticalDivider
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalConfiguration
import androidx.compose.ui.text.font.FontStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.navigation.NavController
import androidx.navigation.compose.currentBackStackEntryAsState
import com.tebogo.markvault.AppViewModel
import com.tebogo.markvault.TabInfo
import com.tebogo.markvault.data.NoteMeta
import com.tebogo.markvault.data.TopicCard

/**
 * v5.4.314cc — Persistent tablet Workspace shell + Obsidian-style vault explorer.
 *
 * This is deliberately a *layout* layer, not a second navigation stack.  The
 * existing NavHost remains the single source of truth for screen navigation,
 * while the shell adds the pieces that make Workspace mode behave like a
 * tablet/desktop workspace: ribbon, collapsible navigator, document tabs and
 * a right inspector frame.  Standard mode bypasses this composable entirely.
 */
@Composable
fun WorkspaceTabletShell(
    vm: AppViewModel,
    nav: NavController,
    content: @Composable () -> Unit
) {
    val uiMode by vm.uiMode.collectAsStateWithLifecycle()
    val tablet = LocalConfiguration.current.screenWidthDp >= 600
    if (uiMode != "workspace" || !tablet) {
        content()
        return
    }

    val tabs by vm.tabs.collectAsStateWithLifecycle()
    val activeTab by vm.activeTab.collectAsStateWithLifecycle()
    val recent by vm.recent.collectAsStateWithLifecycle()
    val notes by vm.notes.collectAsStateWithLifecycle()
    val favourites by vm.favouriteNotes.collectAsStateWithLifecycle()
    val favouriteIds by vm.favouriteIds.collectAsStateWithLifecycle()
    val topics by vm.topics.collectAsStateWithLifecycle()
    val navigatorOpen by vm.workspaceNavOpen.collectAsStateWithLifecycle()
    val navigatorSection by vm.workspaceNavSection.collectAsStateWithLifecycle()
    val compactRows by vm.workspaceCompact.collectAsStateWithLifecycle()
    val backStackEntry by nav.currentBackStackEntryAsState()
    val route = backStackEntry?.destination?.route.orEmpty()

    var inspectorOpen by rememberSaveable { mutableStateOf(false) }

    fun setNavigatorOpen(open: Boolean) = vm.setWorkspaceNavOpen(open)
    fun selectNavigatorSection(section: String) {
        vm.setWorkspaceNavSection(section)
        if (!navigatorOpen) vm.setWorkspaceNavOpen(true)
    }

    Surface(
        modifier = Modifier.fillMaxSize(),
        color = MaterialTheme.colorScheme.background
    ) {
        Column(Modifier.fillMaxSize()) {
            WorkspaceDocumentBar(
                tabs = tabs,
                activeTab = activeTab,
                route = route,
                navigatorOpen = navigatorOpen,
                inspectorOpen = inspectorOpen,
                onToggleNavigator = { setNavigatorOpen(!navigatorOpen) },
                onToggleInspector = { inspectorOpen = !inspectorOpen },
                onOpenHome = { nav.navigate("home") { launchSingleTop = true } },
                onSelectTab = { tab -> openWorkspaceTab(vm, nav, tab) },
                onCloseTab = vm::closeTab
            )
            HorizontalDivider(color = MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.65f))

            Row(Modifier.fillMaxSize()) {
                WorkspaceRibbon(
                    selectedRoute = route,
                    navigatorOpen = navigatorOpen,
                    onToggleNavigator = { setNavigatorOpen(!navigatorOpen) },
                    onHome = { nav.navigate("home") { launchSingleTop = true } },
                    onSearch = { nav.navigate("search") { launchSingleTop = true } },
                    onBrowse = { selectNavigatorSection("files") },
                    onGraph = { nav.navigate("graph") { launchSingleTop = true } },
                    onWeb = { openWorkspaceBrowser(vm, nav) },
                    onSettings = { nav.navigate("settings") { launchSingleTop = true } }
                )

                if (navigatorOpen) {
                    VerticalDivider(color = MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.6f))
                    WorkspaceNavigator(
                        notes = notes,
                        tabs = tabs,
                        activeTab = activeTab,
                        recent = recent,
                        favourites = favourites,
                        favouriteIds = favouriteIds,
                        topics = topics,
                        section = navigatorSection,
                        compactRows = compactRows,
                        onSection = ::selectNavigatorSection,
                        onToggleCompact = { vm.setWorkspaceCompact(!compactRows) },
                        onSelectTab = { tab -> openWorkspaceTab(vm, nav, tab) },
                        onCloseTab = vm::closeTab,
                        onOpenNote = { note ->
                            vm.openArticle(note.id, note.title, fileType = note.fileType)
                            openWorkspaceTab(vm, nav, TabInfo(note.id, note.title, note.fileType))
                        },
                        onOpenRecent = { id, title, fileType ->
                            vm.openArticle(id, title, fileType = fileType)
                            openWorkspaceTab(vm, nav, TabInfo(id, title, fileType))
                        },
                        onToggleFavourite = vm::toggleFavourite,
                        onOpenTopic = { key -> nav.navigate("topic/$key") { launchSingleTop = true } },
                        onNewTab = { nav.navigate("home") { launchSingleTop = true } }
                    )
                }

                if (navigatorOpen) {
                    VerticalDivider(color = MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.6f))
                }

                Box(Modifier.weight(1f).fillMaxHeight()) {
                    content()
                }

                if (inspectorOpen) {
                    VerticalDivider(color = MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.6f))
                    WorkspaceInspector(
                        activeTab = tabs.firstOrNull { it.id == activeTab },
                        onSearch = { nav.navigate("search") { launchSingleTop = true } },
                        onChat = { nav.navigate("chat") { launchSingleTop = true } },
                        onGraph = { nav.navigate("graph") { launchSingleTop = true } },
                        onClose = { inspectorOpen = false }
                    )
                }
            }
        }
    }
}


private fun openWorkspaceBrowser(vm: AppViewModel, nav: NavController) {
    val tabs = vm.webTabs
    val active = if (tabs.isEmpty()) null else tabs[vm.webActiveTabIdx.coerceIn(0, tabs.lastIndex)]
    val url = active?.url ?: "https://www.jw.org"
    val label = active?.title?.ifBlank { "Tab" } ?: "jw.org"
    val encUrl = java.net.URLEncoder.encode(url, "UTF-8")
    val encLabel = java.net.URLEncoder.encode(label, "UTF-8")
    nav.navigate("web/$encUrl/$encLabel") { launchSingleTop = true }
}

private fun openWorkspaceTab(vm: AppViewModel, nav: NavController, tab: TabInfo) {
    vm.setActiveTab(tab.id)
    when (tab.fileType.lowercase()) {
        "pdf" -> nav.navigate("pdfReader/${tab.id}") { launchSingleTop = true }
        "html", "htm", "mhtml" -> nav.navigate("htmlReader/${tab.id}") { launchSingleTop = true }
        else -> nav.navigate("reader") { launchSingleTop = true }
    }
}

@Composable
private fun WorkspaceDocumentBar(
    tabs: List<TabInfo>,
    activeTab: Long?,
    route: String,
    navigatorOpen: Boolean,
    inspectorOpen: Boolean,
    onToggleNavigator: () -> Unit,
    onToggleInspector: () -> Unit,
    onOpenHome: () -> Unit,
    onSelectTab: (TabInfo) -> Unit,
    onCloseTab: (Long) -> Unit
) {
    val scroll = rememberScrollState()
    Row(
        Modifier.fillMaxWidth().height(42.dp).background(MaterialTheme.colorScheme.surface),
        verticalAlignment = Alignment.CenterVertically
    ) {
        IconButton(onClick = onToggleNavigator, modifier = Modifier.size(40.dp)) {
            Icon(Icons.Default.Menu, contentDescription = if (navigatorOpen) "Close workspace navigator" else "Open workspace navigator")
        }
        Text(
            "MarkVault",
            fontSize = 13.sp,
            fontWeight = FontWeight.SemiBold,
            color = MaterialTheme.colorScheme.onSurface,
            modifier = Modifier.padding(end = 8.dp)
        )
        VerticalDivider(Modifier.height(24.dp), color = MaterialTheme.colorScheme.outlineVariant)

        Row(
            Modifier.weight(1f).horizontalScroll(scroll).padding(horizontal = 4.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            val routeIsReader = route.startsWith("reader") || route.startsWith("pdfReader") ||
                route.startsWith("htmlReader") || route.startsWith("splitReader")
            if (!routeIsReader) {
                WorkspaceViewTab(
                    label = workspaceRouteLabel(route),
                    selected = true,
                    onClick = {},
                    onClose = null
                )
            }
            tabs.forEach { tab ->
                WorkspaceViewTab(
                    label = tab.title,
                    selected = routeIsReader && tab.id == activeTab,
                    leading = when (tab.fileType.lowercase()) {
                        "pdf" -> "PDF"
                        "html", "htm", "mhtml" -> "WEB"
                        else -> "MD"
                    },
                    onClick = { onSelectTab(tab) },
                    onClose = { onCloseTab(tab.id) }
                )
            }
            IconButton(onClick = onOpenHome, modifier = Modifier.size(34.dp)) {
                Icon(Icons.Default.Add, contentDescription = "New workspace tab", modifier = Modifier.size(17.dp))
            }
        }

        VerticalDivider(Modifier.height(24.dp), color = MaterialTheme.colorScheme.outlineVariant)
        Surface(
            color = if (inspectorOpen) MaterialTheme.colorScheme.secondaryContainer else Color.Transparent,
            shape = RoundedCornerShape(7.dp),
            modifier = Modifier.padding(horizontal = 4.dp)
        ) {
            IconButton(onClick = onToggleInspector, modifier = Modifier.size(34.dp)) {
                Icon(Icons.Default.MoreVert, contentDescription = if (inspectorOpen) "Close inspector" else "Open inspector", modifier = Modifier.size(18.dp))
            }
        }
    }
}

@Composable
private fun WorkspaceViewTab(
    label: String,
    selected: Boolean,
    leading: String? = null,
    onClick: () -> Unit,
    onClose: (() -> Unit)?
) {
    Surface(
        color = if (selected) MaterialTheme.colorScheme.surfaceVariant else Color.Transparent,
        shape = RoundedCornerShape(topStart = 8.dp, topEnd = 8.dp),
        modifier = Modifier.height(34.dp).widthIn(min = 92.dp, max = 220.dp).padding(horizontal = 1.dp)
    ) {
        Row(
            Modifier.clickable(onClick = onClick).padding(start = 9.dp, end = 3.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            if (leading != null) {
                Text(leading, fontSize = 8.sp, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary)
                Spacer(Modifier.width(6.dp))
            }
            Text(
                label,
                modifier = Modifier.weight(1f, fill = false),
                maxLines = 1,
                overflow = TextOverflow.Ellipsis,
                fontSize = 11.sp,
                fontWeight = if (selected) FontWeight.SemiBold else FontWeight.Normal,
                color = if (selected) MaterialTheme.colorScheme.onSurface else MaterialTheme.colorScheme.onSurfaceVariant
            )
            if (onClose != null) {
                IconButton(onClick = onClose, modifier = Modifier.size(26.dp)) {
                    Icon(Icons.Default.Close, contentDescription = "Close tab", modifier = Modifier.size(13.dp))
                }
            } else {
                Spacer(Modifier.width(7.dp))
            }
        }
    }
}

@Composable
private fun WorkspaceRibbon(
    selectedRoute: String,
    navigatorOpen: Boolean,
    onToggleNavigator: () -> Unit,
    onHome: () -> Unit,
    onSearch: () -> Unit,
    onBrowse: () -> Unit,
    onGraph: () -> Unit,
    onWeb: () -> Unit,
    onSettings: () -> Unit
) {
    Column(
        Modifier.width(48.dp).fillMaxHeight().background(MaterialTheme.colorScheme.surface),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        WorkspaceRibbonButton("☰", "Navigator", navigatorOpen, onToggleNavigator)
        Spacer(Modifier.height(6.dp))
        WorkspaceRibbonButton("⌂", "Home", selectedRoute == "home", onHome)
        WorkspaceRibbonButton("⌕", "Search", selectedRoute == "search", onSearch)
        WorkspaceRibbonButton("▤", "Library", selectedRoute == "browse", onBrowse)
        WorkspaceRibbonButton("◇", "Graph", selectedRoute == "graph", onGraph)
        WorkspaceRibbonButton("◎", "Web", selectedRoute.startsWith("web"), onWeb)
        Spacer(Modifier.weight(1f))
        WorkspaceRibbonButton("⚙", "Settings", selectedRoute == "settings", onSettings)
        Spacer(Modifier.height(6.dp))
    }
}

@Composable
private fun WorkspaceRibbonButton(
    symbol: String,
    description: String,
    selected: Boolean,
    onClick: () -> Unit
) {
    Surface(
        color = if (selected) MaterialTheme.colorScheme.primaryContainer else Color.Transparent,
        shape = RoundedCornerShape(9.dp),
        modifier = Modifier.padding(vertical = 2.dp).size(38.dp).clip(RoundedCornerShape(9.dp)).clickable(onClick = onClick)
    ) {
        Box(contentAlignment = Alignment.Center) {
            Text(
                symbol,
                fontSize = if (symbol == "⚙") 17.sp else 18.sp,
                fontWeight = FontWeight.Medium,
                color = if (selected) MaterialTheme.colorScheme.onPrimaryContainer else MaterialTheme.colorScheme.onSurfaceVariant
            )
        }
    }
}

private data class WorkspaceExplorerIndex(
    val notesByFolder: Map<String, List<NoteMeta>>,
    val childFolders: Map<String, List<String>>
)

private sealed interface WorkspaceExplorerRow {
    val key: String
    data class Folder(val path: String, val depth: Int, val expanded: Boolean) : WorkspaceExplorerRow {
        override val key: String = "folder:$path"
    }
    data class File(val note: NoteMeta, val depth: Int) : WorkspaceExplorerRow {
        override val key: String = "file:${note.id}"
    }
}

private fun normaliseWorkspaceFolder(folder: String): String =
    folder.replace('\\', '/').trim('/').replace(Regex("/+"), "/")

private fun buildWorkspaceExplorerIndex(notes: List<NoteMeta>): WorkspaceExplorerIndex {
    val notesByFolder = LinkedHashMap<String, MutableList<NoteMeta>>()
    val children = LinkedHashMap<String, LinkedHashSet<String>>()
    children.getOrPut("") { linkedSetOf() }

    notes.forEach { note ->
        val folder = normaliseWorkspaceFolder(note.folder)
        notesByFolder.getOrPut(folder) { mutableListOf() }.add(note)
        if (folder.isNotBlank()) {
            val parts = folder.split('/').filter { it.isNotBlank() }
            var parent = ""
            parts.forEach { part ->
                val path = if (parent.isEmpty()) part else "$parent/$part"
                children.getOrPut(parent) { linkedSetOf() }.add(path)
                children.getOrPut(path) { linkedSetOf() }
                parent = path
            }
        }
    }
    val sortedNotes = notesByFolder.mapValues { (_, list) ->
        list.sortedWith(compareBy<NoteMeta>({ it.title.lowercase() }, { it.relPath.lowercase() }))
    }
    val sortedChildren = children.mapValues { (_, list) ->
        list.sortedBy { it.substringAfterLast('/').lowercase() }
    }
    return WorkspaceExplorerIndex(sortedNotes, sortedChildren)
}

private fun flattenWorkspaceTree(
    index: WorkspaceExplorerIndex,
    expanded: Set<String>
): List<WorkspaceExplorerRow> {
    val rows = ArrayList<WorkspaceExplorerRow>()
    fun appendFolder(parent: String, depth: Int) {
        index.childFolders[parent].orEmpty().forEach { path ->
            val isExpanded = path in expanded
            rows += WorkspaceExplorerRow.Folder(path, depth, isExpanded)
            if (isExpanded) {
                index.notesByFolder[path].orEmpty().forEach { rows += WorkspaceExplorerRow.File(it, depth + 1) }
                appendFolder(path, depth + 1)
            }
        }
    }
    index.notesByFolder[""].orEmpty().forEach { rows += WorkspaceExplorerRow.File(it, 0) }
    appendFolder("", 0)
    return rows
}

private fun folderAncestors(folder: String): Set<String> {
    val normalized = normaliseWorkspaceFolder(folder)
    if (normalized.isBlank()) return emptySet()
    val out = LinkedHashSet<String>()
    var path = ""
    normalized.split('/').filter { it.isNotBlank() }.forEach { part ->
        path = if (path.isEmpty()) part else "$path/$part"
        out += path
    }
    return out
}

@Composable
private fun WorkspaceNavigator(
    notes: List<NoteMeta>,
    tabs: List<TabInfo>,
    activeTab: Long?,
    recent: List<com.tebogo.markvault.data.RecentNote>,
    favourites: List<NoteMeta>,
    favouriteIds: Set<Long>,
    topics: List<TopicCard>,
    section: String,
    compactRows: Boolean,
    onSection: (String) -> Unit,
    onToggleCompact: () -> Unit,
    onSelectTab: (TabInfo) -> Unit,
    onCloseTab: (Long) -> Unit,
    onOpenNote: (NoteMeta) -> Unit,
    onOpenRecent: (Long, String, String) -> Unit,
    onToggleFavourite: (Long) -> Unit,
    onOpenTopic: (String) -> Unit,
    onNewTab: () -> Unit
) {
    val index = remember(notes) { buildWorkspaceExplorerIndex(notes) }
    var query by rememberSaveable { mutableStateOf("") }
    var expandedFolders by remember { mutableStateOf(emptySet<String>()) }

    LaunchedEffect(activeTab, notes) {
        val active = activeTab?.let { id -> notes.firstOrNull { it.id == id } }
        if (active != null) expandedFolders = expandedFolders + folderAncestors(active.folder)
    }

    val visibleTree = remember(index, expandedFolders) { flattenWorkspaceTree(index, expandedFolders) }
    val filteredNotes = remember(notes, query) {
        val q = query.trim()
        if (q.isBlank()) emptyList()
        else notes.asSequence().filter { note ->
            note.title.contains(q, ignoreCase = true) ||
                note.name.contains(q, ignoreCase = true) ||
                note.relPath.contains(q, ignoreCase = true)
        }.take(400).toList()
    }

    Column(
        Modifier.width(286.dp).fillMaxHeight().background(MaterialTheme.colorScheme.surface.copy(alpha = 0.985f))
    ) {
        Row(
            Modifier.fillMaxWidth().height(44.dp).padding(start = 11.dp, end = 5.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column(Modifier.weight(1f)) {
                Text("VAULT", fontSize = 9.sp, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary)
                Text(
                    "${notes.size} indexed files",
                    fontSize = 11.sp,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
            Surface(
                color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.65f),
                shape = RoundedCornerShape(6.dp),
                modifier = Modifier.clickable(onClick = onToggleCompact)
            ) {
                Text(
                    if (compactRows) "Compact" else "Comfort",
                    Modifier.padding(horizontal = 7.dp, vertical = 5.dp),
                    fontSize = 9.sp,
                    fontWeight = FontWeight.Medium
                )
            }
        }
        HorizontalDivider(color = MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.65f))

        Row(
            Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()).padding(horizontal = 6.dp, vertical = 5.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(3.dp)
        ) {
            NavigatorSectionButton("Files", section == "files") { onSection("files") }
            NavigatorSectionButton("★", section == "favourites") { onSection("favourites") }
            NavigatorSectionButton("Recent", section == "recent") { onSection("recent") }
            NavigatorSectionButton("Topics", section == "topics") { onSection("topics") }
            NavigatorSectionButton("Tabs", section == "tabs") { onSection("tabs") }
        }
        HorizontalDivider(color = MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.65f))

        when (section) {
            "tabs" -> WorkspaceTabsSection(tabs, activeTab, compactRows, onSelectTab, onCloseTab)
            "favourites" -> WorkspaceNoteListSection(
                title = "FAVOURITES",
                notes = favourites,
                activeTab = activeTab,
                favouriteIds = favouriteIds,
                compactRows = compactRows,
                emptyText = "No favourite notes yet",
                onOpenNote = onOpenNote,
                onToggleFavourite = onToggleFavourite
            )
            "recent" -> WorkspaceRecentSection(recent, activeTab, compactRows, onOpenRecent)
            "topics" -> WorkspaceTopicsSection(topics, onOpenTopic)
            else -> {
                OutlinedTextField(
                    value = query,
                    onValueChange = { query = it },
                    modifier = Modifier.fillMaxWidth().padding(horizontal = 8.dp, vertical = 7.dp),
                    singleLine = true,
                    placeholder = { Text("Filter vault…", fontSize = 11.sp) },
                    leadingIcon = { Text("⌕", fontSize = 15.sp, color = MaterialTheme.colorScheme.onSurfaceVariant) },
                    trailingIcon = if (query.isNotEmpty()) {
                        { Text("×", Modifier.clickable { query = "" }.padding(7.dp), fontSize = 16.sp) }
                    } else null,
                    textStyle = MaterialTheme.typography.bodySmall
                )
                if (query.isNotBlank()) {
                    Text(
                        if (filteredNotes.size >= 400) "MATCHES · first 400" else "MATCHES · ${filteredNotes.size}",
                        Modifier.padding(horizontal = 12.dp, vertical = 2.dp),
                        fontSize = 9.sp,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                    LazyColumn(Modifier.weight(1f).fillMaxWidth().padding(horizontal = 5.dp)) {
                        items(filteredNotes, key = { "workspace-filter-${it.id}" }) { note ->
                            WorkspaceFileRow(
                                note = note,
                                depth = 0,
                                active = note.id == activeTab,
                                favourite = note.id in favouriteIds,
                                compact = compactRows,
                                showPath = true,
                                onOpen = { onOpenNote(note) },
                                onToggleFavourite = { onToggleFavourite(note.id) }
                            )
                        }
                    }
                } else {
                    LazyColumn(Modifier.weight(1f).fillMaxWidth().padding(horizontal = 4.dp, vertical = 3.dp)) {
                        items(visibleTree, key = { it.key }) { row ->
                            when (row) {
                                is WorkspaceExplorerRow.Folder -> WorkspaceFolderRow(
                                    row = row,
                                    compact = compactRows,
                                    onToggle = {
                                        expandedFolders = if (row.path in expandedFolders) {
                                            expandedFolders - row.path
                                        } else expandedFolders + row.path
                                    }
                                )
                                is WorkspaceExplorerRow.File -> WorkspaceFileRow(
                                    note = row.note,
                                    depth = row.depth,
                                    active = row.note.id == activeTab,
                                    favourite = row.note.id in favouriteIds,
                                    compact = compactRows,
                                    showPath = false,
                                    onOpen = { onOpenNote(row.note) },
                                    onToggleFavourite = { onToggleFavourite(row.note.id) }
                                )
                            }
                        }
                    }
                }
            }
        }

        HorizontalDivider(color = MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.65f))
        Row(
            Modifier.fillMaxWidth().clickable(onClick = onNewTab).padding(horizontal = 11.dp, vertical = 9.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Icon(Icons.Default.Add, contentDescription = null, modifier = Modifier.size(15.dp))
            Spacer(Modifier.width(7.dp))
            Text("Open another view", fontSize = 11.sp)
        }
    }
}

@Composable
private fun WorkspaceFolderRow(row: WorkspaceExplorerRow.Folder, compact: Boolean, onToggle: () -> Unit) {
    val height = if (compact) 27.dp else 34.dp
    Row(
        Modifier.fillMaxWidth().height(height).clip(RoundedCornerShape(5.dp)).clickable(onClick = onToggle)
            .padding(start = (6 + row.depth * 13).dp, end = 5.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(if (row.expanded) "⌄" else "›", fontSize = 13.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
        Spacer(Modifier.width(3.dp))
        Text("▰", fontSize = 11.sp, color = MaterialTheme.colorScheme.primary.copy(alpha = 0.78f))
        Spacer(Modifier.width(6.dp))
        Text(
            row.path.substringAfterLast('/'),
            Modifier.weight(1f),
            maxLines = 1,
            overflow = TextOverflow.Ellipsis,
            fontSize = if (compact) 11.sp else 12.sp,
            fontWeight = FontWeight.Medium
        )
    }
}

@OptIn(ExperimentalFoundationApi::class)
@Composable
private fun WorkspaceFileRow(
    note: NoteMeta,
    depth: Int,
    active: Boolean,
    favourite: Boolean,
    compact: Boolean,
    showPath: Boolean,
    onOpen: () -> Unit,
    onToggleFavourite: () -> Unit
) {
    var menuOpen by remember { mutableStateOf(false) }
    val rowHeight = if (showPath) (if (compact) 39.dp else 47.dp) else (if (compact) 28.dp else 36.dp)
    Box {
        Surface(
            color = if (active) MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.68f) else Color.Transparent,
            shape = RoundedCornerShape(6.dp),
            modifier = Modifier.fillMaxWidth().padding(vertical = 1.dp)
                .combinedClickable(onClick = onOpen, onLongClick = { menuOpen = true })
        ) {
            Row(
                Modifier.height(rowHeight).padding(start = (8 + depth * 13).dp, end = 5.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    workspaceFileGlyph(note.fileType),
                    color = if (active) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurfaceVariant,
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Bold
                )
                Spacer(Modifier.width(6.dp))
                Column(Modifier.weight(1f)) {
                    Text(
                        note.title.ifBlank { note.name },
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis,
                        fontSize = if (compact) 10.sp else 11.sp,
                        fontWeight = if (active) FontWeight.SemiBold else FontWeight.Normal,
                        color = if (active) MaterialTheme.colorScheme.onPrimaryContainer else MaterialTheme.colorScheme.onSurface
                    )
                    if (showPath) {
                        Text(
                            note.relPath,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis,
                            fontSize = 8.sp,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                            fontStyle = FontStyle.Italic
                        )
                    }
                }
                if (favourite) Text("★", fontSize = 10.sp, color = MaterialTheme.colorScheme.tertiary)
            }
        }
        DropdownMenu(expanded = menuOpen, onDismissRequest = { menuOpen = false }) {
            DropdownMenuItem(text = { Text("Open") }, onClick = { menuOpen = false; onOpen() })
            DropdownMenuItem(
                text = { Text(if (favourite) "Remove from favourites" else "Add to favourites") },
                onClick = { menuOpen = false; onToggleFavourite() }
            )
        }
    }
}

@Composable
private fun WorkspaceNoteListSection(
    title: String,
    notes: List<NoteMeta>,
    activeTab: Long?,
    favouriteIds: Set<Long>,
    compactRows: Boolean,
    emptyText: String,
    onOpenNote: (NoteMeta) -> Unit,
    onToggleFavourite: (Long) -> Unit
) {
    Text(title, Modifier.padding(start = 12.dp, top = 9.dp, bottom = 3.dp), fontSize = 9.sp, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.onSurfaceVariant)
    if (notes.isEmpty()) {
        Box(Modifier.weight(1f).fillMaxWidth(), contentAlignment = Alignment.Center) {
            Text(emptyText, fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
    } else {
        LazyColumn(Modifier.weight(1f).fillMaxWidth().padding(horizontal = 5.dp)) {
            items(notes, key = { "workspace-note-${it.id}" }) { note ->
                WorkspaceFileRow(
                    note = note, depth = 0, active = note.id == activeTab,
                    favourite = note.id in favouriteIds, compact = compactRows, showPath = true,
                    onOpen = { onOpenNote(note) }, onToggleFavourite = { onToggleFavourite(note.id) }
                )
            }
        }
    }
}

@Composable
private fun WorkspaceRecentSection(
    recent: List<com.tebogo.markvault.data.RecentNote>,
    activeTab: Long?,
    compactRows: Boolean,
    onOpenRecent: (Long, String, String) -> Unit
) {
    Text("RECENT FILES", Modifier.padding(start = 12.dp, top = 9.dp, bottom = 3.dp), fontSize = 9.sp, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.onSurfaceVariant)
    LazyColumn(Modifier.weight(1f).fillMaxWidth().padding(horizontal = 5.dp)) {
        items(recent, key = { "workspace-recent-${it.id}" }) { item ->
            val selected = item.id == activeTab
            Surface(
                color = if (selected) MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.68f) else Color.Transparent,
                shape = RoundedCornerShape(6.dp),
                modifier = Modifier.fillMaxWidth().padding(vertical = 1.dp).clickable { onOpenRecent(item.id, item.title, item.fileType) }
            ) {
                Row(
                    Modifier.padding(horizontal = 8.dp, vertical = if (compactRows) 6.dp else 9.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(workspaceFileGlyph(item.fileType), fontSize = 11.sp, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary)
                    Spacer(Modifier.width(7.dp))
                    Column(Modifier.weight(1f)) {
                        Text(item.title, maxLines = 1, overflow = TextOverflow.Ellipsis, fontSize = if (compactRows) 10.sp else 11.sp)
                        if (!compactRows && item.folder.isNotBlank()) Text(item.folder, maxLines = 1, overflow = TextOverflow.Ellipsis, fontSize = 8.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                }
            }
        }
    }
}

@Composable
private fun WorkspaceTopicsSection(topics: List<TopicCard>, onOpenTopic: (String) -> Unit) {
    Text("TOPICS", Modifier.padding(start = 12.dp, top = 9.dp, bottom = 3.dp), fontSize = 9.sp, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.onSurfaceVariant)
    LazyColumn(Modifier.weight(1f).fillMaxWidth().padding(horizontal = 5.dp)) {
        items(topics, key = { "workspace-topic-${it.key}" }) { topic ->
            Row(
                Modifier.fillMaxWidth().clip(RoundedCornerShape(6.dp)).clickable { onOpenTopic(topic.key) }.padding(horizontal = 8.dp, vertical = 8.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(topic.emoji, fontSize = 13.sp)
                Spacer(Modifier.width(7.dp))
                Text(topic.label, Modifier.weight(1f), fontSize = 11.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                Text(topic.count.toString(), fontSize = 9.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
        }
    }
}

@Composable
private fun WorkspaceTabsSection(
    tabs: List<TabInfo>, activeTab: Long?, compactRows: Boolean,
    onSelectTab: (TabInfo) -> Unit, onCloseTab: (Long) -> Unit
) {
    Text("OPEN TABS", Modifier.padding(start = 12.dp, top = 9.dp, bottom = 3.dp), fontSize = 9.sp, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.onSurfaceVariant)
    LazyColumn(Modifier.weight(1f).fillMaxWidth().padding(horizontal = 5.dp)) {
        items(tabs, key = { "workspace-tab-${it.id}" }) { tab ->
            val selected = tab.id == activeTab
            Surface(
                color = if (selected) MaterialTheme.colorScheme.secondaryContainer.copy(alpha = 0.72f) else Color.Transparent,
                shape = RoundedCornerShape(6.dp),
                modifier = Modifier.fillMaxWidth().padding(vertical = 1.dp)
            ) {
                Row(
                    Modifier.clickable { onSelectTab(tab) }.padding(start = 8.dp).height(if (compactRows) 30.dp else 38.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(workspaceFileGlyph(tab.fileType), fontSize = 10.sp, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary)
                    Spacer(Modifier.width(6.dp))
                    Text(tab.title, Modifier.weight(1f), maxLines = 1, overflow = TextOverflow.Ellipsis, fontSize = if (compactRows) 10.sp else 11.sp, fontWeight = if (selected) FontWeight.SemiBold else FontWeight.Normal)
                    IconButton(onClick = { onCloseTab(tab.id) }, modifier = Modifier.size(27.dp)) {
                        Icon(Icons.Default.Close, contentDescription = "Close ${tab.title}", modifier = Modifier.size(12.dp))
                    }
                }
            }
        }
    }
}

private fun workspaceFileGlyph(fileType: String): String = when (fileType.lowercase()) {
    "pdf" -> "PDF"
    "html", "htm", "mhtml" -> "◇"
    else -> "≡"
}

@Composable
private fun NavigatorSectionButton(label: String, selected: Boolean, onClick: () -> Unit) {
    Surface(
        color = if (selected) MaterialTheme.colorScheme.surfaceVariant else Color.Transparent,
        shape = RoundedCornerShape(7.dp),
        modifier = Modifier.clickable(onClick = onClick)
    ) {
        Text(
            label,
            Modifier.padding(horizontal = 10.dp, vertical = 6.dp),
            fontSize = 11.sp,
            fontWeight = if (selected) FontWeight.SemiBold else FontWeight.Normal,
            color = if (selected) MaterialTheme.colorScheme.onSurface else MaterialTheme.colorScheme.onSurfaceVariant
        )
    }
}

@Composable
private fun WorkspaceInspector(
    activeTab: TabInfo?,
    onSearch: () -> Unit,
    onChat: () -> Unit,
    onGraph: () -> Unit,
    onClose: () -> Unit
) {
    Column(
        Modifier.width(228.dp).fillMaxHeight().background(MaterialTheme.colorScheme.surface).padding(10.dp)
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text("Inspector", Modifier.weight(1f), fontSize = 13.sp, fontWeight = FontWeight.SemiBold)
            IconButton(onClick = onClose, modifier = Modifier.size(28.dp)) {
                Icon(Icons.Default.Close, contentDescription = "Close inspector", modifier = Modifier.size(14.dp))
            }
        }
        HorizontalDivider(Modifier.padding(vertical = 6.dp))
        Text("ACTIVE VIEW", fontSize = 9.sp, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.onSurfaceVariant)
        Text(
            activeTab?.title ?: "Workspace",
            Modifier.padding(top = 5.dp, bottom = 12.dp),
            fontSize = 12.sp,
            fontWeight = FontWeight.Medium,
            maxLines = 3,
            overflow = TextOverflow.Ellipsis
        )
        WorkspaceInspectorAction("⌕", "Search library", onSearch)
        WorkspaceInspectorAction("◇", "Graph view", onGraph)
        WorkspaceInspectorAction("AI", "AI workspace", onChat)
        Spacer(Modifier.height(12.dp))
        Text(
            "Article outline, links and contextual tools remain available in the reader panel while the workspace shell is active.",
            fontSize = 10.sp,
            color = MaterialTheme.colorScheme.onSurfaceVariant
        )
    }
}

@Composable
private fun WorkspaceInspectorAction(symbol: String, label: String, onClick: () -> Unit) {
    Row(
        Modifier.fillMaxWidth().clip(RoundedCornerShape(7.dp)).clickable(onClick = onClick).padding(horizontal = 7.dp, vertical = 8.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(symbol, fontSize = 12.sp, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary)
        Spacer(Modifier.width(8.dp))
        Text(label, fontSize = 11.sp)
    }
}

private fun workspaceRouteLabel(route: String): String = when {
    route == "home" -> "Home"
    route == "search" -> "Search"
    route == "browse" -> "Library"
    route == "graph" -> "Graph"
    route == "settings" -> "Settings"
    route == "chat" -> "AI Chat"
    route.startsWith("web") -> "Web"
    route.startsWith("topic") -> "Topics"
    route.startsWith("media") -> "Media"
    route.isBlank() -> "Workspace"
    else -> route.substringBefore('/').replaceFirstChar { it.uppercase() }
}
