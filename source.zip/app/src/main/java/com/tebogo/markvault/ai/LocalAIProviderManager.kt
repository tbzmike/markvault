package com.tebogo.markvault.ai

/**
 * v5.4.77 — Provider lifecycle manager.
 */
object LocalAIProviderManager {

    private var provider: LocalAIProvider? = null

    fun acquire(): LocalAIProvider {
        if (provider == null) {
            provider = LiteRtLocalAIProvider(
                RetrievalModelManager.current().name,
                RetrievalModelPathResolver.pathFor(
                    RetrievalModelManager.current()
                )
            )
        }
        return provider!!
    }

    fun release() {
        provider = null
        System.gc()
    }
}
