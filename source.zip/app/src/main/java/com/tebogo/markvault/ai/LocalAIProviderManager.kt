package com.tebogo.markvault.ai

/**
 * v5.4.76 — Lightweight provider lifecycle manager.
 *
 * Keeps only the expansion model alive during inference.
 */
object LocalAIProviderManager {

    private var provider: LocalAIProvider? = null

    fun acquire(): LocalAIProvider {
        if (provider == null) {
            provider = LiteRtLocalAIProvider(
                RetrievalModelManager.current().name
            )
        }
        return provider!!
    }

    fun release() {
        provider = null
        System.gc()
    }
}

private class LiteRtLocalAIProvider(
    private val model: String
) : LocalAIProvider {

    override suspend fun expandQuery(query: String): List<String> {
        // Runtime inference connection point.
        return listOf(query)
    }

    override fun modelName(): String = model
}
