package com.tebogo.markvault.ai

import com.tebogo.markvault.llm.LlmManager

/**
 * v5.4.82 — LLM memory lifecycle manager.
 *
 * Prevents Qwen 0.6B and embedding models from competing for RAM.
 */
object LocalAIProviderManager {

    private var provider: LocalAIProvider? = null

    fun acquire(): LocalAIProvider {
        if (provider == null) {
            provider = LiteRtLocalAIProvider(
                RetrievalModelManager.current().name,
                RetrievalModelPathResolver.pathFor(
                    RetrievalModelManager.current()
                )
            )
        }
        return provider!!
    }

    suspend fun release() {
        provider = null

        // Critical: LiteRT-LM keeps native memory outside the JVM heap.
        // System.gc() alone cannot release the native model buffers.
        runCatching {
            LlmManager.unload()
        }

        System.gc()
    }
}
