package com.tebogo.markvault.data

/** A topic definition: a stable key, a display emoji + label, and the keywords/phrases that signal it. */
data class TopicDef(
    val key: String,
    val emoji: String,
    val label: String,
    val keywords: List<String>
)

/** A topic with how many notes currently fall under it (for cards / explorer). */
data class TopicCard(val key: String, val emoji: String, val label: String, val count: Int)

/**
 * Offline, rule-based topic engine. No machine-learning model — it classifies notes by
 * counting curated keyword/phrase hits, and expands searches with near-synonyms so a query
 * like "death" also surfaces notes about the dead, the grave, sheol, etc.
 */
object Topics {

    val ALL: List<TopicDef> = listOf(
        TopicDef("death", "\uD83D\uDC80", "Death",
            listOf("death", "dies", "died", "dying", "dead", "grave", "sheol", "hades",
                "mortal", "mortality", "perish", "tomb", "corpse", "deceased")),
        TopicDef("resurrection", "\uD83D\uDD4A\uFE0F", "Resurrection",
            listOf("resurrection", "resurrect", "resurrected", "raised up", "rise again",
                "awakening", "brought back to life", "raised to life")),
        TopicDef("eternal_life", "\u2728", "Eternal Life",
            listOf("eternal life", "everlasting life", "immortality", "live forever",
                "never die", "endless life", "live for ever")),
        TopicDef("soul", "\uD83E\uDDE0", "Soul",
            listOf("soul", "souls", "nephesh", "psyche", "living being")),
        TopicDef("spirit", "\uD83D\uDC7B", "Holy Spirit",
            listOf("holy spirit", "ruach", "pneuma", "active force", "breath of life",
                "spirit creature", "god's spirit")),
        TopicDef("prayer", "\uD83D\uDE4F", "Prayer",
            listOf("prayer", "prayers", "pray", "prayed", "praying", "supplication",
                "petition", "thanksgiving")),
        TopicDef("prophecy", "\uD83D\uDCD6", "Bible Prophecy",
            listOf("prophecy", "prophecies", "prophet", "prophetic", "fulfillment",
                "foretold", "time of the end", "seventy weeks", "daniel's prophecy")),
        TopicDef("judgment", "\u2696\uFE0F", "Judgment Day",
            listOf("judgment", "judgement", "judge", "judged", "day of judgment",
                "great tribulation", "armageddon", "condemned")),
        TopicDef("love", "\u2764\uFE0F", "Love",
            listOf("love", "loved", "loving", "agape", "kindness", "compassion",
                "mercy", "neighbor", "neighbour")),
        TopicDef("kingdom", "\uD83D\uDC51", "God's Kingdom",
            listOf("kingdom", "god's kingdom", "throne", "reign", "ruler",
                "government", "messianic", "millennial reign")),
        TopicDef("faith", "\uD83E\uDD1D", "Faith",
            listOf("faith", "faithful", "believe", "belief", "trust", "conviction")),
        TopicDef("hope", "\uD83C\uDF1F", "Hope & Paradise",
            listOf("hope", "new world", "paradise", "restoration", "new earth", "new heavens")),
        TopicDef("blood", "\uD83E\uDE78", "Blood",
            listOf("blood", "transfusion", "abstain from blood", "sanctity of life", "blood doctrine")),
        TopicDef("worship", "\uD83C\uDFDB\uFE0F", "True Worship",
            listOf("worship", "true worship", "pure worship", "sacred service", "draw close to jehovah")),
        TopicDef("divine_name", "\uD83D\uDCDB", "Divine Name",
            listOf("jehovah", "god's name", "tetragrammaton", "sanctify", "name of god",
                "divine name", "yhwh")),
        TopicDef("jesus", "\uD83D\uDC64", "Jesus Christ",
            listOf("jesus", "christ", "messiah", "son of god", "son of man", "lamb of god",
                "the word", "firstborn")),
        TopicDef("bible_history", "\uD83D\uDCDC", "Bible History",
            listOf("manuscript", "manuscripts", "codex", "sinaiticus", "vaticanus", "septuagint",
                "dead sea scrolls", "scribe", "the canon", "papyrus", "tikkune sopherim",
                "comma johanneum", "preservation of the bible")),
        TopicDef("knowing_god", "\uD83D\uDD26", "In Search of God",
            listOf("knowing god", "who is god", "in search of god", "draw close to god",
                "god's qualities", "attributes of god", "is there a god", "god's personality")),
        TopicDef("creation", "\uD83C\uDF0D", "Creation",
            listOf("creation", "creator", "created", "in the beginning", "genesis account",
                "intelligent design", "evolution", "the designer")),
        TopicDef("suffering", "\uD83D\uDD6F\uFE0F", "Why Suffering",
            listOf("suffering", "why does god allow", "permit suffering", "human suffering",
                "the problem of evil", "pain and suffering", "injustice")),
        TopicDef("family", "\uD83D\uDC6A", "Family & Marriage",
            listOf("marriage", "married", "husband", "wife", "family life", "raising children",
                "divorce", "headship", "parents and children")),
        TopicDef("angels", "\uD83D\uDE07", "Angels & Demons",
            listOf("angel", "angels", "archangel", "michael", "gabriel", "cherub", "seraph",
                "spirit creatures", "demon", "demons", "wicked spirits")),
        TopicDef("satan", "\uD83D\uDC09", "Satan the Devil",
            listOf("satan", "the devil", "devil", "serpent", "the dragon", "adversary",
                "ruler of this world", "god of this system")),
        TopicDef("salvation", "\uD83C\uDD98", "Salvation & Ransom",
            listOf("salvation", "be saved", "ransom", "redeem", "redemption",
                "ransom sacrifice", "atonement", "saved")),
        TopicDef("last_days", "\u23F3", "Last Days",
            listOf("last days", "sign of the", "system of things", "conclusion of the system",
                "wars", "famines", "earthquakes", "end of the world", "critical times")),
        TopicDef("preaching", "\uD83D\uDCE3", "Preaching Work",
            listOf("preaching", "preach", "the ministry", "good news", "make disciples",
                "house to house", "field service", "kingdom message", "evangelizing")),
        TopicDef("false_religion", "\u26EA", "False Religion",
            listOf("false religion", "babylon the great", "christendom", "apostasy",
                "false teachers", "trinity", "immortal soul", "hellfire", "purgatory")),
        TopicDef("holidays", "\uD83C\uDF89", "Holidays & Customs",
            listOf("christmas", "easter", "birthday", "birthdays", "halloween", "pagan origin",
                "pagan roots", "sun worship", "winter solstice")),
        TopicDef("conduct", "\u2705", "Christian Conduct",
            listOf("honesty", "integrity", "good conduct", "morality", "conscience", "modest",
                "chastity", "sexual immorality", "clean conduct")),
        TopicDef("jehovahs_people", "\uD83D\uDC65", "Jehovah's Witnesses",
            listOf("jehovah's witnesses", "faithful and discreet slave", "the governing body",
                "the congregation", "anointed", "144,000", "great crowd", "other sheep"))
    )

    private val byKey: Map<String, TopicDef> = ALL.associateBy { it.key }
    fun def(key: String): TopicDef? = byKey[key]

    // ---- Per-topic accent colours (ARGB) for cards, distributed by position ----
    private val PALETTE: List<Long> = listOf(
        0xFFEF5350, 0xFFAB47BC, 0xFF7E57C2, 0xFF5C6BC0, 0xFF42A5F5, 0xFF29B6F6,
        0xFF26C6DA, 0xFF26A69A, 0xFF66BB6A, 0xFF9CCC65, 0xFFD4E157, 0xFFFFCA28,
        0xFFFFA726, 0xFFFF7043, 0xFF8D6E63, 0xFF78909C, 0xFFEC407A
    )
    private val colorByKey: Map<String, Long> =
        ALL.mapIndexed { i, d -> d.key to PALETTE[i % PALETTE.size] }.toMap()

    fun colorFor(key: String): Long = colorByKey[key] ?: 0xFF8AB4F8

    private val compiled: List<Pair<TopicDef, Regex>> = ALL.map { d ->
        val alt = d.keywords.sortedByDescending { it.length }.joinToString("|") { Regex.escape(it) }
        d to Regex("(?<![\\p{L}])(?:$alt)(?![\\p{L}])", RegexOption.IGNORE_CASE)
    }

    /** Synonyms used to broaden full-text search (head term -> extra OR terms). */
    private val synonyms: Map<String, List<String>> = mapOf(
        "death" to listOf("dead", "dying", "grave", "sheol", "hades", "deceased"),
        "die" to listOf("death", "dead", "dying"),
        "dead" to listOf("death", "dying", "sheol", "grave"),
        "soul" to listOf("nephesh", "souls", "\"living being\""),
        "spirit" to listOf("ruach", "pneuma", "\"holy spirit\"", "\"active force\""),
        "resurrection" to listOf("resurrect", "raised", "\"rise again\""),
        "kingdom" to listOf("throne", "reign", "\"god's kingdom\""),
        "prayer" to listOf("pray", "supplication", "petition"),
        "judgment" to listOf("judge", "armageddon", "\"great tribulation\""),
        "love" to listOf("agape", "kindness", "compassion"),
        "hope" to listOf("paradise", "\"new world\"", "restoration"),
        "jesus" to listOf("christ", "messiah", "\"son of god\""),
        "jehovah" to listOf("\"god's name\"", "tetragrammaton"),
        "prophecy" to listOf("prophet", "\"time of the end\""),
        "michael" to listOf("archangel", "\"son of god\""),
        "satan" to listOf("devil", "serpent", "adversary"),
        "ransom" to listOf("redemption", "salvation", "atonement"),
        "bible" to listOf("scripture", "scriptures", "manuscript"),
        "angel" to listOf("angels", "archangel", "\"spirit creature\"")
    )

    /**
     * Classify a note. Returns (topicKey, score) for topics it belongs to.
     * A title hit is a strong signal; otherwise at least 3 body hits are required.
     */
    fun classify(title: String, content: String): List<Pair<String, Int>> {
        val out = ArrayList<Pair<String, Int>>()
        for ((d, rx) in compiled) {
            val titleHits = rx.findAll(title).count()
            val bodyHits = rx.findAll(content).count()
            if (titleHits >= 1 || bodyHits >= 3) {
                out.add(d.key to (titleHits * 5 + bodyHits))
            }
        }
        return out.sortedByDescending { it.second }.take(6)
    }

    /** Topics whose vocabulary appears in a free-text query (for search topic chips). */
    fun matchQuery(query: String): List<String> {
        val q = " ${query.lowercase().trim()} "
        if (q.isBlank()) return emptyList()
        val hits = ArrayList<String>()
        for (d in ALL) {
            val label = d.label.lowercase()
            if (q.contains(" $label ") || d.keywords.any { q.contains(it.lowercase()) }) hits.add(d.key)
        }
        return hits
    }

    /** Build an FTS MATCH string, expanding each word with near-synonyms (OR groups). */
    fun expandQuery(raw: String): String {
        val trimmed = raw.trim()
        if (trimmed.length >= 2 && trimmed.startsWith("\"") && trimmed.endsWith("\"")) return trimmed
        val tokens = trimmed.lowercase().replace(Regex("[^\\p{L}\\p{N}\\s]"), " ")
            .split(Regex("\\s+")).filter { it.isNotBlank() }
        if (tokens.isEmpty()) return "\"\""
        return tokens.joinToString(" ") { tok ->
            val syn = synonyms[tok]
            if (syn.isNullOrEmpty()) "$tok*"
            else "(" + (listOf("$tok*") + syn).joinToString(" OR ") + ")"
        }
    }
}
