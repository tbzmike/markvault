package com.tebogo.markvault.data

/** A topic definition: a stable key, a display emoji + label, and the keywords/phrases that signal it. */
data class TopicDef(
    val key: String,
    val emoji: String,
    val label: String,
    val keywords: List<String>
)

/** A topic with how many notes currently fall under it (for cards / explorer). */
data class TopicCard(val key: String, val emoji: String, val label: String, val count: Int)

/**
 * Offline, rule-based topic engine. No machine-learning model — it classifies notes by
 * counting curated keyword/phrase hits, and expands searches with near-synonyms so a query
 * like "death" also surfaces notes about the dead, the grave, sheol, etc.
 */
object Topics {

    val ALL: List<TopicDef> = listOf(
        TopicDef("death", "\uD83D\uDC80", "Death",
            listOf("death", "dies", "died", "dying", "dead", "grave", "sheol", "hades",
                "mortal", "mortality", "perish", "tomb", "corpse", "deceased")),
        TopicDef("resurrection", "\uD83D\uDD4A\uFE0F", "Resurrection",
            listOf("resurrection", "resurrect", "resurrected", "raised up", "rise again",
                "awakening", "brought back to life", "raised to life")),
        TopicDef("eternal_life", "\u2728", "Eternal Life",
            listOf("eternal life", "everlasting life", "immortality", "live forever",
                "never die", "endless life", "live for ever")),
        TopicDef("soul", "\uD83E\uDDE0", "Soul",
            listOf("soul", "souls", "nephesh", "psyche", "living being")),
        TopicDef("spirit", "\uD83D\uDC7B", "Spirit",
            listOf("spirit", "ruach", "pneuma", "holy spirit", "active force",
                "breath of life", "spirit creature")),
        TopicDef("prayer", "\uD83D\uDE4F", "Prayer",
            listOf("prayer", "prayers", "pray", "prayed", "praying", "supplication",
                "petition", "thanksgiving")),
        TopicDef("prophecy", "\uD83D\uDCD6", "Bible Prophecy",
            listOf("prophecy", "prophecies", "prophet", "prophetic", "fulfillment",
                "foretold", "last days", "time of the end")),
        TopicDef("judgment", "\u2696\uFE0F", "Judgment",
            listOf("judgment", "judgement", "judge", "judged", "day of judgment",
                "great tribulation", "armageddon", "condemned")),
        TopicDef("love", "\u2764\uFE0F", "Love",
            listOf("love", "loved", "loving", "agape", "kindness", "compassion",
                "mercy", "neighbor", "neighbour")),
        TopicDef("kingdom", "\uD83D\uDC51", "Kingdom",
            listOf("kingdom", "god's kingdom", "throne", "reign", "ruler",
                "government", "messianic")),
        TopicDef("faith", "\uD83E\uDD1D", "Faith",
            listOf("faith", "faithful", "believe", "belief", "trust", "conviction")),
        TopicDef("hope", "\uD83C\uDF1F", "Hope",
            listOf("hope", "new world", "paradise", "restoration", "new earth")),
        TopicDef("blood", "\uD83E\uDE78", "Blood",
            listOf("blood", "transfusion", "abstain from blood", "sanctity of life")),
        TopicDef("worship", "\uD83C\uDFDB\uFE0F", "Worship",
            listOf("worship", "true worship", "false religion", "idolatry",
                "pure worship", "babylon the great")),
        TopicDef("divine_name", "\uD83D\uDCDB", "Divine Name",
            listOf("jehovah", "god's name", "tetragrammaton", "sanctify", "name of god")),
        TopicDef("jesus", "\uD83D\uDC64", "Jesus",
            listOf("jesus", "christ", "messiah", "son of god", "ransom",
                "son of man", "lamb of god"))
    )

    private val byKey: Map<String, TopicDef> = ALL.associateBy { it.key }
    fun def(key: String): TopicDef? = byKey[key]

    private val compiled: List<Pair<TopicDef, Regex>> = ALL.map { d ->
        val alt = d.keywords.sortedByDescending { it.length }.joinToString("|") { Regex.escape(it) }
        d to Regex("(?<![\\p{L}])(?:$alt)(?![\\p{L}])", RegexOption.IGNORE_CASE)
    }

    /** Synonyms used to broaden full-text search (head term -> extra OR terms). */
    private val synonyms: Map<String, List<String>> = mapOf(
        "death" to listOf("dead", "dying", "grave", "sheol", "hades", "deceased"),
        "die" to listOf("death", "dead", "dying"),
        "dead" to listOf("death", "dying", "sheol", "grave"),
        "soul" to listOf("nephesh", "souls", "\"living being\""),
        "spirit" to listOf("ruach", "pneuma", "\"holy spirit\"", "\"active force\""),
        "resurrection" to listOf("resurrect", "raised", "\"rise again\""),
        "kingdom" to listOf("throne", "reign", "\"god's kingdom\""),
        "prayer" to listOf("pray", "supplication", "petition"),
        "judgment" to listOf("judge", "armageddon", "\"great tribulation\""),
        "love" to listOf("agape", "kindness", "compassion"),
        "hope" to listOf("paradise", "\"new world\"", "restoration"),
        "jesus" to listOf("christ", "messiah", "\"son of god\"", "ransom"),
        "jehovah" to listOf("\"god's name\"", "tetragrammaton"),
        "prophecy" to listOf("prophet", "\"last days\"", "\"time of the end\"")
    )

    /**
     * Classify a note. Returns (topicKey, score) for topics it belongs to.
     * A title hit is a strong signal; otherwise at least 3 body hits are required.
     */
    fun classify(title: String, content: String): List<Pair<String, Int>> {
        val out = ArrayList<Pair<String, Int>>()
        for ((d, rx) in compiled) {
            val titleHits = rx.findAll(title).count()
            val bodyHits = rx.findAll(content).count()
            if (titleHits >= 1 || bodyHits >= 3) {
                out.add(d.key to (titleHits * 5 + bodyHits))
            }
        }
        return out.sortedByDescending { it.second }.take(5)
    }

    /** Topics whose vocabulary appears in a free-text query (for search topic chips). */
    fun matchQuery(query: String): List<String> {
        val q = " ${query.lowercase().trim()} "
        if (q.isBlank()) return emptyList()
        val hits = ArrayList<String>()
        for (d in ALL) {
            val label = d.label.lowercase()
            if (q.contains(" $label ") || d.keywords.any { q.contains(it.lowercase()) }) hits.add(d.key)
        }
        return hits
    }

    /** Build an FTS MATCH string, expanding each word with near-synonyms (OR groups). */
    fun expandQuery(raw: String): String {
        val trimmed = raw.trim()
        if (trimmed.length >= 2 && trimmed.startsWith("\"") && trimmed.endsWith("\"")) return trimmed
        val tokens = trimmed.lowercase().replace(Regex("[^\\p{L}\\p{N}\\s]"), " ")
            .split(Regex("\\s+")).filter { it.isNotBlank() }
        if (tokens.isEmpty()) return "\"\""
        return tokens.joinToString(" ") { tok ->
            val syn = synonyms[tok]
            if (syn.isNullOrEmpty()) "$tok*"
            else "(" + (listOf("$tok*") + syn).joinToString(" OR ") + ")"
        }
    }
}
