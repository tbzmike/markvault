package com.tebogo.markvault.data

data class TopicDef(val key: String, val emoji: String, val label: String, val keywords: List<String>)
data class TopicCard(val key: String, val emoji: String, val label: String, val count: Int)

object Topics {

    /** Increment when the lexicon changes so notes can be auto-reclassified. */
    const val VERSION = 1

    val ALL: List<TopicDef> = listOf(
        TopicDef("death", "\uD83D\uDC80", "Death",
            listOf("death", "dies", "died", "dying", "dead", "grave", "sheol", "hades",
                "mortal", "mortality", "perish", "tomb", "corpse", "deceased")),
        TopicDef("resurrection", "\uD83D\uDD4A\uFE0F", "Resurrection",
            listOf("resurrection", "resurrect", "resurrected", "raised up", "rise again",
                "awakening", "brought back to life", "raised to life")),
        TopicDef("eternal_life", "\u2728", "Eternal Life",
            listOf("eternal life", "everlasting life", "immortality", "live forever",
                "never die", "endless life", "live for ever")),
        TopicDef("soul", "\uD83E\uDDE0", "Soul",
            listOf("soul", "souls", "nephesh", "psyche", "living being")),
        TopicDef("spirit", "\uD83D\uDC7B", "Spirit",
            listOf("spirit", "ruach", "pneuma", "holy spirit", "active force",
                "breath of life", "spirit creature")),
        TopicDef("prayer", "\uD83D\uDE4F", "Prayer",
            listOf("prayer", "prayers", "pray", "prayed", "praying", "supplication",
                "petition", "thanksgiving")),
        TopicDef("prophecy", "\uD83D\uDCD6", "Bible Prophecy",
            listOf("prophecy", "prophecies", "prophet", "prophetic", "fulfillment",
                "foretold", "last days", "time of the end")),
        TopicDef("judgment", "\u2696\uFE0F", "Judgment",
            listOf("judgment", "judgement", "judge", "judged", "day of judgment",
                "great tribulation", "armageddon", "condemned")),
        TopicDef("love", "\u2764\uFE0F", "Love",
            listOf("love", "loved", "loving", "agape", "kindness", "compassion",
                "mercy", "neighbor", "neighbour")),
        TopicDef("kingdom", "\uD83D\uDC51", "Kingdom",
            listOf("kingdom", "god's kingdom", "throne", "reign", "ruler",
                "government", "messianic")),
        TopicDef("faith", "\uD83E\uDD1D", "Faith",
            listOf("faith", "faithful", "believe", "belief", "trust", "conviction")),
        TopicDef("hope", "\uD83C\uDF1F", "Hope",
            listOf("hope", "new world", "paradise", "restoration", "new earth")),
        TopicDef("blood", "\uD83E\uDE78", "Blood",
            listOf("blood", "transfusion", "abstain from blood", "sanctity of life")),
        TopicDef("worship", "\uD83C\uDFDB\uFE0F", "Worship",
            listOf("worship", "true worship", "false religion", "idolatry",
                "pure worship", "babylon the great")),
        TopicDef("divine_name", "\uD83D\uDCDB", "Divine Name",
            listOf("jehovah", "god's name", "tetragrammaton", "sanctify", "name of god")),
        TopicDef("jesus", "\uD83D\uDC64", "Jesus",
            listOf("jesus", "christ", "messiah", "son of god", "ransom",
                "son of man", "lamb of god"))
    )

    private val byKey: Map<String, TopicDef> = ALL.associateBy { it.key }
    fun def(key: String): TopicDef? = byKey[key]

    private val compiled: List<Pair<TopicDef, Regex>> = ALL.map { d ->
        val alt = d.keywords.sortedByDescending { it.length }.joinToString("|") { Regex.escape(it) }
        d to Regex("(?<![\\p{L}])(?:$alt)(?![\\p{L}])", RegexOption.IGNORE_CASE)
    }

    private val synonyms: Map<String, List<String>> = mapOf(
        "death" to listOf("dead", "dying", "grave", "sheol", "hades", "deceased"),
        "die" to listOf("death", "dead", "dying"),
        "dead" to listOf("death", "dying", "sheol", "grave"),
        "soul" to listOf("nephesh", "souls", "\"living being\""),
        "spirit" to listOf("ruach", "pneuma", "\"holy spirit\"", "\"active force\""),
        "resurrection" to listOf("resurrect", "raised", "\"rise again\""),
        "kingdom" to listOf("throne", "reign", "\"god's kingdom\""),
        "prayer" to listOf("pray", "supplication", "petition"),
        "judgment" to listOf("judge", "armageddon", "\"great tribulation\""),
        "love" to listOf("agape", "kindness", "compassion"),
        "hope" to listOf("paradise", "\"new world\"", "restoration"),
        "jesus" to listOf("christ", "messiah", "\"son of god\"", "ransom"),
        "jehovah" to listOf("\"god's name\"", "tetragrammaton"),
        "prophecy" to listOf("prophet", "\"last days\"", "\"time of the end\"")
    )

    fun classify(title: String, content: String): List<Pair<String, Int>> {
        val out = ArrayList<Pair<String, Int>>()
        for ((d, rx) in compiled) {
            val titleHits = rx.findAll(title).count()
            val bodyHits = rx.findAll(content).count()
            if (titleHits >= 1 || bodyHits >= 3) {
                out.add(d.key to (titleHits * 5 + bodyHits))
            }
        }
        return out.sortedByDescending { it.second }.take(5)
    }

    fun matchQuery(query: String): List<String> {
        val q = " ${query.lowercase().trim()} "
        if (q.isBlank()) return emptyList()
        val hits = ArrayList<String>()
        for (d in ALL) {
            val label = d.label.lowercase()
            if (q.contains(" $label ") || d.keywords.any { q.contains(it.lowercase()) }) hits.add(d.key)
        }
        return hits
    }

    /**
     * v5.5.12 — Build an FTS query from ONLY the wording supplied by the
     * caller. Tokens keep prefix matching (`word*`) for inflections, but no
     * topic synonym is injected.
     *
     * The multi-query search pipeline already has explicit, weighted synonym
     * and LLM variants. Feeding those variants through [expandQuery] again
     * silently gave generated synonyms full "original query" trust and caused
     * double expansion / intent drift. Hybrid search uses this literal form;
     * the simple keyword-only fallback can still use [expandQuery].
     */
    fun literalPrefixQuery(raw: String): String {
        val trimmed = raw.trim()
        if (trimmed.length >= 2 && trimmed.startsWith("\"") && trimmed.endsWith("\"")) return trimmed
        val tokens = trimmed.lowercase().replace(Regex("[^\\p{L}\\p{N}\\s]"), " ")
            .split(Regex("\\s+")).filter { it.isNotBlank() }
        if (tokens.isEmpty()) return "\"\""
        return tokens.joinToString(" ") { "$it*" }
    }

    fun expandQuery(raw: String): String {
        val trimmed = raw.trim()
        if (trimmed.length >= 2 && trimmed.startsWith("\"") && trimmed.endsWith("\"")) return trimmed
        val tokens = trimmed.lowercase().replace(Regex("[^\\p{L}\\p{N}\\s]"), " ")
            .split(Regex("\\s+")).filter { it.isNotBlank() }
        if (tokens.isEmpty()) return "\"\""
        return tokens.joinToString(" ") { tok ->
            val syn = synonyms[tok]
            if (syn.isNullOrEmpty()) "$tok*"
            else "(" + (listOf("$tok*") + syn).joinToString(" OR ") + ")"
        }
    }
}

/**
 * Extracts Obsidian-style `[[Target]]` and `[[Target|Alias]]` wikilinks from note content,
 * skipping anything inside fenced code blocks (``` or ~~~) or inline `code` spans.
 */
object Wikilinks {

    /** Increment whenever the extraction logic changes so notes get re-scanned. */
    const val VERSION = 2

    private val WIKI_RX = Regex("""\[\[([^\[\]\n|#^]+)(?:\|[^\[\]\n]*)?(?:#[^\[\]\n|]*)?(?:\^[^\[\]\n|]*)?]]""")
    // Markdown link: [label](target). We only treat it as a graph edge if [target] resolves to
    // an internal note (no scheme, no anchor-only, ends in .md/.markdown or has no extension).
    private val MD_LINK_RX = Regex("""\[([^\]\n]+)]\(([^)\n]+)\)""")

    /** Returns the list of raw target strings (unique, original case) found in content. */
    fun extract(content: String): List<String> {
        val out = LinkedHashSet<String>()
        var inFence = false
        var fence = ""
        for (raw in content.lineSequence()) {
            val t = raw.trimStart()
            if (inFence) {
                if (t.startsWith(fence)) inFence = false
                continue
            }
            if (t.startsWith("```") || t.startsWith("~~~")) {
                inFence = true; fence = t.take(3); continue
            }
            // Strip inline `code` so [[Foo]] inside backticks doesn't count
            val cleaned = stripInlineCode(raw)
            // (1) Obsidian-style [[wikilinks]] (and ![[embeds]] — same payload)
            for (m in WIKI_RX.findAll(cleaned)) {
                val target = m.groupValues[1].trim()
                if (target.isNotEmpty()) out.add(target)
            }
            // (2) Markdown-style [text](target.md). Only edges for internal-looking targets.
            for (m in MD_LINK_RX.findAll(cleaned)) {
                val target = m.groupValues[2].trim()
                val internal = toInternalTarget(target) ?: continue
                if (internal.isNotEmpty()) out.add(internal)
            }
        }
        return out.toList()
    }

    /**
     * Decide whether a markdown-link target looks like an internal note reference.
     * Returns the cleaned target (URL-decoded, no anchor, no leading "./"), or null if external
     * (web URLs, mailto:, anchor-only fragments, image extensions, etc).
     */
    private fun toInternalTarget(raw: String): String? {
        var s = raw.trim()
        if (s.isEmpty()) return null
        // Skip external schemes and anchor-only links
        val lower = s.lowercase()
        if (lower.startsWith("http://") || lower.startsWith("https://")) return null
        if (lower.startsWith("mailto:") || lower.startsWith("tel:")) return null
        if (lower.startsWith("ftp://") || lower.startsWith("file://")) return null
        if (s.startsWith("#")) return null
        // Strip a "./" prefix that markdown editors often produce
        if (s.startsWith("./")) s = s.substring(2)
        // Drop everything after a # anchor or ? query
        s = s.substringBefore('#').substringBefore('?').trim()
        if (s.isEmpty()) return null
        // URL-decode (e.g. spaces written as %20)
        s = runCatching { java.net.URLDecoder.decode(s, "UTF-8") }.getOrElse { s }
        // Filter to .md / .markdown only — skip images, PDFs, etc.
        val lo = s.lowercase()
        val ok = lo.endsWith(".md") || lo.endsWith(".markdown") ||
            // Some vault links omit the extension; allow extension-less targets too
            !lo.substringAfterLast('/', lo).contains('.')
        return if (ok) s else null
    }

    /** Normalised lookup key — lowercased, trimmed, no leading/trailing whitespace. */
    fun normalize(target: String): String {
        val t = target.trim().lowercase()
        // Drop any anchor or block-ref tail just in case the caller passed one
        return t.substringBefore('#').substringBefore('^').trim()
    }

    /** Append `.md` to a normalised key for path/filename matching. */
    fun withMd(norm: String): String = if (norm.endsWith(".md")) norm else "$norm.md"

    private fun stripInlineCode(line: String): String {
        if ('`' !in line) return line
        val sb = StringBuilder(line.length)
        var i = 0
        while (i < line.length) {
            val c = line[i]
            if (c == '`') {
                // Skip until the matching backtick on the same line
                val end = line.indexOf('`', i + 1)
                if (end < 0) { sb.append(line, i, line.length); break }
                i = end + 1
            } else {
                sb.append(c); i++
            }
        }
        return sb.toString()
    }
}
