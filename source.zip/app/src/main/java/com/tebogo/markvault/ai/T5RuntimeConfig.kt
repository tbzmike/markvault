package com.tebogo.markvault.ai

/** Runtime limits for T5 expansion. */
data class T5RuntimeConfig(
    val maxParaphrases: Int = 5,
    val timeoutMs: Long = 10000L
)
