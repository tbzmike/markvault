package com.tebogo.markvault.markdown

/**
 * Optional preprocessing layer. Does not replace Flexmark.
 */
object AdvancedMarkdownPreprocessor {
    fun process(source: String): String {
        var s = FrontMatterParser.strip(source)
        s = CalloutProcessor.process(s)
        s = MermaidProcessor.process(s)
        ScriptureDetector.extract(s) // reserved hook for future metadata indexing
        TagExtractor.extract(s)
        return s
    }
}
