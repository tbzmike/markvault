package com.tebogo.markvault.ai

/**
 * Creates multiple retrieval queries from one user query.
 */
class MultiQueryRetriever(
    private val provider: LocalAIProvider
) {
    suspend fun createQueries(query: String): List<String> {
        val expanded = provider.expandQuery(query)
        return (listOf(query) + expanded).distinct()
    }
}
