package com.tebogo.markvault.ai

/**
 * Creates multiple retrieval queries from one user query.
 */
class MultiQueryRetriever(
    private val provider: QueryExpansionProvider
) {
    suspend fun createQueries(query: String): List<String> {
        val expanded = provider.expandQuery(query)
        val count = MultiQueryPreference.getCount()
        if (count == 0) return listOf(query)
        return (listOf(query) + expanded.take(count)).distinct()
    }
}
