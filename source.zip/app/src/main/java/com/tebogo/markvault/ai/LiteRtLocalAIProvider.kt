package com.tebogo.markvault.ai

import com.tebogo.markvault.llm.LlmManager
import kotlinx.coroutines.flow.toList

/**
 * v5.4.73 — LiteRT-LM provider (secondary path via RagRetrievalPipeline).
 *
 * NOTE: the primary search pipeline uses [LlmQueryExpander] directly.
 * This class exists for [RagRetrievalPipeline] compatibility.
 * LLM is NOT unloaded here — [LocalAIProviderManager.release] handles it.
 */
class LiteRtLocalAIProvider(
    private val modelName: String,
    private val modelPath: String
) : LocalAIProvider {

    override suspend fun expandQuery(query: String): List<String> {
        LlmManager.load(modelPath)

        val output = LlmManager.generate(
            "Create semantic search variants for this query only:\n$query"
        ).toList().joinToString("")

        return listOf(query) + output
            .lineSequence()
            .map { it.trim() }
            .filter { it.isNotEmpty() }
            .take(5)
            .toList()
    }

    override fun modelName(): String = modelName
}
