package com.tebogo.markvault.ai

import com.tebogo.markvault.llm.LlmManager
import kotlinx.coroutines.flow.toList

/**
 * v5.4.77 — LiteRT-LM provider connection.
 *
 * Connects retrieval expansion to the existing LiteRT-LM manager.
 */
class LiteRtLocalAIProvider(
    private val modelName: String,
    private val modelPath: String
) : LocalAIProvider {

    override suspend fun expandQuery(query: String): List<String> {
        LlmManager.load(modelPath)

        val output = LlmManager.generate(
            "Create semantic search variants for this query only:\n$query"
        ).toList().joinToString("")

        return listOf(query) + output
            .lineSequence()
            .map { it.trim() }
            .filter { it.isNotEmpty() }
            .take(5)
            .toList()
    }

    override fun modelName(): String = modelName
}
