package com.tebogo.markvault.llm

import android.content.Context
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.isActive
import kotlinx.coroutines.withContext
import java.io.File
import java.io.FileOutputStream
import java.net.HttpURLConnection
import java.net.URL
import kotlin.coroutines.coroutineContext

/**
 * v4.20.0 — Download manager for chat LLM model files.
 *
 * Mirrors the proven pattern from [com.tebogo.markvault.search.OnnxBertEmbedderBackend]:
 *   1. Download to `<localFilename>.part` (so partial downloads can't
 *      masquerade as a usable model).
 *   2. Stream over HTTP with progress callbacks every ~1 MB.
 *   3. On success, atomic rename `.part` → final filename.
 *   4. On failure, clean up the `.part`.
 *
 * ## Why not WorkManager / DownloadManager
 *
 * We considered Android's DownloadManager (handles retries, system UI,
 * wifi-only constraints automatically) but it doesn't integrate cleanly
 * with our existing foreground-service pattern, and it doesn't give us
 * the per-byte progress callbacks the embedding service flow already
 * uses. Reusing the proven HTTP-with-progress code from the embedding
 * backend keeps the install UX consistent: same progress bar, same
 * cancel behaviour, same notification.
 */
object ChatModelDownloader {

    /** Buffer size for the byte-copy loop. 32 KB is the JVM default for BufferedInputStream. */
    private const val BUFFER_SIZE = 32 * 1024

    /** How often to fire the progress callback, in bytes. ~1 MB. */
    private const val PROGRESS_INTERVAL_BYTES = 1_000_000L

    /** Connect timeout in milliseconds. 30 s is plenty for the handshake. */
    private const val CONNECT_TIMEOUT_MS = 30_000

    /**
     * Read timeout in milliseconds. Must be generous for the 4B model
     * (5.28 GB): on a typical South African WISP / mobile connection
     * (~10 Mbps), any stall over 30 s would kill the download mid-stream
     * with "unexpected end of stream". 5 minutes tolerates temporary
     * congestion without abandoning hours of progress.
     */
    private const val READ_TIMEOUT_MS = 300_000   // 5 minutes

    /**
     * Download [descriptor] into the app's `filesDir`. Reports progress
     * via [onProgress] as a 0.0–1.0 float. Returns success or the first
     * exception encountered.
     *
     * Cancellable: callers should run this inside a CoroutineScope and
     * cancel that scope to abort. The byte-copy loop checks
     * [Thread.interrupted] each iteration; on interrupt the `.part`
     * file is deleted and Result.failure(CancellationException) returns.
     */
    suspend fun download(
        context: Context,
        descriptor: ChatModelDescriptor,
        onProgress: (Float) -> Unit = {}
    ): Result<Unit> = withContext(Dispatchers.IO) {
        val finalFile = descriptor.fileIn(context.filesDir)
        val partFile = File(context.filesDir, "${descriptor.localFilename}.part")
        // Clean any stale .part from a previous aborted attempt.
        runCatching { partFile.delete() }

        try {
            val url = URL(descriptor.downloadUrl)
            val conn = (url.openConnection() as HttpURLConnection).apply {
                connectTimeout = CONNECT_TIMEOUT_MS
                readTimeout = READ_TIMEOUT_MS
                instanceFollowRedirects = true
                requestMethod = "GET"
            }
            conn.connect()
            val code = conn.responseCode
            if (code !in 200..299) {
                conn.disconnect()
                return@withContext Result.failure(
                    java.io.IOException("HTTP $code while downloading ${descriptor.id}")
                )
            }
            // Hugging Face sends Content-Length; if missing we fall back to
            // descriptor.approxSizeMb * 1MB for percentage display purposes.
            val totalBytes = conn.contentLengthLong
                .takeIf { it > 0 }
                ?: (descriptor.approxSizeMb.toLong() * 1_000_000L)

            val buffer = ByteArray(BUFFER_SIZE)
            var copied = 0L
            var nextProgressAt = PROGRESS_INTERVAL_BYTES

            conn.inputStream.use { input ->
                FileOutputStream(partFile).use { output ->
                    while (true) {
                        if (!coroutineContext.isActive) {
                            runCatching { partFile.delete() }
                            return@withContext Result.failure(
                                kotlinx.coroutines.CancellationException(
                                    "Chat model download cancelled by caller"
                                )
                            )
                        }
                        val n = input.read(buffer)
                        if (n <= 0) break
                        output.write(buffer, 0, n)
                        copied += n
                        if (copied >= nextProgressAt) {
                            val pct = (copied.toFloat() / totalBytes.toFloat())
                                .coerceIn(0f, 1f)
                            onProgress(pct)
                            nextProgressAt += PROGRESS_INTERVAL_BYTES
                        }
                    }
                }
            }
            conn.disconnect()

            // Sanity check before promoting .part → final.
            if (partFile.length() < ChatModelCatalog.MIN_PLAUSIBLE_MODEL_BYTES) {
                val gotMb = partFile.length() / 1_000_000
                runCatching { partFile.delete() }
                return@withContext Result.failure(
                    java.io.IOException(
                        "Downloaded file only $gotMb MB — much smaller than expected " +
                            "${descriptor.approxSizeMb} MB. Likely an HTML error page rather " +
                            "than the model. Check internet connection and try again."
                    )
                )
            }

            // Atomic-ish rename. If finalFile already exists (previous install),
            // replace it.
            if (finalFile.exists()) finalFile.delete()
            if (!partFile.renameTo(finalFile)) {
                runCatching { partFile.delete() }
                return@withContext Result.failure(
                    java.io.IOException("Failed to finalise downloaded model file")
                )
            }
            onProgress(1.0f)
            Result.success(Unit)
        } catch (e: Throwable) {
            runCatching { partFile.delete() }
            Result.failure(e)
        }
    }

    /** Delete the installed model. Safe to call when not installed. */
    fun delete(context: Context, descriptor: ChatModelDescriptor): Boolean {
        val f = descriptor.fileIn(context.filesDir)
        return if (f.exists()) f.delete() else true
    }
}
