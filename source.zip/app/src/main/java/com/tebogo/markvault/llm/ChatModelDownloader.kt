package com.tebogo.markvault.llm

import android.content.Context
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.isActive
import kotlinx.coroutines.withContext
import java.io.File
import java.io.FileOutputStream
import java.net.HttpURLConnection
import java.net.URL
import kotlin.coroutines.coroutineContext

/**
 * v5.4.72 — Download manager for chat LLM model files.
 *
 * ## Resumable downloads (v5.4.72)
 *
 * If a `.part` file already exists when [download] is called, it uses an
 * HTTP `Range: bytes=N-` request to continue from byte N rather than
 * starting over. The server responds with `206 Partial Content` and the
 * remaining bytes are appended to the existing `.part` file.
 *
 * This means:
 *
 *   - **Failed downloads auto-resume** on the next "Install" tap — the user
 *     never loses progress to a transient network error (the common cause of
 *     "fails at the end" with 1.6 GB files).
 *   - **Pause/resume works transparently** — the service simply cancels the
 *     coroutine (keeping `.part`), and the next `download()` call resumes.
 *   - **Cancellation keeps `.part`** — the downloader never deletes it; the
 *     caller ([ChatModelDownloadService] or the VM) decides whether to discard
 *     it (explicit "Start fresh").
 *
 * ## Why the downloader no longer deletes `.part` on failure
 *
 * Previously the catch block ran `partFile.delete()` on any exception, which
 * meant a 1.6 GB download that hit a `SocketException` on the final chunk
 * was wiped and had to restart from zero. The downloader now only deletes
 * `.part` when it's too small to hold any real data (< 5 MB), i.e. the
 * initial connection succeeded but almost nothing was received.
 *
 * ## Timeout split
 *
 * [CONNECT_TIMEOUT_MS] = 30 s — initial TCP handshake.
 * [READ_TIMEOUT_MS]    = 120 s — per-read-call stall tolerance, giving the
 *                        radio time to reattach after a cell-tower handoff
 *                        without aborting the download.
 */
object ChatModelDownloader {

    /** Read buffer: 32 KB matches typical JVM streaming defaults. */
    private const val BUFFER_SIZE = 32 * 1024

    /** Fire the progress callback roughly every 1 MB to keep UI responsive. */
    private const val PROGRESS_INTERVAL_BYTES = 1_000_000L

    /** TCP connection timeout. */
    private const val CONNECT_TIMEOUT_MS = 30_000

    /**
     * Per-read-call timeout. Does NOT cap total download time — it only
     * limits how long a single [java.io.InputStream.read] may block. Two
     * minutes lets the radio reconnect after a brief signal loss without
     * aborting the download.
     */
    private const val READ_TIMEOUT_MS = 120_000

    /**
     * Minimum `.part` file size we consider worth keeping for resume. Files
     * below this threshold are almost certainly a failed connection response
     * (HTML error page or zero bytes) — not worth resuming.
     */
    private const val RESUME_MIN_BYTES = 5_000_000L   // 5 MB

    /**
     * Download [descriptor] into the app's `filesDir`. Reports progress via
     * [onProgress] as a 0.0–1.0 float. Returns [Result.success] or the
     * first exception encountered.
     *
     * **Auto-resume**: if `<localFilename>.part` already exists and is
     * ≥ [RESUME_MIN_BYTES], this sends `Range: bytes=N-` automatically.
     *
     * **Cancellable**: the byte-copy loop checks [coroutineContext.isActive]
     * before each read. On cancellation the `.part` file is **kept** so the
     * caller can resume later — the caller is responsible for deleting it if
     * a "start fresh" is desired.
     */
    suspend fun download(
        context: Context,
        descriptor: ChatModelDescriptor,
        onProgress: (Float) -> Unit = {}
    ): Result<Unit> = withContext(Dispatchers.IO) {
        val finalFile  = descriptor.fileIn(context.filesDir)
        val partFile   = File(context.filesDir, "${descriptor.localFilename}.part")

        // Determine how many bytes we already have (resume offset).
        val alreadyBytes = if (partFile.exists() && partFile.length() >= RESUME_MIN_BYTES) {
            partFile.length()
        } else {
            // Stale / near-empty .part — delete it and start clean.
            if (partFile.exists()) runCatching { partFile.delete() }
            0L
        }

        val resuming = alreadyBytes > 0L

        try {
            val url  = URL(descriptor.downloadUrl)
            val conn = (url.openConnection() as HttpURLConnection).apply {
                connectTimeout      = CONNECT_TIMEOUT_MS
                readTimeout         = READ_TIMEOUT_MS
                instanceFollowRedirects = true
                requestMethod       = "GET"
                if (resuming) {
                    setRequestProperty("Range", "bytes=$alreadyBytes-")
                }
            }
            conn.connect()

            val code = conn.responseCode
            // 200 = full content (server ignored Range), 206 = partial content.
            if (code !in 200..299) {
                conn.disconnect()
                return@withContext Result.failure(
                    java.io.IOException("HTTP $code while downloading ${descriptor.id}")
                )
            }

            // Content-Length for a 206 response is the *remaining* bytes.
            // Total = alreadyBytes + remaining.
            val remaining  = conn.contentLengthLong.takeIf { it > 0 } ?: 0L
            val totalBytes = if (remaining > 0L) {
                alreadyBytes + remaining
            } else {
                descriptor.approxSizeMb.toLong() * 1_000_000L
            }

            val buffer   = ByteArray(BUFFER_SIZE)
            var copied   = alreadyBytes     // already-written bytes count toward progress
            var nextProgressAt = alreadyBytes + PROGRESS_INTERVAL_BYTES

            // Emit initial progress so the UI shows the correct position.
            if (resuming) {
                onProgress((alreadyBytes.toFloat() / totalBytes.toFloat()).coerceIn(0f, 1f))
            }

            conn.inputStream.use { input ->
                // Append if resuming, otherwise overwrite.
                FileOutputStream(partFile, resuming).use { output ->
                    while (true) {
                        if (!coroutineContext.isActive) {
                            // Cancelled (pause or user cancel).
                            // Do NOT delete .part — caller decides.
                            return@withContext Result.failure(
                                kotlinx.coroutines.CancellationException(
                                    "Chat model download cancelled"
                                )
                            )
                        }
                        val n = input.read(buffer)
                        if (n <= 0) break
                        output.write(buffer, 0, n)
                        copied += n
                        if (copied >= nextProgressAt) {
                            val pct = (copied.toFloat() / totalBytes.toFloat()).coerceIn(0f, 1f)
                            onProgress(pct)
                            nextProgressAt += PROGRESS_INTERVAL_BYTES
                        }
                    }
                }
            }
            conn.disconnect()

            // Size sanity check.
            if (partFile.length() < ChatModelCatalog.MIN_PLAUSIBLE_MODEL_BYTES) {
                val gotMb = partFile.length() / 1_000_000L
                // File is too small to be real — delete and fail.
                runCatching { partFile.delete() }
                return@withContext Result.failure(
                    java.io.IOException(
                        "Downloaded file only ${gotMb} MB, expected ~${descriptor.approxSizeMb} MB. " +
                            "Likely an error page was returned. Check connection and try again."
                    )
                )
            }

            // Promote .part → final.
            if (finalFile.exists()) finalFile.delete()
            if (!partFile.renameTo(finalFile)) {
                runCatching { partFile.delete() }
                return@withContext Result.failure(
                    java.io.IOException("Could not rename .part file to final path")
                )
            }
            onProgress(1.0f)
            Result.success(Unit)

        } catch (e: Throwable) {
            // On any exception (SocketException, EOFException, timeout…)
            // we keep the .part file so the next attempt can resume.
            // Only delete if it's too small to be useful (≤ RESUME_MIN_BYTES),
            // which means the connection failed before any real data arrived.
            if (partFile.exists() && partFile.length() < RESUME_MIN_BYTES) {
                runCatching { partFile.delete() }
            }
            Result.failure(e)
        }
    }

    /** Delete the installed model and any partial download. Safe to call when not installed. */
    fun delete(context: Context, descriptor: ChatModelDescriptor): Boolean {
        val f    = descriptor.fileIn(context.filesDir)
        val part = File(context.filesDir, "${descriptor.localFilename}.part")
        runCatching { part.delete() }
        return if (f.exists()) f.delete() else true
    }

    /**
     * Delete only the `.part` (resume checkpoint) without touching a
     * completed install. Used by "Start fresh" to force a clean download.
     */
    fun deletePart(context: Context, descriptor: ChatModelDescriptor) {
        val part = File(context.filesDir, "${descriptor.localFilename}.part")
        runCatching { part.delete() }
    }

    /**
     * True if a meaningful `.part` file exists — i.e. a paused or interrupted
     * download that can be resumed.
     */
    fun hasResumableDownload(context: Context, descriptor: ChatModelDescriptor): Boolean {
        val part = File(context.filesDir, "${descriptor.localFilename}.part")
        return part.exists() && part.length() >= RESUME_MIN_BYTES
    }
}
