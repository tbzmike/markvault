package com.tebogo.markvault.update

import android.content.Context
import android.content.Intent
import android.net.Uri
import androidx.core.content.ContextCompat
import com.tebogo.markvault.BuildConfig
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.withContext
import org.json.JSONObject
import java.io.File
import java.io.IOException
import java.net.HttpURLConnection
import java.net.URL
import java.security.MessageDigest
import java.util.Locale

/** Durable state shown by Settings and updated by [AppUpdateDownloadService]. */
enum class AppUpdatePhase {
    IDLE,
    CHECKING,
    UP_TO_DATE,
    AVAILABLE,
    DOWNLOADING,
    WAITING_NETWORK,
    VERIFYING,
    READY_TO_INSTALL,
    PAUSED_SYSTEM,
    CANCELED,
    ERROR
}

data class AppUpdateState(
    val phase: AppUpdatePhase = AppUpdatePhase.IDLE,
    val message: String = "",
    val bytesDownloaded: Long = 0L,
    val totalBytes: Long = 0L,
    val bytesPerSecond: Long = 0L,
    val releaseUpdatedAt: String = "",
    val assetUrl: String = "",
    val expectedSha256: String = "",
    val candidateVersionName: String = "",
    val candidateVersionCode: Long = 0L
) {
    val fraction: Float
        get() = if (totalBytes <= 0L) 0f
        else (bytesDownloaded.toDouble() / totalBytes.toDouble()).toFloat().coerceIn(0f, 1f)

    val active: Boolean
        get() = phase == AppUpdatePhase.DOWNLOADING ||
            phase == AppUpdatePhase.WAITING_NETWORK ||
            phase == AppUpdatePhase.VERIFYING
}

/**
 * MarkVault's app updater is intentionally release-based. The repository workflow only
 * replaces the `latest` release asset after `assembleRelease` succeeds, so this client
 * never consumes Actions artifacts or failed/incomplete workflow output.
 *
 * The release's SHA-256 digest is compared with the currently installed APK. That avoids
 * guessing a version from the fixed `latest` tag and also gives the downloader an exact
 * integrity value to verify before Android is ever asked to install the file.
 */
object AppUpdateManager {
    private const val PREFS_NAME = "markvault_app_update"
    private const val RELEASE_API = "https://api.github.com/repos/tbzmike/markvault/releases/latest"
    private const val EXPECTED_ASSET_NAME = "MarkVault.apk"
    private const val EXPECTED_DOWNLOAD_HOST = "github.com"
    private const val EXPECTED_DOWNLOAD_PATH_PREFIX = "/tbzmike/markvault/releases/download/"

    private const val KEY_PHASE = "phase"
    private const val KEY_MESSAGE = "message"
    private const val KEY_BYTES = "bytes"
    private const val KEY_TOTAL = "total"
    private const val KEY_SPEED = "speed"
    private const val KEY_UPDATED = "updated"
    private const val KEY_URL = "url"
    private const val KEY_SHA = "sha"
    private const val KEY_VERSION_NAME = "version_name"
    private const val KEY_VERSION_CODE = "version_code"

    private val mutableState = MutableStateFlow(AppUpdateState())
    val state: StateFlow<AppUpdateState> = mutableState.asStateFlow()

    @Volatile
    private var initialized = false

    fun initialize(context: Context) {
        if (initialized) return
        synchronized(this) {
            if (initialized) return
            val prefs = context.applicationContext.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
            val phase = runCatching {
                AppUpdatePhase.valueOf(prefs.getString(KEY_PHASE, AppUpdatePhase.IDLE.name) ?: AppUpdatePhase.IDLE.name)
            }.getOrDefault(AppUpdatePhase.IDLE)
            mutableState.value = AppUpdateState(
                phase = phase,
                message = prefs.getString(KEY_MESSAGE, "") ?: "",
                bytesDownloaded = prefs.getLong(KEY_BYTES, 0L).coerceAtLeast(0L),
                totalBytes = prefs.getLong(KEY_TOTAL, 0L).coerceAtLeast(0L),
                bytesPerSecond = 0L,
                releaseUpdatedAt = prefs.getString(KEY_UPDATED, "") ?: "",
                assetUrl = prefs.getString(KEY_URL, "") ?: "",
                expectedSha256 = prefs.getString(KEY_SHA, "") ?: "",
                candidateVersionName = prefs.getString(KEY_VERSION_NAME, "") ?: "",
                candidateVersionCode = prefs.getLong(KEY_VERSION_CODE, 0L).coerceAtLeast(0L)
            )
            initialized = true
            val restored = mutableState.value
            if (restored.phase == AppUpdatePhase.READY_TO_INSTALL &&
                restored.candidateVersionCode > 0L &&
                BuildConfig.VERSION_CODE.toLong() >= restored.candidateVersionCode) {
                clearDownloadedFiles(context)
                val installed = restored.copy(
                    phase = AppUpdatePhase.UP_TO_DATE,
                    message = "MarkVault ${BuildConfig.VERSION_NAME} was updated successfully.",
                    bytesDownloaded = 0L,
                    bytesPerSecond = 0L
                )
                mutableState.value = installed
                persist(context, installed)
            }
        }
    }

    suspend fun checkForUpdate(context: Context) = withContext(Dispatchers.IO) {
        initialize(context)
        setState(
            context,
            mutableState.value.copy(
                phase = AppUpdatePhase.CHECKING,
                message = "Checking the latest successful MarkVault release…",
                bytesPerSecond = 0L
            )
        )

        try {
            val release = fetchLatestRelease()
            val previous = mutableState.value
            if (previous.expectedSha256.isNotBlank() &&
                !previous.expectedSha256.equals(release.sha256, ignoreCase = true)) {
                clearDownloadedFiles(context)
            }
            val installedDigest = sha256Of(File(context.applicationInfo.sourceDir))
            if (installedDigest.equals(release.sha256, ignoreCase = true)) {
                clearDownloadedFiles(context)
                setState(
                    context,
                    AppUpdateState(
                        phase = AppUpdatePhase.UP_TO_DATE,
                        message = "MarkVault ${BuildConfig.VERSION_NAME} is already the latest successful release.",
                        totalBytes = release.size,
                        releaseUpdatedAt = release.updatedAt,
                        assetUrl = release.downloadUrl,
                        expectedSha256 = release.sha256
                    )
                )
            } else {
                val downloadedApk = AppUpdateInstaller.finalApk(context)
                val downloadedMatches = downloadedApk.isFile &&
                    downloadedApk.length() == release.size &&
                    runCatching { sha256Of(downloadedApk).equals(release.sha256, ignoreCase = true) }
                        .getOrDefault(false)
                val packageCheck = if (downloadedMatches) {
                    AppUpdateInstaller.verifyDownloadedApk(context, downloadedApk)
                } else null
                if (packageCheck?.valid == true) {
                    setState(
                        context,
                        AppUpdateState(
                            phase = AppUpdatePhase.READY_TO_INSTALL,
                            message = "MarkVault ${packageCheck.versionName} is already downloaded, verified, and ready to install.",
                            bytesDownloaded = release.size,
                            totalBytes = release.size,
                            releaseUpdatedAt = release.updatedAt,
                            assetUrl = release.downloadUrl,
                            expectedSha256 = release.sha256,
                            candidateVersionName = packageCheck.versionName,
                            candidateVersionCode = packageCheck.versionCode
                        )
                    )
                } else {
                    if (downloadedApk.exists()) downloadedApk.delete()
                    setState(
                        context,
                        AppUpdateState(
                            phase = AppUpdatePhase.AVAILABLE,
                            message = "A newer successful MarkVault release is available.",
                            totalBytes = release.size,
                            releaseUpdatedAt = release.updatedAt,
                            assetUrl = release.downloadUrl,
                            expectedSha256 = release.sha256
                        )
                    )
                }
            }
        } catch (t: Throwable) {
            val reason = t.message?.takeIf { it.isNotBlank() } ?: t.javaClass.simpleName
            setState(
                context,
                mutableState.value.copy(
                    phase = AppUpdatePhase.ERROR,
                    message = "Update check failed: $reason",
                    bytesPerSecond = 0L
                )
            )
        }
    }

    fun startDownload(context: Context) {
        initialize(context)
        val current = mutableState.value
        if (current.assetUrl.isBlank() || current.expectedSha256.length != 64 || current.totalBytes <= 0L) {
            setState(
                context,
                current.copy(
                    phase = AppUpdatePhase.ERROR,
                    message = "No verified release is selected. Check for updates again first."
                )
            )
            return
        }
        setState(
            context,
            current.copy(
                phase = AppUpdatePhase.DOWNLOADING,
                message = "Preparing update download…",
                bytesPerSecond = 0L,
                candidateVersionName = "",
                candidateVersionCode = 0L
            )
        )
        val intent = Intent(context, AppUpdateDownloadService::class.java)
            .setAction(AppUpdateDownloadService.ACTION_START_OR_RESUME)
        ContextCompat.startForegroundService(context, intent)
    }

    fun cancelDownload(context: Context) {
        initialize(context)
        val intent = Intent(context, AppUpdateDownloadService::class.java)
            .setAction(AppUpdateDownloadService.ACTION_CANCEL)
        context.startService(intent)
    }

    /** Resume a persisted in-flight transfer when the user brings MarkVault back to the foreground. */
    fun resumePendingDownload(context: Context) {
        initialize(context)
        val current = mutableState.value
        val resumable = current.phase == AppUpdatePhase.DOWNLOADING ||
            current.phase == AppUpdatePhase.WAITING_NETWORK ||
            current.phase == AppUpdatePhase.VERIFYING ||
            current.phase == AppUpdatePhase.PAUSED_SYSTEM
        if (!resumable || current.assetUrl.isBlank() || current.expectedSha256.length != 64) return
        val intent = Intent(context, AppUpdateDownloadService::class.java)
            .setAction(AppUpdateDownloadService.ACTION_START_OR_RESUME)
        runCatching { ContextCompat.startForegroundService(context, intent) }
    }

    internal fun updateFromService(context: Context, state: AppUpdateState, persist: Boolean = true) {
        initialize(context)
        mutableState.value = state
        if (persist) persist(context, state)
    }

    internal fun current(context: Context): AppUpdateState {
        initialize(context)
        return mutableState.value
    }

    internal fun updateDirectory(context: Context): File =
        File(context.filesDir, "app_updates").apply { mkdirs() }

    internal fun clearDownloadedFiles(context: Context) {
        val dir = updateDirectory(context)
        File(dir, AppUpdateDownloadService.PART_FILE_NAME).delete()
        File(dir, AppUpdateDownloadService.FINAL_FILE_NAME).delete()
    }

    private fun setState(context: Context, newState: AppUpdateState) {
        mutableState.value = newState
        persist(context, newState)
    }

    private fun persist(context: Context, state: AppUpdateState) {
        context.applicationContext.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
            .edit()
            .putString(KEY_PHASE, state.phase.name)
            .putString(KEY_MESSAGE, state.message)
            .putLong(KEY_BYTES, state.bytesDownloaded)
            .putLong(KEY_TOTAL, state.totalBytes)
            .putLong(KEY_SPEED, 0L)
            .putString(KEY_UPDATED, state.releaseUpdatedAt)
            .putString(KEY_URL, state.assetUrl)
            .putString(KEY_SHA, state.expectedSha256)
            .putString(KEY_VERSION_NAME, state.candidateVersionName)
            .putLong(KEY_VERSION_CODE, state.candidateVersionCode)
            .apply()
    }

    private data class ReleaseAsset(
        val downloadUrl: String,
        val size: Long,
        val sha256: String,
        val updatedAt: String
    )

    private fun fetchLatestRelease(): ReleaseAsset {
        val connection = (URL(RELEASE_API).openConnection() as HttpURLConnection).apply {
            instanceFollowRedirects = true
            connectTimeout = 20_000
            readTimeout = 20_000
            requestMethod = "GET"
            setRequestProperty("Accept", "application/vnd.github+json")
            setRequestProperty("X-GitHub-Api-Version", "2026-03-10")
            setRequestProperty("User-Agent", "MarkVault-Android/${BuildConfig.VERSION_NAME}")
            connect()
        }
        try {
            if (connection.responseCode !in 200..299) {
                throw IOException("GitHub returned HTTP ${connection.responseCode}")
            }
            val body = connection.inputStream.bufferedReader(Charsets.UTF_8).use { it.readText() }
            val root = JSONObject(body)
            if (root.optBoolean("draft", false) || root.optBoolean("prerelease", false)) {
                throw IOException("Latest release is not a published stable release")
            }
            val assets = root.optJSONArray("assets") ?: throw IOException("Release has no APK assets")
            var selected: JSONObject? = null
            for (index in 0 until assets.length()) {
                val candidate = assets.optJSONObject(index) ?: continue
                if (candidate.optString("name") == EXPECTED_ASSET_NAME &&
                    candidate.optString("state") == "uploaded") {
                    selected = candidate
                    break
                }
            }
            val asset = selected ?: throw IOException("Release does not contain $EXPECTED_ASSET_NAME")
            val size = asset.optLong("size", -1L)
            if (size <= 0L) throw IOException("Release APK has an invalid size")
            val rawDigest = asset.optString("digest")
            if (!rawDigest.startsWith("sha256:", ignoreCase = true)) {
                throw IOException("Release APK has no SHA-256 digest")
            }
            val sha = rawDigest.substringAfter(':').lowercase(Locale.ROOT)
            if (!sha.matches(Regex("[0-9a-f]{64}"))) {
                throw IOException("Release APK has an invalid SHA-256 digest")
            }
            val downloadUrl = asset.optString("browser_download_url")
            validateDownloadUrl(downloadUrl)
            return ReleaseAsset(
                downloadUrl = downloadUrl,
                size = size,
                sha256 = sha,
                updatedAt = asset.optString("updated_at")
            )
        } finally {
            connection.disconnect()
        }
    }

    private fun validateDownloadUrl(raw: String) {
        val uri = Uri.parse(raw)
        val schemeOk = uri.scheme.equals("https", ignoreCase = true)
        val hostOk = uri.host.equals(EXPECTED_DOWNLOAD_HOST, ignoreCase = true)
        val pathOk = (uri.path ?: "").startsWith(EXPECTED_DOWNLOAD_PATH_PREFIX) &&
            (uri.path ?: "").endsWith("/$EXPECTED_ASSET_NAME")
        if (!schemeOk || !hostOk || !pathOk) {
            throw IOException("Release APK URL is not an approved MarkVault GitHub release URL")
        }
    }

    internal fun sha256Of(file: File): String {
        val digest = MessageDigest.getInstance("SHA-256")
        file.inputStream().buffered(64 * 1024).use { input ->
            val buffer = ByteArray(64 * 1024)
            while (true) {
                val count = input.read(buffer)
                if (count < 0) break
                if (count > 0) digest.update(buffer, 0, count)
            }
        }
        return digest.digest().joinToString("") { byte -> "%02x".format(byte) }
    }
}
