package com.tebogo.markvault.ui

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.os.Build
import android.os.IBinder
import android.os.PowerManager
import androidx.core.app.NotificationCompat
import com.tebogo.markvault.AppViewModel
import com.tebogo.markvault.MainActivity
import com.tebogo.markvault.MarkVaultApp
import com.tebogo.markvault.OfflineHtmlSavePhase
import com.tebogo.markvault.OfflineHtmlSaveState
import com.tebogo.markvault.R
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.launch

/**
 * v5.5.7 — Foreground progress service for a single WebViewer
 * "Save as Offline HTML" operation.
 *
 * The old single-page path had no foreground service at all: it waited for
 * one potentially huge evaluateJavascript() result and only showed a Toast
 * after the whole capture + write completed. If WebView stalled while
 * returning the DOM, tapping Save appeared to do nothing.
 *
 * The save itself stays in AppViewModel. This service only mirrors
 * [AppViewModel.offlineHtmlSaveState] into the notification shade and holds
 * a short partial wake lock so capture/write is not suspended when the
 * screen turns off mid-save.
 */
class OfflineHtmlSaveService : Service() {

    private val serviceScope = CoroutineScope(SupervisorJob() + Dispatchers.Main.immediate)
    private var observeJob: Job? = null
    private var wakeLock: PowerManager.WakeLock? = null

    override fun onCreate() {
        super.onCreate()
        createNotificationChannel()
        val pm = getSystemService(Context.POWER_SERVICE) as PowerManager
        wakeLock = pm.newWakeLock(
            PowerManager.PARTIAL_WAKE_LOCK,
            "MarkVault::OfflineHtmlSaveWakeLock"
        )
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (wakeLock?.isHeld != true) {
            runCatching { wakeLock?.acquire(WAKELOCK_TIMEOUT_MS) }
        }

        // Android requires a foreground notification immediately. The first
        // StateFlow emission replaces this warm-up text almost at once.
        startForeground(
            NOTIFICATION_ID,
            buildNotification(
                OfflineHtmlSaveState(
                    phase = OfflineHtmlSavePhase.CAPTURING,
                    message = "Starting offline HTML save…"
                )
            )
        )
        observeState()
        return START_NOT_STICKY
    }

    private fun observeState() {
        observeJob?.cancel()
        val vm = (application as? MarkVaultApp)?.sharedVm ?: run {
            stopForegroundAndSelf(removeNotification = true)
            return
        }
        observeJob = serviceScope.launch {
            var seenOperationId = 0L
            vm.offlineHtmlSaveState.collect { state ->
                if (state.operationId > 0L) seenOperationId = state.operationId

                when (state.phase) {
                    OfflineHtmlSavePhase.IDLE -> {
                        if (seenOperationId > 0L) {
                            stopForegroundAndSelf(removeNotification = false)
                        }
                    }
                    OfflineHtmlSavePhase.SUCCESS,
                    OfflineHtmlSavePhase.ERROR -> {
                        updateNotification(state)
                        stopForegroundAndSelf(removeNotification = false)
                    }
                    else -> updateNotification(state)
                }
            }
        }
    }

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                CHANNEL_ID,
                "Offline HTML saves",
                NotificationManager.IMPORTANCE_LOW
            ).apply {
                description = "Progress while saving the current WebViewer page for offline reading"
                setShowBadge(false)
            }
            (getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager)
                .createNotificationChannel(channel)
        }
    }

    private fun buildNotification(state: OfflineHtmlSaveState): Notification {
        val openPi = PendingIntent.getActivity(
            this,
            0,
            Intent(this, MainActivity::class.java).apply {
                flags = Intent.FLAG_ACTIVITY_SINGLE_TOP or Intent.FLAG_ACTIVITY_CLEAR_TOP
            },
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        val complete = state.phase == OfflineHtmlSavePhase.SUCCESS ||
            state.phase == OfflineHtmlSavePhase.ERROR
        val title = when (state.phase) {
            OfflineHtmlSavePhase.SUCCESS -> "MarkVault — offline HTML saved"
            OfflineHtmlSavePhase.ERROR -> "MarkVault — offline HTML save failed"
            OfflineHtmlSavePhase.WRITING -> "MarkVault — writing offline HTML"
            OfflineHtmlSavePhase.INDEXING -> "MarkVault — indexing saved article"
            else -> "MarkVault — saving offline HTML"
        }
        val text = state.message.ifBlank {
            state.title.ifBlank { "Saving current WebViewer page…" }
        }

        val builder = NotificationCompat.Builder(this, CHANNEL_ID)
            .setSmallIcon(R.mipmap.ic_launcher)
            .setContentTitle(title)
            .setContentText(text)
            .setContentIntent(openPi)
            .setOngoing(!complete)
            .setAutoCancel(complete)
            .setOnlyAlertOnce(true)
            .setPriority(NotificationCompat.PRIORITY_LOW)
            .setCategory(NotificationCompat.CATEGORY_PROGRESS)

        when {
            complete -> Unit
            state.total > 0 -> builder.setProgress(state.total, state.done.coerceIn(0, state.total), false)
            else -> builder.setProgress(0, 0, true)
        }
        return builder.build()
    }

    private fun updateNotification(state: OfflineHtmlSaveState) {
        (getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager)
            .notify(NOTIFICATION_ID, buildNotification(state))
    }

    private fun stopForegroundAndSelf(removeNotification: Boolean) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N) {
            stopForeground(if (removeNotification) STOP_FOREGROUND_REMOVE else STOP_FOREGROUND_DETACH)
        } else {
            @Suppress("DEPRECATION")
            stopForeground(removeNotification)
        }
        stopSelf()
    }

    override fun onDestroy() {
        observeJob?.cancel()
        serviceScope.cancel()
        runCatching { if (wakeLock?.isHeld == true) wakeLock?.release() }
        super.onDestroy()
    }

    override fun onBind(intent: Intent?): IBinder? = null

    companion object {
        private const val CHANNEL_ID = "markvault_offline_html_save"
        private const val NOTIFICATION_ID = 4821
        private const val WAKELOCK_TIMEOUT_MS = 5L * 60L * 1000L
    }
}
