package com.tebogo.markvault.render

object MarkdownDiagramDetector {

    fun containsMermaid(markdown: String): Boolean {
        return markdown.contains("```mermaid", ignoreCase = true)
    }
}
