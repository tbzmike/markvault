package com.tebogo.markvault.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.wrapContentWidth
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material3.Button
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.navigation.NavHostController
import com.tebogo.markvault.AppViewModel

/**
 * v5.4.47b — On-device RAG chat screen.
 *
 * New in this version:
 *   - Context status banner at the top shows EXACTLY which notes are
 *     loaded (article names, count, or "not indexed" warning)
 *   - 🔄 Refresh button in the top bar re-queries the DB and updates
 *     the banner without sending a message
 *   - Context source label shown in the top bar subtitle
 */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ChatScreen(vm: AppViewModel, nav: NavHostController) {
    val messages by vm.chatMessages.collectAsStateWithLifecycle()
    val isModelLoading by vm.chatIsModelLoading.collectAsStateWithLifecycle()
    val isGenerating by vm.chatIsGenerating.collectAsStateWithLifecycle()
    val modelInstalled by vm.chatModelInstalled.collectAsStateWithLifecycle()
    val loadError by vm.chatModelLoadError.collectAsStateWithLifecycle()
    val loadMode by vm.chatModelLoadModePref.collectAsStateWithLifecycle()
    val ragSource by vm.chatRagSourcePref.collectAsStateWithLifecycle()
    val contextStatus by vm.chatContextStatus.collectAsStateWithLifecycle()

    var input by remember { mutableStateOf("") }
    val listState = rememberLazyListState()

    // ── Lifecycle: load model + refresh context on open ───────────────
    LaunchedEffect(loadMode, modelInstalled) {
        if (loadMode == "on_open" && modelInstalled) {
            vm.ensureChatModelLoaded()
        }
    }
    LaunchedEffect(ragSource) {
        // Refresh context status whenever source changes or screen opens
        vm.refreshChatContext()
    }
    DisposableEffect(loadMode) {
        onDispose {
            if (loadMode != "preload") {
                vm.unloadChatModel()
            }
        }
    }

    // Auto-scroll to the latest message as it streams.
    LaunchedEffect(messages.size, messages.lastOrNull()?.content?.length) {
        if (messages.isNotEmpty()) {
            listState.animateScrollToItem(messages.size - 1)
        }
    }

    val ragLabel = when (ragSource) {
        "last_1" -> "Last opened article"
        "full_library" -> "Full library"
        else -> "Last 5 opened articles"
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Column {
                        Text("\uD83D\uDCAC Chat", fontWeight = FontWeight.SemiBold)
                        Text(
                            ragLabel,
                            fontSize = 11.sp,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                },
                navigationIcon = {
                    IconButton(onClick = { nav.popBackStack() }) {
                        Icon(
                            Icons.AutoMirrored.Filled.ArrowBack,
                            contentDescription = "Back"
                        )
                    }
                },
                actions = {
                    // 🔄 Refresh context button
                    IconButton(
                        onClick = { vm.refreshChatContext() },
                        enabled = !isGenerating
                    ) {
                        Icon(
                            Icons.Default.Refresh,
                            contentDescription = "Refresh context",
                            tint = MaterialTheme.colorScheme.primary
                        )
                    }
                    if (messages.isNotEmpty()) {
                        TextButton(onClick = { vm.clearChatMessages() }) {
                            Text("Clear")
                        }
                    }
                }
            )
        },
        bottomBar = {
            ChatInputBar(
                input = input,
                onInputChange = { input = it },
                isBusy = isGenerating || isModelLoading,
                isGenerating = isGenerating,
                enabled = modelInstalled && loadError == null,
                onSend = {
                    val text = input.trim()
                    if (text.isNotEmpty()) {
                        input = ""
                        vm.sendChatMessage(text)
                    }
                },
                onStop = { vm.stopChatGeneration() }
            )
        }
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
        ) {
            // ── Model status banner (error / loading / not installed) ─
            ChatStatusBanner(
                modelInstalled = modelInstalled,
                isModelLoading = isModelLoading,
                loadError = loadError,
                onDismissError = { vm.clearChatModelLoadError() },
                onGoToSettings = { nav.navigate("settings") }
            )

            // ── Context status banner ─────────────────────────────────
            // Always visible so the user can see what's loaded before
            // sending the first question. Green = good, amber = warning.
            val isWarning = contextStatus.startsWith("⚠️")
            val isChecking = contextStatus.startsWith("Checking")
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(
                        when {
                            isChecking -> MaterialTheme.colorScheme.surfaceVariant
                            isWarning  -> androidx.compose.ui.graphics.Color(0xFFFFF8E1)
                            else       -> androidx.compose.ui.graphics.Color(0xFFE8F5E9)
                        }
                    )
                    .padding(horizontal = 14.dp, vertical = 8.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                if (isChecking) {
                    CircularProgressIndicator(
                        modifier = Modifier
                            .width(14.dp)
                            .height(14.dp),
                        strokeWidth = 2.dp
                    )
                }
                Text(
                    contextStatus,
                    fontSize = 12.sp,
                    lineHeight = 16.sp,
                    color = when {
                        isWarning  -> androidx.compose.ui.graphics.Color(0xFF5D4037)
                        isChecking -> MaterialTheme.colorScheme.onSurfaceVariant
                        else       -> androidx.compose.ui.graphics.Color(0xFF1B5E20)
                    },
                    modifier = Modifier.weight(1f)
                )
            }

            if (messages.isEmpty()) {
                ChatEmptyState(
                    modelInstalled = modelInstalled,
                    isModelLoading = isModelLoading,
                    ragLabel = ragLabel,
                    contextStatus = contextStatus
                )
            } else {
                LazyColumn(
                    state = listState,
                    modifier = Modifier.fillMaxSize(),
                    contentPadding = PaddingValues(12.dp),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    items(messages, key = { it.id }) { msg ->
                        ChatMessageBubble(msg) { noteId, fileType ->
                            vm.openArticle(noteId, "", fileType = fileType)
                            when (fileType) {
                                "pdf" -> nav.navigate("pdfReader/$noteId")
                                "html", "mhtml" -> nav.navigate("htmlReader/$noteId")
                                else -> nav.navigate("reader") { launchSingleTop = true }
                            }
                        }
                    }
                }
            }
        }
    }
}

/**
 * Banner across the top of the chat area showing the model's status
 * when not normal: loading, errored, or uninstalled.
 */
@Composable
private fun ChatStatusBanner(
    modelInstalled: Boolean,
    isModelLoading: Boolean,
    loadError: String?,
    onDismissError: () -> Unit,
    onGoToSettings: () -> Unit
) {
    when {
        loadError != null -> {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(MaterialTheme.colorScheme.errorContainer)
                    .padding(12.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    "\u26A0\uFE0F  $loadError",
                    fontSize = 13.sp,
                    color = MaterialTheme.colorScheme.onErrorContainer,
                    modifier = Modifier.weight(1f)
                )
                if (!modelInstalled) {
                    TextButton(onClick = onGoToSettings) {
                        Text("Settings")
                    }
                } else {
                    TextButton(onClick = onDismissError) {
                        Text("Dismiss")
                    }
                }
            }
        }
        !modelInstalled -> {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(MaterialTheme.colorScheme.tertiaryContainer)
                    .padding(12.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    "Chat model is not installed. ~400 MB download required.",
                    fontSize = 13.sp,
                    color = MaterialTheme.colorScheme.onTertiaryContainer,
                    modifier = Modifier.weight(1f)
                )
                TextButton(onClick = onGoToSettings) {
                    Text("Install in Settings")
                }
            }
        }
        isModelLoading -> {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(MaterialTheme.colorScheme.surfaceVariant)
                    .padding(12.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                CircularProgressIndicator(
                    modifier = Modifier.width(16.dp).height(16.dp),
                    strokeWidth = 2.dp
                )
                Spacer(Modifier.width(12.dp))
                Text(
                    "Loading model into memory (~5–10 seconds the first time)…",
                    fontSize = 13.sp,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
        }
    }
}

/** Placeholder when the conversation is empty. */
@Composable
private fun ChatEmptyState(
    modelInstalled: Boolean,
    isModelLoading: Boolean,
    ragLabel: String,
    contextStatus: String
) {
    Box(
        modifier = Modifier.fillMaxSize().padding(24.dp),
        contentAlignment = Alignment.Center
    ) {
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            Text("\uD83D\uDCAC", fontSize = 48.sp)
            Spacer(Modifier.height(12.dp))
            Text(
                if (!modelInstalled)
                    "Install the chat model in Settings to get started."
                else if (isModelLoading)
                    "Getting the model ready…"
                else
                    "Ask a question about your library.",
                fontSize = 15.sp,
                fontWeight = FontWeight.Medium,
                color = MaterialTheme.colorScheme.onSurface
            )
            if (modelInstalled && !isModelLoading) {
                Spacer(Modifier.height(8.dp))
                Text(
                    "Context: $ragLabel",
                    fontSize = 12.sp,
                    fontWeight = FontWeight.Medium,
                    color = MaterialTheme.colorScheme.primary
                )
                Spacer(Modifier.height(4.dp))
                Text(
                    contextStatus,
                    fontSize = 11.sp,
                    color = if (contextStatus.startsWith("⚠️"))
                        MaterialTheme.colorScheme.error
                    else
                        MaterialTheme.colorScheme.onSurfaceVariant,
                    lineHeight = 15.sp
                )
                Spacer(Modifier.height(10.dp))
                Text(
                    "Try: \u201CSummarise what I have on the holy spirit.\u201D",
                    fontSize = 13.sp,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
        }
    }
}

/** One message bubble. */
@Composable
private fun ChatMessageBubble(
    msg: AppViewModel.ChatMessage,
    onCitationClick: (noteId: Long, fileType: String) -> Unit
) {
    val isUser = msg.role == AppViewModel.ChatRole.USER
    val bubbleColor =
        if (msg.isError) MaterialTheme.colorScheme.errorContainer
        else if (isUser) MaterialTheme.colorScheme.primaryContainer
        else MaterialTheme.colorScheme.surfaceVariant
    val textColor =
        if (msg.isError) MaterialTheme.colorScheme.onErrorContainer
        else if (isUser) MaterialTheme.colorScheme.onPrimaryContainer
        else MaterialTheme.colorScheme.onSurfaceVariant

    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = if (isUser) Arrangement.End else Arrangement.Start
    ) {
        Column(
            modifier = Modifier
                .wrapContentWidth()
                .clip(RoundedCornerShape(14.dp))
                .background(bubbleColor)
                .padding(horizontal = 14.dp, vertical = 10.dp)
        ) {
            Text(
                if (isUser) "You" else "Library answer",
                fontSize = 10.sp,
                fontWeight = FontWeight.Bold,
                color = textColor.copy(alpha = 0.7f)
            )
            Spacer(Modifier.height(4.dp))
            // v5.4.48 — SelectionContainer makes text long-pressable to
            // select and copy, like any other text in the app.
            androidx.compose.foundation.text.selection.SelectionContainer {
                if (msg.content.isEmpty() && msg.isStreaming) {
                    Text("…", fontSize = 16.sp, color = textColor)
                } else {
                    Text(msg.content, fontSize = 14.sp, color = textColor, lineHeight = 20.sp)
                }
            }
            // v5.4.48 — Citation chips: tappable, open the source article
            if (!isUser && msg.citations.isNotEmpty()) {
                Spacer(Modifier.height(10.dp))
                Text(
                    "Sources (${msg.citations.size}):",
                    fontSize = 10.sp,
                    fontWeight = FontWeight.Bold,
                    color = textColor.copy(alpha = 0.7f)
                )
                Spacer(Modifier.height(4.dp))
                msg.citations.forEach { c ->
                    val fileIcon = when (c.fileType) {
                        "pdf" -> "📕"
                        "html", "mhtml" -> "🌐"
                        else -> "📄"
                    }
                    androidx.compose.foundation.layout.Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(vertical = 2.dp)
                            .clip(RoundedCornerShape(8.dp))
                            .background(
                                MaterialTheme.colorScheme.primary.copy(alpha = 0.12f)
                            )
                            .clickable { onCitationClick(c.noteId, c.fileType) }
                            .padding(horizontal = 10.dp, vertical = 6.dp)
                    ) {
                        Text(
                            "$fileIcon  ${c.title}  →",
                            fontSize = 12.sp,
                            color = MaterialTheme.colorScheme.primary,
                            fontWeight = FontWeight.Medium,
                            maxLines = 2,
                            overflow = TextOverflow.Ellipsis
                        )
                    }
                }
            }
        }
    }
}

/** Bottom input bar. */
@Composable
private fun ChatInputBar(
    input: String,
    onInputChange: (String) -> Unit,
    isBusy: Boolean,
    isGenerating: Boolean,
    enabled: Boolean,
    onSend: () -> Unit,
    onStop: () -> Unit
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .background(MaterialTheme.colorScheme.surface)
            .padding(8.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        OutlinedTextField(
            value = input,
            onValueChange = onInputChange,
            modifier = Modifier.weight(1f),
            enabled = enabled && !isBusy,
            placeholder = { Text("Ask about your library…", fontSize = 14.sp) },
            singleLine = false,
            maxLines = 4,
            textStyle = androidx.compose.ui.text.TextStyle(fontSize = 14.sp)
        )
        Spacer(Modifier.width(8.dp))
        if (isGenerating) {
            Button(
                onClick = onStop,
                colors = androidx.compose.material3.ButtonDefaults.buttonColors(
                    containerColor = MaterialTheme.colorScheme.error
                )
            ) {
                Text("Stop")
            }
        } else {
            Button(
                onClick = onSend,
                enabled = enabled && !isBusy && input.isNotBlank()
            ) {
                Text("Send")
            }
        }
    }
}
