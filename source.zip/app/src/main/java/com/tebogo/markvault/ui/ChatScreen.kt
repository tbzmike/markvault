package com.tebogo.markvault.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.wrapContentWidth
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material3.Button
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.navigation.NavHostController
import com.tebogo.markvault.AppViewModel

/**
 * v4.22.0 — Stage 5b: the actual chat UI for the on-device RAG feature.
 *
 * Top app bar with title + clear-conversation button. A status banner
 * appears between the bar and the message list when the model is loading,
 * failed to load, or needs installation. The message list scrolls within
 * a fixed bottom input row — keeps the text field reachable with one thumb.
 *
 * Lifecycle:
 *   - On open: if load mode is "on_open" (default), kick off model load
 *     immediately. "on_first_q" defers to first send; "preload" should
 *     already be loaded by AppViewModel.init.
 *   - On dispose: if load mode is "on_open" or "on_first_q", unload to
 *     free ~900 MB of RAM. "preload" mode keeps the model resident.
 *
 * Streaming:
 *   - Each generation creates one streaming-flagged assistant message.
 *   - The ViewModel updates its content as tokens arrive; the LazyColumn
 *     re-composes that one row.
 *   - A "Stop" button replaces "Send" while generating; tapping it
 *     cancels the coroutine via [AppViewModel.stopChatGeneration].
 */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ChatScreen(vm: AppViewModel, nav: NavHostController) {
    val messages by vm.chatMessages.collectAsStateWithLifecycle()
    val isModelLoading by vm.chatIsModelLoading.collectAsStateWithLifecycle()
    val isGenerating by vm.chatIsGenerating.collectAsStateWithLifecycle()
    val modelInstalled by vm.chatModelInstalled.collectAsStateWithLifecycle()
    val loadError by vm.chatModelLoadError.collectAsStateWithLifecycle()
    val loadMode by vm.chatModelLoadModePref.collectAsStateWithLifecycle()

    var input by remember { mutableStateOf("") }
    val listState = rememberLazyListState()

    // ── Lifecycle: load on open (default), unload on dispose ──────────
    LaunchedEffect(loadMode, modelInstalled) {
        if (loadMode == "on_open" && modelInstalled) {
            vm.ensureChatModelLoaded()
        }
    }
    DisposableEffect(loadMode) {
        onDispose {
            // Free RAM when leaving the screen — unless user picked
            // "preload" mode, in which case keep model resident.
            if (loadMode != "preload") {
                vm.unloadChatModel()
            }
        }
    }

    // Auto-scroll to the latest message as it streams.
    LaunchedEffect(messages.size, messages.lastOrNull()?.content?.length) {
        if (messages.isNotEmpty()) {
            listState.animateScrollToItem(messages.size - 1)
        }
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Text("\uD83D\uDCAC Chat", fontWeight = FontWeight.SemiBold)
                },
                navigationIcon = {
                    IconButton(onClick = { nav.popBackStack() }) {
                        Icon(
                            Icons.AutoMirrored.Filled.ArrowBack,
                            contentDescription = "Back"
                        )
                    }
                },
                actions = {
                    if (messages.isNotEmpty()) {
                        TextButton(onClick = { vm.clearChatMessages() }) {
                            Text("Clear")
                        }
                    }
                }
            )
        },
        bottomBar = {
            ChatInputBar(
                input = input,
                onInputChange = { input = it },
                isBusy = isGenerating || isModelLoading,
                isGenerating = isGenerating,
                enabled = modelInstalled && loadError == null,
                onSend = {
                    val text = input.trim()
                    if (text.isNotEmpty()) {
                        input = ""
                        vm.sendChatMessage(text)
                    }
                },
                onStop = { vm.stopChatGeneration() }
            )
        }
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
        ) {
            ChatStatusBanner(
                modelInstalled = modelInstalled,
                isModelLoading = isModelLoading,
                loadError = loadError,
                onDismissError = { vm.clearChatModelLoadError() },
                onGoToSettings = { nav.navigate("settings") }
            )
            if (messages.isEmpty()) {
                ChatEmptyState(
                    modelInstalled = modelInstalled,
                    isModelLoading = isModelLoading
                )
            } else {
                LazyColumn(
                    state = listState,
                    modifier = Modifier.fillMaxSize(),
                    contentPadding = PaddingValues(12.dp),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    items(messages, key = { it.id }) { msg ->
                        ChatMessageBubble(msg)
                    }
                }
            }
        }
    }
}

/**
 * Banner across the top of the chat area showing the model's status
 * when not normal: loading, errored, or uninstalled.
 */
@Composable
private fun ChatStatusBanner(
    modelInstalled: Boolean,
    isModelLoading: Boolean,
    loadError: String?,
    onDismissError: () -> Unit,
    onGoToSettings: () -> Unit
) {
    when {
        loadError != null -> {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(MaterialTheme.colorScheme.errorContainer)
                    .padding(12.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    "\u26A0\uFE0F  $loadError",
                    fontSize = 13.sp,
                    color = MaterialTheme.colorScheme.onErrorContainer,
                    modifier = Modifier.weight(1f)
                )
                if (!modelInstalled) {
                    TextButton(onClick = onGoToSettings) {
                        Text("Settings")
                    }
                } else {
                    TextButton(onClick = onDismissError) {
                        Text("Dismiss")
                    }
                }
            }
        }
        !modelInstalled -> {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(MaterialTheme.colorScheme.tertiaryContainer)
                    .padding(12.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    "Chat model is not installed. ~400 MB download required.",
                    fontSize = 13.sp,
                    color = MaterialTheme.colorScheme.onTertiaryContainer,
                    modifier = Modifier.weight(1f)
                )
                TextButton(onClick = onGoToSettings) {
                    Text("Install in Settings")
                }
            }
        }
        isModelLoading -> {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(MaterialTheme.colorScheme.surfaceVariant)
                    .padding(12.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                CircularProgressIndicator(
                    modifier = Modifier.width(16.dp).height(16.dp),
                    strokeWidth = 2.dp
                )
                Spacer(Modifier.width(12.dp))
                Text(
                    "Loading model into memory (~5–10 seconds the first time)…",
                    fontSize = 13.sp,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
        }
    }
}

/** Placeholder when the conversation is empty. */
@Composable
private fun ChatEmptyState(modelInstalled: Boolean, isModelLoading: Boolean) {
    Box(
        modifier = Modifier.fillMaxSize().padding(24.dp),
        contentAlignment = Alignment.Center
    ) {
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            Text(
                "\uD83D\uDCAC",
                fontSize = 48.sp
            )
            Spacer(Modifier.height(12.dp))
            Text(
                if (!modelInstalled)
                    "Install the chat model in Settings to get started."
                else if (isModelLoading)
                    "Getting the model ready…"
                else
                    "Ask a question about your library.",
                fontSize = 15.sp,
                fontWeight = FontWeight.Medium,
                color = MaterialTheme.colorScheme.onSurface
            )
            if (modelInstalled && !isModelLoading) {
                Spacer(Modifier.height(8.dp))
                Text(
                    "Try: \u201CSummarise what I have on the holy spirit.\u201D",
                    fontSize = 13.sp,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
                Spacer(Modifier.height(10.dp))
                Text(
                    "📚 Uses your indexed library if available.\n" +
                    "📄 Falls back to your 5 most recently opened articles.",
                    fontSize = 11.sp,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    lineHeight = 16.sp
                )
            }
        }
    }
}

/** One message bubble. */
@Composable
private fun ChatMessageBubble(msg: AppViewModel.ChatMessage) {
    val isUser = msg.role == AppViewModel.ChatRole.USER
    val bubbleColor =
        if (msg.isError) MaterialTheme.colorScheme.errorContainer
        else if (isUser) MaterialTheme.colorScheme.primaryContainer
        else MaterialTheme.colorScheme.surfaceVariant
    val textColor =
        if (msg.isError) MaterialTheme.colorScheme.onErrorContainer
        else if (isUser) MaterialTheme.colorScheme.onPrimaryContainer
        else MaterialTheme.colorScheme.onSurfaceVariant

    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = if (isUser) Arrangement.End else Arrangement.Start
    ) {
        Column(
            modifier = Modifier
                .wrapContentWidth()
                .clip(RoundedCornerShape(14.dp))
                .background(bubbleColor)
                .padding(horizontal = 14.dp, vertical = 10.dp)
        ) {
            // Header chip showing role
            Text(
                if (isUser) "You" else "Library answer",
                fontSize = 10.sp,
                fontWeight = FontWeight.Bold,
                color = textColor.copy(alpha = 0.7f)
            )
            Spacer(Modifier.height(4.dp))
            // The message content. Empty content during streaming becomes
            // a typing indicator instead of an empty bubble.
            if (msg.content.isEmpty() && msg.isStreaming) {
                Text("…", fontSize = 16.sp, color = textColor)
            } else {
                Text(msg.content, fontSize = 14.sp, color = textColor, lineHeight = 20.sp)
            }
            // Citation chips, only shown on assistant messages with hits.
            if (!isUser && msg.citations.isNotEmpty()) {
                Spacer(Modifier.height(10.dp))
                Text(
                    "Notes used (${msg.citations.size}):",
                    fontSize = 10.sp,
                    fontWeight = FontWeight.Bold,
                    color = textColor.copy(alpha = 0.7f)
                )
                Spacer(Modifier.height(4.dp))
                msg.citations.forEach { c ->
                    Text(
                        "• ${c.title}",
                        fontSize = 12.sp,
                        color = textColor,
                        lineHeight = 16.sp
                    )
                }
            }
        }
    }
}

/** Bottom input bar. */
@Composable
private fun ChatInputBar(
    input: String,
    onInputChange: (String) -> Unit,
    isBusy: Boolean,
    isGenerating: Boolean,
    enabled: Boolean,
    onSend: () -> Unit,
    onStop: () -> Unit
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .background(MaterialTheme.colorScheme.surface)
            .padding(8.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        OutlinedTextField(
            value = input,
            onValueChange = onInputChange,
            modifier = Modifier.weight(1f),
            enabled = enabled && !isBusy,
            placeholder = { Text("Ask about your library…", fontSize = 14.sp) },
            singleLine = false,
            maxLines = 4,
            textStyle = androidx.compose.ui.text.TextStyle(fontSize = 14.sp)
        )
        Spacer(Modifier.width(8.dp))
        if (isGenerating) {
            Button(
                onClick = onStop,
                colors = androidx.compose.material3.ButtonDefaults.buttonColors(
                    containerColor = MaterialTheme.colorScheme.error
                )
            ) {
                Text("Stop")
            }
        } else {
            Button(
                onClick = onSend,
                enabled = enabled && !isBusy && input.isNotBlank()
            ) {
                Text("Send")
            }
        }
    }
}
