package com.tebogo.markvault.markdown

object ScriptureDetector {
    private val bible=Regex("""\b(Genesis|Exodus|Matthew|Mark|Luke|John|Acts|Romans|[1-3]\s+\w+)\s+\d+:\d+""")
    fun extract(source:String):List<String> = bible.findAll(source).map{it.value}.toList()
}
