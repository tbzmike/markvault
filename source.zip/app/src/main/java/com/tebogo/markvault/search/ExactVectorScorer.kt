package com.tebogo.markvault.search

/** Full precision dot products for blue HNSW; callers retain the existing scalar fallback. */
object ExactVectorScorer {
    fun score(query: FloatArray, vectors: Array<ByteArray>): FloatArray? {
        if (!NativeHnswBridge.available) return null
        return runCatching {
            NativeHnswBridge.scoreVectors(query, vectors).also { check(it.size == vectors.size) }
        }.getOrNull()
    }
}
