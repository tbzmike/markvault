package com.tebogo.markvault.ai

/** Final model install validation. */
object T5ModelInstallVerifier {
    fun verify(files: Set<String>, checksumOk: Boolean, versionOk: Boolean): Boolean {
        return files.contains("model.tflite") &&
               files.contains("tokenizer.json") &&
               files.contains("config.json") &&
               checksumOk && versionOk
    }
}
