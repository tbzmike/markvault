package com.tebogo.markvault.ai

/** Final model install validation. */
object T5ModelInstallVerifier {
    fun verify(files: Set<String>, checksumOk: Boolean, versionOk: Boolean): Boolean {
        return T5ModelFileRegistry.missingFiles(files).isEmpty() &&
               checksumOk && versionOk
    }
}
