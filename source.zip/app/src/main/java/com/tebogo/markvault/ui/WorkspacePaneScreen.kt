package com.tebogo.markvault.ui

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectDragGesturesAfterLongPress
import androidx.compose.foundation.gestures.detectHorizontalDragGestures
import androidx.compose.foundation.gestures.detectVerticalDragGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.ui.layout.boundsInRoot
import androidx.compose.ui.layout.onGloballyPositioned
import androidx.compose.ui.layout.onSizeChanged
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.layout.wrapContentHeight
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.focusable
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.MoreVert
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.TextButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.VerticalDivider
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateMapOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Rect
import androidx.compose.ui.Modifier
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.input.key.KeyEventType
import androidx.compose.ui.input.key.onPreviewKeyEvent
import androidx.compose.ui.input.key.type
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.delay
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.navigation.NavHostController
import com.tebogo.markvault.AppViewModel
import com.tebogo.markvault.TabInfo
import org.json.JSONArray
import org.json.JSONObject

private const val MAX_WORKSPACE_PANES = 4

private data class PaneTab(
    val key: String,
    val label: String,
    val kind: String,
    val noteId: Long = 0L,
    val fileType: String = "md",
    val scrollPosition: Int = 0,
    val anchor: String = ""
)

private sealed interface PaneNode
private data class PaneLeaf(
    val paneId: Int,
    val tabs: List<PaneTab>,
    val activeKey: String,
    val locked: Boolean = false,
    val backStack: List<String> = emptyList(),
    val forwardStack: List<String> = emptyList(),
    val openMode: String = "current"
) : PaneNode
private data class PaneSplit(
    val splitId: Int,
    val vertical: Boolean,
    val ratio: Float = 0.5f,
    val first: PaneNode,
    val second: PaneNode
 ) : PaneNode

private data class WorkspaceBookmarkEntry(
    val id: String,
    val label: String,
    val tab: PaneTab
)

/**
 * v5.4.330cc — Advanced Obsidian-style multi-pane Workspace.
 *
 * This is additive: it reuses the proven document split renderers and existing
 * Search/Graph/Media/AI screens rather than replacing the normal readers.
 */
@Composable
fun WorkspacePaneScreen(vm: AppViewModel, nav: NavHostController) {
    val globalTabs by vm.tabs.collectAsStateWithLifecycle()
    val activeGlobal by vm.activeTab.collectAsStateWithLifecycle()
    val savedA by vm.workspacePaneLayoutA.collectAsStateWithLifecycle()
    val savedB by vm.workspacePaneLayoutB.collectAsStateWithLifecycle()
    val savedC by vm.workspacePaneLayoutC.collectAsStateWithLifecycle()
    val liveSaved by vm.workspacePaneCurrent.collectAsStateWithLifecycle()
    val namedLayoutsRaw by vm.workspaceNamedLayouts.collectAsStateWithLifecycle()
    val bookmarksRaw by vm.workspaceBookmarks.collectAsStateWithLifecycle()
    val indexedNotes by vm.notes.collectAsStateWithLifecycle()

    val initial = remember(globalTabs, activeGlobal) { seedPaneTree(globalTabs, activeGlobal) }
    var root by remember { mutableStateOf<PaneNode>(initial) }
    var activePaneId by remember { mutableStateOf(firstLeaf(root).paneId) }
    var layoutsMenu by remember { mutableStateOf(false) }
    var liveLayoutLoaded by remember { mutableStateOf(false) }
    var workspaceManagerOpen by remember { mutableStateOf(false) }
    var bookmarkManagerOpen by remember { mutableStateOf(false) }
    var vaultOpen by remember { mutableStateOf(false) }
    val paneBounds = remember { mutableStateMapOf<Int, Rect>() }
    val workspaceFocus = remember { FocusRequester() }

    // Restore the last unsaved live pane arrangement only after DataStore has actually emitted.
    LaunchedEffect(liveSaved) {
        if (!liveLayoutLoaded && liveSaved != "__loading__") {
            decodePaneTree(liveSaved).let { restored ->
                if (restored != null) {
                    root = restored
                    activePaneId = firstLeaf(restored).paneId
                }
            }
            liveLayoutLoaded = true
        }
    }

    // Debounced live-session persistence. Layout A/B/C remain explicit snapshots.
    LaunchedEffect(root, liveLayoutLoaded) {
        if (liveLayoutLoaded) {
            delay(350)
            vm.setWorkspacePaneCurrent(encodePaneTree(root))
        }
    }

    LaunchedEffect(Unit) { workspaceFocus.requestFocus() }

    LaunchedEffect(globalTabs) {
        if (leafCount(root) == 1 && globalTabs.isNotEmpty()) {
            val leaf = firstLeaf(root)
            val currentDocs = leaf.tabs.filter { it.kind == "document" }.map { it.noteId }.toSet()
            val missing = globalTabs.filterNot { it.id in currentDocs }
            if (missing.isNotEmpty()) {
                root = updateLeaf(root, leaf.paneId) { l ->
                    l.copy(tabs = l.tabs + missing.map(::documentPaneTab))
                }
            }
        }
    }

    Column(
        Modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
            .focusRequester(workspaceFocus)
            .focusable()
            .onPreviewKeyEvent { event ->
                if (event.type != KeyEventType.KeyDown) return@onPreviewKeyEvent false
                val native = event.nativeKeyEvent
                when {
                    native.isAltPressed && native.keyCode == android.view.KeyEvent.KEYCODE_DPAD_LEFT -> {
                        val changed = paneBack(root, activePaneId)
                        if (changed != root) root = changed
                        true
                    }
                    native.isAltPressed && native.keyCode == android.view.KeyEvent.KEYCODE_DPAD_RIGHT -> {
                        val changed = paneForward(root, activePaneId)
                        if (changed != root) root = changed
                        true
                    }
                    native.isCtrlPressed && native.keyCode == android.view.KeyEvent.KEYCODE_TAB -> {
                        root = cyclePaneTab(root, activePaneId, backwards = native.isShiftPressed)
                        true
                    }
                    native.isCtrlPressed && native.keyCode == android.view.KeyEvent.KEYCODE_W -> {
                        root = closeActivePaneTab(root, activePaneId)
                        true
                    }
                    native.isCtrlPressed && native.keyCode == android.view.KeyEvent.KEYCODE_BACKSLASH -> {
                        if (leafCount(root) < MAX_WORKSPACE_PANES) {
                            root = splitLeaf(root, activePaneId, vertical = !native.isShiftPressed)
                        }
                        true
                    }
                    native.isCtrlPressed && native.isShiftPressed && native.keyCode == android.view.KeyEvent.KEYCODE_B -> {
                        findLeaf(root, activePaneId)?.tabs?.firstOrNull { it.key == findLeaf(root, activePaneId)?.activeKey }?.let { tab ->
                            vm.setWorkspaceBookmarks(addBookmarkRaw(bookmarksRaw, WorkspaceBookmarkEntry(newBookmarkId(), tab.label, tab)))
                        }
                        true
                    }
                    native.isCtrlPressed && native.keyCode in android.view.KeyEvent.KEYCODE_1..android.view.KeyEvent.KEYCODE_4 -> {
                        val index = native.keyCode - android.view.KeyEvent.KEYCODE_1
                        leaves(root).getOrNull(index)?.let { activePaneId = it.paneId }
                        true
                    }
                    native.isCtrlPressed && native.keyCode == android.view.KeyEvent.KEYCODE_L -> {
                        root = updateLeaf(root, activePaneId) { it.copy(locked = !it.locked) }
                        true
                    }
                    native.isCtrlPressed && native.isShiftPressed && native.keyCode == android.view.KeyEvent.KEYCODE_P -> {
                        workspaceManagerOpen = true
                        true
                    }
                    native.isCtrlPressed && native.keyCode == android.view.KeyEvent.KEYCODE_O -> {
                        vaultOpen = !vaultOpen
                        true
                    }
                    else -> false
                }
            }
    ) {
        Surface(
            tonalElevation = 2.dp,
            shadowElevation = 2.dp,
            color = MaterialTheme.colorScheme.surface,
            border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant)
        ) {
            Row(
                Modifier.fillMaxWidth().height(44.dp).padding(horizontal = 8.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                Text("Workspace panes", fontSize = 14.sp, fontWeight = FontWeight.Bold)
                Text("${leafCount(root)}/$MAX_WORKSPACE_PANES", fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                Spacer(Modifier.weight(1f))
                val activeLeaf = findLeaf(root, activePaneId)
                PaneToolbarButton("←") { root = paneBack(root, activePaneId) }
                PaneToolbarButton("→") { root = paneForward(root, activePaneId) }
                PaneToolbarButton("Split ↔") {
                    if (leafCount(root) < MAX_WORKSPACE_PANES) {
                        root = splitLeaf(root, activePaneId, vertical = true)
                    }
                }
                PaneToolbarButton("Split ↕") {
                    if (leafCount(root) < MAX_WORKSPACE_PANES) {
                        root = splitLeaf(root, activePaneId, vertical = false)
                    }
                }
                PaneToolbarButton(if (findLeaf(root, activePaneId)?.locked == true) "🔒" else "🔓") {
                    root = updateLeaf(root, activePaneId) { it.copy(locked = !it.locked) }
                }
                PaneToolbarButton(if (vaultOpen) "Vault ×" else "Vault") { vaultOpen = !vaultOpen }
                PaneToolbarButton("★") { bookmarkManagerOpen = true }
                PaneToolbarButton("Workspaces") { workspaceManagerOpen = true }
                Box {
                    PaneToolbarButton("Layouts ▾") { layoutsMenu = true }
                    DropdownMenu(expanded = layoutsMenu, onDismissRequest = { layoutsMenu = false }) {
                        DropdownMenuItem(text = { Text("Save layout A") }, onClick = { vm.setWorkspacePaneLayoutA(encodePaneTree(root)); layoutsMenu = false })
                        DropdownMenuItem(text = { Text("Load layout A") }, enabled = savedA.isNotBlank(), onClick = { decodePaneTree(savedA)?.let { root = it; activePaneId = firstLeaf(it).paneId }; layoutsMenu = false })
                        HorizontalDivider()
                        DropdownMenuItem(text = { Text("Save layout B") }, onClick = { vm.setWorkspacePaneLayoutB(encodePaneTree(root)); layoutsMenu = false })
                        DropdownMenuItem(text = { Text("Load layout B") }, enabled = savedB.isNotBlank(), onClick = { decodePaneTree(savedB)?.let { root = it; activePaneId = firstLeaf(it).paneId }; layoutsMenu = false })
                        HorizontalDivider()
                        DropdownMenuItem(text = { Text("Save layout C") }, onClick = { vm.setWorkspacePaneLayoutC(encodePaneTree(root)); layoutsMenu = false })
                        DropdownMenuItem(text = { Text("Load layout C") }, enabled = savedC.isNotBlank(), onClick = { decodePaneTree(savedC)?.let { root = it; activePaneId = firstLeaf(it).paneId }; layoutsMenu = false })
                    }
                }
                PaneToolbarButton("Reset") {
                    root = seedPaneTree(globalTabs, activeGlobal)
                    activePaneId = firstLeaf(root).paneId
                }
            }
        }

        Row(Modifier.weight(1f).fillMaxWidth()) {
            if (vaultOpen) {
                PaneVaultRail(
                    notes = indexedNotes,
                    paneBounds = paneBounds,
                    rootProvider = { root },
                    onUpdateRoot = { root = it },
                    onFocusPane = { activePaneId = it },
                    activePaneId = activePaneId
                )
            }
            PaneNodeView(
                node = root,
                vm = vm,
                nav = nav,
                activePaneId = activePaneId,
                onFocusPane = { activePaneId = it },
                onUpdateRoot = { root = it },
                rootProvider = { root },
                globalTabs = globalTabs,
                paneBounds = paneBounds,
                modifier = Modifier.weight(1f)
            )
        }
    }

    if (workspaceManagerOpen) {
        NamedWorkspacesDialog(
            raw = namedLayoutsRaw,
            currentLayout = encodePaneTree(root),
            onDismiss = { workspaceManagerOpen = false },
            onSaveRaw = vm::setWorkspaceNamedLayouts,
            onLoad = { layout -> decodePaneTree(layout)?.let { root = it; activePaneId = firstLeaf(it).paneId }; workspaceManagerOpen = false }
        )
    }
    if (bookmarkManagerOpen) {
        WorkspaceBookmarksDialog(
            raw = bookmarksRaw,
            activeTab = findLeaf(root, activePaneId)?.let { leaf -> leaf.tabs.firstOrNull { it.key == leaf.activeKey } },
            onDismiss = { bookmarkManagerOpen = false },
            onSaveRaw = vm::setWorkspaceBookmarks,
            onOpen = { tab ->
                val opened = openTabByPanePolicy(root, activePaneId, tab)
                root = opened.first
                activePaneId = opened.second
                bookmarkManagerOpen = false
            }
        )
    }
}

@Composable
private fun PaneNodeView(
    node: PaneNode,
    vm: AppViewModel,
    nav: NavHostController,
    activePaneId: Int,
    onFocusPane: (Int) -> Unit,
    onUpdateRoot: (PaneNode) -> Unit,
    rootProvider: () -> PaneNode,
    globalTabs: List<TabInfo>,
    paneBounds: MutableMap<Int, Rect>,
    modifier: Modifier = Modifier
) {
    when (node) {
        is PaneLeaf -> PaneLeafView(node, vm, nav, activePaneId == node.paneId, onFocusPane, onUpdateRoot, rootProvider, globalTabs, paneBounds, modifier)
        is PaneSplit -> PaneSplitView(node, vm, nav, activePaneId, onFocusPane, onUpdateRoot, rootProvider, globalTabs, paneBounds, modifier)
    }
}

@Composable
private fun PaneSplitView(
    node: PaneSplit,
    vm: AppViewModel,
    nav: NavHostController,
    activePaneId: Int,
    onFocusPane: (Int) -> Unit,
    onUpdateRoot: (PaneNode) -> Unit,
    rootProvider: () -> PaneNode,
    globalTabs: List<TabInfo>,
    paneBounds: MutableMap<Int, Rect>,
    modifier: Modifier
) {
    var extentPx by remember { mutableStateOf(1) }
    if (node.vertical) {
        Row(modifier.fillMaxSize().onSizeChanged { extentPx = it.width.coerceAtLeast(1) }) {
            PaneNodeView(node.first, vm, nav, activePaneId, onFocusPane, onUpdateRoot, rootProvider, globalTabs, paneBounds, Modifier.weight(node.ratio).fillMaxHeight())
            PaneTreeDivider(vertical = true) { delta ->
                val next = (node.ratio + delta / extentPx.toFloat()).coerceIn(0.2f, 0.8f)
                onUpdateRoot(updateSplitRatio(rootProvider(), node.splitId, next))
            }
            PaneNodeView(node.second, vm, nav, activePaneId, onFocusPane, onUpdateRoot, rootProvider, globalTabs, paneBounds, Modifier.weight(1f - node.ratio).fillMaxHeight())
        }
    } else {
        Column(modifier.fillMaxSize().onSizeChanged { extentPx = it.height.coerceAtLeast(1) }) {
            PaneNodeView(node.first, vm, nav, activePaneId, onFocusPane, onUpdateRoot, rootProvider, globalTabs, paneBounds, Modifier.weight(node.ratio).fillMaxWidth())
            PaneTreeDivider(vertical = false) { delta ->
                val next = (node.ratio + delta / extentPx.toFloat()).coerceIn(0.2f, 0.8f)
                onUpdateRoot(updateSplitRatio(rootProvider(), node.splitId, next))
            }
            PaneNodeView(node.second, vm, nav, activePaneId, onFocusPane, onUpdateRoot, rootProvider, globalTabs, paneBounds, Modifier.weight(1f - node.ratio).fillMaxWidth())
        }
    }
}

@Composable
private fun PaneLeafView(
    leaf: PaneLeaf,
    vm: AppViewModel,
    nav: NavHostController,
    focused: Boolean,
    onFocusPane: (Int) -> Unit,
    onUpdateRoot: (PaneNode) -> Unit,
    rootProvider: () -> PaneNode,
    globalTabs: List<TabInfo>,
    paneBounds: MutableMap<Int, Rect>,
    modifier: Modifier
) {
    var addMenu by remember { mutableStateOf(false) }
    var dockPreview by remember { mutableStateOf<String?>(null) }
    var transferTargetPaneId by remember { mutableStateOf<Int?>(null) }
    var contextNote by remember { mutableStateOf<com.tebogo.markvault.data.Note?>(null) }
    val active = leaf.tabs.firstOrNull { it.key == leaf.activeKey } ?: leaf.tabs.firstOrNull()
    val contextDocument = active?.takeIf { it.kind == "document" }
        ?: leaf.tabs.lastOrNull { it.kind == "document" }
    LaunchedEffect(contextDocument?.noteId) {
        contextNote = contextDocument?.noteId?.takeIf { it != 0L }?.let { vm.noteById(it) }
    }

    Surface(
        modifier = modifier.padding(2.dp)
            .onGloballyPositioned { paneBounds[leaf.paneId] = it.boundsInRoot() }
            .clickable { onFocusPane(leaf.paneId) },
        border = BorderStroke(if (focused) 2.dp else 1.dp, if (focused) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.outlineVariant),
        color = MaterialTheme.colorScheme.surface,
        shape = RoundedCornerShape(6.dp)
    ) {
        Column(Modifier.fillMaxSize()) {
            Row(
                Modifier.fillMaxWidth().height(38.dp).padding(start = 5.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(Modifier.weight(1f).horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                    leaf.tabs.forEach { tab ->
                        val selected = tab.key == active?.key
                        var tabBounds by remember(tab.key) { mutableStateOf<Rect?>(null) }
                        Surface(
                            color = if (selected) MaterialTheme.colorScheme.primaryContainer else MaterialTheme.colorScheme.surfaceVariant,
                            border = BorderStroke(1.dp, if (selected) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.outlineVariant),
                            shape = RoundedCornerShape(7.dp),
                            modifier = Modifier.height(32.dp).widthIn(min = 96.dp, max = 210.dp)
                                .onGloballyPositioned { tabBounds = it.boundsInRoot() }
                                .pointerInput(tab.key, leaf.paneId, leaf.locked, paneBounds.size) {
                                    var dragX = 0f
                                    var dragY = 0f
                                    detectDragGesturesAfterLongPress(
                                        onDragStart = { dragX = 0f; dragY = 0f; dockPreview = null; transferTargetPaneId = null },
                                        onDragCancel = { dragX = 0f; dragY = 0f; dockPreview = null; transferTargetPaneId = null },
                                        onDragEnd = {
                                            val targetId = transferTargetPaneId
                                            val edge = dockPreview
                                            when {
                                                targetId != null && targetId != leaf.paneId && !leaf.locked -> {
                                                    val moved = moveTabToPane(rootProvider(), leaf.paneId, targetId, tab)
                                                    onUpdateRoot(moved)
                                                    onFocusPane(targetId)
                                                }
                                                edge != null && !leaf.locked && leafCount(rootProvider()) < MAX_WORKSPACE_PANES -> {
                                                    val newPaneId = nextPaneId(rootProvider())
                                                    val docked = dockTabAtEdge(rootProvider(), leaf.paneId, tab, edge)
                                                    if (docked != rootProvider()) { onUpdateRoot(docked); onFocusPane(newPaneId) }
                                                }
                                                !leaf.locked && kotlin.math.abs(dragX) > 24f -> {
                                                    onUpdateRoot(reorderPaneTab(rootProvider(), leaf.paneId, tab.key, if (dragX > 0) 1 else -1))
                                                }
                                            }
                                            dragX = 0f; dragY = 0f; dockPreview = null; transferTargetPaneId = null
                                        },
                                        onDrag = { change, amount ->
                                            change.consume()
                                            dragX += amount.x
                                            dragY += amount.y
                                            val b = tabBounds
                                            val global = if (b != null) Offset(b.left + change.position.x, b.top + change.position.y) else null
                                            transferTargetPaneId = global?.let { point ->
                                                paneBounds.entries.firstOrNull { (id, rect) -> id != leaf.paneId && rect.contains(point) }?.key
                                            }
                                            if (transferTargetPaneId == null && !leaf.locked && leafCount(rootProvider()) < MAX_WORKSPACE_PANES) {
                                                val threshold = 52f
                                                dockPreview = if (kotlin.math.abs(dragX) >= kotlin.math.abs(dragY)) {
                                                    when { dragX >= threshold -> "right"; dragX <= -threshold -> "left"; else -> null }
                                                } else {
                                                    when { dragY >= threshold -> "bottom"; dragY <= -threshold -> "top"; else -> null }
                                                }
                                            } else dockPreview = null
                                        }
                                    )
                                }
                        ) {
                            Row(Modifier.clickable {
                                onFocusPane(leaf.paneId)
                                onUpdateRoot(activatePaneTab(rootProvider(), leaf.paneId, tab.key))
                                if (tab.kind == "document" && tab.noteId != 0L) vm.setActiveTab(tab.noteId)
                            }.padding(horizontal = 7.dp), verticalAlignment = Alignment.CenterVertically) {
                                Text(tab.label, Modifier.weight(1f), maxLines = 1, overflow = TextOverflow.Ellipsis, fontSize = 10.sp, fontWeight = if (selected) FontWeight.Bold else FontWeight.Medium)
                                Text("×", Modifier.clickable {
                                    if (leaf.tabs.size > 1) {
                                        onUpdateRoot(updateLeaf(rootProvider(), leaf.paneId) { l ->
                                            val nextTabs = l.tabs.filterNot { it.key == tab.key }
                                            val nextActive = if (l.activeKey == tab.key) nextTabs.first().key else l.activeKey
                                            l.copy(tabs = nextTabs, activeKey = nextActive)
                                        })
                                    }
                                }.padding(start = 5.dp), fontSize = 11.sp)
                            }
                        }
                    }
                }
                Text(if (leaf.locked) "🔒" else "", fontSize = 11.sp)
                Box {
                    IconButton(onClick = { addMenu = true }, modifier = Modifier.size(34.dp)) { Icon(Icons.Default.MoreVert, contentDescription = "Pane menu") }
                    DropdownMenu(expanded = addMenu, onDismissRequest = { addMenu = false }) {
                        DropdownMenuItem(text = { Text("Add Search tab") }, enabled = !leaf.locked, onClick = { onUpdateRoot(addTab(rootProvider(), leaf.paneId, PaneTab("tool-search", "Search", "search"))); addMenu = false })
                        DropdownMenuItem(text = { Text("Add Graph tab") }, enabled = !leaf.locked, onClick = { onUpdateRoot(addTab(rootProvider(), leaf.paneId, PaneTab("tool-graph", "Graph", "graph"))); addMenu = false })
                        DropdownMenuItem(text = { Text("Add Media tab") }, enabled = !leaf.locked, onClick = { onUpdateRoot(addTab(rootProvider(), leaf.paneId, PaneTab("tool-media", "Media", "media"))); addMenu = false })
                        DropdownMenuItem(text = { Text("Add AI tab") }, enabled = !leaf.locked, onClick = { onUpdateRoot(addTab(rootProvider(), leaf.paneId, PaneTab("tool-ai", "AI", "chat"))); addMenu = false })
                        contextDocument?.let { doc ->
                            DropdownMenuItem(text = { Text("Detach Outline") }, enabled = !leaf.locked, onClick = { onUpdateRoot(addTab(rootProvider(), leaf.paneId, PaneTab("tool-outline-${doc.noteId}", "Outline", "outline", doc.noteId, doc.fileType))); addMenu = false })
                            DropdownMenuItem(text = { Text("Detach Links & backlinks") }, enabled = !leaf.locked, onClick = { onUpdateRoot(addTab(rootProvider(), leaf.paneId, PaneTab("tool-links-${doc.noteId}", "Links", "links", doc.noteId, doc.fileType))); addMenu = false })
                            DropdownMenuItem(text = { Text("Detach Properties") }, enabled = !leaf.locked && doc.fileType.lowercase() in setOf("md", "markdown"), onClick = { onUpdateRoot(addTab(rootProvider(), leaf.paneId, PaneTab("tool-props-${doc.noteId}", "Properties", "properties", doc.noteId, doc.fileType))); addMenu = false })
                            DropdownMenuItem(text = { Text("Detach local graph") }, enabled = !leaf.locked, onClick = { onUpdateRoot(addTab(rootProvider(), leaf.paneId, PaneTab("tool-localgraph-${doc.noteId}", "Local graph", "localgraph", doc.noteId, doc.fileType))); addMenu = false })
                        }
                        HorizontalDivider()
                        globalTabs.forEach { g ->
                            DropdownMenuItem(
                                text = { Text("Add: ${g.title}", maxLines = 1, overflow = TextOverflow.Ellipsis) },
                                enabled = !leaf.locked,
                                onClick = {
                                    val opened = openTabByPanePolicy(rootProvider(), leaf.paneId, documentPaneTab(g))
                                    onUpdateRoot(opened.first); onFocusPane(opened.second); addMenu = false
                                }
                            )
                        }
                        HorizontalDivider()
                        DropdownMenuItem(text = { Text("Duplicate active tab") }, enabled = active != null && !leaf.locked, onClick = {
                            active?.let { onUpdateRoot(duplicatePaneTab(rootProvider(), leaf.paneId, it)) }
                            addMenu = false
                        })
                        DropdownMenuItem(text = { Text("Open links here${if (leaf.openMode == "current") " ✓" else ""}") }, onClick = { onUpdateRoot(updateLeaf(rootProvider(), leaf.paneId) { it.copy(openMode = "current") }); addMenu = false })
                        DropdownMenuItem(text = { Text("Open links in adjacent pane${if (leaf.openMode == "adjacent") " ✓" else ""}") }, onClick = { onUpdateRoot(updateLeaf(rootProvider(), leaf.paneId) { it.copy(openMode = "adjacent") }); addMenu = false })
                        DropdownMenuItem(text = { Text("Open links in new split${if (leaf.openMode == "split") " ✓" else ""}") }, onClick = { onUpdateRoot(updateLeaf(rootProvider(), leaf.paneId) { it.copy(openMode = "split") }); addMenu = false })
                        DropdownMenuItem(text = { Text(if (leaf.locked) "Unlock pane" else "Lock pane") }, onClick = { onUpdateRoot(updateLeaf(rootProvider(), leaf.paneId) { it.copy(locked = !it.locked) }); addMenu = false })
                        DropdownMenuItem(text = { Text("Move active tab to next pane") }, enabled = leaf.tabs.size > 1 && leafCount(rootProvider()) > 1 && !leaf.locked, onClick = {
                            active?.let { onUpdateRoot(moveTabToNextPane(rootProvider(), leaf.paneId, it)) }
                            addMenu = false
                        })
                        leaves(rootProvider()).filter { it.paneId != leaf.paneId }.forEach { target ->
                            DropdownMenuItem(text = { Text("Move active tab to pane ${target.paneId}") }, enabled = active != null && !leaf.locked && !target.locked, onClick = {
                                active?.let { onUpdateRoot(moveTabToPane(rootProvider(), leaf.paneId, target.paneId, it)); onFocusPane(target.paneId) }
                                addMenu = false
                            })
                        }
                        DropdownMenuItem(text = { Text("Dock active tab right") }, enabled = !leaf.locked && active != null && leafCount(rootProvider()) < MAX_WORKSPACE_PANES, onClick = {
                            active?.let { tab ->
                                val newId = nextPaneId(rootProvider())
                                onUpdateRoot(dockTabAtEdge(rootProvider(), leaf.paneId, tab, "right"))
                                onFocusPane(newId)
                            }
                            addMenu = false
                        })
                        DropdownMenuItem(text = { Text("Dock active tab down") }, enabled = !leaf.locked && active != null && leafCount(rootProvider()) < MAX_WORKSPACE_PANES, onClick = {
                            active?.let { tab ->
                                val newId = nextPaneId(rootProvider())
                                onUpdateRoot(dockTabAtEdge(rootProvider(), leaf.paneId, tab, "bottom"))
                                onFocusPane(newId)
                            }
                            addMenu = false
                        })
                        contextDocument?.let { doc ->
                            DropdownMenuItem(text = { Text("Open document full screen") }, onClick = {
                                vm.setActiveTab(doc.noteId)
                                when (doc.fileType.lowercase()) {
                                    "pdf" -> nav.navigate("pdfReader/${doc.noteId}")
                                    "html", "htm", "mhtml" -> nav.navigate("htmlReader/${doc.noteId}")
                                    else -> nav.navigate("reader")
                                }
                                addMenu = false
                            })
                        }
                        DropdownMenuItem(text = { Text("Open Vault explorer") }, onClick = { nav.navigate("browse"); addMenu = false })
                        DropdownMenuItem(text = { Text("Close pane") }, enabled = leafCount(rootProvider()) > 1, onClick = {
                            val nextRoot = removeLeaf(rootProvider(), leaf.paneId) ?: rootProvider()
                            onUpdateRoot(nextRoot)
                            onFocusPane(firstLeaf(nextRoot).paneId)
                            addMenu = false
                        })
                    }
                }
            }
            contextNote?.let { note ->
                PaneBreadcrumbs(note = note, onReveal = { nav.navigate("browse") })
            }
            if (transferTargetPaneId != null) {
                DockPreviewBar("pane ${transferTargetPaneId}")
            } else if (dockPreview != null) {
                DockPreviewBar(dockPreview!!)
            }
            HorizontalDivider()
            Box(Modifier.weight(1f).fillMaxWidth()) {
                when (active?.kind) {
                    "document" -> WorkspaceDocumentPane(
                        vm = vm, noteId = active.noteId, fileType = active.fileType, modifier = Modifier.fillMaxSize(), focused = focused,
                        onFocus = { onFocusPane(leaf.paneId); vm.setActiveTab(active.noteId) }, onClose = {},
                        initialScrollPosition = active.scrollPosition,
                        initialAnchor = active.anchor,
                        instanceKey = active.key,
                        onScrollPositionChanged = { pos ->
                            val current = findLeaf(rootProvider(), leaf.paneId)?.tabs?.firstOrNull { it.key == active.key }
                            if (current != null && kotlin.math.abs(current.scrollPosition - pos) >= 100) {
                                onUpdateRoot(updateTabScroll(rootProvider(), leaf.paneId, active.key, pos))
                            }
                        }
                    )
                    "search" -> SearchScreen(vm, nav)
                    "graph" -> GraphScreen(vm, nav, startNoteId = null)
                    "localgraph" -> GraphScreen(vm, nav, startNoteId = active.noteId.takeIf { it != 0L })
                    "media" -> JwVideoBrowseScreen(vm, nav)
                    "chat" -> ChatScreen(vm, nav)
                    "outline" -> PaneOutlineTool(vm, active.noteId, onBookmarkHeading = { heading ->
                        vm.setWorkspaceBookmarks(addBookmarkRaw(vm.workspaceBookmarks.value, WorkspaceBookmarkEntry(newBookmarkId(), heading, PaneTab("bookmark-heading-${active.noteId}-${heading.hashCode()}", heading, "document", active.noteId, active.fileType, anchor = heading))))
                    })
                    "links" -> PaneLinksTool(vm, active.noteId, onOpenNote = { id, title ->
                        val note = runCatching { vm.notes.value.firstOrNull { it.id == id } }.getOrNull()
                        val tab = PaneTab("doc-$id", title, "document", id, note?.fileType ?: "md")
                        val opened = openTabByPanePolicy(rootProvider(), leaf.paneId, tab)
                        onUpdateRoot(opened.first); onFocusPane(opened.second)
                    })
                    "properties" -> PanePropertiesTool(vm, active.noteId)
                    else -> Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) { Text("Open a document or tool in this pane") }
                }
            }
        }
    }
}

@Composable
private fun DockPreviewBar(edge: String) {
    val label = when {
        edge.startsWith("pane ") -> "Move to ${edge.removePrefix("pane ")}"
        edge == "left" -> "⇤ Dock left"
        edge == "right" -> "Dock right ⇥"
        edge == "top" -> "⇧ Dock above"
        else -> "⇩ Dock below"
    }
    Surface(
        color = MaterialTheme.colorScheme.primaryContainer,
        contentColor = MaterialTheme.colorScheme.onPrimaryContainer,
        border = BorderStroke(1.dp, MaterialTheme.colorScheme.primary),
        modifier = Modifier.fillMaxWidth()
    ) {
        Text(label, Modifier.padding(vertical = 4.dp), textAlign = TextAlign.Center, fontSize = 11.sp, fontWeight = FontWeight.Bold)
    }
}

@Composable
private fun PaneBreadcrumbs(note: com.tebogo.markvault.data.Note, onReveal: () -> Unit) {
    val parts = note.relPath.split('/').filter { it.isNotBlank() }
    Row(
        Modifier.fillMaxWidth().background(MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.45f)).padding(horizontal = 8.dp, vertical = 4.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        parts.forEachIndexed { index, part ->
            Text(
                part,
                Modifier.clickable(onClick = onReveal).padding(horizontal = 2.dp),
                fontSize = 10.sp,
                fontWeight = if (index == parts.lastIndex) FontWeight.Bold else FontWeight.Medium,
                color = if (index == parts.lastIndex) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurfaceVariant,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )
            if (index != parts.lastIndex) Text(" › ", fontSize = 10.sp, color = MaterialTheme.colorScheme.outline)
        }
    }
}

@Composable
private fun PaneOutlineTool(vm: AppViewModel, noteId: Long, onBookmarkHeading: (String) -> Unit) {
    var content by remember(noteId) { mutableStateOf<String?>(null) }
    LaunchedEffect(noteId) { content = vm.getContentForComparison(noteId) }
    val outline = remember(content) { content?.let { AppViewModel.parseOutline(it) }.orEmpty() }
    Column(Modifier.fillMaxSize().padding(10.dp)) {
        Text("Outline", fontWeight = FontWeight.Bold, fontSize = 15.sp)
        HorizontalDivider(Modifier.padding(vertical = 6.dp))
        if (outline.isEmpty()) Text("No headings", color = MaterialTheme.colorScheme.onSurfaceVariant)
        else LazyColumn(Modifier.fillMaxSize()) {
            items(outline) { item ->
                Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                    Text(
                        item.title,
                        Modifier.weight(1f).padding(start = ((item.level - 1) * 12).dp, top = 6.dp, bottom = 6.dp),
                        fontSize = 13.sp,
                        fontWeight = if (item.level <= 2) FontWeight.Bold else FontWeight.Medium
                    )
                    Text("☆", Modifier.clickable { onBookmarkHeading(item.title) }.padding(6.dp), fontSize = 15.sp)
                }
            }
        }
    }
}

@Composable
private fun PaneLinksTool(vm: AppViewModel, noteId: Long, onOpenNote: (Long, String) -> Unit) {
    var outgoing by remember(noteId) { mutableStateOf<List<com.tebogo.markvault.data.LinkedNote>>(emptyList()) }
    var backlinks by remember(noteId) { mutableStateOf<List<com.tebogo.markvault.data.LinkedNote>>(emptyList()) }
    var unlinked by remember(noteId) { mutableStateOf<List<com.tebogo.markvault.data.SearchHit>>(emptyList()) }
    LaunchedEffect(noteId) {
        outgoing = runCatching { vm.loadForwardLinks(noteId) }.getOrElse { emptyList() }
        backlinks = runCatching { vm.loadBacklinks(noteId) }.getOrElse { emptyList() }
        unlinked = runCatching { vm.findUnlinkedMentions(noteId) }.getOrElse { emptyList() }
    }
    LazyColumn(Modifier.fillMaxSize().padding(10.dp)) {
        item { Text("Outgoing links (${outgoing.size})", fontWeight = FontWeight.Bold, fontSize = 14.sp) }
        if (outgoing.isEmpty()) item { Text("No outgoing links", Modifier.padding(vertical = 8.dp), color = MaterialTheme.colorScheme.onSurfaceVariant) }
        items(outgoing) { linked ->
            Text("→ ${linked.title}", Modifier.fillMaxWidth().clickable { onOpenNote(linked.id, linked.title) }.padding(vertical = 7.dp), fontSize = 13.sp)
        }
        item { HorizontalDivider(Modifier.padding(vertical = 8.dp)); Text("Backlinks (${backlinks.size})", fontWeight = FontWeight.Bold, fontSize = 14.sp) }
        if (backlinks.isEmpty()) item { Text("No backlinks", Modifier.padding(vertical = 8.dp), color = MaterialTheme.colorScheme.onSurfaceVariant) }
        items(backlinks) { linked ->
            Text("← ${linked.title}", Modifier.fillMaxWidth().clickable { onOpenNote(linked.id, linked.title) }.padding(vertical = 7.dp), fontSize = 13.sp)
        }
        item { HorizontalDivider(Modifier.padding(vertical = 8.dp)); Text("Unlinked mentions (${unlinked.size})", fontWeight = FontWeight.Bold, fontSize = 14.sp) }
        if (unlinked.isEmpty()) item { Text("No unlinked title mentions", Modifier.padding(vertical = 8.dp), color = MaterialTheme.colorScheme.onSurfaceVariant) }
        items(unlinked) { hit ->
            Column(Modifier.fillMaxWidth().clickable { onOpenNote(hit.id, hit.title) }.padding(vertical = 7.dp)) {
                Text("◇ ${hit.title}", fontSize = 13.sp, fontWeight = FontWeight.Medium)
                Text(hit.snippet.replace('⟦',' ').replace('⟧',' ').trim(), fontSize = 10.sp, color = MaterialTheme.colorScheme.onSurfaceVariant, maxLines = 2, overflow = TextOverflow.Ellipsis)
            }
        }
    }
}

@Composable
private fun PanePropertiesTool(vm: AppViewModel, noteId: Long) {
    var content by remember(noteId) { mutableStateOf<String?>(null) }
    var rows by remember(noteId) { mutableStateOf<List<Pair<String, String>>>(emptyList()) }
    var editing by remember(noteId) { mutableStateOf(false) }
    var status by remember(noteId) { mutableStateOf<String?>(null) }
    LaunchedEffect(noteId) {
        content = vm.getContentForComparison(noteId)
        rows = parseFrontmatterProperties(content.orEmpty())
    }
    Column(Modifier.fillMaxSize().padding(10.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text("Properties", Modifier.weight(1f), fontWeight = FontWeight.Bold, fontSize = 15.sp)
            TextButton(onClick = { editing = !editing }) { Text(if (editing) "Cancel" else "Edit") }
        }
        HorizontalDivider(Modifier.padding(bottom = 6.dp))
        status?.let { Text(it, fontSize = 11.sp, color = MaterialTheme.colorScheme.primary, modifier = Modifier.padding(bottom = 5.dp)) }
        if (editing) {
            LazyColumn(Modifier.weight(1f)) {
                items(rows.size) { index ->
                    val pair = rows[index]
                    Row(Modifier.fillMaxWidth().padding(vertical = 4.dp), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        OutlinedTextField(
                            value = pair.first,
                            onValueChange = { v -> rows = rows.toMutableList().also { it[index] = v to pair.second } },
                            label = { Text("Key") },
                            modifier = Modifier.weight(0.38f),
                            singleLine = true
                        )
                        OutlinedTextField(
                            value = pair.second,
                            onValueChange = { v -> rows = rows.toMutableList().also { it[index] = pair.first to v } },
                            label = { Text("Value") },
                            modifier = Modifier.weight(0.62f),
                            singleLine = true
                        )
                        Text("×", Modifier.clickable { rows = rows.toMutableList().also { it.removeAt(index) } }.padding(8.dp), fontSize = 16.sp)
                    }
                }
            }
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                TextButton(onClick = { rows = rows + ("property" to "") }) { Text("+ Property") }
                Spacer(Modifier.weight(1f))
                TextButton(onClick = {
                    status = "Saving…"
                }) { Text("Save") }
            }
            if (status == "Saving…") {
                LaunchedEffect(rows) {
                    val error = vm.updateMarkdownFrontmatter(noteId, rows)
                    status = error ?: "Saved"
                    if (error == null) {
                        content = vm.getContentForComparison(noteId)
                        rows = parseFrontmatterProperties(content.orEmpty())
                        editing = false
                    }
                }
            }
        } else {
            LazyColumn(Modifier.fillMaxSize()) {
                if (rows.isEmpty()) item { Text("No YAML/frontmatter properties", color = MaterialTheme.colorScheme.onSurfaceVariant) }
                items(rows) { pair ->
                    Column(Modifier.fillMaxWidth().padding(vertical = 6.dp)) {
                        Text(pair.first, fontSize = 11.sp, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary)
                        Text(pair.second.ifBlank { "—" }, fontSize = 13.sp)
                    }
                }
            }
        }
    }
}

private fun parseFrontmatterProperties(content: String): List<Pair<String, String>> {
    val lines = content.lineSequence().toList()
    if (lines.firstOrNull()?.trim() != "---") return emptyList()
    val end = lines.drop(1).indexOfFirst { it.trim() == "---" }
    if (end < 0) return emptyList()
    return lines.subList(1, end + 1).mapNotNull { line ->
        if (line.isBlank() || line.trimStart().startsWith("#")) return@mapNotNull null
        val split = line.indexOf(':')
        if (split <= 0) null else line.substring(0, split).trim().takeIf { it.isNotBlank() }?.let { key -> key to line.substring(split + 1).trim() }
    }
}

@Composable
private fun NamedWorkspacesDialog(
    raw: String,
    currentLayout: String,
    onDismiss: () -> Unit,
    onSaveRaw: (String) -> Unit,
    onLoad: (String) -> Unit
) {
    val layouts = remember(raw) { decodeNamedLayouts(raw) }
    var name by remember { mutableStateOf("") }
    var selected by remember { mutableStateOf<String?>(null) }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Named workspaces") },
        text = {
            Column {
                OutlinedTextField(value = name, onValueChange = { name = it }, label = { Text("Workspace name") }, singleLine = true, modifier = Modifier.fillMaxWidth())
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    TextButton(onClick = {
                        val n = name.trim()
                        if (n.isNotBlank()) onSaveRaw(encodeNamedLayouts(layouts.toMutableMap().apply { put(n, currentLayout) }))
                    }) { Text("Save current") }
                    TextButton(enabled = selected != null && name.isNotBlank(), onClick = {
                        val old = selected ?: return@TextButton
                        val n = name.trim()
                        val next = layouts.toMutableMap()
                        val value = next.remove(old) ?: return@TextButton
                        next[n] = value
                        onSaveRaw(encodeNamedLayouts(next))
                        selected = n
                    }) { Text("Rename selected") }
                }
                HorizontalDivider()
                LazyColumn(Modifier.height(300.dp)) {
                    items(layouts.entries.toList()) { entry ->
                        Surface(
                            color = if (selected == entry.key) MaterialTheme.colorScheme.primaryContainer else MaterialTheme.colorScheme.surface,
                            modifier = Modifier.fillMaxWidth().padding(vertical = 2.dp),
                            shape = RoundedCornerShape(7.dp),
                            border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant)
                        ) {
                            Row(Modifier.fillMaxWidth().clickable { selected = entry.key; name = entry.key }.padding(7.dp), verticalAlignment = Alignment.CenterVertically) {
                                Text(entry.key, Modifier.weight(1f), fontWeight = FontWeight.Medium, maxLines = 1, overflow = TextOverflow.Ellipsis)
                                TextButton(onClick = { onLoad(entry.value) }) { Text("Load") }
                                TextButton(onClick = {
                                    val next = layouts.toMutableMap()
                                    var copy = "${entry.key} copy"
                                    var i = 2
                                    while (copy in next) { copy = "${entry.key} copy $i"; i++ }
                                    next[copy] = entry.value
                                    onSaveRaw(encodeNamedLayouts(next))
                                }) { Text("Copy") }
                                TextButton(onClick = { onSaveRaw(encodeNamedLayouts(layouts.toMutableMap().apply { remove(entry.key) })) }) { Text("Delete") }
                            }
                        }
                    }
                }
            }
        },
        confirmButton = { TextButton(onClick = onDismiss) { Text("Done") } }
    )
}

@Composable
private fun WorkspaceBookmarksDialog(
    raw: String,
    activeTab: PaneTab?,
    onDismiss: () -> Unit,
    onSaveRaw: (String) -> Unit,
    onOpen: (PaneTab) -> Unit
) {
    val bookmarks = remember(raw) { decodeBookmarks(raw) }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Workspace bookmarks") },
        text = {
            Column {
                activeTab?.let { tab ->
                    TextButton(onClick = { onSaveRaw(addBookmarkRaw(raw, WorkspaceBookmarkEntry(newBookmarkId(), tab.label, tab))) }) {
                        Text("★ Bookmark current tab")
                    }
                }
                HorizontalDivider()
                LazyColumn(Modifier.height(320.dp)) {
                    if (bookmarks.isEmpty()) item { Text("No Workspace bookmarks yet.", Modifier.padding(10.dp), color = MaterialTheme.colorScheme.onSurfaceVariant) }
                    items(bookmarks) { bookmark ->
                        Row(Modifier.fillMaxWidth().padding(vertical = 3.dp), verticalAlignment = Alignment.CenterVertically) {
                            Text(bookmark.label, Modifier.weight(1f).clickable { onOpen(bookmark.tab) }.padding(7.dp), maxLines = 2, overflow = TextOverflow.Ellipsis)
                            Text("×", Modifier.clickable { onSaveRaw(encodeBookmarks(bookmarks.filterNot { it.id == bookmark.id })) }.padding(8.dp), fontSize = 16.sp)
                        }
                    }
                }
            }
        },
        confirmButton = { TextButton(onClick = onDismiss) { Text("Done") } }
    )
}

@Composable
private fun PaneVaultRail(
    notes: List<com.tebogo.markvault.data.NoteMeta>,
    paneBounds: Map<Int, Rect>,
    rootProvider: () -> PaneNode,
    onUpdateRoot: (PaneNode) -> Unit,
    onFocusPane: (Int) -> Unit,
    activePaneId: Int
) {
    var query by remember { mutableStateOf("") }
    val shown = remember(notes, query) {
        val q = query.trim().lowercase()
        (if (q.isBlank()) notes else notes.filter { it.title.lowercase().contains(q) || it.relPath.lowercase().contains(q) }).take(400)
    }
    Surface(Modifier.width(300.dp).fillMaxHeight(), tonalElevation = 2.dp, border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant)) {
        Column(Modifier.fillMaxSize().padding(7.dp)) {
            Text("Vault · drag into a pane", fontWeight = FontWeight.Bold, fontSize = 13.sp)
            OutlinedTextField(query, { query = it }, label = { Text("Filter files") }, singleLine = true, modifier = Modifier.fillMaxWidth().padding(vertical = 5.dp))
            LazyColumn(Modifier.fillMaxSize()) {
                items(shown) { note ->
                    var rowBounds by remember(note.id) { mutableStateOf<Rect?>(null) }
                    var targetId by remember(note.id) { mutableStateOf<Int?>(null) }
                    val tab = PaneTab("doc-${note.id}", note.title.ifBlank { note.name }, "document", note.id, note.fileType)
                    Surface(
                        color = if (targetId != null) MaterialTheme.colorScheme.primaryContainer else MaterialTheme.colorScheme.surface,
                        shape = RoundedCornerShape(6.dp),
                        modifier = Modifier.fillMaxWidth().padding(vertical = 2.dp)
                            .onGloballyPositioned { rowBounds = it.boundsInRoot() }
                            .pointerInput(note.id, paneBounds.size) {
                                detectDragGesturesAfterLongPress(
                                    onDragStart = { targetId = null },
                                    onDragCancel = { targetId = null },
                                    onDragEnd = {
                                        val target = targetId
                                        if (target != null && findLeaf(rootProvider(), target)?.locked != true) {
                                            onUpdateRoot(addTab(rootProvider(), target, tab)); onFocusPane(target)
                                        }
                                        targetId = null
                                    },
                                    onDrag = { change, _ ->
                                        change.consume()
                                        val b = rowBounds
                                        val point = if (b != null) Offset(b.left + change.position.x, b.top + change.position.y) else null
                                        targetId = point?.let { p -> paneBounds.entries.firstOrNull { (_, rect) -> rect.contains(p) }?.key }
                                    }
                                )
                            }
                            .clickable {
                                val opened = openTabByPanePolicy(rootProvider(), activePaneId, tab)
                                onUpdateRoot(opened.first); onFocusPane(opened.second)
                            }
                    ) {
                        Column(Modifier.padding(horizontal = 7.dp, vertical = 6.dp)) {
                            Text(note.title.ifBlank { note.name }, fontSize = 12.sp, fontWeight = FontWeight.Medium, maxLines = 1, overflow = TextOverflow.Ellipsis)
                            Text(note.relPath, fontSize = 9.sp, color = MaterialTheme.colorScheme.onSurfaceVariant, maxLines = 1, overflow = TextOverflow.Ellipsis)
                        }
                    }
                }
            }
        }
    }
}

private fun decodeNamedLayouts(raw: String): LinkedHashMap<String, String> = runCatching {
    val obj = JSONObject(raw.ifBlank { "{}" })
    linkedMapOf<String, String>().apply { obj.keys().forEach { key -> put(key, obj.optString(key)) } }
}.getOrDefault(linkedMapOf())

private fun encodeNamedLayouts(layouts: Map<String, String>): String = JSONObject().apply { layouts.forEach { (k, v) -> put(k, v) } }.toString()
private fun newBookmarkId(): String = "b-${System.currentTimeMillis()}-${(0..9999).random()}"
private fun decodeBookmarks(raw: String): List<WorkspaceBookmarkEntry> = runCatching {
    val arr = JSONArray(raw.ifBlank { "[]" })
    buildList {
        for (i in 0 until arr.length()) {
            val o = arr.getJSONObject(i)
            val t = o.getJSONObject("tab")
            add(WorkspaceBookmarkEntry(o.getString("id"), o.optString("label", "Bookmark"), jsonToPaneTab(t)))
        }
    }
}.getOrDefault(emptyList())
private fun encodeBookmarks(items: List<WorkspaceBookmarkEntry>): String = JSONArray().apply {
    items.forEach { b -> put(JSONObject().apply { put("id", b.id); put("label", b.label); put("tab", paneTabToJson(b.tab)) }) }
}.toString()
private fun addBookmarkRaw(raw: String, item: WorkspaceBookmarkEntry): String {
    val current = decodeBookmarks(raw)
    val withoutDuplicate = current.filterNot { it.tab.kind == item.tab.kind && it.tab.noteId == item.tab.noteId && it.tab.anchor == item.tab.anchor && it.label == item.label }
    return encodeBookmarks((withoutDuplicate + item).takeLast(100))
}

@Composable
private fun PaneTreeDivider(vertical: Boolean, onDrag: (Float) -> Unit) {
    val line = MaterialTheme.colorScheme.outlineVariant
    if (vertical) {
        Box(
            Modifier.fillMaxHeight().width(8.dp).background(MaterialTheme.colorScheme.surface)
                .pointerInput(Unit) { detectHorizontalDragGestures { change, drag -> change.consume(); onDrag(drag) } },
            contentAlignment = Alignment.Center
        ) { Box(Modifier.fillMaxHeight().width(1.dp).background(line)) }
    } else {
        Box(
            Modifier.fillMaxWidth().height(8.dp).background(MaterialTheme.colorScheme.surface)
                .pointerInput(Unit) { detectVerticalDragGestures { change, drag -> change.consume(); onDrag(drag) } },
            contentAlignment = Alignment.Center
        ) { Box(Modifier.fillMaxWidth().height(1.dp).background(line)) }
    }
}

@Composable
private fun PaneToolbarButton(label: String, onClick: () -> Unit) {
    Surface(shape = RoundedCornerShape(7.dp), border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant), color = MaterialTheme.colorScheme.surfaceVariant) {
        Text(label, Modifier.clickable(onClick = onClick).padding(horizontal = 8.dp, vertical = 6.dp), fontSize = 11.sp, fontWeight = FontWeight.SemiBold)
    }
}

private fun documentPaneTab(tab: TabInfo) = PaneTab("doc-${tab.id}", tab.title, "document", tab.id, tab.fileType)
private fun paneTabToJson(t: PaneTab): JSONObject = JSONObject().apply {
    put("key", t.key); put("label", t.label); put("kind", t.kind); put("noteId", t.noteId); put("fileType", t.fileType)
    put("scroll", t.scrollPosition); put("anchor", t.anchor)
}
private fun jsonToPaneTab(t: JSONObject): PaneTab = PaneTab(
    t.getString("key"), t.optString("label", "Untitled"), t.getString("kind"), t.optLong("noteId", 0L),
    t.optString("fileType", "md"), t.optInt("scroll", 0), t.optString("anchor", "")
)
private fun duplicatePaneTab(root: PaneNode, paneId: Int, tab: PaneTab): PaneNode {
    val duplicate = tab.copy(key = "${tab.key}-dup-${System.nanoTime()}", label = "${tab.label} · copy")
    return updateLeaf(root, paneId) { leaf -> leaf.copy(tabs = leaf.tabs + duplicate, activeKey = duplicate.key) }
}
private fun updateTabScroll(root: PaneNode, paneId: Int, key: String, position: Int): PaneNode = updateLeaf(root, paneId) { leaf ->
    leaf.copy(tabs = leaf.tabs.map { if (it.key == key) it.copy(scrollPosition = position.coerceAtLeast(0)) else it })
}
private fun reorderPaneTab(root: PaneNode, paneId: Int, key: String, delta: Int): PaneNode = updateLeaf(root, paneId) { leaf ->
    val from = leaf.tabs.indexOfFirst { it.key == key }
    if (from < 0) return@updateLeaf leaf
    val to = (from + delta).coerceIn(0, leaf.tabs.lastIndex)
    if (from == to) return@updateLeaf leaf
    val list = leaf.tabs.toMutableList()
    val item = list.removeAt(from); list.add(to, item)
    leaf.copy(tabs = list)
}
private fun moveTabToPane(root: PaneNode, fromPaneId: Int, toPaneId: Int, tab: PaneTab): PaneNode {
    if (fromPaneId == toPaneId) return root
    val target = findLeaf(root, toPaneId) ?: return root
    if (target.locked) return root
    var next = updateLeaf(root, toPaneId) { l ->
        val existing = l.tabs.firstOrNull { it.key == tab.key }
        if (existing != null) l.copy(activeKey = existing.key)
        else l.copy(tabs = l.tabs + tab, activeKey = tab.key, backStack = (l.backStack + l.activeKey).takeLast(40), forwardStack = emptyList())
    }
    next = updateLeaf(next, fromPaneId) { l ->
        if (l.tabs.size <= 1) l else {
            val remaining = l.tabs.filterNot { it.key == tab.key }
            l.copy(
                tabs = remaining,
                activeKey = if (l.activeKey == tab.key) remaining.first().key else l.activeKey,
                backStack = l.backStack.filter { key -> remaining.any { it.key == key } },
                forwardStack = l.forwardStack.filter { key -> remaining.any { it.key == key } }
            )
        }
    }
    return next
}
private fun splitLeafWithTab(root: PaneNode, paneId: Int, tab: PaneTab, vertical: Boolean = true): Pair<PaneNode, Int> {
    if (leafCount(root) >= MAX_WORKSPACE_PANES) return root to paneId
    val source = findLeaf(root, paneId) ?: return root to paneId
    val newId = nextPaneId(root)
    val newLeaf = PaneLeaf(newId, listOf(tab), tab.key)
    fun replace(node: PaneNode): PaneNode = when (node) {
        is PaneLeaf -> if (node.paneId == paneId) PaneSplit(nextSplitId(root), vertical, 0.5f, node, newLeaf) else node
        is PaneSplit -> node.copy(first = replace(node.first), second = replace(node.second))
    }
    return replace(root) to newId
}
private fun openTabByPanePolicy(root: PaneNode, paneId: Int, tab: PaneTab): Pair<PaneNode, Int> {
    val source = findLeaf(root, paneId) ?: return root to paneId
    val all = leaves(root)
    val sourceIndex = all.indexOfFirst { it.paneId == paneId }.coerceAtLeast(0)
    if (source.locked || source.openMode == "adjacent") {
        val target = (1 until all.size).map { all[(sourceIndex + it) % all.size] }.firstOrNull { !it.locked }
        if (target != null) return addTab(root, target.paneId, tab) to target.paneId
        return if (leafCount(root) < MAX_WORKSPACE_PANES) splitLeafWithTab(root, paneId, tab, true) else root to paneId
    }
    if (source.openMode == "split") {
        return if (leafCount(root) < MAX_WORKSPACE_PANES) splitLeafWithTab(root, paneId, tab, true) else addTab(root, paneId, tab) to paneId
    }
    return addTab(root, paneId, tab) to paneId
}
private fun seedPaneTree(tabs: List<TabInfo>, activeId: Long?): PaneNode {
    val paneTabs = tabs.map(::documentPaneTab).ifEmpty { listOf(PaneTab("tool-search", "Search", "search")) }
    val activeKey = paneTabs.firstOrNull { it.noteId == activeId }?.key ?: paneTabs.first().key
    return PaneLeaf(1, paneTabs, activeKey)
}
private fun firstLeaf(node: PaneNode): PaneLeaf = when (node) { is PaneLeaf -> node; is PaneSplit -> firstLeaf(node.first) }
private fun leaves(node: PaneNode): List<PaneLeaf> = when (node) { is PaneLeaf -> listOf(node); is PaneSplit -> leaves(node.first) + leaves(node.second) }
private fun leafCount(node: PaneNode) = leaves(node).size
private fun findLeaf(node: PaneNode, id: Int): PaneLeaf? = when (node) { is PaneLeaf -> node.takeIf { it.paneId == id }; is PaneSplit -> findLeaf(node.first, id) ?: findLeaf(node.second, id) }
private fun nextPaneId(node: PaneNode) = (leaves(node).maxOfOrNull { it.paneId } ?: 0) + 1
private fun nextSplitId(node: PaneNode): Int {
    fun collect(n: PaneNode): Int = when (n) { is PaneLeaf -> 0; is PaneSplit -> maxOf(n.splitId, collect(n.first), collect(n.second)) }
    return collect(node) + 1
}
private fun updateLeaf(node: PaneNode, id: Int, f: (PaneLeaf) -> PaneLeaf): PaneNode = when (node) {
    is PaneLeaf -> if (node.paneId == id) f(node) else node
    is PaneSplit -> node.copy(first = updateLeaf(node.first, id, f), second = updateLeaf(node.second, id, f))
}
private fun updateSplitRatio(node: PaneNode, splitId: Int, ratio: Float): PaneNode = when (node) {
    is PaneLeaf -> node
    is PaneSplit -> if (node.splitId == splitId) node.copy(ratio = ratio) else node.copy(first = updateSplitRatio(node.first, splitId, ratio), second = updateSplitRatio(node.second, splitId, ratio))
}
private fun splitLeaf(root: PaneNode, paneId: Int, vertical: Boolean): PaneNode {
    val source = findLeaf(root, paneId) ?: return root
    if (leafCount(root) >= MAX_WORKSPACE_PANES) return root
    val active = source.tabs.firstOrNull { it.key == source.activeKey } ?: source.tabs.first()
    val second = PaneLeaf(nextPaneId(root), listOf(active), active.key)
    fun replace(node: PaneNode): PaneNode = when (node) {
        is PaneLeaf -> if (node.paneId == paneId) PaneSplit(nextSplitId(root), vertical, 0.5f, node, second) else node
        is PaneSplit -> node.copy(first = replace(node.first), second = replace(node.second))
    }
    return replace(root)
}
private fun addTab(root: PaneNode, paneId: Int, tab: PaneTab): PaneNode = updateLeaf(root, paneId) { leaf ->
    val tabs = if (leaf.tabs.any { it.key == tab.key }) leaf.tabs else leaf.tabs + tab
    if (leaf.activeKey == tab.key) leaf.copy(tabs = tabs)
    else leaf.copy(
        tabs = tabs,
        activeKey = tab.key,
        backStack = (leaf.backStack + leaf.activeKey).takeLast(40),
        forwardStack = emptyList()
    )
}

private fun activatePaneTab(root: PaneNode, paneId: Int, key: String): PaneNode = updateLeaf(root, paneId) { leaf ->
    if (key == leaf.activeKey || leaf.tabs.none { it.key == key }) leaf
    else leaf.copy(
        activeKey = key,
        backStack = (leaf.backStack + leaf.activeKey).takeLast(40),
        forwardStack = emptyList()
    )
}

private fun paneBack(root: PaneNode, paneId: Int): PaneNode = updateLeaf(root, paneId) { leaf ->
    val target = leaf.backStack.lastOrNull { key -> leaf.tabs.any { it.key == key } } ?: return@updateLeaf leaf
    leaf.copy(
        activeKey = target,
        backStack = leaf.backStack.dropLastWhile { it != target }.dropLast(1),
        forwardStack = (leaf.forwardStack + leaf.activeKey).takeLast(40)
    )
}

private fun paneForward(root: PaneNode, paneId: Int): PaneNode = updateLeaf(root, paneId) { leaf ->
    val target = leaf.forwardStack.lastOrNull { key -> leaf.tabs.any { it.key == key } } ?: return@updateLeaf leaf
    leaf.copy(
        activeKey = target,
        backStack = (leaf.backStack + leaf.activeKey).takeLast(40),
        forwardStack = leaf.forwardStack.dropLastWhile { it != target }.dropLast(1)
    )
}

private fun cyclePaneTab(root: PaneNode, paneId: Int, backwards: Boolean): PaneNode = updateLeaf(root, paneId) { leaf ->
    if (leaf.tabs.size < 2) return@updateLeaf leaf
    val current = leaf.tabs.indexOfFirst { it.key == leaf.activeKey }.coerceAtLeast(0)
    val next = if (backwards) (current - 1 + leaf.tabs.size) % leaf.tabs.size else (current + 1) % leaf.tabs.size
    val key = leaf.tabs[next].key
    leaf.copy(
        activeKey = key,
        backStack = (leaf.backStack + leaf.activeKey).takeLast(40),
        forwardStack = emptyList()
    )
}

private fun closeActivePaneTab(root: PaneNode, paneId: Int): PaneNode = updateLeaf(root, paneId) { leaf ->
    if (leaf.tabs.size <= 1) return@updateLeaf leaf
    val currentIndex = leaf.tabs.indexOfFirst { it.key == leaf.activeKey }.coerceAtLeast(0)
    val remaining = leaf.tabs.filterNot { it.key == leaf.activeKey }
    val next = remaining[currentIndex.coerceAtMost(remaining.lastIndex)].key
    leaf.copy(
        tabs = remaining,
        activeKey = next,
        backStack = leaf.backStack.filter { key -> remaining.any { it.key == key } },
        forwardStack = leaf.forwardStack.filter { key -> remaining.any { it.key == key } }
    )
}
private fun removeLeaf(node: PaneNode, paneId: Int): PaneNode? = when (node) {
    is PaneLeaf -> if (node.paneId == paneId) null else node
    is PaneSplit -> {
        val a = removeLeaf(node.first, paneId)
        val b = removeLeaf(node.second, paneId)
        when { a == null -> b; b == null -> a; else -> node.copy(first = a, second = b) }
    }
}
private fun dockTabAtEdge(root: PaneNode, paneId: Int, tab: PaneTab, edge: String): PaneNode {
    val source = findLeaf(root, paneId) ?: return root
    if (source.locked || leafCount(root) >= MAX_WORKSPACE_PANES) return root
    val newId = nextPaneId(root)
    val newLeaf = PaneLeaf(newId, listOf(tab), tab.key)
    val sourceAfterMove = if (source.tabs.size > 1) {
        val remaining = source.tabs.filterNot { it.key == tab.key }
        source.copy(
            tabs = remaining,
            activeKey = if (source.activeKey == tab.key) remaining.first().key else source.activeKey,
            backStack = source.backStack.filter { key -> remaining.any { it.key == key } },
            forwardStack = source.forwardStack.filter { key -> remaining.any { it.key == key } }
        )
    } else source
    val vertical = edge == "left" || edge == "right"
    val newFirst = edge == "left" || edge == "top"
    fun replace(node: PaneNode): PaneNode = when (node) {
        is PaneLeaf -> if (node.paneId == paneId) {
            PaneSplit(
                nextSplitId(root),
                vertical = vertical,
                ratio = 0.5f,
                first = if (newFirst) newLeaf else sourceAfterMove,
                second = if (newFirst) sourceAfterMove else newLeaf
            )
        } else node
        is PaneSplit -> node.copy(first = replace(node.first), second = replace(node.second))
    }
    return replace(root)
}

private fun moveTabToNextPane(root: PaneNode, fromPaneId: Int, tab: PaneTab): PaneNode {
    val all = leaves(root)
    val fromIndex = all.indexOfFirst { it.paneId == fromPaneId }
    if (fromIndex < 0 || all.size < 2) return root
    val target = all[(fromIndex + 1) % all.size]
    var next = updateLeaf(root, target.paneId) { l -> l.copy(tabs = (l.tabs + tab).distinctBy { it.key }, activeKey = tab.key) }
    next = updateLeaf(next, fromPaneId) { l ->
        val remaining = l.tabs.filterNot { it.key == tab.key }
        if (remaining.isEmpty()) l else l.copy(tabs = remaining, activeKey = if (l.activeKey == tab.key) remaining.first().key else l.activeKey)
    }
    return next
}

private fun encodePaneTree(node: PaneNode): String = nodeToJson(node).toString()
private fun nodeToJson(node: PaneNode): JSONObject = when (node) {
    is PaneLeaf -> JSONObject().apply {
        put("type", "leaf"); put("paneId", node.paneId); put("active", node.activeKey); put("locked", node.locked); put("openMode", node.openMode)
        put("back", JSONArray().apply { node.backStack.forEach { put(it) } })
        put("forward", JSONArray().apply { node.forwardStack.forEach { put(it) } })
        put("tabs", JSONArray().apply { node.tabs.forEach { t -> put(paneTabToJson(t)) } })
    }
    is PaneSplit -> JSONObject().apply { put("type", "split"); put("splitId", node.splitId); put("vertical", node.vertical); put("ratio", node.ratio.toDouble()); put("first", nodeToJson(node.first)); put("second", nodeToJson(node.second)) }
}
private fun decodePaneTree(raw: String): PaneNode? = runCatching { jsonToNode(JSONObject(raw)) }.getOrNull()
private fun jsonToNode(o: JSONObject): PaneNode {
    return if (o.getString("type") == "leaf") {
        val arr = o.getJSONArray("tabs")
        val tabs = buildList {
            for (i in 0 until arr.length()) {
                val t = arr.getJSONObject(i)
                add(jsonToPaneTab(t))
            }
        }.ifEmpty { listOf(PaneTab("tool-search", "Search", "search")) }
        val validKeys = tabs.map { it.key }.toSet()
        fun stringArray(name: String): List<String> {
            val history = o.optJSONArray(name) ?: return emptyList()
            return buildList { for (i in 0 until history.length()) history.optString(i).takeIf { it in validKeys }?.let(::add) }.takeLast(40)
        }
        PaneLeaf(
            o.getInt("paneId"),
            tabs,
            o.optString("active", tabs.first().key).takeIf { it in validKeys } ?: tabs.first().key,
            o.optBoolean("locked", false),
            stringArray("back"),
            stringArray("forward"),
            o.optString("openMode", "current").takeIf { it in setOf("current", "adjacent", "split") } ?: "current"
        )
    } else {
        PaneSplit(o.getInt("splitId"), o.optBoolean("vertical", true), o.optDouble("ratio", 0.5).toFloat().coerceIn(0.2f, 0.8f), jsonToNode(o.getJSONObject("first")), jsonToNode(o.getJSONObject("second")))
    }
}
