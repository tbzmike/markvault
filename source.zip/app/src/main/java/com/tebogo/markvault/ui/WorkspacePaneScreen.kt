package com.tebogo.markvault.ui

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectDragGesturesAfterLongPress
import androidx.compose.foundation.gestures.detectHorizontalDragGestures
import androidx.compose.foundation.gestures.detectVerticalDragGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.ui.layout.onSizeChanged
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.focusable
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.MoreVert
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.VerticalDivider
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.input.key.KeyEventType
import androidx.compose.ui.input.key.onPreviewKeyEvent
import androidx.compose.ui.input.key.type
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.delay
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.navigation.NavHostController
import com.tebogo.markvault.AppViewModel
import com.tebogo.markvault.TabInfo
import org.json.JSONArray
import org.json.JSONObject

private const val MAX_WORKSPACE_PANES = 4

private data class PaneTab(
    val key: String,
    val label: String,
    val kind: String,
    val noteId: Long = 0L,
    val fileType: String = "md"
)

private sealed interface PaneNode
private data class PaneLeaf(
    val paneId: Int,
    val tabs: List<PaneTab>,
    val activeKey: String,
    val locked: Boolean = false,
    val backStack: List<String> = emptyList(),
    val forwardStack: List<String> = emptyList()
) : PaneNode
private data class PaneSplit(
    val splitId: Int,
    val vertical: Boolean,
    val ratio: Float = 0.5f,
    val first: PaneNode,
    val second: PaneNode
) : PaneNode

/**
 * v5.4.330cc — Advanced Obsidian-style multi-pane Workspace.
 *
 * This is additive: it reuses the proven document split renderers and existing
 * Search/Graph/Media/AI screens rather than replacing the normal readers.
 */
@Composable
fun WorkspacePaneScreen(vm: AppViewModel, nav: NavHostController) {
    val globalTabs by vm.tabs.collectAsStateWithLifecycle()
    val activeGlobal by vm.activeTab.collectAsStateWithLifecycle()
    val savedA by vm.workspacePaneLayoutA.collectAsStateWithLifecycle()
    val savedB by vm.workspacePaneLayoutB.collectAsStateWithLifecycle()
    val savedC by vm.workspacePaneLayoutC.collectAsStateWithLifecycle()
    val liveSaved by vm.workspacePaneCurrent.collectAsStateWithLifecycle()

    val initial = remember(globalTabs, activeGlobal) { seedPaneTree(globalTabs, activeGlobal) }
    var root by remember { mutableStateOf<PaneNode>(initial) }
    var activePaneId by remember { mutableStateOf(firstLeaf(root).paneId) }
    var layoutsMenu by remember { mutableStateOf(false) }
    var liveLayoutLoaded by remember { mutableStateOf(false) }
    val workspaceFocus = remember { FocusRequester() }

    // Restore the last unsaved live pane arrangement only after DataStore has actually emitted.
    LaunchedEffect(liveSaved) {
        if (!liveLayoutLoaded && liveSaved != "__loading__") {
            decodePaneTree(liveSaved).let { restored ->
                if (restored != null) {
                    root = restored
                    activePaneId = firstLeaf(restored).paneId
                }
            }
            liveLayoutLoaded = true
        }
    }

    // Debounced live-session persistence. Layout A/B/C remain explicit snapshots.
    LaunchedEffect(root, liveLayoutLoaded) {
        if (liveLayoutLoaded) {
            delay(350)
            vm.setWorkspacePaneCurrent(encodePaneTree(root))
        }
    }

    LaunchedEffect(Unit) { workspaceFocus.requestFocus() }

    LaunchedEffect(globalTabs) {
        if (leafCount(root) == 1 && globalTabs.isNotEmpty()) {
            val leaf = firstLeaf(root)
            val currentDocs = leaf.tabs.filter { it.kind == "document" }.map { it.noteId }.toSet()
            val missing = globalTabs.filterNot { it.id in currentDocs }
            if (missing.isNotEmpty()) {
                root = updateLeaf(root, leaf.paneId) { l ->
                    l.copy(tabs = l.tabs + missing.map(::documentPaneTab))
                }
            }
        }
    }

    Column(
        Modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
            .focusRequester(workspaceFocus)
            .focusable()
            .onPreviewKeyEvent { event ->
                if (event.type != KeyEventType.KeyDown) return@onPreviewKeyEvent false
                val native = event.nativeKeyEvent
                when {
                    native.isAltPressed && native.keyCode == android.view.KeyEvent.KEYCODE_DPAD_LEFT -> {
                        val changed = paneBack(root, activePaneId)
                        if (changed != root) root = changed
                        true
                    }
                    native.isAltPressed && native.keyCode == android.view.KeyEvent.KEYCODE_DPAD_RIGHT -> {
                        val changed = paneForward(root, activePaneId)
                        if (changed != root) root = changed
                        true
                    }
                    native.isCtrlPressed && native.keyCode == android.view.KeyEvent.KEYCODE_TAB -> {
                        root = cyclePaneTab(root, activePaneId, backwards = native.isShiftPressed)
                        true
                    }
                    native.isCtrlPressed && native.keyCode == android.view.KeyEvent.KEYCODE_W -> {
                        root = closeActivePaneTab(root, activePaneId)
                        true
                    }
                    native.isCtrlPressed && native.keyCode == android.view.KeyEvent.KEYCODE_BACKSLASH -> {
                        if (leafCount(root) < MAX_WORKSPACE_PANES) {
                            root = splitLeaf(root, activePaneId, vertical = !native.isShiftPressed)
                        }
                        true
                    }
                    else -> false
                }
            }
    ) {
        Surface(
            tonalElevation = 2.dp,
            shadowElevation = 2.dp,
            color = MaterialTheme.colorScheme.surface,
            border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant)
        ) {
            Row(
                Modifier.fillMaxWidth().height(44.dp).padding(horizontal = 8.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                Text("Workspace panes", fontSize = 14.sp, fontWeight = FontWeight.Bold)
                Text("${leafCount(root)}/$MAX_WORKSPACE_PANES", fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                Spacer(Modifier.weight(1f))
                val activeLeaf = findLeaf(root, activePaneId)
                PaneToolbarButton("←") { root = paneBack(root, activePaneId) }
                PaneToolbarButton("→") { root = paneForward(root, activePaneId) }
                PaneToolbarButton("Split ↔") {
                    if (leafCount(root) < MAX_WORKSPACE_PANES) {
                        root = splitLeaf(root, activePaneId, vertical = true)
                    }
                }
                PaneToolbarButton("Split ↕") {
                    if (leafCount(root) < MAX_WORKSPACE_PANES) {
                        root = splitLeaf(root, activePaneId, vertical = false)
                    }
                }
                PaneToolbarButton(if (findLeaf(root, activePaneId)?.locked == true) "🔒" else "🔓") {
                    root = updateLeaf(root, activePaneId) { it.copy(locked = !it.locked) }
                }
                Box {
                    PaneToolbarButton("Layouts ▾") { layoutsMenu = true }
                    DropdownMenu(expanded = layoutsMenu, onDismissRequest = { layoutsMenu = false }) {
                        DropdownMenuItem(text = { Text("Save layout A") }, onClick = { vm.setWorkspacePaneLayoutA(encodePaneTree(root)); layoutsMenu = false })
                        DropdownMenuItem(text = { Text("Load layout A") }, enabled = savedA.isNotBlank(), onClick = { decodePaneTree(savedA)?.let { root = it; activePaneId = firstLeaf(it).paneId }; layoutsMenu = false })
                        HorizontalDivider()
                        DropdownMenuItem(text = { Text("Save layout B") }, onClick = { vm.setWorkspacePaneLayoutB(encodePaneTree(root)); layoutsMenu = false })
                        DropdownMenuItem(text = { Text("Load layout B") }, enabled = savedB.isNotBlank(), onClick = { decodePaneTree(savedB)?.let { root = it; activePaneId = firstLeaf(it).paneId }; layoutsMenu = false })
                        HorizontalDivider()
                        DropdownMenuItem(text = { Text("Save layout C") }, onClick = { vm.setWorkspacePaneLayoutC(encodePaneTree(root)); layoutsMenu = false })
                        DropdownMenuItem(text = { Text("Load layout C") }, enabled = savedC.isNotBlank(), onClick = { decodePaneTree(savedC)?.let { root = it; activePaneId = firstLeaf(it).paneId }; layoutsMenu = false })
                    }
                }
                PaneToolbarButton("Reset") {
                    root = seedPaneTree(globalTabs, activeGlobal)
                    activePaneId = firstLeaf(root).paneId
                }
            }
        }

        PaneNodeView(
            node = root,
            vm = vm,
            nav = nav,
            activePaneId = activePaneId,
            onFocusPane = { activePaneId = it },
            onUpdateRoot = { root = it },
            rootProvider = { root },
            globalTabs = globalTabs
        )
    }
}

@Composable
private fun PaneNodeView(
    node: PaneNode,
    vm: AppViewModel,
    nav: NavHostController,
    activePaneId: Int,
    onFocusPane: (Int) -> Unit,
    onUpdateRoot: (PaneNode) -> Unit,
    rootProvider: () -> PaneNode,
    globalTabs: List<TabInfo>,
    modifier: Modifier = Modifier
) {
    when (node) {
        is PaneLeaf -> PaneLeafView(node, vm, nav, activePaneId == node.paneId, onFocusPane, onUpdateRoot, rootProvider, globalTabs, modifier)
        is PaneSplit -> PaneSplitView(node, vm, nav, activePaneId, onFocusPane, onUpdateRoot, rootProvider, globalTabs, modifier)
    }
}

@Composable
private fun PaneSplitView(
    node: PaneSplit,
    vm: AppViewModel,
    nav: NavHostController,
    activePaneId: Int,
    onFocusPane: (Int) -> Unit,
    onUpdateRoot: (PaneNode) -> Unit,
    rootProvider: () -> PaneNode,
    globalTabs: List<TabInfo>,
    modifier: Modifier
) {
    var extentPx by remember { mutableStateOf(1) }
    if (node.vertical) {
        Row(modifier.fillMaxSize().onSizeChanged { extentPx = it.width.coerceAtLeast(1) }) {
            PaneNodeView(node.first, vm, nav, activePaneId, onFocusPane, onUpdateRoot, rootProvider, globalTabs, Modifier.weight(node.ratio).fillMaxHeight())
            PaneTreeDivider(vertical = true) { delta ->
                val next = (node.ratio + delta / extentPx.toFloat()).coerceIn(0.2f, 0.8f)
                onUpdateRoot(updateSplitRatio(rootProvider(), node.splitId, next))
            }
            PaneNodeView(node.second, vm, nav, activePaneId, onFocusPane, onUpdateRoot, rootProvider, globalTabs, Modifier.weight(1f - node.ratio).fillMaxHeight())
        }
    } else {
        Column(modifier.fillMaxSize().onSizeChanged { extentPx = it.height.coerceAtLeast(1) }) {
            PaneNodeView(node.first, vm, nav, activePaneId, onFocusPane, onUpdateRoot, rootProvider, globalTabs, Modifier.weight(node.ratio).fillMaxWidth())
            PaneTreeDivider(vertical = false) { delta ->
                val next = (node.ratio + delta / extentPx.toFloat()).coerceIn(0.2f, 0.8f)
                onUpdateRoot(updateSplitRatio(rootProvider(), node.splitId, next))
            }
            PaneNodeView(node.second, vm, nav, activePaneId, onFocusPane, onUpdateRoot, rootProvider, globalTabs, Modifier.weight(1f - node.ratio).fillMaxWidth())
        }
    }
}

@Composable
private fun PaneLeafView(
    leaf: PaneLeaf,
    vm: AppViewModel,
    nav: NavHostController,
    focused: Boolean,
    onFocusPane: (Int) -> Unit,
    onUpdateRoot: (PaneNode) -> Unit,
    rootProvider: () -> PaneNode,
    globalTabs: List<TabInfo>,
    modifier: Modifier
) {
    var addMenu by remember { mutableStateOf(false) }
    var dockPreview by remember { mutableStateOf<String?>(null) }
    val active = leaf.tabs.firstOrNull { it.key == leaf.activeKey } ?: leaf.tabs.firstOrNull()
    val contextDocument = active?.takeIf { it.kind == "document" }
        ?: leaf.tabs.lastOrNull { it.kind == "document" }

    Surface(
        modifier = modifier.padding(2.dp).clickable { onFocusPane(leaf.paneId) },
        border = BorderStroke(if (focused) 2.dp else 1.dp, if (focused) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.outlineVariant),
        color = MaterialTheme.colorScheme.surface,
        shape = RoundedCornerShape(6.dp)
    ) {
        Column(Modifier.fillMaxSize()) {
            Row(
                Modifier.fillMaxWidth().height(38.dp).padding(start = 5.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(Modifier.weight(1f).horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                    leaf.tabs.forEach { tab ->
                        val selected = tab.key == active?.key
                        Surface(
                            color = if (selected) MaterialTheme.colorScheme.primaryContainer else MaterialTheme.colorScheme.surfaceVariant,
                            border = BorderStroke(1.dp, if (selected) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.outlineVariant),
                            shape = RoundedCornerShape(7.dp),
                            modifier = Modifier.height(30.dp).widthIn(min = 86.dp, max = 180.dp)
                                .pointerInput(tab.key, leaf.paneId, leaf.locked) {
                                    var dragX = 0f
                                    var dragY = 0f
                                    detectDragGesturesAfterLongPress(
                                        onDragStart = { dragX = 0f; dragY = 0f; dockPreview = null },
                                        onDragCancel = { dragX = 0f; dragY = 0f; dockPreview = null },
                                        onDragEnd = {
                                            val edge = dockPreview
                                            if (edge != null && !leaf.locked && leafCount(rootProvider()) < MAX_WORKSPACE_PANES) {
                                                val newPaneId = nextPaneId(rootProvider())
                                                val docked = dockTabAtEdge(rootProvider(), leaf.paneId, tab, edge)
                                                if (docked != rootProvider()) {
                                                    onUpdateRoot(docked)
                                                    onFocusPane(newPaneId)
                                                }
                                            }
                                            dragX = 0f; dragY = 0f; dockPreview = null
                                        },
                                        onDrag = { change, amount ->
                                            change.consume()
                                            if (!leaf.locked && leafCount(rootProvider()) < MAX_WORKSPACE_PANES) {
                                                dragX += amount.x
                                                dragY += amount.y
                                                val threshold = 44f
                                                dockPreview = if (kotlin.math.abs(dragX) >= kotlin.math.abs(dragY)) {
                                                    when { dragX >= threshold -> "right"; dragX <= -threshold -> "left"; else -> null }
                                                } else {
                                                    when { dragY >= threshold -> "bottom"; dragY <= -threshold -> "top"; else -> null }
                                                }
                                            }
                                        }
                                    )
                                }
                        ) {
                            Row(Modifier.clickable {
                                onFocusPane(leaf.paneId)
                                onUpdateRoot(activatePaneTab(rootProvider(), leaf.paneId, tab.key))
                                if (tab.kind == "document" && tab.noteId != 0L) vm.setActiveTab(tab.noteId)
                            }.padding(horizontal = 7.dp), verticalAlignment = Alignment.CenterVertically) {
                                Text(tab.label, Modifier.weight(1f), maxLines = 1, overflow = TextOverflow.Ellipsis, fontSize = 10.sp, fontWeight = if (selected) FontWeight.Bold else FontWeight.Medium)
                                Text("×", Modifier.clickable {
                                    if (leaf.tabs.size > 1) {
                                        onUpdateRoot(updateLeaf(rootProvider(), leaf.paneId) { l ->
                                            val nextTabs = l.tabs.filterNot { it.key == tab.key }
                                            val nextActive = if (l.activeKey == tab.key) nextTabs.first().key else l.activeKey
                                            l.copy(tabs = nextTabs, activeKey = nextActive)
                                        })
                                    }
                                }.padding(start = 5.dp), fontSize = 11.sp)
                            }
                        }
                    }
                }
                Text(if (leaf.locked) "🔒" else "", fontSize = 11.sp)
                Box {
                    IconButton(onClick = { addMenu = true }, modifier = Modifier.size(34.dp)) { Icon(Icons.Default.MoreVert, contentDescription = "Pane menu") }
                    DropdownMenu(expanded = addMenu, onDismissRequest = { addMenu = false }) {
                        DropdownMenuItem(text = { Text("Add Search tab") }, enabled = !leaf.locked, onClick = { onUpdateRoot(addTab(rootProvider(), leaf.paneId, PaneTab("tool-search", "Search", "search"))); addMenu = false })
                        DropdownMenuItem(text = { Text("Add Graph tab") }, enabled = !leaf.locked, onClick = { onUpdateRoot(addTab(rootProvider(), leaf.paneId, PaneTab("tool-graph", "Graph", "graph"))); addMenu = false })
                        DropdownMenuItem(text = { Text("Add Media tab") }, enabled = !leaf.locked, onClick = { onUpdateRoot(addTab(rootProvider(), leaf.paneId, PaneTab("tool-media", "Media", "media"))); addMenu = false })
                        DropdownMenuItem(text = { Text("Add AI tab") }, enabled = !leaf.locked, onClick = { onUpdateRoot(addTab(rootProvider(), leaf.paneId, PaneTab("tool-ai", "AI", "chat"))); addMenu = false })
                        contextDocument?.let { doc ->
                            DropdownMenuItem(text = { Text("Detach Outline") }, enabled = !leaf.locked, onClick = { onUpdateRoot(addTab(rootProvider(), leaf.paneId, PaneTab("tool-outline-${doc.noteId}", "Outline", "outline", doc.noteId, doc.fileType))); addMenu = false })
                            DropdownMenuItem(text = { Text("Detach Links & backlinks") }, enabled = !leaf.locked, onClick = { onUpdateRoot(addTab(rootProvider(), leaf.paneId, PaneTab("tool-links-${doc.noteId}", "Links", "links", doc.noteId, doc.fileType))); addMenu = false })
                            DropdownMenuItem(text = { Text("Detach Properties") }, enabled = !leaf.locked && doc.fileType.lowercase() in setOf("md", "markdown"), onClick = { onUpdateRoot(addTab(rootProvider(), leaf.paneId, PaneTab("tool-props-${doc.noteId}", "Properties", "properties", doc.noteId, doc.fileType))); addMenu = false })
                        }
                        HorizontalDivider()
                        globalTabs.forEach { g ->
                            DropdownMenuItem(
                                text = { Text("Add: ${g.title}", maxLines = 1, overflow = TextOverflow.Ellipsis) },
                                enabled = !leaf.locked && leaf.tabs.none { it.kind == "document" && it.noteId == g.id },
                                onClick = { onUpdateRoot(addTab(rootProvider(), leaf.paneId, documentPaneTab(g))); addMenu = false }
                            )
                        }
                        HorizontalDivider()
                        DropdownMenuItem(text = { Text(if (leaf.locked) "Unlock pane" else "Lock pane") }, onClick = { onUpdateRoot(updateLeaf(rootProvider(), leaf.paneId) { it.copy(locked = !it.locked) }); addMenu = false })
                        DropdownMenuItem(text = { Text("Move active tab to next pane") }, enabled = leaf.tabs.size > 1 && leafCount(rootProvider()) > 1 && !leaf.locked, onClick = {
                            active?.let { onUpdateRoot(moveTabToNextPane(rootProvider(), leaf.paneId, it)) }
                            addMenu = false
                        })
                        DropdownMenuItem(text = { Text("Dock active tab right") }, enabled = !leaf.locked && active != null && leafCount(rootProvider()) < MAX_WORKSPACE_PANES, onClick = {
                            active?.let { tab ->
                                val newId = nextPaneId(rootProvider())
                                onUpdateRoot(dockTabAtEdge(rootProvider(), leaf.paneId, tab, "right"))
                                onFocusPane(newId)
                            }
                            addMenu = false
                        })
                        DropdownMenuItem(text = { Text("Dock active tab down") }, enabled = !leaf.locked && active != null && leafCount(rootProvider()) < MAX_WORKSPACE_PANES, onClick = {
                            active?.let { tab ->
                                val newId = nextPaneId(rootProvider())
                                onUpdateRoot(dockTabAtEdge(rootProvider(), leaf.paneId, tab, "bottom"))
                                onFocusPane(newId)
                            }
                            addMenu = false
                        })
                        contextDocument?.let { doc ->
                            DropdownMenuItem(text = { Text("Open document full screen") }, onClick = {
                                vm.setActiveTab(doc.noteId)
                                when (doc.fileType.lowercase()) {
                                    "pdf" -> nav.navigate("pdfReader/${doc.noteId}")
                                    "html", "htm", "mhtml" -> nav.navigate("htmlReader/${doc.noteId}")
                                    else -> nav.navigate("reader")
                                }
                                addMenu = false
                            })
                        }
                        DropdownMenuItem(text = { Text("Open Vault explorer") }, onClick = { nav.navigate("browse"); addMenu = false })
                        DropdownMenuItem(text = { Text("Close pane") }, enabled = leafCount(rootProvider()) > 1, onClick = {
                            val nextRoot = removeLeaf(rootProvider(), leaf.paneId) ?: rootProvider()
                            onUpdateRoot(nextRoot)
                            onFocusPane(firstLeaf(nextRoot).paneId)
                            addMenu = false
                        })
                    }
                }
            }
            if (dockPreview != null) {
                DockPreviewBar(dockPreview!!)
            }
            HorizontalDivider()
            Box(Modifier.weight(1f).fillMaxWidth()) {
                when (active?.kind) {
                    "document" -> WorkspaceDocumentPane(vm, active.noteId, active.fileType, Modifier.fillMaxSize(), focused, { onFocusPane(leaf.paneId); vm.setActiveTab(active.noteId) }, {})
                    "search" -> SearchScreen(vm, nav)
                    "graph" -> GraphScreen(vm, nav, startNoteId = null)
                    "media" -> JwVideoBrowseScreen(vm, nav)
                    "chat" -> ChatScreen(vm, nav)
                    "outline" -> PaneOutlineTool(vm, active.noteId)
                    "links" -> PaneLinksTool(vm, active.noteId, nav)
                    "properties" -> PanePropertiesTool(vm, active.noteId)
                    else -> Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) { Text("Open a document or tool in this pane") }
                }
            }
        }
    }
}

@Composable
private fun DockPreviewBar(edge: String) {
    val label = when (edge) {
        "left" -> "⇤ Dock left"
        "right" -> "Dock right ⇥"
        "top" -> "⇧ Dock above"
        else -> "⇩ Dock below"
    }
    Surface(
        color = MaterialTheme.colorScheme.primaryContainer,
        contentColor = MaterialTheme.colorScheme.onPrimaryContainer,
        border = BorderStroke(1.dp, MaterialTheme.colorScheme.primary),
        modifier = Modifier.fillMaxWidth()
    ) {
        Text(label, Modifier.padding(vertical = 4.dp), textAlign = TextAlign.Center, fontSize = 11.sp, fontWeight = FontWeight.Bold)
    }
}

@Composable
private fun PaneOutlineTool(vm: AppViewModel, noteId: Long) {
    var content by remember(noteId) { mutableStateOf<String?>(null) }
    LaunchedEffect(noteId) { content = vm.getContentForComparison(noteId) }
    val outline = remember(content) { content?.let { AppViewModel.parseOutline(it) }.orEmpty() }
    Column(Modifier.fillMaxSize().padding(10.dp)) {
        Text("Outline", fontWeight = FontWeight.Bold, fontSize = 15.sp)
        HorizontalDivider(Modifier.padding(vertical = 6.dp))
        if (outline.isEmpty()) Text("No headings", color = MaterialTheme.colorScheme.onSurfaceVariant)
        else LazyColumn(Modifier.fillMaxSize()) {
            items(outline) { item ->
                Text(
                    item.title,
                    Modifier.fillMaxWidth().padding(start = ((item.level - 1) * 12).dp, top = 6.dp, bottom = 6.dp),
                    fontSize = 13.sp,
                    fontWeight = if (item.level <= 2) FontWeight.Bold else FontWeight.Medium
                )
            }
        }
    }
}

@Composable
private fun PaneLinksTool(vm: AppViewModel, noteId: Long, nav: NavHostController) {
    var outgoing by remember(noteId) { mutableStateOf<List<com.tebogo.markvault.data.LinkedNote>>(emptyList()) }
    var backlinks by remember(noteId) { mutableStateOf<List<com.tebogo.markvault.data.LinkedNote>>(emptyList()) }
    LaunchedEffect(noteId) {
        outgoing = runCatching { vm.loadForwardLinks(noteId) }.getOrElse { emptyList() }
        backlinks = runCatching { vm.loadBacklinks(noteId) }.getOrElse { emptyList() }
    }
    LazyColumn(Modifier.fillMaxSize().padding(10.dp)) {
        item { Text("Outgoing links (${outgoing.size})", fontWeight = FontWeight.Bold, fontSize = 14.sp) }
        if (outgoing.isEmpty()) item { Text("No outgoing links", Modifier.padding(vertical = 8.dp), color = MaterialTheme.colorScheme.onSurfaceVariant) }
        items(outgoing) { linked ->
            Text("→ ${linked.title}", Modifier.fillMaxWidth().clickable { vm.setActiveTab(linked.id); nav.navigate("reader") }.padding(vertical = 7.dp), fontSize = 13.sp)
        }
        item { HorizontalDivider(Modifier.padding(vertical = 8.dp)); Text("Backlinks (${backlinks.size})", fontWeight = FontWeight.Bold, fontSize = 14.sp) }
        if (backlinks.isEmpty()) item { Text("No backlinks", Modifier.padding(vertical = 8.dp), color = MaterialTheme.colorScheme.onSurfaceVariant) }
        items(backlinks) { linked ->
            Text("← ${linked.title}", Modifier.fillMaxWidth().clickable { vm.setActiveTab(linked.id); nav.navigate("reader") }.padding(vertical = 7.dp), fontSize = 13.sp)
        }
    }
}

@Composable
private fun PanePropertiesTool(vm: AppViewModel, noteId: Long) {
    var content by remember(noteId) { mutableStateOf<String?>(null) }
    LaunchedEffect(noteId) { content = vm.getContentForComparison(noteId) }
    val props = remember(content) { parseFrontmatterProperties(content.orEmpty()) }
    LazyColumn(Modifier.fillMaxSize().padding(10.dp)) {
        item { Text("Properties", fontWeight = FontWeight.Bold, fontSize = 15.sp); HorizontalDivider(Modifier.padding(vertical = 6.dp)) }
        if (props.isEmpty()) item { Text("No YAML/frontmatter properties", color = MaterialTheme.colorScheme.onSurfaceVariant) }
        items(props) { pair ->
            Column(Modifier.fillMaxWidth().padding(vertical = 6.dp)) {
                Text(pair.first, fontSize = 11.sp, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary)
                Text(pair.second.ifBlank { "—" }, fontSize = 13.sp)
            }
        }
    }
}

private fun parseFrontmatterProperties(content: String): List<Pair<String, String>> {
    val lines = content.lineSequence().toList()
    if (lines.firstOrNull()?.trim() != "---") return emptyList()
    val end = lines.drop(1).indexOfFirst { it.trim() == "---" }
    if (end < 0) return emptyList()
    return lines.subList(1, end + 1).mapNotNull { line ->
        if (line.isBlank() || line.trimStart().startsWith("#")) return@mapNotNull null
        val split = line.indexOf(':')
        if (split <= 0) null else line.substring(0, split).trim().takeIf { it.isNotBlank() }?.let { key -> key to line.substring(split + 1).trim() }
    }
}

@Composable
private fun PaneTreeDivider(vertical: Boolean, onDrag: (Float) -> Unit) {
    val line = MaterialTheme.colorScheme.outlineVariant
    if (vertical) {
        Box(
            Modifier.fillMaxHeight().width(8.dp).background(MaterialTheme.colorScheme.surface)
                .pointerInput(Unit) { detectHorizontalDragGestures { change, drag -> change.consume(); onDrag(drag) } },
            contentAlignment = Alignment.Center
        ) { Box(Modifier.fillMaxHeight().width(1.dp).background(line)) }
    } else {
        Box(
            Modifier.fillMaxWidth().height(8.dp).background(MaterialTheme.colorScheme.surface)
                .pointerInput(Unit) { detectVerticalDragGestures { change, drag -> change.consume(); onDrag(drag) } },
            contentAlignment = Alignment.Center
        ) { Box(Modifier.fillMaxWidth().height(1.dp).background(line)) }
    }
}

@Composable
private fun PaneToolbarButton(label: String, onClick: () -> Unit) {
    Surface(shape = RoundedCornerShape(7.dp), border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant), color = MaterialTheme.colorScheme.surfaceVariant) {
        Text(label, Modifier.clickable(onClick = onClick).padding(horizontal = 8.dp, vertical = 6.dp), fontSize = 11.sp, fontWeight = FontWeight.SemiBold)
    }
}

private fun documentPaneTab(tab: TabInfo) = PaneTab("doc-${tab.id}", tab.title, "document", tab.id, tab.fileType)
private fun seedPaneTree(tabs: List<TabInfo>, activeId: Long?): PaneNode {
    val paneTabs = tabs.map(::documentPaneTab).ifEmpty { listOf(PaneTab("tool-search", "Search", "search")) }
    val activeKey = paneTabs.firstOrNull { it.noteId == activeId }?.key ?: paneTabs.first().key
    return PaneLeaf(1, paneTabs, activeKey)
}
private fun firstLeaf(node: PaneNode): PaneLeaf = when (node) { is PaneLeaf -> node; is PaneSplit -> firstLeaf(node.first) }
private fun leaves(node: PaneNode): List<PaneLeaf> = when (node) { is PaneLeaf -> listOf(node); is PaneSplit -> leaves(node.first) + leaves(node.second) }
private fun leafCount(node: PaneNode) = leaves(node).size
private fun findLeaf(node: PaneNode, id: Int): PaneLeaf? = when (node) { is PaneLeaf -> node.takeIf { it.paneId == id }; is PaneSplit -> findLeaf(node.first, id) ?: findLeaf(node.second, id) }
private fun nextPaneId(node: PaneNode) = (leaves(node).maxOfOrNull { it.paneId } ?: 0) + 1
private fun nextSplitId(node: PaneNode): Int {
    fun collect(n: PaneNode): Int = when (n) { is PaneLeaf -> 0; is PaneSplit -> maxOf(n.splitId, collect(n.first), collect(n.second)) }
    return collect(node) + 1
}
private fun updateLeaf(node: PaneNode, id: Int, f: (PaneLeaf) -> PaneLeaf): PaneNode = when (node) {
    is PaneLeaf -> if (node.paneId == id) f(node) else node
    is PaneSplit -> node.copy(first = updateLeaf(node.first, id, f), second = updateLeaf(node.second, id, f))
}
private fun updateSplitRatio(node: PaneNode, splitId: Int, ratio: Float): PaneNode = when (node) {
    is PaneLeaf -> node
    is PaneSplit -> if (node.splitId == splitId) node.copy(ratio = ratio) else node.copy(first = updateSplitRatio(node.first, splitId, ratio), second = updateSplitRatio(node.second, splitId, ratio))
}
private fun splitLeaf(root: PaneNode, paneId: Int, vertical: Boolean): PaneNode {
    val source = findLeaf(root, paneId) ?: return root
    if (leafCount(root) >= MAX_WORKSPACE_PANES) return root
    val active = source.tabs.firstOrNull { it.key == source.activeKey } ?: source.tabs.first()
    val second = PaneLeaf(nextPaneId(root), listOf(active), active.key)
    fun replace(node: PaneNode): PaneNode = when (node) {
        is PaneLeaf -> if (node.paneId == paneId) PaneSplit(nextSplitId(root), vertical, 0.5f, node, second) else node
        is PaneSplit -> node.copy(first = replace(node.first), second = replace(node.second))
    }
    return replace(root)
}
private fun addTab(root: PaneNode, paneId: Int, tab: PaneTab): PaneNode = updateLeaf(root, paneId) { leaf ->
    val tabs = if (leaf.tabs.any { it.key == tab.key }) leaf.tabs else leaf.tabs + tab
    if (leaf.activeKey == tab.key) leaf.copy(tabs = tabs)
    else leaf.copy(
        tabs = tabs,
        activeKey = tab.key,
        backStack = (leaf.backStack + leaf.activeKey).takeLast(40),
        forwardStack = emptyList()
    )
}

private fun activatePaneTab(root: PaneNode, paneId: Int, key: String): PaneNode = updateLeaf(root, paneId) { leaf ->
    if (key == leaf.activeKey || leaf.tabs.none { it.key == key }) leaf
    else leaf.copy(
        activeKey = key,
        backStack = (leaf.backStack + leaf.activeKey).takeLast(40),
        forwardStack = emptyList()
    )
}

private fun paneBack(root: PaneNode, paneId: Int): PaneNode = updateLeaf(root, paneId) { leaf ->
    val target = leaf.backStack.lastOrNull { key -> leaf.tabs.any { it.key == key } } ?: return@updateLeaf leaf
    leaf.copy(
        activeKey = target,
        backStack = leaf.backStack.dropLastWhile { it != target }.dropLast(1),
        forwardStack = (leaf.forwardStack + leaf.activeKey).takeLast(40)
    )
}

private fun paneForward(root: PaneNode, paneId: Int): PaneNode = updateLeaf(root, paneId) { leaf ->
    val target = leaf.forwardStack.lastOrNull { key -> leaf.tabs.any { it.key == key } } ?: return@updateLeaf leaf
    leaf.copy(
        activeKey = target,
        backStack = (leaf.backStack + leaf.activeKey).takeLast(40),
        forwardStack = leaf.forwardStack.dropLastWhile { it != target }.dropLast(1)
    )
}

private fun cyclePaneTab(root: PaneNode, paneId: Int, backwards: Boolean): PaneNode = updateLeaf(root, paneId) { leaf ->
    if (leaf.tabs.size < 2) return@updateLeaf leaf
    val current = leaf.tabs.indexOfFirst { it.key == leaf.activeKey }.coerceAtLeast(0)
    val next = if (backwards) (current - 1 + leaf.tabs.size) % leaf.tabs.size else (current + 1) % leaf.tabs.size
    val key = leaf.tabs[next].key
    leaf.copy(
        activeKey = key,
        backStack = (leaf.backStack + leaf.activeKey).takeLast(40),
        forwardStack = emptyList()
    )
}

private fun closeActivePaneTab(root: PaneNode, paneId: Int): PaneNode = updateLeaf(root, paneId) { leaf ->
    if (leaf.tabs.size <= 1) return@updateLeaf leaf
    val currentIndex = leaf.tabs.indexOfFirst { it.key == leaf.activeKey }.coerceAtLeast(0)
    val remaining = leaf.tabs.filterNot { it.key == leaf.activeKey }
    val next = remaining[currentIndex.coerceAtMost(remaining.lastIndex)].key
    leaf.copy(
        tabs = remaining,
        activeKey = next,
        backStack = leaf.backStack.filter { key -> remaining.any { it.key == key } },
        forwardStack = leaf.forwardStack.filter { key -> remaining.any { it.key == key } }
    )
}
private fun removeLeaf(node: PaneNode, paneId: Int): PaneNode? = when (node) {
    is PaneLeaf -> if (node.paneId == paneId) null else node
    is PaneSplit -> {
        val a = removeLeaf(node.first, paneId)
        val b = removeLeaf(node.second, paneId)
        when { a == null -> b; b == null -> a; else -> node.copy(first = a, second = b) }
    }
}
private fun dockTabAtEdge(root: PaneNode, paneId: Int, tab: PaneTab, edge: String): PaneNode {
    val source = findLeaf(root, paneId) ?: return root
    if (source.locked || leafCount(root) >= MAX_WORKSPACE_PANES) return root
    val newId = nextPaneId(root)
    val newLeaf = PaneLeaf(newId, listOf(tab), tab.key)
    val sourceAfterMove = if (source.tabs.size > 1) {
        val remaining = source.tabs.filterNot { it.key == tab.key }
        source.copy(
            tabs = remaining,
            activeKey = if (source.activeKey == tab.key) remaining.first().key else source.activeKey,
            backStack = source.backStack.filter { key -> remaining.any { it.key == key } },
            forwardStack = source.forwardStack.filter { key -> remaining.any { it.key == key } }
        )
    } else source
    val vertical = edge == "left" || edge == "right"
    val newFirst = edge == "left" || edge == "top"
    fun replace(node: PaneNode): PaneNode = when (node) {
        is PaneLeaf -> if (node.paneId == paneId) {
            PaneSplit(
                nextSplitId(root),
                vertical = vertical,
                ratio = 0.5f,
                first = if (newFirst) newLeaf else sourceAfterMove,
                second = if (newFirst) sourceAfterMove else newLeaf
            )
        } else node
        is PaneSplit -> node.copy(first = replace(node.first), second = replace(node.second))
    }
    return replace(root)
}

private fun moveTabToNextPane(root: PaneNode, fromPaneId: Int, tab: PaneTab): PaneNode {
    val all = leaves(root)
    val fromIndex = all.indexOfFirst { it.paneId == fromPaneId }
    if (fromIndex < 0 || all.size < 2) return root
    val target = all[(fromIndex + 1) % all.size]
    var next = updateLeaf(root, target.paneId) { l -> l.copy(tabs = (l.tabs + tab).distinctBy { it.key }, activeKey = tab.key) }
    next = updateLeaf(next, fromPaneId) { l ->
        val remaining = l.tabs.filterNot { it.key == tab.key }
        if (remaining.isEmpty()) l else l.copy(tabs = remaining, activeKey = if (l.activeKey == tab.key) remaining.first().key else l.activeKey)
    }
    return next
}

private fun encodePaneTree(node: PaneNode): String = nodeToJson(node).toString()
private fun nodeToJson(node: PaneNode): JSONObject = when (node) {
    is PaneLeaf -> JSONObject().apply {
        put("type", "leaf"); put("paneId", node.paneId); put("active", node.activeKey); put("locked", node.locked)
        put("back", JSONArray().apply { node.backStack.forEach { put(it) } })
        put("forward", JSONArray().apply { node.forwardStack.forEach { put(it) } })
        put("tabs", JSONArray().apply { node.tabs.forEach { t -> put(JSONObject().apply { put("key", t.key); put("label", t.label); put("kind", t.kind); put("noteId", t.noteId); put("fileType", t.fileType) }) } })
    }
    is PaneSplit -> JSONObject().apply { put("type", "split"); put("splitId", node.splitId); put("vertical", node.vertical); put("ratio", node.ratio.toDouble()); put("first", nodeToJson(node.first)); put("second", nodeToJson(node.second)) }
}
private fun decodePaneTree(raw: String): PaneNode? = runCatching { jsonToNode(JSONObject(raw)) }.getOrNull()
private fun jsonToNode(o: JSONObject): PaneNode {
    return if (o.getString("type") == "leaf") {
        val arr = o.getJSONArray("tabs")
        val tabs = buildList {
            for (i in 0 until arr.length()) {
                val t = arr.getJSONObject(i)
                add(PaneTab(t.getString("key"), t.optString("label", "Untitled"), t.getString("kind"), t.optLong("noteId", 0L), t.optString("fileType", "md")))
            }
        }.ifEmpty { listOf(PaneTab("tool-search", "Search", "search")) }
        val validKeys = tabs.map { it.key }.toSet()
        fun stringArray(name: String): List<String> {
            val history = o.optJSONArray(name) ?: return emptyList()
            return buildList { for (i in 0 until history.length()) history.optString(i).takeIf { it in validKeys }?.let(::add) }.takeLast(40)
        }
        PaneLeaf(
            o.getInt("paneId"),
            tabs,
            o.optString("active", tabs.first().key).takeIf { it in validKeys } ?: tabs.first().key,
            o.optBoolean("locked", false),
            stringArray("back"),
            stringArray("forward")
        )
    } else {
        PaneSplit(o.getInt("splitId"), o.optBoolean("vertical", true), o.optDouble("ratio", 0.5).toFloat().coerceIn(0.2f, 0.8f), jsonToNode(o.getJSONObject("first")), jsonToNode(o.getJSONObject("second")))
    }
}
