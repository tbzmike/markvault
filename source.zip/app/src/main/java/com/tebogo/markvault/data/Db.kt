package com.tebogo.markvault.data

import android.content.Context
import androidx.room.Dao
import androidx.room.Database
import androidx.room.Entity
import androidx.room.Fts4
import androidx.room.FtsOptions
import androidx.room.Index
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.PrimaryKey
import androidx.room.Query
import androidx.room.Room
import androidx.room.RoomDatabase

@Entity(
    tableName = "notes",
    indices = [Index(value = ["uri"], unique = true), Index(value = ["relPath"])]
)
data class Note(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val uri: String,
    val relPath: String,
    val name: String,
    val title: String,
    val folder: String,
    val content: String,
    val lastModified: Long,
    val size: Long,
    val lastOpened: Long = 0
)

@Fts4(contentEntity = Note::class, tokenizer = FtsOptions.TOKENIZER_UNICODE61)
@Entity(tableName = "notes_fts")
data class NoteFts(
    val title: String,
    val content: String
)

data class NoteMeta(
    val id: Long,
    val relPath: String,
    val name: String,
    val title: String,
    val folder: String,
    val lastModified: Long,
    val size: Long
)

data class SyncInfo(
    val id: Long,
    val uri: String,
    val lastModified: Long,
    val size: Long,
    val lastOpened: Long
)

data class SearchHit(
    val id: Long,
    val relPath: String,
    val title: String,
    val snippet: String
)

@Dao
interface NoteDao {

    @Query("SELECT id, relPath, name, title, folder, lastModified, size FROM notes ORDER BY relPath")
    suspend fun allMeta(): List<NoteMeta>

    @Query("SELECT id, uri, lastModified, size, lastOpened FROM notes")
    suspend fun syncInfo(): List<SyncInfo>

    @Query("SELECT * FROM notes WHERE id = :id")
    suspend fun byId(id: Long): Note?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsert(note: Note): Long

    @Query("DELETE FROM notes WHERE id IN (:ids)")
    suspend fun deleteByIds(ids: List<Long>)

    @Query("DELETE FROM notes")
    suspend fun clearAll()

    @Query("UPDATE notes SET lastOpened = :time WHERE id = :id")
    suspend fun touch(id: Long, time: Long)

    @Query(
        "SELECT id, relPath, name, title, folder, lastModified, size FROM notes " +
            "WHERE title LIKE :like OR name LIKE :like ORDER BY title LIMIT 200"
    )
    suspend fun searchTitles(like: String): List<NoteMeta>

    @Query(
        "SELECT notes.id AS id, notes.relPath AS relPath, notes.title AS title, " +
            "snippet(notes_fts, '\u27E6', '\u27E7', ' \u2026 ', -1, 14) AS snippet " +
            "FROM notes JOIN notes_fts ON notes.id = notes_fts.rowid " +
            "WHERE notes_fts MATCH :query LIMIT 150"
    )
    suspend fun search(query: String): List<SearchHit>
}

@Database(entities = [Note::class, NoteFts::class], version = 2, exportSchema = false)
abstract class VaultDb : RoomDatabase() {
    abstract fun notes(): NoteDao

    companion object {
        @Volatile
        private var INSTANCE: VaultDb? = null

        fun get(context: Context): VaultDb = INSTANCE ?: synchronized(this) {
            INSTANCE ?: Room.databaseBuilder(
                context.applicationContext,
                VaultDb::class.java,
                "markvault.db"
            )
                .fallbackToDestructiveMigration()
                .build()
                .also { INSTANCE = it }
        }
    }
}
