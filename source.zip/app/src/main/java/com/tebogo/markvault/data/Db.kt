package com.tebogo.markvault.data

import android.content.Context
import androidx.room.Dao
import androidx.room.Database
import androidx.room.Entity
import androidx.room.Fts4
import androidx.room.FtsOptions
import androidx.room.Index
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.PrimaryKey
import androidx.room.Query
import androidx.room.Room
import androidx.room.RoomDatabase
import androidx.room.Transaction

@Entity(
    tableName = "notes",
    indices = [Index(value = ["uri"], unique = true), Index(value = ["relPath"]),
        Index(value = ["lastModified", "id"])]
)
data class Note(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val uri: String,
    val relPath: String,
    val name: String,
    val title: String,
    val folder: String,
    val content: String,
    val lastModified: Long,
    val size: Long,
    val lastOpened: Long = 0,
    val lastScroll: Int = 0,
    val favourite: Int = 0,
    /** "md" for Markdown notes (default), "pdf" for PDF documents. */
    val fileType: String = "md"
)

@Fts4(contentEntity = Note::class, tokenizer = FtsOptions.TOKENIZER_UNICODE61)
@Entity(tableName = "notes_fts")
data class NoteFts(
    val title: String,
    val content: String
)

/** A note's membership in an auto-detected topic, with a relevance score. */
@Entity(
    tableName = "note_topics",
    primaryKeys = ["noteId", "topic"],
    indices = [Index("topic"), Index("noteId")]
)
data class NoteTopic(
    val noteId: Long,
    val topic: String,
    val score: Int
)

/** A wikilink found inside a note: fromId is the note containing [[target]], target is the raw text. */
@Entity(
    tableName = "note_links",
    primaryKeys = ["fromId", "targetNorm"],
    indices = [Index("fromId"), Index("targetNorm")]
)
data class NoteLink(
    val fromId: Long,
    /** Raw target text exactly as written inside [[...]]. */
    val target: String,
    /** Lowercased, trimmed, .md-stripped key used for matching. */
    val targetNorm: String
)

/**
 * Bookmarks for the in-app web browser. Distinct from web_history — a bookmark
 * is a user-chosen save, history is automatic.
 */
@Entity(
    tableName = "web_bookmarks",
    indices = [Index("url", unique = true), Index("addedAt")]
)
data class WebBookmark(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val url: String,
    val title: String,
    val host: String,
    val addedAt: Long = System.currentTimeMillis()
)

/**
 * Log of every web page visited in the in-app browser. Date + time is tracked so
 * the history screen can show grouping ("Today", "Yesterday", older dates).
 */
@Entity(
    tableName = "web_history",
    indices = [Index("openedAt"), Index("url")]
)
data class WebHistoryEntry(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val url: String,
    val title: String,
    /** Hostname for quick filtering / display ("www.jw.org" etc). */
    val host: String,
    val openedAt: Long = System.currentTimeMillis()
)

/**
 * Log of every PDF view — both library notes and external PDFs (opened from file
 * managers, downloads, etc). External entries have noteId = 0 and an arbitrary URI.
 */
@Entity(
    tableName = "pdf_history",
    indices = [Index("openedAt"), Index("uri")]
)
data class PdfHistoryEntry(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    /** URI of the PDF. For library notes, matches Note.uri; for external, the source URI. */
    val uri: String,
    /** Human-readable title. For library notes: Note.title. For external: derived from filename. */
    val title: String,
    /** If from library, the Note ID; 0 for external. */
    val noteId: Long,
    /** True if not in the library (opened from outside the app). */
    val isExternal: Boolean,
    val openedAt: Long = System.currentTimeMillis()
)

/** Lightweight projection: a note that links to (or is linked from) another. */
data class LinkedNote(val id: Long, val title: String, val folder: String)

/** Lightweight graph-only article row, including the aliases needed to resolve wikilinks. */
data class GraphGroupNodeRow(
    val id: Long,
    val title: String,
    val folder: String,
    val name: String,
    val relPath: String
)

/** Raw link emitted by one article in a graph-only window. */
data class GraphGroupRawLink(val fromId: Long, val targetNorm: String)

/**
 * Cached extracted text from a PDF page. Lets in-document search be instant on second open.
 * Keyed by (noteId, pageIndex). Invalidated whenever the source file's lastModified changes.
 */
@Entity(
    tableName = "pdf_page_text",
    primaryKeys = ["noteId", "pageIndex"],
    indices = [Index("noteId")]
)
data class PdfPageText(
    val noteId: Long,
    val pageIndex: Int,
    val text: String,
    val sourceLastModified: Long
)

/**
 * Hand-drawn PDF annotation. Stored per (noteId, pageIndex). The `paths` field holds
 * JSON of stroke data (array of arrays of x,y points normalised 0..1 relative to page width).
 */
@Entity(
    tableName = "pdf_annotations",
    primaryKeys = ["noteId", "pageIndex"],
    indices = [Index("noteId")]
)
data class PdfAnnotation(
    val noteId: Long,
    val pageIndex: Int,
    /** JSON: [[{"x":0.1,"y":0.2},...],[...]] — list of strokes, each stroke a list of normalised points */
    val paths: String,
    val updated: Long = System.currentTimeMillis()
)

data class NoteMeta(
    val id: Long,
    val relPath: String,
    val name: String,
    val title: String,
    val folder: String,
    val lastModified: Long,
    val size: Long,
    val fileType: String = "md"
)

data class RecentNote(
    val id: Long,
    val title: String,
    val folder: String,
    val lastOpened: Long,
    val fileType: String = "md"
)

data class TopicCount(val topic: String, val cnt: Int)

data class NoteText(val id: Long, val title: String, val content: String)

/** v5.5.0 — Lightweight projection for ANN index build — only noteId + vector BLOB. */
data class EmbeddingVectorProjection(val noteId: Long, val vector: ByteArray)

/** Stable passage identity, independent of SQLite row ids and backup imports. */
data class HnswVectorProjection(val noteId: Long, val chunkIndex: Int, val vector: ByteArray)
data class HnswMetadataProjection(val noteId: Long, val chunkIndex: Int, val createdAt: Long)

/** v5.5.9 — Lightweight media-semantic projection for hot search scoring. */
data class MediaEmbeddingVectorProjection(val mediaId: Long, val vector: ByteArray)

/**
 * v5.4.266cc — Semantic vector for one cached media item's searchable metadata.
 * Kept separate from note_embeddings so media cannot consume or interfere with
 * the 20k/22k article scopes. One row per media item and embedding model.
 */
@Entity(
    tableName = "media_embeddings",
    primaryKeys = ["mediaId", "modelVersion"],
    indices = [
        Index("mediaId"),
        // v5.5.9 — Search pages are always filtered by modelVersion and
        // ordered by mediaId. This composite index prevents a multi-model
        // media table from becoming a model-independent scan bottleneck.
        Index(value = ["modelVersion", "mediaId"])
    ]
)
data class MediaEmbedding(
    val mediaId: Long,
    val modelVersion: String,
    val dim: Int,
    val vector: ByteArray,
    val sourceFingerprint: String,
    val createdAt: Long
) {
    override fun equals(other: Any?): Boolean {
        if (this === other) return true
        if (javaClass != other?.javaClass) return false
        other as MediaEmbedding
        return mediaId == other.mediaId &&
            modelVersion == other.modelVersion &&
            dim == other.dim &&
            vector.contentEquals(other.vector) &&
            sourceFingerprint == other.sourceFingerprint &&
            createdAt == other.createdAt
    }

    override fun hashCode(): Int {
        var result = mediaId.hashCode()
        result = 31 * result + modelVersion.hashCode()
        result = 31 * result + dim
        result = 31 * result + vector.contentHashCode()
        result = 31 * result + sourceFingerprint.hashCode()
        result = 31 * result + createdAt.hashCode()
        return result
    }
}

/**
 * v5.4.100cc — Lightweight row for URL backfill from the library.
 * Populated by [NoteDao.notesForUrlHarvest]; the VM extracts source
 * URLs from the content (markdown frontmatter, HTML/MHTML envelope
 * comments) and adds them to the saved-URL cache so cross-format
 * dedup catches "already saved" articles regardless of whether they
 * live as .md or .html in the library.
 */
data class NoteUrlRow(
    val id: Long,
    val uri: String,
    val content: String,
    val fileType: String
)

data class SyncInfo(
    val id: Long,
    val uri: String,
    val lastModified: Long,
    val size: Long,
    val lastOpened: Long
)

/**
 * v4.8 — vector embedding of a note's content, used for semantic similarity
 * search. One row per note per model version. When a new model is downloaded
 * (different `modelVersion`), old rows are invalidated and re-embedded.
 *
 * The `vector` column is a packed `FloatArray` stored as a BLOB. Most embedding
 * models produce dimensions in [100, 768]; this layout keeps the binary form
 * compact (4 bytes per float, no JSON overhead) and lets us load all rows in
 * one query for in-memory cosine similarity over a few thousand candidates.
 *
 * `sourceLastModified` is captured so we can detect "note has been edited
 * since embedding" without joining against the notes table.
 */
@Entity(
    tableName = "note_embeddings",
    indices = [
        Index("noteId"),
        // v5.5.9 — ANN/semantic hot paths constrain modelVersion first and
        // then a set/page of noteIds. Since v5.5.8 keeps embeddings for
        // several models in the same table, noteId-only indexing makes every
        // search touch rows belonging to the other models too. This composite
        // index lets SQLite jump straight to the selected model's chunks.
        Index(value = ["modelVersion", "noteId", "chunkIndex"]),
        Index(value = ["modelVersion", "createdAt"])
    ],
    // v5.4.174cc — chunkIndex added to the primary key. A note now gets
    // ONE ROW PER PASSAGE instead of a single row for the whole note —
    // see EmbeddingService's indexing loop and TextChunker.kt. chunkIndex
    // is 0-based and stable for a given (note, modelVersion) pair as long
    // as the note's content doesn't change (buildOverlappingChunks is
    // deterministic), so re-embedding after a content edit correctly
    // overwrites the same chunk slots rather than accumulating stale ones.
    primaryKeys = ["noteId", "modelVersion", "chunkIndex"]
)
data class NoteEmbedding(
    val noteId: Long,
    val modelVersion: String,
    val chunkIndex: Int,
    val dim: Int,
    val vector: ByteArray,
    val sourceLastModified: Long,
    val createdAt: Long
) {
    // Auto-generated entities need explicit equals/hashCode when they hold
    // a ByteArray, because the default ones compare by reference identity.
    override fun equals(other: Any?): Boolean {
        if (this === other) return true
        if (javaClass != other?.javaClass) return false
        other as NoteEmbedding
        return noteId == other.noteId &&
            modelVersion == other.modelVersion &&
            chunkIndex == other.chunkIndex &&
            dim == other.dim &&
            vector.contentEquals(other.vector) &&
            sourceLastModified == other.sourceLastModified &&
            createdAt == other.createdAt
    }
    override fun hashCode(): Int {
        var result = noteId.hashCode()
        result = 31 * result + modelVersion.hashCode()
        result = 31 * result + chunkIndex
        result = 31 * result + dim
        result = 31 * result + vector.contentHashCode()
        result = 31 * result + sourceLastModified.hashCode()
        result = 31 * result + createdAt.hashCode()
        return result
    }
}

data class SearchHit(
    val id: Long,
    val relPath: String,
    val title: String,
    val snippet: String,
    val fileType: String = "md",
    /**
     * v4.24.0/v5.5.10 — Relevance score, 0.0–1.0, displayed in the result
     * row as a percentage. Higher = more relevant.
     *
     * IMPORTANT: this field is a DISPLAY/RANKING score, not one model's raw
     * probability. v5.5.12 uses an absolute 0..1 evidence-strength scale for
     * hybrid search: semantic + trusted keyword evidence reinforce one another
     * without normalising the best result to 100%. The bounded cross-encoder
     * changes the order of the top window, then that order is calibrated back
     * onto the same evidence-strength slots. Cross-encoder logits, embedding
     * cosine values and RRF scores are therefore never compared as though they
     * were the same numerical scale — the source of the v5.5.5 regression.
     *
     * v5.4.77cc — Note: LLM-only match tagging (v5.4.76cc's
     * `matchedViaLlm`) was moved OFF `SearchHit` to
     * [com.tebogo.markvault.AppViewModel.llmMatchedHitIds]. Room 2.8.4's
     * KSP query verifier rejects non-null primitive properties on DAO
     * return types that don't map to a SELECT column, and `@Ignore`
     * with the default Kotlin site target proved fragile across
     * Room-KSP versions. Keeping [SearchHit] a pure DB projection.
     */
    val score: Float? = null
)

/**
 * Lightweight projection used during the embedding pass. Holds only the
 * fields needed to decide whether a note's embedding is still current. The
 * actual note content is fetched lazily via [NoteDao.byId] so we never
 * materialise multi-megabyte content strings for every row in one query.
 */
data class NoteEmbedTarget(
    val id: Long,
    val lastModified: Long
)

@Dao
interface NoteDao {

    @Query("SELECT id, relPath, name, title, folder, lastModified, size, fileType FROM notes ORDER BY relPath")
    suspend fun allMeta(): List<NoteMeta>

    /** v5.4.34 — Notes that share the same file size (potential duplicates). */
    @Query("SELECT id, relPath, name, title, folder, lastModified, size, fileType FROM notes WHERE size IN (SELECT size FROM notes GROUP BY size HAVING COUNT(*) > 1) ORDER BY size, relPath")
    suspend fun duplicateCandidatesBySize(): List<NoteMeta>

    /** v5.4.34 — Get raw content for a single note (for hash comparison). */
    @Query("SELECT content FROM notes WHERE id = :id")
    suspend fun contentById(id: Long): String?

    /** v5.4.346cc — Read-only tag workspace source. */
    @Query(
        "SELECT id, title, content FROM notes " +
            "WHERE content LIKE '%tags:%' OR content LIKE '% #%' ORDER BY id"
    )
    suspend fun tagSourceRows(): List<NoteText>

    @Query(
        "SELECT id, title, folder, lastOpened, fileType FROM notes " +
            "WHERE lastOpened > 0 ORDER BY lastOpened DESC LIMIT 15"
    )
    suspend fun recentNotes(): List<RecentNote>

    @Query("SELECT id, uri, lastModified, size, lastOpened FROM notes WHERE uri = :uri LIMIT 1")
    suspend fun syncInfoByUri(uri: String): SyncInfo?

    @Query("SELECT id, uri, lastModified, size, lastOpened FROM notes")
    suspend fun syncInfo(): List<SyncInfo>

    @Query("SELECT * FROM notes WHERE id = :id")
    suspend fun byId(id: Long): Note?

    /**
     * v5.5.9 — Batch projection for the reranker hot path. A submitted search
     * reranks up to 20 notes; fetching them one-by-one caused 20 Room/SQLite
     * round trips that were identical for MiniLM and BGE and therefore hid the
     * embedding-model latency difference.
     */
    @Query("SELECT id, title, content FROM notes WHERE id IN (:ids)")
    suspend fun noteTextsByIds(ids: List<Long>): List<NoteText>

    /** Blue HNSW fusion only needs hit metadata; do not load complete article contents. */
    @Query("SELECT id, relPath, title, '' AS snippet, fileType, NULL AS score FROM notes WHERE id IN (:ids)")
    suspend fun semanticSearchHitsByIds(ids: List<Long>): List<SearchHit>

    /** Just the first kilobyte of content, used for home-screen preview cards. */
    @Query("SELECT SUBSTR(content, 1, 600) FROM notes WHERE id = :id")
    suspend fun previewOf(id: Long): String?

    @Query("SELECT COUNT(*) FROM notes")
    suspend fun countNotes(): Int

    /**
     * v5.4.384cc — Authoritative search-scope paging. Unlike the older
     * embedding-derived page, this slices the actual article table so
     * 1st 20K and 2nd 22K are fixed, disjoint article sets regardless of
     * embedding coverage or the currently selected embedding model.
     */
    @Query("SELECT id FROM notes ORDER BY lastModified DESC, id DESC LIMIT :limit OFFSET :offset")
    suspend fun getSearchScopeNoteIdPage(limit: Int, offset: Int): List<Long>

    /** Graph-only paging helpers. Ordered by stable note id; no indexing state is changed. */
    @Query("SELECT id FROM notes ORDER BY id LIMIT :limit OFFSET :offset")
    suspend fun graphGroupIds(limit: Int, offset: Int): List<Long>

    @Query("SELECT id, title, folder FROM notes ORDER BY id LIMIT 1 OFFSET :offset")
    suspend fun graphGroupFirst(offset: Int): LinkedNote?

    /** Full graph-only article window. Does not mutate notes, links, indexing, or embeddings. */
    @Query("SELECT id, title, folder, name, relPath FROM notes ORDER BY id LIMIT :limit OFFSET :offset")
    suspend fun graphGroupNotes(limit: Int, offset: Int): List<GraphGroupNodeRow>

    /** Raw links whose source article is inside the same graph window. */
    @Query(
        "WITH srcGroup AS (SELECT id FROM notes ORDER BY id LIMIT :limit OFFSET :offset) " +
            "SELECT l.fromId AS fromId, l.targetNorm AS targetNorm " +
            "FROM note_links l JOIN srcGroup s ON s.id = l.fromId"
    )
    suspend fun graphGroupLinks(limit: Int, offset: Int): List<GraphGroupRawLink>

    @Query("SELECT id, title, folder, name, relPath FROM notes ORDER BY id")
    suspend fun graphAllNotes(): List<GraphGroupNodeRow>

    @Query("SELECT fromId, targetNorm FROM note_links")
    suspend fun graphAllLinks(): List<GraphGroupRawLink>

    @Query("SELECT COUNT(*) FROM notes WHERE id < :id")
    suspend fun graphPositionBefore(id: Long): Int

    @Query("SELECT id, title, content FROM notes ORDER BY id LIMIT :limit OFFSET :offset")
    suspend fun notesTextPage(limit: Int, offset: Int): List<NoteText>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsert(note: Note): Long

    @Query("DELETE FROM notes WHERE id IN (:ids)")
    suspend fun deleteByIds(ids: List<Long>)

    @Query("DELETE FROM notes")
    suspend fun clearAll()

    @Query("UPDATE notes SET lastOpened = :time WHERE id = :id")
    suspend fun touch(id: Long, time: Long)

    @Query("UPDATE notes SET lastScroll = :scroll WHERE id = :id")
    suspend fun setScroll(id: Long, scroll: Int)

    @Query("UPDATE notes SET favourite = :fav WHERE id = :id")
    suspend fun setFavourite(id: Long, fav: Int)

    @Query("SELECT id, relPath, name, title, folder, lastModified, size, fileType FROM notes WHERE favourite = 1 ORDER BY title")
    suspend fun favouriteNotes(): List<NoteMeta>

    // ---- Topics ----
    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertTopics(rows: List<NoteTopic>)

    @Query("DELETE FROM note_topics WHERE noteId = :id")
    suspend fun clearTopicsForNote(id: Long)

    @Query("DELETE FROM note_topics")
    suspend fun clearTopics()

    @Query("DELETE FROM note_topics WHERE noteId NOT IN (SELECT id FROM notes)")
    suspend fun pruneOrphanTopics()

    /**
     * Notes the user hasn't recently opened, biased toward the topics they read most.
     * Logic: pick notes whose topics intersect with the topics of recently-opened notes,
     * exclude notes opened in the last few weeks, and prefer ones with no `lastOpened` at all.
     */
    @Query(
        "SELECT id, relPath, name, title, folder, lastModified, size, fileType FROM notes " +
            "WHERE id IN (" +
            "  SELECT DISTINCT noteId FROM note_topics WHERE topic IN (" +
            "    SELECT topic FROM note_topics WHERE noteId IN (" +
            "      SELECT id FROM notes WHERE lastOpened > 0 ORDER BY lastOpened DESC LIMIT 30" +
            "    )" +
            "  )" +
            ") " +
            "AND (lastOpened = 0 OR lastOpened < :recentCutoff) " +
            "ORDER BY lastOpened ASC, RANDOM() LIMIT :limit"
    )
    suspend fun suggestedNotes(recentCutoff: Long, limit: Int): List<NoteMeta>

    /** Fallback: random unread notes when the user has no recent reading history yet. */
    @Query(
        "SELECT id, relPath, name, title, folder, lastModified, size, fileType FROM notes " +
            "WHERE lastOpened = 0 ORDER BY RANDOM() LIMIT :limit"
    )
    suspend fun randomUnopened(limit: Int): List<NoteMeta>

    // ---- Links (wikilinks [[Target]]) ----
    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertLinks(rows: List<NoteLink>)

    @Query("DELETE FROM note_links WHERE fromId = :id")
    suspend fun clearLinksForNote(id: Long)

    @Query("DELETE FROM note_links")
    suspend fun clearLinks()

    @Query("DELETE FROM note_links WHERE fromId NOT IN (SELECT id FROM notes)")
    suspend fun pruneOrphanLinks()

    /** All `targetNorm` strings this note links to (outgoing). */
    @Query("SELECT target FROM note_links WHERE fromId = :id")
    suspend fun outgoingTargets(id: Long): List<String>

    /** Try to resolve a wikilink target to a real note. Matches title, file name, or relative path (case-insensitive). */
    @Query(
        "SELECT id, title, folder FROM notes " +
            "WHERE LOWER(title) = :norm OR LOWER(name) = :norm OR LOWER(name) = :normMd " +
            "OR LOWER(relPath) = :norm OR LOWER(relPath) = :normMd " +
            "LIMIT 1"
    )
    suspend fun resolveLink(norm: String, normMd: String): LinkedNote?

    /** Notes that link TO :id (backlinks). */
    @Query(
        "SELECT DISTINCT n.id AS id, n.title AS title, n.folder AS folder " +
            "FROM note_links l JOIN notes n ON n.id = l.fromId " +
            "WHERE l.targetNorm IN (:norms) ORDER BY n.title LIMIT 200"
    )
    suspend fun backlinksFor(norms: List<String>): List<LinkedNote>

    /** Resolved outgoing links from :id (forward links that actually point to existing notes). */
    @Query(
        "SELECT DISTINCT n.id AS id, n.title AS title, n.folder AS folder " +
            "FROM note_links l JOIN notes n ON " +
            "  LOWER(n.title) = l.targetNorm OR LOWER(n.name) = l.targetNorm " +
            "  OR LOWER(n.name) = l.targetNorm || '.md' OR LOWER(n.relPath) = l.targetNorm " +
            "WHERE l.fromId = :id ORDER BY n.title LIMIT 200"
    )
    suspend fun forwardLinksFor(id: Long): List<LinkedNote>

    /** Quick count of resolvable outgoing wikilinks from :id (used to badge the article header). */
    @Query(
        "SELECT COUNT(DISTINCT n.id) FROM note_links l JOIN notes n ON " +
            "  LOWER(n.title) = l.targetNorm OR LOWER(n.name) = l.targetNorm " +
            "  OR LOWER(n.name) = l.targetNorm || '.md' OR LOWER(n.relPath) = l.targetNorm " +
            "WHERE l.fromId = :id"
    )
    suspend fun forwardLinkCount(id: Long): Int

    /** Quick count of backlinks to any of the given normalised targets. */
    @Query(
        "SELECT COUNT(DISTINCT l.fromId) FROM note_links l " +
            "WHERE l.targetNorm IN (:norms) AND l.fromId != :excludeId"
    )
    suspend fun backlinkCount(norms: List<String>, excludeId: Long): Int

    /**
     * Find the note with the highest total connection count (outgoing wikilinks + backlinks).
     * Used as the default "anchor" for the graph view when no specific note is supplied.
     */
    @Query(
        "SELECT n.id AS id, n.title AS title, n.folder AS folder " +
            "FROM notes n " +
            "ORDER BY (" +
            "  (SELECT COUNT(*) FROM note_links WHERE fromId = n.id) + " +
            "  (SELECT COUNT(*) FROM note_links l WHERE l.targetNorm IN " +
            "    (LOWER(n.title), LOWER(n.name), LOWER(n.relPath), LOWER(n.name) || '.md')" +
            "  )" +
            ") DESC LIMIT 1"
    )
    suspend fun mostConnectedNote(): LinkedNote?

    @Query("SELECT topic, COUNT(*) AS cnt FROM note_topics GROUP BY topic")
    suspend fun topicCounts(): List<TopicCount>

    @Query("SELECT topic FROM note_topics WHERE noteId = :id ORDER BY score DESC")
    suspend fun topicsForNote(id: Long): List<String>

    @Query(
        "SELECT n.id AS id, n.relPath AS relPath, n.name AS name, n.title AS title, " +
            "n.folder AS folder, n.lastModified AS lastModified, n.size AS size, n.fileType AS fileType " +
            "FROM notes n JOIN note_topics t ON n.id = t.noteId " +
            "WHERE t.topic = :topic ORDER BY t.score DESC, n.title LIMIT 400"
    )
    suspend fun notesInTopic(topic: String): List<NoteMeta>

    /**
     * Title/path search that requires EVERY non-empty token to appear somewhere in the title,
     * file name, or relative path — in any order. Unused slots pass `%%` (matches anything).
     * Supports up to 6 tokens; extra words past that are ignored at the call site.
     */
    @Query(
        "SELECT id, relPath, name, title, folder, lastModified, size, fileType FROM notes " +
            "WHERE (title LIKE :p1 OR name LIKE :p1 OR relPath LIKE :p1) " +
            "  AND (title LIKE :p2 OR name LIKE :p2 OR relPath LIKE :p2) " +
            "  AND (title LIKE :p3 OR name LIKE :p3 OR relPath LIKE :p3) " +
            "  AND (title LIKE :p4 OR name LIKE :p4 OR relPath LIKE :p4) " +
            "  AND (title LIKE :p5 OR name LIKE :p5 OR relPath LIKE :p5) " +
            "  AND (title LIKE :p6 OR name LIKE :p6 OR relPath LIKE :p6) " +
            "ORDER BY title LIMIT 400"
    )
    suspend fun searchTitlesAllWords(
        p1: String, p2: String, p3: String, p4: String, p5: String, p6: String
    ): List<NoteMeta>

    @Query(
        "SELECT id, relPath, name, title, folder, lastModified, size, fileType FROM notes " +
            "WHERE title LIKE :like OR name LIKE :like ORDER BY title LIMIT 200"
    )
    suspend fun searchTitles(like: String): List<NoteMeta>

    @Query(
        "SELECT notes.id AS id, notes.relPath AS relPath, notes.title AS title, " +
            "snippet(notes_fts, '\u27E6', '\u27E7', ' \u2026 ', -1, 14) AS snippet, " +
            "notes.fileType AS fileType " +
            "FROM notes JOIN notes_fts ON notes.id = notes_fts.rowid " +
            // v5.5.12 — FTS4 has no built-in BM25 ORDER BY. Pull a wider
            // candidate pool so AppViewModel's title/phrase/adjacency scorer
            // is not forced to rank an arbitrary first 150 rowids. 500 keeps
            // recall materially higher without making multi-query search unbounded.
            "WHERE notes_fts MATCH :query LIMIT 500"
    )
    suspend fun search(query: String): List<SearchHit>

    /**
     * v5.4.100cc — URL harvest query. Returns every note whose content
     * plausibly carries a source URL:
     *   • Markdown notes with `source:` in frontmatter or `Source:` in
     *     the body (covers `saveConvertedMarkdown` and UrlImportScreen
     *     output, plus any manually-frontmattered import).
     *   • Every HTML/MHTML note (the URL lives in the envelope
     *     comment; content-field extraction has to fall back to the
     *     raw file since [stripHtmlForIndex] strips comments, but
     *     from v5.4.100cc onwards the source URL is preserved inline
     *     by the indexer).
     *
     * The LIKE-filter on markdown keeps the result set small on 14K+
     * libraries; without it we'd stream the entire notes table.
     */
    @Query(
        "SELECT id, uri, content, fileType FROM notes WHERE " +
            "(fileType = 'md' AND (content LIKE '%source:%' OR content LIKE '%Source:%')) " +
            "OR fileType IN ('html', 'htm', 'mhtml', 'mht')"
    )
    suspend fun notesForUrlHarvest(): List<NoteUrlRow>

    /* ── PDF page text cache ── */

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun savePdfPageText(rows: List<PdfPageText>)

    @Query("SELECT * FROM pdf_page_text WHERE noteId = :noteId ORDER BY pageIndex")
    suspend fun loadPdfPageText(noteId: Long): List<PdfPageText>

    @Query("DELETE FROM pdf_page_text WHERE noteId = :noteId")
    suspend fun clearPdfPageText(noteId: Long)

    @Query("SELECT sourceLastModified FROM pdf_page_text WHERE noteId = :noteId LIMIT 1")
    suspend fun pdfPageTextStamp(noteId: Long): Long?

    /* ── PDF annotations ── */

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun saveAnnotation(row: PdfAnnotation)

    @Query("DELETE FROM pdf_annotations WHERE noteId = :noteId AND pageIndex = :pageIndex")
    suspend fun deleteAnnotation(noteId: Long, pageIndex: Int)

    @Query("DELETE FROM pdf_annotations WHERE noteId = :noteId")
    suspend fun deleteAllAnnotationsForNote(noteId: Long)

    @Query("SELECT * FROM pdf_annotations WHERE noteId = :noteId")
    suspend fun loadAnnotationsForNote(noteId: Long): List<PdfAnnotation>

    @Query("SELECT * FROM pdf_annotations WHERE noteId = :noteId AND pageIndex = :pageIndex LIMIT 1")
    suspend fun loadAnnotation(noteId: Long, pageIndex: Int): PdfAnnotation?

    /* ── PDF view history ── */

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertPdfHistory(entry: PdfHistoryEntry): Long

    /** De-duplicate by URI: when re-opening the same PDF, update the timestamp instead of stacking entries. */
    @Query("DELETE FROM pdf_history WHERE uri = :uri")
    suspend fun deletePdfHistoryByUri(uri: String)

    @Query("SELECT * FROM pdf_history ORDER BY openedAt DESC LIMIT :limit")
    suspend fun recentPdfHistory(limit: Int = 100): List<PdfHistoryEntry>

    @Query("DELETE FROM pdf_history")
    suspend fun clearPdfHistory()

    @Query("DELETE FROM pdf_history WHERE id = :id")
    suspend fun deletePdfHistory(id: Long)

    /* ── Web history ── */

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertWebHistory(entry: WebHistoryEntry): Long

    @Query("DELETE FROM web_history WHERE url = :url")
    suspend fun deleteWebHistoryByUrl(url: String)

    @Query("SELECT * FROM web_history ORDER BY openedAt DESC LIMIT :limit")
    suspend fun recentWebHistory(limit: Int = 200): List<WebHistoryEntry>

    @Query("DELETE FROM web_history")
    suspend fun clearWebHistory()

    @Query("DELETE FROM web_history WHERE id = :id")
    suspend fun deleteWebHistory(id: Long)

    /* ── Web bookmarks ── */

    @Insert(onConflict = OnConflictStrategy.IGNORE)
    suspend fun insertBookmark(b: WebBookmark): Long

    @Query("SELECT EXISTS(SELECT 1 FROM web_bookmarks WHERE url = :url)")
    suspend fun isBookmarked(url: String): Boolean

    @Query("DELETE FROM web_bookmarks WHERE url = :url")
    suspend fun deleteBookmarkByUrl(url: String)

    @Query("DELETE FROM web_bookmarks WHERE id = :id")
    suspend fun deleteBookmark(id: Long)

    @Query("SELECT * FROM web_bookmarks ORDER BY addedAt DESC")
    suspend fun allBookmarks(): List<WebBookmark>

    // ── v4.8 — Embeddings ───────────────────────────────────────────────────
    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsertEmbedding(e: NoteEmbedding)

    @Query("SELECT * FROM note_embeddings WHERE noteId = :noteId AND modelVersion = :modelVersion LIMIT 1")
    suspend fun loadEmbedding(noteId: Long, modelVersion: String): NoteEmbedding?

    // v5.4.174cc — Removed loadAnyEmbedding (v5.4.173cc's short-note reuse
    // optimization): it copied forward a WHOLE-note vector on the
    // assumption that short-enough notes produce an identical embedding
    // regardless of the token budget. That assumption doesn't carry over
    // to chunking — a chunked embedding isn't equivalent to a truncated
    // whole-note one even for short notes, since the STORAGE SHAPE itself
    // changed (single row → one row per passage). An analogous reuse
    // optimization for the chunked scheme (e.g. skip re-chunking when a
    // note's content hasn't changed) is a reasonable future addition, but
    // needs its own reasoning, not a carry-over of this one.

    // v5.4.174cc — Deletes every chunk row for one note+modelVersion
    // before re-inserting a fresh set. Needed because a note's chunk
    // COUNT can change between embedding passes (the note got longer or
    // shorter), so a plain upsert-per-chunk would leave stale trailing
    // chunk rows behind if the new pass produces fewer chunks than the
    // last one did — e.g. an edit that shrinks a 3-chunk note down to 2
    // chunks would otherwise leave chunkIndex=2's old row orphaned,
    // silently still contributing to search with stale content.
    @Query("DELETE FROM note_embeddings WHERE noteId = :noteId AND modelVersion = :modelVersion")
    suspend fun deleteEmbeddingsForNote(noteId: Long, modelVersion: String)

    // v5.4.177cc — Wraps one note's full chunk-set replacement (the
    // delete above + every chunk's upsert) in a SINGLE database
    // transaction, via Room's @Transaction support for a default-bodied
    // DAO method that calls other DAO methods.
    //
    // Before this, EmbeddingService called deleteEmbeddingsForNote() and
    // upsertEmbedding() individually per chunk — each one its own
    // separately auto-committed SQLite write, each paying its own
    // fsync-to-disk cost. For a note with ~5 chunks that's 6 individual
    // commits; across a 42k-note library averaging a handful of chunks
    // each, that's roughly 200k+ individual commits — pure database I/O
    // overhead, completely unrelated to which embedding model is doing
    // the inference. That's why switching to the smallest/fastest model
    // barely helped: the bottleneck wasn't ML inference, it was
    // transaction commit overhead. Batching to one commit per note cuts
    // that ~5-6x.
    @Transaction
    suspend fun replaceNoteEmbeddings(noteId: Long, modelVersion: String, embeddings: List<NoteEmbedding>) {
        deleteEmbeddingsForNote(noteId, modelVersion)
        for (e in embeddings) {
            upsertEmbedding(e)
        }
    }

    /**
     * v5.4.186cc — Article-scoped semantic index: the N most recently
     * modified notes that have embeddings. Used by ensureSemanticIndex()
     * when the user's article limit > 0. Returns note IDs only; the caller
     * fetches their chunk embeddings via loadEmbeddingsForNotes().
     */
    /**
     * v5.4.188cc — Page-based half loading. Returns note IDs ordered by
     * recency with LIMIT + OFFSET, so the same query covers both halves:
     * half 0 → offset=0, half 1 → offset=halfSize.
     */
    @Query("""
        SELECT n.id
        FROM notes n
        INNER JOIN note_embeddings e ON e.noteId = n.id AND e.modelVersion = :modelVersion
        GROUP BY n.id
        ORDER BY n.lastModified DESC, n.id DESC
        LIMIT :limit OFFSET :offset
    """)
    suspend fun getEmbeddedNoteIdPage(modelVersion: String, limit: Int, offset: Int): List<Long>

    @Query("""
        SELECT n.id
        FROM notes n
        INNER JOIN note_embeddings e ON e.noteId = n.id AND e.modelVersion = :modelVersion
        GROUP BY n.id
        ORDER BY n.lastModified DESC
        LIMIT :limit
    """)
    suspend fun getRecentEmbeddedNoteIds(modelVersion: String, limit: Int): List<Long>

    /**
     * v5.4.185cc — Load embeddings for a specific set of note IDs (FTS5
     * candidates or article-scoped batches). Room handles the IN clause;
     * caller must chunk lists > 900 items to stay within SQLite's 999-
     * variable limit.
     */
    @Query("SELECT * FROM note_embeddings WHERE modelVersion = :modelVersion AND noteId IN (:noteIds)")
    suspend fun loadEmbeddingsForNotes(modelVersion: String, noteIds: List<Long>): List<NoteEmbedding>

    /**
     * v5.5.9 — Hot-path projection for semantic/ANN scoring. Search only needs
     * the owning note id and vector BLOB; avoiding the full NoteEmbedding entity
     * removes unused cursor columns/timestamp objects from every candidate page.
     */
    @Query("SELECT noteId, vector FROM note_embeddings WHERE modelVersion = :modelVersion AND noteId IN (:noteIds)")
    suspend fun loadEmbeddingVectorsForNotes(
        modelVersion: String,
        noteIds: List<Long>
    ): List<EmbeddingVectorProjection>

    /**
     * v5.5.0 — Paginated lightweight embedding loader for ANN index build.
     * Returns only noteId + vector BLOB (no timestamps, no dim) to keep
     * memory bounded while streaming through 100k+ rows. Ordered by
     * (noteId, chunkIndex) so OFFSET-based pagination is stable.
     */
    @Query(
        "SELECT noteId, vector FROM note_embeddings " +
            "WHERE modelVersion = :mv ORDER BY noteId, chunkIndex " +
            "LIMIT :limit OFFSET :offset"
    )
    suspend fun loadEmbeddingVectorsPage(mv: String, limit: Int, offset: Int): List<EmbeddingVectorProjection>

    @Query("SELECT noteId, chunkIndex, vector FROM note_embeddings WHERE modelVersion = :mv " +
        "AND (noteId > :afterNote OR (noteId = :afterNote AND chunkIndex > :afterChunk)) " +
        "ORDER BY noteId, chunkIndex LIMIT :limit")
    suspend fun loadHnswVectorsPage(mv: String, afterNote: Long, afterChunk: Int, limit: Int): List<HnswVectorProjection>

    @Query("SELECT noteId, chunkIndex, createdAt FROM note_embeddings WHERE modelVersion = :mv " +
        "AND (noteId > :afterNote OR (noteId = :afterNote AND chunkIndex > :afterChunk)) " +
        "ORDER BY noteId, chunkIndex LIMIT :limit")
    suspend fun loadHnswMetadataPage(mv: String, afterNote: Long, afterChunk: Int, limit: Int): List<HnswMetadataProjection>

    @Query("SELECT noteId, chunkIndex, vector FROM note_embeddings WHERE modelVersion = :mv " +
        "AND noteId IN (:noteIds) ORDER BY noteId, chunkIndex LIMIT :limit OFFSET :offset")
    suspend fun loadHnswChangedVectorsPage(mv: String, noteIds: List<Long>, limit: Int, offset: Int): List<HnswVectorProjection>

    @Query("SELECT * FROM note_embeddings WHERE modelVersion = :modelVersion")
    suspend fun loadAllEmbeddings(modelVersion: String): List<NoteEmbedding>

    /**
     * v5.4.183cc — Capped load for large libraries. When the user sets a
     * semantic chunk limit (to prevent OOM or first-search latency spikes
     * from very large chunk sets), we fetch at most [limit] rows ordered by
     * noteId so the most recently added notes are included. limit=0 means
     * "no cap — load all". The DAO caller handles the limit=0 case by
     * calling [loadAllEmbeddings] instead, so LIMIT 0 is never sent to SQLite.
     */
    @Query("SELECT * FROM note_embeddings WHERE modelVersion = :modelVersion ORDER BY noteId DESC LIMIT :limit")
    suspend fun loadEmbeddingsLimited(modelVersion: String, limit: Int): List<NoteEmbedding>

    @Query("SELECT COUNT(*) FROM note_embeddings WHERE modelVersion = :modelVersion")
    suspend fun embeddingCount(modelVersion: String): Int

    /**
     * v5.5.12 — Freshness marker for ANN validation. A row-count check alone
     * cannot detect an edited article that was re-embedded into the same number
     * of chunks. Compare this newest embedding timestamp with the ANN file's
     * last synchronized timestamp before trusting approximate candidate lookup.
     */
    @Query("SELECT COALESCE(MAX(createdAt), 0) FROM note_embeddings WHERE modelVersion = :modelVersion")
    suspend fun latestEmbeddingCreatedAt(modelVersion: String): Long

    // v5.4.175cc — Chunking (v5.4.174cc) means embeddingCount above now
    // counts PASSAGES, not notes — a 42k-note library with several
    // chunks per long note reports as a much bigger number than 42k.
    // That's CORRECT for memory-usage math (RAM scales with vector
    // count, i.e. chunks), but wrong for anything labeled "N-note
    // library". This gives the real note count for that latter case.
    @Query("SELECT COUNT(DISTINCT noteId) FROM note_embeddings WHERE modelVersion = :modelVersion")
    suspend fun distinctEmbeddedNoteCount(modelVersion: String): Int

    @Query("DELETE FROM note_embeddings WHERE noteId NOT IN (SELECT id FROM notes)")
    suspend fun pruneOrphanEmbeddings()

    @Query("DELETE FROM note_embeddings")
    suspend fun clearAllEmbeddings()

    @Query("DELETE FROM note_embeddings WHERE modelVersion != :keepVersion")
    suspend fun clearStaleEmbeddings(keepVersion: String)

    /**
     * v4.8.1 — cheap COUNT for the same predicate as [targetsNeedingEmbedding].
     * Returns a single integer rather than 14k rows, so it's safe to call as a
     * pre-flight before starting an embedding pass. Used by the VM to compute
     * the denominator of the progress fraction the moment the user taps
     * "Build embeddings", so the UI flips out of "Preparing…" within a second.
     */
    /**
     * v5.5.8 — Count NOTES, not chunk rows. Since chunked-v1 stores several
     * embedding rows per note, the old LEFT JOIN predicate returned the same
     * edited note once per stale chunk. That made one edited article get
     * embedded repeatedly in the same pass (and inflated the progress total).
     *
     * A note needs work when it has no rows for this model OR when ANY of its
     * rows was generated from an older lastModified value. The paired target
     * query below uses the identical predicate and returns each note exactly once.
     */
    @Query(
        "SELECT COUNT(*) FROM notes n " +
            "WHERE NOT EXISTS (" +
            "  SELECT 1 FROM note_embeddings e " +
            "  WHERE e.noteId = n.id AND e.modelVersion = :modelVersion" +
            ") OR EXISTS (" +
            "  SELECT 1 FROM note_embeddings e " +
            "  WHERE e.noteId = n.id AND e.modelVersion = :modelVersion " +
            "    AND e.sourceLastModified != n.lastModified" +
            ")"
    )
    suspend fun countNotesNeedingEmbedding(modelVersion: String): Int

    /**
     * v4.8.1 — lightweight projection of "what needs embedding". Returns just
     * (id, lastModified) pairs, NOT the full Note rows, because materialising
     * 14k+ Note objects (each carrying a multi-KB `content` String) blows out
     * the SQLite cursor window AND triggers OutOfMemoryError on most phones.
     * The caller fetches each note's content lazily via [byId] as it embeds.
     *
     * v5.5.8 — correlated EXISTS predicates intentionally replace the old
     * LEFT JOIN so chunked notes cannot appear multiple times after an edit.
     */
    @Query(
        "SELECT n.id AS id, n.lastModified AS lastModified FROM notes n " +
            "WHERE NOT EXISTS (" +
            "  SELECT 1 FROM note_embeddings e " +
            "  WHERE e.noteId = n.id AND e.modelVersion = :modelVersion" +
            ") OR EXISTS (" +
            "  SELECT 1 FROM note_embeddings e " +
            "  WHERE e.noteId = n.id AND e.modelVersion = :modelVersion " +
            "    AND e.sourceLastModified != n.lastModified" +
            ") ORDER BY n.id"
    )
    suspend fun targetsNeedingEmbedding(modelVersion: String): List<NoteEmbedTarget>

    /**
     * Kept for backwards compatibility with the v4.8.0 entry point. The new
     * code path uses [targetsNeedingEmbedding] for memory safety; this
     * full-row variant is retained so any out-of-tree callers don't break.
     */
    @Query(
        "SELECT n.* FROM notes n " +
            "LEFT JOIN note_embeddings e " +
            "  ON e.noteId = n.id AND e.modelVersion = :modelVersion " +
            "WHERE e.noteId IS NULL OR e.sourceLastModified != n.lastModified " +
            "ORDER BY n.id"
    )
    suspend fun notesNeedingEmbedding(modelVersion: String): List<Note>
}

@Database(
    entities = [
        Note::class, NoteFts::class, NoteTopic::class, NoteLink::class,
        PdfPageText::class, PdfAnnotation::class, PdfHistoryEntry::class,
        WebHistoryEntry::class, WebBookmark::class, NoteEmbedding::class,
        MediaItem::class, MediaEmbedding::class, Playlist::class
    ],
    version = 24,
    exportSchema = false
)
abstract class VaultDb : RoomDatabase() {
    abstract fun notes(): NoteDao
    abstract fun media(): MediaDao
    abstract fun playlists(): PlaylistDao

    companion object {
        @Volatile
        private var INSTANCE: VaultDb? = null

        /**
         * v11 → v12 migration. Adds the `note_embeddings` table for semantic
         * search. Pure additive — no existing column touched, so the user's
         * 14k-file index survives the upgrade without re-syncing.
         */
        private val MIGRATION_11_12 = object : androidx.room.migration.Migration(11, 12) {
            override fun migrate(db: androidx.sqlite.db.SupportSQLiteDatabase) {
                db.execSQL(
                    "CREATE TABLE IF NOT EXISTS `note_embeddings` (" +
                        "`noteId` INTEGER NOT NULL, " +
                        "`modelVersion` TEXT NOT NULL, " +
                        "`dim` INTEGER NOT NULL, " +
                        "`vector` BLOB NOT NULL, " +
                        "`sourceLastModified` INTEGER NOT NULL, " +
                        "`createdAt` INTEGER NOT NULL, " +
                        "PRIMARY KEY(`noteId`, `modelVersion`)" +
                        ")"
                )
                db.execSQL(
                    "CREATE INDEX IF NOT EXISTS `index_note_embeddings_noteId` " +
                        "ON `note_embeddings` (`noteId`)"
                )
            }
        }

        /**
         * v12 → v13 migration. `note_embeddings` gains `chunkIndex` in its
         * primary key — a note now stores one row PER PASSAGE instead of a
         * single whole-note (truncated) embedding. See TextChunker.kt and
         * EmbeddingService's indexing loop.
         *
         * This is a targeted DROP + CREATE of ONLY this one table — the
         * other 8 tables (notes, notes_fts, note_topics, note_links,
         * pdf_page_text, pdf_annotations, pdf_history, web_history,
         * web_bookmarks) are completely untouched, so this migration
         * cannot lose the user's vault, history, or bookmarks.
         *
         * The old rows aren't preserved because they aren't meaningfully
         * reusable: a whole-note embedding truncated to the model's token
         * budget isn't equivalent to "chunk 0" of a real multi-passage
         * split — it was computed over a DIFFERENT, truncated slice of
         * the note's text, not the same first-180-words window
         * buildOverlappingChunks would produce. Every note is re-embedded
         * from scratch under the new scheme; see Embedder.modelVersion's
         * doc comment for how that re-embedding gets correctly triggered
         * (not skipped as "already up to date").
         */
        /** v5.4.225cc — v13 → v14: adds media_items table for JW.org video/audio cache. */
        private val MIGRATION_13_14 = object : androidx.room.migration.Migration(13, 14) {
            override fun migrate(db: androidx.sqlite.db.SupportSQLiteDatabase) {
                db.execSQL(
                    "CREATE TABLE IF NOT EXISTS `media_items` (" +
                        "`id` INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL," +
                        "`title` TEXT NOT NULL DEFAULT ''," +
                        "`description` TEXT NOT NULL DEFAULT ''," +
                        "`durationMs` INTEGER NOT NULL DEFAULT 0," +
                        "`thumbnailUrl` TEXT NOT NULL DEFAULT ''," +
                        "`streamUrl` TEXT NOT NULL DEFAULT ''," +
                        "`localPath` TEXT NOT NULL DEFAULT ''," +
                        "`mediaType` TEXT NOT NULL DEFAULT 'video'," +
                        "`mimeType` TEXT NOT NULL DEFAULT 'video/mp4'," +
                        "`jwKey` TEXT NOT NULL DEFAULT ''," +
                        "`scriptureRefs` TEXT NOT NULL DEFAULT ''," +
                        "`category` TEXT NOT NULL DEFAULT ''," +
                        "`source` TEXT NOT NULL DEFAULT 'jworg'," +
                        "`cachedAt` INTEGER NOT NULL DEFAULT 0," +
                        "`lastPlayedAt` INTEGER NOT NULL DEFAULT 0," +
                        "`resumePositionMs` INTEGER NOT NULL DEFAULT 0" +
                        ")"
                )
            }
        }

        /** v5.4.235cc — v14 → v15: adds qualityOptions column for the video-quality picker. */
        private val MIGRATION_14_15 = object : androidx.room.migration.Migration(14, 15) {
            override fun migrate(db: androidx.sqlite.db.SupportSQLiteDatabase) {
                db.execSQL(
                    "ALTER TABLE `media_items` ADD COLUMN `qualityOptions` TEXT NOT NULL DEFAULT ''"
                )
            }
        }

        /**
         * v5.4.250cc — v15 → v16: adds uploadDate column (epoch millis,
         * parsed from JW.org's `firstPublished` field — see
         * MediaItem.uploadDate's doc comment). Same one-column
         * ALTER TABLE pattern as MIGRATION_14_15 above; existing cached
         * rows simply get 0 (unknown) until re-fetched from JW.org, which
         * re-populates it via the normal upsert-on-search/browse path —
         * no data loss, no re-index required.
         */
        private val MIGRATION_15_16 = object : androidx.room.migration.Migration(15, 16) {
            override fun migrate(db: androidx.sqlite.db.SupportSQLiteDatabase) {
                db.execSQL(
                    "ALTER TABLE `media_items` ADD COLUMN `uploadDate` INTEGER NOT NULL DEFAULT 0"
                )
            }
        }

        /**
         * v5.4.254cc — v16 → v17: adds isFavourite column so videos/audio
         * can be favourited, same as notes already are. Same one-column
         * ALTER TABLE pattern as MIGRATION_14_15/15_16 above; existing
         * cached rows default to 0 (not favourited) — no data loss.
         */
        private val MIGRATION_16_17 = object : androidx.room.migration.Migration(16, 17) {
            override fun migrate(db: androidx.sqlite.db.SupportSQLiteDatabase) {
                db.execSQL(
                    "ALTER TABLE `media_items` ADD COLUMN `isFavourite` INTEGER NOT NULL DEFAULT 0"
                )
            }
        }

        /** v5.4.255cc — v17 → v18: new playlists table (pure addition, nothing existing touched). */
        private val MIGRATION_17_18 = object : androidx.room.migration.Migration(17, 18) {
            override fun migrate(db: androidx.sqlite.db.SupportSQLiteDatabase) {
                db.execSQL(
                    "CREATE TABLE IF NOT EXISTS `playlists` (" +
                        "`id` INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL," +
                        "`name` TEXT NOT NULL DEFAULT ''," +
                        "`createdAt` INTEGER NOT NULL DEFAULT 0," +
                        "`mediaIds` TEXT NOT NULL DEFAULT ''" +
                        ")"
                )
            }
        }

        private val MIGRATION_12_13 = object : androidx.room.migration.Migration(12, 13) {
            override fun migrate(db: androidx.sqlite.db.SupportSQLiteDatabase) {
                db.execSQL("DROP TABLE IF EXISTS `note_embeddings`")
                db.execSQL(
                    "CREATE TABLE IF NOT EXISTS `note_embeddings` (" +
                        "`noteId` INTEGER NOT NULL, " +
                        "`modelVersion` TEXT NOT NULL, " +
                        "`chunkIndex` INTEGER NOT NULL, " +
                        "`dim` INTEGER NOT NULL, " +
                        "`vector` BLOB NOT NULL, " +
                        "`sourceLastModified` INTEGER NOT NULL, " +
                        "`createdAt` INTEGER NOT NULL, " +
                        "PRIMARY KEY(`noteId`, `modelVersion`, `chunkIndex`)" +
                        ")"
                )
                db.execSQL(
                    "CREATE INDEX IF NOT EXISTS `index_note_embeddings_noteId` " +
                        "ON `note_embeddings` (`noteId`)"
                )
            }
        }

        /** v5.4.266cc — v18 → v19: adds the separate media semantic-vector table.
         * Purely additive: all notes, chunks, media rows, and playlists remain untouched.
         */
        private val MIGRATION_18_19 = object : androidx.room.migration.Migration(18, 19) {
            override fun migrate(db: androidx.sqlite.db.SupportSQLiteDatabase) {
                db.execSQL(
                    "CREATE TABLE IF NOT EXISTS `media_embeddings` (" +
                        "`mediaId` INTEGER NOT NULL," +
                        "`modelVersion` TEXT NOT NULL," +
                        "`dim` INTEGER NOT NULL," +
                        "`vector` BLOB NOT NULL," +
                        "`sourceFingerprint` TEXT NOT NULL," +
                        "`createdAt` INTEGER NOT NULL," +
                        "PRIMARY KEY(`mediaId`, `modelVersion`)" +
                        ")"
                )
                db.execSQL(
                    "CREATE INDEX IF NOT EXISTS `index_media_embeddings_mediaId` " +
                        "ON `media_embeddings` (`mediaId`)"
                )
            }
        }

        /**
         * v5.4.288cc — v19 → v20: persist JW.org's separate subtitle URL and
         * language alongside cached media. Purely additive: existing notes,
         * embeddings, media metadata, playlists, and article chunks are untouched.
         */
        private val MIGRATION_19_20 = object : androidx.room.migration.Migration(19, 20) {
            override fun migrate(db: androidx.sqlite.db.SupportSQLiteDatabase) {
                db.execSQL(
                    "ALTER TABLE `media_items` ADD COLUMN `subtitleUrl` TEXT NOT NULL DEFAULT ''"
                )
                db.execSQL(
                    "ALTER TABLE `media_items` ADD COLUMN `subtitleLanguage` TEXT NOT NULL DEFAULT 'E'"
                )
            }
        }


        /** v5.4.350cc — v20 → v21: language identity for multilingual JW media cache. */
        private val MIGRATION_20_21 = object : androidx.room.migration.Migration(20, 21) {
            override fun migrate(db: androidx.sqlite.db.SupportSQLiteDatabase) {
                db.execSQL(
                    "ALTER TABLE `media_items` ADD COLUMN `contentLanguage` TEXT NOT NULL DEFAULT 'E'"
                )
            }
        }

        /**
         * v5.5.9 — v21 → v22: add model-first indexes for semantic hot paths.
         *
         * v5.5.8 intentionally keeps embeddings for multiple installed models
         * in the same tables. The existing noteId/mediaId-only indexes were
         * therefore no longer selective for searches constrained by modelVersion.
         * These are pure additive indexes: no rows are rewritten or discarded.
         */
        private val MIGRATION_21_22 = object : androidx.room.migration.Migration(21, 22) {
            override fun migrate(db: androidx.sqlite.db.SupportSQLiteDatabase) {
                db.execSQL(
                    "CREATE INDEX IF NOT EXISTS `index_note_embeddings_modelVersion_noteId_chunkIndex` " +
                        "ON `note_embeddings` (`modelVersion`, `noteId`, `chunkIndex`)"
                )
                db.execSQL(
                    "CREATE INDEX IF NOT EXISTS `index_media_embeddings_modelVersion_mediaId` " +
                        "ON `media_embeddings` (`modelVersion`, `mediaId`)"
                )
            }
        }

        private val MIGRATION_22_23 = object : androidx.room.migration.Migration(22, 23) {
            override fun migrate(db: androidx.sqlite.db.SupportSQLiteDatabase) {
                db.execSQL("CREATE INDEX IF NOT EXISTS `index_note_embeddings_modelVersion_createdAt` " +
                    "ON `note_embeddings` (`modelVersion`, `createdAt`)")
            }
        }

        // Cover the existing first/second library partition query without
        // scanning article bodies or sorting every note at each search.
        private val MIGRATION_23_24 = object : androidx.room.migration.Migration(23, 24) {
            override fun migrate(db: androidx.sqlite.db.SupportSQLiteDatabase) {
                db.execSQL("CREATE INDEX IF NOT EXISTS `index_notes_lastModified_id` " +
                    "ON `notes` (`lastModified`, `id`)")
            }
        }

        /**
         * Restore-only lifecycle hook. BackupManager must replace the physical
         * database file while no Room connection is holding it. Clearing the
         * singleton is essential so a failed restore can reopen the rolled-back
         * database instead of leaving the app with a permanently closed Room.
         */
        fun closeForRestore() = synchronized(this) {
            INSTANCE?.close()
            INSTANCE = null
        }

        fun get(context: Context): VaultDb = INSTANCE ?: synchronized(this) {
            INSTANCE ?: Room.databaseBuilder(
                context.applicationContext,
                VaultDb::class.java,
                "markvault.db"
            )
                .addMigrations(MIGRATION_11_12, MIGRATION_12_13, MIGRATION_13_14, MIGRATION_14_15, MIGRATION_15_16, MIGRATION_16_17, MIGRATION_17_18, MIGRATION_18_19, MIGRATION_19_20, MIGRATION_20_21, MIGRATION_21_22, MIGRATION_22_23, MIGRATION_23_24)
                .fallbackToDestructiveMigration()
                .build()
                .also { INSTANCE = it }
        }
    }
}
