package com.tebogo.markvault.data

import android.content.Context
import androidx.room.Dao
import androidx.room.Database
import androidx.room.Entity
import androidx.room.Fts4
import androidx.room.FtsOptions
import androidx.room.Index
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.PrimaryKey
import androidx.room.Query
import androidx.room.Room
import androidx.room.RoomDatabase

@Entity(
    tableName = "notes",
    indices = [Index(value = ["uri"], unique = true), Index(value = ["relPath"])]
)
data class Note(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val uri: String,
    val relPath: String,
    val name: String,
    val title: String,
    val folder: String,
    val content: String,
    val lastModified: Long,
    val size: Long,
    val lastOpened: Long = 0,
    val lastScroll: Int = 0
)

@Fts4(contentEntity = Note::class, tokenizer = FtsOptions.TOKENIZER_UNICODE61)
@Entity(tableName = "notes_fts")
data class NoteFts(
    val title: String,
    val content: String
)

/** A note's membership in an auto-detected topic, with a relevance score. */
@Entity(
    tableName = "note_topics",
    primaryKeys = ["noteId", "topic"],
    indices = [Index("topic"), Index("noteId")]
)
data class NoteTopic(
    val noteId: Long,
    val topic: String,
    val score: Int
)

data class NoteMeta(
    val id: Long,
    val relPath: String,
    val name: String,
    val title: String,
    val folder: String,
    val lastModified: Long,
    val size: Long
)

data class RecentNote(
    val id: Long,
    val title: String,
    val folder: String,
    val lastOpened: Long
)

data class TopicCount(val topic: String, val cnt: Int)

data class SyncInfo(
    val id: Long,
    val uri: String,
    val lastModified: Long,
    val size: Long,
    val lastOpened: Long
)

data class SearchHit(
    val id: Long,
    val relPath: String,
    val title: String,
    val snippet: String
)

@Dao
interface NoteDao {

    @Query("SELECT id, relPath, name, title, folder, lastModified, size FROM notes ORDER BY relPath")
    suspend fun allMeta(): List<NoteMeta>

    @Query(
        "SELECT id, title, folder, lastOpened FROM notes " +
            "WHERE lastOpened > 0 ORDER BY lastOpened DESC LIMIT 15"
    )
    suspend fun recentNotes(): List<RecentNote>

    @Query("SELECT id, uri, lastModified, size, lastOpened FROM notes")
    suspend fun syncInfo(): List<SyncInfo>

    @Query("SELECT * FROM notes WHERE id = :id")
    suspend fun byId(id: Long): Note?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsert(note: Note): Long

    @Query("DELETE FROM notes WHERE id IN (:ids)")
    suspend fun deleteByIds(ids: List<Long>)

    @Query("DELETE FROM notes")
    suspend fun clearAll()

    @Query("UPDATE notes SET lastOpened = :time WHERE id = :id")
    suspend fun touch(id: Long, time: Long)

    @Query("UPDATE notes SET lastScroll = :scroll WHERE id = :id")
    suspend fun setScroll(id: Long, scroll: Int)

    // ---- Topics ----
    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertTopics(rows: List<NoteTopic>)

    @Query("DELETE FROM note_topics WHERE noteId = :id")
    suspend fun clearTopicsForNote(id: Long)

    @Query("DELETE FROM note_topics")
    suspend fun clearTopics()

    @Query("DELETE FROM note_topics WHERE noteId NOT IN (SELECT id FROM notes)")
    suspend fun pruneOrphanTopics()

    @Query("SELECT topic, COUNT(*) AS cnt FROM note_topics GROUP BY topic")
    suspend fun topicCounts(): List<TopicCount>

    @Query("SELECT topic FROM note_topics WHERE noteId = :id ORDER BY score DESC")
    suspend fun topicsForNote(id: Long): List<String>

    @Query(
        "SELECT n.id AS id, n.relPath AS relPath, n.name AS name, n.title AS title, " +
            "n.folder AS folder, n.lastModified AS lastModified, n.size AS size " +
            "FROM notes n JOIN note_topics t ON n.id = t.noteId " +
            "WHERE t.topic = :topic ORDER BY t.score DESC, n.title LIMIT 400"
    )
    suspend fun notesInTopic(topic: String): List<NoteMeta>

    @Query(
        "SELECT id, relPath, name, title, folder, lastModified, size FROM notes " +
            "WHERE title LIKE :like OR name LIKE :like ORDER BY title LIMIT 200"
    )
    suspend fun searchTitles(like: String): List<NoteMeta>

    @Query(
        "SELECT notes.id AS id, notes.relPath AS relPath, notes.title AS title, " +
            "snippet(notes_fts, '\u27E6', '\u27E7', ' \u2026 ', -1, 14) AS snippet " +
            "FROM notes JOIN notes_fts ON notes.id = notes_fts.rowid " +
            "WHERE notes_fts MATCH :query LIMIT 150"
    )
    suspend fun search(query: String): List<SearchHit>
}

@Database(entities = [Note::class, NoteFts::class, NoteTopic::class], version = 3, exportSchema = false)
abstract class VaultDb : RoomDatabase() {
    abstract fun notes(): NoteDao

    companion object {
        @Volatile
        private var INSTANCE: VaultDb? = null

        fun get(context: Context): VaultDb = INSTANCE ?: synchronized(this) {
            INSTANCE ?: Room.databaseBuilder(
                context.applicationContext,
                VaultDb::class.java,
                "markvault.db"
            )
                .fallbackToDestructiveMigration()
                .build()
                .also { INSTANCE = it }
        }
    }
}
