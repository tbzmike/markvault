package com.tebogo.markvault.data

import android.content.Context
import androidx.room.Dao
import androidx.room.Database
import androidx.room.Entity
import androidx.room.Fts4
import androidx.room.FtsOptions
import androidx.room.Index
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.PrimaryKey
import androidx.room.Query
import androidx.room.Room
import androidx.room.RoomDatabase

@Entity(
    tableName = "notes",
    indices = [Index(value = ["uri"], unique = true), Index(value = ["relPath"])]
)
data class Note(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val uri: String,
    val relPath: String,
    val name: String,
    val title: String,
    val folder: String,
    val content: String,
    val lastModified: Long,
    val size: Long,
    val lastOpened: Long = 0,
    val lastScroll: Int = 0,
    val favourite: Int = 0,
    /** "md" for Markdown notes (default), "pdf" for PDF documents. */
    val fileType: String = "md"
)

@Fts4(contentEntity = Note::class, tokenizer = FtsOptions.TOKENIZER_UNICODE61)
@Entity(tableName = "notes_fts")
data class NoteFts(
    val title: String,
    val content: String
)

/** A note's membership in an auto-detected topic, with a relevance score. */
@Entity(
    tableName = "note_topics",
    primaryKeys = ["noteId", "topic"],
    indices = [Index("topic"), Index("noteId")]
)
data class NoteTopic(
    val noteId: Long,
    val topic: String,
    val score: Int
)

/** A wikilink found inside a note: fromId is the note containing [[target]], target is the raw text. */
@Entity(
    tableName = "note_links",
    primaryKeys = ["fromId", "targetNorm"],
    indices = [Index("fromId"), Index("targetNorm")]
)
data class NoteLink(
    val fromId: Long,
    /** Raw target text exactly as written inside [[...]]. */
    val target: String,
    /** Lowercased, trimmed, .md-stripped key used for matching. */
    val targetNorm: String
)

/** Lightweight projection: a note that links to (or is linked from) another. */
data class LinkedNote(val id: Long, val title: String, val folder: String)

/**
 * Cached extracted text from a PDF page. Lets in-document search be instant on second open.
 * Keyed by (noteId, pageIndex). Invalidated whenever the source file's lastModified changes.
 */
@Entity(
    tableName = "pdf_page_text",
    primaryKeys = ["noteId", "pageIndex"],
    indices = [Index("noteId")]
)
data class PdfPageText(
    val noteId: Long,
    val pageIndex: Int,
    val text: String,
    val sourceLastModified: Long
)

/**
 * Hand-drawn PDF annotation. Stored per (noteId, pageIndex). The `paths` field holds
 * JSON of stroke data (array of arrays of x,y points normalised 0..1 relative to page width).
 */
@Entity(
    tableName = "pdf_annotations",
    primaryKeys = ["noteId", "pageIndex"],
    indices = [Index("noteId")]
)
data class PdfAnnotation(
    val noteId: Long,
    val pageIndex: Int,
    /** JSON: [[{"x":0.1,"y":0.2},...],[...]] — list of strokes, each stroke a list of normalised points */
    val paths: String,
    val updated: Long = System.currentTimeMillis()
)

data class NoteMeta(
    val id: Long,
    val relPath: String,
    val name: String,
    val title: String,
    val folder: String,
    val lastModified: Long,
    val size: Long,
    val fileType: String = "md"
)

data class RecentNote(
    val id: Long,
    val title: String,
    val folder: String,
    val lastOpened: Long,
    val fileType: String = "md"
)

data class TopicCount(val topic: String, val cnt: Int)

data class NoteText(val id: Long, val title: String, val content: String)

data class SyncInfo(
    val id: Long,
    val uri: String,
    val lastModified: Long,
    val size: Long,
    val lastOpened: Long
)

data class SearchHit(
    val id: Long,
    val relPath: String,
    val title: String,
    val snippet: String,
    val fileType: String = "md"
)

@Dao
interface NoteDao {

    @Query("SELECT id, relPath, name, title, folder, lastModified, size, fileType FROM notes ORDER BY relPath")
    suspend fun allMeta(): List<NoteMeta>

    @Query(
        "SELECT id, title, folder, lastOpened, fileType FROM notes " +
            "WHERE lastOpened > 0 ORDER BY lastOpened DESC LIMIT 15"
    )
    suspend fun recentNotes(): List<RecentNote>

    @Query("SELECT id, uri, lastModified, size, lastOpened FROM notes")
    suspend fun syncInfo(): List<SyncInfo>

    @Query("SELECT * FROM notes WHERE id = :id")
    suspend fun byId(id: Long): Note?

    /** Just the first kilobyte of content, used for home-screen preview cards. */
    @Query("SELECT SUBSTR(content, 1, 600) FROM notes WHERE id = :id")
    suspend fun previewOf(id: Long): String?

    @Query("SELECT COUNT(*) FROM notes")
    suspend fun countNotes(): Int

    @Query("SELECT id, title, content FROM notes ORDER BY id LIMIT :limit OFFSET :offset")
    suspend fun notesTextPage(limit: Int, offset: Int): List<NoteText>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsert(note: Note): Long

    @Query("DELETE FROM notes WHERE id IN (:ids)")
    suspend fun deleteByIds(ids: List<Long>)

    @Query("DELETE FROM notes")
    suspend fun clearAll()

    @Query("UPDATE notes SET lastOpened = :time WHERE id = :id")
    suspend fun touch(id: Long, time: Long)

    @Query("UPDATE notes SET lastScroll = :scroll WHERE id = :id")
    suspend fun setScroll(id: Long, scroll: Int)

    @Query("UPDATE notes SET favourite = :fav WHERE id = :id")
    suspend fun setFavourite(id: Long, fav: Int)

    @Query("SELECT id, relPath, name, title, folder, lastModified, size, fileType FROM notes WHERE favourite = 1 ORDER BY title")
    suspend fun favouriteNotes(): List<NoteMeta>

    // ---- Topics ----
    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertTopics(rows: List<NoteTopic>)

    @Query("DELETE FROM note_topics WHERE noteId = :id")
    suspend fun clearTopicsForNote(id: Long)

    @Query("DELETE FROM note_topics")
    suspend fun clearTopics()

    @Query("DELETE FROM note_topics WHERE noteId NOT IN (SELECT id FROM notes)")
    suspend fun pruneOrphanTopics()

    /**
     * Notes the user hasn't recently opened, biased toward the topics they read most.
     * Logic: pick notes whose topics intersect with the topics of recently-opened notes,
     * exclude notes opened in the last few weeks, and prefer ones with no `lastOpened` at all.
     */
    @Query(
        "SELECT id, relPath, name, title, folder, lastModified, size, fileType FROM notes " +
            "WHERE id IN (" +
            "  SELECT DISTINCT noteId FROM note_topics WHERE topic IN (" +
            "    SELECT topic FROM note_topics WHERE noteId IN (" +
            "      SELECT id FROM notes WHERE lastOpened > 0 ORDER BY lastOpened DESC LIMIT 30" +
            "    )" +
            "  )" +
            ") " +
            "AND (lastOpened = 0 OR lastOpened < :recentCutoff) " +
            "ORDER BY lastOpened ASC, RANDOM() LIMIT :limit"
    )
    suspend fun suggestedNotes(recentCutoff: Long, limit: Int): List<NoteMeta>

    /** Fallback: random unread notes when the user has no recent reading history yet. */
    @Query(
        "SELECT id, relPath, name, title, folder, lastModified, size, fileType FROM notes " +
            "WHERE lastOpened = 0 ORDER BY RANDOM() LIMIT :limit"
    )
    suspend fun randomUnopened(limit: Int): List<NoteMeta>

    // ---- Links (wikilinks [[Target]]) ----
    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertLinks(rows: List<NoteLink>)

    @Query("DELETE FROM note_links WHERE fromId = :id")
    suspend fun clearLinksForNote(id: Long)

    @Query("DELETE FROM note_links")
    suspend fun clearLinks()

    @Query("DELETE FROM note_links WHERE fromId NOT IN (SELECT id FROM notes)")
    suspend fun pruneOrphanLinks()

    /** All `targetNorm` strings this note links to (outgoing). */
    @Query("SELECT target FROM note_links WHERE fromId = :id")
    suspend fun outgoingTargets(id: Long): List<String>

    /** Try to resolve a wikilink target to a real note. Matches title, file name, or relative path (case-insensitive). */
    @Query(
        "SELECT id, title, folder FROM notes " +
            "WHERE LOWER(title) = :norm OR LOWER(name) = :norm OR LOWER(name) = :normMd " +
            "OR LOWER(relPath) = :norm OR LOWER(relPath) = :normMd " +
            "LIMIT 1"
    )
    suspend fun resolveLink(norm: String, normMd: String): LinkedNote?

    /** Notes that link TO :id (backlinks). */
    @Query(
        "SELECT DISTINCT n.id AS id, n.title AS title, n.folder AS folder " +
            "FROM note_links l JOIN notes n ON n.id = l.fromId " +
            "WHERE l.targetNorm IN (:norms) ORDER BY n.title LIMIT 200"
    )
    suspend fun backlinksFor(norms: List<String>): List<LinkedNote>

    /** Resolved outgoing links from :id (forward links that actually point to existing notes). */
    @Query(
        "SELECT DISTINCT n.id AS id, n.title AS title, n.folder AS folder " +
            "FROM note_links l JOIN notes n ON " +
            "  LOWER(n.title) = l.targetNorm OR LOWER(n.name) = l.targetNorm " +
            "  OR LOWER(n.name) = l.targetNorm || '.md' OR LOWER(n.relPath) = l.targetNorm " +
            "WHERE l.fromId = :id ORDER BY n.title LIMIT 200"
    )
    suspend fun forwardLinksFor(id: Long): List<LinkedNote>

    /** Quick count of resolvable outgoing wikilinks from :id (used to badge the article header). */
    @Query(
        "SELECT COUNT(DISTINCT n.id) FROM note_links l JOIN notes n ON " +
            "  LOWER(n.title) = l.targetNorm OR LOWER(n.name) = l.targetNorm " +
            "  OR LOWER(n.name) = l.targetNorm || '.md' OR LOWER(n.relPath) = l.targetNorm " +
            "WHERE l.fromId = :id"
    )
    suspend fun forwardLinkCount(id: Long): Int

    /** Quick count of backlinks to any of the given normalised targets. */
    @Query(
        "SELECT COUNT(DISTINCT l.fromId) FROM note_links l " +
            "WHERE l.targetNorm IN (:norms) AND l.fromId != :excludeId"
    )
    suspend fun backlinkCount(norms: List<String>, excludeId: Long): Int

    /**
     * Find the note with the highest total connection count (outgoing wikilinks + backlinks).
     * Used as the default "anchor" for the graph view when no specific note is supplied.
     */
    @Query(
        "SELECT n.id AS id, n.title AS title, n.folder AS folder " +
            "FROM notes n " +
            "ORDER BY (" +
            "  (SELECT COUNT(*) FROM note_links WHERE fromId = n.id) + " +
            "  (SELECT COUNT(*) FROM note_links l WHERE l.targetNorm IN " +
            "    (LOWER(n.title), LOWER(n.name), LOWER(n.relPath), LOWER(n.name) || '.md')" +
            "  )" +
            ") DESC LIMIT 1"
    )
    suspend fun mostConnectedNote(): LinkedNote?

    @Query("SELECT topic, COUNT(*) AS cnt FROM note_topics GROUP BY topic")
    suspend fun topicCounts(): List<TopicCount>

    @Query("SELECT topic FROM note_topics WHERE noteId = :id ORDER BY score DESC")
    suspend fun topicsForNote(id: Long): List<String>

    @Query(
        "SELECT n.id AS id, n.relPath AS relPath, n.name AS name, n.title AS title, " +
            "n.folder AS folder, n.lastModified AS lastModified, n.size AS size, n.fileType AS fileType " +
            "FROM notes n JOIN note_topics t ON n.id = t.noteId " +
            "WHERE t.topic = :topic ORDER BY t.score DESC, n.title LIMIT 400"
    )
    suspend fun notesInTopic(topic: String): List<NoteMeta>

    /**
     * Title/path search that requires EVERY non-empty token to appear somewhere in the title,
     * file name, or relative path — in any order. Unused slots pass `%%` (matches anything).
     * Supports up to 6 tokens; extra words past that are ignored at the call site.
     */
    @Query(
        "SELECT id, relPath, name, title, folder, lastModified, size, fileType FROM notes " +
            "WHERE (title LIKE :p1 OR name LIKE :p1 OR relPath LIKE :p1) " +
            "  AND (title LIKE :p2 OR name LIKE :p2 OR relPath LIKE :p2) " +
            "  AND (title LIKE :p3 OR name LIKE :p3 OR relPath LIKE :p3) " +
            "  AND (title LIKE :p4 OR name LIKE :p4 OR relPath LIKE :p4) " +
            "  AND (title LIKE :p5 OR name LIKE :p5 OR relPath LIKE :p5) " +
            "  AND (title LIKE :p6 OR name LIKE :p6 OR relPath LIKE :p6) " +
            "ORDER BY title LIMIT 400"
    )
    suspend fun searchTitlesAllWords(
        p1: String, p2: String, p3: String, p4: String, p5: String, p6: String
    ): List<NoteMeta>

    @Query(
        "SELECT id, relPath, name, title, folder, lastModified, size, fileType FROM notes " +
            "WHERE title LIKE :like OR name LIKE :like ORDER BY title LIMIT 200"
    )
    suspend fun searchTitles(like: String): List<NoteMeta>

    @Query(
        "SELECT notes.id AS id, notes.relPath AS relPath, notes.title AS title, " +
            "snippet(notes_fts, '\u27E6', '\u27E7', ' \u2026 ', -1, 14) AS snippet, " +
            "notes.fileType AS fileType " +
            "FROM notes JOIN notes_fts ON notes.id = notes_fts.rowid " +
            "WHERE notes_fts MATCH :query LIMIT 150"
    )
    suspend fun search(query: String): List<SearchHit>

    /* ── PDF page text cache ── */

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun savePdfPageText(rows: List<PdfPageText>)

    @Query("SELECT * FROM pdf_page_text WHERE noteId = :noteId ORDER BY pageIndex")
    suspend fun loadPdfPageText(noteId: Long): List<PdfPageText>

    @Query("DELETE FROM pdf_page_text WHERE noteId = :noteId")
    suspend fun clearPdfPageText(noteId: Long)

    @Query("SELECT sourceLastModified FROM pdf_page_text WHERE noteId = :noteId LIMIT 1")
    suspend fun pdfPageTextStamp(noteId: Long): Long?

    /* ── PDF annotations ── */

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun saveAnnotation(row: PdfAnnotation)

    @Query("DELETE FROM pdf_annotations WHERE noteId = :noteId AND pageIndex = :pageIndex")
    suspend fun deleteAnnotation(noteId: Long, pageIndex: Int)

    @Query("DELETE FROM pdf_annotations WHERE noteId = :noteId")
    suspend fun deleteAllAnnotationsForNote(noteId: Long)

    @Query("SELECT * FROM pdf_annotations WHERE noteId = :noteId")
    suspend fun loadAnnotationsForNote(noteId: Long): List<PdfAnnotation>

    @Query("SELECT * FROM pdf_annotations WHERE noteId = :noteId AND pageIndex = :pageIndex LIMIT 1")
    suspend fun loadAnnotation(noteId: Long, pageIndex: Int): PdfAnnotation?
}

@Database(
    entities = [
        Note::class, NoteFts::class, NoteTopic::class, NoteLink::class,
        PdfPageText::class, PdfAnnotation::class
    ],
    version = 8,
    exportSchema = false
)
abstract class VaultDb : RoomDatabase() {
    abstract fun notes(): NoteDao

    companion object {
        @Volatile
        private var INSTANCE: VaultDb? = null

        fun get(context: Context): VaultDb = INSTANCE ?: synchronized(this) {
            INSTANCE ?: Room.databaseBuilder(
                context.applicationContext,
                VaultDb::class.java,
                "markvault.db"
            )
                .fallbackToDestructiveMigration()
                .build()
                .also { INSTANCE = it }
        }
    }
}
