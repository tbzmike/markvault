package com.tebogo.markvault.ui

import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.spring
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.interaction.collectIsPressedAsState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.graphicsLayer

/**
 * v5.4.158cc — Shared press-feedback scale animation for every
 * FloatingActionButton in the app.
 *
 * Scales the FAB down to 86% on press, then springs back to 100% on
 * release with a bouncy overshoot — the classic "squish and pop" tap
 * feedback. Applied identically across SearchScreen, ReaderScreen,
 * HtmlReaderScreen, WebSearchScreen, PdfReaderScreen, WebPopup,
 * WebViewerArticleSaver, and ArticleSemanticPopup so every FAB in
 * MarkVault feels consistent, rather than some bouncing and others not.
 *
 * v5.4.159cc — Also bounces IN when the FAB first enters composition
 * (scale 0 → ~1.15 overshoot → 1.0, via a bouncy spring's natural
 * overshoot rather than a separate two-step tween). Most of this app's
 * FABs are conditionally shown (`if (showKeywordFab) { FAB(...) }`), so
 * "first enters composition" corresponds exactly to "the FAB just
 * appeared on screen" — precisely when an entrance animation should
 * play. Entrance and press-feedback scale multiply together, so a tap
 * during the entrance bounce still squishes correctly, and once settled
 * the FAB behaves exactly as before.
 *
 * Usage at each call site (unchanged from v5.4.158cc — no call-site
 * changes were needed to add the entrance bounce):
 *   val fabInteraction = remember { MutableInteractionSource() }
 *   SmallFloatingActionButton(
 *       onClick = { ... },
 *       interactionSource = fabInteraction,
 *       modifier = Modifier.fabPressScale(fabInteraction)
 *   ) { ... }
 *
 * Both `interactionSource` (so the FAB reports press state here) AND the
 * `.fabPressScale(...)` modifier (so the scale actually renders) are
 * required — passing only one has no visible effect.
 */
@Composable
fun Modifier.fabPressScale(interactionSource: MutableInteractionSource): Modifier {
    // v5.4.159cc — Entrance bounce. remember{} without a key means this
    // Animatable is created fresh exactly once per composition-instance —
    // i.e. once each time this FAB mounts. For a conditionally-shown FAB,
    // that's every time it (re)appears; for an always-composed FAB, it's
    // once on initial app/screen launch. Either way is the correct trigger
    // for an entrance animation.
    val entranceScale = remember { Animatable(0f) }
    LaunchedEffect(Unit) {
        entranceScale.animateTo(
            targetValue = 1f,
            animationSpec = spring(
                dampingRatio = Spring.DampingRatioMediumBouncy,
                stiffness = Spring.StiffnessLow
            )
        )
    }

    val isPressed by interactionSource.collectIsPressedAsState()
    val pressScale by animateFloatAsState(
        targetValue = if (isPressed) 0.86f else 1f,
        animationSpec = spring(
            dampingRatio = Spring.DampingRatioMediumBouncy,
            stiffness = Spring.StiffnessMedium
        ),
        label = "fabPressScale"
    )
    return this.graphicsLayer {
        val combined = entranceScale.value * pressScale
        scaleX = combined
        scaleY = combined
    }
}
