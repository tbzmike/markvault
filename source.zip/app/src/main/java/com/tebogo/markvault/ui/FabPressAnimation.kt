package com.tebogo.markvault.ui

import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.spring
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.interaction.collectIsPressedAsState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.graphicsLayer

/**
 * v5.4.158cc — Shared press-feedback scale animation for every
 * FloatingActionButton in the app.
 *
 * Scales the FAB down on press, then springs back on release with a
 * bouncy overshoot — the classic "squish and pop" tap feedback. Applied
 * identically across SearchScreen, ReaderScreen, HtmlReaderScreen,
 * WebSearchScreen, PdfReaderScreen, WebPopup, WebViewerArticleSaver, and
 * ArticleSemanticPopup so every FAB in MarkVault feels consistent.
 *
 * v5.4.159cc — Also bounces IN when the FAB first enters composition.
 * Most of this app's FABs are conditionally shown, so "first enters
 * composition" corresponds exactly to "the FAB just appeared on screen."
 *
 * v5.4.162cc — Reads [UiAnim.prefs] for enabled/speed (Settings → UI
 * Animations). enabled=false suppresses both animations entirely; speed
 * scales spring stiffness (higher speed = higher stiffness = faster
 * settle — springs don't have a fixed "duration" the way tween does).
 *
 * v5.4.164cc — Reads [UiAnimPrefs.style] for genuinely different
 * entrance/press CHARACTER, not just timing:
 *   • BOUNCE/ZOOM: pure scale, differ in bounciness and speed.
 *   • WIGGLE/SPIN/FLIP: scale PLUS a rotation (Z, Z, and Y axis
 *     respectively), so these three are visually distinct from each
 *     other in addition to being distinct from the two scale-only styles.
 *   • RANDOM_MIX: resolves to one random concrete style PER FAB
 *     INSTANCE (picked once, in [remember], stable for that instance's
 *     mounted lifetime) — so the same button can look different from
 *     one appearance to the next, and two simultaneously-visible FABs
 *     can genuinely differ from each other.
 *
 * The rotation styles deliberately reuse the SAME entrance spring's own
 * overshoot/undershoot to drive their rotation amount (via
 * `(1f - entranceProgress.value) * rotationDegrees`), rather than
 * running a second, separate rotation animation — so the rotation winds
 * down in lockstep with the scale settling instead of as a disconnected
 * second motion, and there's only one set of spring numbers to reason
 * about per style.
 *
 * Usage at each call site (unchanged since v5.4.158cc):
 *   val fabInteraction = remember { MutableInteractionSource() }
 *   SmallFloatingActionButton(
 *       onClick = { ... },
 *       interactionSource = fabInteraction,
 *       modifier = Modifier.fabPressScale(fabInteraction)
 *   ) { ... }
 */
@Composable
fun Modifier.fabPressScale(interactionSource: MutableInteractionSource): Modifier {
    val uiAnim = UiAnim.prefs

    // v5.4.164cc — Resolve ONE concrete style for this FAB instance.
    // remember(uiAnim.style) means: if the user changes the Settings
    // style pick while this FAB is already mounted, it picks up the new
    // style (or re-rolls a new random one) on the next recomposition —
    // exactly what the Settings live-preview button needs to visibly
    // react when the user taps a different style chip. If the style
    // itself hasn't changed, this stays stable across recompositions
    // (no re-rolling on every keystroke/scroll).
    val resolvedStyle = remember(uiAnim.style) {
        if (uiAnim.style == UiAnimStyle.RANDOM_MIX) {
            UiAnimStyle.concreteStyles.random()
        } else {
            uiAnim.style
        }
    }

    val entranceProgress = remember { Animatable(if (uiAnim.enabled) 0f else 1f) }
    LaunchedEffect(uiAnim.enabled, uiAnim.speed, resolvedStyle) {
        if (uiAnim.enabled) {
            entranceProgress.snapTo(0f)
            entranceProgress.animateTo(
                targetValue = 1f,
                animationSpec = spring(
                    dampingRatio = resolvedStyle.dampingRatio,
                    // v5.4.165cc — DIVIDE by speed now (was multiply):
                    // higher speed = lower stiffness = slower spring
                    // settle, matching the inverted UiAnimPrefs semantics
                    // (higher slider value = slower, smoother motion).
                    stiffness = (Spring.StiffnessLow * resolvedStyle.stiffnessMultiplier / uiAnim.speed)
                        .coerceIn(30f, 4000f)
                )
            )
        } else {
            entranceProgress.snapTo(1f)
        }
    }

    val isPressed by interactionSource.collectIsPressedAsState()
    val pressProgress by animateFloatAsState(
        targetValue = if (uiAnim.enabled && isPressed) 1f else 0f,
        animationSpec = spring(
            dampingRatio = resolvedStyle.dampingRatio,
            // v5.4.165cc — DIVIDE by speed (was multiply); see entrance
            // spring comment above for why.
            stiffness = (Spring.StiffnessMedium * resolvedStyle.stiffnessMultiplier / uiAnim.speed)
                .coerceIn(30f, 8000f)
        ),
        label = "fabPressScale"
    )

    return this.graphicsLayer {
        val pressScale = 1f - (pressProgress * (1f - resolvedStyle.pressScaleTarget))
        val combinedScale = entranceProgress.value * pressScale
        scaleX = combinedScale
        scaleY = combinedScale

        val rotationAmount = (1f - entranceProgress.value) * resolvedStyle.rotationDegrees
        when (resolvedStyle.rotationAxis) {
            RotationAxis.Z -> rotationZ = rotationAmount
            RotationAxis.Y -> rotationY = rotationAmount
            RotationAxis.X -> rotationX = rotationAmount
            RotationAxis.NONE -> { /* no rotation for this style */ }
        }
    }
}
