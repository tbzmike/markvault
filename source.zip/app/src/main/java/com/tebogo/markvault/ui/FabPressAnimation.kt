package com.tebogo.markvault.ui

import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.spring
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.interaction.collectIsPressedAsState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.graphicsLayer

/**
 * v5.4.158cc — Shared press-feedback scale animation for every
 * FloatingActionButton in the app.
 *
 * Scales the FAB down to 86% on press, then springs back to 100% on
 * release with a bouncy overshoot — the classic "squish and pop" tap
 * feedback. Applied identically across SearchScreen, ReaderScreen,
 * HtmlReaderScreen, WebSearchScreen, PdfReaderScreen, WebPopup,
 * WebViewerArticleSaver, and ArticleSemanticPopup so every FAB in
 * MarkVault feels consistent, rather than some bouncing and others not.
 *
 * v5.4.159cc — Also bounces IN when the FAB first enters composition
 * (scale 0 → ~1.15 overshoot → 1.0, via a bouncy spring's natural
 * overshoot rather than a separate two-step tween). Most of this app's
 * FABs are conditionally shown (`if (showKeywordFab) { FAB(...) }`), so
 * "first enters composition" corresponds exactly to "the FAB just
 * appeared on screen" — precisely when an entrance animation should
 * play. Entrance and press-feedback scale multiply together, so a tap
 * during the entrance bounce still squishes correctly, and once settled
 * the FAB behaves exactly as before.
 *
 * v5.4.162cc — Now reads [UiAnim.prefs] (Settings → UI Animations):
 *   • enabled=false → both the entrance bounce and the press-squish are
 *     fully suppressed. Entrance snaps straight to 1.0 (no pop-in);
 *     press-scale's target stays pinned at 1.0 regardless of press
 *     state, so the button never visibly moves.
 *   • speed → scales spring stiffness for both animations. Springs
 *     don't have a fixed "duration" the tween has, so speed is applied
 *     as a stiffness multiplier (higher speed = higher stiffness =
 *     faster settle) rather than a literal duration divide — this
 *     preserves the bounce character across the whole adjustable
 *     range instead of degrading into a linear tween.
 *
 * Usage at each call site (unchanged since v5.4.158cc — no call-site
 * changes were needed for either the entrance bounce or this retrofit):
 *   val fabInteraction = remember { MutableInteractionSource() }
 *   SmallFloatingActionButton(
 *       onClick = { ... },
 *       interactionSource = fabInteraction,
 *       modifier = Modifier.fabPressScale(fabInteraction)
 *   ) { ... }
 *
 * Both `interactionSource` (so the FAB reports press state here) AND the
 * `.fabPressScale(...)` modifier (so the scale actually renders) are
 * required — passing only one has no visible effect.
 */
@Composable
fun Modifier.fabPressScale(interactionSource: MutableInteractionSource): Modifier {
    val uiAnim = UiAnim.prefs

    // v5.4.159cc — Entrance bounce. remember{} without a key means this
    // Animatable is created fresh exactly once per composition-instance —
    // i.e. once each time this FAB mounts. For a conditionally-shown FAB,
    // that's every time it (re)appears; for an always-composed FAB, it's
    // once on initial app/screen launch. Either way is the correct trigger
    // for an entrance animation.
    val entranceScale = remember { Animatable(if (uiAnim.enabled) 0f else 1f) }
    LaunchedEffect(uiAnim.enabled, uiAnim.speed) {
        if (uiAnim.enabled) {
            entranceScale.animateTo(
                targetValue = 1f,
                animationSpec = spring(
                    dampingRatio = Spring.DampingRatioMediumBouncy,
                    stiffness = (Spring.StiffnessLow * uiAnim.speed).coerceIn(50f, 3000f)
                )
            )
        } else {
            entranceScale.snapTo(1f)
        }
    }

    val isPressed by interactionSource.collectIsPressedAsState()
    val pressScale by animateFloatAsState(
        targetValue = if (uiAnim.enabled && isPressed) 0.86f else 1f,
        animationSpec = spring(
            dampingRatio = Spring.DampingRatioMediumBouncy,
            stiffness = (Spring.StiffnessMedium * uiAnim.speed).coerceIn(50f, 4000f)
        ),
        label = "fabPressScale"
    )
    return this.graphicsLayer {
        val combined = entranceScale.value * pressScale
        scaleX = combined
        scaleY = combined
    }
}
