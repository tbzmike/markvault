package com.tebogo.markvault.ui

import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.spring
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.interaction.collectIsPressedAsState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.graphicsLayer

/**
 * v5.4.158cc — Shared press-feedback scale animation for every
 * FloatingActionButton in the app.
 *
 * Scales the FAB down to 86% on press, then springs back to 100% on
 * release with a bouncy overshoot — the classic "squish and pop" tap
 * feedback. Applied identically across SearchScreen, ReaderScreen,
 * HtmlReaderScreen, WebSearchScreen, PdfReaderScreen, WebPopup,
 * WebViewerArticleSaver, and ArticleSemanticPopup so every FAB in
 * MarkVault feels consistent, rather than some bouncing and others not.
 *
 * Usage at each call site:
 *   val fabInteraction = remember { MutableInteractionSource() }
 *   SmallFloatingActionButton(
 *       onClick = { ... },
 *       interactionSource = fabInteraction,
 *       modifier = Modifier.fabPressScale(fabInteraction)
 *   ) { ... }
 *
 * Both `interactionSource` (so the FAB reports press state here) AND the
 * `.fabPressScale(...)` modifier (so the scale actually renders) are
 * required — passing only one has no visible effect.
 */
@Composable
fun Modifier.fabPressScale(interactionSource: MutableInteractionSource): Modifier {
    val isPressed by interactionSource.collectIsPressedAsState()
    val scale by animateFloatAsState(
        targetValue = if (isPressed) 0.86f else 1f,
        animationSpec = spring(
            dampingRatio = Spring.DampingRatioMediumBouncy,
            stiffness = Spring.StiffnessMedium
        ),
        label = "fabPressScale"
    )
    return this.graphicsLayer {
        scaleX = scale
        scaleY = scale
    }
}
