package com.tebogo.markvault.llm

import com.google.ai.edge.litertlm.Backend
import com.google.ai.edge.litertlm.Conversation
import com.google.ai.edge.litertlm.ConversationConfig
import com.google.ai.edge.litertlm.Engine
import com.google.ai.edge.litertlm.EngineConfig
import com.google.ai.edge.litertlm.SamplerConfig
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.flow
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock

/**
 * v4.20.0 — Stage 3: lifetime + streaming wiring for the on-device chat LLM.
 *
 * Replaces the Stage 1 smoke-test skeleton. Now actually opens a
 * Conversation, supports streaming token Flows, and tears down cleanly to
 * free RAM when chat isn't visible.
 *
 * ## Lifecycle contract
 *
 *   1. [load] — block until the engine + conversation are ready. Cheap to
 *      call when already loaded (returns immediately). Idempotent.
 *   2. [generate] — stream tokens for a single prompt. Each call resets
 *      the conversation by default (fresh per-question RAG, no carryover).
 *   3. [unload] — call when leaving the chat screen. Releases ~1.5 GB of
 *      RAM. ALWAYS call this in onCleared() / onDispose() / ViewModel
 *      teardown — failing to call leaks an entire LLM into the heap.
 *
 * ## Thread safety
 *
 * All public functions are guarded by a [Mutex]. Concurrent calls
 * serialise. Multiple Flow collectors on a single [generate] call are not
 * supported (LiteRT-LM's Flow is single-collector).
 *
 * ## Single instance, by design
 *
 * Holding more than one LlmInference instance simultaneously OOMs on most
 * Android devices per the LiteRT-LM docs. We enforce single-instance via
 * the `object` declaration plus the Mutex.
 */
object LlmManager {

    private val lock = Mutex()

    @Volatile
    private var engine: Engine? = null

    @Volatile
    private var loadedModelPath: String? = null

    /** True iff the engine is currently in memory. UI surfaces this. */
    val isLoaded: Boolean get() = engine != null

    /**
     * v5.4.45 — Absolute path of the model file currently loaded into
     * the engine, or `null` if nothing is loaded. Read by the ViewModel
     * to detect "user picked a different model in Settings, we need to
     * swap engines" without duplicating the path-comparison logic.
     */
    val loadedPath: String? get() = loadedModelPath

    /**
     * Load the model at [modelPath] if it isn't already loaded. If a
     * different model was loaded previously, it's unloaded first
     * (single-instance guarantee).
     *
     * Per LiteRT-LM docs, initialisation can take up to ~10 seconds. Must
     * be called from a background coroutine (e.g. `Dispatchers.IO`).
     *
     * ## v5.4.46 — REMOVED the master Conversation creation
     *
     * v4.20.0 created a `Conversation` here in load() and stored it in
     * the class-level `conversation` field. v5.4.44 then stopped using
     * that master conversation in generate() and instead created a fresh
     * one per question. But the master conversation stayed ALIVE in the
     * engine's resource table, never closed. Some LiteRT-LM backends
     * only support ONE active conversation at a time — the alive master
     * conversation blocked the second fresh conversation from starting,
     * which caused the "second question stuck loading forever" bug.
     *
     * Fix: don't create any conversation here. Only generate() creates
     * conversations, uses them, and closes them in a finally block.
     */
    suspend fun load(modelPath: String) = lock.withLock {
        // Already loaded with the same model — nothing to do.
        if (engine != null && loadedModelPath == modelPath) return@withLock
        // Different model loaded — tear down before swapping.
        if (engine != null && loadedModelPath != modelPath) {
            closeInternal()
        }
        val config = EngineConfig(
            modelPath = modelPath,
            backend = Backend.CPU()
        )
        val newEngine = Engine(config)
        newEngine.initialize()
        // No Conversation created here — see doc above.
        engine = newEngine
        loadedModelPath = modelPath
    }

    /**
     * Generate a streaming response to [prompt]. The returned Flow emits
     * tokens (or short token-chunks) as the model produces them. The Flow
     * completes when generation is done.
     *
     * Each call creates a fresh Conversation so previous Q&A doesn't
     * pollute context. The Conversation is closed in the finally block
     * so the engine never has more than one active at a time.
     *
     * ## v5.4.46 — Optimised sampling + removed master-conv dependency
     *
     *   - Temperature lowered from 0.4 to 0.3 — keeps answers tighter
     *     and more grounded in context (RAG's job is to extract, not
     *     create). Also produces fewer stalls where the model loops on
     *     low-probability tokens.
     *   - topK tightened from 40 to 20 — less time spent scoring unlikely
     *     candidates. Combined with lower temperature, this typically
     *     cuts per-token latency ~15–25 % on CPU.
     *   - Added maxTokens = 512 to prevent runaway generation that hangs
     *     the UI. If the model reaches 512 tokens it stops cleanly.
     *
     * Throws [IllegalStateException] if [load] hasn't been called.
     */
    fun generate(prompt: String): Flow<String> = flow {
        val eng = engine
            ?: throw IllegalStateException(
                "LlmManager.generate called before load — call load(modelPath) first"
            )
        val convConfig = ConversationConfig(
            samplerConfig = SamplerConfig(
                // v5.4.48 — 0.15 temperature for near-deterministic extraction.
                // Small models hallucinate when temperature is too high; at 0.15
                // they copy/paraphrase the provided notes rather than drift into
                // training-data knowledge.
                temperature = 0.15,
                topK = 10,
                topP = 0.85
            )
        )
        val freshConv = eng.createConversation(convConfig)
        try {
            freshConv.sendMessageAsync(prompt).collect { chunk ->
                emit(chunk.toString())
            }
        } finally {
            runCatching { freshConv.close() }
        }
    }

    /**
     * Release the engine and conversation, freeing the native memory
     * they hold. Safe to call when not loaded — no-op in that case.
     *
     * MUST be called when leaving the chat screen. Without this, the
     * model sits in RAM forever and the app's footprint stays ~1.5 GB
     * higher than necessary, which can get it killed by Android's
     * low-memory killer.
     */
    suspend fun unload() = lock.withLock {
        closeInternal()
    }

    /** Internal close — caller must already hold [lock]. */
    private fun closeInternal() {
        runCatching { engine?.close() }
        engine = null
        loadedModelPath = null
    }
}
