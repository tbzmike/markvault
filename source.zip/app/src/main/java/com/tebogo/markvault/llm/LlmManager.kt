package com.tebogo.markvault.llm

import com.google.ai.edge.litertlm.Backend
import com.google.ai.edge.litertlm.Conversation
import com.google.ai.edge.litertlm.ConversationConfig
import com.google.ai.edge.litertlm.Engine
import com.google.ai.edge.litertlm.EngineConfig
import com.google.ai.edge.litertlm.SamplerConfig
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.flow
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock

/**
 * v4.20.0 — Stage 3: lifetime + streaming wiring for the on-device chat LLM.
 *
 * Replaces the Stage 1 smoke-test skeleton. Now actually opens a
 * Conversation, supports streaming token Flows, and tears down cleanly to
 * free RAM when chat isn't visible.
 *
 * ## Lifecycle contract
 *
 *   1. [load] — block until the engine + conversation are ready. Cheap to
 *      call when already loaded (returns immediately). Idempotent.
 *   2. [generate] — stream tokens for a single prompt. Each call resets
 *      the conversation by default (fresh per-question RAG, no carryover).
 *   3. [unload] — call when leaving the chat screen. Releases ~1.5 GB of
 *      RAM. ALWAYS call this in onCleared() / onDispose() / ViewModel
 *      teardown — failing to call leaks an entire LLM into the heap.
 *
 * ## Thread safety
 *
 * All public functions are guarded by a [Mutex]. Concurrent calls
 * serialise. Multiple Flow collectors on a single [generate] call are not
 * supported (LiteRT-LM's Flow is single-collector).
 *
 * ## Single instance, by design
 *
 * Holding more than one LlmInference instance simultaneously OOMs on most
 * Android devices per the LiteRT-LM docs. We enforce single-instance via
 * the `object` declaration plus the Mutex.
 */
object LlmManager {

    private val lock = Mutex()

    @Volatile
    private var engine: Engine? = null

    @Volatile
    private var conversation: Conversation? = null

    @Volatile
    private var loadedModelPath: String? = null

    /**
     * v5.4.139cc — Sampling/conversation config captured at [load] and
     * reused by every [generate] call to build a fresh [Conversation]
     * per turn. Fresh-per-turn was the documented behaviour since
     * Stage 5 ("Each call creates a fresh Conversation so previous Q&A
     * doesn't pollute context") but the actual code reused a single
     * long-lived Conversation created in [load]. On chat's second
     * question the native KV cache was already populated with turn 1,
     * and on some device/model combinations the follow-up
     * `sendMessageAsync` hung indefinitely — exactly the "second
     * question never answers" bug in field reports. Now generate()
     * creates a Conversation from this stored config, streams the
     * response, and closes it with the same 600 ms callback_thread
     * drain that [unload] uses, so each turn starts from clean
     * native state and the hang is eliminated.
     */
    @Volatile
    private var convConfig: ConversationConfig? = null

    /** True iff the engine is currently in memory. UI surfaces this. */
    val isLoaded: Boolean get() = engine != null

    /**
     * Load the model at [modelPath] if it isn't already loaded. If a
     * different model was loaded previously, it's unloaded first
     * (single-instance guarantee).
     *
     * Per LiteRT-LM docs, initialisation can take up to ~10 seconds. Must
     * be called from a background coroutine (e.g. `Dispatchers.IO`).
     */
    suspend fun load(modelPath: String) = lock.withLock {
        // Already loaded with the same model — nothing to do.
        if (engine != null && loadedModelPath == modelPath) return@withLock
        // Different model loaded — tear down before swapping.
        if (engine != null && loadedModelPath != modelPath) {
            closeInternal()
        }
        val config = EngineConfig(
            modelPath = modelPath,
            backend = Backend.CPU()
        )
        val newEngine = Engine(config)
        newEngine.initialize()
        // Default sampling: temperature 0.4, top-K 40. Chosen for RAG
        // answer quality — slightly below the library default of 0.7 to
        // keep answers grounded in the retrieved context rather than
        // drifting into invention. The user's standing rule is
        // no-speculation, so we err toward determinism.
        val convConfig = ConversationConfig(
            samplerConfig = SamplerConfig(
                // v4.20.1 — LiteRT-LM 0.13.1's SamplerConfig takes Double
                // (not Float) for temperature and topP. The `f` suffix in
                // v4.20.0 caused a compile error. topK is Int and stays.
                temperature = 0.4,
                topK = 40,
                topP = 0.95
            )
        )
        // v5.4.139cc — Save the config for fresh-per-turn Conversation
        // creation in generate(); see the field's doc for why.
        this.convConfig = convConfig
        conversation = newEngine.createConversation(convConfig)
        engine = newEngine
        loadedModelPath = modelPath
    }

    /**
     * Generate a streaming response to [prompt]. The returned Flow emits
     * tokens (or short token-chunks) as the model produces them. The Flow
     * completes when generation is done.
     *
     * Each call creates a fresh Conversation so previous Q&A doesn't
     * pollute context. The user's default preference (per Settings) is
     * "fresh per question"; multi-turn mode would route through a
     * different code path that reuses the same Conversation across calls.
     *
     * Throws [IllegalStateException] if [load] hasn't been called.
     */
    /**
     * Generate a streamed response for [prompt].
     *
     * v5.4.139cc — Fresh-Conversation-per-turn semantics.
     *
     * Previously this reused the single [conversation] instance
     * created inside [load], despite the doc comment claiming
     * per-turn freshness. Chat's second question hit a native
     * hang because the reused Conversation's KV cache was already
     * primed from turn 1 and some device/model combinations
     * dispatched into a bad state on the follow-up call.
     *
     * Now: every call creates its own Conversation from the stored
     * [convConfig], streams the response, and closes it with the
     * same 600 ms callback_thread drain that [unload] uses. Each
     * turn starts from clean native state. The persistent
     * [conversation] field is no longer used by generate; it stays
     * around only so [unload] can free it if load ran but generate
     * never did.
     *
     * If multi-turn context (chat that remembers prior turns) is
     * ever needed, the correct place is a NEW method that takes a
     * conversation-history list and folds it into the prompt — NOT
     * reuse of the LiteRT-LM Conversation object itself, which is
     * what caused the hang.
     *
     * Throws [IllegalStateException] if [load] hasn't been called.
     */
    fun generate(prompt: String): Flow<String> = flow {
        val eng: Engine = engine
            ?: throw IllegalStateException(
                "LlmManager.generate called before load — call load(modelPath) first"
            )
        val cfg: ConversationConfig = convConfig
            ?: throw IllegalStateException(
                "LlmManager.generate: convConfig missing — load() didn't set it"
            )
        // Fresh Conversation for this single turn.
        val turnConv: Conversation = eng.createConversation(cfg)
        try {
            turnConv.sendMessageAsync(prompt).collect { chunk ->
                emit(chunk.toString())
            }
        } finally {
            // Close on a non-cancellable path so mapLatest / user
            // cancellation still frees the native session cleanly.
            // 600 ms drain matches unload() — see its doc for the
            // callback_thread race this prevents.
            kotlinx.coroutines.withContext(kotlinx.coroutines.NonCancellable) {
                kotlinx.coroutines.delay(600L)
                runCatching { turnConv.close() }
            }
        }
    }

    /**
     * Release the engine and conversation, freeing the native memory
     * they hold. Safe to call when not loaded — no-op in that case.
     *
     * MUST be called when leaving the chat screen. Without this, the
     * model sits in RAM forever and the app's footprint stays ~1.5 GB
     * higher than necessary, which can get it killed by Android's
     * low-memory killer.
     */
    suspend fun unload() {
        // v5.4.116cc — Give the native `callback_thread` a beat to
        // drain its final callback before we free the session.
        //
        // LiteRT-LM's `sendMessageAsync` Flow can hand control back to
        // Java after the token stream ends but BEFORE its native
        // producer thread has finished its cleanup callback. If we
        // close the Conversation while that callback is still in
        // flight, the native thread dispatches through freed memory
        // and the process dies with:
        //
        //   Fatal signal 11 (SIGSEGV), code 1 (SEGV_MAPERR),
        //   fault addr 0x0 in tid N (callback_thread)
        //
        // v5.4.117cc — The delay-and-close pair MUST be non-
        // cancellable. mapLatest in the search pipeline cancels the
        // in-flight mapper on every keystroke, which cancels this
        // coroutine mid-delay. Without the NonCancellable block,
        // the coroutine throws CancellationException at delay(),
        // withLock releases the mutex, and closeInternal never runs.
        //
        // v5.4.137cc — Bumped drain from 120 ms → 600 ms so Qwen 3
        // 0.6B and Phi-4-mini's larger native shutdown windows don't
        // race the close.
        //
        // v5.4.138cc — CRITICAL REFACTOR. Previous versions held the
        // mutex across the ENTIRE close, which meant if native
        // `engine.close()` blocked (a real occurrence on some
        // device/model combinations — the callback_thread has
        // outstanding work that keeps the JNI reference alive), the
        // mutex stayed held forever. Every future search that touched
        // the LLM path (which is every search when the AI multi-query
        // toggle is on, INCLUDING nominally-"keyword" searches
        // because the paraphrase computation runs before the semantic
        // gate) then waited on that mutex indefinitely, producing the
        // reported "searching…" hang.
        //
        // Now: acquire the mutex briefly, snapshot the session
        // objects, null the fields, RELEASE the mutex. Then close
        // outside the mutex in a NonCancellable block. A hung close
        // now leaks one native session (until the process ends) but
        // never blocks future loads — the next search sees engine =
        // null in the fast-path and proceeds with a fresh session.
        val snapshot: Pair<Conversation?, Engine?> = lock.withLock {
            val convSnap = conversation
            val engSnap = engine
            conversation = null
            engine = null
            loadedModelPath = null
            // v5.4.139cc — Also clear the stored ConversationConfig so
            // a subsequent load() re-derives it (and, more importantly,
            // so generate() doesn't try to build a Conversation on a
            // now-null Engine using a stale config).
            convConfig = null
            convSnap to engSnap
        }
        // If the mutex snapshot was empty, there's nothing to close.
        if (snapshot.first == null && snapshot.second == null) return
        kotlinx.coroutines.withContext(kotlinx.coroutines.NonCancellable) {
            kotlinx.coroutines.delay(600L)
            runCatching { snapshot.first?.close() }
            runCatching { snapshot.second?.close() }
        }
    }

    /** Internal close — caller must already hold [lock]. */
    private fun closeInternal() {
        runCatching { conversation?.close() }
        runCatching { engine?.close() }
        conversation = null
        engine = null
        loadedModelPath = null
    }
}
