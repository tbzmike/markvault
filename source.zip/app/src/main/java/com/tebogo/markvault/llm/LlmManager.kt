package com.tebogo.markvault.llm

import com.google.ai.edge.litertlm.Backend
import com.google.ai.edge.litertlm.Conversation
import com.google.ai.edge.litertlm.ConversationConfig
import com.google.ai.edge.litertlm.Engine
import com.google.ai.edge.litertlm.EngineConfig
import com.google.ai.edge.litertlm.SamplerConfig
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.flow
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock

/**
 * v4.20.0 — Stage 3: lifetime + streaming wiring for the on-device chat LLM.
 *
 * Replaces the Stage 1 smoke-test skeleton. Now actually opens a
 * Conversation, supports streaming token Flows, and tears down cleanly to
 * free RAM when chat isn't visible.
 *
 * ## Lifecycle contract
 *
 *   1. [load] — block until the engine + conversation are ready. Cheap to
 *      call when already loaded (returns immediately). Idempotent.
 *   2. [generate] — stream tokens for a single prompt. Each call resets
 *      the conversation by default (fresh per-question RAG, no carryover).
 *   3. [unload] — call when leaving the chat screen. Releases ~1.5 GB of
 *      RAM. ALWAYS call this in onCleared() / onDispose() / ViewModel
 *      teardown — failing to call leaks an entire LLM into the heap.
 *
 * ## Thread safety
 *
 * All public functions are guarded by a [Mutex]. Concurrent calls
 * serialise. Multiple Flow collectors on a single [generate] call are not
 * supported (LiteRT-LM's Flow is single-collector).
 *
 * ## Single instance, by design
 *
 * Holding more than one LlmInference instance simultaneously OOMs on most
 * Android devices per the LiteRT-LM docs. We enforce single-instance via
 * the `object` declaration plus the Mutex.
 */
object LlmManager {

    private val lock = Mutex()

    @Volatile
    private var engine: Engine? = null

    @Volatile
    private var conversation: Conversation? = null

    @Volatile
    private var loadedModelPath: String? = null

    /** True iff the engine is currently in memory. UI surfaces this. */
    val isLoaded: Boolean get() = engine != null

    /**
     * Load the model at [modelPath] if it isn't already loaded. If a
     * different model was loaded previously, it's unloaded first
     * (single-instance guarantee).
     *
     * Per LiteRT-LM docs, initialisation can take up to ~10 seconds. Must
     * be called from a background coroutine (e.g. `Dispatchers.IO`).
     */
    suspend fun load(modelPath: String) = lock.withLock {
        // Already loaded with the same model — nothing to do.
        if (engine != null && loadedModelPath == modelPath) return@withLock
        // Different model loaded — tear down before swapping.
        if (engine != null && loadedModelPath != modelPath) {
            closeInternal()
        }
        val config = EngineConfig(
            modelPath = modelPath,
            backend = Backend.CPU()
        )
        val newEngine = Engine(config)
        newEngine.initialize()
        // Default sampling: temperature 0.4, top-K 40. Chosen for RAG
        // answer quality — slightly below the library default of 0.7 to
        // keep answers grounded in the retrieved context rather than
        // drifting into invention. The user's standing rule is
        // no-speculation, so we err toward determinism.
        val convConfig = ConversationConfig(
            samplerConfig = SamplerConfig(
                // v4.20.1 — LiteRT-LM 0.13.1's SamplerConfig takes Double
                // (not Float) for temperature and topP. The `f` suffix in
                // v4.20.0 caused a compile error. topK is Int and stays.
                temperature = 0.4,
                topK = 40,
                topP = 0.95
            )
        )
        conversation = newEngine.createConversation(convConfig)
        engine = newEngine
        loadedModelPath = modelPath
    }

    /**
     * Generate a streaming response to [prompt]. The returned Flow emits
     * tokens (or short token-chunks) as the model produces them. The Flow
     * completes when generation is done.
     *
     * Each call creates a fresh Conversation so previous Q&A doesn't
     * pollute context. The user's default preference (per Settings) is
     * "fresh per question"; multi-turn mode would route through a
     * different code path that reuses the same Conversation across calls.
     *
     * Throws [IllegalStateException] if [load] hasn't been called.
     */
    fun generate(prompt: String): Flow<String> = flow {
        val conv = conversation
            ?: throw IllegalStateException(
                "LlmManager.generate called before load — call load(modelPath) first"
            )
        // Note: we don't `lock.withLock` the streaming itself — that would
        // hold the mutex for the entire generation (potentially minutes).
        // We rely on callers / UI not to invoke generate() concurrently;
        // the chat UI in Stage 5 will enforce one-at-a-time via a busy
        // flag in the ViewModel.
        conv.sendMessageAsync(prompt).collect { chunk ->
            emit(chunk.toString())
        }
    }

    /**
     * v5.4.74 — Release the engine and conversation, freeing native memory.
     *
     * Under LiteRT-LM on Android, plain `.close()` does NOT reliably return
     * the mmapped model buffers and KV-cache tensor pools to the OS. We
     * work around this by:
     *
     *   1. Closing conversation FIRST (frees KV cache — the biggest hog).
     *   2. Closing engine SECOND (frees weights + activation buffers).
     *   3. Nulling all references so JVM knows they're unreachable.
     *   4. Requesting `System.gc()` twice with a small delay — first pass
     *      lets objects become unreachable, second finalises them.
     *   5. `Runtime.getRuntime().gc()` for good measure on some vendor VMs.
     *
     * Without this, a 900 MB LLM leaves ~600 MB of ghost RSS in the
     * process after "unload", and subsequent BGE-large embeddings run
     * on top of that — leading to 1.5+ GB peaks and OOM crashes.
     */
    suspend fun unload() = lock.withLock {
        closeInternal()
        // Give the native layer a chance to actually release. Two GC
        // passes because the first one just marks; the second reclaims.
        System.gc()
        kotlinx.coroutines.delay(50)
        System.gc()
        Runtime.getRuntime().gc()
        kotlinx.coroutines.delay(50)
    }

    /** Internal close — caller must already hold [lock]. */
    private fun closeInternal() {
        runCatching { conversation?.close() }
        runCatching { engine?.close() }
        conversation = null
        engine = null
        loadedModelPath = null
    }
}
