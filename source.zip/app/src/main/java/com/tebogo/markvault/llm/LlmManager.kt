package com.tebogo.markvault.llm

import com.google.ai.edge.litertlm.Backend
import com.google.ai.edge.litertlm.Engine
import com.google.ai.edge.litertlm.EngineConfig

/**
 * v4.19.0 — Stage 1 of the on-device chat LLM project (RAG over the user's
 * notes, using the existing BGE-large [com.tebogo.markvault.search.SemanticIndex]
 * for retrieval and a local LLM for synthesis).
 *
 * ## Why this file exists right now
 *
 * This object is deliberately minimal and is NOT called from anywhere yet.
 * Its only job is to prove that the `litertlm-android` AAR resolves and
 * compiles correctly against this project's exact Kotlin/KSP/AGP versions
 * before any real feature work (model download flow, RAG prompt building,
 * chat UI) is built on top of it.
 *
 * The library is young (LiteRT-LM is Google's replacement for the now-
 * deprecated MediaPipe LLM Inference API, still in the 0.x version range)
 * and this project has limited CI credits with a "must compile first try"
 * constraint. Isolating the riskiest unknown — does this dependency even
 * link in our setup — into the smallest possible change means a failure
 * here is cheap to diagnose and fix, rather than discovering an upstream
 * incompatibility after writing hundreds of lines of chat UI on top of it.
 *
 * ## What's deliberately NOT here yet
 *
 *   - Conversation / Message wiring (Stage 3)
 *   - Model download + storage (Stage 2)
 *   - RAG prompt construction from SemanticIndex hits (Stage 4)
 *   - Any UI (Stage 5)
 *
 * ## Target model (once Stage 2 lands)
 *
 * Gemma 3 1B, 4-bit quantized, `.litertlm` format — the lightest model in
 * the current Gemma family. Chosen over the newer Gemma 4 E2B because E2B
 * needs ~1.9 GB just for weights + memory-mapped embeddings, which is too
 * tight alongside BGE-large (340 MB), Room, and the rest of MarkVault on a
 * 6 GB-RAM device.
 *
 * ## Backend choice
 *
 * CPU only, deliberately. The GPU backend requires extra
 * `<uses-native-library>` manifest entries (`libvndksupport.so`,
 * `libOpenCL.so`) — another moving part we don't need while just proving
 * the dependency compiles. GPU can be added in a later stage once the CPU
 * path is confirmed working end-to-end.
 */
object LlmManager {

    @Volatile
    private var engine: Engine? = null

    /**
     * Lazily creates and initializes the [Engine] for the model at
     * [modelPath]. Safe to call repeatedly — returns the existing engine if
     * one is already initialized.
     *
     * `engine.initialize()` can take up to ~10 seconds per Google's own
     * docs, so this function is `suspend` regardless of whether the
     * underlying call itself suspends or blocks — calling a blocking
     * function from inside a suspend function on a background dispatcher
     * is safe and is how callers should invoke this (e.g. from
     * `viewModelScope.launch(Dispatchers.IO) { ... }`).
     *
     * NOT YET CALLED FROM ANYWHERE in the app. Stage 3 wires this up.
     */
    suspend fun ensureEngine(modelPath: String): Engine {
        engine?.let { return it }
        val config = EngineConfig(
            modelPath = modelPath,
            backend = Backend.CPU()
        )
        val created = Engine(config)
        created.initialize()
        engine = created
        return created
    }

    /** Release the engine and any native resources it holds. */
    fun close() {
        engine?.close()
        engine = null
    }
}
