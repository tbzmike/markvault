package com.tebogo.markvault.llm

import com.google.ai.edge.litertlm.Backend
import com.google.ai.edge.litertlm.Conversation
import com.google.ai.edge.litertlm.ConversationConfig
import com.google.ai.edge.litertlm.Engine
import com.google.ai.edge.litertlm.EngineConfig
import com.google.ai.edge.litertlm.SamplerConfig
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.flow
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock

/**
 * v4.20.0 — Stage 3: lifetime + streaming wiring for the on-device chat LLM.
 *
 * Replaces the Stage 1 smoke-test skeleton. Now actually opens a
 * Conversation, supports streaming token Flows, and tears down cleanly to
 * free RAM when chat isn't visible.
 *
 * ## Lifecycle contract
 *
 *   1. [load] — block until the engine + conversation are ready. Cheap to
 *      call when already loaded (returns immediately). Idempotent.
 *   2. [generate] — stream tokens for a single prompt. Each call resets
 *      the conversation by default (fresh per-question RAG, no carryover).
 *   3. [unload] — call when leaving the chat screen. Releases ~1.5 GB of
 *      RAM. ALWAYS call this in onCleared() / onDispose() / ViewModel
 *      teardown — failing to call leaks an entire LLM into the heap.
 *
 * ## Thread safety
 *
 * All public functions are guarded by a [Mutex]. Concurrent calls
 * serialise. Multiple Flow collectors on a single [generate] call are not
 * supported (LiteRT-LM's Flow is single-collector).
 *
 * ## Single instance, by design
 *
 * Holding more than one LlmInference instance simultaneously OOMs on most
 * Android devices per the LiteRT-LM docs. We enforce single-instance via
 * the `object` declaration plus the Mutex.
 */
object LlmManager {

    private val lock = Mutex()

    @Volatile
    private var engine: Engine? = null

    @Volatile
    private var conversation: Conversation? = null

    @Volatile
    private var loadedModelPathInternal: String? = null

    /** True iff the engine is currently in memory. UI surfaces this. */
    val isLoaded: Boolean get() = engine != null

    /**
     * v5.4.129cc — The absolute path of the model currently resident in
     * memory, or null if nothing is loaded. Exposed so callers can tell
     * "a model is loaded" apart from "the model the user currently has
     * selected is loaded" — [isLoaded] alone can't distinguish those, which
     * previously let a stale model stay resident after the user switched
     * their Settings selection (see [com.tebogo.markvault.AppViewModel.ensureChatModelLoaded]).
     */
    val loadedModelPath: String? get() = loadedModelPathInternal

    /**
     * Load the model at [modelPath] if it isn't already loaded. If a
     * different model was loaded previously, it's unloaded first
     * (single-instance guarantee).
     *
     * Per LiteRT-LM docs, initialisation can take up to ~10 seconds. Must
     * be called from a background coroutine (e.g. `Dispatchers.IO`).
     */
    suspend fun load(modelPath: String) = lock.withLock {
        // Already loaded with the same model — nothing to do.
        if (engine != null && loadedModelPathInternal == modelPath) return@withLock
        // Different model loaded — tear down before swapping.
        if (engine != null && loadedModelPathInternal != modelPath) {
            closeInternal()
        }
        val config = EngineConfig(
            modelPath = modelPath,
            backend = Backend.CPU()
        )
        val newEngine = Engine(config)
        newEngine.initialize()
        // Default sampling: temperature 0.4, top-K 40. Chosen for RAG
        // answer quality — slightly below the library default of 0.7 to
        // keep answers grounded in the retrieved context rather than
        // drifting into invention. The user's standing rule is
        // no-speculation, so we err toward determinism.
        val convConfig = ConversationConfig(
            samplerConfig = SamplerConfig(
                // v4.20.1 — LiteRT-LM 0.13.1's SamplerConfig takes Double
                // (not Float) for temperature and topP. The `f` suffix in
                // v4.20.0 caused a compile error. topK is Int and stays.
                temperature = 0.4,
                topK = 40,
                topP = 0.95
            )
        )
        conversation = newEngine.createConversation(convConfig)
        engine = newEngine
        loadedModelPathInternal = modelPath
    }

    /**
     * Generate a streaming response to [prompt]. The returned Flow emits
     * tokens (or short token-chunks) as the model produces them. The Flow
     * completes when generation is done.
     *
     * Each call creates a fresh Conversation so previous Q&A doesn't
     * pollute context. The user's default preference (per Settings) is
     * "fresh per question"; multi-turn mode would route through a
     * different code path that reuses the same Conversation across calls.
     *
     * Throws [IllegalStateException] if [load] hasn't been called.
     */
    fun generate(prompt: String): Flow<String> = flow {
        val conv = conversation
            ?: throw IllegalStateException(
                "LlmManager.generate called before load — call load(modelPath) first"
            )
        // Note: we don't `lock.withLock` the streaming itself — that would
        // hold the mutex for the entire generation (potentially minutes).
        // We rely on callers / UI not to invoke generate() concurrently;
        // the chat UI in Stage 5 will enforce one-at-a-time via a busy
        // flag in the ViewModel.
        conv.sendMessageAsync(prompt).collect { chunk ->
            emit(chunk.toString())
        }
    }

    /**
     * Release the engine and conversation, freeing the native memory
     * they hold. Safe to call when not loaded — no-op in that case.
     *
     * MUST be called when leaving the chat screen. Without this, the
     * model sits in RAM forever and the app's footprint stays ~1.5 GB
     * higher than necessary, which can get it killed by Android's
     * low-memory killer.
     */
    suspend fun unload() = lock.withLock {
        // v5.4.116cc — Give the native `callback_thread` a beat to
        // drain its final callback before we free the session.
        //
        // LiteRT-LM's `sendMessageAsync` Flow can hand control back to
        // Java after the token stream ends but BEFORE its native
        // producer thread has finished its cleanup callback. If we
        // close the Conversation while that callback is still in
        // flight, the native thread dispatches through freed memory
        // and the process dies with:
        //
        //   Fatal signal 11 (SIGSEGV), code 1 (SEGV_MAPERR),
        //   fault addr 0x0 in tid N (callback_thread)
        //
        // v5.4.117cc — The delay-and-close pair MUST be non-
        // cancellable. mapLatest in the search pipeline cancels the
        // in-flight mapper on every keystroke, which cancels this
        // coroutine mid-delay. Without the NonCancellable block below,
        // the coroutine throws CancellationException at delay(),
        // withLock releases the mutex, and closeInternal never runs.
        // The next search then finds `engine != null` with a stale,
        // never-closed native session — LlmManager.load's fast-path
        // reuses it, generate() hangs on the wedged session forever,
        // and the search UI shows "searching…" indefinitely because
        // `LlmManager.generate` never emits and the mapper's
        // withTimeout doesn't fire (the coroutine is stuck in the
        // native call). Wrapping in NonCancellable guarantees a full
        // teardown even under cancellation, so the next search starts
        // from a clean state.
        //
        // v5.4.137cc — Bumped the drain delay from 120 ms to 600 ms.
        // Field reports on Qwen 3 0.6B and Phi-4-mini showed the
        // SIGSEGV still happening intermittently at 120 ms; those
        // heavier models' native shutdown windows are longer than
        // SmolLM2's (more callbacks in flight, larger contexts to
        // free). 600 ms adds negligible perceived latency (unload
        // runs after generation, not before results paint) but gives
        // callback_thread a comfortable margin to finish its final
        // dispatch on every model in the catalog. Verified locally
        // to eliminate the crash on all three models under
        // cancel-mid-generate stress.
        kotlinx.coroutines.withContext(kotlinx.coroutines.NonCancellable) {
            kotlinx.coroutines.delay(600L)
            closeInternal()
        }
    }

    /** Internal close — caller must already hold [lock]. */
    private fun closeInternal() {
        runCatching { conversation?.close() }
        runCatching { engine?.close() }
        conversation = null
        engine = null
        loadedModelPathInternal = null
    }
}
