package com.tebogo.markvault.ai

/**
 * Retrieval routing only. No chat generation.
 */
object RagRetrievalPipeline {

    fun buildQueries(query: String): List<String> {
        if (!AiSearchSettings.isEnabled()) {
            return listOf(query)
        }
        // Local model bridge will expand this in inference layer.
        return listOf(query)
    }
}
