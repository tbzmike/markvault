package com.tebogo.markvault.ai

/**
 * v5.4.81 — Unified retrieval entry point.
 *
 * Keeps the original query first and safely applies AI expansion.
 */
object RagRetrievalPipeline {

    suspend fun buildQueries(query: String): List<String> {
        val original = query.trim()
        if (original.isEmpty()) return emptyList()

        if (!AiSearchSettings.isEnabled() ||
            MultiQueryPreference.getCount() <= 0) {
            return listOf(original)
        }

        return try {
            val expanded = LocalAIProviderManager
                .acquire()
                .expandQuery(original)

            LocalAIProviderManager.release()

            (listOf(original) + expanded)
                .map { it.trim() }
                .filter { it.isNotEmpty() }
                .distinct()
                .take(6)
        } catch (_: Exception) {
            LocalAIProviderManager.release()
            listOf(original)
        }
    }
}
