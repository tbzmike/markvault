package com.tebogo.markvault.ai

/**
 * v5.4.76 — Protected LLM expansion lifecycle.
 *
 * Update 7:
 * Ensures expansion happens inside the inference lock and releases
 * the provider after use.
 */
object RagRetrievalPipeline {

    suspend fun buildQueries(query: String): List<String> {
        if (!AiSearchSettings.isEnabled()) {
            return listOf(query)
        }

        return RetrievalModelManager.withInferenceLock {
            val provider = LocalAIProviderManager.acquire()
            try {
                provider.expandQuery(query)
            } finally {
                LocalAIProviderManager.release()
            }
        }
    }
}
