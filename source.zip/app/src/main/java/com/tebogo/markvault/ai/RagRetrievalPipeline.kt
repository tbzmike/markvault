package com.tebogo.markvault.ai

/**
 * v5.4.82 — Memory-safe retrieval expansion.
 *
 * LLM expansion is isolated from embedding retrieval.
 */
object RagRetrievalPipeline {

    suspend fun buildQueries(query: String): List<String> {
        val original = query.trim()
        if (original.isEmpty()) return emptyList()

        if (!AiSearchSettings.isEnabled() ||
            MultiQueryPreference.getCount() <= 0) {
            return listOf(original)
        }

        return try {
            val provider = LocalAIProviderManager.acquire()
            val expanded = try {
                provider.expandQuery(original)
            } finally {
                LocalAIProviderManager.release()
            }

            (listOf(original) + expanded)
                .map { it.trim() }
                .filter { it.isNotEmpty() }
                .distinct()
                .take(6)

        } catch (_: Exception) {
            LocalAIProviderManager.release()
            listOf(original)
        }
    }
}
