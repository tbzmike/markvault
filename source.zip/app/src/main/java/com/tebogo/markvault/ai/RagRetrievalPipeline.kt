package com.tebogo.markvault.ai

/**
 * v5.4.60 — Retrieval routing with protected expansion stage.
 */
object RagRetrievalPipeline {

    suspend fun buildQueries(query: String): List<String> {
        if (!AiSearchSettings.isEnabled()) {
            return listOf(query)
        }

        return RetrievalModelManager.withInferenceLock {
            expandWithLocalModel(query)
        }
    }

    private fun expandWithLocalModel(query: String): List<String> {
        // Local model bridge will load, expand, then unload the LLM.
        return listOf(query)
    }
}
