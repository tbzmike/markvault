package com.tebogo.markvault.ai

/**
 * v5.4.80 — Reliable AI expansion pipeline.
 *
 * Falls back safely when the local LLM is unavailable.
 */
object RagRetrievalPipeline {

    suspend fun buildQueries(query: String): List<String> {
        if (!AiSearchSettings.isEnabled()) {
            return listOf(query)
        }

        return RetrievalModelManager.withInferenceLock {
            try {
                val provider = LocalAIProviderManager.acquire()
                try {
                    val expanded = provider.expandQuery(query)
                    if (expanded.isEmpty()) listOf(query)
                    else expanded.distinct()
                } finally {
                    LocalAIProviderManager.release()
                }
            } catch (_: Exception) {
                // Never damage normal semantic search because AI expansion failed.
                listOf(query)
            }
        }
    }
}
