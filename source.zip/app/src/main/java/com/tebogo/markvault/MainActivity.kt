package com.tebogo.markvault

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import com.tebogo.markvault.ui.HomeScreen
import com.tebogo.markvault.ui.BrowseScreen
import com.tebogo.markvault.ui.ReaderScreen
import com.tebogo.markvault.ui.SearchScreen
import com.tebogo.markvault.ui.SettingsScreen
import com.tebogo.markvault.ui.TopicDetailScreen
import com.tebogo.markvault.ui.TopicsScreen

private val AmoledColors = darkColorScheme(
    primary = Color(0xFF8AB4F8),
    onPrimary = Color(0xFF00264D),
    secondary = Color(0xFF9AD0B0),
    onSecondary = Color(0xFF06281A),
    background = Color(0xFF000000),
    onBackground = Color(0xFFE6E6E6),
    surface = Color(0xFF0B0F14),
    onSurface = Color(0xFFE6E6E6),
    surfaceVariant = Color(0xFF161C23),
    onSurfaceVariant = Color(0xFFAEB9C4),
    outline = Color(0xFF3A434D)
)

@Composable
fun MarkVaultTheme(content: @Composable () -> Unit) {
    MaterialTheme(colorScheme = AmoledColors, content = content)
}

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            MarkVaultTheme {
                Surface(
                    modifier = Modifier.fillMaxSize(),
                    color = MaterialTheme.colorScheme.background
                ) {
                    val nav = rememberNavController()
                    val vm: AppViewModel = viewModel()
                    NavHost(navController = nav, startDestination = "home") {
                        composable("home") { HomeScreen(vm, nav) }
                        composable("browse") { BrowseScreen(vm, nav) }
                        composable("search") { SearchScreen(vm, nav) }
                        composable("topics") { TopicsScreen(vm, nav) }
                        composable("topic/{key}") { backStackEntry ->
                            TopicDetailScreen(vm, nav, backStackEntry.arguments?.getString("key") ?: "")
                        }
                        composable("settings") { SettingsScreen(vm, nav) }
                        composable("reader") { ReaderScreen(vm, nav) }
                    }
                }
            }
        }
    }
}
