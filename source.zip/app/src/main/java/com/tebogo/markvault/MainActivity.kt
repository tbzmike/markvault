package com.tebogo.markvault

import android.content.Intent
import android.os.Build
import android.os.Bundle
import androidx.activity.compose.setContent
import androidx.fragment.app.FragmentActivity
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.WindowInsetsControllerCompat
import androidx.compose.animation.EnterTransition
import androidx.compose.animation.ExitTransition
import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.FiniteAnimationSpec
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInHorizontally
import androidx.compose.animation.slideOutHorizontally
import androidx.compose.foundation.background
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.ColorScheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Shapes
import androidx.compose.material3.Surface
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import com.tebogo.markvault.ui.HomeScreen
import com.tebogo.markvault.ui.MarkVaultLaunchWelcome
import com.tebogo.markvault.ui.BrowseScreen
import com.tebogo.markvault.ui.GraphScreen
import com.tebogo.markvault.ui.PdfHistoryScreen
import com.tebogo.markvault.ui.HtmlReaderScreen
import com.tebogo.markvault.ui.PdfReaderScreen
import com.tebogo.markvault.ui.ReaderScreen
import com.tebogo.markvault.ui.ChatScreen
import com.tebogo.markvault.ui.SearchScreen
import com.tebogo.markvault.ui.SavedSearchesScreen
import com.tebogo.markvault.ui.SettingsScreen
import com.tebogo.markvault.ui.TopicDetailScreen
import com.tebogo.markvault.ui.TopicsScreen
import com.tebogo.markvault.ui.UrlImportScreen
import com.tebogo.markvault.ui.WebPopupFullScreen
import com.tebogo.markvault.ui.FloatingWebViewerHost
import com.tebogo.markvault.ui.SplitReaderScreen
import com.tebogo.markvault.ui.WebBookmarksScreen
import com.tebogo.markvault.ui.WebHistoryScreen
import com.tebogo.markvault.ui.WebSearchScreen
import com.tebogo.markvault.ui.WebSplitScreen
import com.tebogo.markvault.ui.WorkspaceTabletShell
import com.tebogo.markvault.ui.BatchSaveDashboardScreen
import com.tebogo.markvault.ui.DuplicatesScreen
import com.tebogo.markvault.ui.MotionSpecs
import com.tebogo.markvault.ui.UiAnim
import com.tebogo.markvault.ui.rememberEffectiveMotionProfile
import com.tebogo.markvault.ui.customColorSchemeFromJson
import com.tebogo.markvault.ui.obsidianColorSchemeFromPayload
import com.tebogo.markvault.ui.obsidianShapesFromPayload
import com.tebogo.markvault.ui.obsidianTypographyFromPayload
import com.tebogo.markvault.ui.resolveObsidianDark
import com.tebogo.markvault.data.ObsidianThemePayload
import com.tebogo.markvault.ui.LocalMarkVaultTargetColorScheme
import com.tebogo.markvault.ui.LocalMarkVaultDarkMode
import com.tebogo.markvault.ui.resolveAppDark
import com.tebogo.markvault.ui.LocalObsidianThemeVariables
import com.tebogo.markvault.ui.ArtifactThemeShapes
import com.tebogo.markvault.ui.artifactColorScheme
import com.tebogo.markvault.ui.artifactThemeBackdrop
import com.tebogo.markvault.ui.isArtifactTheme
import com.tebogo.markvault.ui.LocalArtifactThemeName
import kotlinx.coroutines.flow.MutableStateFlow

/* ── Color schemes per user-selectable theme ──
 * Each maps to one of the WebView's `theme-*` body classes so the article
 * viewer and the surrounding app chrome stay visually in sync.
 */
private val GreyDarkColors = darkColorScheme(
    primary = Color(0xFF8AB4F8),
    onPrimary = Color(0xFF00264D),
    secondary = Color(0xFF9AD0B0),
    onSecondary = Color(0xFF06281A),
    tertiary = Color(0xFFE5C07B),
    onTertiary = Color(0xFF3A2A06),
    background = Color(0xFF1C2026),
    onBackground = Color(0xFFE2E6EC),
    surface = Color(0xFF22272F),
    onSurface = Color(0xFFE2E6EC),
    surfaceVariant = Color(0xFF2E343D),
    onSurfaceVariant = Color(0xFFB6BFCB),
    outline = Color(0xFF4A5466),
    outlineVariant = Color(0xFF3D4554)
)

private val AmoledColors = darkColorScheme(
    primary = Color(0xFF8AB4F8),
    onPrimary = Color(0xFF00264D),
    secondary = Color(0xFF9AD0B0),
    onSecondary = Color(0xFF06281A),
    tertiary = Color(0xFFE5C07B),
    onTertiary = Color(0xFF3A2A06),
    background = Color(0xFF000000),
    onBackground = Color(0xFFE6E6E6),
    surface = Color(0xFF0B0F14),
    onSurface = Color(0xFFE6E6E6),
    surfaceVariant = Color(0xFF161C23),
    onSurfaceVariant = Color(0xFFAEB9C4),
    outline = Color(0xFF3A434D),
    outlineVariant = Color(0xFF2A3038)
)

private val SepiaColors = androidx.compose.material3.lightColorScheme(
    primary = Color(0xFF8A5A00),
    onPrimary = Color(0xFFF0EBD8),
    secondary = Color(0xFF7A5A2E),
    onSecondary = Color(0xFFF0EBD8),
    background = Color(0xFFF4ECD8),
    onBackground = Color(0xFF4A3F2F),
    surface = Color(0xFFECE2C8),
    onSurface = Color(0xFF4A3F2F),
    surfaceVariant = Color(0xFFE7DCBF),
    onSurfaceVariant = Color(0xFF7C6F59),
    outline = Color(0xFFB89C5E),
    outlineVariant = Color(0xFFC9B88E)
)

private val LightColors = androidx.compose.material3.lightColorScheme(
    primary = Color(0xFF0969DA),
    onPrimary = Color(0xFFF0ECE4),
    secondary = Color(0xFF1F6FEB),
    onSecondary = Color(0xFFF0ECE4),
    background = Color(0xFFFFFFFF),
    onBackground = Color(0xFF1F2328),
    surface = Color(0xFFF6F8FA),
    onSurface = Color(0xFF1F2328),
    surfaceVariant = Color(0xFFEEF1F4),
    onSurfaceVariant = Color(0xFF57606A),
    outline = Color(0xFF9CA6B2),
    outlineVariant = Color(0xFFB8C0CA)
)

/**
 * v4.16.0 — "Light grey" theme. Distinct from `LightColors` (pure white)
 * and from the dark/sepia families. Designed for users who want a light
 * theme but find pure white too glaring.
 *
 * Contrast spot-checked:
 *   onBackground (#181B1F) on background (#DDE1E5) ≈ 14:1 — AAA
 *   onSurfaceVariant (#2F3438) on surfaceVariant (#C3C9CF) ≈ 10:1 — AAA
 *   onPrimary white on primary navy #1F4D7A ≈ 9.5:1 — AAA
 * All text combinations exceed WCAG AAA (7:1) for body text.
 */
private val LightGreyColors = androidx.compose.material3.lightColorScheme(
    primary = Color(0xFF1F4D7A),          // deep navy — pops on grey
    onPrimary = Color(0xFFF0ECE4),
    secondary = Color(0xFF2D6B4F),        // deep teal accent
    onSecondary = Color(0xFFF0ECE4),
    tertiary = Color(0xFF6B4C1F),         // warm brown
    onTertiary = Color(0xFFF0ECE4),
    background = Color(0xFFDDE1E5),       // light cool grey, not white
    onBackground = Color(0xFF181B1F),     // near-black — maximum readability
    surface = Color(0xFFD2D6DB),          // slightly darker grey for cards
    onSurface = Color(0xFF181B1F),
    surfaceVariant = Color(0xFFC3C9CF),   // cooler grey for chips/inputs
    onSurfaceVariant = Color(0xFF2F3438), // very dark grey
    outline = Color(0xFF6B7178),
    outlineVariant = Color(0xFF98A0A8)
)

/* ── High-contrast dark ── AMOLED black base, maximum-contrast text ── */
private val HiContrastDarkColors = darkColorScheme(
    primary = Color(0xFF66BBFF),
    onPrimary = Color(0xFF000000),
    secondary = Color(0xFF66FF99),
    onSecondary = Color(0xFF000000),
    tertiary = Color(0xFFFFDD55),
    onTertiary = Color(0xFF000000),
    background = Color(0xFF000000),
    onBackground = Color(0xFFECECEC),
    surface = Color(0xFF0A0E14),
    onSurface = Color(0xFFECECEC),
    surfaceVariant = Color(0xFF141A22),
    onSurfaceVariant = Color(0xFFE0E8F0),
    outline = Color(0xFF66BBFF),
    outlineVariant = Color(0xFF335577)
)

/* ── Ocean ── deep blue-grey inspired by midnight water ── */
private val OceanColors = darkColorScheme(
    primary = Color(0xFF56CCF2),
    onPrimary = Color(0xFF002030),
    secondary = Color(0xFF6EDBCF),
    onSecondary = Color(0xFF002828),
    tertiary = Color(0xFFF0B866),
    onTertiary = Color(0xFF2A1800),
    background = Color(0xFF0D2030),
    onBackground = Color(0xFFD8E8F0),
    surface = Color(0xFF122838),
    onSurface = Color(0xFFD8E8F0),
    surfaceVariant = Color(0xFF183040),
    onSurfaceVariant = Color(0xFFAAC4D4),
    outline = Color(0xFF3A6070),
    outlineVariant = Color(0xFF2A4858)
)

/* ── Forest ── dark green canopy ── */
private val ForestColors = darkColorScheme(
    primary = Color(0xFF7EC8A4),
    onPrimary = Color(0xFF00281A),
    secondary = Color(0xFFA8D8B4),
    onSecondary = Color(0xFF08301C),
    tertiary = Color(0xFFD4B870),
    onTertiary = Color(0xFF2A2008),
    background = Color(0xFF142219),
    onBackground = Color(0xFFD8E8DC),
    surface = Color(0xFF1A2C22),
    onSurface = Color(0xFFD8E8DC),
    surfaceVariant = Color(0xFF22362A),
    onSurfaceVariant = Color(0xFFAAC8B4),
    outline = Color(0xFF3A6848),
    outlineVariant = Color(0xFF2A4E38)
)

/* ── Cream ── warm off-white, easy on the eyes ── */
private val CreamColors = androidx.compose.material3.lightColorScheme(
    primary = Color(0xFF7A5A00),
    onPrimary = Color(0xFFF0ECE4),
    secondary = Color(0xFF6A6030),
    onSecondary = Color(0xFFF0ECE4),
    tertiary = Color(0xFF5A6A40),
    onTertiary = Color(0xFFF0ECE4),
    background = Color(0xFFFDF6E3),
    onBackground = Color(0xFF3A3428),
    surface = Color(0xFFF5EDD4),
    onSurface = Color(0xFF3A3428),
    surfaceVariant = Color(0xFFEDE4C8),
    onSurfaceVariant = Color(0xFF6A6050),
    outline = Color(0xFFA89A70),
    outlineVariant = Color(0xFFC4B890)
)

/* ── High-contrast light ── pure white, maximum dark-on-light contrast ── */
private val HiContrastLightColors = androidx.compose.material3.lightColorScheme(
    primary = Color(0xFF0040A0),
    onPrimary = Color(0xFFF0ECE4),
    secondary = Color(0xFF006644),
    onSecondary = Color(0xFFF0ECE4),
    tertiary = Color(0xFF884400),
    onTertiary = Color(0xFFF0ECE4),
    background = Color(0xFFFFFFFF),
    onBackground = Color(0xFF000000),
    surface = Color(0xFFF0F2F5),
    onSurface = Color(0xFF000000),
    surfaceVariant = Color(0xFFE0E4E8),
    onSurfaceVariant = Color(0xFF1A1A1A),
    outline = Color(0xFF0040A0),
    outlineVariant = Color(0xFF6688BB)
)

/* ── v5.4.36 — Grey ── neutral mid-grey, neither light nor dark ── */
private val GreyColors = darkColorScheme(
    primary = Color(0xFF7EADD9),
    onPrimary = Color(0xFF1A2A3A),
    secondary = Color(0xFF88B8A0),
    onSecondary = Color(0xFF1A2A20),
    tertiary = Color(0xFFD4B87A),
    onTertiary = Color(0xFF2A2008),
    background = Color(0xFF606468),
    onBackground = Color(0xFF1A1C1E),
    surface = Color(0xFF6E7276),
    onSurface = Color(0xFF1A1C1E),
    surfaceVariant = Color(0xFF787C80),
    onSurfaceVariant = Color(0xFF2A2C2E),
    outline = Color(0xFF4A4E52),
    outlineVariant = Color(0xFF545860)
)

/* ── v5.4.36 — Darker Sepia ── warmer, deeper sepia for low-light reading ── */
private val DarkSepiaColors = darkColorScheme(
    primary = Color(0xFFD4A55A),
    onPrimary = Color(0xFF2A1A06),
    secondary = Color(0xFFC49856),
    onSecondary = Color(0xFF2A1A06),
    tertiary = Color(0xFFA88A60),
    onTertiary = Color(0xFF1A1206),
    background = Color(0xFF3A3028),
    onBackground = Color(0xFFE8DCC8),
    surface = Color(0xFF44382E),
    onSurface = Color(0xFFE8DCC8),
    surfaceVariant = Color(0xFF504234),
    onSurfaceVariant = Color(0xFFCCBDA8),
    outline = Color(0xFF7A6A50),
    outlineVariant = Color(0xFF5A4C3A)
)

/* ── v5.4.36 — Sky Blue ── gentle light-blue background ── */
private val SkyBlueColors = androidx.compose.material3.lightColorScheme(
    primary = Color(0xFF1565C0),
    onPrimary = Color(0xFFF0ECE4),
    secondary = Color(0xFF2E7D32),
    onSecondary = Color(0xFFF0ECE4),
    tertiary = Color(0xFF8D6E00),
    onTertiary = Color(0xFFF0ECE4),
    background = Color(0xFFD6EAFF),
    onBackground = Color(0xFF1A2A3A),
    surface = Color(0xFFC8DEFA),
    onSurface = Color(0xFF1A2A3A),
    surfaceVariant = Color(0xFFB8D2F0),
    onSurfaceVariant = Color(0xFF2A3A4A),
    outline = Color(0xFF6A8AAA),
    outlineVariant = Color(0xFF8AA8C8)
)

/* ══════════════════════════════════════════════════════════════════
 * v5.4.114cc — Expressive theme pack
 *
 * Four new high-contrast schemes in the Material 3 Expressive spirit:
 * confident, saturated primaries with warm accent tertiaries. They
 * slot into the same `themeName` switch below as ordinary themes, so
 * they work with or without the motion plugin — a theme is just a
 * colour scheme, no behaviour attached. Each fills the container roles
 * too (primaryContainer / secondaryContainer / tertiaryContainer /
 * errorContainer) because the pill/badge/skip UIs added in recent
 * versions read those roles; the app's older schemes let them
 * auto-derive, which these improve on.
 * ════════════════════════════════════════════════════════════════════ */

/* ── Expressive Indigo (dark) ── ink-on-study-notes ── */
private val ExprIndigoColors = darkColorScheme(
    primary = Color(0xFFB8BCFF),
    onPrimary = Color(0xFF080C5E),
    primaryContainer = Color(0xFF222674),
    onPrimaryContainer = Color(0xFFE1E0FF),
    secondary = Color(0xFFF0C04C),
    onSecondary = Color(0xFF3F2E00),
    secondaryContainer = Color(0xFF5C4300),
    onSecondaryContainer = Color(0xFFFFDF9E),
    tertiary = Color(0xFFA1D0CB),
    onTertiary = Color(0xFF003733),
    tertiaryContainer = Color(0xFF214B49),
    onTertiaryContainer = Color(0xFFBCECE7),
    error = Color(0xFFFFB4AB),
    onError = Color(0xFF690005),
    errorContainer = Color(0xFF93000A),
    onErrorContainer = Color(0xFFFFDAD6),
    background = Color(0xFF15151A),
    onBackground = Color(0xFFE4E1E6),
    surface = Color(0xFF1B1B22),
    onSurface = Color(0xFFE4E1E6),
    surfaceVariant = Color(0xFF2A2A38),
    onSurfaceVariant = Color(0xFFC7C5D0),
    outline = Color(0xFF6A6A80),
    outlineVariant = Color(0xFF3A3A48),
    inverseSurface = Color(0xFFE4E1E6),
    inverseOnSurface = Color(0xFF303034),
    inversePrimary = Color(0xFF3B3F8C)
)

/* ── Expressive Violet (light) ── bright, clean ── */
private val ExprVioletColors = androidx.compose.material3.lightColorScheme(
    primary = Color(0xFF5B3FA0),
    onPrimary = Color(0xFFFFFFFF),
    primaryContainer = Color(0xFFE9DDFF),
    onPrimaryContainer = Color(0xFF1D0060),
    secondary = Color(0xFF9A4A00),
    onSecondary = Color(0xFFFFFFFF),
    secondaryContainer = Color(0xFFFFDCC5),
    onSecondaryContainer = Color(0xFF321300),
    tertiary = Color(0xFF006A63),
    onTertiary = Color(0xFFFFFFFF),
    tertiaryContainer = Color(0xFF9EF2E7),
    onTertiaryContainer = Color(0xFF00201D),
    error = Color(0xFFBA1A1A),
    onError = Color(0xFFFFFFFF),
    errorContainer = Color(0xFFFFDAD6),
    onErrorContainer = Color(0xFF410002),
    background = Color(0xFFFDF7FF),
    onBackground = Color(0xFF1C1B1F),
    surface = Color(0xFFFDF7FF),
    onSurface = Color(0xFF1C1B1F),
    surfaceVariant = Color(0xFFE7E0EB),
    onSurfaceVariant = Color(0xFF49454E),
    outline = Color(0xFF7A757F),
    outlineVariant = Color(0xFFCAC4CF),
    inverseSurface = Color(0xFF313033),
    inverseOnSurface = Color(0xFFF4EFF4),
    inversePrimary = Color(0xFFCFBCFF)
)

/* ── Expressive Ember (dark) ── warm charcoal + amber ── */
private val ExprEmberColors = darkColorScheme(
    primary = Color(0xFFFFB68A),
    onPrimary = Color(0xFF4E2600),
    primaryContainer = Color(0xFF6F3900),
    onPrimaryContainer = Color(0xFFFFDBC7),
    secondary = Color(0xFFE6C08D),
    onSecondary = Color(0xFF412D05),
    secondaryContainer = Color(0xFF5A431A),
    onSecondaryContainer = Color(0xFFFFDDB0),
    tertiary = Color(0xFFB4CF9A),
    onTertiary = Color(0xFF203710),
    tertiaryContainer = Color(0xFF364E24),
    onTertiaryContainer = Color(0xFFD0EBB4),
    error = Color(0xFFFFB4AB),
    onError = Color(0xFF690005),
    errorContainer = Color(0xFF93000A),
    onErrorContainer = Color(0xFFFFDAD6),
    background = Color(0xFF1A140F),
    onBackground = Color(0xFFF0E0D4),
    surface = Color(0xFF211A14),
    onSurface = Color(0xFFF0E0D4),
    surfaceVariant = Color(0xFF332821),
    onSurfaceVariant = Color(0xFFD8C4B4),
    outline = Color(0xFF7A6A5A),
    outlineVariant = Color(0xFF453A30),
    inverseSurface = Color(0xFFF0E0D4),
    inverseOnSurface = Color(0xFF33291F),
    inversePrimary = Color(0xFF8B5000)
)

/* ── Expressive Rose (light) ── soft warm paper + rose ── */
private val ExprRoseColors = androidx.compose.material3.lightColorScheme(
    primary = Color(0xFFB0295E),
    onPrimary = Color(0xFFFFFFFF),
    primaryContainer = Color(0xFFFFD9E1),
    onPrimaryContainer = Color(0xFF3E001C),
    secondary = Color(0xFF745668),
    onSecondary = Color(0xFFFFFFFF),
    secondaryContainer = Color(0xFFFFD9E9),
    onSecondaryContainer = Color(0xFF2B1523),
    tertiary = Color(0xFF7E5700),
    onTertiary = Color(0xFFFFFFFF),
    tertiaryContainer = Color(0xFFFFDDAE),
    onTertiaryContainer = Color(0xFF281800),
    error = Color(0xFFBA1A1A),
    onError = Color(0xFFFFFFFF),
    errorContainer = Color(0xFFFFDAD6),
    onErrorContainer = Color(0xFF410002),
    background = Color(0xFFFFF8F7),
    onBackground = Color(0xFF22191C),
    surface = Color(0xFFFFF8F7),
    onSurface = Color(0xFF22191C),
    surfaceVariant = Color(0xFFF2DDE2),
    onSurfaceVariant = Color(0xFF514347),
    outline = Color(0xFF837377),
    outlineVariant = Color(0xFFD5C2C6),
    inverseSurface = Color(0xFF382E31),
    inverseOnSurface = Color(0xFFFDEDEF),
    inversePrimary = Color(0xFFFFB1C6)
)

/* ── v5.4.284cc — 3D Glass theme family ───────────────────────────────
 * Two complete global palettes.  The visual depth comes from deliberately
 * separated background/surface/surfaceVariant/container tones, strong edge
 * colors and the global rounded Material shapes below.  Markdown/HTML gets
 * the matching glass treatment through viewer.css + ThemeBridge.
 */
private val GlassObsidianColors = darkColorScheme(
    primary = Color(0xFF8B7CFF),
    onPrimary = Color(0xFF0B0820),
    primaryContainer = Color(0xFF29205A),
    onPrimaryContainer = Color(0xFFE8E4FF),
    secondary = Color(0xFF39D5FF),
    onSecondary = Color(0xFF001F29),
    secondaryContainer = Color(0xFF0E3B4A),
    onSecondaryContainer = Color(0xFFD7F7FF),
    tertiary = Color(0xFFB8A7FF),
    onTertiary = Color(0xFF1D103F),
    tertiaryContainer = Color(0xFF382B68),
    onTertiaryContainer = Color(0xFFEEE9FF),
    background = Color(0xFF080B12),
    onBackground = Color(0xFFE9EDF7),
    surface = Color(0xFF101621),
    onSurface = Color(0xFFE9EDF7),
    surfaceVariant = Color(0xFF182132),
    onSurfaceVariant = Color(0xFFB8C2D7),
    outline = Color(0xFF69758E),
    outlineVariant = Color(0xFF354159),
    inverseSurface = Color(0xFFE9EDF7),
    inverseOnSurface = Color(0xFF151A24),
    inversePrimary = Color(0xFF5142C5)
)

private val GlassCrystalColors = androidx.compose.material3.lightColorScheme(
    primary = Color(0xFF5546D8),
    onPrimary = Color(0xFFFFFFFF),
    primaryContainer = Color(0xFFE6E0FF),
    onPrimaryContainer = Color(0xFF21175D),
    secondary = Color(0xFF007E9E),
    onSecondary = Color(0xFFFFFFFF),
    secondaryContainer = Color(0xFFCDEFFC),
    onSecondaryContainer = Color(0xFF003642),
    tertiary = Color(0xFF7057C6),
    onTertiary = Color(0xFFFFFFFF),
    tertiaryContainer = Color(0xFFE9DEFF),
    onTertiaryContainer = Color(0xFF29145E),
    background = Color(0xFFF3F6FC),
    onBackground = Color(0xFF18202C),
    surface = Color(0xFFFFFFFF),
    onSurface = Color(0xFF18202C),
    surfaceVariant = Color(0xFFE7ECF5),
    onSurfaceVariant = Color(0xFF485568),
    outline = Color(0xFF77859A),
    outlineVariant = Color(0xFFC5CFDE),
    inverseSurface = Color(0xFF2D3440),
    inverseOnSurface = Color(0xFFF1F4FA),
    inversePrimary = Color(0xFFBFC3FF)
)

private val Glass3DShapes = Shapes(
    extraSmall = RoundedCornerShape(10.dp),
    small = RoundedCornerShape(14.dp),
    medium = RoundedCornerShape(18.dp),
    large = RoundedCornerShape(24.dp),
    extraLarge = RoundedCornerShape(30.dp)
)

private val ObsidianColors = darkColorScheme(
    primary = Color(0xFF7EC8A4),
    onPrimary = Color(0xFF10251C),
    secondary = Color(0xFFE8A87C),
    onSecondary = Color(0xFF3A2114),
    tertiary = Color(0xFFB088D0),
    onTertiary = Color(0xFF25142F),
    background = Color(0xFF1E1E1E),
    onBackground = Color(0xFFDCDDDE),
    surface = Color(0xFF252525),
    onSurface = Color(0xFFDCDDDE),
    surfaceVariant = Color(0xFF2D2D2D),
    onSurfaceVariant = Color(0xFFAAAAAA),
    outline = Color(0xFF555555),
    outlineVariant = Color(0xFF444444)
)

private fun enforceAppAppearance(scheme: ColorScheme, dark: Boolean): ColorScheme {
    val bg = scheme.background
    val perceived = 0.2126f * bg.red + 0.7152f * bg.green + 0.0722f * bg.blue
    val alreadyMatches = if (dark) perceived < 0.50f else perceived >= 0.50f
    return if (alreadyMatches) scheme else if (dark) GreyDarkColors else LightColors
}

@Composable
fun MarkVaultTheme(
    themeName: String? = null,
    customThemeJson: String = "",
    obsidianThemePayload: ObsidianThemePayload? = null,
    obsidianAppearanceMode: String = "system",
    appAppearanceMode: String = "system",
    fontScale: Float = 1.0f,
    // v5.4.114cc — Expressive motion plugin params. Both default to the
    // disabled state, so any existing call to MarkVaultTheme that
    // doesn't pass them behaves exactly as before — the motion provider
    // installs OFF specs, which are no-ops. Only MainActivity passes
    // real values from the VM.
    motionEnabled: Boolean = false,
    motionProfileName: String = "EXPRESSIVE",
    // v5.4.162cc — UI Animations master toggle + speed. Defaults match
    // Prefs' defaults (enabled, normal speed) so any call to
    // MarkVaultTheme that doesn't pass these still animates normally
    // rather than going inert. Only MainActivity's real setContent call
    // passes live values from the VM.
    uiAnimEnabled: Boolean = true,
    uiAnimSpeed: Float = 1.0f,
    uiAnimStyleName: String = "BOUNCE",
    content: @Composable () -> Unit
) {
    val artifactScheme = artifactColorScheme(themeName)
    val baseScheme = artifactScheme ?: when (themeName) {
        "black"            -> AmoledColors
        "hicontrast-dark"  -> HiContrastDarkColors
        "ocean"            -> OceanColors
        "forest"           -> ForestColors
        "sepia"            -> SepiaColors
        "dark_sepia"       -> DarkSepiaColors
        "cream"            -> CreamColors
        "light_grey"       -> LightGreyColors
        "grey"             -> GreyColors
        "sky_blue"         -> SkyBlueColors
        "expr_indigo"      -> ExprIndigoColors
        "expr_violet"      -> ExprVioletColors
        "expr_ember"       -> ExprEmberColors
        "expr_rose"        -> ExprRoseColors
        "light"            -> LightColors
        "hicontrast-light" -> HiContrastLightColors
        "obsidian"         -> ObsidianColors
        "glass_obsidian"   -> GlassObsidianColors
        "glass_crystal"    -> GlassCrystalColors
        else               -> GreyDarkColors          // "dark" or null → proper grey dark
    }
    val systemDark = isSystemInDarkTheme()
    val appDark = resolveAppDark(appAppearanceMode, systemDark)
    // Universal appearance is authoritative. Obsidian themes receive the same
    // variant request as the rest of MarkVault instead of keeping a separate
    // per-theme light/dark state.
    val effectiveObsidianDark = appDark
    val themedScheme = when (themeName) {
        "custom" -> customColorSchemeFromJson(baseScheme, customThemeJson)
        "obsidian_imported" -> obsidianColorSchemeFromPayload(
            if (effectiveObsidianDark) baseScheme else LightColors,
            obsidianThemePayload,
            effectiveObsidianDark
        )
        else -> baseScheme
    }
    val scheme = enforceAppAppearance(themedScheme, appDark)
    val importedTypography = if (themeName == "obsidian_imported") {
        obsidianTypographyFromPayload(MaterialTheme.typography, obsidianThemePayload, effectiveObsidianDark)
    } else MaterialTheme.typography
    // v4.16.0 — Global font-size adjustment.
    //
    // We multiply the system Density's fontScale by the user's preference,
    // then provide that as LocalDensity for every Composable under this
    // theme. Every `Text(...)` in the app — including dialogs, menus,
    // bottom bars, settings — picks the new size up automatically because
    // sp resolution goes through LocalDensity. Icons specified in dp are
    // unaffected, which is exactly the behaviour we want.
    //
    // Clamping is done at the call site (Prefs slider 0.7–1.5); this
    // function trusts the value but caps it defensively to keep extreme
    // values from breaking layout entirely.
    val safeScale = fontScale.coerceIn(0.7f, 1.5f)
    val baseDensity = androidx.compose.ui.platform.LocalDensity.current
    val scaledDensity = androidx.compose.ui.unit.Density(
        density = baseDensity.density,
        fontScale = baseDensity.fontScale * safeScale
    )
    androidx.compose.runtime.CompositionLocalProvider(
        androidx.compose.ui.platform.LocalDensity provides scaledDensity,
        LocalMarkVaultTargetColorScheme provides scheme,
        LocalMarkVaultDarkMode provides appDark,
        LocalArtifactThemeName provides themeName,
        LocalObsidianThemeVariables provides if (themeName == "obsidian_imported") {
            if (effectiveObsidianDark) obsidianThemePayload?.darkVariables.orEmpty()
            else obsidianThemePayload?.lightVariables.orEmpty()
        } else emptyMap()
    ) {
        // v5.4.161cc — Color transition on theme switch. Previously,
        // `scheme` (a brand-new ColorScheme object every time themeName
        // changes) was passed straight into MaterialTheme, so EVERY
        // MaterialTheme.colorScheme.* read throughout the entire app
        // snapped to the new theme's colors on the same frame — jarring
        // for a deliberate action like picking a new theme in Settings.
        //
        // Resolves the SAME effective motion profile ProvideAppMotion
        // will install just below (same helper, same logic — see
        // rememberEffectiveMotionProfile's doc comment), so this respects
        // the user's "Expressive motion" setting AND the OS-level
        // "remove animations" accessibility toggle, same as everything
        // else that reads AppMotion. Computed here (before
        // MaterialTheme/ProvideAppMotion exist) because animateColorScheme
        // needs the resolved spec, and AppMotion's CompositionLocal isn't
        // available until one line further down.
        val themeEffectiveProfile = rememberEffectiveMotionProfile(motionEnabled, motionProfileName)
        val themeMotionSpecs = remember(themeEffectiveProfile) { MotionSpecs.forProfile(themeEffectiveProfile) }
        val animatedScheme = animateColorScheme(scheme, themeMotionSpecs.colorSpec)
        val glass3d = themeName == "glass_obsidian" || themeName == "glass_crystal"
        val artifactTheme = isArtifactTheme(themeName)
        MaterialTheme(
            colorScheme = animatedScheme,
            typography = importedTypography,
            shapes = when {
                glass3d -> Glass3DShapes
                artifactTheme -> ArtifactThemeShapes
                themeName == "obsidian_imported" -> obsidianShapesFromPayload(obsidianThemePayload, effectiveObsidianDark)
                else -> MaterialTheme.shapes
            }
        ) {
            // v5.4.114cc — Install the motion plugin INSIDE the theme so
            // components can read both MaterialTheme.* and AppMotion.*.
            // When motionEnabled is false this provides OFF specs (pure
            // no-op), so the app is byte-for-byte unchanged in behaviour.
            com.tebogo.markvault.ui.ProvideAppMotion(
                enabled = motionEnabled,
                profileName = motionProfileName
            ) {
                // v5.4.162cc — Separate UI Animations system (see
                // UiAnimPrefs.kt doc comment for why this is independent
                // of ProvideAppMotion above).
                com.tebogo.markvault.ui.ProvideUiAnimPrefs(
                    enabled = uiAnimEnabled,
                    speed = uiAnimSpeed,
                    styleName = uiAnimStyleName,
                    content = content
                )
            }
        }
    }
}

/**
 * v5.4.161cc — Smoothly animates every field of a ColorScheme toward
 * [target] using [spec], so switching themes cross-fades each color
 * instead of every MaterialTheme.colorScheme.* consumer in the app
 * snapping to the new value on the same frame.
 *
 * Deliberately animates the ~27 "classic" ColorScheme fields that have
 * existed since Material3 1.0 and that this app's own color scheme
 * definitions above actually set (container variants for primary/
 * secondary/tertiary, background/surface variants, outline, error, and
 * the three inverse-* fields the Expressive rose/violet schemes use). A
 * handful of newer, rarely-touched fields (surfaceTint, scrim, the
 * surfaceContainer* tier, surfaceBright/Dim) are intentionally left
 * un-animated — ColorScheme.copy() defaults any field not explicitly
 * passed to [target]'s own value, so those fields still correctly reach
 * the new theme, just without an animated transition. Since this app's
 * own UI code doesn't directly reference those fields, the visible
 * result still reads as a complete, smooth transition.
 *
 * Does NOT duplicate or crossfade the app's composition tree the way
 * wrapping `content()` in a Crossfade would — [content] is called
 * exactly once, exactly as before. Only the ColorScheme VALUES feed
 * into MaterialTheme change smoothly, via ordinary recomposition, the
 * same mechanism any other animated State already used throughout this
 * app relies on. This matters because `content()` here is the entire
 * app's NavHost — every screen, every WebView, every ViewModel-held
 * navigation and scroll state — and duplicating that subtree even
 * briefly would risk real state and performance problems.
 */
@Composable
private fun animateColorScheme(
    target: ColorScheme,
    spec: FiniteAnimationSpec<Color>
): ColorScheme {
    val primary by animateColorAsState(target.primary, spec, label = "primary")
    val onPrimary by animateColorAsState(target.onPrimary, spec, label = "onPrimary")
    val primaryContainer by animateColorAsState(target.primaryContainer, spec, label = "primaryContainer")
    val onPrimaryContainer by animateColorAsState(target.onPrimaryContainer, spec, label = "onPrimaryContainer")
    val secondary by animateColorAsState(target.secondary, spec, label = "secondary")
    val onSecondary by animateColorAsState(target.onSecondary, spec, label = "onSecondary")
    val secondaryContainer by animateColorAsState(target.secondaryContainer, spec, label = "secondaryContainer")
    val onSecondaryContainer by animateColorAsState(target.onSecondaryContainer, spec, label = "onSecondaryContainer")
    val tertiary by animateColorAsState(target.tertiary, spec, label = "tertiary")
    val onTertiary by animateColorAsState(target.onTertiary, spec, label = "onTertiary")
    val tertiaryContainer by animateColorAsState(target.tertiaryContainer, spec, label = "tertiaryContainer")
    val onTertiaryContainer by animateColorAsState(target.onTertiaryContainer, spec, label = "onTertiaryContainer")
    val background by animateColorAsState(target.background, spec, label = "background")
    val onBackground by animateColorAsState(target.onBackground, spec, label = "onBackground")
    val surface by animateColorAsState(target.surface, spec, label = "surface")
    val onSurface by animateColorAsState(target.onSurface, spec, label = "onSurface")
    val surfaceVariant by animateColorAsState(target.surfaceVariant, spec, label = "surfaceVariant")
    val onSurfaceVariant by animateColorAsState(target.onSurfaceVariant, spec, label = "onSurfaceVariant")
    val outline by animateColorAsState(target.outline, spec, label = "outline")
    val outlineVariant by animateColorAsState(target.outlineVariant, spec, label = "outlineVariant")
    val error by animateColorAsState(target.error, spec, label = "error")
    val onError by animateColorAsState(target.onError, spec, label = "onError")
    val errorContainer by animateColorAsState(target.errorContainer, spec, label = "errorContainer")
    val onErrorContainer by animateColorAsState(target.onErrorContainer, spec, label = "onErrorContainer")
    val inverseSurface by animateColorAsState(target.inverseSurface, spec, label = "inverseSurface")
    val inverseOnSurface by animateColorAsState(target.inverseOnSurface, spec, label = "inverseOnSurface")
    val inversePrimary by animateColorAsState(target.inversePrimary, spec, label = "inversePrimary")

    return target.copy(
        primary = primary,
        onPrimary = onPrimary,
        primaryContainer = primaryContainer,
        onPrimaryContainer = onPrimaryContainer,
        secondary = secondary,
        onSecondary = onSecondary,
        secondaryContainer = secondaryContainer,
        onSecondaryContainer = onSecondaryContainer,
        tertiary = tertiary,
        onTertiary = onTertiary,
        tertiaryContainer = tertiaryContainer,
        onTertiaryContainer = onTertiaryContainer,
        background = background,
        onBackground = onBackground,
        surface = surface,
        onSurface = onSurface,
        surfaceVariant = surfaceVariant,
        onSurfaceVariant = onSurfaceVariant,
        outline = outline,
        outlineVariant = outlineVariant,
        error = error,
        onError = onError,
        errorContainer = errorContainer,
        onErrorContainer = onErrorContainer,
        inverseSurface = inverseSurface,
        inverseOnSurface = inverseOnSurface,
        inversePrimary = inversePrimary
    )
}

/**
 * If the launching Intent is an ACTION_SEND of text/plain whose body is a URL,
 * return that URL — otherwise null. This is what Chrome / Firefox / JW Library /
 * etc. send when the user picks our app from the share sheet.
 */
private fun extractSharedUrl(intent: Intent?): String? {
    if (intent == null) return null
    if (intent.action != Intent.ACTION_SEND) return null
    val text = intent.getStringExtra(Intent.EXTRA_TEXT)?.trim() ?: return null
    if (text.isEmpty()) return null
    if (text.startsWith("http://", ignoreCase = true) ||
        text.startsWith("https://", ignoreCase = true)) {
        return text
    }
    // Some apps share a text caption first and the URL second. Find a URL token.
    return text.split(Regex("\\s+")).firstOrNull {
        it.startsWith("http://", ignoreCase = true) ||
        it.startsWith("https://", ignoreCase = true)
    }
}

/**
 * v5.4.12 — Extract a URL from an ACTION_VIEW intent (i.e. the user
 * tapped a link in another app and Android showed MarkVault in the
 * "Open with" chooser). Distinct from [extractSharedUrl] in two ways:
 *
 *  • Action is VIEW, not SEND. The URL lives in `intent.data`, not
 *    `EXTRA_TEXT`.
 *  • Host is whitelisted. Only jw.org and wol.jw.org URLs are claimed.
 *    The manifest filter already enforces this, but we double-check
 *    in case a malformed intent slips through.
 *
 * VIEW intents go straight to the in-app browser — no chooser screen,
 * because the user already chose by tapping the link.
 */
private fun extractViewBrowserUrl(intent: Intent?): String? {
    if (intent == null) return null
    if (intent.action != Intent.ACTION_VIEW) return null
    val data = intent.data ?: return null
    val scheme = data.scheme?.lowercase() ?: return null
    if (scheme != "http" && scheme != "https") return null
    val host = data.host?.lowercase() ?: return null
    val allowed = host == "jw.org" || host == "wol.jw.org" ||
        host.endsWith(".jw.org") || host.endsWith(".wol.jw.org")
    if (!allowed) return null
    return data.toString()
}

/**
 * Extract text to drop into the library search bar.
 *
 * Two intent paths route here:
 *
 *  • **ACTION_PROCESS_TEXT** — fires when the user highlights text in any app
 *    and picks MarkVault from the text-selection context menu (the row with
 *    "Copy / Share / Define / …"). The selection lives in
 *    `EXTRA_PROCESS_TEXT_READONLY` (preferred) or `EXTRA_PROCESS_TEXT`.
 *
 *  • **ACTION_SEND** — fires when the user picks MarkVault from the share
 *    sheet. The shared body lives in `EXTRA_TEXT`. We only treat it as a
 *    search query when it is NOT a URL — URLs are still routed through the
 *    existing import/save pipeline by [extractSharedUrl].
 *
 * Returns the trimmed text, or null when neither applies. The length cap
 * (500 chars) keeps the search bar from drowning when a user accidentally
 * selects a whole article.
 */
private fun extractSharedSearchText(intent: Intent?): String? {
    if (intent == null) return null
    val raw = when (intent.action) {
        Intent.ACTION_PROCESS_TEXT -> {
            intent.getCharSequenceExtra(Intent.EXTRA_PROCESS_TEXT_READONLY)?.toString()
                ?: intent.getCharSequenceExtra(Intent.EXTRA_PROCESS_TEXT)?.toString()
        }
        Intent.ACTION_SEND -> {
            // Skip when this share is a URL — that's the import flow's job.
            if (extractSharedUrl(intent) != null) return null
            intent.getStringExtra(Intent.EXTRA_TEXT)
        }
        else -> null
    } ?: return null
    val cleaned = raw.trim().replace(Regex("\\s+"), " ")
    if (cleaned.isEmpty()) return null
    return cleaned.take(500)
}

class MainActivity : FragmentActivity() {
    /** Holds a URL that arrived via a share intent. Read by the composition below. */
    private val pendingSharedUrl = MutableStateFlow<String?>(null)

    /**
     * Holds text that arrived via PROCESS_TEXT (long-press → "Search in MarkVault")
     * or via a non-URL ACTION_SEND share. Consumed once by the composition to
     * populate the search bar and navigate to the Search screen.
     */
    private val pendingSharedSearchText = MutableStateFlow<String?>(null)

    /**
     * v5.4.12 — Holds a URL that arrived via ACTION_VIEW for jw.org /
     * wol.jw.org (user tapped a link in another app, picked MarkVault
     * from the "Open with" chooser). Goes straight to the in-app
     * browser, no chooser screen.
     */
    private val pendingViewBrowserUrl = MutableStateFlow<String?>(null)

    // v5.4.373cc — Search-complete notifications carry the durable saved
    // session id. Keeping it in a StateFlow handles both cold starts and
    // onNewIntent() when the Activity is already alive.
    private val pendingSavedSearchId = MutableStateFlow<String?>(null)

    /**
     * v5.4.112cc — Whether the activity is currently in the foreground.
     * Toggled in onStart/onStop. Used to gate the search-ready
     * notification: only post it when the user can't see the results
     * screen directly.
     */
    @Volatile private var appInForeground: Boolean = true

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        pendingSharedUrl.value = extractSharedUrl(intent)
        pendingSharedSearchText.value = extractSharedSearchText(intent)
        pendingViewBrowserUrl.value = extractViewBrowserUrl(intent)
        pendingSavedSearchId.value = intent?.getStringExtra("open_saved_search_id")
        // v5.4.94cc — Ask for POST_NOTIFICATIONS on Android 13+.
        //
        // Without this the notification channel exists, we call
        // startForeground(...), the service runs — but the notification
        // itself is silently suppressed by the OS. The batch-save
        // progress bar had no way to reach the shade until the user
        // manually enabled notifications in system Settings. This
        // matches what the embedding + model-download services need too
        // (they've been sailing on legacy grants from earlier installs).
        //
        // Request is fire-and-forget: whatever the user picks, the app
        // continues normally. Denied → no notification but the batch
        // save still runs correctly. Granted → the progress bar shows
        // up in the tray like the user expects.
        requestNotificationPermissionIfNeeded()
        setContent {
            // Acquire the vm at the OUTERMOST level so its theme flow can drive
            // both the Compose chrome (MarkVaultTheme) and the WebView CSS.
            val vm: AppViewModel = viewModel()
            val themeName by vm.theme.collectAsStateWithLifecycle()
            val appAppearanceMode by vm.appAppearanceMode.collectAsStateWithLifecycle()
            val appSystemDark = isSystemInDarkTheme()
            val appDark = resolveAppDark(appAppearanceMode, appSystemDark)
            val customThemeJson by vm.customThemeJson.collectAsStateWithLifecycle()
            val activeObsidianTheme by vm.activeObsidianTheme.collectAsStateWithLifecycle()
            val activeObsidianAppearanceMode by vm.activeObsidianAppearanceMode.collectAsStateWithLifecycle()
            val libraryReady by vm.libraryReady.collectAsStateWithLifecycle()
            // v4.16.0 — global font size lives in the same Prefs flow used
            // by the markdown reader. MarkVaultTheme uses it to override
            // LocalDensity so every Compose Text scales together.
            val uiFontScale by vm.fontScale.collectAsStateWithLifecycle()
            // v5.4.114cc — Expressive motion plugin state (default OFF).
            val motionOn by vm.motionEnabled.collectAsStateWithLifecycle()
            val motionProfileName by vm.motionProfile.collectAsStateWithLifecycle()
            // v5.4.162cc — UI Animations state (default ON).
            val uiAnimOn by vm.uiAnimEnabled.collectAsStateWithLifecycle()
            val uiAnimSpeedValue by vm.uiAnimSpeed.collectAsStateWithLifecycle()
            // v5.4.164cc — Animation style pick.
            val uiAnimStyleValue by vm.uiAnimStyle.collectAsStateWithLifecycle()
            val immersiveViewEnabled by vm.immersiveViewEnabled.collectAsStateWithLifecycle()
            DisposableEffect(immersiveViewEnabled, appDark) {
                val controller = WindowCompat.getInsetsController(window, window.decorView)
                @Suppress("DEPRECATION")
                window.statusBarColor = if (appDark) android.graphics.Color.BLACK else android.graphics.Color.WHITE
                @Suppress("DEPRECATION")
                window.navigationBarColor = if (appDark) android.graphics.Color.BLACK else android.graphics.Color.WHITE
                controller.isAppearanceLightStatusBars = !appDark
                controller.isAppearanceLightNavigationBars = !appDark
                WindowCompat.setDecorFitsSystemWindows(window, !immersiveViewEnabled)
                if (immersiveViewEnabled) {
                    controller.systemBarsBehavior =
                        WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
                    controller.hide(WindowInsetsCompat.Type.systemBars())
                } else {
                    controller.show(WindowInsetsCompat.Type.systemBars())
                }
                onDispose { }
            }
            MarkVaultTheme(
                themeName = themeName,
                customThemeJson = customThemeJson,
                obsidianThemePayload = activeObsidianTheme,
                obsidianAppearanceMode = activeObsidianAppearanceMode,
                appAppearanceMode = appAppearanceMode,
                fontScale = uiFontScale,
                motionEnabled = motionOn,
                motionProfileName = motionProfileName,
                uiAnimEnabled = uiAnimOn,
                uiAnimSpeed = uiAnimSpeedValue,
                uiAnimStyleName = uiAnimStyleValue
            ) {
                val glass3d = themeName == "glass_obsidian" || themeName == "glass_crystal"
                val artifactTheme = isArtifactTheme(themeName)
                val rootModifier = when {
                    glass3d -> Modifier.fillMaxSize().background(Brush.verticalGradient(listOf(MaterialTheme.colorScheme.background, MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.72f), MaterialTheme.colorScheme.background)))
                    artifactTheme -> Modifier.fillMaxSize().artifactThemeBackdrop(themeName, MaterialTheme.colorScheme)
                    else -> Modifier.fillMaxSize()
                }
                val launchWelcomeVisible = remember {
                    androidx.compose.runtime.mutableStateOf(savedInstanceState == null)
                }
                Surface(
                    modifier = rootModifier,
                    color = if (glass3d || artifactTheme) Color.Transparent else MaterialTheme.colorScheme.background
                ) {
                    androidx.compose.foundation.layout.Box(modifier = Modifier.fillMaxSize()) {
                    val nav = rememberNavController()

                    // v5.4.233cc — "Any new window opened... after a few ms the
                    // ram must be cleared, so the heap ram does not stay full,
                    // always prioritize new app state." Applies to EVERY
                    // navigation destination change app-wide — opened articles,
                    // JW Videos, Settings, Home, all of it — via a single
                    // centralized listener rather than per-screen calls.
                    DisposableEffect(nav) {
                        val listener = androidx.navigation.NavController.OnDestinationChangedListener { _, destination, _ ->
                            // v5.4.236cc — Home gets the thorough reset
                            // (query + result lists + full model unload,
                            // with a "Memory Cleared" Toast showing what was
                            // freed) on top of the universal per-navigation
                            // clear every other screen already gets.
                            if (destination.route == "home") {
                                vm.resetHomeState()
                            } else {
                                vm.scheduleMemoryClearAfterNavigation()
                            }
                        }
                        nav.addOnDestinationChangedListener(listener)
                        onDispose { nav.removeOnDestinationChangedListener(listener) }
                    }

                    val sharedUrl by pendingSharedUrl.collectAsState()
                    val sharedSearchText by pendingSharedSearchText.collectAsState()
                    val viewBrowserUrl by pendingViewBrowserUrl.collectAsState()
                    val savedSearchId by pendingSavedSearchId.collectAsState()

                    // v5.4.105cc — On first composition (cold start),
                    // jump to the last saved route if there is one AND
                    // the app wasn't cold-started with a share/view
                    // intent (those take precedence — they're an
                    // explicit new action from the user). Consuming
                    // the flow value clears it so a config change
                    // doesn't re-navigate.
                    LaunchedEffect(Unit) {
                        val target = vm.pendingRestoredRoute.value
                        vm.consumeRestoredRoute()
                        val hasIncomingIntent = pendingSharedUrl.value != null ||
                            pendingSharedSearchText.value != null ||
                            pendingViewBrowserUrl.value != null ||
                            pendingSavedSearchId.value != null
                        if (!hasIncomingIntent && target.isNotBlank() && target != "home") {
                            // v5.4.113cc — WebViewer sentinel: navigate
                            // into the browser with the persisted active
                            // tab's URL. ensureBrowserSession then
                            // rebuilds the FULL tab set from
                            // pendingRestoredWebTabs. Give the async VM
                            // init a beat to populate the restored-tabs
                            // flow before reading it.
                            if (target == "webViewer") {
                                // Wait for the async VM-init pref reads
                                // to populate the restored-tabs flow.
                                // Poll briefly rather than a fixed delay
                                // so a slow cold start doesn't miss the
                                // tabs. Give up after ~2s.
                                var waited = 0
                                while (vm.pendingRestoredWebTabs.value.isEmpty() && waited < 2000) {
                                    kotlinx.coroutines.delay(100)
                                    waited += 100
                                }
                                val restoredTabs = vm.pendingRestoredWebTabs.value
                                val activeIdx = vm.pendingRestoredWebActiveIdx.value
                                    .coerceIn(0, (restoredTabs.size - 1).coerceAtLeast(0))
                                val activeUrl = restoredTabs.getOrNull(activeIdx)?.url
                                    ?: restoredTabs.firstOrNull()?.url
                                if (!activeUrl.isNullOrBlank()) {
                                    val enc = runCatching {
                                        java.net.URLEncoder.encode(activeUrl, "UTF-8")
                                    }.getOrElse { activeUrl }
                                    val host = runCatching {
                                        java.net.URLEncoder.encode(
                                            android.net.Uri.parse(activeUrl).host ?: "jw.org",
                                            "UTF-8"
                                        )
                                    }.getOrElse { "jw.org" }
                                    runCatching { nav.navigate("web/$enc/$host") }
                                }
                                // If no tabs were persisted, stay on home.
                            } else {
                                runCatching { nav.navigate(target) }
                            }
                        }
                    }
                    // v5.4.108cc — Batch save resume offer. On cold
                    // start we check whether a previous session had a
                    // partially-completed batch save. If so, we auto-
                    // resume it (silent, in the background) and toast
                    // the user so they know why the save-progress
                    // notification just re-appeared. Wait ~1.5s so
                    // the async VM-init pref reads have a chance to
                    // populate the state flow.
                    LaunchedEffect(Unit) {
                        kotlinx.coroutines.delay(1500)
                        // v5.4.115cc — Expansion resumes FIRST. If a
                        // previous session died while expanding heads,
                        // those heads still need to become articles
                        // before there's anything to save. Resuming the
                        // save first would race an empty basket.
                        val pendingHeads = vm.pendingResumeExpansion.value
                        if (pendingHeads.isNotEmpty()) {
                            android.widget.Toast.makeText(
                                this@MainActivity,
                                "\u25B6\uFE0F Resuming head expansion " +
                                    "(${pendingHeads.size} left)",
                                android.widget.Toast.LENGTH_LONG
                            ).show()
                            vm.resumePendingHeadExpansion()
                        }
                        val pending = vm.pendingResumeBatch.value
                        if (pending.isNotEmpty()) {
                            android.widget.Toast.makeText(
                                this@MainActivity,
                                "\u25B6\uFE0F Resuming batch save (${pending.size} left)",
                                android.widget.Toast.LENGTH_LONG
                            ).show()
                            vm.resumePendingBatchSave()
                        }
                    }
                    // v5.4.110cc — Notification-tap deep link. If the
                    // activity was launched with the "open_dashboard"
                    // extra (from BatchSaveService's contentIntent),
                    // navigate to the live dashboard once composition
                    // is up. Clears the extra so a config change
                    // doesn't re-navigate.
                    LaunchedEffect(Unit) {
                        if (intent?.getBooleanExtra("open_dashboard", false) == true) {
                            intent.removeExtra("open_dashboard")
                            runCatching { nav.navigate("batch_dashboard") }
                        }
                    }
                    // v5.4.373cc — Durable saved-search deep link. A notification
                    // can outlive the process; on tap we load the exact result set
                    // from internal storage before navigating to Search.
                    LaunchedEffect(savedSearchId) {
                        val id = savedSearchId ?: return@LaunchedEffect
                        pendingSavedSearchId.value = null
                        intent?.removeExtra("open_saved_search_id")
                        vm.restoreSavedSearchSession(id)
                        nav.navigate("search") { launchSingleTop = true }
                    }

                    // v5.4.112cc — Search-ready notification. Observe the
                    // VM's one-shot searchReadyEvent. When it fires AND
                    // the app is backgrounded AND results are non-empty,
                    // post a heads-up notification so the user knows to
                    // come back. Foreground users see results directly,
                    // so we skip the notification for them.
                    LaunchedEffect(Unit) {
                        vm.searchReadyEvent.collect { q ->
                            if (q == null) return@collect
                            vm.consumeSearchReady()
                            if (!appInForeground && vm.results.value.isNotEmpty()) {
                                postSearchReadyNotification(
                                    q,
                                    vm.results.value.size,
                                    vm.lastSavedSearchSessionId.value
                                )
                            }
                        }
                    }
                    // v5.4.105cc — Persist every top-level route
                    // change so RAM-kill / crash still leaves the
                    // latest destination in DataStore. We filter to
                    // "resumable" routes only; args-carrying routes
                    // (splitReader/…/…, htmlReader/{id}, etc.) hold
                    // ephemeral IDs that would be invalid on next
                    // launch, so we snap those back to their parent
                    // family or ignore.
                    LaunchedEffect(nav) {
                        nav.currentBackStackEntryFlow.collect { entry ->
                            val route = entry.destination.route.orEmpty()
                            if (route.isBlank()) return@collect
                            // Only persist stable top-level routes.
                            val persistable = when {
                                route == "home" -> "home"
                                route == "activity_log" -> "activity_log"
                                route == "browse" -> "browse"
                                route == "settings" -> "settings"
                                route == "pdfHistory" -> "pdfHistory"
                                route == "graph" -> "graph"
                                route == "duplicates" -> "duplicates"
                                // v5.4.106cc — Reader route persists
                                // because the tab list itself is
                                // restored on ReaderScreen mount.
                                route == "reader" -> "reader"
                                // v5.4.113cc — WebViewer. The actual
                                // route is web/{url}/{label} with args,
                                // but we persist it as the sentinel
                                // "webViewer" so cold-start knows to
                                // reopen the browser. The tab list +
                                // active tab are already persisted
                                // separately (persistWebTabsSession);
                                // on restore we navigate into the
                                // browser with the active tab's URL,
                                // which triggers ensureBrowserSession
                                // to rebuild the whole tab set.
                                route.startsWith("web/") -> "webViewer"
                                else -> null
                            }
                            if (persistable != null) vm.persistLastRoute(persistable)
                        }
                    }

                    // v5.4.12 — VIEW intent on a jw.org URL: open in
                    // the in-app browser directly. No chooser screen —
                    // the user already chose by tapping the link.
                    LaunchedEffect(viewBrowserUrl) {
                        val u = viewBrowserUrl ?: return@LaunchedEffect
                        pendingViewBrowserUrl.value = null
                        // v5.4.234cc — Video/audio links route to the media
                        // player instead of the browser. Reuses the same
                        // MediaLinkDetector patterns as everywhere else in
                        // the app — no separate, drifting URL logic.
                        val playedAsMedia = vm.tryPlayIncomingVideoLink(u)
                        if (playedAsMedia) {
                            nav.navigate("mediaPlayer/0") { launchSingleTop = true }
                            return@LaunchedEffect
                        }
                        val encUrl = runCatching {
                            java.net.URLEncoder.encode(u, "UTF-8")
                        }.getOrElse { u }
                        val label = runCatching {
                            java.net.URLEncoder.encode(
                                android.net.Uri.parse(u).host ?: "Web",
                                "UTF-8"
                            )
                        }.getOrElse { "Web" }
                        nav.navigate("web/$encUrl/$label")
                    }

                    // When a share lands (cold start OR while running), navigate to the import
                    // screen with the URL. Clearing the value after navigation avoids re-entry.
                    // v5.4.235cc — Always goes to the chooser now (was briefly
                    // bypassing it for detected video links in v5.4.234cc).
                    // The chooser itself detects video/audio and shows a 4th
                    // "Play Video" option with real title/thumbnail/duration —
                    // the user chooses, rather than the app deciding for them.
                    LaunchedEffect(sharedUrl) {
                        val u = sharedUrl ?: return@LaunchedEffect
                        pendingSharedUrl.value = null
                        val enc = runCatching { java.net.URLEncoder.encode(u, "UTF-8") }.getOrElse { u }
                        // v5.4.10 — Route to chooser first; user picks
                        // Convert to PDF / Convert to Markdown / View live.
                        nav.navigate("urlShareChooser/$enc")
                    }

                    // v4.7.9 — text from PROCESS_TEXT or non-URL share goes
                    // straight into the search bar. We default the search to
                    // full-text mode because the user usually wants to find
                    // where this phrase appears INSIDE their library, not just
                    // in titles. They can toggle to Titles afterwards.
                    LaunchedEffect(sharedSearchText) {
                        val t = sharedSearchText ?: return@LaunchedEffect
                        pendingSharedSearchText.value = null
                        vm.query.value = t
                        vm.mode.value = com.tebogo.markvault.SearchMode.CONTENT
                        nav.navigate("search") { launchSingleTop = true }
                    }

                    // v5.4.90cc — Batch-save engine is hoisted here (out
                    // of any single screen) so navigating between screens
                    // in MarkVault while a save is in flight doesn't
                    // dispose the WebViews and interrupt the job. Emits
                    // nothing until AppViewModel.batchSaveRequest goes
                    // non-empty; costs one boolean read otherwise.
                    com.tebogo.markvault.ui.HiddenBatchSaver(vm)
                    // v5.4.99cc — Head-expansion engine (Multi Selection
                    // Mode). Same hoisting rationale as HiddenBatchSaver:
                    // navigating between MarkVault screens mid-expansion
                    // must not dispose the hidden WebView driving the
                    // page-load. Emits nothing while the queue is empty.
                    com.tebogo.markvault.ui.HiddenHeadExpander(vm)

                    // v5.4.165cc — Screen transitions (slide + fade) for
                    // every navigation in the app: forward navigation
                    // slides the new screen in from the right while the
                    // old one slides out left; back navigation reverses
                    // it. This is what makes moving between Home, Search,
                    // Reader, Settings, etc. feel like a deliberate,
                    // continuous motion instead of an instant cut — and
                    // it's what makes Search's own entrance/exit (and
                    // every other screen's) smooth.
                    //
                    // Reads UiAnim.prefs ONCE per recomposition of this
                    // scope (a plain data-class snapshot, not re-read
                    // inside the transition lambdas themselves, since
                    // those lambdas aren't @Composable) and captures it
                    // by closure — so these transitions respect the same
                    // Settings → UI Animations enable toggle and speed
                    // slider as the FAB press/entrance system. Base
                    // duration 320ms means the actual duration ranges
                    // 320ms (speed=1.0, default) to 960ms (speed=3.0,
                    // "slow and smooth") via UiAnimPrefs.scaledDurationMs.
                    val navUiAnim = UiAnim.prefs
                    val navTransitionMs = navUiAnim.scaledDurationMs(320).coerceAtLeast(1)
                    val navSlideFraction = 4 // slides 1/4 of screen width, not edge-to-edge

                    WorkspaceTabletShell(vm = vm, nav = nav) {
                    NavHost(
                        navController = nav,
                        startDestination = "home",
                        enterTransition = {
                            if (!navUiAnim.enabled) {
                                EnterTransition.None
                            } else {
                                slideInHorizontally(
                                    animationSpec = tween(navTransitionMs, easing = FastOutSlowInEasing),
                                    initialOffsetX = { fullWidth -> fullWidth / navSlideFraction }
                                ) + fadeIn(animationSpec = tween(navTransitionMs))
                            }
                        },
                        exitTransition = {
                            if (!navUiAnim.enabled) {
                                ExitTransition.None
                            } else {
                                slideOutHorizontally(
                                    animationSpec = tween(navTransitionMs, easing = FastOutSlowInEasing),
                                    targetOffsetX = { fullWidth -> -fullWidth / navSlideFraction }
                                ) + fadeOut(animationSpec = tween(navTransitionMs))
                            }
                        },
                        popEnterTransition = {
                            if (!navUiAnim.enabled) {
                                EnterTransition.None
                            } else {
                                slideInHorizontally(
                                    animationSpec = tween(navTransitionMs, easing = FastOutSlowInEasing),
                                    initialOffsetX = { fullWidth -> -fullWidth / navSlideFraction }
                                ) + fadeIn(animationSpec = tween(navTransitionMs))
                            }
                        },
                        popExitTransition = {
                            if (!navUiAnim.enabled) {
                                ExitTransition.None
                            } else {
                                slideOutHorizontally(
                                    animationSpec = tween(navTransitionMs, easing = FastOutSlowInEasing),
                                    targetOffsetX = { fullWidth -> fullWidth / navSlideFraction }
                                ) + fadeOut(animationSpec = tween(navTransitionMs))
                            }
                        }
                    ) {
                        composable("home") { HomeScreen(vm, nav) }
                        composable("browse") { BrowseScreen(vm, nav) }
                        composable("search") { SearchScreen(vm, nav) }
                        composable("savedSearches") { SavedSearchesScreen(vm, nav) }
                        composable("topics") { TopicsScreen(vm, nav) }
                        composable("topic/{key}") { backStackEntry ->
                            TopicDetailScreen(vm, nav, backStackEntry.arguments?.getString("key") ?: "")
                        }
                        composable("settings") { SettingsScreen(vm, nav) }
                        composable("activity_log") {
                            com.tebogo.markvault.ui.ActivityLogScreen(vm, nav)
                        }
                        // v5.4.131cc — Crash-log viewer route. Reached
                        // from Settings ("Open crash logs" button).
                        composable("crash_logs") {
                            com.tebogo.markvault.ui.CrashLogViewerScreen(nav)
                        }
                        // v5.4.110cc — Live batch save dashboard. Route
                        // is stable (no args) so the notification
                        // pending-intent can target it without needing
                        // to know the current batch id.
                        composable("batch_dashboard") {
                            BatchSaveDashboardScreen(vm, nav)
                        }
                        composable("chat") { ChatScreen(vm, nav) }
                        composable("reader") { ReaderScreen(vm, nav) }
                        composable("workspacePanes") {
                            com.tebogo.markvault.ui.WorkspacePaneScreen(vm, nav)
                        }
                        composable("workspaceTags") {
                            com.tebogo.markvault.ui.WorkspaceTagsScreen(vm, nav)
                        }
                        composable("workspaceData") {
                            com.tebogo.markvault.ui.WorkspaceDataViewScreen(vm, nav)
                        }
                        composable("commandPalette") {
                            com.tebogo.markvault.ui.CommandPaletteScreen(nav)
                        }
                        composable("extensions") {
                            com.tebogo.markvault.ui.ReadOnlyExtensionsScreen(nav)
                        }
                        composable("canvas/{id}") { backStackEntry ->
                            val id = backStackEntry.arguments?.getString("id")?.toLongOrNull() ?: 0L
                            com.tebogo.markvault.ui.CanvasViewerScreen(vm, nav, id)
                        }
                        composable(
                            "splitReader/{leftId}/{leftType}/{rightId}/{rightType}",
                            arguments = listOf(
                                androidx.navigation.navArgument("leftId") { type = androidx.navigation.NavType.LongType },
                                androidx.navigation.navArgument("leftType") { type = androidx.navigation.NavType.StringType },
                                androidx.navigation.navArgument("rightId") { type = androidx.navigation.NavType.LongType },
                                androidx.navigation.navArgument("rightType") { type = androidx.navigation.NavType.StringType }
                            )
                        ) { backStackEntry ->
                            val leftId = backStackEntry.arguments?.getLong("leftId") ?: 0L
                            val leftType = backStackEntry.arguments?.getString("leftType") ?: "md"
                            val rightId = backStackEntry.arguments?.getLong("rightId") ?: 0L
                            val rightType = backStackEntry.arguments?.getString("rightType") ?: "md"
                            SplitReaderScreen(vm, nav, leftId, leftType, rightId, rightType)
                        }
                        composable("pdfReader/{id}") { backStackEntry ->
                            val id = backStackEntry.arguments?.getString("id")?.toLongOrNull() ?: 0L
                            PdfReaderScreen(vm, nav, noteId = id)
                        }
                        // v4.4 — viewer for saved offline web pages (.html / .mhtml).
                        // Previously these got routed to /reader and crashed because
                        // the markdown engine choked on the MIME envelope.
                        composable("htmlReader/{id}") { backStackEntry ->
                            val id = backStackEntry.arguments?.getString("id")?.toLongOrNull() ?: 0L
                            HtmlReaderScreen(vm, nav, id = id)
                        }
                        composable("mediaPlayer/{id}") { backStackEntry ->
                            val mid = backStackEntry.arguments?.getString("id")?.toLongOrNull() ?: return@composable
                            com.tebogo.markvault.ui.MediaPlayerScreen(vm, nav, mid)
                        }
                        composable("jwVideos") {
                            com.tebogo.markvault.ui.JwVideoBrowseScreen(vm, nav)
                        }
                        // v5.4.255cc — Named playlists browse/play screen.
                        composable("playlists") {
                            com.tebogo.markvault.ui.PlaylistsScreen(vm, nav)
                        }
                        composable("pdfHistory") { PdfHistoryScreen(vm, nav) }
                        composable("graph") { GraphScreen(vm, nav, startNoteId = null) }
                        composable("graph/{id}") { backStackEntry ->
                            val id = backStackEntry.arguments?.getString("id")?.toLongOrNull()
                            GraphScreen(vm, nav, startNoteId = id)
                        }
                        composable("web/{url}/{label}") { backStackEntry ->
                            val rawUrl = backStackEntry.arguments?.getString("url") ?: ""
                            val rawLabel = backStackEntry.arguments?.getString("label") ?: "jw.org"
                            val url = runCatching { java.net.URLDecoder.decode(rawUrl, "UTF-8") }.getOrElse { rawUrl }
                            val label = runCatching { java.net.URLDecoder.decode(rawLabel, "UTF-8") }.getOrElse { rawLabel }
                            WebSearchScreen(vm, nav, url, label)
                        }
                        // v5.4.106cc — Split view: WebView pane +
                        // library-note pane, spawned from the
                        // LibraryCheckOverlay's "Split view" button.
                        composable("webSplit/{url}/{noteId}/{fileType}") { backStackEntry ->
                            val rawUrl = backStackEntry.arguments?.getString("url") ?: ""
                            val url = runCatching {
                                java.net.URLDecoder.decode(rawUrl, "UTF-8")
                            }.getOrElse { rawUrl }
                            val id = backStackEntry.arguments?.getString("noteId")
                                ?.toLongOrNull() ?: 0L
                            val ft = backStackEntry.arguments?.getString("fileType") ?: "md"
                            WebSplitScreen(
                                vm = vm,
                                nav = nav,
                                liveUrl = url,
                                noteId = id,
                                fileType = ft
                            )
                        }
                        composable("webHistory") { WebHistoryScreen(vm, nav) }
                        composable("duplicates") { DuplicatesScreen(vm, nav) }
                        composable("webBookmarks") { WebBookmarksScreen(vm, nav) }
                        composable("web_popup_full/{url}/{label}") { backStackEntry ->
                            val rawUrl = backStackEntry.arguments?.getString("url") ?: ""
                            val rawLabel = backStackEntry.arguments?.getString("label") ?: "jw.org"
                            val url = runCatching { java.net.URLDecoder.decode(rawUrl, "UTF-8") }.getOrElse { rawUrl }
                            val label = runCatching { java.net.URLDecoder.decode(rawLabel, "UTF-8") }.getOrElse { rawLabel }
                            WebPopupFullScreen(
                                vm = vm,
                                url = url,
                                onClose = { nav.popBackStack() },
                                onShrink = { u, _ ->
                                    vm.requestWebPopup(u)
                                    nav.popBackStack()
                                },
                                onOpenBookmarks = {
                                    // Pop the fullscreen popup off the back stack, then go to bookmarks
                                    nav.popBackStack()
                                    nav.navigate("webBookmarks")
                                },
                                // v4.12.0 — three new overflow-menu destinations.
                                // Each pops the fullscreen popup off the back stack
                                // first so the user lands cleanly on the target
                                // screen without the popup re-appearing on Back.
                                onOpenWebHistory = {
                                    nav.popBackStack()
                                    nav.navigate("webHistory")
                                },
                                onOpenPdfHistory = {
                                    nav.popBackStack()
                                    nav.navigate("pdfHistory")
                                },
                                onOpenSettings = {
                                    nav.popBackStack()
                                    nav.navigate("settings")
                                },
                                onOpenActivityLog = {
                                    nav.popBackStack()
                                    nav.navigate("activity_log")
                                },
                                // v5.4.85cc — Floating "Article" FAB. Same
                                // effect as onClose today (pop the back stack
                                // so the article that triggered the link is
                                // shown again), but wired to a distinct
                                // callback so the routing is documented and
                                // can diverge later (e.g. WebView-state
                                // preservation to support alt-tab-style
                                // switching).
                                onReturnToArticle = { nav.popBackStack() }
                            )
                        }
                        composable("urlImport/{url}") { backStackEntry ->
                            val rawUrl = backStackEntry.arguments?.getString("url") ?: ""
                            val url = runCatching {
                                java.net.URLDecoder.decode(rawUrl, "UTF-8")
                            }.getOrElse { rawUrl }
                            UrlImportScreen(
                                vm = vm,
                                url = url,
                                onClose = { nav.popBackStack() }
                            )
                        }
                        // v5.4.10 — URL → PDF route.
                        composable("pdfFromUrl/{url}") { backStackEntry ->
                            val rawUrl = backStackEntry.arguments?.getString("url") ?: ""
                            val url = runCatching {
                                java.net.URLDecoder.decode(rawUrl, "UTF-8")
                            }.getOrElse { rawUrl }
                            com.tebogo.markvault.ui.UrlToPdfScreen(
                                vm = vm,
                                url = url,
                                onClose = { nav.popBackStack() },
                                onSavedToLibrary = {
                                    // After save: bounce back to home;
                                    // user finds the new PDF in Browse.
                                    nav.popBackStack(route = "home", inclusive = false)
                                }
                            )
                        }
                        // v5.4.10 — Share-URL chooser. When the user shares a
                        // URL to MarkVault, this screen pops up and asks
                        // whether they want to:
                        //   • Convert to PDF       → pdfFromUrl/{url}
                        //   • Convert to Markdown  → urlImport/{url}  (existing)
                        //   • View live website    → web/{url}/{label}
                        // Replaces the silent auto-convert-to-markdown that
                        // every shared URL used to trigger.
                        composable("urlShareChooser/{url}") { backStackEntry ->
                            val rawUrl = backStackEntry.arguments?.getString("url") ?: ""
                            val url = runCatching {
                                java.net.URLDecoder.decode(rawUrl, "UTF-8")
                            }.getOrElse { rawUrl }
                            com.tebogo.markvault.ui.UrlShareChooserScreen(
                                vm = vm,
                                url = url,
                                onConvertToMarkdown = {
                                    val enc = runCatching {
                                        java.net.URLEncoder.encode(url, "UTF-8")
                                    }.getOrElse { url }
                                    nav.navigate("urlImport/$enc") {
                                        popUpTo("urlShareChooser/{url}") { inclusive = true }
                                    }
                                },
                                onConvertToPdf = {
                                    val enc = runCatching {
                                        java.net.URLEncoder.encode(url, "UTF-8")
                                    }.getOrElse { url }
                                    nav.navigate("pdfFromUrl/$enc") {
                                        popUpTo("urlShareChooser/{url}") { inclusive = true }
                                    }
                                },
                                onViewLive = {
                                    val encUrl = runCatching {
                                        java.net.URLEncoder.encode(url, "UTF-8")
                                    }.getOrElse { url }
                                    val label = runCatching {
                                        java.net.URLEncoder.encode(
                                            android.net.Uri.parse(url).host ?: "Web",
                                            "UTF-8"
                                        )
                                    }.getOrElse { "Web" }
                                    nav.navigate("web/$encUrl/$label") {
                                        popUpTo("urlShareChooser/{url}") { inclusive = true }
                                    }
                                },
                                onPlayMedia = { info ->
                                    vm.playMedia(info)
                                    nav.navigate("mediaPlayer/0") {
                                        popUpTo("urlShareChooser/{url}") { inclusive = true }
                                    }
                                },
                                onCancel = { nav.popBackStack() }
                            )
                        }
                    }
                    } // WorkspaceTabletShell — v5.4.313cc

                    val popupUrl by vm.webPopupRequest.collectAsState()
                    val ctx = androidx.compose.ui.platform.LocalContext.current
                    if (popupUrl != null) {
                        // v5.4.272cc — Restore the Settings-controlled WebViewer
                        // routing. Popup mode creates/reuses an in-app floating
                        // window. If popup mode is off, full-screen mode uses the
                        // same WebPopupContents engine. Only when both are off do
                        // we hand the URL to Android's system browser.
                        val urlAtRequest = popupUrl!!
                        LaunchedEffect(urlAtRequest) {
                            val popupEnabled = vm.webViewerPopupEnabled.value
                            val fullScreenEnabled = vm.webViewerFullScreenEnabled.value
                            when {
                                popupEnabled -> vm.openWebPopupWindow(urlAtRequest)
                                fullScreenEnabled -> {
                                    val label = runCatching {
                                        android.net.Uri.parse(urlAtRequest).host ?: "Web"
                                    }.getOrElse { "Web" }
                                    val encUrl = runCatching {
                                        java.net.URLEncoder.encode(urlAtRequest, "UTF-8")
                                    }.getOrElse { urlAtRequest }
                                    val encLabel = runCatching {
                                        java.net.URLEncoder.encode(label, "UTF-8")
                                    }.getOrElse { label }
                                    nav.navigate("web_popup_full/$encUrl/$encLabel")
                                }
                                else -> runCatching {
                                    ctx.startActivity(
                                        android.content.Intent(
                                            android.content.Intent.ACTION_VIEW,
                                            android.net.Uri.parse(urlAtRequest)
                                        )
                                    )
                                }
                            }
                            vm.clearWebPopup()
                        }
                    }

                    // v5.4.272cc — Global floating WebViewer layer. It lives
                    // outside the NavHost, so a popup can overlay Home, Search,
                    // Reader, Settings, media screens, etc. without navigating
                    // away from the screen that launched the link.
                    FloatingWebViewerHost(
                        vm = vm,
                        onOpenBookmarks = { nav.navigate("webBookmarks") },
                        onOpenWebHistory = { nav.navigate("webHistory") },
                        onOpenPdfHistory = { nav.navigate("pdfHistory") },
                        onOpenSettings = { nav.navigate("settings") },
                        onOpenActivityLog = { nav.navigate("activity_log") }
                    )

                    if (launchWelcomeVisible.value) {
                        MarkVaultLaunchWelcome(
                            libraryReady = libraryReady,
                            onFinished = { launchWelcomeVisible.value = false }
                        )
                    }
                    }
                }
            }
        }
    }

    /**
     * v5.4.105cc — Flush WebViewer tab session to DataStore on
     * background transition. Runs whenever the activity leaves the
     * foreground (Home button, task switch, screen off) so a
     * subsequent RAM-kill / crash still has the latest snapshot on
     * disk. Cheap enough to run unconditionally — a single
     * DataStore.edit with three keys.
     *
     * Uses [MarkVaultApp.sharedVm] because the [AppViewModel]
     * instance held by `setContent` is a local val inside the Compose
     * scope; from a raw activity-lifecycle override the only reliable
     * handle is the app-scoped reference the VM registers into on
     * init.
     */
    override fun onStop() {
        super.onStop()
        // v5.4.112cc — Track background state for the search-ready
        // notification. When backgrounded, a completed search posts a
        // heads-up notification instead of silently updating the UI
        // the user can't see.
        appInForeground = false
        runCatching {
            val vm = (application as? MarkVaultApp)?.sharedVm
            vm?.persistWebTabsSession()
            // v5.4.106cc — Reader tab session flush.
            vm?.persistReaderTabsSession()
        }
    }

    override fun onStart() {
        super.onStart()
        appInForeground = true
        // v5.4.402cc — If Android reclaimed/paused an in-flight app update,
        // foregrounding MarkVault resumes the same .part file instead of restarting it.
        com.tebogo.markvault.update.AppUpdateManager.resumePendingDownload(this)
    }

    /**
     * v5.4.112cc — Post a "search results ready" heads-up notification.
     * Only called when the app is backgrounded and a submitted search
     * produced results. Tapping the notification brings MarkVault back
     * to the foreground (the Search screen still holds the results, so
     * no re-query is needed). Uses its own channel so the user can
     * mute search notifications independently of batch-save progress.
     */
    private fun postSearchReadyNotification(query: String, count: Int, savedSessionId: String?) {
        runCatching {
            val nm = getSystemService(android.content.Context.NOTIFICATION_SERVICE)
                as android.app.NotificationManager
            val channelId = "markvault_search_ready"
            if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.O) {
                val ch = android.app.NotificationChannel(
                    channelId,
                    "Search results ready",
                    android.app.NotificationManager.IMPORTANCE_DEFAULT
                ).apply {
                    description = "Notifies when a search finishes while the app is in the background"
                    setShowBadge(true)
                }
                nm.createNotificationChannel(ch)
            }
            val tapPi = android.app.PendingIntent.getActivity(
                this, 4821,
                Intent(this, MainActivity::class.java).apply {
                    flags = Intent.FLAG_ACTIVITY_SINGLE_TOP or Intent.FLAG_ACTIVITY_CLEAR_TOP
                    if (!savedSessionId.isNullOrBlank()) {
                        putExtra("open_saved_search_id", savedSessionId)
                    }
                },
                android.app.PendingIntent.FLAG_UPDATE_CURRENT or
                    android.app.PendingIntent.FLAG_IMMUTABLE
            )
            val notif = androidx.core.app.NotificationCompat.Builder(this, channelId)
                .setSmallIcon(R.mipmap.ic_launcher)
                .setContentTitle("\uD83D\uDD0D Search results ready")
                .setContentText("$count result${if (count == 1) "" else "s"} for \u201C$query\u201D")
                .setContentIntent(tapPi)
                .setAutoCancel(true)
                .setPriority(androidx.core.app.NotificationCompat.PRIORITY_DEFAULT)
                .build()
            nm.notify(4821, notif)
        }
    }

    /** Handle a share that lands while the app is already running. */
    override fun onNewIntent(newIntent: Intent) {
        super.onNewIntent(newIntent)
        setIntent(newIntent)
        val shared = extractSharedUrl(newIntent)
        if (shared != null) pendingSharedUrl.value = shared
        val sharedText = extractSharedSearchText(newIntent)
        if (sharedText != null) pendingSharedSearchText.value = sharedText
        // v5.4.12 — Browser VIEW intents (jw.org / wol.jw.org links
        // clicked from another app while MarkVault is already running).
        val viewUrl = extractViewBrowserUrl(newIntent)
        if (viewUrl != null) pendingViewBrowserUrl.value = viewUrl
        val savedSearchId = newIntent.getStringExtra("open_saved_search_id")
        if (!savedSearchId.isNullOrBlank()) pendingSavedSearchId.value = savedSearchId
    }

    /**
     * v5.4.94cc — Ask for POST_NOTIFICATIONS on Android 13+ if we
     * haven't been granted it already. No-op on API 32 and below (older
     * OS versions treat notification posting as an install-time grant).
     *
     * Registered against the ActivityResultRegistry so it survives
     * configuration changes; the launcher itself is created once per
     * activity instance.
     */
    private val notificationPermLauncher =
        registerForActivityResult(
            androidx.activity.result.contract.ActivityResultContracts.RequestPermission()
        ) { /* no-op — whatever the user chose, we keep running */ }

    private fun requestNotificationPermissionIfNeeded() {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.TIRAMISU) return
        val perm = android.Manifest.permission.POST_NOTIFICATIONS
        val already = androidx.core.content.ContextCompat.checkSelfPermission(this, perm) ==
            android.content.pm.PackageManager.PERMISSION_GRANTED
        if (!already) {
            runCatching { notificationPermLauncher.launch(perm) }
        }
    }
}

