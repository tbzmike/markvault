package com.tebogo.markvault

import android.content.Intent
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import com.tebogo.markvault.ui.HomeScreen
import com.tebogo.markvault.ui.BrowseScreen
import com.tebogo.markvault.ui.GraphScreen
import com.tebogo.markvault.ui.PdfHistoryScreen
import com.tebogo.markvault.ui.PdfReaderScreen
import com.tebogo.markvault.ui.ReaderScreen
import com.tebogo.markvault.ui.SearchScreen
import com.tebogo.markvault.ui.SettingsScreen
import com.tebogo.markvault.ui.TopicDetailScreen
import com.tebogo.markvault.ui.TopicsScreen
import com.tebogo.markvault.ui.UrlImportScreen
import com.tebogo.markvault.ui.WebPopupFullScreen
import com.tebogo.markvault.ui.WebPopupSheet
import com.tebogo.markvault.ui.WebSearchScreen
import kotlinx.coroutines.flow.MutableStateFlow

private val AmoledColors = darkColorScheme(
    primary = Color(0xFF8AB4F8),
    onPrimary = Color(0xFF00264D),
    secondary = Color(0xFF9AD0B0),
    onSecondary = Color(0xFF06281A),
    background = Color(0xFF000000),
    onBackground = Color(0xFFE6E6E6),
    surface = Color(0xFF0B0F14),
    onSurface = Color(0xFFE6E6E6),
    surfaceVariant = Color(0xFF161C23),
    onSurfaceVariant = Color(0xFFAEB9C4),
    outline = Color(0xFF3A434D)
)

@Composable
fun MarkVaultTheme(content: @Composable () -> Unit) {
    MaterialTheme(colorScheme = AmoledColors, content = content)
}

/**
 * If the launching Intent is an ACTION_SEND of text/plain whose body is a URL,
 * return that URL — otherwise null. This is what Chrome / Firefox / JW Library /
 * etc. send when the user picks our app from the share sheet.
 */
private fun extractSharedUrl(intent: Intent?): String? {
    if (intent == null) return null
    if (intent.action != Intent.ACTION_SEND) return null
    val text = intent.getStringExtra(Intent.EXTRA_TEXT)?.trim() ?: return null
    if (text.isEmpty()) return null
    if (text.startsWith("http://", ignoreCase = true) ||
        text.startsWith("https://", ignoreCase = true)) {
        return text
    }
    // Some apps share a text caption first and the URL second. Find a URL token.
    return text.split(Regex("\\s+")).firstOrNull {
        it.startsWith("http://", ignoreCase = true) ||
        it.startsWith("https://", ignoreCase = true)
    }
}

class MainActivity : ComponentActivity() {
    /** Holds a URL that arrived via a share intent. Read by the composition below. */
    private val pendingSharedUrl = MutableStateFlow<String?>(null)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        pendingSharedUrl.value = extractSharedUrl(intent)
        setContent {
            MarkVaultTheme {
                Surface(
                    modifier = Modifier.fillMaxSize(),
                    color = MaterialTheme.colorScheme.background
                ) {
                    val nav = rememberNavController()
                    val vm: AppViewModel = viewModel()
                    val sharedUrl by pendingSharedUrl.collectAsState()

                    // When a share lands (cold start OR while running), navigate to the import
                    // screen with the URL. Clearing the value after navigation avoids re-entry.
                    LaunchedEffect(sharedUrl) {
                        val u = sharedUrl ?: return@LaunchedEffect
                        pendingSharedUrl.value = null
                        val enc = runCatching { java.net.URLEncoder.encode(u, "UTF-8") }.getOrElse { u }
                        nav.navigate("urlImport/$enc")
                    }

                    NavHost(navController = nav, startDestination = "home") {
                        composable("home") { HomeScreen(vm, nav) }
                        composable("browse") { BrowseScreen(vm, nav) }
                        composable("search") { SearchScreen(vm, nav) }
                        composable("topics") { TopicsScreen(vm, nav) }
                        composable("topic/{key}") { backStackEntry ->
                            TopicDetailScreen(vm, nav, backStackEntry.arguments?.getString("key") ?: "")
                        }
                        composable("settings") { SettingsScreen(vm, nav) }
                        composable("reader") { ReaderScreen(vm, nav) }
                        composable("pdfReader/{id}") { backStackEntry ->
                            val id = backStackEntry.arguments?.getString("id")?.toLongOrNull() ?: 0L
                            PdfReaderScreen(vm, nav, noteId = id)
                        }
                        composable("pdfHistory") { PdfHistoryScreen(vm, nav) }
                        composable("graph") { GraphScreen(vm, nav, startNoteId = null) }
                        composable("graph/{id}") { backStackEntry ->
                            val id = backStackEntry.arguments?.getString("id")?.toLongOrNull()
                            GraphScreen(vm, nav, startNoteId = id)
                        }
                        composable("web/{url}/{label}") { backStackEntry ->
                            val rawUrl = backStackEntry.arguments?.getString("url") ?: ""
                            val rawLabel = backStackEntry.arguments?.getString("label") ?: "jw.org"
                            val url = runCatching { java.net.URLDecoder.decode(rawUrl, "UTF-8") }.getOrElse { rawUrl }
                            val label = runCatching { java.net.URLDecoder.decode(rawLabel, "UTF-8") }.getOrElse { rawLabel }
                            WebSearchScreen(nav, url, label)
                        }
                        composable("web_popup_full/{url}/{label}") { backStackEntry ->
                            val rawUrl = backStackEntry.arguments?.getString("url") ?: ""
                            val rawLabel = backStackEntry.arguments?.getString("label") ?: "jw.org"
                            val url = runCatching { java.net.URLDecoder.decode(rawUrl, "UTF-8") }.getOrElse { rawUrl }
                            val label = runCatching { java.net.URLDecoder.decode(rawLabel, "UTF-8") }.getOrElse { rawLabel }
                            WebPopupFullScreen(
                                vm = vm,
                                url = url,
                                onClose = { nav.popBackStack() },
                                onShrink = { u, _ ->
                                    vm.requestWebPopup(u)
                                    nav.popBackStack()
                                }
                            )
                        }
                        composable("urlImport/{url}") { backStackEntry ->
                            val rawUrl = backStackEntry.arguments?.getString("url") ?: ""
                            val url = runCatching {
                                java.net.URLDecoder.decode(rawUrl, "UTF-8")
                            }.getOrElse { rawUrl }
                            UrlImportScreen(
                                vm = vm,
                                url = url,
                                onClose = { nav.popBackStack() }
                            )
                        }
                    }

                    val popupUrl by vm.webPopupRequest.collectAsState()
                    if (popupUrl != null) {
                        WebPopupSheet(
                            vm = vm,
                            url = popupUrl!!,
                            onClose = { vm.clearWebPopup() },
                            onPromote = { u, label ->
                                vm.clearWebPopup()
                                val encUrl = runCatching { java.net.URLEncoder.encode(u, "UTF-8") }.getOrElse { u }
                                val encLabel = runCatching { java.net.URLEncoder.encode(label, "UTF-8") }.getOrElse { label }
                                nav.navigate("web_popup_full/$encUrl/$encLabel")
                            }
                        )
                    }
                }
            }
        }
    }

    /** Handle a share that lands while the app is already running. */
    override fun onNewIntent(newIntent: Intent) {
        super.onNewIntent(newIntent)
        setIntent(newIntent)
        val shared = extractSharedUrl(newIntent)
        if (shared != null) pendingSharedUrl.value = shared
    }
}

