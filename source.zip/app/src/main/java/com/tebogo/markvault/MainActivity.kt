package com.tebogo.markvault

import android.content.Intent
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import com.tebogo.markvault.ui.HomeScreen
import com.tebogo.markvault.ui.BrowseScreen
import com.tebogo.markvault.ui.GraphScreen
import com.tebogo.markvault.ui.PdfHistoryScreen
import com.tebogo.markvault.ui.HtmlReaderScreen
import com.tebogo.markvault.ui.PdfReaderScreen
import com.tebogo.markvault.ui.ReaderScreen
import com.tebogo.markvault.ui.ChatScreen
import com.tebogo.markvault.ui.SearchScreen
import com.tebogo.markvault.ui.SettingsScreen
import com.tebogo.markvault.ui.TopicDetailScreen
import com.tebogo.markvault.ui.TopicsScreen
import com.tebogo.markvault.ui.UrlImportScreen
import com.tebogo.markvault.ui.WebPopupFullScreen
import com.tebogo.markvault.ui.WebPopupSheet
import com.tebogo.markvault.ui.SplitReaderScreen
import com.tebogo.markvault.ui.WebBookmarksScreen
import com.tebogo.markvault.ui.WebHistoryScreen
import com.tebogo.markvault.ui.WebSearchScreen
import com.tebogo.markvault.ui.DuplicatesScreen
import kotlinx.coroutines.flow.MutableStateFlow

/* ── Color schemes per user-selectable theme ──
 * Each maps to one of the WebView's `theme-*` body classes so the article
 * viewer and the surrounding app chrome stay visually in sync.
 */
private val GreyDarkColors = darkColorScheme(
    primary = Color(0xFF8AB4F8),
    onPrimary = Color(0xFF00264D),
    secondary = Color(0xFF9AD0B0),
    onSecondary = Color(0xFF06281A),
    tertiary = Color(0xFFE5C07B),
    onTertiary = Color(0xFF3A2A06),
    background = Color(0xFF1C2026),
    onBackground = Color(0xFFE2E6EC),
    surface = Color(0xFF22272F),
    onSurface = Color(0xFFE2E6EC),
    surfaceVariant = Color(0xFF2E343D),
    onSurfaceVariant = Color(0xFFB6BFCB),
    outline = Color(0xFF4A5466),
    outlineVariant = Color(0xFF3D4554)
)

private val AmoledColors = darkColorScheme(
    primary = Color(0xFF8AB4F8),
    onPrimary = Color(0xFF00264D),
    secondary = Color(0xFF9AD0B0),
    onSecondary = Color(0xFF06281A),
    tertiary = Color(0xFFE5C07B),
    onTertiary = Color(0xFF3A2A06),
    background = Color(0xFF000000),
    onBackground = Color(0xFFE6E6E6),
    surface = Color(0xFF0B0F14),
    onSurface = Color(0xFFE6E6E6),
    surfaceVariant = Color(0xFF161C23),
    onSurfaceVariant = Color(0xFFAEB9C4),
    outline = Color(0xFF3A434D),
    outlineVariant = Color(0xFF2A3038)
)

private val SepiaColors = androidx.compose.material3.lightColorScheme(
    primary = Color(0xFF8A5A00),
    onPrimary = Color(0xFFF0EBD8),
    secondary = Color(0xFF7A5A2E),
    onSecondary = Color(0xFFF0EBD8),
    background = Color(0xFFF4ECD8),
    onBackground = Color(0xFF4A3F2F),
    surface = Color(0xFFECE2C8),
    onSurface = Color(0xFF4A3F2F),
    surfaceVariant = Color(0xFFE7DCBF),
    onSurfaceVariant = Color(0xFF7C6F59),
    outline = Color(0xFFB89C5E),
    outlineVariant = Color(0xFFC9B88E)
)

private val LightColors = androidx.compose.material3.lightColorScheme(
    primary = Color(0xFF0969DA),
    onPrimary = Color(0xFFF0ECE4),
    secondary = Color(0xFF1F6FEB),
    onSecondary = Color(0xFFF0ECE4),
    background = Color(0xFFFFFFFF),
    onBackground = Color(0xFF1F2328),
    surface = Color(0xFFF6F8FA),
    onSurface = Color(0xFF1F2328),
    surfaceVariant = Color(0xFFEEF1F4),
    onSurfaceVariant = Color(0xFF57606A),
    outline = Color(0xFF9CA6B2),
    outlineVariant = Color(0xFFB8C0CA)
)

/**
 * v4.16.0 — "Light grey" theme. Distinct from `LightColors` (pure white)
 * and from the dark/sepia families. Designed for users who want a light
 * theme but find pure white too glaring.
 *
 * Contrast spot-checked:
 *   onBackground (#181B1F) on background (#DDE1E5) ≈ 14:1 — AAA
 *   onSurfaceVariant (#2F3438) on surfaceVariant (#C3C9CF) ≈ 10:1 — AAA
 *   onPrimary white on primary navy #1F4D7A ≈ 9.5:1 — AAA
 * All text combinations exceed WCAG AAA (7:1) for body text.
 */
private val LightGreyColors = androidx.compose.material3.lightColorScheme(
    primary = Color(0xFF1F4D7A),          // deep navy — pops on grey
    onPrimary = Color(0xFFF0ECE4),
    secondary = Color(0xFF2D6B4F),        // deep teal accent
    onSecondary = Color(0xFFF0ECE4),
    tertiary = Color(0xFF6B4C1F),         // warm brown
    onTertiary = Color(0xFFF0ECE4),
    background = Color(0xFFDDE1E5),       // light cool grey, not white
    onBackground = Color(0xFF181B1F),     // near-black — maximum readability
    surface = Color(0xFFD2D6DB),          // slightly darker grey for cards
    onSurface = Color(0xFF181B1F),
    surfaceVariant = Color(0xFFC3C9CF),   // cooler grey for chips/inputs
    onSurfaceVariant = Color(0xFF2F3438), // very dark grey
    outline = Color(0xFF6B7178),
    outlineVariant = Color(0xFF98A0A8)
)

/* ── High-contrast dark ── AMOLED black base, maximum-contrast text ── */
private val HiContrastDarkColors = darkColorScheme(
    primary = Color(0xFF66BBFF),
    onPrimary = Color(0xFF000000),
    secondary = Color(0xFF66FF99),
    onSecondary = Color(0xFF000000),
    tertiary = Color(0xFFFFDD55),
    onTertiary = Color(0xFF000000),
    background = Color(0xFF000000),
    onBackground = Color(0xFFECECEC),
    surface = Color(0xFF0A0E14),
    onSurface = Color(0xFFECECEC),
    surfaceVariant = Color(0xFF141A22),
    onSurfaceVariant = Color(0xFFE0E8F0),
    outline = Color(0xFF66BBFF),
    outlineVariant = Color(0xFF335577)
)

/* ── Ocean ── deep blue-grey inspired by midnight water ── */
private val OceanColors = darkColorScheme(
    primary = Color(0xFF56CCF2),
    onPrimary = Color(0xFF002030),
    secondary = Color(0xFF6EDBCF),
    onSecondary = Color(0xFF002828),
    tertiary = Color(0xFFF0B866),
    onTertiary = Color(0xFF2A1800),
    background = Color(0xFF0D2030),
    onBackground = Color(0xFFD8E8F0),
    surface = Color(0xFF122838),
    onSurface = Color(0xFFD8E8F0),
    surfaceVariant = Color(0xFF183040),
    onSurfaceVariant = Color(0xFFAAC4D4),
    outline = Color(0xFF3A6070),
    outlineVariant = Color(0xFF2A4858)
)

/* ── Forest ── dark green canopy ── */
private val ForestColors = darkColorScheme(
    primary = Color(0xFF7EC8A4),
    onPrimary = Color(0xFF00281A),
    secondary = Color(0xFFA8D8B4),
    onSecondary = Color(0xFF08301C),
    tertiary = Color(0xFFD4B870),
    onTertiary = Color(0xFF2A2008),
    background = Color(0xFF142219),
    onBackground = Color(0xFFD8E8DC),
    surface = Color(0xFF1A2C22),
    onSurface = Color(0xFFD8E8DC),
    surfaceVariant = Color(0xFF22362A),
    onSurfaceVariant = Color(0xFFAAC8B4),
    outline = Color(0xFF3A6848),
    outlineVariant = Color(0xFF2A4E38)
)

/* ── Cream ── warm off-white, easy on the eyes ── */
private val CreamColors = androidx.compose.material3.lightColorScheme(
    primary = Color(0xFF7A5A00),
    onPrimary = Color(0xFFF0ECE4),
    secondary = Color(0xFF6A6030),
    onSecondary = Color(0xFFF0ECE4),
    tertiary = Color(0xFF5A6A40),
    onTertiary = Color(0xFFF0ECE4),
    background = Color(0xFFFDF6E3),
    onBackground = Color(0xFF3A3428),
    surface = Color(0xFFF5EDD4),
    onSurface = Color(0xFF3A3428),
    surfaceVariant = Color(0xFFEDE4C8),
    onSurfaceVariant = Color(0xFF6A6050),
    outline = Color(0xFFA89A70),
    outlineVariant = Color(0xFFC4B890)
)

/* ── High-contrast light ── pure white, maximum dark-on-light contrast ── */
private val HiContrastLightColors = androidx.compose.material3.lightColorScheme(
    primary = Color(0xFF0040A0),
    onPrimary = Color(0xFFF0ECE4),
    secondary = Color(0xFF006644),
    onSecondary = Color(0xFFF0ECE4),
    tertiary = Color(0xFF884400),
    onTertiary = Color(0xFFF0ECE4),
    background = Color(0xFFFFFFFF),
    onBackground = Color(0xFF000000),
    surface = Color(0xFFF0F2F5),
    onSurface = Color(0xFF000000),
    surfaceVariant = Color(0xFFE0E4E8),
    onSurfaceVariant = Color(0xFF1A1A1A),
    outline = Color(0xFF0040A0),
    outlineVariant = Color(0xFF6688BB)
)

/* ── v5.4.36 — Grey ── neutral mid-grey, neither light nor dark ── */
private val GreyColors = darkColorScheme(
    primary = Color(0xFF7EADD9),
    onPrimary = Color(0xFF1A2A3A),
    secondary = Color(0xFF88B8A0),
    onSecondary = Color(0xFF1A2A20),
    tertiary = Color(0xFFD4B87A),
    onTertiary = Color(0xFF2A2008),
    background = Color(0xFF606468),
    onBackground = Color(0xFF1A1C1E),
    surface = Color(0xFF6E7276),
    onSurface = Color(0xFF1A1C1E),
    surfaceVariant = Color(0xFF787C80),
    onSurfaceVariant = Color(0xFF2A2C2E),
    outline = Color(0xFF4A4E52),
    outlineVariant = Color(0xFF545860)
)

/* ── v5.4.36 — Darker Sepia ── warmer, deeper sepia for low-light reading ── */
private val DarkSepiaColors = darkColorScheme(
    primary = Color(0xFFD4A55A),
    onPrimary = Color(0xFF2A1A06),
    secondary = Color(0xFFC49856),
    onSecondary = Color(0xFF2A1A06),
    tertiary = Color(0xFFA88A60),
    onTertiary = Color(0xFF1A1206),
    background = Color(0xFF3A3028),
    onBackground = Color(0xFFE8DCC8),
    surface = Color(0xFF44382E),
    onSurface = Color(0xFFE8DCC8),
    surfaceVariant = Color(0xFF504234),
    onSurfaceVariant = Color(0xFFCCBDA8),
    outline = Color(0xFF7A6A50),
    outlineVariant = Color(0xFF5A4C3A)
)

/* ── v5.4.36 — Sky Blue ── gentle light-blue background ── */
private val SkyBlueColors = androidx.compose.material3.lightColorScheme(
    primary = Color(0xFF1565C0),
    onPrimary = Color(0xFFF0ECE4),
    secondary = Color(0xFF2E7D32),
    onSecondary = Color(0xFFF0ECE4),
    tertiary = Color(0xFF8D6E00),
    onTertiary = Color(0xFFF0ECE4),
    background = Color(0xFFD6EAFF),
    onBackground = Color(0xFF1A2A3A),
    surface = Color(0xFFC8DEFA),
    onSurface = Color(0xFF1A2A3A),
    surfaceVariant = Color(0xFFB8D2F0),
    onSurfaceVariant = Color(0xFF2A3A4A),
    outline = Color(0xFF6A8AAA),
    outlineVariant = Color(0xFF8AA8C8)
)

@Composable
fun MarkVaultTheme(
    themeName: String? = null,
    fontScale: Float = 1.0f,
    content: @Composable () -> Unit
) {
    val scheme = when (themeName) {
        "black"            -> AmoledColors
        "hicontrast-dark"  -> HiContrastDarkColors
        "ocean"            -> OceanColors
        "forest"           -> ForestColors
        "sepia"            -> SepiaColors
        "dark_sepia"       -> DarkSepiaColors
        "cream"            -> CreamColors
        "light_grey"       -> LightGreyColors
        "grey"             -> GreyColors
        "sky_blue"         -> SkyBlueColors
        "light"            -> LightColors
        "hicontrast-light" -> HiContrastLightColors
        else               -> GreyDarkColors          // "dark" or null → proper grey dark
    }
    // v4.16.0 — Global font-size adjustment.
    //
    // We multiply the system Density's fontScale by the user's preference,
    // then provide that as LocalDensity for every Composable under this
    // theme. Every `Text(...)` in the app — including dialogs, menus,
    // bottom bars, settings — picks the new size up automatically because
    // sp resolution goes through LocalDensity. Icons specified in dp are
    // unaffected, which is exactly the behaviour we want.
    //
    // Clamping is done at the call site (Prefs slider 0.7–1.5); this
    // function trusts the value but caps it defensively to keep extreme
    // values from breaking layout entirely.
    val safeScale = fontScale.coerceIn(0.7f, 1.5f)
    val baseDensity = androidx.compose.ui.platform.LocalDensity.current
    val scaledDensity = androidx.compose.ui.unit.Density(
        density = baseDensity.density,
        fontScale = baseDensity.fontScale * safeScale
    )
    androidx.compose.runtime.CompositionLocalProvider(
        androidx.compose.ui.platform.LocalDensity provides scaledDensity
    ) {
        MaterialTheme(colorScheme = scheme, content = content)
    }
}

/**
 * If the launching Intent is an ACTION_SEND of text/plain whose body is a URL,
 * return that URL — otherwise null. This is what Chrome / Firefox / JW Library /
 * etc. send when the user picks our app from the share sheet.
 */
private fun extractSharedUrl(intent: Intent?): String? {
    if (intent == null) return null
    if (intent.action != Intent.ACTION_SEND) return null
    val text = intent.getStringExtra(Intent.EXTRA_TEXT)?.trim() ?: return null
    if (text.isEmpty()) return null
    if (text.startsWith("http://", ignoreCase = true) ||
        text.startsWith("https://", ignoreCase = true)) {
        return text
    }
    // Some apps share a text caption first and the URL second. Find a URL token.
    return text.split(Regex("\\s+")).firstOrNull {
        it.startsWith("http://", ignoreCase = true) ||
        it.startsWith("https://", ignoreCase = true)
    }
}

/**
 * v5.4.12 — Extract a URL from an ACTION_VIEW intent (i.e. the user
 * tapped a link in another app and Android showed MarkVault in the
 * "Open with" chooser). Distinct from [extractSharedUrl] in two ways:
 *
 *  • Action is VIEW, not SEND. The URL lives in `intent.data`, not
 *    `EXTRA_TEXT`.
 *  • Host is whitelisted. Only jw.org and wol.jw.org URLs are claimed.
 *    The manifest filter already enforces this, but we double-check
 *    in case a malformed intent slips through.
 *
 * VIEW intents go straight to the in-app browser — no chooser screen,
 * because the user already chose by tapping the link.
 */
private fun extractViewBrowserUrl(intent: Intent?): String? {
    if (intent == null) return null
    if (intent.action != Intent.ACTION_VIEW) return null
    val data = intent.data ?: return null
    val scheme = data.scheme?.lowercase() ?: return null
    if (scheme != "http" && scheme != "https") return null
    val host = data.host?.lowercase() ?: return null
    val allowed = host == "jw.org" || host == "wol.jw.org" ||
        host.endsWith(".jw.org") || host.endsWith(".wol.jw.org")
    if (!allowed) return null
    return data.toString()
}

/**
 * Extract text to drop into the library search bar.
 *
 * Two intent paths route here:
 *
 *  • **ACTION_PROCESS_TEXT** — fires when the user highlights text in any app
 *    and picks MarkVault from the text-selection context menu (the row with
 *    "Copy / Share / Define / …"). The selection lives in
 *    `EXTRA_PROCESS_TEXT_READONLY` (preferred) or `EXTRA_PROCESS_TEXT`.
 *
 *  • **ACTION_SEND** — fires when the user picks MarkVault from the share
 *    sheet. The shared body lives in `EXTRA_TEXT`. We only treat it as a
 *    search query when it is NOT a URL — URLs are still routed through the
 *    existing import/save pipeline by [extractSharedUrl].
 *
 * Returns the trimmed text, or null when neither applies. The length cap
 * (500 chars) keeps the search bar from drowning when a user accidentally
 * selects a whole article.
 */
private fun extractSharedSearchText(intent: Intent?): String? {
    if (intent == null) return null
    val raw = when (intent.action) {
        Intent.ACTION_PROCESS_TEXT -> {
            intent.getCharSequenceExtra(Intent.EXTRA_PROCESS_TEXT_READONLY)?.toString()
                ?: intent.getCharSequenceExtra(Intent.EXTRA_PROCESS_TEXT)?.toString()
        }
        Intent.ACTION_SEND -> {
            // Skip when this share is a URL — that's the import flow's job.
            if (extractSharedUrl(intent) != null) return null
            intent.getStringExtra(Intent.EXTRA_TEXT)
        }
        else -> null
    } ?: return null
    val cleaned = raw.trim().replace(Regex("\\s+"), " ")
    if (cleaned.isEmpty()) return null
    return cleaned.take(500)
}

class MainActivity : ComponentActivity() {
    /** Holds a URL that arrived via a share intent. Read by the composition below. */
    private val pendingSharedUrl = MutableStateFlow<String?>(null)

    /**
     * Holds text that arrived via PROCESS_TEXT (long-press → "Search in MarkVault")
     * or via a non-URL ACTION_SEND share. Consumed once by the composition to
     * populate the search bar and navigate to the Search screen.
     */
    private val pendingSharedSearchText = MutableStateFlow<String?>(null)

    /**
     * v5.4.12 — Holds a URL that arrived via ACTION_VIEW for jw.org /
     * wol.jw.org (user tapped a link in another app, picked MarkVault
     * from the "Open with" chooser). Goes straight to the in-app
     * browser, no chooser screen.
     */
    private val pendingViewBrowserUrl = MutableStateFlow<String?>(null)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        pendingSharedUrl.value = extractSharedUrl(intent)
        pendingSharedSearchText.value = extractSharedSearchText(intent)
        pendingViewBrowserUrl.value = extractViewBrowserUrl(intent)
        setContent {
            // Acquire the vm at the OUTERMOST level so its theme flow can drive
            // both the Compose chrome (MarkVaultTheme) and the WebView CSS.
            val vm: AppViewModel = viewModel()
            val themeName by vm.theme.collectAsStateWithLifecycle()
            // v4.16.0 — global font size lives in the same Prefs flow used
            // by the markdown reader. MarkVaultTheme uses it to override
            // LocalDensity so every Compose Text scales together.
            val uiFontScale by vm.fontScale.collectAsStateWithLifecycle()
            MarkVaultTheme(themeName = themeName, fontScale = uiFontScale) {
                Surface(
                    modifier = Modifier.fillMaxSize(),
                    color = MaterialTheme.colorScheme.background
                ) {
                    val nav = rememberNavController()
                    val sharedUrl by pendingSharedUrl.collectAsState()
                    val sharedSearchText by pendingSharedSearchText.collectAsState()
                    val viewBrowserUrl by pendingViewBrowserUrl.collectAsState()

                    // v5.4.12 — VIEW intent on a jw.org URL: open in
                    // the in-app browser directly. No chooser screen —
                    // the user already chose by tapping the link.
                    LaunchedEffect(viewBrowserUrl) {
                        val u = viewBrowserUrl ?: return@LaunchedEffect
                        pendingViewBrowserUrl.value = null
                        val encUrl = runCatching {
                            java.net.URLEncoder.encode(u, "UTF-8")
                        }.getOrElse { u }
                        val label = runCatching {
                            java.net.URLEncoder.encode(
                                android.net.Uri.parse(u).host ?: "Web",
                                "UTF-8"
                            )
                        }.getOrElse { "Web" }
                        nav.navigate("web/$encUrl/$label")
                    }

                    // When a share lands (cold start OR while running), navigate to the import
                    // screen with the URL. Clearing the value after navigation avoids re-entry.
                    LaunchedEffect(sharedUrl) {
                        val u = sharedUrl ?: return@LaunchedEffect
                        pendingSharedUrl.value = null
                        val enc = runCatching { java.net.URLEncoder.encode(u, "UTF-8") }.getOrElse { u }
                        // v5.4.10 — Route to chooser first; user picks
                        // Convert to PDF / Convert to Markdown / View live.
                        nav.navigate("urlShareChooser/$enc")
                    }

                    // v4.7.9 — text from PROCESS_TEXT or non-URL share goes
                    // straight into the search bar. We default the search to
                    // full-text mode because the user usually wants to find
                    // where this phrase appears INSIDE their library, not just
                    // in titles. They can toggle to Titles afterwards.
                    LaunchedEffect(sharedSearchText) {
                        val t = sharedSearchText ?: return@LaunchedEffect
                        pendingSharedSearchText.value = null
                        vm.query.value = t
                        vm.mode.value = com.tebogo.markvault.SearchMode.CONTENT
                        nav.navigate("search") { launchSingleTop = true }
                    }

                    // v5.4.90cc — Batch-save engine is hoisted here (out
                    // of any single screen) so navigating between screens
                    // in MarkVault while a save is in flight doesn't
                    // dispose the WebViews and interrupt the job. Emits
                    // nothing until AppViewModel.batchSaveRequest goes
                    // non-empty; costs one boolean read otherwise.
                    com.tebogo.markvault.ui.HiddenBatchSaver(vm)

                    NavHost(navController = nav, startDestination = "home") {
                        composable("home") { HomeScreen(vm, nav) }
                        composable("browse") { BrowseScreen(vm, nav) }
                        composable("search") { SearchScreen(vm, nav) }
                        composable("topics") { TopicsScreen(vm, nav) }
                        composable("topic/{key}") { backStackEntry ->
                            TopicDetailScreen(vm, nav, backStackEntry.arguments?.getString("key") ?: "")
                        }
                        composable("settings") { SettingsScreen(vm, nav) }
                        composable("chat") { ChatScreen(vm, nav) }
                        composable("reader") { ReaderScreen(vm, nav) }
                        composable(
                            "splitReader/{leftId}/{leftType}/{rightId}/{rightType}",
                            arguments = listOf(
                                androidx.navigation.navArgument("leftId") { type = androidx.navigation.NavType.LongType },
                                androidx.navigation.navArgument("leftType") { type = androidx.navigation.NavType.StringType },
                                androidx.navigation.navArgument("rightId") { type = androidx.navigation.NavType.LongType },
                                androidx.navigation.navArgument("rightType") { type = androidx.navigation.NavType.StringType }
                            )
                        ) { backStackEntry ->
                            val leftId = backStackEntry.arguments?.getLong("leftId") ?: 0L
                            val leftType = backStackEntry.arguments?.getString("leftType") ?: "md"
                            val rightId = backStackEntry.arguments?.getLong("rightId") ?: 0L
                            val rightType = backStackEntry.arguments?.getString("rightType") ?: "md"
                            SplitReaderScreen(vm, nav, leftId, leftType, rightId, rightType)
                        }
                        composable("pdfReader/{id}") { backStackEntry ->
                            val id = backStackEntry.arguments?.getString("id")?.toLongOrNull() ?: 0L
                            PdfReaderScreen(vm, nav, noteId = id)
                        }
                        // v4.4 — viewer for saved offline web pages (.html / .mhtml).
                        // Previously these got routed to /reader and crashed because
                        // the markdown engine choked on the MIME envelope.
                        composable("htmlReader/{id}") { backStackEntry ->
                            val id = backStackEntry.arguments?.getString("id")?.toLongOrNull() ?: 0L
                            HtmlReaderScreen(vm, nav, id = id)
                        }
                        composable("pdfHistory") { PdfHistoryScreen(vm, nav) }
                        composable("graph") { GraphScreen(vm, nav, startNoteId = null) }
                        composable("graph/{id}") { backStackEntry ->
                            val id = backStackEntry.arguments?.getString("id")?.toLongOrNull()
                            GraphScreen(vm, nav, startNoteId = id)
                        }
                        composable("web/{url}/{label}") { backStackEntry ->
                            val rawUrl = backStackEntry.arguments?.getString("url") ?: ""
                            val rawLabel = backStackEntry.arguments?.getString("label") ?: "jw.org"
                            val url = runCatching { java.net.URLDecoder.decode(rawUrl, "UTF-8") }.getOrElse { rawUrl }
                            val label = runCatching { java.net.URLDecoder.decode(rawLabel, "UTF-8") }.getOrElse { rawLabel }
                            WebSearchScreen(vm, nav, url, label)
                        }
                        composable("webHistory") { WebHistoryScreen(vm, nav) }
                        composable("duplicates") { DuplicatesScreen(vm, nav) }
                        composable("webBookmarks") { WebBookmarksScreen(vm, nav) }
                        composable("web_popup_full/{url}/{label}") { backStackEntry ->
                            val rawUrl = backStackEntry.arguments?.getString("url") ?: ""
                            val rawLabel = backStackEntry.arguments?.getString("label") ?: "jw.org"
                            val url = runCatching { java.net.URLDecoder.decode(rawUrl, "UTF-8") }.getOrElse { rawUrl }
                            val label = runCatching { java.net.URLDecoder.decode(rawLabel, "UTF-8") }.getOrElse { rawLabel }
                            WebPopupFullScreen(
                                vm = vm,
                                url = url,
                                onClose = { nav.popBackStack() },
                                onShrink = { u, _ ->
                                    vm.requestWebPopup(u)
                                    nav.popBackStack()
                                },
                                onOpenBookmarks = {
                                    // Pop the fullscreen popup off the back stack, then go to bookmarks
                                    nav.popBackStack()
                                    nav.navigate("webBookmarks")
                                },
                                // v4.12.0 — three new overflow-menu destinations.
                                // Each pops the fullscreen popup off the back stack
                                // first so the user lands cleanly on the target
                                // screen without the popup re-appearing on Back.
                                onOpenWebHistory = {
                                    nav.popBackStack()
                                    nav.navigate("webHistory")
                                },
                                onOpenPdfHistory = {
                                    nav.popBackStack()
                                    nav.navigate("pdfHistory")
                                },
                                onOpenSettings = {
                                    nav.popBackStack()
                                    nav.navigate("settings")
                                },
                                // v5.4.85cc — Floating "Article" FAB. Same
                                // effect as onClose today (pop the back stack
                                // so the article that triggered the link is
                                // shown again), but wired to a distinct
                                // callback so the routing is documented and
                                // can diverge later (e.g. WebView-state
                                // preservation to support alt-tab-style
                                // switching).
                                onReturnToArticle = { nav.popBackStack() }
                            )
                        }
                        composable("urlImport/{url}") { backStackEntry ->
                            val rawUrl = backStackEntry.arguments?.getString("url") ?: ""
                            val url = runCatching {
                                java.net.URLDecoder.decode(rawUrl, "UTF-8")
                            }.getOrElse { rawUrl }
                            UrlImportScreen(
                                vm = vm,
                                url = url,
                                onClose = { nav.popBackStack() }
                            )
                        }
                        // v5.4.10 — URL → PDF route.
                        composable("pdfFromUrl/{url}") { backStackEntry ->
                            val rawUrl = backStackEntry.arguments?.getString("url") ?: ""
                            val url = runCatching {
                                java.net.URLDecoder.decode(rawUrl, "UTF-8")
                            }.getOrElse { rawUrl }
                            com.tebogo.markvault.ui.UrlToPdfScreen(
                                vm = vm,
                                url = url,
                                onClose = { nav.popBackStack() },
                                onSavedToLibrary = {
                                    // After save: bounce back to home;
                                    // user finds the new PDF in Browse.
                                    nav.popBackStack(route = "home", inclusive = false)
                                }
                            )
                        }
                        // v5.4.10 — Share-URL chooser. When the user shares a
                        // URL to MarkVault, this screen pops up and asks
                        // whether they want to:
                        //   • Convert to PDF       → pdfFromUrl/{url}
                        //   • Convert to Markdown  → urlImport/{url}  (existing)
                        //   • View live website    → web/{url}/{label}
                        // Replaces the silent auto-convert-to-markdown that
                        // every shared URL used to trigger.
                        composable("urlShareChooser/{url}") { backStackEntry ->
                            val rawUrl = backStackEntry.arguments?.getString("url") ?: ""
                            val url = runCatching {
                                java.net.URLDecoder.decode(rawUrl, "UTF-8")
                            }.getOrElse { rawUrl }
                            com.tebogo.markvault.ui.UrlShareChooserScreen(
                                url = url,
                                onConvertToMarkdown = {
                                    val enc = runCatching {
                                        java.net.URLEncoder.encode(url, "UTF-8")
                                    }.getOrElse { url }
                                    nav.navigate("urlImport/$enc") {
                                        popUpTo("urlShareChooser/{url}") { inclusive = true }
                                    }
                                },
                                onConvertToPdf = {
                                    val enc = runCatching {
                                        java.net.URLEncoder.encode(url, "UTF-8")
                                    }.getOrElse { url }
                                    nav.navigate("pdfFromUrl/$enc") {
                                        popUpTo("urlShareChooser/{url}") { inclusive = true }
                                    }
                                },
                                onViewLive = {
                                    val encUrl = runCatching {
                                        java.net.URLEncoder.encode(url, "UTF-8")
                                    }.getOrElse { url }
                                    val label = runCatching {
                                        java.net.URLEncoder.encode(
                                            android.net.Uri.parse(url).host ?: "Web",
                                            "UTF-8"
                                        )
                                    }.getOrElse { "Web" }
                                    nav.navigate("web/$encUrl/$label") {
                                        popUpTo("urlShareChooser/{url}") { inclusive = true }
                                    }
                                },
                                onCancel = { nav.popBackStack() }
                            )
                        }
                    }

                    val popupUrl by vm.webPopupRequest.collectAsState()
                    val popupModeOn by vm.webViewerPopupEnabled.collectAsState()
                    val fullScreenModeOn by vm.webViewerFullScreenEnabled.collectAsState()
                    val ctx = androidx.compose.ui.platform.LocalContext.current
                    if (popupUrl != null) {
                        when {
                            // ── Popup ON ───────────────────────────────
                            popupModeOn -> {
                                // Original bottom-sheet behaviour. The
                                // onPromote callback below routes to
                                // full-screen if that mode is available,
                                // or falls back to the system browser if
                                // the user has explicitly turned it off.
                                WebPopupSheet(
                                    vm = vm,
                                    url = popupUrl!!,
                                    onClose = { vm.clearWebPopup() },
                                    onPromote = { u, label ->
                                        vm.clearWebPopup()
                                        if (fullScreenModeOn) {
                                            val encUrl = runCatching { java.net.URLEncoder.encode(u, "UTF-8") }.getOrElse { u }
                                            val encLabel = runCatching { java.net.URLEncoder.encode(label, "UTF-8") }.getOrElse { label }
                                            nav.navigate("web_popup_full/$encUrl/$encLabel")
                                        } else {
                                            // v5.4.84cc — Full-screen mode
                                            // turned off in Settings — hand
                                            // to system browser so the
                                            // "Full screen" button still
                                            // does *something* obvious.
                                            runCatching {
                                                ctx.startActivity(
                                                    Intent(Intent.ACTION_VIEW, android.net.Uri.parse(u))
                                                )
                                            }
                                        }
                                    },
                                    onOpenBookmarks = {
                                        vm.clearWebPopup()
                                        nav.navigate("webBookmarks")
                                    },
                                    onOpenWebHistory = {
                                        vm.clearWebPopup()
                                        nav.navigate("webHistory")
                                    },
                                    onOpenPdfHistory = {
                                        vm.clearWebPopup()
                                        nav.navigate("pdfHistory")
                                    },
                                    onOpenSettings = {
                                        vm.clearWebPopup()
                                        nav.navigate("settings")
                                    }
                                )
                            }
                            // ── Popup OFF, Full-screen ON ─────────────
                            fullScreenModeOn -> {
                                // v5.4.83cc — In-app full-screen mode.
                                // Same WebView chrome the "Full screen"
                                // button in the popup normally promotes
                                // to, reached directly without the
                                // bottom sheet ever appearing.
                                val urlAtRequest = popupUrl!!
                                LaunchedEffect(urlAtRequest) {
                                    val encUrl = runCatching {
                                        java.net.URLEncoder.encode(urlAtRequest, "UTF-8")
                                    }.getOrElse { urlAtRequest }
                                    val encLabel = runCatching {
                                        java.net.URLEncoder.encode("Web", "UTF-8")
                                    }.getOrElse { "Web" }
                                    // Nav FIRST, clear SECOND — if we clear
                                    // first, the recomposition disposes the
                                    // LaunchedEffect mid-block and the nav
                                    // call may never fire.
                                    nav.navigate("web_popup_full/$encUrl/$encLabel")
                                    vm.clearWebPopup()
                                }
                            }
                            // ── Both OFF ──────────────────────────────
                            else -> {
                                // v5.4.84cc — Neither in-app mode is
                                // available; hand off to the system
                                // browser. Same nav-first-clear-second
                                // ordering rationale as the full-screen
                                // branch above.
                                val urlAtRequest = popupUrl!!
                                LaunchedEffect(urlAtRequest) {
                                    runCatching {
                                        ctx.startActivity(
                                            Intent(Intent.ACTION_VIEW, android.net.Uri.parse(urlAtRequest))
                                        )
                                    }
                                    vm.clearWebPopup()
                                }
                            }
                        }
                    }
                }
            }
        }
    }

    /** Handle a share that lands while the app is already running. */
    override fun onNewIntent(newIntent: Intent) {
        super.onNewIntent(newIntent)
        setIntent(newIntent)
        val shared = extractSharedUrl(newIntent)
        if (shared != null) pendingSharedUrl.value = shared
        val sharedText = extractSharedSearchText(newIntent)
        if (sharedText != null) pendingSharedSearchText.value = sharedText
        // v5.4.12 — Browser VIEW intents (jw.org / wol.jw.org links
        // clicked from another app while MarkVault is already running).
        val viewUrl = extractViewBrowserUrl(newIntent)
        if (viewUrl != null) pendingViewBrowserUrl.value = viewUrl
    }
}

