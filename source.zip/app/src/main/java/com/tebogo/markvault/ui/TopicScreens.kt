package com.tebogo.markvault.ui

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.navigation.NavController
import com.tebogo.markvault.AppViewModel
import com.tebogo.markvault.data.NoteMeta
import com.tebogo.markvault.data.Topics

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun TopicsScreen(vm: AppViewModel, nav: NavController) {
    val topics by vm.topics.collectAsStateWithLifecycle()
    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("\uD83E\uDDED Topic explorer") },
                navigationIcon = {
                    IconButton(onClick = { nav.popBackStack() }) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back")
                    }
                },
                actions = {
                    IconButton(onClick = { nav.navigate("search") }) {
                        Icon(Icons.Default.Search, contentDescription = "Search library")
                    }
                    GlobalAppMenu(nav)
                }
            )
        }
    ) { pad ->
        if (topics.isEmpty()) {
            Box(Modifier.padding(pad).fillMaxSize(), contentAlignment = Alignment.Center) {
                Text(
                    "Topics appear once your library is indexed.",
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
        } else {
            LazyColumn(Modifier.padding(pad).fillMaxSize()) {
                items(topics, key = { it.key }) { t ->
                    Row(
                        Modifier.fillMaxWidth()
                            .clickable { nav.navigate("topic/${t.key}") }
                            .padding(horizontal = 18.dp, vertical = 15.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(t.emoji, fontSize = 24.sp)
                        Spacer(Modifier.width(14.dp))
                        Text(t.label, Modifier.weight(1f), fontWeight = FontWeight.Medium, fontSize = 16.sp)
                        Text(
                            "${t.count}",
                            fontSize = 13.sp, color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                    HorizontalDivider(color = MaterialTheme.colorScheme.surfaceVariant)
                }
                item { Spacer(Modifier.height(24.dp)) }
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun TopicDetailScreen(vm: AppViewModel, nav: NavController, topicKey: String) {
    val def = remember(topicKey) { Topics.def(topicKey) }
    var notes by remember { mutableStateOf<List<NoteMeta>>(emptyList()) }
    var loading by remember { mutableStateOf(true) }

    androidx.compose.runtime.LaunchedEffect(topicKey) {
        notes = vm.loadTopicNotes(topicKey)
        loading = false
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("${def?.emoji ?: "\uD83E\uDDED"} ${def?.label ?: "Topic"}") },
                navigationIcon = {
                    IconButton(onClick = { nav.popBackStack() }) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back")
                    }
                },
                actions = {
                    IconButton(onClick = { nav.navigate("search") }) {
                        Icon(Icons.Default.Search, contentDescription = "Search library")
                    }
                    GlobalAppMenu(nav)
                }
            )
        }
    ) { pad ->
        Column(Modifier.padding(pad).fillMaxSize()) {
            Text(
                if (loading) "Loading\u2026"
                else "${notes.size} note${if (notes.size == 1) "" else "s"} \u00B7 auto-grouped by topic",
                Modifier.padding(horizontal = 18.dp, vertical = 8.dp),
                fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant
            )
            HorizontalDivider(color = MaterialTheme.colorScheme.surfaceVariant)
            when {
                loading -> Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                    CircularProgressIndicator()
                }
                notes.isEmpty() -> Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                    Text("No notes in this topic.", color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
                else -> LazyColumn(Modifier.fillMaxSize()) {
                    items(notes, key = { it.id }) { n ->
                        Column(
                            Modifier.fillMaxWidth()
                                .clickable {
                                    if (n.fileType == "pdf") {
                                        vm.openArticle(n.id, n.title, fileType = "pdf"); nav.navigate("pdfReader/${n.id}")
                                    } else {
                                        // If the user entered this topic via a search, carry that
                                        // query as a highlight so the term flashes in the article.
                                        val q = vm.query.value.trim().removeSurrounding("\"")
                                        if (q.length >= 2) vm.pendingHighlight = q
                                        vm.openArticle(n.id, n.title)
                                        nav.navigate("reader") { launchSingleTop = true }
                                    }
                                }
                                .padding(horizontal = 18.dp, vertical = 13.dp)
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                if (n.fileType == "pdf") {
                                    Text("\uD83D\uDCD5 ", fontSize = 14.sp)
                                }
                                Text(n.title, fontWeight = FontWeight.Medium,
                                    maxLines = 2, overflow = TextOverflow.Ellipsis,
                                    modifier = Modifier.weight(1f))
                            }
                            if (n.folder.isNotBlank()) {
                                Text(n.folder, fontSize = 11.sp,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                                    maxLines = 1, overflow = TextOverflow.Ellipsis)
                            }
                        }
                        HorizontalDivider(color = MaterialTheme.colorScheme.surfaceVariant)
                    }
                    item { Spacer(Modifier.height(24.dp)) }
                }
            }
        }
    }
}
