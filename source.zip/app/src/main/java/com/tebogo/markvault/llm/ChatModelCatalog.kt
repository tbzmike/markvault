package com.tebogo.markvault.llm

import java.io.File

/**
 * v5.4.75cc — Catalog of the on-device LLM used by MarkVault.
 *
 * ## What this catalog is for now
 *
 * As of v5.4.74cc the on-device LLM is **not** consumed by the chat UI at all.
 * The chat screen is left in the codebase for existing wiring but the sole
 * intended caller is the multi-query retrieval path
 * ([com.tebogo.markvault.ai.MultiQueryRetriever] via
 * [com.tebogo.markvault.ai.LocalAIProvider]), which uses the model briefly to
 * expand a single search query into a small set of paraphrased sub-queries
 * before delegating to the normal BGE-large semantic search + cross-encoder
 * reranker. The model is not held resident for streaming chat and does not
 * need multi-turn memory.
 *
 * Prior versions (v5.4.71–v5.4.73) offered two chat-oriented models — Qwen 3
 * 0.6B (mixed INT4) and Qwen 2.5 1.5B Instruct (INT8). Both were removed in
 * v5.4.74cc in favour of a single 2.5B-tier model.
 *
 * ## Why Phi-4-mini rather than Qwen 2.5 3B
 *
 * v5.4.74cc first shipped with Qwen 2.5 3B Instruct from
 * `litert-community/Qwen2.5-3B-Instruct`. That repo turned out to hold only
 * a `notebook.ipynb` — the actual `.litertlm` weights have not been
 * published there — so every install attempt failed with `HTTP 401 while
 * downloading qwen25-3b-instruct-q8`. (Separately, the underlying
 * `Qwen/Qwen2.5-3B-Instruct` base model ships under Alibaba's
 * `qwen-research` licence rather than the Apache 2.0 the smaller siblings
 * carry, which likely explains why the LiteRT wrapping was never
 * publicly resolvable.)
 *
 * v5.4.75cc replaces it with **Microsoft's Phi-4-mini-instruct** from
 * `litert-community/Phi-4-mini-instruct`. Phi-4-mini is:
 *
 *   1. Published under the MIT licence — no HF account, no click-through,
 *      no bearer token. `resolve/main/...` returns the weights directly.
 *   2. Officially in the `litert-community` org (same publisher as the
 *      previously-shipped 0.6B and 1.5B models).
 *   3. On the LiteRT-LM ecosystem's "verified loads" list alongside
 *      Qwen 2.5 1.5B, Qwen 3 0.6B and DeepSeek-R1-Distill-Qwen-1.5B —
 *      i.e. the exact packaging (`multi-prefill-seq_q8_ekv4096.litertlm`)
 *      that the LiteRT-LM 0.13.1 Android runtime pinned in
 *      app/build.gradle.kts understands.
 *   4. Uses standard `Phi3ForCausalLM` architecture (no new / experimental
 *      operators), so there is no risk of the runtime silently emitting
 *      garbage tokens like earlier LiteRT-LM builds did on models with
 *      unimplemented op schemas.
 *
 * ## About the parameter count
 *
 * The original request was for a "2.5B parameter model". Phi-4-mini has
 * ~3.8 B parameters, which is above that target. It is nevertheless the
 * best on-device option available today because every closer-to-2.5B
 * `.litertlm` in the wild either
 *
 *   - is gated (the Gemma family; Qwen 2.5 3B via the `qwen-research`
 *     licence),
 *   - has not been uploaded to `litert-community` yet (SmolLM3-3B,
 *     Falcon3-3B — open community requests exist but no weights are
 *     resolvable from litert-community/`resolve/main` today),
 *   - or uses a brand-new architecture (paulsp94/Qwen3.5-2B-LiteRT-LM
 *     with GatedDeltaNet — not yet on the LiteRT-LM 0.13.1 verified list).
 *
 * Phi-4-mini is the closest verified-ungated tier above 1.5B.
 *
 * ## Why not Gemma
 *
 * Every Gemma model on Hugging Face — including the LiteRT-LM variants in
 * `litert-community` — is gated behind Google's Gemma licence and needs a
 * signed-in HF account plus licence acceptance before the resolve URL will
 * return the actual weights (otherwise the download returns HTTP 401 and an
 * HTML error page). That does not fit MarkVault's "one-tap install, no
 * signup" UX.
 *
 * ## Device requirement
 *
 * ~3.9 GB storage for the download, ~4.5 GB peak RAM at CPU-backend
 * inference time. On a 6 GB device (Redmi Note 10 Pro) with BGE-large
 * loaded (~340 MB) plus Room, WebView and Compose, this is tight but
 * workable because the model is only loaded for the short duration of a
 * query expansion and is unloaded again immediately. It is **not**
 * appropriate for devices with 4 GB or less RAM.
 */

/**
 * Describes the on-device LLM that the user can install. Field names and
 * meaning are unchanged from earlier catalog versions so the downloader,
 * download service and settings UI keep working without any signature
 * changes.
 */
data class ChatModelDescriptor(
    /** Stable identifier, used as DB / Prefs key. */
    val id: String,
    /** Human-readable name shown in the model card. */
    val displayName: String,
    /** Short label shown in compact UI. */
    val shortName: String,
    /** A 2–3 sentence honest description shown in the install dialog. */
    val description: String,
    /** Where to download the model from. Stable Hugging Face resolve URL. */
    val downloadUrl: String,
    /** Local filename the downloaded model will be saved under. */
    val localFilename: String,
    /** Approximate download size in megabytes, shown in install dialog. */
    val approxSizeMb: Int,
    /** Approximate RAM footprint once loaded, shown in install dialog. */
    val approxRamMb: Int,
    /**
     * Max prompt context window in tokens. For multi-query retrieval this
     * is far larger than needed (a single question and a short expansion
     * instruction fit in well under 512 tokens).
     */
    val contextTokens: Int,
    /** True when this model is offered in the UI. */
    val enabled: Boolean = true
)

object ChatModelCatalog {

    /**
     * Microsoft Phi-4-mini-instruct, dynamic INT8 quantised, multi-prefill
     * signature, 4096-token KV cache, in LiteRT-LM's `.litertlm` bundle
     * format.
     *
     * ## Provenance of the download URL
     *
     * The file lives in the `litert-community/Phi-4-mini-instruct` repo on
     * Hugging Face — same publisher as the previously-shipped Qwen 2.5
     * 1.5B model. The tree at `main` (verified) contains the file
     * `Phi-4-mini-instruct_multi-prefill-seq_q8_ekv4096.litertlm`
     * (3.91 GB, Xet-stored, uploaded within the last month). MIT
     * licence — no HF account or click-through required.
     *
     * ## Compatibility
     *
     * `litert-community/Phi-4-mini-instruct` is on the LiteRT-LM
     * ecosystem's official "verified loads" list next to
     * `litert-community/Qwen2.5-1.5B-Instruct` and
     * `litert-community/Qwen3-0.6B` — i.e. exactly the same packaging and
     * runtime path we already exercise, so LiteRT-LM 0.13.1 (the version
     * pinned in app/build.gradle.kts) loads it via
     * [com.google.ai.edge.litertlm.Engine] with no code changes required
     * further up the stack.
     *
     * ## Quantisation scheme
     *
     * `dynamic_int8` (q8) quantises linear-layer weights to 8-bit while
     * keeping activations in float. Result: roughly a quarter of the
     * fp32 footprint with negligible quality loss for the paraphrase /
     * query-expansion job this model is asked to do.
     *
     * ## Approximate footprint
     *
     * Verified 3,910 MB on disk (3.91 GB, per the Hugging Face tree
     * listing); ~4,500 MB peak RAM on the CPU backend is a conservative
     * upper estimate for a ~3.8B INT8 model with a 4096-token KV cache.
     */
    val PHI4_MINI_INSTRUCT_INT8 = ChatModelDescriptor(
        id = "phi4-mini-instruct-q8",
        displayName = "Phi-4-mini Instruct (INT8)",
        shortName = "Phi-4-mini",
        description = "Microsoft's Phi-4-mini instruction model (~3.8B " +
            "parameters), dynamic INT8 quantised for on-device inference. " +
            "MIT licensed — no signup or licence click-through required. " +
            "Used by MarkVault purely to expand a search question into a " +
            "small set of paraphrased sub-queries for the semantic search " +
            "step; the chat interface does not consume it. Requires ~3.9 GB " +
            "storage and ~4.5 GB peak RAM while active — recommended only " +
            "on devices with 6 GB or more RAM. The model is loaded on " +
            "demand for a query expansion and unloaded again immediately " +
            "after, so the RAM cost is transient rather than resident.",
        downloadUrl = "https://huggingface.co/litert-community/Phi-4-mini-instruct/" +
            "resolve/main/Phi-4-mini-instruct_multi-prefill-seq_q8_ekv4096.litertlm",
        localFilename = "phi4-mini-instruct-q8-ekv4096.litertlm",
        approxSizeMb = 3910,
        approxRamMb = 4500,
        contextTokens = 4096,
        enabled = true
    )

    /** Every model offered in the picker. Order = display order. */
    val all: List<ChatModelDescriptor> = listOf(
        PHI4_MINI_INSTRUCT_INT8
    )

    /** Convenience: the default-recommended (and currently only) model. */
    val default: ChatModelDescriptor get() = PHI4_MINI_INSTRUCT_INT8

    /** Lookup by id. Returns null when the id is unknown (e.g. a stale
     *  preference left over from a previous catalog version); callers
     *  fall back to [default]. */
    fun byId(id: String): ChatModelDescriptor? = all.firstOrNull { it.id == id }

    /**
     * Plausibility floor for "the file is downloaded and probably real".
     * Kept at the pre-existing 100 MB threshold so behaviour is unchanged
     * for the resume / installed / sanity-check paths. The new Phi-4-mini
     * INT8 bundle is ~3.9 GB so it clears this floor by a wide margin; the
     * threshold only exists to catch obviously-broken partial downloads
     * (HTML error pages, zero-byte responses).
     */
    const val MIN_PLAUSIBLE_MODEL_BYTES = 100_000_000L  // 100 MB
}

/**
 * Where the model lives on disk for a given descriptor + context.
 * Top-level helper (not in the object) so it can be inlined into download
 * code that already has a Context but doesn't want to take a Catalog
 * dependency.
 */
fun ChatModelDescriptor.fileIn(filesDir: File): File = File(filesDir, localFilename)

/** Whether this model is currently installed and big enough to be plausible. */
fun ChatModelDescriptor.isInstalled(filesDir: File): Boolean {
    val f = fileIn(filesDir)
    return f.exists() && f.length() > ChatModelCatalog.MIN_PLAUSIBLE_MODEL_BYTES
}
