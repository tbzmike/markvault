package com.tebogo.markvault.llm

import java.io.File

/**
 * v5.4.71 — Catalog of on-device chat LLMs available for RAG over the user's
 * library. Mirrors the structure of [com.tebogo.markvault.search.ModelCatalog]
 * (the embedding-model catalog) so the same install / delete / picker UX
 * patterns can be reused.
 *
 * ## Current catalog
 *
 * Two models are offered:
 *
 *   1. **Qwen 3 0.6B (mixed INT4)** — 400 MB download, ~900 MB peak RAM.
 *      The lean default. Works on 3 GB+ devices.
 *
 *   2. **Qwen 2.5 1.5B Instruct (INT8)** — 1,600 MB download, ~2,200 MB
 *      peak RAM. Better reasoning and instruction-following; requires a
 *      device with at least 4 GB RAM (6 GB recommended alongside BGE-large).
 *
 * ## Why no Gemma models
 *
 * Every Gemma model on Hugging Face — including the LiteRT-LM variants in
 * the `litert-community` org — is gated behind Google's Gemma license.
 * Downloads require a signed-in HF account and licence acceptance. That
 * doesn't fit the "one-tap install, no signup" UX this app targets. Both
 * Qwen models are Apache 2.0 licensed — no account, no click-through.
 *
 * ## Memory budget note
 *
 * On a 6 GB device (Redmi Note 10 Pro), with BGE-large loaded (~340 MB),
 * Room + WebView + Compose UI, the safe LLM budget is roughly 2–2.5 GB.
 * Qwen 3 0.6B fits easily. Qwen 2.5 1.5B at INT8 peaks ~2,216 MB (per
 * the official litert-community benchmark on S25 Ultra, CPU backend), which
 * is tight but workable — the OS will reclaim WebView/cache RAM first if
 * needed. Users with only 4 GB total RAM should be warned.
 */

/**
 * Describes a single chat LLM that the user can install on-device. All
 * fields are user-visible; honesty over marketing.
 */
data class ChatModelDescriptor(
    /** Stable identifier, e.g. "gemma3-1b-it-q4". Used as DB / Prefs key. */
    val id: String,
    /** Human-readable name shown in the model picker. */
    val displayName: String,
    /** Short label shown in compact UI (e.g. "Gemma 3 1B"). */
    val shortName: String,
    /** A 2–3 sentence honest description shown in the install dialog. */
    val description: String,
    /** Where to download the model from. Stable Hugging Face resolve URL. */
    val downloadUrl: String,
    /** Local filename the downloaded model will be saved under. */
    val localFilename: String,
    /** Approximate download size in megabytes, shown in install dialog. */
    val approxSizeMb: Int,
    /** Approximate RAM footprint once loaded, shown in install dialog. */
    val approxRamMb: Int,
    /**
     * Max prompt context window in tokens. Constrains how many notes we
     * can fit into a RAG prompt. In practice we cap at ~3K to leave room
     * for generation and stay quick.
     */
    val contextTokens: Int,
    /** True when this model is offered in the UI. */
    val enabled: Boolean = true
)

object ChatModelCatalog {

    /**
     * Qwen 3 0.6B, mixed 4-bit quantised, in LiteRT-LM's `.litertlm`
     * bundle format.
     *
     * ## Why this model, not Gemma 3 1B
     *
     * v4.21.0 originally targeted Gemma 3 1B. We discovered at runtime
     * (HTTP 401) that every Gemma model on Hugging Face — including the
     * LiteRT-LM compatible variants in the `litert-community` org — is
     * gated behind Google's Gemma license. Downloads require either:
     *
     *   1. A user-signed-in browser session after clicking through the
     *      license terms, OR
     *   2. A Hugging Face authentication token attached as a Bearer
     *      header on the request.
     *
     * Neither fits the "one-tap install, no signup" UX this app expects
     * (and that the embedding models already deliver). Adding an HF
     * token flow would mean: HF account signup, license acceptance,
     * token generation in HF settings, paste into MarkVault. Hard pass
     * for a Bible-study notes app.
     *
     * Qwen 3 0.6B is the closest alternative: Alibaba's small chat
     * model, Apache 2.0 licensed, no signup or licence-click required,
     * already published in the `.litertlm` format by the same
     * `litert-community` org. LiteRT-LM 0.13.1 supports Qwen natively
     * per the official README's "Broad Model Support" list.
     *
     * ## Quality tradeoff to be honest about
     *
     * Qwen 3 0.6B has fewer parameters than Gemma 3 1B (0.6B vs 1B), so
     * raw quality on complex synthesis is lower. For RAG over retrieved
     * notes — where the model's main job is summarising / rephrasing
     * content that's already in front of it — this matters less than
     * it would for free-form chat. Tradeoff worth taking to keep the
     * "install once and it works" property.
     *
     * ## File details
     *
     * `qwen3_0_6b_mixed_int4.litertlm` uses blockwise INT4 weights with
     * group size 32 for linear projections, INT8 for token embeddings,
     * and fp for normalisation and KV cache. Approximately 400 MB on
     * disk, ~900 MB peak RAM at inference time. Context window 4096
     * tokens — enough for our RAG prompts (system rules + top-6 notes
     * + question budget around 3000 tokens).
     */
    val GEMMA3_QWEN_0_6B_INT4 = ChatModelDescriptor(
        id = "qwen3-0_6b-mixed-int4",
        displayName = "Qwen 3 0.6B (mixed 4-bit)",
        shortName = "Qwen 3 0.6B",
        description = "Alibaba's small open-source language model, mixed " +
            "4-bit quantised. Apache 2.0 licensed — no signup, no licence " +
            "acceptance, just install. Smaller than Gemma 3 1B but newer " +
            "architecture; expect decent quality on summarisation and " +
            "short Q&A over retrieved notes, less depth on multi-step " +
            "reasoning. Lighter on RAM too, so more comfortable alongside " +
            "BGE-large.",
        downloadUrl = "https://huggingface.co/litert-community/Qwen3-0.6B/" +
            "resolve/main/qwen3_0_6b_mixed_int4.litertlm",
        localFilename = "qwen3-0_6b-mixed-int4.litertlm",
        approxSizeMb = 400,
        approxRamMb = 900,
        contextTokens = 4096,
        enabled = true
    )

    /**
     * Qwen 2.5 1.5B Instruct, dynamic INT8 quantised, multi-prefill
     * signature, 4096-token KV cache, in LiteRT-LM's `.litertlm` format.
     *
     * ## Why Qwen 2.5 1.5B
     *
     * Same no-auth, Apache 2.0 rationale as the 0.6B sibling — no HF
     * account or licence click-through needed. At 1.5B parameters this
     * model has noticeably better reasoning, longer-context coherence, and
     * instruction-following than the 0.6B, making it the better choice for
     * multi-step Q&A over a large Bible-study library.
     *
     * ## Quantisation scheme
     *
     * `dynamic_int8` (q8) quantises linear-layer weights to 8-bit at
     * inference time, keeping activations in float. The result is ~1/4 the
     * disk footprint of fp32 while losing very little quality — the
     * litert-community benchmark shows decode speed of ~26–34 tok/s on CPU
     * (Samsung S25 Ultra), which is fast enough for streaming answers.
     *
     * ## File details
     *
     * `Qwen2.5-1.5B-Instruct_multi-prefill-seq_q8_ekv4096.litertlm`
     *   - Disk size  : 1,598 MB  (~1.6 GB download)
     *   - Peak RAM   : ~2,216 MB  (CPU backend, per official benchmark)
     *   - Context    : 4,096 tokens (ekv4096 KV-cache budget)
     *   - Prefill    : multi-signature (32 / 128 / 512 / 1280 token chunks)
     *   - License    : Apache 2.0
     *
     * ## Device requirement
     *
     * 2,216 MB peak RAM plus BGE-large (~340 MB) plus OS overhead sits
     * around 2.6–2.8 GB of working memory. On a 6 GB device this is
     * comfortable; on 4 GB devices Android may start killing background
     * processes. Recommend this model only on devices with ≥ 6 GB RAM.
     */
    val QWEN25_1_5B_INSTRUCT_INT8 = ChatModelDescriptor(
        id = "qwen25-1_5b-instruct-q8",
        displayName = "Qwen 2.5 1.5B Instruct (INT8)",
        shortName = "Qwen 2.5 1.5B",
        description = "Alibaba's 1.5B-parameter instruction model, dynamic " +
            "INT8 quantised for on-device CPU inference. Apache 2.0 licensed " +
            "— no signup required. Noticeably smarter than the 0.6B on " +
            "multi-step reasoning and longer answers. Requires ~2.2 GB RAM " +
            "at runtime; recommended on devices with 6 GB or more.",
        downloadUrl = "https://huggingface.co/litert-community/Qwen2.5-1.5B-Instruct/" +
            "resolve/main/Qwen2.5-1.5B-Instruct_multi-prefill-seq_q8_ekv4096.litertlm",
        localFilename = "qwen25-1_5b-instruct-q8-ekv4096.litertlm",
        approxSizeMb = 1600,
        approxRamMb = 2200,
        contextTokens = 4096,
        enabled = true
    )

    /** Every model offered in the picker. Order = display order. */
    val all: List<ChatModelDescriptor> = listOf(
        GEMMA3_QWEN_0_6B_INT4,
        QWEN25_1_5B_INSTRUCT_INT8
    )

    /** Convenience: the default-recommended model. */
    val default: ChatModelDescriptor get() = GEMMA3_QWEN_0_6B_INT4

    /** Lookup by id. */
    fun byId(id: String): ChatModelDescriptor? = all.firstOrNull { it.id == id }

    /** Plausibility floor for "the file is downloaded and probably real". */
    const val MIN_PLAUSIBLE_MODEL_BYTES = 100_000_000L  // 100 MB
}

/**
 * Where the chat model lives on disk for a given descriptor + context.
 * Top-level helper (not in the object) so it can be inlined into download
 * code that already has a Context but doesn't want to take a Catalog
 * dependency.
 */
fun ChatModelDescriptor.fileIn(filesDir: File): File = File(filesDir, localFilename)

/** Whether this model is currently installed and big enough to be plausible. */
fun ChatModelDescriptor.isInstalled(filesDir: File): Boolean {
    val f = fileIn(filesDir)
    return f.exists() && f.length() > ChatModelCatalog.MIN_PLAUSIBLE_MODEL_BYTES
}
