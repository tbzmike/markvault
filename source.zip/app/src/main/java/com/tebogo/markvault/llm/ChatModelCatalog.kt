package com.tebogo.markvault.llm

import java.io.File

/**
 * v4.20.0 — Catalog of on-device chat LLMs available for RAG over the user's
 * library. Mirrors the structure of [com.tebogo.markvault.search.ModelCatalog]
 * (the embedding-model catalog) so the same install / delete / picker UX
 * patterns can be reused.
 *
 * ## v5.4.45 — Two models: primary + tiny fallback
 *
 * The catalog now offers TWO models the user can install and switch
 * between in Settings:
 *
 *   1. **Qwen 3 0.6B (mixed 4-bit)** — the primary recommended model.
 *      ~400 MB download, ~900 MB peak RAM, decent quality on
 *      summarisation and short Q&A.
 *   2. **SmolLM2 135M (Instruct)** — a tiny fallback for when Qwen 3
 *      crashes on low-RAM devices or a device that can't reliably keep
 *      900 MB free alongside BGE-large. ~143 MB download, ~400 MB peak
 *      RAM. Trained by Hugging Face on 2T tokens, primarily English,
 *      instruction-tuned. Small enough to almost always load; quality
 *      is coarser than Qwen 3 but coherent for lookup-style questions
 *      over retrieved notes.
 *
 * ## Both models must be ungated
 *
 * v4.21.0 originally tried Gemma 3 1B — every Gemma on Hugging Face is
 * gated behind a Google license click-through, so the "one-tap install,
 * no signup" property broke. Qwen 3 0.6B (Apache 2.0) and SmolLM2 135M
 * (Apache 2.0) are both fully ungated — direct-fetchable from the
 * `litert-community` org on Hugging Face without any auth header.
 *
 * ## Memory budget rationale
 *
 * On the user's Redmi Note 10 Pro (6 GB RAM total), with BGE-large
 * embedding model loaded (~340 MB), Room + WebView + Compose UI, the
 * working LLM budget is roughly 1.5–2 GB. Qwen 3 0.6B (~900 MB peak)
 * fits comfortably in normal conditions but can OOM if other apps are
 * holding memory. SmolLM2 135M (~400 MB peak) is the safety net that
 * almost always fits.
 */

/**
 * Describes a single chat LLM that the user can install on-device. All
 * fields are user-visible; honesty over marketing.
 */
data class ChatModelDescriptor(
    /** Stable identifier, e.g. "gemma3-1b-it-q4". Used as DB / Prefs key. */
    val id: String,
    /** Human-readable name shown in the model picker. */
    val displayName: String,
    /** Short label shown in compact UI (e.g. "Gemma 3 1B"). */
    val shortName: String,
    /** A 2–3 sentence honest description shown in the install dialog. */
    val description: String,
    /** Where to download the model from. Stable Hugging Face resolve URL. */
    val downloadUrl: String,
    /** Local filename the downloaded model will be saved under. */
    val localFilename: String,
    /** Approximate download size in megabytes, shown in install dialog. */
    val approxSizeMb: Int,
    /** Approximate RAM footprint once loaded, shown in install dialog. */
    val approxRamMb: Int,
    /**
     * Max prompt context window in tokens. Constrains how many notes we
     * can fit into a RAG prompt. Gemma 3 1B is 32K context but in practice
     * we cap at ~3K to leave room for generation and stay quick.
     */
    val contextTokens: Int,
    /** True when this model is offered in the UI. */
    val enabled: Boolean = true
)

object ChatModelCatalog {

    /**
     * Qwen 3 0.6B, mixed 4-bit quantised, in LiteRT-LM's `.litertlm`
     * bundle format.
     *
     * ## Why this model, not Gemma 3 1B
     *
     * v4.21.0 originally targeted Gemma 3 1B. We discovered at runtime
     * (HTTP 401) that every Gemma model on Hugging Face — including the
     * LiteRT-LM compatible variants in the `litert-community` org — is
     * gated behind Google's Gemma license. Downloads require either:
     *
     *   1. A user-signed-in browser session after clicking through the
     *      license terms, OR
     *   2. A Hugging Face authentication token attached as a Bearer
     *      header on the request.
     *
     * Neither fits the "one-tap install, no signup" UX this app expects
     * (and that the embedding models already deliver). Adding an HF
     * token flow would mean: HF account signup, license acceptance,
     * token generation in HF settings, paste into MarkVault. Hard pass
     * for a Bible-study notes app.
     *
     * Qwen 3 0.6B is the closest alternative: Alibaba's small chat
     * model, Apache 2.0 licensed, no signup or licence-click required,
     * already published in the `.litertlm` format by the same
     * `litert-community` org. LiteRT-LM 0.13.1 supports Qwen natively
     * per the official README's "Broad Model Support" list.
     *
     * ## Quality tradeoff to be honest about
     *
     * Qwen 3 0.6B has fewer parameters than Gemma 3 1B (0.6B vs 1B), so
     * raw quality on complex synthesis is lower. For RAG over retrieved
     * notes — where the model's main job is summarising / rephrasing
     * content that's already in front of it — this matters less than
     * it would for free-form chat. Tradeoff worth taking to keep the
     * "install once and it works" property.
     *
     * ## File details
     *
     * `qwen3_0_6b_mixed_int4.litertlm` uses blockwise INT4 weights with
     * group size 32 for linear projections, INT8 for token embeddings,
     * and fp for normalisation and KV cache. Approximately 400 MB on
     * disk, ~900 MB peak RAM at inference time. Context window 4096
     * tokens — enough for our RAG prompts (system rules + top-6 notes
     * + question budget around 3000 tokens).
     */
    val QWEN3_0_6B_INT4 = ChatModelDescriptor(
        id = "qwen3-0_6b-mixed-int4",
        displayName = "Qwen 3 0.6B (mixed 4-bit)",
        shortName = "Qwen 3 0.6B",
        description = "Alibaba's small open-source language model, mixed " +
            "4-bit quantised. Apache 2.0 licensed — no signup, no licence " +
            "acceptance, just install. Smaller than Gemma 3 1B but newer " +
            "architecture; expect decent quality on summarisation and " +
            "short Q&A over retrieved notes, less depth on multi-step " +
            "reasoning. Lighter on RAM too, so more comfortable alongside " +
            "BGE-large.",
        downloadUrl = "https://huggingface.co/litert-community/Qwen3-0.6B/" +
            "resolve/main/qwen3_0_6b_mixed_int4.litertlm",
        localFilename = "qwen3-0_6b-mixed-int4.litertlm",
        approxSizeMb = 400,
        approxRamMb = 900,
        contextTokens = 4096,
        enabled = true
    )

    /**
     * SmolLM2 135M Instruct — Hugging Face's tiny English chat model,
     * shipped by the `litert-community` org in the `.litertlm` format
     * for LiteRT-LM.
     *
     * ## Why this one for the "smaller fallback" slot
     *
     * The user asked for a 100–300 M-parameter model that has "good
     * English and is reliable" as a fallback if the ~600 M Qwen 3
     * crashes. Options in that size range on the LiteRT-LM community
     * org, filtered by "ungated + Apache 2.0 + English":
     *
     *   - Gemma 3 270 M — **gated** (Google license click-through
     *     required on Hugging Face). Ruled out for the same reason we
     *     rejected Gemma 3 1B for the primary slot.
     *   - SmolLM 135 M (v1) — older, weaker instruction-following.
     *   - **SmolLM2 135 M Instruct** — Apache 2.0, ungated, trained on
     *     2 T English tokens (FineWeb-Edu + DCLM + The Stack),
     *     instruction-tuned with SFT + DPO. The paper (arXiv:2502.02737)
     *     shows meaningful gains over SmolLM1 on IFEval / MT-Bench at
     *     the same parameter count. Best available in-slot fit.
     *
     * ## Honest quality tradeoff
     *
     * At 135 M parameters this is roughly one-quarter the size of
     * Qwen 3 0.6 B. Expect:
     *
     *   - Coherent short answers on lookup-style questions ("what does
     *     the article say about X").
     *   - Decent extractive summaries of a single retrieved note.
     *   - Weaker on multi-step reasoning, synthesis across many notes,
     *     and non-English content. If a question needs joining ideas
     *     from 4+ notes, switch back to Qwen 3.
     *   - Primarily English-trained; Sepedi and other African-language
     *     content will not work well here — keep Qwen 3 for those.
     *
     * ## File details
     *
     * The `.litertlm` bundle uses per-channel INT8 weight quantisation
     * with FP scales, packaged by the litert-community team's stock
     * `litert-torch export_hf` converter. 143 MB on disk, expected
     * peak RAM around 400 MB at inference time (weights + KV cache +
     * activation buffers). Context window is 8192 native but we cap
     * RAG prompts at ~2048 for latency.
     */
    val SMOLLM2_135M_INSTRUCT = ChatModelDescriptor(
        id = "smollm2-135m-instruct",
        displayName = "SmolLM2 135M (Instruct)",
        shortName = "SmolLM2 135M",
        description = "Hugging Face's tiny 135M-parameter English chat " +
            "model, instruction-tuned. Apache 2.0 licensed — no signup, " +
            "no licence acceptance, just install. About one-quarter the " +
            "size of Qwen 3 0.6B, so it almost always fits in memory " +
            "even on tight-RAM devices. Best for short lookup-style " +
            "questions and single-note summaries; weaker on multi-step " +
            "reasoning and non-English content. Use as a fallback when " +
            "Qwen 3 crashes or is unavailable.",
        downloadUrl = "https://huggingface.co/litert-community/" +
            "SmolLM2-135M-Instruct/resolve/main/SmolLM2_135M_Instruct.litertlm",
        localFilename = "smollm2-135m-instruct.litertlm",
        approxSizeMb = 143,
        approxRamMb = 400,
        contextTokens = 2048,
        enabled = true
    )

    /** Every model offered in the picker. Order = display order. */
    val all: List<ChatModelDescriptor> = listOf(
        QWEN3_0_6B_INT4,
        SMOLLM2_135M_INSTRUCT
    )

    /** Convenience: the default-recommended model. */
    val default: ChatModelDescriptor get() = QWEN3_0_6B_INT4

    /** Lookup by id. */
    fun byId(id: String): ChatModelDescriptor? = all.firstOrNull { it.id == id }

    /**
     * Plausibility floor for "the file is downloaded and probably real".
     * Set to 100 MB so both Qwen 3 (~400 MB) and SmolLM2 (~143 MB) pass.
     * Any real LiteRT-LM chat model bundle in the catalog will exceed this
     * — the smallest weights + tokenizer + metadata combo in a modern
     * .litertlm still crosses ~120 MB.
     *
     * NOTE: if we ever add an even smaller model (e.g. a distilled 60 M),
     * this floor MUST be revisited so a partial download of a bigger
     * model can't slip past as "already installed".
     */
    const val MIN_PLAUSIBLE_MODEL_BYTES = 100_000_000L  // 100 MB
}

/**
 * Where the chat model lives on disk for a given descriptor + context.
 * Top-level helper (not in the object) so it can be inlined into download
 * code that already has a Context but doesn't want to take a Catalog
 * dependency.
 */
fun ChatModelDescriptor.fileIn(filesDir: File): File = File(filesDir, localFilename)

/** Whether this model is currently installed and big enough to be plausible. */
fun ChatModelDescriptor.isInstalled(filesDir: File): Boolean {
    val f = fileIn(filesDir)
    return f.exists() && f.length() > ChatModelCatalog.MIN_PLAUSIBLE_MODEL_BYTES
}
