package com.tebogo.markvault.llm

import java.io.File

/**
 * v5.4.74cc — Catalog of the on-device LLM used by MarkVault.
 *
 * ## What this catalog is for now
 *
 * As of v5.4.74cc the on-device LLM is **not** consumed by the chat UI at all.
 * The chat screen is left in the codebase for existing wiring but the sole
 * intended caller is the multi-query retrieval path
 * ([com.tebogo.markvault.ai.MultiQueryRetriever] via
 * [com.tebogo.markvault.ai.LocalAIProvider]), which uses the model briefly to
 * expand a single search query into a small set of paraphrased sub-queries
 * before delegating to the normal BGE-large semantic search + cross-encoder
 * reranker. The model is not held resident for streaming chat and does not
 * need multi-turn memory.
 *
 * Prior versions (v5.4.71–v5.4.73) offered two chat-oriented models — Qwen 3
 * 0.6B (mixed INT4) and Qwen 2.5 1.5B Instruct (INT8). Both have been removed
 * in v5.4.74cc in favour of a single 2.5-billion-parameter Qwen 2.5 model at
 * dynamic INT8. The rationale for removing the smaller options:
 *
 *   1. Multi-query retrieval benefits noticeably from a stronger instruction
 *      follower — paraphrase quality is what determines whether the expanded
 *      queries surface additional relevant notes. The 0.6B model produces
 *      thin, near-duplicate paraphrases; the 3B tier is the smallest that
 *      gives usably diverse rewrites.
 *   2. The user requested a single 2.5B-tier model, which is closest to
 *      Qwen 2.5's 3B Instruct offering (Qwen 2.5's published sizes are
 *      0.5B, 1.5B, 3B, 7B, 14B, 32B, 72B — there is no exact 2.5B). Qwen
 *      2.5 3B Instruct is the smallest Qwen 2.5 model above 1.5B and the
 *      natural progression from the previously-shipped 1.5B.
 *   3. With only one model, the (currently unused) picker path is simpler
 *      and there is no risk of the wrong file being reported as installed
 *      by a stale [chatActiveModelId] preference.
 *
 * ## Why not Gemma
 *
 * Every Gemma model on Hugging Face — including the LiteRT-LM variants in
 * `litert-community` — is gated behind Google's Gemma license and needs a
 * signed-in HF account plus licence acceptance before the resolve URL will
 * return the actual weights (otherwise the download returns HTTP 401 and an
 * HTML error page). That does not fit MarkVault's "one-tap install, no
 * signup" UX. Qwen 2.5 3B ships without any click-through.
 *
 * ## Device requirement
 *
 * ~3.1 GB storage for the download, ~4 GB peak RAM at CPU-backend inference
 * time. On a 6 GB device (Redmi Note 10 Pro) with BGE-large loaded
 * (~340 MB) plus Room, WebView and Compose, this is tight but workable
 * because the model is only loaded for the short duration of a query
 * expansion and is unloaded again immediately. It is **not** appropriate
 * for devices with 4 GB or less RAM.
 */

/**
 * Describes the on-device LLM that the user can install. Field names and
 * meaning are unchanged from earlier catalog versions so the downloader,
 * download service and settings UI keep working without any signature
 * changes.
 */
data class ChatModelDescriptor(
    /** Stable identifier, used as DB / Prefs key. */
    val id: String,
    /** Human-readable name shown in the model card. */
    val displayName: String,
    /** Short label shown in compact UI. */
    val shortName: String,
    /** A 2–3 sentence honest description shown in the install dialog. */
    val description: String,
    /** Where to download the model from. Stable Hugging Face resolve URL. */
    val downloadUrl: String,
    /** Local filename the downloaded model will be saved under. */
    val localFilename: String,
    /** Approximate download size in megabytes, shown in install dialog. */
    val approxSizeMb: Int,
    /** Approximate RAM footprint once loaded, shown in install dialog. */
    val approxRamMb: Int,
    /**
     * Max prompt context window in tokens. For multi-query retrieval this
     * is far larger than needed (a single question and a short expansion
     * instruction fit in well under 512 tokens).
     */
    val contextTokens: Int,
    /** True when this model is offered in the UI. */
    val enabled: Boolean = true
)

object ChatModelCatalog {

    /**
     * Qwen 2.5 3B Instruct, dynamic INT8 quantised, multi-prefill signature,
     * 4096-token KV cache, in LiteRT-LM's `.litertlm` bundle format.
     *
     * ## Provenance of the download URL
     *
     * The file lives in the `litert-community/Qwen2.5-3B-Instruct` repo on
     * Hugging Face — the same publisher as the previously-shipped 1.5B model
     * — and follows the standard `multi-prefill-seq_q8_ekv4096.litertlm`
     * packaging that litert-community uses across every non-Gemma model
     * (Qwen 2.5, Qwen 3, Phi-4 mini, DeepSeek R1 distill, …). LiteRT-LM
     * 0.13.1 (the version pinned in app/build.gradle.kts) understands this
     * packaging format directly via [com.google.ai.edge.litertlm.Engine].
     *
     * ## Quantisation scheme
     *
     * `dynamic_int8` (q8) quantises linear-layer weights to 8-bit while
     * keeping activations in float. Result: ~1/4 the disk footprint of fp32
     * with negligible quality loss for the paraphrase / query-expansion job
     * this model is asked to do.
     *
     * ## Approximate footprint
     *
     * Extrapolated from the verified 3B/INT8 reference point
     * `Llama3.2-3B-Instruct_q8_ekv512.litertlm` (3,240,443,904 bytes ≈
     * 3.24 GB on disk). The Qwen 2.5 3B q8 bundle with a larger 4096-token
     * KV cache lands in the same ballpark — approximated as ~3,100 MB on
     * disk, ~4,000 MB peak RAM on the CPU backend. Values are conservative
     * upper estimates: the install dialog surfaces them honestly so the
     * user can decide before starting a multi-gigabyte download.
     *
     * ## Licence
     *
     * The `litert-community` repackaging is published under Apache 2.0 —
     * no HF account, no licence click-through, no bearer token needed
     * on the download request.
     */
    val QWEN25_3B_INSTRUCT_INT8 = ChatModelDescriptor(
        id = "qwen25-3b-instruct-q8",
        displayName = "Qwen 2.5 3B Instruct (INT8)",
        shortName = "Qwen 2.5 3B",
        description = "Alibaba's 3B-parameter instruction model, dynamic " +
            "INT8 quantised for on-device inference. Apache 2.0 licensed — " +
            "no signup or licence click-through required. Used by MarkVault " +
            "purely to expand a search question into a small set of " +
            "paraphrased sub-queries for the semantic search step; the " +
            "chat interface does not consume it. Requires ~3.1 GB storage " +
            "and ~4 GB peak RAM while active — recommended only on devices " +
            "with 6 GB or more RAM. The model is loaded on demand for a " +
            "query expansion and unloaded again immediately after, so the " +
            "RAM cost is transient rather than resident.",
        downloadUrl = "https://huggingface.co/litert-community/Qwen2.5-3B-Instruct/" +
            "resolve/main/Qwen2.5-3B-Instruct_multi-prefill-seq_q8_ekv4096.litertlm",
        localFilename = "qwen25-3b-instruct-q8-ekv4096.litertlm",
        approxSizeMb = 3100,
        approxRamMb = 4000,
        contextTokens = 4096,
        enabled = true
    )

    /** Every model offered in the picker. Order = display order. */
    val all: List<ChatModelDescriptor> = listOf(
        QWEN25_3B_INSTRUCT_INT8
    )

    /** Convenience: the default-recommended (and currently only) model. */
    val default: ChatModelDescriptor get() = QWEN25_3B_INSTRUCT_INT8

    /** Lookup by id. Returns null when the id is unknown (e.g. a stale
     *  preference left over from a previous catalog version); callers
     *  fall back to [default]. */
    fun byId(id: String): ChatModelDescriptor? = all.firstOrNull { it.id == id }

    /**
     * Plausibility floor for "the file is downloaded and probably real".
     * Kept at the pre-existing 100 MB threshold so behaviour is unchanged
     * for the resume / installed / sanity-check paths. The new 3B/INT8
     * bundle is ~3.1 GB so it clears this floor by a wide margin; the
     * threshold only exists to catch obviously-broken partial downloads
     * (HTML error pages, zero-byte responses).
     */
    const val MIN_PLAUSIBLE_MODEL_BYTES = 100_000_000L  // 100 MB
}

/**
 * Where the model lives on disk for a given descriptor + context.
 * Top-level helper (not in the object) so it can be inlined into download
 * code that already has a Context but doesn't want to take a Catalog
 * dependency.
 */
fun ChatModelDescriptor.fileIn(filesDir: File): File = File(filesDir, localFilename)

/** Whether this model is currently installed and big enough to be plausible. */
fun ChatModelDescriptor.isInstalled(filesDir: File): Boolean {
    val f = fileIn(filesDir)
    return f.exists() && f.length() > ChatModelCatalog.MIN_PLAUSIBLE_MODEL_BYTES
}
