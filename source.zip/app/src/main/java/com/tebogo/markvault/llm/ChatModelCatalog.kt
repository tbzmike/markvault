package com.tebogo.markvault.llm

import java.io.File

/**
 * v5.4.79cc — Catalog of the on-device LLM(s) used by MarkVault.
 *
 * ## What this catalog is for now
 *
 * As of v5.4.74cc the on-device LLM is **not** consumed by the chat UI at all.
 * The chat screen is left in the codebase for existing wiring but the sole
 * intended caller is the multi-query retrieval path
 * ([com.tebogo.markvault.ai.MultiQueryRetriever] via
 * [com.tebogo.markvault.ai.LocalAIProvider]), which uses the model briefly to
 * expand a single search query into a small set of paraphrased sub-queries
 * before delegating to the normal BGE-large semantic search + cross-encoder
 * reranker.
 *
 * ## v5.4.79cc — Two-model line-up
 *
 * v5.4.76cc–v5.4.78cc shipped only Phi-4-mini (3.8 B params, ~3.9 GB on
 * disk, ~4.5 GB peak RAM). On a 6 GB device (Redmi Note 10 Pro) with
 * BGE-large, Room, WebView and Compose already resident, running Phi-4-mini
 * for query expansion pushed the process past the RAM ceiling and the OS
 * killed the app mid-inference — no results, sudden crash.
 *
 * v5.4.79cc keeps Phi-4-mini available but adds a **default lightweight
 * model** — [SMOLLM2_135M_INSTRUCT_INT8], HuggingFace's SmolLM2 135 M
 * Instruct at INT8, only 143 MB on disk and ~350 MB peak RAM. Comfortably
 * fits alongside everything else on any Android 8+ device.
 *
 * The AI-search Settings screen offers a two-way radio picker; the user
 * chooses either model per session. The [default] accessor returns
 * SmolLM2 so *new installs* land on the safe model. Users who explicitly
 * chose Phi-4-mini before v5.4.79cc keep that choice via their saved
 * `chatActiveModelId` DataStore preference — the catalog's
 * `byId(...) ?: default` fallback preserves their selection.
 *
 * ### Why not SmolLM2-360M
 *
 * The user's initial request was the 360 M SmolLM2. That size is not
 * available in `.litertlm` format: Google's ai-edge/litert-torch
 * converter fails on the 360 M variant with a size-mismatch error
 * (upstream issue #913, still open at time of writing). Only 135 M and
 * 1.7 B SmolLM2 variants have made it through the converter. 135 M is
 * therefore the closest SmolLM2 tier we can ship today, and it's the
 * safer choice for query paraphrasing on constrained devices anyway.
 *
 * ## Why not Gemma
 *
 * Every Gemma model on Hugging Face — including the LiteRT-LM variants in
 * `litert-community` — is gated behind Google's Gemma licence and needs a
 * signed-in HF account plus licence acceptance before the resolve URL will
 * return the actual weights. That does not fit MarkVault's "one-tap
 * install, no signup" UX.
 */

/**
 * Describes the on-device LLM that the user can install. Field names and
 * meaning are unchanged from earlier catalog versions so the downloader,
 * download service and settings UI keep working without any signature
 * changes.
 */
data class ChatModelDescriptor(
    /** Stable identifier, used as DB / Prefs key. */
    val id: String,
    /** Human-readable name shown in the model card. */
    val displayName: String,
    /** Short label shown in compact UI. */
    val shortName: String,
    /** A 2–3 sentence honest description shown in the install dialog. */
    val description: String,
    /** Where to download the model from. Stable Hugging Face resolve URL. */
    val downloadUrl: String,
    /** Local filename the downloaded model will be saved under. */
    val localFilename: String,
    /** Approximate download size in megabytes, shown in install dialog. */
    val approxSizeMb: Int,
    /** Approximate RAM footprint once loaded, shown in install dialog. */
    val approxRamMb: Int,
    /**
     * Max prompt context window in tokens. For multi-query retrieval this
     * is far larger than needed (a single question and a short expansion
     * instruction fit in well under 512 tokens).
     */
    val contextTokens: Int,
    /** True when this model is offered in the UI. */
    val enabled: Boolean = true
)

object ChatModelCatalog {

    /**
     * v5.4.79cc — SmolLM2 135 M Instruct, dynamic INT8 quantised,
     * `.litertlm` bundle. **New default**: chosen as the safe out-of-the-box
     * model because it fits comfortably in RAM on any device MarkVault
     * targets, including the ~6 GB entry-level tier where Phi-4-mini
     * previously crashed during inference.
     *
     * ## Provenance of the download URL
     *
     * The file lives in `litert-community/SmolLM2-135M-Instruct` (same
     * publisher as Phi-4-mini). Tree at `main` (fetched and verified)
     * lists exactly one weight file: `SmolLM2_135M_Instruct.litertlm`
     * (**143 MB**, xet-stored). Note the *underscores* in the filename —
     * different from Phi-4-mini's hyphen-plus-suffix convention. The
     * repo is Apache 2.0, ungated, no HF token required on the
     * resolve URL.
     *
     * ## Runtime footprint
     *
     * 143 MB on disk; roughly 350 MB peak RAM under LiteRT-LM 0.13.1 on
     * CPU backend (weights ~140 MB + activations + KV cache for a
     * ~1280-token context). Comfortable on any 3 GB+ Android device.
     * The model loads in ~1–2 s (versus ~10 s for Phi-4-mini) and
     * generates a paraphrase list in <1 s, so cold submits are nearly
     * indistinguishable from cache hits.
     *
     * ## Paraphrase quality
     *
     * At 135 M parameters SmolLM2 will not produce the same nuanced
     * paraphrases Phi-4-mini would; expect crisper, more surface-level
     * rewrites. That is *fine* for multi-query FTS expansion — the
     * downstream BGE-large semantic search does the heavy conceptual
     * lifting; the LLM's job here is just to spread the surface
     * vocabulary a bit so the FTS index catches synonym hits it would
     * otherwise miss. On instruction-following, SmolLM2 sometimes
     * ignores the "one per line" rule; the parser in
     * [LlmQueryExpander.parseParaphrases] is defensive about that.
     */
    val SMOLLM2_135M_INSTRUCT_INT8 = ChatModelDescriptor(
        id = "smollm2-135m-instruct-q8",
        displayName = "SmolLM2 135M Instruct (INT8)",
        shortName = "SmolLM2 135M",
        description = "HuggingFace's SmolLM2 135M instruction model, INT8 " +
            "quantised for on-device inference. Apache 2.0 licensed — no " +
            "signup required. Recommended for MarkVault's LLM multi-query " +
            "search on any device — only 143 MB on disk and ~350 MB peak " +
            "RAM while active, so the query-expansion pass runs " +
            "comfortably on the same 6 GB device that would OOM with a " +
            "bigger model. Paraphrase quality is intentionally simple; " +
            "the downstream BGE-large semantic search does the heavy " +
            "conceptual lifting.",
        downloadUrl = "https://huggingface.co/litert-community/SmolLM2-135M-Instruct/" +
            "resolve/main/SmolLM2_135M_Instruct.litertlm",
        localFilename = "smollm2-135m-instruct-q8.litertlm",
        approxSizeMb = 143,
        approxRamMb = 350,
        contextTokens = 2048,
        enabled = true
    )

    /**
     * v5.4.138cc — Google's Gemma 4 E2B Instruct in LiteRT-LM's
     * `.litertlm` bundle format. Replaces Qwen 3 0.6B and Phi-4-mini
     * as the sole non-default option because neither of those two
     * models ever produced a usable paraphrase run on the target
     * device tier — Qwen 3 hung on generate mid-stream, Phi-4-mini
     * exceeded the 6 GB device's RAM ceiling every attempt.
     *
     * ## Why Gemma 4 E2B specifically
     *
     * Gemma 4 uses a mixture 2/4/8-bit quantization scheme with
     * memory-mapped embeddings. The result is a 2.59 GB file on
     * disk but only ~0.8 GB of weight footprint held in RAM (the
     * 1.1 GB embedding table is memory-mapped, so only the pages
     * actually needed for inference come in). Android CPU-memory
     * benchmarks on the reference S26 Ultra: ~1.7 GB peak resident
     * — well within a 6 GB device's headroom alongside BGE-large,
     * Room, WebViews and Compose. Loads and runs on the same class
     * of device that would OOM with Phi-4-mini.
     *
     * ## Provenance
     *
     * File verified at the litert-community repo:
     * `gemma-4-E2B-it.litertlm` at 2.59 GB. Same publisher
     * (`litert-community`) as the SmolLM2 135M we already ship, same
     * resolve-URL pattern, no HF token required. Apache 2.0 licensed.
     *
     * ## Runtime footprint on the 6 GB tier
     *
     * 2.59 GB on disk, ~1.7 GB peak resident during inference. Load
     * time cold: ~3–5 s. Decode on Snapdragon-class CPU: ~30–45
     * tokens/sec (from the reference benchmark). A 3-paraphrase
     * generate finishes in ~2–4 s per the Android CPU numbers.
     *
     * ## Instruction-following quality
     *
     * At the ~2 B parameter class, Gemma 4 E2B follows short
     * structured instructions reliably — "give me N distinct
     * paraphrases, one per line" is exactly the kind of task it's
     * designed for. This is the tier the previous middle-option
     * (Qwen 3 0.6B) was supposed to occupy but couldn't due to
     * runtime issues. Also usable for the chat feature since Gemma
     * 4 was trained on general conversational data — same model can
     * back both query expansion AND on-device chat.
     */
    val GEMMA4_E2B_IT = ChatModelDescriptor(
        id = "gemma-4-e2b-it",
        displayName = "Gemma 4 E2B Instruct",
        shortName = "Gemma 4 E2B",
        description = "Google's Gemma 4 E2B instruction model in LiteRT-LM " +
            "format. Apache 2.0 licensed \u2014 no signup required. Uses a " +
            "mixture 2/4/8-bit quantization scheme with memory-mapped " +
            "embeddings, so it's 2.59 GB on disk but only ~0.8 GB " +
            "weight footprint in RAM (peak ~1.7 GB resident during " +
            "inference). Comfortable on 6 GB devices where Phi-4-mini " +
            "would OOM. Reliably follows the \"give me N paraphrases\" " +
            "instruction that smaller models drift on, and also " +
            "backs the on-device chat feature.",
        downloadUrl = "https://huggingface.co/litert-community/" +
            "gemma-4-E2B-it-litert-lm/resolve/main/gemma-4-E2B-it.litertlm",
        localFilename = "gemma-4-e2b-it.litertlm",
        approxSizeMb = 2650,   // 2.59 GB rounded to MB
        approxRamMb = 1800,    // Android peak (S26 Ultra CPU benchmark: 1733 MB)
        contextTokens = 4096,  // Model supports 32 k, we cap for practical latency
        enabled = true
    )

    /** Every model offered in the picker. Order = display order. */
    val all: List<ChatModelDescriptor> = listOf(
        SMOLLM2_135M_INSTRUCT_INT8,
        GEMMA4_E2B_IT
    )

    /**
     * Convenience: the default-recommended model. v5.4.79cc switched from
     * Phi-4-mini to SmolLM2 so fresh installs land on the safer, smaller
     * model. Users who explicitly picked Phi-4-mini before that keep
     * their choice via their saved `chatActiveModelId` — the fallback
     * `byId(...) ?: default` only kicks in when the saved id is unknown.
     */
    val default: ChatModelDescriptor get() = SMOLLM2_135M_INSTRUCT_INT8

    /** Lookup by id. Returns null when the id is unknown (e.g. a stale
     *  preference left over from a previous catalog version); callers
     *  fall back to [default]. */
    fun byId(id: String): ChatModelDescriptor? = all.firstOrNull { it.id == id }

    /**
     * Plausibility floor for "the file is downloaded and probably real".
     * v5.4.79cc lowered to 50 MB — the new default SmolLM2-135M bundle
     * is only 143 MB, so the previous 100 MB floor risked flagging a
     * fully-downloaded SmolLM2 install as too small if a resume glitch
     * left it slightly under. 50 MB still catches obviously-broken
     * partial downloads (HTML error pages, zero-byte responses,
     * mid-DNS-failure fragments) while giving both catalog models a
     * comfortable margin (SmolLM2 ~143 MB / Phi-4-mini ~3910 MB).
     */
    const val MIN_PLAUSIBLE_MODEL_BYTES = 50_000_000L  // 50 MB
}

/**
 * Where the model lives on disk for a given descriptor + context.
 * Top-level helper (not in the object) so it can be inlined into download
 * code that already has a Context but doesn't want to take a Catalog
 * dependency.
 */
fun ChatModelDescriptor.fileIn(filesDir: File): File = File(filesDir, localFilename)

/** Whether this model is currently installed and big enough to be plausible. */
fun ChatModelDescriptor.isInstalled(filesDir: File): Boolean {
    val f = fileIn(filesDir)
    return f.exists() && f.length() > ChatModelCatalog.MIN_PLAUSIBLE_MODEL_BYTES
}
