package com.tebogo.markvault.llm

import java.io.File

/**
 * v4.20.0 — Catalog of on-device chat LLMs available for RAG over the user's
 * library. Mirrors the structure of [com.tebogo.markvault.search.ModelCatalog]
 * (the embedding-model catalog) so the same install / delete / picker UX
 * patterns can be reused.
 *
 * ## Why one model right now
 *
 * Only Gemma 3 1B IT is listed in v4.20.0. The catalog is structured so
 * additional models (Phi-3.5 mini, Llama 3.2 1B, Qwen 2.5 1.5B variants)
 * can be added later as a single new entry in [all] without UI changes.
 *
 * ## Memory budget rationale
 *
 * On the user's Redmi Note 10 Pro (6 GB RAM total), with BGE-large
 * embedding model loaded (~340 MB), Room + WebView + Compose UI, the
 * working LLM budget is roughly 1.5–2 GB. Gemma 3 1B at 4-bit fits
 * comfortably; Gemma 3n E2B (~1.9 GB just for weights + memory-mapped
 * embeddings) is on the hairy edge of OOM. We pick the safer option for
 * v1.
 */

/**
 * Describes a single chat LLM that the user can install on-device. All
 * fields are user-visible; honesty over marketing.
 */
data class ChatModelDescriptor(
    /** Stable identifier, e.g. "gemma3-1b-it-q4". Used as DB / Prefs key. */
    val id: String,
    /** Human-readable name shown in the model picker. */
    val displayName: String,
    /** Short label shown in compact UI (e.g. "Gemma 3 1B"). */
    val shortName: String,
    /** A 2–3 sentence honest description shown in the install dialog. */
    val description: String,
    /** Where to download the model from. Stable Hugging Face resolve URL. */
    val downloadUrl: String,
    /** Local filename the downloaded model will be saved under. */
    val localFilename: String,
    /** Approximate download size in megabytes, shown in install dialog. */
    val approxSizeMb: Int,
    /** Approximate RAM footprint once loaded, shown in install dialog. */
    val approxRamMb: Int,
    /**
     * Max prompt context window in tokens. Constrains how many notes we
     * can fit into a RAG prompt. Gemma 3 1B is 32K context but in practice
     * we cap at ~3K to leave room for generation and stay quick.
     */
    val contextTokens: Int,
    /** True when this model is offered in the UI. */
    val enabled: Boolean = true
)

object ChatModelCatalog {

    /**
     * Qwen 3 0.6B, mixed 4-bit quantised, in LiteRT-LM's `.litertlm`
     * bundle format.
     *
     * ## Why this model, not Gemma 3 1B
     *
     * v4.21.0 originally targeted Gemma 3 1B. We discovered at runtime
     * (HTTP 401) that every Gemma model on Hugging Face — including the
     * LiteRT-LM compatible variants in the `litert-community` org — is
     * gated behind Google's Gemma license. Downloads require either:
     *
     *   1. A user-signed-in browser session after clicking through the
     *      license terms, OR
     *   2. A Hugging Face authentication token attached as a Bearer
     *      header on the request.
     *
     * Neither fits the "one-tap install, no signup" UX this app expects
     * (and that the embedding models already deliver). Adding an HF
     * token flow would mean: HF account signup, license acceptance,
     * token generation in HF settings, paste into MarkVault. Hard pass
     * for a Bible-study notes app.
     *
     * Qwen 3 0.6B is the closest alternative: Alibaba's small chat
     * model, Apache 2.0 licensed, no signup or licence-click required,
     * already published in the `.litertlm` format by the same
     * `litert-community` org. LiteRT-LM 0.13.1 supports Qwen natively
     * per the official README's "Broad Model Support" list.
     *
     * ## Quality tradeoff to be honest about
     *
     * Qwen 3 0.6B has fewer parameters than Gemma 3 1B (0.6B vs 1B), so
     * raw quality on complex synthesis is lower. For RAG over retrieved
     * notes — where the model's main job is summarising / rephrasing
     * content that's already in front of it — this matters less than
     * it would for free-form chat. Tradeoff worth taking to keep the
     * "install once and it works" property.
     *
     * ## File details
     *
     * `qwen3_0_6b_mixed_int4.litertlm` uses blockwise INT4 weights with
     * group size 32 for linear projections, INT8 for token embeddings,
     * and fp for normalisation and KV cache. Approximately 400 MB on
     * disk, ~900 MB peak RAM at inference time. Context window 4096
     * tokens — enough for our RAG prompts (system rules + top-6 notes
     * + question budget around 3000 tokens).
     */
    val QWEN3_0_6B_INT4 = ChatModelDescriptor(
        id = "qwen3-0_6b-mixed-int4",
        displayName = "Qwen 3 0.6B (mixed 4-bit)",
        shortName = "Qwen 3 0.6B",
        description = "Alibaba's small open-source language model, mixed " +
            "4-bit quantised. Apache 2.0 licensed — no signup, no licence " +
            "acceptance, just install. Smaller than Gemma 3 1B but newer " +
            "architecture; expect decent quality on summarisation and " +
            "short Q&A over retrieved notes, less depth on multi-step " +
            "reasoning. Lighter on RAM too, so more comfortable alongside " +
            "BGE-large.",
        downloadUrl = "https://huggingface.co/litert-community/Qwen3-0.6B/" +
            "resolve/main/qwen3_0_6b_mixed_int4.litertlm",
        localFilename = "qwen3-0_6b-mixed-int4.litertlm",
        approxSizeMb = 400,
        approxRamMb = 900,
        contextTokens = 4096,
        enabled = true
    )

    /** Every model offered in the picker. Order = display order. */
    val all: List<ChatModelDescriptor> = listOf(QWEN3_0_6B_INT4)

    /** Convenience: the default-recommended model. */
    val default: ChatModelDescriptor get() = QWEN3_0_6B_INT4

    /** Lookup by id. */
    fun byId(id: String): ChatModelDescriptor? = all.firstOrNull { it.id == id }

    /** Plausibility floor for "the file is downloaded and probably real". */
    const val MIN_PLAUSIBLE_MODEL_BYTES = 100_000_000L  // 100 MB
}

/**
 * Where the chat model lives on disk for a given descriptor + context.
 * Top-level helper (not in the object) so it can be inlined into download
 * code that already has a Context but doesn't want to take a Catalog
 * dependency.
 */
fun ChatModelDescriptor.fileIn(filesDir: File): File = File(filesDir, localFilename)

/** Whether this model is currently installed and big enough to be plausible. */
fun ChatModelDescriptor.isInstalled(filesDir: File): Boolean {
    val f = fileIn(filesDir)
    return f.exists() && f.length() > ChatModelCatalog.MIN_PLAUSIBLE_MODEL_BYTES
}
