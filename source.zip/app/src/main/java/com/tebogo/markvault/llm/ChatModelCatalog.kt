package com.tebogo.markvault.llm

import java.io.File

/**
 * v5.4.74 — Catalog of on-device LLMs for multi-query retrieval AND chat.
 *
 * Three tiers. The UI picker and download system both read from [all].
 * Adding a model = adding one entry here.
 */

data class ChatModelDescriptor(
    val id: String,
    val displayName: String,
    val shortName: String,
    val description: String,
    val downloadUrl: String,
    val localFilename: String,
    val approxSizeMb: Int,
    val approxRamMb: Int,
    val contextTokens: Int,
    val enabled: Boolean = true
)

object ChatModelCatalog {

    val GEMMA3_QWEN_0_6B_INT4 = ChatModelDescriptor(
        id = "qwen3-0_6b-mixed-int4",
        displayName = "Qwen 3 0.6B (mixed INT4)",
        shortName = "Qwen 3 0.6B",
        description = "Ultra-light. ~400 MB download, ~900 MB RAM. " +
            "Fastest load. Basic query expansion \u2014 adequate for " +
            "simple searches. Default. Apache 2.0 \u2014 no signup.",
        downloadUrl = "https://huggingface.co/litert-community/Qwen3-0.6B/" +
            "resolve/main/qwen3_0_6b_mixed_int4.litertlm",
        localFilename = "qwen3-0_6b-mixed-int4.litertlm",
        approxSizeMb = 400,
        approxRamMb = 900,
        contextTokens = 4096
    )

    val QWEN25_1_5B_INT8 = ChatModelDescriptor(
        id = "qwen25-1_5b-instruct-q8",
        displayName = "Qwen 2.5 1.5B Instruct (INT8) \u2B50",
        shortName = "Qwen 2.5 1.5B",
        description = "\u2B50 Recommended for best query understanding. " +
            "2.5\u00D7 better reasoning than 0.6B. " +
            "~1 600 MB download, ~2 000 MB RAM. Fits 6 GB devices when " +
            "unloaded between searches. Apache 2.0.",
        downloadUrl = "https://huggingface.co/litert-community/Qwen2.5-1.5B-Instruct/" +
            "resolve/main/Qwen2.5-1.5B-Instruct_multi-prefill-seq_q8_ekv4096.litertlm",
        localFilename = "qwen25-1_5b-instruct-q8.litertlm",
        approxSizeMb = 1600,
        approxRamMb = 2000,
        contextTokens = 4096
    )

    val QWEN3_4B_INT8 = ChatModelDescriptor(
        id = "qwen3-4b-channelwise-int8",
        displayName = "Qwen 3 4B (channel INT8)",
        shortName = "Qwen 3 4B",
        description = "Strongest expansion. ~5 280 MB download, " +
            "~5 800 MB RAM. \u26A0\uFE0F Requires \u2265 8 GB RAM \u2014 " +
            "may OOM on 6 GB. Close all other apps before loading. Apache 2.0.",
        downloadUrl = "https://huggingface.co/litert-community/Qwen3-4B/" +
            "resolve/main/qwen3_4b_channelwise_int8_float32kv.litertlm",
        localFilename = "qwen3-4b-channelwise-int8.litertlm",
        approxSizeMb = 5280,
        approxRamMb = 5800,
        contextTokens = 4096
    )

    val all: List<ChatModelDescriptor> = listOf(
        GEMMA3_QWEN_0_6B_INT4,
        QWEN25_1_5B_INT8,
        QWEN3_4B_INT8
    )

    val default: ChatModelDescriptor get() = GEMMA3_QWEN_0_6B_INT4

    fun byId(id: String): ChatModelDescriptor? = all.firstOrNull { it.id == id }

    const val MIN_PLAUSIBLE_MODEL_BYTES = 100_000_000L
}

fun ChatModelDescriptor.fileIn(filesDir: File): File = File(filesDir, localFilename)

fun ChatModelDescriptor.isInstalled(filesDir: File): Boolean {
    val f = fileIn(filesDir)
    return f.exists() && f.length() > ChatModelCatalog.MIN_PLAUSIBLE_MODEL_BYTES
}
