package com.tebogo.markvault.llm

import java.io.File

/**
 * v5.4.120cc — Catalog of the on-device LLM(s) used by MarkVault.
 *
 * ## What this catalog is for
 *
 * The on-device LLM is **not** consumed by the chat UI. The chat screen
 * is left in the codebase for existing wiring, but the sole intended caller
 * is the multi-query retrieval path
 * ([com.tebogo.markvault.ai.MultiQueryRetriever] via
 * [com.tebogo.markvault.ai.LocalAIProvider]), which uses the model briefly to
 * expand a single search query into a small set of paraphrased sub-queries
 * before delegating to the normal BGE-large semantic search + cross-encoder
 * reranker.
 *
 * ## v5.4.120cc — Two-model line-up (SmolLM2 135M + Qwen3-4B-Instruct-2507)
 *
 * ### Removed: Qwen3 0.6B
 *
 * Qwen3 0.6B (shipped in v5.4.119cc) is replaced by Qwen3-4B-Instruct-2507
 * (mixed INT4). The 0.6B size was a meaningful step up from SmolLM2 135M for
 * instruction-following, but Qwen3-4B-Instruct-2507 at mixed INT4 brings the
 * same Apache 2.0 / no-signup story with far stronger paraphrase quality, and
 * its peak RAM footprint (~1.6–1.7 GB on Android GPU) is still comfortable
 * on a 6 GB device next to BGE-large, Room, WebView, and Compose. The 0.6B
 * `.litertlm` artifact is removed from the catalog.
 *
 * ### Removed: Phi-4-mini
 *
 * Phi-4-mini (3.8 B params, ~3.9 GB on disk, ~4.5 GB peak RAM) caused OOM
 * crashes on 6 GB devices (Redmi Note 10 Pro class hardware) starting in
 * v5.4.76cc. It was kept as a heavy-device option but no longer justifies
 * catalog space now that Qwen3-4B-Instruct-2507 delivers comparable or
 * better paraphrase quality at roughly one-third the RAM cost.
 *
 * ### New heavy option: Qwen3-4B-Instruct-2507 (mixed INT4)
 *
 * Qwen3-4B-Instruct-2507 is the July 2025 Instruct checkpoint of Alibaba's
 * Qwen3 4B model, converted by the litert-community team to a mixed INT4
 * `.litertlm` bundle. File size ~2.5 GB; peak private RAM footprint reported
 * at ~1,587 MB on Samsung SM-S937U1 GPU OpenCL (vs ~4,903 MB for Phi-4-mini
 * on comparable mid-range hardware). Apache 2.0, no HF token required.
 *
 * ## Why not Gemma
 *
 * Every Gemma model on Hugging Face — including LiteRT-LM variants in
 * `litert-community` — is gated behind Google's Gemma licence and needs a
 * signed-in HF account plus licence acceptance before the resolve URL will
 * return the actual weights. That does not fit MarkVault's
 * "one-tap install, no signup" UX.
 */

/**
 * Describes the on-device LLM that the user can install. Field names and
 * meaning are unchanged from earlier catalog versions so the downloader,
 * download service and settings UI keep working without any signature
 * changes.
 */
data class ChatModelDescriptor(
    /** Stable identifier, used as DB / Prefs key. */
    val id: String,
    /** Human-readable name shown in the model card. */
    val displayName: String,
    /** Short label shown in compact UI. */
    val shortName: String,
    /** A 2–3 sentence honest description shown in the install dialog. */
    val description: String,
    /** Where to download the model from. Stable Hugging Face resolve URL. */
    val downloadUrl: String,
    /** Local filename the downloaded model will be saved under. */
    val localFilename: String,
    /** Approximate download size in megabytes, shown in install dialog. */
    val approxSizeMb: Int,
    /** Approximate RAM footprint once loaded, shown in install dialog. */
    val approxRamMb: Int,
    /**
     * Max prompt context window in tokens. For multi-query retrieval this
     * is far larger than needed (a single question and a short expansion
     * instruction fit in well under 512 tokens).
     */
    val contextTokens: Int,
    /** True when this model is offered in the UI. */
    val enabled: Boolean = true
)

object ChatModelCatalog {

    /**
     * v5.4.79cc — SmolLM2 135 M Instruct, dynamic INT8 quantised,
     * `.litertlm` bundle. **Default**: chosen as the safe out-of-the-box
     * model because it fits comfortably in RAM on any device MarkVault
     * targets, including the ~6 GB entry-level tier.
     *
     * ## Provenance of the download URL
     *
     * The file lives in `litert-community/SmolLM2-135M-Instruct` (same
     * publisher as Qwen3-4B-Instruct-2507). Tree at `main` lists exactly
     * one weight file: `SmolLM2_135M_Instruct.litertlm` (143 MB,
     * xet-stored). The repo is Apache 2.0, ungated, no HF token required.
     *
     * ## Runtime footprint
     *
     * 143 MB on disk; roughly 350 MB peak RAM under LiteRT-LM 0.13.1 on
     * CPU backend. Loads in ~1–2 s and generates a paraphrase list in
     * <1 s, so cold submits are nearly indistinguishable from cache hits.
     *
     * ## Paraphrase quality
     *
     * At 135 M parameters SmolLM2 sometimes ignores the "one per line"
     * rule; the parser in [LlmQueryExpander.parseParaphrases] is defensive
     * about that. For better instruction-following, users can switch to
     * Qwen3-4B-Instruct-2507.
     */
    val SMOLLM2_135M_INSTRUCT_INT8 = ChatModelDescriptor(
        id = "smollm2-135m-instruct-q8",
        displayName = "SmolLM2 135M Instruct (INT8)",
        shortName = "SmolLM2 135M",
        description = "HuggingFace's SmolLM2 135M instruction model, INT8 " +
            "quantised for on-device inference. Apache 2.0 licensed — no " +
            "signup required. Recommended default for MarkVault's LLM " +
            "multi-query search on any device — only 143 MB on disk and " +
            "~350 MB peak RAM while active. Simple paraphrase quality; " +
            "upgrade to Qwen3-4B if LLM expansion results come back empty.",
        downloadUrl = "https://huggingface.co/litert-community/SmolLM2-135M-Instruct/" +
            "resolve/main/SmolLM2_135M_Instruct.litertlm",
        localFilename = "smollm2-135m-instruct-q8.litertlm",
        approxSizeMb = 143,
        approxRamMb = 350,
        contextTokens = 2048,
        enabled = true
    )

    /**
     * v5.4.120cc — Qwen3-4B-Instruct-2507, mixed INT4 quantised,
     * `.litertlm` bundle. **High-quality option** for users who want
     * better paraphrases and reliable instruction-following.
     *
     * ## Why this specific model and variant
     *
     * Qwen3-4B-Instruct-2507 is the July 2025 Instruct checkpoint of
     * Alibaba's Qwen3 4B series, converted by the litert-community team.
     * At mixed INT4 (TorchAO blockwise, group-size 32; embedding stays
     * INT8; normalization and KV cache stay float) it lands at ~2.5 GB on
     * disk — large but manageable on a 6 GB device when the model is
     * loaded transiently for query expansion and then unloaded via
     * [LlmManager.unload].
     *
     * Peak private RAM footprint (Android, LiteRT-LM v0.13.1, GPU
     * OpenCL): ~1,587 MB on Samsung SM-S937U1 (Galaxy S25+). That is
     * roughly one-third of what Phi-4-mini consumed and comfortably
     * coexists with BGE-large, Room, WebView, and Compose on a 6 GB device.
     *
     * ## Provenance of the download URL
     *
     * Repository: `litert-community/Qwen3-4B-Instruct-2507` (same
     * publisher as SmolLM2-135M-Instruct). Single weight file at `main`:
     * `qwen3_4b_instruct_2507_mixed_int4.litertlm` (~2,536 MB,
     * xet-stored). Apache 2.0, no HF token required on the resolve URL.
     *
     * ## Paraphrase quality
     *
     * At 4 B parameters with an Instruct-2507 checkpoint this model
     * reliably follows "give me N paraphrases, one per line" instructions
     * and produces semantically diverse rewrites — meaningfully better
     * than the 0.6B tier that was removed in this version. Decode speed
     * on GPU OpenCL is ~18 tok/s (Samsung SM-S937U1), so a 30–40 token
     * paraphrase list completes in ~2 s after the model is warm.
     */
    val QWEN3_4B_INSTRUCT_2507_INT4 = ChatModelDescriptor(
        id = "qwen3-4b-instruct-2507-int4",
        displayName = "Qwen3 4B Instruct 2507 (INT4)",
        shortName = "Qwen3 4B",
        description = "Alibaba's Qwen3 4B Instruct (July 2025 checkpoint), " +
            "mixed INT4 quantised for on-device inference via LiteRT-LM. " +
            "Apache 2.0 licensed — no signup required. ~2.5 GB on disk and " +
            "~1.6 GB peak RAM on Android GPU — fits comfortably on a 6 GB " +
            "device. Delivers strong paraphrase quality and reliable " +
            "instruction-following; recommended if SmolLM2's LLM expansion " +
            "column comes back empty in your search history dialog.",
        downloadUrl = "https://huggingface.co/litert-community/Qwen3-4B-Instruct-2507/" +
            "resolve/main/qwen3_4b_instruct_2507_mixed_int4.litertlm",
        localFilename = "qwen3-4b-instruct-2507-int4.litertlm",
        approxSizeMb = 2536,
        approxRamMb = 1650,
        contextTokens = 2048,
        enabled = true
    )

    /** Every model offered in the picker. Order = display order. */
    val all: List<ChatModelDescriptor> = listOf(
        SMOLLM2_135M_INSTRUCT_INT8,
        QWEN3_4B_INSTRUCT_2507_INT4
    )

    /**
     * The default-recommended model. SmolLM2 135M so fresh installs land
     * on the safest, smallest model. Users can switch to Qwen3 4B in
     * Settings for better paraphrase quality. The fallback
     * `byId(...) ?: default` kicks in when a saved id is unknown (e.g.
     * stale "qwen3-0_6b-instruct-q8" or "phi4-mini-instruct-q8"
     * preferences from earlier catalog versions).
     */
    val default: ChatModelDescriptor get() = SMOLLM2_135M_INSTRUCT_INT8

    /** Lookup by id. Returns null when the id is unknown (e.g. a stale
     *  preference left over from a previous catalog version); callers
     *  fall back to [default]. */
    fun byId(id: String): ChatModelDescriptor? = all.firstOrNull { it.id == id }

    /**
     * Plausibility floor for "the file is downloaded and probably real".
     * 50 MB catches obviously-broken partial downloads (HTML error pages,
     * zero-byte responses, mid-DNS-failure fragments) while giving both
     * catalog models a comfortable margin (SmolLM2 ~143 MB /
     * Qwen3-4B ~2536 MB).
     */
    const val MIN_PLAUSIBLE_MODEL_BYTES = 50_000_000L  // 50 MB
}

/**
 * Where the model lives on disk for a given descriptor + context.
 * Top-level helper (not in the object) so it can be inlined into download
 * code that already has a Context but doesn't want to take a Catalog
 * dependency.
 */
fun ChatModelDescriptor.fileIn(filesDir: File): File = File(filesDir, localFilename)

/** Whether this model is currently installed and big enough to be plausible. */
fun ChatModelDescriptor.isInstalled(filesDir: File): Boolean {
    val f = fileIn(filesDir)
    return f.exists() && f.length() > ChatModelCatalog.MIN_PLAUSIBLE_MODEL_BYTES
}
