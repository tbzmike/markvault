package com.tebogo.markvault.llm

import java.io.File

/**
 * v4.20.0 — Catalog of on-device chat LLMs available for RAG over the user's
 * library. Mirrors the structure of [com.tebogo.markvault.search.ModelCatalog]
 * (the embedding-model catalog) so the same install / delete / picker UX
 * patterns can be reused.
 *
 * ## Why one model right now
 *
 * Only Gemma 3 1B IT is listed in v4.20.0. The catalog is structured so
 * additional models (Phi-3.5 mini, Llama 3.2 1B, Qwen 2.5 1.5B variants)
 * can be added later as a single new entry in [all] without UI changes.
 *
 * ## Memory budget rationale
 *
 * On the user's Redmi Note 10 Pro (6 GB RAM total), with BGE-large
 * embedding model loaded (~340 MB), Room + WebView + Compose UI, the
 * working LLM budget is roughly 1.5–2 GB. Gemma 3 1B at 4-bit fits
 * comfortably; Gemma 3n E2B (~1.9 GB just for weights + memory-mapped
 * embeddings) is on the hairy edge of OOM. We pick the safer option for
 * v1.
 */

/**
 * Describes a single chat LLM that the user can install on-device. All
 * fields are user-visible; honesty over marketing.
 */
data class ChatModelDescriptor(
    /** Stable identifier, e.g. "gemma3-1b-it-q4". Used as DB / Prefs key. */
    val id: String,
    /** Human-readable name shown in the model picker. */
    val displayName: String,
    /** Short label shown in compact UI (e.g. "Gemma 3 1B"). */
    val shortName: String,
    /** A 2–3 sentence honest description shown in the install dialog. */
    val description: String,
    /** Where to download the model from. Stable Hugging Face resolve URL. */
    val downloadUrl: String,
    /** Local filename the downloaded model will be saved under. */
    val localFilename: String,
    /** Approximate download size in megabytes, shown in install dialog. */
    val approxSizeMb: Int,
    /** Approximate RAM footprint once loaded, shown in install dialog. */
    val approxRamMb: Int,
    /**
     * Max prompt context window in tokens. Constrains how many notes we
     * can fit into a RAG prompt. Gemma 3 1B is 32K context but in practice
     * we cap at ~3K to leave room for generation and stay quick.
     */
    val contextTokens: Int,
    /** True when this model is offered in the UI. */
    val enabled: Boolean = true
)

object ChatModelCatalog {

    /**
     * Gemma 3 1B Instruction-tuned, 4-bit quantised, in LiteRT-LM's
     * `.litertlm` bundle format.
     *
     * Source: Hugging Face's `litert-community` org, which hosts the
     * MediaPipe / LiteRT-LM compatible variants of the official Google
     * Gemma releases. The `q4_block-128_ekv4096` variant is the one Google
     * recommends for general mobile use — block-quantised 4-bit weights
     * with 4096-token KV cache budget (sufficient for our ≤3K-token
     * RAG prompts).
     *
     * If the URL stops resolving in the future, Google AI Edge Gallery is
     * a working fallback source — same file, different host.
     */
    val GEMMA_3_1B_IT_Q4 = ChatModelDescriptor(
        id = "gemma3-1b-it-q4",
        displayName = "Gemma 3 1B Instruct (4-bit)",
        shortName = "Gemma 3 1B",
        description = "Google's lightest 2026 small language model, 4-bit " +
            "quantised. Designed for on-device chat. Decent quality on " +
            "summarisation and short Q&A over retrieved notes; not as " +
            "deep on multi-step reasoning as cloud models. Best for " +
            "drafting and lookup over your library, not deep theological " +
            "synthesis.",
        downloadUrl = "https://huggingface.co/litert-community/Gemma3-1B-IT/" +
            "resolve/main/Gemma3-1B-IT_multi-prefill-seq_q4_ekv4096.litertlm",
        localFilename = "gemma3-1b-it-q4.litertlm",
        approxSizeMb = 530,
        approxRamMb = 1500,
        contextTokens = 4096,
        enabled = true
    )

    /** Every model offered in the picker. Order = display order. */
    val all: List<ChatModelDescriptor> = listOf(GEMMA_3_1B_IT_Q4)

    /** Convenience: the default-recommended model. */
    val default: ChatModelDescriptor get() = GEMMA_3_1B_IT_Q4

    /** Lookup by id. */
    fun byId(id: String): ChatModelDescriptor? = all.firstOrNull { it.id == id }

    /** Plausibility floor for "the file is downloaded and probably real". */
    const val MIN_PLAUSIBLE_MODEL_BYTES = 100_000_000L  // 100 MB
}

/**
 * Where the chat model lives on disk for a given descriptor + context.
 * Top-level helper (not in the object) so it can be inlined into download
 * code that already has a Context but doesn't want to take a Catalog
 * dependency.
 */
fun ChatModelDescriptor.fileIn(filesDir: File): File = File(filesDir, localFilename)

/** Whether this model is currently installed and big enough to be plausible. */
fun ChatModelDescriptor.isInstalled(filesDir: File): Boolean {
    val f = fileIn(filesDir)
    return f.exists() && f.length() > ChatModelCatalog.MIN_PLAUSIBLE_MODEL_BYTES
}
