package com.tebogo.markvault.llm

import java.io.File

/**
 * v5.4.59 — Catalog of on-device chat LLMs available for RAG / multi-query
 * retrieval over the user's library. Two models are now offered:
 *
 *   • Qwen 3 0.6B mixed-INT4  — 400 MB / ~900 MB RAM. Comfortable on all
 *     devices; default.
 *
 *   • Qwen 3 4B channel-INT8  — 5 280 MB / ~5 800 MB RAM.  Better query
 *     expansion quality; requires a device with ≥ 8 GB RAM to avoid OOM.
 *     On the Redmi Note 10 Pro (6 GB) loading this model may trigger the
 *     Android low-memory killer — use with caution and close other apps.
 *
 * The catalog is structured so additional models can be added as a single
 * new entry in [all] without any UI changes.
 */

/**
 * Describes a single chat LLM that the user can install on-device.
 */
data class ChatModelDescriptor(
    /** Stable identifier. Used as DB / Prefs key. */
    val id: String,
    /** Human-readable name shown in the model picker. */
    val displayName: String,
    /** Short label shown in compact UI. */
    val shortName: String,
    /** A 2–3 sentence honest description shown in the install dialog. */
    val description: String,
    /** Stable Hugging Face resolve URL. */
    val downloadUrl: String,
    /** Local filename the downloaded model will be saved under. */
    val localFilename: String,
    /** Approximate download size in megabytes. */
    val approxSizeMb: Int,
    /** Approximate RAM footprint once loaded, in megabytes. */
    val approxRamMb: Int,
    /**
     * Max prompt context window in tokens. Constrains how many notes we
     * can fit into a RAG prompt.
     */
    val contextTokens: Int,
    /** True when this model is offered in the UI. */
    val enabled: Boolean = true
)

object ChatModelCatalog {

    /**
     * Qwen 3 0.6B — mixed 4-bit quantised, LiteRT-LM `.litertlm` format.
     *
     * Apache 2.0 — no signup, no licence-click required. ~400 MB disk,
     * ~900 MB peak RAM. Safe alongside BGE-large on the Redmi Note 10 Pro.
     * Good quality for short query expansion; lighter reasoning depth than 4B.
     */
    val QWEN3_0_6B_INT4 = ChatModelDescriptor(
        id = "qwen3-0_6b-mixed-int4",
        displayName = "Qwen 3 0.6B (mixed 4-bit)",
        shortName = "Qwen 3 0.6B",
        description = "Alibaba's compact language model, mixed 4-bit quantised. " +
            "Apache 2.0 — no signup. ~400 MB download, ~900 MB RAM when loaded. " +
            "Safe on 6 GB devices alongside BGE-large. Ideal for query expansion " +
            "in the multi-query retrieval pipeline; lighter reasoning than 4B.",
        downloadUrl = "https://huggingface.co/litert-community/Qwen3-0.6B/" +
            "resolve/main/qwen3_0_6b_mixed_int4.litertlm",
        localFilename = "qwen3-0_6b-mixed-int4.litertlm",
        approxSizeMb = 400,
        approxRamMb = 900,
        contextTokens = 4096,
        enabled = true
    )

    /**
     * Qwen 3 4B — channel-wise INT8 weights, Float32 KV cache, LiteRT-LM
     * `.litertlm` format. Official litert-community build.
     *
     * ## Why this for multi-query retrieval
     *
     * The multi-query retrieval pipeline asks the LLM to rephrase one
     * user query into several semantically diverse sub-queries. A larger
     * model produces more creative and accurate rephrasing, improving
     * recall across the 14k-note library. The 4B gives meaningfully
     * better query expansion than the 0.6B for complex theological or
     * technical questions.
     *
     * ## RAM warning — important on the Redmi Note 10 Pro (6 GB)
     *
     * Channel-wise INT8 weights for 4B parameters amount to ~4 GB on disk
     * (the 5.28 GB file also includes Float32 KV cache buffers, embeddings,
     * and metadata). Peak RAM at inference time is estimated at ~5.8 GB.
     * On a 6 GB device this leaves ~0.2 GB headroom after the OS kernel,
     * BGE-large (~340 MB), Room, and Compose overhead — Android's low-memory
     * killer will terminate the app if memory pressure spikes.
     *
     * **Recommendation**: close all other apps, disable BGE-large reranking
     * temporarily, and ensure at least 3 GB free RAM before loading this
     * model. Switching back to 0.6B after query expansion is generated
     * and before opening Reader will reduce memory pressure.
     *
     * ## File details
     *
     * Quantization: channel-wise INT8 weights, Float32 KV cache.
     * Tested on macOS, Linux, and Android CPU (litert-community page).
     * Apache 2.0 — no signup or licence-acceptance required.
     */
    val QWEN3_4B_INT8 = ChatModelDescriptor(
        id = "qwen3-4b-channelwise-int8",
        displayName = "Qwen 3 4B (channel-wise INT8)",
        shortName = "Qwen 3 4B",
        description = "Qwen 3 4B at channel-wise INT8 quantisation. Significantly " +
            "better query expansion for multi-query retrieval. Apache 2.0 — no signup. " +
            "⚠\uFE0F Large: ~5 280 MB download, ~5 800 MB RAM. May OOM on 6 GB devices — " +
            "close all other apps before loading. Recommended for devices with ≥ 8 GB RAM.",
        downloadUrl = "https://huggingface.co/litert-community/Qwen3-4B/" +
            "resolve/main/qwen3_4b_channelwise_int8_float32kv.litertlm",
        localFilename = "qwen3-4b-channelwise-int8.litertlm",
        approxSizeMb = 5280,
        approxRamMb = 5800,
        contextTokens = 4096,
        enabled = true
    )

    /** Every model offered in the picker. Order = display order. */
    val all: List<ChatModelDescriptor> = listOf(QWEN3_0_6B_INT4, QWEN3_4B_INT8)

    /**
     * The default model — Qwen 3 0.6B. Safe on all supported devices.
     * Used as fallback when the saved preference ID is unknown.
     */
    val default: ChatModelDescriptor get() = QWEN3_0_6B_INT4

    /** Lookup by id. Returns null if the id is unknown. */
    fun byId(id: String): ChatModelDescriptor? = all.firstOrNull { it.id == id }

    /** Plausibility floor — file must exceed this to be considered a real model. */
    const val MIN_PLAUSIBLE_MODEL_BYTES = 100_000_000L  // 100 MB
}

/** Where the model lives on disk for a given descriptor + files directory. */
fun ChatModelDescriptor.fileIn(filesDir: File): File = File(filesDir, localFilename)

/** True iff this model is currently installed and passes the plausibility check. */
fun ChatModelDescriptor.isInstalled(filesDir: File): Boolean {
    val f = fileIn(filesDir)
    return f.exists() && f.length() > ChatModelCatalog.MIN_PLAUSIBLE_MODEL_BYTES
}
