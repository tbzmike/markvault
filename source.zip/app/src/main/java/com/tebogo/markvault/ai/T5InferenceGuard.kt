package com.tebogo.markvault.ai

/** Safety guard around T5 inference execution. */
object T5InferenceGuard {
    fun allowExecution(): Boolean {
        return T5InferenceLifecycle.isActive() || T5ExpansionAvailability.isAvailable()
    }
}
