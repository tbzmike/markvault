package com.tebogo.markvault.ai

import android.content.Context
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.launch

/**
 * v5.4.75 — Model picker bridge.
 *
 * Connects UI model selection to the persisted retrieval model.
 */
object RetrievalModelPickerBridge {

    fun restoreSelection(context: Context, scope: CoroutineScope) {
        scope.launch {
            val saved = AiPreferenceStore.loadModel(context)
            runCatching {
                val model = RetrievalModelManager.Model.valueOf(saved)
                RetrievalModelManager.setModel(model)
                RetrievalModelSelection.select(
                    RetrievalModelSelection.Model.valueOf(saved)
                )
            }
        }
    }

    fun select(
        context: Context,
        scope: CoroutineScope,
        model: RetrievalModelManager.Model
    ) {
        scope.launch {
            RetrievalModelManager.setModel(model)
            AiPreferenceStore.saveModel(context, model.name)
        }
    }
}
