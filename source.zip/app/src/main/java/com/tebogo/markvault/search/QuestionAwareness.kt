package com.tebogo.markvault.search

/**
 * v5.5.14 — Deterministic question-intent detector and answer-oriented query builder.
 *
 * This layer is deliberately model-independent. It recognizes direct and indirect
 * questions even without a trailing '?', classifies the expected answer shape, and
 * emits retrieval queries that look like likely answers instead of merely paraphrasing
 * the question. The original user query remains in the retrieval plan as a secondary
 * signal whenever answer-oriented variants are available.
 */
object QuestionAwareness {

    enum class QuestionType(val label: String) {
        WHY_REASON("WHY / reason"),
        AGE("AGE"),
        COUNT("COUNT / quantity"),
        TIME_DATE("WHEN / date / time"),
        LOCATION("WHERE / location"),
        PERSON_IDENTITY("WHO / identity"),
        DEFINITION_MEANING("DEFINITION / meaning"),
        METHOD_PROCESS("HOW / method"),
        CHOICE("WHICH / choice"),
        YES_NO("YES / NO"),
        OTHER("GENERAL QUESTION")
    }

    data class WeightedAnswerQuery(val text: String, val weight: Double)

    data class Analysis(
        val isQuestion: Boolean,
        val type: QuestionType? = null,
        val answerQueries: List<WeightedAnswerQuery> = emptyList()
    ) {
        val usedSuccessfully: Boolean get() = isQuestion && answerQueries.isNotEmpty()
        val primarySemanticQuery: String? get() = answerQueries.firstOrNull()?.text
    }

    private val directInterrogatives = setOf(
        "who", "whom", "whose", "what", "which", "where", "when", "why", "how"
    )

    private val auxiliaryStarters = setOf(
        "am", "is", "are", "was", "were", "do", "does", "did", "can", "could",
        "will", "would", "shall", "should", "may", "might", "must", "has", "have", "had"
    )

    private val indirectQuestionMarkers = listOf(
        "tell me why", "tell me how", "tell me when", "tell me where", "tell me who", "tell me what",
        "can you tell me", "could you tell me", "i want to know", "i would like to know",
        "do you know why", "do you know how", "do you know when", "do you know where", "do you know who",
        "explain why", "explain how", "find out why", "find out how", "find out when", "find out where"
    )

    private val questionPunctuation = setOf('?', '？', '؟', '¿')

    fun analyze(raw: String): Analysis {
        val cleaned = clean(raw)
        if (cleaned.isBlank()) return Analysis(false)
        val lower = cleaned.lowercase()
        val words = Regex("[\\p{L}\\p{N}']+").findAll(lower).map { it.value }.toList()
        if (words.isEmpty()) return Analysis(false)

        val punctuationSignal = raw.any { it in questionPunctuation }
        val directSignal = words.first() in directInterrogatives
        val auxiliarySignal = words.first() in auxiliaryStarters
        val indirectSignal = indirectQuestionMarkers.any { lower.startsWith(it) || lower.contains(" $it") }
        val compoundSignal = listOf(
            "how many", "how much", "how old", "how long", "how far", "how often",
            "what age", "what year", "what time", "what date", "what does", "what do",
            "who was", "who is", "where did", "where was", "where is", "when did", "when was",
            "why did", "why was", "why is", "how did", "how was", "how is"
        ).any { lower.startsWith(it) || lower.contains(" $it") }

        val isQuestion = punctuationSignal || directSignal || auxiliarySignal || indirectSignal || compoundSignal
        if (!isQuestion) return Analysis(false)

        // For indirect requests ("tell me why…", "I want to know how old…"),
        // classify and rewrite the embedded question rather than the conversational
        // wrapper. Detection still uses the complete user query above.
        val answerCore = extractQuestionCore(cleaned)
        val coreLower = answerCore.lowercase()
        val coreWords = Regex("[\\p{L}\\p{N}']+").findAll(coreLower).map { it.value }.toList()
        val type = classify(coreLower, coreWords.ifEmpty { words })
        val variants = buildAnswerQueries(answerCore, type)
            .mapIndexed { index, text ->
                WeightedAnswerQuery(text, listOf(1.0, 0.94, 0.88, 0.82).getOrElse(index) { 0.78 })
            }
            .distinctBy { it.text.lowercase() }
            .take(4)
        return Analysis(true, type, variants)
    }

    private fun classify(lower: String, words: List<String>): QuestionType = when {
        Regex("\\bhow\\s+old\\b|\\bwhat\\s+age\\b").containsMatchIn(lower) -> QuestionType.AGE
        Regex("\\bhow\\s+many\\b|\\bhow\\s+much\\b|\\bnumber\\s+of\\b").containsMatchIn(lower) -> QuestionType.COUNT
        Regex("\\bwhat\\s+(year|date|time)\\b|\\bwhen\\b|\\bhow\\s+long\\s+ago\\b").containsMatchIn(lower) -> QuestionType.TIME_DATE
        Regex("\\bwhere\\b|\\bwhat\\s+place\\b|\\bwhich\\s+place\\b").containsMatchIn(lower) -> QuestionType.LOCATION
        Regex("\\bwho\\b|\\bwhom\\b|\\bwhose\\b").containsMatchIn(lower) -> QuestionType.PERSON_IDENTITY
        Regex("\\bwhat\\s+(does|do)\\b.*\\bmean\\b|\\bmeaning\\s+of\\b|\\bdefine\\b").containsMatchIn(lower) -> QuestionType.DEFINITION_MEANING
        Regex("\\bwhy\\b|\\breason\\b|\\bwhat\\s+caused\\b|\\bwhat\\s+was\\s+the\\s+cause\\b").containsMatchIn(lower) -> QuestionType.WHY_REASON
        words.firstOrNull() == "how" || Regex("\\bhow\\s+(did|does|do|can|could|is|was)\\b").containsMatchIn(lower) -> QuestionType.METHOD_PROCESS
        words.firstOrNull() == "which" -> QuestionType.CHOICE
        words.firstOrNull() in auxiliaryStarters -> QuestionType.YES_NO
        else -> QuestionType.OTHER
    }

    private fun buildAnswerQueries(cleaned: String, type: QuestionType): List<String> {
        val out = LinkedHashSet<String>()
        fun add(s: String) {
            val v = clean(s).trim(' ', '.', ',', ';', ':', '?', '!', '？', '؟')
            if (v.length >= 3 && !v.equals(cleaned, ignoreCase = true)) out += v
        }

        when (type) {
            QuestionType.AGE -> {
                val m = Regex("(?i)^how\\s+old\\s+(?:was|is|were|are)\\s+(.+?)(?:\\s+when\\s+(.+))?$").find(cleaned)
                    ?: Regex("(?i)^how\\s+old\\s+(.+?)\\s+(?:was|is|were|are)(?:\\s+when\\s+(.+))?$").find(cleaned)
                val target = m?.groupValues?.getOrNull(1)?.trim().orEmpty()
                val event = m?.groupValues?.getOrNull(2)?.trim().orEmpty()
                if (target.isNotBlank()) {
                    add("$target was years old")
                    add("age of $target")
                    if (event.contains(Regex("(?i)die|died|death"))) {
                        add("$target died at age")
                        add("$target age at death")
                    } else if (event.isNotBlank()) {
                        add("$target was years old when $event")
                    }
                }
            }
            QuestionType.COUNT -> {
                val have = Regex("(?i)^how\\s+many\\s+(.+?)\\s+did\\s+(.+?)\\s+have$").find(cleaned)
                    ?: Regex("(?i)^how\\s+many\\s+(.+?)\\s+(?:does|do)\\s+(.+?)\\s+have$").find(cleaned)
                if (have != null) {
                    val item = have.groupValues[1].trim()
                    val subject = have.groupValues[2].trim()
                    add("$subject had $item")
                    add("number of $item $subject had")
                    if (item.lowercase() in setOf("child", "children", "sons", "daughters", "offspring")) {
                        add("$subject sons and daughters")
                        add("$subject other children")
                    }
                } else {
                    val rest = cleaned.replace(Regex("(?i)^how\\s+(many|much)\\s+"), "")
                    add("number of $rest")
                    add("quantity of $rest")
                }
            }
            QuestionType.WHY_REASON -> {
                val passive = Regex("(?i)^why\\s+(was|were|is|are)\\s+(.+?)\\s+([\\p{L}][\\p{L} '-]+)$").find(cleaned)
                val did = Regex("(?i)^why\\s+did\\s+(.+?)\\s+([\\p{L}][\\p{L} '-]+)$").find(cleaned)
                when {
                    passive != null -> {
                        val aux = passive.groupValues[1].lowercase()
                        val subject = passive.groupValues[2].trim()
                        val predicate = passive.groupValues[3].trim()
                        add("$subject $aux $predicate because")
                        if (predicate.contains(Regex("(?i)kill|execut|put to death"))) {
                            // Answer vocabulary matters more than another paraphrase of
                            // the question: articles may say "died for" / "put to death"
                            // even when the user asks why someone was "killed".
                            add("$subject died for")
                            add("$subject died because")
                            add("reason for death of $subject")
                        } else {
                            add("reason $subject $aux $predicate")
                            add("$subject $aux $predicate for")
                            if (predicate.contains(Regex("(?i)die|death"))) {
                                add("reason for death of $subject")
                            }
                        }
                    }
                    did != null -> {
                        val subject = did.groupValues[1].trim()
                        val action = toAnswerVerbPhrase(did.groupValues[2].trim())
                        add("$subject $action because")
                        add("reason $subject $action")
                        add("purpose $subject $action")
                    }
                    else -> {
                        val rest = cleaned.replace(Regex("(?i)^why\\s+"), "")
                        add("reason $rest")
                        add("cause $rest")
                        add("$rest because")
                    }
                }
            }
            QuestionType.TIME_DATE -> {
                val did = Regex("(?i)^when\\s+did\\s+(.+?)\\s+(.+)$").find(cleaned)
                val be = Regex("(?i)^when\\s+(?:was|is|were|are)\\s+(.+)$").find(cleaned)
                when {
                    did != null -> {
                        val subject = did.groupValues[1].trim()
                        val action = toAnswerVerbPhrase(did.groupValues[2].trim())
                        add("$subject $action in")
                        add("date of $subject $action")
                        add("time of $subject $action")
                    }
                    be != null -> {
                        val target = be.groupValues[1].trim()
                        add("$target was in")
                        add("date of $target")
                        add("time of $target")
                    }
                    else -> add("date ${cleaned.replace(Regex("(?i)^when\\s+"), "")}")
                }
            }
            QuestionType.LOCATION -> {
                val born = Regex("(?i)^where\\s+(was|is)\\s+(.+?)\\s+born$").find(cleaned)
                val be = Regex("(?i)^where\\s+(?:was|is|were|are)\\s+(.+)$").find(cleaned)
                val did = Regex("(?i)^where\\s+did\\s+(.+?)\\s+(.+)$").find(cleaned)
                when {
                    born != null -> {
                        val aux = born.groupValues[1].lowercase()
                        val target = born.groupValues[2].trim()
                        add("$target $aux born in")
                        add("birthplace of $target")
                        add("$target birthplace")
                    }
                    be != null -> {
                        val target = be.groupValues[1].trim()
                        add("$target was in")
                        add("location of $target")
                        add("$target located in")
                    }
                    did != null -> {
                        val subject = did.groupValues[1].trim()
                        val action = toAnswerVerbPhrase(did.groupValues[2].trim())
                        add("$subject $action at")
                        add("location of $subject $action")
                    }
                    else -> add("location ${cleaned.replace(Regex("(?i)^where\\s+"), "")}")
                }
            }
            QuestionType.PERSON_IDENTITY -> {
                val action = Regex("(?i)^who\\s+([\\p{L}]+)\\s+(.+)$").find(cleaned)
                val be = Regex("(?i)^who\\s+(?:was|is)\\s+(.+)$").find(cleaned)
                when {
                    action != null && action.groupValues[1].lowercase() in setOf("killed", "murdered", "executed", "betrayed", "wrote", "built", "led") -> {
                        val verb = action.groupValues[1].trim()
                        val target = action.groupValues[2].trim()
                        if (verb in setOf("killed", "murdered", "executed", "betrayed")) add("$target was $verb by")
                        add("$verb $target")
                        add("person who $verb $target")
                    }
                    be != null -> {
                        val target = be.groupValues[1].trim()
                        add("$target was")
                        add("identity of $target")
                    }
                }
            }
            QuestionType.DEFINITION_MEANING -> {
                val meaning = Regex("(?i)^what\\s+(?:does|do)\\s+(.+?)\\s+mean$").find(cleaned)
                val whatIs = Regex("(?i)^what\\s+is\\s+(.+)$").find(cleaned)
                val target = meaning?.groupValues?.getOrNull(1)?.trim()
                    ?: whatIs?.groupValues?.getOrNull(1)?.trim().orEmpty()
                if (target.isNotBlank()) {
                    add("$target means")
                    add("meaning of $target")
                    add("$target definition")
                }
            }
            QuestionType.METHOD_PROCESS -> {
                val did = Regex("(?i)^how\\s+did\\s+(.+?)\\s+(.+)$").find(cleaned)
                if (did != null) {
                    val subject = did.groupValues[1].trim()
                    val action = toAnswerVerbPhrase(did.groupValues[2].trim())
                    add("$subject $action by")
                    add("way $subject $action")
                    add("method $subject $action")
                } else {
                    val rest = cleaned.replace(Regex("(?i)^how\\s+"), "")
                    add("method $rest")
                    add("way $rest")
                }
            }
            QuestionType.CHOICE -> {
                val rest = cleaned.replace(Regex("(?i)^which\\s+"), "")
                add("selected $rest")
                add("choice $rest")
            }
            QuestionType.YES_NO -> {
                val modalBe = Regex("(?i)^(can|could|will|would|shall|should|may|might|must)\\s+(.+?)\\s+(be|have)\\s+(.+)$").find(cleaned)
                val beQuestion = Regex("(?i)^(am|is|are|was|were|has|have|had)\\s+(.+)$").find(cleaned)
                when {
                    modalBe != null -> {
                        val modal = modalBe.groupValues[1].lowercase()
                        val subject = modalBe.groupValues[2].trim()
                        val verb = modalBe.groupValues[3].lowercase()
                        val rest = modalBe.groupValues[4].trim()
                        add("$subject $modal $verb $rest")
                    }
                    beQuestion != null -> {
                        val rest = beQuestion.groupValues[2].trim()
                        add(rest)
                    }
                }
            }
            QuestionType.OTHER -> {
                // Detection can legitimately succeed without a safe deterministic
                // answer-shape rewrite. In that case Question Awareness is reported
                // as detected-but-not-used rather than inventing a risky query.
            }
        }
        return out.toList()
    }

    private fun toAnswerVerbPhrase(raw: String): String {
        val trimmed = raw.trim()
        if (trimmed.isBlank()) return trimmed
        val first = trimmed.substringBefore(' ').lowercase()
        val rest = trimmed.substringAfter(' ', "")
        val past = when (first) {
            "die" -> "died"
            "kill" -> "killed"
            "come" -> "came"
            "go" -> "went"
            "send" -> "sent"
            "say" -> "said"
            "make" -> "made"
            "take" -> "took"
            "give" -> "gave"
            "become" -> "became"
            "write" -> "wrote"
            "build" -> "built"
            "lead" -> "led"
            "fall" -> "fell"
            "rise" -> "rose"
            "begin" -> "began"
            else -> first
        }
        return if (rest.isBlank()) past else "$past $rest"
    }

    private fun extractQuestionCore(cleaned: String): String {
        val patterns = listOf(
            Regex("(?i)^(?:please\\s+)?tell\\s+me\\s+(?=(why|how|when|where|who|what|which)\\b)"),
            Regex("(?i)^i\\s+(?:want|would\\s+like)\\s+to\\s+know\\s+(?=(why|how|when|where|who|what|which)\\b)"),
            Regex("(?i)^(?:can|could)\\s+you\\s+tell\\s+me\\s+(?=(why|how|when|where|who|what|which)\\b)"),
            Regex("(?i)^do\\s+you\\s+know\\s+(?=(why|how|when|where|who|what|which)\\b)"),
            Regex("(?i)^explain\\s+(?=(why|how)\\b)"),
            Regex("(?i)^find\\s+out\\s+(?=(why|how|when|where|who|what|which)\\b)")
        )
        var core = cleaned
        for (pattern in patterns) {
            val stripped = core.replaceFirst(pattern, "").trim()
            if (stripped != core) return stripped
        }
        return core
    }

    private fun clean(raw: String): String = raw
        .trim()
        .replace(Regex("[?？؟]+$"), "")
        .replace(Regex("\\s+"), " ")
        .trim()
}
