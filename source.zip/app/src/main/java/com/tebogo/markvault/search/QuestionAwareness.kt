package com.tebogo.markvault.search

/**
 * v5.5.14 — Deterministic question-intent detector and answer-oriented query builder.
 *
 * This layer is deliberately model-independent. It recognizes direct and indirect
 * questions even without a trailing '?', classifies the expected answer shape, and
 * emits retrieval queries that look like likely answers instead of merely paraphrasing
 * the question. The original user query remains in the retrieval plan as a secondary
 * signal whenever answer-oriented variants are available.
 */
object QuestionAwareness {

    enum class QuestionType(val label: String) {
        WHY_REASON("WHY / reason"),
        AGE("AGE"),
        COUNT("COUNT / quantity"),
        TIME_DATE("WHEN / date / time"),
        LOCATION("WHERE / location"),
        PERSON_IDENTITY("WHO / identity"),
        DEFINITION_MEANING("DEFINITION / meaning"),
        METHOD_PROCESS("HOW / method"),
        CHOICE("WHICH / choice"),
        YES_NO("YES / NO"),
        OTHER("GENERAL QUESTION")
    }

    data class WeightedAnswerQuery(val text: String, val weight: Double)

    data class Analysis(
        val isQuestion: Boolean,
        val type: QuestionType? = null,
        val answerQueries: List<WeightedAnswerQuery> = emptyList()
    ) {
        val usedSuccessfully: Boolean get() = isQuestion && answerQueries.isNotEmpty()
        val primarySemanticQuery: String? get() = answerQueries.firstOrNull()?.text
    }

    private val directInterrogatives = setOf(
        "who", "whom", "whose", "what", "which", "where", "when", "why", "how"
    )

    private val auxiliaryStarters = setOf(
        "am", "is", "are", "was", "were", "do", "does", "did", "can", "could",
        "will", "would", "shall", "should", "may", "might", "must", "has", "have", "had"
    )

    private val beAuxiliaries = setOf("am", "is", "are", "was", "were")
    private val doHaveAuxiliaries = setOf("do", "does", "did", "has", "have", "had")
    private val modalAuxiliaries = setOf(
        "can", "could", "will", "would", "shall", "should", "may", "might", "must"
    )

    /**
     * v5.5.16 — These are deliberately prefix-only. The old detector used
     * `contains(" marker")`, so an ordinary topical query that merely quoted a
     * conversational phrase could become a question accidentally.
     */
    private val indirectQuestionMarkers = listOf(
        "tell me why", "tell me how", "tell me when", "tell me where", "tell me who", "tell me what",
        "can you tell me", "could you tell me", "i want to know", "i would like to know",
        "do you know why", "do you know how", "do you know when", "do you know where", "do you know who",
        "explain why", "explain how", "find out why", "find out how", "find out when", "find out where"
    )

    private val questionPunctuation = setOf('?', '？', '؟', '¿')

    /**
     * Common finite/action verbs used only as a *grammar signal*. This is not a
     * synonym list and never changes scoring. It lets us distinguish a clause
     * such as "who killed Goliath" from a noun-style search such as "who magazine".
     */
    private val questionVerbSignals = setOf(
        "be", "been", "become", "became", "begin", "began", "build", "built",
        "cause", "caused", "come", "came", "create", "created", "die", "died",
        "do", "does", "did", "fall", "fell", "forgive", "forgave", "give", "gave",
        "go", "went", "happen", "happened", "have", "has", "had", "kill", "killed",
        "lead", "led", "make", "made", "mean", "means", "murder", "murdered",
        "return", "returned", "rise", "rose", "say", "said", "save", "saved",
        "send", "sent", "teach", "taught", "take", "took", "write", "wrote",
        "live", "lived", "know", "knew", "see", "saw", "hear", "heard",
        "exist", "exists", "love", "loves", "care", "cares", "believe", "believes",
        "worship", "worships", "pray", "prays", "speak", "speaks", "work", "works",
        "rule", "rules", "reign", "reigns", "judge", "judges", "obey", "obeys",
        "vote", "votes", "drink", "drinks", "survive", "survives", "suffer", "suffered",
        "destroy", "destroyed", "promise", "promised", "choose", "chose", "call", "called",
        "betray", "betrayed", "execute", "executed", "resurrect", "resurrected"
    )

    fun analyze(raw: String): Analysis {
        val cleaned = clean(raw)
        if (cleaned.isBlank()) return Analysis(false)

        // Classify the embedded question for conversational requests such as
        // "tell me why ..." rather than classifying the wrapper itself.
        val answerCore = extractQuestionCore(cleaned)
        val coreLower = answerCore.lowercase()
        val coreWords = wordsOf(coreLower)
        if (coreWords.isEmpty()) return Analysis(false)

        val rawTrimmed = raw.trim()
        val trailingQuestionPunctuation = rawTrimmed.lastOrNull() in questionPunctuation
        val indirectSignal = indirectQuestionMarkers.any { marker ->
            val lower = cleaned.lowercase()
            lower == marker || lower.startsWith("$marker ")
        }
        val directWhSignal = looksLikeWhQuestion(coreLower, coreWords, trailingQuestionPunctuation)
        val auxiliarySignal = looksLikeAuxiliaryQuestion(coreWords, trailingQuestionPunctuation)

        // A terminal question mark is strong evidence for ordinary prose, but it
        // must not turn URLs/search syntax such as `page?id=4` into questions.
        val punctuationSignal = trailingQuestionPunctuation &&
            coreWords.size >= 2 && !looksLikeSearchSyntax(cleaned)

        val isQuestion = indirectSignal || directWhSignal || auxiliarySignal || punctuationSignal
        if (!isQuestion) return Analysis(false)

        val type = classify(coreLower, coreWords)
        val variants = buildAnswerQueries(answerCore, type)
            .mapIndexed { index, text ->
                WeightedAnswerQuery(text, listOf(1.0, 0.94, 0.88, 0.82).getOrElse(index) { 0.78 })
            }
            .distinctBy { it.text.lowercase() }
            .take(4)
        return Analysis(true, type, variants)
    }

    /**
     * v5.5.16 — Conservative WH-clause detector.
     *
     * A WH word by itself is no longer enough. This prevents normal noun-style
     * searches such as "who magazine", "when articles", and especially
     * "how old testament prophecies" from being labelled as questions. Direct
     * grammatical forms, answer-type compounds, or terminal question punctuation
     * still count strongly.
     */
    private fun looksLikeWhQuestion(
        lower: String,
        words: List<String>,
        trailingQuestionPunctuation: Boolean
    ): Boolean {
        val first = words.firstOrNull() ?: return false
        if (first !in directInterrogatives || words.size < 2) return false
        val second = words.getOrNull(1).orEmpty()
        val laterHasVerb = words.drop(1).take(6).any { it in questionVerbSignals || it in auxiliaryStarters }

        return when (first) {
            "how" -> {
                // "how old Testament ..." is a topical noun phrase, not an AGE question.
                if (Regex("^how\\s+old\\s+testament\\b").containsMatchIn(lower)) return false
                Regex(
                    "^how\\s+(many|much|old|long|far|often)\\b|" +
                        "^how\\s+(am|is|are|was|were|do|does|did|can|could|will|would|should|may|might|must|has|have|had)\\b"
                ).containsMatchIn(lower) || laterHasVerb || trailingQuestionPunctuation
            }
            "what" -> Regex(
                "^what\\s+(age|year|date|time|place|meaning|number)\\b|" +
                    "^what\\s+(am|is|are|was|were|do|does|did|can|could|will|would|should|has|have|had)\\b|" +
                    "^what\\s+(happened|caused|made|makes|means)\\b"
            ).containsMatchIn(lower) || laterHasVerb || trailingQuestionPunctuation
            "which" -> second in auxiliaryStarters || laterHasVerb || trailingQuestionPunctuation
            "who", "whom", "whose", "where", "when", "why" ->
                second in auxiliaryStarters || laterHasVerb || trailingQuestionPunctuation
            else -> false
        }
    }

    /** v5.5.16 — Validate inversion instead of treating any leading auxiliary as a question. */
    private fun looksLikeAuxiliaryQuestion(words: List<String>, trailingQuestionPunctuation: Boolean): Boolean {
        val first = words.firstOrNull() ?: return false
        if (first !in auxiliaryStarters || words.size < 2) return false
        if (trailingQuestionPunctuation) return true

        return when (first) {
            in beAuxiliaries -> words.size >= 3
            in doHaveAuxiliaries -> words.size >= 3 && words.drop(2).take(4).any { it in questionVerbSignals }
            in modalAuxiliaries -> words.size >= 3 && words.drop(2).take(4).any { it in questionVerbSignals }
            else -> false
        }
    }

    private fun looksLikeSearchSyntax(raw: String): Boolean {
        val lower = raw.lowercase()
        if ("://" in lower) return true
        if (Regex("\\b[a-z0-9._-]+\\?[a-z0-9._-]+=", RegexOption.IGNORE_CASE).containsMatchIn(lower)) return true
        if (Regex("\\b(site|file|path|tag|type):\\S+", RegexOption.IGNORE_CASE).containsMatchIn(raw)) return true
        return false
    }

    private fun wordsOf(lower: String): List<String> =
        Regex("[\\p{L}\\p{N}']+").findAll(lower).map { it.value }.toList()

    private fun isDefinitionCopulaQuestion(lower: String): Boolean {
        val match = Regex("^what\\s+(is|are)\\s+(.+)$").find(lower) ?: return false
        val targetWords = wordsOf(match.groupValues[2])
        if (targetWords.isEmpty() || targetWords.size > 8) return false
        val eventWords = setOf(
            "doing", "happening", "going", "saying", "teaching", "wearing",
            "working", "coming", "living", "located", "occurring"
        )
        return targetWords.none { it in eventWords || it in questionVerbSignals }
    }

    private fun classify(lower: String, words: List<String>): QuestionType = when {
        Regex("^how\\s+old\\b|^what\\s+age\\b")
            .containsMatchIn(lower) -> QuestionType.AGE
        Regex("^how\\s+(many|much)\\b|^what\\s+number\\b").containsMatchIn(lower) -> QuestionType.COUNT
        Regex("^what\\s+(year|date|time)\\b|^when\\b|^how\\s+long\\s+ago\\b").containsMatchIn(lower) -> QuestionType.TIME_DATE
        Regex("^where\\b|^what\\s+place\\b|^which\\s+place\\b").containsMatchIn(lower) -> QuestionType.LOCATION
        Regex("^(who|whom|whose)\\b").containsMatchIn(lower) -> QuestionType.PERSON_IDENTITY
        Regex("^what\\s+(does|do)\\b.*\\bmean\\b|^what\\s+(is|are)\\s+(?:the\\s+)?(meaning|definition)\\b|^meaning\\s+of\\b|^define\\b")
            .containsMatchIn(lower) || isDefinitionCopulaQuestion(lower) -> QuestionType.DEFINITION_MEANING
        Regex("^why\\b|^what\\s+caused\\b|^what\\s+was\\s+the\\s+cause\\b").containsMatchIn(lower) -> QuestionType.WHY_REASON
        words.firstOrNull() == "how" || Regex("^how\\s+(did|does|do|can|could|is|was)\\b").containsMatchIn(lower) -> QuestionType.METHOD_PROCESS
        words.firstOrNull() == "which" -> QuestionType.CHOICE
        words.firstOrNull() in auxiliaryStarters -> QuestionType.YES_NO
        else -> QuestionType.OTHER
    }

    private fun buildAnswerQueries(cleaned: String, type: QuestionType): List<String> {
        val out = LinkedHashSet<String>()
        fun add(s: String) {
            val v = clean(s).trim(' ', '.', ',', ';', ':', '?', '!', '？', '؟')
            if (v.length >= 3 && !v.equals(cleaned, ignoreCase = true)) out += v
        }

        when (type) {
            QuestionType.AGE -> {
                val howOld = Regex("(?i)^how\\s+old\\s+(?:was|is|were|are)\\s+(.+?)(?:\\s+when\\s+(.+))?$").find(cleaned)
                    ?: Regex("(?i)^how\\s+old\\s+(.+?)\\s+(?:was|is|were|are)(?:\\s+when\\s+(.+))?$").find(cleaned)
                val whatAge = Regex("(?i)^what\\s+age\\s+(?:was|is|were|are)\\s+(.+?)(?:\\s+when\\s+(.+))?$").find(cleaned)
                val elliptical = Regex("(?i)^how\\s+old\\s+(.+)$").find(cleaned)
                val match = howOld ?: whatAge
                val target = match?.groupValues?.getOrNull(1)?.trim()
                    ?: elliptical?.groupValues?.getOrNull(1)?.trim().orEmpty()
                val event = match?.groupValues?.getOrNull(2)?.trim().orEmpty()
                if (target.isNotBlank()) {
                    add("$target was years old")
                    add("age of $target")
                    if (event.contains(Regex("(?i)die|died|death"))) {
                        add("$target died at age")
                        add("$target age at death")
                    } else if (event.isNotBlank()) {
                        add("$target was years old when $event")
                    }
                }
            }
            QuestionType.COUNT -> {
                val have = Regex("(?i)^how\\s+many\\s+(.+?)\\s+did\\s+(.+?)\\s+have$").find(cleaned)
                    ?: Regex("(?i)^how\\s+many\\s+(.+?)\\s+(?:does|do)\\s+(.+?)\\s+have$").find(cleaned)
                if (have != null) {
                    val item = have.groupValues[1].trim()
                    val subject = have.groupValues[2].trim()
                    add("$subject had $item")
                    add("number of $item $subject had")
                    if (item.lowercase() in setOf("child", "children", "sons", "daughters", "offspring")) {
                        add("$subject sons and daughters")
                        add("$subject other children")
                    }
                } else {
                    val rest = cleaned.replace(Regex("(?i)^how\\s+(many|much)\\s+"), "")
                    add("number of $rest")
                    add("quantity of $rest")
                }
            }
            QuestionType.WHY_REASON -> {
                val passive = Regex("(?i)^why\\s+(was|were|is|are)\\s+(.+?)\\s+([\\p{L}][\\p{L} '-]+)$").find(cleaned)
                val did = Regex("(?i)^why\\s+did\\s+(.+?)\\s+([\\p{L}][\\p{L} '-]+)$").find(cleaned)
                when {
                    passive != null -> {
                        val aux = passive.groupValues[1].lowercase()
                        val subject = passive.groupValues[2].trim()
                        val predicate = passive.groupValues[3].trim()
                        add("$subject $aux $predicate because")
                        if (predicate.contains(Regex("(?i)kill|execut|put to death"))) {
                            // Answer vocabulary matters more than another paraphrase of
                            // the question: articles may say "died for" / "put to death"
                            // even when the user asks why someone was "killed".
                            add("$subject died for")
                            add("$subject died because")
                            add("reason for death of $subject")
                        } else {
                            add("reason $subject $aux $predicate")
                            add("$subject $aux $predicate for")
                            if (predicate.contains(Regex("(?i)die|death"))) {
                                add("reason for death of $subject")
                            }
                        }
                    }
                    did != null -> {
                        val subject = did.groupValues[1].trim()
                        val action = toAnswerVerbPhrase(did.groupValues[2].trim())
                        add("$subject $action because")
                        add("reason $subject $action")
                        add("purpose $subject $action")
                    }
                    else -> {
                        val rest = cleaned.replace(Regex("(?i)^why\\s+"), "")
                        add("reason $rest")
                        add("cause $rest")
                        add("$rest because")
                    }
                }
            }
            QuestionType.TIME_DATE -> {
                val did = Regex("(?i)^when\\s+did\\s+(.+?)\\s+(.+)$").find(cleaned)
                val be = Regex("(?i)^when\\s+(?:was|is|were|are)\\s+(.+)$").find(cleaned)
                when {
                    did != null -> {
                        val subject = did.groupValues[1].trim()
                        val action = toAnswerVerbPhrase(did.groupValues[2].trim())
                        add("$subject $action in")
                        add("date of $subject $action")
                        add("time of $subject $action")
                    }
                    be != null -> {
                        val target = be.groupValues[1].trim()
                        add("$target was in")
                        add("date of $target")
                        add("time of $target")
                    }
                    else -> add("date ${cleaned.replace(Regex("(?i)^when\\s+"), "")}")
                }
            }
            QuestionType.LOCATION -> {
                val born = Regex("(?i)^where\\s+(was|is)\\s+(.+?)\\s+born$").find(cleaned)
                val be = Regex("(?i)^where\\s+(?:was|is|were|are)\\s+(.+)$").find(cleaned)
                val did = Regex("(?i)^where\\s+did\\s+(.+?)\\s+(.+)$").find(cleaned)
                when {
                    born != null -> {
                        val aux = born.groupValues[1].lowercase()
                        val target = born.groupValues[2].trim()
                        add("$target $aux born in")
                        add("birthplace of $target")
                        add("$target birthplace")
                    }
                    be != null -> {
                        val target = be.groupValues[1].trim()
                        add("$target was in")
                        add("location of $target")
                        add("$target located in")
                    }
                    did != null -> {
                        val subject = did.groupValues[1].trim()
                        val action = toAnswerVerbPhrase(did.groupValues[2].trim())
                        add("$subject $action at")
                        add("location of $subject $action")
                    }
                    else -> add("location ${cleaned.replace(Regex("(?i)^where\\s+"), "")}")
                }
            }
            QuestionType.PERSON_IDENTITY -> {
                val action = Regex("(?i)^who\\s+([\\p{L}]+)\\s+(.+)$").find(cleaned)
                val be = Regex("(?i)^who\\s+(was|is|were|are)\\s+(.+)$").find(cleaned)
                when {
                    action != null && action.groupValues[1].lowercase() in setOf("killed", "murdered", "executed", "betrayed", "wrote", "built", "led") -> {
                        val verb = action.groupValues[1].trim()
                        val target = action.groupValues[2].trim()
                        if (verb in setOf("killed", "murdered", "executed", "betrayed")) add("$target was $verb by")
                        add("$verb $target")
                        add("person who $verb $target")
                    }
                    be != null -> {
                        val aux = be.groupValues[1].lowercase()
                        val target = be.groupValues[2].trim()
                        add("$target $aux")
                        add("identity of $target")
                        add("$target identity")
                    }
                }
            }
            QuestionType.DEFINITION_MEANING -> {
                val meaning = Regex("(?i)^what\\s+(?:does|do)\\s+(.+?)\\s+mean$").find(cleaned)
                val copula = Regex("(?i)^what\\s+(is|are)\\s+(.+)$").find(cleaned)
                val target = meaning?.groupValues?.getOrNull(1)?.trim()
                    ?: copula?.groupValues?.getOrNull(2)?.trim().orEmpty()
                if (target.isNotBlank()) {
                    if (copula != null) add("$target ${copula.groupValues[1].lowercase()}")
                    add("$target means")
                    add("meaning of $target")
                    add("$target definition")
                }
            }
            QuestionType.METHOD_PROCESS -> {
                val did = Regex("(?i)^how\\s+did\\s+(.+?)\\s+(.+)$").find(cleaned)
                if (did != null) {
                    val subject = did.groupValues[1].trim()
                    val action = toAnswerVerbPhrase(did.groupValues[2].trim())
                    add("$subject $action by")
                    add("way $subject $action")
                    add("method $subject $action")
                } else {
                    val rest = cleaned.replace(Regex("(?i)^how\\s+"), "")
                    add("method $rest")
                    add("way $rest")
                }
            }
            QuestionType.CHOICE -> {
                val rest = cleaned.replace(Regex("(?i)^which\\s+"), "")
                add("selected $rest")
                add("choice $rest")
            }
            QuestionType.YES_NO -> {
                val words = wordsOf(cleaned.lowercase())
                val aux = words.firstOrNull().orEmpty()
                val remainderWords = words.drop(1)
                when {
                    aux in beAuxiliaries && remainderWords.size >= 2 -> {
                        // Copular inversion: "Is Jesus God" -> "Jesus is God".
                        val subject = remainderWords.first()
                        val predicate = remainderWords.drop(1).joinToString(" ")
                        add("$subject $aux $predicate")
                    }
                    aux in doHaveAuxiliaries || aux in modalAuxiliaries -> {
                        // Find the first plausible predicate verb so multi-word
                        // subjects remain intact: "Did King David kill Goliath"
                        // -> "King David killed Goliath".
                        val verbIndex = remainderWords.indexOfFirst { it in questionVerbSignals }
                        if (verbIndex > 0) {
                            val subject = remainderWords.take(verbIndex).joinToString(" ")
                            val predicate = remainderWords.drop(verbIndex).joinToString(" ")
                            when {
                                aux == "did" -> add("$subject ${toAnswerVerbPhrase(predicate)}")
                                aux in modalAuxiliaries -> {
                                    add("$subject $aux $predicate")
                                    add("$subject $predicate")
                                }
                                else -> add("$subject $aux $predicate")
                            }
                        }
                    }
                }
            }
            QuestionType.OTHER -> {
                // Detection can legitimately succeed without a safe deterministic
                // answer-shape rewrite. In that case Question Awareness is reported
                // as detected-but-not-used rather than inventing a risky query.
            }
        }
        return out.toList()
    }

    private fun toAnswerVerbPhrase(raw: String): String {
        val trimmed = raw.trim()
        if (trimmed.isBlank()) return trimmed
        val first = trimmed.substringBefore(' ').lowercase()
        val rest = trimmed.substringAfter(' ', "")
        val past = when (first) {
            "die" -> "died"
            "kill" -> "killed"
            "come" -> "came"
            "go" -> "went"
            "send" -> "sent"
            "say" -> "said"
            "make" -> "made"
            "take" -> "took"
            "give" -> "gave"
            "become" -> "became"
            "write" -> "wrote"
            "build" -> "built"
            "lead" -> "led"
            "fall" -> "fell"
            "rise" -> "rose"
            "begin" -> "began"
            else -> first
        }
        return if (rest.isBlank()) past else "$past $rest"
    }

    private fun extractQuestionCore(cleaned: String): String {
        val patterns = listOf(
            Regex("(?i)^(?:please\\s+)?tell\\s+me\\s+(?=(why|how|when|where|who|what|which)\\b)"),
            Regex("(?i)^i\\s+(?:want|would\\s+like)\\s+to\\s+know\\s+(?=(why|how|when|where|who|what|which)\\b)"),
            Regex("(?i)^(?:can|could)\\s+you\\s+tell\\s+me\\s+(?=(why|how|when|where|who|what|which)\\b)"),
            Regex("(?i)^do\\s+you\\s+know\\s+(?=(why|how|when|where|who|what|which)\\b)"),
            Regex("(?i)^explain\\s+(?=(why|how)\\b)"),
            Regex("(?i)^find\\s+out\\s+(?=(why|how|when|where|who|what|which)\\b)")
        )
        var core = cleaned
        for (pattern in patterns) {
            val stripped = core.replaceFirst(pattern, "").trim()
            if (stripped != core) return stripped
        }
        return core
    }

    private fun clean(raw: String): String = raw
        .trim()
        .replace(Regex("[?？؟]+$"), "")
        .replace(Regex("\\s+"), " ")
        .trim()
}
