package com.tebogo.markvault.search

/**
 * v5.5.14 — Deterministic question-intent detector and answer-oriented query builder.
 *
 * This layer is deliberately model-independent. It recognizes direct and indirect
 * questions even without a trailing '?', classifies the expected answer shape, and
 * emits retrieval queries that look like likely answers instead of merely paraphrasing
 * the question. The original user query remains in the retrieval plan as a secondary
 * signal whenever answer-oriented variants are available.
 */
object QuestionAwareness {

    enum class QuestionType(val label: String) {
        WHY_REASON("WHY / reason"),
        AGE("AGE"),
        COUNT("COUNT / quantity"),
        TIME_DATE("WHEN / date / time"),
        LOCATION("WHERE / location"),
        PERSON_IDENTITY("WHO / identity"),
        EVENT_OCCURRENCE("WHAT / event"),
        DEFINITION_MEANING("DEFINITION / meaning"),
        METHOD_PROCESS("HOW / method"),
        CHOICE("WHICH / choice"),
        YES_NO("YES / NO"),
        OTHER("GENERAL QUESTION")
    }

    data class WeightedAnswerQuery(val text: String, val weight: Double)

    data class Analysis(
        val isQuestion: Boolean,
        val type: QuestionType? = null,
        val answerQueries: List<WeightedAnswerQuery> = emptyList(),
        val detectionConfidence: Double = 0.0,
        val rewriteConfidence: Double = 0.0
    ) {
        val usedSuccessfully: Boolean get() = isQuestion && answerQueries.isNotEmpty()
        val primarySemanticQuery: String? get() = answerQueries.firstOrNull()?.text
    }

    private val directInterrogatives = setOf(
        "who", "whom", "whose", "what", "which", "where", "when", "why", "how"
    )

    private val auxiliaryStarters = setOf(
        "am", "is", "are", "was", "were", "do", "does", "did", "can", "could",
        "will", "would", "shall", "should", "may", "might", "must", "has", "have", "had"
    )

    private val beAuxiliaries = setOf("am", "is", "are", "was", "were")
    private val doHaveAuxiliaries = setOf("do", "does", "did", "has", "have", "had")
    private val modalAuxiliaries = setOf(
        "can", "could", "will", "would", "shall", "should", "may", "might", "must"
    )

    /**
     * v5.5.16 — These are deliberately prefix-only. The old detector used
     * `contains(" marker")`, so an ordinary topical query that merely quoted a
     * conversational phrase could become a question accidentally.
     */
    private val indirectQuestionMarkers = listOf(
        "tell me why", "tell me how", "tell me when", "tell me where", "tell me who", "tell me what",
        "can you tell me", "could you tell me", "i want to know", "i would like to know",
        "do you know why", "do you know how", "do you know when", "do you know where", "do you know who",
        "explain why", "explain how", "find out why", "find out how", "find out when", "find out where"
    )

    private val questionPunctuation = setOf('?', '？', '؟', '¿')

    /**
     * Common finite/action verbs used only as a *grammar signal*. This is not a
     * synonym list and never changes scoring. It lets us distinguish a clause
     * such as "who killed Goliath" from a noun-style search such as "who magazine".
     */
    private val questionVerbSignals = setOf(
        "be", "been", "become", "became", "begin", "began", "build", "built",
        "cause", "caused", "come", "came", "create", "created", "die", "died",
        "do", "does", "did", "fall", "fell", "forgive", "forgave", "give", "gave",
        "go", "went", "happen", "happened", "have", "has", "had", "kill", "killed",
        "lead", "led", "make", "made", "mean", "means", "murder", "murdered",
        "return", "returned", "rise", "rose", "say", "said", "save", "saved",
        "send", "sent", "teach", "taught", "take", "took", "write", "wrote",
        "live", "lived", "know", "knew", "see", "saw", "hear", "heard",
        "exist", "exists", "love", "loves", "care", "cares", "believe", "believes",
        "worship", "worships", "pray", "prays", "speak", "speaks", "work", "works",
        "rule", "rules", "reign", "reigns", "judge", "judges", "obey", "obeys",
        "vote", "votes", "drink", "drinks", "survive", "survives", "suffer", "suffered",
        "destroy", "destroyed", "promise", "promised", "choose", "chose", "call", "called",
        "betray", "betrayed", "execute", "executed", "resurrect", "resurrected"
    )

    /**
     * v5.5.44 — Confidence is a gate, not a retrieval weight. Poorly formed
     * questions remain searchable verbatim, without speculative rewrites.
     */
    private const val MIN_DETECTION_CONFIDENCE = 0.72
    private const val MIN_REWRITE_CONFIDENCE = 0.75

    private data class SubjectFirst(val canonical: String, val confidence: Double)

    /**
     * A subject may precede the actual question: "Caleb who was he?".
     * Require a clear interrogative clause and a coreferential pronoun to
     * avoid misreading relative clauses like "men who abused their wives".
     */
    private fun subjectFirstQuestion(cleaned: String): SubjectFirst? {
        val match = Regex("(?i)^([\\p{L}][\\p{L}\\p{N}'’ -]{1,64}?)\\s+(who|whom|whose|what|where|when|why|how|which)\\s+(.+)$")
            .find(cleaned) ?: return null
        val subject = match.groupValues[1].trim()
        val wh = match.groupValues[2].lowercase()
        val clause = match.groupValues[3].trim()
        val nameWords = wordsOf(subject.lowercase())
        if (nameWords.size !in 1..4 || nameWords.any { it in auxiliaryStarters || it in directInterrogatives }) return null
        if (nameWords.any { it in questionVerbSignals }) return null
        val pronoun = "(?:he|she|it|they|him|her|them)"
        fun replace(pattern: String, with: (MatchResult) -> String): String? {
            val m = Regex(pattern, RegexOption.IGNORE_CASE).matchEntire(clause) ?: return null
            return with(m)
        }
        // 'Caleb who was he' -> 'Who was Caleb'
        if (wh == "who") {
            replace("(was|is|are|were)\\s+$pronoun") { "Who ${it.groupValues[1]} $subject" }
                ?.let { return SubjectFirst(it, 0.99) }
        }
        if (wh == "what") {
            replace("happened\\s+to\\s+$pronoun") { "What happened to $subject" }
                ?.let { return SubjectFirst(it, 0.98) }
            replace("(did|does)\\s+$pronoun\\s+(.+)") { "What ${it.groupValues[1]} $subject ${it.groupValues[2]}" }
                ?.let { return SubjectFirst(it, 0.94) }
        }
        if (wh == "how") {
            replace("(many|much)\\s+(.+?)\\s+(did|does|do)\\s+$pronoun\\s+(.+)") {
                "How ${it.groupValues[1]} ${it.groupValues[2]} ${it.groupValues[3]} $subject ${it.groupValues[4]}"
            }?.let { return SubjectFirst(it, 0.97) }
            replace("(old|many|much|long)\\s+(was|is|did|does|were|are)\\s+$pronoun(\\s+.+)?") {
                "How ${it.groupValues[1]} ${it.groupValues[2]} $subject${it.groupValues[3]}"
            }?.let { return SubjectFirst(it, 0.97) }
        }
        if (wh in setOf("where", "when", "why", "how", "which")) {
            replace("(was|is|are|were|did|does|do|can|could|will|would|should)\\s+$pronoun(\\s+.+)?") {
                "$wh ${it.groupValues[1]} $subject${it.groupValues[2]}"
            }?.let { return SubjectFirst(it, 0.96) }
        }
        return null
    }

    /** Predictably small on-device modules; unsupported languages never trigger
     * an unsafe English grammar rewrite. More languages can implement this API.
     */
    internal interface QuestionDetector {
        fun detect(cleaned: String): LanguageQuestion?
    }
    internal data class LanguageQuestion(val type: QuestionType, val confidence: Double)
    private object SepediDetector : QuestionDetector {
        override fun detect(cleaned: String): LanguageQuestion? = when {
            Regex("(?i)^ke mang\\b").containsMatchIn(cleaned) -> LanguageQuestion(QuestionType.PERSON_IDENTITY, 0.94)
            Regex("(?i)^ka lebaka la eng\\b|^goreng\\b").containsMatchIn(cleaned) -> LanguageQuestion(QuestionType.WHY_REASON, 0.90)
            Regex("(?i)^neng\\b").containsMatchIn(cleaned) -> LanguageQuestion(QuestionType.TIME_DATE, 0.88)
            Regex("(?i)^kae\\b").containsMatchIn(cleaned) -> LanguageQuestion(QuestionType.LOCATION, 0.86)
            else -> null
        }
    }
    private object ZuluDetector : QuestionDetector {
        override fun detect(cleaned: String): LanguageQuestion? = when {
            Regex("(?i)^ngubani\\b").containsMatchIn(cleaned) -> LanguageQuestion(QuestionType.PERSON_IDENTITY, 0.94)
            Regex("(?i)^kungani\\b|^ngani\\b").containsMatchIn(cleaned) -> LanguageQuestion(QuestionType.WHY_REASON, 0.90)
            Regex("(?i)^nini\\b").containsMatchIn(cleaned) -> LanguageQuestion(QuestionType.TIME_DATE, 0.90)
            Regex("(?i)^kuphi\\b").containsMatchIn(cleaned) -> LanguageQuestion(QuestionType.LOCATION, 0.88)
            else -> null
        }
    }
    private val additionalLanguageDetectors: List<QuestionDetector> = listOf(SepediDetector, ZuluDetector)

    /** Total budget includes Question Awareness, synonym, T5 and LLM rewrites.
     * Keep a model-selected one-slot search focused on the selected model.
     * Otherwise share slots with the complementary expander. */
    fun questionSlots(maxExpansions: Int, competingExpander: Boolean): Int {
        val allowed = maxExpansions.coerceAtLeast(0)
        return when {
            allowed == 0 -> 0
            allowed == 1 && competingExpander -> 0
            else -> (allowed + 1) / 2
        }
    }

    fun analyze(raw: String): Analysis {
        val cleaned = clean(raw)
        if (cleaned.isBlank() || looksLikeSearchSyntax(cleaned)) return Analysis(false)
        val subjectFirst = subjectFirstQuestion(cleaned)
        val normalized = subjectFirst?.canonical ?: cleaned
        // A detected non-English question is kept literal until its language
        // has a safe, dedicated query builder (never force English templates).
        if (subjectFirst == null) {
            val languageHit = additionalLanguageDetectors.firstNotNullOfOrNull { it.detect(cleaned) }
            if (languageHit != null) return Analysis(
                isQuestion = true, type = languageHit.type,
                detectionConfidence = languageHit.confidence
            )
        }

        // Classify the embedded question for conversational requests such as
        // "tell me why ..." rather than classifying the wrapper itself.
        val answerCore = extractQuestionCore(normalized)
        val coreLower = answerCore.lowercase()
        val coreWords = wordsOf(coreLower)
        if (coreWords.isEmpty()) return Analysis(false)

        val rawTrimmed = raw.trim()
        val trailingQuestionPunctuation = rawTrimmed.lastOrNull() in questionPunctuation
        val indirectSignal = indirectQuestionMarkers.any { marker ->
            val lower = cleaned.lowercase()
            lower == marker || lower.startsWith("$marker ")
        }
        val directWhSignal = looksLikeWhQuestion(coreLower, coreWords, trailingQuestionPunctuation)
        val auxiliarySignal = looksLikeAuxiliaryQuestion(coreWords, trailingQuestionPunctuation)

        // A terminal question mark is strong evidence for ordinary prose, but it
        // must not turn URLs/search syntax such as `page?id=4` into questions.
        val punctuationSignal = trailingQuestionPunctuation &&
            coreWords.size >= 2 && !looksLikeSearchSyntax(cleaned)

        val detectionConfidence = when {
            subjectFirst != null -> subjectFirst.confidence
            indirectSignal -> 0.96
            directWhSignal -> 0.94
            auxiliarySignal -> 0.91
            punctuationSignal -> 0.76
            else -> 0.0
        }
        if (detectionConfidence < MIN_DETECTION_CONFIDENCE) return Analysis(false)

        val type = classify(coreLower, coreWords)
        // A punctuation-only general question has no trustworthy deterministic rewrite.
        val rewriteConfidence = when {
            type == QuestionType.OTHER -> 0.0
            subjectFirst != null -> 0.94
            directWhSignal -> 0.92
            auxiliarySignal -> 0.90
            indirectSignal -> 0.88
            else -> 0.70
        }
        val variants = if (rewriteConfidence >= MIN_REWRITE_CONFIDENCE) {
            buildAnswerQueries(answerCore, type)
                .mapIndexed { index, text ->
                    WeightedAnswerQuery(text, listOf(1.0, 0.94, 0.88, 0.82).getOrElse(index) { 0.78 })
                }
                .distinctBy { it.text.lowercase() }
                .take(4)
        } else emptyList()
        return Analysis(true, type, variants, detectionConfidence, rewriteConfidence)
    }

    /**
     * v5.5.16 — Conservative WH-clause detector.
     *
     * A WH word by itself is no longer enough. This prevents normal noun-style
     * searches such as "who magazine", "when articles", and especially
     * "how old testament prophecies" from being labelled as questions. Direct
     * grammatical forms, answer-type compounds, or terminal question punctuation
     * still count strongly.
     */
    private fun looksLikeWhQuestion(
        lower: String,
        words: List<String>,
        trailingQuestionPunctuation: Boolean
    ): Boolean {
        val first = words.firstOrNull() ?: return false
        if (first !in directInterrogatives || words.size < 2) return false
        val second = words.getOrNull(1).orEmpty()
        val laterHasVerb = words.drop(1).take(6).any { it in questionVerbSignals || it in auxiliaryStarters }

        return when (first) {
            "how" -> {
                // "how old Testament ..." is a topical noun phrase, not an AGE question.
                if (Regex("^how\\s+old\\s+testament\\b").containsMatchIn(lower)) return false
                Regex(
                    "^how\\s+(many|much|old|long|far|often)\\b|" +
                        "^how\\s+(am|is|are|was|were|do|does|did|can|could|will|would|should|may|might|must|has|have|had)\\b"
                ).containsMatchIn(lower) || laterHasVerb || trailingQuestionPunctuation
            }
            "what" -> Regex(
                "^what\\s+(age|year|date|time|place|meaning|number)\\b|" +
                    "^what\\s+(am|is|are|was|were|do|does|did|can|could|will|would|should|has|have|had)\\b|" +
                    "^what\\s+(happened|caused|made|makes|means)\\b"
            ).containsMatchIn(lower) || laterHasVerb || trailingQuestionPunctuation
            "which" -> second in auxiliaryStarters || laterHasVerb || trailingQuestionPunctuation
            "who", "whom", "whose", "where", "when", "why" ->
                second in auxiliaryStarters || laterHasVerb || trailingQuestionPunctuation
            else -> false
        }
    }

    /** v5.5.16 — Validate inversion instead of treating any leading auxiliary as a question. */
    private fun looksLikeAuxiliaryQuestion(words: List<String>, trailingQuestionPunctuation: Boolean): Boolean {
        val first = words.firstOrNull() ?: return false
        if (first !in auxiliaryStarters || words.size < 2) return false
        if (trailingQuestionPunctuation) return true

        return when (first) {
            in beAuxiliaries -> words.size >= 3
            in doHaveAuxiliaries -> words.size >= 3 && words.drop(2).take(4).any { it in questionVerbSignals }
            in modalAuxiliaries -> words.size >= 3 && words.drop(2).take(4).any { it in questionVerbSignals }
            else -> false
        }
    }

    private fun looksLikeSearchSyntax(raw: String): Boolean {
        val lower = raw.lowercase()
        if ("://" in lower) return true
        if (Regex("\\b[a-z0-9._-]+\\?[a-z0-9._-]+=", RegexOption.IGNORE_CASE).containsMatchIn(lower)) return true
        if (Regex("\\b(site|file|path|tag|type):\\S+", RegexOption.IGNORE_CASE).containsMatchIn(raw)) return true
        return false
    }

    private fun wordsOf(lower: String): List<String> =
        Regex("[\\p{L}\\p{N}']+").findAll(lower).map { it.value }.toList()

    private fun isDefinitionCopulaQuestion(lower: String): Boolean {
        val match = Regex("^what\\s+(is|are)\\s+(.+)$").find(lower) ?: return false
        val targetWords = wordsOf(match.groupValues[2])
        if (targetWords.isEmpty() || targetWords.size > 8) return false
        val eventWords = setOf(
            "doing", "happening", "going", "saying", "teaching", "wearing",
            "working", "coming", "living", "located", "occurring"
        )
        return targetWords.none { it in eventWords || it in questionVerbSignals }
    }

    private fun classify(lower: String, words: List<String>): QuestionType = when {
        Regex("^how\\s+old\\b|^what\\s+age\\b")
            .containsMatchIn(lower) -> QuestionType.AGE
        Regex("^how\\s+(many|much)\\b|^what\\s+number\\b").containsMatchIn(lower) -> QuestionType.COUNT
        Regex("^what\\s+(year|date|time)\\b|^when\\b|^how\\s+long\\s+ago\\b").containsMatchIn(lower) -> QuestionType.TIME_DATE
        Regex("^where\\b|^what\\s+place\\b|^which\\s+place\\b").containsMatchIn(lower) -> QuestionType.LOCATION
        Regex("^(who|whom|whose)\\b").containsMatchIn(lower) -> QuestionType.PERSON_IDENTITY
        Regex("^what\\s+(happened|occurred)\\s+to\\b").containsMatchIn(lower) -> QuestionType.EVENT_OCCURRENCE
        Regex("^what\\s+(does|do)\\b.*\\bmean\\b|^what\\s+(is|are)\\s+(?:the\\s+)?(meaning|definition)\\b|^meaning\\s+of\\b|^define\\b")
            .containsMatchIn(lower) || isDefinitionCopulaQuestion(lower) -> QuestionType.DEFINITION_MEANING
        Regex("^why\\b|^what\\s+caused\\b|^what\\s+was\\s+the\\s+cause\\b").containsMatchIn(lower) -> QuestionType.WHY_REASON
        words.firstOrNull() == "how" || Regex("^how\\s+(did|does|do|can|could|is|was)\\b").containsMatchIn(lower) -> QuestionType.METHOD_PROCESS
        words.firstOrNull() == "which" -> QuestionType.CHOICE
        words.firstOrNull() in auxiliaryStarters -> QuestionType.YES_NO
        else -> QuestionType.OTHER
    }

    private fun buildAnswerQueries(cleaned: String, type: QuestionType): List<String> {
        val out = LinkedHashSet<String>()
        fun add(s: String) {
            val v = clean(s).trim(' ', '.', ',', ';', ':', '?', '!', '？', '؟')
            if (v.length >= 3 && !v.equals(cleaned, ignoreCase = true)) out += v
        }

        when (type) {
            QuestionType.AGE -> {
                val howOld = Regex("(?i)^how\\s+old\\s+(?:was|is|were|are)\\s+(.+?)(?:\\s+when\\s+(.+))?$").find(cleaned)
                    ?: Regex("(?i)^how\\s+old\\s+(.+?)\\s+(?:was|is|were|are)(?:\\s+when\\s+(.+))?$").find(cleaned)
                val whatAge = Regex("(?i)^what\\s+age\\s+(?:was|is|were|are)\\s+(.+?)(?:\\s+when\\s+(.+))?$").find(cleaned)
                val elliptical = Regex("(?i)^how\\s+old\\s+(.+)$").find(cleaned)
                val match = howOld ?: whatAge
                val target = match?.groupValues?.getOrNull(1)?.trim()
                    ?: elliptical?.groupValues?.getOrNull(1)?.trim().orEmpty()
                val event = match?.groupValues?.getOrNull(2)?.trim().orEmpty()
                if (target.isNotBlank()) {
                    add("$target was years old")
                    add("age of $target")
                    if (event.contains(Regex("(?i)die|died|death"))) {
                        add("$target died at age")
                        add("$target age at death")
                    } else if (event.isNotBlank()) {
                        add("$target was years old when $event")
                    }
                }
            }
            QuestionType.COUNT -> {
                val have = Regex("(?i)^how\\s+many\\s+(.+?)\\s+did\\s+(.+?)\\s+have$").find(cleaned)
                    ?: Regex("(?i)^how\\s+many\\s+(.+?)\\s+(?:does|do)\\s+(.+?)\\s+have$").find(cleaned)
                if (have != null) {
                    val item = have.groupValues[1].trim()
                    val subject = have.groupValues[2].trim()
                    add("$subject had $item")
                    add("number of $item $subject had")
                    if (item.lowercase() in setOf("child", "children", "sons", "daughters", "offspring")) {
                        add("$subject sons and daughters")
                        add("$subject other children")
                    }
                } else {
                    val did = Regex("(?i)^how\\s+many\\s+(.+?)\\s+did\\s+(.+?)\\s+([\\p{L}]+)$").find(cleaned)
                    if (did != null) {
                        val item = did.groupValues[1].trim()
                        val subject = did.groupValues[2].trim()
                        val past = toAnswerVerbPhrase(did.groupValues[3])
                        add("$subject $past $item")
                        add("number of $item $subject $past")
                        if (past == "wrote") add("$item written by $subject")
                    } else {
                        val rest = cleaned.replace(Regex("(?i)^how\\s+(many|much)\\s+"), "")
                        add("number of $rest")
                        add("quantity of $rest")
                    }
                }
            }
            QuestionType.WHY_REASON -> {
                val passive = Regex("(?i)^why\\s+(was|were|is|are)\\s+(.+?)\\s+([\\p{L}][\\p{L} '-]+)$").find(cleaned)
                val did = Regex("(?i)^why\\s+did\\s+(.+?)\\s+([\\p{L}][\\p{L} '-]+)$").find(cleaned)
                when {
                    passive != null -> {
                        val aux = passive.groupValues[1].lowercase()
                        val subject = passive.groupValues[2].trim()
                        val predicate = passive.groupValues[3].trim()
                        add("$subject $aux $predicate because")
                        if (predicate.contains(Regex("(?i)kill|execut|put to death"))) {
                            // Answer vocabulary matters more than another paraphrase of
                            // the question: articles may say "died for" / "put to death"
                            // even when the user asks why someone was "killed".
                            add("$subject died for")
                            add("$subject died because")
                            add("reason for death of $subject")
                        } else {
                            add("reason $subject $aux $predicate")
                            add("$subject $aux $predicate for")
                            if (predicate.contains(Regex("(?i)die|death"))) {
                                add("reason for death of $subject")
                            }
                        }
                    }
                    did != null -> {
                        val subject = did.groupValues[1].trim()
                        val action = toAnswerVerbPhrase(did.groupValues[2].trim())
                        add("$subject $action because")
                        add("reason $subject $action")
                        add("purpose $subject $action")
                    }
                    else -> {
                        val rest = cleaned.replace(Regex("(?i)^why\\s+"), "")
                        add("reason $rest")
                        add("cause $rest")
                        add("$rest because")
                    }
                }
            }
            QuestionType.TIME_DATE -> {
                val did = Regex("(?i)^when\\s+did\\s+(.+?)\\s+(.+)$").find(cleaned)
                val be = Regex("(?i)^when\\s+(?:was|is|were|are)\\s+(.+)$").find(cleaned)
                when {
                    did != null -> {
                        val subject = did.groupValues[1].trim()
                        val action = toAnswerVerbPhrase(did.groupValues[2].trim())
                        add("$subject $action in")
                        val nounPhrase = eventNounPhrase(subject, action)
                        if (nounPhrase != "$subject $action") {
                            add("date of $nounPhrase")
                            add("time of $nounPhrase")
                        } else {
                            add("when $subject $action")
                            add("year $subject $action")
                        }
                    }
                    be != null -> {
                        val target = be.groupValues[1].trim()
                        if (target.endsWith(" born", ignoreCase = true)) {
                            val subject = target.dropLast(5).trim()
                            add("$subject was born in")
                            add("birth date of $subject")
                            add("year of $subject birth")
                        } else {
                            add("when $target")
                            add("date of $target")
                            add("time of $target")
                        }
                    }
                    else -> add("date ${cleaned.replace(Regex("(?i)^when\\s+"), "")}")
                }
            }
            QuestionType.LOCATION -> {
                val born = Regex("(?i)^where\\s+(was|is)\\s+(.+?)\\s+born$").find(cleaned)
                val be = Regex("(?i)^where\\s+(?:was|is|were|are)\\s+(.+)$").find(cleaned)
                val did = Regex("(?i)^where\\s+did\\s+(.+?)\\s+(.+)$").find(cleaned)
                when {
                    born != null -> {
                        val aux = born.groupValues[1].lowercase()
                        val target = born.groupValues[2].trim()
                        add("$target $aux born in")
                        add("birthplace of $target")
                        add("$target birthplace")
                    }
                    be != null -> {
                        val target = be.groupValues[1].trim()
                        val beVerb = Regex("(?i)^where\\s+(was|is|were|are)").find(cleaned)?.groupValues?.get(1) ?: "was"
                        add("$target $beVerb in")
                        add("location of $target")
                        add("$target located in")
                    }
                    did != null -> {
                        val subject = did.groupValues[1].trim()
                        val action = toAnswerVerbPhrase(did.groupValues[2].trim())
                        add("$subject $action at")
                        add("location of $subject $action")
                    }
                    else -> add("location ${cleaned.replace(Regex("(?i)^where\\s+"), "")}")
                }
            }
            QuestionType.PERSON_IDENTITY -> {
                val action = Regex("(?i)^who\\s+([\\p{L}]+)\\s+(.+)$").find(cleaned)
                val be = Regex("(?i)^who\\s+(was|is|were|are)\\s+(.+)$").find(cleaned)
                when {
                    action != null && action.groupValues[1].lowercase() in setOf("killed", "murdered", "executed", "betrayed", "wrote", "built", "led") -> {
                        val verb = action.groupValues[1].trim()
                        val target = action.groupValues[2].trim()
                        if (verb in setOf("killed", "murdered", "executed", "betrayed")) add("$target was $verb by")
                        add("$verb $target")
                        add("person who $verb $target")
                    }
                    be != null -> {
                        val aux = be.groupValues[1].lowercase()
                        val target = be.groupValues[2].trim()
                        add("$target $aux")
                        add("identity of $target")
                        add("background of $target")
                        add("role of $target")
                    }
                }
            }
            QuestionType.EVENT_OCCURRENCE -> {
                val event = Regex("(?i)^what\\s+(?:happened|occurred)\\s+to\\s+(.+)$").find(cleaned)
                if (event != null) {
                    val subject = event.groupValues[1].trim()
                    add("events involving $subject")
                    add("$subject experienced")
                    add("account of $subject")
                }
            }
            QuestionType.DEFINITION_MEANING -> {
                val meaning = Regex("(?i)^what\\s+(?:does|do)\\s+(.+?)\\s+mean$").find(cleaned)
                val copula = Regex("(?i)^what\\s+(is|are)\\s+(.+)$").find(cleaned)
                val target = meaning?.groupValues?.getOrNull(1)?.trim()
                    ?: copula?.groupValues?.getOrNull(2)?.trim().orEmpty()
                if (target.isNotBlank()) {
                    if (copula != null) add("$target ${copula.groupValues[1].lowercase()}")
                    add("$target means")
                    add("meaning of $target")
                    add("$target definition")
                }
            }
            QuestionType.METHOD_PROCESS -> {
                val did = Regex("(?i)^how\\s+did\\s+(.+?)\\s+(.+)$").find(cleaned)
                if (did != null) {
                    val subject = did.groupValues[1].trim()
                    val action = toAnswerVerbPhrase(did.groupValues[2].trim())
                    add("$subject $action by")
                    add("way $subject $action")
                    add("method $subject $action")
                } else {
                    val rest = cleaned.replace(Regex("(?i)^how\\s+"), "")
                    add("method $rest")
                    add("way $rest")
                }
            }
            QuestionType.CHOICE -> {
                val rest = cleaned.replace(Regex("(?i)^which\\s+"), "")
                add("selected $rest")
                add("choice $rest")
            }
            QuestionType.YES_NO -> {
                // No affirmative/negative assumption: preserve entities and
                // retrieve their relationship, not a presumed doctrinal answer.
                val match = Regex("(?i)^(am|is|are|was|were|do|does|did|can|could|will|would|shall|should|may|might|must|has|have|had)\\s+(.+)$")
                    .find(cleaned)
                if (match != null) {
                    val aux = match.groupValues[1].lowercase()
                    val remainder = match.groupValues[2].trim()
                    if (aux in beAuxiliaries) {
                        val words = remainder.split(' ')
                        if (words.size >= 2) {
                            val subject = words.first()
                            val predicate = words.drop(1).joinToString(" ")
                            add("$subject $predicate")
                            add("whether $subject $aux $predicate")
                            add("relationship between $subject and $predicate")
                        }
                    } else {
                        val tokens = remainder.split(' ')
                        val verbIndex = tokens.indexOfFirst { it.lowercase() in questionVerbSignals }
                        if (verbIndex > 0) {
                            val subject = tokens.take(verbIndex).joinToString(" ")
                            val verbPhrase = tokens.drop(verbIndex).joinToString(" ")
                            add("$subject $verbPhrase")
                            val factualVerb = if (aux == "did") toAnswerVerbPhrase(verbPhrase) else verbPhrase
                            add("whether $subject $factualVerb")
                            val objectText = tokens.drop(verbIndex + 1).joinToString(" ")
                            if (objectText.isNotBlank()) add("$subject $objectText")
                        } else {
                            add("whether $remainder")
                        }
                    }
                }
            }
            QuestionType.OTHER -> {
                // Detection can legitimately succeed without a safe deterministic
                // answer-shape rewrite. In that case Question Awareness is reported
                // as detected-but-not-used rather than inventing a risky query.
            }
        }
        return out.toList()
    }

    /** Minimal inflection lexicon; deliberately no whole-query stemming that
     * could corrupt names, quotations, Bible references, or negation. */
    private val eventNouns = mapOf(
        "die" to "death", "died" to "death", "born" to "birth",
        "begin" to "beginning", "began" to "beginning",
        "arrive" to "arrival", "arrived" to "arrival",
        "return" to "return", "returned" to "return",
        "kill" to "killing", "killed" to "killing",
        "resurrect" to "resurrection", "resurrected" to "resurrection"
    )
    private fun eventNounPhrase(subject: String, action: String): String {
        val verb = action.substringBefore(' ').lowercase()
        val rest = action.substringAfter(' ', "").trim()
        val noun = eventNouns[verb]
        return if (noun != null && rest.isBlank()) "${subject}${if (subject.endsWith("s", ignoreCase = true)) "'" else "'s"} $noun"
            else "$subject ${action.trim()}"  // a grammatical clause, not "date of Jesus died"
    }

    private fun toAnswerVerbPhrase(raw: String): String {
        val trimmed = raw.trim()
        if (trimmed.isBlank()) return trimmed
        val first = trimmed.substringBefore(' ').lowercase()
        val rest = trimmed.substringAfter(' ', "")
        val past = when (first) {
            "die" -> "died"
            "flee" -> "fled"
            "allow" -> "allowed"
            "permit" -> "permitted"
            "love" -> "loved"
            "believe" -> "believed"
            "pray" -> "prayed"
            "worship" -> "worshipped"
            "resurrect" -> "resurrected"
            "promise" -> "promised"
            "survive" -> "survived"
            "obey" -> "obeyed"
            "choose" -> "chose"
            "see" -> "saw"
            "write" -> "wrote"
            "teach" -> "taught"
            "speak" -> "spoke"
            "drink" -> "drank"
            "eat" -> "ate"
            "kill" -> "killed"
            "come" -> "came"
            "go" -> "went"
            "send" -> "sent"
            "say" -> "said"
            "make" -> "made"
            "take" -> "took"
            "give" -> "gave"
            "become" -> "became"
            "build" -> "built"
            "lead" -> "led"
            "fall" -> "fell"
            "rise" -> "rose"
            "begin" -> "began"
            else -> first
        }
        return if (rest.isBlank()) past else "$past $rest"
    }

    private fun extractQuestionCore(cleaned: String): String {
        val patterns = listOf(
            Regex("(?i)^(?:please\\s+)?tell\\s+me\\s+(?=(why|how|when|where|who|what|which)\\b)"),
            Regex("(?i)^i\\s+(?:want|would\\s+like)\\s+to\\s+know\\s+(?=(why|how|when|where|who|what|which)\\b)"),
            Regex("(?i)^(?:can|could)\\s+you\\s+tell\\s+me\\s+(?=(why|how|when|where|who|what|which)\\b)"),
            Regex("(?i)^do\\s+you\\s+know\\s+(?=(why|how|when|where|who|what|which)\\b)"),
            Regex("(?i)^explain\\s+(?=(why|how)\\b)"),
            Regex("(?i)^find\\s+out\\s+(?=(why|how|when|where|who|what|which)\\b)")
        )
        var core = cleaned
        for (pattern in patterns) {
            val stripped = core.replaceFirst(pattern, "").trim()
            if (stripped != core) return stripped
        }
        return core
    }

    private fun clean(raw: String): String = raw
        .trim()
        .replace(Regex("[?？؟]+$"), "")
        .replace(Regex("\\s+"), " ")
        .trim()
}
