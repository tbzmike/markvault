package com.tebogo.markvault.search

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.os.Build
import android.os.IBinder
import android.os.PowerManager
import androidx.core.app.NotificationCompat
import com.tebogo.markvault.MainActivity
import com.tebogo.markvault.R
import com.tebogo.markvault.data.NoteEmbedding
import com.tebogo.markvault.data.Prefs
import com.tebogo.markvault.data.VaultDb
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch

/**
 * v4.15.0 — Foreground service that owns the embedding pass.
 *
 * # Why this exists
 *
 * Before v4.15.0, embedding ran in `viewModelScope` inside `AppViewModel`.
 * That works for short jobs but breaks down for big libraries:
 *
 *   - The OS kills background app processes under memory pressure; the
 *     coroutine dies with the process.
 *   - Doze mode throttles background CPU when the screen is off.
 *   - The ViewModel scope is cancelled the moment the Activity is destroyed
 *     (e.g., user swipes the app away from Recents).
 *
 * For a 14k-note library with `bge-large-en-v1.5` (1024-dim), an embedding
 * pass takes roughly 3–4 hours on mid-range Android. The user shouldn't
 * have to stare at the screen the whole time.
 *
 * # What this does instead
 *
 * 1. **Foreground service** — declared in the manifest with type
 *    `dataSync`. Tells Android "this is important user-perceived work,
 *    keep me alive."
 * 2. **Persistent notification** — required for every foreground service
 *    on Android 8+. Doubles as live progress for the user.
 * 3. **Partial wake lock** — prevents CPU sleep while embedding. Tagged
 *    `MarkVault::EmbeddingWakeLock`. Released in `onDestroy`.
 * 4. **Resumable loop** — same code path as the old in-VM loop. The DAO's
 *    `targetsNeedingEmbedding` query already skips already-embedded
 *    notes, so if the OS kills the service mid-pass and restarts it,
 *    we pick up exactly where we left off.
 *
 * # How progress is reported
 *
 * The service writes to [EmbeddingProgressBus] — a module-level
 * StateFlow singleton. The `AppViewModel` delegates its public
 * `embeddingProgress` flow to the bus, so the Settings UI keeps working
 * without any changes to the Composables.
 *
 * # Lifecycle
 *
 * - `onCreate`: create notification channel, allocate wake lock
 * - `onStartCommand`: `startForeground` with the initial notification,
 *   acquire wake lock, launch the embed coroutine (no-op if one is
 *   already running)
 * - Coroutine completes → `stopSelf()` → `onDestroy` cleans up
 * - External cancel: `Context.stopService(Intent(EmbeddingService))` →
 *   `onDestroy` cancels the coroutine + releases resources
 *
 * # Return code: START_REDELIVER_INTENT
 *
 * If the OS kills the service mid-pass (very rare for foreground
 * services but theoretically possible under extreme memory pressure),
 * Android restarts it with the same Intent we originally passed. The
 * embed loop is idempotent — `targetsNeedingEmbedding` returns only
 * notes that still need embedding — so the restart simply continues
 * the pass.
 */
class EmbeddingService : Service() {

    private val serviceScope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
    private var embeddingJob: Job? = null
    private var wakeLock: PowerManager.WakeLock? = null

    override fun onCreate() {
        super.onCreate()
        createNotificationChannel()
        // Allocate the wake lock but DON'T acquire it yet — we acquire in
        // onStartCommand so a stray onCreate without start (which shouldn't
        // happen but doesn't hurt to guard against) doesn't leak power.
        val pm = getSystemService(Context.POWER_SERVICE) as PowerManager
        wakeLock = pm.newWakeLock(
            PowerManager.PARTIAL_WAKE_LOCK,
            "MarkVault::EmbeddingWakeLock"
        )
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        // Required within 5–10 seconds of startForegroundService(). We
        // post a placeholder notification first; the embed coroutine
        // overwrites it with real progress within a few hundred ms.
        startForeground(NOTIFICATION_ID, buildNotification(done = 0, total = 0, complete = false))

        // Acquire the wake lock with an 8-hour safety timeout. Real
        // releases happen in onDestroy. The timeout is just a backstop
        // for the catastrophic case where onDestroy never fires.
        runCatching {
            if (wakeLock?.isHeld != true) {
                wakeLock?.acquire(WAKELOCK_TIMEOUT_MS)
            }
        }

        // If a job is already running, ignore the duplicate start. The
        // service is single-instance by design — we don't want two
        // concurrent embed loops fighting over the same DB rows.
        if (embeddingJob?.isActive == true) {
            return START_REDELIVER_INTENT
        }

        embeddingJob = serviceScope.launch {
            runEmbeddingPass()
            // Tell the OS we're done; onDestroy releases the wake lock
            // and removes the notification.
            stopSelf()
        }
        return START_REDELIVER_INTENT
    }

    /**
     * The actual embed loop. Mirrors the pre-v4.15.0 in-VM loop almost
     * exactly — only the I/O side-effects (notification + bus updates)
     * differ. Kept inside the service so the work survives Activity
     * lifecycle changes.
     */
    private suspend fun runEmbeddingPass() {
        val app = application
        // Read the user's currently-active model from Prefs. The service
        // doesn't share an Embedder instance with the VM — it constructs
        // its own from the active model descriptor. This means a model
        // switch by the user mid-pass is ignored; the running pass
        // finishes on the model it started with. The user can stop the
        // service and re-start to pick up the new model.
        val prefs = Prefs(app)
        val activeId = prefs.activeModelId.first()
        val descriptor = com.tebogo.markvault.search.ModelCatalog.byId(activeId)
            ?: com.tebogo.markvault.search.ModelCatalog.default
        if (!descriptor.enabled) {
            EmbeddingProgressBus.idle()
            return
        }

        val embedder = com.tebogo.markvault.search.Embedder(app, descriptor)
        if (!embedder.isModelAvailable()) {
            EmbeddingProgressBus.idle()
            return
        }

        val dao = VaultDb.get(app).notes()

        try {
            EmbeddingProgressBus.start()

            val total = runCatching {
                dao.countNotesNeedingEmbedding(embedder.modelVersion)
            }.getOrElse { 0 }

            if (total == 0) {
                // Nothing to embed (everything already done for this
                // model). Show a quick completion notification so the
                // user sees something happened, then bail.
                EmbeddingProgressBus.complete()
                updateNotification(done = 0, total = 0, complete = true,
                    modelName = descriptor.shortName)
                return
            }

            EmbeddingProgressBus.updateProgress(0, total)
            updateNotification(done = 0, total = total, complete = false,
                modelName = descriptor.shortName)

            val targets = runCatching {
                dao.targetsNeedingEmbedding(embedder.modelVersion)
            }.getOrElse { emptyList() }

            var done = 0
            var lastNotificationMs = 0L
            // v5.4.178cc — Diagnostic timing. Two rounds of targeted fixes
            // (v5.4.176cc's larger chunks, v5.4.177cc's transaction
            // batching) produced no visible speed change, which means my
            // reasoning-from-code-reading diagnosis has been wrong or
            // incomplete — I have no way to actually profile a real
            // device from here. Rather than guess a third time, this
            // measures where time ACTUALLY goes (ms accumulated across
            // the whole pass) and surfaces it directly in the
            // already-visible notification, so the next report is backed
            // by real numbers instead of another guess.
            var totalChunkMs = 0L
            var totalEmbedMs = 0L
            var totalDbMs = 0L

            for (target in targets) {
                // Honour cancellation between iterations so stopService()
                // takes effect within one note.
                if (!serviceScope.isActive) break

                val note = runCatching { dao.byId(target.id) }.getOrNull()
                    ?: continue

                // v5.4.174cc — Chunked indexing, replacing v5.4.173cc's
                // short-note reuse shortcut (removed — see Db.kt's
                // deleteEmbeddingsForNote doc comment for why it doesn't
                // carry over to chunking).
                //
                // Splits the note's CONTENT (not title+content combined —
                // see below) into overlapping ~180-word passages via the
                // same TextChunker the in-article popup already uses, then
                // embeds EACH passage separately, with the note's title
                // prepended to every one of them for context. Prepending
                // per-chunk (rather than chunking title+content as one
                // blob, which would only give the FIRST chunk any title
                // context) means a passage from deep in a long article
                // still carries "this is from an article about X" — not
                // just bare text with no anchor.
                //
                // This is what actually fixes the "content past ~380
                // words is invisible to search" problem: every passage
                // gets its own vector, so nothing is silently truncated
                // away regardless of how long the note is.
                //
                // v5.4.176cc — targetWords raised 180 -> 350 (overlap
                // scaled to match, 45 -> 70) SPECIFICALLY for this bulk-
                // indexing path. Chunking multiplies embed() calls per
                // note — a 2000-word note was producing 15 separate
                // inference calls at 180 words; at 350 words that's 7.
                // Across 42k notes that difference is the whole ballgame
                // for how long a full re-embed takes, and it hits EVERY
                // model equally (this is a call-COUNT problem, not
                // something specific to any one model's speed) — a
                // "small/fast" model still pays for 2x the calls. 350
                // words (~260 tokens) is still comfortably under the
                // 512-token budget per chunk, so this doesn't reintroduce
                // truncation — it just makes each passage a bit broader.
                // The in-article popup's OWN chunking call (a different,
                // on-demand, single-article use case where finer passages
                // genuinely help) is intentionally left at 180/45 —
                // that's not what's slow for a 42k-note bulk index.
                val chunkStartNs = System.nanoTime()
                val contentChunks = com.tebogo.markvault.search.buildOverlappingChunks(
                    note.content,
                    targetWords = 350,
                    overlapWords = 70,
                    minWords = 30
                )
                totalChunkMs += (System.nanoTime() - chunkStartNs) / 1_000_000
                // Fallback for notes too short to produce a real chunk
                // (empty/near-empty body) — still embed something (title +
                // whatever content exists) so the note stays searchable
                // instead of silently dropping out of the index.
                val chunkTexts: List<String> = if (contentChunks.isNotEmpty()) {
                    contentChunks.map { it.text }
                } else {
                    listOf(note.content)
                }

                // v5.4.177cc — Embedding (ML inference) still happens one
                // chunk at a time below — that part's unavoidable, each
                // passage needs its own forward pass. What changed is the
                // DATABASE WRITE: results are collected into a list and
                // written via ONE dao.replaceNoteEmbeddings() transaction
                // per note (delete-old + insert-all-chunks together),
                // instead of the delete and every individual upsert each
                // auto-committing separately. See replaceNoteEmbeddings'
                // doc comment in Db.kt for why that was the dominant
                // remaining bottleneck, independent of embedding model.
                val noteEmbeddings = mutableListOf<NoteEmbedding>()
                for ((chunkIdx, chunkText) in chunkTexts.withIndex()) {
                    if (!serviceScope.isActive) break
                    val textToEmbed = buildString {
                        append(note.title).append("\n\n").append(chunkText)
                    }
                    val embedStartNs = System.nanoTime()
                    val vec = embedder.embed(textToEmbed)
                    totalEmbedMs += (System.nanoTime() - embedStartNs) / 1_000_000
                    if (vec != null) {
                        noteEmbeddings.add(
                            NoteEmbedding(
                                noteId = note.id,
                                modelVersion = embedder.modelVersion,
                                chunkIndex = chunkIdx,
                                dim = vec.size,
                                vector = floatArrayToBytes(vec),
                                sourceLastModified = note.lastModified,
                                createdAt = System.currentTimeMillis()
                            )
                        )
                    }
                }
                // Single transactional write for this note's whole chunk
                // set — see the comment above and replaceNoteEmbeddings'
                // doc comment in Db.kt.
                val dbStartNs = System.nanoTime()
                runCatching {
                    dao.replaceNoteEmbeddings(note.id, embedder.modelVersion, noteEmbeddings)
                }
                totalDbMs += (System.nanoTime() - dbStartNs) / 1_000_000
                done++
                EmbeddingProgressBus.updateProgress(done, total)

                // v5.4.259cc — Aggressive periodic memory-pressure check,
                // matching the same 95%-of-maxMemory() threshold and
                // aggressive-clear philosophy as AppViewModel's
                // checkMemoryPressureAndPause() — kept self-contained here
                // rather than shared, since this Service has no access to
                // that private ViewModel member, and only needs to manage
                // the one native resource it actually owns: the embedder
                // (this service never touches reranker/T5/LLM at all, so
                // there's nothing else here to close). Checked every 100
                // notes — frequent enough to catch pressure building up
                // over a long 42k-note pass, cheap enough (a
                // Runtime.maxMemory() read + comparison) to not
                // meaningfully slow the run when memory is fine.
                if (done % 100 == 0) {
                    val maxMb = Runtime.getRuntime().maxMemory() / (1024 * 1024)
                    val usedMb = (Runtime.getRuntime().totalMemory() - Runtime.getRuntime().freeMemory()) / (1024 * 1024)
                    if (usedMb >= (maxMb * 0.95).toLong()) {
                        // embedder.close() is safe mid-pass: embed()'s own
                        // "Lazy session + tokenizer init" (ensureLoaded())
                        // transparently reloads it on the very next call —
                        // confirmed by reading OnnxBertEmbedderBackend.embed()
                        // directly — so this cannot break the next note.
                        runCatching { embedder.close() }
                        runCatching { System.gc() }
                        kotlinx.coroutines.delay(200L)
                        runCatching { System.gc() }
                        kotlinx.coroutines.delay(250L)
                    }
                }

                // Throttle notification updates — the system rate-limits
                // notification posts and posting too fast results in
                // dropped updates and CPU waste.
                val now = System.currentTimeMillis()
                if (now - lastNotificationMs > NOTIFICATION_UPDATE_INTERVAL_MS ||
                    done == total) {
                    val safeDone = done.coerceAtLeast(1)
                    updateNotification(
                        done = done, total = total, complete = false,
                        modelName = descriptor.shortName,
                        avgChunkMs = totalChunkMs / safeDone,
                        avgEmbedMs = totalEmbedMs / safeDone,
                        avgDbMs = totalDbMs / safeDone
                    )
                    lastNotificationMs = now
                }
            }

            EmbeddingProgressBus.complete()
            updateNotification(done = done, total = total, complete = true,
                modelName = descriptor.shortName)
        } finally {
            runCatching { embedder.close() }
            // If we exit via exception or cancellation, make sure the
            // bus reflects idle state.
            EmbeddingProgressBus.idle()
        }
    }

    override fun onDestroy() {
        // Cancel the embed job FIRST, then release the wake lock. Doing
        // it in this order ensures we don't hold power any longer than
        // the loop runs.
        embeddingJob?.cancel()
        serviceScope.cancel()
        runCatching {
            if (wakeLock?.isHeld == true) wakeLock?.release()
        }
        EmbeddingProgressBus.idle()
        super.onDestroy()
    }

    /** Not a bound service — return null. */
    override fun onBind(intent: Intent?): IBinder? = null

    // ── Notification plumbing ───────────────────────────────────────────

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                CHANNEL_ID,
                "Embedding library",
                NotificationManager.IMPORTANCE_LOW   // no sound for progress
            ).apply {
                description = "Shows progress while MarkVault embeds your notes for semantic search."
                setShowBadge(false)
            }
            val nm = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
            nm.createNotificationChannel(channel)
        }
    }

    private fun buildNotification(
        done: Int,
        total: Int,
        complete: Boolean,
        modelName: String = "",
        avgChunkMs: Long = 0L,
        avgEmbedMs: Long = 0L,
        avgDbMs: Long = 0L
    ): Notification {
        // PendingIntent to bring the user back to the app when they tap
        // the notification. Goes straight to MainActivity which already
        // observes EmbeddingProgressBus, so the Settings progress bar is
        // already updated by the time they get there.
        val openIntent = Intent(this, MainActivity::class.java).apply {
            flags = Intent.FLAG_ACTIVITY_SINGLE_TOP or Intent.FLAG_ACTIVITY_CLEAR_TOP
        }
        val pi = PendingIntent.getActivity(
            this, 0, openIntent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        // v5.4.178cc — Per-note timing breakdown (chunk split / ML
        // inference / DB write), shown right in the notification you're
        // already watching, so a slow pass can be diagnosed from a
        // screenshot instead of another guess. See the accumulator
        // comment in runEmbeddingPass for why this exists now.
        val timingSuffix = if (!complete && avgEmbedMs + avgDbMs + avgChunkMs > 0) {
            " · ${avgEmbedMs + avgDbMs + avgChunkMs}ms/note (${avgEmbedMs}ML ${avgDbMs}DB ${avgChunkMs}split)"
        } else {
            ""
        }

        val title: String
        val text: String
        when {
            complete -> {
                title = "MarkVault — embedding complete"
                text = if (modelName.isNotBlank())
                    "$done notes embedded with $modelName"
                else
                    "$done notes embedded"
            }
            total == 0 -> {
                title = "MarkVault — preparing to embed"
                text = "Counting notes…"
            }
            else -> {
                val pct = if (total > 0) (done * 100 / total).coerceIn(0, 100) else 0
                title = "MarkVault — embedding library"
                text = if (modelName.isNotBlank())
                    "$done of $total notes ($pct%) — $modelName$timingSuffix"
                else
                    "$done of $total notes ($pct%)$timingSuffix"
            }
        }

        val builder = NotificationCompat.Builder(this, CHANNEL_ID)
            .setSmallIcon(R.mipmap.ic_launcher)
            .setContentTitle(title)
            .setContentText(text)
            .setContentIntent(pi)
            .setOngoing(!complete)            // sticky while running, dismissable when complete
            .setOnlyAlertOnce(true)
            .setPriority(NotificationCompat.PRIORITY_LOW)
            .setCategory(NotificationCompat.CATEGORY_PROGRESS)

        if (!complete && total > 0) {
            builder.setProgress(total, done, false)
        } else if (!complete) {
            // Indeterminate progress for the "preparing" stage
            builder.setProgress(0, 0, true)
        }

        return builder.build()
    }

    /** Posts an updated notification using the same channel + ID. */
    private fun updateNotification(
        done: Int, total: Int, complete: Boolean, modelName: String,
        avgChunkMs: Long = 0L, avgEmbedMs: Long = 0L, avgDbMs: Long = 0L
    ) {
        val nm = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        nm.notify(
            NOTIFICATION_ID,
            buildNotification(done, total, complete, modelName, avgChunkMs, avgEmbedMs, avgDbMs)
        )
    }

    companion object {
        private const val CHANNEL_ID = "markvault_embedding"
        private const val NOTIFICATION_ID = 4815   // arbitrary, just needs to be stable
        private const val NOTIFICATION_UPDATE_INTERVAL_MS = 500L
        private const val WAKELOCK_TIMEOUT_MS = 8L * 60L * 60L * 1000L  // 8 hours safety net
    }
}
