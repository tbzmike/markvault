package com.tebogo.markvault.search

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.os.Build
import android.os.IBinder
import android.os.PowerManager
import androidx.core.app.NotificationCompat
import com.tebogo.markvault.MainActivity
import com.tebogo.markvault.R
import com.tebogo.markvault.data.NoteEmbedding
import com.tebogo.markvault.data.Prefs
import com.tebogo.markvault.data.VaultDb
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch

/**
 * v4.15.0 — Foreground service that owns the embedding pass.
 *
 * # Why this exists
 *
 * Before v4.15.0, embedding ran in `viewModelScope` inside `AppViewModel`.
 * That works for short jobs but breaks down for big libraries:
 *
 *   - The OS kills background app processes under memory pressure; the
 *     coroutine dies with the process.
 *   - Doze mode throttles background CPU when the screen is off.
 *   - The ViewModel scope is cancelled the moment the Activity is destroyed
 *     (e.g., user swipes the app away from Recents).
 *
 * For a 14k-note library with `bge-large-en-v1.5` (1024-dim), an embedding
 * pass takes roughly 3–4 hours on mid-range Android. The user shouldn't
 * have to stare at the screen the whole time.
 *
 * # What this does instead
 *
 * 1. **Foreground service** — declared in the manifest with type
 *    `dataSync`. Tells Android "this is important user-perceived work,
 *    keep me alive."
 * 2. **Persistent notification** — required for every foreground service
 *    on Android 8+. Doubles as live progress for the user.
 * 3. **Partial wake lock** — prevents CPU sleep while embedding. Tagged
 *    `MarkVault::EmbeddingWakeLock`. Released in `onDestroy`.
 * 4. **Resumable loop** — same code path as the old in-VM loop. The DAO's
 *    `targetsNeedingEmbedding` query already skips already-embedded
 *    notes, so if the OS kills the service mid-pass and restarts it,
 *    we pick up exactly where we left off.
 *
 * # How progress is reported
 *
 * The service writes to [EmbeddingProgressBus] — a module-level
 * StateFlow singleton. The `AppViewModel` delegates its public
 * `embeddingProgress` flow to the bus, so the Settings UI keeps working
 * without any changes to the Composables.
 *
 * # Lifecycle
 *
 * - `onCreate`: create notification channel, allocate wake lock
 * - `onStartCommand`: `startForeground` with the initial notification,
 *   acquire wake lock, launch the embed coroutine (no-op if one is
 *   already running)
 * - Coroutine completes → `stopSelf()` → `onDestroy` cleans up
 * - External cancel: `Context.stopService(Intent(EmbeddingService))` →
 *   `onDestroy` cancels the coroutine + releases resources
 *
 * # Return code: START_REDELIVER_INTENT
 *
 * If the OS kills the service mid-pass (very rare for foreground
 * services but theoretically possible under extreme memory pressure),
 * Android restarts it with the same Intent we originally passed. The
 * embed loop is idempotent — `targetsNeedingEmbedding` returns only
 * notes that still need embedding — so the restart simply continues
 * the pass.
 */
class EmbeddingService : Service() {

    private val serviceScope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
    private var embeddingJob: Job? = null
    private var wakeLock: PowerManager.WakeLock? = null

    override fun onCreate() {
        super.onCreate()
        createNotificationChannel()
        // Allocate the wake lock but DON'T acquire it yet — we acquire in
        // onStartCommand so a stray onCreate without start (which shouldn't
        // happen but doesn't hurt to guard against) doesn't leak power.
        val pm = getSystemService(Context.POWER_SERVICE) as PowerManager
        wakeLock = pm.newWakeLock(
            PowerManager.PARTIAL_WAKE_LOCK,
            "MarkVault::EmbeddingWakeLock"
        )
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        // Required within 5–10 seconds of startForegroundService(). We
        // post a placeholder notification first; the embed coroutine
        // overwrites it with real progress within a few hundred ms.
        startForeground(NOTIFICATION_ID, buildNotification(done = 0, total = 0, complete = false))

        // Acquire the wake lock with an 8-hour safety timeout. Real
        // releases happen in onDestroy. The timeout is just a backstop
        // for the catastrophic case where onDestroy never fires.
        runCatching {
            if (wakeLock?.isHeld != true) {
                wakeLock?.acquire(WAKELOCK_TIMEOUT_MS)
            }
        }

        // If a job is already running, ignore the duplicate start. The
        // service is single-instance by design — we don't want two
        // concurrent embed loops fighting over the same DB rows.
        if (embeddingJob?.isActive == true) {
            return START_REDELIVER_INTENT
        }

        embeddingJob = serviceScope.launch {
            runEmbeddingPass()
            // Tell the OS we're done; onDestroy releases the wake lock
            // and removes the notification.
            stopSelf()
        }
        return START_REDELIVER_INTENT
    }

    /**
     * The actual embed loop. Mirrors the pre-v4.15.0 in-VM loop almost
     * exactly — only the I/O side-effects (notification + bus updates)
     * differ. Kept inside the service so the work survives Activity
     * lifecycle changes.
     *
     * v5.4.58 — Corrupt-note resilience:
     *
     *   Previously a single bad note could stall the entire pass because
     *   [Embedder.embed] has no timeout — if the native MediaPipe code
     *   hangs on corrupt input (binary garbage, malformed Unicode, extreme
     *   line lengths), [done] never increments and the notification number
     *   freezes forever. The service keeps running but appears stuck.
     *
     *   Fixes applied here:
     *
     *   1. **Per-note timeout** — each embed call is wrapped in
     *      `withTimeout(NOTE_EMBED_TIMEOUT_MS)`. If a note hangs the
     *      embedder for longer than 25 seconds it is skipped.
     *
     *   2. **runCatching per note** — any unexpected exception (OOM,
     *      native crash, SQLite error) is caught and logged; the loop
     *      continues with the next note rather than crashing the service.
     *
     *   3. **Sentinel embedding for failed notes** — when a note is
     *      skipped (timeout or error), we write a zero-dimension sentinel
     *      row to `note_embeddings` so [targetsNeedingEmbedding]'s
     *      LEFT JOIN no longer returns it. The note is effectively marked
     *      "attempted, skip permanently" without changing the DB schema.
     *      `dim = 0` is the sentinel marker; search code already guards
     *      `if (vec.size != expectedDim)` before any dot-product.
     *
     *   4. **Logcat trail** — every skipped note logs its ID, title, and
     *      reason at WARN level so the developer can investigate later.
     */
    private suspend fun runEmbeddingPass() {
        val app = application
        val prefs = Prefs(app)
        val activeId = prefs.activeModelId.first()
        val descriptor = com.tebogo.markvault.search.ModelCatalog.byId(activeId)
            ?: com.tebogo.markvault.search.ModelCatalog.default
        if (!descriptor.enabled) {
            EmbeddingProgressBus.idle()
            return
        }

        val embedder = com.tebogo.markvault.search.Embedder(app, descriptor)
        if (!embedder.isModelAvailable()) {
            EmbeddingProgressBus.idle()
            return
        }

        val dao = VaultDb.get(app).notes()

        try {
            EmbeddingProgressBus.start()

            val total = runCatching {
                dao.countNotesNeedingEmbedding(embedder.modelVersion)
            }.getOrElse { 0 }

            if (total == 0) {
                EmbeddingProgressBus.complete()
                updateNotification(done = 0, total = 0, complete = true,
                    modelName = descriptor.shortName)
                return
            }

            EmbeddingProgressBus.updateProgress(0, total)
            updateNotification(done = 0, total = total, complete = false,
                modelName = descriptor.shortName)

            val targets = runCatching {
                dao.targetsNeedingEmbedding(embedder.modelVersion)
            }.getOrElse { emptyList() }

            var done = 0
            var skipped = 0
            var lastNotificationMs = 0L

            for (target in targets) {
                if (!serviceScope.isActive) break

                // ── Per-note isolation: never let one bad note crash the pass
                val noteResult = runCatching {
                    kotlinx.coroutines.withTimeout(NOTE_EMBED_TIMEOUT_MS) {
                        val note = dao.byId(target.id) ?: return@withTimeout
                        val rawText = buildString {
                            append(note.title).append("\n\n").append(note.content)
                        }

                        // Pre-screen: skip obviously non-text content
                        // (e.g. a .md file that actually contains binary data)
                        if (isLikelyCorrupt(rawText)) {
                            android.util.Log.w(TAG,
                                "Skipping note ${note.id} '${note.title}' — " +
                                    "content appears corrupt or binary")
                            writeSentinel(dao, note.id, note.lastModified, embedder.modelVersion)
                            skipped++
                            return@withTimeout
                        }

                        val vec = embedder.embed(rawText)
                        if (vec != null) {
                            runCatching {
                                dao.upsertEmbedding(
                                    NoteEmbedding(
                                        noteId = note.id,
                                        modelVersion = embedder.modelVersion,
                                        dim = vec.size,
                                        vector = floatArrayToBytes(vec),
                                        sourceLastModified = note.lastModified,
                                        createdAt = System.currentTimeMillis()
                                    )
                                )
                            }
                        } else {
                            // Embedder returned null (model not ready or
                            // text was blank after cleaning). Write a
                            // sentinel so we don't retry on next restart.
                            android.util.Log.w(TAG,
                                "Note ${target.id} produced null embedding — writing sentinel")
                            writeSentinel(dao, target.id, target.lastModified, embedder.modelVersion)
                            skipped++
                        }
                    }
                }

                if (noteResult.isFailure) {
                    val ex = noteResult.exceptionOrNull()
                    val isTimeout = ex is kotlinx.coroutines.TimeoutCancellationException
                    android.util.Log.w(TAG,
                        "Note ${target.id} skipped — ${if (isTimeout) "timed out after ${NOTE_EMBED_TIMEOUT_MS}ms" else ex?.message}")
                    // Write sentinel so this note is skipped in future passes
                    runCatching {
                        writeSentinel(dao, target.id, target.lastModified, embedder.modelVersion)
                    }
                    skipped++
                }

                done++
                EmbeddingProgressBus.updateProgress(done, total)

                val now = System.currentTimeMillis()
                if (now - lastNotificationMs > NOTIFICATION_UPDATE_INTERVAL_MS || done == total) {
                    updateNotification(done = done, total = total, complete = false,
                        modelName = descriptor.shortName, skipped = skipped)
                    lastNotificationMs = now
                }
            }

            EmbeddingProgressBus.complete()
            updateNotification(done = done, total = total, complete = true,
                modelName = descriptor.shortName, skipped = skipped)
        } finally {
            runCatching { embedder.close() }
            EmbeddingProgressBus.idle()
        }
    }

    /**
     * Write a zero-dimension sentinel embedding so [targetsNeedingEmbedding]
     * stops returning this note. The sentinel is detectable by `dim == 0`.
     * Search code already filters `if (vec.size != expectedDim)` so sentinels
     * are never used in cosine similarity calculations.
     */
    private suspend fun writeSentinel(
        dao: com.tebogo.markvault.data.NoteDao,
        noteId: Long,
        lastModified: Long,
        modelVersion: String
    ) {
        runCatching {
            dao.upsertEmbedding(
                NoteEmbedding(
                    noteId = noteId,
                    modelVersion = modelVersion,
                    dim = 0,           // sentinel marker
                    vector = ByteArray(0),
                    sourceLastModified = lastModified,
                    createdAt = System.currentTimeMillis()
                )
            )
        }
    }

    /**
     * Quick heuristic to detect notes whose content is likely binary or
     * severely corrupt — e.g. a .md file that actually contains binary
     * data, or a note imported from a broken PDF that left garbage bytes.
     *
     * Checks:
     *   - More than 5% null bytes in the first 2000 chars → binary
     *   - More than 30% non-printable non-whitespace characters → binary
     *   - Single line longer than 50,000 chars (would cause tokenizer hang)
     */
    private fun isLikelyCorrupt(text: String): Boolean {
        val sample = text.take(2000)
        if (sample.isBlank()) return false

        val nullCount = sample.count { it == '\u0000' }
        if (nullCount > sample.length * 0.05) return true

        val nonPrintable = sample.count { c ->
            !c.isWhitespace() && !c.isLetterOrDigit() &&
                !c.isISOControl() && c.code < 32
        }
        if (nonPrintable > sample.length * 0.30) return true

        // Single line > 50k chars (pathological input for tokenizer)
        if (text.lineSequence().any { it.length > 50_000 }) return true

        return false
    }

    override fun onDestroy() {
        // Cancel the embed job FIRST, then release the wake lock. Doing
        // it in this order ensures we don't hold power any longer than
        // the loop runs.
        embeddingJob?.cancel()
        serviceScope.cancel()
        runCatching {
            if (wakeLock?.isHeld == true) wakeLock?.release()
        }
        EmbeddingProgressBus.idle()
        super.onDestroy()
    }

    /** Not a bound service — return null. */
    override fun onBind(intent: Intent?): IBinder? = null

    // ── Notification plumbing ───────────────────────────────────────────

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                CHANNEL_ID,
                "Embedding library",
                NotificationManager.IMPORTANCE_LOW   // no sound for progress
            ).apply {
                description = "Shows progress while MarkVault embeds your notes for semantic search."
                setShowBadge(false)
            }
            val nm = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
            nm.createNotificationChannel(channel)
        }
    }

    private fun buildNotification(
        done: Int,
        total: Int,
        complete: Boolean,
        modelName: String = "",
        skipped: Int = 0
    ): Notification {
        // PendingIntent to bring the user back to the app when they tap
        // the notification. Goes straight to MainActivity which already
        // observes EmbeddingProgressBus, so the Settings progress bar is
        // already updated by the time they get there.
        val openIntent = Intent(this, MainActivity::class.java).apply {
            flags = Intent.FLAG_ACTIVITY_SINGLE_TOP or Intent.FLAG_ACTIVITY_CLEAR_TOP
        }
        val pi = PendingIntent.getActivity(
            this, 0, openIntent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        val title: String
        val text: String
        when {
            complete -> {
                title = "MarkVault — embedding complete"
                val skipSuffix = if (skipped > 0) ", $skipped skipped (corrupt)" else ""
                text = if (modelName.isNotBlank())
                    "$done notes embedded with $modelName$skipSuffix"
                else
                    "$done notes embedded$skipSuffix"
            }
            total == 0 -> {
                title = "MarkVault — preparing to embed"
                text = "Counting notes…"
            }
            else -> {
                val pct = if (total > 0) (done * 100 / total).coerceIn(0, 100) else 0
                title = "MarkVault — embedding library"
                text = if (modelName.isNotBlank())
                    "$done of $total notes ($pct%) — $modelName"
                else
                    "$done of $total notes ($pct%)"
            }
        }

        val builder = NotificationCompat.Builder(this, CHANNEL_ID)
            .setSmallIcon(R.mipmap.ic_launcher)
            .setContentTitle(title)
            .setContentText(text)
            .setContentIntent(pi)
            .setOngoing(!complete)            // sticky while running, dismissable when complete
            .setOnlyAlertOnce(true)
            .setPriority(NotificationCompat.PRIORITY_LOW)
            .setCategory(NotificationCompat.CATEGORY_PROGRESS)

        if (!complete && total > 0) {
            builder.setProgress(total, done, false)
        } else if (!complete) {
            // Indeterminate progress for the "preparing" stage
            builder.setProgress(0, 0, true)
        }

        return builder.build()
    }

    /** Posts an updated notification using the same channel + ID. */
    private fun updateNotification(
        done: Int, total: Int, complete: Boolean, modelName: String, skipped: Int = 0
    ) {
        val nm = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        nm.notify(NOTIFICATION_ID, buildNotification(done, total, complete, modelName, skipped))
    }

    companion object {
        private const val TAG = "EmbeddingService"
        private const val CHANNEL_ID = "markvault_embedding"
        private const val NOTIFICATION_ID = 4815
        private const val NOTIFICATION_UPDATE_INTERVAL_MS = 500L
        private const val WAKELOCK_TIMEOUT_MS = 8L * 60L * 60L * 1000L
        /** Max time to spend embedding a single note before skipping it. */
        private const val NOTE_EMBED_TIMEOUT_MS = 25_000L
    }
}
