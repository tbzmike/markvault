package com.tebogo.markvault.search

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.os.Build
import android.os.IBinder
import android.os.PowerManager
import androidx.core.app.NotificationCompat
import com.tebogo.markvault.MainActivity
import com.tebogo.markvault.R
import com.tebogo.markvault.data.NoteEmbedding
import com.tebogo.markvault.data.Prefs
import com.tebogo.markvault.data.VaultDb
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.CoroutineStart
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch

/**
 * v4.15.0 — Foreground service that owns the embedding pass.
 *
 * # Why this exists
 *
 * Before v4.15.0, embedding ran in `viewModelScope` inside `AppViewModel`.
 * That works for short jobs but breaks down for big libraries:
 *
 *   - The OS kills background app processes under memory pressure; the
 *     coroutine dies with the process.
 *   - Doze mode throttles background CPU when the screen is off.
 *   - The ViewModel scope is cancelled the moment the Activity is destroyed
 *     (e.g., user swipes the app away from Recents).
 *
 * For a 14k-note library with `bge-large-en-v1.5` (1024-dim), an embedding
 * pass takes roughly 3–4 hours on mid-range Android. The user shouldn't
 * have to stare at the screen the whole time.
 *
 * # What this does instead
 *
 * 1. **Foreground service** — declared in the manifest with type
 *    `dataSync`. Tells Android "this is important user-perceived work,
 *    keep me alive."
 * 2. **Persistent notification** — required for every foreground service
 *    on Android 8+. Doubles as live progress for the user.
 * 3. **Partial wake lock** — prevents CPU sleep while embedding. Tagged
 *    `MarkVault::EmbeddingWakeLock`. Released in `onDestroy`.
 * 4. **Resumable loop** — same code path as the old in-VM loop. The DAO's
 *    `targetsNeedingEmbedding` query already skips already-embedded
 *    notes, so if the OS kills the service mid-pass and restarts it,
 *    we pick up exactly where we left off.
 *
 * # How progress is reported
 *
 * The service writes to [EmbeddingProgressBus] — a module-level
 * StateFlow singleton. The `AppViewModel` delegates its public
 * `embeddingProgress` flow to the bus, so the Settings UI keeps working
 * without any changes to the Composables.
 *
 * # Lifecycle
 *
 * - `onCreate`: create notification channel, allocate wake lock
 * - `onStartCommand`: `startForeground` with the initial notification,
 *   acquire wake lock, and launch one worker. Additional start requests are
 *   coalesced into a fresh delta pass instead of running concurrently.
 * - Worker drains pending delta requests → `stopSelfResult()` → `onDestroy` cleans up
 * - External cancel: `Context.stopService(Intent(EmbeddingService))` →
 *   `onDestroy` cancels the coroutine + releases resources
 *
 * # Return code: START_REDELIVER_INTENT
 *
 * If the OS kills the service mid-pass (very rare for foreground
 * services but theoretically possible under extreme memory pressure),
 * Android restarts it with the same Intent we originally passed. The
 * embed loop is idempotent — `targetsNeedingEmbedding` returns only
 * notes that still need embedding — so the restart simply continues
 * the pass.
 */
class EmbeddingService : Service() {

    private val serviceScope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
    private var embeddingJob: Job? = null
    private var wakeLock: PowerManager.WakeLock? = null

    /**
     * v5.5.8 — Coalesced re-entry state. Every start request advances a
     * generation. The single worker snapshots that generation before a pass
     * and runs another delta pass if a newer request arrived meanwhile.
     *
     * Access is guarded by [requestLock] rather than a lone volatile boolean:
     * this closes the tiny finish/start race where an article could arrive
     * after the worker's final `while` check but before `stopSelf()`.
     */
    private val requestLock = Any()
    private var requestedGeneration: Long = 0L
    private var latestStartId: Int = 0

    override fun onCreate() {
        super.onCreate()
        createNotificationChannel()
        // Allocate the wake lock but DON'T acquire it yet — we acquire in
        // onStartCommand so a stray onCreate without start (which shouldn't
        // happen but doesn't hurt to guard against) doesn't leak power.
        val pm = getSystemService(Context.POWER_SERVICE) as PowerManager
        wakeLock = pm.newWakeLock(
            PowerManager.PARTIAL_WAKE_LOCK,
            "MarkVault::EmbeddingWakeLock"
        )
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        var shouldLaunchWorker = false
        synchronized(requestLock) {
            requestedGeneration++
            latestStartId = startId
            // Android serialises onStartCommand() on the main thread, and this
            // lock also coordinates with the worker's finish decision. A later
            // request therefore cannot fall into the old check/stopSelf gap.
            if (embeddingJob?.isActive != true) shouldLaunchWorker = true
        }

        // If a worker already owns the foreground service, this request is now
        // represented by requestedGeneration. Do NOT reset its notification to
        // "preparing"; it will run one fresh delta pass before stopping.
        if (!shouldLaunchWorker) return START_REDELIVER_INTENT

        // Required within 5–10 seconds of the first startForegroundService().
        // The embed coroutine overwrites this placeholder with real progress.
        startForeground(NOTIFICATION_ID, buildNotification(done = 0, total = 0, complete = false))

        // Acquire the wake lock with an 8-hour safety timeout. Real
        // releases happen in onDestroy. The timeout is just a backstop
        // for the catastrophic case where onDestroy never fires.
        runCatching {
            if (wakeLock?.isHeld != true) {
                wakeLock?.acquire(WAKELOCK_TIMEOUT_MS)
            }
        }

        // LAZY ensures embeddingJob is published under requestLock BEFORE the
        // IO dispatcher can run to completion and clear it.
        val worker = serviceScope.launch(start = CoroutineStart.LAZY) {
            while (serviceScope.isActive) {
                val passGeneration = synchronized(requestLock) { requestedGeneration }
                try {
                    runEmbeddingPass()
                } catch (cancelled: kotlinx.coroutines.CancellationException) {
                    throw cancelled
                } catch (t: Throwable) {
                    // Keep the service from becoming permanently wedged by one
                    // model/backend failure. If another request arrived during
                    // this pass, the generation check below still permits a
                    // fresh delta attempt.
                    android.util.Log.e("EmbeddingService", "Embedding/model-index pass failed", t)
                    EmbeddingProgressBus.idle()
                }

                var stopId = 0
                val runAgain = synchronized(requestLock) {
                    if (requestedGeneration > passGeneration) {
                        true
                    } else {
                        // Mark this worker absent while holding the same lock
                        // used by onStartCommand(). If a new start arrives after
                        // this point it launches a new worker; stopSelfResult()
                        // below uses the old startId and cannot stop that newer
                        // request.
                        embeddingJob = null
                        stopId = latestStartId
                        false
                    }
                }
                if (!runAgain) {
                    stopSelfResult(stopId)
                    return@launch
                }
            }
        }
        synchronized(requestLock) {
            embeddingJob = worker
        }
        worker.start()
        return START_REDELIVER_INTENT
    }

    /**
     * v5.5.8 — Embed the active model AND keep every already-built ANN model
     * synchronized.
     *
     * ANN files are model-specific because embeddings from BGE-large, BGE-base,
     * MiniLM, USE, etc. live in different vector spaces/dimensions and cannot
     * share centroids. The previous service embedded only the currently-active
     * model; consequently an ANN index built for another installed model stopped
     * receiving newly-added/edited articles until the user switched back and
     * manually rebuilt/re-embedded it.
     *
     * New rule:
     *   1. Always maintain the active installed embedding model (old behaviour).
     *   2. Also maintain every OTHER installed model that already has its own
     *      ANN index on disk.
     *   3. After each model's delta embedding pass, reconcile that model's ANN
     *      memberships from the current DB rows. New notes are added, updated
     *      notes are re-clustered, and deleted/orphaned memberships are pruned.
     *   4. This maintenance is independent of the Fast Search toggle. Turning
     *      ANN search off must not make the index silently stale for later use.
     *
     * Models that are merely installed but have NEVER had an ANN index built are
     * not force-embedded in the background; their first full ANN build remains a
     * deliberate per-model user action. This avoids unexpectedly starting a
     * multi-hour BGE-large full-library pass just because its files are present.
     */
    private suspend fun runEmbeddingPass() {
        val app = application
        val prefs = Prefs(app)
        val storedActiveId = prefs.activeModelId.first()
        val activeDescriptor = ModelCatalog.byId(storedActiveId) ?: ModelCatalog.default
        val dao = VaultDb.get(app).notes()
        val annIndex = AnnIndex(app)

        data class ModelWork(
            val descriptor: ModelDescriptor,
            val modelVersion: String,
            val maintainAnn: Boolean,
            val plannedTargets: Int
        )

        // Active model first, then the remaining catalog entries in their
        // existing deterministic order. Probe objects do not load native model
        // sessions; isModelAvailable() only validates files on disk.
        val orderedDescriptors = ModelCatalog.all
            .filter { it.enabled }
            .sortedBy { if (it.id == activeDescriptor.id) 0 else 1 }

        val work = ArrayList<ModelWork>()
        for (descriptor in orderedDescriptors) {
            val probe = Embedder(app, descriptor)
            val modelVersion = probe.modelVersion
            val installed = runCatching { probe.isModelAvailable() }.getOrElse { false }
            runCatching { probe.close() }
            if (!installed) continue

            val hasAnn = annIndex.isAvailable(modelVersion)
            // Preserve the historical active-model embedding behaviour even
            // before ANN is built. Other models join automatic maintenance only
            // after they have a real ANN index of their own.
            if (descriptor.id != activeDescriptor.id && !hasAnn) continue

            val count = runCatching {
                dao.countNotesNeedingEmbedding(modelVersion)
            }.getOrElse { 0 }
            work.add(ModelWork(descriptor, modelVersion, hasAnn, count))
        }

        if (work.isEmpty()) {
            EmbeddingProgressBus.idle()
            return
        }

        var totalWork = work.sumOf { it.plannedTargets }
        var overallDone = 0
        var lastNotificationMs = 0L
        var completedModels = 0
        var lastModelName = work.first().descriptor.shortName

        try {
            EmbeddingProgressBus.start()
            if (totalWork > 0) EmbeddingProgressBus.updateProgress(0, totalWork)
            updateNotification(
                done = 0,
                total = totalWork,
                complete = false,
                modelName = "${work.first().descriptor.shortName} · model 1/${work.size}"
            )

            for ((modelIndex, modelWork) in work.withIndex()) {
                if (!serviceScope.isActive) break

                val descriptor = modelWork.descriptor
                val embedder = Embedder(app, descriptor)
                lastModelName = descriptor.shortName
                if (!embedder.isModelAvailable()) {
                    runCatching { embedder.close() }
                    continue
                }

                // Re-query at the moment this model starts. A note may have
                // been added/edited after the initial counts above.
                val targets = runCatching {
                    dao.targetsNeedingEmbedding(embedder.modelVersion)
                }.getOrElse { emptyList() }

                // If the live target list grew after preflight, grow the
                // denominator rather than allowing progress to exceed 100%.
                val plannedForThisModel = modelWork.plannedTargets
                if (targets.size > plannedForThisModel) {
                    totalWork += targets.size - plannedForThisModel
                }

                // Only notes whose replacement transaction actually succeeds
                // are considered dirty for ANN re-clustering. If a DB write
                // fails, leaving the old membership in place is safer than
                // re-clustering stale vectors and pretending the update landed.
                val dirtyNoteIds = HashSet<Long>(targets.size * 2 + 1)

                var modelDone = 0
                var totalChunkMs = 0L
                var totalEmbedMs = 0L
                var totalDbMs = 0L

                try {
                    for (target in targets) {
                        if (!serviceScope.isActive) break

                        val note = runCatching { dao.byId(target.id) }.getOrNull()
                        if (note == null) {
                            // The note disappeared after targets were queried.
                            // Count the unit as consumed so aggregate progress
                            // remains monotonic; ANN reconciliation below will
                            // prune its old membership if necessary.
                            overallDone++
                            modelDone++
                            if (totalWork > 0) {
                                EmbeddingProgressBus.updateProgress(overallDone, totalWork)
                            }
                            continue
                        }

                        // v5.4.176cc — bulk indexing deliberately uses broader
                        // 350-word chunks with 70-word overlap to keep inference
                        // call count manageable while staying below the 512-token
                        // model budget. This behaviour is preserved exactly.
                        val chunkStartNs = System.nanoTime()
                        val contentChunks = buildOverlappingChunks(
                            note.content,
                            targetWords = 350,
                            overlapWords = 70,
                            minWords = 30
                        )
                        totalChunkMs += (System.nanoTime() - chunkStartNs) / 1_000_000
                        val chunkTexts: List<String> = if (contentChunks.isNotEmpty()) {
                            contentChunks.map { it.text }
                        } else {
                            listOf(note.content)
                        }

                        // v5.4.177cc — keep the existing one-transaction-per-note
                        // write: replace the complete chunk set atomically so a
                        // shortened article cannot retain stale trailing chunks.
                        val noteEmbeddings = mutableListOf<NoteEmbedding>()
                        for ((chunkIdx, chunkText) in chunkTexts.withIndex()) {
                            if (!serviceScope.isActive) break
                            val textToEmbed = buildString {
                                append(note.title).append("\n\n").append(chunkText)
                            }
                            val embedStartNs = System.nanoTime()
                            val vec = embedder.embed(textToEmbed)
                            totalEmbedMs += (System.nanoTime() - embedStartNs) / 1_000_000
                            if (vec != null) {
                                noteEmbeddings.add(
                                    NoteEmbedding(
                                        noteId = note.id,
                                        modelVersion = embedder.modelVersion,
                                        chunkIndex = chunkIdx,
                                        dim = vec.size,
                                        vector = floatArrayToBytes(vec),
                                        sourceLastModified = note.lastModified,
                                        createdAt = System.currentTimeMillis()
                                    )
                                )
                            }
                        }

                        val dbStartNs = System.nanoTime()
                        val wroteEmbeddings = runCatching {
                            dao.replaceNoteEmbeddings(
                                note.id,
                                embedder.modelVersion,
                                noteEmbeddings
                            )
                            true
                        }.onFailure {
                            android.util.Log.e(
                                "EmbeddingService",
                                "Failed to replace embeddings for note ${note.id} / ${descriptor.id}",
                                it
                            )
                        }.getOrDefault(false)
                        totalDbMs += (System.nanoTime() - dbStartNs) / 1_000_000
                        if (wroteEmbeddings) dirtyNoteIds.add(note.id)

                        overallDone++
                        modelDone++
                        if (totalWork > 0) {
                            EmbeddingProgressBus.updateProgress(overallDone, totalWork)
                        }

                        // Preserve v5.4.260cc's aggressive memory-pressure
                        // protection. Closing is safe: Embedder lazily reloads
                        // its native session on the next embed() call.
                        run {
                            val rt = Runtime.getRuntime()
                            val maxBytes = rt.maxMemory().coerceAtLeast(1L)
                            val usedBytes = rt.totalMemory() - rt.freeMemory()
                            if (usedBytes >= (maxBytes * 95L) / 100L) {
                                runCatching { embedder.close() }
                                runCatching { System.gc() }
                                kotlinx.coroutines.delay(200L)
                                runCatching { System.gc() }
                                kotlinx.coroutines.delay(250L)
                            }
                        }

                        val now = System.currentTimeMillis()
                        if (now - lastNotificationMs > NOTIFICATION_UPDATE_INTERVAL_MS ||
                            overallDone == totalWork) {
                            val safeModelDone = modelDone.coerceAtLeast(1)
                            updateNotification(
                                done = overallDone,
                                total = totalWork,
                                complete = false,
                                modelName = "${descriptor.shortName} · model ${modelIndex + 1}/${work.size}",
                                avgChunkMs = totalChunkMs / safeModelDone,
                                avgEmbedMs = totalEmbedMs / safeModelDone,
                                avgDbMs = totalDbMs / safeModelDone
                            )
                            lastNotificationMs = now
                        }
                    }
                } finally {
                    runCatching { embedder.close() }
                }

                // v5.5.8 — ANN maintenance belongs to the MODEL that owns the
                // vectors, not whichever model happens to be active in the UI.
                // Avoid a full vector-table scan when absolutely nothing changed:
                // the model-specific header must match both Room's embedding count
                // and its newest embedding timestamp. Dirty notes force a sync even
                // when the count is unchanged because their vectors may have moved
                // to different clusters.
                if (modelWork.maintainAnn && annIndex.isAvailable(modelWork.modelVersion)) {
                    val currentEmbeddingCount = runCatching {
                        dao.embeddingCount(modelWork.modelVersion)
                    }.getOrElse { -1 }
                    val latestEmbeddingAt = runCatching {
                        dao.latestEmbeddingCreatedAt(modelWork.modelVersion)
                    }.getOrElse { Long.MAX_VALUE }
                    val annStats = annIndex.stats(modelWork.modelVersion)
                    // v5.5.12 — count equality is not sufficient: an edited
                    // note can be replaced by the same number of chunk rows.
                    // Track this separately so synchronizeModel can persist a
                    // new freshness watermark even when membership/counts do
                    // not otherwise need rewriting.
                    val timestampStale = annStats != null &&
                        annStats.buildTimestamp < latestEmbeddingAt
                    val needsAnnSync = dirtyNoteIds.isNotEmpty() ||
                        currentEmbeddingCount < 0 ||
                        annStats == null ||
                        annStats.embeddingCountAtBuild != currentEmbeddingCount ||
                        annStats.numVectors != currentEmbeddingCount ||
                        timestampStale

                    if (needsAnnSync) {
                        updateNotification(
                            done = overallDone,
                            total = totalWork,
                            complete = false,
                            modelName = "${descriptor.shortName} · syncing fast index"
                        )
                        val syncResult = runCatching {
                            annIndex.synchronizeModel(
                                loadPage = { limit, offset ->
                                    dao.loadEmbeddingVectorsPage(
                                        modelWork.modelVersion,
                                        limit,
                                        offset
                                    ).map { it.noteId to it.vector }
                                },
                                modelVersion = modelWork.modelVersion,
                                dirtyNoteIds = dirtyNoteIds,
                                forceFreshnessWrite = timestampStale
                            )
                        }.onFailure {
                            android.util.Log.e(
                                "EmbeddingService",
                                "ANN synchronization failed for ${descriptor.id}",
                                it
                            )
                        }.getOrNull()

                        if (syncResult != null &&
                            (syncResult.updatedNotes > 0 || syncResult.removedNotes > 0)) {
                            android.util.Log.i(
                                "EmbeddingService",
                                "ANN synchronized ${descriptor.id}: " +
                                    "updated=${syncResult.updatedNotes}, " +
                                    "removed=${syncResult.removedNotes}, " +
                                    "embeddings=${syncResult.embeddingCount}"
                            )
                            // Preserve the existing user-auditable Fast Search
                            // history, now with the owning model identified.
                            runCatching {
                                (app as? com.tebogo.markvault.MarkVaultApp)?.activityLog?.log(
                                    com.tebogo.markvault.data.ActivityLog.Category.FAST_SEARCH,
                                    "ANN index synchronized — ${descriptor.shortName}",
                                    mapOf(
                                        "updated_notes" to syncResult.updatedNotes.toString(),
                                        "removed_notes" to syncResult.removedNotes.toString(),
                                        "embedding_rows" to syncResult.embeddingCount.toString(),
                                        "model" to descriptor.id
                                    )
                                )
                            }
                        }
                    }
                    // Only one model's centroids need to be resident at once.
                    annIndex.unload()
                }

                completedModels++
                // Release native pressure before loading the next embedding
                // model (especially important when BGE-large is followed by
                // another ONNX model).
                runCatching { System.gc() }
                kotlinx.coroutines.delay(50L)
            }

            EmbeddingProgressBus.complete()
            updateNotification(
                done = overallDone,
                total = totalWork,
                complete = true,
                modelName = if (completedModels > 1)
                    "$completedModels models synchronized"
                else
                    lastModelName
            )
        } finally {
            annIndex.unload()
            // If we exit via exception/cancellation, make sure the bus cannot
            // remain stuck in a running state.
            EmbeddingProgressBus.idle()
        }
    }

    override fun onDestroy() {
        // Cancel the embed job FIRST, then release the wake lock. Doing
        // it in this order ensures we don't hold power any longer than
        // the loop runs.
        embeddingJob?.cancel()
        serviceScope.cancel()
        runCatching {
            if (wakeLock?.isHeld == true) wakeLock?.release()
        }
        EmbeddingProgressBus.idle()
        super.onDestroy()
    }

    /** Not a bound service — return null. */
    override fun onBind(intent: Intent?): IBinder? = null

    // ── Notification plumbing ───────────────────────────────────────────

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                CHANNEL_ID,
                "Embedding library",
                NotificationManager.IMPORTANCE_LOW   // no sound for progress
            ).apply {
                description = "Shows progress while MarkVault embeds your notes for semantic search."
                setShowBadge(false)
            }
            val nm = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
            nm.createNotificationChannel(channel)
        }
    }

    private fun buildNotification(
        done: Int,
        total: Int,
        complete: Boolean,
        modelName: String = "",
        avgChunkMs: Long = 0L,
        avgEmbedMs: Long = 0L,
        avgDbMs: Long = 0L
    ): Notification {
        // PendingIntent to bring the user back to the app when they tap
        // the notification. Goes straight to MainActivity which already
        // observes EmbeddingProgressBus, so the Settings progress bar is
        // already updated by the time they get there.
        val openIntent = Intent(this, MainActivity::class.java).apply {
            flags = Intent.FLAG_ACTIVITY_SINGLE_TOP or Intent.FLAG_ACTIVITY_CLEAR_TOP
        }
        val pi = PendingIntent.getActivity(
            this, 0, openIntent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        // v5.4.178cc — Per-note timing breakdown (chunk split / ML
        // inference / DB write), shown right in the notification you're
        // already watching, so a slow pass can be diagnosed from a
        // screenshot instead of another guess. See the accumulator
        // comment in runEmbeddingPass for why this exists now.
        val timingSuffix = if (!complete && avgEmbedMs + avgDbMs + avgChunkMs > 0) {
            " · ${avgEmbedMs + avgDbMs + avgChunkMs}ms/note (${avgEmbedMs}ML ${avgDbMs}DB ${avgChunkMs}split)"
        } else {
            ""
        }

        val title: String
        val text: String
        when {
            complete -> {
                title = "MarkVault — embedding/index sync complete"
                text = when {
                    done > 0 && modelName.isNotBlank() ->
                        "$done embedding update${if (done == 1) "" else "s"} · $modelName"
                    modelName.isNotBlank() -> "Fast-search indexes checked · $modelName"
                    else -> "Embedding and fast-search maintenance complete"
                }
            }
            total == 0 -> {
                title = "MarkVault — synchronizing fast search"
                text = if (modelName.isNotBlank()) modelName else "Checking model indexes…"
            }
            else -> {
                val pct = if (total > 0) (done * 100 / total).coerceIn(0, 100) else 0
                title = "MarkVault — synchronizing embeddings"
                text = if (modelName.isNotBlank())
                    "$done of $total updates ($pct%) — $modelName$timingSuffix"
                else
                    "$done of $total updates ($pct%)$timingSuffix"
            }
        }

        val builder = NotificationCompat.Builder(this, CHANNEL_ID)
            .setSmallIcon(R.mipmap.ic_launcher)
            .setContentTitle(title)
            .setContentText(text)
            .setContentIntent(pi)
            .setOngoing(!complete)            // sticky while running, dismissable when complete
            .setOnlyAlertOnce(true)
            .setPriority(NotificationCompat.PRIORITY_LOW)
            .setCategory(NotificationCompat.CATEGORY_PROGRESS)

        if (!complete && total > 0) {
            builder.setProgress(total, done, false)
        } else if (!complete) {
            // Indeterminate progress for the "preparing" stage
            builder.setProgress(0, 0, true)
        }

        return builder.build()
    }

    /** Posts an updated notification using the same channel + ID. */
    private fun updateNotification(
        done: Int, total: Int, complete: Boolean, modelName: String,
        avgChunkMs: Long = 0L, avgEmbedMs: Long = 0L, avgDbMs: Long = 0L
    ) {
        val nm = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        nm.notify(
            NOTIFICATION_ID,
            buildNotification(done, total, complete, modelName, avgChunkMs, avgEmbedMs, avgDbMs)
        )
    }

    companion object {
        private const val CHANNEL_ID = "markvault_embedding"
        private const val NOTIFICATION_ID = 4815   // arbitrary, just needs to be stable
        private const val NOTIFICATION_UPDATE_INTERVAL_MS = 500L
        private const val WAKELOCK_TIMEOUT_MS = 8L * 60L * 60L * 1000L  // 8 hours safety net
    }
}
