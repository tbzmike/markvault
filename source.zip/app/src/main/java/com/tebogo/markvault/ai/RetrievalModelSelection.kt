package com.tebogo.markvault.ai

/**
 * Selected local retrieval model.
 */
object RetrievalModelSelection {

    enum class Model {
        GEMMA_3,
        QWEN,
        SMOLLM2_360M
    }

    private var selected = Model.GEMMA_3

    fun select(model: Model) {
        selected = model
    }

    fun current(): Model = selected
}
