package com.tebogo.markvault.ai

/**
 * v5.4.120cc — Bookkeeping stub for the currently-selected retrieval model.
 * Parallel to [RetrievalModelManager] but scoped to "selection" (user
 * intent) rather than "active" (loaded runtime). Enum member reflects
 * the model actually shipped in [com.tebogo.markvault.llm.ChatModelCatalog].
 *
 * v5.4.120cc: replaced PHI4_MINI with QWEN3_4B to mirror the removal of
 * Phi-4-mini and Qwen3 0.6B from ChatModelCatalog and the addition of
 * Qwen3-4B-Instruct-2507 as the heavy option.
 */
object RetrievalModelSelection {
    enum class Model {
        QWEN3_4B
    }

    private var selected = Model.QWEN3_4B

    fun select(model: Model) {
        selected = model
    }

    fun current(): Model = selected
}
