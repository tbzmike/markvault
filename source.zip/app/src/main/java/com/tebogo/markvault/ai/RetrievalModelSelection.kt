package com.tebogo.markvault.ai

/**
 * v5.4.59 — UI-layer selection state for the retrieval model picker.
 * Mirrors [RetrievalModelManager] but lives closer to the compose UI.
 */
object RetrievalModelSelection {
    enum class Model {
        QWEN3_0_6B,
        QWEN3_4B
    }

    private var selected = Model.QWEN3_0_6B

    fun select(model: Model) {
        selected = model
    }

    fun current(): Model = selected
}
