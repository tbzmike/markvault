package com.tebogo.markvault.ai

/**
 * Selected local retrieval model.
 */
object RetrievalModelSelection {

    enum class Model {
        GEMMA3_QWEN_0_6B,
        GEMMA3_QWEN_0_6B,
        SMOLLM2_360M
    }

    private var selected = Model.GEMMA3_QWEN_0_6B

    fun select(model: Model) {
        selected = model
    }

    fun current(): Model = selected
}
