package com.tebogo.markvault.ai

/**
 * v5.4.60 — UI-layer retrieval model selection.
 *
 * Update 2:
 * Added Qwen 2.5 1.5B as the recommended default model.
 */
object RetrievalModelSelection {

    enum class Model {
        QWEN2_5_1_5B,
        QWEN3_0_6B,
        QWEN3_4B,
        PHI4_MINI
    }

    private var selected = Model.QWEN2_5_1_5B

    fun select(model: Model) {
        selected = model
    }

    fun current(): Model = selected
}
