package com.tebogo.markvault.ai

/**
 * v5.4.75cc — Bookkeeping stub for the currently-selected retrieval model.
 * Parallel to [RetrievalModelManager] but scoped to "selection" (user
 * intent) rather than "active" (loaded runtime). Enum member reflects
 * the model actually shipped in
 * [com.tebogo.markvault.llm.ChatModelCatalog].
 */
object RetrievalModelSelection {
    enum class Model {
        PHI4_MINI
    }

    private var selected = Model.PHI4_MINI

    fun select(model: Model) {
        selected = model
    }

    fun current(): Model = selected
}
