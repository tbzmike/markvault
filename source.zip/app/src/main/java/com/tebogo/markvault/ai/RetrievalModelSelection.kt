package com.tebogo.markvault.ai

/**
 * v5.4.73 — UI-layer retrieval model selection.
 */
object RetrievalModelSelection {
    enum class Model {
        QWEN3_0_6B,
        QWEN2_5_1_5B,
        QWEN3_4B,
        PHI4_MINI
    }

    private var selected = Model.QWEN3_0_6B

    fun select(model: Model) { selected = model }
    fun current(): Model = selected
}
