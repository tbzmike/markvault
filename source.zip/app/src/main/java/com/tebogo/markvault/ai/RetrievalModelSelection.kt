package com.tebogo.markvault.ai

object RetrievalModelSelection {

    enum class Model {
        GEMMA3_QWEN_0_6B
    }

    private var selected = Model.GEMMA3_QWEN_0_6B

    fun select(model: Model) {
        selected = model
    }

    fun current(): Model = selected
}
