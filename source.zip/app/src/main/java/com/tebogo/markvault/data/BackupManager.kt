package com.tebogo.markvault.data

import android.content.Context
import android.database.sqlite.SQLiteDatabase
import android.net.Uri
import android.provider.DocumentsContract
import android.util.Log
import androidx.sqlite.db.SupportSQLiteDatabase
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.runBlocking
import org.json.JSONObject
import java.io.File
import java.io.DataInputStream
import java.io.DataOutputStream
import java.io.FileInputStream
import java.io.FileOutputStream
import java.io.ByteArrayOutputStream
import java.io.OutputStream
import java.io.BufferedOutputStream
import java.security.MessageDigest
import java.util.zip.ZipEntry
import java.util.zip.ZipInputStream
import java.util.zip.ZipFile
import java.util.zip.ZipOutputStream
import java.util.zip.Deflater

/**
 * MarkVault backup / restore.
 *
 * Backup v7 includes indexed notes/chunks, all-model article + media embeddings,
 * PDF/web/media/playlist history, ANN snapshots, DataStore & app preferences,
 * saved-search/model assets and the original SAF library tree (including empty
 * folders). Restores require a user-selected writable SAF tree on the new phone.
 * Original file permissions / content URIs are NOT copied between phones.
 * v1-v6 archives remain readable. Streaming avoids staging a copy of the huge
 * article-embedding database during backup.
 */
object BackupManager {

    private const val TAG = "MV-BackupManager"
    private const val FORMAT_VERSION = 8

    private const val MANIFEST_ENTRY = "manifest.json"
    // v4 streams the requested state directly into the destination ZIP. This avoids
    // staging a second, potentially very large SQLite database in app cache.
    private const val NOTES_ENTRY = "library/notes.bin"
    private const val TOPICS_ENTRY = "library/note_topics.bin"
    private const val LINKS_ENTRY = "library/note_links.bin"
    private const val EMBEDDINGS_ENTRY = "library/note_embeddings.bin"
    private const val DS_ENTRY = "settings/settings.preferences_pb"
    private const val ANN_PREFIX = "search/ann/"

    // v3 selective-SQLite entry retained for backwards-compatible restore.
    private const val STATE_ENTRY = "library/library_state.db"

    private const val MAGIC_NOTES = 0x4D564E31 // MVN1
    private const val MAGIC_TOPICS = 0x4D565431 // MVT1
    private const val MAGIC_LINKS = 0x4D564C31 // MVL1
    private const val MAGIC_EMBEDDINGS = 0x4D564531 // MVE1
    private const val STREAM_SCHEMA_VERSION = 1
    private const val MAX_STRING_BYTES = 256 * 1024 * 1024
    private const val MAX_BLOB_BYTES = 64 * 1024 * 1024

    // Legacy v1/v2 entry names retained for old-backup restore support.
    private const val LEGACY_DB_V2_ENTRY = "database/markvault.db"
    private const val LEGACY_DB_V1_ENTRY = "markvault.db"
    private const val LEGACY_DS_ENTRY = "settings.preferences_pb"
    private const val LEGACY_LYRICS_PREFIX = "media/song_lyrics/"
    private const val LEGACY_TRANSCRIPTS_PREFIX = "media/video_transcripts/"
    private const val LEGACY_ACTIVITY_ENTRY = "optional/activity_log.jsonl"

    private const val PENDING_DIR = "restore_pending"
    private const val PENDING_DS = "settings.preferences_pb"
    private const val PENDING_MARKER = "pending_datastore_restore"
    private const val PENDING_LIBRARY_URI = "current_library_uri.txt"
    private const val NO_LIBRARY_SENTINEL = "__MARKVAULT_NO_LIBRARY__"

    private data class BackupSource(val entryName: String, val file: File)

    fun databaseFile(ctx: Context): File = ctx.getDatabasePath("markvault.db")
    private fun databaseWal(ctx: Context): File = ctx.getDatabasePath("markvault.db-wal")
    private fun databaseShm(ctx: Context): File = ctx.getDatabasePath("markvault.db-shm")

    fun datastoreFile(ctx: Context): File =
        File(ctx.filesDir, "datastore/settings.preferences_pb")

    private fun verificationStatusFile(ctx: Context) = File(ctx.cacheDir, "last_restore_verification.txt")
    fun lastVerificationStatus(ctx: Context): String? = runCatching { verificationStatusFile(ctx).readText() }.getOrNull()
    private fun recordVerificationStatus(ctx: Context, message: String) {
        runCatching { verificationStatusFile(ctx).writeText(message) }
    }

    /**
     * Apply staged settings on a cold process start. The current device's library
     * tree selection is intentionally preserved: a SAF content:// tree URI from
     * another phone is not portable and would make otherwise-restored notes
     * impossible to open.
     */
    fun applyPendingDatastoreRestore(ctx: Context) {
        val pendingRoot = File(ctx.filesDir, PENDING_DIR)
        val marker = File(pendingRoot, PENDING_MARKER)
        val staged = File(pendingRoot, PENDING_DS)
        val libraryOverride = File(pendingRoot, PENDING_LIBRARY_URI)
        if (!marker.exists()) return

        // The shared preferences file is not replaced while its Android cache
        // is live. Both settings stores are applied before any ViewModel starts.
        try {
            PortableBackupFiles.applyPendingSharedPrefs(ctx)
        } catch (e: Exception) {
            // Retain the staged restore for another cold start rather than
            // deleting un-applied settings and reporting a false success.
            Log.e(TAG, "Could not apply pending shared preferences", e)
            recordVerificationStatus(ctx, "Restore verification incomplete: shared preferences could not be applied. ${e.message.orEmpty()}")
            return
        }
        val target = datastoreFile(ctx)
        val rollback = File(target.parentFile, "${target.name}.pre_restore")
        try {
            require(staged.isFile) { "Pending DataStore restore is missing" }
            require(libraryOverride.isFile) { "Pending library-location override is missing" }
            val currentDeviceLibrary = libraryOverride.readText(Charsets.UTF_8)

            target.parentFile?.mkdirs()
            rollback.delete()
            if (target.exists()) {
                require(target.renameTo(rollback)) { "Could not create DataStore rollback copy" }
            }
            try {
                copyFileChecked(staged, target)
                require(target.isFile && target.length() == staged.length() && sha256(target) == sha256(staged)) {
                    "Restored DataStore size mismatch"
                }

                // Use the app's single DataStore delegate after the raw file is in
                // place, but before any ViewModel is created. This overwrites the
                // non-portable library_uri from the old device with the library
                // tree chosen on this device (or clears it when none is selected).
                runBlocking {
                    val prefs = Prefs(ctx.applicationContext)
                    if (currentDeviceLibrary == NO_LIBRARY_SENTINEL) {
                        prefs.clearLibraryUri()
                    } else {
                        prefs.setLibraryUri(currentDeviceLibrary)
                    }
                    val applied = prefs.libraryUri.first()
                    require(if (currentDeviceLibrary == NO_LIBRARY_SENTINEL) applied.isNullOrBlank() else applied == currentDeviceLibrary) {
                        "Restored library selection failed verification"
                    }
                }

                rollback.delete()
                staged.delete()
                libraryOverride.delete()
                marker.delete()
                pendingRoot.delete()
                recordVerificationStatus(ctx, "Restore verification complete: staged preferences applied and destination library selection checked.")
                Log.i(TAG, "Pending DataStore restore applied; current-device library URI preserved")
            } catch (e: Exception) {
                target.delete()
                if (rollback.exists()) rollback.renameTo(target)
                throw e
            }
        } catch (e: Exception) {
            Log.e(TAG, "Pending DataStore restore failed; original preferences retained", e)
            recordVerificationStatus(ctx, "Restore verification incomplete: settings could not be applied. ${e.message.orEmpty()}")
        }
    }

    data class BackupProgress(
        val stage: String,
        val completed: Long,
        val total: Long,
        val percent: Int
    )

    data class RestoreProgress(
        val stage: String,
        val completed: Long,
        val total: Long,
        val percent: Int
    )

    @Volatile
    private var lastBackupError: String? = null
    @Volatile
    private var lastRestoreError: String? = null
    @Volatile
    private var lastRestoreSummary: String? = null

    fun lastBackupErrorMessage(): String? = lastBackupError
    fun lastRestoreErrorMessage(): String? = lastRestoreError
    fun lastRestoreSummaryMessage(): String? = lastRestoreSummary

    suspend fun createBackup(
        ctx: Context,
        destUri: Uri,
        versionName: String,
        selection: Int = BackupSelection.ALL,
        onProgress: (BackupProgress) -> Unit = {}
    ): Boolean = withContext(Dispatchers.IO) {
        lastBackupError = null
        try {
            // A live model-sync worker could change vectors and ANN snapshots
            // after their database transaction snapshot. Never label that as
            // an exact transferable checkpoint.
            require(!com.tebogo.markvault.search.EmbeddingProgressBus.isRunning.value) {
                "Stop embedding synchronization before making a portable backup"
            }
            onProgress(BackupProgress("Preparing backup…", 0L, 0L, 0))
            require(BackupSelection.valid(selection)) { "Choose valid backup components" }
            val libraryUri = Prefs(ctx.applicationContext).libraryUri.first()
            val libraryTree = if (BackupSelection.has(selection, BackupSelection.FILES) && !libraryUri.isNullOrBlank()) {
                PortableBackupFiles.scanLibrary(ctx, libraryUri) { count ->
                    onProgress(BackupProgress("Scanning library metadata… ($count files found)", 0, 0, 0))
                }
            } else PortableBackupFiles.LibraryTree(emptyList(), emptyList())
            val extraAppFiles = PortableBackupFiles.appFiles(ctx).filter {
                if (it.entry.startsWith(PortableBackupFiles.PREF_PREFIX)) BackupSelection.has(selection, BackupSelection.SETTINGS)
                else BackupSelection.has(selection, BackupSelection.APP_FILES)
            }
            // A backup created inside the library tree would otherwise read its
            // own growing ZIP and fill storage. Refuse this configuration.
            val destinationId = runCatching { DocumentsContract.getDocumentId(destUri) }.getOrNull()
            require(libraryTree.files.none { item ->
                item.uri == destUri || (destinationId != null &&
                    runCatching { DocumentsContract.getDocumentId(item.uri) }.getOrNull() == destinationId)
            }) { "Save the backup outside the selected MarkVault library folder" }
            // Validate source/document identity before opening the destination
            // for writing. A failed preflight must not truncate a previous backup.
            val roomDb = VaultDb.get(ctx).openHelper.writableDatabase
            val totalNotes = if (BackupSelection.has(selection, BackupSelection.DATABASE)) queryCount(roomDb, "notes") else 0L
            require(totalNotes == 0L || libraryTree.files.isNotEmpty()) {
                "No readable article files found. Select the original library folder before making a portable backup."
            }
            // SAF providers may list two different document IDs with the
            // same visible relative path. The portable scanner assigns
            // distinct archive paths; match notes by document ID first
            // so neither note can be linked to its similarly-named peer.
            val filesById = libraryTree.files.groupBy { item ->
                DocumentsContract.getDocumentId(item.uri)
            }
            val filesByOriginalPath = libraryTree.files.groupBy { item ->
                normalizeRelPath(item.sourceRelativePath)
            }
            val sourceAuthority = libraryUri?.let { runCatching { Uri.parse(it).authority }.getOrNull() }
            fun archiveFileForNote(uri: String, relPath: String): PortableBackupFiles.LibraryFile? {
                val original = normalizeRelPath(relPath)
                val noteUri = runCatching { Uri.parse(uri) }.getOrNull()
                val sourceId = noteUri?.let {
                    runCatching { DocumentsContract.getDocumentId(it) }.getOrNull()
                }
                // A document ID is meaningful only for the same provider.
                val matchesById = if (sourceId != null && noteUri.authority == sourceAuthority)
                    filesById[sourceId].orEmpty() else emptyList()
                return matchesById.firstOrNull { normalizeRelPath(it.sourceRelativePath) == original }
                    ?: matchesById.singleOrNull()
                    ?: filesByOriginalPath[original]?.singleOrNull()
            }
            // Validate *before* serializing. If a source file cannot be
            // identified unambiguously, do not produce a valid-looking
            // backup whose restored embeddings open the wrong article.
            val portableNotePaths = HashMap<Long, String>()
            if (totalNotes > 0L) {
                var missing = 0L
                roomDb.query("SELECT id, uri, relPath FROM notes").use { cursor ->
                    while (cursor.moveToNext()) {
                        val noteId = cursor.getLong(0)
                        val file = archiveFileForNote(cursor.getString(1), cursor.getString(2))
                        if (file == null) missing++ else
                            portableNotePaths[noteId] = file.relativePath
                    }
                }
                require(missing == 0L) {
                    "$missing indexed articles could not be matched to distinct source documents. " +
                        "Portable backup stopped to protect embeddings; verify the selected library folder."
                }
            }

            val out = ctx.contentResolver.openOutputStream(destUri, "w")
                ?: throw IllegalStateException("The selected backup file could not be opened for writing")

            val checksums = JSONObject()
            val sizes = JSONObject()
            var noteCount = 0L
            var embeddingCount = 0L
            // v5.5.17 — ANN files are model-specific and live outside Room, so
            // backing up note_embeddings alone does not preserve Quick Search.
            // Only complete final snapshots are included; .tmp/.bak files are
            // deliberately excluded.
            val annFiles = if (!BackupSelection.has(selection, BackupSelection.ANN)) emptyList() else ctx.filesDir.listFiles()
                ?.filter { it.isFile && isSafeAnnFileName(it.name) }
                ?.filter { candidate ->
                    // v5.5.47: never package a broken/partially published
                    // ANN snapshot that would make an otherwise valid note-
                    // embedding backup impossible to restore. The vectors
                    // still back up and missing indexes can be rebuilt.
                    val valid = validateAnnSnapshotFile(candidate)
                    if (!valid) Log.w(TAG, "Omitting invalid ANN snapshot from backup: ${candidate.name}")
                    valid
                }
                ?.sortedBy { it.name }
                .orEmpty()

            out.buffered(256 * 1024).use { raw ->
                ZipOutputStream(raw).use { zip ->
                    // Prefer the smallest practical standard ZIP for portable backups.
                    // Level 9 is lossless and keeps the v7 archive/restore format unchanged.
                    // Compression runs only during an explicitly requested backup.
                    zip.setLevel(Deflater.BEST_COMPRESSION)

                    val totalTopics = queryCount(roomDb, "note_topics")
                    val totalLinks = queryCount(roomDb, "note_links")
                    val totalEmbeddings = queryCount(roomDb, "note_embeddings")
                    val totalRows = (totalNotes + totalTopics + totalLinks + totalEmbeddings).coerceAtLeast(1L)
                    var completedRows = 0L
                    var lastReportedPercent = -1

                    fun report(stage: String, force: Boolean = false) {
                        val pct = ((completedRows * 48L) / totalRows).toInt().coerceIn(0, 48)
                        if (force || pct != lastReportedPercent) {
                            lastReportedPercent = pct
                            onProgress(BackupProgress(stage, completedRows, totalRows, pct))
                        }
                    }

                    report("Backing up library index…", force = true)

                    // Keep one coherent database view while rows are streamed. No duplicate
                    // SQLite file is created in cache, so large embedding stores do not require
                    // a second copy's worth of free internal storage.
                    if (BackupSelection.has(selection, BackupSelection.DATABASE)) {
                    roomDb.beginTransaction()
                    try {
                        val notesStats = writeProtectedEntry(zip, NOTES_ENTRY) { output ->
                            val data = DataOutputStream(output)
                            noteCount = totalNotes
                            data.writeInt(MAGIC_NOTES)
                            data.writeInt(STREAM_SCHEMA_VERSION)
                            data.writeLong(noteCount)
                            roomDb.query(
                                "SELECT id, uri, relPath, name, title, folder, content, lastModified, size, fileType " +
                                    "FROM notes ORDER BY id"
                            ).use { c ->
                                while (c.moveToNext()) {
                                    data.writeLong(c.getLong(0))
                                    writeString(data, c.getString(1))
                                    val sourcePath = c.getString(2)
                                    val backupPath = portableNotePaths[c.getLong(0)]
                                        ?: error("Missing portable path for indexed note ${c.getLong(0)}")
                                    val renamed = backupPath != normalizeRelPath(sourcePath)
                                    writeString(data, backupPath)
                                    writeString(data, if (renamed) backupPath.substringAfterLast('/') else c.getString(3))
                                    writeString(data, c.getString(4))
                                    writeString(data, if (renamed) backupPath.substringBeforeLast('/', "") else c.getString(5))
                                    writeString(data, c.getString(6))
                                    data.writeLong(c.getLong(7))
                                    data.writeLong(c.getLong(8))
                                    writeString(data, c.getString(9))
                                    completedRows++
                                    if (completedRows % 128L == 0L) report("Backing up library index…")
                                }
                            }
                            data.flush()
                        }
                        checksums.put(NOTES_ENTRY, notesStats.sha256)
                        sizes.put(NOTES_ENTRY, notesStats.size)

                        val topicsStats = writeProtectedEntry(zip, TOPICS_ENTRY) { output ->
                            val data = DataOutputStream(output)
                            val count = totalTopics
                            data.writeInt(MAGIC_TOPICS)
                            data.writeInt(STREAM_SCHEMA_VERSION)
                            data.writeLong(count)
                            roomDb.query("SELECT noteId, topic, score FROM note_topics ORDER BY noteId, topic").use { c ->
                                while (c.moveToNext()) {
                                    data.writeLong(c.getLong(0))
                                    writeString(data, c.getString(1))
                                    data.writeInt(c.getInt(2))
                                    completedRows++
                                    if (completedRows % 256L == 0L) report("Backing up library index…")
                                }
                            }
                            data.flush()
                        }
                        checksums.put(TOPICS_ENTRY, topicsStats.sha256)
                        sizes.put(TOPICS_ENTRY, topicsStats.size)

                        val linksStats = writeProtectedEntry(zip, LINKS_ENTRY) { output ->
                            val data = DataOutputStream(output)
                            val count = totalLinks
                            data.writeInt(MAGIC_LINKS)
                            data.writeInt(STREAM_SCHEMA_VERSION)
                            data.writeLong(count)
                            roomDb.query("SELECT fromId, target, targetNorm FROM note_links ORDER BY fromId, targetNorm").use { c ->
                                while (c.moveToNext()) {
                                    data.writeLong(c.getLong(0))
                                    writeString(data, c.getString(1))
                                    writeString(data, c.getString(2))
                                    completedRows++
                                    if (completedRows % 256L == 0L) report("Backing up library index…")
                                }
                            }
                            data.flush()
                        }
                        checksums.put(LINKS_ENTRY, linksStats.sha256)
                        sizes.put(LINKS_ENTRY, linksStats.size)

                        report("Backing up semantic embeddings…", force = true)
                        val embeddingsStats = writeProtectedEntry(zip, EMBEDDINGS_ENTRY) { output ->
                            val data = DataOutputStream(output)
                            embeddingCount = totalEmbeddings
                            data.writeInt(MAGIC_EMBEDDINGS)
                            data.writeInt(STREAM_SCHEMA_VERSION)
                            data.writeLong(embeddingCount)
                            roomDb.query(
                                "SELECT noteId, modelVersion, chunkIndex, dim, vector, sourceLastModified, createdAt " +
                                    "FROM note_embeddings ORDER BY noteId, modelVersion, chunkIndex"
                            ).use { c ->
                                while (c.moveToNext()) {
                                    data.writeLong(c.getLong(0))
                                    writeString(data, c.getString(1))
                                    data.writeInt(c.getInt(2))
                                    data.writeInt(c.getInt(3))
                                    writeByteArray(data, c.getBlob(4))
                                    data.writeLong(c.getLong(5))
                                    data.writeLong(c.getLong(6))
                                    completedRows++
                                    if (completedRows % 64L == 0L) report("Backing up semantic embeddings…")
                                }
                            }
                            data.flush()
                        }
                        checksums.put(EMBEDDINGS_ENTRY, embeddingsStats.sha256)
                        sizes.put(EMBEDDINGS_ENTRY, embeddingsStats.size)

                        report("Backing up additional database tables…", force = true)
                        val extra = writeProtectedEntry(zip, PortableBackupState.EXTRA_ENTRY) { output ->
                            PortableBackupState.writeExtras(roomDb, output)
                        }
                        checksums.put(PortableBackupState.EXTRA_ENTRY, extra.sha256)
                        sizes.put(PortableBackupState.EXTRA_ENTRY, extra.size)
                        report("Backing up note preferences…", force = true)
                        val ui = writeProtectedEntry(zip, PortableBackupState.UI_ENTRY) { output ->
                            PortableBackupState.writeNoteUi(roomDb, output)
                        }
                        checksums.put(PortableBackupState.UI_ENTRY, ui.sha256)
                        sizes.put(PortableBackupState.UI_ENTRY, ui.size)
                        roomDb.setTransactionSuccessful()
                    } finally {
                        roomDb.endTransaction()
                    }

                    }
                    completedRows = totalRows
                    if (BackupSelection.has(selection, BackupSelection.SETTINGS)) {
                    onProgress(BackupProgress("Backing up settings…", 0, 1, 49))
                    val dsStats = writeProtectedEntry(zip, DS_ENTRY) { output ->
                        val dsLive = datastoreFile(ctx)
                        if (dsLive.isFile) FileInputStream(dsLive).use { it.copyTo(output) }
                    }
                    checksums.put(DS_ENTRY, dsStats.sha256)
                    sizes.put(DS_ENTRY, dsStats.size)
                    }

                    val buffer = ByteArray(128 * 1024)
                    fun stage(label: String, start: Int, end: Int, count: Int, bytes: Long) =
                        BackupZipIO.Stage(label, start, end, count.toLong(), bytes) { name, done, total, pct ->
                            onProgress(BackupProgress(name, done, total, pct))
                        }
                    val ann = stage("Backing up ANN indexes…", 50, 57, annFiles.size, annFiles.sumOf { it.length() })
                    ann.report(true)
                    for (annFile in annFiles) {
                        require(isSafeAnnFileName(annFile.name)) { "Unsafe ANN index filename" }
                        val entryName = ANN_PREFIX + annFile.name
                        val stats = writeProtectedEntry(zip, entryName) { output ->
                            FileInputStream(annFile).use { BackupZipIO.copy(it, output, buffer, ann::bytes) }
                        }
                        checksums.put(entryName, stats.sha256)
                        sizes.put(entryName, stats.size)
                        ann.item()
                    }
                    ann.report(true)

                    val library = stage("Backing up library files…", 57, 82, libraryTree.files.size,
                        if (libraryTree.files.all { it.size >= 0 }) libraryTree.files.sumOf { it.size } else 0L)
                    library.report(true)
                    if (BackupSelection.has(selection, BackupSelection.FILES)) {
                    val dirs = writeProtectedEntry(zip, PortableBackupFiles.DIRECTORIES_ENTRY) { output ->
                        output.write(PortableBackupFiles.directoryBytes(libraryTree))
                    }
                    checksums.put(PortableBackupFiles.DIRECTORIES_ENTRY, dirs.sha256)
                    sizes.put(PortableBackupFiles.DIRECTORIES_ENTRY, dirs.size)
                    for (item in libraryTree.files) {
                        val entry = PortableBackupFiles.LIBRARY_PREFIX + item.relativePath
                        val stats = writeProtectedEntry(zip, entry) { output ->
                            ctx.contentResolver.openInputStream(item.uri)?.use { input ->
                                BackupZipIO.copy(input, output, buffer, library::bytes)
                            } ?: error("Cannot read library file ${item.relativePath}")
                        }
                        checksums.put(entry, stats.sha256)
                        sizes.put(entry, stats.size)
                        library.item()
                    }
                    }
                    library.report(true)
                    val app = stage("Backing up models, saved results and settings…", 82, 91, extraAppFiles.size,
                        extraAppFiles.sumOf { it.file.length() })
                    app.report(true)
                    for (item in extraAppFiles) {
                        val stats = writeProtectedEntry(zip, item.entry) { output ->
                            FileInputStream(item.file).use { BackupZipIO.copy(it, output, buffer, app::bytes) }
                        }
                        checksums.put(item.entry, stats.sha256)
                        sizes.put(item.entry, stats.size)
                        app.item()
                    }
                    app.report(true)
                    onProgress(BackupProgress("Writing backup manifest and ZIP directory…", 0, 0, 92))

                    val manifest = JSONObject().apply {
                        put("app", "MarkVault")
                        put("format_version", if (selection == BackupSelection.ALL) 7 else FORMAT_VERSION)
                        if (selection != BackupSelection.ALL) put("components", selection)
                        put("stream_schema_version", STREAM_SCHEMA_VERSION)
                        put("version", versionName)
                        put("timestamp", System.currentTimeMillis())
                        put("scope", if (selection == BackupSelection.ALL) "portable_library+all_database_tables+all_model_embeddings+ann_indexes+settings+model_assets" else "selected_components")
                        put("database_schema", 24)
                        put("library_files", libraryTree.files.size)
                        put("library_files_disambiguated", libraryTree.files.count {
                            it.sourceRelativePath != it.relativePath
                        })
                        put("app_files", extraAppFiles.size)
                        put("ann_indexes", annFiles.size)
                        put("notes", noteCount)
                        put("embeddings", embeddingCount)
                        put("checksums", checksums)
                        put("sizes", sizes)
                    }.toString()

                    onProgress(BackupProgress("Finalizing backup ZIP…", 0, 0, 93))
                    zip.putNextEntry(ZipEntry(MANIFEST_ENTRY))
                    zip.write(manifest.toByteArray(Charsets.UTF_8))
                    zip.closeEntry()
                }
            }

            val verifyTotal = checksums.length().toLong() + 1L
            val verificationBytes = sumEntrySizes(sizes)
            onProgress(BackupProgress("Verifying backup integrity…", 0, verifyTotal, 94))
            require(validateV4Archive(ctx, destUri) { checked, bytes ->
                val pct = if (verificationBytes > 0) BackupZipIO.percent(94, 99, bytes, verificationBytes)
                    else BackupZipIO.percent(94, 99, checked.toLong(), verifyTotal)
                onProgress(BackupProgress("Verifying backup integrity… (${bytes / 1048576} MiB checked)",
                    checked.toLong(), verifyTotal, pct))
            } != null) {
                "The written backup could not be read back and verified"
            }
            onProgress(BackupProgress("Backup complete", 1L, 1L, 100))
            Log.i(TAG, "Portable backup v7 written and verified: library files, all Room data, embeddings, models, settings, ANN")
            true
        } catch (e: Exception) {
            lastBackupError = e.message?.takeIf { it.isNotBlank() } ?: e.javaClass.simpleName
            Log.e(TAG, "createBackup failed", e)
            false
        }
    }

    /**
     * A metadata-only preview of an existing v4–v7 ZIP. Android's document
     * provider can expose a seekable descriptor even though it does not expose
     * a regular filesystem path. ZipFile reads the central directory through
     * that descriptor: no library articles, models, or embedding vectors are
     * inflated merely to display the confirmation dialog.
     *
     * Some cloud providers return a non-seekable pipe. In that case the caller
     * falls back to the prior streaming validator. We deliberately do NOT
     * trust this preview for restore: applyBackup still verifies the complete
     * SHA-256 manifest before altering any live data.
     */
    /** Complete backups remain v7; v8 declares selected groups. */
    fun availableComponents(manifest: JSONObject): Int =
        if (manifest.optInt("format_version", 1) >= 8) manifest.optInt("components", 0) else BackupSelection.ALL

    private fun validPartialEntries(manifest: JSONObject, names: Set<String>): Boolean {
        val mask = availableComponents(manifest)
        if (!BackupSelection.valid(mask) || manifest.optInt("database_schema", -1) != 24) return false
        val db = setOf(NOTES_ENTRY, TOPICS_ENTRY, LINKS_ENTRY, EMBEDDINGS_ENTRY,
            PortableBackupState.EXTRA_ENTRY, PortableBackupState.UI_ENTRY)
        val required = mutableSetOf<String>()
        if (BackupSelection.has(mask, BackupSelection.DATABASE)) required.addAll(db)
        if (BackupSelection.has(mask, BackupSelection.SETTINGS)) required.add(DS_ENTRY)
        if (BackupSelection.has(mask, BackupSelection.FILES)) required.add(PortableBackupFiles.DIRECTORIES_ENTRY)
        if (!names.containsAll(required)) return false
        return names.all { name -> name in required ||
            (BackupSelection.has(mask, BackupSelection.FILES) && name.startsWith(PortableBackupFiles.LIBRARY_PREFIX)) ||
            (BackupSelection.has(mask, BackupSelection.ANN) && name.startsWith(ANN_PREFIX)) ||
            (BackupSelection.has(mask, BackupSelection.SETTINGS) && name.startsWith(PortableBackupFiles.PREF_PREFIX)) ||
            (BackupSelection.has(mask, BackupSelection.APP_FILES) && name.startsWith(PortableBackupFiles.APP_PREFIX)) }
    }

    private fun readSeekableManifestPreview(ctx: Context, srcUri: Uri): JSONObject? =
        try {
            ctx.contentResolver.openFileDescriptor(srcUri, "r")?.use { descriptor ->
                ZipFile(File("/proc/self/fd/${descriptor.fd}")).use zipUse@{ zip ->
                    val meta = zip.getEntry(MANIFEST_ENTRY) ?: return@zipUse null
                    require(meta.size in 1L..(64L * 1024L * 1024L)) {
                        "Invalid backup manifest length"
                    }
                    val bytes = zip.getInputStream(meta).use { input ->
                        val out = ByteArrayOutputStream()
                        val buffer = ByteArray(16 * 1024)
                        var count = 0L
                        while (true) {
                            val read = input.read(buffer)
                            if (read < 0) break
                            count += read
                            require(count <= 64L * 1024L * 1024L) { "Backup manifest is too large" }
                            out.write(buffer, 0, read)
                        }
                        out.toByteArray()
                    }
                    val manifest = JSONObject(bytes.toString(Charsets.UTF_8))
                    require(manifest.optString("app") == "MarkVault" &&
                        manifest.optInt("format_version", 0) in 4..FORMAT_VERSION &&
                        manifest.optInt("stream_schema_version", 0) == STREAM_SCHEMA_VERSION) {
                        "Incompatible MarkVault backup"
                    }
                    val checksums = manifest.optJSONObject("checksums")
                        ?: error("Missing backup checksums")
                    val sizes = manifest.optJSONObject("sizes")
                        ?: error("Missing backup sizes")
                    val entries = linkedMapOf<String, Long>()
                    val iterator = zip.entries()
                    while (iterator.hasMoreElements()) {
                        val entry = iterator.nextElement()
                        require(!entry.isDirectory && isAllowedV4Entry(entry.name)) {
                            "Unexpected backup entry: ${entry.name}"
                        }
                        require(entries.put(entry.name, entry.size) == null) {
                            "Duplicate backup entry: ${entry.name}"
                        }
                    }
                    require(entries.containsKey(MANIFEST_ENTRY)) { "Missing manifest" }
                    val dataEntries = entries.filterKeys { it != MANIFEST_ENTRY }
                    require(checksums.length() == dataEntries.size && sizes.length() == dataEntries.size) {
                        "Incomplete backup manifest"
                    }
                    val expected = setOf(NOTES_ENTRY, TOPICS_ENTRY, LINKS_ENTRY, EMBEDDINGS_ENTRY, DS_ENTRY)
                    val archiveVersion = manifest.optInt("format_version", 0)
                    if (archiveVersion >= 8) require(validPartialEntries(manifest, dataEntries.keys)) { "Invalid selected backup components" }
                    else require(dataEntries.keys.containsAll(expected)) { "Missing required backup streams" }
                    if (archiveVersion == 7) {
                        require(manifest.optInt("database_schema", -1) == 24 &&
                            dataEntries.containsKey(PortableBackupState.EXTRA_ENTRY) &&
                            dataEntries.containsKey(PortableBackupState.UI_ENTRY) &&
                            dataEntries.containsKey(PortableBackupFiles.DIRECTORIES_ENTRY)) {
                            "Incomplete portable backup"
                        }
                    }
                    if (archiveVersion >= 5) {
                        require(manifest.optInt("ann_indexes", -1) ==
                            dataEntries.keys.count { it.startsWith(ANN_PREFIX) }) {
                            "ANN index list mismatch"
                        }
                    }
                    val sha256Pattern = Regex("[A-Fa-f0-9]{64}")
                    for ((name, size) in dataEntries) {
                        require(size >= 0L && sizes.optLong(name, -1L) == size &&
                            checksums.optString(name).matches(sha256Pattern)) {
                            "Backup manifest mismatch: $name"
                        }
                    }
                    manifest
                }
            }
        } catch (e: Exception) {
            Log.w(TAG, "Seekable preview unavailable; trying streaming backup detection", e)
            null
        }

    /** Return a safe preview; full checksum validation occurs after confirmation. */
    suspend fun readManifest(ctx: Context, srcUri: Uri): JSONObject? =
        withContext(Dispatchers.IO) {
            // Fast for local Downloads/document providers supporting random access.
            readSeekableManifestPreview(ctx, srcUri)?.let { return@withContext it }
            try {
                // For non-seekable providers, retain the old full verification
                // instead of weakening integrity checks or rejecting old ZIPs.
                validateV4Archive(ctx, srcUri)?.let { return@withContext it }

                var manifest: JSONObject? = null
                var hasState = false
                var hasLegacyDb = false
                var hasDs = false
                ctx.contentResolver.openInputStream(srcUri)?.buffered()?.use { raw ->
                    ZipInputStream(raw).use { zip ->
                        var entry = zip.nextEntry
                        while (entry != null) {
                            when (entry.name) {
                                MANIFEST_ENTRY -> manifest = JSONObject(zip.readBytes().toString(Charsets.UTF_8))
                                STATE_ENTRY -> hasState = true
                                LEGACY_DB_V2_ENTRY, LEGACY_DB_V1_ENTRY -> hasLegacyDb = true
                                DS_ENTRY, LEGACY_DS_ENTRY -> hasDs = true
                            }
                            zip.closeEntry()
                            entry = zip.nextEntry
                        }
                    }
                } ?: return@withContext null

                val json = manifest ?: return@withContext null
                if (json.optString("app") != "MarkVault" || !hasDs) return@withContext null
                val version = json.optInt("format_version", 1)
                if (version >= 4) return@withContext null // v4+ needs the full streaming validator above
                if (version >= 3 && !hasState) return@withContext null
                if (version < 3 && !hasLegacyDb) return@withContext null
                json
            } catch (e: Exception) {
                Log.e(TAG, "readManifest failed", e)
                null
            }
        }

    suspend fun applyBackup(
        ctx: Context,
        srcUri: Uri,
        selection: Int = BackupSelection.ALL,
        onProgress: (RestoreProgress) -> Unit = {}
    ): Boolean = withContext(Dispatchers.IO) {
        lastRestoreError = null
        lastRestoreSummary = null
        runCatching { verificationStatusFile(ctx).delete() }
        val staging = File(ctx.cacheDir, "restore_staging_${System.nanoTime()}")
        try {
            require(!com.tebogo.markvault.search.EmbeddingProgressBus.isRunning.value) {
                "Stop embedding synchronization before restoring a portable backup"
            }
            onProgress(RestoreProgress("Validating backup…", 0L, 0L, 2))
            staging.mkdirs()
            val currentLibraryUri = runCatching { Prefs(ctx.applicationContext).libraryUri.first() }.getOrNull()
            var streamVerified: JSONObject? = null
            val manifest = readSeekableManifestPreview(ctx, srcUri)
                ?: validateV4Archive(ctx, srcUri) { checked, bytes ->
                    onProgress(RestoreProgress("Validating non-seekable backup (${bytes / 1048576} MiB checked)…", checked.toLong(), 0L, 8))
                }?.also { streamVerified = it }
                ?: extractRecognisedEntries(ctx, srcUri, staging)
                ?: throw IllegalArgumentException("Backup is missing a valid manifest")
            val formatVersion = manifest.optInt("format_version", 1)
            val selected = if (formatVersion < 7) BackupSelection.ALL else selection
            require(BackupSelection.valid(selected) && (selected and availableComponents(manifest)) == selected) {
                "Selected restore components are not present or depend on an unselected component"
            }
            fun chosen(group: Int) = BackupSelection.has(selected, group)

            if (formatVersion >= 4) {
                onProgress(RestoreProgress("Verifying backup integrity…", 0L, 0L, 8))
                val totalEntries = (manifest.optJSONObject("checksums")?.length() ?: 0).toLong() + 1L
                val totalBytes = manifest.optJSONObject("sizes")?.let { sumEntrySizes(it) } ?: 0L
                val verified = streamVerified ?: validateV4Archive(ctx, srcUri) { checked, bytes ->
                    val pct = if (totalBytes > 0) BackupZipIO.percent(8, 22, bytes, totalBytes)
                        else BackupZipIO.percent(8, 22, checked.toLong(), totalEntries)
                    onProgress(RestoreProgress("Verifying backup integrity… (${bytes / 1048576} MiB checked)", checked.toLong(), totalEntries, pct))
                } ?: throw IllegalArgumentException("Backup integrity validation failed")
                if (formatVersion >= 7 && chosen(BackupSelection.DATABASE)) {
                    onProgress(RestoreProgress("Checking database compatibility before copying files…", 0, 0, 22))
                    val current = VaultDb.get(ctx).openHelper.writableDatabase
                    var checkedSchema = false
                    BackupZipIO.visitVerified(ctx, srcUri, { verified.optJSONObject("checksums")!!.getString(it) },
                        { it.name == PortableBackupState.EXTRA_ENTRY }) { _, stream ->
                        PortableBackupState.validateExtrasSchema(current, stream.buffered(128 * 1024)) { table, done, total ->
                            onProgress(RestoreProgress("Checking schema: $table…", done, total, 22))
                        }
                        checkedSchema = true
                    }
                    require(checkedSchema) { "Missing database compatibility stream" }
                }
                val streamedDs = File(staging, PENDING_DS)
                onProgress(RestoreProgress("Preparing settings…", 0L, 0L, 23))
                if (chosen(BackupSelection.SETTINGS)) {
                    extractV4Settings(ctx, srcUri, streamedDs, verified)
                    stageDatastoreForNextStart(ctx, streamedDs, currentLibraryUri)
                }

                var restoredLibrary: PortableBackupFiles.LibraryRestoreResult? = null
                if (formatVersion >= 7) {
                    require(verified.optInt("database_schema", -1) == 24) { "Incompatible backup database schema" }
                    // The source archive can contain several GB of downloaded
                    // models. Restoring them currently stages verified copies
                    // before installation; refuse early if that cannot fit.
                    val sizeTable = verified.optJSONObject("sizes")
                        ?: error("Portable backup sizes are missing")
                    val iterator = sizeTable.keys()
                    var appBytes = 0L
                    val appEntriesToRestore = HashSet<String>()
                    val appHashes = verified.optJSONObject("checksums") ?: error("Missing verified checksums")
                    onProgress(RestoreProgress("Checking already restored app files…", 0, 0, 24))
                    while (iterator.hasNext()) {
                        val name = iterator.next()
                        if ((chosen(BackupSelection.APP_FILES) && name.startsWith(PortableBackupFiles.APP_PREFIX)) ||
                            (chosen(BackupSelection.SETTINGS) && name.startsWith(PortableBackupFiles.PREF_PREFIX))) {
                            val size = sizeTable.optLong(name, -1)
                            require(size >= 0 && Long.MAX_VALUE - appBytes >= size) {
                                "Invalid app file size in backup"
                            }
                            val existing = if (name.startsWith(PortableBackupFiles.APP_PREFIX)) {
                                val rel = name.removePrefix(PortableBackupFiles.APP_PREFIX)
                                require(PortableBackupFiles.safeRel(rel)) { "Unsafe app file path" }
                                File(ctx.filesDir, rel)
                            } else null
                            if (existing != null && existing.isFile && existing.length() == size &&
                                sha256(existing).equals(appHashes.getString(name), true)) continue
                            appEntriesToRestore.add(name)
                            appBytes += size
                        }
                    }
                    require(appBytes < (ctx.cacheDir.usableSpace - 32L * 1024 * 1024).coerceAtLeast(0L) / 2L) {
                        "Not enough internal storage to safely stage and install restored model files"
                    }
                    if (chosen(BackupSelection.FILES)) {
                        require(!currentLibraryUri.isNullOrBlank()) {
                            "Select a writable library folder on this phone before restoring"
                        }
                        onProgress(RestoreProgress("Preparing original library files…", 0, 0, 24))
                        val checksums = verified.optJSONObject("checksums") ?: error("Missing verified checksums")
                        val libraryHashes = LinkedHashMap<String, String>()
                        val keys = checksums.keys()
                        while (keys.hasNext()) {
                            val entry = keys.next()
                            if (entry.startsWith(PortableBackupFiles.LIBRARY_PREFIX)) {
                                libraryHashes[entry.removePrefix(PortableBackupFiles.LIBRARY_PREFIX)] = checksums.getString(entry)
                            }
                        }
                        restoredLibrary = PortableBackupFiles.restoreLibrary(ctx, srcUri, currentLibraryUri, libraryHashes,
                            directoryHash = checksums.getString(PortableBackupFiles.DIRECTORIES_ENTRY),
                            onActivity = { label, done, total ->
                                onProgress(RestoreProgress(label, done, total, BackupZipIO.percent(24, 48, done, total)))
                            }, keepCompletedOnFailure = true) { done, total ->
                            onProgress(RestoreProgress("Restoring original library files…", done, total, BackupZipIO.percent(24, 48, done, total)))
                        }
                    }
                    onProgress(RestoreProgress("Preparing portable app data…", 0, 0, 48))
                    PortableBackupFiles.restoreAppFiles(ctx, srcUri, staging, { name -> verified.optJSONObject("checksums")!!.getString(name) },
                        include = { name -> name in appEntriesToRestore }) { bytes ->
                        onProgress(RestoreProgress("Staging models and app files (MiB)…", bytes / 1048576, appBytes / 1048576,
                            BackupZipIO.percent(48, 53, bytes, appBytes)))
                    }
                }

                onProgress(RestoreProgress("Scanning destination library metadata…", 0, 0, 53))
                val scannedLibrary = if (chosen(BackupSelection.DATABASE) && !currentLibraryUri.isNullOrBlank()) {
                    runCatching {
                        scanCurrentLibrary(ctx, currentLibraryUri) { done, total ->
                            val pct = BackupZipIO.percent(53, 56, done, total)
                            val label = if (total == 0L) "Scanning destination library… ($done files found)" else "Matching current-device library files…"
                            onProgress(RestoreProgress(label, done, total, pct))
                        }
                    }.getOrElse { error ->
                        Log.w(TAG, "Current library could not be scanned for portable URI remap", error)
                        emptyMap()
                    }
                } else emptyMap()
                // Use the exact verified document ID, not the original path (which
                // may identify a different destination file with the same name).
                val libraryFiles = restoredLibrary?.takeIf { chosen(BackupSelection.DATABASE) }?.let { restored ->
                    val byId = scannedLibrary.values.associateBy { DocumentsContract.getDocumentId(Uri.parse(it.uri)) }
                    restored.documentIds.mapValues { (archivePath, documentId) ->
                        byId[documentId] ?: error("Restored document cannot be found: $archivePath")
                    }
                } ?: scannedLibrary

                // A newly installed phone may have no on-disk Room database yet.
                // Create/migrate it using the normal schema before closing its
                // connection for the streamed portable restore.
                if (chosen(BackupSelection.DATABASE)) {
                    VaultDb.get(ctx).openHelper.writableDatabase
                    VaultDb.closeForRestore()
                }
                return@withContext try {
                    val remap = if (chosen(BackupSelection.DATABASE)) restoreDatabaseWithCheckpoint(
                        ctx = ctx,
                        srcUri = srcUri,
                        manifest = verified,
                        libraryFiles = libraryFiles,
                        onProgress = { p -> onProgress(p.copy(percent = 56 + ((p.percent - 32).coerceIn(0, 66) * 39 / 66))) }
                    ) else RestoreRemapResult(0, 0)
                    if (formatVersion >= 5 && chosen(BackupSelection.ANN)) {
                        onProgress(RestoreProgress("Restoring ANN indexes…", 0L, 0L, 96))
                        restoreAnnIndexes(ctx, srcUri, verified) { name, done, total, percent ->
                            onProgress(RestoreProgress(name, done, total, percent))
                        }
                    } else if (chosen(BackupSelection.DATABASE)) {
                        // v4 had no ANN payload. Remove stale indexes that may refer
                        // to the pre-restore embedding set; Quick Search will rebuild
                        // them safely from the restored embeddings when needed.
                        clearFinalAnnIndexes(ctx)
                    }
                    if (formatVersion >= 7) {
                        onProgress(RestoreProgress("Installing models and app files…", 0, 0, 98))
                        PortableBackupFiles.installAppFiles(ctx, staging) { done, total ->
                            onProgress(RestoreProgress("Installing models and app files (MiB)…", done / 1048576, total / 1048576, BackupZipIO.percent(98, 99, done, total)))
                        }
                    }
                    onProgress(RestoreProgress("Final verification of restored components…", 0, 0, 99))
                    if (chosen(BackupSelection.DATABASE)) require(quickCheckSqlite(databaseFile(ctx))) { "Final SQLite verification failed" }
                    if (chosen(BackupSelection.SETTINGS)) {
                        val pending = File(ctx.filesDir, PENDING_DIR)
                        require(File(pending, PENDING_MARKER).isFile && File(pending, PENDING_DS).isFile &&
                            sha256(File(pending, PENDING_DS)).equals(verified.optJSONObject("checksums")!!.getString(DS_ENTRY), true)) {
                            "Staged settings failed final verification"
                        }
                    }
                    lastRestoreSummary = when {
                        formatVersion >= 7 && selected != BackupSelection.ALL ->
                            "Selected components restored and checked: " + BackupSelection.choices.filter { chosen(it.first) }.joinToString { it.second } + ". Restarting to finish applying any selected preferences."
                        formatVersion >= 7 ->
                            "Portable restore completed. Library files, all Room records and embeddings, model assets, ANN snapshots and settings restored. " +
                                (restoredLibrary?.conflicts ?: 0).let { count ->
                                    if (count > 0) "$count conflicting files preserved as separate MarkVault restored copies (Obsidian conflicts in .markvault-restore-conflicts); existing files were not overwritten. " else ""
                                } + (restoredLibrary?.providerRenames ?: 0).let { count ->
                                    if (count > 0) "$count destination filenames or folders adjusted; article links use the actual restored document IDs. " else ""
                                } + "Restarting to apply preferences."
                        currentLibraryUri.isNullOrBlank() ->
                            "Restore complete. Settings, index, all-model embeddings and ANN indexes were restored. Select/copy your library folder to reconnect article files."
                        remap.totalNotes == 0L -> "Restore complete and verified."
                        remap.matchedNotes == remap.totalNotes ->
                            "Restore complete. ${remap.matchedNotes} / ${remap.totalNotes} article files reconnected to this device."
                        else ->
                            "Restore complete. ${remap.matchedNotes} / ${remap.totalNotes} article files reconnected; ${remap.totalNotes - remap.matchedNotes} could not be matched by relative path and size."
                    }
                    recordVerificationStatus(ctx, if (chosen(BackupSelection.SETTINGS))
                        "Selected data verified; settings application will be checked at the next app start."
                        else "Restore verification complete: selected data checked; settings left unchanged.")
                    onProgress(RestoreProgress("Restore complete", remap.totalNotes, remap.totalNotes, 100))
                    Log.i(TAG, "Streaming v4 restore installed; settings apply on next cold start")
                    true
                } catch (e: Exception) {
                    File(ctx.filesDir, PENDING_DIR).deleteRecursively()
                    runCatching { VaultDb.get(ctx).openHelper.writableDatabase }
                    throw e
                }
            }

            val stagedDs = firstExisting(File(staging, DS_ENTRY), File(staging, LEGACY_DS_ENTRY))
                ?: throw IllegalArgumentException("Backup settings are missing")
            require(stagedDs.isFile) { "Backup settings are missing" }
            stageDatastoreForNextStart(ctx, stagedDs, currentLibraryUri)

            if (formatVersion >= 3) {
                onProgress(RestoreProgress("Verifying legacy library state…", 0L, 0L, 25))
                verifyManifestProtectedEntries(manifest, staging, requireSelectiveState = true)
                val stagedState = File(staging, STATE_ENTRY)
                require(stagedState.isFile && stagedState.length() > 0L) { "Library state is missing" }
                require(quickCheckSqlite(stagedState)) { "Library state failed SQLite quick_check" }
                validateSelectiveState(stagedState)

                VaultDb.closeForRestore()
                return@withContext try {
                    onProgress(RestoreProgress("Restoring library state…", 0L, 0L, 55))
                    applySelectiveLibraryState(ctx, stagedState)
                    // v3 predates per-model ANN backup. Any live ANN snapshot
                    // belongs to the pre-restore embeddings and is unsafe to reuse.
                    clearFinalAnnIndexes(ctx)
                    onProgress(RestoreProgress("Verifying restored data…", 0L, 0L, 98))
                    lastRestoreSummary = "Legacy restore complete and verified. Current-device library selection was preserved."
                    onProgress(RestoreProgress("Restore complete", 1L, 1L, 100))
                    true
                } catch (e: Exception) {
                    File(ctx.filesDir, PENDING_DIR).deleteRecursively()
                    runCatching { VaultDb.get(ctx).openHelper.writableDatabase }
                    throw e
                }
            }

            // Legacy v1/v2 compatibility: those archives only contain a whole Room DB.
            val stagedDb = firstExisting(
                File(staging, LEGACY_DB_V2_ENTRY),
                File(staging, LEGACY_DB_V1_ENTRY)
            ) ?: throw IllegalArgumentException("Backup database is missing")
            require(stagedDb.length() > 0L && quickCheckSqlite(stagedDb)) {
                "Legacy backup database failed validation"
            }
            if (formatVersion >= 2) {
                verifyManifestProtectedEntries(manifest, staging, requireSelectiveState = false)
            }
            onProgress(RestoreProgress("Installing legacy database…", 0L, 0L, 65))
            val ok = installLegacyWholeDatabase(ctx, stagedDb)
            if (!ok) File(ctx.filesDir, PENDING_DIR).deleteRecursively()
            if (ok) {
                // v1/v2 archives also have no ANN payload. Never leave a stale
                // index pointing at a different restored embedding database.
                clearFinalAnnIndexes(ctx)
                lastRestoreSummary = "Legacy restore complete. Current-device library selection was preserved."
                onProgress(RestoreProgress("Restore complete", 1L, 1L, 100))
            }
            ok
        } catch (e: Exception) {
            lastRestoreError = e.message?.takeIf { it.isNotBlank() } ?: e.javaClass.simpleName
            Log.e(TAG, "applyBackup failed", e)
            recordVerificationStatus(ctx, "Restore not complete: ${lastRestoreError.orEmpty()}. Retry the same ZIP to reuse verified files.")
            File(ctx.filesDir, PENDING_DIR).deleteRecursively()
            false
        } finally {
            staging.deleteRecursively()
        }
    }

    private fun stageDatastoreForNextStart(
        ctx: Context,
        stagedDs: File,
        currentLibraryUri: String?
    ) {
        val pendingRoot = File(ctx.filesDir, PENDING_DIR).apply { mkdirs() }
        val pendingDs = File(pendingRoot, PENDING_DS)
        val pendingMarker = File(pendingRoot, PENDING_MARKER)
        val libraryOverride = File(pendingRoot, PENDING_LIBRARY_URI)
        pendingDs.delete()
        copyFileChecked(stagedDs, pendingDs)
        require(pendingDs.length() == stagedDs.length()) { "Could not stage restored settings" }
        libraryOverride.writeText(currentLibraryUri ?: NO_LIBRARY_SENTINEL, Charsets.UTF_8)
        pendingMarker.writeText("ready", Charsets.UTF_8)
    }

    private data class EntryStats(val sha256: String, val size: Long)

    private class HashingEntryOutputStream(
        private val delegate: OutputStream,
        private val digest: MessageDigest = MessageDigest.getInstance("SHA-256")
    ) : OutputStream() {
        var count: Long = 0L
            private set

        override fun write(b: Int) {
            delegate.write(b)
            digest.update(b.toByte())
            count++
        }

        override fun write(b: ByteArray, off: Int, len: Int) {
            delegate.write(b, off, len)
            digest.update(b, off, len)
            count += len.toLong()
        }

        override fun flush() = delegate.flush()

        fun finish(): EntryStats = EntryStats(
            BackupZipIO.hex(digest.digest()),
            count
        )
    }

    private inline fun writeProtectedEntry(
        zip: ZipOutputStream,
        name: String,
        writer: (OutputStream) -> Unit
    ): EntryStats {
        zip.putNextEntry(ZipEntry(name))
        val hashing = HashingEntryOutputStream(zip)
        // DataOutputStream emits many tiny writes per database row. Coalesce them
        // before invoking native DEFLATE and SHA-256, without changing any bytes.
        if (name == NOTES_ENTRY || name == TOPICS_ENTRY || name == LINKS_ENTRY || name == EMBEDDINGS_ENTRY ||
            name == PortableBackupState.EXTRA_ENTRY || name == PortableBackupState.UI_ENTRY) {
            val buffered = BufferedOutputStream(hashing, 128 * 1024)
            writer(buffered)
            buffered.flush()
        } else writer(hashing)
        val stats = hashing.finish()
        zip.closeEntry()
        return stats
    }

    private fun queryCount(db: SupportSQLiteDatabase, table: String): Long =
        db.query("SELECT COUNT(*) FROM `$table`").use { c ->
            require(c.moveToFirst()) { "Could not count $table" }
            c.getLong(0)
        }

    private fun writeString(out: DataOutputStream, value: String) {
        val bytes = value.toByteArray(Charsets.UTF_8)
        require(bytes.size <= MAX_STRING_BYTES) { "Backup string is too large" }
        out.writeInt(bytes.size)
        out.write(bytes)
    }

    private fun readString(input: DataInputStream): String {
        val size = input.readInt()
        require(size in 0..MAX_STRING_BYTES) { "Invalid string length in backup" }
        val bytes = ByteArray(size)
        input.readFully(bytes)
        return bytes.toString(Charsets.UTF_8)
    }

    private fun writeByteArray(out: DataOutputStream, value: ByteArray) {
        require(value.size <= MAX_BLOB_BYTES) { "Backup blob is too large" }
        out.writeInt(value.size)
        out.write(value)
    }

    private fun readByteArray(input: DataInputStream): ByteArray {
        val size = input.readInt()
        require(size in 0..MAX_BLOB_BYTES) { "Invalid blob length in backup" }
        return ByteArray(size).also { input.readFully(it) }
    }

    private fun requireStreamHeader(input: DataInputStream, expectedMagic: Int): Long {
        require(input.readInt() == expectedMagic) { "Backup stream has the wrong type" }
        require(input.readInt() == STREAM_SCHEMA_VERSION) { "Unsupported backup stream schema" }
        val count = input.readLong()
        require(count >= 0L) { "Invalid row count in backup" }
        return count
    }

    /** Shared allowlist used by both fast preview and full integrity validation. */
    private fun isAllowedV4Entry(name: String): Boolean =
        name == NOTES_ENTRY || name == TOPICS_ENTRY || name == LINKS_ENTRY ||
            name == EMBEDDINGS_ENTRY || name == DS_ENTRY || name == MANIFEST_ENTRY ||
            (name.startsWith(ANN_PREFIX) && isSafeAnnFileName(name.removePrefix(ANN_PREFIX))) ||
            name == PortableBackupState.EXTRA_ENTRY || name == PortableBackupState.UI_ENTRY ||
            name == PortableBackupFiles.DIRECTORIES_ENTRY ||
            (name.startsWith(PortableBackupFiles.LIBRARY_PREFIX) && PortableBackupFiles.safeRel(name.removePrefix(PortableBackupFiles.LIBRARY_PREFIX))) ||
            (name.startsWith(PortableBackupFiles.APP_PREFIX) && PortableBackupFiles.safeRel(name.removePrefix(PortableBackupFiles.APP_PREFIX))) ||
            (name.startsWith(PortableBackupFiles.PREF_PREFIX) && PortableBackupFiles.safeRel(name.removePrefix(PortableBackupFiles.PREF_PREFIX)))

    /**
     * Fully validates a v4 archive without extracting its large database payloads.
     * Checksums are calculated over the uncompressed entry bytes, so corruption in
     * either the ZIP or payload is caught before restore modifies the live database.
     */
    private fun sumEntrySizes(sizes: JSONObject): Long {
        var total = 0L
        val keys = sizes.keys()
        while (keys.hasNext()) {
            val n = sizes.optLong(keys.next(), -1)
            if (n < 0 || Long.MAX_VALUE - total < n) return 0L
            total += n
        }
        return total
    }

    private fun validateV4Archive(
        ctx: Context, srcUri: Uri, onEntriesChecked: ((Int, Long) -> Unit)? = null
    ): JSONObject? {
        return try {
            val actual = linkedMapOf<String, EntryStats>()
            var manifest: JSONObject? = null
            ctx.contentResolver.openInputStream(srcUri)?.buffered()?.use { raw ->
                ZipInputStream(raw).use { zip ->
                    val buffer = ByteArray(128 * 1024)
                    var entriesChecked = 0
                    var bytesChecked = 0L
                    var lastProgressNs = 0L
                    fun report(force: Boolean = false) {
                        val now = System.nanoTime()
                        if (force || now - lastProgressNs >= 500_000_000L) {
                            onEntriesChecked?.invoke(entriesChecked, bytesChecked)
                            lastProgressNs = now
                        }
                    }
                    var entry = zip.nextEntry
                    while (entry != null) {
                        require(!entry.isDirectory && isAllowedV4Entry(entry.name)) {
                            "Unknown entry in MarkVault backup: ${entry.name}"
                        }
                        if (entry.name == MANIFEST_ENTRY) {
                            require(manifest == null) { "Duplicate backup manifest" }
                            manifest = JSONObject(zip.readBytes().toString(Charsets.UTF_8))
                        } else {
                            require(!actual.containsKey(entry.name)) {
                                "Duplicate backup entry: ${entry.name}"
                            }
                            val digest = MessageDigest.getInstance("SHA-256")
                            var size = 0L
                            while (true) {
                                val read = zip.read(buffer)
                                if (read <= 0) break
                                digest.update(buffer, 0, read)
                                size += read.toLong()
                                bytesChecked += read.toLong()
                                report()
                            }
                            val hash = BackupZipIO.hex(digest.digest())
                            actual[entry.name] = EntryStats(hash, size)
                        }
                        zip.closeEntry()
                        entriesChecked++
                        report()
                        entry = zip.nextEntry
                    }
                    report(true)
                }
            } ?: return null

            val json = manifest ?: return null
            val archiveVersion = json.optInt("format_version", 0)
            if (json.optString("app") != "MarkVault" || archiveVersion !in 4..FORMAT_VERSION) {
                return null
            }
            if (json.optInt("stream_schema_version", 0) != STREAM_SCHEMA_VERSION) return null

            val required = setOf(NOTES_ENTRY, TOPICS_ENTRY, LINKS_ENTRY, EMBEDDINGS_ENTRY, DS_ENTRY)
            val annEntries = actual.keys.filter { it.startsWith(ANN_PREFIX) }.toSet()
            val portableEntries = actual.keys.filter {
                it.startsWith(PortableBackupFiles.LIBRARY_PREFIX) ||
                    it.startsWith(PortableBackupFiles.APP_PREFIX) ||
                    it.startsWith(PortableBackupFiles.PREF_PREFIX)
            }.toSet()
            val portableRequired = if (archiveVersion >= 7)
                setOf(PortableBackupState.EXTRA_ENTRY, PortableBackupState.UI_ENTRY,
                    PortableBackupFiles.DIRECTORIES_ENTRY) + portableEntries else emptySet()
            val expected = if (archiveVersion >= 8) {
                if (!validPartialEntries(json, actual.keys)) return null
                actual.keys
            } else (if (archiveVersion >= 5) required + annEntries else required) + portableRequired
            if (actual.keys != expected) return null
            if (archiveVersion >= 7) {
                if (json.optInt("database_schema", -1) != 24) return null
                if (json.optInt("library_files", -1) != portableEntries.count {
                    it.startsWith(PortableBackupFiles.LIBRARY_PREFIX) }) return null
                if (json.optInt("app_files", -1) != portableEntries.count {
                    it.startsWith(PortableBackupFiles.APP_PREFIX) || it.startsWith(PortableBackupFiles.PREF_PREFIX) }) return null
            }
            if (archiveVersion >= 5 && json.optInt("ann_indexes", -1) != annEntries.size) return null
            val checksums = json.optJSONObject("checksums") ?: return null
            val sizes = json.optJSONObject("sizes") ?: return null
            if (checksums.length() != expected.size || sizes.length() != expected.size) return null
            for (name in expected) {
                val stats = actual[name] ?: return null
                if (!stats.sha256.equals(checksums.optString(name), ignoreCase = true)) return null
                if (stats.size != sizes.optLong(name, -1L)) return null
            }
            json
        } catch (e: Exception) {
            Log.e(TAG, "validateV4Archive failed", e)
            null
        }
    }

    private fun isSafeAnnFileName(name: String): Boolean =
        name.matches(Regex("ann_(?:ivf|hnsw)_[A-Za-z0-9_-]+\\.bin"))

    private fun validateAnnSnapshotFile(file: File): Boolean = runCatching {
        if (file.name.startsWith("ann_hnsw_")) {
            return@runCatching com.tebogo.markvault.search.HnswIndex.readStatsFile(file) != null
        }
        DataInputStream(java.io.BufferedInputStream(FileInputStream(file), 8 * 1024)).use { input ->
            val version = input.readInt()
            val modelVersion = input.readUTF()
            val dim = input.readInt()
            val clusters = input.readInt()
            val vectors = input.readInt()
            input.readLong() // build timestamp
            val embeddingCountAtBuild = input.readInt()
            val expectedName = "ann_ivf_" + modelVersion.replace(Regex("[^a-zA-Z0-9_-]"), "_") + ".bin"
            version == 1 && file.name == expectedName && dim in 1..2048 &&
                clusters in 1..1024 && vectors >= 0 && embeddingCountAtBuild >= 0
        }
    }.getOrDefault(false)

    private fun clearFinalAnnIndexes(ctx: Context) {
        ctx.filesDir.listFiles()?.filter {
            it.isFile && isSafeAnnFileName(it.name)
        }?.forEach { runCatching { it.delete() } }
    }

    /** Restore all model-specific ANN snapshots only after the Room embedding
     * transaction has committed. Every payload was checksum-verified by
     * validateV4Archive first. Stage all files before replacing any live index
     * so an I/O failure cannot leave a half-restored model set. */
    private fun restoreAnnIndexes(ctx: Context, srcUri: Uri, manifest: JSONObject,
                                  onProgress: (String, Long, Long, Int) -> Unit = { _, _, _, _ -> }) {
        val expectedCount = manifest.optInt("ann_indexes", 0)
        val staged = File(ctx.cacheDir, "ann_restore_${System.nanoTime()}").apply { mkdirs() }
        var preserveRecoveryCopies = false
        try {
            var found = 0
            val hashes = manifest.optJSONObject("checksums") ?: error("Missing verified checksums")
            val sizes = manifest.optJSONObject("sizes") ?: error("Missing verified sizes")
            val annBytes = sizes.keys().asSequence().filter { it.startsWith(ANN_PREFIX) }.sumOf { sizes.optLong(it, 0L) }
            val expectedNames = sizes.keys().asSequence().filter { it.startsWith(ANN_PREFIX) }.map { it.removePrefix(ANN_PREFIX) }.toSet()
            val existingNames = ctx.filesDir.listFiles()?.filter { it.isFile && isSafeAnnFileName(it.name) }?.map { it.name }?.toSet().orEmpty()
            if (expectedNames.size == expectedCount && expectedNames == existingNames && expectedNames.all { name ->
                val live = File(ctx.filesDir, name)
                isSafeAnnFileName(name) && live.length() == sizes.optLong(ANN_PREFIX + name, -1) &&
                    validateAnnSnapshotFile(live) && sha256(live).equals(hashes.getString(ANN_PREFIX + name), true)
            }) {
                onProgress("Reusing verified ANN indexes…", expectedCount.toLong(), expectedCount.toLong(), 98)
                return
            }
            val progress = BackupZipIO.Stage("Restoring ANN indexes…", 96, 98, expectedCount.toLong(), annBytes, onProgress)
            val buffer = ByteArray(128 * 1024)
            progress.report(true)
            BackupZipIO.visitVerified(ctx, srcUri, { hashes.getString(it) }, { !it.isDirectory && it.name.startsWith(ANN_PREFIX) }) { entry, zip ->
                val name = entry.name.removePrefix(ANN_PREFIX)
                require(isSafeAnnFileName(name)) { "Unsafe ANN index in backup" }
                val out = File(staged, name)
                FileOutputStream(out).use { BackupZipIO.copy(zip, it, buffer, progress::bytes) }
                require(out.length() > 1000L && validateAnnSnapshotFile(out)) {
                    "ANN index is invalid or does not match its model filename: $name"
                }
                found++
                progress.item()
            }
            progress.report(true)
            require(found == expectedCount) { "ANN index count does not match backup manifest" }

            // v5.5.47: retain the old ANN set until *all* replacements have
            // been published. Earlier code deleted every index first, so a
            // failed copy could destroy usable indexes on an otherwise intact
            // device. Renames stay within app-private storage; no extra vector
            // copies are allocated in memory.
            val incoming = staged.listFiles()?.filter { it.isFile }?.sortedBy { it.name }.orEmpty()
            val previous = File(staged, "previous").apply {
                require(mkdirs()) { "Could not create ANN rollback directory" }
            }
            val installed = ArrayList<File>()
            val moved = ArrayList<Pair<File, File>>()
            try {
                val oldIndexes = ctx.filesDir.listFiles()
                    ?.filter { it.isFile && isSafeAnnFileName(it.name) }
                    ?.sortedBy { it.name }.orEmpty()
                for (old in oldIndexes) {
                    val saved = File(previous, old.name)
                    require(old.renameTo(saved)) { "Could not safeguard existing ANN index: ${old.name}" }
                    moved.add(saved to old)
                }
                for (src in incoming) {
                    val dst = File(ctx.filesDir, src.name)
                    // Mark the destination before copying, including on failure.
                    installed.add(dst)
                    copyFileChecked(src, dst)
                    require(dst.length() == src.length() && validateAnnSnapshotFile(dst) &&
                        sha256(dst).equals(hashes.getString(ANN_PREFIX + src.name), true)) {
                        "ANN restore failed post-copy validation: ${src.name}"
                    }
                }
            } catch (failure: Exception) {
                installed.forEach { runCatching { it.delete() } }
                for ((saved, original) in moved.asReversed()) {
                    if (!saved.renameTo(original)) {
                        preserveRecoveryCopies = true
                        failure.addSuppressed(java.io.IOException(
                            "Could not restore ${original.name}; recovery copy at ${saved.absolutePath}"
                        ))
                    }
                }
                throw failure
            }
        } finally {
            // Do not erase the only remaining rollback copy if restoration
            // of an old index fails unexpectedly.
            if (!preserveRecoveryCopies) staged.deleteRecursively()
        }
    }

    private data class CurrentLibraryFile(
        val uri: String,
        val relPath: String,
        val size: Long,
        val lastModified: Long
    )

    private data class RestoreRemapResult(
        val matchedNotes: Long,
        val totalNotes: Long
    )

    private fun normalizeRelPath(path: String): String =
        path.replace('\\', '/').trim('/').replace(Regex("/+"), "/")

    /**
     * Scan only metadata from the currently-selected SAF library. No article
     * contents are read and no indexing is triggered. The resulting map lets a
     * restore reconnect old-device note rows to the new device's content:// URIs
     * using the stable relative path that is already stored in every backup row.
     */
    private fun scanCurrentLibrary(
        ctx: Context,
        treeUriString: String,
        onProgress: (done: Long, total: Long) -> Unit = { _, _ -> }
    ): Map<String, CurrentLibraryFile> {
        val tree = PortableBackupFiles.scanLibrary(ctx, treeUriString) { count -> onProgress(count.toLong(), 0L) }
        val result = LinkedHashMap<String, CurrentLibraryFile>(tree.files.size)
        tree.files.forEachIndexed { index, file ->
            result[file.relativePath] = CurrentLibraryFile(
                file.uri.toString(), file.sourceRelativePath, file.size, file.lastModified
            )
            if ((index + 1) % 256 == 0) onProgress((index + 1).toLong(), tree.files.size.toLong())
        }
        onProgress(tree.files.size.toLong(), tree.files.size.toLong().coerceAtLeast(1L))
        return result
    }

    private fun extractV4Settings(ctx: Context, srcUri: Uri, target: File, manifest: JSONObject) {
        target.parentFile?.mkdirs()
        target.delete()
        var found = false
        BackupZipIO.visitVerified(ctx, srcUri, { manifest.optJSONObject("checksums")!!.getString(it) }, { it.name == DS_ENTRY && !it.isDirectory }) { _, zip ->
            require(!found) { "Duplicate settings stream" }
            FileOutputStream(target).use { output ->
                zip.copyTo(output)
                output.fd.sync()
            }
            found = true
        }
        require(found && target.isFile) { "Backup settings are missing" }
    }

    /** Retry only skips a committed database if the archive streams, actual
     * destination mapping and the closed, WAL-free database bytes all match.
     * Cache eviction or a changed database merely causes a safe replay. */
    private fun restoreDatabaseWithCheckpoint(
        ctx: Context, srcUri: Uri, manifest: JSONObject,
        libraryFiles: Map<String, CurrentLibraryFile>, onProgress: (RestoreProgress) -> Unit
    ): RestoreRemapResult {
        if (manifest.optInt("format_version", 1) < 7) return applyV4StreamedLibraryState(ctx, srcUri, manifest, libraryFiles, onProgress)
        val digest = MessageDigest.getInstance("SHA-256")
        fun add(value: String) {
            val bytes = value.toByteArray(Charsets.UTF_8)
            digest.update(java.nio.ByteBuffer.allocate(4).putInt(bytes.size).array())
            digest.update(bytes)
        }
        val hashes = manifest.optJSONObject("checksums") ?: error("Missing checksums")
        for (name in listOf(NOTES_ENTRY, TOPICS_ENTRY, LINKS_ENTRY, EMBEDDINGS_ENTRY,
            PortableBackupState.EXTRA_ENTRY, PortableBackupState.UI_ENTRY)) add(hashes.getString(name))
        for ((path, file) in libraryFiles.toSortedMap()) {
            add(path); add(file.uri); add(file.relPath); add(file.size.toString()); add(file.lastModified.toString())
        }
        val identity = BackupZipIO.hex(digest.digest())
        val checkpoint = File(ctx.cacheDir, "portable_restore_database_checkpoint.txt")
        val live = databaseFile(ctx)
        val prior = runCatching { checkpoint.readLines() }.getOrDefault(emptyList())
        if (prior.size == 2 && prior[0] == identity && live.isFile && databaseWal(ctx).length() == 0L) {
            onProgress(RestoreProgress("Checking previously committed database…", 0, 0, 32))
            if (sha256(live) == prior[1] && quickCheckSqlite(live)) {
                val count = manifest.optLong("notes", 0)
                onProgress(RestoreProgress("Reusing verified database and embeddings…", count, count, 98))
                return RestoreRemapResult(count, count)
            }
        }
        checkpoint.delete()
        val remap = applyV4StreamedLibraryState(ctx, srcUri, manifest, libraryFiles, onProgress)
        if (databaseWal(ctx).length() == 0L) {
            onProgress(RestoreProgress("Recording committed database checkpoint…", 0, 0, 98))
            // A checkpoint is an optimization, not a requirement for success.
            runCatching { checkpoint.writeText(identity + "\n" + sha256(live) + "\n") }
        }
        return remap
    }

    private fun applyV4StreamedLibraryState(
        ctx: Context,
        srcUri: Uri,
        manifest: JSONObject,
        libraryFiles: Map<String, CurrentLibraryFile>,
        onProgress: (RestoreProgress) -> Unit
    ): RestoreRemapResult {
        val live = databaseFile(ctx)
        require(live.isFile && live.length() > 0L) { "Live MarkVault database is missing" }
        databaseWal(ctx).delete()
        databaseShm(ctx).delete()

        val expectedNotes = manifest.optLong("notes", -1L)
        val expectedEmbeddings = manifest.optLong("embeddings", -1L)
        val mappedLastModified = HashMap<Long, Long>()
        var matchedNotes = 0L

        val db = SQLiteDatabase.openDatabase(live.absolutePath, null, SQLiteDatabase.OPEN_READWRITE)
        try {
            db.beginTransaction()
            try {
                // Preserve this device's UI-only note state by both URI and
                // relative path. Relative-path matching matters after a portable
                // restore because the content:// URI is expected to change.
                db.execSQL(
                    "CREATE TEMP TABLE current_note_ui AS " +
                        "SELECT uri, relPath, lastOpened, lastScroll, favourite FROM notes"
                )
                db.execSQL("DELETE FROM note_embeddings")
                db.execSQL("DELETE FROM note_topics")
                db.execSQL("DELETE FROM note_links")
                db.execSQL("DELETE FROM notes")

                var restoredNotes = 0L
                var restoredEmbeddings = 0L
                var sawNotes = false
                var sawTopics = false
                var sawLinks = false
                var sawEmbeddings = false
                var sawExtra = false
                var sawNoteUi = false
                var lastDbProgress = 0L
                fun rowProgress(index: Long, count: Long): Boolean {
                    val now = System.nanoTime()
                    if (index == 0L || index + 1L == count || now - lastDbProgress >= 500_000_000L) {
                        lastDbProgress = now
                        return true
                    }
                    return false
                }

                val databaseEntries = setOf(NOTES_ENTRY, TOPICS_ENTRY, LINKS_ENTRY, EMBEDDINGS_ENTRY,
                    PortableBackupState.EXTRA_ENTRY, PortableBackupState.UI_ENTRY)
                BackupZipIO.visitVerified(ctx, srcUri, { manifest.optJSONObject("checksums")!!.getString(it) }, { !it.isDirectory && it.name in databaseEntries }) { entry, zip ->
                            when (entry.name) {
                                PortableBackupState.EXTRA_ENTRY -> {
                                    onProgress(RestoreProgress("Restoring additional database tables…", 0, 0, 95))
                                    PortableBackupState.restoreExtras(db, zip.buffered(128 * 1024)) { table, done, total ->
                                        onProgress(RestoreProgress("Restoring $table…", done, total, 95))
                                    }
                                    sawExtra = true
                                }
                                PortableBackupState.UI_ENTRY -> {
                                    onProgress(RestoreProgress("Restoring note preferences…", 0, 0, 95))
                                    PortableBackupState.restoreNoteUi(db, zip.buffered(128 * 1024))
                                    sawNoteUi = true
                                }
                                NOTES_ENTRY -> {
                                    val input = DataInputStream(zip.buffered(128 * 1024))
                                    val count = requireStreamHeader(input, MAGIC_NOTES)
                                    val stmt = db.compileStatement(
                                        "INSERT INTO notes(id, uri, relPath, name, title, folder, content, lastModified, size, " +
                                            "lastOpened, lastScroll, favourite, fileType) VALUES(?,?,?,?,?,?,?,?,?,0,0,0,?)"
                                    )
                                    repeatLong(count) { index ->
                                        val id = input.readLong()
                                        readString(input) // old-device URI; intentionally never reused blindly
                                        val relPath = readString(input)
                                        val name = readString(input)
                                        val title = readString(input)
                                        val folder = readString(input)
                                        val content = readString(input)
                                        val backupLastModified = input.readLong()
                                        val backupSize = input.readLong()
                                        val fileType = readString(input)

                                        val current = libraryFiles[normalizeRelPath(relPath)]
                                        val safeMatch = current != null &&
                                            (current.size <= 0L || backupSize <= 0L || current.size == backupSize)
                                        val restoredUri = if (safeMatch) {
                                            current!!.uri
                                        } else {
                                            // Never trust an old device's SAF URI when a file
                                            // could not be proved to match this library. Keep the
                                            // indexed row searchable but make its unresolved state
                                            // explicit instead of risking opening the wrong file.
                                            "markvault-unmapped://note/$id"
                                        }
                                        val restoredModified = if (safeMatch && current!!.lastModified > 0L) {
                                            current.lastModified
                                        } else backupLastModified
                                        val restoredSize = if (safeMatch && current!!.size >= 0L) current.size else backupSize
                                        if (safeMatch) {
                                            matchedNotes++
                                            mappedLastModified[id] = restoredModified
                                        }

                                        stmt.clearBindings()
                                        stmt.bindLong(1, id)
                                        stmt.bindString(2, restoredUri)
                                        val destinationPath = if (manifest.optInt("format_version", 1) >= 7 && safeMatch)
                                            current!!.relPath else relPath
                                        val renamed = destinationPath != relPath
                                        stmt.bindString(3, destinationPath)
                                        stmt.bindString(4, if (renamed) destinationPath.substringAfterLast('/') else name)
                                        stmt.bindString(5, title)
                                        stmt.bindString(6, if (renamed) destinationPath.substringBeforeLast('/', "") else folder)
                                        stmt.bindString(7, content)
                                        stmt.bindLong(8, restoredModified)
                                        stmt.bindLong(9, restoredSize)
                                        stmt.bindString(10, fileType)
                                        stmt.executeInsert()

                                        if ((index % 128L == 0L || index + 1L == count) && rowProgress(index, count)) {
                                            val pct = 32 + (((index + 1L) * 23L) / count.coerceAtLeast(1L)).toInt()
                                            onProgress(RestoreProgress("Restoring library index…", index + 1L, count, pct.coerceIn(32, 55)))
                                        }
                                    }
                                    restoredNotes = count
                                    sawNotes = true
                                }
                                TOPICS_ENTRY -> {
                                    val input = DataInputStream(zip.buffered(128 * 1024))
                                    val count = requireStreamHeader(input, MAGIC_TOPICS)
                                    val stmt = db.compileStatement(
                                        "INSERT INTO note_topics(noteId, topic, score) VALUES(?,?,?)"
                                    )
                                    repeatLong(count) { index ->
                                        stmt.clearBindings()
                                        stmt.bindLong(1, input.readLong())
                                        stmt.bindString(2, readString(input))
                                        stmt.bindLong(3, input.readInt().toLong())
                                        stmt.executeInsert()
                                        if ((index % 256L == 0L || index + 1L == count) && rowProgress(index, count)) {
                                            val pct = 56 + (((index + 1L) * 9L) / count.coerceAtLeast(1L)).toInt()
                                            onProgress(RestoreProgress("Restoring topics…", index + 1L, count, pct.coerceIn(56, 65)))
                                        }
                                    }
                                    sawTopics = true
                                }
                                LINKS_ENTRY -> {
                                    val input = DataInputStream(zip.buffered(128 * 1024))
                                    val count = requireStreamHeader(input, MAGIC_LINKS)
                                    val stmt = db.compileStatement(
                                        "INSERT INTO note_links(fromId, target, targetNorm) VALUES(?,?,?)"
                                    )
                                    repeatLong(count) { index ->
                                        stmt.clearBindings()
                                        stmt.bindLong(1, input.readLong())
                                        stmt.bindString(2, readString(input))
                                        stmt.bindString(3, readString(input))
                                        stmt.executeInsert()
                                        if ((index % 256L == 0L || index + 1L == count) && rowProgress(index, count)) {
                                            val pct = 66 + (((index + 1L) * 9L) / count.coerceAtLeast(1L)).toInt()
                                            onProgress(RestoreProgress("Restoring links…", index + 1L, count, pct.coerceIn(66, 75)))
                                        }
                                    }
                                    sawLinks = true
                                }
                                EMBEDDINGS_ENTRY -> {
                                    val input = DataInputStream(zip.buffered(128 * 1024))
                                    val count = requireStreamHeader(input, MAGIC_EMBEDDINGS)
                                    val stmt = db.compileStatement(
                                        "INSERT INTO note_embeddings(noteId, modelVersion, chunkIndex, dim, vector, " +
                                            "sourceLastModified, createdAt) VALUES(?,?,?,?,?,?,?)"
                                    )
                                    repeatLong(count) { index ->
                                        val noteId = input.readLong()
                                        val modelVersion = readString(input)
                                        val chunkIndex = input.readInt()
                                        val dim = input.readInt()
                                        val vector = readByteArray(input)
                                        val backupSourceModified = input.readLong()
                                        val createdAt = input.readLong()
                                        val sourceModified = mappedLastModified[noteId] ?: backupSourceModified

                                        stmt.clearBindings()
                                        stmt.bindLong(1, noteId)
                                        stmt.bindString(2, modelVersion)
                                        stmt.bindLong(3, chunkIndex.toLong())
                                        stmt.bindLong(4, dim.toLong())
                                        stmt.bindBlob(5, vector)
                                        stmt.bindLong(6, sourceModified)
                                        stmt.bindLong(7, createdAt)
                                        stmt.executeInsert()
                                        if ((index % 64L == 0L || index + 1L == count) && rowProgress(index, count)) {
                                            val pct = 76 + (((index + 1L) * 19L) / count.coerceAtLeast(1L)).toInt()
                                            onProgress(RestoreProgress("Restoring semantic embeddings…", index + 1L, count, pct.coerceIn(76, 95)))
                                        }
                                    }
                                    restoredEmbeddings = count
                                    sawEmbeddings = true
                                }
                            }
                }

                require(sawNotes && sawTopics && sawLinks && sawEmbeddings) {
                    "Backup is missing required library streams"
                }
                if (manifest.optInt("format_version", 1) >= 7) {
                    require(sawExtra && sawNoteUi) { "Portable database state is incomplete" }
                }
                require(restoredNotes == expectedNotes) {
                    "Restored note count does not match the backup manifest"
                }
                require(restoredEmbeddings == expectedEmbeddings) {
                    "Restored embedding count does not match the backup manifest"
                }
                if (manifest.optInt("format_version", 1) >= 7) {
                    // Every restored article must have a working new-device file URI.
                    // Abort inside the SQL transaction rather than claiming a
                    // portable success with missing articles and stale embeddings.
                    require(matchedNotes == expectedNotes) {
                        "Only $matchedNotes of $expectedNotes library files were matched; library state rolled back"
                    }
                    db.execSQL(
                        "UPDATE pdf_history SET uri=(SELECT n.uri FROM notes n WHERE n.id=pdf_history.noteId) " +
                            "WHERE noteId>0 AND EXISTS (SELECT 1 FROM notes n WHERE n.id=pdf_history.noteId)"
                    )
                }

                // Restore UI-only state for rows already known on this device.
                // relPath fallback makes this work across SAF URI changes.
                if (manifest.optInt("format_version", 1) < 7) db.execSQL(
                    "UPDATE notes SET " +
                        "lastOpened=COALESCE((SELECT u.lastOpened FROM current_note_ui u WHERE u.uri=notes.uri OR u.relPath=notes.relPath LIMIT 1),0), " +
                        "lastScroll=COALESCE((SELECT u.lastScroll FROM current_note_ui u WHERE u.uri=notes.uri OR u.relPath=notes.relPath LIMIT 1),0), " +
                        "favourite=COALESCE((SELECT u.favourite FROM current_note_ui u WHERE u.uri=notes.uri OR u.relPath=notes.relPath LIMIT 1),0)"
                )
                onProgress(RestoreProgress("Rebuilding search index…", 0, 0, 96))
                db.execSQL("INSERT INTO notes_fts(notes_fts) VALUES('rebuild')")
                db.execSQL("DROP TABLE current_note_ui")
                onProgress(RestoreProgress("Verifying restored data…", 0L, 0L, 98))
                db.rawQuery("PRAGMA quick_check", null).use { cursor ->
                    require(cursor.moveToFirst() && cursor.getString(0).equals("ok", ignoreCase = true)) {
                        "Restored database failed SQLite quick_check before commit"
                    }
                }
                fun actualCount(table: String): Long = db.rawQuery("SELECT COUNT(*) FROM $table", null).use {
                    require(it.moveToFirst()); it.getLong(0)
                }
                require(actualCount("notes") == expectedNotes && actualCount("note_embeddings") == expectedEmbeddings) {
                    "Final restored database counts differ from the backup"
                }
                db.setTransactionSuccessful()
            } finally {
                db.endTransaction()
            }
        } finally {
            db.close()
        }
        onProgress(RestoreProgress("Checking committed database…", 0, 0, 98))
        require(quickCheckSqlite(live)) { "Live database failed SQLite quick_check after restore" }
        return RestoreRemapResult(matchedNotes = matchedNotes, totalNotes = expectedNotes.coerceAtLeast(0L))
    }

    private inline fun repeatLong(count: Long, block: (Long) -> Unit) {
        var i = 0L
        while (i < count) {
            block(i)
            i++
        }
    }

    /**
     * Creates a compact SQLite payload containing only library-index state.
     * FTS is deliberately omitted because it is deterministically rebuilt from
     * notes on restore; media embeddings are deliberately excluded.
     *
     * The destination is attached directly to Room's live SQLite connection and
     * populated inside one transaction. That gives all copied tables one coherent
     * point-in-time view without first duplicating the entire (potentially huge)
     * application database in cache.
     */
    private fun createSelectiveLibraryState(ctx: Context, target: File): Boolean {
        target.delete()
        target.parentFile?.mkdirs()
        val roomDb = VaultDb.get(ctx).openHelper.writableDatabase
        var attached = false
        return try {
            roomDb.execSQL("ATTACH DATABASE '${sqlPath(target)}' AS mvbackup")
            attached = true
            roomDb.beginTransaction()
            try {
                roomDb.execSQL(
                    "CREATE TABLE mvbackup.notes AS SELECT id AS backupId, uri, relPath, name, title, folder, " +
                        "content, lastModified, size, fileType FROM main.notes"
                )
                roomDb.execSQL(
                    "CREATE TABLE mvbackup.note_topics AS SELECT noteId, topic, score FROM main.note_topics"
                )
                roomDb.execSQL(
                    "CREATE TABLE mvbackup.note_links AS SELECT fromId, target, targetNorm FROM main.note_links"
                )
                roomDb.execSQL(
                    "CREATE TABLE mvbackup.note_embeddings AS SELECT noteId, modelVersion, chunkIndex, dim, vector, " +
                        "sourceLastModified, createdAt FROM main.note_embeddings"
                )
                roomDb.execSQL("CREATE INDEX mvbackup.idx_backup_notes_id ON notes(backupId)")
                roomDb.execSQL("CREATE INDEX mvbackup.idx_backup_topics_note ON note_topics(noteId)")
                roomDb.execSQL("CREATE INDEX mvbackup.idx_backup_links_note ON note_links(fromId)")
                roomDb.execSQL("CREATE INDEX mvbackup.idx_backup_embeddings_note ON note_embeddings(noteId)")
                roomDb.setTransactionSuccessful()
            } finally {
                roomDb.endTransaction()
            }
            roomDb.execSQL("DETACH DATABASE mvbackup")
            attached = false
            target.isFile && target.length() > 0L
        } catch (e: Exception) {
            Log.e(TAG, "createSelectiveLibraryState failed", e)
            false
        } finally {
            if (attached) runCatching { roomDb.execSQL("DETACH DATABASE mvbackup") }
        }
    }

    private fun validateSelectiveState(file: File) {
        val db = SQLiteDatabase.openDatabase(file.absolutePath, null, SQLiteDatabase.OPEN_READONLY)
        try {
            requireTableColumns(db, "notes", setOf(
                "backupId", "uri", "relPath", "name", "title", "folder", "content",
                "lastModified", "size", "fileType"
            ))
            requireTableColumns(db, "note_topics", setOf("noteId", "topic", "score"))
            requireTableColumns(db, "note_links", setOf("fromId", "target", "targetNorm"))
            requireTableColumns(db, "note_embeddings", setOf(
                "noteId", "modelVersion", "chunkIndex", "dim", "vector", "sourceLastModified", "createdAt"
            ))
        } finally {
            db.close()
        }
    }

    private fun requireTableColumns(db: SQLiteDatabase, table: String, required: Set<String>) {
        val found = mutableSetOf<String>()
        db.rawQuery("PRAGMA table_info(`$table`)", null).use { c ->
            val nameIdx = c.getColumnIndexOrThrow("name")
            while (c.moveToNext()) found += c.getString(nameIdx)
        }
        require(found.containsAll(required)) { "Backup table $table has an incompatible schema" }
    }

    private fun selectiveStateCounts(file: File): Pair<Long, Long> {
        val db = SQLiteDatabase.openDatabase(file.absolutePath, null, SQLiteDatabase.OPEN_READONLY)
        return try {
            fun count(table: String): Long = db.rawQuery("SELECT COUNT(*) FROM `$table`", null).use { c ->
                c.moveToFirst(); c.getLong(0)
            }
            count("notes") to count("note_embeddings")
        } finally {
            db.close()
        }
    }

    /** Merge only the requested state into the live Room DB, leaving all other tables untouched. */
    private fun applySelectiveLibraryState(ctx: Context, stateFile: File) {
        val live = databaseFile(ctx)
        require(live.isFile && live.length() > 0L) { "Live MarkVault database is missing" }
        databaseWal(ctx).delete()
        databaseShm(ctx).delete()

        val db = SQLiteDatabase.openDatabase(live.absolutePath, null, SQLiteDatabase.OPEN_READWRITE)
        try {
            db.execSQL("ATTACH DATABASE '${sqlPath(stateFile)}' AS restore")
            db.beginTransaction()
            try {
                // Keep UI-only note state that is not part of the requested backup scope.
                db.execSQL(
                    "CREATE TEMP TABLE current_note_ui AS " +
                        "SELECT uri, relPath, lastOpened, lastScroll, favourite FROM notes"
                )

                db.execSQL("DELETE FROM note_embeddings")
                db.execSQL("DELETE FROM note_topics")
                db.execSQL("DELETE FROM note_links")
                db.execSQL("DELETE FROM notes")

                db.execSQL(
                    "INSERT INTO notes(id, uri, relPath, name, title, folder, content, lastModified, size, " +
                        "lastOpened, lastScroll, favourite, fileType) " +
                        "SELECT r.backupId, r.uri, r.relPath, r.name, r.title, r.folder, r.content, " +
                        "r.lastModified, r.size, " +
                        "COALESCE((SELECT u.lastOpened FROM current_note_ui u WHERE u.uri=r.uri LIMIT 1), 0), " +
                        "COALESCE((SELECT u.lastScroll FROM current_note_ui u WHERE u.uri=r.uri LIMIT 1), 0), " +
                        "COALESCE((SELECT u.favourite FROM current_note_ui u WHERE u.uri=r.uri LIMIT 1), 0), " +
                        "r.fileType FROM restore.notes r"
                )
                db.execSQL(
                    "INSERT INTO note_topics(noteId, topic, score) " +
                        "SELECT noteId, topic, score FROM restore.note_topics"
                )
                db.execSQL(
                    "INSERT INTO note_links(fromId, target, targetNorm) " +
                        "SELECT fromId, target, targetNorm FROM restore.note_links"
                )
                db.execSQL(
                    "INSERT INTO note_embeddings(noteId, modelVersion, chunkIndex, dim, vector, sourceLastModified, createdAt) " +
                        "SELECT noteId, modelVersion, chunkIndex, dim, vector, sourceLastModified, createdAt " +
                        "FROM restore.note_embeddings"
                )

                // notes_fts is a Room FTS4 external-content table. Rebuild it from the
                // restored notes instead of storing a duplicate copy in the backup.
                db.execSQL("INSERT INTO notes_fts(notes_fts) VALUES('rebuild')")
                db.execSQL("DROP TABLE current_note_ui")
                db.rawQuery("PRAGMA quick_check", null).use { cursor ->
                    require(cursor.moveToFirst() && cursor.getString(0).equals("ok", ignoreCase = true)) {
                        "Restored database failed SQLite quick_check before commit"
                    }
                }
                db.setTransactionSuccessful()
            } finally {
                db.endTransaction()
            }
            db.execSQL("DETACH DATABASE restore")
        } finally {
            db.close()
        }
        require(quickCheckSqlite(live)) { "Live database failed SQLite quick_check after restore" }
    }

    /** Legacy whole-DB replacement, used only when restoring old v1/v2 archives. */
    private fun installLegacyWholeDatabase(ctx: Context, stagedDb: File): Boolean {
        val rollback = File(ctx.cacheDir, "restore_legacy_rollback_${System.nanoTime()}")
        val target = databaseFile(ctx)
        var moved = false
        var installed = false
        return try {
            rollback.mkdirs()
            VaultDb.closeForRestore()
            target.parentFile?.mkdirs()
            val old = File(rollback, "markvault.db")
            if (target.exists()) {
                require(target.renameTo(old)) { "Could not protect current database" }
                moved = true
            }
            databaseWal(ctx).delete()
            databaseShm(ctx).delete()
            val incoming = File(target.parentFile, "markvault.db.restore_incoming")
            incoming.delete()
            copyFileChecked(stagedDb, incoming)
            require(incoming.renameTo(target)) { "Could not install legacy backup database" }
            installed = true
            require(quickCheckSqlite(target)) { "Installed legacy database failed SQLite quick_check" }
            true
        } catch (e: Exception) {
            Log.e(TAG, "Legacy database restore failed; rolling back", e)
            runCatching {
                val old = File(rollback, "markvault.db")
                if (installed) target.delete()
                if (moved && old.exists()) require(old.renameTo(target)) { "Legacy DB rollback failed" }
                databaseWal(ctx).delete()
                databaseShm(ctx).delete()
            }
            runCatching { VaultDb.get(ctx).openHelper.writableDatabase }
            false
        } finally {
            rollback.deleteRecursively()
        }
    }

    private fun createDatabaseSnapshot(ctx: Context, target: File): Boolean {
        target.delete()
        target.parentFile?.mkdirs()
        val roomDb = VaultDb.get(ctx).openHelper.writableDatabase

        val escaped = target.absolutePath.replace("'", "''")
        val vacuumOk = runCatching {
            roomDb.execSQL("VACUUM INTO '$escaped'")
            target.isFile && target.length() > 0L
        }.getOrElse {
            Log.i(TAG, "VACUUM INTO unavailable; using locked checkpoint snapshot: ${it.message}")
            false
        }
        if (vacuumOk) return true

        return runCatching {
            roomDb.execSQL("PRAGMA wal_checkpoint(TRUNCATE)")
            roomDb.beginTransaction()
            try {
                val live = databaseFile(ctx)
                require(live.isFile && live.length() > 0L) { "Live database missing" }
                copyFileChecked(live, target)
                roomDb.setTransactionSuccessful()
            } finally {
                roomDb.endTransaction()
            }
            target.isFile && target.length() > 0L
        }.getOrElse {
            Log.e(TAG, "Locked database snapshot failed", it)
            false
        }
    }

    private fun extractRecognisedEntries(ctx: Context, srcUri: Uri, staging: File): JSONObject? {
        var manifest: JSONObject? = null
        ctx.contentResolver.openInputStream(srcUri)?.buffered()?.use { raw ->
            ZipInputStream(raw).use { zip ->
                var entry = zip.nextEntry
                while (entry != null) {
                    val name = entry.name
                    if (!entry.isDirectory && isRecognisedEntry(name)) {
                        if (name == MANIFEST_ENTRY) {
                            manifest = JSONObject(zip.readBytes().toString(Charsets.UTF_8))
                        } else {
                            val output = safeStagingFile(staging, name)
                            output.parentFile?.mkdirs()
                            FileOutputStream(output).use { zip.copyTo(it) }
                        }
                    }
                    zip.closeEntry()
                    entry = zip.nextEntry
                }
            }
        } ?: return null
        return manifest?.takeIf { it.optString("app") == "MarkVault" }
    }

    private fun isRecognisedEntry(name: String): Boolean =
        name == MANIFEST_ENTRY || name == STATE_ENTRY || name == DS_ENTRY ||
            name == LEGACY_DB_V2_ENTRY || name == LEGACY_DB_V1_ENTRY || name == LEGACY_DS_ENTRY ||
            name == LEGACY_ACTIVITY_ENTRY || name.startsWith(LEGACY_LYRICS_PREFIX) ||
            name.startsWith(LEGACY_TRANSCRIPTS_PREFIX)

    private fun safeStagingFile(root: File, entryName: String): File {
        require(!entryName.startsWith("/") && !entryName.contains("..")) { "Unsafe ZIP entry" }
        val file = File(root, entryName)
        val rootPath = root.canonicalPath
        val filePath = file.canonicalPath
        require(filePath == rootPath || filePath.startsWith(rootPath + File.separator)) {
            "ZIP entry escapes staging directory"
        }
        return file
    }

    private fun verifyManifestProtectedEntries(
        manifest: JSONObject,
        staging: File,
        requireSelectiveState: Boolean
    ) {
        val checksums = manifest.optJSONObject("checksums")
            ?: throw IllegalArgumentException("Backup checksum table is missing")
        val sizes = manifest.optJSONObject("sizes")
            ?: throw IllegalArgumentException("Backup size table is missing")

        val keys = checksums.keys()
        var protectedCount = 0
        while (keys.hasNext()) {
            val entry = keys.next()
            require(isRecognisedEntry(entry) && entry != MANIFEST_ENTRY) { "Unknown protected backup entry" }
            val file = safeStagingFile(staging, entry)
            require(file.isFile) { "Backup entry missing: $entry" }
            require(file.length() == sizes.optLong(entry, -1L)) { "Backup size mismatch: $entry" }
            require(sha256(file).equals(checksums.optString(entry), ignoreCase = true)) {
                "Backup checksum mismatch: $entry"
            }
            protectedCount++
        }
        require(protectedCount >= 2) { "Backup does not contain required protected data" }
        if (requireSelectiveState) {
            require(checksums.has(STATE_ENTRY) && checksums.has(DS_ENTRY)) {
                "Required v3 entries are not protected"
            }
        } else {
            require(
                (checksums.has(LEGACY_DB_V2_ENTRY) || checksums.has(LEGACY_DB_V1_ENTRY)) &&
                    (checksums.has(DS_ENTRY) || checksums.has(LEGACY_DS_ENTRY))
            ) { "Required legacy entries are not protected" }
        }

        val extracted = staging.walkTopDown()
            .filter { it.isFile }
            .map { it.relativeTo(staging).invariantSeparatorsPath }
            .filter { it != MANIFEST_ENTRY }
            .toList()
        require(extracted.all { checksums.has(it) }) { "Backup contains unprotected data entries" }
        require(extracted.size == protectedCount) { "Backup checksum table does not match extracted data" }
    }

    private fun firstExisting(vararg files: File): File? = files.firstOrNull { it.isFile }

    private fun copyFileChecked(source: File, target: File) {
        require(source.isFile) { "Source file does not exist: ${source.name}" }
        target.parentFile?.mkdirs()
        FileInputStream(source).use { input ->
            FileOutputStream(target).use { output ->
                input.copyTo(output)
                output.fd.sync()
            }
        }
        require(target.isFile && target.length() == source.length()) {
            "File copy verification failed: ${source.name}"
        }
    }

    private fun quickCheckSqlite(file: File): Boolean = try {
        val db = SQLiteDatabase.openDatabase(file.absolutePath, null, SQLiteDatabase.OPEN_READONLY)
        db.use {
            it.rawQuery("PRAGMA quick_check", null).use { cursor ->
                cursor.moveToFirst() && cursor.getString(0).equals("ok", ignoreCase = true)
            }
        }
    } catch (e: Exception) {
        Log.e(TAG, "SQLite quick_check failed for ${file.name}", e)
        false
    }

    private fun sha256(file: File): String {
        val digest = MessageDigest.getInstance("SHA-256")
        FileInputStream(file).use { input ->
            val buffer = ByteArray(128 * 1024)
            while (true) {
                val read = input.read(buffer)
                if (read <= 0) break
                digest.update(buffer, 0, read)
            }
        }
        return BackupZipIO.hex(digest.digest())
    }

    private fun sqlPath(file: File): String = file.absolutePath.replace("'", "''")
}
