package com.tebogo.markvault.data

import android.content.Context
import android.net.Uri
import android.util.Log
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONObject
import java.io.File
import java.util.zip.ZipEntry
import java.util.zip.ZipInputStream
import java.util.zip.ZipOutputStream

/**
 * v5.4.142cc — Backup and restore for all MarkVault app data.
 *
 * **What is backed up:**
 *   • `markvault.db`  — the full Room database, which contains:
 *       - The note index (all scanned file metadata)
 *       - FTS (full-text search) index
 *       - Semantic embeddings (note_embeddings table)
 *       - Favourites (notes.favourite column)
 *       - Web bookmarks (web_bookmarks table)
 *       - Web browsing history (web_history table)
 *       - PDF view history (pdf_history table)
 *       - PDF annotations (pdf_annotations table)
 *       - Topic assignments (note_topics table)
 *       - Wiki-link graph (note_links table)
 *   • `settings.preferences_pb` — the DataStore preferences file, which holds
 *       every setting exposed in the Settings screen:
 *         theme, font scale, search configuration, AI/LLM toggles, reranker
 *         choice, chip visibility, home screen layout, browser tabs, search
 *         screen setup, motion profile, dedup flags, and more.
 *
 * **What is NOT backed up:**
 *   - The article library files (those live in the user-chosen SAF folder).
 *   - Downloaded AI / embedding model files (large; re-downloadable from Settings).
 *
 * **Backup format:** a ZIP file with three entries:
 *   - `manifest.json`          — version + timestamp metadata
 *   - `markvault.db`           — SQLite database (after WAL checkpoint)
 *   - `settings.preferences_pb`— DataStore protobuf file
 *
 * **Restore flow:**
 *   1. Extract entries to temp files.
 *   2. Close Room so no file locks remain.
 *   3. Delete stale WAL/SHM sidecars.
 *   4. Atomically rename temp files over the live files.
 *   The caller must kill and restart the process for Room and DataStore to
 *   reinitialise from the newly restored files.
 */
object BackupManager {

    private const val TAG = "MV-BackupManager"

    private const val MANIFEST_ENTRY = "manifest.json"
    private const val DB_ENTRY       = "markvault.db"
    private const val DS_ENTRY       = "settings.preferences_pb"

    // ── File path helpers ────────────────────────────────────────────────────

    /** Primary Room database file. */
    fun databaseFile(ctx: Context): File = ctx.getDatabasePath("markvault.db")

    /** WAL sidecar — must be deleted before a restore so Room opens cleanly. */
    private fun databaseWal(ctx: Context): File = ctx.getDatabasePath("markvault.db-wal")

    /** Shared memory sidecar — same reason. */
    private fun databaseShm(ctx: Context): File = ctx.getDatabasePath("markvault.db-shm")

    /**
     * DataStore file. `preferencesDataStore(name = "settings")` places the
     * protobuf at `{context.filesDir}/datastore/settings.preferences_pb`.
     */
    fun datastoreFile(ctx: Context): File =
        File(ctx.filesDir, "datastore/settings.preferences_pb")

    // ── Public API ───────────────────────────────────────────────────────────

    /**
     * Write a backup ZIP to [destUri] (SAF output stream from CreateDocument).
     *
     * Steps:
     *  1. PRAGMA wal_checkpoint(TRUNCATE) — flush the WAL into the main .db file
     *     so the snapshot is self-consistent without requiring WAL replay.
     *  2. Stream `markvault.db` and `settings.preferences_pb` into the ZIP.
     *  3. Prepend a `manifest.json` with version + timestamp for validation.
     *
     * Returns true on success, false on any error.
     */
    suspend fun createBackup(
        ctx: Context,
        destUri: Uri,
        versionName: String
    ): Boolean = withContext(Dispatchers.IO) {
        try {
            // Flush WAL so the .db file is a complete, self-consistent snapshot.
            runCatching {
                VaultDb.get(ctx)
                    .openHelper
                    .writableDatabase
                    .execSQL("PRAGMA wal_checkpoint(TRUNCATE)")
            }.onFailure { Log.w(TAG, "WAL checkpoint skipped: ${it.message}") }

            val manifest = JSONObject().apply {
                put("app",       "MarkVault")
                put("version",   versionName)
                put("timestamp", System.currentTimeMillis())
                put("db_entry",  DB_ENTRY)
                put("ds_entry",  DS_ENTRY)
            }.toString(2)

            ctx.contentResolver.openOutputStream(destUri)?.buffered()?.use { raw ->
                ZipOutputStream(raw).use { zip ->
                    // manifest.json
                    zip.putNextEntry(ZipEntry(MANIFEST_ENTRY))
                    zip.write(manifest.toByteArray(Charsets.UTF_8))
                    zip.closeEntry()

                    // Room database
                    val dbFile = databaseFile(ctx)
                    if (dbFile.exists()) {
                        zip.putNextEntry(ZipEntry(DB_ENTRY))
                        dbFile.inputStream().use { it.copyTo(zip) }
                        zip.closeEntry()
                        Log.d(TAG, "DB added: ${dbFile.length()} bytes")
                    } else {
                        Log.w(TAG, "DB file not found — skipped")
                    }

                    // DataStore preferences
                    val dsFile = datastoreFile(ctx)
                    if (dsFile.exists()) {
                        zip.putNextEntry(ZipEntry(DS_ENTRY))
                        dsFile.inputStream().use { it.copyTo(zip) }
                        zip.closeEntry()
                        Log.d(TAG, "DataStore added: ${dsFile.length()} bytes")
                    } else {
                        Log.w(TAG, "DataStore file not found — skipped")
                    }
                }
            } ?: return@withContext false.also { Log.e(TAG, "Could not open output stream") }

            Log.i(TAG, "Backup written to $destUri")
            true
        } catch (e: Exception) {
            Log.e(TAG, "createBackup failed", e)
            false
        }
    }

    /**
     * Read and return the manifest JSON from a backup ZIP [srcUri] without
     * extracting the database or DataStore files.
     *
     * Returns a [JSONObject] on success, or null if [srcUri] is not a valid
     * MarkVault backup.  The UI uses this to show the backup date + version
     * in the restore-confirmation dialog before any data is touched.
     */
    suspend fun readManifest(ctx: Context, srcUri: Uri): JSONObject? =
        withContext(Dispatchers.IO) {
            try {
                ctx.contentResolver.openInputStream(srcUri)?.buffered()?.use { raw ->
                    ZipInputStream(raw).use { zip ->
                        var entry = zip.nextEntry
                        while (entry != null) {
                            if (entry.name == MANIFEST_ENTRY) {
                                val json = JSONObject(zip.readBytes().toString(Charsets.UTF_8))
                                // Must carry the "app" field to be considered valid.
                                return@withContext if (json.optString("app") == "MarkVault") json else null
                            }
                            zip.closeEntry()
                            entry = zip.nextEntry
                        }
                    }
                }
                null
            } catch (e: Exception) {
                Log.e(TAG, "readManifest failed", e)
                null
            }
        }

    /**
     * Extract and apply a backup ZIP [srcUri] to the app's data directory.
     *
     * Steps:
     *  1. Stream entries to temp files (never partially overwrites live files).
     *  2. Close Room so the database file lock is released.
     *  3. Delete WAL/SHM sidecars so Room opens cleanly after restart.
     *  4. Atomically rename each temp file over the corresponding live file.
     *
     * The caller is responsible for killing and restarting the process so that
     * Room, DataStore, and all in-memory caches reinitialise from scratch.
     *
     * Returns true on success, false on any error (temp files are cleaned up).
     */
    suspend fun applyBackup(ctx: Context, srcUri: Uri): Boolean =
        withContext(Dispatchers.IO) {
            val dbTarget = databaseFile(ctx)
            val dsTarget = datastoreFile(ctx)
            val dbTemp   = File(dbTarget.parent, "${DB_ENTRY}.restore_tmp")
            val dsTemp   = File(dsTarget.parent, "${DS_ENTRY}.restore_tmp")

            dbTarget.parentFile?.mkdirs()
            dsTarget.parentFile?.mkdirs()

            try {
                // Extract entries into temp files
                ctx.contentResolver.openInputStream(srcUri)?.buffered()?.use { raw ->
                    ZipInputStream(raw).use { zip ->
                        var entry = zip.nextEntry
                        while (entry != null) {
                            when (entry.name) {
                                DB_ENTRY -> {
                                    dbTemp.outputStream().use { zip.copyTo(it) }
                                    Log.d(TAG, "DB extracted: ${dbTemp.length()} bytes")
                                }
                                DS_ENTRY -> {
                                    dsTemp.outputStream().use { zip.copyTo(it) }
                                    Log.d(TAG, "DS extracted: ${dsTemp.length()} bytes")
                                }
                            }
                            zip.closeEntry()
                            entry = zip.nextEntry
                        }
                    }
                } ?: return@withContext false.also {
                    Log.e(TAG, "Could not open input stream for restore")
                    dbTemp.delete()
                    dsTemp.delete()
                }

                // Close Room so it releases its file lock on markvault.db
                runCatching { VaultDb.get(ctx).close() }
                    .onFailure { Log.w(TAG, "Room.close() warning: ${it.message}") }

                // Remove WAL/SHM sidecars — stale WAL replayed on top of a
                // different DB snapshot would corrupt the restored database.
                databaseWal(ctx).delete()
                databaseShm(ctx).delete()

                // Atomically rename temp files over live files
                if (dbTemp.exists()) {
                    dbTarget.delete()
                    val ok = dbTemp.renameTo(dbTarget)
                    Log.d(TAG, "DB rename → $ok")
                }
                if (dsTemp.exists()) {
                    dsTarget.delete()
                    val ok = dsTemp.renameTo(dsTarget)
                    Log.d(TAG, "DS rename → $ok")
                }

                Log.i(TAG, "Restore complete")
                true
            } catch (e: Exception) {
                Log.e(TAG, "applyBackup failed", e)
                dbTemp.delete()
                dsTemp.delete()
                false
            }
        }
}
