package com.tebogo.markvault.data

import android.content.Context
import android.database.sqlite.SQLiteDatabase
import android.net.Uri
import android.os.StatFs
import android.util.Log
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONObject
import java.io.ByteArrayOutputStream
import java.io.File
import java.io.FileInputStream
import java.io.FileOutputStream
import java.nio.file.Files
import java.nio.file.StandardCopyOption
import java.security.MessageDigest
import java.util.zip.ZipEntry
import java.util.zip.ZipInputStream
import java.util.zip.ZipOutputStream

/**
 * MarkVault backup / restore.
 *
 * Backup v2 contains the Room database, DataStore preferences, cached song
 * lyrics, cached video transcripts, and the activity log when present.
 * Article-library files and downloaded AI/model files are intentionally not
 * included because they live outside app-private state or are re-downloadable.
 *
 * Safety properties:
 *  • Backup never reports success unless required DB + DataStore snapshots exist.
 *  • Every v2 entry is SHA-256 + size protected in manifest.json.
 *  • Restore extracts only recognised paths into a staging directory first.
 *  • SQLite is quick-checked before the live database is touched.
 *  • The old database/cache directories are retained as rollback copies until
 *    every replacement succeeds.
 *  • DataStore is NOT replaced while its singleton may be alive. It is staged
 *    and installed at the very beginning of the next Application.onCreate().
 */
object BackupManager {

    private const val TAG = "MV-BackupManager"
    private const val FORMAT_VERSION = 2
    // VaultDb supplies explicit migrations for every schema from 11 through 20.
    // Installing anything outside this range would make Room fall back to a
    // destructive migration, which is never acceptable during restore.
    private const val MIN_RESTORABLE_DB_SCHEMA = 11
    private const val CURRENT_DB_SCHEMA = 20
    private const val MAX_MANIFEST_BYTES = 16L * 1024L * 1024L
    private const val RESTORE_FREE_SPACE_RESERVE = 128L * 1024L * 1024L

    private const val MANIFEST_ENTRY = "manifest.json"
    private const val DB_ENTRY = "database/markvault.db"
    private const val DS_ENTRY = "settings/settings.preferences_pb"
    private const val LYRICS_PREFIX = "media/song_lyrics/"
    private const val TRANSCRIPTS_PREFIX = "media/video_transcripts/"
    private const val ACTIVITY_ENTRY = "optional/activity_log.jsonl"

    // Legacy v1 entry names, retained so old backups remain restorable.
    private const val LEGACY_DB_ENTRY = "markvault.db"
    private const val LEGACY_DS_ENTRY = "settings.preferences_pb"

    private const val PENDING_DIR = "restore_pending"
    private const val PENDING_DS = "settings.preferences_pb"
    private const val PENDING_MARKER = "pending_datastore_restore"

    // Crash-recovery transaction kept in filesDir rather than cacheDir. Android
    // may clear cache at any time, including while the process is not running.
    private const val RESTORE_JOURNAL_DIR = "restore_transaction"
    private const val RESTORE_JOURNAL_FILE = "journal.json"
    private const val RESTORE_PHASE_PREPARED = "prepared"
    private const val RESTORE_PHASE_COMMITTED = "committed"

    data class Progress(val phase: String, val percent: Int?, val detail: String = phase)

    class BackupStoppedException : RuntimeException("Backup/restore stopped by user")

    @Volatile
    var lastFailureReason: String? = null
        private set

    /** True once a restore has closed Room; cached DAOs require a cold restart. */
    @Volatile
    var restartRequiredAfterRestoreAttempt: Boolean = false
        private set

    private data class BackupSource(val entryName: String, val file: File)

    private data class ExpectedArchiveEntry(val size: Long, val sha256: String)

    private data class ArchiveVerification(val ok: Boolean, val reason: String = "")

    private data class SqliteCheckResult(
        val ok: Boolean,
        val messages: List<String>,
        val userVersion: Int? = null
    ) {
        val summary: String
            get() = messages.joinToString("; ").ifBlank { "unknown SQLite validation error" }
    }

    fun databaseFile(ctx: Context): File = ctx.getDatabasePath("markvault.db")
    private fun databaseWal(ctx: Context): File = ctx.getDatabasePath("markvault.db-wal")
    private fun databaseShm(ctx: Context): File = ctx.getDatabasePath("markvault.db-shm")

    fun datastoreFile(ctx: Context): File =
        File(ctx.filesDir, "datastore/settings.preferences_pb")

    private fun lyricsDir(ctx: Context): File = File(ctx.filesDir, "song_lyrics")
    private fun transcriptsDir(ctx: Context): File = File(ctx.filesDir, "video_transcripts")
    private fun activityLogFile(ctx: Context): File = File(ctx.filesDir, "activity_log.jsonl")

    private fun restoreJournalRoot(ctx: Context): File = File(ctx.filesDir, RESTORE_JOURNAL_DIR)

    /**
     * Runs before DataStore is opened. If the previous process died during a
     * restore, put every original file back before the pending settings file
     * can be applied. A committed journal only needs stale rollback cleanup.
     */
    fun recoverInterruptedRestore(ctx: Context) {
        val root = restoreJournalRoot(ctx)
        val journalFile = File(root, RESTORE_JOURNAL_FILE)
        if (!journalFile.isFile) return

        val journal = runCatching { JSONObject(journalFile.readText(Charsets.UTF_8)) }
            .getOrElse {
                Log.e(TAG, "Restore journal is unreadable; leaving it for manual recovery", it)
                return
            }
        if (journal.optString("phase") == RESTORE_PHASE_COMMITTED) {
            root.deleteRecursively()
            return
        }

        if (rollbackFromJournal(ctx, root, journal)) {
            File(ctx.filesDir, PENDING_DIR).deleteRecursively()
            root.deleteRecursively()
            Log.w(TAG, "Recovered data from an interrupted restore")
        } else {
            Log.e(TAG, "Interrupted restore recovery was incomplete; rollback data retained")
        }
    }

    private fun prepareRestoreJournal(ctx: Context): Pair<File, JSONObject> {
        val root = restoreJournalRoot(ctx)
        require(!root.exists()) {
            "An interrupted restore is awaiting recovery. Close and reopen MarkVault, then try again."
        }
        require(root.mkdirs()) { "Could not create persistent restore rollback directory" }
        return try {
            val journal = JSONObject().apply {
                put("phase", RESTORE_PHASE_PREPARED)
                put("had_database", databaseFile(ctx).exists())
                put("had_lyrics", lyricsDir(ctx).exists())
                put("had_transcripts", transcriptsDir(ctx).exists())
                put("had_activity", activityLogFile(ctx).exists())
                put("created_at", System.currentTimeMillis())
            }
            writeJsonSynced(File(root, RESTORE_JOURNAL_FILE), journal)
            root to journal
        } catch (e: Exception) {
            // No live file has moved yet. Do not leave an uninitialised root
            // that would permanently block every later restore attempt.
            root.deleteRecursively()
            throw e
        }
    }

    private fun markRestoreCommitted(root: File, journal: JSONObject) {
        journal.put("phase", RESTORE_PHASE_COMMITTED)
        writeJsonSynced(File(root, RESTORE_JOURNAL_FILE), journal)
    }

    private fun writeJsonSynced(file: File, json: JSONObject) {
        file.parentFile?.mkdirs()
        val incoming = File(file.parentFile, "${file.name}.incoming")
        incoming.delete()
        FileOutputStream(incoming).use { output ->
            output.write(json.toString().toByteArray(Charsets.UTF_8))
            output.fd.sync()
        }
        try {
            Files.move(
                incoming.toPath(),
                file.toPath(),
                StandardCopyOption.ATOMIC_MOVE,
                StandardCopyOption.REPLACE_EXISTING
            )
        } catch (_: java.nio.file.AtomicMoveNotSupportedException) {
            Files.move(incoming.toPath(), file.toPath(), StandardCopyOption.REPLACE_EXISTING)
        }
    }

    private fun rollbackFromJournal(ctx: Context, root: File, journal: JSONObject): Boolean =
        runCatching {
            restoreFileFromRollback(
                databaseFile(ctx),
                File(root, "markvault.db"),
                journal.optBoolean("had_database")
            )
            databaseWal(ctx).delete()
            databaseShm(ctx).delete()
            File(databaseFile(ctx).parentFile, "markvault.db.restore_incoming").delete()

            restoreDirectoryFromRollback(
                lyricsDir(ctx),
                File(root, "song_lyrics"),
                journal.optBoolean("had_lyrics")
            )
            restoreDirectoryFromRollback(
                transcriptsDir(ctx),
                File(root, "video_transcripts"),
                journal.optBoolean("had_transcripts")
            )
            restoreFileFromRollback(
                activityLogFile(ctx),
                File(root, "activity_log.jsonl"),
                journal.optBoolean("had_activity")
            )
            true
        }.getOrElse {
            Log.e(TAG, "Restore rollback failed", it)
            false
        }

    private fun restoreFileFromRollback(target: File, rollback: File, hadOriginal: Boolean) {
        when {
            rollback.exists() -> {
                target.delete()
                target.parentFile?.mkdirs()
                require(rollback.renameTo(target)) { "Could not restore ${target.name}" }
            }
            !hadOriginal -> target.delete()
            // If the original existed but no rollback copy exists, the move
            // never happened; leave the still-live original untouched.
        }
    }

    private fun restoreDirectoryFromRollback(target: File, rollback: File, hadOriginal: Boolean) {
        when {
            rollback.exists() -> {
                target.deleteRecursively()
                target.parentFile?.mkdirs()
                require(rollback.renameTo(target)) { "Could not restore ${target.name}" }
            }
            !hadOriginal -> target.deleteRecursively()
        }
    }

    /**
     * Called before any DataStore-backed UI is created. A restore stages the
     * protobuf while the old process is alive; the next cold process installs
     * it here, before MarkVault creates its preference DataStore delegate.
     */
    fun applyPendingDatastoreRestore(ctx: Context) {
        // Never apply restored settings while an unresolved restore journal
        // exists. recoverInterruptedRestore() runs immediately before this;
        // a remaining journal means rollback could not be completed safely.
        if (File(restoreJournalRoot(ctx), RESTORE_JOURNAL_FILE).exists()) {
            Log.e(TAG, "Pending DataStore restore deferred until database rollback is recovered")
            return
        }
        val pendingRoot = File(ctx.filesDir, PENDING_DIR)
        val marker = File(pendingRoot, PENDING_MARKER)
        val staged = File(pendingRoot, PENDING_DS)
        if (!marker.exists()) return

        val target = datastoreFile(ctx)
        val rollback = File(target.parentFile, "${target.name}.pre_restore")
        val incoming = File(target.parentFile, "${target.name}.restore_incoming")
        try {
            require(staged.isFile && staged.length() > 0L) {
                "Pending DataStore restore is missing or empty"
            }
            target.parentFile?.mkdirs()
            incoming.delete()
            copyFileChecked(staged, incoming)

            // A rollback left beside the target means the previous process
            // died while applying these same pending settings. Keep that
            // original until the replacement is installed and verified.
            if (target.exists() && !rollback.exists()) {
                require(target.renameTo(rollback)) { "Could not create DataStore rollback copy" }
            } else if (target.exists()) {
                require(target.delete()) { "Could not replace partially restored settings" }
            }
            try {
                require(incoming.renameTo(target)) { "Could not install restored settings" }
                require(target.isFile && target.length() == staged.length() &&
                    sha256(target) == sha256(staged)) {
                    "Restored DataStore verification failed"
                }
                require(!rollback.exists() || rollback.delete()) {
                    "Could not remove DataStore rollback copy"
                }
                // Marker removal commits this small startup transaction. If
                // the process dies afterward, an orphan staged copy is inert;
                // the reverse order could leave a live marker with no payload.
                if (marker.delete()) {
                    staged.delete()
                    pendingRoot.delete()
                } else {
                    // Keep the staged payload so a surviving marker always has
                    // something complete to retry on the next cold start.
                    Log.w(TAG, "Restored settings installed; pending marker cleanup will retry")
                }
                Log.i(TAG, "Pending DataStore restore applied")
            } catch (e: Exception) {
                target.delete()
                if (rollback.exists()) {
                    require(rollback.renameTo(target)) { "Could not restore original settings" }
                }
                throw e
            }
        } catch (e: Exception) {
            // Do not let DataStore open on an absent/partial target if a prior
            // startup was interrupted after protecting the original file.
            if (rollback.exists()) {
                target.delete()
                if (!rollback.renameTo(target)) {
                    Log.e(TAG, "Could not restore original preferences after apply failure")
                }
            }
            Log.e(TAG, "Pending DataStore restore failed; original preferences retained", e)
        } finally {
            incoming.delete()
        }
    }

    suspend fun createBackup(
        ctx: Context,
        destUri: Uri,
        versionName: String,
        onProgress: (Progress) -> Unit = {},
        shouldStop: () -> Boolean = { false }
    ): Boolean = withContext(Dispatchers.IO) {
        lastFailureReason = null
        val tempRoot = File(ctx.cacheDir, "backup_staging_${System.nanoTime()}")
        try {
            checkStop(shouldStop)
            onProgress(Progress("Checking storage", 2, "Checking available storage…"))
            val preflight = backupPreflight(ctx, destUri)
            if (!preflight.ok) {
                lastFailureReason = preflight.reason
                Log.e(TAG, "Backup preflight failed: ${preflight.reason}")
                return@withContext false
            }

            tempRoot.mkdirs()
            onProgress(Progress("Database snapshot", 8, "Creating a consistent database snapshot…"))
            val dbSnapshot = File(tempRoot, "markvault.db")
            val dsSnapshot = File(tempRoot, "settings.preferences_pb")

            if (!createDatabaseSnapshot(ctx, dbSnapshot)) {
                lastFailureReason = "Database snapshot could not be created."
                Log.e(TAG, "Backup aborted: database snapshot could not be created")
                return@withContext false
            }
            checkStop(shouldStop)
            onProgress(Progress("Database validation", 28, "Validating database snapshot…"))
            var dbCheck = if (dbSnapshot.isFile && dbSnapshot.length() > 0L) {
                quickCheckSqlite(dbSnapshot)
            } else {
                SqliteCheckResult(false, listOf("snapshot file is missing or empty"))
            }
            if (!dbCheck.ok) {
                // notes_fts is fully derived from notes. Older indexer builds
                // used INSERT OR REPLACE, whose implicit conflict deletion can
                // bypass FTS delete triggers and leave stale index rows. Repair
                // only the isolated snapshot, never the live database, then run
                // the complete integrity gate again. Physical corruption still
                // fails closed.
                onProgress(Progress("Database validation", 30, "Refreshing the backup search index…"))
                Log.w(TAG, "Initial snapshot validation failed: ${dbCheck.summary}")
                if (rebuildDerivedFtsIndex(dbSnapshot)) {
                    dbCheck = quickCheckSqlite(dbSnapshot)
                }
            }
            if (!dbCheck.ok) {
                lastFailureReason = "Database snapshot failed integrity validation."
                Log.e(TAG, "Backup aborted: database snapshot failed validation: ${dbCheck.summary}")
                return@withContext false
            }
            if (dbCheck.userVersion != CURRENT_DB_SCHEMA) {
                lastFailureReason = "Database snapshot has unsupported schema version ${dbCheck.userVersion ?: "unknown"}."
                Log.e(TAG, "Backup aborted: unexpected live database schema ${dbCheck.userVersion}")
                return@withContext false
            }

            checkStop(shouldStop)
            onProgress(Progress("Settings snapshot", 34, "Copying MarkVault settings…"))

            val dsLive = datastoreFile(ctx)
            if (!dsLive.isFile || dsLive.length() <= 0L) {
                lastFailureReason = "Settings file is missing or empty."
                Log.e(TAG, "Backup aborted: DataStore file is missing or empty")
                return@withContext false
            }
            copyFileChecked(dsLive, dsSnapshot)
            if (!dsSnapshot.isFile || dsSnapshot.length() != dsLive.length()) {
                lastFailureReason = "Settings snapshot failed validation."
                Log.e(TAG, "Backup aborted: DataStore snapshot failed validation")
                return@withContext false
            }

            val sources = mutableListOf(
                BackupSource(DB_ENTRY, dbSnapshot),
                BackupSource(DS_ENTRY, dsSnapshot)
            )
            addDirectorySources(lyricsDir(ctx), LYRICS_PREFIX, sources)
            addDirectorySources(transcriptsDir(ctx), TRANSCRIPTS_PREFIX, sources)
            val activity = activityLogFile(ctx)
            if (activity.isFile) sources += BackupSource(ACTIVITY_ENTRY, activity)

            checkStop(shouldStop)
            onProgress(Progress("Integrity manifest", 40, "Calculating backup checksums…"))
            val checksums = JSONObject()
            val sizes = JSONObject()
            val expectedEntries = linkedMapOf<String, ExpectedArchiveEntry>()
            sources.forEachIndexed { index, source ->
                checkStop(shouldStop)
                val checksum = sha256(source.file, shouldStop)
                checksums.put(source.entryName, checksum)
                sizes.put(source.entryName, source.file.length())
                expectedEntries[source.entryName] = ExpectedArchiveEntry(source.file.length(), checksum)
                val pct = 40 + (((index + 1).toDouble() / sources.size.coerceAtLeast(1)) * 10.0).toInt()
                onProgress(Progress("Integrity manifest", pct.coerceAtMost(50), "Verifying ${index + 1} / ${sources.size} backup items…"))
            }

            require(expectedEntries.size == sources.size) { "Duplicate backup entry name" }
            val manifestBytes = JSONObject().apply {
                put("app", "MarkVault")
                put("format_version", FORMAT_VERSION)
                put("version", versionName)
                put("timestamp", System.currentTimeMillis())
                put("db_schema_version", dbCheck.userVersion)
                put("db_entry", DB_ENTRY)
                put("ds_entry", DS_ENTRY)
                put("lyrics_count", sources.count { it.entryName.startsWith(LYRICS_PREFIX) })
                put("transcripts_count", sources.count { it.entryName.startsWith(TRANSCRIPTS_PREFIX) })
                put("checksums", checksums)
                put("sizes", sizes)
            }.toString(2).toByteArray(Charsets.UTF_8)
            expectedEntries[MANIFEST_ENTRY] = ExpectedArchiveEntry(
                manifestBytes.size.toLong(),
                sha256(manifestBytes)
            )

            checkStop(shouldStop)
            onProgress(Progress("Writing backup", 50, "Writing backup file…"))
            val totalBytes = sources.sumOf { it.file.length().coerceAtLeast(0L) }.coerceAtLeast(1L)
            var writtenBytes = 0L
            val out = ctx.contentResolver.openOutputStream(destUri, "w")
                ?: return@withContext false.also {
                    lastFailureReason = "The selected backup destination could not be opened for writing."
                    Log.e(TAG, "Could not open backup output stream")
                }
            out.buffered().use { raw ->
                ZipOutputStream(raw).use { zip ->
                    zip.putNextEntry(ZipEntry(MANIFEST_ENTRY))
                    zip.write(manifestBytes)
                    zip.closeEntry()

                    for (source in sources) {
                        checkStop(shouldStop)
                        zip.putNextEntry(ZipEntry(source.entryName))
                        FileInputStream(source.file).use { input ->
                            val buffer = ByteArray(256 * 1024)
                            while (true) {
                                checkStop(shouldStop)
                                val read = input.read(buffer)
                                if (read <= 0) break
                                zip.write(buffer, 0, read)
                                writtenBytes += read
                                val pct = 50 + ((writtenBytes.toDouble() / totalBytes) * 48.0).toInt()
                                onProgress(Progress("Writing backup", pct.coerceIn(50, 98), "Writing ${formatBytes(writtenBytes)} / ${formatBytes(totalBytes)}…"))
                            }
                        }
                        zip.closeEntry()
                    }
                }
            }

            checkStop(shouldStop)
            onProgress(Progress("Final verification", 99, "Reading back and verifying the completed backup…"))
            val archiveVerification = verifyWrittenBackup(ctx, destUri, expectedEntries, shouldStop)
            if (!archiveVerification.ok) {
                lastFailureReason = "Backup file failed final verification: ${archiveVerification.reason}"
                Log.e(TAG, lastFailureReason.orEmpty())
                return@withContext false
            }

            checkStop(shouldStop)
            onProgress(Progress("Complete", 100, "Backup saved and verified."))
            Log.i(TAG, "Backup written: ${sources.size} protected data entries")
            true
        } catch (e: BackupStoppedException) {
            lastFailureReason = "Backup stopped by user."
            Log.i(TAG, "Backup stopped by user")
            throw e
        } catch (e: Exception) {
            lastFailureReason = e.message?.takeIf { it.isNotBlank() } ?: "Backup failed due to an unexpected I/O error."
            Log.e(TAG, "createBackup failed", e)
            false
        } finally {
            tempRoot.deleteRecursively()
        }
    }

    /**
     * Returns manifest only when the ZIP is structurally a restorable MarkVault
     * backup. Required DB + DataStore entries must both be present.
     */
    suspend fun readManifest(ctx: Context, srcUri: Uri): JSONObject? =
        withContext(Dispatchers.IO) {
            try {
                var manifest: JSONObject? = null
                var hasDb = false
                var hasDs = false
                ctx.contentResolver.openInputStream(srcUri)?.buffered()?.use { raw ->
                    ZipInputStream(raw).use { zip ->
                        var entry = zip.nextEntry
                        while (entry != null) {
                            when (entry.name) {
                                MANIFEST_ENTRY -> manifest = JSONObject(
                                    readZipEntryLimited(zip, MAX_MANIFEST_BYTES)
                                        .toString(Charsets.UTF_8)
                                )
                                DB_ENTRY, LEGACY_DB_ENTRY -> hasDb = true
                                DS_ENTRY, LEGACY_DS_ENTRY -> hasDs = true
                            }
                            zip.closeEntry()
                            entry = zip.nextEntry
                        }
                    }
                } ?: return@withContext null

                val json = manifest ?: return@withContext null
                val format = json.optInt("format_version", 1)
                if (json.optString("app") != "MarkVault" || !hasDb || !hasDs ||
                    format !in 1..FORMAT_VERSION) return@withContext null
                json
            } catch (e: Exception) {
                Log.e(TAG, "readManifest failed", e)
                null
            }
        }

    suspend fun applyBackup(
        ctx: Context,
        srcUri: Uri,
        onProgress: (Progress) -> Unit = {},
        shouldStop: () -> Boolean = { false }
    ): Boolean = withContext(Dispatchers.IO) {
            lastFailureReason = null
            restartRequiredAfterRestoreAttempt = false
            val staging = File(ctx.cacheDir, "restore_staging_${System.nanoTime()}")
            var rollbackRoot: File? = null
            var restoreJournal: JSONObject? = null

            val dbTarget = databaseFile(ctx)
            val lyricsTarget = lyricsDir(ctx)
            val transcriptsTarget = transcriptsDir(ctx)
            val activityTarget = activityLogFile(ctx)

            try {
                checkStop(shouldStop)
                onProgress(Progress("Checking backup", 3, "Checking backup file and temporary storage…"))
                val restorePreflight = restorePreflight(ctx, srcUri)
                if (!restorePreflight.ok) throw IllegalStateException(restorePreflight.reason)

                staging.mkdirs()
                checkStop(shouldStop)
                onProgress(Progress("Reading backup", 10, "Reading backup contents…"))
                val manifest = extractRecognisedEntries(ctx, srcUri, staging, shouldStop)
                    ?: throw IllegalArgumentException("Backup is missing a valid manifest")
                val formatVersion = manifest.optInt("format_version", 1)
                require(formatVersion in 1..FORMAT_VERSION) {
                    "Backup format $formatVersion is not supported by this MarkVault version"
                }

                val stagedBytes = staging.walkTopDown()
                    .filter { it.isFile }
                    .sumOf { it.length().coerceAtLeast(0L) }
                val installAvailable = StatFs(ctx.filesDir.absolutePath).availableBytes
                val installNeed = stagedBytes + RESTORE_FREE_SPACE_RESERVE
                require(installAvailable >= installNeed) {
                    "Not enough internal space to install the verified backup. Need about " +
                        "${formatBytes(installNeed)}, available ${formatBytes(installAvailable)}."
                }

                val stagedDb = firstExisting(
                    File(staging, DB_ENTRY),
                    File(staging, LEGACY_DB_ENTRY)
                ) ?: throw IllegalArgumentException("Backup database is missing")
                val stagedDs = firstExisting(
                    File(staging, DS_ENTRY),
                    File(staging, LEGACY_DS_ENTRY)
                ) ?: throw IllegalArgumentException("Backup settings are missing")

                require(stagedDb.length() > 0L) { "Backup database is empty" }
                require(stagedDs.length() > 0L) { "Backup settings are empty" }

                checkStop(shouldStop)
                onProgress(Progress("Validating backup", 48, "Validating checksums and database integrity…"))
                if (formatVersion >= 2) verifyManifestProtectedEntries(manifest, staging, shouldStop)
                var stagedCheck = quickCheckSqlite(stagedDb)
                if (!stagedCheck.ok && rebuildDerivedFtsIndex(stagedDb)) {
                    stagedCheck = quickCheckSqlite(stagedDb)
                }
                require(stagedCheck.ok) {
                    "Backup database failed integrity validation: ${stagedCheck.summary}"
                }
                val stagedSchema = stagedCheck.userVersion
                    ?: throw IllegalArgumentException("Backup database schema version is missing")
                require(stagedSchema in MIN_RESTORABLE_DB_SCHEMA..CURRENT_DB_SCHEMA) {
                    "Backup database schema $stagedSchema is not safely restorable by this MarkVault version"
                }
                if (manifest.has("db_schema_version")) {
                    require(manifest.optInt("db_schema_version", -1) == stagedSchema) {
                        "Backup manifest database schema does not match its database"
                    }
                }

                checkStop(shouldStop)
                onProgress(Progress("Preparing restore", 65, "Preparing a safe rollback point…"))
                val preparedJournal = prepareRestoreJournal(ctx)
                rollbackRoot = preparedJournal.first
                restoreJournal = preparedJournal.second
                // Stage DataStore for next process BEFORE touching current live data.
                val pendingRoot = File(ctx.filesDir, PENDING_DIR).apply { mkdirs() }
                val pendingDs = File(pendingRoot, PENDING_DS)
                val pendingMarker = File(pendingRoot, PENDING_MARKER)
                pendingDs.delete()
                copyFileChecked(stagedDs, pendingDs)
                require(pendingDs.length() == stagedDs.length()) { "Could not stage restored settings" }
                FileOutputStream(pendingMarker).use { markerOutput ->
                    markerOutput.write("ready".toByteArray(Charsets.UTF_8))
                    markerOutput.fd.sync()
                }

                checkStop(shouldStop)
                VaultDb.closeForRestore()
                restartRequiredAfterRestoreAttempt = true
                onProgress(Progress("Restoring database", 74, "Replacing database with rollback protection…"))

                val rollback = requireNotNull(rollbackRoot)
                dbTarget.parentFile?.mkdirs()
                val dbRollback = File(rollback, "markvault.db")
                if (dbTarget.exists()) {
                    require(dbTarget.renameTo(dbRollback)) { "Could not create database rollback copy" }
                }
                databaseWal(ctx).delete()
                databaseShm(ctx).delete()

                val dbIncoming = File(dbTarget.parentFile, "markvault.db.restore_incoming")
                dbIncoming.delete()
                copyFileChecked(stagedDb, dbIncoming)
                require(dbIncoming.length() == stagedDb.length()) { "Database replacement size mismatch" }
                require(dbIncoming.renameTo(dbTarget)) { "Could not install restored database" }
                val installedCheck = quickCheckSqlite(dbTarget)
                require(installedCheck.ok) {
                    "Installed database failed integrity validation: ${installedCheck.summary}"
                }
                checkStop(shouldStop)
                onProgress(Progress("Restoring media data", 86, "Restoring lyrics, transcripts, and activity data…"))

                // v2 backups explicitly represent cache directories, including empty ones.
                if (formatVersion >= 2) {
                    val lyricsRollback = File(rollback, "song_lyrics")
                    if (lyricsTarget.exists()) {
                        require(lyricsTarget.renameTo(lyricsRollback)) { "Could not protect current lyrics cache" }
                    }
                    copyDirectoryContents(File(staging, LYRICS_PREFIX.removeSuffix("/")), lyricsTarget)

                    val transcriptsRollback = File(rollback, "video_transcripts")
                    if (transcriptsTarget.exists()) {
                        require(transcriptsTarget.renameTo(transcriptsRollback)) { "Could not protect current transcript cache" }
                    }
                    copyDirectoryContents(File(staging, TRANSCRIPTS_PREFIX.removeSuffix("/")), transcriptsTarget)

                    val stagedActivity = File(staging, ACTIVITY_ENTRY)
                    val activityRollback = File(rollback, "activity_log.jsonl")
                    if (activityTarget.exists()) {
                        require(activityTarget.renameTo(activityRollback)) { "Could not protect current activity log" }
                    }
                    if (stagedActivity.isFile) {
                        copyFileChecked(stagedActivity, activityTarget)
                    }
                }

                // All live replacements succeeded. Rollback copies are no longer needed.
                checkStop(shouldStop)
                onProgress(Progress("Complete", 100, "Restore complete. MarkVault will restart cleanly."))
                markRestoreCommitted(rollback, requireNotNull(restoreJournal))
                rollback.deleteRecursively()
                Log.i(TAG, "Restore data installed; settings will be applied on next cold start")
                true
            } catch (e: Exception) {
                lastFailureReason = if (e is BackupStoppedException) "Restore stopped by user." else (e.message ?: "Restore failed.")
                Log.e(TAG, "applyBackup failed; rolling back", e)

                val rollback = rollbackRoot
                val journal = restoreJournal
                if (rollback != null && journal != null) {
                    if (rollbackFromJournal(ctx, rollback, journal)) {
                        File(ctx.filesDir, PENDING_DIR).deleteRecursively()
                        rollback.deleteRecursively()
                    } else {
                        // Leave the persistent journal and pending settings in
                        // place. Startup recovery will retry the rollback, and
                        // applyPendingDatastoreRestore() refuses to apply those
                        // settings until recovery succeeds.
                        Log.e(TAG, "Rollback retained for recovery on next cold start")
                    }
                } else {
                    File(ctx.filesDir, PENDING_DIR).deleteRecursively()
                }
                false
            } finally {
                staging.deleteRecursively()
            }
        }

    private fun createDatabaseSnapshot(ctx: Context, target: File): Boolean {
        target.delete()
        target.parentFile?.mkdirs()
        val roomDb = VaultDb.get(ctx).openHelper.writableDatabase

        // Preferred path on SQLite versions supporting VACUUM INTO: SQLite itself
        // creates the consistent standalone snapshot while MarkVault stays online.
        val escaped = target.absolutePath.replace("'", "''")
        val vacuumOk = runCatching {
            roomDb.execSQL("VACUUM INTO '$escaped'")
            target.isFile && target.length() > 0L
        }.getOrElse {
            Log.i(TAG, "VACUUM INTO unavailable; using locked checkpoint snapshot: ${it.message}")
            false
        }
        if (vacuumOk) return true

        // API 26 devices can ship older SQLite. Fallback: checkpoint first, then
        // hold a write transaction with no mutations while copying the main DB.
        // The lock prevents a concurrent writer from changing the file mid-copy.
        return runCatching {
            roomDb.execSQL("PRAGMA wal_checkpoint(TRUNCATE)")
            roomDb.beginTransaction()
            try {
                val live = databaseFile(ctx)
                require(live.isFile && live.length() > 0L) { "Live database missing" }
                copyFileChecked(live, target)
                roomDb.setTransactionSuccessful()
            } finally {
                roomDb.endTransaction()
            }
            target.isFile && target.length() > 0L
        }.getOrElse {
            Log.e(TAG, "Locked database snapshot failed", it)
            false
        }
    }

    private fun extractRecognisedEntries(
        ctx: Context,
        srcUri: Uri,
        staging: File,
        shouldStop: () -> Boolean = { false }
    ): JSONObject? {
        var manifest: JSONObject? = null
        var extractedBytes = 0L
        val maximumExtractedBytes =
            (StatFs(ctx.cacheDir.absolutePath).availableBytes - RESTORE_FREE_SPACE_RESERVE)
                .coerceAtLeast(0L)
        ctx.contentResolver.openInputStream(srcUri)?.buffered()?.use { raw ->
            ZipInputStream(raw).use { zip ->
                var entry = zip.nextEntry
                while (entry != null) {
                    checkStop(shouldStop)
                    val name = entry.name
                    if (!entry.isDirectory && isRecognisedEntry(name)) {
                        if (name == MANIFEST_ENTRY) {
                            manifest = JSONObject(
                                readZipEntryLimited(zip, MAX_MANIFEST_BYTES)
                                    .toString(Charsets.UTF_8)
                            )
                        } else {
                            val output = safeStagingFile(staging, name)
                            output.parentFile?.mkdirs()
                            FileOutputStream(output).use { fileOutput ->
                                val buffer = ByteArray(256 * 1024)
                                while (true) {
                                    checkStop(shouldStop)
                                    val read = zip.read(buffer)
                                    if (read < 0) break
                                    if (read == 0) continue
                                    extractedBytes += read
                                    require(extractedBytes <= maximumExtractedBytes) {
                                        "Backup expands beyond safe internal working space"
                                    }
                                    fileOutput.write(buffer, 0, read)
                                }
                                fileOutput.fd.sync()
                            }
                        }
                    }
                    zip.closeEntry()
                    entry = zip.nextEntry
                }
            }
        } ?: return null
        return manifest?.takeIf { it.optString("app") == "MarkVault" }
    }

    private fun readZipEntryLimited(zip: ZipInputStream, maximumBytes: Long): ByteArray {
        val output = ByteArrayOutputStream()
        val buffer = ByteArray(32 * 1024)
        var total = 0L
        while (true) {
            val read = zip.read(buffer)
            if (read < 0) break
            if (read == 0) continue
            total += read
            require(total <= maximumBytes) { "Backup manifest is too large" }
            output.write(buffer, 0, read)
        }
        return output.toByteArray()
    }

    private fun isRecognisedEntry(name: String): Boolean =
        name == MANIFEST_ENTRY || name == DB_ENTRY || name == DS_ENTRY ||
            name == LEGACY_DB_ENTRY || name == LEGACY_DS_ENTRY ||
            name == ACTIVITY_ENTRY || name.startsWith(LYRICS_PREFIX) ||
            name.startsWith(TRANSCRIPTS_PREFIX)

    private fun safeStagingFile(root: File, entryName: String): File {
        require(!entryName.startsWith("/") && !entryName.contains("..")) { "Unsafe ZIP entry" }
        val file = File(root, entryName)
        val rootPath = root.canonicalPath
        val filePath = file.canonicalPath
        require(filePath == rootPath || filePath.startsWith(rootPath + File.separator)) {
            "ZIP entry escapes staging directory"
        }
        return file
    }

    private fun verifyManifestProtectedEntries(
        manifest: JSONObject,
        staging: File,
        shouldStop: () -> Boolean
    ) {
        val checksums = manifest.optJSONObject("checksums")
            ?: throw IllegalArgumentException("Backup checksum table is missing")
        val sizes = manifest.optJSONObject("sizes")
            ?: throw IllegalArgumentException("Backup size table is missing")

        val keys = checksums.keys()
        var protectedCount = 0
        while (keys.hasNext()) {
            checkStop(shouldStop)
            val entry = keys.next()
            require(isRecognisedEntry(entry) && entry != MANIFEST_ENTRY) { "Unknown protected backup entry" }
            val file = safeStagingFile(staging, entry)
            require(file.isFile) { "Backup entry missing: $entry" }
            require(file.length() == sizes.optLong(entry, -1L)) { "Backup size mismatch: $entry" }
            require(sha256(file, shouldStop).equals(checksums.optString(entry), ignoreCase = true)) {
                "Backup checksum mismatch: $entry"
            }
            protectedCount++
        }
        require(protectedCount >= 2) { "Backup does not contain required protected data" }
        require(checksums.has(DB_ENTRY) && checksums.has(DS_ENTRY)) { "Required v2 entries are not protected" }

        val extracted = staging.walkTopDown()
            .filter { it.isFile }
            .map { it.relativeTo(staging).invariantSeparatorsPath }
            .filter { it != MANIFEST_ENTRY }
            .toList()
        require(extracted.all { checksums.has(it) }) { "Backup contains unprotected data entries" }
        require(extracted.size == protectedCount) { "Backup checksum table does not match extracted data" }
    }

    private data class Preflight(val ok: Boolean, val reason: String = "")

    private fun backupPreflight(ctx: Context, destUri: Uri): Preflight {
        val db = databaseFile(ctx)
        val ds = datastoreFile(ctx)
        if (!db.isFile || db.length() <= 0L) return Preflight(false, "MarkVault database is missing or empty.")
        if (!ds.isFile || ds.length() <= 0L) return Preflight(false, "MarkVault settings file is missing or empty.")

        val stagingNeed = (db.length() + ds.length() + 128L * 1024L * 1024L).coerceAtLeast(256L * 1024L * 1024L)
        val available = StatFs(ctx.cacheDir.absolutePath).availableBytes
        if (available < stagingNeed) {
            return Preflight(false, "Not enough internal working space. Need about ${formatBytes(stagingNeed)}, available ${formatBytes(available)}.")
        }

        val writable = runCatching {
            ctx.contentResolver.openFileDescriptor(destUri, "rw")?.use { true } ?: false
        }.getOrDefault(false)
        if (!writable) return Preflight(false, "The selected backup destination is not writable.")
        return Preflight(true)
    }

    private fun restorePreflight(ctx: Context, srcUri: Uri): Preflight {
        val sourceSize = runCatching {
            ctx.contentResolver.openFileDescriptor(srcUri, "r")?.use { it.statSize.coerceAtLeast(0L) } ?: 0L
        }.getOrDefault(0L)
        val currentDb = databaseFile(ctx).length().coerceAtLeast(0L)
        // Restore simultaneously holds staged data plus rollback data. Use a conservative
        // allowance without pretending SAF can expose every provider's capacity.
        val needed = (sourceSize * 2L + currentDb + 128L * 1024L * 1024L).coerceAtLeast(256L * 1024L * 1024L)
        val available = StatFs(ctx.cacheDir.absolutePath).availableBytes
        if (available < needed) {
            return Preflight(false, "Not enough internal working space for safe restore. Need about ${formatBytes(needed)}, available ${formatBytes(available)}.")
        }
        val readable = runCatching {
            ctx.contentResolver.openFileDescriptor(srcUri, "r")?.use { true } ?: false
        }.getOrDefault(false)
        if (!readable) return Preflight(false, "The selected backup file cannot be read.")
        return Preflight(true)
    }

    private fun checkStop(shouldStop: () -> Boolean) {
        if (shouldStop()) throw BackupStoppedException()
    }

    private fun formatBytes(bytes: Long): String {
        val value = bytes.coerceAtLeast(0L).toDouble()
        val gb = 1024.0 * 1024.0 * 1024.0
        val mb = 1024.0 * 1024.0
        return when {
            value >= gb -> String.format(java.util.Locale.US, "%.1f GB", value / gb)
            value >= mb -> String.format(java.util.Locale.US, "%.1f MB", value / mb)
            else -> "${bytes.coerceAtLeast(0L)} B"
        }
    }

    private fun addDirectorySources(dir: File, prefix: String, out: MutableList<BackupSource>) {
        if (!dir.isDirectory) return
        dir.walkTopDown().filter { it.isFile }.forEach { file ->
            val relative = file.relativeTo(dir).invariantSeparatorsPath
            out += BackupSource(prefix + relative, file)
        }
    }

    private fun copyDirectoryContents(source: File, target: File) {
        target.deleteRecursively()
        target.mkdirs()
        if (!source.isDirectory) return
        source.walkTopDown().filter { it.isFile }.forEach { file ->
            val relative = file.relativeTo(source).invariantSeparatorsPath
            copyFileChecked(file, File(target, relative))
        }
    }

    private fun firstExisting(vararg files: File): File? = files.firstOrNull { it.isFile }

    private fun copyFileChecked(source: File, target: File) {
        require(source.isFile) { "Source file does not exist: ${source.name}" }
        target.parentFile?.mkdirs()
        FileInputStream(source).use { input ->
            FileOutputStream(target).use { output ->
                input.copyTo(output)
                output.fd.sync()
            }
        }
        require(target.isFile && target.length() == source.length()) {
            "File copy verification failed: ${source.name}"
        }
    }

    private fun verifyWrittenBackup(
        ctx: Context,
        uri: Uri,
        expected: Map<String, ExpectedArchiveEntry>,
        shouldStop: () -> Boolean
    ): ArchiveVerification = runCatching {
        val seen = mutableSetOf<String>()
        val raw = ctx.contentResolver.openInputStream(uri)
            ?: throw IllegalStateException("destination could not be reopened")
        raw.buffered().use { input ->
            ZipInputStream(input).use { zip ->
                var entry = zip.nextEntry
                while (entry != null) {
                    checkStop(shouldStop)
                    require(!entry.isDirectory) { "unexpected directory entry: ${entry.name}" }
                    require(seen.add(entry.name)) { "duplicate entry: ${entry.name}" }
                    val wanted = expected[entry.name]
                        ?: throw IllegalStateException("unexpected entry: ${entry.name}")

                    val digest = MessageDigest.getInstance("SHA-256")
                    var count = 0L
                    val buffer = ByteArray(256 * 1024)
                    while (true) {
                        checkStop(shouldStop)
                        val read = zip.read(buffer)
                        if (read < 0) break
                        if (read == 0) continue
                        count += read
                        require(count <= wanted.size) { "entry is larger than expected: ${entry.name}" }
                        digest.update(buffer, 0, read)
                    }
                    val actualHash = digest.digest().joinToString("") { "%02x".format(it) }
                    require(count == wanted.size) { "entry size mismatch: ${entry.name}" }
                    require(actualHash.equals(wanted.sha256, ignoreCase = true)) {
                        "entry checksum mismatch: ${entry.name}"
                    }
                    zip.closeEntry()
                    entry = zip.nextEntry
                }
            }
        }
        require(seen == expected.keys) { "required entries are missing" }
        ArchiveVerification(true)
    }.getOrElse {
        if (it is BackupStoppedException) throw it
        Log.e(TAG, "Completed backup verification failed", it)
        ArchiveVerification(false, it.message ?: it.javaClass.simpleName)
    }

    private fun quickCheckSqlite(file: File): SqliteCheckResult {
        if (!file.isFile || file.length() <= 0L) {
            return SqliteCheckResult(false, listOf("database file is missing or empty"))
        }

        return runCatching {
            val db = SQLiteDatabase.openDatabase(
                file.absolutePath,
                null,
                SQLiteDatabase.OPEN_READONLY or SQLiteDatabase.NO_LOCALIZED_COLLATORS
            )
            try {
                val messages = mutableListOf<String>()
                val userVersion = db.rawQuery("PRAGMA user_version", null).use { cursor ->
                    if (cursor.moveToFirst()) cursor.getInt(0) else null
                }
                db.rawQuery("PRAGMA quick_check(20)", null).use { cursor ->
                    while (cursor.moveToNext()) {
                        messages += cursor.getString(0)?.trim().orEmpty().ifBlank {
                            "empty SQLite validation result"
                        }
                    }
                }
                SqliteCheckResult(
                    ok = messages.size == 1 && messages.single().equals("ok", ignoreCase = true),
                    messages = messages.ifEmpty { listOf("SQLite returned no validation result") },
                    userVersion = userVersion
                )
            } finally {
                db.close()
            }
        }.getOrElse {
            Log.e(TAG, "SQLite quick_check failed for ${file.name}", it)
            SqliteCheckResult(
                false,
                listOf("${it.javaClass.simpleName}: ${it.message ?: "could not open database"}")
            )
        }
    }

    /**
     * Repairs only Room's external-content FTS4 table in an isolated backup
     * file. notes_fts contains no user-owned state: it is deterministically
     * derived from notes.title and notes.content. The caller always runs the
     * SQLite integrity gate again and rejects every non-FTS corruption.
     */
    private fun rebuildDerivedFtsIndex(file: File): Boolean = runCatching {
        val db = SQLiteDatabase.openDatabase(
            file.absolutePath,
            null,
            SQLiteDatabase.OPEN_READWRITE or SQLiteDatabase.NO_LOCALIZED_COLLATORS
        )
        try {
            val definition = db.rawQuery(
                "SELECT sql FROM sqlite_master WHERE type = 'table' AND name = 'notes_fts'",
                null
            ).use { cursor ->
                if (cursor.moveToFirst()) cursor.getString(0).orEmpty() else ""
            }
            require(definition.contains("VIRTUAL TABLE", ignoreCase = true) &&
                definition.contains("USING FTS4", ignoreCase = true)) {
                "notes_fts is not the expected derived FTS4 table"
            }
            val notesExists = db.rawQuery(
                "SELECT 1 FROM sqlite_master WHERE type = 'table' AND name = 'notes'",
                null
            ).use { it.moveToFirst() }
            require(notesExists) { "notes content table is missing" }

            // Force all repair writes into the main snapshot file. The backup
            // archive intentionally never carries SQLite WAL/SHM sidecars.
            db.rawQuery("PRAGMA journal_mode=DELETE", null).use { cursor ->
                require(cursor.moveToFirst() && cursor.getString(0).equals("delete", true)) {
                    "could not switch backup snapshot out of WAL mode"
                }
            }
            db.beginTransaction()
            try {
                db.execSQL("INSERT INTO notes_fts(notes_fts) VALUES('rebuild')")
                db.setTransactionSuccessful()
            } finally {
                db.endTransaction()
            }
        } finally {
            db.close()
        }
        File("${file.absolutePath}-wal").delete()
        File("${file.absolutePath}-shm").delete()
        true
    }.getOrElse {
        Log.e(TAG, "Could not rebuild derived FTS index in ${file.name}", it)
        false
    }

    private fun sha256(file: File, shouldStop: (() -> Boolean)? = null): String {
        val digest = MessageDigest.getInstance("SHA-256")
        FileInputStream(file).use { input ->
            val buffer = ByteArray(DEFAULT_BUFFER_SIZE)
            while (true) {
                if (shouldStop != null) checkStop(shouldStop)
                val read = input.read(buffer)
                if (read <= 0) break
                digest.update(buffer, 0, read)
            }
        }
        return digest.digest().joinToString("") { "%02x".format(it) }
    }

    private fun sha256(bytes: ByteArray): String =
        MessageDigest.getInstance("SHA-256")
            .digest(bytes)
            .joinToString("") { "%02x".format(it) }
}
