package com.tebogo.markvault.data

import android.content.Context
import android.database.sqlite.SQLiteDatabase
import android.net.Uri
import android.util.Log
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONObject
import java.io.File
import java.io.FileInputStream
import java.io.FileOutputStream
import java.security.MessageDigest
import java.util.zip.ZipEntry
import java.util.zip.ZipInputStream
import java.util.zip.ZipOutputStream

/**
 * MarkVault backup / restore.
 *
 * Backup v2 contains the Room database, DataStore preferences, cached song
 * lyrics, cached video transcripts, and the activity log when present.
 * Article-library files and downloaded AI/model files are intentionally not
 * included because they live outside app-private state or are re-downloadable.
 *
 * Safety properties:
 *  • Backup never reports success unless required DB + DataStore snapshots exist.
 *  • Every v2 entry is SHA-256 + size protected in manifest.json.
 *  • Restore extracts only recognised paths into a staging directory first.
 *  • SQLite is quick-checked before the live database is touched.
 *  • The old database/cache directories are retained as rollback copies until
 *    every replacement succeeds.
 *  • DataStore is NOT replaced while its singleton may be alive. It is staged
 *    and installed at the very beginning of the next Application.onCreate().
 */
object BackupManager {

    private const val TAG = "MV-BackupManager"
    private const val FORMAT_VERSION = 2

    private const val MANIFEST_ENTRY = "manifest.json"
    private const val DB_ENTRY = "database/markvault.db"
    private const val DS_ENTRY = "settings/settings.preferences_pb"
    private const val LYRICS_PREFIX = "media/song_lyrics/"
    private const val TRANSCRIPTS_PREFIX = "media/video_transcripts/"
    private const val ACTIVITY_ENTRY = "optional/activity_log.jsonl"

    // Legacy v1 entry names, retained so old backups remain restorable.
    private const val LEGACY_DB_ENTRY = "markvault.db"
    private const val LEGACY_DS_ENTRY = "settings.preferences_pb"

    private const val PENDING_DIR = "restore_pending"
    private const val PENDING_DS = "settings.preferences_pb"
    private const val PENDING_MARKER = "pending_datastore_restore"

    private data class BackupSource(val entryName: String, val file: File)

    fun databaseFile(ctx: Context): File = ctx.getDatabasePath("markvault.db")
    private fun databaseWal(ctx: Context): File = ctx.getDatabasePath("markvault.db-wal")
    private fun databaseShm(ctx: Context): File = ctx.getDatabasePath("markvault.db-shm")

    fun datastoreFile(ctx: Context): File =
        File(ctx.filesDir, "datastore/settings.preferences_pb")

    private fun lyricsDir(ctx: Context): File = File(ctx.filesDir, "song_lyrics")
    private fun transcriptsDir(ctx: Context): File = File(ctx.filesDir, "video_transcripts")
    private fun activityLogFile(ctx: Context): File = File(ctx.filesDir, "activity_log.jsonl")

    /**
     * Called before any DataStore-backed UI is created. A restore stages the
     * protobuf while the old process is alive; the next cold process installs
     * it here, before MarkVault creates its preference DataStore delegate.
     */
    fun applyPendingDatastoreRestore(ctx: Context) {
        val pendingRoot = File(ctx.filesDir, PENDING_DIR)
        val marker = File(pendingRoot, PENDING_MARKER)
        val staged = File(pendingRoot, PENDING_DS)
        if (!marker.exists()) return

        val target = datastoreFile(ctx)
        val rollback = File(target.parentFile, "${target.name}.pre_restore")
        try {
            require(staged.isFile && staged.length() > 0L) {
                "Pending DataStore restore is missing or empty"
            }
            target.parentFile?.mkdirs()
            rollback.delete()
            if (target.exists()) {
                require(target.renameTo(rollback)) { "Could not create DataStore rollback copy" }
            }
            try {
                copyFileChecked(staged, target)
                require(target.isFile && target.length() == staged.length()) {
                    "Restored DataStore size mismatch"
                }
                rollback.delete()
                staged.delete()
                marker.delete()
                pendingRoot.delete()
                Log.i(TAG, "Pending DataStore restore applied")
            } catch (e: Exception) {
                target.delete()
                if (rollback.exists()) rollback.renameTo(target)
                throw e
            }
        } catch (e: Exception) {
            Log.e(TAG, "Pending DataStore restore failed; original preferences retained", e)
        }
    }

    suspend fun createBackup(
        ctx: Context,
        destUri: Uri,
        versionName: String
    ): Boolean = withContext(Dispatchers.IO) {
        val tempRoot = File(ctx.cacheDir, "backup_staging_${System.nanoTime()}")
        try {
            tempRoot.mkdirs()
            val dbSnapshot = File(tempRoot, "markvault.db")
            val dsSnapshot = File(tempRoot, "settings.preferences_pb")

            if (!createDatabaseSnapshot(ctx, dbSnapshot)) {
                Log.e(TAG, "Backup aborted: database snapshot could not be created")
                return@withContext false
            }
            if (!dbSnapshot.isFile || dbSnapshot.length() <= 0L || !quickCheckSqlite(dbSnapshot)) {
                Log.e(TAG, "Backup aborted: database snapshot failed validation")
                return@withContext false
            }

            val dsLive = datastoreFile(ctx)
            if (!dsLive.isFile || dsLive.length() <= 0L) {
                Log.e(TAG, "Backup aborted: DataStore file is missing or empty")
                return@withContext false
            }
            copyFileChecked(dsLive, dsSnapshot)
            if (!dsSnapshot.isFile || dsSnapshot.length() != dsLive.length()) {
                Log.e(TAG, "Backup aborted: DataStore snapshot failed validation")
                return@withContext false
            }

            val sources = mutableListOf(
                BackupSource(DB_ENTRY, dbSnapshot),
                BackupSource(DS_ENTRY, dsSnapshot)
            )
            addDirectorySources(lyricsDir(ctx), LYRICS_PREFIX, sources)
            addDirectorySources(transcriptsDir(ctx), TRANSCRIPTS_PREFIX, sources)
            val activity = activityLogFile(ctx)
            if (activity.isFile) sources += BackupSource(ACTIVITY_ENTRY, activity)

            val checksums = JSONObject()
            val sizes = JSONObject()
            for (source in sources) {
                checksums.put(source.entryName, sha256(source.file))
                sizes.put(source.entryName, source.file.length())
            }

            val manifest = JSONObject().apply {
                put("app", "MarkVault")
                put("format_version", FORMAT_VERSION)
                put("version", versionName)
                put("timestamp", System.currentTimeMillis())
                put("db_entry", DB_ENTRY)
                put("ds_entry", DS_ENTRY)
                put("lyrics_count", sources.count { it.entryName.startsWith(LYRICS_PREFIX) })
                put("transcripts_count", sources.count { it.entryName.startsWith(TRANSCRIPTS_PREFIX) })
                put("checksums", checksums)
                put("sizes", sizes)
            }.toString(2)

            val out = ctx.contentResolver.openOutputStream(destUri)
                ?: return@withContext false.also { Log.e(TAG, "Could not open backup output stream") }
            out.buffered().use { raw ->
                ZipOutputStream(raw).use { zip ->
                    zip.putNextEntry(ZipEntry(MANIFEST_ENTRY))
                    zip.write(manifest.toByteArray(Charsets.UTF_8))
                    zip.closeEntry()

                    for (source in sources) {
                        zip.putNextEntry(ZipEntry(source.entryName))
                        FileInputStream(source.file).use { it.copyTo(zip) }
                        zip.closeEntry()
                    }
                }
            }

            Log.i(TAG, "Backup written: ${sources.size} protected data entries")
            true
        } catch (e: Exception) {
            Log.e(TAG, "createBackup failed", e)
            false
        } finally {
            tempRoot.deleteRecursively()
        }
    }

    /**
     * Returns manifest only when the ZIP is structurally a restorable MarkVault
     * backup. Required DB + DataStore entries must both be present.
     */
    suspend fun readManifest(ctx: Context, srcUri: Uri): JSONObject? =
        withContext(Dispatchers.IO) {
            try {
                var manifest: JSONObject? = null
                var hasDb = false
                var hasDs = false
                ctx.contentResolver.openInputStream(srcUri)?.buffered()?.use { raw ->
                    ZipInputStream(raw).use { zip ->
                        var entry = zip.nextEntry
                        while (entry != null) {
                            when (entry.name) {
                                MANIFEST_ENTRY -> manifest = JSONObject(zip.readBytes().toString(Charsets.UTF_8))
                                DB_ENTRY, LEGACY_DB_ENTRY -> hasDb = true
                                DS_ENTRY, LEGACY_DS_ENTRY -> hasDs = true
                            }
                            zip.closeEntry()
                            entry = zip.nextEntry
                        }
                    }
                } ?: return@withContext null

                val json = manifest ?: return@withContext null
                if (json.optString("app") != "MarkVault" || !hasDb || !hasDs) return@withContext null
                json
            } catch (e: Exception) {
                Log.e(TAG, "readManifest failed", e)
                null
            }
        }

    suspend fun applyBackup(ctx: Context, srcUri: Uri): Boolean =
        withContext(Dispatchers.IO) {
            val staging = File(ctx.cacheDir, "restore_staging_${System.nanoTime()}")
            val rollback = File(ctx.cacheDir, "restore_rollback_${System.nanoTime()}")
            var dbWasMoved = false
            var dbInstalled = false
            var lyricsWasMoved = false
            var lyricsInstalled = false
            var transcriptsWasMoved = false
            var transcriptsInstalled = false
            var activityWasMoved = false
            var activityInstalled = false
            var roomWasClosed = false

            val dbTarget = databaseFile(ctx)
            val lyricsTarget = lyricsDir(ctx)
            val transcriptsTarget = transcriptsDir(ctx)
            val activityTarget = activityLogFile(ctx)

            try {
                staging.mkdirs()
                rollback.mkdirs()

                val manifest = extractRecognisedEntries(ctx, srcUri, staging)
                    ?: throw IllegalArgumentException("Backup is missing a valid manifest")
                val formatVersion = manifest.optInt("format_version", 1)

                val stagedDb = firstExisting(
                    File(staging, DB_ENTRY),
                    File(staging, LEGACY_DB_ENTRY)
                ) ?: throw IllegalArgumentException("Backup database is missing")
                val stagedDs = firstExisting(
                    File(staging, DS_ENTRY),
                    File(staging, LEGACY_DS_ENTRY)
                ) ?: throw IllegalArgumentException("Backup settings are missing")

                require(stagedDb.length() > 0L) { "Backup database is empty" }
                require(stagedDs.length() > 0L) { "Backup settings are empty" }

                if (formatVersion >= 2) verifyManifestProtectedEntries(manifest, staging)
                require(quickCheckSqlite(stagedDb)) { "Backup database failed SQLite quick_check" }

                // Stage DataStore for next process BEFORE touching current live data.
                val pendingRoot = File(ctx.filesDir, PENDING_DIR).apply { mkdirs() }
                val pendingDs = File(pendingRoot, PENDING_DS)
                val pendingMarker = File(pendingRoot, PENDING_MARKER)
                pendingDs.delete()
                copyFileChecked(stagedDs, pendingDs)
                require(pendingDs.length() == stagedDs.length()) { "Could not stage restored settings" }
                pendingMarker.writeText("ready", Charsets.UTF_8)

                VaultDb.closeForRestore()
                roomWasClosed = true

                dbTarget.parentFile?.mkdirs()
                val dbRollback = File(rollback, "markvault.db")
                if (dbTarget.exists()) {
                    require(dbTarget.renameTo(dbRollback)) { "Could not create database rollback copy" }
                    dbWasMoved = true
                }
                databaseWal(ctx).delete()
                databaseShm(ctx).delete()

                val dbIncoming = File(dbTarget.parentFile, "markvault.db.restore_incoming")
                dbIncoming.delete()
                copyFileChecked(stagedDb, dbIncoming)
                require(dbIncoming.length() == stagedDb.length()) { "Database replacement size mismatch" }
                require(dbIncoming.renameTo(dbTarget)) { "Could not install restored database" }
                dbInstalled = true
                require(quickCheckSqlite(dbTarget)) { "Installed database failed SQLite quick_check" }

                // v2 backups explicitly represent cache directories, including empty ones.
                if (formatVersion >= 2) {
                    val lyricsRollback = File(rollback, "song_lyrics")
                    if (lyricsTarget.exists()) {
                        require(lyricsTarget.renameTo(lyricsRollback)) { "Could not protect current lyrics cache" }
                        lyricsWasMoved = true
                    }
                    copyDirectoryContents(File(staging, LYRICS_PREFIX.removeSuffix("/")), lyricsTarget)
                    lyricsInstalled = true

                    val transcriptsRollback = File(rollback, "video_transcripts")
                    if (transcriptsTarget.exists()) {
                        require(transcriptsTarget.renameTo(transcriptsRollback)) { "Could not protect current transcript cache" }
                        transcriptsWasMoved = true
                    }
                    copyDirectoryContents(File(staging, TRANSCRIPTS_PREFIX.removeSuffix("/")), transcriptsTarget)
                    transcriptsInstalled = true

                    val stagedActivity = File(staging, ACTIVITY_ENTRY)
                    val activityRollback = File(rollback, "activity_log.jsonl")
                    if (activityTarget.exists()) {
                        require(activityTarget.renameTo(activityRollback)) { "Could not protect current activity log" }
                        activityWasMoved = true
                    }
                    if (stagedActivity.isFile) {
                        copyFileChecked(stagedActivity, activityTarget)
                        activityInstalled = true
                    }
                }

                // All live replacements succeeded. Rollback copies are no longer needed.
                rollback.deleteRecursively()
                Log.i(TAG, "Restore data installed; settings will be applied on next cold start")
                true
            } catch (e: Exception) {
                Log.e(TAG, "applyBackup failed; rolling back", e)

                // Roll back current-process data. Pending DataStore must not survive a failed restore.
                File(ctx.filesDir, PENDING_DIR).deleteRecursively()

                runCatching {
                    val dbRollback = File(rollback, "markvault.db")
                    if (dbInstalled) dbTarget.delete()
                    if (dbWasMoved && dbRollback.exists()) {
                        require(dbRollback.renameTo(dbTarget)) { "Database rollback rename failed" }
                    }
                    databaseWal(ctx).delete()
                    databaseShm(ctx).delete()

                    if (lyricsInstalled) lyricsTarget.deleteRecursively()
                    if (lyricsWasMoved) {
                        require(File(rollback, "song_lyrics").renameTo(lyricsTarget)) { "Lyrics rollback failed" }
                    }
                    if (transcriptsInstalled) transcriptsTarget.deleteRecursively()
                    if (transcriptsWasMoved) {
                        require(File(rollback, "video_transcripts").renameTo(transcriptsTarget)) { "Transcript rollback failed" }
                    }
                    if (activityInstalled) activityTarget.delete()
                    if (activityWasMoved) {
                        require(File(rollback, "activity_log.jsonl").renameTo(activityTarget)) { "Activity-log rollback failed" }
                    }
                }.onFailure { rollbackError ->
                    Log.e(TAG, "Rollback itself encountered an error", rollbackError)
                }
                if (roomWasClosed) {
                    runCatching { VaultDb.get(ctx).openHelper.writableDatabase }
                        .onFailure { Log.e(TAG, "Could not reopen Room after failed restore", it) }
                }
                false
            } finally {
                staging.deleteRecursively()
                rollback.deleteRecursively()
            }
        }

    private fun createDatabaseSnapshot(ctx: Context, target: File): Boolean {
        target.delete()
        target.parentFile?.mkdirs()
        val roomDb = VaultDb.get(ctx).openHelper.writableDatabase

        // Preferred path on SQLite versions supporting VACUUM INTO: SQLite itself
        // creates the consistent standalone snapshot while MarkVault stays online.
        val escaped = target.absolutePath.replace("'", "''")
        val vacuumOk = runCatching {
            roomDb.execSQL("VACUUM INTO '$escaped'")
            target.isFile && target.length() > 0L
        }.getOrElse {
            Log.i(TAG, "VACUUM INTO unavailable; using locked checkpoint snapshot: ${it.message}")
            false
        }
        if (vacuumOk) return true

        // API 26 devices can ship older SQLite. Fallback: checkpoint first, then
        // hold a write transaction with no mutations while copying the main DB.
        // The lock prevents a concurrent writer from changing the file mid-copy.
        return runCatching {
            roomDb.execSQL("PRAGMA wal_checkpoint(TRUNCATE)")
            roomDb.beginTransaction()
            try {
                val live = databaseFile(ctx)
                require(live.isFile && live.length() > 0L) { "Live database missing" }
                copyFileChecked(live, target)
                roomDb.setTransactionSuccessful()
            } finally {
                roomDb.endTransaction()
            }
            target.isFile && target.length() > 0L
        }.getOrElse {
            Log.e(TAG, "Locked database snapshot failed", it)
            false
        }
    }

    private fun extractRecognisedEntries(ctx: Context, srcUri: Uri, staging: File): JSONObject? {
        var manifest: JSONObject? = null
        ctx.contentResolver.openInputStream(srcUri)?.buffered()?.use { raw ->
            ZipInputStream(raw).use { zip ->
                var entry = zip.nextEntry
                while (entry != null) {
                    val name = entry.name
                    if (!entry.isDirectory && isRecognisedEntry(name)) {
                        if (name == MANIFEST_ENTRY) {
                            manifest = JSONObject(zip.readBytes().toString(Charsets.UTF_8))
                        } else {
                            val output = safeStagingFile(staging, name)
                            output.parentFile?.mkdirs()
                            FileOutputStream(output).use { zip.copyTo(it) }
                        }
                    }
                    zip.closeEntry()
                    entry = zip.nextEntry
                }
            }
        } ?: return null
        return manifest?.takeIf { it.optString("app") == "MarkVault" }
    }

    private fun isRecognisedEntry(name: String): Boolean =
        name == MANIFEST_ENTRY || name == DB_ENTRY || name == DS_ENTRY ||
            name == LEGACY_DB_ENTRY || name == LEGACY_DS_ENTRY ||
            name == ACTIVITY_ENTRY || name.startsWith(LYRICS_PREFIX) ||
            name.startsWith(TRANSCRIPTS_PREFIX)

    private fun safeStagingFile(root: File, entryName: String): File {
        require(!entryName.startsWith("/") && !entryName.contains("..")) { "Unsafe ZIP entry" }
        val file = File(root, entryName)
        val rootPath = root.canonicalPath
        val filePath = file.canonicalPath
        require(filePath == rootPath || filePath.startsWith(rootPath + File.separator)) {
            "ZIP entry escapes staging directory"
        }
        return file
    }

    private fun verifyManifestProtectedEntries(manifest: JSONObject, staging: File) {
        val checksums = manifest.optJSONObject("checksums")
            ?: throw IllegalArgumentException("Backup checksum table is missing")
        val sizes = manifest.optJSONObject("sizes")
            ?: throw IllegalArgumentException("Backup size table is missing")

        val keys = checksums.keys()
        var protectedCount = 0
        while (keys.hasNext()) {
            val entry = keys.next()
            require(isRecognisedEntry(entry) && entry != MANIFEST_ENTRY) { "Unknown protected backup entry" }
            val file = safeStagingFile(staging, entry)
            require(file.isFile) { "Backup entry missing: $entry" }
            require(file.length() == sizes.optLong(entry, -1L)) { "Backup size mismatch: $entry" }
            require(sha256(file).equals(checksums.optString(entry), ignoreCase = true)) {
                "Backup checksum mismatch: $entry"
            }
            protectedCount++
        }
        require(protectedCount >= 2) { "Backup does not contain required protected data" }
        require(checksums.has(DB_ENTRY) && checksums.has(DS_ENTRY)) { "Required v2 entries are not protected" }

        val extracted = staging.walkTopDown()
            .filter { it.isFile }
            .map { it.relativeTo(staging).invariantSeparatorsPath }
            .filter { it != MANIFEST_ENTRY }
            .toList()
        require(extracted.all { checksums.has(it) }) { "Backup contains unprotected data entries" }
        require(extracted.size == protectedCount) { "Backup checksum table does not match extracted data" }
    }

    private fun addDirectorySources(dir: File, prefix: String, out: MutableList<BackupSource>) {
        if (!dir.isDirectory) return
        dir.walkTopDown().filter { it.isFile }.forEach { file ->
            val relative = file.relativeTo(dir).invariantSeparatorsPath
            out += BackupSource(prefix + relative, file)
        }
    }

    private fun copyDirectoryContents(source: File, target: File) {
        target.deleteRecursively()
        target.mkdirs()
        if (!source.isDirectory) return
        source.walkTopDown().filter { it.isFile }.forEach { file ->
            val relative = file.relativeTo(source).invariantSeparatorsPath
            copyFileChecked(file, File(target, relative))
        }
    }

    private fun firstExisting(vararg files: File): File? = files.firstOrNull { it.isFile }

    private fun copyFileChecked(source: File, target: File) {
        require(source.isFile) { "Source file does not exist: ${source.name}" }
        target.parentFile?.mkdirs()
        FileInputStream(source).use { input ->
            FileOutputStream(target).use { output ->
                input.copyTo(output)
                output.fd.sync()
            }
        }
        require(target.isFile && target.length() == source.length()) {
            "File copy verification failed: ${source.name}"
        }
    }

    private fun quickCheckSqlite(file: File): Boolean = runCatching {
        val db = SQLiteDatabase.openDatabase(file.absolutePath, null, SQLiteDatabase.OPEN_READONLY)
        try {
            db.rawQuery("PRAGMA quick_check(1)", null).use { cursor ->
                cursor.moveToFirst() && cursor.getString(0).equals("ok", ignoreCase = true)
            }
        } finally {
            db.close()
        }
    }.getOrElse {
        Log.e(TAG, "SQLite quick_check failed for ${file.name}", it)
        false
    }

    private fun sha256(file: File): String {
        val digest = MessageDigest.getInstance("SHA-256")
        FileInputStream(file).use { input ->
            val buffer = ByteArray(DEFAULT_BUFFER_SIZE)
            while (true) {
                val read = input.read(buffer)
                if (read <= 0) break
                digest.update(buffer, 0, read)
            }
        }
        return digest.digest().joinToString("") { "%02x".format(it) }
    }
}
