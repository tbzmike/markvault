package com.tebogo.markvault.data

import android.content.Context
import android.database.sqlite.SQLiteDatabase
import android.net.Uri
import android.util.Log
import androidx.sqlite.db.SupportSQLiteDatabase
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONObject
import java.io.File
import java.io.DataInputStream
import java.io.DataOutputStream
import java.io.FileInputStream
import java.io.FileOutputStream
import java.io.OutputStream
import java.security.MessageDigest
import java.util.zip.ZipEntry
import java.util.zip.ZipInputStream
import java.util.zip.ZipOutputStream

/**
 * MarkVault backup / restore.
 *
 * Backup v4 intentionally contains ONLY:
 *  • DataStore settings
 *  • the library index (notes + topic/link index data; FTS is rebuilt from notes)
 *  • note semantic embeddings
 *
 * Article files, browser/PDF history, bookmarks, annotations, media caches,
 * playlists, activity logs, downloaded models, and media embeddings are excluded.
 *
 * v1/v2/v3 archives remain readable for backwards compatibility. v4 streams the
 * requested state directly to/from the ZIP so large embedding stores do not need
 * a second full-size staging database in internal app storage.
 */
object BackupManager {

    private const val TAG = "MV-BackupManager"
    private const val FORMAT_VERSION = 4

    private const val MANIFEST_ENTRY = "manifest.json"
    // v4 streams the requested state directly into the destination ZIP. This avoids
    // staging a second, potentially very large SQLite database in app cache.
    private const val NOTES_ENTRY = "library/notes.bin"
    private const val TOPICS_ENTRY = "library/note_topics.bin"
    private const val LINKS_ENTRY = "library/note_links.bin"
    private const val EMBEDDINGS_ENTRY = "library/note_embeddings.bin"
    private const val DS_ENTRY = "settings/settings.preferences_pb"

    // v3 selective-SQLite entry retained for backwards-compatible restore.
    private const val STATE_ENTRY = "library/library_state.db"

    private const val MAGIC_NOTES = 0x4D564E31 // MVN1
    private const val MAGIC_TOPICS = 0x4D565431 // MVT1
    private const val MAGIC_LINKS = 0x4D564C31 // MVL1
    private const val MAGIC_EMBEDDINGS = 0x4D564531 // MVE1
    private const val STREAM_SCHEMA_VERSION = 1
    private const val MAX_STRING_BYTES = 256 * 1024 * 1024
    private const val MAX_BLOB_BYTES = 64 * 1024 * 1024

    // Legacy v1/v2 entry names retained for old-backup restore support.
    private const val LEGACY_DB_V2_ENTRY = "database/markvault.db"
    private const val LEGACY_DB_V1_ENTRY = "markvault.db"
    private const val LEGACY_DS_ENTRY = "settings.preferences_pb"
    private const val LEGACY_LYRICS_PREFIX = "media/song_lyrics/"
    private const val LEGACY_TRANSCRIPTS_PREFIX = "media/video_transcripts/"
    private const val LEGACY_ACTIVITY_ENTRY = "optional/activity_log.jsonl"

    private const val PENDING_DIR = "restore_pending"
    private const val PENDING_DS = "settings.preferences_pb"
    private const val PENDING_MARKER = "pending_datastore_restore"

    private data class BackupSource(val entryName: String, val file: File)

    fun databaseFile(ctx: Context): File = ctx.getDatabasePath("markvault.db")
    private fun databaseWal(ctx: Context): File = ctx.getDatabasePath("markvault.db-wal")
    private fun databaseShm(ctx: Context): File = ctx.getDatabasePath("markvault.db-shm")

    fun datastoreFile(ctx: Context): File =
        File(ctx.filesDir, "datastore/settings.preferences_pb")

    /** Apply a staged DataStore restore before the DataStore singleton is created. */
    fun applyPendingDatastoreRestore(ctx: Context) {
        val pendingRoot = File(ctx.filesDir, PENDING_DIR)
        val marker = File(pendingRoot, PENDING_MARKER)
        val staged = File(pendingRoot, PENDING_DS)
        if (!marker.exists()) return

        val target = datastoreFile(ctx)
        val rollback = File(target.parentFile, "${target.name}.pre_restore")
        try {
            require(staged.isFile) {
                "Pending DataStore restore is missing"
            }
            target.parentFile?.mkdirs()
            rollback.delete()
            if (target.exists()) {
                require(target.renameTo(rollback)) { "Could not create DataStore rollback copy" }
            }
            try {
                copyFileChecked(staged, target)
                require(target.isFile && target.length() == staged.length()) {
                    "Restored DataStore size mismatch"
                }
                rollback.delete()
                staged.delete()
                marker.delete()
                pendingRoot.delete()
                Log.i(TAG, "Pending DataStore restore applied")
            } catch (e: Exception) {
                target.delete()
                if (rollback.exists()) rollback.renameTo(target)
                throw e
            }
        } catch (e: Exception) {
            Log.e(TAG, "Pending DataStore restore failed; original preferences retained", e)
        }
    }

    @Volatile
    private var lastBackupError: String? = null

    fun lastBackupErrorMessage(): String? = lastBackupError

    suspend fun createBackup(
        ctx: Context,
        destUri: Uri,
        versionName: String
    ): Boolean = withContext(Dispatchers.IO) {
        lastBackupError = null
        try {
            val out = ctx.contentResolver.openOutputStream(destUri, "w")
                ?: throw IllegalStateException("The selected backup file could not be opened for writing")

            val checksums = JSONObject()
            val sizes = JSONObject()
            var noteCount = 0L
            var embeddingCount = 0L

            out.buffered().use { raw ->
                ZipOutputStream(raw).use { zip ->
                    val roomDb = VaultDb.get(ctx).openHelper.writableDatabase

                    // Keep one coherent database view while rows are streamed. No duplicate
                    // SQLite file is created in cache, so large embedding stores do not require
                    // a second copy's worth of free internal storage.
                    roomDb.beginTransaction()
                    try {
                        val notesStats = writeProtectedEntry(zip, NOTES_ENTRY) { output ->
                            val data = DataOutputStream(output)
                            noteCount = queryCount(roomDb, "notes")
                            data.writeInt(MAGIC_NOTES)
                            data.writeInt(STREAM_SCHEMA_VERSION)
                            data.writeLong(noteCount)
                            roomDb.query(
                                "SELECT id, uri, relPath, name, title, folder, content, lastModified, size, fileType " +
                                    "FROM notes ORDER BY id"
                            ).use { c ->
                                while (c.moveToNext()) {
                                    data.writeLong(c.getLong(0))
                                    writeString(data, c.getString(1))
                                    writeString(data, c.getString(2))
                                    writeString(data, c.getString(3))
                                    writeString(data, c.getString(4))
                                    writeString(data, c.getString(5))
                                    writeString(data, c.getString(6))
                                    data.writeLong(c.getLong(7))
                                    data.writeLong(c.getLong(8))
                                    writeString(data, c.getString(9))
                                }
                            }
                            data.flush()
                        }
                        checksums.put(NOTES_ENTRY, notesStats.sha256)
                        sizes.put(NOTES_ENTRY, notesStats.size)

                        val topicsStats = writeProtectedEntry(zip, TOPICS_ENTRY) { output ->
                            val data = DataOutputStream(output)
                            val count = queryCount(roomDb, "note_topics")
                            data.writeInt(MAGIC_TOPICS)
                            data.writeInt(STREAM_SCHEMA_VERSION)
                            data.writeLong(count)
                            roomDb.query("SELECT noteId, topic, score FROM note_topics ORDER BY noteId, topic").use { c ->
                                while (c.moveToNext()) {
                                    data.writeLong(c.getLong(0))
                                    writeString(data, c.getString(1))
                                    data.writeInt(c.getInt(2))
                                }
                            }
                            data.flush()
                        }
                        checksums.put(TOPICS_ENTRY, topicsStats.sha256)
                        sizes.put(TOPICS_ENTRY, topicsStats.size)

                        val linksStats = writeProtectedEntry(zip, LINKS_ENTRY) { output ->
                            val data = DataOutputStream(output)
                            val count = queryCount(roomDb, "note_links")
                            data.writeInt(MAGIC_LINKS)
                            data.writeInt(STREAM_SCHEMA_VERSION)
                            data.writeLong(count)
                            roomDb.query("SELECT fromId, target, targetNorm FROM note_links ORDER BY fromId, targetNorm").use { c ->
                                while (c.moveToNext()) {
                                    data.writeLong(c.getLong(0))
                                    writeString(data, c.getString(1))
                                    writeString(data, c.getString(2))
                                }
                            }
                            data.flush()
                        }
                        checksums.put(LINKS_ENTRY, linksStats.sha256)
                        sizes.put(LINKS_ENTRY, linksStats.size)

                        val embeddingsStats = writeProtectedEntry(zip, EMBEDDINGS_ENTRY) { output ->
                            val data = DataOutputStream(output)
                            embeddingCount = queryCount(roomDb, "note_embeddings")
                            data.writeInt(MAGIC_EMBEDDINGS)
                            data.writeInt(STREAM_SCHEMA_VERSION)
                            data.writeLong(embeddingCount)
                            roomDb.query(
                                "SELECT noteId, modelVersion, chunkIndex, dim, vector, sourceLastModified, createdAt " +
                                    "FROM note_embeddings ORDER BY noteId, modelVersion, chunkIndex"
                            ).use { c ->
                                while (c.moveToNext()) {
                                    data.writeLong(c.getLong(0))
                                    writeString(data, c.getString(1))
                                    data.writeInt(c.getInt(2))
                                    data.writeInt(c.getInt(3))
                                    writeByteArray(data, c.getBlob(4))
                                    data.writeLong(c.getLong(5))
                                    data.writeLong(c.getLong(6))
                                }
                            }
                            data.flush()
                        }
                        checksums.put(EMBEDDINGS_ENTRY, embeddingsStats.sha256)
                        sizes.put(EMBEDDINGS_ENTRY, embeddingsStats.size)
                        roomDb.setTransactionSuccessful()
                    } finally {
                        roomDb.endTransaction()
                    }

                    val dsStats = writeProtectedEntry(zip, DS_ENTRY) { output ->
                        val dsLive = datastoreFile(ctx)
                        // A missing DataStore file means the app is still using defaults. Empty
                        // Preferences protobuf is a valid representation of that state.
                        if (dsLive.isFile) FileInputStream(dsLive).use { it.copyTo(output) }
                    }
                    checksums.put(DS_ENTRY, dsStats.sha256)
                    sizes.put(DS_ENTRY, dsStats.size)

                    val manifest = JSONObject().apply {
                        put("app", "MarkVault")
                        put("format_version", FORMAT_VERSION)
                        put("stream_schema_version", STREAM_SCHEMA_VERSION)
                        put("version", versionName)
                        put("timestamp", System.currentTimeMillis())
                        put("scope", "settings+library_index+note_embeddings")
                        put("notes", noteCount)
                        put("embeddings", embeddingCount)
                        put("checksums", checksums)
                        put("sizes", sizes)
                    }.toString(2)

                    zip.putNextEntry(ZipEntry(MANIFEST_ENTRY))
                    zip.write(manifest.toByteArray(Charsets.UTF_8))
                    zip.closeEntry()
                }
            }

            require(validateV4Archive(ctx, destUri) != null) {
                "The written backup could not be read back and verified"
            }
            Log.i(TAG, "Backup v4 written and verified: settings + library index + note embeddings")
            true
        } catch (e: Exception) {
            lastBackupError = e.message?.takeIf { it.isNotBlank() } ?: e.javaClass.simpleName
            Log.e(TAG, "createBackup failed", e)
            false
        }
    }

    /** Return the manifest only for a structurally restorable MarkVault archive. */
    suspend fun readManifest(ctx: Context, srcUri: Uri): JSONObject? =
        withContext(Dispatchers.IO) {
            try {
                // v4 archives are fully checksum-validated before the confirmation dialog is shown.
                validateV4Archive(ctx, srcUri)?.let { return@withContext it }

                var manifest: JSONObject? = null
                var hasState = false
                var hasLegacyDb = false
                var hasDs = false
                ctx.contentResolver.openInputStream(srcUri)?.buffered()?.use { raw ->
                    ZipInputStream(raw).use { zip ->
                        var entry = zip.nextEntry
                        while (entry != null) {
                            when (entry.name) {
                                MANIFEST_ENTRY -> manifest = JSONObject(zip.readBytes().toString(Charsets.UTF_8))
                                STATE_ENTRY -> hasState = true
                                LEGACY_DB_V2_ENTRY, LEGACY_DB_V1_ENTRY -> hasLegacyDb = true
                                DS_ENTRY, LEGACY_DS_ENTRY -> hasDs = true
                            }
                            zip.closeEntry()
                            entry = zip.nextEntry
                        }
                    }
                } ?: return@withContext null

                val json = manifest ?: return@withContext null
                if (json.optString("app") != "MarkVault" || !hasDs) return@withContext null
                val version = json.optInt("format_version", 1)
                if (version >= 4) return@withContext null // v4 must pass validateV4Archive above
                if (version >= 3 && !hasState) return@withContext null
                if (version < 3 && !hasLegacyDb) return@withContext null
                json
            } catch (e: Exception) {
                Log.e(TAG, "readManifest failed", e)
                null
            }
        }

    suspend fun applyBackup(ctx: Context, srcUri: Uri): Boolean =
        withContext(Dispatchers.IO) {
            val staging = File(ctx.cacheDir, "restore_staging_${System.nanoTime()}")
            try {
                staging.mkdirs()
                val manifest = extractRecognisedEntries(ctx, srcUri, staging)
                    ?: throw IllegalArgumentException("Backup is missing a valid manifest")
                val formatVersion = manifest.optInt("format_version", 1)

                if (formatVersion >= 4) {
                    val verified = validateV4Archive(ctx, srcUri)
                        ?: throw IllegalArgumentException("Backup integrity validation failed")
                    val streamedDs = File(staging, PENDING_DS)
                    extractV4Settings(ctx, srcUri, streamedDs)
                    stageDatastoreForNextStart(ctx, streamedDs)
                    VaultDb.closeForRestore()
                    return@withContext try {
                        applyV4StreamedLibraryState(ctx, srcUri, verified)
                        Log.i(TAG, "Streaming v4 restore installed; settings apply on next cold start")
                        true
                    } catch (e: Exception) {
                        File(ctx.filesDir, PENDING_DIR).deleteRecursively()
                        runCatching { VaultDb.get(ctx).openHelper.writableDatabase }
                        throw e
                    }
                }

                val stagedDs = firstExisting(File(staging, DS_ENTRY), File(staging, LEGACY_DS_ENTRY))
                    ?: throw IllegalArgumentException("Backup settings are missing")
                require(stagedDs.isFile) { "Backup settings are missing" }

                if (formatVersion >= 3) {
                    verifyManifestProtectedEntries(manifest, staging, requireSelectiveState = true)
                    val stagedState = File(staging, STATE_ENTRY)
                    require(stagedState.isFile && stagedState.length() > 0L) { "Library state is missing" }
                    require(quickCheckSqlite(stagedState)) { "Library state failed SQLite quick_check" }
                    validateSelectiveState(stagedState)

                    stageDatastoreForNextStart(ctx, stagedDs)
                    VaultDb.closeForRestore()
                    return@withContext try {
                        applySelectiveLibraryState(ctx, stagedState)
                        Log.i(TAG, "Selective restore installed; settings apply on next cold start")
                        true
                    } catch (e: Exception) {
                        File(ctx.filesDir, PENDING_DIR).deleteRecursively()
                        runCatching { VaultDb.get(ctx).openHelper.writableDatabase }
                        throw e
                    }
                }

                // Legacy v1/v2 compatibility: those archives only contain a whole Room DB.
                val stagedDb = firstExisting(
                    File(staging, LEGACY_DB_V2_ENTRY),
                    File(staging, LEGACY_DB_V1_ENTRY)
                ) ?: throw IllegalArgumentException("Backup database is missing")
                require(stagedDb.length() > 0L && quickCheckSqlite(stagedDb)) {
                    "Legacy backup database failed validation"
                }
                if (formatVersion >= 2) {
                    verifyManifestProtectedEntries(manifest, staging, requireSelectiveState = false)
                }
                stageDatastoreForNextStart(ctx, stagedDs)
                val ok = installLegacyWholeDatabase(ctx, stagedDb)
                if (!ok) File(ctx.filesDir, PENDING_DIR).deleteRecursively()
                ok
            } catch (e: Exception) {
                Log.e(TAG, "applyBackup failed", e)
                File(ctx.filesDir, PENDING_DIR).deleteRecursively()
                false
            } finally {
                staging.deleteRecursively()
            }
        }

    private fun stageDatastoreForNextStart(ctx: Context, stagedDs: File) {
        val pendingRoot = File(ctx.filesDir, PENDING_DIR).apply { mkdirs() }
        val pendingDs = File(pendingRoot, PENDING_DS)
        val pendingMarker = File(pendingRoot, PENDING_MARKER)
        pendingDs.delete()
        copyFileChecked(stagedDs, pendingDs)
        require(pendingDs.length() == stagedDs.length()) { "Could not stage restored settings" }
        pendingMarker.writeText("ready", Charsets.UTF_8)
    }

    private data class EntryStats(val sha256: String, val size: Long)

    private class HashingEntryOutputStream(
        private val delegate: OutputStream,
        private val digest: MessageDigest = MessageDigest.getInstance("SHA-256")
    ) : OutputStream() {
        var count: Long = 0L
            private set

        override fun write(b: Int) {
            delegate.write(b)
            digest.update(b.toByte())
            count++
        }

        override fun write(b: ByteArray, off: Int, len: Int) {
            delegate.write(b, off, len)
            digest.update(b, off, len)
            count += len.toLong()
        }

        override fun flush() = delegate.flush()

        fun finish(): EntryStats = EntryStats(
            digest.digest().joinToString("") { "%02x".format(it) },
            count
        )
    }

    private inline fun writeProtectedEntry(
        zip: ZipOutputStream,
        name: String,
        writer: (OutputStream) -> Unit
    ): EntryStats {
        zip.putNextEntry(ZipEntry(name))
        val hashing = HashingEntryOutputStream(zip)
        writer(hashing)
        hashing.flush()
        val stats = hashing.finish()
        zip.closeEntry()
        return stats
    }

    private fun queryCount(db: SupportSQLiteDatabase, table: String): Long =
        db.query("SELECT COUNT(*) FROM `$table`").use { c ->
            require(c.moveToFirst()) { "Could not count $table" }
            c.getLong(0)
        }

    private fun writeString(out: DataOutputStream, value: String) {
        val bytes = value.toByteArray(Charsets.UTF_8)
        require(bytes.size <= MAX_STRING_BYTES) { "Backup string is too large" }
        out.writeInt(bytes.size)
        out.write(bytes)
    }

    private fun readString(input: DataInputStream): String {
        val size = input.readInt()
        require(size in 0..MAX_STRING_BYTES) { "Invalid string length in backup" }
        val bytes = ByteArray(size)
        input.readFully(bytes)
        return bytes.toString(Charsets.UTF_8)
    }

    private fun writeByteArray(out: DataOutputStream, value: ByteArray) {
        require(value.size <= MAX_BLOB_BYTES) { "Backup blob is too large" }
        out.writeInt(value.size)
        out.write(value)
    }

    private fun readByteArray(input: DataInputStream): ByteArray {
        val size = input.readInt()
        require(size in 0..MAX_BLOB_BYTES) { "Invalid blob length in backup" }
        return ByteArray(size).also { input.readFully(it) }
    }

    private fun requireStreamHeader(input: DataInputStream, expectedMagic: Int): Long {
        require(input.readInt() == expectedMagic) { "Backup stream has the wrong type" }
        require(input.readInt() == STREAM_SCHEMA_VERSION) { "Unsupported backup stream schema" }
        val count = input.readLong()
        require(count >= 0L) { "Invalid row count in backup" }
        return count
    }

    /**
     * Fully validates a v4 archive without extracting its large database payloads.
     * Checksums are calculated over the uncompressed entry bytes, so corruption in
     * either the ZIP or payload is caught before restore modifies the live database.
     */
    private fun validateV4Archive(ctx: Context, srcUri: Uri): JSONObject? {
        return try {
            val actual = linkedMapOf<String, EntryStats>()
            var manifest: JSONObject? = null
            val allowed = setOf(
                NOTES_ENTRY, TOPICS_ENTRY, LINKS_ENTRY, EMBEDDINGS_ENTRY, DS_ENTRY, MANIFEST_ENTRY
            )

            ctx.contentResolver.openInputStream(srcUri)?.buffered()?.use { raw ->
                ZipInputStream(raw).use { zip ->
                    val buffer = ByteArray(128 * 1024)
                    var entry = zip.nextEntry
                    while (entry != null) {
                        require(!entry.isDirectory && entry.name in allowed) {
                            "Unknown entry in MarkVault backup: ${entry.name}"
                        }
                        if (entry.name == MANIFEST_ENTRY) {
                            manifest = JSONObject(zip.readBytes().toString(Charsets.UTF_8))
                        } else {
                            val digest = MessageDigest.getInstance("SHA-256")
                            var size = 0L
                            while (true) {
                                val read = zip.read(buffer)
                                if (read <= 0) break
                                digest.update(buffer, 0, read)
                                size += read.toLong()
                            }
                            val hash = digest.digest().joinToString("") { "%02x".format(it) }
                            actual[entry.name] = EntryStats(hash, size)
                        }
                        zip.closeEntry()
                        entry = zip.nextEntry
                    }
                }
            } ?: return null

            val json = manifest ?: return null
            if (json.optString("app") != "MarkVault" || json.optInt("format_version", 0) != FORMAT_VERSION) {
                return null
            }
            if (json.optInt("stream_schema_version", 0) != STREAM_SCHEMA_VERSION) return null

            val required = setOf(NOTES_ENTRY, TOPICS_ENTRY, LINKS_ENTRY, EMBEDDINGS_ENTRY, DS_ENTRY)
            if (actual.keys != required) return null
            val checksums = json.optJSONObject("checksums") ?: return null
            val sizes = json.optJSONObject("sizes") ?: return null
            if (checksums.length() != required.size || sizes.length() != required.size) return null
            for (name in required) {
                val stats = actual[name] ?: return null
                if (!stats.sha256.equals(checksums.optString(name), ignoreCase = true)) return null
                if (stats.size != sizes.optLong(name, -1L)) return null
            }
            json
        } catch (e: Exception) {
            Log.e(TAG, "validateV4Archive failed", e)
            null
        }
    }

    private fun extractV4Settings(ctx: Context, srcUri: Uri, target: File) {
        target.parentFile?.mkdirs()
        target.delete()
        var found = false
        ctx.contentResolver.openInputStream(srcUri)?.buffered()?.use { raw ->
            ZipInputStream(raw).use { zip ->
                var entry = zip.nextEntry
                while (entry != null) {
                    if (entry.name == DS_ENTRY) {
                        FileOutputStream(target).use { output ->
                            zip.copyTo(output)
                            output.fd.sync()
                        }
                        found = true
                        zip.closeEntry()
                        break
                    }
                    zip.closeEntry()
                    entry = zip.nextEntry
                }
            }
        } ?: throw IllegalArgumentException("Backup file could not be opened")
        require(found && target.isFile) { "Backup settings are missing" }
    }

    private fun applyV4StreamedLibraryState(ctx: Context, srcUri: Uri, manifest: JSONObject) {
        val live = databaseFile(ctx)
        require(live.isFile && live.length() > 0L) { "Live MarkVault database is missing" }
        databaseWal(ctx).delete()
        databaseShm(ctx).delete()

        val db = SQLiteDatabase.openDatabase(live.absolutePath, null, SQLiteDatabase.OPEN_READWRITE)
        try {
            db.beginTransaction()
            try {
                db.execSQL(
                    "CREATE TEMP TABLE current_note_ui AS " +
                        "SELECT uri, lastOpened, lastScroll, favourite FROM notes"
                )
                db.execSQL("DELETE FROM note_embeddings")
                db.execSQL("DELETE FROM note_topics")
                db.execSQL("DELETE FROM note_links")
                db.execSQL("DELETE FROM notes")

                var restoredNotes = 0L
                var restoredEmbeddings = 0L
                var sawNotes = false
                var sawTopics = false
                var sawLinks = false
                var sawEmbeddings = false

                ctx.contentResolver.openInputStream(srcUri)?.buffered()?.use { raw ->
                    ZipInputStream(raw).use { zip ->
                        var entry = zip.nextEntry
                        while (entry != null) {
                            when (entry.name) {
                                NOTES_ENTRY -> {
                                    val input = DataInputStream(zip)
                                    val count = requireStreamHeader(input, MAGIC_NOTES)
                                    val stmt = db.compileStatement(
                                        "INSERT INTO notes(id, uri, relPath, name, title, folder, content, lastModified, size, " +
                                            "lastOpened, lastScroll, favourite, fileType) VALUES(?,?,?,?,?,?,?,?,?,0,0,0,?)"
                                    )
                                    repeatLong(count) {
                                        stmt.clearBindings()
                                        stmt.bindLong(1, input.readLong())
                                        stmt.bindString(2, readString(input))
                                        stmt.bindString(3, readString(input))
                                        stmt.bindString(4, readString(input))
                                        stmt.bindString(5, readString(input))
                                        stmt.bindString(6, readString(input))
                                        stmt.bindString(7, readString(input))
                                        stmt.bindLong(8, input.readLong())
                                        stmt.bindLong(9, input.readLong())
                                        stmt.bindString(10, readString(input))
                                        stmt.executeInsert()
                                    }
                                    restoredNotes = count
                                    sawNotes = true
                                }
                                TOPICS_ENTRY -> {
                                    val input = DataInputStream(zip)
                                    val count = requireStreamHeader(input, MAGIC_TOPICS)
                                    val stmt = db.compileStatement(
                                        "INSERT INTO note_topics(noteId, topic, score) VALUES(?,?,?)"
                                    )
                                    repeatLong(count) {
                                        stmt.clearBindings()
                                        stmt.bindLong(1, input.readLong())
                                        stmt.bindString(2, readString(input))
                                        stmt.bindLong(3, input.readInt().toLong())
                                        stmt.executeInsert()
                                    }
                                    sawTopics = true
                                }
                                LINKS_ENTRY -> {
                                    val input = DataInputStream(zip)
                                    val count = requireStreamHeader(input, MAGIC_LINKS)
                                    val stmt = db.compileStatement(
                                        "INSERT INTO note_links(fromId, target, targetNorm) VALUES(?,?,?)"
                                    )
                                    repeatLong(count) {
                                        stmt.clearBindings()
                                        stmt.bindLong(1, input.readLong())
                                        stmt.bindString(2, readString(input))
                                        stmt.bindString(3, readString(input))
                                        stmt.executeInsert()
                                    }
                                    sawLinks = true
                                }
                                EMBEDDINGS_ENTRY -> {
                                    val input = DataInputStream(zip)
                                    val count = requireStreamHeader(input, MAGIC_EMBEDDINGS)
                                    val stmt = db.compileStatement(
                                        "INSERT INTO note_embeddings(noteId, modelVersion, chunkIndex, dim, vector, " +
                                            "sourceLastModified, createdAt) VALUES(?,?,?,?,?,?,?)"
                                    )
                                    repeatLong(count) {
                                        stmt.clearBindings()
                                        stmt.bindLong(1, input.readLong())
                                        stmt.bindString(2, readString(input))
                                        stmt.bindLong(3, input.readInt().toLong())
                                        stmt.bindLong(4, input.readInt().toLong())
                                        stmt.bindBlob(5, readByteArray(input))
                                        stmt.bindLong(6, input.readLong())
                                        stmt.bindLong(7, input.readLong())
                                        stmt.executeInsert()
                                    }
                                    restoredEmbeddings = count
                                    sawEmbeddings = true
                                }
                            }
                            zip.closeEntry()
                            entry = zip.nextEntry
                        }
                    }
                } ?: throw IllegalArgumentException("Backup file could not be opened")

                require(sawNotes && sawTopics && sawLinks && sawEmbeddings) {
                    "Backup is missing required library streams"
                }
                require(restoredNotes == manifest.optLong("notes", -1L)) {
                    "Restored note count does not match the backup manifest"
                }
                require(restoredEmbeddings == manifest.optLong("embeddings", -1L)) {
                    "Restored embedding count does not match the backup manifest"
                }

                // Restore UI-only state for notes that still have the same URI. These values are
                // intentionally not part of the backup scope.
                db.execSQL(
                    "UPDATE notes SET " +
                        "lastOpened=COALESCE((SELECT u.lastOpened FROM current_note_ui u WHERE u.uri=notes.uri LIMIT 1),0), " +
                        "lastScroll=COALESCE((SELECT u.lastScroll FROM current_note_ui u WHERE u.uri=notes.uri LIMIT 1),0), " +
                        "favourite=COALESCE((SELECT u.favourite FROM current_note_ui u WHERE u.uri=notes.uri LIMIT 1),0)"
                )
                db.execSQL("INSERT INTO notes_fts(notes_fts) VALUES('rebuild')")
                db.execSQL("DROP TABLE current_note_ui")
                db.rawQuery("PRAGMA quick_check", null).use { cursor ->
                    require(cursor.moveToFirst() && cursor.getString(0).equals("ok", ignoreCase = true)) {
                        "Restored database failed SQLite quick_check before commit"
                    }
                }
                db.setTransactionSuccessful()
            } finally {
                db.endTransaction()
            }
        } finally {
            db.close()
        }
        require(quickCheckSqlite(live)) { "Live database failed SQLite quick_check after restore" }
    }

    private inline fun repeatLong(count: Long, block: (Long) -> Unit) {
        var i = 0L
        while (i < count) {
            block(i)
            i++
        }
    }

    /**
     * Creates a compact SQLite payload containing only library-index state.
     * FTS is deliberately omitted because it is deterministically rebuilt from
     * notes on restore; media embeddings are deliberately excluded.
     *
     * The destination is attached directly to Room's live SQLite connection and
     * populated inside one transaction. That gives all copied tables one coherent
     * point-in-time view without first duplicating the entire (potentially huge)
     * application database in cache.
     */
    private fun createSelectiveLibraryState(ctx: Context, target: File): Boolean {
        target.delete()
        target.parentFile?.mkdirs()
        val roomDb = VaultDb.get(ctx).openHelper.writableDatabase
        var attached = false
        return try {
            roomDb.execSQL("ATTACH DATABASE '${sqlPath(target)}' AS mvbackup")
            attached = true
            roomDb.beginTransaction()
            try {
                roomDb.execSQL(
                    "CREATE TABLE mvbackup.notes AS SELECT id AS backupId, uri, relPath, name, title, folder, " +
                        "content, lastModified, size, fileType FROM main.notes"
                )
                roomDb.execSQL(
                    "CREATE TABLE mvbackup.note_topics AS SELECT noteId, topic, score FROM main.note_topics"
                )
                roomDb.execSQL(
                    "CREATE TABLE mvbackup.note_links AS SELECT fromId, target, targetNorm FROM main.note_links"
                )
                roomDb.execSQL(
                    "CREATE TABLE mvbackup.note_embeddings AS SELECT noteId, modelVersion, chunkIndex, dim, vector, " +
                        "sourceLastModified, createdAt FROM main.note_embeddings"
                )
                roomDb.execSQL("CREATE INDEX mvbackup.idx_backup_notes_id ON notes(backupId)")
                roomDb.execSQL("CREATE INDEX mvbackup.idx_backup_topics_note ON note_topics(noteId)")
                roomDb.execSQL("CREATE INDEX mvbackup.idx_backup_links_note ON note_links(fromId)")
                roomDb.execSQL("CREATE INDEX mvbackup.idx_backup_embeddings_note ON note_embeddings(noteId)")
                roomDb.setTransactionSuccessful()
            } finally {
                roomDb.endTransaction()
            }
            roomDb.execSQL("DETACH DATABASE mvbackup")
            attached = false
            target.isFile && target.length() > 0L
        } catch (e: Exception) {
            Log.e(TAG, "createSelectiveLibraryState failed", e)
            false
        } finally {
            if (attached) runCatching { roomDb.execSQL("DETACH DATABASE mvbackup") }
        }
    }

    private fun validateSelectiveState(file: File) {
        val db = SQLiteDatabase.openDatabase(file.absolutePath, null, SQLiteDatabase.OPEN_READONLY)
        try {
            requireTableColumns(db, "notes", setOf(
                "backupId", "uri", "relPath", "name", "title", "folder", "content",
                "lastModified", "size", "fileType"
            ))
            requireTableColumns(db, "note_topics", setOf("noteId", "topic", "score"))
            requireTableColumns(db, "note_links", setOf("fromId", "target", "targetNorm"))
            requireTableColumns(db, "note_embeddings", setOf(
                "noteId", "modelVersion", "chunkIndex", "dim", "vector", "sourceLastModified", "createdAt"
            ))
        } finally {
            db.close()
        }
    }

    private fun requireTableColumns(db: SQLiteDatabase, table: String, required: Set<String>) {
        val found = mutableSetOf<String>()
        db.rawQuery("PRAGMA table_info(`$table`)", null).use { c ->
            val nameIdx = c.getColumnIndexOrThrow("name")
            while (c.moveToNext()) found += c.getString(nameIdx)
        }
        require(found.containsAll(required)) { "Backup table $table has an incompatible schema" }
    }

    private fun selectiveStateCounts(file: File): Pair<Long, Long> {
        val db = SQLiteDatabase.openDatabase(file.absolutePath, null, SQLiteDatabase.OPEN_READONLY)
        return try {
            fun count(table: String): Long = db.rawQuery("SELECT COUNT(*) FROM `$table`", null).use { c ->
                c.moveToFirst(); c.getLong(0)
            }
            count("notes") to count("note_embeddings")
        } finally {
            db.close()
        }
    }

    /** Merge only the requested state into the live Room DB, leaving all other tables untouched. */
    private fun applySelectiveLibraryState(ctx: Context, stateFile: File) {
        val live = databaseFile(ctx)
        require(live.isFile && live.length() > 0L) { "Live MarkVault database is missing" }
        databaseWal(ctx).delete()
        databaseShm(ctx).delete()

        val db = SQLiteDatabase.openDatabase(live.absolutePath, null, SQLiteDatabase.OPEN_READWRITE)
        try {
            db.execSQL("ATTACH DATABASE '${sqlPath(stateFile)}' AS restore")
            db.beginTransaction()
            try {
                // Keep UI-only note state that is not part of the requested backup scope.
                db.execSQL(
                    "CREATE TEMP TABLE current_note_ui AS " +
                        "SELECT uri, relPath, lastOpened, lastScroll, favourite FROM notes"
                )

                db.execSQL("DELETE FROM note_embeddings")
                db.execSQL("DELETE FROM note_topics")
                db.execSQL("DELETE FROM note_links")
                db.execSQL("DELETE FROM notes")

                db.execSQL(
                    "INSERT INTO notes(id, uri, relPath, name, title, folder, content, lastModified, size, " +
                        "lastOpened, lastScroll, favourite, fileType) " +
                        "SELECT r.backupId, r.uri, r.relPath, r.name, r.title, r.folder, r.content, " +
                        "r.lastModified, r.size, " +
                        "COALESCE((SELECT u.lastOpened FROM current_note_ui u WHERE u.uri=r.uri LIMIT 1), 0), " +
                        "COALESCE((SELECT u.lastScroll FROM current_note_ui u WHERE u.uri=r.uri LIMIT 1), 0), " +
                        "COALESCE((SELECT u.favourite FROM current_note_ui u WHERE u.uri=r.uri LIMIT 1), 0), " +
                        "r.fileType FROM restore.notes r"
                )
                db.execSQL(
                    "INSERT INTO note_topics(noteId, topic, score) " +
                        "SELECT noteId, topic, score FROM restore.note_topics"
                )
                db.execSQL(
                    "INSERT INTO note_links(fromId, target, targetNorm) " +
                        "SELECT fromId, target, targetNorm FROM restore.note_links"
                )
                db.execSQL(
                    "INSERT INTO note_embeddings(noteId, modelVersion, chunkIndex, dim, vector, sourceLastModified, createdAt) " +
                        "SELECT noteId, modelVersion, chunkIndex, dim, vector, sourceLastModified, createdAt " +
                        "FROM restore.note_embeddings"
                )

                // notes_fts is a Room FTS4 external-content table. Rebuild it from the
                // restored notes instead of storing a duplicate copy in the backup.
                db.execSQL("INSERT INTO notes_fts(notes_fts) VALUES('rebuild')")
                db.execSQL("DROP TABLE current_note_ui")
                db.rawQuery("PRAGMA quick_check", null).use { cursor ->
                    require(cursor.moveToFirst() && cursor.getString(0).equals("ok", ignoreCase = true)) {
                        "Restored database failed SQLite quick_check before commit"
                    }
                }
                db.setTransactionSuccessful()
            } finally {
                db.endTransaction()
            }
            db.execSQL("DETACH DATABASE restore")
        } finally {
            db.close()
        }
        require(quickCheckSqlite(live)) { "Live database failed SQLite quick_check after restore" }
    }

    /** Legacy whole-DB replacement, used only when restoring old v1/v2 archives. */
    private fun installLegacyWholeDatabase(ctx: Context, stagedDb: File): Boolean {
        val rollback = File(ctx.cacheDir, "restore_legacy_rollback_${System.nanoTime()}")
        val target = databaseFile(ctx)
        var moved = false
        var installed = false
        return try {
            rollback.mkdirs()
            VaultDb.closeForRestore()
            target.parentFile?.mkdirs()
            val old = File(rollback, "markvault.db")
            if (target.exists()) {
                require(target.renameTo(old)) { "Could not protect current database" }
                moved = true
            }
            databaseWal(ctx).delete()
            databaseShm(ctx).delete()
            val incoming = File(target.parentFile, "markvault.db.restore_incoming")
            incoming.delete()
            copyFileChecked(stagedDb, incoming)
            require(incoming.renameTo(target)) { "Could not install legacy backup database" }
            installed = true
            require(quickCheckSqlite(target)) { "Installed legacy database failed SQLite quick_check" }
            true
        } catch (e: Exception) {
            Log.e(TAG, "Legacy database restore failed; rolling back", e)
            runCatching {
                val old = File(rollback, "markvault.db")
                if (installed) target.delete()
                if (moved && old.exists()) require(old.renameTo(target)) { "Legacy DB rollback failed" }
                databaseWal(ctx).delete()
                databaseShm(ctx).delete()
            }
            runCatching { VaultDb.get(ctx).openHelper.writableDatabase }
            false
        } finally {
            rollback.deleteRecursively()
        }
    }

    private fun createDatabaseSnapshot(ctx: Context, target: File): Boolean {
        target.delete()
        target.parentFile?.mkdirs()
        val roomDb = VaultDb.get(ctx).openHelper.writableDatabase

        val escaped = target.absolutePath.replace("'", "''")
        val vacuumOk = runCatching {
            roomDb.execSQL("VACUUM INTO '$escaped'")
            target.isFile && target.length() > 0L
        }.getOrElse {
            Log.i(TAG, "VACUUM INTO unavailable; using locked checkpoint snapshot: ${it.message}")
            false
        }
        if (vacuumOk) return true

        return runCatching {
            roomDb.execSQL("PRAGMA wal_checkpoint(TRUNCATE)")
            roomDb.beginTransaction()
            try {
                val live = databaseFile(ctx)
                require(live.isFile && live.length() > 0L) { "Live database missing" }
                copyFileChecked(live, target)
                roomDb.setTransactionSuccessful()
            } finally {
                roomDb.endTransaction()
            }
            target.isFile && target.length() > 0L
        }.getOrElse {
            Log.e(TAG, "Locked database snapshot failed", it)
            false
        }
    }

    private fun extractRecognisedEntries(ctx: Context, srcUri: Uri, staging: File): JSONObject? {
        var manifest: JSONObject? = null
        ctx.contentResolver.openInputStream(srcUri)?.buffered()?.use { raw ->
            ZipInputStream(raw).use { zip ->
                var entry = zip.nextEntry
                while (entry != null) {
                    val name = entry.name
                    if (!entry.isDirectory && isRecognisedEntry(name)) {
                        if (name == MANIFEST_ENTRY) {
                            manifest = JSONObject(zip.readBytes().toString(Charsets.UTF_8))
                        } else {
                            val output = safeStagingFile(staging, name)
                            output.parentFile?.mkdirs()
                            FileOutputStream(output).use { zip.copyTo(it) }
                        }
                    }
                    zip.closeEntry()
                    entry = zip.nextEntry
                }
            }
        } ?: return null
        return manifest?.takeIf { it.optString("app") == "MarkVault" }
    }

    private fun isRecognisedEntry(name: String): Boolean =
        name == MANIFEST_ENTRY || name == STATE_ENTRY || name == DS_ENTRY ||
            name == LEGACY_DB_V2_ENTRY || name == LEGACY_DB_V1_ENTRY || name == LEGACY_DS_ENTRY ||
            name == LEGACY_ACTIVITY_ENTRY || name.startsWith(LEGACY_LYRICS_PREFIX) ||
            name.startsWith(LEGACY_TRANSCRIPTS_PREFIX)

    private fun safeStagingFile(root: File, entryName: String): File {
        require(!entryName.startsWith("/") && !entryName.contains("..")) { "Unsafe ZIP entry" }
        val file = File(root, entryName)
        val rootPath = root.canonicalPath
        val filePath = file.canonicalPath
        require(filePath == rootPath || filePath.startsWith(rootPath + File.separator)) {
            "ZIP entry escapes staging directory"
        }
        return file
    }

    private fun verifyManifestProtectedEntries(
        manifest: JSONObject,
        staging: File,
        requireSelectiveState: Boolean
    ) {
        val checksums = manifest.optJSONObject("checksums")
            ?: throw IllegalArgumentException("Backup checksum table is missing")
        val sizes = manifest.optJSONObject("sizes")
            ?: throw IllegalArgumentException("Backup size table is missing")

        val keys = checksums.keys()
        var protectedCount = 0
        while (keys.hasNext()) {
            val entry = keys.next()
            require(isRecognisedEntry(entry) && entry != MANIFEST_ENTRY) { "Unknown protected backup entry" }
            val file = safeStagingFile(staging, entry)
            require(file.isFile) { "Backup entry missing: $entry" }
            require(file.length() == sizes.optLong(entry, -1L)) { "Backup size mismatch: $entry" }
            require(sha256(file).equals(checksums.optString(entry), ignoreCase = true)) {
                "Backup checksum mismatch: $entry"
            }
            protectedCount++
        }
        require(protectedCount >= 2) { "Backup does not contain required protected data" }
        if (requireSelectiveState) {
            require(checksums.has(STATE_ENTRY) && checksums.has(DS_ENTRY)) {
                "Required v3 entries are not protected"
            }
        } else {
            require(
                (checksums.has(LEGACY_DB_V2_ENTRY) || checksums.has(LEGACY_DB_V1_ENTRY)) &&
                    (checksums.has(DS_ENTRY) || checksums.has(LEGACY_DS_ENTRY))
            ) { "Required legacy entries are not protected" }
        }

        val extracted = staging.walkTopDown()
            .filter { it.isFile }
            .map { it.relativeTo(staging).invariantSeparatorsPath }
            .filter { it != MANIFEST_ENTRY }
            .toList()
        require(extracted.all { checksums.has(it) }) { "Backup contains unprotected data entries" }
        require(extracted.size == protectedCount) { "Backup checksum table does not match extracted data" }
    }

    private fun firstExisting(vararg files: File): File? = files.firstOrNull { it.isFile }

    private fun copyFileChecked(source: File, target: File) {
        require(source.isFile) { "Source file does not exist: ${source.name}" }
        target.parentFile?.mkdirs()
        FileInputStream(source).use { input ->
            FileOutputStream(target).use { output ->
                input.copyTo(output)
                output.fd.sync()
            }
        }
        require(target.isFile && target.length() == source.length()) {
            "File copy verification failed: ${source.name}"
        }
    }

    private fun quickCheckSqlite(file: File): Boolean = try {
        val db = SQLiteDatabase.openDatabase(file.absolutePath, null, SQLiteDatabase.OPEN_READONLY)
        db.use {
            it.rawQuery("PRAGMA quick_check", null).use { cursor ->
                cursor.moveToFirst() && cursor.getString(0).equals("ok", ignoreCase = true)
            }
        }
    } catch (e: Exception) {
        Log.e(TAG, "SQLite quick_check failed for ${file.name}", e)
        false
    }

    private fun sha256(file: File): String {
        val digest = MessageDigest.getInstance("SHA-256")
        FileInputStream(file).use { input ->
            val buffer = ByteArray(128 * 1024)
            while (true) {
                val read = input.read(buffer)
                if (read <= 0) break
                digest.update(buffer, 0, read)
            }
        }
        return digest.digest().joinToString("") { "%02x".format(it) }
    }

    private fun sqlPath(file: File): String = file.absolutePath.replace("'", "''")
}
