package com.tebogo.markvault.data

import android.content.Context
import android.database.sqlite.SQLiteDatabase
import android.net.Uri
import android.util.Log
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONObject
import java.io.File
import java.io.FileInputStream
import java.io.FileOutputStream
import java.security.MessageDigest
import java.util.zip.ZipEntry
import java.util.zip.ZipInputStream
import java.util.zip.ZipOutputStream

/**
 * MarkVault backup / restore.
 *
 * Backup v3 intentionally contains ONLY:
 *  • DataStore settings
 *  • the library index (notes + topic/link index data; FTS is rebuilt from notes)
 *  • note semantic embeddings
 *
 * Article files, browser/PDF history, bookmarks, annotations, media caches,
 * playlists, activity logs, downloaded models, and media embeddings are excluded.
 *
 * v1/v2 archives remain readable for backwards compatibility. Their database is
 * restored with the legacy whole-database path because those formats did not
 * contain a selective library-state database.
 */
object BackupManager {

    private const val TAG = "MV-BackupManager"
    private const val FORMAT_VERSION = 3

    private const val MANIFEST_ENTRY = "manifest.json"
    private const val STATE_ENTRY = "library/library_state.db"
    private const val DS_ENTRY = "settings/settings.preferences_pb"

    // Legacy v1/v2 entry names retained for old-backup restore support.
    private const val LEGACY_DB_V2_ENTRY = "database/markvault.db"
    private const val LEGACY_DB_V1_ENTRY = "markvault.db"
    private const val LEGACY_DS_ENTRY = "settings.preferences_pb"
    private const val LEGACY_LYRICS_PREFIX = "media/song_lyrics/"
    private const val LEGACY_TRANSCRIPTS_PREFIX = "media/video_transcripts/"
    private const val LEGACY_ACTIVITY_ENTRY = "optional/activity_log.jsonl"

    private const val PENDING_DIR = "restore_pending"
    private const val PENDING_DS = "settings.preferences_pb"
    private const val PENDING_MARKER = "pending_datastore_restore"

    private data class BackupSource(val entryName: String, val file: File)

    fun databaseFile(ctx: Context): File = ctx.getDatabasePath("markvault.db")
    private fun databaseWal(ctx: Context): File = ctx.getDatabasePath("markvault.db-wal")
    private fun databaseShm(ctx: Context): File = ctx.getDatabasePath("markvault.db-shm")

    fun datastoreFile(ctx: Context): File =
        File(ctx.filesDir, "datastore/settings.preferences_pb")

    /** Apply a staged DataStore restore before the DataStore singleton is created. */
    fun applyPendingDatastoreRestore(ctx: Context) {
        val pendingRoot = File(ctx.filesDir, PENDING_DIR)
        val marker = File(pendingRoot, PENDING_MARKER)
        val staged = File(pendingRoot, PENDING_DS)
        if (!marker.exists()) return

        val target = datastoreFile(ctx)
        val rollback = File(target.parentFile, "${target.name}.pre_restore")
        try {
            require(staged.isFile) {
                "Pending DataStore restore is missing"
            }
            target.parentFile?.mkdirs()
            rollback.delete()
            if (target.exists()) {
                require(target.renameTo(rollback)) { "Could not create DataStore rollback copy" }
            }
            try {
                copyFileChecked(staged, target)
                require(target.isFile && target.length() == staged.length()) {
                    "Restored DataStore size mismatch"
                }
                rollback.delete()
                staged.delete()
                marker.delete()
                pendingRoot.delete()
                Log.i(TAG, "Pending DataStore restore applied")
            } catch (e: Exception) {
                target.delete()
                if (rollback.exists()) rollback.renameTo(target)
                throw e
            }
        } catch (e: Exception) {
            Log.e(TAG, "Pending DataStore restore failed; original preferences retained", e)
        }
    }

    suspend fun createBackup(
        ctx: Context,
        destUri: Uri,
        versionName: String
    ): Boolean = withContext(Dispatchers.IO) {
        val tempRoot = File(ctx.cacheDir, "backup_staging_${System.nanoTime()}")
        try {
            tempRoot.mkdirs()
            val libraryState = File(tempRoot, "library_state.db")
            val dsSnapshot = File(tempRoot, "settings.preferences_pb")

            // Copy only the requested tables directly from Room while holding a database
            // transaction. This avoids creating a second full markvault.db first — important
            // when the library and embedding table are large and free storage is limited.
            if (!createSelectiveLibraryState(ctx, libraryState)) {
                Log.e(TAG, "Backup aborted: selective library state could not be created")
                return@withContext false
            }
            require(libraryState.isFile && libraryState.length() > 0L && quickCheckSqlite(libraryState)) {
                "Selective library state failed validation"
            }
            validateSelectiveState(libraryState)

            val dsLive = datastoreFile(ctx)
            if (!dsLive.isFile) {
                Log.e(TAG, "Backup aborted: DataStore file is missing")
                return@withContext false
            }
            copyFileChecked(dsLive, dsSnapshot)

            val sources = listOf(
                BackupSource(STATE_ENTRY, libraryState),
                BackupSource(DS_ENTRY, dsSnapshot)
            )
            val checksums = JSONObject()
            val sizes = JSONObject()
            for (source in sources) {
                checksums.put(source.entryName, sha256(source.file))
                sizes.put(source.entryName, source.file.length())
            }
            val counts = selectiveStateCounts(libraryState)

            val manifest = JSONObject().apply {
                put("app", "MarkVault")
                put("format_version", FORMAT_VERSION)
                put("version", versionName)
                put("timestamp", System.currentTimeMillis())
                put("state_entry", STATE_ENTRY)
                put("ds_entry", DS_ENTRY)
                put("scope", "settings+library_index+note_embeddings")
                put("notes", counts.first)
                put("embeddings", counts.second)
                put("checksums", checksums)
                put("sizes", sizes)
            }.toString(2)

            val out = ctx.contentResolver.openOutputStream(destUri, "w")
                ?: return@withContext false.also { Log.e(TAG, "Could not open backup output stream") }
            out.buffered().use { raw ->
                ZipOutputStream(raw).use { zip ->
                    zip.putNextEntry(ZipEntry(MANIFEST_ENTRY))
                    zip.write(manifest.toByteArray(Charsets.UTF_8))
                    zip.closeEntry()
                    for (source in sources) {
                        zip.putNextEntry(ZipEntry(source.entryName))
                        FileInputStream(source.file).use { it.copyTo(zip) }
                        zip.closeEntry()
                    }
                }
            }

            Log.i(TAG, "Backup v3 written: settings + library index + note embeddings only")
            true
        } catch (e: Exception) {
            Log.e(TAG, "createBackup failed", e)
            false
        } finally {
            tempRoot.deleteRecursively()
        }
    }

    /** Return the manifest only for a structurally restorable MarkVault archive. */
    suspend fun readManifest(ctx: Context, srcUri: Uri): JSONObject? =
        withContext(Dispatchers.IO) {
            try {
                var manifest: JSONObject? = null
                var hasState = false
                var hasLegacyDb = false
                var hasDs = false
                ctx.contentResolver.openInputStream(srcUri)?.buffered()?.use { raw ->
                    ZipInputStream(raw).use { zip ->
                        var entry = zip.nextEntry
                        while (entry != null) {
                            when (entry.name) {
                                MANIFEST_ENTRY -> manifest = JSONObject(zip.readBytes().toString(Charsets.UTF_8))
                                STATE_ENTRY -> hasState = true
                                LEGACY_DB_V2_ENTRY, LEGACY_DB_V1_ENTRY -> hasLegacyDb = true
                                DS_ENTRY, LEGACY_DS_ENTRY -> hasDs = true
                            }
                            zip.closeEntry()
                            entry = zip.nextEntry
                        }
                    }
                } ?: return@withContext null

                val json = manifest ?: return@withContext null
                if (json.optString("app") != "MarkVault" || !hasDs) return@withContext null
                val version = json.optInt("format_version", 1)
                if (version >= 3 && !hasState) return@withContext null
                if (version < 3 && !hasLegacyDb) return@withContext null
                json
            } catch (e: Exception) {
                Log.e(TAG, "readManifest failed", e)
                null
            }
        }

    suspend fun applyBackup(ctx: Context, srcUri: Uri): Boolean =
        withContext(Dispatchers.IO) {
            val staging = File(ctx.cacheDir, "restore_staging_${System.nanoTime()}")
            try {
                staging.mkdirs()
                val manifest = extractRecognisedEntries(ctx, srcUri, staging)
                    ?: throw IllegalArgumentException("Backup is missing a valid manifest")
                val formatVersion = manifest.optInt("format_version", 1)

                val stagedDs = firstExisting(File(staging, DS_ENTRY), File(staging, LEGACY_DS_ENTRY))
                    ?: throw IllegalArgumentException("Backup settings are missing")
                require(stagedDs.isFile) { "Backup settings are missing" }

                if (formatVersion >= 3) {
                    verifyManifestProtectedEntries(manifest, staging, requireSelectiveState = true)
                    val stagedState = File(staging, STATE_ENTRY)
                    require(stagedState.isFile && stagedState.length() > 0L) { "Library state is missing" }
                    require(quickCheckSqlite(stagedState)) { "Library state failed SQLite quick_check" }
                    validateSelectiveState(stagedState)

                    stageDatastoreForNextStart(ctx, stagedDs)
                    VaultDb.closeForRestore()
                    return@withContext try {
                        applySelectiveLibraryState(ctx, stagedState)
                        Log.i(TAG, "Selective restore installed; settings apply on next cold start")
                        true
                    } catch (e: Exception) {
                        File(ctx.filesDir, PENDING_DIR).deleteRecursively()
                        runCatching { VaultDb.get(ctx).openHelper.writableDatabase }
                        throw e
                    }
                }

                // Legacy v1/v2 compatibility: those archives only contain a whole Room DB.
                val stagedDb = firstExisting(
                    File(staging, LEGACY_DB_V2_ENTRY),
                    File(staging, LEGACY_DB_V1_ENTRY)
                ) ?: throw IllegalArgumentException("Backup database is missing")
                require(stagedDb.length() > 0L && quickCheckSqlite(stagedDb)) {
                    "Legacy backup database failed validation"
                }
                if (formatVersion >= 2) {
                    verifyManifestProtectedEntries(manifest, staging, requireSelectiveState = false)
                }
                stageDatastoreForNextStart(ctx, stagedDs)
                val ok = installLegacyWholeDatabase(ctx, stagedDb)
                if (!ok) File(ctx.filesDir, PENDING_DIR).deleteRecursively()
                ok
            } catch (e: Exception) {
                Log.e(TAG, "applyBackup failed", e)
                File(ctx.filesDir, PENDING_DIR).deleteRecursively()
                false
            } finally {
                staging.deleteRecursively()
            }
        }

    private fun stageDatastoreForNextStart(ctx: Context, stagedDs: File) {
        val pendingRoot = File(ctx.filesDir, PENDING_DIR).apply { mkdirs() }
        val pendingDs = File(pendingRoot, PENDING_DS)
        val pendingMarker = File(pendingRoot, PENDING_MARKER)
        pendingDs.delete()
        copyFileChecked(stagedDs, pendingDs)
        require(pendingDs.length() == stagedDs.length()) { "Could not stage restored settings" }
        pendingMarker.writeText("ready", Charsets.UTF_8)
    }

    /**
     * Creates a compact SQLite payload containing only library-index state.
     * FTS is deliberately omitted because it is deterministically rebuilt from
     * notes on restore; media embeddings are deliberately excluded.
     *
     * The destination is attached directly to Room's live SQLite connection and
     * populated inside one transaction. That gives all copied tables one coherent
     * point-in-time view without first duplicating the entire (potentially huge)
     * application database in cache.
     */
    private fun createSelectiveLibraryState(ctx: Context, target: File): Boolean {
        target.delete()
        target.parentFile?.mkdirs()
        val roomDb = VaultDb.get(ctx).openHelper.writableDatabase
        var attached = false
        return try {
            roomDb.execSQL("ATTACH DATABASE '${sqlPath(target)}' AS mvbackup")
            attached = true
            roomDb.beginTransaction()
            try {
                roomDb.execSQL(
                    "CREATE TABLE mvbackup.notes AS SELECT id AS backupId, uri, relPath, name, title, folder, " +
                        "content, lastModified, size, fileType FROM main.notes"
                )
                roomDb.execSQL(
                    "CREATE TABLE mvbackup.note_topics AS SELECT noteId, topic, score FROM main.note_topics"
                )
                roomDb.execSQL(
                    "CREATE TABLE mvbackup.note_links AS SELECT fromId, target, targetNorm FROM main.note_links"
                )
                roomDb.execSQL(
                    "CREATE TABLE mvbackup.note_embeddings AS SELECT noteId, modelVersion, chunkIndex, dim, vector, " +
                        "sourceLastModified, createdAt FROM main.note_embeddings"
                )
                roomDb.execSQL("CREATE INDEX mvbackup.idx_backup_notes_id ON notes(backupId)")
                roomDb.execSQL("CREATE INDEX mvbackup.idx_backup_topics_note ON note_topics(noteId)")
                roomDb.execSQL("CREATE INDEX mvbackup.idx_backup_links_note ON note_links(fromId)")
                roomDb.execSQL("CREATE INDEX mvbackup.idx_backup_embeddings_note ON note_embeddings(noteId)")
                roomDb.setTransactionSuccessful()
            } finally {
                roomDb.endTransaction()
            }
            roomDb.execSQL("DETACH DATABASE mvbackup")
            attached = false
            target.isFile && target.length() > 0L
        } catch (e: Exception) {
            Log.e(TAG, "createSelectiveLibraryState failed", e)
            false
        } finally {
            if (attached) runCatching { roomDb.execSQL("DETACH DATABASE mvbackup") }
        }
    }

    private fun validateSelectiveState(file: File) {
        val db = SQLiteDatabase.openDatabase(file.absolutePath, null, SQLiteDatabase.OPEN_READONLY)
        try {
            requireTableColumns(db, "notes", setOf(
                "backupId", "uri", "relPath", "name", "title", "folder", "content",
                "lastModified", "size", "fileType"
            ))
            requireTableColumns(db, "note_topics", setOf("noteId", "topic", "score"))
            requireTableColumns(db, "note_links", setOf("fromId", "target", "targetNorm"))
            requireTableColumns(db, "note_embeddings", setOf(
                "noteId", "modelVersion", "chunkIndex", "dim", "vector", "sourceLastModified", "createdAt"
            ))
        } finally {
            db.close()
        }
    }

    private fun requireTableColumns(db: SQLiteDatabase, table: String, required: Set<String>) {
        val found = mutableSetOf<String>()
        db.rawQuery("PRAGMA table_info(`$table`)", null).use { c ->
            val nameIdx = c.getColumnIndexOrThrow("name")
            while (c.moveToNext()) found += c.getString(nameIdx)
        }
        require(found.containsAll(required)) { "Backup table $table has an incompatible schema" }
    }

    private fun selectiveStateCounts(file: File): Pair<Long, Long> {
        val db = SQLiteDatabase.openDatabase(file.absolutePath, null, SQLiteDatabase.OPEN_READONLY)
        return try {
            fun count(table: String): Long = db.rawQuery("SELECT COUNT(*) FROM `$table`", null).use { c ->
                c.moveToFirst(); c.getLong(0)
            }
            count("notes") to count("note_embeddings")
        } finally {
            db.close()
        }
    }

    /** Merge only the requested state into the live Room DB, leaving all other tables untouched. */
    private fun applySelectiveLibraryState(ctx: Context, stateFile: File) {
        val live = databaseFile(ctx)
        require(live.isFile && live.length() > 0L) { "Live MarkVault database is missing" }
        databaseWal(ctx).delete()
        databaseShm(ctx).delete()

        val db = SQLiteDatabase.openDatabase(live.absolutePath, null, SQLiteDatabase.OPEN_READWRITE)
        try {
            db.execSQL("ATTACH DATABASE '${sqlPath(stateFile)}' AS restore")
            db.beginTransaction()
            try {
                // Keep UI-only note state that is not part of the requested backup scope.
                db.execSQL(
                    "CREATE TEMP TABLE current_note_ui AS " +
                        "SELECT uri, relPath, lastOpened, lastScroll, favourite FROM notes"
                )

                db.execSQL("DELETE FROM note_embeddings")
                db.execSQL("DELETE FROM note_topics")
                db.execSQL("DELETE FROM note_links")
                db.execSQL("DELETE FROM notes")

                db.execSQL(
                    "INSERT INTO notes(id, uri, relPath, name, title, folder, content, lastModified, size, " +
                        "lastOpened, lastScroll, favourite, fileType) " +
                        "SELECT r.backupId, r.uri, r.relPath, r.name, r.title, r.folder, r.content, " +
                        "r.lastModified, r.size, " +
                        "COALESCE((SELECT u.lastOpened FROM current_note_ui u WHERE u.uri=r.uri LIMIT 1), 0), " +
                        "COALESCE((SELECT u.lastScroll FROM current_note_ui u WHERE u.uri=r.uri LIMIT 1), 0), " +
                        "COALESCE((SELECT u.favourite FROM current_note_ui u WHERE u.uri=r.uri LIMIT 1), 0), " +
                        "r.fileType FROM restore.notes r"
                )
                db.execSQL(
                    "INSERT INTO note_topics(noteId, topic, score) " +
                        "SELECT noteId, topic, score FROM restore.note_topics"
                )
                db.execSQL(
                    "INSERT INTO note_links(fromId, target, targetNorm) " +
                        "SELECT fromId, target, targetNorm FROM restore.note_links"
                )
                db.execSQL(
                    "INSERT INTO note_embeddings(noteId, modelVersion, chunkIndex, dim, vector, sourceLastModified, createdAt) " +
                        "SELECT noteId, modelVersion, chunkIndex, dim, vector, sourceLastModified, createdAt " +
                        "FROM restore.note_embeddings"
                )

                // notes_fts is a Room FTS4 external-content table. Rebuild it from the
                // restored notes instead of storing a duplicate copy in the backup.
                db.execSQL("INSERT INTO notes_fts(notes_fts) VALUES('rebuild')")
                db.execSQL("DROP TABLE current_note_ui")
                db.rawQuery("PRAGMA quick_check", null).use { cursor ->
                    require(cursor.moveToFirst() && cursor.getString(0).equals("ok", ignoreCase = true)) {
                        "Restored database failed SQLite quick_check before commit"
                    }
                }
                db.setTransactionSuccessful()
            } finally {
                db.endTransaction()
            }
            db.execSQL("DETACH DATABASE restore")
        } finally {
            db.close()
        }
        require(quickCheckSqlite(live)) { "Live database failed SQLite quick_check after restore" }
    }

    /** Legacy whole-DB replacement, used only when restoring old v1/v2 archives. */
    private fun installLegacyWholeDatabase(ctx: Context, stagedDb: File): Boolean {
        val rollback = File(ctx.cacheDir, "restore_legacy_rollback_${System.nanoTime()}")
        val target = databaseFile(ctx)
        var moved = false
        var installed = false
        return try {
            rollback.mkdirs()
            VaultDb.closeForRestore()
            target.parentFile?.mkdirs()
            val old = File(rollback, "markvault.db")
            if (target.exists()) {
                require(target.renameTo(old)) { "Could not protect current database" }
                moved = true
            }
            databaseWal(ctx).delete()
            databaseShm(ctx).delete()
            val incoming = File(target.parentFile, "markvault.db.restore_incoming")
            incoming.delete()
            copyFileChecked(stagedDb, incoming)
            require(incoming.renameTo(target)) { "Could not install legacy backup database" }
            installed = true
            require(quickCheckSqlite(target)) { "Installed legacy database failed SQLite quick_check" }
            true
        } catch (e: Exception) {
            Log.e(TAG, "Legacy database restore failed; rolling back", e)
            runCatching {
                val old = File(rollback, "markvault.db")
                if (installed) target.delete()
                if (moved && old.exists()) require(old.renameTo(target)) { "Legacy DB rollback failed" }
                databaseWal(ctx).delete()
                databaseShm(ctx).delete()
            }
            runCatching { VaultDb.get(ctx).openHelper.writableDatabase }
            false
        } finally {
            rollback.deleteRecursively()
        }
    }

    private fun createDatabaseSnapshot(ctx: Context, target: File): Boolean {
        target.delete()
        target.parentFile?.mkdirs()
        val roomDb = VaultDb.get(ctx).openHelper.writableDatabase

        val escaped = target.absolutePath.replace("'", "''")
        val vacuumOk = runCatching {
            roomDb.execSQL("VACUUM INTO '$escaped'")
            target.isFile && target.length() > 0L
        }.getOrElse {
            Log.i(TAG, "VACUUM INTO unavailable; using locked checkpoint snapshot: ${it.message}")
            false
        }
        if (vacuumOk) return true

        return runCatching {
            roomDb.execSQL("PRAGMA wal_checkpoint(TRUNCATE)")
            roomDb.beginTransaction()
            try {
                val live = databaseFile(ctx)
                require(live.isFile && live.length() > 0L) { "Live database missing" }
                copyFileChecked(live, target)
                roomDb.setTransactionSuccessful()
            } finally {
                roomDb.endTransaction()
            }
            target.isFile && target.length() > 0L
        }.getOrElse {
            Log.e(TAG, "Locked database snapshot failed", it)
            false
        }
    }

    private fun extractRecognisedEntries(ctx: Context, srcUri: Uri, staging: File): JSONObject? {
        var manifest: JSONObject? = null
        ctx.contentResolver.openInputStream(srcUri)?.buffered()?.use { raw ->
            ZipInputStream(raw).use { zip ->
                var entry = zip.nextEntry
                while (entry != null) {
                    val name = entry.name
                    if (!entry.isDirectory && isRecognisedEntry(name)) {
                        if (name == MANIFEST_ENTRY) {
                            manifest = JSONObject(zip.readBytes().toString(Charsets.UTF_8))
                        } else {
                            val output = safeStagingFile(staging, name)
                            output.parentFile?.mkdirs()
                            FileOutputStream(output).use { zip.copyTo(it) }
                        }
                    }
                    zip.closeEntry()
                    entry = zip.nextEntry
                }
            }
        } ?: return null
        return manifest?.takeIf { it.optString("app") == "MarkVault" }
    }

    private fun isRecognisedEntry(name: String): Boolean =
        name == MANIFEST_ENTRY || name == STATE_ENTRY || name == DS_ENTRY ||
            name == LEGACY_DB_V2_ENTRY || name == LEGACY_DB_V1_ENTRY || name == LEGACY_DS_ENTRY ||
            name == LEGACY_ACTIVITY_ENTRY || name.startsWith(LEGACY_LYRICS_PREFIX) ||
            name.startsWith(LEGACY_TRANSCRIPTS_PREFIX)

    private fun safeStagingFile(root: File, entryName: String): File {
        require(!entryName.startsWith("/") && !entryName.contains("..")) { "Unsafe ZIP entry" }
        val file = File(root, entryName)
        val rootPath = root.canonicalPath
        val filePath = file.canonicalPath
        require(filePath == rootPath || filePath.startsWith(rootPath + File.separator)) {
            "ZIP entry escapes staging directory"
        }
        return file
    }

    private fun verifyManifestProtectedEntries(
        manifest: JSONObject,
        staging: File,
        requireSelectiveState: Boolean
    ) {
        val checksums = manifest.optJSONObject("checksums")
            ?: throw IllegalArgumentException("Backup checksum table is missing")
        val sizes = manifest.optJSONObject("sizes")
            ?: throw IllegalArgumentException("Backup size table is missing")

        val keys = checksums.keys()
        var protectedCount = 0
        while (keys.hasNext()) {
            val entry = keys.next()
            require(isRecognisedEntry(entry) && entry != MANIFEST_ENTRY) { "Unknown protected backup entry" }
            val file = safeStagingFile(staging, entry)
            require(file.isFile) { "Backup entry missing: $entry" }
            require(file.length() == sizes.optLong(entry, -1L)) { "Backup size mismatch: $entry" }
            require(sha256(file).equals(checksums.optString(entry), ignoreCase = true)) {
                "Backup checksum mismatch: $entry"
            }
            protectedCount++
        }
        require(protectedCount >= 2) { "Backup does not contain required protected data" }
        if (requireSelectiveState) {
            require(checksums.has(STATE_ENTRY) && checksums.has(DS_ENTRY)) {
                "Required v3 entries are not protected"
            }
        } else {
            require(
                (checksums.has(LEGACY_DB_V2_ENTRY) || checksums.has(LEGACY_DB_V1_ENTRY)) &&
                    (checksums.has(DS_ENTRY) || checksums.has(LEGACY_DS_ENTRY))
            ) { "Required legacy entries are not protected" }
        }

        val extracted = staging.walkTopDown()
            .filter { it.isFile }
            .map { it.relativeTo(staging).invariantSeparatorsPath }
            .filter { it != MANIFEST_ENTRY }
            .toList()
        require(extracted.all { checksums.has(it) }) { "Backup contains unprotected data entries" }
        require(extracted.size == protectedCount) { "Backup checksum table does not match extracted data" }
    }

    private fun firstExisting(vararg files: File): File? = files.firstOrNull { it.isFile }

    private fun copyFileChecked(source: File, target: File) {
        require(source.isFile) { "Source file does not exist: ${source.name}" }
        target.parentFile?.mkdirs()
        FileInputStream(source).use { input ->
            FileOutputStream(target).use { output ->
                input.copyTo(output)
                output.fd.sync()
            }
        }
        require(target.isFile && target.length() == source.length()) {
            "File copy verification failed: ${source.name}"
        }
    }

    private fun quickCheckSqlite(file: File): Boolean = try {
        val db = SQLiteDatabase.openDatabase(file.absolutePath, null, SQLiteDatabase.OPEN_READONLY)
        db.use {
            it.rawQuery("PRAGMA quick_check", null).use { cursor ->
                cursor.moveToFirst() && cursor.getString(0).equals("ok", ignoreCase = true)
            }
        }
    } catch (e: Exception) {
        Log.e(TAG, "SQLite quick_check failed for ${file.name}", e)
        false
    }

    private fun sha256(file: File): String {
        val digest = MessageDigest.getInstance("SHA-256")
        FileInputStream(file).use { input ->
            val buffer = ByteArray(128 * 1024)
            while (true) {
                val read = input.read(buffer)
                if (read <= 0) break
                digest.update(buffer, 0, read)
            }
        }
        return digest.digest().joinToString("") { "%02x".format(it) }
    }

    private fun sqlPath(file: File): String = file.absolutePath.replace("'", "''")
}
