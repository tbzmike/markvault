package com.tebogo.markvault.data

import android.content.Context
import android.database.sqlite.SQLiteDatabase
import android.net.Uri
import android.os.StatFs
import android.util.Log
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONObject
import java.io.File
import java.io.FileInputStream
import java.io.FileOutputStream
import java.security.MessageDigest
import java.util.zip.ZipEntry
import java.util.zip.ZipInputStream
import java.util.zip.ZipOutputStream

/**
 * MarkVault backup / restore.
 *
 * Backup v2 contains the Room database, DataStore preferences, cached song
 * lyrics, cached video transcripts, and the activity log when present.
 * Article-library files and downloaded AI/model files are intentionally not
 * included because they live outside app-private state or are re-downloadable.
 *
 * Safety properties:
 *  • Backup never reports success unless required DB + DataStore snapshots exist.
 *  • Every v2 entry is SHA-256 + size protected in manifest.json.
 *  • Restore extracts only recognised paths into a staging directory first.
 *  • SQLite is quick-checked before the live database is touched.
 *  • The old database/cache directories are retained as rollback copies until
 *    every replacement succeeds.
 *  • DataStore is NOT replaced while its singleton may be alive. It is staged
 *    and installed at the very beginning of the next Application.onCreate().
 */
object BackupManager {

    private const val TAG = "MV-BackupManager"
    private const val FORMAT_VERSION = 2

    private const val MANIFEST_ENTRY = "manifest.json"
    private const val DB_ENTRY = "database/markvault.db"
    private const val DS_ENTRY = "settings/settings.preferences_pb"
    private const val LYRICS_PREFIX = "media/song_lyrics/"
    private const val TRANSCRIPTS_PREFIX = "media/video_transcripts/"
    private const val ACTIVITY_ENTRY = "optional/activity_log.jsonl"

    // Legacy v1 entry names, retained so old backups remain restorable.
    private const val LEGACY_DB_ENTRY = "markvault.db"
    private const val LEGACY_DS_ENTRY = "settings.preferences_pb"

    private const val PENDING_DIR = "restore_pending"
    private const val PENDING_DS = "settings.preferences_pb"
    private const val PENDING_MARKER = "pending_datastore_restore"

    data class Progress(val phase: String, val percent: Int?, val detail: String = phase)

    class BackupStoppedException : RuntimeException("Backup/restore stopped by user")

    @Volatile
    var lastFailureReason: String? = null
        private set

    private data class BackupSource(val entryName: String, val file: File)

    fun databaseFile(ctx: Context): File = ctx.getDatabasePath("markvault.db")
    private fun databaseWal(ctx: Context): File = ctx.getDatabasePath("markvault.db-wal")
    private fun databaseShm(ctx: Context): File = ctx.getDatabasePath("markvault.db-shm")

    fun datastoreFile(ctx: Context): File =
        File(ctx.filesDir, "datastore/settings.preferences_pb")

    private fun lyricsDir(ctx: Context): File = File(ctx.filesDir, "song_lyrics")
    private fun transcriptsDir(ctx: Context): File = File(ctx.filesDir, "video_transcripts")
    private fun activityLogFile(ctx: Context): File = File(ctx.filesDir, "activity_log.jsonl")

    /**
     * Called before any DataStore-backed UI is created. A restore stages the
     * protobuf while the old process is alive; the next cold process installs
     * it here, before MarkVault creates its preference DataStore delegate.
     */
    fun applyPendingDatastoreRestore(ctx: Context) {
        val pendingRoot = File(ctx.filesDir, PENDING_DIR)
        val marker = File(pendingRoot, PENDING_MARKER)
        val staged = File(pendingRoot, PENDING_DS)
        if (!marker.exists()) return

        val target = datastoreFile(ctx)
        val rollback = File(target.parentFile, "${target.name}.pre_restore")
        try {
            require(staged.isFile && staged.length() > 0L) {
                "Pending DataStore restore is missing or empty"
            }
            target.parentFile?.mkdirs()
            rollback.delete()
            if (target.exists()) {
                require(target.renameTo(rollback)) { "Could not create DataStore rollback copy" }
            }
            try {
                copyFileChecked(staged, target)
                require(target.isFile && target.length() == staged.length()) {
                    "Restored DataStore size mismatch"
                }
                rollback.delete()
                staged.delete()
                marker.delete()
                pendingRoot.delete()
                Log.i(TAG, "Pending DataStore restore applied")
            } catch (e: Exception) {
                target.delete()
                if (rollback.exists()) rollback.renameTo(target)
                throw e
            }
        } catch (e: Exception) {
            Log.e(TAG, "Pending DataStore restore failed; original preferences retained", e)
        }
    }

    suspend fun createBackup(
        ctx: Context,
        destUri: Uri,
        versionName: String,
        onProgress: (Progress) -> Unit = {},
        shouldStop: () -> Boolean = { false }
    ): Boolean = withContext(Dispatchers.IO) {
        lastFailureReason = null
        val tempRoot = File(ctx.cacheDir, "backup_staging_${System.nanoTime()}")
        try {
            checkStop(shouldStop)
            onProgress(Progress("Checking storage", 2, "Checking available storage…"))
            val preflight = backupPreflight(ctx, destUri)
            if (!preflight.ok) {
                lastFailureReason = preflight.reason
                Log.e(TAG, "Backup preflight failed: ${preflight.reason}")
                return@withContext false
            }

            tempRoot.mkdirs()
            onProgress(Progress("Database snapshot", 8, "Creating a consistent database snapshot…"))
            val dbSnapshot = File(tempRoot, "markvault.db")
            val dsSnapshot = File(tempRoot, "settings.preferences_pb")

            if (!createDatabaseSnapshot(ctx, dbSnapshot)) {
                lastFailureReason = "Database snapshot could not be created."
                Log.e(TAG, "Backup aborted: database snapshot could not be created")
                return@withContext false
            }
            checkStop(shouldStop)
            onProgress(Progress("Database validation", 28, "Validating database snapshot…"))
            if (!dbSnapshot.isFile || dbSnapshot.length() <= 0L || !quickCheckSqlite(dbSnapshot)) {
                lastFailureReason = "Database snapshot failed integrity validation."
                Log.e(TAG, "Backup aborted: database snapshot failed validation")
                return@withContext false
            }

            checkStop(shouldStop)
            onProgress(Progress("Settings snapshot", 34, "Copying MarkVault settings…"))

            val dsLive = datastoreFile(ctx)
            if (!dsLive.isFile || dsLive.length() <= 0L) {
                lastFailureReason = "Settings file is missing or empty."
                Log.e(TAG, "Backup aborted: DataStore file is missing or empty")
                return@withContext false
            }
            copyFileChecked(dsLive, dsSnapshot)
            if (!dsSnapshot.isFile || dsSnapshot.length() != dsLive.length()) {
                lastFailureReason = "Settings snapshot failed validation."
                Log.e(TAG, "Backup aborted: DataStore snapshot failed validation")
                return@withContext false
            }

            val sources = mutableListOf(
                BackupSource(DB_ENTRY, dbSnapshot),
                BackupSource(DS_ENTRY, dsSnapshot)
            )
            addDirectorySources(lyricsDir(ctx), LYRICS_PREFIX, sources)
            addDirectorySources(transcriptsDir(ctx), TRANSCRIPTS_PREFIX, sources)
            val activity = activityLogFile(ctx)
            if (activity.isFile) sources += BackupSource(ACTIVITY_ENTRY, activity)

            checkStop(shouldStop)
            onProgress(Progress("Integrity manifest", 40, "Calculating backup checksums…"))
            val checksums = JSONObject()
            val sizes = JSONObject()
            sources.forEachIndexed { index, source ->
                checkStop(shouldStop)
                checksums.put(source.entryName, sha256(source.file))
                sizes.put(source.entryName, source.file.length())
                val pct = 40 + (((index + 1).toDouble() / sources.size.coerceAtLeast(1)) * 10.0).toInt()
                onProgress(Progress("Integrity manifest", pct.coerceAtMost(50), "Verifying ${index + 1} / ${sources.size} backup items…"))
            }

            val manifest = JSONObject().apply {
                put("app", "MarkVault")
                put("format_version", FORMAT_VERSION)
                put("version", versionName)
                put("timestamp", System.currentTimeMillis())
                put("db_entry", DB_ENTRY)
                put("ds_entry", DS_ENTRY)
                put("lyrics_count", sources.count { it.entryName.startsWith(LYRICS_PREFIX) })
                put("transcripts_count", sources.count { it.entryName.startsWith(TRANSCRIPTS_PREFIX) })
                put("checksums", checksums)
                put("sizes", sizes)
            }.toString(2)

            checkStop(shouldStop)
            onProgress(Progress("Writing backup", 50, "Writing backup file…"))
            val totalBytes = sources.sumOf { it.file.length().coerceAtLeast(0L) }.coerceAtLeast(1L)
            var writtenBytes = 0L
            val out = ctx.contentResolver.openOutputStream(destUri, "w")
                ?: return@withContext false.also {
                    lastFailureReason = "The selected backup destination could not be opened for writing."
                    Log.e(TAG, "Could not open backup output stream")
                }
            out.buffered().use { raw ->
                ZipOutputStream(raw).use { zip ->
                    zip.putNextEntry(ZipEntry(MANIFEST_ENTRY))
                    zip.write(manifest.toByteArray(Charsets.UTF_8))
                    zip.closeEntry()

                    for (source in sources) {
                        checkStop(shouldStop)
                        zip.putNextEntry(ZipEntry(source.entryName))
                        FileInputStream(source.file).use { input ->
                            val buffer = ByteArray(256 * 1024)
                            while (true) {
                                checkStop(shouldStop)
                                val read = input.read(buffer)
                                if (read <= 0) break
                                zip.write(buffer, 0, read)
                                writtenBytes += read
                                val pct = 50 + ((writtenBytes.toDouble() / totalBytes) * 48.0).toInt()
                                onProgress(Progress("Writing backup", pct.coerceIn(50, 98), "Writing ${formatBytes(writtenBytes)} / ${formatBytes(totalBytes)}…"))
                            }
                        }
                        zip.closeEntry()
                    }
                }
            }

            checkStop(shouldStop)
            onProgress(Progress("Complete", 100, "Backup saved and verified."))
            Log.i(TAG, "Backup written: ${sources.size} protected data entries")
            true
        } catch (e: BackupStoppedException) {
            lastFailureReason = "Backup stopped by user."
            Log.i(TAG, "Backup stopped by user")
            throw e
        } catch (e: Exception) {
            lastFailureReason = e.message?.takeIf { it.isNotBlank() } ?: "Backup failed due to an unexpected I/O error."
            Log.e(TAG, "createBackup failed", e)
            false
        } finally {
            tempRoot.deleteRecursively()
        }
    }

    /**
     * Returns manifest only when the ZIP is structurally a restorable MarkVault
     * backup. Required DB + DataStore entries must both be present.
     */
    suspend fun readManifest(ctx: Context, srcUri: Uri): JSONObject? =
        withContext(Dispatchers.IO) {
            try {
                var manifest: JSONObject? = null
                var hasDb = false
                var hasDs = false
                ctx.contentResolver.openInputStream(srcUri)?.buffered()?.use { raw ->
                    ZipInputStream(raw).use { zip ->
                        var entry = zip.nextEntry
                        while (entry != null) {
                            when (entry.name) {
                                MANIFEST_ENTRY -> manifest = JSONObject(zip.readBytes().toString(Charsets.UTF_8))
                                DB_ENTRY, LEGACY_DB_ENTRY -> hasDb = true
                                DS_ENTRY, LEGACY_DS_ENTRY -> hasDs = true
                            }
                            zip.closeEntry()
                            entry = zip.nextEntry
                        }
                    }
                } ?: return@withContext null

                val json = manifest ?: return@withContext null
                if (json.optString("app") != "MarkVault" || !hasDb || !hasDs) return@withContext null
                json
            } catch (e: Exception) {
                Log.e(TAG, "readManifest failed", e)
                null
            }
        }

    suspend fun applyBackup(
        ctx: Context,
        srcUri: Uri,
        onProgress: (Progress) -> Unit = {},
        shouldStop: () -> Boolean = { false }
    ): Boolean = withContext(Dispatchers.IO) {
            lastFailureReason = null
            val staging = File(ctx.cacheDir, "restore_staging_${System.nanoTime()}")
            val rollback = File(ctx.cacheDir, "restore_rollback_${System.nanoTime()}")
            var dbWasMoved = false
            var dbInstalled = false
            var lyricsWasMoved = false
            var lyricsInstalled = false
            var transcriptsWasMoved = false
            var transcriptsInstalled = false
            var activityWasMoved = false
            var activityInstalled = false
            var roomWasClosed = false

            val dbTarget = databaseFile(ctx)
            val lyricsTarget = lyricsDir(ctx)
            val transcriptsTarget = transcriptsDir(ctx)
            val activityTarget = activityLogFile(ctx)

            try {
                checkStop(shouldStop)
                onProgress(Progress("Checking backup", 3, "Checking backup file and temporary storage…"))
                val restorePreflight = restorePreflight(ctx, srcUri)
                if (!restorePreflight.ok) throw IllegalStateException(restorePreflight.reason)

                staging.mkdirs()
                rollback.mkdirs()

                checkStop(shouldStop)
                onProgress(Progress("Reading backup", 10, "Reading backup contents…"))
                val manifest = extractRecognisedEntries(ctx, srcUri, staging, shouldStop)
                    ?: throw IllegalArgumentException("Backup is missing a valid manifest")
                val formatVersion = manifest.optInt("format_version", 1)

                val stagedDb = firstExisting(
                    File(staging, DB_ENTRY),
                    File(staging, LEGACY_DB_ENTRY)
                ) ?: throw IllegalArgumentException("Backup database is missing")
                val stagedDs = firstExisting(
                    File(staging, DS_ENTRY),
                    File(staging, LEGACY_DS_ENTRY)
                ) ?: throw IllegalArgumentException("Backup settings are missing")

                require(stagedDb.length() > 0L) { "Backup database is empty" }
                require(stagedDs.length() > 0L) { "Backup settings are empty" }

                checkStop(shouldStop)
                onProgress(Progress("Validating backup", 48, "Validating checksums and database integrity…"))
                if (formatVersion >= 2) verifyManifestProtectedEntries(manifest, staging)
                require(quickCheckSqlite(stagedDb)) { "Backup database failed SQLite quick_check" }

                checkStop(shouldStop)
                onProgress(Progress("Preparing restore", 65, "Preparing a safe rollback point…"))
                // Stage DataStore for next process BEFORE touching current live data.
                val pendingRoot = File(ctx.filesDir, PENDING_DIR).apply { mkdirs() }
                val pendingDs = File(pendingRoot, PENDING_DS)
                val pendingMarker = File(pendingRoot, PENDING_MARKER)
                pendingDs.delete()
                copyFileChecked(stagedDs, pendingDs)
                require(pendingDs.length() == stagedDs.length()) { "Could not stage restored settings" }
                pendingMarker.writeText("ready", Charsets.UTF_8)

                checkStop(shouldStop)
                VaultDb.closeForRestore()
                roomWasClosed = true
                onProgress(Progress("Restoring database", 74, "Replacing database with rollback protection…"))

                dbTarget.parentFile?.mkdirs()
                val dbRollback = File(rollback, "markvault.db")
                if (dbTarget.exists()) {
                    require(dbTarget.renameTo(dbRollback)) { "Could not create database rollback copy" }
                    dbWasMoved = true
                }
                databaseWal(ctx).delete()
                databaseShm(ctx).delete()

                val dbIncoming = File(dbTarget.parentFile, "markvault.db.restore_incoming")
                dbIncoming.delete()
                copyFileChecked(stagedDb, dbIncoming)
                require(dbIncoming.length() == stagedDb.length()) { "Database replacement size mismatch" }
                require(dbIncoming.renameTo(dbTarget)) { "Could not install restored database" }
                dbInstalled = true
                require(quickCheckSqlite(dbTarget)) { "Installed database failed SQLite quick_check" }
                checkStop(shouldStop)
                onProgress(Progress("Restoring media data", 86, "Restoring lyrics, transcripts, and activity data…"))

                // v2 backups explicitly represent cache directories, including empty ones.
                if (formatVersion >= 2) {
                    val lyricsRollback = File(rollback, "song_lyrics")
                    if (lyricsTarget.exists()) {
                        require(lyricsTarget.renameTo(lyricsRollback)) { "Could not protect current lyrics cache" }
                        lyricsWasMoved = true
                    }
                    copyDirectoryContents(File(staging, LYRICS_PREFIX.removeSuffix("/")), lyricsTarget)
                    lyricsInstalled = true

                    val transcriptsRollback = File(rollback, "video_transcripts")
                    if (transcriptsTarget.exists()) {
                        require(transcriptsTarget.renameTo(transcriptsRollback)) { "Could not protect current transcript cache" }
                        transcriptsWasMoved = true
                    }
                    copyDirectoryContents(File(staging, TRANSCRIPTS_PREFIX.removeSuffix("/")), transcriptsTarget)
                    transcriptsInstalled = true

                    val stagedActivity = File(staging, ACTIVITY_ENTRY)
                    val activityRollback = File(rollback, "activity_log.jsonl")
                    if (activityTarget.exists()) {
                        require(activityTarget.renameTo(activityRollback)) { "Could not protect current activity log" }
                        activityWasMoved = true
                    }
                    if (stagedActivity.isFile) {
                        copyFileChecked(stagedActivity, activityTarget)
                        activityInstalled = true
                    }
                }

                // All live replacements succeeded. Rollback copies are no longer needed.
                checkStop(shouldStop)
                onProgress(Progress("Complete", 100, "Restore complete. MarkVault will restart cleanly."))
                rollback.deleteRecursively()
                Log.i(TAG, "Restore data installed; settings will be applied on next cold start")
                true
            } catch (e: Exception) {
                lastFailureReason = if (e is BackupStoppedException) "Restore stopped by user." else (e.message ?: "Restore failed.")
                Log.e(TAG, "applyBackup failed; rolling back", e)

                // Roll back current-process data. Pending DataStore must not survive a failed restore.
                File(ctx.filesDir, PENDING_DIR).deleteRecursively()

                runCatching {
                    val dbRollback = File(rollback, "markvault.db")
                    if (dbInstalled) dbTarget.delete()
                    if (dbWasMoved && dbRollback.exists()) {
                        require(dbRollback.renameTo(dbTarget)) { "Database rollback rename failed" }
                    }
                    databaseWal(ctx).delete()
                    databaseShm(ctx).delete()

                    if (lyricsInstalled) lyricsTarget.deleteRecursively()
                    if (lyricsWasMoved) {
                        require(File(rollback, "song_lyrics").renameTo(lyricsTarget)) { "Lyrics rollback failed" }
                    }
                    if (transcriptsInstalled) transcriptsTarget.deleteRecursively()
                    if (transcriptsWasMoved) {
                        require(File(rollback, "video_transcripts").renameTo(transcriptsTarget)) { "Transcript rollback failed" }
                    }
                    if (activityInstalled) activityTarget.delete()
                    if (activityWasMoved) {
                        require(File(rollback, "activity_log.jsonl").renameTo(activityTarget)) { "Activity-log rollback failed" }
                    }
                }.onFailure { rollbackError ->
                    Log.e(TAG, "Rollback itself encountered an error", rollbackError)
                }
                if (roomWasClosed) {
                    runCatching { VaultDb.get(ctx).openHelper.writableDatabase }
                        .onFailure { Log.e(TAG, "Could not reopen Room after failed restore", it) }
                }
                false
            } finally {
                staging.deleteRecursively()
                rollback.deleteRecursively()
            }
        }

    /**
     * v5.4.306cc — VACUUM INTO removed entirely. This was the actual cause
     * of "Database snapshot failed integrity validation" always firing:
     * VACUUM INTO does a full logical rebuild of the target file (not a
     * raw copy) — it re-creates every table and index from scratch. SQLite
     * has a confirmed, documented bug class where this rebuild can produce
     * a subtly-wrong copy specifically when the schema contains a virtual
     * table with cross-referencing shadow tables (SQLite Forum, "VACUUM
     * INTO fails on DB with virtual columns" — the reporter's own words:
     * "The real DB passes pragma integrity_check and pragma
     * foreign_key_check" — i.e. the SOURCE database was completely fine;
     * only VACUUM INTO's rebuilt COPY was wrong).
     *
     * This schema has exactly that shape: NoteFts is an @Fts4 external-
     * content virtual table (Db.kt) synced against Note — FTS4 uses
     * multiple internal shadow tables that must stay cross-consistent,
     * and reconstructing them via VACUUM INTO's rebuild is precisely the
     * scenario the documented bug affects. That's why quick_check kept
     * failing on the SNAPSHOT while the live app (reading the ORIGINAL,
     * never-rebuilt database every day) never showed any problem — the
     * live database was never actually corrupt.
     *
     * Fix: only ever take a raw file copy (checkpoint the WAL into the
     * main file first, hold a lock so nothing can write mid-copy, then
     * byte-copy the file). A raw copy duplicates bytes that are already
     * internally consistent — it never asks SQLite to rebuild anything,
     * so this specific bug class cannot occur. Trade-off, stated plainly:
     * the backup file will be exactly as large as the live database
     * (VACUUM's free-list compaction is gone), not smaller — a completely
     * acceptable cost for a backup that's actually reliably valid.
     */
    private fun createDatabaseSnapshot(ctx: Context, target: File): Boolean {
        target.delete()
        target.parentFile?.mkdirs()
        val roomDb = VaultDb.get(ctx).openHelper.writableDatabase

        // Checkpoint first so every WAL-resident write is flushed into the
        // main file, then hold a write transaction with no mutations while
        // copying — the lock prevents a concurrent writer from changing
        // the file mid-copy. This is a byte-for-byte copy of a file the
        // live app already reads/writes successfully every day, so it
        // cannot introduce new corruption the way a logical rebuild can.
        return runCatching {
            roomDb.execSQL("PRAGMA wal_checkpoint(TRUNCATE)")
            roomDb.beginTransaction()
            try {
                val live = databaseFile(ctx)
                require(live.isFile && live.length() > 0L) { "Live database missing" }
                copyFileChecked(live, target)
                roomDb.setTransactionSuccessful()
            } finally {
                roomDb.endTransaction()
            }
            target.isFile && target.length() > 0L
        }.getOrElse {
            Log.e(TAG, "Database snapshot failed", it)
            false
        }
    }

    private fun extractRecognisedEntries(
        ctx: Context,
        srcUri: Uri,
        staging: File,
        shouldStop: () -> Boolean = { false }
    ): JSONObject? {
        var manifest: JSONObject? = null
        ctx.contentResolver.openInputStream(srcUri)?.buffered()?.use { raw ->
            ZipInputStream(raw).use { zip ->
                var entry = zip.nextEntry
                while (entry != null) {
                    checkStop(shouldStop)
                    val name = entry.name
                    if (!entry.isDirectory && isRecognisedEntry(name)) {
                        if (name == MANIFEST_ENTRY) {
                            manifest = JSONObject(zip.readBytes().toString(Charsets.UTF_8))
                        } else {
                            val output = safeStagingFile(staging, name)
                            output.parentFile?.mkdirs()
                            FileOutputStream(output).use { zip.copyTo(it) }
                        }
                    }
                    zip.closeEntry()
                    entry = zip.nextEntry
                }
            }
        } ?: return null
        return manifest?.takeIf { it.optString("app") == "MarkVault" }
    }

    private fun isRecognisedEntry(name: String): Boolean =
        name == MANIFEST_ENTRY || name == DB_ENTRY || name == DS_ENTRY ||
            name == LEGACY_DB_ENTRY || name == LEGACY_DS_ENTRY ||
            name == ACTIVITY_ENTRY || name.startsWith(LYRICS_PREFIX) ||
            name.startsWith(TRANSCRIPTS_PREFIX)

    private fun safeStagingFile(root: File, entryName: String): File {
        require(!entryName.startsWith("/") && !entryName.contains("..")) { "Unsafe ZIP entry" }
        val file = File(root, entryName)
        val rootPath = root.canonicalPath
        val filePath = file.canonicalPath
        require(filePath == rootPath || filePath.startsWith(rootPath + File.separator)) {
            "ZIP entry escapes staging directory"
        }
        return file
    }

    private fun verifyManifestProtectedEntries(manifest: JSONObject, staging: File) {
        val checksums = manifest.optJSONObject("checksums")
            ?: throw IllegalArgumentException("Backup checksum table is missing")
        val sizes = manifest.optJSONObject("sizes")
            ?: throw IllegalArgumentException("Backup size table is missing")

        val keys = checksums.keys()
        var protectedCount = 0
        while (keys.hasNext()) {
            val entry = keys.next()
            require(isRecognisedEntry(entry) && entry != MANIFEST_ENTRY) { "Unknown protected backup entry" }
            val file = safeStagingFile(staging, entry)
            require(file.isFile) { "Backup entry missing: $entry" }
            require(file.length() == sizes.optLong(entry, -1L)) { "Backup size mismatch: $entry" }
            require(sha256(file).equals(checksums.optString(entry), ignoreCase = true)) {
                "Backup checksum mismatch: $entry"
            }
            protectedCount++
        }
        require(protectedCount >= 2) { "Backup does not contain required protected data" }
        require(checksums.has(DB_ENTRY) && checksums.has(DS_ENTRY)) { "Required v2 entries are not protected" }

        val extracted = staging.walkTopDown()
            .filter { it.isFile }
            .map { it.relativeTo(staging).invariantSeparatorsPath }
            .filter { it != MANIFEST_ENTRY }
            .toList()
        require(extracted.all { checksums.has(it) }) { "Backup contains unprotected data entries" }
        require(extracted.size == protectedCount) { "Backup checksum table does not match extracted data" }
    }

    private data class Preflight(val ok: Boolean, val reason: String = "")

    private fun backupPreflight(ctx: Context, destUri: Uri): Preflight {
        val db = databaseFile(ctx)
        val ds = datastoreFile(ctx)
        if (!db.isFile || db.length() <= 0L) return Preflight(false, "MarkVault database is missing or empty.")
        if (!ds.isFile || ds.length() <= 0L) return Preflight(false, "MarkVault settings file is missing or empty.")

        val stagingNeed = (db.length() + ds.length() + 128L * 1024L * 1024L).coerceAtLeast(256L * 1024L * 1024L)
        val available = StatFs(ctx.cacheDir.absolutePath).availableBytes
        if (available < stagingNeed) {
            return Preflight(false, "Not enough internal working space. Need about ${formatBytes(stagingNeed)}, available ${formatBytes(available)}.")
        }

        val writable = runCatching {
            ctx.contentResolver.openFileDescriptor(destUri, "rw")?.use { true } ?: false
        }.getOrDefault(false)
        if (!writable) return Preflight(false, "The selected backup destination is not writable.")
        return Preflight(true)
    }

    private fun restorePreflight(ctx: Context, srcUri: Uri): Preflight {
        val sourceSize = runCatching {
            ctx.contentResolver.openFileDescriptor(srcUri, "r")?.use { it.statSize.coerceAtLeast(0L) } ?: 0L
        }.getOrDefault(0L)
        val currentDb = databaseFile(ctx).length().coerceAtLeast(0L)
        // Restore simultaneously holds staged data plus rollback data. Use a conservative
        // allowance without pretending SAF can expose every provider's capacity.
        val needed = (sourceSize * 2L + currentDb + 128L * 1024L * 1024L).coerceAtLeast(256L * 1024L * 1024L)
        val available = StatFs(ctx.cacheDir.absolutePath).availableBytes
        if (available < needed) {
            return Preflight(false, "Not enough internal working space for safe restore. Need about ${formatBytes(needed)}, available ${formatBytes(available)}.")
        }
        val readable = runCatching {
            ctx.contentResolver.openFileDescriptor(srcUri, "r")?.use { true } ?: false
        }.getOrDefault(false)
        if (!readable) return Preflight(false, "The selected backup file cannot be read.")
        return Preflight(true)
    }

    private fun checkStop(shouldStop: () -> Boolean) {
        if (shouldStop()) throw BackupStoppedException()
    }

    private fun formatBytes(bytes: Long): String {
        val value = bytes.coerceAtLeast(0L).toDouble()
        val gb = 1024.0 * 1024.0 * 1024.0
        val mb = 1024.0 * 1024.0
        return when {
            value >= gb -> String.format(java.util.Locale.US, "%.1f GB", value / gb)
            value >= mb -> String.format(java.util.Locale.US, "%.1f MB", value / mb)
            else -> "${bytes.coerceAtLeast(0L)} B"
        }
    }

    private fun addDirectorySources(dir: File, prefix: String, out: MutableList<BackupSource>) {
        if (!dir.isDirectory) return
        dir.walkTopDown().filter { it.isFile }.forEach { file ->
            val relative = file.relativeTo(dir).invariantSeparatorsPath
            out += BackupSource(prefix + relative, file)
        }
    }

    private fun copyDirectoryContents(source: File, target: File) {
        target.deleteRecursively()
        target.mkdirs()
        if (!source.isDirectory) return
        source.walkTopDown().filter { it.isFile }.forEach { file ->
            val relative = file.relativeTo(source).invariantSeparatorsPath
            copyFileChecked(file, File(target, relative))
        }
    }

    private fun firstExisting(vararg files: File): File? = files.firstOrNull { it.isFile }

    private fun copyFileChecked(source: File, target: File) {
        require(source.isFile) { "Source file does not exist: ${source.name}" }
        target.parentFile?.mkdirs()
        FileInputStream(source).use { input ->
            FileOutputStream(target).use { output ->
                input.copyTo(output)
                output.fd.sync()
            }
        }
        require(target.isFile && target.length() == source.length()) {
            "File copy verification failed: ${source.name}"
        }
    }

    private fun quickCheckSqlite(file: File): Boolean = runCatching {
        val db = SQLiteDatabase.openDatabase(file.absolutePath, null, SQLiteDatabase.OPEN_READONLY)
        try {
            db.rawQuery("PRAGMA quick_check(1)", null).use { cursor ->
                val hasRow = cursor.moveToFirst()
                val ok = hasRow && cursor.getString(0).equals("ok", ignoreCase = true)
                if (!ok) {
                    // v5.4.306cc — Log the ACTUAL quick_check output, not just
                    // pass/fail, so a future failure (of any cause) is
                    // immediately diagnosable instead of a bare boolean.
                    // Only reads getString when a row genuinely exists
                    // (hasRow) — quick_check always returns at least one row
                    // per SQLite's own documented contract, but this stays
                    // correct even if that ever changed.
                    val detail = if (hasRow) cursor.getString(0) else "(no rows)"
                    Log.e(TAG, "SQLite quick_check reported: $detail")
                }
                ok
            }
        } finally {
            db.close()
        }
    }.getOrElse {
        Log.e(TAG, "SQLite quick_check failed for ${file.name}", it)
        false
    }

    private fun sha256(file: File): String {
        val digest = MessageDigest.getInstance("SHA-256")
        FileInputStream(file).use { input ->
            val buffer = ByteArray(DEFAULT_BUFFER_SIZE)
            while (true) {
                val read = input.read(buffer)
                if (read <= 0) break
                digest.update(buffer, 0, read)
            }
        }
        return digest.digest().joinToString("") { "%02x".format(it) }
    }
}
