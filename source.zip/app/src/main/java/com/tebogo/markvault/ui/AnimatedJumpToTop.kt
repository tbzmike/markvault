package com.tebogo.markvault.ui

import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.tween
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.compose.LocalLifecycleOwner
import androidx.lifecycle.repeatOnLifecycle
import kotlinx.coroutines.delay
import kotlinx.coroutines.isActive

/**
 * v5.4.356cc — Large, animated and consistently placed jump-to-top affordance.
 * The finger bobs upward without moving the hit target itself, so repeated taps
 * stay reliable even while the visual is animated.
 */
@Composable
fun AnimatedJumpToTop(
    onClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    val lifecycleOwner = LocalLifecycleOwner.current
    var raised by remember { mutableStateOf(false) }
    LaunchedEffect(lifecycleOwner) {
        lifecycleOwner.lifecycle.repeatOnLifecycle(Lifecycle.State.STARTED) {
            while (isActive) {
                raised = !raised
                delay(800L)
            }
        }
    }
    // v5.4.365cc — Same animated pointing cue, but only short 200 ms
    // transitions every 800 ms instead of a permanent frame-producing loop.
    val phase by animateFloatAsState(
        targetValue = if (raised) 1f else 0f,
        animationSpec = tween(200, easing = FastOutSlowInEasing),
        label = "jump-to-top-phase"
    )
    val density = LocalDensity.current
    val liftPx = with(density) { 8.dp.toPx() }

    Surface(
        modifier = modifier.size(62.dp).clickable(onClick = onClick),
        shape = RoundedCornerShape(22.dp),
        color = MaterialTheme.colorScheme.secondaryContainer.copy(alpha = 0.96f),
        contentColor = MaterialTheme.colorScheme.onSecondaryContainer,
        shadowElevation = 7.dp,
        tonalElevation = 3.dp
    ) {
        Column(
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center
        ) {
            Text(
                "☝",
                fontSize = 31.sp,
                modifier = Modifier.graphicsLayer {
                    translationY = -liftPx * phase
                    scaleX = 1f + 0.08f * phase
                    scaleY = 1f + 0.08f * phase
                }
            )
            Text("TOP", fontSize = 9.sp, fontWeight = FontWeight.Black)
        }
    }
}
