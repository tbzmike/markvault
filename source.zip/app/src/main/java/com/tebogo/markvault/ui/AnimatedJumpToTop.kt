package com.tebogo.markvault.ui

import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

/**
 * v5.4.356cc — Large, animated and consistently placed jump-to-top affordance.
 * The finger bobs upward without moving the hit target itself, so repeated taps
 * stay reliable even while the visual is animated.
 */
@Composable
fun AnimatedJumpToTop(
    onClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    val transition = rememberInfiniteTransition(label = "jump-to-top-finger")
    val phase by transition.animateFloat(
        initialValue = 0f,
        targetValue = 1f,
        animationSpec = infiniteRepeatable(
            animation = tween(620, easing = FastOutSlowInEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "jump-to-top-phase"
    )
    val density = LocalDensity.current
    val liftPx = with(density) { 8.dp.toPx() }

    Surface(
        modifier = modifier.size(62.dp).clickable(onClick = onClick),
        shape = RoundedCornerShape(22.dp),
        color = MaterialTheme.colorScheme.secondaryContainer.copy(alpha = 0.96f),
        contentColor = MaterialTheme.colorScheme.onSecondaryContainer,
        shadowElevation = 7.dp,
        tonalElevation = 3.dp
    ) {
        Column(
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center
        ) {
            Text(
                "☝",
                fontSize = 31.sp,
                modifier = Modifier.graphicsLayer {
                    translationY = -liftPx * phase
                    scaleX = 1f + 0.08f * phase
                    scaleY = 1f + 0.08f * phase
                }
            )
            Text("TOP", fontSize = 9.sp, fontWeight = FontWeight.Black)
        }
    }
}
