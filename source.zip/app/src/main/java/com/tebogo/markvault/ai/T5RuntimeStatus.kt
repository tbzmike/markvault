package com.tebogo.markvault.ai

/** Runtime status exposed to UI. */
data class T5RuntimeStatus(
    val installed: Boolean,
    val ready: Boolean,
    val active: Boolean
)
