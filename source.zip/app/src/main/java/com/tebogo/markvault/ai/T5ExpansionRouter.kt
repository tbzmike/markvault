package com.tebogo.markvault.ai

/** Routes expansion requests between T5 and built-in expansion. */
object T5ExpansionRouter {
    fun useT5(requested: Boolean): Boolean {
        return requested && T5ExpansionAvailability.isAvailable()
    }
}
