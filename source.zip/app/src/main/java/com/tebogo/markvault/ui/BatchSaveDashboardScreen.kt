package com.tebogo.markvault.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.navigation.NavController
import com.tebogo.markvault.AppViewModel
import kotlinx.coroutines.delay
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/**
 * v5.4.110cc — Live batch save dashboard.
 *
 * A single-screen view of everything the batch save engine is doing,
 * driven entirely by [AppViewModel.batchTelemetry]. Purpose: give the
 * user visibility into per-worker activity, rolling throughput, event
 * timeline, and progress so slow batches don't feel opaque.
 *
 * Sections top-to-bottom:
 *   • **Header** — status pill (Running / Idle / Complete), elapsed time,
 *     ETA, and a stop button (mirrors the FAB pill's cancel action).
 *   • **Progress card** — big X of Y, thin linear progress bar, plus
 *     colour-coded counters for saved / failed / dupes / small.
 *   • **Throughput card** — articles/sec and MB/sec computed from the
 *     start timestamp and current bytes, refreshed every second by a
 *     background ticker in this composable.
 *   • **Workers card** — one row per parallel worker showing what URL
 *     it's currently fetching (or "idle"). Renders exactly
 *     PARALLEL_WORKERS rows so it's obvious when a worker is stuck.
 *   • **Event timeline** — most-recent-first list, one row per event
 *     (fetch start, save ok, skip dupe, skip small, save fail) with a
 *     timestamp, kind emoji, title, duration, size. Capped to 200 in
 *     the VM so this scrolls without turning into a memory hog.
 *
 * Access points:
 *   • Tap the "Saving X/Y…" pill in the WebViewer.
 *   • Tap the batch save notification in the shade.
 *   • Global overflow menu → "📊 Batch save dashboard" (only when a
 *     batch is active).
 */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun BatchSaveDashboardScreen(vm: AppViewModel, nav: NavController) {
    val telemetry by vm.batchTelemetry.collectAsStateWithLifecycle()
    val batchInFlight by vm.batchSaveRequest.collectAsStateWithLifecycle()
    val saving by vm.webSelectionSaving.collectAsStateWithLifecycle()

    // Local wall-clock ticker for elapsed / speed. Refreshes every
    // second so throughput numbers feel live without hammering
    // recomposition.
    var nowMs by remember { mutableStateOf(System.currentTimeMillis()) }
    LaunchedEffect(telemetry?.startedAtMs) {
        while (telemetry != null) {
            nowMs = System.currentTimeMillis()
            delay(1000)
        }
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Batch save dashboard", fontWeight = FontWeight.SemiBold) },
                navigationIcon = {
                    IconButton(onClick = { nav.popBackStack() }) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back")
                    }
                }
            )
        }
    ) { padding ->
        val t = telemetry
        if (t == null) {
            EmptyState(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(padding)
            )
            return@Scaffold
        }

        val elapsedMs = (nowMs - t.startedAtMs).coerceAtLeast(1L)
        val active = batchInFlight.isNotEmpty()
        val (_, total) = saving
        val progressFrac = if (t.total > 0) t.done.toFloat() / t.total.toFloat() else 0f

        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .padding(horizontal = 16.dp)
        ) {
            item { Spacer(Modifier.height(12.dp)) }

            // ── Header ────────────────────────────────────────────
            item {
                HeaderCard(
                    active = active,
                    elapsedMs = elapsedMs,
                    remaining = t.remaining,
                    done = t.done,
                    ok = t.ok,
                    onStop = { vm.cancelBatchSave() }
                )
                Spacer(Modifier.height(14.dp))
            }

            // ── Progress ──────────────────────────────────────────
            item {
                Card(title = "\uD83D\uDCE6 Progress") {
                    Text(
                        "${t.done} of ${t.total}",
                        fontSize = 28.sp,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.onSurface
                    )
                    Spacer(Modifier.height(6.dp))
                    LinearProgressIndicator(
                        progress = { progressFrac },
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(6.dp),
                    )
                    Spacer(Modifier.height(12.dp))
                    StatRow("\u2705 Saved", t.ok.toString(), Color(0xFF2E7D32))
                    StatRow("\u267B\uFE0F Skipped (in library)", t.skippedDupes.toString(), Color(0xFF1565C0))
                    StatRow("\uD83D\uDCCF Skipped (< 10 KB)", t.skippedSmall.toString(), Color(0xFFEF6C00))
                    StatRow("\u274C Failed", t.failed.toString(), Color(0xFFC62828))
                }
                Spacer(Modifier.height(14.dp))
            }

            // ── Throughput ────────────────────────────────────────
            item {
                val elapsedSec = elapsedMs / 1000.0
                val netCompleted = t.ok + t.skippedSmall + t.failed
                val articlesPerSec = if (elapsedSec > 0) netCompleted / elapsedSec else 0.0
                val bytesPerSec = if (elapsedSec > 0) t.bytesFetched / elapsedSec else 0.0
                val etaSec = if (articlesPerSec > 0.001) {
                    val remainingActual = (t.total - t.skippedDupes - netCompleted)
                        .coerceAtLeast(0)
                    (remainingActual / articlesPerSec).toLong()
                } else 0L
                val avgBytesPerArticle = if (netCompleted > 0)
                    t.bytesFetched / netCompleted else 0L

                Card(title = "\u26A1 Throughput") {
                    StatRow("Speed", "%.2f articles/sec".format(Locale.US, articlesPerSec))
                    StatRow("Bandwidth", formatBytesPerSec(bytesPerSec))
                    StatRow("Data fetched", formatBytes(t.bytesFetched))
                    StatRow("Avg article size", formatBytes(avgBytesPerArticle))
                    StatRow("Elapsed", formatDuration(elapsedMs))
                    if (etaSec > 0 && active) {
                        StatRow("ETA", formatDuration(etaSec * 1000))
                    }
                }
                Spacer(Modifier.height(14.dp))
            }

            // ── Workers ───────────────────────────────────────────
            item {
                Card(title = "\uD83D\uDC77 Workers (${t.workerActivity.size} parallel)") {
                    t.workerActivity.forEachIndexed { idx, url ->
                        WorkerRow(idx, url)
                        if (idx < t.workerActivity.lastIndex) Spacer(Modifier.height(6.dp))
                    }
                }
                Spacer(Modifier.height(14.dp))
            }

            // ── Timeline ──────────────────────────────────────────
            item {
                Text(
                    "\uD83D\uDCDC Recent events (${t.events.size})",
                    fontWeight = FontWeight.SemiBold,
                    fontSize = 14.sp,
                    modifier = Modifier.padding(vertical = 8.dp)
                )
            }
            // Most-recent-first.
            items(t.events.asReversed()) { ev ->
                EventRow(ev) { url ->
                    // A tapped dashboard URL is a normal WebViewer link request;
                    // presentation is controlled globally by Settings.
                    vm.requestWebPopup(url)
                }
            }
            item { Spacer(Modifier.height(24.dp)) }
        }
    }
}

@Composable
private fun EmptyState(modifier: Modifier) {
    Column(
        modifier = modifier,
        verticalArrangement = Arrangement.Center,
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Text("\uD83D\uDCE4", fontSize = 48.sp)
        Spacer(Modifier.height(12.dp))
        Text(
            "No batch save in progress",
            fontSize = 16.sp,
            fontWeight = FontWeight.SemiBold
        )
        Spacer(Modifier.height(4.dp))
        Text(
            "Kick one off from the WebViewer to see live stats here.",
            fontSize = 13.sp,
            color = MaterialTheme.colorScheme.onSurfaceVariant
        )
    }
}

@Composable
private fun HeaderCard(
    active: Boolean,
    elapsedMs: Long,
    remaining: Int,
    done: Int,
    ok: Int,
    onStop: () -> Unit
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .background(
                color = if (active) MaterialTheme.colorScheme.tertiaryContainer
                    else MaterialTheme.colorScheme.surfaceVariant,
                shape = RoundedCornerShape(14.dp)
            )
            .padding(14.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        if (active) {
            CircularProgressIndicator(
                strokeWidth = 2.5.dp,
                modifier = Modifier.size(28.dp),
                color = MaterialTheme.colorScheme.onTertiaryContainer
            )
        } else {
            Text(
                if (ok > 0) "\u2705" else "\u23F9\uFE0F",
                fontSize = 26.sp
            )
        }
        Spacer(Modifier.width(12.dp))
        Column(Modifier.weight(1f)) {
            Text(
                when {
                    active -> "Saving\u2026"
                    ok > 0 -> "Complete"
                    else -> "Idle"
                },
                fontWeight = FontWeight.Bold, fontSize = 15.sp
            )
            Text(
                if (active) "$remaining remaining \u00B7 ${formatDuration(elapsedMs)} elapsed"
                else "$done processed \u00B7 ${formatDuration(elapsedMs)} total",
                fontSize = 12.sp,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
        }
        if (active) {
            Spacer(Modifier.width(8.dp))
            OutlinedButton(onClick = onStop) {
                Text("\u2716 Stop", fontSize = 12.sp)
            }
        }
    }
}

@Composable
private fun Card(title: String, content: @Composable () -> Unit) {
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .background(
                MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f),
                shape = RoundedCornerShape(12.dp)
            )
            .padding(14.dp)
    ) {
        Text(title, fontWeight = FontWeight.SemiBold, fontSize = 13.sp)
        Spacer(Modifier.height(10.dp))
        content()
    }
}

@Composable
private fun StatRow(label: String, value: String, valueColor: Color? = null) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 3.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(
            label,
            fontSize = 13.sp,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
            modifier = Modifier.weight(1f)
        )
        Text(
            value,
            fontSize = 13.sp,
            fontWeight = FontWeight.SemiBold,
            color = valueColor ?: MaterialTheme.colorScheme.onSurface,
            fontFamily = FontFamily.Monospace
        )
    }
}

@Composable
private fun WorkerRow(idx: Int, url: String?) {
    Row(verticalAlignment = Alignment.CenterVertically) {
        Box(
            modifier = Modifier
                .size(10.dp)
                .background(
                    color = if (url != null) Color(0xFF43A047) else Color(0xFF9E9E9E),
                    shape = RoundedCornerShape(50)
                )
        )
        Spacer(Modifier.width(10.dp))
        Column(Modifier.weight(1f)) {
            Text(
                "Worker ${idx + 1}",
                fontSize = 12.sp,
                fontWeight = FontWeight.SemiBold
            )
            Text(
                url?.let { shortenUrl(it) } ?: "idle",
                fontSize = 11.sp,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                fontFamily = FontFamily.Monospace,
                maxLines = 1
            )
        }
    }
}

@Composable
private fun EventRow(ev: AppViewModel.BatchEvent, onUrlClick: (String) -> Unit) {
    val (emoji, colorTone) = when (ev.kind) {
        AppViewModel.BatchEventKind.FETCH_START -> "\uD83D\uDD04" to Color(0xFF616161)
        AppViewModel.BatchEventKind.SAVE_OK -> "\u2705" to Color(0xFF2E7D32)
        AppViewModel.BatchEventKind.SAVE_FAIL -> "\u274C" to Color(0xFFC62828)
        AppViewModel.BatchEventKind.SKIP_DUPE -> "\u267B\uFE0F" to Color(0xFF1565C0)
        AppViewModel.BatchEventKind.SKIP_SMALL -> "\uD83D\uDCCF" to Color(0xFFEF6C00)
        AppViewModel.BatchEventKind.HEAD_EXPAND -> "\uD83C\uDF33" to Color(0xFF6A1B9A)
    }
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 5.dp),
        verticalAlignment = Alignment.Top
    ) {
        Text(emoji, fontSize = 14.sp)
        Spacer(Modifier.width(8.dp))
        Column(Modifier.weight(1f)) {
            Text(
                ev.title.ifBlank { ev.url },
                fontSize = 12.sp,
                fontWeight = FontWeight.Medium,
                maxLines = 1
            )
            Text(
                ev.message,
                fontSize = 10.sp,
                color = colorTone
            )
            // v5.4.113cc — Show the ONLINE article URL as a clickable
            // link so the user can open it and eyeball whether a
            // "URL match" dupe skip was legitimate (i.e. whether the
            // online URL really equals a library note's source URL).
            // Tapping opens it in the WebViewer.
            if (ev.url.isNotBlank()) {
                Text(
                    ev.url,
                    fontSize = 10.sp,
                    color = MaterialTheme.colorScheme.primary,
                    textDecoration = androidx.compose.ui.text.style.TextDecoration.Underline,
                    modifier = Modifier
                        .fillMaxWidth()
                        .clickable { onUrlClick(ev.url) }
                        .padding(vertical = 2.dp)
                )
            }
            val meta = buildString {
                append(formatTs(ev.timestampMs))
                if (ev.workerIdx >= 0) append(" \u00B7 W${ev.workerIdx + 1}")
                if (ev.durationMs > 0) append(" \u00B7 ${ev.durationMs}ms")
                if (ev.bytes > 0) append(" \u00B7 ${formatBytes(ev.bytes)}")
            }
            Text(
                meta,
                fontSize = 10.sp,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                fontFamily = FontFamily.Monospace
            )
        }
    }
    HorizontalDivider(color = MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.4f))
}

// ── Formatting helpers ──

private fun formatBytes(bytes: Long): String = when {
    bytes < 1024 -> "$bytes B"
    bytes < 1024 * 1024 -> "%.1f KB".format(Locale.US, bytes / 1024.0)
    bytes < 1024L * 1024L * 1024L -> "%.2f MB".format(Locale.US, bytes / (1024.0 * 1024.0))
    else -> "%.2f GB".format(Locale.US, bytes / (1024.0 * 1024.0 * 1024.0))
}

private fun formatBytesPerSec(bps: Double): String = when {
    bps < 1024 -> "%.0f B/s".format(Locale.US, bps)
    bps < 1024 * 1024 -> "%.1f KB/s".format(Locale.US, bps / 1024.0)
    else -> "%.2f MB/s".format(Locale.US, bps / (1024.0 * 1024.0))
}

private fun formatDuration(ms: Long): String {
    val totalSec = ms / 1000
    val h = totalSec / 3600
    val m = (totalSec % 3600) / 60
    val s = totalSec % 60
    return if (h > 0) "%dh %02dm %02ds".format(Locale.US, h, m, s)
    else if (m > 0) "%dm %02ds".format(Locale.US, m, s)
    else "%ds".format(Locale.US, s)
}

private val TS_FMT = SimpleDateFormat("HH:mm:ss", Locale.US)
private fun formatTs(ms: Long): String = TS_FMT.format(Date(ms))

private fun shortenUrl(url: String): String {
    if (url.length <= 60) return url
    return url.take(40) + "\u2026" + url.takeLast(15)
}
