package com.tebogo.markvault.data

import android.content.Context
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.floatPreferencesKey
import androidx.datastore.preferences.core.intPreferencesKey
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map

private val Context.dataStore by preferencesDataStore(name = "settings")

private val KEY_LIBRARY_URI = stringPreferencesKey("library_uri")
private val KEY_FONT_SCALE = floatPreferencesKey("font_scale")
private val KEY_THEME = stringPreferencesKey("reader_theme")
private val KEY_TOPIC_VERSION = intPreferencesKey("topic_version")
private val KEY_LINKS_VERSION = intPreferencesKey("links_version")
private val KEY_RECENT_SEARCHES = stringPreferencesKey("recent_searches_v1")
private val KEY_IMPORTS_SUBFOLDER = stringPreferencesKey("imports_subfolder")
// Web-import toggles (matches markdownr's "Include X" checkboxes)
private val KEY_INCLUDE_FRONTMATTER = androidx.datastore.preferences.core.booleanPreferencesKey("include_frontmatter")
private val KEY_INCLUDE_URL = androidx.datastore.preferences.core.booleanPreferencesKey("include_url")
private val KEY_INCLUDE_EXCERPT = androidx.datastore.preferences.core.booleanPreferencesKey("include_excerpt")
private val KEY_INCLUDE_BODY = androidx.datastore.preferences.core.booleanPreferencesKey("include_body")
// Performance/feature toggles — let the user re-enable features that are off by
// default for performance reasons. Useful on higher-end devices.
private val KEY_SMART_STYLING_ALL_DOCS = androidx.datastore.preferences.core.booleanPreferencesKey("smart_styling_all_docs")
private val KEY_SWIPE_SWITCH_TABS = androidx.datastore.preferences.core.booleanPreferencesKey("swipe_switch_tabs")
/** Text contrast multiplier 1.0 = default, up to 2.0 = max boost. Drives WebView CSS variables. */
private val KEY_TEXT_CONTRAST = androidx.datastore.preferences.core.floatPreferencesKey("text_contrast")

class Prefs(private val context: Context) {

    val libraryUri: Flow<String?> = context.dataStore.data.map { it[KEY_LIBRARY_URI] }
    val fontScale: Flow<Float> = context.dataStore.data.map { it[KEY_FONT_SCALE] ?: 1.0f }
    val theme: Flow<String> = context.dataStore.data.map { it[KEY_THEME] ?: "dark" }
    val topicVersion: Flow<Int> = context.dataStore.data.map { it[KEY_TOPIC_VERSION] ?: 0 }
    val linksVersion: Flow<Int> = context.dataStore.data.map { it[KEY_LINKS_VERSION] ?: 0 }
    val recentSearchesRaw: Flow<String> = context.dataStore.data.map { it[KEY_RECENT_SEARCHES] ?: "" }
    /** Subfolder of the library where web-import .md files are written. */
    val importsSubfolder: Flow<String> = context.dataStore.data.map {
        it[KEY_IMPORTS_SUBFOLDER] ?: ""
    }

    // Include toggles for web imports — match the markdownr "Include X" UX.
    val includeFrontmatter: Flow<Boolean> = context.dataStore.data.map { it[KEY_INCLUDE_FRONTMATTER] ?: true }
    val includeUrl: Flow<Boolean>         = context.dataStore.data.map { it[KEY_INCLUDE_URL] ?: true }
    val includeExcerpt: Flow<Boolean>     = context.dataStore.data.map { it[KEY_INCLUDE_EXCERPT] ?: true }
    val includeBody: Flow<Boolean>        = context.dataStore.data.map { it[KEY_INCLUDE_BODY] ?: true }

    /**
     * When ON, smart styling runs on documents of every size — including the
     * 60k+ char ones it skips by default. Heavy DOM = potentially laggy scroll
     * on lower-end devices, but full visual richness on higher-end devices.
     */
    val smartStylingAllDocs: Flow<Boolean> = context.dataStore.data.map { it[KEY_SMART_STYLING_ALL_DOCS] ?: false }

    /**
     * When ON, restores horizontal swipe-to-switch-tabs in the markdown reader.
     * Adds touch-event interception that can mildly impact scrolling perf on
     * lower-end devices, hence the default-OFF.
     */
    val swipeSwitchTabs: Flow<Boolean> = context.dataStore.data.map { it[KEY_SWIPE_SWITCH_TABS] ?: false }

    /** Text contrast boost. 1.0 = default; values > 1 brighten foreground / darken background. */
    val textContrast: Flow<Float> = context.dataStore.data.map { it[KEY_TEXT_CONTRAST] ?: 1.0f }

    suspend fun setRecentSearchesRaw(value: String) {
        context.dataStore.edit { it[KEY_RECENT_SEARCHES] = value }
    }

    suspend fun setTopicVersion(v: Int) {
        context.dataStore.edit { it[KEY_TOPIC_VERSION] = v }
    }

    suspend fun setLinksVersion(v: Int) {
        context.dataStore.edit { it[KEY_LINKS_VERSION] = v }
    }

    suspend fun setLibraryUri(uri: String) {
        context.dataStore.edit { it[KEY_LIBRARY_URI] = uri }
    }

    suspend fun setFontScale(scale: Float) {
        context.dataStore.edit { it[KEY_FONT_SCALE] = scale }
    }

    suspend fun setTheme(name: String) {
        context.dataStore.edit { it[KEY_THEME] = name }
    }

    suspend fun setImportsSubfolder(name: String) {
        context.dataStore.edit { it[KEY_IMPORTS_SUBFOLDER] = name }
    }

    suspend fun setIncludeFrontmatter(v: Boolean) { context.dataStore.edit { it[KEY_INCLUDE_FRONTMATTER] = v } }
    suspend fun setIncludeUrl(v: Boolean)         { context.dataStore.edit { it[KEY_INCLUDE_URL] = v } }
    suspend fun setIncludeExcerpt(v: Boolean)     { context.dataStore.edit { it[KEY_INCLUDE_EXCERPT] = v } }
    suspend fun setIncludeBody(v: Boolean)        { context.dataStore.edit { it[KEY_INCLUDE_BODY] = v } }

    suspend fun setSmartStylingAllDocs(v: Boolean) {
        context.dataStore.edit { it[KEY_SMART_STYLING_ALL_DOCS] = v }
    }
    suspend fun setSwipeSwitchTabs(v: Boolean) {
        context.dataStore.edit { it[KEY_SWIPE_SWITCH_TABS] = v }
    }
    suspend fun setTextContrast(v: Float) {
        context.dataStore.edit { it[KEY_TEXT_CONTRAST] = v.coerceIn(1.0f, 2.0f) }
    }
}
