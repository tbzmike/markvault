package com.tebogo.markvault.data

import android.content.Context
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.floatPreferencesKey
import androidx.datastore.preferences.core.intPreferencesKey
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map

private val Context.dataStore by preferencesDataStore(name = "settings")

private val KEY_LIBRARY_URI = stringPreferencesKey("library_uri")
private val KEY_FONT_SCALE = floatPreferencesKey("font_scale")
private val KEY_THEME = stringPreferencesKey("reader_theme")
private val KEY_TOPIC_VERSION = intPreferencesKey("topic_version")
private val KEY_LINKS_VERSION = intPreferencesKey("links_version")
private val KEY_RECENT_SEARCHES = stringPreferencesKey("recent_searches_v1")
private val KEY_IMPORTS_SUBFOLDER = stringPreferencesKey("imports_subfolder")

class Prefs(private val context: Context) {

    val libraryUri: Flow<String?> = context.dataStore.data.map { it[KEY_LIBRARY_URI] }
    val fontScale: Flow<Float> = context.dataStore.data.map { it[KEY_FONT_SCALE] ?: 1.0f }
    val theme: Flow<String> = context.dataStore.data.map { it[KEY_THEME] ?: "dark" }
    val topicVersion: Flow<Int> = context.dataStore.data.map { it[KEY_TOPIC_VERSION] ?: 0 }
    val linksVersion: Flow<Int> = context.dataStore.data.map { it[KEY_LINKS_VERSION] ?: 0 }
    val recentSearchesRaw: Flow<String> = context.dataStore.data.map { it[KEY_RECENT_SEARCHES] ?: "" }
    /** Subfolder of the library where web-import .md files are written. */
    val importsSubfolder: Flow<String> = context.dataStore.data.map {
        it[KEY_IMPORTS_SUBFOLDER] ?: ""
    }

    suspend fun setRecentSearchesRaw(value: String) {
        context.dataStore.edit { it[KEY_RECENT_SEARCHES] = value }
    }

    suspend fun setTopicVersion(v: Int) {
        context.dataStore.edit { it[KEY_TOPIC_VERSION] = v }
    }

    suspend fun setLinksVersion(v: Int) {
        context.dataStore.edit { it[KEY_LINKS_VERSION] = v }
    }

    suspend fun setLibraryUri(uri: String) {
        context.dataStore.edit { it[KEY_LIBRARY_URI] = uri }
    }

    suspend fun setFontScale(scale: Float) {
        context.dataStore.edit { it[KEY_FONT_SCALE] = scale }
    }

    suspend fun setTheme(name: String) {
        context.dataStore.edit { it[KEY_THEME] = name }
    }

    suspend fun setImportsSubfolder(name: String) {
        context.dataStore.edit { it[KEY_IMPORTS_SUBFOLDER] = name }
    }
}
