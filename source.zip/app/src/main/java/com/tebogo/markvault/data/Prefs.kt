package com.tebogo.markvault.data

import android.content.Context
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.floatPreferencesKey
import androidx.datastore.preferences.core.intPreferencesKey
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map

private val Context.dataStore by preferencesDataStore(name = "settings")

private val KEY_LIBRARY_URI = stringPreferencesKey("library_uri")
private val KEY_FONT_SCALE = floatPreferencesKey("font_scale")
private val KEY_THEME = stringPreferencesKey("reader_theme")
private val KEY_TOPIC_VERSION = intPreferencesKey("topic_version")
private val KEY_LINKS_VERSION = intPreferencesKey("links_version")
private val KEY_RECENT_SEARCHES = stringPreferencesKey("recent_searches_v1")
private val KEY_IMPORTS_SUBFOLDER = stringPreferencesKey("imports_subfolder")
// v5.4.90cc — Newline-separated list of source URLs the user has already
// saved as offline HTML. Used by the WebViewer multi-select feature to
// (a) skip duplicates during batch save and (b) paint a distinct "already
// saved" highlight on links that live in the library. Newline is a safe
// separator because URLs can't contain literal LFs.
private val KEY_SAVED_OFFLINE_URLS = stringPreferencesKey("saved_offline_urls_v1")
// Web-import toggles (matches markdownr's "Include X" checkboxes)
private val KEY_INCLUDE_FRONTMATTER = androidx.datastore.preferences.core.booleanPreferencesKey("include_frontmatter")
private val KEY_INCLUDE_URL = androidx.datastore.preferences.core.booleanPreferencesKey("include_url")
private val KEY_INCLUDE_EXCERPT = androidx.datastore.preferences.core.booleanPreferencesKey("include_excerpt")

// ── v4.20.0 — On-device chat (RAG) preference keys ─────────────────────────
//
// Three toggles exposed in Settings so the user can revisit the chat UX
// decisions without code changes. Defaults baked in via the Flow `?:`
// fallback match the user's chosen v1 defaults (opt-in install, own
// screen, fresh per question).
//
// chat_install_flow:    "opt_in" | "auto_prompt"
// chat_location:        "own_screen" | "in_search"
// chat_history_mode:    "fresh_per_q" | "multi_turn"
private val KEY_CHAT_INSTALL_FLOW = stringPreferencesKey("chat_install_flow")
private val KEY_CHAT_LOCATION = stringPreferencesKey("chat_location")
private val KEY_CHAT_HISTORY_MODE = stringPreferencesKey("chat_history_mode")
private val KEY_CHAT_ACTIVE_MODEL_ID = stringPreferencesKey("chat_active_model_id")
// v4.21.2 — when the LLM gets loaded into RAM:
//   "on_open"     → load when chat screen opens (default; ~5–10s wait once per session)
//   "preload"     → load at app start (chat instant, ~900 MB always held)
//   "on_first_q"  → load on first message tap (input always enabled, first answer slow)
private val KEY_CHAT_MODEL_LOAD_MODE = stringPreferencesKey("chat_model_load_mode")
// v4.23.0 — When ON and the reranker model is installed, search results
// pass through a second-stage cross-encoder reranker for higher quality.
// Adds ~3–5 s latency per search. Off by default — opt-in.
private val KEY_RERANK_ENABLED = androidx.datastore.preferences.core.booleanPreferencesKey("rerank_enabled")
/** v5.4.76cc — Master switch for LLM-driven multi-query search expansion. See docstring on the flow. */
private val KEY_AI_LLM_SEARCH_ENABLED = androidx.datastore.preferences.core.booleanPreferencesKey("ai_llm_search_enabled")
/** v5.4.79cc — Memory-safety belt around the LLM expander (free-RAM precheck + tight timeout). */
private val KEY_MEMORY_OPTIMIZED_LLM = androidx.datastore.preferences.core.booleanPreferencesKey("memory_optimized_llm")
/** v5.4.80cc — How many LLM paraphrases per submitted search. Slider-driven, 0..10. */
private val KEY_LLM_PARAPHRASE_COUNT = androidx.datastore.preferences.core.intPreferencesKey("llm_paraphrase_count")
private val KEY_POPUP_ARTICLES_TOP_N = intPreferencesKey("popup_articles_top_n")
/**
 * v5.4.121cc — Persists which query-expansion engine is selected:
 * "builtin" (Phi-4-mini via [com.tebogo.markvault.llm.LlmQueryExpander])
 * or "t5_base" (on-device T5-base ONNX paraphraser). Previously this
 * choice lived only in a Compose `remember {}` on the Settings screen,
 * so it silently reverted to "builtin" on every screen re-entry and on
 * every process restart even though the T5 model stayed downloaded.
 */
private val KEY_T5_EXPANSION_MODE = androidx.datastore.preferences.core.stringPreferencesKey("t5_expansion_mode")
/** v5.4.82cc — Master switch for the in-app WebView popup (bottom sheet). See docstring on the flow. */
private val KEY_WEB_VIEWER_POPUP_ENABLED = androidx.datastore.preferences.core.booleanPreferencesKey("web_viewer_popup_enabled")
/** v5.4.84cc — Independent switch for in-app WebView full-screen mode. See docstring on the flow. */
private val KEY_WEB_VIEWER_FULLSCREEN_ENABLED = androidx.datastore.preferences.core.booleanPreferencesKey("web_viewer_fullscreen_enabled")
private val KEY_MAX_RECENT_SEARCHES_ON_HOME = intPreferencesKey("max_recent_searches_on_home")
private val KEY_TABS_PREVIEW_ORIENTATION = stringPreferencesKey("tabs_preview_orientation")

// v5.4.105cc — Session-state persistence so a RAM-kill or crash doesn't
// wipe the user's working context. Each key is written whenever the
// underlying VM state changes; on next launch the values are re-read
// and the app resumes at the last route / open tabs / active tab. Not
// meant to be a full state-restoration framework — just enough to hit
// the user's "I don't want to start over" bar. See:
//   • KEY_LAST_ROUTE      — top-level nav route (home / webSearch / …)
//   • KEY_WEB_TABS        — URLs of open WebViewer tabs, "|"-joined
//   • KEY_WEB_TABS_TITLES — matching titles for the tabs above
//   • KEY_WEB_ACTIVE_IDX  — index of the currently-visible WebViewer tab
private val KEY_LAST_ROUTE = stringPreferencesKey("last_route_v1")
private val KEY_WEB_TABS = stringPreferencesKey("web_tabs_urls_v1")
private val KEY_WEB_TABS_TITLES = stringPreferencesKey("web_tabs_titles_v1")
private val KEY_WEB_ACTIVE_IDX = intPreferencesKey("web_active_tab_idx_v1")
// v5.4.106cc — Reader (article) tabs. Each tab is stored as three
// parallel arrays keyed by the same index: id, title, fileType.
// A dedicated "active id" key records which tab was focused; on
// restore, the VM re-opens the tabs and switches to that id if
// still present. Note ids can go stale (indexer reassigns them on
// reindex) so restore silently drops missing ids.
private val KEY_READER_TAB_IDS = stringPreferencesKey("reader_tab_ids_v1")
private val KEY_READER_TAB_TITLES = stringPreferencesKey("reader_tab_titles_v1")
private val KEY_READER_TAB_TYPES = stringPreferencesKey("reader_tab_types_v1")
private val KEY_READER_ACTIVE_ID = stringPreferencesKey("reader_active_id_v1")

// v5.4.108cc — In-flight batch-save queue snapshot for cold-start
// resume. Format: each item is `url\u0001title\u0001expanded` (where
// `expanded` is "1" or "0"), items joined with `\u0000`. Written by
// [AppViewModel.persistBatchSaveQueue] whenever the request flow
// changes; cleared by [AppViewModel.finishBatchSave]. On next launch
// the VM reads it in init and — if non-empty — re-fires the batch
// save with whatever items were still pending. Foreground-service
// death (OS RAM-kill) is the primary trigger for this recovery path.
private val KEY_BATCH_SAVE_QUEUE = stringPreferencesKey("batch_save_queue_v1")

// v5.4.115cc — In-flight multi-select head-expansion queue. Same
// motivation as the batch-save queue above: an expansion run that gets
// interrupted by a RAM-kill or crash used to be lost entirely (nothing
// persisted it), so relaunching restarted head expansion from scratch.
// Format: each entry `url\u0001text`, entries joined with `\u0000`.
private val KEY_HEAD_EXPANSION_QUEUE = stringPreferencesKey("head_expansion_queue_v1")

// v5.4.109cc — Dedup-signal toggles. Both default ON. Turning either
// off makes the batch save fetch that item regardless of the
// corresponding cache. Debug lever for cases like "1000 selected, 980
// skipped" — flip title matching off to see if URL matches account for
// the skip count on their own.
private val KEY_DEDUP_BY_URL = androidx.datastore.preferences.core.booleanPreferencesKey("dedup_by_url_v1")
private val KEY_DEDUP_BY_TITLE = androidx.datastore.preferences.core.booleanPreferencesKey("dedup_by_title_v1")

// v5.4.111cc — Search-chip visibility toggles. Each controls whether one
// of the chips under the search bar is rendered. All default ON so the
// screen is unchanged until the user hides chips in Settings.
private val KEY_CHIP_SEMANTIC = androidx.datastore.preferences.core.booleanPreferencesKey("chip_semantic_v1")
private val KEY_CHIP_RERANK = androidx.datastore.preferences.core.booleanPreferencesKey("chip_rerank_v1")
private val KEY_CHIP_RERANK_PCT = androidx.datastore.preferences.core.booleanPreferencesKey("chip_rerank_pct_v1")
private val KEY_CHIP_SEMANTIC_PCT = androidx.datastore.preferences.core.booleanPreferencesKey("chip_semantic_pct_v1")
private val KEY_CHIP_ACCURATE = androidx.datastore.preferences.core.booleanPreferencesKey("chip_accurate_v1")

// v5.4.114cc — Expressive motion plugin. This is an OPT-IN layer that
// adds spring-based animation to dialogs/menus/screens. It is OFF by
// default so the app behaves exactly as before unless the user turns
// it on in Settings. `motionEnabled` is the master kill switch;
// `motionProfile` picks the physics style when enabled. Stored as the
// enum name (not ordinal) so reordering the enum can never remap a
// saved value to the wrong profile.
private val KEY_MOTION_ENABLED = androidx.datastore.preferences.core.booleanPreferencesKey("motion_enabled_v1")
private val KEY_MOTION_PROFILE = stringPreferencesKey("motion_profile_v1")
private val KEY_KEYWORD_FILTER_ENABLED = androidx.datastore.preferences.core.booleanPreferencesKey("keyword_filter_enabled")
private val KEY_LIVE_SEARCH_ENABLED = androidx.datastore.preferences.core.booleanPreferencesKey("live_search_enabled")
private val KEY_CANCEL_INFLIGHT_SEARCH = androidx.datastore.preferences.core.booleanPreferencesKey("cancel_inflight_search")
private val KEY_AUTO_FREE_MEMORY = androidx.datastore.preferences.core.booleanPreferencesKey("auto_free_memory")
private val KEY_RERANK_ON_SUBMIT_ONLY = androidx.datastore.preferences.core.booleanPreferencesKey("rerank_on_submit_only")
private val KEY_RERANKER_MODEL_ID = stringPreferencesKey("reranker_model_id")
private val KEY_ARTICLE_HIGHLIGHT_ENABLED = androidx.datastore.preferences.core.booleanPreferencesKey("article_highlight_enabled")
private val KEY_HIGHLIGHT_MODE = androidx.datastore.preferences.core.stringPreferencesKey("highlight_mode")
private val KEY_LINK_LONG_PRESS_ACTION = androidx.datastore.preferences.core.stringPreferencesKey("link_long_press_action")
private val KEY_SHOW_RERANK_PROGRESS = androidx.datastore.preferences.core.booleanPreferencesKey("show_rerank_progress")
private val KEY_SHOW_SEMANTIC_PROGRESS = androidx.datastore.preferences.core.booleanPreferencesKey("show_semantic_progress")
private val KEY_SEARCH_IN_ARTICLE_FAB = androidx.datastore.preferences.core.booleanPreferencesKey("search_in_article_fab")
private val KEY_SEMANTIC_IN_ARTICLE = androidx.datastore.preferences.core.booleanPreferencesKey("semantic_in_article")
private val KEY_SEARCH_INDICATOR_STYLE = androidx.datastore.preferences.core.stringPreferencesKey("search_indicator_style")
private val KEY_DUPLICATE_DELETE_PASSWORD = androidx.datastore.preferences.core.stringPreferencesKey("duplicate_delete_password")
private val KEY_UI_MODE = androidx.datastore.preferences.core.stringPreferencesKey("ui_mode")
private val KEY_INCLUDE_BODY = androidx.datastore.preferences.core.booleanPreferencesKey("include_body")
// Performance/feature toggles — let the user re-enable features that are off by
// default for performance reasons. Useful on higher-end devices.
private val KEY_SMART_STYLING_ALL_DOCS = androidx.datastore.preferences.core.booleanPreferencesKey("smart_styling_all_docs")
private val KEY_SWIPE_SWITCH_TABS = androidx.datastore.preferences.core.booleanPreferencesKey("swipe_switch_tabs")
/** v5.4.35 — When true (default), scripture / external links from offline articles
 *  open in a brand-new browser tab. When false, they reuse the active tab. */
private val KEY_OPEN_LINKS_IN_NEW_TAB = androidx.datastore.preferences.core.booleanPreferencesKey("open_links_in_new_tab")
/** v5.4.36 — When true, home-screen article rows scroll vertically instead of
 *  the default horizontal LazyRow. */
private val KEY_HOME_SCROLL_VERTICAL = androidx.datastore.preferences.core.booleanPreferencesKey("home_scroll_vertical")
/** Text contrast multiplier 1.0 = default, up to 2.0 = max boost. Drives WebView CSS variables. */
private val KEY_TEXT_CONTRAST = androidx.datastore.preferences.core.floatPreferencesKey("text_contrast")

// v4.9.0 — Semantic search controls.
/** Master switch for the semantic ranking layer. Defaults to ON. */
private val KEY_SEMANTIC_ENABLED = androidx.datastore.preferences.core.booleanPreferencesKey("semantic_enabled")
/** Whether to automatically check for newer embedding models on app launch. */
private val KEY_AUTO_CHECK_MODEL_UPDATES = androidx.datastore.preferences.core.booleanPreferencesKey("auto_check_model_updates")
/** Which model id from [ModelCatalog] the user has selected as active. */
private val KEY_ACTIVE_MODEL_ID = stringPreferencesKey("active_model_id")

class Prefs(private val context: Context) {

    val libraryUri: Flow<String?> = context.dataStore.data.map { it[KEY_LIBRARY_URI] }
    val fontScale: Flow<Float> = context.dataStore.data.map { it[KEY_FONT_SCALE] ?: 1.0f }
    val theme: Flow<String> = context.dataStore.data.map { it[KEY_THEME] ?: "dark" }
    val topicVersion: Flow<Int> = context.dataStore.data.map { it[KEY_TOPIC_VERSION] ?: 0 }
    val linksVersion: Flow<Int> = context.dataStore.data.map { it[KEY_LINKS_VERSION] ?: 0 }
    val recentSearchesRaw: Flow<String> = context.dataStore.data.map { it[KEY_RECENT_SEARCHES] ?: "" }
    /** Subfolder of the library where web-import .md files are written. */
    val importsSubfolder: Flow<String> = context.dataStore.data.map {
        it[KEY_IMPORTS_SUBFOLDER] ?: ""
    }

    /**
     * v5.4.90cc — Set of source URLs that have been saved as offline HTML,
     * stored as a newline-separated string in DataStore. Emitted as a raw
     * `String` here to keep the Flow lightweight; the VM parses it into a
     * `Set<String>` and caches that.
     *
     * v5.4.100cc — Cap raised 5000 → 30000. The URL-backfill pass reads
     * source URLs out of every markdown/HTML note in the library (see
     * `notesForUrlHarvest` in NoteDao); on 14K+ libraries the previous
     * 5000 cap would drop most legacy URLs, defeating cross-format
     * dedup. 30000 × ~200-char URLs ≈ 6 MB in memory / DataStore —
     * still under Android's DataStore file-size safety threshold.
     */
    val savedOfflineUrlsRaw: Flow<String> = context.dataStore.data.map {
        it[KEY_SAVED_OFFLINE_URLS] ?: ""
    }

    suspend fun setSavedOfflineUrls(urls: Set<String>) {
        // LRU cap: keep the most recent 30000 (Set order = insertion
        // order for LinkedHashSet). Anything beyond that gets pushed
        // out.
        val limited = if (urls.size <= 30000) urls
        else urls.toList().takeLast(30000).toSet()
        context.dataStore.edit { it[KEY_SAVED_OFFLINE_URLS] = limited.joinToString("\n") }
    }

    // Include toggles for web imports — match the markdownr "Include X" UX.
    val includeFrontmatter: Flow<Boolean> = context.dataStore.data.map { it[KEY_INCLUDE_FRONTMATTER] ?: true }
    val includeUrl: Flow<Boolean>         = context.dataStore.data.map { it[KEY_INCLUDE_URL] ?: true }
    val includeExcerpt: Flow<Boolean>     = context.dataStore.data.map { it[KEY_INCLUDE_EXCERPT] ?: true }
    val includeBody: Flow<Boolean>        = context.dataStore.data.map { it[KEY_INCLUDE_BODY] ?: true }

    // ── v4.20.0 — On-device chat preference Flows ──────────────────────────
    /** "opt_in" (default — user taps Install button) or "auto_prompt"
     *  (chat screen prompts user on first open). */
    val chatInstallFlow: Flow<String> = context.dataStore.data.map {
        it[KEY_CHAT_INSTALL_FLOW] ?: "opt_in"
    }
    /** "own_screen" (default — dedicated screen via overflow menu) or
     *  "in_search" (toggle inside the existing Search screen). */
    val chatLocation: Flow<String> = context.dataStore.data.map {
        it[KEY_CHAT_LOCATION] ?: "own_screen"
    }
    /** "fresh_per_q" (default — each question is independent) or
     *  "multi_turn" (conversation history kept within session). */
    val chatHistoryMode: Flow<String> = context.dataStore.data.map {
        it[KEY_CHAT_HISTORY_MODE] ?: "fresh_per_q"
    }
    /** Currently selected chat model id from [ChatModelCatalog]. v5.4.79cc
     *  changed the fresh-install fallback from Phi-4-mini to SmolLM2-135M
     *  because the 3.8B Phi-4-mini caused OOM crashes on 6 GB devices
     *  during LLM query expansion. Existing users whose DataStore already
     *  holds one of the older ids — v5.4.73's two chat-tier ids
     *  ("qwen3-0_6b-mixed-int4", "qwen25-1_5b-instruct-q8"), v5.4.74cc's
     *  id ("qwen25-3b-instruct-q8"), or v5.4.75cc–v5.4.78cc's
     *  ("phi4-mini-instruct-q8") — keep that saved value; the catalog's
     *  `byId(...) ?: default` fallback then transparently routes them to
     *  the new default only if the saved id has been removed from the
     *  catalog (Phi-4-mini has NOT been removed — v5.4.75cc–v5.4.78cc
     *  users still get Phi-4-mini until they explicitly switch in
     *  Settings). */
    val chatActiveModelId: Flow<String> = context.dataStore.data.map {
        it[KEY_CHAT_ACTIVE_MODEL_ID] ?: "smollm2-135m-instruct-q8"
    }
    /**
     * When the LLM gets loaded into RAM:
     *   "on_open"     → when chat screen opens (default)
     *   "preload"     → at app start, kept loaded
     *   "on_first_q"  → first time you send a message
     */
    val chatModelLoadMode: Flow<String> = context.dataStore.data.map {
        it[KEY_CHAT_MODEL_LOAD_MODE] ?: "on_open"
    }
    /** When ON, search reranking pass runs after semantic retrieval. */
    val rerankEnabled: Flow<Boolean> = context.dataStore.data.map {
        it[KEY_RERANK_ENABLED] ?: false
    }

    /**
     * v5.4.76cc — Master switch for LLM-driven multi-query retrieval.
     * When ON *and* the Phi-4-mini model is installed, the search
     * pipeline runs the query through the on-device LLM (via
     * [com.tebogo.markvault.llm.LlmQueryExpander]) to produce a small
     * set of paraphrased sub-queries, then folds their FTS+semantic
     * hits into the merged result set. Hits reachable only through an
     * LLM paraphrase have their ids published on
     * [com.tebogo.markvault.AppViewModel.llmMatchedHitIds] (v5.4.77cc)
     * so the UI can paint the "✨ AI" chip and lavender snippet
     * highlight on those rows. Default OFF so v5.4.75cc behaviour is
     * preserved bit for bit until the user opts in from Settings.
     */
    val aiLlmSearchEnabled: Flow<Boolean> = context.dataStore.data.map {
        it[KEY_AI_LLM_SEARCH_ENABLED] ?: false
    }

    /**
     * v5.4.79cc — When ON, [com.tebogo.markvault.llm.LlmQueryExpander]
     * enforces the mobile memory-safety belt around every LLM run:
     *
     *   • A **free-RAM precheck** before load — if the process has less
     *     than `descriptor.approxRamMb + 300 MB` of headroom, the
     *     expansion is skipped for that query and the search proceeds
     *     with just the Kotlin synonyms. Prevents the OOM kill that
     *     ended the app mid-inference in v5.4.76cc–v5.4.78cc when
     *     Phi-4-mini was selected on a 6 GB device.
     *
     *   • An **aggressive 5-second generate timeout** (down from 30 s)
     *     so a stalled or thrashing inference bows out quickly instead
     *     of holding the whole search hot path.
     *
     * Default ON — it's the safe, sensible mode for the general case.
     * Users on high-RAM devices who want to trust Phi-4-mini
     * unconditionally can turn it OFF in Settings.
     */
    val memoryOptimizedLlm: Flow<Boolean> = context.dataStore.data.map {
        it[KEY_MEMORY_OPTIMIZED_LLM] ?: true
    }

    /**
     * v5.4.80cc — Number of paraphrased sub-queries the on-device LLM
     * should produce per submitted search. Wired to the settings slider
     * at the top of the Settings screen.
     *
     *   0 → skip LLM entirely (equivalent to turning the master toggle
     *       off; provided as a per-slider off-switch that keeps the
     *       Settings toggle in "AI is available" state)
     *   1..10 → target paraphrase count. The expander requests this many
     *       and trims from the top after parsing.
     *
     * Default 3 so users who flip the AI multi-query toggle on and then
     * ignore the slider get a sensible working expansion out of the
     * box. Coerced into [0, 10] on write in [setLlmParaphraseCount].
     */
    val llmParaphraseCount: Flow<Int> = context.dataStore.data.map {
        (it[KEY_LLM_PARAPHRASE_COUNT] ?: 3).coerceIn(0, 10)
    }

    /**
     * v5.4.132cc — How many top-rated search results the "search-results
     * pumping heart" FAB pulls passages from when building the multi-
     * article popup. Default 1 (the single highest-scoring article);
     * range 1..10. Coerced on write.
     */
    val popupArticlesTopN: Flow<Int> = context.dataStore.data.map {
        (it[KEY_POPUP_ARTICLES_TOP_N] ?: 1).coerceIn(1, 10)
    }

    /**
     * v5.4.121cc — Which query-expansion engine is selected: "builtin"
     * or "t5_base". Persisted so the choice survives navigation,
     * process death, and app relaunch instead of resetting to
     * "builtin" on its own. Unknown/corrupt values fall back to
     * "builtin" rather than crashing.
     */
    val t5ExpansionMode: Flow<String> = context.dataStore.data.map {
        val v = it[KEY_T5_EXPANSION_MODE] ?: "builtin"
        if (v == "t5_base") "t5_base" else "builtin"
    }

    /**
     * v5.4.82cc — Master switch for the in-app WebView popup (the
     * bottom-sheet browser that overlays whatever screen you're on
     * when a JW link is tapped).
     *
     *   • **ON (default)** — links open in the bottom-sheet popup as
     *     they always have, preserving `WebPopupSheet`'s in-app
     *     browsing UX (bookmarks, history, "Full screen" promotion,
     *     dark mode, text zoom, etc.).
     *   • **OFF** — [AppViewModel.requestWebPopup] transparently
     *     redirects to the system browser via `Intent.ACTION_VIEW`.
     *     The bottom sheet is never shown. Full-screen web routes
     *     accessed via direct navigation still work; only the popup
     *     entry point is disabled.
     *
     * Default true so the existing behaviour is preserved bit for bit
     * for anyone who doesn't touch the toggle.
     */
    val webViewerPopupEnabled: Flow<Boolean> = context.dataStore.data.map {
        it[KEY_WEB_VIEWER_POPUP_ENABLED] ?: true
    }

    /**
     * v5.4.84cc — Companion switch for the in-app WebView's full-screen
     * mode. Together with [webViewerPopupEnabled] this gives you full
     * independent control over the two in-app viewer modes:
     *
     *   ┌──────────┬─────────────┬─────────────────────────────────────┐
     *   │ Popup    │ Full-screen │ What a tapped link actually does    │
     *   ├──────────┼─────────────┼─────────────────────────────────────┤
     *   │ ON       │ ON (default)│ Popup with "Full screen" promotion  │
     *   │ OFF      │ ON          │ Direct in-app full-screen viewer    │
     *   │ ON       │ OFF         │ Popup, but "Full screen" → system   │
     *   │ OFF      │ OFF         │ System browser directly             │
     *   └──────────┴─────────────┴─────────────────────────────────────┘
     *
     * Default true so the historical default (both modes available,
     * popup wins) is preserved for anyone who never touches Settings.
     */
    val webViewerFullScreenEnabled: Flow<Boolean> = context.dataStore.data.map {
        it[KEY_WEB_VIEWER_FULLSCREEN_ENABLED] ?: true
    }

    /**
     * When ON, smart styling runs on documents of every size — including the
     * 60k+ char ones it skips by default. Heavy DOM = potentially laggy scroll
     * on lower-end devices, but full visual richness on higher-end devices.
     */
    val smartStylingAllDocs: Flow<Boolean> = context.dataStore.data.map { it[KEY_SMART_STYLING_ALL_DOCS] ?: false }

    /**
     * When ON, restores horizontal swipe-to-switch-tabs in the markdown reader.
     * Adds touch-event interception that can mildly impact scrolling perf on
     * lower-end devices, hence the default-OFF.
     */
    val swipeSwitchTabs: Flow<Boolean> = context.dataStore.data.map { it[KEY_SWIPE_SWITCH_TABS] ?: false }

    /** Text contrast boost. 1.0 = default; values > 1 brighten foreground / darken background. */
    val textContrast: Flow<Float> = context.dataStore.data.map { it[KEY_TEXT_CONTRAST] ?: 1.0f }

    // v4.9.0 — Semantic search prefs.
    /** Master semantic search switch. Default ON — once a user has embeddings, they want them used. */
    val semanticEnabled: Flow<Boolean> = context.dataStore.data.map { it[KEY_SEMANTIC_ENABLED] ?: true }
    /** Whether to automatically check for model updates on each launch. */
    val autoCheckModelUpdates: Flow<Boolean> = context.dataStore.data.map { it[KEY_AUTO_CHECK_MODEL_UPDATES] ?: false }
    /** Which model id from the catalog is currently active. Default matches the v4.8 hard-coded model. */
    val activeModelId: Flow<String> = context.dataStore.data.map { it[KEY_ACTIVE_MODEL_ID] ?: "mediapipe-use-lite-v1" }

    suspend fun setRecentSearchesRaw(value: String) {
        context.dataStore.edit { it[KEY_RECENT_SEARCHES] = value }
    }

    suspend fun setTopicVersion(v: Int) {
        context.dataStore.edit { it[KEY_TOPIC_VERSION] = v }
    }

    suspend fun setLinksVersion(v: Int) {
        context.dataStore.edit { it[KEY_LINKS_VERSION] = v }
    }

    suspend fun setLibraryUri(uri: String) {
        context.dataStore.edit { it[KEY_LIBRARY_URI] = uri }
    }

    suspend fun setFontScale(scale: Float) {
        context.dataStore.edit { it[KEY_FONT_SCALE] = scale }
    }

    suspend fun setTheme(name: String) {
        context.dataStore.edit { it[KEY_THEME] = name }
    }

    suspend fun setImportsSubfolder(name: String) {
        context.dataStore.edit { it[KEY_IMPORTS_SUBFOLDER] = name }
    }

    suspend fun setIncludeFrontmatter(v: Boolean) { context.dataStore.edit { it[KEY_INCLUDE_FRONTMATTER] = v } }

    // ── v4.20.0 — On-device chat preference setters ────────────────────────
    suspend fun setChatInstallFlow(v: String) { context.dataStore.edit { it[KEY_CHAT_INSTALL_FLOW] = v } }
    suspend fun setChatLocation(v: String) { context.dataStore.edit { it[KEY_CHAT_LOCATION] = v } }
    suspend fun setChatHistoryMode(v: String) { context.dataStore.edit { it[KEY_CHAT_HISTORY_MODE] = v } }
    suspend fun setChatActiveModelId(v: String) { context.dataStore.edit { it[KEY_CHAT_ACTIVE_MODEL_ID] = v } }
    suspend fun setChatModelLoadMode(v: String) { context.dataStore.edit { it[KEY_CHAT_MODEL_LOAD_MODE] = v } }
    suspend fun setRerankEnabled(v: Boolean) { context.dataStore.edit { it[KEY_RERANK_ENABLED] = v } }
    /** v5.4.76cc — Persist the master LLM multi-query switch. Off by default. */
    suspend fun setAiLlmSearchEnabled(v: Boolean) { context.dataStore.edit { it[KEY_AI_LLM_SEARCH_ENABLED] = v } }
    /** v5.4.79cc — Persist the LLM memory-safety belt. On by default. */
    suspend fun setMemoryOptimizedLlm(v: Boolean) { context.dataStore.edit { it[KEY_MEMORY_OPTIMIZED_LLM] = v } }
    /** v5.4.80cc — Persist the paraphrase-count slider value. Coerced 0..10. */
    suspend fun setLlmParaphraseCount(v: Int) {
        context.dataStore.edit { it[KEY_LLM_PARAPHRASE_COUNT] = v.coerceIn(0, 10) }
    }
    /** v5.4.132cc — Persist the top-N articles count for the multi-article popup FAB. Coerced 1..10. */
    suspend fun setPopupArticlesTopN(v: Int) {
        context.dataStore.edit { it[KEY_POPUP_ARTICLES_TOP_N] = v.coerceIn(1, 10) }
    }
    /** v5.4.121cc — Persist the selected query-expansion engine ("builtin" or "t5_base"). */
    suspend fun setT5ExpansionMode(v: String) {
        context.dataStore.edit { it[KEY_T5_EXPANSION_MODE] = if (v == "t5_base") "t5_base" else "builtin" }
    }
    /** v5.4.82cc — Persist the WebViewer popup master switch. */
    suspend fun setWebViewerPopupEnabled(v: Boolean) {
        context.dataStore.edit { it[KEY_WEB_VIEWER_POPUP_ENABLED] = v }
    }
    /** v5.4.84cc — Persist the WebViewer full-screen master switch. */
    suspend fun setWebViewerFullScreenEnabled(v: Boolean) {
        context.dataStore.edit { it[KEY_WEB_VIEWER_FULLSCREEN_ENABLED] = v }
    }

    /** v5.2.0 — How many recent search queries to surface on the home screen. */
    val maxRecentSearchesOnHome: Flow<Int> = context.dataStore.data.map {
        it[KEY_MAX_RECENT_SEARCHES_ON_HOME] ?: 7
    }
    suspend fun setMaxRecentSearchesOnHome(v: Int) {
        context.dataStore.edit { it[KEY_MAX_RECENT_SEARCHES_ON_HOME] = v.coerceIn(0, 20) }
    }

    /** v5.3.0 — "vertical" (default, scroll up/down) or "horizontal" (swipe side-to-side). */
    val tabsPreviewOrientation: Flow<String> = context.dataStore.data.map {
        it[KEY_TABS_PREVIEW_ORIENTATION] ?: "vertical"
    }
    suspend fun setTabsPreviewOrientation(v: String) {
        context.dataStore.edit { it[KEY_TABS_PREVIEW_ORIENTATION] = v }
    }

    // ────────────────────────────────────────────────────────────────
    // v5.4.105cc — Session-state persistence (see key defs at file top)
    // ────────────────────────────────────────────────────────────────

    /** Last top-level nav route the user was on, or "" if none saved. */
    val lastRoute: Flow<String> = context.dataStore.data.map {
        it[KEY_LAST_ROUTE].orEmpty()
    }
    suspend fun setLastRoute(v: String) {
        context.dataStore.edit { it[KEY_LAST_ROUTE] = v }
    }

    /**
     * WebViewer tab URLs, joined with a null character delimiter (safe
     * because URLs never contain \u0000). Empty string means no saved
     * session. Titles are stored in parallel via [webTabsTitles].
     */
    val webTabsUrls: Flow<String> = context.dataStore.data.map {
        it[KEY_WEB_TABS].orEmpty()
    }
    val webTabsTitles: Flow<String> = context.dataStore.data.map {
        it[KEY_WEB_TABS_TITLES].orEmpty()
    }
    val webActiveTabIdx: Flow<Int> = context.dataStore.data.map {
        it[KEY_WEB_ACTIVE_IDX] ?: 0
    }
    suspend fun setWebTabsSession(urls: List<String>, titles: List<String>, activeIdx: Int) {
        context.dataStore.edit {
            it[KEY_WEB_TABS] = urls.joinToString("\u0000")
            it[KEY_WEB_TABS_TITLES] = titles.joinToString("\u0000")
            it[KEY_WEB_ACTIVE_IDX] = activeIdx.coerceAtLeast(0)
        }
    }

    // v5.4.106cc — Reader (article) tab session
    val readerTabIds: Flow<String> = context.dataStore.data.map {
        it[KEY_READER_TAB_IDS].orEmpty()
    }
    val readerTabTitles: Flow<String> = context.dataStore.data.map {
        it[KEY_READER_TAB_TITLES].orEmpty()
    }
    val readerTabTypes: Flow<String> = context.dataStore.data.map {
        it[KEY_READER_TAB_TYPES].orEmpty()
    }
    val readerActiveId: Flow<Long?> = context.dataStore.data.map {
        it[KEY_READER_ACTIVE_ID]?.toLongOrNull()
    }
    suspend fun setReaderTabsSession(
        ids: List<Long>,
        titles: List<String>,
        types: List<String>,
        activeId: Long?
    ) {
        context.dataStore.edit {
            it[KEY_READER_TAB_IDS] = ids.joinToString("\u0000") { id -> id.toString() }
            it[KEY_READER_TAB_TITLES] = titles.joinToString("\u0000")
            it[KEY_READER_TAB_TYPES] = types.joinToString("\u0000")
            if (activeId != null) {
                it[KEY_READER_ACTIVE_ID] = activeId.toString()
            } else {
                it.remove(KEY_READER_ACTIVE_ID)
            }
        }
    }

    // v5.4.108cc — In-flight batch save queue
    val batchSaveQueue: Flow<String> = context.dataStore.data.map {
        it[KEY_BATCH_SAVE_QUEUE].orEmpty()
    }
    suspend fun setBatchSaveQueue(payload: String) {
        context.dataStore.edit {
            if (payload.isBlank()) it.remove(KEY_BATCH_SAVE_QUEUE)
            else it[KEY_BATCH_SAVE_QUEUE] = payload
        }
    }

    // v5.4.115cc — In-flight head-expansion queue
    val headExpansionQueue: Flow<String> = context.dataStore.data.map {
        it[KEY_HEAD_EXPANSION_QUEUE].orEmpty()
    }
    suspend fun setHeadExpansionQueue(payload: String) {
        context.dataStore.edit {
            if (payload.isBlank()) it.remove(KEY_HEAD_EXPANSION_QUEUE)
            else it[KEY_HEAD_EXPANSION_QUEUE] = payload
        }
    }

    /** v5.4.109cc — Whether the batch dedup filter checks the URL cache. */
    val dedupByUrl: Flow<Boolean> = context.dataStore.data.map {
        it[KEY_DEDUP_BY_URL] ?: true
    }
    suspend fun setDedupByUrl(v: Boolean) {
        context.dataStore.edit { it[KEY_DEDUP_BY_URL] = v }
    }

    /** v5.4.109cc — Whether the batch dedup filter checks the title cache. */
    val dedupByTitle: Flow<Boolean> = context.dataStore.data.map {
        it[KEY_DEDUP_BY_TITLE] ?: true
    }
    suspend fun setDedupByTitle(v: Boolean) {
        context.dataStore.edit { it[KEY_DEDUP_BY_TITLE] = v }
    }

    // v5.4.111cc — Search-chip visibility. All default true.
    val chipSemantic: Flow<Boolean> = context.dataStore.data.map { it[KEY_CHIP_SEMANTIC] ?: true }
    suspend fun setChipSemantic(v: Boolean) { context.dataStore.edit { it[KEY_CHIP_SEMANTIC] = v } }
    val chipRerank: Flow<Boolean> = context.dataStore.data.map { it[KEY_CHIP_RERANK] ?: true }
    suspend fun setChipRerank(v: Boolean) { context.dataStore.edit { it[KEY_CHIP_RERANK] = v } }
    val chipRerankPct: Flow<Boolean> = context.dataStore.data.map { it[KEY_CHIP_RERANK_PCT] ?: true }
    suspend fun setChipRerankPct(v: Boolean) { context.dataStore.edit { it[KEY_CHIP_RERANK_PCT] = v } }
    val chipSemanticPct: Flow<Boolean> = context.dataStore.data.map { it[KEY_CHIP_SEMANTIC_PCT] ?: true }
    suspend fun setChipSemanticPct(v: Boolean) { context.dataStore.edit { it[KEY_CHIP_SEMANTIC_PCT] = v } }
    val chipAccurate: Flow<Boolean> = context.dataStore.data.map { it[KEY_CHIP_ACCURATE] ?: true }
    suspend fun setChipAccurate(v: Boolean) { context.dataStore.edit { it[KEY_CHIP_ACCURATE] = v } }

    // v5.4.114cc — Expressive motion plugin (OFF by default).
    val motionEnabled: Flow<Boolean> = context.dataStore.data.map { it[KEY_MOTION_ENABLED] ?: false }
    suspend fun setMotionEnabled(v: Boolean) { context.dataStore.edit { it[KEY_MOTION_ENABLED] = v } }
    /** Stored as MotionProfile.name; defaults to "EXPRESSIVE". */
    val motionProfile: Flow<String> = context.dataStore.data.map { it[KEY_MOTION_PROFILE] ?: "EXPRESSIVE" }
    suspend fun setMotionProfile(name: String) { context.dataStore.edit { it[KEY_MOTION_PROFILE] = name } }

    /** v5.3.1 — When true (default), search results in CONTENT mode must
     *  contain at least 2 of the user's meaningful query words. When
     *  false, every keyword + semantic hit is shown. Turning this off
     *  surfaces more semantic-only matches at the cost of more noise. */
    val keywordFilterEnabled: Flow<Boolean> = context.dataStore.data.map {
        it[KEY_KEYWORD_FILTER_ENABLED] ?: true
    }
    suspend fun setKeywordFilterEnabled(v: Boolean) {
        context.dataStore.edit { it[KEY_KEYWORD_FILTER_ENABLED] = v }
    }

    /** v5.4.1 — When true (default), the search results flow updates on
     *  every debounced keystroke. When false, the search runs only when
     *  the user explicitly submits (Enter key on the search field). Use
     *  to diagnose typing-related crashes. */
    val liveSearchEnabled: Flow<Boolean> = context.dataStore.data.map {
        it[KEY_LIVE_SEARCH_ENABLED] ?: true
    }
    suspend fun setLiveSearchEnabled(v: Boolean) {
        context.dataStore.edit { it[KEY_LIVE_SEARCH_ENABLED] = v }
    }

    /** v5.4.1 — When true (default), a new keystroke cancels any
     *  in-progress search (via flow's mapLatest). When false, every
     *  debounced search runs to completion in turn. Use ON if cancelling
     *  causes issues with native code that doesn't tolerate cancellation. */
    val cancelInflightSearch: Flow<Boolean> = context.dataStore.data.map {
        it[KEY_CANCEL_INFLIGHT_SEARCH] ?: true
    }
    suspend fun setCancelInflightSearch(v: Boolean) {
        context.dataStore.edit { it[KEY_CANCEL_INFLIGHT_SEARCH] = v }
    }

    /** v5.4.1 — When true (default), the app releases ONNX sessions and
     *  the semantic index when sent to background (onTrimMemory). When
     *  false, models stay resident. Toggle OFF if you suspect the
     *  release/reload cycle is causing crashes on resume. */
    val autoFreeMemory: Flow<Boolean> = context.dataStore.data.map {
        it[KEY_AUTO_FREE_MEMORY] ?: true
    }
    suspend fun setAutoFreeMemory(v: Boolean) {
        context.dataStore.edit { it[KEY_AUTO_FREE_MEMORY] = v }
    }

    /** v5.4.5 — When true (default), the cross-encoder reranker only
     *  runs when the user explicitly submits a search (Enter key /
     *  🔍 button). When false, rerank fires on every debounced
     *  keystroke just like before. The "submit-only" mode dramatically
     *  cuts cross-encoder invocations per typing session — the right
     *  default for memory-constrained devices where the reranker has
     *  been crashing. Quality is preserved: the cross-encoder still
     *  runs, just once per actual search instead of per keystroke. */
    val rerankOnSubmitOnly: Flow<Boolean> = context.dataStore.data.map {
        it[KEY_RERANK_ON_SUBMIT_ONLY] ?: true
    }
    suspend fun setRerankOnSubmitOnly(v: Boolean) {
        context.dataStore.edit { it[KEY_RERANK_ON_SUBMIT_ONLY] = v }
    }

    /** v5.4.6 — Selected reranker model id from RerankerCatalog.
     *  Default is the L-12 model (highest quality); users on
     *  memory-constrained devices can switch to L-6. */
    val rerankerModelId: Flow<String> = context.dataStore.data.map {
        it[KEY_RERANKER_MODEL_ID] ?: "ms-marco-minilm-l12-v2"
    }
    suspend fun setRerankerModelId(id: String) {
        context.dataStore.edit { it[KEY_RERANKER_MODEL_ID] = id }
    }

    /** v5.4.6 — When ON (default), opened articles highlight whole
     *  sentences containing query terms. When OFF, the JS that walks
     *  text nodes + wraps matches doesn't run at all. Diagnostic
     *  toggle to test whether the highlighter is involved in
     *  search-related crashes. */
    val articleHighlightEnabled: Flow<Boolean> = context.dataStore.data.map {
        it[KEY_ARTICLE_HIGHLIGHT_ENABLED] ?: true
    }
    suspend fun setArticleHighlightEnabled(v: Boolean) {
        context.dataStore.edit { it[KEY_ARTICLE_HIGHLIGHT_ENABLED] = v }
    }

    /** v5.4.9 — Highlight style. Three accepted values:
     *
     *   • "auto"    (default) — sentence-level "smart" when semantic
     *                            search is enabled, word-level "keyword"
     *                            when semantic search is disabled. The
     *                            recommended setting; matches the user's
     *                            intuition that meaning-based highlight
     *                            should only fire when meaning-based
     *                            search is active.
     *   • "smart"             — always sentence-level (skips headings,
     *                            requires 2+ distinct query terms in a
     *                            sentence to trigger wrap).
     *   • "keyword"           — always word-level only (no sentence
     *                            wrapping).
     */
    val highlightMode: Flow<String> = context.dataStore.data.map {
        it[KEY_HIGHLIGHT_MODE] ?: "auto"
    }
    suspend fun setHighlightMode(v: String) {
        context.dataStore.edit { it[KEY_HIGHLIGHT_MODE] = v }
    }

    /** v5.4.13 — In-browser link long-press action. Three values:
     *
     *   • "menu"     (default) — show the action sheet with all options
     *                            (open in new tab, copy link, convert, etc.)
     *   • "markdown"           — silently route the link through the
     *                            URL → Markdown converter (UrlImportScreen)
     *                            without showing the action sheet first.
     *   • "offlineHtml"        — silently route the link through the
     *                            URL → offline HTML save flow.
     *   • "pdf"                — silently route the link through the
     *                            URL → PDF converter (UrlToPdfScreen).
     */
    val linkLongPressAction: Flow<String> = context.dataStore.data.map {
        it[KEY_LINK_LONG_PRESS_ACTION] ?: "menu"
    }
    suspend fun setLinkLongPressAction(v: String) {
        context.dataStore.edit { it[KEY_LINK_LONG_PRESS_ACTION] = v }
    }

    /** v5.4.35 — Open links from offline articles in a new browser tab (true, default)
     *  or reuse the active tab (false). */
    val openLinksInNewTab: Flow<Boolean> = context.dataStore.data.map {
        it[KEY_OPEN_LINKS_IN_NEW_TAB] ?: true
    }
    suspend fun setOpenLinksInNewTab(v: Boolean) {
        context.dataStore.edit { it[KEY_OPEN_LINKS_IN_NEW_TAB] = v }
    }

    /** v5.4.36 — Vertical scroll layout for home-screen article rows. */
    val homeScrollVertical: Flow<Boolean> = context.dataStore.data.map {
        it[KEY_HOME_SCROLL_VERTICAL] ?: false
    }
    suspend fun setHomeScrollVertical(v: Boolean) {
        context.dataStore.edit { it[KEY_HOME_SCROLL_VERTICAL] = v }
    }

    /** v5.4.18 — Show the % progress indicator during manual rerank. Default on. */
    val showRerankProgress: Flow<Boolean> = context.dataStore.data.map {
        it[KEY_SHOW_RERANK_PROGRESS] ?: true
    }
    suspend fun setShowRerankProgress(v: Boolean) {
        context.dataStore.edit { it[KEY_SHOW_RERANK_PROGRESS] = v }
    }

    /** v5.4.18 — Show the semantic-embedding progress indicator during downloads /
     *  index builds / model loads. Default on. */
    val showSemanticProgress: Flow<Boolean> = context.dataStore.data.map {
        it[KEY_SHOW_SEMANTIC_PROGRESS] ?: true
    }
    suspend fun setShowSemanticProgress(v: Boolean) {
        context.dataStore.edit { it[KEY_SHOW_SEMANTIC_PROGRESS] = v }
    }

    /** v5.4.18 — Show a floating "search in article" button in readers when the
     *  article was opened from a search result. Default on. */
    val searchInArticleFab: Flow<Boolean> = context.dataStore.data.map {
        it[KEY_SEARCH_IN_ARTICLE_FAB] ?: true
    }
    suspend fun setSearchInArticleFab(v: Boolean) {
        context.dataStore.edit { it[KEY_SEARCH_IN_ARTICLE_FAB] = v }
    }

    /** v5.4.18 — Also use semantic embeddings for in-article search, ranking
     *  paragraphs by cosine similarity to the query. Opt-in — off by default. */
    val semanticInArticle: Flow<Boolean> = context.dataStore.data.map {
        it[KEY_SEMANTIC_IN_ARTICLE] ?: false
    }
    suspend fun setSemanticInArticle(v: Boolean) {
        context.dataStore.edit { it[KEY_SEMANTIC_IN_ARTICLE] = v }
    }

    /** v5.4.33 — Search indicator animation style: "percentage", "hourglass", "book".
     *  Controls what animation the user sees while a search is running. */
    val searchIndicatorStyle: Flow<String> = context.dataStore.data.map {
        it[KEY_SEARCH_INDICATOR_STYLE] ?: "percentage"
    }
    suspend fun setSearchIndicatorStyle(v: String) {
        context.dataStore.edit { it[KEY_SEARCH_INDICATOR_STYLE] = v }
    }

    /** v5.4.34 — SHA-256 hashed password for duplicate deletion. Empty = not set. */
    val duplicateDeletePassword: Flow<String> = context.dataStore.data.map {
        it[KEY_DUPLICATE_DELETE_PASSWORD] ?: ""
    }
    suspend fun setDuplicateDeletePassword(hashedPw: String) {
        context.dataStore.edit { it[KEY_DUPLICATE_DELETE_PASSWORD] = hashedPw }
    }

    /** v5.4.20 — UI mode: "standard" (default) or "workspace" (Obsidian-flavored).
     *  Standard = current minimalist look. Workspace = adds a persistent
     *  horizontal tab strip to the reader for fast tab switching. Zero
     *  feature loss between modes — Workspace only adds affordances. */
    val uiMode: Flow<String> = context.dataStore.data.map {
        it[KEY_UI_MODE] ?: "standard"
    }
    suspend fun setUiMode(v: String) {
        context.dataStore.edit { it[KEY_UI_MODE] = v }
    }
    suspend fun setIncludeUrl(v: Boolean)         { context.dataStore.edit { it[KEY_INCLUDE_URL] = v } }
    suspend fun setIncludeExcerpt(v: Boolean)     { context.dataStore.edit { it[KEY_INCLUDE_EXCERPT] = v } }
    suspend fun setIncludeBody(v: Boolean)        { context.dataStore.edit { it[KEY_INCLUDE_BODY] = v } }

    suspend fun setSmartStylingAllDocs(v: Boolean) {
        context.dataStore.edit { it[KEY_SMART_STYLING_ALL_DOCS] = v }
    }
    suspend fun setSwipeSwitchTabs(v: Boolean) {
        context.dataStore.edit { it[KEY_SWIPE_SWITCH_TABS] = v }
    }
    suspend fun setTextContrast(v: Float) {
        context.dataStore.edit { it[KEY_TEXT_CONTRAST] = v.coerceIn(1.0f, 2.0f) }
    }

    // v4.9.0 — Semantic search setters.
    suspend fun setSemanticEnabled(v: Boolean) {
        context.dataStore.edit { it[KEY_SEMANTIC_ENABLED] = v }
    }
    suspend fun setAutoCheckModelUpdates(v: Boolean) {
        context.dataStore.edit { it[KEY_AUTO_CHECK_MODEL_UPDATES] = v }
    }
    suspend fun setActiveModelId(v: String) {
        context.dataStore.edit { it[KEY_ACTIVE_MODEL_ID] = v }
    }
}
