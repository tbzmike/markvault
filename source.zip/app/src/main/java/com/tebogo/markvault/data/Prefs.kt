package com.tebogo.markvault.data

import android.content.Context
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.floatPreferencesKey
import androidx.datastore.preferences.core.intPreferencesKey
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map

private val Context.dataStore by preferencesDataStore(name = "settings")

private val KEY_LIBRARY_URI = stringPreferencesKey("library_uri")
private val KEY_FONT_SCALE = floatPreferencesKey("font_scale")
private val KEY_THEME = stringPreferencesKey("reader_theme")
private val KEY_TOPIC_VERSION = intPreferencesKey("topic_version")
private val KEY_LINKS_VERSION = intPreferencesKey("links_version")
private val KEY_RECENT_SEARCHES = stringPreferencesKey("recent_searches_v1")
private val KEY_IMPORTS_SUBFOLDER = stringPreferencesKey("imports_subfolder")
// Web-import toggles (matches markdownr's "Include X" checkboxes)
private val KEY_INCLUDE_FRONTMATTER = androidx.datastore.preferences.core.booleanPreferencesKey("include_frontmatter")
private val KEY_INCLUDE_URL = androidx.datastore.preferences.core.booleanPreferencesKey("include_url")
private val KEY_INCLUDE_EXCERPT = androidx.datastore.preferences.core.booleanPreferencesKey("include_excerpt")

// ── v4.20.0 — On-device chat (RAG) preference keys ─────────────────────────
//
// Three toggles exposed in Settings so the user can revisit the chat UX
// decisions without code changes. Defaults baked in via the Flow `?:`
// fallback match the user's chosen v1 defaults (opt-in install, own
// screen, fresh per question).
//
// chat_install_flow:    "opt_in" | "auto_prompt"
// chat_location:        "own_screen" | "in_search"
// chat_history_mode:    "fresh_per_q" | "multi_turn"
private val KEY_CHAT_INSTALL_FLOW = stringPreferencesKey("chat_install_flow")
private val KEY_CHAT_LOCATION = stringPreferencesKey("chat_location")
private val KEY_CHAT_HISTORY_MODE = stringPreferencesKey("chat_history_mode")
private val KEY_CHAT_ACTIVE_MODEL_ID = stringPreferencesKey("chat_active_model_id")
// v4.21.2 — when the LLM gets loaded into RAM:
//   "on_open"     → load when chat screen opens (default; ~5–10s wait once per session)
//   "preload"     → load at app start (chat instant, ~900 MB always held)
//   "on_first_q"  → load on first message tap (input always enabled, first answer slow)
private val KEY_CHAT_MODEL_LOAD_MODE = stringPreferencesKey("chat_model_load_mode")
// v4.23.0 — When ON and the reranker model is installed, search results
// pass through a second-stage cross-encoder reranker for higher quality.
// Adds ~3–5 s latency per search. Off by default — opt-in.
private val KEY_RERANK_ENABLED = androidx.datastore.preferences.core.booleanPreferencesKey("rerank_enabled")
private val KEY_MAX_RECENT_SEARCHES_ON_HOME = intPreferencesKey("max_recent_searches_on_home")
private val KEY_TABS_PREVIEW_ORIENTATION = stringPreferencesKey("tabs_preview_orientation")
private val KEY_KEYWORD_FILTER_ENABLED = androidx.datastore.preferences.core.booleanPreferencesKey("keyword_filter_enabled")
private val KEY_INCLUDE_BODY = androidx.datastore.preferences.core.booleanPreferencesKey("include_body")
// Performance/feature toggles — let the user re-enable features that are off by
// default for performance reasons. Useful on higher-end devices.
private val KEY_SMART_STYLING_ALL_DOCS = androidx.datastore.preferences.core.booleanPreferencesKey("smart_styling_all_docs")
private val KEY_SWIPE_SWITCH_TABS = androidx.datastore.preferences.core.booleanPreferencesKey("swipe_switch_tabs")
/** Text contrast multiplier 1.0 = default, up to 2.0 = max boost. Drives WebView CSS variables. */
private val KEY_TEXT_CONTRAST = androidx.datastore.preferences.core.floatPreferencesKey("text_contrast")

// v4.9.0 — Semantic search controls.
/** Master switch for the semantic ranking layer. Defaults to ON. */
private val KEY_SEMANTIC_ENABLED = androidx.datastore.preferences.core.booleanPreferencesKey("semantic_enabled")
/** Whether to automatically check for newer embedding models on app launch. */
private val KEY_AUTO_CHECK_MODEL_UPDATES = androidx.datastore.preferences.core.booleanPreferencesKey("auto_check_model_updates")
/** Which model id from [ModelCatalog] the user has selected as active. */
private val KEY_ACTIVE_MODEL_ID = stringPreferencesKey("active_model_id")

class Prefs(private val context: Context) {

    val libraryUri: Flow<String?> = context.dataStore.data.map { it[KEY_LIBRARY_URI] }
    val fontScale: Flow<Float> = context.dataStore.data.map { it[KEY_FONT_SCALE] ?: 1.0f }
    val theme: Flow<String> = context.dataStore.data.map { it[KEY_THEME] ?: "dark" }
    val topicVersion: Flow<Int> = context.dataStore.data.map { it[KEY_TOPIC_VERSION] ?: 0 }
    val linksVersion: Flow<Int> = context.dataStore.data.map { it[KEY_LINKS_VERSION] ?: 0 }
    val recentSearchesRaw: Flow<String> = context.dataStore.data.map { it[KEY_RECENT_SEARCHES] ?: "" }
    /** Subfolder of the library where web-import .md files are written. */
    val importsSubfolder: Flow<String> = context.dataStore.data.map {
        it[KEY_IMPORTS_SUBFOLDER] ?: ""
    }

    // Include toggles for web imports — match the markdownr "Include X" UX.
    val includeFrontmatter: Flow<Boolean> = context.dataStore.data.map { it[KEY_INCLUDE_FRONTMATTER] ?: true }
    val includeUrl: Flow<Boolean>         = context.dataStore.data.map { it[KEY_INCLUDE_URL] ?: true }
    val includeExcerpt: Flow<Boolean>     = context.dataStore.data.map { it[KEY_INCLUDE_EXCERPT] ?: true }
    val includeBody: Flow<Boolean>        = context.dataStore.data.map { it[KEY_INCLUDE_BODY] ?: true }

    // ── v4.20.0 — On-device chat preference Flows ──────────────────────────
    /** "opt_in" (default — user taps Install button) or "auto_prompt"
     *  (chat screen prompts user on first open). */
    val chatInstallFlow: Flow<String> = context.dataStore.data.map {
        it[KEY_CHAT_INSTALL_FLOW] ?: "opt_in"
    }
    /** "own_screen" (default — dedicated screen via overflow menu) or
     *  "in_search" (toggle inside the existing Search screen). */
    val chatLocation: Flow<String> = context.dataStore.data.map {
        it[KEY_CHAT_LOCATION] ?: "own_screen"
    }
    /** "fresh_per_q" (default — each question is independent) or
     *  "multi_turn" (conversation history kept within session). */
    val chatHistoryMode: Flow<String> = context.dataStore.data.map {
        it[KEY_CHAT_HISTORY_MODE] ?: "fresh_per_q"
    }
    /** Currently selected chat model id from [ChatModelCatalog]. */
    val chatActiveModelId: Flow<String> = context.dataStore.data.map {
        it[KEY_CHAT_ACTIVE_MODEL_ID] ?: "qwen3-0_6b-mixed-int4"
    }
    /**
     * When the LLM gets loaded into RAM:
     *   "on_open"     → when chat screen opens (default)
     *   "preload"     → at app start, kept loaded
     *   "on_first_q"  → first time you send a message
     */
    val chatModelLoadMode: Flow<String> = context.dataStore.data.map {
        it[KEY_CHAT_MODEL_LOAD_MODE] ?: "on_open"
    }
    /** When ON, search reranking pass runs after semantic retrieval. */
    val rerankEnabled: Flow<Boolean> = context.dataStore.data.map {
        it[KEY_RERANK_ENABLED] ?: false
    }

    /**
     * When ON, smart styling runs on documents of every size — including the
     * 60k+ char ones it skips by default. Heavy DOM = potentially laggy scroll
     * on lower-end devices, but full visual richness on higher-end devices.
     */
    val smartStylingAllDocs: Flow<Boolean> = context.dataStore.data.map { it[KEY_SMART_STYLING_ALL_DOCS] ?: false }

    /**
     * When ON, restores horizontal swipe-to-switch-tabs in the markdown reader.
     * Adds touch-event interception that can mildly impact scrolling perf on
     * lower-end devices, hence the default-OFF.
     */
    val swipeSwitchTabs: Flow<Boolean> = context.dataStore.data.map { it[KEY_SWIPE_SWITCH_TABS] ?: false }

    /** Text contrast boost. 1.0 = default; values > 1 brighten foreground / darken background. */
    val textContrast: Flow<Float> = context.dataStore.data.map { it[KEY_TEXT_CONTRAST] ?: 1.0f }

    // v4.9.0 — Semantic search prefs.
    /** Master semantic search switch. Default ON — once a user has embeddings, they want them used. */
    val semanticEnabled: Flow<Boolean> = context.dataStore.data.map { it[KEY_SEMANTIC_ENABLED] ?: true }
    /** Whether to automatically check for model updates on each launch. */
    val autoCheckModelUpdates: Flow<Boolean> = context.dataStore.data.map { it[KEY_AUTO_CHECK_MODEL_UPDATES] ?: false }
    /** Which model id from the catalog is currently active. Default matches the v4.8 hard-coded model. */
    val activeModelId: Flow<String> = context.dataStore.data.map { it[KEY_ACTIVE_MODEL_ID] ?: "mediapipe-use-lite-v1" }

    suspend fun setRecentSearchesRaw(value: String) {
        context.dataStore.edit { it[KEY_RECENT_SEARCHES] = value }
    }

    suspend fun setTopicVersion(v: Int) {
        context.dataStore.edit { it[KEY_TOPIC_VERSION] = v }
    }

    suspend fun setLinksVersion(v: Int) {
        context.dataStore.edit { it[KEY_LINKS_VERSION] = v }
    }

    suspend fun setLibraryUri(uri: String) {
        context.dataStore.edit { it[KEY_LIBRARY_URI] = uri }
    }

    suspend fun setFontScale(scale: Float) {
        context.dataStore.edit { it[KEY_FONT_SCALE] = scale }
    }

    suspend fun setTheme(name: String) {
        context.dataStore.edit { it[KEY_THEME] = name }
    }

    suspend fun setImportsSubfolder(name: String) {
        context.dataStore.edit { it[KEY_IMPORTS_SUBFOLDER] = name }
    }

    suspend fun setIncludeFrontmatter(v: Boolean) { context.dataStore.edit { it[KEY_INCLUDE_FRONTMATTER] = v } }

    // ── v4.20.0 — On-device chat preference setters ────────────────────────
    suspend fun setChatInstallFlow(v: String) { context.dataStore.edit { it[KEY_CHAT_INSTALL_FLOW] = v } }
    suspend fun setChatLocation(v: String) { context.dataStore.edit { it[KEY_CHAT_LOCATION] = v } }
    suspend fun setChatHistoryMode(v: String) { context.dataStore.edit { it[KEY_CHAT_HISTORY_MODE] = v } }
    suspend fun setChatActiveModelId(v: String) { context.dataStore.edit { it[KEY_CHAT_ACTIVE_MODEL_ID] = v } }
    suspend fun setChatModelLoadMode(v: String) { context.dataStore.edit { it[KEY_CHAT_MODEL_LOAD_MODE] = v } }
    suspend fun setRerankEnabled(v: Boolean) { context.dataStore.edit { it[KEY_RERANK_ENABLED] = v } }

    /** v5.2.0 — How many recent search queries to surface on the home screen. */
    val maxRecentSearchesOnHome: Flow<Int> = context.dataStore.data.map {
        it[KEY_MAX_RECENT_SEARCHES_ON_HOME] ?: 7
    }
    suspend fun setMaxRecentSearchesOnHome(v: Int) {
        context.dataStore.edit { it[KEY_MAX_RECENT_SEARCHES_ON_HOME] = v.coerceIn(0, 20) }
    }

    /** v5.3.0 — "vertical" (default, scroll up/down) or "horizontal" (swipe side-to-side). */
    val tabsPreviewOrientation: Flow<String> = context.dataStore.data.map {
        it[KEY_TABS_PREVIEW_ORIENTATION] ?: "vertical"
    }
    suspend fun setTabsPreviewOrientation(v: String) {
        context.dataStore.edit { it[KEY_TABS_PREVIEW_ORIENTATION] = v }
    }

    /** v5.3.1 — When true (default), search results in CONTENT mode must
     *  contain at least 2 of the user's meaningful query words. When
     *  false, every keyword + semantic hit is shown. Turning this off
     *  surfaces more semantic-only matches at the cost of more noise. */
    val keywordFilterEnabled: Flow<Boolean> = context.dataStore.data.map {
        it[KEY_KEYWORD_FILTER_ENABLED] ?: true
    }
    suspend fun setKeywordFilterEnabled(v: Boolean) {
        context.dataStore.edit { it[KEY_KEYWORD_FILTER_ENABLED] = v }
    }
    suspend fun setIncludeUrl(v: Boolean)         { context.dataStore.edit { it[KEY_INCLUDE_URL] = v } }
    suspend fun setIncludeExcerpt(v: Boolean)     { context.dataStore.edit { it[KEY_INCLUDE_EXCERPT] = v } }
    suspend fun setIncludeBody(v: Boolean)        { context.dataStore.edit { it[KEY_INCLUDE_BODY] = v } }

    suspend fun setSmartStylingAllDocs(v: Boolean) {
        context.dataStore.edit { it[KEY_SMART_STYLING_ALL_DOCS] = v }
    }
    suspend fun setSwipeSwitchTabs(v: Boolean) {
        context.dataStore.edit { it[KEY_SWIPE_SWITCH_TABS] = v }
    }
    suspend fun setTextContrast(v: Float) {
        context.dataStore.edit { it[KEY_TEXT_CONTRAST] = v.coerceIn(1.0f, 2.0f) }
    }

    // v4.9.0 — Semantic search setters.
    suspend fun setSemanticEnabled(v: Boolean) {
        context.dataStore.edit { it[KEY_SEMANTIC_ENABLED] = v }
    }
    suspend fun setAutoCheckModelUpdates(v: Boolean) {
        context.dataStore.edit { it[KEY_AUTO_CHECK_MODEL_UPDATES] = v }
    }
    suspend fun setActiveModelId(v: String) {
        context.dataStore.edit { it[KEY_ACTIVE_MODEL_ID] = v }
    }
}
