package com.tebogo.markvault.service

import java.io.File
import java.io.FileOutputStream
import java.util.Properties

/** Local-only outcome journal. No replay scheduling or periodic disk writes. */
internal object BackupJobJournal {
    data class Record(val id: String, val kind: String, val status: String, val message: String)
    fun read(file: File): Record? = runCatching {
        val p = Properties().apply { file.inputStream().use { load(it) } }
        Record(p.getProperty("id"), p.getProperty("kind"), p.getProperty("status"), p.getProperty("message"))
    }.getOrNull()
    fun write(file: File, record: Record) {
        file.parentFile?.mkdirs()
        val tmp = File(file.parentFile, file.name + ".tmp")
        val p = Properties().apply {
            setProperty("id", record.id); setProperty("kind", record.kind)
            setProperty("status", record.status); setProperty("message", record.message)
        }
        FileOutputStream(tmp).use { p.store(it, null); it.fd.sync() }
        require(tmp.renameTo(file)) { "Could not publish backup/restore job status" }
    }
    fun interruptedMessage(kind: String): String = if (kind == "BACKUP")
        "Previous backup was interrupted. No job restarted automatically. An unverified ZIP is not a backup; create a new ZIP." else
        "Previous restore was interrupted. Select the same ZIP and destination to reuse verified files and committed data. No job restarted automatically."
}
