package com.tebogo.markvault.markdown

object MarkdownPreprocessors {

    fun apply(source: String): String {
        var text = source
        if (AdvancedMarkdownFeatures.enableYamlFrontMatter) {
            text = stripYamlFrontMatter(text)
        }
        if (AdvancedMarkdownFeatures.enableCallouts) {
            text = convertCallouts(text)
        }
        if (AdvancedMarkdownFeatures.enableMermaid) {
            text = convertMermaid(text)
        }
        if (AdvancedMarkdownFeatures.enableScriptureDetection) {
            text = detectScriptures(text)
        }
        return text
    }

    private fun stripYamlFrontMatter(s: String): String {
        return if (s.startsWith("---")) {
            val end = s.indexOf("\n---", 3)
            if (end >= 0) s.substring(end + 4) else s
        } else s
    }

    private fun convertCallouts(s: String): String {
        val regex = Regex("""(?m)^> \[!(\w+)\]\s*\n((?:^>.*(?:\n|$))+)"")
        return s.replace(regex) { m ->
            val type = m.groupValues[1].lowercase()
            val body = m.groupValues[2]
                .lines()
                .joinToString("\n") { it.removePrefix(">").trimStart() }
            "<div class=\"mv-callout mv-$type\">\n<strong>${type.uppercase()}</strong>\n<p>$body</p>\n</div>"
        }
    }

    private fun convertMermaid(s: String): String {
        val regex = Regex("""```mermaid\s*\n([\s\S]*?)```""")
        return s.replace(regex) {
            "<pre class=\"mermaid\">${it.groupValues[1]}</pre>"
        }
    }

    private fun detectScriptures(s: String): String {
        // Visual marker only. Existing JW links remain untouched.
        return s.replace(
            Regex("""(?<![\w/])(Genesis|Exodus|Matthew|Mark|Luke|John|Acts|Romans|1 Corinthians|2 Corinthians|Galatians|Ephesians|Philippians|Colossians|1 Thessalonians|2 Thessalonians|1 Timothy|2 Timothy|Titus|Hebrews|James|1 Peter|2 Peter|1 John|2 John|3 John|Revelation) (\d+:\d+(?:-\d+)?)"""),
            "📖 $1 $2"
        )
    }
}
