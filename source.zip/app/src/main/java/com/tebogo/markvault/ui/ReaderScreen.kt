package com.tebogo.markvault.ui

import android.annotation.SuppressLint
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.webkit.WebResourceRequest
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.Toast
import androidx.activity.compose.BackHandler
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.KeyboardArrowDown
import androidx.compose.material.icons.filled.KeyboardArrowUp
import androidx.compose.material.icons.filled.MoreVert
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TextField
import androidx.compose.material3.TextFieldDefaults
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.toArgb
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.navigation.NavController
import com.tebogo.markvault.AppViewModel
import com.tebogo.markvault.OutlineItem
import com.tebogo.markvault.data.Note
import org.json.JSONObject

@OptIn(ExperimentalMaterial3Api::class)
@SuppressLint("SetJavaScriptEnabled")
@Composable
fun ReaderScreen(vm: AppViewModel, nav: NavController) {
    val tabs by vm.tabs.collectAsStateWithLifecycle()
    val activeTab by vm.activeTab.collectAsStateWithLifecycle()
    val fontScale by vm.fontScale.collectAsStateWithLifecycle()
    val theme by vm.theme.collectAsStateWithLifecycle()
    val favouriteIds by vm.favouriteIds.collectAsStateWithLifecycle()
    val ctx = LocalContext.current
    val clipboard = LocalClipboardManager.current

    LaunchedEffect(tabs.isEmpty()) { if (tabs.isEmpty()) nav.popBackStack() }

    var note by remember { mutableStateOf<Note?>(null) }
    /** The phrase to flash-highlight in this article (captured once when the tab opens). */
    var highlightTerm by remember { mutableStateOf<String?>(null) }
    LaunchedEffect(activeTab) {
        val id = activeTab
        note = if (id != null) vm.loadNote(id) else null
        // Capture the pending highlight exactly once per article open
        highlightTerm = vm.consumePendingHighlight()?.takeIf { it.isNotBlank() }
    }

    var webView by remember { mutableStateOf<WebView?>(null) }
    var pageReady by remember { mutableStateOf(false) }
    val scrollMap = remember { HashMap<Long, Int>() }
    val latestScroll = remember { mutableStateOf(0) }

    var showFind by remember { mutableStateOf(false) }
    var findQuery by remember { mutableStateOf("") }
    var matchCount by remember { mutableStateOf(0) }
    var activeMatch by remember { mutableStateOf(0) }
    val findFocus = remember { FocusRequester() }

    var menuOpen by remember { mutableStateOf(false) }
    var themeMenuOpen by remember { mutableStateOf(false) }
    var showOutline by remember { mutableStateOf(false) }

    val bg = MaterialTheme.colorScheme.background.toArgb()
    val outline = remember(note?.id) { note?.let { AppViewModel.parseOutline(it.content) } ?: emptyList() }

    fun jsString(s: String) = JSONObject.quote(s)

    LaunchedEffect(pageReady, note?.id) {
        val wv = webView ?: return@LaunchedEffect
        val n = note ?: return@LaunchedEffect
        if (!pageReady) return@LaunchedEffect
        val y = scrollMap[n.id] ?: n.lastScroll
        latestScroll.value = y
        val term = highlightTerm
        if (!term.isNullOrBlank()) {
            // Render → highlight + scroll to match (no scroll restore)
            wv.evaluateJavascript(
                "renderMarkdown(${jsString(n.content)}, $fontScale, ${jsString(theme)}); highlightTerm(${jsString(term)});",
                null
            )
            // Consume so theme/font changes don't re-flash later
            highlightTerm = null
        } else {
            wv.evaluateJavascript(
                "renderMarkdown(${jsString(n.content)}, $fontScale, ${jsString(theme)}); restoreScroll($y);",
                null
            )
        }
    }
    DisposableEffect(Unit) {
        onDispose {
            val id = activeTab
            if (id != null) vm.saveScroll(id, latestScroll.value)
        }
    }
    LaunchedEffect(fontScale, pageReady) {
        if (pageReady) webView?.evaluateJavascript("setFontScale($fontScale);", null)
    }
    LaunchedEffect(theme, pageReady) {
        if (pageReady) webView?.evaluateJavascript("setTheme(${jsString(theme)});", null)
    }

    BackHandler(enabled = showFind) { showFind = false; webView?.clearMatches() }

    fun switchTab(newId: Long) {
        val old = activeTab
        if (old != null && old != newId) {
            val y = latestScroll.value
            scrollMap[old] = y
            vm.saveScroll(old, y)
        }
        vm.setActiveTab(newId)
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text(note?.title ?: "\u2026", maxLines = 1, overflow = TextOverflow.Ellipsis) },
                navigationIcon = {
                    IconButton(onClick = { nav.popBackStack() }) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back")
                    }
                },
                actions = {
                    TextButton(onClick = { vm.setFontScale((fontScale - 0.1f).coerceIn(0.7f, 2.2f)) }) { Text("A\u2212") }
                    TextButton(onClick = { vm.setFontScale((fontScale + 0.1f).coerceIn(0.7f, 2.2f)) }) { Text("A+") }
                    IconButton(onClick = { showFind = !showFind; if (!showFind) webView?.clearMatches() }) {
                        Icon(Icons.Default.Search, contentDescription = "Find in note")
                    }
                    Box {
                        IconButton(onClick = { menuOpen = true }) {
                            Icon(Icons.Default.MoreVert, contentDescription = "More")
                        }
                        DropdownMenu(expanded = menuOpen, onDismissRequest = { menuOpen = false }) {
                            DropdownMenuItem(
                                text = { Text("\uD83E\uDDED Outline") },
                                onClick = { menuOpen = false; showOutline = true }
                            )
                            DropdownMenuItem(
                                text = { Text("\uD83C\uDFA8 Theme\u2026") },
                                onClick = { menuOpen = false; themeMenuOpen = true }
                            )
                            DropdownMenuItem(
                                text = { Text("\u2B06\uFE0F Collapse all boxes") },
                                onClick = { menuOpen = false; webView?.evaluateJavascript("collapseAllCallouts();", null) }
                            )
                            DropdownMenuItem(
                                text = { Text("\u2B07\uFE0F Expand all boxes") },
                                onClick = { menuOpen = false; webView?.evaluateJavascript("expandAllCallouts();", null) }
                            )
                            HorizontalDivider()
                            val isFav = note?.id?.let { it in favouriteIds } ?: false
                            DropdownMenuItem(
                                text = { Text(if (isFav) "\uD83D\uDC94 Remove from favourites" else "\u2B50 Add to favourites") },
                                onClick = {
                                    menuOpen = false
                                    note?.id?.let { vm.toggleFavourite(it) }
                                }
                            )
                            DropdownMenuItem(
                                text = { Text("\uD83D\uDCCB Copy text") },
                                onClick = {
                                    menuOpen = false
                                    note?.content?.let {
                                        clipboard.setText(AnnotatedString(it))
                                        Toast.makeText(ctx, "Copied", Toast.LENGTH_SHORT).show()
                                    }
                                }
                            )
                            DropdownMenuItem(
                                text = { Text("\uD83D\uDD17 Share") },
                                onClick = {
                                    menuOpen = false
                                    note?.let {
                                        val send = Intent(Intent.ACTION_SEND).apply {
                                            type = "text/plain"
                                            putExtra(Intent.EXTRA_SUBJECT, it.title)
                                            putExtra(Intent.EXTRA_TEXT, it.content)
                                        }
                                        ctx.startActivity(Intent.createChooser(send, "Share note"))
                                    }
                                }
                            )
                        }
                        DropdownMenu(expanded = themeMenuOpen, onDismissRequest = { themeMenuOpen = false }) {
                            listOf(
                                "dark" to "\uD83C\uDF11 Dark",
                                "black" to "\u26AB AMOLED black",
                                "sepia" to "\uD83D\uDCDC Sepia",
                                "light" to "\u2600\uFE0F Light"
                            ).forEach { pair ->
                                DropdownMenuItem(
                                    text = { Text(pair.second + if (theme == pair.first) "  \u2713" else "") },
                                    onClick = { themeMenuOpen = false; vm.setTheme(pair.first) }
                                )
                            }
                        }
                    }
                }
            )
        }
    ) { pad ->
        Column(Modifier.padding(pad).fillMaxSize()) {

            if (tabs.size > 1) {
                LazyRow(
                    Modifier.fillMaxWidth().padding(vertical = 4.dp),
                    horizontalArrangement = Arrangement.spacedBy(6.dp),
                    contentPadding = PaddingValues(horizontal = 8.dp)
                ) {
                    items(tabs, key = { it.id }) { tab ->
                        val selected = tab.id == activeTab
                        Surface(
                            color = if (selected) MaterialTheme.colorScheme.primary.copy(alpha = 0.22f)
                            else MaterialTheme.colorScheme.surfaceVariant,
                            shape = RoundedCornerShape(8.dp),
                            modifier = Modifier.clickable { switchTab(tab.id) }
                        ) {
                            Row(
                                Modifier.padding(start = 12.dp, end = 4.dp, top = 6.dp, bottom = 6.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text(
                                    tab.title,
                                    modifier = Modifier.widthIn(max = 150.dp),
                                    maxLines = 1, overflow = TextOverflow.Ellipsis,
                                    fontSize = 13.sp,
                                    fontWeight = if (selected) FontWeight.SemiBold else FontWeight.Normal,
                                    color = if (selected) MaterialTheme.colorScheme.onSurface
                                    else MaterialTheme.colorScheme.onSurfaceVariant
                                )
                                IconButton(onClick = { vm.closeTab(tab.id) }, modifier = Modifier.size(28.dp)) {
                                    Icon(
                                        Icons.Default.Close, contentDescription = "Close tab",
                                        modifier = Modifier.size(15.dp),
                                        tint = MaterialTheme.colorScheme.onSurfaceVariant
                                    )
                                }
                            }
                        }
                    }
                }
                HorizontalDivider(color = MaterialTheme.colorScheme.surfaceVariant)
            }

            if (showFind) {
                Surface(color = MaterialTheme.colorScheme.surfaceVariant) {
                    Row(
                        Modifier.fillMaxWidth().padding(horizontal = 8.dp, vertical = 4.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        TextField(
                            value = findQuery,
                            onValueChange = {
                                findQuery = it
                                val wv = webView
                                if (wv != null) {
                                    if (it.isBlank()) { wv.clearMatches(); matchCount = 0 }
                                    else wv.findAllAsync(it)
                                }
                            },
                            modifier = Modifier.weight(1f).focusRequester(findFocus),
                            singleLine = true,
                            placeholder = { Text("Find in this note\u2026") },
                            colors = TextFieldDefaults.colors(
                                focusedContainerColor = Color.Transparent,
                                unfocusedContainerColor = Color.Transparent
                            )
                        )
                        Text(
                            if (matchCount > 0) "${activeMatch + 1}/$matchCount" else "0/0",
                            fontSize = 12.sp,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                            modifier = Modifier.padding(horizontal = 6.dp)
                        )
                        IconButton(onClick = { webView?.findNext(false) }) {
                            Icon(Icons.Default.KeyboardArrowUp, contentDescription = "Previous")
                        }
                        IconButton(onClick = { webView?.findNext(true) }) {
                            Icon(Icons.Default.KeyboardArrowDown, contentDescription = "Next")
                        }
                        IconButton(onClick = {
                            showFind = false; findQuery = ""; webView?.clearMatches(); matchCount = 0
                        }) {
                            Icon(Icons.Default.Close, contentDescription = "Close find")
                        }
                    }
                }
                LaunchedEffect(Unit) { findFocus.requestFocus() }
            }

            Box(Modifier.fillMaxSize()) {
                AndroidView(
                    modifier = Modifier.fillMaxSize(),
                    factory = { c ->
                        WebView(c).apply {
                            setBackgroundColor(bg)
                            settings.javaScriptEnabled = true
                            settings.allowFileAccess = true
                            settings.domStorageEnabled = true
                            settings.loadsImagesAutomatically = true
                            settings.mixedContentMode = WebSettings.MIXED_CONTENT_COMPATIBILITY_MODE
                            setFindListener { active, count, _ -> matchCount = count; activeMatch = active }
                            setOnScrollChangeListener { _, _, scrollY, _, _ ->
                                latestScroll.value = scrollY
                                val id = activeTab
                                if (id != null) scrollMap[id] = scrollY
                            }
                            webViewClient = object : WebViewClient() {
                                override fun onPageFinished(view: WebView?, url: String?) { pageReady = true }
                                override fun shouldOverrideUrlLoading(
                                    view: WebView?, request: WebResourceRequest?
                                ): Boolean {
                                    val uri = request?.url ?: return false
                                    if (uri.scheme == "file") return false
                                    openExternally(ctx, uri)
                                    return true
                                }
                            }
                            loadUrl("file:///android_asset/viewer.html")
                            webView = this
                        }
                    }
                )
            }
        }
    }

    if (showOutline) {
        ModalBottomSheet(onDismissRequest = { showOutline = false }) {
            Text(
                "\uD83E\uDDED Outline",
                Modifier.padding(start = 20.dp, top = 4.dp, bottom = 8.dp),
                fontWeight = FontWeight.Bold, fontSize = 16.sp
            )
            if (outline.isEmpty()) {
                Text(
                    "No headings in this note.",
                    Modifier.padding(20.dp),
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            } else {
                LazyColumn(Modifier.fillMaxWidth().heightIn(max = 460.dp)) {
                    items(outline) { item: OutlineItem ->
                        Text(
                            item.title,
                            Modifier
                                .fillMaxWidth()
                                .clickable {
                                    webView?.evaluateJavascript(
                                        "document.getElementById('sec-${item.index}')?." +
                                            "scrollIntoView({behavior:'smooth',block:'start'});",
                                        null
                                    )
                                    showOutline = false
                                }
                                .padding(
                                    start = (16 + (item.level - 1) * 14).dp,
                                    end = 16.dp, top = 11.dp, bottom = 11.dp
                                ),
                            fontSize = if (item.level <= 2) 15.sp else 13.sp,
                            fontWeight = if (item.level <= 2) FontWeight.SemiBold else FontWeight.Normal,
                            color = if (item.level <= 2) MaterialTheme.colorScheme.onSurface
                            else MaterialTheme.colorScheme.onSurfaceVariant,
                            maxLines = 2, overflow = TextOverflow.Ellipsis
                        )
                    }
                    item { Spacer(Modifier.height(24.dp)) }
                }
            }
        }
    }
}

private fun openExternally(ctx: Context, uri: Uri) {
    try {
        ctx.startActivity(Intent(Intent.ACTION_VIEW, uri).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
    } catch (e: Exception) {
        Toast.makeText(ctx, "No app can open this link", Toast.LENGTH_SHORT).show()
    }
}
