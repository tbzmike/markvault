package com.tebogo.markvault.ui

import android.annotation.SuppressLint
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.webkit.WebResourceRequest
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.Toast
import androidx.activity.compose.BackHandler
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.KeyboardArrowDown
import androidx.compose.material.icons.filled.KeyboardArrowUp
import androidx.compose.material.icons.filled.Menu
import androidx.compose.material.icons.filled.MoreVert
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TextField
import androidx.compose.material3.TextFieldDefaults
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.toArgb
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.navigation.NavController
import com.tebogo.markvault.AppViewModel
import com.tebogo.markvault.OutlineItem
import com.tebogo.markvault.data.Note
import org.json.JSONObject

@OptIn(ExperimentalMaterial3Api::class)
@SuppressLint("SetJavaScriptEnabled")
@Composable
fun ReaderScreen(vm: AppViewModel, nav: NavController) {
    val tabs by vm.tabs.collectAsStateWithLifecycle()
    val activeTab by vm.activeTab.collectAsStateWithLifecycle()
    val fontScale by vm.fontScale.collectAsStateWithLifecycle()
    val theme by vm.theme.collectAsStateWithLifecycle()
    val favouriteIds by vm.favouriteIds.collectAsStateWithLifecycle()
    val tabHistory by vm.tabHistory.collectAsStateWithLifecycle()
    val ctx = LocalContext.current
    val clipboard = LocalClipboardManager.current

    LaunchedEffect(tabs.isEmpty()) { if (tabs.isEmpty()) nav.popBackStack() }
    // When the Reader leaves the composition entirely, reset the tab visit history so a future
    // re-entry doesn't try to back-navigate into a stale chain.
    DisposableEffect(Unit) {
        onDispose { vm.clearTabHistory() }
    }

    var note by remember { mutableStateOf<Note?>(null) }
    /** The phrase to flash-highlight in this article (captured once when the tab opens). */
    var highlightTerm by remember { mutableStateOf<String?>(null) }
    /** Total wikilink connections (forward + backlinks) for the active article — drives the header chip. */
    var connCount by remember { mutableStateOf(-1) } // -1 = unknown / loading
    LaunchedEffect(activeTab) {
        val id = activeTab
        note = if (id != null) vm.loadNote(id) else null
        // Capture the pending highlight exactly once per article open
        highlightTerm = vm.consumePendingHighlight()?.takeIf { it.isNotBlank() }
        // Refresh the connection count for this tab
        connCount = if (id != null) vm.connectionCount(id) else -1
    }

    var webView by remember { mutableStateOf<WebView?>(null) }
    var pageReady by remember { mutableStateOf(false) }
    val scrollMap = remember { HashMap<Long, Int>() }
    val latestScroll = remember { mutableStateOf(0) }

    var showFind by remember { mutableStateOf(false) }
    var findQuery by remember { mutableStateOf("") }
    var matchCount by remember { mutableStateOf(0) }
    var activeMatch by remember { mutableStateOf(0) }
    val findFocus = remember { FocusRequester() }

    var menuOpen by remember { mutableStateOf(false) }
    var themeMenuOpen by remember { mutableStateOf(false) }
    var showOutline by remember { mutableStateOf(false) }
    var showBacklinks by remember { mutableStateOf(false) }
    var wikilinkTap by remember { mutableStateOf<String?>(null) }
    var backlinks by remember { mutableStateOf<List<com.tebogo.markvault.data.LinkedNote>>(emptyList()) }
    var forwardlinks by remember { mutableStateOf<List<com.tebogo.markvault.data.LinkedNote>>(emptyList()) }
    /** Long-pressed link inside the article — drives the copy/share bottom-sheet menu. */
    var linkLongPress by remember { mutableStateOf<LinkPressData?>(null) }
    /** Bottom sheet showing all open tabs as a scrollable grid. */
    var showTabGrid by remember { mutableStateOf(false) }
    /** Bottom sheet for Print / PDF export with paper size, orientation, theme, margin. */
    var showPrintSheet by remember { mutableStateOf(false) }
    /** Keeps the transient print WebView from being GC'd before PrintManager finishes. */
    val printPinHolder = remember { PinHolder() }

    val bg = MaterialTheme.colorScheme.background.toArgb()
    val outline = remember(note?.id) { note?.let { AppViewModel.parseOutline(it.content) } ?: emptyList() }

    fun jsString(s: String) = JSONObject.quote(s)

    LaunchedEffect(pageReady, note?.id) {
        val wv = webView ?: return@LaunchedEffect
        val n = note ?: return@LaunchedEffect
        if (!pageReady) return@LaunchedEffect
        val y = scrollMap[n.id] ?: n.lastScroll
        latestScroll.value = y
        val term = highlightTerm
        if (!term.isNullOrBlank()) {
            // Render → highlight + scroll to match (no scroll restore)
            wv.evaluateJavascript(
                "renderMarkdown(${jsString(n.content)}, $fontScale, ${jsString(theme)}); highlightTerm(${jsString(term)});",
                null
            )
            // Consume so theme/font changes don't re-flash later
            highlightTerm = null
        } else {
            wv.evaluateJavascript(
                "renderMarkdown(${jsString(n.content)}, $fontScale, ${jsString(theme)}); restoreScroll($y);",
                null
            )
        }
    }
    DisposableEffect(Unit) {
        onDispose {
            val id = activeTab
            if (id != null) vm.saveScroll(id, latestScroll.value)
        }
    }
    LaunchedEffect(fontScale, pageReady) {
        if (pageReady) webView?.evaluateJavascript("setFontScale($fontScale);", null)
    }
    LaunchedEffect(theme, pageReady) {
        if (pageReady) webView?.evaluateJavascript("setTheme(${jsString(theme)});", null)
    }

    // Resolve wikilink taps from the WebView and open the target in a new tab
    LaunchedEffect(wikilinkTap) {
        val target = wikilinkTap ?: return@LaunchedEffect
        val decoded = runCatching { java.net.URLDecoder.decode(target, "UTF-8") }.getOrElse { target }
        val hit = vm.resolveWikilink(decoded)
        if (hit != null) {
            // Save current scroll so going back to this note resumes
            val cur = activeTab
            if (cur != null) {
                scrollMap[cur] = latestScroll.value
                vm.saveScroll(cur, latestScroll.value)
            }
            vm.openArticle(hit.id, hit.title, com.tebogo.markvault.OpenSource.LINK)
        } else {
            Toast.makeText(ctx, "No note matches \"$decoded\"", Toast.LENGTH_SHORT).show()
        }
        wikilinkTap = null
    }

    BackHandler(enabled = showFind) { showFind = false; webView?.clearMatches() }
    // System Back inside the Reader: walk the tab visit history first, then exit the Reader
    // (the default nav pop) only once there's no previous tab to return to.
    BackHandler(enabled = !showFind && tabHistory.size >= 2) {
        // Persist current tab's scroll so when we re-enter it later it lands in the right place
        val cur = activeTab
        if (cur != null) {
            scrollMap[cur] = latestScroll.value
            vm.saveScroll(cur, latestScroll.value)
        }
        vm.goBackInTabs()
    }

    fun switchTab(newId: Long) {
        val old = activeTab
        if (old != null && old != newId) {
            val y = latestScroll.value
            scrollMap[old] = y
            vm.saveScroll(old, y)
        }
        vm.setActiveTab(newId)
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text(note?.title ?: "\u2026", maxLines = 1, overflow = TextOverflow.Ellipsis) },
                navigationIcon = {
                    IconButton(onClick = {
                        // Same logic as system Back: previous tab first, then exit Reader
                        val cur = activeTab
                        if (cur != null) {
                            scrollMap[cur] = latestScroll.value
                            vm.saveScroll(cur, latestScroll.value)
                        }
                        if (!vm.goBackInTabs()) nav.popBackStack()
                    }) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back")
                    }
                },
                actions = {
                    // Connection chip — shows total wikilink connections, tap to open in graph
                    if (connCount >= 0) {
                        val chipColor =
                            if (connCount > 0) MaterialTheme.colorScheme.primary
                            else MaterialTheme.colorScheme.onSurfaceVariant
                        val chipBg =
                            if (connCount > 0) MaterialTheme.colorScheme.primary.copy(alpha = 0.18f)
                            else MaterialTheme.colorScheme.surfaceVariant
                        Surface(
                            color = chipBg,
                            shape = RoundedCornerShape(14.dp),
                            modifier = Modifier
                                .padding(end = 4.dp)
                                .clickable(enabled = note?.id != null) {
                                    // Save current scroll before leaving the Reader
                                    val cur = activeTab
                                    if (cur != null) {
                                        scrollMap[cur] = latestScroll.value
                                        vm.saveScroll(cur, latestScroll.value)
                                    }
                                    note?.id?.let { nav.navigate("graph/$it") }
                                }
                        ) {
                            Text(
                                "\uD83D\uDD17 $connCount",
                                modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp),
                                fontSize = 12.sp,
                                fontWeight = FontWeight.Medium,
                                color = chipColor
                            )
                        }
                    }
                    TextButton(onClick = { vm.setFontScale((fontScale - 0.1f).coerceIn(0.7f, 2.2f)) }) { Text("A\u2212") }
                    TextButton(onClick = { vm.setFontScale((fontScale + 0.1f).coerceIn(0.7f, 2.2f)) }) { Text("A+") }
                    // Tab grid — shows when you have multiple tabs, lets you pick or close any of them
                    if (tabs.size > 1) {
                        IconButton(onClick = { showTabGrid = true }) {
                            Icon(
                                Icons.Default.Menu,
                                contentDescription = "All tabs (${tabs.size})"
                            )
                        }
                    }
                    IconButton(onClick = { showFind = !showFind; if (!showFind) webView?.clearMatches() }) {
                        Icon(Icons.Default.Search, contentDescription = "Find in note")
                    }
                    Box {
                        IconButton(onClick = { menuOpen = true }) {
                            Icon(Icons.Default.MoreVert, contentDescription = "More")
                        }
                        DropdownMenu(expanded = menuOpen, onDismissRequest = { menuOpen = false }) {
                            DropdownMenuItem(
                                text = { Text("\uD83E\uDDED Outline") },
                                onClick = { menuOpen = false; showOutline = true }
                            )
                            DropdownMenuItem(
                                text = { Text("\uD83D\uDD17 Links & backlinks") },
                                onClick = { menuOpen = false; showBacklinks = true }
                            )
                            DropdownMenuItem(
                                text = { Text("\uD83C\uDF10 Graph from this note") },
                                onClick = {
                                    menuOpen = false
                                    // Save scroll before leaving the reader
                                    val cur = activeTab
                                    if (cur != null) {
                                        scrollMap[cur] = latestScroll.value
                                        vm.saveScroll(cur, latestScroll.value)
                                    }
                                    note?.id?.let { nav.navigate("graph/$it") }
                                }
                            )
                            DropdownMenuItem(
                                text = { Text("\uD83C\uDFA8 Theme\u2026") },
                                onClick = { menuOpen = false; themeMenuOpen = true }
                            )
                            DropdownMenuItem(
                                text = { Text("\u2B06\uFE0F Collapse all boxes") },
                                onClick = { menuOpen = false; webView?.evaluateJavascript("collapseAllCallouts();", null) }
                            )
                            DropdownMenuItem(
                                text = { Text("\u2B07\uFE0F Expand all boxes") },
                                onClick = { menuOpen = false; webView?.evaluateJavascript("expandAllCallouts();", null) }
                            )
                            HorizontalDivider()
                            val isFav = note?.id?.let { it in favouriteIds } ?: false
                            DropdownMenuItem(
                                text = { Text(if (isFav) "\uD83D\uDC94 Remove from favourites" else "\u2B50 Add to favourites") },
                                onClick = {
                                    menuOpen = false
                                    note?.id?.let { vm.toggleFavourite(it) }
                                }
                            )
                            DropdownMenuItem(
                                text = { Text("\uD83D\uDCCB Copy text") },
                                onClick = {
                                    menuOpen = false
                                    note?.content?.let {
                                        clipboard.setText(AnnotatedString(it))
                                        Toast.makeText(ctx, "Copied", Toast.LENGTH_SHORT).show()
                                    }
                                }
                            )
                            DropdownMenuItem(
                                text = { Text("\uD83D\uDDA8\uFE0F Print / PDF\u2026") },
                                onClick = {
                                    menuOpen = false
                                    showPrintSheet = true
                                }
                            )
                            DropdownMenuItem(
                                text = { Text("\uD83D\uDD17 Share") },
                                onClick = {
                                    menuOpen = false
                                    note?.let {
                                        val send = Intent(Intent.ACTION_SEND).apply {
                                            type = "text/plain"
                                            putExtra(Intent.EXTRA_SUBJECT, it.title)
                                            putExtra(Intent.EXTRA_TEXT, it.content)
                                        }
                                        ctx.startActivity(Intent.createChooser(send, "Share note"))
                                    }
                                }
                            )
                        }
                        DropdownMenu(expanded = themeMenuOpen, onDismissRequest = { themeMenuOpen = false }) {
                            listOf(
                                "dark" to "\uD83C\uDF11 Dark",
                                "black" to "\u26AB AMOLED black",
                                "sepia" to "\uD83D\uDCDC Sepia",
                                "light" to "\u2600\uFE0F Light"
                            ).forEach { pair ->
                                DropdownMenuItem(
                                    text = { Text(pair.second + if (theme == pair.first) "  \u2713" else "") },
                                    onClick = { themeMenuOpen = false; vm.setTheme(pair.first) }
                                )
                            }
                        }
                    }
                }
            )
        }
    ) { pad ->
        Column(Modifier.padding(pad).fillMaxSize()) {

            if (tabs.size > 1) {
                LazyRow(
                    Modifier.fillMaxWidth().padding(vertical = 4.dp),
                    horizontalArrangement = Arrangement.spacedBy(6.dp),
                    contentPadding = PaddingValues(horizontal = 8.dp)
                ) {
                    items(tabs, key = { it.id }) { tab ->
                        val selected = tab.id == activeTab
                        Surface(
                            color = if (selected) MaterialTheme.colorScheme.primary.copy(alpha = 0.22f)
                            else MaterialTheme.colorScheme.surfaceVariant,
                            shape = RoundedCornerShape(8.dp),
                            modifier = Modifier.clickable { switchTab(tab.id) }
                        ) {
                            Row(
                                Modifier.padding(start = 12.dp, end = 4.dp, top = 6.dp, bottom = 6.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text(
                                    tab.title,
                                    modifier = Modifier.widthIn(max = 150.dp),
                                    maxLines = 1, overflow = TextOverflow.Ellipsis,
                                    fontSize = 13.sp,
                                    fontWeight = if (selected) FontWeight.SemiBold else FontWeight.Normal,
                                    color = if (selected) MaterialTheme.colorScheme.onSurface
                                    else MaterialTheme.colorScheme.onSurfaceVariant
                                )
                                IconButton(onClick = { vm.closeTab(tab.id) }, modifier = Modifier.size(28.dp)) {
                                    Icon(
                                        Icons.Default.Close, contentDescription = "Close tab",
                                        modifier = Modifier.size(15.dp),
                                        tint = MaterialTheme.colorScheme.onSurfaceVariant
                                    )
                                }
                            }
                        }
                    }
                }
                HorizontalDivider(color = MaterialTheme.colorScheme.surfaceVariant)
            }

            if (showFind) {
                Surface(color = MaterialTheme.colorScheme.surfaceVariant) {
                    Row(
                        Modifier.fillMaxWidth().padding(horizontal = 8.dp, vertical = 4.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        TextField(
                            value = findQuery,
                            onValueChange = {
                                findQuery = it
                                val wv = webView
                                if (wv != null) {
                                    if (it.isBlank()) { wv.clearMatches(); matchCount = 0 }
                                    else wv.findAllAsync(it)
                                }
                            },
                            modifier = Modifier.weight(1f).focusRequester(findFocus),
                            singleLine = true,
                            placeholder = { Text("Find in this note\u2026") },
                            colors = TextFieldDefaults.colors(
                                focusedContainerColor = Color.Transparent,
                                unfocusedContainerColor = Color.Transparent
                            )
                        )
                        Text(
                            if (matchCount > 0) "${activeMatch + 1}/$matchCount" else "0/0",
                            fontSize = 12.sp,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                            modifier = Modifier.padding(horizontal = 6.dp)
                        )
                        IconButton(onClick = { webView?.findNext(false) }) {
                            Icon(Icons.Default.KeyboardArrowUp, contentDescription = "Previous")
                        }
                        IconButton(onClick = { webView?.findNext(true) }) {
                            Icon(Icons.Default.KeyboardArrowDown, contentDescription = "Next")
                        }
                        IconButton(onClick = {
                            showFind = false; findQuery = ""; webView?.clearMatches(); matchCount = 0
                        }) {
                            Icon(Icons.Default.Close, contentDescription = "Close find")
                        }
                    }
                }
                LaunchedEffect(Unit) { findFocus.requestFocus() }
            }

            Box(Modifier.fillMaxSize()) {
                AndroidView(
                    modifier = Modifier.fillMaxSize(),
                    factory = { c ->
                        WebView(c).apply {
                            setBackgroundColor(bg)
                            settings.javaScriptEnabled = true
                            settings.allowFileAccess = true
                            settings.domStorageEnabled = true
                            settings.loadsImagesAutomatically = true
                            settings.mixedContentMode = WebSettings.MIXED_CONTENT_COMPATIBILITY_MODE
                            setFindListener { active, count, _ -> matchCount = count; activeMatch = active }
                            setOnScrollChangeListener { _, _, scrollY, _, _ ->
                                latestScroll.value = scrollY
                                val id = activeTab
                                if (id != null) scrollMap[id] = scrollY
                            }
                            // Long-press on an <a> → bottom-sheet with Copy URL / Copy text / Share / Open in browser.
                            // Long-press on plain text falls through to the system text-selection UI.
                            setOnLongClickListener { _ ->
                                val hit = hitTestResult
                                val type = hit.type
                                val anchor = type == WebView.HitTestResult.SRC_ANCHOR_TYPE ||
                                    type == WebView.HitTestResult.SRC_IMAGE_ANCHOR_TYPE
                                if (!anchor) return@setOnLongClickListener false
                                val url = hit.extra ?: return@setOnLongClickListener false
                                // Ignore internal wikilinks — they have their own tap behavior already
                                if (url.startsWith("mv://")) return@setOnLongClickListener true
                                // Look up the visible link text via a tiny JS query.
                                // (Escape the URL for safe embedding in the JS string literal.)
                                val esc = url
                                    .replace("\\", "\\\\")
                                    .replace("'", "\\'")
                                    .replace("\n", "\\n")
                                    .replace("\r", "\\r")
                                evaluateJavascript(
                                    "(function(){var as=document.querySelectorAll('a');" +
                                    "for(var i=0;i<as.length;i++){if(as[i].href==='$esc')" +
                                    "return as[i].textContent.replace(/\\s+/g,' ').trim();}return '';})();"
                                ) { result ->
                                    // result comes back as a JSON-encoded string ("..." or null)
                                    val text = if (result == null || result == "null") ""
                                        else result.trim().removeSurrounding("\"")
                                            .replace("\\\"", "\"").replace("\\\\", "\\")
                                    linkLongPress = LinkPressData(url, text)
                                }
                                true  // consume the long-press; suppresses default text-selection UI
                            }
                            webViewClient = object : WebViewClient() {
                                override fun onPageFinished(view: WebView?, url: String?) { pageReady = true }
                                override fun shouldOverrideUrlLoading(
                                    view: WebView?, request: WebResourceRequest?
                                ): Boolean {
                                    val uri = request?.url ?: return false
                                    if (uri.scheme == "file") return false
                                    // Intercept wikilink taps: mv://wiki/<URL-encoded target>
                                    if (uri.scheme == "mv" && uri.host == "wiki") {
                                        val target = uri.lastPathSegment ?: uri.schemeSpecificPart
                                            ?.removePrefix("//wiki/")
                                        if (!target.isNullOrBlank()) {
                                            wikilinkTap = target
                                        }
                                        return true
                                    }
                                    // External link routing
                                    when (routeLink(uri)) {
                                        LinkTarget.JW_LIBRARY_APP -> {
                                            openInJwLibrary(ctx, uri) {
                                                // No JW Library installed → fall back to in-app popup
                                                vm.requestWebPopup(uri.toString())
                                            }
                                        }
                                        LinkTarget.IN_APP_WEBVIEW -> {
                                            vm.requestWebPopup(uri.toString())
                                        }
                                        LinkTarget.SYSTEM_BROWSER -> {
                                            openExternally(ctx, uri)
                                        }
                                    }
                                    return true
                                }
                            }
                            loadUrl("file:///android_asset/viewer.html")
                            webView = this
                        }
                    }
                )
            }
        }
    }

    if (showOutline) {
        ModalBottomSheet(onDismissRequest = { showOutline = false }) {
            Text(
                "\uD83E\uDDED Outline",
                Modifier.padding(start = 20.dp, top = 4.dp, bottom = 8.dp),
                fontWeight = FontWeight.Bold, fontSize = 16.sp
            )
            if (outline.isEmpty()) {
                Text(
                    "No headings in this note.",
                    Modifier.padding(20.dp),
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            } else {
                LazyColumn(Modifier.fillMaxWidth().heightIn(max = 460.dp)) {
                    items(outline) { item: OutlineItem ->
                        Text(
                            item.title,
                            Modifier
                                .fillMaxWidth()
                                .clickable {
                                    webView?.evaluateJavascript(
                                        "document.getElementById('sec-${item.index}')?." +
                                            "scrollIntoView({behavior:'smooth',block:'start'});",
                                        null
                                    )
                                    showOutline = false
                                }
                                .padding(
                                    start = (16 + (item.level - 1) * 14).dp,
                                    end = 16.dp, top = 11.dp, bottom = 11.dp
                                ),
                            fontSize = if (item.level <= 2) 15.sp else 13.sp,
                            fontWeight = if (item.level <= 2) FontWeight.SemiBold else FontWeight.Normal,
                            color = if (item.level <= 2) MaterialTheme.colorScheme.onSurface
                            else MaterialTheme.colorScheme.onSurfaceVariant,
                            maxLines = 2, overflow = TextOverflow.Ellipsis
                        )
                    }
                    item { Spacer(Modifier.height(24.dp)) }
                }
            }
        }
    }

    if (showBacklinks) {
        // Load both lists when the sheet opens (re-runs if note changes while it's open)
        LaunchedEffect(showBacklinks, note?.id) {
            val id = note?.id
            if (id == null) {
                backlinks = emptyList()
                forwardlinks = emptyList()
            } else {
                forwardlinks = vm.loadForwardLinks(id)
                backlinks = vm.loadBacklinks(id)
            }
        }
        ModalBottomSheet(onDismissRequest = { showBacklinks = false }) {
            Row(
                Modifier.fillMaxWidth().padding(start = 20.dp, end = 12.dp, top = 4.dp, bottom = 6.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    "\uD83D\uDD17 Links",
                    Modifier.weight(1f),
                    fontWeight = FontWeight.Bold, fontSize = 16.sp
                )
                Surface(
                    color = MaterialTheme.colorScheme.primary.copy(alpha = 0.18f),
                    shape = RoundedCornerShape(14.dp),
                    modifier = Modifier.clickable(enabled = note?.id != null) {
                        showBacklinks = false
                        val cur = activeTab
                        if (cur != null) {
                            scrollMap[cur] = latestScroll.value
                            vm.saveScroll(cur, latestScroll.value)
                        }
                        note?.id?.let { nav.navigate("graph/$it") }
                    }
                ) {
                    Text(
                        "\uD83C\uDF33 View in graph",
                        modifier = Modifier.padding(horizontal = 12.dp, vertical = 7.dp),
                        fontSize = 12.sp, fontWeight = FontWeight.Medium,
                        color = MaterialTheme.colorScheme.primary
                    )
                }
            }
            LazyColumn(Modifier.fillMaxWidth().heightIn(max = 540.dp)) {
                item {
                    Text(
                        "\u2192 Links from this note (${forwardlinks.size})",
                        Modifier.padding(start = 20.dp, top = 6.dp, bottom = 4.dp),
                        fontSize = 13.sp, fontWeight = FontWeight.SemiBold,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
                if (forwardlinks.isEmpty()) {
                    item {
                        Text(
                            "No outgoing wikilinks in this note.",
                            Modifier.padding(horizontal = 20.dp, vertical = 6.dp),
                            fontSize = 13.sp,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                } else {
                    items(forwardlinks, key = { "fwd-" + it.id }) { ln ->
                        LinkRow(ln) {
                            // Save scroll on current article, then open the target
                            val cur = activeTab
                            if (cur != null) {
                                scrollMap[cur] = latestScroll.value
                                vm.saveScroll(cur, latestScroll.value)
                            }
                            vm.openArticle(ln.id, ln.title, com.tebogo.markvault.OpenSource.LINK)
                            showBacklinks = false
                        }
                    }
                }
                item { Spacer(Modifier.height(8.dp)) }
                item { HorizontalDivider(color = MaterialTheme.colorScheme.surfaceVariant) }
                item {
                    Text(
                        "\u2190 Backlinks: notes that link to this one (${backlinks.size})",
                        Modifier.padding(start = 20.dp, top = 12.dp, bottom = 4.dp),
                        fontSize = 13.sp, fontWeight = FontWeight.SemiBold,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
                if (backlinks.isEmpty()) {
                    item {
                        Text(
                            "No other notes link to this one yet.",
                            Modifier.padding(horizontal = 20.dp, vertical = 6.dp),
                            fontSize = 13.sp,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                } else {
                    items(backlinks, key = { "bk-" + it.id }) { ln ->
                        LinkRow(ln) {
                            val cur = activeTab
                            if (cur != null) {
                                scrollMap[cur] = latestScroll.value
                                vm.saveScroll(cur, latestScroll.value)
                            }
                            vm.openArticle(ln.id, ln.title, com.tebogo.markvault.OpenSource.BACKLINK)
                            showBacklinks = false
                        }
                    }
                }
                item { Spacer(Modifier.height(24.dp)) }
            }
        }
    }

    // (In-app WebView popup is now overlaid globally from MainActivity; the Reader
    // requests it via vm.requestWebPopup(url).)

    // --- Link long-press menu (Copy URL / Copy link text / Share / Open in browser) ---
    if (linkLongPress != null) {
        val data = linkLongPress!!
        ModalBottomSheet(onDismissRequest = { linkLongPress = null }) {
            Column(Modifier.padding(horizontal = 20.dp, vertical = 4.dp)) {
                if (data.text.isNotBlank()) {
                    Text(
                        data.text,
                        fontWeight = FontWeight.SemiBold, fontSize = 14.sp,
                        maxLines = 2, overflow = TextOverflow.Ellipsis
                    )
                    Spacer(Modifier.height(2.dp))
                }
                Text(
                    data.url, fontSize = 11.sp,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    maxLines = 2, overflow = TextOverflow.Ellipsis
                )
                Spacer(Modifier.height(8.dp))
                HorizontalDivider(color = MaterialTheme.colorScheme.surfaceVariant)
            }
            LinkActionRow("\uD83D\uDD17  Copy link address") {
                clipboard.setText(androidx.compose.ui.text.AnnotatedString(data.url))
                Toast.makeText(ctx, "Link copied", Toast.LENGTH_SHORT).show()
                linkLongPress = null
            }
            if (data.text.isNotBlank()) {
                LinkActionRow("\uD83D\uDCDD  Copy link text") {
                    clipboard.setText(androidx.compose.ui.text.AnnotatedString(data.text))
                    Toast.makeText(ctx, "Text copied", Toast.LENGTH_SHORT).show()
                    linkLongPress = null
                }
            }
            LinkActionRow("\u2197\uFE0F  Share") {
                val send = Intent(Intent.ACTION_SEND).apply {
                    type = "text/plain"
                    putExtra(Intent.EXTRA_TEXT, data.url)
                    if (data.text.isNotBlank()) putExtra(Intent.EXTRA_SUBJECT, data.text)
                }
                runCatching {
                    ctx.startActivity(Intent.createChooser(send, "Share link").addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
                }
                linkLongPress = null
            }
            LinkActionRow("\uD83C\uDF10  Open in system browser") {
                runCatching {
                    openExternally(ctx, Uri.parse(data.url))
                }
                linkLongPress = null
            }
            Spacer(Modifier.height(20.dp))
        }
    }

    // --- Tab grid bottom sheet ---
    // Vertical-scrolling list of all open tabs. Tap a card to switch; tap × to close that tab;
    // "Close all" button at the top closes every tab and exits the Reader.
    if (showTabGrid) {
        ModalBottomSheet(onDismissRequest = { showTabGrid = false }) {
            Column(Modifier.fillMaxWidth().padding(bottom = 8.dp)) {
                // Header row: count + Close all
                Row(
                    Modifier.fillMaxWidth().padding(start = 20.dp, end = 12.dp, top = 4.dp, bottom = 6.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        "\uD83D\uDCD1  Open tabs (${tabs.size})",
                        fontWeight = FontWeight.SemiBold, fontSize = 15.sp,
                        modifier = Modifier.weight(1f)
                    )
                    TextButton(onClick = {
                        // Save current scroll for the active tab before nuking everything
                        val cur = activeTab
                        if (cur != null) {
                            scrollMap[cur] = latestScroll.value
                            vm.saveScroll(cur, latestScroll.value)
                        }
                        vm.closeAllTabs()
                        showTabGrid = false
                        // Leaving the Reader since there are no tabs anymore
                        nav.popBackStack()
                    }) { Text("\u2716 Close all", fontSize = 13.sp) }
                }
                HorizontalDivider(color = MaterialTheme.colorScheme.surfaceVariant)
                LazyColumn(Modifier.fillMaxWidth().heightIn(max = 520.dp)) {
                    items(tabs, key = { "tg-${it.id}" }) { tab ->
                        val selected = tab.id == activeTab
                        Surface(
                            color = if (selected) MaterialTheme.colorScheme.primary.copy(alpha = 0.20f)
                            else MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.30f),
                            shape = RoundedCornerShape(10.dp),
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(horizontal = 12.dp, vertical = 4.dp)
                                .clickable {
                                    // Save scroll for the current tab before switching
                                    val cur = activeTab
                                    if (cur != null) {
                                        scrollMap[cur] = latestScroll.value
                                        vm.saveScroll(cur, latestScroll.value)
                                    }
                                    switchTab(tab.id)
                                    showTabGrid = false
                                }
                        ) {
                            Row(
                                Modifier.padding(start = 14.dp, end = 4.dp, top = 10.dp, bottom = 10.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text(
                                    if (selected) "\u2022 " else "\uD83D\uDCC4  ",
                                    fontSize = 14.sp,
                                    color = if (selected) MaterialTheme.colorScheme.primary
                                    else MaterialTheme.colorScheme.onSurfaceVariant
                                )
                                Text(
                                    tab.title,
                                    modifier = Modifier.weight(1f),
                                    maxLines = 2, overflow = TextOverflow.Ellipsis,
                                    fontSize = 14.sp,
                                    lineHeight = 18.sp,
                                    fontWeight = if (selected) FontWeight.SemiBold else FontWeight.Normal
                                )
                                IconButton(onClick = {
                                    // If we're closing the last tab, leave the Reader cleanly
                                    if (tabs.size == 1) {
                                        vm.closeAllTabs()
                                        showTabGrid = false
                                        nav.popBackStack()
                                    } else {
                                        vm.closeTab(tab.id)
                                    }
                                }) {
                                    Icon(
                                        Icons.Default.Close,
                                        contentDescription = "Close tab",
                                        modifier = Modifier.size(18.dp),
                                        tint = MaterialTheme.colorScheme.onSurfaceVariant
                                    )
                                }
                            }
                        }
                    }
                }
                Spacer(Modifier.height(12.dp))
            }
        }
    }

    // --- Print / PDF bottom sheet ---
    // Lets the user pick paper size, orientation, margins, theme; on confirm we read the
    // already-rendered HTML out of the Reader's WebView, wrap it in print-specific CSS,
    // and hand it to the Android print framework (which offers Save-as-PDF + real printers).
    if (showPrintSheet) {
        ModalBottomSheet(onDismissRequest = { showPrintSheet = false }) {
            PrintOptionsSheet(
                noteTitle = note?.title ?: "Note",
                onCancel = { showPrintSheet = false },
                onConfirm = { opts ->
                    showPrintSheet = false
                    val wv = webView
                    if (wv != null) {
                        // Extract the rendered HTML from the Reader's WebView. markdown-it has
                        // already done its work — we just grab #content's innerHTML, wrap it
                        // in our print-specific styling, and start the print job.
                        wv.evaluateJavascript(
                            "(function(){var e=document.getElementById('content');" +
                                "return e?e.innerHTML:'';})();"
                        ) { jsonResult ->
                            // Result is JSON-encoded ("...html..."); decode once
                            val rendered = decodeJsString(jsonResult)
                            val title = note?.title ?: "Note"
                            val printHtml = buildPrintHtml(title, rendered, opts)
                            startPrintJob(ctx, title, printHtml, opts, printPinHolder)
                        }
                    } else {
                        Toast.makeText(ctx, "Note not ready to print yet", Toast.LENGTH_SHORT).show()
                    }
                }
            )
        }
    }
}

/**
 * Decode the JSON-encoded string that evaluateJavascript hands back. The input is wrapped in
 * double-quotes and uses \uXXXX/\\ escapes — we strip those carefully so the print HTML stays
 * intact.
 */
private fun decodeJsString(jsonString: String?): String {
    if (jsonString.isNullOrBlank() || jsonString == "null") return ""
    return try {
        org.json.JSONArray("[$jsonString]").getString(0)
    } catch (_: Exception) {
        // Fallback for trivial cases
        jsonString.trim().trim('"')
            .replace("\\n", "\n").replace("\\r", "")
            .replace("\\\"", "\"").replace("\\\\", "\\")
    }
}

@Composable
private fun LinkActionRow(text: String, onClick: () -> Unit) {
    Text(
        text,
        Modifier
            .fillMaxWidth()
            .clickable(onClick = onClick)
            .padding(horizontal = 20.dp, vertical = 13.dp),
        fontSize = 14.sp
    )
}

@Composable
private fun LinkRow(ln: com.tebogo.markvault.data.LinkedNote, onClick: () -> Unit) {
    Column(
        Modifier
            .fillMaxWidth()
            .clickable(onClick = onClick)
            .padding(horizontal = 20.dp, vertical = 11.dp)
    ) {
        Text(
            ln.title, fontWeight = FontWeight.Medium, fontSize = 14.sp,
            maxLines = 2, overflow = TextOverflow.Ellipsis
        )
        if (ln.folder.isNotBlank()) {
            Text(
                ln.folder, fontSize = 11.sp,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                maxLines = 1, overflow = TextOverflow.Ellipsis
            )
        }
    }
}

/** Snapshot of a long-pressed `<a>` in the article — URL + visible text. */
private data class LinkPressData(val url: String, val text: String)

/** Where a tapped external link should go. */
private enum class LinkTarget { JW_LIBRARY_APP, IN_APP_WEBVIEW, SYSTEM_BROWSER }

/** Hosts we'll keep inside the in-app WebView popup. */
private val JW_DOMAIN_SUFFIXES = listOf(
    "jw.org", "wol.jw.org", "tv.jw.org", "jw-cdn.org", "akamaihd.net"
)

private fun isJwHost(uri: Uri): Boolean {
    val host = uri.host?.lowercase() ?: return false
    return JW_DOMAIN_SUFFIXES.any { host == it || host.endsWith(".$it") }
}

/**
 * The user's example link:
 *   https://www.jw.org/finder?srcid=jwlshare&wtlocale=E&prefer=lang&bible=40006002&pub=nwtsty
 * That's the format JW Library registers an intent-filter for. The signature is:
 *   host == *.jw.org, path == /finder, query has srcid=jwlshare AND pub=... (any pub)
 * Other jw.org links (no jwlshare srcid) belong in the in-app WebView.
 */
private fun routeLink(uri: Uri): LinkTarget {
    val host = uri.host?.lowercase() ?: return LinkTarget.SYSTEM_BROWSER
    if (!isJwHost(uri)) return LinkTarget.SYSTEM_BROWSER
    val path = uri.path?.lowercase() ?: ""
    val srcid = uri.getQueryParameter("srcid")?.lowercase()
    val isJwLibraryDeepLink =
        (host == "jw.org" || host == "www.jw.org") &&
        path == "/finder" &&
        srcid == "jwlshare"
    return if (isJwLibraryDeepLink) LinkTarget.JW_LIBRARY_APP else LinkTarget.IN_APP_WEBVIEW
}

/**
 * Hand the URL off to JW Library directly. If JW Library isn't installed, fall back to letting
 * the in-app WebView popup handle it (caller passes [onFallback]).
 */
private fun openInJwLibrary(ctx: Context, uri: Uri, onFallback: () -> Unit) {
    val packages = listOf("org.jw.jwlibrary.mobile", "org.jw.jwlpub.mobile") // try common pkgs
    for (pkg in packages) {
        try {
            val intent = Intent(Intent.ACTION_VIEW, uri)
                .setPackage(pkg)
                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            ctx.startActivity(intent)
            return
        } catch (_: Exception) { /* try next */ }
    }
    // Generic ACTION_VIEW with no package — Android shows a chooser if multiple match
    try {
        val anyHandler = Intent(Intent.ACTION_VIEW, uri).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        // Resolve first to make sure something handles the intent before launching
        val resolved = ctx.packageManager.resolveActivity(anyHandler, 0) != null
        if (resolved) {
            ctx.startActivity(anyHandler)
        } else {
            onFallback()
        }
    } catch (_: Exception) {
        onFallback()
    }
}

private fun openExternally(ctx: Context, uri: Uri) {
    try {
        ctx.startActivity(Intent(Intent.ACTION_VIEW, uri).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
    } catch (e: Exception) {
        Toast.makeText(ctx, "No app can open this link", Toast.LENGTH_SHORT).show()
    }
}
