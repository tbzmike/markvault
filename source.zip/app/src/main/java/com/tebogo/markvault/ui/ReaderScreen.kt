package com.tebogo.markvault.ui

import android.annotation.SuppressLint
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.webkit.WebResourceRequest
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.tween
import android.widget.Toast
import androidx.activity.compose.BackHandler
import androidx.compose.foundation.background
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectHorizontalDragGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.filled.KeyboardArrowLeft
import androidx.compose.material.icons.automirrored.filled.KeyboardArrowRight
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.KeyboardArrowDown
import androidx.compose.material.icons.filled.KeyboardArrowUp
import androidx.compose.material.icons.filled.Menu
import androidx.compose.material.icons.filled.MoreVert
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.Button
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.TextField
import androidx.compose.material3.TextFieldDefaults
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.mutableStateMapOf
import androidx.compose.foundation.border
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import com.tebogo.markvault.ui.DraggableBubble
import com.tebogo.markvault.ui.BubbleCloseZone
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.toArgb
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.navigation.NavController
import kotlinx.coroutines.launch
import com.tebogo.markvault.AppViewModel
import com.tebogo.markvault.OutlineItem
import com.tebogo.markvault.data.Note
import org.json.JSONObject
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.rememberCoroutineScope

@OptIn(ExperimentalMaterial3Api::class)
@SuppressLint("SetJavaScriptEnabled")
@Composable
fun ReaderScreen(vm: AppViewModel, nav: NavController) {
    val tabs by vm.tabs.collectAsStateWithLifecycle()
    val activeTab by vm.activeTab.collectAsStateWithLifecycle()
    val fontScale by vm.fontScale.collectAsStateWithLifecycle()
    val theme by vm.theme.collectAsStateWithLifecycle()
    val customThemeJson by vm.customThemeJson.collectAsStateWithLifecycle()
    val activeObsidianTheme by vm.activeObsidianTheme.collectAsStateWithLifecycle()
    val obsidianAppearanceMode by vm.activeObsidianAppearanceMode.collectAsStateWithLifecycle()
    val obsidianDark = resolveObsidianDark(obsidianAppearanceMode, isSystemInDarkTheme(), activeObsidianTheme)
    val favouriteIds by vm.favouriteIds.collectAsStateWithLifecycle()
    val tabHistory by vm.tabHistory.collectAsStateWithLifecycle()
    val smartStylingAllDocs by vm.smartStylingAllDocs.collectAsStateWithLifecycle()
    val textContrast by vm.textContrast.collectAsStateWithLifecycle()
    val swipeSwitchTabs by vm.swipeSwitchTabs.collectAsStateWithLifecycle()
    val workspaceBoldText by vm.workspaceBoldText.collectAsStateWithLifecycle()
    val readerUiMode by vm.uiMode.collectAsStateWithLifecycle()
    // v5.4.150cc — Typing speed persisted via DataStore; slider reads this,
    // slider changes call vm.setPopupTypingSpeed which writes back to DataStore.
    val popupTypingSpeed by vm.popupTypingSpeed.collectAsStateWithLifecycle()
    val ctx = LocalContext.current
    val relatedScope = rememberCoroutineScope()
    var relatedVideos by remember { mutableStateOf<List<com.tebogo.markvault.data.RelatedVideoMatch>>(emptyList()) }
    var showRelatedVideos by remember { mutableStateOf(false) }
    var relatedVideoPopup by remember { mutableStateOf<com.tebogo.markvault.data.MediaItem?>(null) }
    LaunchedEffect(activeTab) {
        val id = activeTab ?: return@LaunchedEffect
        val n = vm.noteById(id) ?: return@LaunchedEffect
        relatedVideos = vm.findRelatedVideos(n.title, n.content, includeOnline = false)
        val enriched = vm.findRelatedVideos(n.title, n.content, includeOnline = true)
        relatedVideos = enriched
    }
    val clipboard = LocalClipboardManager.current
    val activeColorScheme = LocalMarkVaultTargetColorScheme.current ?: MaterialTheme.colorScheme
    val effectiveArticleThemeJson = remember(theme, customThemeJson, activeColorScheme) {
        articleThemeJson(activeColorScheme, customThemeJson.takeIf { theme == "custom" })
    }
    val effectiveObsidianCss = remember(theme, activeObsidianTheme, obsidianDark) {
        if (theme == "obsidian_imported") {
            activeObsidianTheme?.let { obsidianArticleCompatibilityCss(obsidianDark) + "\n" + it.css }.orEmpty()
        } else ""
    }
    val obsidianThemeJs = remember(effectiveObsidianCss, obsidianDark) {
        "setObsidianThemeCss(${JSONObject.quote(effectiveObsidianCss)}, ${if (obsidianDark) "true" else "false"});"
    }

    // v5.4.106cc — On first mount, if the previous session left tabs
    // and the current tab list is empty (fresh cold start into this
    // screen), re-open them via the VM. Idempotent: the consume
    // method internally clears the pending payload on first call.
    LaunchedEffect(Unit) {
        if (vm.tabs.value.isEmpty()) {
            vm.consumeRestoredReaderTabs()
        }
    }

    LaunchedEffect(tabs.isEmpty()) {
        // Only pop if the tabs list is *still* empty after the restore
        // effect above has had a chance to run. The consume path is
        // asynchronous (DB checks on IO) so we give it a beat before
        // deciding there's nothing to show.
        if (tabs.isEmpty()) {
            val hasPending = vm.pendingRestoredReaderTabs.value.isNotEmpty()
            if (!hasPending) nav.popBackStack()
        }
    }
    // When the Reader leaves the composition entirely, reset the tab visit history so a future
    // re-entry doesn't try to back-navigate into a stale chain.
    DisposableEffect(Unit) {
        onDispose { vm.clearTabHistory() }
    }

    var note by remember { mutableStateOf<Note?>(null) }
    /** The phrase to flash-highlight in this article (captured once when the tab opens). */
    var highlightTerm by remember { mutableStateOf<String?>(null) }
    var highlightIsPhrase by remember { mutableStateOf(false) }
    var highlightSnippet by remember { mutableStateOf("") }
    /** v5.4.76cc — LLM-produced paraphrase terms for softer lavender overlay. */
    var highlightLlmTerms by remember { mutableStateOf<List<String>>(emptyList()) }
    /** v5.4.307cc — One-shot query from SearchResultActionSheet. Kept locally
     * until the WebView has rendered and the yellow term-hit marks exist. */
    var pendingAutoPopupQuery by remember { mutableStateOf<String?>(null) }
    /** Total wikilink connections (forward + backlinks) for the active article — drives the header chip. */
    var connCount by remember { mutableStateOf(-1) } // -1 = unknown / loading
    LaunchedEffect(activeTab) {
        val id = activeTab
        note = if (id != null) vm.loadNote(id) else null
        // v5.4.307cc — Preserve the one-shot popup request until the
        // article has actually rendered. The previous v5.4.144cc code
        // consumed and discarded it here, which is the verified reason
        // the long-press action only opened the article.
        val n: com.tebogo.markvault.data.Note? = note
        pendingAutoPopupQuery = if (n != null) vm.consumePendingPopupQuery() else null
        pendingAutoPopupQuery?.takeIf { it.length >= 2 }?.let {
            vm.setArticlePopupLoading(n!!.id, it)
        }
        // Capture the pending highlight exactly once per article open.
        // v5.4.37 — Now also carries the FTS snippet for the
        // snippet-first highlight cascade.
        val pending = vm.consumePendingHighlight()?.takeIf { it.query.isNotBlank() }
        val highlightOn = vm.articleHighlightEnabled.value
        if (highlightOn && pending != null) {
            highlightTerm = pending.query
            highlightIsPhrase = pending.isPhrase
            highlightSnippet = pending.snippet
            highlightLlmTerms = pending.llmTerms
        } else {
            highlightTerm = null
            highlightIsPhrase = false
            highlightSnippet = ""
            highlightLlmTerms = emptyList()
        }
        // Refresh the connection count for this tab
        connCount = if (id != null) vm.connectionCount(id) else -1
    }

    var webView by remember { mutableStateOf<WebView?>(null) }
    var pageReady by remember { mutableStateOf(false) }
    val scrollMap = remember { HashMap<Long, Int>() }
    val latestScroll = remember { mutableStateOf(0) }
    
    // v5.4.145cc — Scroll-driven toolbar hiding for fullscreen mode
    var lastScrollValue by remember { mutableStateOf(0) }
    var toolbarsVisible by remember { mutableStateOf(true) }
    val enableFullscreenMode by vm.enableFullscreenMode.collectAsStateWithLifecycle()
    
    // v5.4.155cc — Scroll-to-hide logic moved DIRECTLY into the WebView's
    // setOnScrollChangeListener inside the AndroidView update lambda below.
    // The previous LaunchedEffect(latestScroll.value) approach introduced
    // an async gap between the scroll event and the hide/show decision,
    // which caused the toolbar to never reliably hide. The update-lambda
    // pattern (same as the working WebSearchScreen) runs the logic
    // synchronously in the listener and re-attaches on every recomposition
    // so the listener always captures the latest enableFullscreenMode value.

    var showFind by remember { mutableStateOf(false) }
    var findQuery by remember { mutableStateOf("") }
    var matchCount by remember { mutableStateOf(0) }
    var activeMatch by remember { mutableStateOf(0) }
    val findFocus = remember { FocusRequester() }

    var menuOpen by remember { mutableStateOf(false) }
    var themeMenuOpen by remember { mutableStateOf(false) }
    var showOutline by remember { mutableStateOf(false) }
    var showBacklinks by remember { mutableStateOf(false) }
    // Feature 1: Scripture Context Panel — shows all Bible references in this note
    // along with the snippet of preceding text as the context clue.
    var showScripturePanel by remember { mutableStateOf(false) }
    // Feature 2: Press-and-hold to Peek — populated when the user long-presses a
    // wikilink in the article. The note id is passed via the mv:// scheme.
    var peekNoteId by remember { mutableStateOf<Long?>(null) }
    // Feature 3: Split view picker — when true, show a dialog listing the other
    // open tabs that the user can pair with this one to enter dual-pane mode.
    var showSplitPicker by remember { mutableStateOf(false) }
    var wikilinkTap by remember { mutableStateOf<String?>(null) }
    var backlinks by remember { mutableStateOf<List<com.tebogo.markvault.data.LinkedNote>>(emptyList()) }
    var forwardlinks by remember { mutableStateOf<List<com.tebogo.markvault.data.LinkedNote>>(emptyList()) }
    /** Long-pressed link inside the article — drives the copy/share bottom-sheet menu. */
    var linkLongPress by remember { mutableStateOf<LinkPressData?>(null) }
    /** Bottom sheet showing all open tabs as a scrollable grid. */
    var showTabGrid by remember { mutableStateOf(false) }
    /** Bottom sheet for Print / PDF export with paper size, orientation, theme, margin. */
    var showPrintSheet by remember { mutableStateOf(false) }
    /** v5.4.33 — Theme creator bottom sheet. */
    var showThemeCreator by remember { mutableStateOf(false) }
    /** Keeps the transient print WebView from being GC'd before PrintManager finishes. */
    val printPinHolder = remember { PinHolder() }

    val bg = MaterialTheme.colorScheme.background.toArgb()
    val outline = remember(note?.id) { note?.let { AppViewModel.parseOutline(it.content) } ?: emptyList() }

    // v5.4.27 — Detect once whether the note is an HTML document
    // masquerading as .md so we can drive zoom controls + render path
    // from the same state.
    val isHtmlDominant = remember(note?.id) {
        val content = note?.content ?: return@remember false
        val trimmed = content.trimStart()
        val afterFirstWikilink = if (trimmed.startsWith("[[")) {
            val endIdx = trimmed.indexOf("]]")
            if (endIdx >= 0) trimmed.substring(endIdx + 2).trimStart() else trimmed
        } else trimmed
        afterFirstWikilink.take(30).lowercase().let {
            it.startsWith("<!doctype html") || it.startsWith("<html")
        }
    }
    // v5.4.27 — Per-article HTML text zoom (percent). textZoom starts at
    // 100 for every new HTML doc. Android's system font-scale would
    // otherwise be applied on top of the doc's own CSS, producing the
    // 3x-too-big text you saw. This resets that override.
    var htmlZoom by remember(note?.id) { mutableIntStateOf(100) }
    LaunchedEffect(htmlZoom, pageReady, isHtmlDominant) {
        if (pageReady && isHtmlDominant) {
            webView?.settings?.textZoom = htmlZoom
        }
    }

    fun jsString(s: String) = JSONObject.quote(s)

    /**
     * v5.4.76cc — Build a trailing JS fragment that calls
     * `highlightLlmTerms([...])` with the paraphrase list. Returns an
     * empty string when there are no terms so the injected script for
     * plain articles stays exactly what it was before.
     *
     * Each term is JSON-quoted (escaping quotes and control chars via
     * `JSONObject.quote`) so no user- or model-emitted character can
     * break out of the JS array literal. Terms shorter than 3
     * characters are skipped to avoid marking noise like "is"/"an"
     * across the entire document.
     */
    fun buildLlmHighlightTail(terms: List<String>): String {
        // v5.4.144cc — AI highlighting must only wrap PHRASES (2+ words).
        // Single-word terms (no space) are rejected before building the payload.
        val filtered = terms.map { it.trim() }
            .filter { it.length >= 3 && ' ' in it }
            .distinctBy { it.lowercase() }
        if (filtered.isEmpty()) return ""
        val payload = filtered.joinToString(",") { JSONObject.quote(it) }
        return "highlightLlmTerms([$payload]);"
    }

    LaunchedEffect(pageReady, note?.id) {
        val wv = webView ?: return@LaunchedEffect
        val n = note ?: return@LaunchedEffect
        if (!pageReady) return@LaunchedEffect
        val y = scrollMap[n.id] ?: n.lastScroll
        latestScroll.value = y
        lastScrollValue = y  // v5.4.147cc — Initialize lastScrollValue for scroll detection
        val term = highlightTerm
        val smartAll = if (smartStylingAllDocs) "true" else "false"
        val contrastStr = textContrast.toString()

        // v5.4.26 — HTML-dominant .md detection. Some notes are actually
        // whole HTML documents saved with a .md extension (with an
        // optional [[wikilink]] title line on top). Running those
        // through flexmark produces the "raw <div class="timeline">
        // showing as text" garbage the user saw. Detect and bypass:
        // load the raw content into the WebView via loadDataWithBaseURL
        // with a viewport-meta injection so it fits the phone.
        // v5.4.27 — Detection hoisted to isHtmlDominant state above;
        // this branch just consumes it and applies the current htmlZoom.
        if (isHtmlDominant) {
            val trimmedStart = n.content.trimStart()
            val afterFirstWikilink = if (trimmedStart.startsWith("[[")) {
                val endIdx = trimmedStart.indexOf("]]")
                if (endIdx >= 0) trimmedStart.substring(endIdx + 2).trimStart() else trimmedStart
            } else trimmedStart
            val viewportMeta =
                "<meta name=\"viewport\" content=\"width=device-width, " +
                    "initial-scale=1.0\">"
            // v5.4.29 — Mobile-fit CSS override. The user's HTML has
            // `.wrap { max-width: 1200px }` and other desktop-oriented
            // widths that made content overflow the phone viewport even
            // with a proper viewport meta. This override forces every
            // element to fit within the viewport width, wraps long
            // words / URLs so nothing overflows, and shrinks images /
            // tables / pre blocks. Typography, colours, and the doc's
            // own visual design stay intact.
            val mobileFitCss =
                "<style id=\"mv-mobile-fit\">" +
                    "html,body{max-width:100vw!important;overflow-x:hidden!important;" +
                    "word-wrap:break-word;overflow-wrap:break-word}" +
                    "*{max-width:100%!important;box-sizing:border-box!important}" +
                    "img,video,iframe,svg,canvas{max-width:100%!important;height:auto!important}" +
                    "table{width:100%!important;display:block!important;overflow-x:auto!important}" +
                    "pre,code{white-space:pre-wrap!important;word-break:break-word!important}" +
                    "</style>"
            val globalThemeCss = articleThemeHtmlCss(
                activeColorScheme,
                customThemeJson.takeIf { theme == "custom" },
                theme,
                boldBodyText = readerUiMode == "workspace" && workspaceBoldText,
                obsidianCss = activeObsidianTheme?.css.takeIf { theme == "obsidian_imported" },
                obsidianDark = obsidianDark
            )
            val headInjection = viewportMeta + mobileFitCss + globalThemeCss
            val src = afterFirstWikilink
            val lower = src.lowercase()
            val patched = run {
                val headOpen = lower.indexOf("<head")
                if (headOpen >= 0) {
                    val after = src.indexOf('>', headOpen) + 1
                    if (after > 0) src.substring(0, after) + headInjection + src.substring(after)
                    else src
                } else {
                    val htmlOpen = lower.indexOf("<html")
                    if (htmlOpen >= 0) {
                        val after = src.indexOf('>', htmlOpen) + 1
                        if (after > 0)
                            src.substring(0, after) +
                                "<head>" + headInjection + "</head>" +
                                src.substring(after)
                        else src
                    } else src
                }
            }
            wv.settings.useWideViewPort = false
            // v5.4.27 — apply current zoom before load so first render
            // uses the right size instead of flashing at default first.
            wv.settings.textZoom = htmlZoom
            wv.loadDataWithBaseURL("about:blank", patched, "text/html", "utf-8", null)
            // HTML-dominant .md bypasses viewer.html/highlightTerm(), so
            // there are no .term-hit nodes to extract. Use the existing
            // semantic passage engine as the verified fallback so the
            // smart popup still opens instead of remaining in Loading.
            pendingAutoPopupQuery?.takeIf { it.length >= 2 }?.let { autoQ ->
                pendingAutoPopupQuery = null
                vm.findAndShowArticlePassages(n.id, n.content, autoQ)
            }
            return@LaunchedEffect
        }

        // v4.18.0 — pre-render markdown to HTML in Kotlin via flexmark
        // (MarkdownEngine.markdownToHtml) and hand the HTML to the WebView.
        // The JS `renderMarkdown` function now consumes HTML, not raw
        // markdown — signature unchanged so this is a drop-in swap.
        val html = com.tebogo.markvault.markdown.MarkdownEngine.render(n.content) { target ->
            vm.resolveEmbedContent(target)
        }
        if (!term.isNullOrBlank()) {
            // v5.4.37 — Pass the FTS snippet as 4th arg so JS can
            // use it as the most precise highlight needle.
            val hlMode = vm.effectiveHighlightMode()
            val phraseFlag = if (highlightIsPhrase) "true" else "false"
            // v5.4.76cc — Also inject a call to highlightLlmTerms with
            // the paraphrase list captured from the pending highlight,
            // so LLM-surfaced terms get the softer lavender `.llm-hit`
            // overlay on top of any yellow `.term-hit` from the
            // original query. Skipped when there are no LLM terms — we
            // don't want a no-op JS call cluttering renderMarkdown's
            // scroll-restore path.
            val llmJs = buildLlmHighlightTail(highlightLlmTerms)
            val autoPopupQuery = pendingAutoPopupQuery
            wv.evaluateJavascript(
                "setThemeVariables(${jsString(effectiveArticleThemeJson)}); renderMarkdown(${jsString(html)}, $fontScale, ${jsString(theme)}, $smartAll, $contrastStr); setThemeVariables(${jsString(effectiveArticleThemeJson)});$obsidianThemeJs highlightTerm(${jsString(term)}, ${jsString(hlMode)}, $phraseFlag, ${jsString(highlightSnippet)});$llmJs"
            ) {
                // v5.4.307cc — highlightTerm() has completed in this JS
                // transaction, so the DOM now contains the exact yellow
                // text that the brain FAB normally copies into the popup.
                if (!autoPopupQuery.isNullOrBlank() && autoPopupQuery.length >= 2 &&
                    pendingAutoPopupQuery == autoPopupQuery) {
                    pendingAutoPopupQuery = null
                    wv.evaluateJavascript(
                        """(function(){
                          var els=document.querySelectorAll('mark.term-hit, span.term-hit');
                          var texts=[]; var seen={};
                          for(var i=0;i<els.length && texts.length<20;i++){
                            var t=(els[i].textContent||'').replace(/\s+/g,' ').trim();
                            if(t.length>1 && !seen[t]){seen[t]=1;texts.push(t);}
                          }
                          return JSON.stringify(texts);
                        })()"""
                    ) { result ->
                        val passages = decodeJsHighlightArray(result)
                        if (passages.isNotEmpty()) {
                            vm.showArticlePopupWithPassages(n.id, autoPopupQuery, passages)
                        } else {
                            // A rendering/highlight edge case must not strand
                            // the popup in Loading. Fall back to the existing
                            // semantic passage ranker for this article.
                            vm.findAndShowArticlePassages(n.id, n.content, autoPopupQuery)
                        }
                    }
                }
            }
            highlightTerm = null
        } else {
            // v5.4.76cc — Even when there's no primary highlightTerm
            // (e.g. article opened directly, not from a search), we
            // still overlay any pending LLM terms if the user opted in
            // and history has an expansion for a recent query. This
            // keeps the "AI trace" visible when jumping between
            // articles via wikilinks after an LLM-expanded search.
            val llmJs = buildLlmHighlightTail(highlightLlmTerms)
            wv.evaluateJavascript(
                "setThemeVariables(${jsString(effectiveArticleThemeJson)}); renderMarkdown(${jsString(html)}, $fontScale, ${jsString(theme)}, $smartAll, $contrastStr); setThemeVariables(${jsString(effectiveArticleThemeJson)});$obsidianThemeJs restoreScroll($y);$llmJs",
                null
            )
            pendingAutoPopupQuery?.takeIf { it.length >= 2 }?.let { autoQ ->
                pendingAutoPopupQuery = null
                vm.findAndShowArticlePassages(n.id, n.content, autoQ)
            }
        }
    }
    DisposableEffect(Unit) {
        onDispose {
            val id = activeTab
            if (id != null) vm.saveScroll(id, latestScroll.value)
        }
    }
    LaunchedEffect(fontScale, pageReady) {
        if (pageReady) webView?.evaluateJavascript("setFontScale($fontScale);", null)
    }
    LaunchedEffect(theme, customThemeJson, activeObsidianTheme, obsidianDark, pageReady) {
        if (pageReady && !isHtmlDominant) {
            webView?.evaluateJavascript(
                "setTheme(${jsString(theme)}); setThemeVariables(${jsString(effectiveArticleThemeJson)});$obsidianThemeJs",
                null
            )
        }
    }
    LaunchedEffect(workspaceBoldText, readerUiMode, pageReady) {
        if (pageReady) {
            val weight = if (readerUiMode == "workspace" && workspaceBoldText) "600" else "400"
            webView?.evaluateJavascript(
                "(function(){var s=document.getElementById('mv-workspace-weight');" +
                    "if(!s){s=document.createElement('style');s.id='mv-workspace-weight';document.head.appendChild(s);}" +
                    "s.textContent='body,p,li,dd,dt,td{font-weight:$weight !important;}';})();",
                null
            )
        }
    }

    // Resolve wikilink taps from the WebView and open the target in a new tab
    LaunchedEffect(wikilinkTap) {
        val target = wikilinkTap ?: return@LaunchedEffect
        val decoded = runCatching { java.net.URLDecoder.decode(target, "UTF-8") }.getOrElse { target }
        val hit = vm.resolveWikilink(decoded)
        if (hit != null) {
            // Save current scroll so going back to this note resumes
            val cur = activeTab
            if (cur != null) {
                scrollMap[cur] = latestScroll.value
                vm.saveScroll(cur, latestScroll.value)
            }
            vm.openArticle(hit.id, hit.title, com.tebogo.markvault.OpenSource.LINK)
        } else {
            Toast.makeText(ctx, "No note matches \"$decoded\"", Toast.LENGTH_SHORT).show()
        }
        wikilinkTap = null
    }

    BackHandler(enabled = showFind) { showFind = false; webView?.clearMatches() }
    // System Back inside the Reader: walk the tab visit history first, then exit the Reader
    // (the default nav pop) only once there's no previous tab to return to.
    BackHandler(enabled = !showFind && tabHistory.size >= 2) {
        // Persist current tab's scroll so when we re-enter it later it lands in the right place
        val cur = activeTab
        if (cur != null) {
            scrollMap[cur] = latestScroll.value
            vm.saveScroll(cur, latestScroll.value)
        }
        vm.goBackInTabs()
    }

    fun switchTab(newId: Long) {
        val old = activeTab
        if (old != null && old != newId) {
            val y = latestScroll.value
            scrollMap[old] = y
            vm.saveScroll(old, y)
        }
        vm.setActiveTab(newId)
    }

    // v5.4.18 — Read the FAB-related toggles once for this scope so
    // recomposition stays cheap.
    val fabEnabled by vm.searchInArticleFab.collectAsStateWithLifecycle()
    val semanticInArticleOn by vm.semanticInArticle.collectAsStateWithLifecycle()
    val currentSearchQuery by vm.query.collectAsStateWithLifecycle()
    // Latch the "opened from search" flag per active tab so:
    //   1. FAB stays visible for the whole reading session on this tab.
    //   2. Clearing the VM flag immediately means later opens from
    //      Browse/Topics don't inherit search-attribution incorrectly.
    val openedFromSearchLatched by androidx.compose.runtime.produceState(
        initialValue = false, key1 = activeTab
    ) {
        value = vm.openedFromSearch.value
        vm.clearOpenedFromSearch()
    }
    // fabBusy kept for PumpingBrainFab busy indicator (always false after
    // v5.4.144cc — popup extraction is instant via evaluateJavascript).
    var fabBusy by remember { mutableStateOf(false) }
    // fabScope removed v5.4.144cc — no coroutine needed for popup path

    // v5.4.21 — Workspace-mode left drawer. ModalNavigationDrawer
    // always wraps the Scaffold but gesturesEnabled + hamburger
    // visibility are workspace-only, so standard mode sees no change
    // in behaviour. Drawer lists open tabs + a shortcut to Home for
    // opening a new tab.
    val uiMode by vm.uiMode.collectAsStateWithLifecycle()
    val workspaceOn = uiMode == "workspace"
    // v5.4.22 — Tablet three-column layout when workspace mode is on AND
    // the current window is wide enough (≥ 600dp). Below that, workspace
    // falls back to the modal drawer + 📑 button UI from v5.4.21. This
    // keeps phone UX unchanged and lights up Obsidian-style side panels
    // only when there's room for them.
    val screenWidthDp = androidx.compose.ui.platform.LocalConfiguration.current.screenWidthDp
    val isTabletWidth = screenWidthDp >= 600
    val forceTabletUi by vm.forceWorkspaceTabletUi.collectAsStateWithLifecycle()
    // v5.4.324cc — The global WorkspaceTabletShell is the single owner of
    // tablet navigation/Inspector panes. Keep this reader's legacy workspace
    // drawers only for narrow/phone Workspace, never duplicate them on tablet.
    val workspaceTabletShell = workspaceOn && (isTabletWidth || forceTabletUi)
    val threeColumn = false
    val leftColWidth = 240.dp
    val rightColWidth = 220.dp
    // v5.4.24 — Collapsible panels. Default open at tablet width so the
    // Obsidian look shows up, but users can toggle each panel closed
    // via the corner buttons and the layout responds live.
    var leftPanelOpen by remember { mutableStateOf(true) }
    var rightPanelOpen by remember { mutableStateOf(true) }
    // v5.4.33 — Left panel tab: switch between "tabs" and "results"
    var leftPanelTab by remember { mutableStateOf("tabs") }
    // v5.4.33 — Right panel bottom sheet for portrait workspace mode
    var showRightSheet by remember { mutableStateOf(false) }
    // v5.4.33 — Observe search results in reader for left panel
    val searchResults by vm.results.collectAsStateWithLifecycle()
    val searchQuery by vm.query.collectAsStateWithLifecycle()
    // v5.4.24 — Backlinks + forward links for the right panel.
    // Refresh whenever the active tab changes.
    var forwardLinks by remember { mutableStateOf<List<com.tebogo.markvault.data.LinkedNote>>(emptyList()) }
    var backLinks by remember { mutableStateOf<List<com.tebogo.markvault.data.LinkedNote>>(emptyList()) }
    LaunchedEffect(activeTab) {
        val id = activeTab
        if (id == null) {
            forwardLinks = emptyList(); backLinks = emptyList()
        } else {
            forwardLinks = runCatching { vm.loadForwardLinks(id) }.getOrElse { emptyList() }
            backLinks = runCatching { vm.loadBacklinks(id) }.getOrElse { emptyList() }
        }
    }
    val drawerState = androidx.compose.material3.rememberDrawerState(
        androidx.compose.material3.DrawerValue.Closed
    )
    val drawerScope = androidx.compose.runtime.rememberCoroutineScope()
    // v5.4.183cc — Scripture detection (reuses drawerScope for coroutine launches)
    val scriptureDetectionOn by vm.scriptureDetectionEnabled.collectAsStateWithLifecycle()

    androidx.compose.foundation.layout.Box(Modifier.fillMaxSize()) {
    androidx.compose.foundation.layout.Box(
        Modifier
            .padding(
                start = if (threeColumn && leftPanelOpen) leftColWidth else 0.dp,
                end = if (threeColumn && rightPanelOpen) rightColWidth else 0.dp
            )
            .fillMaxSize()
    ) {
    androidx.compose.material3.ModalNavigationDrawer(
        drawerState = drawerState,
        // v5.4.24 — Gestures fully off. User's scroll near the left edge
        // was getting intercepted as a drawer-open swipe, halting the
        // article scroll. Toggles happen only via the corner buttons.
        gesturesEnabled = false,
        drawerContent = {
            if (workspaceOn && !workspaceTabletShell) {
                androidx.compose.material3.ModalDrawerSheet {
                    androidx.compose.foundation.layout.Column(
                        Modifier
                            .fillMaxWidth()
                            .padding(16.dp)
                    ) {
                        Text(
                            "\uD83E\uDDF0 Workspace",
                            fontSize = 18.sp,
                            fontWeight = FontWeight.Bold
                        )
                        // v5.4.33 — Toggle between tabs and search results
                        androidx.compose.foundation.layout.Spacer(Modifier.height(8.dp))
                        Row(
                            Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(6.dp)
                        ) {
                            androidx.compose.material3.FilterChip(
                                selected = leftPanelTab == "tabs",
                                onClick = { leftPanelTab = "tabs" },
                                label = { Text("Tabs", fontSize = 12.sp) }
                            )
                            androidx.compose.material3.FilterChip(
                                selected = leftPanelTab == "results",
                                onClick = { leftPanelTab = "results" },
                                label = { Text("Results", fontSize = 12.sp) }
                            )
                        }
                        androidx.compose.foundation.layout.Spacer(Modifier.height(8.dp))
                        if (leftPanelTab == "tabs") {
                        LazyColumn(
                            modifier = Modifier
                                .weight(1f)
                                .fillMaxWidth()
                        ) {
                            items(tabs, key = { it.id }) { tab ->
                                val selected = tab.id == activeTab
                                androidx.compose.material3.NavigationDrawerItem(
                                    label = {
                                        Text(
                                            tab.title,
                                            maxLines = 1,
                                            overflow = TextOverflow.Ellipsis,
                                            fontSize = 14.sp
                                        )
                                    },
                                    selected = selected,
                                    icon = {
                                        Text(
                                            when (tab.fileType) {
                                                "pdf" -> "\uD83D\uDCC4"
                                                "html", "htm" -> "\uD83C\uDF10"
                                                else -> "\uD83D\uDCDD"
                                            }
                                        )
                                    },
                                    badge = {
                                        androidx.compose.material3.IconButton(
                                            onClick = { vm.closeTab(tab.id) },
                                            modifier = Modifier.size(28.dp)
                                        ) {
                                            Icon(
                                                Icons.Default.Close,
                                                contentDescription = "Close tab",
                                                modifier = Modifier.size(14.dp),
                                                tint = MaterialTheme.colorScheme.onSurfaceVariant
                                            )
                                        }
                                    },
                                    onClick = {
                                        switchTab(tab.id)
                                        drawerScope.launch { drawerState.close() }
                                    }
                                )
                            }
                        }
                        } else {
                            // Search results panel
                            Text(
                                "\uD83D\uDD0D ${searchResults.size} result(s) for \"${searchQuery.trim()}\"",
                                fontSize = 11.sp,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                            androidx.compose.foundation.layout.Spacer(Modifier.height(4.dp))
                            LazyColumn(
                                modifier = Modifier.weight(1f).fillMaxWidth()
                            ) {
                                items(searchResults, key = { "dr-${it.id}" }) { hit ->
                                    Surface(
                                        color = Color.Transparent,
                                        shape = RoundedCornerShape(8.dp),
                                        modifier = Modifier
                                            .fillMaxWidth()
                                            .padding(vertical = 2.dp)
                                            .clickable {
                                                drawerScope.launch { drawerState.close() }
                                                vm.openArticle(hit.id, hit.title, fileType = hit.fileType)
                                                when (hit.fileType) {
                                                    "pdf" -> nav.navigate("pdfReader/${hit.id}")
                                                    "mhtml", "html" -> nav.navigate("htmlReader/${hit.id}")
                                                    else -> {} // stays in current reader
                                                }
                                            }
                                    ) {
                                        Text(
                                            hit.title,
                                            Modifier.padding(horizontal = 10.dp, vertical = 8.dp),
                                            fontSize = 13.sp,
                                            maxLines = 2,
                                            overflow = TextOverflow.Ellipsis
                                        )
                                    }
                                }
                            }
                        }
                        androidx.compose.material3.HorizontalDivider(Modifier.padding(vertical = 8.dp))
                        androidx.compose.material3.NavigationDrawerItem(
                            label = { Text("Open a new tab", fontSize = 14.sp) },
                            selected = false,
                            icon = { Icon(Icons.Default.Add, contentDescription = null) },
                            onClick = {
                                drawerScope.launch { drawerState.close() }
                                nav.navigate("home")
                            }
                        )
                    }
                }
            }
        }
    ) {
    Scaffold(
        floatingActionButton = {
            // v5.4.33 — Two compact FABs stacked vertically:
            // 1. Keyword search in article (shows when opened from search)
            // 2. Semantic search in article (shows when semantic toggle is ON)
            val showKeywordFab = openedFromSearchLatched && fabEnabled &&
                currentSearchQuery.trim().removeSurrounding("\"").length >= 2
            val showSemanticFab = semanticInArticleOn &&
                currentSearchQuery.trim().removeSurrounding("\"").length >= 2

            if (showKeywordFab || showSemanticFab) {
                Column(
                    horizontalAlignment = Alignment.End,
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    // Semantic search FAB (top)
                    if (showSemanticFab) {
                        // v5.4.142cc — The brain FAB pulses when bubbles
                        // are active (popup content is waiting). Tapping
                        // while bubbles are present restores the most
                        // recent bubble rather than starting a new search.
                        val mdPopupStateFab by vm.articlePopupState.collectAsStateWithLifecycle()
                        val mdBubblesFab by vm.popupBubbles.collectAsStateWithLifecycle()
                        val fabPulsing: Boolean = mdBubblesFab.isNotEmpty()
                        val fabBusyState: Boolean = fabBusy ||
                            (mdPopupStateFab is com.tebogo.markvault.AppViewModel.ArticlePopupState.Loading)
                        PumpingBrainFab(
                            pulsing = fabPulsing,
                            busy = fabBusyState,
                            onClick = {
                                // If bubbles are present, restore the last one.
                                if (mdBubblesFab.isNotEmpty()) {
                                    vm.restoreBubble(mdBubblesFab.last().id)
                                    return@PumpingBrainFab
                                }
                                val wv = webView ?: return@PumpingBrainFab
                                val rawQ = currentSearchQuery.trim()
                                    .removeSurrounding("\"").trim()
                                if (rawQ.length < 2) return@PumpingBrainFab
                                val nId = note?.id ?: return@PumpingBrainFab
                                // v5.4.144cc — Popup shows ONLY text that is
                                // yellow-highlighted (.term-hit spans/marks).
                                // Extract from the live WebView DOM — no semantic
                                // search needed.
                                vm.setArticlePopupLoading(nId, rawQ)
                                wv.evaluateJavascript(
                                    """(function(){
                                      var els = document.querySelectorAll('mark.term-hit, span.term-hit');
                                      var texts = []; var seen = {};
                                      for (var i = 0; i < els.length && texts.length < 20; i++) {
                                        var t = (els[i].textContent || '').replace(/\s+/g,' ').trim();
                                        if (t.length > 1 && !seen[t]) { seen[t]=1; texts.push(t); }
                                      }
                                      return JSON.stringify(texts);
                                    })()"""
                                ) { result ->
                                    val passages = decodeJsHighlightArray(result)
                                    vm.showArticlePopupWithPassages(nId, rawQ, passages)
                                }
                            }
                        )
                    }
                    // Keyword search FAB (bottom)
                    if (showKeywordFab) {
                        // v5.4.158cc — Press feedback (squish on tap).
                        val keywordFabInteraction = remember { MutableInteractionSource() }
                        androidx.compose.material3.SmallFloatingActionButton(
                            onClick = {
                                val wv = webView ?: return@SmallFloatingActionButton
                                val rawQ = currentSearchQuery.trim()
                                    .removeSurrounding("\"").trim()
                                if (rawQ.length < 2) return@SmallFloatingActionButton
                                findQuery = rawQ
                                showFind = true
                                wv.findAllAsync(rawQ)
                            },
                            interactionSource = keywordFabInteraction,
                            modifier = Modifier.fabPressScale(keywordFabInteraction)
                        ) {
                            Text("\uD83D\uDD0D", fontSize = 16.sp)
                        }
                    }
                }
            }
        },
        topBar = {
            // v5.4.148cc — Instant toolbar show/hide (no animation delay)
            if (toolbarsVisible) {
            TopAppBar(
                navigationIcon = {
                    // v5.4.21 — Workspace hamburger.
                    if (workspaceOn && !workspaceTabletShell) {
                        IconButton(onClick = {
                            drawerScope.launch { drawerState.open() }
                        }) {
                            Icon(
                                Icons.Default.Menu,
                                contentDescription = "Workspace drawer"
                            )
                        }
                    }
                },
                title = {
                    if (tabs.size > 1) {
                        Text(
                            "\uD83D\uDCDA Reader \u00B7 ${tabs.size} tabs",
                            fontSize = 13.sp,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                            maxLines = 1, overflow = TextOverflow.Ellipsis
                        )
                    } else {
                        Text(note?.title ?: "\u2026", maxLines = 1, overflow = TextOverflow.Ellipsis)
                    }
                },
                actions = {
                    // v5.4.22 — Split view button. Workspace-only, and
                    // only when there are 2+ open tabs to split against.
                    // Trigger reuses the existing showSplitPicker path.
                    if (workspaceOn && tabs.size >= 2) {
                        IconButton(onClick = { showSplitPicker = true }) {
                            Text("\u25AF\u25AF", fontSize = 15.sp)
                        }
                    }
                    // v5.4.21 — Workspace outline shortcut. In standard
                    // mode the outline lives in the overflow menu; in
                    // workspace mode we promote it to a top-level
                    // action so it's one tap away.
                    if (workspaceOn) {
                        IconButton(onClick = { showOutline = true }) {
                            Text("\uD83D\uDCD1", fontSize = 18.sp)
                        }
                    }
                    // v5.4.33 — Right hamburger: opens links+backlinks+outline panel.
                    // In three-column mode → toggles the right panel.
                    // In portrait workspace → opens a bottom sheet.
                    if (workspaceOn && !workspaceTabletShell) {
                        IconButton(onClick = { showRightSheet = true }) {
                            Text("\uD83D\uDD17", fontSize = 18.sp)
                        }
                    }
                }
            )
            } // end TopAppBar AnimatedVisibility
        },
        bottomBar = {
            // v5.4.148cc — Instant bottom toolbar show/hide (no animation delay)
            if (toolbarsVisible) {
            // Custom bottom row — too many actions for BottomAppBar's tight layout,
            // so we use a Surface with our own arrangement.
            Surface(color = MaterialTheme.colorScheme.surfaceVariant, shadowElevation = 8.dp) {
                Row(
                    Modifier.fillMaxWidth().padding(horizontal = 2.dp, vertical = 2.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    IconButton(onClick = {
                        val cur = activeTab
                        if (cur != null) {
                            scrollMap[cur] = latestScroll.value
                            vm.saveScroll(cur, latestScroll.value)
                        }
                        if (!vm.goBackInTabs()) nav.popBackStack()
                    }) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back")
                    }
                    TextButton(onClick = { vm.setFontScale((fontScale - 0.1f).coerceIn(0.7f, 2.2f)) }) { Text("A\u2212") }
                    TextButton(onClick = { vm.setFontScale((fontScale + 0.1f).coerceIn(0.7f, 2.2f)) }) { Text("A+") }
                    // v5.4.27 — HTML-only zoom buttons. Only appear when
                    // the current article is a full HTML document (which
                    // bypasses the JS renderMarkdown flow, so A-/A+ don't
                    // affect it). Adjusts WebView.settings.textZoom in
                    // 20%% steps.
                    // v5.4.28 — Range widened to 25%%–300%% so HTML docs
                    // can zoom out further than the previous 50%% floor.
                    if (isHtmlDominant) {
                        TextButton(onClick = {
                            htmlZoom = (htmlZoom - 20).coerceAtLeast(25)
                        }) { Text("\uD83D\uDD0D\u2212") }
                        TextButton(onClick = {
                            htmlZoom = (htmlZoom + 20).coerceAtMost(300)
                        }) { Text("\uD83D\uDD0D+") }
                    }
                    if (tabs.size > 1) {
                        IconButton(onClick = { vm.switchTabByDirection(forward = false) }) {
                            Icon(Icons.AutoMirrored.Filled.KeyboardArrowLeft,
                                contentDescription = "Previous tab")
                        }
                        IconButton(onClick = { vm.switchTabByDirection(forward = true) }) {
                            Icon(Icons.AutoMirrored.Filled.KeyboardArrowRight,
                                contentDescription = "Next tab")
                        }
                        IconButton(onClick = { showTabGrid = true }) {
                            Icon(Icons.Default.Menu,
                                contentDescription = "All tabs (${tabs.size})")
                        }
                    }
                    IconButton(onClick = { showFind = !showFind; if (!showFind) webView?.clearMatches() }) {
                        Icon(Icons.Default.Search, contentDescription = "Find in note")
                    }
                    androidx.compose.foundation.layout.Spacer(Modifier.weight(1f))
                    if (relatedVideos.isNotEmpty()) {
                        IconButton(onClick = { showRelatedVideos = true }) { Text("🎬", fontSize = 18.sp) }
                    }
                    // v5.4.97cc — Toolbar de-cramming. The 🎨 palette and
                    // ✨ chat-summarize buttons that used to live here
                    // were pushing the ⋮ overflow menu off the right
                    // edge on phone widths (both standard and workspace
                    // mode showed the same clipping). Both actions have
                    // been moved into the ⋮ menu below — 🎨 was already
                    // duplicated there ("🎨 Theme…"), and a new "✨
                    // Summarise with chat" item covers the summarizer.
                    // The 🌐 browser button stays because it's the
                    // most-used action on jw.org research sessions.
                    // v4.2 — browser button on Reader bottom toolbar too
                    IconButton(onClick = {
                        val encUrl = java.net.URLEncoder.encode("https://www.jw.org", "UTF-8")
                        val encLabel = java.net.URLEncoder.encode("jw.org", "UTF-8")
                        nav.navigate("web/$encUrl/$encLabel") { launchSingleTop = true }
                    }) {
                        Text("\uD83C\uDF10", fontSize = 18.sp)
                    }
                    HomeButton(nav)
                    Box {
                        IconButton(onClick = { menuOpen = true }) {
                            Icon(Icons.Default.MoreVert, contentDescription = "More")
                        }
                        DropdownMenu(expanded = menuOpen, onDismissRequest = { menuOpen = false }) {
                            DropdownMenuItem(
                                text = { Text("\uD83D\uDD0D Search library") },
                                onClick = { menuOpen = false; nav.navigate("search") }
                            )
                            DropdownMenuItem(
                                text = { Text("\uD83D\uDCDC PDF history") },
                                onClick = { menuOpen = false; nav.navigate("pdfHistory") }
                            )
                            DropdownMenuItem(
                                text = { Text("\uD83D\uDD52 Web history") },
                                onClick = { menuOpen = false; nav.navigate("webHistory") }
                            )
                            DropdownMenuItem(
                                text = { Text("\uD83D\uDD16 Bookmarks") },
                                onClick = { menuOpen = false; nav.navigate("webBookmarks") }
                            )
                            DropdownMenuItem(
                                text = { Text("\u2699\uFE0F Settings") },
                                onClick = { menuOpen = false; nav.navigate("settings") }
                            )
                            HorizontalDivider()
                            DropdownMenuItem(
                                text = { Text("\uD83E\uDDED Outline") },
                                onClick = { menuOpen = false; showOutline = true }
                            )
                            DropdownMenuItem(
                                text = { Text("\uD83D\uDD17 Links & backlinks") },
                                onClick = { menuOpen = false; showBacklinks = true }
                            )
                            DropdownMenuItem(
                                text = { Text("\uD83D\uDCD6 Scripture context") },
                                onClick = { menuOpen = false; showScripturePanel = true }
                            )
                            DropdownMenuItem(
                                text = { Text("\uD83E\uDE9F Open in split view\u2026") },
                                onClick = { menuOpen = false; showSplitPicker = true }
                            )
                            DropdownMenuItem(
                                text = { Text("\uD83C\uDF10 Graph from this note") },
                                onClick = {
                                    menuOpen = false
                                    val cur = activeTab
                                    if (cur != null) {
                                        scrollMap[cur] = latestScroll.value
                                        vm.saveScroll(cur, latestScroll.value)
                                    }
                                    note?.id?.let { nav.navigate("graph/$it") }
                                }
                            )
                            DropdownMenuItem(
                                text = { Text("\uD83C\uDFA8 Theme\u2026") },
                                onClick = { menuOpen = false; themeMenuOpen = true }
                            )
                            // v5.4.97cc — Summarise via on-device chat.
                            // Moved from the bottom toolbar (where it was
                            // crowding the ⋮ off the right edge) into the
                            // menu. Same conditional visibility as before:
                            // shown only when the chat model is installed,
                            // otherwise tapping would just produce an
                            // error banner.
                            val chatReadyForMenu by vm.chatModelInstalled.collectAsStateWithLifecycle()
                            if (chatReadyForMenu) {
                                DropdownMenuItem(
                                    text = { Text("\u2728 Summarise with chat") },
                                    onClick = {
                                        menuOpen = false
                                        val id = activeTab
                                        if (id != null) {
                                            val ft = tabs.firstOrNull { it.id == id }?.fileType ?: "md"
                                            vm.summarizeNote(id, ft)
                                            nav.navigate("chat") { launchSingleTop = true }
                                        }
                                    }
                                )
                            }
                            DropdownMenuItem(
                                text = { Text("\u2B06\uFE0F Collapse all boxes") },
                                onClick = { menuOpen = false; webView?.evaluateJavascript("collapseAllCallouts();", null) }
                            )
                            DropdownMenuItem(
                                text = { Text("\u2B07\uFE0F Expand all boxes") },
                                onClick = { menuOpen = false; webView?.evaluateJavascript("expandAllCallouts();", null) }
                            )
                            HorizontalDivider()
                            val isFav = note?.id?.let { it in favouriteIds } ?: false
                            DropdownMenuItem(
                                text = { Text(if (isFav) "\uD83D\uDC94 Remove from favourites" else "\u2B50 Add to favourites") },
                                onClick = {
                                    menuOpen = false
                                    note?.id?.let { vm.toggleFavourite(it) }
                                }
                            )
                            DropdownMenuItem(
                                text = { Text("\uD83D\uDCCB Copy text") },
                                onClick = {
                                    menuOpen = false
                                    note?.content?.let {
                                        clipboard.setText(AnnotatedString(it))
                                        Toast.makeText(ctx, "Copied", Toast.LENGTH_SHORT).show()
                                    }
                                }
                            )
                            DropdownMenuItem(
                                text = { Text("\uD83D\uDDA8\uFE0F Print / PDF\u2026") },
                                onClick = {
                                    menuOpen = false
                                    showPrintSheet = true
                                }
                            )
                            DropdownMenuItem(
                                text = { Text("\uD83D\uDD17 Share") },
                                onClick = {
                                    menuOpen = false
                                    note?.let {
                                        val send = Intent(Intent.ACTION_SEND).apply {
                                            type = "text/plain"
                                            putExtra(Intent.EXTRA_SUBJECT, it.title)
                                            putExtra(Intent.EXTRA_TEXT, it.content)
                                        }
                                        ctx.startActivity(Intent.createChooser(send, "Share note"))
                                    }
                                }
                            )
                        }
                        DropdownMenu(expanded = themeMenuOpen, onDismissRequest = { themeMenuOpen = false }) {
                            listOf(
                                "dark" to "\uD83C\uDF11 Dark",
                                "black" to "\u26AB AMOLED black",
                                "hicontrast-dark" to "\u26A1 High-contrast dark",
                                "obsidian" to "\uD83E\uDEA8 Obsidian",
                                "glass_obsidian" to "🧊 3D Obsidian Glass",
                                "glass_crystal" to "💎 3D Crystal Glass",
                                "artifact_parchment" to "📜 Illuminated Parchment",
                                "artifact_vellum" to "✒️ Vellum Manuscript",
                                "artifact_stone" to "🪨 Limestone Tablet",
                                "artifact_papyrus" to "🌾 Papyrus Archive",
                                "artifact_marble" to "🏛️ Marble Codex",
                                "ocean" to "\uD83C\uDF0A Ocean",
                                "forest" to "\uD83C\uDF32 Forest",
                                "sepia" to "\uD83D\uDCDC Sepia",
                                "dark_sepia" to "\uD83D\uDCDC Dark sepia",
                                "cream" to "\u2615 Cream",
                                "light_grey" to "\uD83E\uDEA8 Light grey",
                                "grey" to "\u2B1C Grey",
                                "sky_blue" to "\uD83C\uDF24 Sky blue",
                                "light" to "\u2600\uFE0F Light",
                                "hicontrast-light" to "\u26A1 High-contrast light",
                                "expr_indigo" to "\uD83D\uDD8B\uFE0F Expressive indigo",
                                "expr_violet" to "\uD83D\uDD2E Expressive violet",
                                "expr_ember" to "\uD83D\uDD25 Expressive ember",
                                "expr_rose" to "\uD83C\uDF39 Expressive rose",
                                "custom" to "\uD83C\uDFA8 Custom"
                            ).forEach { pair ->
                                DropdownMenuItem(
                                    text = { Text(pair.second + if (theme == pair.first) "  \u2713" else "") },
                                    onClick = { themeMenuOpen = false; vm.setTheme(pair.first) }
                                )
                            }
                            HorizontalDivider()
                            DropdownMenuItem(
                                text = { Text("\uD83C\uDFA8 Theme creator\u2026") },
                                onClick = { themeMenuOpen = false; showThemeCreator = true }
                            )
                        }
                    }
                }
            }
            } // end bottomBar AnimatedVisibility
        }
    ) { pad ->
        // v5.4.147cc — Preserve status bar space in fullscreen mode
        val statusBarTopPadding = if (enableFullscreenMode && !toolbarsVisible) 24.dp else 0.dp
        Column(Modifier.padding(pad).padding(top = statusBarTopPadding).fillMaxSize()) {

            // v5.4.20 — Tab strip visibility rule.
            //   Standard mode → show only when 2+ tabs (existing behaviour).
            //   Workspace mode → always show, so the workspace look stays
            //     consistent and the + button is always reachable.
            // v5.4.25 — At tablet width, the left panel already shows a
            // vertical tab list, so this horizontal strip is redundant.
            val showTabStrip = (tabs.size > 1 || (workspaceOn && tabs.isNotEmpty())) && !threeColumn && !workspaceTabletShell

            if (showTabStrip) {
                // v5.4.147cc — Reorder tabs so active tab is ALWAYS first (leftmost)
                val reorderedTabs = remember(tabs, activeTab) {
                    val active = tabs.find { it.id == activeTab }
                    if (active != null) {
                        listOf(active) + tabs.filter { it.id != activeTab }
                    } else {
                        tabs.toList()
                    }
                }
                // v5.4.147cc — Color palette for tab distinction
                val readerTabColors = listOf(
                    Color(0xFF6D4C41),  // Brown
                    Color(0xFF455A64),  // Blue-grey
                    Color(0xFF558B2F),  // Green
                    Color(0xFF6A1B9A),  // Purple
                    Color(0xFFD84315),  // Orange-red
                    Color(0xFF00838F)   // Teal
                )
                // v5.4.168cc — Battery fix. Was `rememberInfiniteTransition`
                // continuously flashing alpha between 0.25 and 0.55 forever,
                // for as long as showTabStrip was true (i.e. whenever more
                // than one reader tab was open) — a real, ongoing animation
                // cost for multi-tab users with no functional need: marking
                // the active tab doesn't require continuous flashing, just
                // being visually distinct. Replaced with a fixed alpha at
                // the old range's midpoint. The animateColorAsState below
                // still smoothly cross-fades WHEN the selected tab changes
                // (a one-time transition) — only the continuous, indefinite
                // pulsing while a tab stays selected is gone.
                val pulseAlpha = 0.4f
                Row(
                    Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    LazyRow(
                        Modifier.weight(1f).padding(vertical = 4.dp),
                        horizontalArrangement = Arrangement.spacedBy(6.dp),
                    contentPadding = PaddingValues(horizontal = 8.dp)
                ) {
                    items(reorderedTabs, key = { it.id }) { tab ->
                        val selected = tab.id == activeTab
                        // v5.4.147cc — Color based on ORIGINAL position for stable identity
                        val originalIdx = tabs.indexOfFirst { it.id == tab.id }.coerceAtLeast(0)
                        val tabColor = readerTabColors[originalIdx % readerTabColors.size]
                        // v5.4.159cc — Cross-fade background + border color instead of an
                        // instant snap when a tab becomes active/inactive.
                        val animatedBg by animateColorAsState(
                            targetValue = if (selected) MaterialTheme.colorScheme.primary.copy(alpha = pulseAlpha)
                                else tabColor.copy(alpha = 0.35f),
                            animationSpec = tween(220),
                            label = "tabBgColor"
                        )
                        val animatedBorderColor by animateColorAsState(
                            targetValue = if (selected) MaterialTheme.colorScheme.primary else tabColor,
                            animationSpec = tween(220),
                            label = "tabBorderColor"
                        )
                        Surface(
                            color = animatedBg,
                            shape = RoundedCornerShape(8.dp),
                            border = androidx.compose.foundation.BorderStroke(
                                if (selected) 2.dp else 1.dp,
                                animatedBorderColor
                            ),
                            // v5.4.159cc — Slides tabs smoothly to their new position
                            // when reorderedTabs puts a newly-active tab first, instead
                            // of an instant jump. Requires LazyItemScope, which this
                            // items(reorderedTabs) block already provides.
                            modifier = Modifier
                                .animateItem()
                                .clickable { switchTab(tab.id) }
                        ) {
                            Row(
                                Modifier.padding(start = 12.dp, end = 4.dp, top = 6.dp, bottom = 6.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text(
                                    tab.title,
                                    modifier = Modifier.widthIn(max = 150.dp),
                                    maxLines = 1, overflow = TextOverflow.Ellipsis,
                                    fontSize = 13.sp,
                                    fontWeight = if (selected) FontWeight.SemiBold else FontWeight.Normal,
                                    color = if (selected) MaterialTheme.colorScheme.onSurface
                                    else MaterialTheme.colorScheme.onSurfaceVariant
                                )
                                IconButton(onClick = { vm.closeTab(tab.id) }, modifier = Modifier.size(28.dp)) {
                                    Icon(
                                        Icons.Default.Close, contentDescription = "Close tab",
                                        modifier = Modifier.size(15.dp),
                                        tint = MaterialTheme.colorScheme.onSurfaceVariant
                                    )
                                }
                            }
                        }
                    }
                    }
                    // v5.4.20 — "+" button only in workspace mode. Pops back
                    // to Home so the user can pick another article to open
                    // in a new tab. Standard mode never shows this to keep
                    // the phone UX minimal.
                    if (workspaceOn) {
                        IconButton(
                            onClick = { nav.navigate("home") },
                            modifier = Modifier.size(36.dp).padding(end = 4.dp)
                        ) {
                            Icon(
                                Icons.Default.Add,
                                contentDescription = "Open a new tab",
                                tint = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    }
                }
                HorizontalDivider(color = MaterialTheme.colorScheme.surfaceVariant)
            }

            if (showFind) {
                Surface(color = MaterialTheme.colorScheme.surfaceVariant) {
                    Row(
                        Modifier.fillMaxWidth().padding(horizontal = 8.dp, vertical = 4.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        TextField(
                            value = findQuery,
                            onValueChange = {
                                findQuery = it
                                val wv = webView
                                if (wv != null) {
                                    if (it.isBlank()) { wv.clearMatches(); matchCount = 0 }
                                    else wv.findAllAsync(it)
                                }
                            },
                            modifier = Modifier.weight(1f).focusRequester(findFocus),
                            singleLine = true,
                            placeholder = { Text("Find in this note\u2026") },
                            colors = TextFieldDefaults.colors(
                                focusedContainerColor = Color.Transparent,
                                unfocusedContainerColor = Color.Transparent
                            )
                        )
                        Text(
                            if (matchCount > 0) "${activeMatch + 1}/$matchCount" else "0/0",
                            fontSize = 12.sp,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                            modifier = Modifier.padding(horizontal = 6.dp)
                        )
                        IconButton(onClick = { webView?.findNext(false) }) {
                            Icon(Icons.Default.KeyboardArrowUp, contentDescription = "Previous")
                        }
                        IconButton(onClick = { webView?.findNext(true) }) {
                            Icon(Icons.Default.KeyboardArrowDown, contentDescription = "Next")
                        }
                        IconButton(onClick = {
                            showFind = false; findQuery = ""; webView?.clearMatches(); matchCount = 0
                        }) {
                            Icon(Icons.Default.Close, contentDescription = "Close find")
                        }
                    }
                }
                LaunchedEffect(Unit) { findFocus.requestFocus() }
            }

            Box(Modifier.fillMaxSize()) {
                AndroidView(
                    modifier = Modifier.fillMaxSize(),
                    factory = { c ->
                        // v4.12.0 — switch from raw WebView to SelectionWebView so
                        // the markdown reader gets the same custom text-selection
                        // menu (Search in MarkVault / wol.jw.org / jw.org / Share)
                        // that the in-app browser already has. Same class, same
                        // behaviour; only the constructor changed.
                        SelectionWebView(c).apply {
                            // Wire the four selection-menu callbacks.
                            onSearchInMarkVault = { selectedText ->
                                vm.requestPendingSearch(selectedText)
                                nav.navigate("search") { launchSingleTop = true }
                            }
                            onSearchInWol = { selectedText ->
                                val target = "https://wol.jw.org/en/wol/s/r1/lp-e?q=" +
                                    java.net.URLEncoder.encode(selectedText, "UTF-8")
                                val encUrl = java.net.URLEncoder.encode(target, "UTF-8")
                                val encLabel = java.net.URLEncoder.encode("wol.jw.org", "UTF-8")
                                nav.navigate("web/$encUrl/$encLabel") {
                                    launchSingleTop = true
                                }
                            }
                            onSearchInJwOrg = { selectedText ->
                                val target = "https://www.jw.org/en/search/?q=" +
                                    java.net.URLEncoder.encode(selectedText, "UTF-8")
                                val encUrl = java.net.URLEncoder.encode(target, "UTF-8")
                                val encLabel = java.net.URLEncoder.encode("jw.org", "UTF-8")
                                nav.navigate("web/$encUrl/$encLabel") {
                                    launchSingleTop = true
                                }
                            }
                            // onShare left null — fallbackShare() inside
                            // SelectionWebView handles it via ACTION_SEND.
                            setBackgroundColor(bg)
                            settings.javaScriptEnabled = true
                            settings.allowFileAccess = true
                            settings.domStorageEnabled = true
                            settings.loadsImagesAutomatically = true
                            settings.mixedContentMode = WebSettings.MIXED_CONTENT_COMPATIBILITY_MODE
                            setFindListener { active, count, _ -> matchCount = count; activeMatch = active }
                            // v5.4.155cc — scroll listener moved to update lambda
                            // Long-press on an <a> → bottom-sheet with Copy URL / Copy text / Share / Open in browser.
                            // Long-press on plain text falls through to the system text-selection UI.
                            setOnLongClickListener { _ ->
                                val hit = hitTestResult
                                val type = hit.type
                                val anchor = type == WebView.HitTestResult.SRC_ANCHOR_TYPE ||
                                    type == WebView.HitTestResult.SRC_IMAGE_ANCHOR_TYPE
                                if (!anchor) return@setOnLongClickListener false
                                val url = hit.extra ?: return@setOnLongClickListener false
                                // Ignore internal wikilinks — they have their own tap behavior already
                                // Wikilink long-press → open the Peek bottom sheet for that note.
                                // The mv://<id> scheme carries the target note id; we parse it
                                // and hand off to the @Composable state below to render the preview.
                                if (url.startsWith("mv://")) {
                                    val targetId = url.removePrefix("mv://").toLongOrNull()
                                    if (targetId != null) peekNoteId = targetId
                                    return@setOnLongClickListener true
                                }
                                // Look up the visible link text via a tiny JS query.
                                // (Escape the URL for safe embedding in the JS string literal.)
                                val esc = url
                                    .replace("\\", "\\\\")
                                    .replace("'", "\\'")
                                    .replace("\n", "\\n")
                                    .replace("\r", "\\r")
                                evaluateJavascript(
                                    "(function(){var as=document.querySelectorAll('a');" +
                                    "for(var i=0;i<as.length;i++){if(as[i].href==='$esc')" +
                                    "return as[i].textContent.replace(/\\s+/g,' ').trim();}return '';})();"
                                ) { result ->
                                    // result comes back as a JSON-encoded string ("..." or null)
                                    val text = if (result == null || result == "null") ""
                                        else result.trim().removeSurrounding("\"")
                                            .replace("\\\"", "\"").replace("\\\\", "\\")
                                    linkLongPress = LinkPressData(url, text)
                                }
                                true  // consume the long-press; suppresses default text-selection UI
                            }
                            webViewClient = object : WebViewClient() {
                                override fun onPageFinished(view: WebView?, url: String?) {
                                    pageReady = true
                                    // v5.4.182cc — Scripture detection JS injection.
                                    // Runs after viewer.html finishes loading the markdown
                                    // HTML so text nodes are fully present in the DOM.
                                    if (view != null && scriptureDetectionOn) {
                                        view.postDelayed({
                                            view.evaluateJavascript(
                                                com.tebogo.markvault.util.ScriptureDetector
                                                    .scriptureDetectionJs,
                                                null
                                            )
                                        }, 300L)
                                    }
                                    // v5.4.182cc — Verse anchor highlight (when arriving
                                    // from a scripture link in another article).
                                    val scriptureAnchor = vm.consumePendingScriptureAnchor()
                                    if (view != null && !scriptureAnchor.isNullOrBlank()) {
                                        view.postDelayed({
                                            view.evaluateJavascript(
                                                com.tebogo.markvault.util.ScriptureDetector
                                                    .verseHighlightJs
                                                    .replace("__ANCHOR__", scriptureAnchor),
                                                null
                                            )
                                        }, 450L)
                                    }
                                }
                                override fun shouldOverrideUrlLoading(
                                    view: WebView?, request: WebResourceRequest?
                                ): Boolean {
                                    val uri = request?.url ?: return false
                                    if (uri.scheme == "file") return false
                                    // v5.4.205cc — Handle scripture detection links.
                                    // verseRef may be "14", "7-9", "8,10", "7-9,12".
                                    val scrParsed = com.tebogo.markvault.util.ScriptureDetector
                                        .parseScriptureUri(uri)
                                    if (scrParsed != null) {
                                        val (bn, ch, verseRef) = scrParsed
                                        val anchors = com.tebogo.markvault.util.ScriptureDetector
                                            .buildVerseAnchors(bn, ch, verseRef)
                                        val anchorStr = anchors.joinToString(",")
                                        drawerScope.launch {
                                            val noteId = vm.findNwtNoteId(bn, ch)
                                            if (noteId != null) {
                                                vm.setPendingScriptureAnchor(anchorStr)
                                                nav.navigate("htmlReader/$noteId")
                                            } else {
                                                val firstVs = com.tebogo.markvault.util.ScriptureDetector
                                                    .firstVerseOf(verseRef)
                                                val code = "%02d%03d%03d".format(bn, ch, firstVs)
                                                val url = "https://www.jw.org/finder?srcid=jwlshare" +
                                                    "&wtlocale=E&prefer=lang&bible=$code&pub=nwtsty"
                                                vm.requestWebPopup(url)
                                            }
                                        }
                                        return true
                                    }
                                    // Intercept wikilink taps: mv://wiki/<URL-encoded target>
                                    if (uri.scheme == "mv" && uri.host == "wiki") {
                                        val target = uri.lastPathSegment ?: uri.schemeSpecificPart
                                            ?.removePrefix("//wiki/")
                                        if (!target.isNullOrBlank()) {
                                            wikilinkTap = target
                                        }
                                        return true
                                    }
                                    // External link routing
                                    // v5.4.37 — Use shared JW Library routing
                                    // utility (with expanded jw.org/finder
                                    // detection and WOL→finder conversion).
                                    when (com.tebogo.markvault.util.routeLink(uri)) {
                                        com.tebogo.markvault.util.LinkTarget.JW_LIBRARY_APP -> {
                                            com.tebogo.markvault.util.openInJwLibrary(ctx, uri) {
                                                // No JW Library installed → fall back to in-app popup
                                                vm.requestWebPopup(uri.toString())
                                            }
                                        }
                                        com.tebogo.markvault.util.LinkTarget.IN_APP_WEBVIEW -> {
                                            vm.requestWebPopup(uri.toString())
                                        }
                                        com.tebogo.markvault.util.LinkTarget.SYSTEM_BROWSER -> {
                                            com.tebogo.markvault.util.openExternally(ctx, uri)
                                        }
                                    }
                                    return true
                                }
                            }
                            loadUrl("file:///android_asset/viewer.html")
                            webView = this
                        }
                    },
                    // v5.4.155cc — Scroll-to-hide moved here from LaunchedEffect.
                    // Re-runs on every recomposition so the listener always
                    // captures the current enableFullscreenMode / toolbarsVisible.
                    // Mirrors the pattern used in WebSearchScreen (which works).
                    update = { w ->
                        if (enableFullscreenMode) {
                            w.setOnScrollChangeListener { _, _, scrollY, _, _ ->
                                latestScroll.value = scrollY
                                val id = activeTab
                                if (id != null) scrollMap[id] = scrollY

                                val scrollDelta = scrollY - lastScrollValue
                                if (scrollDelta > 20 && toolbarsVisible) {
                                    toolbarsVisible = false
                                    lastScrollValue = scrollY
                                } else if (scrollDelta < -3 && !toolbarsVisible) {
                                    toolbarsVisible = true
                                    lastScrollValue = scrollY
                                } else if (kotlin.math.abs(scrollDelta) < 2) {
                                    lastScrollValue = scrollY
                                }
                                // Dead zone 2-20px going down: ignore
                            }
                        } else {
                            toolbarsVisible = true
                            lastScrollValue = latestScroll.value
                            w.setOnScrollChangeListener { _, _, scrollY, _, _ ->
                                latestScroll.value = scrollY
                                val id = activeTab
                                if (id != null) scrollMap[id] = scrollY
                            }
                        }
                    }
                )

                // v5.4.181cc — "Jump to top" for long articles. Reuses the
                // existing webView reference and latestScroll tracking
                // (both already set up for the v5.4.156cc scroll-to-hide
                // toolbar work) — no new capture logic needed. scrollTo(0,0)
                // is the plain View method (guaranteed public on WebView,
                // unlike smoothScrollTo which isn't reliably public), so
                // this is an instant jump rather than an animated one.
                // Positioned bottom-start to avoid the Scaffold FAB slot
                // (bottom-end) and the edge-swipe zones (center-start/end).
                if (latestScroll.value > 400) {
                    Surface(
                        color = MaterialTheme.colorScheme.secondaryContainer.copy(alpha = 0.95f),
                        shape = RoundedCornerShape(16.dp),
                        shadowElevation = 4.dp,
                        modifier = Modifier
                            .align(Alignment.BottomStart)
                            .padding(start = 16.dp, bottom = 16.dp)
                            .clickable { webView?.scrollTo(0, 0) }
                    ) {
                        Text(
                            "🔝 Top",
                            color = MaterialTheme.colorScheme.onSecondaryContainer,
                            fontWeight = FontWeight.SemiBold,
                            fontSize = 13.sp,
                            modifier = Modifier.padding(horizontal = 14.dp, vertical = 10.dp)
                        )
                    }
                }

                // Edge-swipe zones for tab switching. These are narrow (28dp) overlays at
                // the very left and right edges. The vast majority of the screen has zero
                // pointer interception — scrolling stays buttery smooth — while users still
                // get the swipe gesture they expect from a browser-like reader.
                if (swipeSwitchTabs && tabs.size > 1) {
                    Box(
                        Modifier
                            .align(Alignment.CenterStart)
                            .fillMaxHeight()
                            .width(28.dp)
                            .pointerInput(tabs.size) {
                                var totalDx = 0f
                                detectHorizontalDragGestures(
                                    onDragStart = { totalDx = 0f },
                                    onDragEnd = {
                                        // Swipe inward from left edge → previous tab
                                        if (totalDx > 60.dp.toPx()) {
                                            vm.switchTabByDirection(forward = false)
                                        }
                                        totalDx = 0f
                                    },
                                    onDragCancel = { totalDx = 0f }
                                ) { _, dragAmount -> totalDx += dragAmount }
                            }
                    )
                    Box(
                        Modifier
                            .align(Alignment.CenterEnd)
                            .fillMaxHeight()
                            .width(28.dp)
                            .pointerInput(tabs.size) {
                                var totalDx = 0f
                                detectHorizontalDragGestures(
                                    onDragStart = { totalDx = 0f },
                                    onDragEnd = {
                                        // Swipe inward from right edge → next tab
                                        if (totalDx < -60.dp.toPx()) {
                                            vm.switchTabByDirection(forward = true)
                                        }
                                        totalDx = 0f
                                    },
                                    onDragCancel = { totalDx = 0f }
                                ) { _, dragAmount -> totalDx += dragAmount }
                            }
                    )
                }
            }
        }
    }

    if (showRelatedVideos) {
        Box(Modifier.fillMaxSize().padding(12.dp), contentAlignment = Alignment.BottomCenter) {
            RelatedVideosCarousel(
                vm, relatedVideos,
                onClose = { showRelatedVideos = false },
                onPlayVideo = { match ->
                    vm.playMedia(match.item)
                    relatedVideoPopup = match.item
                }
            )
        }
    }

    relatedVideoPopup?.let { media ->
        FloatingMediaPopup(
            vm = vm, title = media.title, url = media.streamUrl, mediaType = media.mediaType,
            onDismiss = { relatedVideoPopup = null },
            onOpenFullPlayer = { relatedVideoPopup = null; nav.navigate("mediaPlayer/0") { launchSingleTop = true } }
        )
    }

    if (showOutline) {
        ModalBottomSheet(onDismissRequest = { showOutline = false }) {
            Text(
                "\uD83E\uDDED Outline",
                Modifier.padding(start = 20.dp, top = 4.dp, bottom = 8.dp),
                fontWeight = FontWeight.Bold, fontSize = 16.sp
            )
            if (outline.isEmpty()) {
                Text(
                    "No headings in this note.",
                    Modifier.padding(20.dp),
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            } else {
                LazyColumn(Modifier.fillMaxWidth().heightIn(max = 460.dp)) {
                    items(outline) { item: OutlineItem ->
                        Text(
                            item.title,
                            Modifier
                                .fillMaxWidth()
                                .clickable {
                                    webView?.evaluateJavascript(
                                        "document.getElementById('sec-${item.index}')?." +
                                            "scrollIntoView({behavior:'smooth',block:'start'});",
                                        null
                                    )
                                    showOutline = false
                                }
                                .padding(
                                    start = (16 + (item.level - 1) * 14).dp,
                                    end = 16.dp, top = 11.dp, bottom = 11.dp
                                ),
                            fontSize = if (item.level <= 2) 15.sp else 13.sp,
                            fontWeight = if (item.level <= 2) FontWeight.SemiBold else FontWeight.Normal,
                            color = if (item.level <= 2) MaterialTheme.colorScheme.onSurface
                            else MaterialTheme.colorScheme.onSurfaceVariant,
                            maxLines = 2, overflow = TextOverflow.Ellipsis
                        )
                    }
                    item { Spacer(Modifier.height(24.dp)) }
                }
            }
        }
    }

    if (showScripturePanel) {
        // Extract scripture references + their contexts lazily — only when opened
        val items = remember(note?.id, note?.content) {
            extractScriptureContexts(note?.content.orEmpty())
        }
        ScriptureContextDialog(
            items = items,
            onDismiss = { showScripturePanel = false },
            onScriptureTap = { ref ->
                showScripturePanel = false
                // Hand off to the existing scripture popup pipeline — it knows how
                // to translate "Matthew 24:14" into a jw.org Bible URL.
                vm.requestWebPopup(buildJwScriptureUrl(ref))
            }
        )
    }

    // Feature 3: Split view picker — choose another open tab to pair with this one.
    if (showSplitPicker) {
        SplitViewPickerDialog(
            currentId = note?.id ?: -1L,
            tabs = tabs,
            onDismiss = { showSplitPicker = false },
            onPick = { otherId ->
                showSplitPicker = false
                val curId = note?.id
                if (curId != null) {
                    // Save current scroll before leaving the single-pane reader
                    val cur = activeTab
                    if (cur != null) {
                        scrollMap[cur] = latestScroll.value
                        vm.saveScroll(cur, latestScroll.value)
                    }
                    nav.navigate("splitReader/$curId/md/$otherId/md")
                }
            }
        )
    }

    // Feature 2: Press-and-hold Peek — when a wikilink is long-pressed in the
    // article, the long-click listener sets peekNoteId. We load that note here
    // and render a lightweight preview without leaving the active reader.
    peekNoteId?.let { targetId ->
        var peekNote by remember(targetId) { mutableStateOf<com.tebogo.markvault.data.Note?>(null) }
        var peekLoading by remember(targetId) { mutableStateOf(true) }
        LaunchedEffect(targetId) {
            peekLoading = true
            peekNote = vm.loadNote(targetId)
            peekLoading = false
        }
        ModalBottomSheet(onDismissRequest = { peekNoteId = null }) {
            Column(Modifier.fillMaxWidth().padding(start = 18.dp, end = 12.dp, bottom = 16.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(
                        "\uD83D\uDC41\uFE0F Peek",
                        fontSize = 13.sp,
                        fontWeight = FontWeight.SemiBold,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                    Spacer(Modifier.weight(1f))
                    // "Open" button — close peek and navigate to the full reader for this note
                    TextButton(onClick = {
                        val n = peekNote
                        peekNoteId = null
                        if (n != null) {
                            // Save current scroll before opening another note in this tab
                            val cur = activeTab
                            if (cur != null) {
                                scrollMap[cur] = latestScroll.value
                                vm.saveScroll(cur, latestScroll.value)
                            }
                            vm.openArticle(
                                n.id, n.title,
                                source = com.tebogo.markvault.OpenSource.LINK
                            )
                        }
                    }) {
                        Text("Open \u2197", fontWeight = FontWeight.Medium)
                    }
                }
                Spacer(Modifier.height(4.dp))
                when {
                    peekLoading -> Box(
                        Modifier.fillMaxWidth().heightIn(min = 120.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        Text("Loading\u2026", color = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                    peekNote == null -> Box(
                        Modifier.fillMaxWidth().heightIn(min = 120.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        Text(
                            "Couldn't load this note.",
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                    else -> {
                        val n = peekNote!!
                        Text(
                            n.title,
                            fontSize = 18.sp,
                            fontWeight = FontWeight.Bold,
                            maxLines = 2,
                            overflow = TextOverflow.Ellipsis
                        )
                        Spacer(Modifier.height(8.dp))
                        // Show ~1500 chars of cleaned content as a quick scrollable preview.
                        // Plain text only — full markdown rendering would need a second WebView
                        // which is too heavy for a "quick peek". This still gives the gist.
                        val previewText = remember(n.id, n.content) {
                            buildPeekPreview(n.content)
                        }
                        Column(
                            Modifier
                                .heightIn(max = 380.dp)
                                .verticalScroll(rememberScrollState())
                        ) {
                            Text(
                                previewText,
                                fontSize = 14.sp,
                                lineHeight = 20.sp,
                                color = MaterialTheme.colorScheme.onSurface
                            )
                            if (n.content.length > 1500) {
                                Spacer(Modifier.height(8.dp))
                                Text(
                                    "\u2026 (tap Open to see the rest)",
                                    fontSize = 12.sp,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }
                        }
                    }
                }
            }
        }
    }

    // v5.4.33 — Right panel bottom sheet for portrait workspace mode.
    // Shows outline + links + backlinks in one scrollable sheet.
    if (showRightSheet) {
        ModalBottomSheet(onDismissRequest = { showRightSheet = false }) {
            LazyColumn(
                Modifier.fillMaxWidth().heightIn(max = 540.dp),
                contentPadding = PaddingValues(horizontal = 16.dp, vertical = 8.dp)
            ) {
                // Outline
                item {
                    Text(
                        "\uD83D\uDCD1 Outline (${outline.size})",
                        fontSize = 14.sp,
                        fontWeight = FontWeight.Bold,
                        modifier = Modifier.padding(bottom = 6.dp)
                    )
                }
                if (outline.isEmpty()) {
                    item {
                        Text("No headings.", fontSize = 12.sp,
                            color = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                } else {
                    items(outline) { item: OutlineItem ->
                        Text(
                            item.title,
                            Modifier
                                .fillMaxWidth()
                                .clickable {
                                    webView?.evaluateJavascript(
                                        "document.getElementById('sec-${item.index}')?." +
                                            "scrollIntoView({behavior:'smooth',block:'start'});",
                                        null
                                    )
                                    showRightSheet = false
                                }
                                .padding(
                                    start = ((item.level - 1) * 12).dp,
                                    top = 8.dp, bottom = 8.dp
                                ),
                            fontSize = if (item.level <= 2) 14.sp else 12.sp,
                            fontWeight = if (item.level <= 2) FontWeight.SemiBold else FontWeight.Normal,
                            maxLines = 2, overflow = TextOverflow.Ellipsis
                        )
                    }
                }
                // Links
                item {
                    HorizontalDivider(Modifier.padding(vertical = 8.dp))
                    Text(
                        "\uD83D\uDD17 Links (${forwardLinks.size})",
                        fontSize = 14.sp,
                        fontWeight = FontWeight.Bold,
                        modifier = Modifier.padding(bottom = 6.dp)
                    )
                }
                if (forwardLinks.isEmpty()) {
                    item {
                        Text("No outgoing links.", fontSize = 12.sp,
                            color = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                } else {
                    items(forwardLinks, key = { "rs-fwd-${it.id}" }) { ln ->
                        Text(
                            "\u2192  ${ln.title}",
                            Modifier
                                .fillMaxWidth()
                                .clickable {
                                    val cur = activeTab
                                    if (cur != null) {
                                        scrollMap[cur] = latestScroll.value
                                        vm.saveScroll(cur, latestScroll.value)
                                    }
                                    vm.openArticle(ln.id, ln.title, com.tebogo.markvault.OpenSource.LINK)
                                    showRightSheet = false
                                }
                                .padding(vertical = 8.dp),
                            fontSize = 13.sp, maxLines = 2, overflow = TextOverflow.Ellipsis
                        )
                    }
                }
                // Backlinks
                item {
                    HorizontalDivider(Modifier.padding(vertical = 8.dp))
                    Text(
                        "\u21A9\uFE0F Backlinks (${backLinks.size})",
                        fontSize = 14.sp,
                        fontWeight = FontWeight.Bold,
                        modifier = Modifier.padding(bottom = 6.dp)
                    )
                }
                if (backLinks.isEmpty()) {
                    item {
                        Text("Nothing links here.", fontSize = 12.sp,
                            color = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                } else {
                    items(backLinks, key = { "rs-bk-${it.id}" }) { ln ->
                        Text(
                            "\u2190  ${ln.title}",
                            Modifier
                                .fillMaxWidth()
                                .clickable {
                                    val cur = activeTab
                                    if (cur != null) {
                                        scrollMap[cur] = latestScroll.value
                                        vm.saveScroll(cur, latestScroll.value)
                                    }
                                    vm.openArticle(ln.id, ln.title, com.tebogo.markvault.OpenSource.BACKLINK)
                                    showRightSheet = false
                                }
                                .padding(vertical = 8.dp),
                            fontSize = 13.sp, maxLines = 2, overflow = TextOverflow.Ellipsis
                        )
                    }
                }
                item { Spacer(Modifier.height(20.dp)) }
            }
        }
    }

    if (showBacklinks) {
        // Load both lists when the sheet opens (re-runs if note changes while it's open)
        LaunchedEffect(showBacklinks, note?.id) {
            val id = note?.id
            if (id == null) {
                backlinks = emptyList()
                forwardlinks = emptyList()
            } else {
                forwardlinks = vm.loadForwardLinks(id)
                backlinks = vm.loadBacklinks(id)
            }
        }
        ModalBottomSheet(onDismissRequest = { showBacklinks = false }) {
            Row(
                Modifier.fillMaxWidth().padding(start = 20.dp, end = 12.dp, top = 4.dp, bottom = 6.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    "\uD83D\uDD17 Links",
                    Modifier.weight(1f),
                    fontWeight = FontWeight.Bold, fontSize = 16.sp
                )
                Surface(
                    color = MaterialTheme.colorScheme.primary.copy(alpha = 0.18f),
                    shape = RoundedCornerShape(14.dp),
                    modifier = Modifier.clickable(enabled = note?.id != null) {
                        showBacklinks = false
                        val cur = activeTab
                        if (cur != null) {
                            scrollMap[cur] = latestScroll.value
                            vm.saveScroll(cur, latestScroll.value)
                        }
                        note?.id?.let { nav.navigate("graph/$it") }
                    }
                ) {
                    Text(
                        "\uD83C\uDF33 View in graph",
                        modifier = Modifier.padding(horizontal = 12.dp, vertical = 7.dp),
                        fontSize = 12.sp, fontWeight = FontWeight.Medium,
                        color = MaterialTheme.colorScheme.primary
                    )
                }
            }
            LazyColumn(Modifier.fillMaxWidth().heightIn(max = 540.dp)) {
                item {
                    Text(
                        "\u2192 Links from this note (${forwardlinks.size})",
                        Modifier.padding(start = 20.dp, top = 6.dp, bottom = 4.dp),
                        fontSize = 13.sp, fontWeight = FontWeight.SemiBold,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
                if (forwardlinks.isEmpty()) {
                    item {
                        Text(
                            "No outgoing wikilinks in this note.",
                            Modifier.padding(horizontal = 20.dp, vertical = 6.dp),
                            fontSize = 13.sp,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                } else {
                    items(forwardlinks, key = { "fwd-" + it.id }) { ln ->
                        LinkRow(ln) {
                            // Save scroll on current article, then open the target
                            val cur = activeTab
                            if (cur != null) {
                                scrollMap[cur] = latestScroll.value
                                vm.saveScroll(cur, latestScroll.value)
                            }
                            vm.openArticle(ln.id, ln.title, com.tebogo.markvault.OpenSource.LINK)
                            showBacklinks = false
                        }
                    }
                }
                item { Spacer(Modifier.height(8.dp)) }
                item { HorizontalDivider(color = MaterialTheme.colorScheme.surfaceVariant) }
                item {
                    Text(
                        "\u2190 Backlinks: notes that link to this one (${backlinks.size})",
                        Modifier.padding(start = 20.dp, top = 12.dp, bottom = 4.dp),
                        fontSize = 13.sp, fontWeight = FontWeight.SemiBold,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
                if (backlinks.isEmpty()) {
                    item {
                        Text(
                            "No other notes link to this one yet.",
                            Modifier.padding(horizontal = 20.dp, vertical = 6.dp),
                            fontSize = 13.sp,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                } else {
                    items(backlinks, key = { "bk-" + it.id }) { ln ->
                        LinkRow(ln) {
                            val cur = activeTab
                            if (cur != null) {
                                scrollMap[cur] = latestScroll.value
                                vm.saveScroll(cur, latestScroll.value)
                            }
                            vm.openArticle(ln.id, ln.title, com.tebogo.markvault.OpenSource.BACKLINK)
                            showBacklinks = false
                        }
                    }
                }
                item { Spacer(Modifier.height(24.dp)) }
            }
        }
    }

    // (In-app WebView popup is now overlaid globally from MainActivity; the Reader
    // requests it via vm.requestWebPopup(url).)

    // --- Link long-press menu (Copy URL / Copy link text / Share / Open in browser) ---
    if (linkLongPress != null) {
        val data = linkLongPress!!
        ModalBottomSheet(onDismissRequest = { linkLongPress = null }) {
            Column(Modifier.padding(horizontal = 20.dp, vertical = 4.dp)) {
                if (data.text.isNotBlank()) {
                    Text(
                        data.text,
                        fontWeight = FontWeight.SemiBold, fontSize = 14.sp,
                        maxLines = 2, overflow = TextOverflow.Ellipsis
                    )
                    Spacer(Modifier.height(2.dp))
                }
                Text(
                    data.url, fontSize = 11.sp,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    maxLines = 2, overflow = TextOverflow.Ellipsis
                )
                Spacer(Modifier.height(8.dp))
                HorizontalDivider(color = MaterialTheme.colorScheme.surfaceVariant)
            }
            LinkActionRow("\uD83D\uDD17  Copy link address") {
                clipboard.setText(androidx.compose.ui.text.AnnotatedString(data.url))
                Toast.makeText(ctx, "Link copied", Toast.LENGTH_SHORT).show()
                linkLongPress = null
            }
            if (data.text.isNotBlank()) {
                LinkActionRow("\uD83D\uDCDD  Copy link text") {
                    clipboard.setText(androidx.compose.ui.text.AnnotatedString(data.text))
                    Toast.makeText(ctx, "Text copied", Toast.LENGTH_SHORT).show()
                    linkLongPress = null
                }
            }
            LinkActionRow("\u2197\uFE0F  Share") {
                val send = Intent(Intent.ACTION_SEND).apply {
                    type = "text/plain"
                    putExtra(Intent.EXTRA_TEXT, data.url)
                    if (data.text.isNotBlank()) putExtra(Intent.EXTRA_SUBJECT, data.text)
                }
                runCatching {
                    ctx.startActivity(Intent.createChooser(send, "Share link").addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
                }
                linkLongPress = null
            }
            LinkActionRow("\uD83C\uDF10  Open in system browser") {
                runCatching {
                    com.tebogo.markvault.util.openExternally(ctx, Uri.parse(data.url))
                }
                linkLongPress = null
            }
            // TASK 1: fallback search in wol.jw.org when a scripture URL is being
            // troublesome (e.g. black-screen issues). The query is taken from the
            // visible LINK TEXT first (e.g. "1 Peter 3:12"), not the URL — that's
            // the user-facing fix in v4.1 after the original implementation was
            // searching the URL itself and producing garbage results.
            LinkActionRow("\uD83D\uDD0D  Search in wol.jw.org") {
                val query = extractScriptureQueryForWol(data.url, data.text)
                if (query.isBlank()) {
                    Toast.makeText(ctx, "Couldn't find any text to search for.",
                        Toast.LENGTH_SHORT).show()
                    linkLongPress = null
                    return@LinkActionRow
                }
                val encoded = java.net.URLEncoder.encode(query, "UTF-8")
                // The /en/ path-prefixed search endpoint actually returns results;
                // the un-prefixed /wol/s/r1/lp-e variant 404s in some locales.
                val target = "https://wol.jw.org/en/wol/s/r1/lp-e?q=$encoded"
                linkLongPress = null
                // Route through the existing in-app browser pipeline so the result
                // shows in the popup (and stays under our domain whitelist).
                vm.requestWebPopup(target)
            }
            Spacer(Modifier.height(20.dp))
        }
    }

    // --- Tab grid bottom sheet ---
    // Vertical-scrolling list of all open tabs. Tap a card to switch; tap × to close that tab;
    // "Close all" button at the top closes every tab and exits the Reader.
    if (showTabGrid) {
        ModalBottomSheet(onDismissRequest = { showTabGrid = false }) {
            Column(Modifier.fillMaxWidth().padding(bottom = 8.dp)) {
                // Header row: count + Close all
                Row(
                    Modifier.fillMaxWidth().padding(start = 20.dp, end = 12.dp, top = 4.dp, bottom = 6.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        "\uD83D\uDCD1  Open tabs (${tabs.size})",
                        fontWeight = FontWeight.SemiBold, fontSize = 15.sp,
                        modifier = Modifier.weight(1f)
                    )
                    TextButton(onClick = {
                        // Save current scroll for the active tab before nuking everything
                        val cur = activeTab
                        if (cur != null) {
                            scrollMap[cur] = latestScroll.value
                            vm.saveScroll(cur, latestScroll.value)
                        }
                        vm.closeAllTabs()
                        showTabGrid = false
                        // Leaving the Reader since there are no tabs anymore
                        nav.popBackStack()
                    }) { Text("\u2716 Close all", fontSize = 13.sp) }
                }
                HorizontalDivider(color = MaterialTheme.colorScheme.surfaceVariant)
                LazyColumn(Modifier.fillMaxWidth().heightIn(max = 520.dp)) {
                    items(tabs, key = { "tg-${it.id}" }) { tab ->
                        val selected = tab.id == activeTab
                        Surface(
                            color = if (selected) MaterialTheme.colorScheme.primary.copy(alpha = 0.20f)
                            else MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.30f),
                            shape = RoundedCornerShape(10.dp),
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(horizontal = 12.dp, vertical = 4.dp)
                                .clickable {
                                    // Save scroll for the current tab before switching
                                    val cur = activeTab
                                    if (cur != null) {
                                        scrollMap[cur] = latestScroll.value
                                        vm.saveScroll(cur, latestScroll.value)
                                    }
                                    switchTab(tab.id)
                                    showTabGrid = false
                                }
                        ) {
                            Row(
                                Modifier.padding(start = 14.dp, end = 4.dp, top = 10.dp, bottom = 10.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text(
                                    if (selected) "\u2022 " else "\uD83D\uDCC4  ",
                                    fontSize = 14.sp,
                                    color = if (selected) MaterialTheme.colorScheme.primary
                                    else MaterialTheme.colorScheme.onSurfaceVariant
                                )
                                Text(
                                    tab.title,
                                    modifier = Modifier.weight(1f),
                                    maxLines = 2, overflow = TextOverflow.Ellipsis,
                                    fontSize = 14.sp,
                                    lineHeight = 18.sp,
                                    fontWeight = if (selected) FontWeight.SemiBold else FontWeight.Normal
                                )
                                IconButton(onClick = {
                                    // If we're closing the last tab, leave the Reader cleanly
                                    if (tabs.size == 1) {
                                        vm.closeAllTabs()
                                        showTabGrid = false
                                        nav.popBackStack()
                                    } else {
                                        vm.closeTab(tab.id)
                                    }
                                }) {
                                    Icon(
                                        Icons.Default.Close,
                                        contentDescription = "Close tab",
                                        modifier = Modifier.size(18.dp),
                                        tint = MaterialTheme.colorScheme.onSurfaceVariant
                                    )
                                }
                            }
                        }
                    }
                }
                Spacer(Modifier.height(12.dp))
            }
        }
    }

    // --- Print / PDF bottom sheet ---
    // Lets the user pick paper size, orientation, margins, theme; on confirm we read the
    // already-rendered HTML out of the Reader's WebView, wrap it in print-specific CSS,
    // and hand it to the Android print framework (which offers Save-as-PDF + real printers).
    // v5.4.33 — Theme creator bottom sheet. Lets users manually adjust
    // individual CSS variables for the reader. Changes are applied live
    // via the setCustomTheme() JS function. The custom theme is persisted
    // as "custom" in the theme pref, with individual colors stored
    // separately.
    // v5.4.33 — Theme Creator: simple visual color picker.
    // Each property shows the current swatch. Tap it to expand
    // a palette of colors to choose from. Live preview on every tap.
    if (showThemeCreator) {
        val palette = remember {
            listOf(
                // Darks
                "#000000", "#0b0e13", "#111111", "#1a1a1a", "#1e1e1e",
                "#1c2026", "#202020", "#252525", "#2d2d2d", "#333333",
                "#3a3a3a", "#404040", "#4a4a4a", "#555555", "#666666",
                // Greys
                "#777777", "#888888", "#999999", "#aaaaaa", "#bbbbbb",
                "#cccccc", "#d0d0d0", "#dddddd", "#e0e0e0", "#eeeeee",
                // Whites & creams
                "#f0f0f0", "#f5f5f5", "#fafafa", "#ffffff", "#fdf6e3",
                "#f4ecd8", "#fffbeb", "#f8f4e8", "#f5f0e0", "#e8e4d8",
                // Warm tones
                "#e8a87c", "#d4956b", "#c07850", "#a65e3a", "#ff9966",
                "#ffb077", "#ffba7a", "#f0c090", "#e0b080", "#cc9966",
                // Reds & pinks
                "#ff6666", "#e55050", "#cc3333", "#ff8888", "#ff4444",
                "#d44040", "#c23030", "#ff9999", "#e87070", "#ff5555",
                // Greens
                "#7ec8a4", "#66b88e", "#50a878", "#3d9060", "#a8e0bb",
                "#7fd09d", "#5ab87e", "#4da870", "#88d4a0", "#44aa66",
                // Blues
                "#7cb8ff", "#69b0ff", "#5090e0", "#3070c0", "#9adcff",
                "#67c4ff", "#4488cc", "#3366aa", "#88bbee", "#aaccff",
                // Purples
                "#b088d0", "#9a70c0", "#8855aa", "#cc99ee", "#aa77cc",
                "#9966bb", "#7744aa", "#bb88dd", "#dd99ff", "#7733aa",
                // Yellows & oranges
                "#ffd700", "#ffcc00", "#e6b800", "#ccaa00", "#ffdd44",
                "#f0c800", "#ddb000", "#ffee88", "#eedd66", "#cc9900",
                // Teals & cyans
                "#40e0d0", "#33ccbb", "#22aa99", "#118877", "#55ddcc",
                "#44ccbb", "#66eedd", "#77ffee", "#00ccaa", "#00aa88",
                // Browns
                "#8b6e4e", "#7c6f59", "#6b5b3e", "#5a4a2e", "#a08060",
                "#9a8868", "#b09878", "#4a3f2f", "#2f2718", "#776e5b"
            )
        }
        val colorLabels = remember {
            listOf(
                "--bg" to "\uD83D\uDDBC Background",
                "--fg" to "\u270D\uFE0F Text",
                "--heading" to "\uD83D\uDD20 Headings",
                "--fg-muted" to "\uD83D\uDD87\uFE0F Faded text",
                "--accent" to "\uD83D\uDD17 Links",
                "--rule" to "\u2500 Lines & dividers",
                "--surface" to "\u25A3 Cards / surfaces",
                "--surface-variant" to "\u25A6 Secondary surfaces",
                "--table-head" to "\uD83D\uDCCA Table header bg",
                "--table-border" to "\uD83D\uDCCF Table borders",
                "--quote-bar" to "\u275D Quote bar",
                "--code-bg" to "\uD83D\uDCBB Code block bg",
                "--code-fg" to "\uD83D\uDCBB Code block text",
                "--code-inline-bg" to "\uD83D\uDCDD Inline code bg",
                "--code-inline-fg" to "\uD83D\uDCDD Inline code text",
                "--mark-bg" to "\uD83D\uDD8D Highlight bg",
                "--mark-fg" to "\u270D\uFE0F Highlight text"
            )
        }
        val colorState = remember(customThemeJson, showThemeCreator) {
            val initial = articleThemeVariables(
                activeColorScheme,
                customThemeJson.takeIf { it.isNotBlank() }
            )
            mutableStateMapOf<String, String>().apply { putAll(initial) }
        }
        var expandedVar by remember { mutableStateOf<String?>(null) }

        fun applyLive() {
            val json = org.json.JSONObject(colorState as Map<*, *>).toString()
            webView?.evaluateJavascript("setCustomTheme(${JSONObject.quote(json)});", null)
        }
        fun parseHexColor(hex: String): Color {
            return runCatching {
                val h = hex.removePrefix("#")
                Color(
                    h.substring(0, 2).toInt(16),
                    h.substring(2, 4).toInt(16),
                    h.substring(4, 6).toInt(16)
                )
            }.getOrElse { Color.Gray }
        }

        ModalBottomSheet(onDismissRequest = { showThemeCreator = false }) {
            Column(
                Modifier.fillMaxWidth().padding(horizontal = 16.dp)
            ) {
                Text("\uD83C\uDFA8 Theme Creator", fontSize = 18.sp, fontWeight = FontWeight.Bold)
                Text("Tap a swatch to pick a new colour", fontSize = 12.sp,
                    color = MaterialTheme.colorScheme.onSurfaceVariant)
                Spacer(Modifier.height(8.dp))

                LazyColumn(
                    Modifier.fillMaxWidth().heightIn(max = 460.dp),
                    verticalArrangement = Arrangement.spacedBy(4.dp)
                ) {
                    items(colorLabels) { (cssVar, label) ->
                        val isExpanded = expandedVar == cssVar
                        val currentHex = colorState[cssVar] ?: "#000000"

                        Column(
                            Modifier
                                .fillMaxWidth()
                                .background(
                                    if (isExpanded)
                                        MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.3f)
                                    else Color.Transparent,
                                    RoundedCornerShape(8.dp)
                                )
                                .padding(vertical = 4.dp, horizontal = 6.dp)
                        ) {
                            // Label row with current color swatch
                            Row(
                                Modifier
                                    .fillMaxWidth()
                                    .clickable {
                                        expandedVar = if (isExpanded) null else cssVar
                                    },
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Box(
                                    Modifier
                                        .size(28.dp)
                                        .background(parseHexColor(currentHex), RoundedCornerShape(6.dp))
                                        .then(
                                            Modifier.border(
                                                1.dp,
                                                MaterialTheme.colorScheme.outline,
                                                RoundedCornerShape(6.dp)
                                            )
                                        )
                                )
                                Spacer(Modifier.width(10.dp))
                                Text(label, fontSize = 13.sp, modifier = Modifier.weight(1f))
                                Text(
                                    currentHex,
                                    fontSize = 11.sp,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                                Spacer(Modifier.width(6.dp))
                                Text(if (isExpanded) "\u25B2" else "\u25BC", fontSize = 10.sp)
                            }

                            // Expanded color grid
                            if (isExpanded) {
                                Spacer(Modifier.height(6.dp))
                                // Show grid of color swatches: 8 per row
                                val rows = palette.chunked(8)
                                rows.forEach { rowColors ->
                                    Row(
                                        Modifier.fillMaxWidth(),
                                        horizontalArrangement = Arrangement.spacedBy(4.dp)
                                    ) {
                                        rowColors.forEach { hex ->
                                            val isSelected = hex.equals(currentHex, ignoreCase = true)
                                            Box(
                                                Modifier
                                                    .size(30.dp)
                                                    .background(
                                                        parseHexColor(hex),
                                                        RoundedCornerShape(4.dp)
                                                    )
                                                    .then(
                                                        if (isSelected) Modifier.border(
                                                            2.dp,
                                                            MaterialTheme.colorScheme.primary,
                                                            RoundedCornerShape(4.dp)
                                                        ) else Modifier.border(
                                                            0.5.dp,
                                                            Color.Gray.copy(alpha = 0.3f),
                                                            RoundedCornerShape(4.dp)
                                                        )
                                                    )
                                                    .clickable {
                                                        colorState[cssVar] = hex
                                                        applyLive()
                                                    },
                                                contentAlignment = Alignment.Center
                                            ) {
                                                if (isSelected) {
                                                    Text("\u2713", fontSize = 12.sp, color = Color.White)
                                                }
                                            }
                                        }
                                    }
                                    Spacer(Modifier.height(3.dp))
                                }
                            }
                        }
                    }
                }
                Spacer(Modifier.height(10.dp))
                Row(
                    Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Button(onClick = {
                        val json = org.json.JSONObject(colorState as Map<*, *>).toString()
                        vm.setCustomThemeJson(json)
                        vm.setTheme("custom")
                        applyLive()
                        showThemeCreator = false
                    }) { Text("Apply globally") }
                    OutlinedButton(onClick = {
                        webView?.evaluateJavascript(
                            "setTheme(${jsString(theme)}); setThemeVariables(${jsString(effectiveArticleThemeJson)});",
                            null
                        )
                        showThemeCreator = false
                    }) { Text("Cancel") }
                }
                Spacer(Modifier.height(16.dp))
            }
        }
    }

    if (showPrintSheet) {
        ModalBottomSheet(onDismissRequest = { showPrintSheet = false }) {
            PrintOptionsSheet(
                noteTitle = note?.title ?: "Note",
                onCancel = { showPrintSheet = false },
                onConfirm = { opts ->
                    showPrintSheet = false
                    val wv = webView
                    if (wv != null) {
                        // Extract the rendered HTML from the Reader's WebView. markdown-it has
                        // already done its work — we just grab #content's innerHTML, wrap it
                        // in our print-specific styling, and start the print job.
                        wv.evaluateJavascript(
                            "(function(){var e=document.getElementById('content');" +
                                "return e?e.innerHTML:'';})();"
                        ) { jsonResult ->
                            // Result is JSON-encoded ("...html..."); decode once
                            val rendered = decodeJsString(jsonResult)
                            val title = note?.title ?: "Note"
                            val printHtml = buildPrintHtml(title, rendered, opts)
                            startPrintJob(ctx, title, printHtml, opts, printPinHolder)
                        }
                    } else {
                        Toast.makeText(ctx, "Note not ready to print yet", Toast.LENGTH_SHORT).show()
                    }
                }
            )
        }
    }
    } // end ModalNavigationDrawer content — v5.4.21
    } // end padded center Box — v5.4.22
    // v5.4.22 — Tablet three-column overlay. Only rendered when
    // workspace mode is ON and the window is wide enough. Both panels
    // are simple @Composable columns positioned via BoxScope.align
    // and don't interfere with the modal drawer / scaffold in the
    // padded center. Standard mode + narrow width → nothing renders
    // here at all.
    // v5.4.24 — Panels wrapped in open-state guards + statusBarsPadding.
    if (threeColumn && leftPanelOpen) {
        androidx.compose.foundation.layout.Column(
            Modifier
                .align(Alignment.TopStart)
                .width(leftColWidth)
                .fillMaxHeight()
                .background(MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.35f))
                .statusBarsPadding()
                .padding(12.dp)
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(
                    "\uD83E\uDDF0 Workspace",
                    fontSize = 15.sp,
                    fontWeight = FontWeight.Bold,
                    modifier = Modifier.weight(1f)
                )
                IconButton(
                    onClick = { leftPanelOpen = false },
                    modifier = Modifier.size(28.dp)
                ) {
                    Text("\u25C0", fontSize = 14.sp)
                }
            }
            // v5.4.33 — Toggle chips: Tabs / Results
            Row(
                Modifier.fillMaxWidth().padding(vertical = 4.dp),
                horizontalArrangement = Arrangement.spacedBy(4.dp)
            ) {
                androidx.compose.material3.FilterChip(
                    selected = leftPanelTab == "tabs",
                    onClick = { leftPanelTab = "tabs" },
                    label = { Text("Tabs", fontSize = 11.sp) }
                )
                androidx.compose.material3.FilterChip(
                    selected = leftPanelTab == "results",
                    onClick = { leftPanelTab = "results" },
                    label = { Text("Results", fontSize = 11.sp) }
                )
            }
            androidx.compose.foundation.layout.Spacer(Modifier.height(4.dp))
            if (leftPanelTab == "tabs") {
            LazyColumn(Modifier.weight(1f).fillMaxWidth()) {
                items(tabs, key = { it.id }) { tab ->
                    val selected = tab.id == activeTab
                    Surface(
                        color = if (selected)
                            MaterialTheme.colorScheme.primary.copy(alpha = 0.18f)
                        else Color.Transparent,
                        shape = RoundedCornerShape(8.dp),
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(vertical = 2.dp)
                            .clickable { switchTab(tab.id) }
                    ) {
                        Row(
                            Modifier.padding(horizontal = 10.dp, vertical = 8.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                when (tab.fileType) {
                                    "pdf" -> "\uD83D\uDCC4"
                                    "html", "htm" -> "\uD83C\uDF10"
                                    else -> "\uD83D\uDCDD"
                                },
                                fontSize = 14.sp
                            )
                            androidx.compose.foundation.layout.Spacer(Modifier.width(8.dp))
                            Text(
                                tab.title,
                                modifier = Modifier.weight(1f),
                                fontSize = 12.sp,
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis,
                                fontWeight = if (selected) FontWeight.SemiBold else FontWeight.Normal
                            )
                            IconButton(
                                onClick = { vm.closeTab(tab.id) },
                                modifier = Modifier.size(22.dp)
                            ) {
                                Icon(
                                    Icons.Default.Close,
                                    contentDescription = "Close tab",
                                    modifier = Modifier.size(12.dp),
                                    tint = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }
                        }
                    }
                }
            }
            } else {
                Text(
                    "\uD83D\uDD0D ${searchResults.size} result(s)",
                    fontSize = 11.sp,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
                androidx.compose.foundation.layout.Spacer(Modifier.height(4.dp))
                LazyColumn(Modifier.weight(1f).fillMaxWidth()) {
                    items(searchResults, key = { "lp-${it.id}" }) { hit ->
                        Surface(
                            color = Color.Transparent,
                            shape = RoundedCornerShape(8.dp),
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(vertical = 2.dp)
                                .clickable {
                                    vm.openArticle(hit.id, hit.title, fileType = hit.fileType)
                                    when (hit.fileType) {
                                        "pdf" -> nav.navigate("pdfReader/${hit.id}")
                                        "mhtml", "html" -> nav.navigate("htmlReader/${hit.id}")
                                        else -> {}
                                    }
                                }
                        ) {
                            Text(
                                hit.title,
                                Modifier.padding(horizontal = 8.dp, vertical = 6.dp),
                                fontSize = 12.sp,
                                maxLines = 2,
                                overflow = TextOverflow.Ellipsis
                            )
                        }
                    }
                }
            }
            HorizontalDivider(Modifier.padding(vertical = 6.dp))
            Row(
                Modifier
                    .fillMaxWidth()
                    .clickable { nav.navigate("home") }
                    .padding(vertical = 10.dp, horizontal = 8.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Icon(
                    Icons.Default.Add,
                    contentDescription = null,
                    modifier = Modifier.size(16.dp)
                )
                androidx.compose.foundation.layout.Spacer(Modifier.width(8.dp))
                Text("Open a new tab", fontSize = 13.sp)
            }
        }
    }
    // Right persistent panel: outline + links + backlinks (v5.4.24).
    if (threeColumn && rightPanelOpen) {
        androidx.compose.foundation.layout.Column(
            Modifier
                .align(Alignment.TopEnd)
                .width(rightColWidth)
                .fillMaxHeight()
                .background(MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.35f))
                .statusBarsPadding()
                .padding(12.dp)
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(
                    "\uD83D\uDCD1 Article info",
                    fontSize = 15.sp,
                    fontWeight = FontWeight.Bold,
                    modifier = Modifier.weight(1f)
                )
                IconButton(
                    onClick = { rightPanelOpen = false },
                    modifier = Modifier.size(28.dp)
                ) {
                    Text("▶", fontSize = 14.sp)
                }
            }
            androidx.compose.foundation.layout.Spacer(Modifier.height(10.dp))
            LazyColumn(Modifier.weight(1f).fillMaxWidth()) {
                // ─── Outline section ───
                item {
                    Text(
                        "\uD83D\uDCD1 Outline (${outline.size})",
                        fontSize = 12.sp,
                        fontWeight = FontWeight.SemiBold,
                        color = MaterialTheme.colorScheme.primary,
                        modifier = Modifier.padding(top = 4.dp, bottom = 4.dp)
                    )
                }
                if (outline.isEmpty()) {
                    item {
                        Text(
                            "No headings.",
                            fontSize = 11.sp,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                            modifier = Modifier.padding(bottom = 6.dp)
                        )
                    }
                } else {
                    items(outline) { item: OutlineItem ->
                        Text(
                            item.title,
                            Modifier
                                .fillMaxWidth()
                                .clickable {
                                    webView?.evaluateJavascript(
                                        "document.getElementById('sec-${item.index}')?." +
                                            "scrollIntoView({behavior:'smooth',block:'start'});",
                                        null
                                    )
                                }
                                .padding(
                                    start = ((item.level - 1) * 10).dp,
                                    top = 6.dp, bottom = 6.dp
                                ),
                            fontSize = if (item.level <= 2) 12.sp else 11.sp,
                            fontWeight = if (item.level <= 2) FontWeight.SemiBold else FontWeight.Normal,
                            color = if (item.level <= 2) MaterialTheme.colorScheme.onSurface
                            else MaterialTheme.colorScheme.onSurfaceVariant,
                            maxLines = 3,
                            overflow = TextOverflow.Ellipsis
                        )
                    }
                }
                // ─── Links section ───
                item {
                    HorizontalDivider(Modifier.padding(vertical = 8.dp))
                    Text(
                        "\uD83D\uDD17 Links (${forwardLinks.size})",
                        fontSize = 12.sp,
                        fontWeight = FontWeight.SemiBold,
                        color = MaterialTheme.colorScheme.primary,
                        modifier = Modifier.padding(bottom = 4.dp)
                    )
                }
                if (forwardLinks.isEmpty()) {
                    item {
                        Text(
                            "No wikilinks out.",
                            fontSize = 11.sp,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                            modifier = Modifier.padding(bottom = 6.dp)
                        )
                    }
                } else {
                    items(forwardLinks) { link ->
                        Text(
                            "\u2192  ${link.title}",
                            Modifier
                                .fillMaxWidth()
                                .clickable { vm.openArticle(link.id, link.title) }
                                .padding(vertical = 6.dp),
                            fontSize = 12.sp,
                            color = MaterialTheme.colorScheme.onSurface,
                            maxLines = 2,
                            overflow = TextOverflow.Ellipsis
                        )
                    }
                }
                // ─── Backlinks section ───
                item {
                    HorizontalDivider(Modifier.padding(vertical = 8.dp))
                    Text(
                        "\u21A9\uFE0F Backlinks (${backLinks.size})",
                        fontSize = 12.sp,
                        fontWeight = FontWeight.SemiBold,
                        color = MaterialTheme.colorScheme.primary,
                        modifier = Modifier.padding(bottom = 4.dp)
                    )
                }
                if (backLinks.isEmpty()) {
                    item {
                        Text(
                            "Nothing links here.",
                            fontSize = 11.sp,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                            modifier = Modifier.padding(bottom = 6.dp)
                        )
                    }
                } else {
                    items(backLinks) { link ->
                        Text(
                            "\u2190  ${link.title}",
                            Modifier
                                .fillMaxWidth()
                                .clickable { vm.openArticle(link.id, link.title) }
                                .padding(vertical = 6.dp),
                            fontSize = 12.sp,
                            color = MaterialTheme.colorScheme.onSurface,
                            maxLines = 2,
                            overflow = TextOverflow.Ellipsis
                        )
                    }
                }
            }
        }
    }
    // v5.4.24 — Corner toggle buttons. Always visible when threeColumn is
    // on. Reopen collapsed panels. Positioned with statusBarsPadding so
    // they never overlap the notification bar.
    if (threeColumn && !leftPanelOpen) {
        IconButton(
            onClick = { leftPanelOpen = true },
            modifier = Modifier
                .align(Alignment.TopStart)
                .statusBarsPadding()
                .padding(4.dp)
                .size(40.dp)
        ) {
            Icon(
                Icons.Default.Menu,
                contentDescription = "Show left panel",
                tint = MaterialTheme.colorScheme.onSurface
            )
        }
    }
    if (threeColumn && !rightPanelOpen) {
        IconButton(
            onClick = { rightPanelOpen = true },
            modifier = Modifier
                .align(Alignment.TopEnd)
                .statusBarsPadding()
                .padding(4.dp)
                .size(40.dp)
        ) {
            Text("📑", fontSize = 18.sp)
        }
    }

    // ── v5.4.130cc — In-article semantic-search popup overlays ──
    // The BRAIN BUTTON that triggers this popup is the pre-existing
    // v5.4.142cc — Multi-bubble system.
    val mdBubbles by vm.popupBubbles.collectAsStateWithLifecycle()
    var nearBottomBubbleId by remember { mutableStateOf<String?>(null) }

    // "search in article" FAB above (now wrapped in PumpingBrainFab).
    // No additional brain button is added here — this Box just renders
    // whichever popup state is active.
    val mdPopupState by vm.articlePopupState.collectAsStateWithLifecycle()
    val mdPopupSlot: com.tebogo.markvault.AppViewModel.ArticlePopupState = mdPopupState
    when (mdPopupSlot) {
        is com.tebogo.markvault.AppViewModel.ArticlePopupState.Loading -> {
            ArticlePopupLoading(
                query = mdPopupSlot.query,
                onCancel = { vm.closeArticlePopup() },
                modifier = Modifier
                    .align(Alignment.BottomCenter)
                    .padding(bottom = 80.dp, start = 16.dp, end = 16.dp)
            )
        }
        is com.tebogo.markvault.AppViewModel.ArticlePopupState.Empty -> {
            ArticlePopupEmpty(
                query = mdPopupSlot.query,
                onClose = { vm.closeArticlePopup() },
                modifier = Modifier
                    .align(Alignment.BottomCenter)
                    .padding(bottom = 80.dp, start = 16.dp, end = 16.dp)
            )
        }
        is com.tebogo.markvault.AppViewModel.ArticlePopupState.Visible -> {
            // v5.4.142cc — Capture note content into a local val
            // before the lambda so K2 smart-cast survives closure.
            val mdNoteContent: String = note?.content ?: ""
            ArticlePopupOverlay(
                query = mdPopupSlot.query,
                passages = mdPopupSlot.passages,
                // X = strict close; — = collapse to bubble (not hide).
                onClose = { vm.closeArticlePopup() },
                onMinimize = { vm.minimizeCurrentPopupToBubble() },
                onCycleBlur = { vm.cycleArticlePopupBlur() },
                onOpenUrl = { url ->
                    vm.requestWebPopup(url)
                },
                mode = mdPopupSlot.mode,
                onToggleMode = {
                    val slotNoteId = mdPopupSlot.noteId
                    val slotQuery  = mdPopupSlot.query
                    vm.toggleArticlePopupMode(slotNoteId, mdNoteContent, slotQuery)
                },
                // v5.4.150cc — Speed persisted via ViewModel/DataStore.
                typingSpeed = popupTypingSpeed,
                onTypingSpeedChange = { vm.setPopupTypingSpeed(it) },
                // v5.4.150cc — Start popup at bottom-center (slightly below
                // the midpoint) so the user can still read the article above it.
                modifier = Modifier
                    .align(Alignment.BottomCenter)
                    .padding(bottom = 80.dp, start = 12.dp, end = 12.dp)
            )
        }
        is com.tebogo.markvault.AppViewModel.ArticlePopupState.Hidden -> {
            // Nothing rendered
        }
    }

    // v5.4.142cc — Render each active bubble (stacked bottom-start,
    // each horizontally offset so they don't overlap initially).
    mdBubbles.forEachIndexed { index, bubble ->
        DraggableBubble(
            bubble = bubble,
            startOffsetX = (index * 210).toFloat(),
            startOffsetY = 0f,
            onRestore = { vm.restoreBubble(bubble.id) },
            onNearBottomChanged = { isNear ->
                nearBottomBubbleId = if (isNear) bubble.id
                else if (nearBottomBubbleId == bubble.id) null
                else nearBottomBubbleId
            },
            modifier = Modifier
                .align(Alignment.BottomStart)
                .padding(start = 16.dp, bottom = 72.dp)
        )
    }

    // Close zone — fades in when any bubble is dragged near the bottom.
    val closeZoneVisible = nearBottomBubbleId != null
    BubbleCloseZone(
        visible = closeZoneVisible,
        onCloseThis = {
            val id = nearBottomBubbleId ?: return@BubbleCloseZone
            vm.closeBubble(id)
            nearBottomBubbleId = null
        },
        onCloseAll = {
            vm.closeAllPopupsAndBubbles()
            nearBottomBubbleId = null
        },
        modifier = Modifier.align(Alignment.BottomCenter)
    )
    } // end outer Box — v5.4.22
}

/**
 * Decode the JSON-encoded string that evaluateJavascript hands back. The input is wrapped in
 * double-quotes and uses \uXXXX/\\ escapes — we strip those carefully so the print HTML stays
 * intact.
 */
private fun decodeJsString(jsonString: String?): String {
    if (jsonString.isNullOrBlank() || jsonString == "null") return ""
    return try {
        org.json.JSONArray("[$jsonString]").getString(0)
    } catch (_: Exception) {
        // Fallback for trivial cases
        jsonString.trim().trim('"')
            .replace("\\n", "\n").replace("\\r", "")
            .replace("\\\"", "\"").replace("\\\\", "\\")
    }
}

/**
 * v5.4.144cc — Decode the JSON array string returned by the
 * yellow-highlight extraction evaluateJavascript call.
 *
 * The WebView wraps the JS return value in an outer JSON string, so
 * `JSON.stringify(["a","b"])` comes back as `"\"[\\\"a\\\",\\\"b\\\"]\""`
 * in the Kotlin callback. We unwrap the outer layer first, then parse
 * the inner JSON array.
 */
private fun decodeJsHighlightArray(raw: String?): List<String> {
    if (raw.isNullOrBlank() || raw == "null") return emptyList()
    return try {
        val inner = org.json.JSONArray("[$raw]").getString(0)
        val arr = org.json.JSONArray(inner)
        (0 until arr.length()).mapNotNull { i ->
            arr.optString(i).trim().takeIf { it.isNotBlank() }
        }
    } catch (_: Exception) {
        emptyList()
    }
}

@Composable
private fun LinkActionRow(text: String, onClick: () -> Unit) {
    Text(
        text,
        Modifier
            .fillMaxWidth()
            .clickable(onClick = onClick)
            .padding(horizontal = 20.dp, vertical = 13.dp),
        fontSize = 14.sp
    )
}

@Composable
private fun LinkRow(ln: com.tebogo.markvault.data.LinkedNote, onClick: () -> Unit) {
    Column(
        Modifier
            .fillMaxWidth()
            .clickable(onClick = onClick)
            .padding(horizontal = 20.dp, vertical = 11.dp)
    ) {
        Text(
            ln.title, fontWeight = FontWeight.Medium, fontSize = 14.sp,
            maxLines = 2, overflow = TextOverflow.Ellipsis
        )
        if (ln.folder.isNotBlank()) {
            Text(
                ln.folder, fontSize = 11.sp,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                maxLines = 1, overflow = TextOverflow.Ellipsis
            )
        }
    }
}

/** Snapshot of a long-pressed `<a>` in the article — URL + visible text. */
private data class LinkPressData(val url: String, val text: String)

// v5.4.37 — Link routing, openInJwLibrary, and openExternally moved to
// com.tebogo.markvault.util.JwLibraryLinks.kt (shared with HtmlReaderScreen).
