package com.tebogo.markvault.ui

import android.annotation.SuppressLint
import android.webkit.WebView
import androidx.activity.compose.BackHandler
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.KeyboardArrowDown
import androidx.compose.material.icons.filled.KeyboardArrowUp
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TextField
import androidx.compose.material3.TextFieldDefaults
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.toArgb
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.navigation.NavController
import com.tebogo.markvault.AppViewModel
import com.tebogo.markvault.data.Note
import org.json.JSONObject

@OptIn(ExperimentalMaterial3Api::class)
@SuppressLint("SetJavaScriptEnabled")
@Composable
fun ReaderScreen(vm: AppViewModel, nav: NavController, id: Long) {
    var note by remember { mutableStateOf<Note?>(null) }
    LaunchedEffect(id) { note = vm.loadNote(id) }

    val fontScale by vm.fontScale.collectAsStateWithLifecycle()

    var webView by remember { mutableStateOf<WebView?>(null) }
    var pageReady by remember { mutableStateOf(false) }

    var showFind by remember { mutableStateOf(false) }
    var findQuery by remember { mutableStateOf("") }
    var matchCount by remember { mutableStateOf(0) }
    var activeMatch by remember { mutableStateOf(0) }
    val findFocus = remember { FocusRequester() }

    val bg = MaterialTheme.colorScheme.background.toArgb()

    // Render content once the page is ready / when the note changes.
    LaunchedEffect(pageReady, note?.id) {
        val wv = webView ?: return@LaunchedEffect
        val content = note?.content ?: return@LaunchedEffect
        if (!pageReady) return@LaunchedEffect
        val json = JSONObject.quote(content)
        wv.evaluateJavascript("renderMarkdown($json, $fontScale);", null)
    }

    // Live font scaling without re-rendering (keeps scroll position).
    LaunchedEffect(fontScale, pageReady) {
        if (pageReady) webView?.evaluateJavascript("setFontScale($fontScale);", null)
    }

    BackHandler(enabled = showFind) {
        showFind = false
        webView?.clearMatches()
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Text(note?.title ?: "\u2026", maxLines = 1, overflow = TextOverflow.Ellipsis)
                },
                navigationIcon = {
                    IconButton(onClick = { nav.popBackStack() }) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back")
                    }
                },
                actions = {
                    IconButton(onClick = {
                        showFind = !showFind
                        if (!showFind) webView?.clearMatches()
                    }) {
                        Icon(Icons.Default.Search, contentDescription = "Find in note")
                    }
                    TextButton(onClick = {
                        vm.setFontScale((fontScale - 0.1f).coerceIn(0.7f, 2.2f))
                    }) { Text("A\u2212") }
                    TextButton(onClick = {
                        vm.setFontScale((fontScale + 0.1f).coerceIn(0.7f, 2.2f))
                    }) { Text("A+") }
                }
            )
        }
    ) { pad ->
        Column(Modifier.padding(pad).fillMaxSize()) {
            if (showFind) {
                Surface(color = MaterialTheme.colorScheme.surfaceVariant) {
                    Row(
                        Modifier.fillMaxWidth().padding(horizontal = 8.dp, vertical = 4.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        TextField(
                            value = findQuery,
                            onValueChange = {
                                findQuery = it
                                val wv = webView
                                if (wv != null) {
                                    if (it.isBlank()) { wv.clearMatches(); matchCount = 0 }
                                    else wv.findAllAsync(it)
                                }
                            },
                            modifier = Modifier.weight(1f).focusRequester(findFocus),
                            singleLine = true,
                            placeholder = { Text("Find in this note\u2026") },
                            colors = TextFieldDefaults.colors(
                                focusedContainerColor = Color.Transparent,
                                unfocusedContainerColor = Color.Transparent
                            )
                        )
                        Text(
                            if (matchCount > 0) "${activeMatch + 1}/$matchCount" else "0/0",
                            fontSize = 12.sp,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                            modifier = Modifier.padding(horizontal = 6.dp)
                        )
                        IconButton(onClick = { webView?.findNext(false) }) {
                            Icon(Icons.Default.KeyboardArrowUp, contentDescription = "Previous")
                        }
                        IconButton(onClick = { webView?.findNext(true) }) {
                            Icon(Icons.Default.KeyboardArrowDown, contentDescription = "Next")
                        }
                        IconButton(onClick = {
                            showFind = false; findQuery = ""
                            webView?.clearMatches(); matchCount = 0
                        }) {
                            Icon(Icons.Default.Close, contentDescription = "Close find")
                        }
                    }
                }
                LaunchedEffect(Unit) { findFocus.requestFocus() }
            }

            Box(Modifier.fillMaxSize()) {
                AndroidView(
                    modifier = Modifier.fillMaxSize(),
                    factory = { c ->
                        WebView(c).apply {
                            setBackgroundColor(bg)
                            settings.javaScriptEnabled = true
                            settings.allowFileAccess = true
                            settings.domStorageEnabled = true
                            settings.textZoom = 100
                            setFindListener { active, count, _ ->
                                matchCount = count
                                activeMatch = active
                            }
                            webViewClient = object : android.webkit.WebViewClient() {
                                override fun onPageFinished(view: WebView?, url: String?) {
                                    pageReady = true
                                }
                            }
                            loadUrl("file:///android_asset/viewer.html")
                            webView = this
                        }
                    }
                )
            }
        }
    }
}
