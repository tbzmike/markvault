package com.tebogo.markvault.ai

import android.content.Context
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

/**
 * v5.4.74 — Restores persisted AI configuration on startup.
 *
 * Update 4 redo:
 * Connects DataStore values to the live AI preference objects.
 */
object AiSettingsBootstrap {

    fun restore(context: Context, scope: CoroutineScope) {
        scope.launch(Dispatchers.IO) {
            AiRetrievalPreference.setEnabled(
                AiPreferenceStore.loadEnabled(context)
            )

            MultiQueryPreference.setCount(
                AiPreferenceStore.loadQueryCount(context)
            )

            val model = AiPreferenceStore.loadModel(context)
            runCatching {
                RetrievalModelManager.setModel(
                    RetrievalModelManager.Model.valueOf(model)
                )
            }
        }
    }

    suspend fun saveModel(context: Context, model: RetrievalModelManager.Model) {
        RetrievalModelManager.setModel(model)
        AiPreferenceStore.saveModel(context, model.name)
    }

    suspend fun saveEnabled(context: Context, enabled: Boolean) {
        AiRetrievalPreference.setEnabled(enabled)
        AiPreferenceStore.saveEnabled(context, enabled)
    }

    suspend fun saveQueryCount(context: Context, count: Int) {
        MultiQueryPreference.setCount(count)
        AiPreferenceStore.saveQueryCount(context, count)
    }
}
