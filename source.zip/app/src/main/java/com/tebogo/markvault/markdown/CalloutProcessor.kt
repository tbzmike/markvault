package com.tebogo.markvault.markdown

object CalloutProcessor {
    private val regex = Regex("""(?m)^>\s*\[!(\w+)]\s*\n((?:^>.*\n?)+)""")
    fun process(source: String): String {
        return regex.replace(source) { m ->
            val type=m.groupValues[1].lowercase()
            val body=m.groupValues[2].lines()
                .joinToString("\n"){it.removePrefix(">").trim()}
            "<div class=\"callout $type\">\n$body\n</div>\n"
        }
    }
}
