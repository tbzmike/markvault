package com.tebogo.markvault.service

import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

enum class BackupRestoreKind { BACKUP, RESTORE }

data class BackupRestoreUiState(
    val running: Boolean = false,
    val kind: BackupRestoreKind? = null,
    val stage: String = "",
    val percent: Int = 0,
    val completed: Long = 0L,
    val total: Long = 0L,
    val message: String? = null
)

/**
 * Process-wide observable state for the user-started backup/restore foreground
 * service. Settings observes this instead of owning the operation coroutine, so
 * leaving Settings or turning the display off cannot cancel the work.
 */
object BackupRestoreOperationState {
    private val _state = MutableStateFlow(BackupRestoreUiState())
    val state: StateFlow<BackupRestoreUiState> = _state.asStateFlow()

    fun start(kind: BackupRestoreKind, stage: String) {
        _state.value = BackupRestoreUiState(
            running = true,
            kind = kind,
            stage = stage,
            percent = 0
        )
    }

    fun progress(
        kind: BackupRestoreKind,
        stage: String,
        percent: Int,
        completed: Long = 0L,
        total: Long = 0L
    ) {
        _state.value = BackupRestoreUiState(
            running = true,
            kind = kind,
            stage = stage,
            percent = percent.coerceIn(0, 100),
            completed = completed,
            total = total
        )
    }

    fun finish(kind: BackupRestoreKind, success: Boolean, message: String) {
        _state.value = BackupRestoreUiState(
            running = false,
            kind = kind,
            stage = if (success) "Complete" else "Failed",
            percent = if (success) 100 else _state.value.percent,
            completed = _state.value.completed,
            total = _state.value.total,
            message = message
        )
    }
}
