package com.tebogo.markvault.service

import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

enum class BackupRestoreKind { BACKUP, RESTORE }

data class BackupRestoreUiState(
    val running: Boolean = false,
    val kind: BackupRestoreKind? = null,
    val stage: String = "",
    val percent: Int = 0,
    val completed: Long = 0L,
    val total: Long = 0L,
    val message: String? = null,
    val pauseRequested: Boolean = false,
    val paused: Boolean = false,
    val stopRequested: Boolean = false
)

/**
 * Process-wide observable state for the user-started backup/restore foreground
 * service. Settings observes this instead of owning the operation coroutine, so
 * leaving Settings or turning the display off cannot cancel the work.
 */
object BackupRestoreOperationState {
    private val _state = MutableStateFlow(BackupRestoreUiState())
    val state: StateFlow<BackupRestoreUiState> = _state.asStateFlow()

    @Synchronized fun start(kind: BackupRestoreKind, stage: String) {
        _state.value = BackupRestoreUiState(
            running = true,
            kind = kind,
            stage = stage,
            percent = 0
        )
    }

    @Synchronized fun progress(
        kind: BackupRestoreKind,
        stage: String,
        percent: Int,
        completed: Long = 0L,
        total: Long = 0L
    ) {
        _state.value = _state.value.copy(
            running = true,
            kind = kind,
            stage = stage,
            percent = percent.coerceIn(0, 100),
            completed = completed,
            total = total
        )
    }

    @Synchronized fun pauseState(requested: Boolean, paused: Boolean) {
        _state.value = _state.value.copy(pauseRequested = requested, paused = paused)
    }

    @Synchronized fun stopping() {
        _state.value = _state.value.copy(stopRequested = true, pauseRequested = false, paused = false)
    }

    @Synchronized fun recover(file: java.io.File) {
        if (_state.value.running || _state.value.message != null) return
        val record = BackupJobJournal.read(file) ?: return
        val kind = runCatching { BackupRestoreKind.valueOf(record.kind) }.getOrNull() ?: return
        val interrupted = record.status == "Running"
        val stage = if (interrupted) "Interrupted" else record.status
        _state.value = BackupRestoreUiState(kind = kind, stage = stage,
            percent = if (stage == "Complete" || stage == "Partial") 100 else 0,
            message = if (interrupted) BackupJobJournal.interruptedMessage(record.kind) else record.message)
    }

    @Synchronized fun finish(kind: BackupRestoreKind, success: Boolean, message: String, stage: String = if (success) "Complete" else "Failed") {
        _state.value = BackupRestoreUiState(
            running = false,
            kind = kind,
            stage = stage,
            percent = if (success) 100 else _state.value.percent,
            completed = _state.value.completed,
            total = _state.value.total,
            message = message
        )
    }
}
