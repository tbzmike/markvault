package com.tebogo.markvault.ui

import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Popup
import androidx.compose.ui.window.PopupProperties

/**
 * v5.4.236cc — Live heap RAM readout, top-right corner of the screen.
 * Updates every second using the exact same formula the rest of the app's
 * memory-pressure logic uses:
 *
 *   used      = totalMemory() - freeMemory()
 *   available = maxMemory() - used
 *
 * Uses Popup (not a plain Box) so it floats above the TopAppBar and
 * everything else, regardless of where in the composable tree it's
 * called from — no layout plumbing needed at the call site.
 */
@Composable
fun MemoryOverlay() {
    var usedMb      by remember { mutableStateOf(0L) }
    var availableMb by remember { mutableStateOf(0L) }

    LaunchedEffect(Unit) {
        while (true) {
            val runtime = Runtime.getRuntime()
            val used = (runtime.totalMemory() - runtime.freeMemory()) / (1024 * 1024)
            val maxMb = runtime.maxMemory() / (1024 * 1024)
            usedMb = used
            availableMb = (maxMb - used).coerceAtLeast(0L)
            kotlinx.coroutines.delay(1000L)
        }
    }

    Popup(
        alignment = Alignment.TopEnd,
        properties = PopupProperties(
            focusable = false,
            dismissOnBackPress = false,
            dismissOnClickOutside = false,
            clippingEnabled = false
        )
    ) {
        Surface(
            color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.9f),
            shape = RoundedCornerShape(bottomStart = 8.dp),
            tonalElevation = 3.dp,
            modifier = Modifier.padding(top = 2.dp, end = 2.dp)
        ) {
            Column(modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)) {
                Text(
                    "\uD83D\uDCCA ${usedMb}MB used",
                    fontSize = 9.sp,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
                Text(
                    "${availableMb}MB free",
                    fontSize = 9.sp,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
        }
    }
}
