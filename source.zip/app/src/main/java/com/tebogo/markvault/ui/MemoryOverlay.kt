package com.tebogo.markvault.ui

import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

/**
 * v5.4.245cc — Live RAM readout, inline in the TopAppBar actions row.
 *
 * Leads with PSS (Proportional Set Size) via ActivityManager — Android's
 * complete, authoritative per-process memory number: Java heap, native
 * heap, AND memory-mapped files (e.g. if ONNX loads model weights via
 * mmap rather than malloc, which neither of the other two numbers below
 * can see). Updated every 3s since it's a binder IPC call to
 * system_server — noticeably more expensive than the others, so it
 * doesn't run on the same 1s tick.
 *
 * java/native/free/max below use the same cheap, local formula as
 * before, still updated every second — useful for seeing WHICH category
 * (Java vs native) something belongs to once PSS says something's off.
 *
 * Note on accuracy: maxMemory() reports the heap ceiling THIS specific
 * running process was actually handed by Zygote at fork time — it does
 * not re-read dalvik.vm.heapsize live. If a device-side heap tweak (e.g.
 * via a Magisk post-fs-data script) hasn't taken effect yet, this will
 * correctly show the OLD ceiling until the device is rebooted, since
 * that's genuinely what the running process is bound by.
 */
@Composable
fun MemoryOverlay() {
    val ctx = androidx.compose.ui.platform.LocalContext.current
    var usedMb      by remember { mutableStateOf(0L) }
    var availableMb by remember { mutableStateOf(0L) }
    var maxMb       by remember { mutableStateOf(0L) }
    var nativeMb    by remember { mutableStateOf(0L) }
    var pssMb       by remember { mutableStateOf(0L) }

    LaunchedEffect(Unit) {
        var tick = 0
        while (true) {
            val runtime = Runtime.getRuntime()
            val used = (runtime.totalMemory() - runtime.freeMemory()) / (1024 * 1024)
            val max = runtime.maxMemory() / (1024 * 1024)
            usedMb = used
            maxMb = max
            availableMb = (max - used).coerceAtLeast(0L)
            nativeMb = android.os.Debug.getNativeHeapAllocatedSize() / (1024 * 1024)

            if (tick % 3 == 0) {
                pssMb = runCatching {
                    val am = ctx.getSystemService(android.content.Context.ACTIVITY_SERVICE)
                        as android.app.ActivityManager
                    val info = am.getProcessMemoryInfo(intArrayOf(android.os.Process.myPid()))
                    (info.firstOrNull()?.totalPss ?: 0) / 1024L
                }.getOrDefault(pssMb)
            }
            tick++
            kotlinx.coroutines.delay(1000L)
        }
    }

    Surface(
        color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.7f),
        shape = RoundedCornerShape(6.dp),
        modifier = Modifier.padding(end = 4.dp)
    ) {
        Column(modifier = Modifier.padding(horizontal = 6.dp, vertical = 3.dp)) {
            Text(
                "${pssMb}M total",
                fontSize = 8.sp,
                lineHeight = 9.sp,
                fontWeight = androidx.compose.ui.text.font.FontWeight.Bold,
                color = MaterialTheme.colorScheme.primary
            )
            Text(
                "${usedMb}J ${nativeMb}N",
                fontSize = 8.sp,
                lineHeight = 9.sp,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
            Text(
                "${availableMb}M free",
                fontSize = 8.sp,
                lineHeight = 9.sp,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
            Text(
                "max ${maxMb}M",
                fontSize = 8.sp,
                lineHeight = 9.sp,
                color = MaterialTheme.colorScheme.tertiary
            )
        }
    }
}
