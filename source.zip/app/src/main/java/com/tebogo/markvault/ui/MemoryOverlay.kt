package com.tebogo.markvault.ui

import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

/**
 * v5.4.237cc — Live heap RAM readout. Renders INLINE — a compact Surface
 * meant to sit inside the TopAppBar's actions Row, between the model
 * selector and the video icon. NOT a Popup/overlay: the previous version
 * used Popup(alignment = TopEnd), which floats at the absolute top-right
 * of the WINDOW, ignoring system window insets — that's why it rendered
 * on top of the status bar. Living inside the TopAppBar means it
 * automatically inherits the Scaffold's correct status-bar-safe
 * positioning, same as every other toolbar element.
 *
 * Uses the same formula as the rest of the app's memory-pressure logic:
 *   used      = totalMemory() - freeMemory()
 *   available = maxMemory() - used
 *
 * Note on accuracy: maxMemory() reports the heap ceiling THIS specific
 * running process was actually handed by Zygote at fork time — it does
 * not re-read dalvik.vm.heapsize live. If a device-side heap tweak (e.g.
 * via a Magisk post-fs-data script) hasn't taken effect yet, this will
 * correctly show the OLD ceiling until the device is rebooted, since
 * that's genuinely what the running process is bound by.
 */
@Composable
fun MemoryOverlay() {
    var usedMb      by remember { mutableStateOf(0L) }
    var availableMb by remember { mutableStateOf(0L) }

    LaunchedEffect(Unit) {
        while (true) {
            val runtime = Runtime.getRuntime()
            val used = (runtime.totalMemory() - runtime.freeMemory()) / (1024 * 1024)
            val maxMb = runtime.maxMemory() / (1024 * 1024)
            usedMb = used
            availableMb = (maxMb - used).coerceAtLeast(0L)
            kotlinx.coroutines.delay(1000L)
        }
    }

    Surface(
        color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.7f),
        shape = RoundedCornerShape(6.dp),
        modifier = Modifier.padding(end = 4.dp)
    ) {
        Column(modifier = Modifier.padding(horizontal = 6.dp, vertical = 3.dp)) {
            Text(
                "${usedMb}M used",
                fontSize = 8.sp,
                lineHeight = 9.sp,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
            Text(
                "${availableMb}M free",
                fontSize = 8.sp,
                lineHeight = 9.sp,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
        }
    }
}
