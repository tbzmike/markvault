package com.tebogo.markvault.ui

import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.compose.LocalLifecycleOwner
import androidx.lifecycle.repeatOnLifecycle
import kotlinx.coroutines.isActive

/**
 * v5.4.245cc — Live RAM readout, inline in the TopAppBar actions row.
 *
 * Leads with PSS (Proportional Set Size) via ActivityManager — Android's
 * complete, authoritative per-process memory number: Java heap, native
 * heap, AND memory-mapped files (e.g. if ONNX loads model weights via
 * mmap rather than malloc, which neither of the other two numbers below
 * can see). v5.4.365cc samples PSS about every 9s because it is a Binder
 * IPC into system_server; the cheap local heap figures update every 3s.
 * Both loops suspend completely while MarkVault is not STARTED.
 *
 * java/native/free/max below use the same cheap, local formula as
 * before — useful for seeing WHICH category
 * (Java vs native) something belongs to once PSS says something's off.
 *
 * Note on accuracy: maxMemory() reports the heap ceiling THIS specific
 * running process was actually handed by Zygote at fork time — it does
 * not re-read dalvik.vm.heapsize live. If a device-side heap tweak (e.g.
 * via a Magisk post-fs-data script) hasn't taken effect yet, this will
 * correctly show the OLD ceiling until the device is rebooted, since
 * that's genuinely what the running process is bound by.
 */
@Composable
fun MemoryOverlay() {
    val ctx = androidx.compose.ui.platform.LocalContext.current
    var usedMb      by remember { mutableStateOf(0L) }
    var availableMb by remember { mutableStateOf(0L) }
    var maxMb       by remember { mutableStateOf(0L) }
    var nativeMb    by remember { mutableStateOf(0L) }
    var pssMb       by remember { mutableStateOf(0L) }

    val lifecycleOwner = LocalLifecycleOwner.current
    LaunchedEffect(lifecycleOwner) {
        lifecycleOwner.lifecycle.repeatOnLifecycle(Lifecycle.State.STARTED) {
            var tick = 0
            while (isActive) {
                val runtime = Runtime.getRuntime()
                val used = (runtime.totalMemory() - runtime.freeMemory()) / (1024 * 1024)
                val max = runtime.maxMemory() / (1024 * 1024)
                usedMb = used
                maxMb = max
                availableMb = (max - used).coerceAtLeast(0L)
                nativeMb = android.os.Debug.getNativeHeapAllocatedSize() / (1024 * 1024)

                // v5.4.365cc — PSS crosses Binder into system_server, so sample
                // it every ~9 s instead of every 3 s. The cheap heap figures
                // refresh every 3 s, which is still more than fast enough for a
                // human-readable toolbar counter. Nothing runs in background.
                if (tick % 3 == 0) {
                    pssMb = runCatching {
                        val am = ctx.getSystemService(android.content.Context.ACTIVITY_SERVICE)
                            as android.app.ActivityManager
                        val info = am.getProcessMemoryInfo(intArrayOf(android.os.Process.myPid()))
                        (info.firstOrNull()?.totalPss ?: 0) / 1024L
                    }.getOrDefault(pssMb)
                }
                tick++
                kotlinx.coroutines.delay(3_000L)
            }
        }
    }

    Surface(
        color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.7f),
        shape = RoundedCornerShape(6.dp),
        modifier = Modifier.padding(end = 4.dp)
    ) {
        Column(modifier = Modifier.padding(horizontal = 6.dp, vertical = 3.dp)) {
            Text(
                "${pssMb}M total",
                fontSize = 8.sp,
                lineHeight = 9.sp,
                fontWeight = androidx.compose.ui.text.font.FontWeight.Bold,
                color = MaterialTheme.colorScheme.primary
            )
            Text(
                "${usedMb}J ${nativeMb}N",
                fontSize = 8.sp,
                lineHeight = 9.sp,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
            Text(
                "${availableMb}M free",
                fontSize = 8.sp,
                lineHeight = 9.sp,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
            Text(
                "max ${maxMb}M",
                fontSize = 8.sp,
                lineHeight = 9.sp,
                color = MaterialTheme.colorScheme.tertiary
            )
        }
    }
}
