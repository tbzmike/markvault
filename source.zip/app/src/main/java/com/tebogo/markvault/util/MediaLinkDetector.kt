package com.tebogo.markvault.util

/**
 * v5.4.228cc — Detect JW.org video/audio references in article text.
 *
 * Fast, pure-Kotlin — no I/O. Runs on snippet text for each visible search
 * result card and returns a small list of detected media links.
 */
object MediaLinkDetector {

    data class Detected(
        val url: String,
        val kind: String,          // "video" or "audio"
        val estimatedMinutes: Int  // 0 if unknown
    )

    // JW.org video-page URLs (article-embedded links)
    private val videoUrlRegex = Regex(
        "https?://[\\w./-]*jw\\.org[^\\s\"'()\\[\\]]*" +
        "(?:subtype=rendered|library/videos[^\\s]*mediaitems[^\\s]*|" +
        "was-it-designed|video)[^\\s\"'()\\[\\]]*",
        RegexOption.IGNORE_CASE
    )

    // Direct MP4 / M4V / WEBM
    private val mp4Regex = Regex(
        "https?://[^\\s\"'()\\[\\]]+\\.(?:mp4|m4v|webm)",
        RegexOption.IGNORE_CASE
    )

    // JW.org audio-page URLs
    private val audioUrlRegex = Regex(
        "https?://[\\w./-]*jw\\.org[^\\s\"'()\\[\\]]*" +
        "(?:audio|listen)[^\\s\"'()\\[\\]]*",
        RegexOption.IGNORE_CASE
    )

    // Direct MP3 / M4A / OGG / AAC
    private val mp3Regex = Regex(
        "https?://[^\\s\"'()\\[\\]]+\\.(?:mp3|m4a|ogg|aac)",
        RegexOption.IGNORE_CASE
    )

    // "(10 min)" / "10 minutes" / "video (5:30)" duration hints near URLs
    private val minutesRegex = Regex("\\((\\d{1,3})\\s*min\\)", RegexOption.IGNORE_CASE)

    /**
     * Scan [text] for video/audio references. Returns at most one video +
     * one audio badge per article (deduplicated). Result is stable so cards
     * don't flicker between recompositions.
     */
    fun detect(text: String): List<Detected> {
        if (text.isBlank() || text.length < 10) return emptyList()

        val hits = mutableListOf<Detected>()

        // Prefer explicit "was-it-designed" & video article patterns first.
        videoUrlRegex.find(text)?.let { m ->
            hits += Detected(m.value, "video", extractMinutes(text, m.range.first))
        }
        if (hits.none { it.kind == "video" }) {
            mp4Regex.find(text)?.let { m ->
                hits += Detected(m.value, "video", extractMinutes(text, m.range.first))
            }
        }

        audioUrlRegex.find(text)?.let { m ->
            // Skip if this was actually captured as a video already
            if (hits.none { it.url == m.value })
                hits += Detected(m.value, "audio", extractMinutes(text, m.range.first))
        }
        if (hits.none { it.kind == "audio" }) {
            mp3Regex.find(text)?.let { m ->
                hits += Detected(m.value, "audio", extractMinutes(text, m.range.first))
            }
        }
        return hits
    }

    /** Look for a "(N min)" hint within 80 chars of the URL. */
    private fun extractMinutes(text: String, urlPos: Int): Int {
        val start = maxOf(0, urlPos - 40)
        val end   = minOf(text.length, urlPos + 200)
        val window = text.substring(start, end)
        return minutesRegex.find(window)?.groupValues?.get(1)?.toIntOrNull() ?: 0
    }
}
