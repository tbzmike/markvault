package com.tebogo.markvault.util

/**
 * v5.4.228cc — Detect JW.org video/audio references in article text.
 *
 * Fast, pure-Kotlin — no I/O. Runs on snippet text for each visible search
 * result card and returns a small list of detected media links.
 */
object MediaLinkDetector {

    data class Detected(
        val url: String,
        val kind: String,          // "video" or "audio"
        val estimatedMinutes: Int  // 0 if unknown
    )

    // JW.org video-page URLs (article-embedded links)
    private val videoUrlRegex = Regex(
        "https?://[\\w./-]*jw\\.org[^\\s\"'()\\[\\]]*" +
        "(?:subtype=rendered|library/videos[^\\s]*mediaitems[^\\s]*|" +
        "was-it-designed|video)[^\\s\"'()\\[\\]]*",
        RegexOption.IGNORE_CASE
    )

    // Direct MP4 / M4V / WEBM
    private val mp4Regex = Regex(
        "https?://[^\\s\"'()\\[\\]]+\\.(?:mp4|m4v|webm)",
        RegexOption.IGNORE_CASE
    )

    // JW.org audio-page URLs
    private val audioUrlRegex = Regex(
        "https?://[\\w./-]*jw\\.org[^\\s\"'()\\[\\]]*" +
        "(?:audio|listen)[^\\s\"'()\\[\\]]*",
        RegexOption.IGNORE_CASE
    )

    // Direct MP3 / M4A / OGG / AAC
    private val mp3Regex = Regex(
        "https?://[^\\s\"'()\\[\\]]+\\.(?:mp3|m4a|ogg|aac)",
        RegexOption.IGNORE_CASE
    )

    // "(10 min)" / "10 minutes" / "video (5:30)" duration hints near URLs
    private val minutesRegex = Regex("\\((\\d{1,3})\\s*min\\)", RegexOption.IGNORE_CASE)

    /**
     * Scan [text] for video/audio references. Returns at most one video +
     * one audio badge per article (deduplicated). Result is stable so cards
     * don't flicker between recompositions.
     */
    fun detect(text: String): List<Detected> {
        if (text.isBlank() || text.length < 10) return emptyList()

        val hits = mutableListOf<Detected>()

        // Prefer explicit "was-it-designed" & video article patterns first.
        videoUrlRegex.find(text)?.let { m ->
            hits += Detected(m.value, "video", extractMinutes(text, m.range.first))
        }
        if (hits.none { it.kind == "video" }) {
            mp4Regex.find(text)?.let { m ->
                hits += Detected(m.value, "video", extractMinutes(text, m.range.first))
            }
        }

        audioUrlRegex.find(text)?.let { m ->
            // Skip if this was actually captured as a video already
            if (hits.none { it.url == m.value })
                hits += Detected(m.value, "audio", extractMinutes(text, m.range.first))
        }
        if (hits.none { it.kind == "audio" }) {
            mp3Regex.find(text)?.let { m ->
                hits += Detected(m.value, "audio", extractMinutes(text, m.range.first))
            }
        }
        return hits
    }

    /** Look for a "(N min)" hint within 80 chars of the URL. */
    private fun extractMinutes(text: String, urlPos: Int): Int {
        val start = maxOf(0, urlPos - 40)
        val end   = minOf(text.length, urlPos + 200)
        val window = text.substring(start, end)
        return minutesRegex.find(window)?.groupValues?.get(1)?.toIntOrNull() ?: 0
    }

    /**
     * v5.4.234cc — Classify a SINGLE, already-extracted URL (e.g. one that
     * arrived via a share-intent or ACTION_VIEW), reusing the exact same
     * patterns [detect] uses for embedded links, so both code paths agree
     * on what counts as a video/audio link — no separate, drifting logic.
     * Returns "video", "audio", or null if the URL doesn't match any
     * known media pattern.
     */
    fun classifySingleUrl(url: String): String? = when {
        videoUrlRegex.containsMatchIn(url) -> "video"
        mp4Regex.containsMatchIn(url)      -> "video"
        audioUrlRegex.containsMatchIn(url) -> "audio"
        mp3Regex.containsMatchIn(url)      -> "audio"
        else -> null
    }

    /**
     * True when [url] itself is a direct, streamable media file (ends in a
     * known video/audio extension) — ExoPlayer can play these immediately
     * with no JW.org API lookup needed at all. False for JW.org video/audio
     * PAGE links (e.g. library/videos, was-it-designed articles), which
     * need a title/key resolved to an actual stream URL first.
     */
    fun isDirectFileUrl(url: String): Boolean =
        mp4Regex.matches(url) || mp3Regex.matches(url) ||
        Regex("\\.(mp4|m4v|webm|mp3|m4a|ogg|aac)(\\?.*)?$", RegexOption.IGNORE_CASE).containsMatchIn(url)

    /**
     * v5.4.252cc — Extract a JW.org natural-key identifier from a share/
     * deep-link URL's QUERY PARAMETERS. JW.org's "finder" deep links
     * (e.g. jw.org/finder?srcid=jwlshare&wtlocale=E&lank=pub-gnj_900_VIDEO)
     * carry the real identifier this way — verified by fetching an actual
     * finder URL and observing the redirect target, which lands on
     * jw.org/en/library/videos/?appLanguage=E&item=pub-gnj_900_VIDEO. The
     * key survives the redirect under a different parameter name (lank →
     * item), so both are checked, along with docid (used by some other
     * JW.org link generators). This is the SAME identifier shape as
     * MediaItem.jwKey (JwMediaApi's languageAgnosticNaturalKey), so a hit
     * here can be looked up directly in the offline media cache.
     *
     * Returns null when none of these parameters are present — e.g. for
     * ordinary jw.org video PAGE URLs, which carry no such parameter and
     * are already handled by PageMediaResolver / the path-slug fallback.
     */
    fun extractNaturalKey(url: String): String? {
        val uri = runCatching { android.net.Uri.parse(url) }.getOrNull() ?: return null
        return listOf("lank", "item", "docid")
            .firstNotNullOfOrNull { param -> uri.getQueryParameter(param)?.trim()?.ifBlank { null } }
    }

    /**
     * v5.4.252cc — Media type implied by a natural key's own suffix
     * (_VIDEO / _AUDIO) — a direct, reliable signal straight from JW.org's
     * own key format, no guessing needed once a key is found. Returns
     * null when the key doesn't end in either (some keys reference
     * non-media publications).
     */
    fun mediaTypeFromKey(key: String): String? = when {
        key.endsWith("_VIDEO", ignoreCase = true) -> "video"
        key.endsWith("_AUDIO", ignoreCase = true) -> "audio"
        else -> null
    }
}
