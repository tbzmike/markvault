package com.tebogo.markvault.ai

import com.tebogo.markvault.llm.ChatModelCatalog
import com.tebogo.markvault.llm.ChatModelDescriptor
import com.tebogo.markvault.llm.LlmManager
import com.tebogo.markvault.llm.fileIn
import java.io.File

/**
 * v5.4.73 — On-device LLM query expander for multi-query retrieval.
 *
 * ## Critical: unload-after-expand
 *
 * The LLM is loaded, generates query variations, then IMMEDIATELY
 * UNLOADED before returning. This guarantees the LLM and BGE-large
 * embedding model NEVER coexist in RAM — preventing OOM on 6 GB devices.
 *
 * Flow:
 *   1. Load model → generate → collect response
 *   2. UNLOAD model (frees ~900 MB–5.8 GB)
 *   3. Return variations → caller runs semantic search with embedder
 */
class LlmQueryExpander(
    private val filesDir: File,
    private val getActiveDescriptor: () -> ChatModelDescriptor
) : LocalAIProvider {

    override suspend fun expandQuery(query: String): List<String> {
        val count = MultiQueryPreference.getCount()
        if (count == 0) return emptyList()

        val descriptor = getActiveDescriptor()
        val modelFile = descriptor.fileIn(filesDir)
        if (!modelFile.exists() ||
            modelFile.length() < ChatModelCatalog.MIN_PLAUSIBLE_MODEL_BYTES
        ) {
            return emptyList()
        }

        return try {
            LlmManager.load(modelFile.absolutePath)

            val prompt = buildPrompt(query, count)
            val response = StringBuilder()
            LlmManager.generate(prompt).collect { chunk -> response.append(chunk) }

            parseVariations(response.toString())
        } catch (e: Throwable) {
            android.util.Log.e("LlmQueryExpander", "Expansion failed", e)
            emptyList()
        } finally {
            // CRITICAL: always unload. Frees the model's RAM before
            // the embedder runs semantic search. This is THE OOM fix.
            runCatching { LlmManager.unload() }
        }
    }

    override fun modelName(): String = getActiveDescriptor().shortName

    private fun buildPrompt(query: String, count: Int): String =
        """Generate exactly $count alternative search queries for a Bible research database.
Each query should use different wording to target the same information.
Output ONLY the queries, one per line, no numbering, no explanations.

Query: $query

Alternative queries:"""

    private fun parseVariations(raw: String): List<String> =
        raw.lines()
            .map { line ->
                line.trim()
                    .trimStart('-', '*', '\u2022')
                    .trimStart { it.isDigit() || it == '.' || it == ')' || it == ' ' }
                    .trim()
            }
            .filter { it.length >= 5 }
            .distinct()
}
