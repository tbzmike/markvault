package com.tebogo.markvault.ai

import com.tebogo.markvault.llm.ChatModelCatalog
import com.tebogo.markvault.llm.ChatModelDescriptor
import com.tebogo.markvault.llm.LlmManager
import com.tebogo.markvault.llm.fileIn
import java.io.File

/**
 * v5.4.74 — On-device LLM query expander for multi-query retrieval.
 *
 * ## Contract with the search pipeline
 *
 * Called ONLY when the user's slider is 4-10 (LLM mode). Below 4, pure
 * Kotlin synonym expansion is used instead (matches working v5.4.66c).
 *
 * ## RAM lifecycle (critical)
 *
 *   1. LlmManager.load(path)      — brings weights into RAM
 *   2. LlmManager.generate(prompt) — produces variations
 *   3. LlmManager.unload()         — releases with forced double-GC
 *      (see LlmManager.unload docs for why plain close() is not enough)
 *
 * By the time expandQuery returns, the LLM is GONE from RAM. The caller
 * (expandedContentSearch) then runs the semantic embedder on a clean
 * heap, exactly like the working v5.4.66c baseline.
 */
class LlmQueryExpander(
    private val filesDir: File,
    private val getActiveDescriptor: () -> ChatModelDescriptor
) : LocalAIProvider {

    override suspend fun expandQuery(query: String): List<String> {
        val count = MultiQueryPreference.getCount()
        if (count == 0) return emptyList()

        val descriptor = getActiveDescriptor()
        val modelFile = descriptor.fileIn(filesDir)
        if (!modelFile.exists() ||
            modelFile.length() < ChatModelCatalog.MIN_PLAUSIBLE_MODEL_BYTES
        ) {
            return emptyList()
        }

        return try {
            LlmManager.load(modelFile.absolutePath)
            val prompt = buildPrompt(query, count)
            val response = StringBuilder()
            LlmManager.generate(prompt).collect { chunk -> response.append(chunk) }
            parseVariations(response.toString())
        } catch (e: Throwable) {
            android.util.Log.e("LlmQueryExpander", "Expansion failed", e)
            emptyList()
        } finally {
            // ALWAYS unload — this is the critical OOM prevention.
            // LlmManager.unload does forced GC internally.
            runCatching { LlmManager.unload() }
        }
    }

    override fun modelName(): String = getActiveDescriptor().shortName

    private fun buildPrompt(query: String, count: Int): String =
        """Generate exactly $count alternative search queries for a Bible research database.
Each query should use different wording to target the same information.
Output ONLY the queries, one per line, no numbering, no explanations.

Query: $query

Alternative queries:"""

    private fun parseVariations(raw: String): List<String> =
        raw.lines()
            .map { line ->
                line.trim()
                    .trimStart('-', '*', '\u2022')
                    .trimStart { it.isDigit() || it == '.' || it == ')' || it == ' ' }
                    .trim()
            }
            .filter { it.length >= 5 }
            .distinct()
}
