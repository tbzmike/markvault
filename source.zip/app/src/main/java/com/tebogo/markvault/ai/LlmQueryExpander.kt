package com.tebogo.markvault.ai

import com.tebogo.markvault.llm.ChatModelCatalog
import com.tebogo.markvault.llm.ChatModelDescriptor
import com.tebogo.markvault.llm.LlmManager
import com.tebogo.markvault.llm.fileIn
import java.io.File

/**
 * v5.4.59 — Concrete implementation of [LocalAIProvider] that uses [LlmManager]
 * to generate multiple semantic query variations from a single user query.
 *
 * Used **exclusively** in the multi-query retrieval pipeline. NOT for chat.
 *
 * ## How it works
 *
 *   1. Resolves the currently active retrieval model from [ChatModelCatalog].
 *   2. Loads the model via [LlmManager.load] (idempotent — no-op if the same
 *      model is already in RAM).
 *   3. Sends a tightly-worded prompt asking for exactly N alternative queries.
 *   4. Parses the response into a clean `List<String>`.
 *
 * ## Prompt design
 *
 * The prompt is intentionally minimal and directive:
 *   • No system-message preamble (avoids the model echoing role boilerplate).
 *   • "Output ONLY the queries, one per line" prevents prose framing.
 *   • The Bible-research context aligns with MarkVault's domain so the model
 *     generates relevant paraphrases rather than generic rewrites.
 *
 * ## Thread safety
 *
 * [LlmManager] is guarded by its own [kotlinx.coroutines.sync.Mutex].
 * [expandQuery] is a suspend function and must be called from a coroutine.
 * Multiple concurrent calls serialise through the LlmManager lock.
 */
class LlmQueryExpander(
    private val filesDir: File,
    /** Lambda that returns the currently-active retrieval model descriptor. */
    private val getActiveDescriptor: () -> ChatModelDescriptor
) : LocalAIProvider {

    /**
     * Generate [MultiQueryPreference.getCount] semantic variations of [query].
     *
     * Returns an empty list (not an exception) when:
     *   • the active model is not yet installed, or
     *   • [MultiQueryPreference.getCount] is 0.
     *
     * Callers should fall back to normal single-query search when the list is empty.
     */
    override suspend fun expandQuery(query: String): List<String> {
        val count = MultiQueryPreference.getCount()
        if (count == 0) return emptyList()

        val descriptor = getActiveDescriptor()
        val modelFile = descriptor.fileIn(filesDir)
        if (!modelFile.exists() ||
            modelFile.length() < ChatModelCatalog.MIN_PLAUSIBLE_MODEL_BYTES
        ) {
            // Model not downloaded — silent fallback, caller handles it.
            return emptyList()
        }

        // Load (idempotent: no-op if this model path is already in RAM).
        LlmManager.load(modelFile.absolutePath)

        val prompt = buildPrompt(query, count)
        val response = StringBuilder()
        LlmManager.generate(prompt).collect { chunk -> response.append(chunk) }

        return parseVariations(response.toString())
    }

    /** Short label shown in status UI. */
    override fun modelName(): String = getActiveDescriptor().shortName

    // ── Internal helpers ─────────────────────────────────────────────────────

    /**
     * Build the generation prompt. Kept terse so the small models don't
     * get confused by elaborate role instructions.
     */
    private fun buildPrompt(query: String, count: Int): String =
        """Generate exactly $count alternative search queries for a Bible research database.
Each query should use different wording to target the same information.
Output ONLY the queries — one per line, no numbering, no explanations.

Query: $query

Alternative queries:"""

    /**
     * Parse raw LLM output into a clean list of query strings.
     * Strips leading bullets, numbers, dashes, blank lines, and very-short lines.
     */
    private fun parseVariations(raw: String): List<String> =
        raw.lines()
            .map { line ->
                line.trim()
                    .trimStart('-', '*', '•', '\u2022')
                    .trimStart { it.isDigit() || it == '.' || it == ')' || it == ' ' }
                    .trim()
            }
            .filter { it.length >= 5 }  // discard noise / empty lines
            .distinct()
}
