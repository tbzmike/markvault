package com.tebogo.markvault.ui

import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Search
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.material3.Button
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Slider
import androidx.compose.material3.SmallFloatingActionButton
import androidx.compose.material3.Switch
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.key
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.navigation.NavController
import com.tebogo.markvault.AppViewModel
import com.tebogo.markvault.ai.T5ExpansionMode
import com.tebogo.markvault.search.isInstalled
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.size
import kotlinx.coroutines.launch

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SettingsScreen(vm: AppViewModel, nav: NavController) {
    val libraryUri by vm.libraryUri.collectAsStateWithLifecycle()
    val notes by vm.notes.collectAsStateWithLifecycle()
    val progress by vm.progress.collectAsStateWithLifecycle()
    val fontScale by vm.fontScale.collectAsStateWithLifecycle()
    // v5.4.121cc — Was `var t5Mode by remember { mutableStateOf(BUILTIN) }`,
    // an ephemeral Compose local with no backing store: it reset to
    // BUILTIN on every recomposition, screen re-entry, and process
    // restart regardless of what the user picked, and switching it never
    // actually changed which engine ran a search. Now reads/writes the
    // persisted selection in the ViewModel (see [AppViewModel.t5ExpansionMode]).
    val t5Mode by vm.t5ExpansionMode.collectAsStateWithLifecycle()
    val t5Installed by vm.t5Installed.collectAsStateWithLifecycle()
    val t5DownloadProgress by vm.t5DownloadProgress.collectAsStateWithLifecycle()
    val t5Error by vm.t5Error.collectAsStateWithLifecycle()
    val picker = rememberLauncherForActivityResult(
        ActivityResultContracts.OpenDocumentTree()
    ) { uri ->
        if (uri != null) vm.setLibrary(uri)
    }
    var selectedSettingsCategory by remember { mutableStateOf<String?>(null) }
    val settingsScrollState = rememberScrollState()
    LaunchedEffect(selectedSettingsCategory) {
        settingsScrollState.scrollTo(0)
    }

    Scaffold(
        topBar = { TopAppBar(title = { Text("\u2699\uFE0F Settings") }) },
        bottomBar = {
            MarkVaultBottomBar(
                nav = nav, vm = vm,
                extraActions = {
                    IconButton(onClick = { nav.navigate("search") }) {
                        Icon(Icons.Default.Search, contentDescription = "Search library")
                    }
                }
            )
        }
    ) { pad ->
        Column(
            Modifier
                .padding(pad)
                .fillMaxSize()
                .verticalScroll(settingsScrollState)
                .padding(16.dp)
        ) {
            SettingsCategoryHub(
                selectedCategory = selectedSettingsCategory,
                onSelect = { selectedSettingsCategory = it }
            )
            if (selectedSettingsCategory != null) {
                Spacer(Modifier.height(12.dp))
                TextButton(onClick = { selectedSettingsCategory = null }) {
                    Text("← All settings")
                }
                Spacer(Modifier.height(4.dp))
            }

            if (selectedSettingsCategory == SETTINGS_AI) {
            MultiQuerySlider(vm = vm)
            T5ExpansionSettingsCard(
                mode = t5Mode,
                installed = t5Installed,
                downloadProgress = t5DownloadProgress,
                error = t5Error,
                onModeChanged = { vm.setT5ExpansionMode(it) },
                onDownloadClick = { vm.downloadT5Model() }
            )
            Spacer(Modifier.height(28.dp))
            SettingsSubheading("Embeddings & Model Management")
            SemanticSearchSection(vm, showCore = false, showAi = false, showEmbeddings = true)
            Spacer(Modifier.height(28.dp))
            SettingsSubheading("LLM Query Expansion")
            SemanticSearchSection(vm, showCore = false, showAi = true, showEmbeddings = false)
            }

            if (selectedSettingsCategory == SETTINGS_LIBRARY) {
            Text("\uD83D\uDCDA Library", fontWeight = FontWeight.Bold, fontSize = 16.sp)
            Spacer(Modifier.height(8.dp))
            val mdCount = remember(notes) { notes.count { it.fileType != "pdf" } }
            val pdfCount = remember(notes) { notes.count { it.fileType == "pdf" } }
            Text(
                buildString {
                    append("Indexed: ${notes.size} files")
                    if (pdfCount > 0) append("  (\uD83D\uDCC4 $mdCount md · \uD83D\uDCD5 $pdfCount pdf)")
                },
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                fontSize = 13.sp
            )
            if (progress.running) {
                Spacer(Modifier.height(8.dp))
                LinearProgressIndicator(Modifier.fillMaxWidth())
                Text(
                    "\u23F3 ${progress.phase} ${progress.done} / ${progress.total}",
                    fontSize = 12.sp,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
            Spacer(Modifier.height(12.dp))
            Row {
                Button(
                    onClick = { vm.reindex() },
                    enabled = libraryUri != null && !progress.running
                ) { Text("\u21BB  Re-index") }
                Spacer(Modifier.width(12.dp))
                OutlinedButton(
                    onClick = { picker.launch(null) },
                    enabled = !progress.running
                ) { Text("\uD83D\uDCC1 Change folder") }
            }

            // ── v5.4.179cc — Backup & Restore ──
            // Wires up BackupManager.kt (data/BackupManager.kt), which
            // already existed fully-built and correct — WAL checkpoint,
            // full note index + semantic embeddings + settings, atomic
            // restore — but was never connected to any UI button. Placed
            // second, right after Library, for visibility: this exists
            // specifically so a long re-embedding pass (which can run for
            // many hours) isn't a single point of failure — back up
            // before or during a long run, restore instead of redoing it
            // if something goes wrong.
            Spacer(Modifier.height(28.dp))
            Text("\uD83D\uDCBE Backup \u0026 restore", fontWeight = FontWeight.Bold, fontSize = 16.sp)
            Spacer(Modifier.height(6.dp))
            Text(
                "Backs up only your settings, library index, and note semantic embeddings in " +
                    "one verified file. Article files, browser/PDF history, bookmarks, annotations, " +
                    "media caches, playlists, activity logs, and downloaded AI models are excluded. " +
                    "Backups include integrity checks and transactional restore protection.",
                fontSize = 12.sp,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
            Spacer(Modifier.height(10.dp))
            val backupCtx = androidx.compose.ui.platform.LocalContext.current
            val backupScope = rememberCoroutineScope()
            var backupInProgress by remember { mutableStateOf(false) }
            var restoreInProgress by remember { mutableStateOf(false) }
            var backupStatusMsg by remember { mutableStateOf<String?>(null) }
            var pendingRestoreUri by remember { mutableStateOf<android.net.Uri?>(null) }
            var pendingRestoreManifest by remember { mutableStateOf<org.json.JSONObject?>(null) }

            val createBackupLauncher = rememberLauncherForActivityResult(
                ActivityResultContracts.CreateDocument("application/zip")
            ) { uri ->
                if (uri != null) {
                    backupInProgress = true
                    backupStatusMsg = null
                    backupScope.launch {
                        val ok = com.tebogo.markvault.data.BackupManager.createBackup(
                            backupCtx, uri, com.tebogo.markvault.BuildConfig.VERSION_NAME
                        )
                        backupInProgress = false
                        backupStatusMsg = if (ok) "\u2705 Backup saved."
                            else "\u26A0\uFE0F Backup failed \u2014 check available storage."
                    }
                }
            }
            val openRestoreLauncher = rememberLauncherForActivityResult(
                ActivityResultContracts.OpenDocument()
            ) { uri ->
                if (uri != null) {
                    backupScope.launch {
                        val manifest = com.tebogo.markvault.data.BackupManager.readManifest(backupCtx, uri)
                        if (manifest != null) {
                            pendingRestoreUri = uri
                            pendingRestoreManifest = manifest
                        } else {
                            backupStatusMsg = "\u26A0\uFE0F Not a valid MarkVault backup file."
                        }
                    }
                }
            }

            Row(Modifier.fillMaxWidth()) {
                Button(
                    onClick = {
                        val stamp = java.text.SimpleDateFormat(
                            "yyyy-MM-dd-HHmm", java.util.Locale.US
                        ).format(java.util.Date())
                        createBackupLauncher.launch("markvault-backup-$stamp.zip")
                    },
                    enabled = !backupInProgress && !restoreInProgress
                ) { Text(if (backupInProgress) "Backing up\u2026" else "\uD83D\uDCBE Backup now") }
                Spacer(Modifier.width(12.dp))
                OutlinedButton(
                    onClick = { openRestoreLauncher.launch(arrayOf("application/zip")) },
                    enabled = !backupInProgress && !restoreInProgress
                ) { Text("Restore\u2026") }
            }
            backupStatusMsg?.let { msg ->
                Spacer(Modifier.height(6.dp))
                Text(msg, fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }

            if (pendingRestoreUri != null && pendingRestoreManifest != null) {
                val manifest = pendingRestoreManifest!!
                val backupWhen = runCatching {
                    java.text.SimpleDateFormat("d MMM yyyy, HH:mm", java.util.Locale.US)
                        .format(java.util.Date(manifest.optLong("timestamp")))
                }.getOrDefault("an unknown time")
                val backupVersion = manifest.optString("version", "an unknown version")
                AlertDialog(
                    onDismissRequest = {
                        pendingRestoreUri = null
                        pendingRestoreManifest = null
                    },
                    title = { Text("Restore this backup?") },
                    text = {
                        Text(
                            "This backup was made $backupWhen with MarkVault $backupVersion. " +
                                "Restoring replaces only your library index, note semantic embeddings, " +
                                "and settings with what's in this file. Article files and unrelated app " +
                                "data are not restored. MarkVault validates the backup and applies the " +
                                "database changes transactionally. The app will close itself after a " +
                                "successful restore; just reopen it."
                        )
                    },
                    confirmButton = {
                        Button(onClick = {
                            val uriToRestore = pendingRestoreUri!!
                            pendingRestoreUri = null
                            pendingRestoreManifest = null
                            restoreInProgress = true
                            backupScope.launch {
                                val ok = com.tebogo.markvault.data.BackupManager.applyBackup(backupCtx, uriToRestore)
                                if (ok) {
                                    android.os.Process.killProcess(android.os.Process.myPid())
                                } else {
                                    restoreInProgress = false
                                    backupStatusMsg = "\u26A0\uFE0F Restore failed \u2014 your current data is untouched."
                                }
                            }
                        }) { Text("Restore") }
                    },
                    dismissButton = {
                        TextButton(onClick = {
                            pendingRestoreUri = null
                            pendingRestoreManifest = null
                        }) { Text("Cancel") }
                    }
                )
            }

            }

            if (selectedSettingsCategory == SETTINGS_APPEARANCE) {
            Spacer(Modifier.height(28.dp))
            Text("\uD83D\uDD20 Reading font size", fontWeight = FontWeight.Bold, fontSize = 16.sp)
            Slider(
                value = fontScale,
                onValueChange = { vm.setFontScale(it) },
                valueRange = 0.7f..2.0f
            )
            Text("Sample text at current size", fontSize = (16f * fontScale).sp)

            }

            if (selectedSettingsCategory == SETTINGS_WEBVIEWER) {
            Spacer(Modifier.height(28.dp))
            Text("\uD83C\uDF10 Web imports", fontWeight = FontWeight.Bold, fontSize = 16.sp)
            Spacer(Modifier.height(6.dp))
            Text(
                "When you share a web page to MarkVault, the page is rendered, converted to " +
                    "markdown, and saved to this subfolder of your library. Leave blank to save " +
                    "directly to the library root.",
                fontSize = 12.sp,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
            Spacer(Modifier.height(10.dp))
            val importsSubfolder by vm.importsSubfolder.collectAsStateWithLifecycle()
            var subfolderText by remember(importsSubfolder) {
                mutableStateOf(importsSubfolder)
            }
            OutlinedTextField(
                value = subfolderText,
                onValueChange = { subfolderText = it.filter { ch -> ch != '/' && ch != '\\' } },
                singleLine = true,
                modifier = Modifier.fillMaxWidth(),
                placeholder = { Text("e.g. Web Clippings") },
                label = { Text("Import subfolder") }
            )
            Spacer(Modifier.height(8.dp))
            Row {
                Button(
                    onClick = { vm.setImportsSubfolder(subfolderText.trim()) },
                    enabled = subfolderText != importsSubfolder
                ) { Text("Save folder name") }
                Spacer(Modifier.width(12.dp))
                OutlinedButton(onClick = { picker.launch(null) }) {
                    Text("\uD83D\uDD13 Re-grant library access")
                }
            }
            Spacer(Modifier.height(4.dp))
            Text(
                "If web imports fail with a read-only error, tap " +
                    "\u201CRe-grant library access\u201D and pick the same library folder again \u2014 " +
                    "this upgrades read-only permission to read+write.",
                fontSize = 11.sp,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )

            // v5.4.109cc — Dedup section. Each signal has its own toggle so
            // the user can diagnose over-eager skipping ("1000 selected,
            // 980 skipped") by flipping one leg off and re-running the
            // batch to see what the URL leg vs the title leg contributes
            // to the skip count.
            Spacer(Modifier.height(28.dp))
            Text(
                "\uD83E\uDDF9 Duplicate detection",
                fontWeight = FontWeight.Bold, fontSize = 16.sp
            )
            Spacer(Modifier.height(6.dp))
            Text(
                "When you batch-save articles from the WebViewer, MarkVault checks whether each " +
                    "one is already in your library and skips duplicates. These toggles control " +
                    "WHICH signals count as a duplicate. Turning either off widens the net — " +
                    "articles that MarkVault would have skipped will be re-fetched and saved as " +
                    "new copies.",
                fontSize = 12.sp,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
            Spacer(Modifier.height(14.dp))

            // ── Toggle 1: URL match ──────────────────────────────────
            val dedupByUrl by vm.dedupByUrl.collectAsStateWithLifecycle()
            Row(
                Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column(Modifier.weight(1f)) {
                    Text(
                        "\uD83D\uDD17 URL match",
                        fontSize = 14.sp, fontWeight = FontWeight.Medium
                    )
                    Text(
                        "Skip an article if its source URL (canonicalised \u2014 " +
                            "fragment stripped, trailing slash trimmed, host lower-cased) " +
                            "matches a URL already stored for a library note. The URL cache " +
                            "is backfilled from every markdown / HTML note on launch, so this " +
                            "catches cross-format duplicates.",
                        fontSize = 11.sp,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
                Spacer(Modifier.width(12.dp))
                Switch(
                    checked = dedupByUrl,
                    onCheckedChange = { vm.setDedupByUrl(it) }
                )
            }

            Spacer(Modifier.height(18.dp))

            // ── Toggle 2: Title / heading match ───────────────────────
            val dedupByTitle by vm.dedupByTitle.collectAsStateWithLifecycle()
            Row(
                Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column(Modifier.weight(1f)) {
                    Text(
                        "\uD83D\uDCDD Title / heading match",
                        fontSize = 14.sp, fontWeight = FontWeight.Medium
                    )
                    Text(
                        "Skip an article if the anchor / heading text captured on the head " +
                            "page (lower-cased, punctuation stripped) exactly matches the " +
                            "title of a note already in the library. Only fires for titles " +
                            "of 15+ normalised characters so generic labels like \u201CRead " +
                            "more\u201D never trigger it. If your \u201C980 of 1000 " +
                            "skipped\u201D count feels wrong, turn this off first \u2014 the " +
                            "URL leg alone is usually enough for jw.org content.",
                        fontSize = 11.sp,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
                Spacer(Modifier.width(12.dp))
                Switch(
                    checked = dedupByTitle,
                    onCheckedChange = { vm.setDedupByTitle(it) }
                )
            }

            Spacer(Modifier.height(12.dp))
            Text(
                "\u2139\uFE0F Both defaults are ON. Filenames are NOT used as a signal " +
                    "\u2014 series like \u201CQuestions From Readers\u201D share a base " +
                    "filename and would false-positive every article after the first.",
                fontSize = 11.sp,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )

            // v5.4.111cc — Search chip visibility. Lets the user hide any
            // of the five chips under the search bar to declutter it.
            }

            if (selectedSettingsCategory == SETTINGS_SEARCH) {
            Spacer(Modifier.height(28.dp))
            Text(
                "\uD83D\uDD0D Search bar chips",
                fontWeight = FontWeight.Bold, fontSize = 16.sp
            )
            Spacer(Modifier.height(6.dp))
            Text(
                "Choose which quick-toggle chips appear under the search bar. Hiding a chip " +
                    "doesn't change what it did \u2014 it just removes the button. The " +
                    "corresponding setting keeps whatever value it had; you can still change " +
                    "it here or by re-showing the chip.",
                fontSize = 12.sp,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
            Spacer(Modifier.height(14.dp))

            val cSemantic by vm.chipSemantic.collectAsStateWithLifecycle()
            SearchChipToggleRow(
                "\uD83E\uDDE0 Semantic",
                "The semantic search on/off chip.",
                cSemantic
            ) { vm.setChipSemantic(it) }

            Spacer(Modifier.height(14.dp))
            val cRerank by vm.chipRerank.collectAsStateWithLifecycle()
            SearchChipToggleRow(
                "\uD83C\uDFAF Rerank",
                "The reranker on/off chip (or \u201CInstall rerank\u201D when the model " +
                    "isn't downloaded yet).",
                cRerank
            ) { vm.setChipRerank(it) }

            Spacer(Modifier.height(14.dp))
            val cRerankPct by vm.chipRerankPct.collectAsStateWithLifecycle()
            SearchChipToggleRow(
                "Rerank %",
                "The chip that toggles the live reranking-progress percentage indicator.",
                cRerankPct
            ) { vm.setChipRerankPct(it) }

            Spacer(Modifier.height(14.dp))
            val cSemanticPct by vm.chipSemanticPct.collectAsStateWithLifecycle()
            SearchChipToggleRow(
                "Semantic %",
                "The chip that toggles the live semantic-search progress percentage indicator.",
                cSemanticPct
            ) { vm.setChipSemanticPct(it) }

            Spacer(Modifier.height(14.dp))
            val cAccurate by vm.chipAccurate.collectAsStateWithLifecycle()
            SearchChipToggleRow(
                "\u2705 Get accurate results",
                "The exact-phrase chip (renamed \u201CGet accurate results\u201D). Flashes " +
                    "green after each search so you know results are ready.",
                cAccurate
            ) { vm.setChipAccurate(it) }

            }

            if (selectedSettingsCategory == SETTINGS_READING) {
            Spacer(Modifier.height(28.dp))
            Text("\u26A1 Performance", fontWeight = FontWeight.Bold, fontSize = 16.sp)
            Spacer(Modifier.height(6.dp))
            Text(
                "Heavy visual features are off by default for snappy scrolling on every " +
                    "device. If you're on a higher-end phone, switch them on for the full " +
                    "experience.",
                fontSize = 12.sp,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
            Spacer(Modifier.height(14.dp))

            // ── Smart styling on all documents ──
            val smartStylingAllDocs by vm.smartStylingAllDocs.collectAsStateWithLifecycle()
            Row(
                Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column(Modifier.weight(1f)) {
                    Text(
                        "\uD83C\uDFA8 Smart styling on all documents",
                        fontSize = 14.sp, fontWeight = FontWeight.Medium
                    )
                    Text(
                        "Auto-colourize numbers, references, percentages, quoted phrases " +
                            "and ALL-CAPS terms even in very long articles. May make " +
                            "scrolling stutter on 60,000+ character files.",
                        fontSize = 11.sp,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
                Spacer(Modifier.width(12.dp))
                Switch(
                    checked = smartStylingAllDocs,
                    onCheckedChange = { vm.setSmartStylingAllDocs(it) }
                )
            }

            Spacer(Modifier.height(18.dp))

            // ── Swipe to switch tabs ──
            val swipeSwitchTabs by vm.swipeSwitchTabs.collectAsStateWithLifecycle()
            Row(
                Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column(Modifier.weight(1f)) {
                    Text(
                        "\uD83D\uDC48\uD83D\uDC49 Swipe to switch tabs",
                        fontSize = 14.sp, fontWeight = FontWeight.Medium
                    )
                    Text(
                        "Horizontal swipe in the markdown reader jumps to the previous / " +
                            "next open tab. Adds touch-event interception that can mildly " +
                            "slow scrolling. Toolbar \u2190 \u2192 buttons are always available.",
                        fontSize = 11.sp,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
                Spacer(Modifier.width(12.dp))
                Switch(
                    checked = swipeSwitchTabs,
                    onCheckedChange = { vm.setSwipeSwitchTabs(it) }
                )
            }

            // v5.4.182cc — Bible & Scripture section
            Spacer(Modifier.height(28.dp))
            Text(
                "\uD83D\uDCD6 Bible & Scripture",
                fontWeight = FontWeight.Bold, fontSize = 16.sp
            )
            Spacer(Modifier.height(6.dp))
            Text(
                "When scripture detection is on, references like \u201CMatthew 23:8\u201D in any " +
                    "article become tappable \uD83D\uDFE0 amber links. Tapping one opens your " +
                    "offline NWT chapter at the exact verse, with the verse highlighted. " +
                    "Requires the matching chapter to be saved in your library as an offline " +
                    "HTML file (e.g. saved from wol.jw.org). Falls back to wol.jw.org if the " +
                    "file is not in your library.",
                fontSize = 12.sp,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
            Spacer(Modifier.height(14.dp))
            val scriptureDetectionOn by vm.scriptureDetectionEnabled.collectAsStateWithLifecycle()
            Row(
                Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column(Modifier.weight(1f)) {
                    Text(
                        "\uD83D\uDCD6 Scripture detection",
                        fontSize = 14.sp, fontWeight = FontWeight.Medium
                    )
                    Text(
                        if (scriptureDetectionOn)
                            "On \u2014 scripture references become tappable amber links"
                        else
                            "Off \u2014 references display as plain text",
                        fontSize = 11.sp,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
                Spacer(Modifier.width(12.dp))
                Switch(
                    checked = scriptureDetectionOn,
                    onCheckedChange = { vm.setScriptureDetectionEnabled(it) }
                )
            }

            // v5.4.145cc — Search & Fullscreen UI toggles
            }

            if (selectedSettingsCategory == SETTINGS_SEARCH) {
            Spacer(Modifier.height(18.dp))
            Text(
                "\uD83D\uDD0D Search & Fullscreen UI",
                fontWeight = FontWeight.Bold, fontSize = 16.sp
            )
            Spacer(Modifier.height(6.dp))
            Text(
                "Control visibility of search result filtering and web search buttons. Enable fullscreen mode to hide toolbars on scroll.",
                fontSize = 12.sp,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
            Spacer(Modifier.height(10.dp))

            // ── Toggle: Hide web search buttons ──
            val hideWebButtons by vm.hideWebSearchButtons.collectAsStateWithLifecycle()
            Row(
                Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column(Modifier.weight(1f)) {
                    Text(
                        "\uD83D\uDC49 Hide web search buttons",
                        fontSize = 14.sp, fontWeight = FontWeight.Medium
                    )
                    Text(
                        "When no matches are found in your library, MarkVault offers buttons to search jw.org, wol.jw.org, and videos. Turn this off to hide those buttons.",
                        fontSize = 11.sp,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
                Spacer(Modifier.width(12.dp))
                Switch(
                    checked = hideWebButtons,
                    onCheckedChange = { vm.setHideWebSearchButtons(it) }
                )
            }

            Spacer(Modifier.height(14.dp))

            // ── Toggle: Hide search chips ──
            val hideChips by vm.hideSearchChips.collectAsStateWithLifecycle()
            Row(
                Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column(Modifier.weight(1f)) {
                    Text(
                        "\uD83C\uDFB2 Hide search filter chips",
                        fontSize = 14.sp, fontWeight = FontWeight.Medium
                    )
                    Text(
                        "Search result filter toggles (Markdown / HTML / PDF). Turn this off to hide them and gain more vertical space for results.",
                        fontSize = 11.sp,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
                Spacer(Modifier.width(12.dp))
                Switch(
                    checked = hideChips,
                    onCheckedChange = { vm.setHideSearchChips(it) }
                )
            }

            Spacer(Modifier.height(14.dp))

            // ── Toggle: Hide embedding model selector ──
            val hideEmbedding by vm.hideEmbeddingSelector.collectAsStateWithLifecycle()
            Row(
                Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column(Modifier.weight(1f)) {
                    Text(
                        "\uD83E\uDDE0 Hide embedding model selector",
                        fontSize = 14.sp, fontWeight = FontWeight.Medium
                    )
                    Text(
                        "Embedding model dropdown in the search bar. Turn this off to hide it when you don't frequently switch models.",
                        fontSize = 11.sp,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
                Spacer(Modifier.width(12.dp))
                Switch(
                    checked = hideEmbedding,
                    onCheckedChange = { vm.setHideEmbeddingSelector(it) }
                )
            }

            Spacer(Modifier.height(14.dp))

            // ── Toggle: Enable fullscreen mode ──
            val enableFullscreen by vm.enableFullscreenMode.collectAsStateWithLifecycle()
            Row(
                Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column(Modifier.weight(1f)) {
                    Text(
                        "\uD83D\uDCFD\uFE0F Fullscreen mode",
                        fontSize = 14.sp, fontWeight = FontWeight.Medium
                    )
                    Text(
                        "When on, search and article toolbars (status bar preserved) hide when you scroll down and reappear when you scroll up. Maximizes reading space.",
                        fontSize = 11.sp,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
                Spacer(Modifier.width(12.dp))
                Switch(
                    checked = enableFullscreen,
                    onCheckedChange = { vm.setEnableFullscreenMode(it) }
                )
            }

            }

            if (selectedSettingsCategory == SETTINGS_WEBVIEWER) {
            Spacer(Modifier.height(14.dp))

            // ── Toggle: Enable web article auto-save ──
            val enableWebAutosave by vm.enableWebAutosave.collectAsStateWithLifecycle()
            Row(
                Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column(Modifier.weight(1f)) {
                    Text(
                        "💾 Auto-save web articles",
                        fontSize = 14.sp, fontWeight = FontWeight.Medium
                    )
                    Text(
                        "When on, web pages viewed in the browser are automatically saved to your library if not already present. Articles are saved with all CSS and images. A notification confirms the auto-save.",
                        fontSize = 11.sp,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
                Spacer(Modifier.width(12.dp))
                Switch(
                    checked = enableWebAutosave,
                    onCheckedChange = { vm.setEnableWebAutosave(it) }
                )
            }

            }

            if (selectedSettingsCategory == SETTINGS_SEARCH) {
            Spacer(Modifier.height(14.dp))

            // ── Toggle: Show "Search on jw.org" button ──
            val showJwSearchButton by vm.showJwSearchButton.collectAsStateWithLifecycle()
            Row(
                Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column(Modifier.weight(1f)) {
                    Text(
                        "🔍 Search on jw.org button",
                        fontSize = 14.sp, fontWeight = FontWeight.Medium
                    )
                    Text(
                        "When on, a floating button appears in search results allowing you to search jw.org and wol.jw.org for the same query.",
                        fontSize = 11.sp,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
                Spacer(Modifier.width(12.dp))
                Switch(
                    checked = showJwSearchButton,
                    onCheckedChange = { vm.setShowJwSearchButton(it) }
                )
            }

            }

            if (selectedSettingsCategory == SETTINGS_WEBVIEWER) {
            Spacer(Modifier.height(28.dp))
            // v5.4.83cc — Corrected routing: off means "still in-app
            // WebView, but full-screen instead of bottom sheet" — not
            // "hand to system browser".
            // v5.4.84cc — Description rewritten to reference the
            // sibling full-screen toggle below; both toggles together
            // form a truth table over the two in-app viewer modes.
            Spacer(Modifier.height(14.dp))
            val webPopupOn by vm.webViewerPopupEnabled.collectAsStateWithLifecycle()
            Row(
                Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column(Modifier.weight(1f)) {
                    Text(
                        "\uD83C\uDF10 In-app WebViewer popup",
                        fontSize = 14.sp, fontWeight = FontWeight.Medium
                    )
                    Text(
                        "When on, links opened from MarkVault use a movable, resizable " +
                            "floating WebViewer with minimize, maximize and close controls. " +
                            "The same WebView session survives resize/maximize so history " +
                            "and page state stay intact. When off, links follow the " +
                            "full-screen setting below.",
                        fontSize = 11.sp,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
                Spacer(Modifier.width(12.dp))
                Switch(
                    checked = webPopupOn,
                    onCheckedChange = { vm.setWebViewerPopupEnabled(it) }
                )
            }

            // v5.4.274cc — Independent switch for the dismissible unsaved-page prompt.
            Spacer(Modifier.height(14.dp))
            val webSavePromptOn by vm.webSavePromptEnabled.collectAsStateWithLifecycle()
            Row(
                Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column(Modifier.weight(1f)) {
                    Text(
                        "💾 Ask to save unsaved web pages",
                        fontSize = 14.sp, fontWeight = FontWeight.Medium
                    )
                    Text(
                        "When on, WebViewer shows the 'Not in library · Save' prompt only when " +
                            "the current online article is not already present as offline HTML or Markdown. " +
                            "Turn this off to hide that prompt completely.",
                        fontSize = 11.sp,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
                Spacer(Modifier.width(12.dp))
                Switch(
                    checked = webSavePromptOn,
                    onCheckedChange = { vm.setWebSavePromptEnabled(it) }
                )
            }

            // v5.4.272cc — One reusable floating popup vs a separate window per link.
            Spacer(Modifier.height(14.dp))
            val popupMultiWindow by vm.webPopupMultipleWindows.collectAsStateWithLifecycle()
            Column(Modifier.fillMaxWidth()) {
                Text(
                    "Floating link windows",
                    fontSize = 14.sp, fontWeight = FontWeight.Medium
                )
                Text(
                    "Choose whether new links reuse the current floating WebViewer " +
                        "(preserving one back-history stack) or open as independent " +
                        "movable popup windows.",
                    fontSize = 11.sp,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
                Spacer(Modifier.height(8.dp))
                Row(
                    Modifier.fillMaxWidth(),
                    horizontalArrangement = androidx.compose.foundation.layout.Arrangement.spacedBy(8.dp)
                ) {
                    androidx.compose.material3.FilterChip(
                        selected = !popupMultiWindow,
                        onClick = { vm.setWebPopupMultipleWindows(false) },
                        label = { Text("Reuse same popup") },
                        modifier = Modifier.weight(1f),
                        enabled = webPopupOn
                    )
                    androidx.compose.material3.FilterChip(
                        selected = popupMultiWindow,
                        onClick = { vm.setWebPopupMultipleWindows(true) },
                        label = { Text("New popup per link") },
                        modifier = Modifier.weight(1f),
                        enabled = webPopupOn
                    )
                }
            }

            // v5.4.84cc — Sibling toggle for the in-app WebViewer's
            // full-screen mode. Together with the popup toggle above
            // this gives independent control over both in-app viewer
            // modes; when both are off, tapped links go to the system
            // browser.
            Spacer(Modifier.height(14.dp))
            val webFullScreenOn by vm.webViewerFullScreenEnabled.collectAsStateWithLifecycle()
            Row(
                Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column(Modifier.weight(1f)) {
                    Text(
                        "\uD83D\uDDBC\uFE0F In-app WebViewer full-screen",
                        fontSize = 14.sp, fontWeight = FontWeight.Medium
                    )
                    Text(
                        "When on, a floating WebViewer can maximize in place to fill " +
                            "the app without replacing its WebView session. If floating " +
                            "popup mode is off, links open directly in the in-app " +
                            "full-screen WebViewer. When both modes are off, links use " +
                            "the system browser.",
                        fontSize = 11.sp,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
                Spacer(Modifier.width(12.dp))
                Switch(
                    checked = webFullScreenOn,
                    onCheckedChange = { vm.setWebViewerFullScreenEnabled(it) }
                )
            }

            }

            if (selectedSettingsCategory == SETTINGS_APPEARANCE) {
            Spacer(Modifier.height(28.dp))
            Text("\uD83C\uDFA8 Appearance", fontWeight = FontWeight.Bold, fontSize = 16.sp)
            Spacer(Modifier.height(6.dp))
            Text(
                "Pick the theme that drives both the article viewer and the app chrome.",
                fontSize = 12.sp,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
            Spacer(Modifier.height(10.dp))
            var themePickerOpen by remember { mutableStateOf(false) }
            val currentTheme by vm.theme.collectAsStateWithLifecycle()
            androidx.compose.material3.OutlinedButton(
                onClick = { themePickerOpen = true },
                modifier = Modifier.fillMaxWidth()
            ) {
                val label = when (currentTheme) {
                    "black"             -> "\u26AB AMOLED black"
                    "sepia"             -> "\uD83D\uDCDC Sepia"
                    "dark_sepia"        -> "\uD83D\uDCDC Dark sepia"
                    "grey"              -> "\u2B1C Grey"
                    "sky_blue"          -> "\uD83C\uDF24 Sky blue"
                    "light_grey"        -> "\uD83E\uDEA8 Light grey"
                    "light"             -> "\u2600\uFE0F Light"
                    "hicontrast-dark"   -> "\u26A1 High-contrast dark"
                    "hicontrast-light"  -> "\u26A1 High-contrast light"
                    "ocean"             -> "\uD83C\uDF0A Ocean"
                    "forest"            -> "\uD83C\uDF32 Forest"
                    "obsidian"          -> "\uD83E\uDEA8 Obsidian"
                    "glass_obsidian"    -> "🧊 3D Obsidian Glass"
                    "glass_crystal"     -> "💎 3D Crystal Glass"
                    "custom"            -> "\uD83C\uDFA8 Custom theme"
                    "cream"             -> "\uD83E\uDD5B Cream"
                    "expr_indigo"       -> "\uD83D\uDD8B\uFE0F Expressive indigo"
                    "expr_violet"       -> "\uD83D\uDD2E Expressive violet"
                    "expr_ember"        -> "\uD83D\uDD25 Expressive ember"
                    "expr_rose"         -> "\uD83C\uDF39 Expressive rose"
                    else                -> "\uD83C\uDF11 Dark (grey)"
                }
                Text("Theme: $label")
            }
            if (themePickerOpen) {
                ThemePickerDialog(vm, onDismiss = { themePickerOpen = false })
            }

            // ── v5.4.162cc — UI Animations ──
            // Separate from "Expressive motion" below — this governs the
            // search-stagger / FAB-bounce / tab-slide / shimmer / parallax /
            // swipe-dismiss / typewriter / foldable-callout / theme-color
            // animations added in v5.4.157cc-161cc. ON by default.
            Spacer(Modifier.height(18.dp))
            androidx.compose.material3.HorizontalDivider()
            Spacer(Modifier.height(18.dp))
            Text(
                "\uD83C\uDFAC UI Animations",
                fontWeight = FontWeight.Bold, fontSize = 16.sp
            )
            Spacer(Modifier.height(6.dp))
            Text(
                "Controls the fade-in on search results, button press feedback, " +
                    "tab-switch transitions, loading placeholders, and similar polish " +
                    "throughout the app. On by default.",
                fontSize = 12.sp,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
            Spacer(Modifier.height(12.dp))
            val uiAnimOn by vm.uiAnimEnabled.collectAsStateWithLifecycle()
            // v5.4.164cc — Declared here (not inside `if (uiAnimOn)` below)
            // because the Reroll button further down also needs to read
            // this, outside that block's scope.
            val uiAnimStyleValue by vm.uiAnimStyle.collectAsStateWithLifecycle()
            Row(
                Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column(Modifier.weight(1f)) {
                    Text(
                        "Enable UI animations",
                        fontSize = 14.sp, fontWeight = FontWeight.Medium
                    )
                    Text(
                        if (uiAnimOn) "On \u2014 animations play throughout the app"
                        else "Off \u2014 all UI animations disabled",
                        fontSize = 11.sp,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
                Spacer(Modifier.width(12.dp))
                androidx.compose.material3.Switch(
                    checked = uiAnimOn,
                    onCheckedChange = { vm.setUiAnimEnabled(it) }
                )
            }

            if (uiAnimOn) {
                Spacer(Modifier.height(14.dp))
                val uiAnimSpeedValue by vm.uiAnimSpeed.collectAsStateWithLifecycle()
                Text(
                    "Animation smoothness: ${String.format(java.util.Locale.US, "%.2f", uiAnimSpeedValue)}\u00d7",
                    fontSize = 13.sp, fontWeight = FontWeight.Medium
                )
                Spacer(Modifier.height(4.dp))
                // v5.4.165cc — Range is now 1.0x (original shipped timing,
                // the floor — never goes faster than that) to 3.0x (triple
                // duration, slow and smooth). steps=7 gives 0.25x
                // increments: 1.0, 1.25, 1.5 ... 3.0.
                Slider(
                    value = uiAnimSpeedValue,
                    onValueChange = { vm.setUiAnimSpeed(it) },
                    valueRange = 1.0f..3.0f,
                    steps = 7
                )
                Text(
                    "1.0\u00d7 normal \u2014 3.0\u00d7 slow \u0026 smooth",
                    fontSize = 11.sp,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )

                // v5.4.164cc — Style picker. Six chips: five distinct
                // concrete animation characters plus "Random Mix," which
                // has each FAB independently roll one of the other five
                // every time it appears.
                Spacer(Modifier.height(14.dp))
                Text(
                    "Animation style",
                    fontSize = 13.sp, fontWeight = FontWeight.Medium
                )
                Spacer(Modifier.height(6.dp))
                Row(
                    Modifier
                        .fillMaxWidth()
                        .horizontalScroll(rememberScrollState()),
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    UiAnimStyle.entries.forEach { styleOption ->
                        FilterChip(
                            selected = uiAnimStyleValue == styleOption.name,
                            onClick = { vm.setUiAnimStyle(styleOption.name) },
                            label = { Text("${styleOption.emoji} ${styleOption.label}", fontSize = 12.sp) }
                        )
                    }
                }
            }

            // Live preview — press and hold this exact button. It uses the
            // same fabPressScale() modifier as every real FAB in the app,
            // so if this doesn't visibly shrink on press, the issue is
            // something below the Settings-toggle level (device/runtime),
            // not any individual screen's animation code.
            //
            // v5.4.164cc — "Reroll" button next to it: when the style is
            // Random Mix, tapping Reroll forces the preview button to
            // fully remount (via key(rerollTick)), so fabPressScale's
            // internal remember(uiAnim.style) picks a FRESH random
            // concrete style — letting you compare several right here
            // without leaving Settings or navigating to a real screen.
            Spacer(Modifier.height(16.dp))
            var rerollTick by remember { mutableStateOf(0) }
            Row(
                Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.Center,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Text(
                        "Press \u0026 hold to preview",
                        fontSize = 11.sp,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                    Spacer(Modifier.height(6.dp))
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        key(rerollTick) {
                            val previewFabInteraction = remember { MutableInteractionSource() }
                            SmallFloatingActionButton(
                                onClick = {},
                                interactionSource = previewFabInteraction,
                                modifier = Modifier.fabPressScale(previewFabInteraction)
                            ) {
                                Text("\uD83C\uDFAC", fontSize = 18.sp)
                            }
                        }
                        if (uiAnimOn && uiAnimStyleValue == UiAnimStyle.RANDOM_MIX.name) {
                            Spacer(Modifier.width(10.dp))
                            androidx.compose.material3.TextButton(
                                onClick = { rerollTick++ }
                            ) {
                                Text("\uD83C\uDFB2 Reroll")
                            }
                        }
                    }
                }
            }

            // ── v5.4.114cc — Expressive motion plugin ──
            Spacer(Modifier.height(18.dp))
            androidx.compose.material3.HorizontalDivider()
            Spacer(Modifier.height(18.dp))
            Text(
                "\u2728 Expressive motion",
                fontWeight = FontWeight.Bold, fontSize = 16.sp
            )
            Spacer(Modifier.height(6.dp))
            Text(
                "Adds spring-based animation to dialogs, menus, and screen changes. " +
                    "Off by default \u2014 turning it off restores the app's normal motion " +
                    "exactly. The Expressive colour themes above work independently of this " +
                    "switch.",
                fontSize = 12.sp,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
            Spacer(Modifier.height(12.dp))
            val motionOn by vm.motionEnabled.collectAsStateWithLifecycle()
            Row(
                Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column(Modifier.weight(1f)) {
                    Text(
                        "Enable expressive motion",
                        fontSize = 14.sp, fontWeight = FontWeight.Medium
                    )
                    Text(
                        if (motionOn) "On \u2014 animated transitions active"
                        else "Off \u2014 default app behaviour",
                        fontSize = 11.sp,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
                Spacer(Modifier.width(12.dp))
                androidx.compose.material3.Switch(
                    checked = motionOn,
                    onCheckedChange = { vm.setMotionEnabled(it) }
                )
            }

            // Profile picker — only meaningful when the plugin is on, so
            // it's disabled (greyed) when off.
            if (motionOn) {
                Spacer(Modifier.height(14.dp))
                val motionProfileName by vm.motionProfile.collectAsStateWithLifecycle()
                Text(
                    "Motion style",
                    fontSize = 13.sp, fontWeight = FontWeight.Medium
                )
                Spacer(Modifier.height(6.dp))
                // Three real profiles (OFF is represented by the master
                // switch, not offered here).
                val profiles = listOf(
                    "EXPRESSIVE" to ("\uD83E\uDD38 Expressive" to "Playful spring with a subtle bounce"),
                    "STANDARD" to ("\u2728 Standard" to "Smooth, clean, no bounce"),
                    "REDUCED" to ("\u26A1 Reduced" to "Near-instant, best for accessibility")
                )
                profiles.forEach { (id, labelPair) ->
                    val (label, desc) = labelPair
                    Row(
                        Modifier.fillMaxWidth()
                            .clickable { vm.setMotionProfile(id) }
                            .padding(vertical = 6.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        androidx.compose.material3.RadioButton(
                            selected = motionProfileName == id,
                            onClick = { vm.setMotionProfile(id) }
                        )
                        Spacer(Modifier.width(8.dp))
                        Column {
                            Text(label, fontSize = 14.sp,
                                fontWeight = if (motionProfileName == id)
                                    FontWeight.SemiBold else FontWeight.Normal)
                            Text(desc, fontSize = 11.sp,
                                color = MaterialTheme.colorScheme.onSurfaceVariant)
                        }
                    }
                }
            }

            Spacer(Modifier.height(18.dp))
            // ── Text contrast slider ──
            val contrast by vm.textContrast.collectAsStateWithLifecycle()
            Text(
                "\uD83D\uDD06 Text contrast \u00B7 ${"%.2f".format(contrast)}\u00D7",
                fontSize = 14.sp, fontWeight = FontWeight.Medium
            )
            Text(
                "Boost foreground/background contrast for easier reading, especially in " +
                    "light and sepia themes. 1.0\u00D7 = default, 2.0\u00D7 = maximum.",
                fontSize = 11.sp,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
            androidx.compose.material3.Slider(
                value = contrast,
                onValueChange = { vm.setTextContrast(it) },
                valueRange = 1.0f..2.0f,
                steps = 19   // 0.05 steps
            )

            }

            if (selectedSettingsCategory == SETTINGS_WEBVIEWER) {
            Spacer(Modifier.height(28.dp))
            Text("\uD83C\uDF10 In-app browser", fontWeight = FontWeight.Bold, fontSize = 16.sp)
            Spacer(Modifier.height(6.dp))
            Text(
                "Settings for the WebView that opens jw.org scriptures.",
                fontSize = 12.sp,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
            Spacer(Modifier.height(10.dp))
            androidx.compose.material3.OutlinedButton(
                onClick = { nav.navigate("webHistory") },
                modifier = Modifier.fillMaxWidth()
            ) { Text("\uD83D\uDD52 Open web history") }
            Spacer(Modifier.height(8.dp))
            androidx.compose.material3.OutlinedButton(
                onClick = { nav.navigate("pdfHistory") },
                modifier = Modifier.fillMaxWidth()
            ) { Text("\uD83D\uDCDC Open PDF history") }
            Spacer(Modifier.height(8.dp))
            var confirmClearWeb by remember { mutableStateOf(false) }
            androidx.compose.material3.OutlinedButton(
                onClick = { confirmClearWeb = true },
                modifier = Modifier.fillMaxWidth()
            ) { Text("\uD83E\uDDF9 Clear all web history") }
            if (confirmClearWeb) {
                androidx.compose.material3.AlertDialog(
                    onDismissRequest = { confirmClearWeb = false },
                    title = { Text("Clear web history?") },
                    text = { Text("This removes every web-history entry. Browser data on the device is not touched.") },
                    confirmButton = {
                        androidx.compose.material3.Button(onClick = {
                            vm.clearWebHistory()
                            confirmClearWeb = false
                        }) { Text("Clear") }
                    },
                    dismissButton = {
                        androidx.compose.material3.TextButton(onClick = { confirmClearWeb = false }) { Text("Cancel") }
                    }
                )
            }

            }

            when (selectedSettingsCategory) {
                SETTINGS_SEARCH -> {
                    SettingsSubheading("Semantic Search")
                    SemanticSearchSection(vm, showCore = true, showAi = false, showEmbeddings = false)
                    Spacer(Modifier.height(28.dp))
                    SettingsSubheading("Search Scope")
                    SearchScopeSettingsSection(vm)
                    Spacer(Modifier.height(28.dp))
                    SettingsSubheading("Reranking")
                    RerankerSection(vm)
                    Spacer(Modifier.height(28.dp))
                    SettingsSubheading("Search Results")
                    SearchFiltersSection(vm)
                }
                SETTINGS_AI -> {
                    SettingsSubheading("LLM & Model Management")
                    OnDeviceChatSection(vm)
                }
                SETTINGS_READING -> {
                    SettingsSubheading("Highlighting")
                    ReadingHighlightingSection(vm)
                }
                SETTINGS_WEBVIEWER -> {
                    SettingsSubheading("Tabs")
                    BrowserTabsSection(vm)
                }
                SETTINGS_APPEARANCE -> {
                    SettingsSubheading("Home & Workspace")
                    HomeScreenSection(vm)
                }
                SETTINGS_MEDIA -> {
                    MediaSettingsSection(vm)
                }
                SETTINGS_LIBRARY -> {
                    SettingsSubheading("Duplicates")
                    DuplicateDetectorSection(nav)
                }
                SETTINGS_ADVANCED -> {
                    SettingsSubheading("Memory")
                    MemorySection(vm)
                    Spacer(Modifier.height(28.dp))
                    SettingsSubheading("Diagnostics")
                    DiagnosticsSection(vm, nav)
                    Spacer(Modifier.height(28.dp))
                    SettingsSubheading("Logs")
                    AdvancedLogsSection(nav)
                    Spacer(Modifier.height(28.dp))
                    Text(
                        "MarkVault ${com.tebogo.markvault.BuildConfig.VERSION_NAME}\n" +
                            "• Offline Markdown + PDF knowledge system.\n" +
                            "• In-app jw.org browser with history.\n" +
                            "• Auto-grouped topics, dashboard, concept search.\n" +
                            "• On-device semantic search with switchable models.\n" +
                            "• Your notes never leave this phone. 📚",
                        fontSize = 13.sp,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }
        }
    }
}

/**
 * Settings UI for the semantic-search foundation. Three controls:
 *
 *   • Status line — "Model not downloaded" / "Downloading…X%" / "Model ready"
 *   • Action button — Download model OR Build embeddings (whichever's next)
 *   • Secondary action — Clear embeddings (only shown when there are any)
 *
 * Kept intentionally self-contained at the bottom of SettingsScreen.kt so it
 * can be moved into its own file later without ceremony. The composable does
 * not depend on any other Settings helpers, only on AppViewModel's public
 * state flows ([modelAvailable], [modelDownloadProgress], [embeddingCount],
 * [embeddingProgress]) and four methods.
 */
@androidx.compose.runtime.Composable
private fun SemanticSearchSection(
    vm: com.tebogo.markvault.AppViewModel,
    showCore: Boolean = true,
    showAi: Boolean = true,
    showEmbeddings: Boolean = true
) {
    val modelReady by vm.modelAvailable.collectAsStateWithLifecycle()
    val downloadProgress by vm.modelDownloadProgress.collectAsStateWithLifecycle()
    val embedCount by vm.embeddingCount.collectAsStateWithLifecycle()
    // v5.4.180cc — embedCount is a PASSAGE/chunk count post-chunking
    // (v5.4.174cc), not a note count — same underlying issue as the
    // Memory section's fix in v5.4.175cc, just a SEPARATE display this
    // composable has of its own that wasn't caught at the time. Reuses
    // the same vm.distinctEmbeddedNoteCount() rather than adding a
    // second query for the same thing.
    var embeddedNoteCount by remember { mutableStateOf(0) }
    LaunchedEffect(embedCount) {
        embeddedNoteCount = vm.distinctEmbeddedNoteCount()
    }
    val embedProgress by vm.embeddingProgress.collectAsStateWithLifecycle()
    // v4.9.0 — toggle / active-model / update-check state
    val semanticOn by vm.semanticEnabled.collectAsStateWithLifecycle()
    val autoCheck by vm.autoCheckModelUpdates.collectAsStateWithLifecycle()
    val activeId by vm.activeModelId.collectAsStateWithLifecycle()
    val updateStatus by vm.modelUpdateStatus.collectAsStateWithLifecycle()
    val activeDescriptor = vm.availableModels.firstOrNull { it.id == activeId }
        ?: vm.availableModels.firstOrNull()

    if (showCore) {
    Text(
        "\uD83E\uDDE0 Semantic search (experimental)",
        fontWeight = androidx.compose.ui.text.font.FontWeight.Bold,
        fontSize = 16.sp
    )
    androidx.compose.foundation.layout.Spacer(
        androidx.compose.ui.Modifier.height(6.dp)
    )
    Text(
        "On-device meaning-based ranking. Downloads a ~25MB language model once, " +
            "then embeds every note in your library so similar phrasings match even " +
            "when wording differs. All processing stays on this phone.",
        fontSize = 13.sp,
        color = androidx.compose.material3.MaterialTheme.colorScheme.onSurfaceVariant,
        lineHeight = 18.sp
    )
    androidx.compose.foundation.layout.Spacer(
        androidx.compose.ui.Modifier.height(14.dp)
    )

    // ── v4.9.0 — Master on/off switch ───────────────────────────────────────
    androidx.compose.foundation.layout.Row(
        modifier = androidx.compose.ui.Modifier.fillMaxWidth(),
        verticalAlignment = androidx.compose.ui.Alignment.CenterVertically
    ) {
        androidx.compose.foundation.layout.Column(
            androidx.compose.ui.Modifier.weight(1f)
        ) {
            Text(
                "Use semantic search",
                fontWeight = androidx.compose.ui.text.font.FontWeight.Medium,
                fontSize = 14.sp
            )
            Text(
                "When off, results use only keyword + synonym + fuzzy matching.",
                fontSize = 11.sp,
                color = androidx.compose.material3.MaterialTheme.colorScheme.onSurfaceVariant,
                lineHeight = 15.sp
            )
        }
        androidx.compose.material3.Switch(
            checked = semanticOn,
            onCheckedChange = { vm.setSemanticEnabled(it) }
        )
    }
    androidx.compose.foundation.layout.Spacer(
        androidx.compose.ui.Modifier.height(14.dp)
    )

    }

    if (showAi) {
    // ── v5.4.76cc — AI multi-query retrieval (LLM query expansion) ─────────
    //
    // Off by default. When the user turns this on AND the Phi-4-mini
    // model is installed (Settings → On-device chat), each *submitted*
    // search runs the query through the LLM to produce a small set of
    // paraphrased sub-queries, folds their hits into the merged result
    // set, and paints an "✨ AI" chip plus lavender highlight on the
    // rows and words the LLM surfaced. Live-typing keystrokes still
    // bypass the model — only submits pay the ~10-15 s cold-load cost,
    // and repeat queries hit the in-memory expansion cache instantly.
    val aiLlmOn by vm.aiLlmSearchEnabled.collectAsStateWithLifecycle()
    androidx.compose.foundation.layout.Row(
        modifier = androidx.compose.ui.Modifier.fillMaxWidth(),
        verticalAlignment = androidx.compose.ui.Alignment.CenterVertically
    ) {
        androidx.compose.foundation.layout.Column(
            androidx.compose.ui.Modifier.weight(1f)
        ) {
            Text(
                "\u2728 AI multi-query retrieval (LLM)",
                fontWeight = androidx.compose.ui.text.font.FontWeight.Medium,
                fontSize = 14.sp
            )
            Text(
                "Uses the on-device Phi-4-mini to expand your query into " +
                    "paraphrases for broader semantic recall. Adds a light " +
                    "lavender highlight on results and inside articles for " +
                    "words the LLM surfaced. Runs only on submit; live typing " +
                    "stays fast. Requires the model to be installed.",
                fontSize = 11.sp,
                color = androidx.compose.material3.MaterialTheme.colorScheme.onSurfaceVariant,
                lineHeight = 15.sp
            )
        }
        androidx.compose.material3.Switch(
            checked = aiLlmOn,
            onCheckedChange = { vm.setAiLlmSearchEnabled(it) }
        )
    }
    androidx.compose.foundation.layout.Spacer(
        androidx.compose.ui.Modifier.height(10.dp)
    )

    // ── v5.4.139cc — LLM-fallback-to-synonym opt-in ──
    // Default OFF: when the AI multi-query toggle is ON, ONLY the LLM
    // runs. If the LLM produces nothing (timeout, engine error, all
    // candidates rejected), the query plan shows zero AI paraphrases —
    // the failure is visible, not silently masked. Users who want
    // expansion regardless of source can turn this on to route around
    // a failing LLM via the offline synonym expander.
    val llmFallbackOn by vm.llmFallbackToSynonym.collectAsStateWithLifecycle()
    androidx.compose.foundation.layout.Row(
        modifier = androidx.compose.ui.Modifier
            .fillMaxWidth()
            .padding(vertical = 4.dp),
        verticalAlignment = androidx.compose.ui.Alignment.CenterVertically
    ) {
        androidx.compose.foundation.layout.Column(
            modifier = androidx.compose.ui.Modifier.weight(1f)
        ) {
            Text(
                "\uD83E\uDDE9  Fall back to synonym expander on LLM failure",
                fontWeight = androidx.compose.ui.text.font.FontWeight.Medium,
                fontSize = 13.sp
            )
            Text(
                "OFF (default): the LLM either works or the plan shows " +
                    "zero AI paraphrases \u2014 no silent masking. ON: if " +
                    "the LLM times out or produces nothing, the offline " +
                    "synonym expander fills in so search never returns " +
                    "zero expansion. Only active when the AI multi-query " +
                    "toggle above is ON.",
                fontSize = 11.sp,
                color = androidx.compose.material3.MaterialTheme.colorScheme.onSurfaceVariant,
                lineHeight = 15.sp
            )
        }
        androidx.compose.material3.Switch(
            checked = llmFallbackOn,
            onCheckedChange = { vm.setLlmFallbackToSynonym(it) }
        )
    }
    androidx.compose.foundation.layout.Spacer(
        androidx.compose.ui.Modifier.height(10.dp)
    )

    // ── v5.4.79cc — Model picker for LLM query expansion ─────────────────
    //
    // Two-way radio between the safe default (SmolLM2 135M, ~350 MB
    // peak RAM) and the heavier alternative (Phi-4-mini, ~4.5 GB peak
    // RAM). Writes the choice into `chatActiveModelId` — the same
    // preference the download UI and `LlmQueryExpander` read, so
    // switching here immediately routes the next submit through the
    // chosen model. Model still needs to be *installed* separately in
    // the "On-device model" section below.
    val activeIdForPicker by vm.chatActiveModelId.collectAsStateWithLifecycle()
    Text(
        "LLM used for query expansion",
        fontWeight = androidx.compose.ui.text.font.FontWeight.Medium,
        fontSize = 13.sp
    )
    androidx.compose.foundation.layout.Spacer(
        androidx.compose.ui.Modifier.height(6.dp)
    )
    for (model in com.tebogo.markvault.llm.ChatModelCatalog.all) {
        androidx.compose.foundation.layout.Row(
            modifier = androidx.compose.ui.Modifier
                .fillMaxWidth()
                .clickable { vm.setChatActiveModelId(model.id) }
                .padding(vertical = 6.dp),
            verticalAlignment = androidx.compose.ui.Alignment.CenterVertically
        ) {
            androidx.compose.material3.RadioButton(
                selected = activeIdForPicker == model.id,
                onClick = { vm.setChatActiveModelId(model.id) }
            )
            androidx.compose.foundation.layout.Spacer(
                androidx.compose.ui.Modifier.width(6.dp)
            )
            androidx.compose.foundation.layout.Column(
                androidx.compose.ui.Modifier.weight(1f)
            ) {
                Text(
                    model.displayName,
                    fontSize = 13.sp,
                    fontWeight = androidx.compose.ui.text.font.FontWeight.Medium
                )
                Text(
                    "~${model.approxSizeMb} MB on disk   \u2022   ~${model.approxRamMb} MB peak RAM",
                    fontSize = 11.sp,
                    color = androidx.compose.material3.MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
        }
    }
    androidx.compose.foundation.layout.Spacer(
        androidx.compose.ui.Modifier.height(10.dp)
    )

    // ── v5.4.79cc — Memory-safety belt toggle ────────────────────────────
    val memoryOptOn by vm.memoryOptimizedLlm.collectAsStateWithLifecycle()
    androidx.compose.foundation.layout.Row(
        modifier = androidx.compose.ui.Modifier.fillMaxWidth(),
        verticalAlignment = androidx.compose.ui.Alignment.CenterVertically
    ) {
        androidx.compose.foundation.layout.Column(
            androidx.compose.ui.Modifier.weight(1f)
        ) {
            Text(
                "\uD83D\uDEE1\uFE0F Memory optimization",
                fontWeight = androidx.compose.ui.text.font.FontWeight.Medium,
                fontSize = 14.sp
            )
            Text(
                "When on, the expander checks free RAM before loading a " +
                    "model and skips the expansion for a query if the " +
                    "device would run out of headroom. Also uses a " +
                    "tighter 5-second timeout on inference. Prevents the " +
                    "OOM crash that could happen with the heavier " +
                    "Phi-4-mini on 6 GB devices. Recommended on.",
                fontSize = 11.sp,
                color = androidx.compose.material3.MaterialTheme.colorScheme.onSurfaceVariant,
                lineHeight = 15.sp
            )
        }
        androidx.compose.material3.Switch(
            checked = memoryOptOn,
            onCheckedChange = { vm.setMemoryOptimizedLlm(it) }
        )
    }
    androidx.compose.foundation.layout.Spacer(
        androidx.compose.ui.Modifier.height(14.dp)
    )

    }

    if (showEmbeddings) {
    // ── v4.9.1 — Models picker ──────────────────────────────────────────────
    // Lists every catalog entry. The currently-active one is highlighted; any
    // other enabled entry is tappable to switch. Disabled entries (e.g.
    // upcoming MiniLM) are rendered greyed out with a "coming soon" tag.
    Text(
        "Models",
        fontWeight = androidx.compose.ui.text.font.FontWeight.Medium,
        fontSize = 14.sp
    )
    androidx.compose.foundation.layout.Spacer(
        androidx.compose.ui.Modifier.height(6.dp)
    )
    for (model in vm.availableModels) {
        val isActive = model.id == activeId
        val isClickable = model.enabled && !isActive
        val rowModifier = if (isClickable) {
            androidx.compose.ui.Modifier
                .fillMaxWidth()
                .clickable(onClick = { vm.setActiveModelId(model.id) })
                .padding(vertical = 6.dp)
        } else {
            androidx.compose.ui.Modifier
                .fillMaxWidth()
                .padding(vertical = 6.dp)
        }
        androidx.compose.foundation.layout.Row(
            modifier = rowModifier,
            verticalAlignment = androidx.compose.ui.Alignment.CenterVertically
        ) {
            // Radio-like marker
            Text(
                when {
                    isActive -> "\uD83D\uDFE2"           // green dot for active
                    !model.enabled -> "\u23F3"           // hourglass for coming-soon
                    else -> "\u26AA"                       // white circle for selectable
                },
                fontSize = 14.sp
            )
            androidx.compose.foundation.layout.Spacer(
                androidx.compose.ui.Modifier.width(10.dp)
            )
            androidx.compose.foundation.layout.Column(
                androidx.compose.ui.Modifier.weight(1f)
            ) {
                val titleColor = when {
                    isActive -> androidx.compose.material3.MaterialTheme.colorScheme.primary
                    !model.enabled -> androidx.compose.material3.MaterialTheme.colorScheme.onSurfaceVariant
                    else -> androidx.compose.material3.MaterialTheme.colorScheme.onSurface
                }
                Text(
                    if (model.enabled) model.displayName
                    else "${model.displayName}  \u2022  coming soon",
                    fontSize = 13.sp,
                    fontWeight = if (isActive) androidx.compose.ui.text.font.FontWeight.SemiBold
                    else androidx.compose.ui.text.font.FontWeight.Normal,
                    color = titleColor
                )
                Text(
                    model.description,
                    fontSize = 11.sp,
                    color = androidx.compose.material3.MaterialTheme.colorScheme.onSurfaceVariant,
                    lineHeight = 15.sp
                )
            }
        }
    }
    androidx.compose.foundation.layout.Spacer(
        androidx.compose.ui.Modifier.height(10.dp)
    )

    // ── v4.9.0 — Check for newer model ──────────────────────────────────────
    androidx.compose.material3.OutlinedButton(
        onClick = { vm.checkForModelUpdates() },
        modifier = androidx.compose.ui.Modifier.fillMaxWidth()
    ) {
        Text("Check for newer model")
    }
    if (!updateStatus.isNullOrBlank()) {
        androidx.compose.foundation.layout.Spacer(
            androidx.compose.ui.Modifier.height(4.dp)
        )
        Text(
            updateStatus ?: "",
            fontSize = 12.sp,
            color = androidx.compose.material3.MaterialTheme.colorScheme.primary
        )
    }
    androidx.compose.foundation.layout.Spacer(
        androidx.compose.ui.Modifier.height(8.dp)
    )

    // Auto-check on launch
    androidx.compose.foundation.layout.Row(
        modifier = androidx.compose.ui.Modifier.fillMaxWidth(),
        verticalAlignment = androidx.compose.ui.Alignment.CenterVertically
    ) {
        androidx.compose.foundation.layout.Column(
            androidx.compose.ui.Modifier.weight(1f)
        ) {
            Text(
                "Check automatically on launch",
                fontWeight = androidx.compose.ui.text.font.FontWeight.Medium,
                fontSize = 14.sp
            )
            Text(
                "Quietly looks for newer models when the app starts.",
                fontSize = 11.sp,
                color = androidx.compose.material3.MaterialTheme.colorScheme.onSurfaceVariant,
                lineHeight = 15.sp
            )
        }
        androidx.compose.material3.Switch(
            checked = autoCheck,
            onCheckedChange = { vm.setAutoCheckModelUpdates(it) }
        )
    }
    androidx.compose.foundation.layout.Spacer(
        androidx.compose.ui.Modifier.height(14.dp)
    )

    // ── Status line ─────────────────────────────────────────────────────
    val statusLine = when {
        downloadProgress != null -> {
            val pct = ((downloadProgress ?: 0f) * 100).toInt()
            "\u23F3 Downloading model\u2026 $pct%"
        }
        embedProgress != null -> {
            val (done, total) = embedProgress!!
            // v4.8.1 — (0, 0) is the "preparing" sentinel emitted before the
            // COUNT query has finished. Avoid the "0 / 0 (0%)" weirdness.
            if (total == 0) "\u23F3 Preparing\u2026 (counting notes)"
            else {
                val pct = (done * 100 / total)
                "\u23F3 Embedding library\u2026 $done / $total ($pct%)"
            }
        }
        !modelReady -> "\u26AB Model not downloaded"
        embedCount == 0 -> "\u2705 Model ready \u2014 no embeddings built yet"
        else -> "\u2705 Model ready \u2014 $embeddedNoteCount note${if (embeddedNoteCount == 1) "" else "s"} embedded"
    }
    Text(
        statusLine,
        fontSize = 13.sp,
        fontWeight = androidx.compose.ui.text.font.FontWeight.Medium,
        color = androidx.compose.material3.MaterialTheme.colorScheme.primary
    )

    androidx.compose.foundation.layout.Spacer(
        androidx.compose.ui.Modifier.height(10.dp)
    )

    // ── Primary action button ───────────────────────────────────────────
    when {
        downloadProgress != null || embedProgress != null -> {
            // Show a linear progress bar while either pass is running.
            // v4.8.1 — when embedding progress is the (0, 0) "preparing"
            // sentinel, use an indeterminate (animated) bar so the user sees
            // motion even before the COUNT query has finished.
            val isPreparing = embedProgress?.let { it.second == 0 } == true
            if (isPreparing) {
                androidx.compose.material3.LinearProgressIndicator(
                    modifier = androidx.compose.ui.Modifier.fillMaxWidth()
                )
            } else {
                val frac = downloadProgress
                    ?: (embedProgress?.let {
                        val (d, t) = it; if (t > 0) d.toFloat() / t else 0f
                    } ?: 0f)
                androidx.compose.material3.LinearProgressIndicator(
                    progress = { frac },
                    modifier = androidx.compose.ui.Modifier.fillMaxWidth()
                )
            }
        }
        !modelReady -> {
            // v4.9.1 — single-step install: tap once, the model downloads
            // AND embeddings start automatically when the download finishes.
            // Replaces the two-button "Download" → "Build" workflow.
            androidx.compose.material3.Button(
                onClick = { vm.installModel() },
                modifier = androidx.compose.ui.Modifier.fillMaxWidth()
            ) {
                val mb = activeDescriptor?.approxSizeMb ?: 25
                Text("Install model (~${mb} MB)")
            }
        }
        embedCount == 0 -> {
            // Model is downloaded but no embeddings yet — surface the embed
            // pass directly. Equivalent to the second phase of installModel().
            androidx.compose.material3.Button(
                onClick = { vm.buildAllEmbeddings() },
                modifier = androidx.compose.ui.Modifier.fillMaxWidth()
            ) {
                Text("Build embeddings")
            }
        }
        else -> {
            androidx.compose.material3.Button(
                onClick = { vm.buildAllEmbeddings() },
                modifier = androidx.compose.ui.Modifier.fillMaxWidth()
            ) {
                Text("Re-embed updated notes")
            }
        }
    }

    // ── Secondary action: clear embeddings ──────────────────────────────
    if (embedCount > 0 && embedProgress == null) {
        androidx.compose.foundation.layout.Spacer(
            androidx.compose.ui.Modifier.height(6.dp)
        )
        androidx.compose.material3.OutlinedButton(
            onClick = { vm.clearAllEmbeddings() },
            modifier = androidx.compose.ui.Modifier.fillMaxWidth()
        ) {
            Text("Clear embeddings")
        }
    }

    // ── Footnote ────────────────────────────────────────────────────────
    androidx.compose.foundation.layout.Spacer(
        androidx.compose.ui.Modifier.height(8.dp)
    )
    Text(
        "\u2705 Search integration is active. When you type in the search bar, " +
            "results are ranked using both keyword matches AND meaning-based " +
            "similarity from these embeddings. Try searching with different " +
            "wording than what's in your articles to see it in action.",
        fontSize = 11.sp,
        color = androidx.compose.material3.MaterialTheme.colorScheme.onSurfaceVariant,
        lineHeight = 15.sp
    )
    }
}

/**
 * v4.21.0 — Settings UI for the on-device chat LLM (RAG over your library).
 *
 * Shows:
 *   • A description of what chat does
 *   • Status line — "Not installed" / "Downloading X% (Y / Z MB)" / "Installed"
 *   • Install / Delete / Cancel button depending on state
 *   • Three future-behaviour toggles (install flow, location, history mode)
 *
 * v4.21.0 is Settings-only — the toggles persist but don't yet change
 * behaviour. v4.22.x adds the chat screen UI that consumes them.
 */
/**
 * v5.4.72 — Settings UI for the on-device chat LLM (RAG over your library).
 *
 * ## Download state machine
 *
 *   IDLE       → Install button
 *   DOWNLOAD   → progress bar + ⏸ Pause   +  ✕ Cancel buttons
 *   PAUSED     → progress bar (frozen) + ▶ Resume + ✕ Cancel buttons
 *   ERROR      → error text + ↩ Retry (auto-resumes .part) + Start fresh link
 *   INSTALLED  → Delete button
 */
@androidx.compose.runtime.Composable
private fun OnDeviceChatSection(vm: com.tebogo.markvault.AppViewModel) {
    val installed   by vm.chatModelInstalled.collectAsStateWithLifecycle()
    val progress    by vm.chatDownloadProgress.collectAsStateWithLifecycle()
    val running     by vm.chatDownloadRunning.collectAsStateWithLifecycle()
    val paused      by vm.chatDownloadPaused.collectAsStateWithLifecycle()
    val lastError   by vm.chatDownloadError.collectAsStateWithLifecycle()
    val installFlow by vm.chatInstallFlowPref.collectAsStateWithLifecycle()
    val location    by vm.chatLocationPref.collectAsStateWithLifecycle()
    val historyMode by vm.chatHistoryModePref.collectAsStateWithLifecycle()
    val loadMode    by vm.chatModelLoadModePref.collectAsStateWithLifecycle()
    val activeChatId by vm.chatActiveModelId.collectAsStateWithLifecycle()
    val descriptor = vm.availableChatModels.firstOrNull { it.id == activeChatId }
        ?: vm.availableChatModels.firstOrNull()

    Text(
        "\uD83D\uDCAC On-device chat (preview)",
        fontWeight = androidx.compose.ui.text.font.FontWeight.Bold,
        fontSize = 16.sp
    )
    androidx.compose.foundation.layout.Spacer(
        androidx.compose.ui.Modifier.height(6.dp)
    )
    Text(
        "Ask questions about your library and get a synthesised answer " +
            "with citations to the notes used. Runs entirely on this phone — " +
            "your notes never leave the device. Quality depends on the small " +
            "model used; best for lookup and drafting, not deep reasoning.",
        fontSize = 13.sp,
        color = androidx.compose.material3.MaterialTheme.colorScheme.onSurfaceVariant,
        lineHeight = 18.sp
    )
    androidx.compose.foundation.layout.Spacer(
        androidx.compose.ui.Modifier.height(14.dp)
    )

    // ── Model card ──────────────────────────────────────────────────────
    if (descriptor != null) {
        Text(
            descriptor.displayName,
            fontWeight = androidx.compose.ui.text.font.FontWeight.SemiBold,
            fontSize = 14.sp
        )
        androidx.compose.foundation.layout.Spacer(
            androidx.compose.ui.Modifier.height(4.dp)
        )
        Text(
            descriptor.description,
            fontSize = 12.sp,
            color = androidx.compose.material3.MaterialTheme.colorScheme.onSurfaceVariant,
            lineHeight = 16.sp
        )
        androidx.compose.foundation.layout.Spacer(
            androidx.compose.ui.Modifier.height(6.dp)
        )
        Text(
            "Download: ~${descriptor.approxSizeMb} MB   •   " +
                "RAM when active: ~${descriptor.approxRamMb} MB",
            fontSize = 11.sp,
            color = androidx.compose.material3.MaterialTheme.colorScheme.onSurfaceVariant
        )
    }

    androidx.compose.foundation.layout.Spacer(
        androidx.compose.ui.Modifier.height(12.dp)
    )

    // ── Status line ─────────────────────────────────────────────────────
    val statusText: String = when {
        running && progress != null -> {
            val (doneMb, totalMb) = progress!!
            val pct = if (totalMb > 0) (doneMb * 100 / totalMb).coerceIn(0, 100) else 0
            "Downloading: $doneMb / $totalMb MB  ($pct%)"
        }
        running  -> "Connecting\u2026"
        paused && progress != null -> {
            val (doneMb, totalMb) = progress!!
            val pct = if (totalMb > 0) (doneMb * 100 / totalMb).coerceIn(0, 100) else 0
            "\u23F8\uFE0F Paused at $doneMb / $totalMb MB ($pct%) \u2014 tap Resume to continue"
        }
        paused   -> "\u23F8\uFE0F Paused \u2014 tap Resume to continue"
        installed -> "\u2705 Installed and ready"
        lastError != null -> "\u26A0\uFE0F  ${lastError}"
        else -> "Not installed"
    }
    Text(
        statusText,
        fontSize = 13.sp,
        color = androidx.compose.material3.MaterialTheme.colorScheme.onSurface
    )

    // Progress bar: visible while downloading OR while paused (frozen).
    val showProgress = (running || paused) && progress != null
    if (showProgress) {
        val (doneMb, totalMb) = progress!!
        androidx.compose.foundation.layout.Spacer(
            androidx.compose.ui.Modifier.height(6.dp)
        )
        androidx.compose.material3.LinearProgressIndicator(
            progress = {
                if (totalMb > 0) (doneMb.toFloat() / totalMb.toFloat()) else 0f
            },
            modifier = androidx.compose.ui.Modifier.fillMaxWidth()
        )
    }
    androidx.compose.foundation.layout.Spacer(
        androidx.compose.ui.Modifier.height(12.dp)
    )

    // ── Primary actions ─────────────────────────────────────────────────
    when {
        running -> {
            // Active download: Pause + Cancel side by side.
            androidx.compose.foundation.layout.Row(
                modifier = androidx.compose.ui.Modifier.fillMaxWidth(),
                horizontalArrangement = androidx.compose.foundation.layout.Arrangement.spacedBy(8.dp)
            ) {
                androidx.compose.material3.Button(
                    onClick  = { vm.pauseChatModelDownload() },
                    modifier = androidx.compose.ui.Modifier.weight(1f)
                ) {
                    Text("\u23F8 Pause")
                }
                OutlinedButton(
                    onClick  = { vm.cancelChatModelDownload() },
                    modifier = androidx.compose.ui.Modifier.weight(1f)
                ) {
                    Text("\u2715 Cancel")
                }
            }
        }

        paused -> {
            // Paused: Resume + Cancel side by side.
            androidx.compose.foundation.layout.Row(
                modifier = androidx.compose.ui.Modifier.fillMaxWidth(),
                horizontalArrangement = androidx.compose.foundation.layout.Arrangement.spacedBy(8.dp)
            ) {
                androidx.compose.material3.Button(
                    onClick = {
                        vm.downloadChatModel()   // auto-resumes via .part file
                    },
                    modifier = androidx.compose.ui.Modifier.weight(1f)
                ) {
                    Text("\u25B6 Resume")
                }
                OutlinedButton(
                    onClick  = { vm.cancelChatModelDownload() },
                    modifier = androidx.compose.ui.Modifier.weight(1f)
                ) {
                    Text("\u2715 Cancel")
                }
            }
        }

        installed -> {
            OutlinedButton(
                onClick  = { vm.deleteChatModel() },
                modifier = androidx.compose.ui.Modifier.fillMaxWidth()
            ) {
                Text("Delete model (frees ~${descriptor?.approxSizeMb ?: 0} MB)")
            }
        }

        lastError != null -> {
            // Error state: Retry (auto-resumes .part) + Start fresh.
            androidx.compose.material3.Button(
                onClick = {
                    vm.clearChatDownloadError()
                    vm.downloadChatModel()   // downloader auto-resumes .part if present
                },
                modifier = androidx.compose.ui.Modifier.fillMaxWidth()
            ) {
                Text("\u21A9 Retry download")
            }
            androidx.compose.foundation.layout.Spacer(
                androidx.compose.ui.Modifier.height(6.dp)
            )
            androidx.compose.material3.TextButton(
                onClick = {
                    vm.clearChatDownloadError()
                    vm.cancelChatModelDownload()   // deletes .part → next retry is fresh
                },
                modifier = androidx.compose.ui.Modifier.fillMaxWidth()
            ) {
                Text("Start fresh (discard partial download)")
            }
        }

        else -> {
            // Idle / not installed.
            androidx.compose.material3.Button(
                onClick = {
                    vm.clearChatDownloadError()
                    vm.downloadChatModel()
                },
                modifier = androidx.compose.ui.Modifier.fillMaxWidth()
            ) {
                Text("Install model (~${descriptor?.approxSizeMb ?: 0} MB)")
            }
        }
    }

    androidx.compose.foundation.layout.Spacer(
        androidx.compose.ui.Modifier.height(20.dp)
    )

    // ── Behaviour toggles (stored only in v4.21.0) ─────────────────────
    Text(
        "Behaviour (revisit anytime)",
        fontWeight = androidx.compose.ui.text.font.FontWeight.SemiBold,
        fontSize = 13.sp
    )
    androidx.compose.foundation.layout.Spacer(
        androidx.compose.ui.Modifier.height(4.dp)
    )
    Text(
        "These choose how chat will work once the chat screen lands in a " +
            "later update. They're saved now so you can change your mind " +
            "without losing the model download.",
        fontSize = 11.sp,
        color = androidx.compose.material3.MaterialTheme.colorScheme.onSurfaceVariant,
        lineHeight = 15.sp
    )
    androidx.compose.foundation.layout.Spacer(
        androidx.compose.ui.Modifier.height(10.dp)
    )

    ChatPickerRow(
        label   = "Model install",
        current = installFlow,
        options = listOf(
            "opt_in"       to "Opt-in (tap Install)",
            "auto_prompt"  to "Prompt on first chat"
        ),
        onSelect = { vm.setChatInstallFlowPref(it) }
    )
    androidx.compose.foundation.layout.Spacer(
        androidx.compose.ui.Modifier.height(8.dp)
    )
    ChatPickerRow(
        label   = "Where chat lives",
        current = location,
        options = listOf(
            "own_screen" to "Own screen (menu)",
            "in_search" to "Inside Search"
        ),
        onSelect = { vm.setChatLocationPref(it) }
    )
    androidx.compose.foundation.layout.Spacer(
        androidx.compose.ui.Modifier.height(8.dp)
    )
    ChatPickerRow(
        label = "Conversation memory",
        current = historyMode,
        options = listOf(
            "fresh_per_q" to "Fresh each question",
            "multi_turn" to "Multi-turn within session"
        ),
        onSelect = { vm.setChatHistoryModePref(it) }
    )
    androidx.compose.foundation.layout.Spacer(
        androidx.compose.ui.Modifier.height(8.dp)
    )
    ChatPickerRow(
        label = "When to load the model",
        current = loadMode,
        options = listOf(
            "on_open" to "When chat opens (default)",
            "preload" to "Always loaded (more RAM, instant)",
            "on_first_q" to "On first question (input ready early)"
        ),
        onSelect = { vm.setChatModelLoadModePref(it) }
    )
}

/**
 * Small reusable row that opens a dialog with the available options as
 * radio buttons. Used for the three chat behaviour toggles.
 */
@androidx.compose.runtime.Composable
private fun ChatPickerRow(
    label: String,
    current: String,
    options: List<Pair<String, String>>,  // id → display
    onSelect: (String) -> Unit
) {
    var dialogOpen by androidx.compose.runtime.remember { androidx.compose.runtime.mutableStateOf(false) }
    val currentDisplay = options.firstOrNull { it.first == current }?.second
        ?: options.firstOrNull()?.second ?: current
    OutlinedButton(
        onClick = { dialogOpen = true },
        modifier = androidx.compose.ui.Modifier.fillMaxWidth()
    ) {
        androidx.compose.foundation.layout.Column(
            androidx.compose.ui.Modifier.fillMaxWidth()
        ) {
            Text(label, fontSize = 12.sp,
                color = androidx.compose.material3.MaterialTheme.colorScheme.onSurfaceVariant)
            Text(currentDisplay, fontSize = 14.sp,
                fontWeight = androidx.compose.ui.text.font.FontWeight.SemiBold)
        }
    }
    if (dialogOpen) {
        androidx.compose.material3.AlertDialog(
            onDismissRequest = { dialogOpen = false },
            title = { Text(label) },
            text = {
                androidx.compose.foundation.layout.Column {
                    options.forEach { (id, display) ->
                        androidx.compose.foundation.layout.Row(
                            modifier = androidx.compose.ui.Modifier
                                .fillMaxWidth()
                                .padding(vertical = 8.dp),
                            verticalAlignment = androidx.compose.ui.Alignment.CenterVertically
                        ) {
                            androidx.compose.material3.RadioButton(
                                selected = (id == current),
                                onClick = {
                                    onSelect(id)
                                    dialogOpen = false
                                }
                            )
                            androidx.compose.foundation.layout.Spacer(
                                androidx.compose.ui.Modifier.width(8.dp)
                            )
                            Text(display, fontSize = 14.sp)
                        }
                    }
                }
            },
            confirmButton = {
                androidx.compose.material3.TextButton(onClick = { dialogOpen = false }) {
                    Text("Close")
                }
            }
        )
    }
}

/**
 * v4.23.0 — Settings card for the reranker (cross-encoder).
 *
 * Shows:
 *   • Description of what reranking does
 *   • Install / Delete / Cancel button depending on state
 *   • Progress bar during download
 *   • Toggle to enable/disable reranking once installed
 */
@androidx.compose.runtime.Composable
private fun RerankerSection(vm: com.tebogo.markvault.AppViewModel) {
    val installed by vm.rerankerInstalled.collectAsStateWithLifecycle()
    val progress by vm.rerankerDownloadProgress.collectAsStateWithLifecycle()
    val downloading by vm.rerankerDownloading.collectAsStateWithLifecycle()
    val lastError by vm.rerankerDownloadError.collectAsStateWithLifecycle()
    val rerankEnabled by vm.rerankEnabled.collectAsStateWithLifecycle()
    val descriptor by vm.rerankerDescriptor.collectAsStateWithLifecycle()
    val selectedModelId by vm.rerankerModelId.collectAsStateWithLifecycle()

    Text(
        "\uD83C\uDFAF Smart reranking (recommended)",
        fontWeight = androidx.compose.ui.text.font.FontWeight.Bold,
        fontSize = 16.sp
    )
    androidx.compose.foundation.layout.Spacer(
        androidx.compose.ui.Modifier.height(6.dp)
    )
    Text(
        "Adds a second-stage ranking pass after semantic search. Instead " +
            "of just matching meaning, the cross-encoder reads each candidate " +
            "article alongside your question and judges whether it actually " +
            "ANSWERS the question. The model runs entirely on this phone.",
        fontSize = 13.sp,
        color = androidx.compose.material3.MaterialTheme.colorScheme.onSurfaceVariant,
        lineHeight = 18.sp
    )
    androidx.compose.foundation.layout.Spacer(
        androidx.compose.ui.Modifier.height(14.dp)
    )

    // v5.4.6 — Model picker. Two options today: L-12 (quality) and
    // L-6 (memory-friendly). User can switch at runtime; selection
    // persists across launches. Each option must be downloaded
    // separately the first time.
    Text(
        "Model",
        fontSize = 12.sp,
        fontWeight = androidx.compose.ui.text.font.FontWeight.SemiBold,
        color = androidx.compose.material3.MaterialTheme.colorScheme.onSurfaceVariant
    )
    androidx.compose.foundation.layout.Spacer(
        androidx.compose.ui.Modifier.height(4.dp)
    )
    androidx.compose.foundation.layout.Column(
        verticalArrangement = androidx.compose.foundation.layout.Arrangement.spacedBy(4.dp)
    ) {
        for (desc in com.tebogo.markvault.search.RerankerCatalog.all) {
            val isSelected = desc.id == selectedModelId
            val isInstalled = desc.isInstalled(
                androidx.compose.ui.platform.LocalContext.current.filesDir
            )
            androidx.compose.foundation.layout.Row(
                modifier = androidx.compose.ui.Modifier
                    .fillMaxWidth()
                    .clickable { vm.setRerankerModelId(desc.id) }
                    .padding(vertical = 4.dp),
                verticalAlignment = androidx.compose.ui.Alignment.CenterVertically
            ) {
                androidx.compose.material3.RadioButton(
                    selected = isSelected,
                    onClick = { vm.setRerankerModelId(desc.id) }
                )
                androidx.compose.foundation.layout.Column(
                    modifier = androidx.compose.ui.Modifier.weight(1f)
                ) {
                    androidx.compose.foundation.layout.Row(
                        verticalAlignment = androidx.compose.ui.Alignment.CenterVertically
                    ) {
                        Text(
                            desc.shortName,
                            fontSize = 13.sp,
                            fontWeight = androidx.compose.ui.text.font.FontWeight.Medium
                        )
                        if (isInstalled) {
                            androidx.compose.foundation.layout.Spacer(
                                androidx.compose.ui.Modifier.width(6.dp)
                            )
                            Text(
                                "✓ installed",
                                fontSize = 10.sp,
                                color = androidx.compose.material3.MaterialTheme.colorScheme.primary
                            )
                        }
                    }
                    Text(
                        "~${desc.approxSizeMb} MB download • ~${desc.approxRamMb} MB RAM",
                        fontSize = 11.sp,
                        color = androidx.compose.material3.MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }
        }
    }
    androidx.compose.foundation.layout.Spacer(
        androidx.compose.ui.Modifier.height(12.dp)
    )

    Text(
        descriptor.displayName,
        fontWeight = androidx.compose.ui.text.font.FontWeight.SemiBold,
        fontSize = 14.sp
    )
    androidx.compose.foundation.layout.Spacer(
        androidx.compose.ui.Modifier.height(4.dp)
    )
    Text(
        descriptor.description,
        fontSize = 12.sp,
        color = androidx.compose.material3.MaterialTheme.colorScheme.onSurfaceVariant,
        lineHeight = 16.sp
    )
    androidx.compose.foundation.layout.Spacer(
        androidx.compose.ui.Modifier.height(6.dp)
    )
    Text(
        "Download: ~${descriptor.approxSizeMb} MB   •   " +
            "RAM when active: ~${descriptor.approxRamMb} MB",
        fontSize = 11.sp,
        color = androidx.compose.material3.MaterialTheme.colorScheme.onSurfaceVariant
    )
    androidx.compose.foundation.layout.Spacer(
        androidx.compose.ui.Modifier.height(12.dp)
    )

    // Status line
    val statusText: String = when {
        downloading && progress != null -> {
            val mb = (progress!! * descriptor.approxSizeMb).toInt()
            val pct = (progress!! * 100).toInt().coerceIn(0, 100)
            "Downloading: $mb / ${descriptor.approxSizeMb} MB  ($pct%)"
        }
        downloading -> "Connecting…"
        installed -> "\u2705 Installed and ready"
        lastError != null -> "\u26A0\uFE0F  ${lastError}"
        else -> "Not installed"
    }
    Text(
        statusText,
        fontSize = 13.sp,
        color = androidx.compose.material3.MaterialTheme.colorScheme.onSurface
    )
    if (downloading && progress != null) {
        androidx.compose.foundation.layout.Spacer(
            androidx.compose.ui.Modifier.height(6.dp)
        )
        androidx.compose.material3.LinearProgressIndicator(
            progress = { progress!! },
            modifier = androidx.compose.ui.Modifier.fillMaxWidth()
        )
    }
    androidx.compose.foundation.layout.Spacer(
        androidx.compose.ui.Modifier.height(12.dp)
    )

    // Primary action
    if (downloading) {
        OutlinedButton(
            onClick = { vm.stopRerankerDownload() },
            modifier = androidx.compose.ui.Modifier.fillMaxWidth()
        ) { Text("Cancel download") }
    } else if (installed) {
        OutlinedButton(
            onClick = { vm.deleteReranker() },
            modifier = androidx.compose.ui.Modifier.fillMaxWidth()
        ) {
            Text("Delete reranker (frees ~${descriptor.approxSizeMb} MB)")
        }
    } else {
        androidx.compose.material3.Button(
            onClick = {
                vm.clearRerankerError()
                vm.downloadReranker()
            },
            modifier = androidx.compose.ui.Modifier.fillMaxWidth()
        ) {
            Text("Install reranker (~${descriptor.approxSizeMb} MB)")
        }
    }

    if (lastError != null && !downloading) {
        androidx.compose.foundation.layout.Spacer(
            androidx.compose.ui.Modifier.height(6.dp)
        )
        androidx.compose.material3.TextButton(
            onClick = { vm.clearRerankerError() }
        ) { Text("Dismiss error") }
    }

    // Once installed: the on/off toggle
    if (installed) {
        androidx.compose.foundation.layout.Spacer(
            androidx.compose.ui.Modifier.height(14.dp)
        )
        androidx.compose.foundation.layout.Row(
            modifier = androidx.compose.ui.Modifier.fillMaxWidth(),
            verticalAlignment = androidx.compose.ui.Alignment.CenterVertically
        ) {
            androidx.compose.foundation.layout.Column(
                androidx.compose.ui.Modifier.weight(1f)
            ) {
                Text(
                    "Use reranking for searches",
                    fontWeight = androidx.compose.ui.text.font.FontWeight.SemiBold,
                    fontSize = 14.sp
                )
                Text(
                    if (rerankEnabled) "ON — adds 3–5 s per search for better results"
                    else "OFF — fast cosine ranking only",
                    fontSize = 11.sp,
                    color = androidx.compose.material3.MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
            androidx.compose.material3.Switch(
                checked = rerankEnabled,
                onCheckedChange = { vm.setRerankEnabled(it) }
            )
        }
    }
}

/**
 * v5.2.0 — Settings card for Home-screen-specific options.
 *
 * Currently just the recent-searches count (0–20). Slider is overkill
 * for one value, so a row of +/− buttons around the current number is
 * used instead — easier to fine-tune on a phone screen.
 */
@androidx.compose.runtime.Composable
private fun HomeScreenSection(vm: com.tebogo.markvault.AppViewModel) {
    val current by vm.maxRecentSearchesOnHome.collectAsStateWithLifecycle()
    Text(
        "\uD83C\uDFE0  Home screen",
        fontWeight = androidx.compose.ui.text.font.FontWeight.Bold,
        fontSize = 16.sp
    )
    androidx.compose.foundation.layout.Spacer(
        androidx.compose.ui.Modifier.height(6.dp)
    )
    Text(
        "How many recent search queries to show under the home-page search bar. " +
            "Tap one to re-run it. Set to 0 to hide the list entirely.",
        fontSize = 13.sp,
        color = androidx.compose.material3.MaterialTheme.colorScheme.onSurfaceVariant,
        lineHeight = 18.sp
    )
    androidx.compose.foundation.layout.Spacer(
        androidx.compose.ui.Modifier.height(12.dp)
    )
    androidx.compose.foundation.layout.Row(
        modifier = androidx.compose.ui.Modifier.fillMaxWidth(),
        verticalAlignment = androidx.compose.ui.Alignment.CenterVertically
    ) {
        Text(
            "Recent search entries",
            fontSize = 14.sp,
            modifier = androidx.compose.ui.Modifier.weight(1f)
        )
        OutlinedButton(
            onClick = { vm.setMaxRecentSearchesOnHome((current - 1).coerceAtLeast(0)) },
            enabled = current > 0
        ) { Text("\u2212") }
        androidx.compose.foundation.layout.Spacer(
            androidx.compose.ui.Modifier.width(12.dp)
        )
        Text(
            "$current",
            fontSize = 18.sp,
            fontWeight = androidx.compose.ui.text.font.FontWeight.Bold,
            modifier = androidx.compose.ui.Modifier.widthIn(min = 28.dp),
            textAlign = androidx.compose.ui.text.style.TextAlign.Center
        )
        androidx.compose.foundation.layout.Spacer(
            androidx.compose.ui.Modifier.width(12.dp)
        )
        OutlinedButton(
            onClick = { vm.setMaxRecentSearchesOnHome((current + 1).coerceAtMost(20)) },
            enabled = current < 20
        ) { Text("+") }
    }

    // v5.4.36 — Home-screen scroll direction toggle.
    androidx.compose.foundation.layout.Spacer(
        androidx.compose.ui.Modifier.height(20.dp)
    )
    androidx.compose.material3.HorizontalDivider()
    androidx.compose.foundation.layout.Spacer(
        androidx.compose.ui.Modifier.height(16.dp)
    )
    Text(
        "Article rows scroll direction",
        fontSize = 14.sp,
        fontWeight = androidx.compose.ui.text.font.FontWeight.SemiBold
    )
    androidx.compose.foundation.layout.Spacer(
        androidx.compose.ui.Modifier.height(4.dp)
    )
    Text(
        "Favourites, Continue reading, New in library, and Suggested " +
            "sections can scroll horizontally (default) or vertically.",
        fontSize = 12.sp,
        color = androidx.compose.material3.MaterialTheme.colorScheme.onSurfaceVariant,
        lineHeight = 16.sp
    )
    androidx.compose.foundation.layout.Spacer(
        androidx.compose.ui.Modifier.height(10.dp)
    )
    val homeVert by vm.homeScrollVertical.collectAsStateWithLifecycle()
    androidx.compose.foundation.layout.Row(
        modifier = androidx.compose.ui.Modifier.fillMaxWidth(),
        horizontalArrangement = androidx.compose.foundation.layout.Arrangement.spacedBy(8.dp)
    ) {
        androidx.compose.material3.FilterChip(
            selected = !homeVert,
            onClick = { vm.setHomeScrollVertical(false) },
            label = { Text("\u2194\uFE0F  Horizontal") },
            modifier = androidx.compose.ui.Modifier.weight(1f)
        )
        androidx.compose.material3.FilterChip(
            selected = homeVert,
            onClick = { vm.setHomeScrollVertical(true) },
            label = { Text("\u2195\uFE0F  Vertical") },
            modifier = androidx.compose.ui.Modifier.weight(1f)
        )
    }

    /**
     * v5.4.20 — UI mode picker. Standard (default) keeps the current
     * minimalist reader look — tab strip only shows when there are 2+
     * open tabs. Workspace makes the tab strip persistent with a "+"
     * button for opening new tabs from any article.
     */
    androidx.compose.foundation.layout.Spacer(
        androidx.compose.ui.Modifier.height(24.dp)
    )
    androidx.compose.material3.HorizontalDivider()
    androidx.compose.foundation.layout.Spacer(
        androidx.compose.ui.Modifier.height(16.dp)
    )
    Text(
        "UI mode",
        fontSize = 14.sp,
        fontWeight = androidx.compose.ui.text.font.FontWeight.SemiBold
    )
    androidx.compose.foundation.layout.Spacer(
        androidx.compose.ui.Modifier.height(4.dp)
    )
    Text(
        "Standard = current minimalist look. Workspace = persistent tab " +
            "strip with a + button for opening new tabs from any reader. " +
            "Every other feature works identically in both modes.",
        fontSize = 12.sp,
        color = androidx.compose.material3.MaterialTheme.colorScheme.onSurfaceVariant,
        lineHeight = 16.sp
    )
    androidx.compose.foundation.layout.Spacer(
        androidx.compose.ui.Modifier.height(10.dp)
    )
    val uiMode by vm.uiMode.collectAsStateWithLifecycle()
    val modeOptions = listOf(
        Triple("standard",  "\uD83D\uDCF1  Standard",
            "Reader is one screen at a time. Tab strip appears only with 2+ open tabs."),
        Triple("workspace", "\uD83E\uDDF0  Workspace",
            "Tab strip always visible with a + button to open new tabs. Everything else unchanged."),
    )
    androidx.compose.foundation.layout.Column(
        modifier = androidx.compose.ui.Modifier.fillMaxWidth()
    ) {
        for ((id, label, desc) in modeOptions) {
            val selected = id == uiMode
            androidx.compose.foundation.layout.Row(
                modifier = androidx.compose.ui.Modifier
                    .fillMaxWidth()
                    .clickable { vm.setUiMode(id) }
                    .padding(vertical = 4.dp),
                verticalAlignment = androidx.compose.ui.Alignment.Top
            ) {
                androidx.compose.material3.RadioButton(
                    selected = selected,
                    onClick = { vm.setUiMode(id) }
                )
                androidx.compose.foundation.layout.Spacer(
                    androidx.compose.ui.Modifier.width(4.dp)
                )
                androidx.compose.foundation.layout.Column(
                    modifier = androidx.compose.ui.Modifier
                        .weight(1f)
                        .padding(top = 12.dp)
                ) {
                    Text(
                        label,
                        fontSize = 13.sp,
                        fontWeight = androidx.compose.ui.text.font.FontWeight.Medium
                    )
                    Text(
                        desc,
                        fontSize = 11.sp,
                        color = androidx.compose.material3.MaterialTheme.colorScheme.onSurfaceVariant,
                        lineHeight = 14.sp
                    )
                }
            }
        }
    }
}

/**
 * v5.3.0 — Settings card for browser-tab preview options.
 *
 * Currently just orientation. "Vertical" (default) shows tab cards in a
 * scrolling 2-column grid — best for many tabs. "Horizontal" shows the
 * cards as a side-swipeable row — best for browsing a few tabs visually.
 */
@androidx.compose.runtime.Composable
private fun BrowserTabsSection(vm: com.tebogo.markvault.AppViewModel) {
    val current by vm.tabsPreviewOrientation.collectAsStateWithLifecycle()
    Text(
        "\uD83D\uDDC2  Browser tabs",
        fontWeight = androidx.compose.ui.text.font.FontWeight.Bold,
        fontSize = 16.sp
    )
    androidx.compose.foundation.layout.Spacer(
        androidx.compose.ui.Modifier.height(6.dp)
    )
    Text(
        "How the floating tabs button shows your open browser tabs when " +
            "you tap it. Vertical lists tabs as a 2-column scrolling grid. " +
            "Horizontal shows one tall card at a time, swipe left/right.",
        fontSize = 13.sp,
        color = androidx.compose.material3.MaterialTheme.colorScheme.onSurfaceVariant,
        lineHeight = 18.sp
    )
    androidx.compose.foundation.layout.Spacer(
        androidx.compose.ui.Modifier.height(12.dp)
    )
    androidx.compose.foundation.layout.Row(
        modifier = androidx.compose.ui.Modifier.fillMaxWidth(),
        horizontalArrangement = androidx.compose.foundation.layout.Arrangement.spacedBy(8.dp)
    ) {
        androidx.compose.material3.FilterChip(
            selected = current == "vertical",
            onClick = { vm.setTabsPreviewOrientation("vertical") },
            label = { Text("\u2630  Vertical grid") },
            modifier = androidx.compose.ui.Modifier.weight(1f)
        )
        androidx.compose.material3.FilterChip(
            selected = current == "horizontal",
            onClick = { vm.setTabsPreviewOrientation("horizontal") },
            label = { Text("\u21E2  Horizontal swipe") },
            modifier = androidx.compose.ui.Modifier.weight(1f)
        )
    }

    // v5.4.13 — Link long-press action picker. Lives here under
    // "Browser tabs" because it only affects the in-app browser's
    // long-press behaviour, never the library-screen long-press
    // (which has its own separate menu).
    androidx.compose.foundation.layout.Spacer(
        androidx.compose.ui.Modifier.height(20.dp)
    )
    androidx.compose.material3.HorizontalDivider()
    androidx.compose.foundation.layout.Spacer(
        androidx.compose.ui.Modifier.height(16.dp)
    )
    Text(
        "Long-press a link in the browser",
        fontSize = 14.sp,
        fontWeight = androidx.compose.ui.text.font.FontWeight.SemiBold
    )
    androidx.compose.foundation.layout.Spacer(
        androidx.compose.ui.Modifier.height(4.dp)
    )
    Text(
        "What happens when you press and hold a link in the in-app " +
            "browser. The library screen's long-press menu is separate.",
        fontSize = 12.sp,
        color = androidx.compose.material3.MaterialTheme.colorScheme.onSurfaceVariant,
        lineHeight = 16.sp
    )
    androidx.compose.foundation.layout.Spacer(
        androidx.compose.ui.Modifier.height(10.dp)
    )
    val lpAction by vm.linkLongPressAction.collectAsStateWithLifecycle()
    val lpOptions = listOf(
        Triple("menu",     "Show menu",
            "Default. Sheet with copy, open in new tab, convert to MD, convert to PDF."),
        Triple("markdown", "Convert to Markdown",
            "Skip the menu. Long-press converts the link to a Markdown article."),
        Triple("pdf",      "Convert to PDF",
            "Skip the menu. Long-press converts the link to a PDF."),
    )
    androidx.compose.foundation.layout.Column(
        modifier = androidx.compose.ui.Modifier.fillMaxWidth()
    ) {
        for ((id, label, desc) in lpOptions) {
            val selected = id == lpAction
            androidx.compose.foundation.layout.Row(
                modifier = androidx.compose.ui.Modifier
                    .fillMaxWidth()
                    .clickable { vm.setLinkLongPressAction(id) }
                    .padding(vertical = 4.dp),
                verticalAlignment = androidx.compose.ui.Alignment.Top
            ) {
                androidx.compose.material3.RadioButton(
                    selected = selected,
                    onClick = { vm.setLinkLongPressAction(id) }
                )
                androidx.compose.foundation.layout.Spacer(
                    androidx.compose.ui.Modifier.width(4.dp)
                )
                androidx.compose.foundation.layout.Column(
                    modifier = androidx.compose.ui.Modifier
                        .weight(1f)
                        .padding(top = 12.dp)
                ) {
                    Text(
                        label,
                        fontSize = 13.sp,
                        fontWeight = androidx.compose.ui.text.font.FontWeight.Medium
                    )
                    Text(
                        desc,
                        fontSize = 11.sp,
                        color = androidx.compose.material3.MaterialTheme.colorScheme.onSurfaceVariant,
                        lineHeight = 14.sp
                    )
                }
            }
        }
    }

    // v5.4.35 — Link-open mode picker: new tab (default) vs same tab.
    // Controls how external links tapped in offline HTML articles open
    // in the in-app browser.
    androidx.compose.foundation.layout.Spacer(
        androidx.compose.ui.Modifier.height(20.dp)
    )
    androidx.compose.material3.HorizontalDivider()
    androidx.compose.foundation.layout.Spacer(
        androidx.compose.ui.Modifier.height(16.dp)
    )
    Text(
        "Links from offline articles",
        fontSize = 14.sp,
        fontWeight = androidx.compose.ui.text.font.FontWeight.SemiBold
    )
    androidx.compose.foundation.layout.Spacer(
        androidx.compose.ui.Modifier.height(4.dp)
    )
    Text(
        "When you tap a scripture or external link in an offline HTML article, " +
            "should it open in a new browser tab or reuse the current tab?",
        fontSize = 12.sp,
        color = androidx.compose.material3.MaterialTheme.colorScheme.onSurfaceVariant,
        lineHeight = 16.sp
    )
    androidx.compose.foundation.layout.Spacer(
        androidx.compose.ui.Modifier.height(10.dp)
    )
    val newTab by vm.openLinksInNewTab.collectAsStateWithLifecycle()
    androidx.compose.foundation.layout.Row(
        modifier = androidx.compose.ui.Modifier.fillMaxWidth(),
        horizontalArrangement = androidx.compose.foundation.layout.Arrangement.spacedBy(8.dp)
    ) {
        androidx.compose.material3.FilterChip(
            selected = newTab,
            onClick = { vm.setOpenLinksInNewTab(true) },
            label = { Text("\uD83D\uDDC2  New tab") },
            modifier = androidx.compose.ui.Modifier.weight(1f)
        )
        androidx.compose.material3.FilterChip(
            selected = !newTab,
            onClick = { vm.setOpenLinksInNewTab(false) },
            label = { Text("\uD83D\uDD04  Same tab") },
            modifier = androidx.compose.ui.Modifier.weight(1f)
        )
    }
}

/**
 * v5.3.1 — Settings card for search-results filtering.
 *
 * Currently just the keyword filter. When ON (default) and the user's
 * query has 2+ meaningful words (i.e. not stopwords), each shown
 * result must contain at least 2 distinct meaningful query words.
 * Cuts noise from single-word matches that happen to share one common
 * term with the query.
 *
 * Turning the filter OFF shows every keyword + semantic hit — useful
 * when the user wants to see semantic-only matches that don't share
 * literal vocabulary with the query.
 */
@androidx.compose.runtime.Composable
private fun SearchFiltersSection(vm: com.tebogo.markvault.AppViewModel) {
    val on by vm.keywordFilterEnabled.collectAsStateWithLifecycle()
    Text(
        "\uD83E\uDDF9  Search filters",
        fontWeight = androidx.compose.ui.text.font.FontWeight.Bold,
        fontSize = 16.sp
    )
    androidx.compose.foundation.layout.Spacer(
        androidx.compose.ui.Modifier.height(6.dp)
    )
    Text(
        "Keyword filter requires search results to contain at least 2 of " +
            "the meaningful words from your query (skipping common words " +
            "like 'the' and 'is'). When OFF, every keyword and semantic " +
            "hit is shown — useful for surfacing semantically-related " +
            "articles that don't share literal vocabulary with the query.",
        fontSize = 13.sp,
        color = androidx.compose.material3.MaterialTheme.colorScheme.onSurfaceVariant,
        lineHeight = 18.sp
    )
    androidx.compose.foundation.layout.Spacer(
        androidx.compose.ui.Modifier.height(12.dp)
    )
    androidx.compose.foundation.layout.Row(
        modifier = androidx.compose.ui.Modifier.fillMaxWidth(),
        verticalAlignment = androidx.compose.ui.Alignment.CenterVertically
    ) {
        Text(
            "Keyword filter",
            fontSize = 14.sp,
            modifier = androidx.compose.ui.Modifier.weight(1f)
        )
        androidx.compose.material3.Switch(
            checked = on,
            onCheckedChange = { vm.setKeywordFilterEnabled(it) }
        )
    }
}

/**
 * v5.4.0 — Memory section.
 *
 * Shows the user a rough estimate of where their RAM is going and
 * gives them a button to release the heaviest holders on demand. The
 * same release happens automatically when the OS signals memory
 * pressure (TRIM_MEMORY_UI_HIDDEN or below); this section is for
 * users who want to free memory explicitly while the app is still in
 * the foreground.
 */
@androidx.compose.runtime.Composable
private fun MemorySection(vm: com.tebogo.markvault.AppViewModel) {
    val ctx = androidx.compose.ui.platform.LocalContext.current
    val rerankerInstalled by vm.rerankerInstalled.collectAsStateWithLifecycle()
    val embeddingCount by vm.embeddingCount.collectAsStateWithLifecycle()
    val semanticEnabled by vm.semanticEnabled.collectAsStateWithLifecycle()
    val semanticChunkCount by vm.semanticChunkCount.collectAsStateWithLifecycle()

    val rt = android.os.Debug.MemoryInfo().also { runCatching { android.os.Debug.getMemoryInfo(it) } }
    val nativeMb = runCatching { rt.nativePss / 1024 }.getOrDefault(0)
    val javaMb   = runCatching { rt.dalvikPss / 1024 }.getOrDefault(0)
    val totalPssMb = runCatching { rt.totalPss / 1024 }.getOrDefault(0)

    Text("\uD83E\uDDE0  Memory",
        fontWeight = androidx.compose.ui.text.font.FontWeight.Bold, fontSize = 16.sp)
    androidx.compose.foundation.layout.Spacer(androidx.compose.ui.Modifier.height(6.dp))
    val indexedMb = (embeddingCount.toLong() * 1024L * 4L / 1024L / 1024L).coerceAtLeast(0L)
    Text(
        "MarkVault holds the BGE-large embedder (~280 MB native) and " +
            "the cross-encoder reranker (~150 MB native) in RAM while " +
            "you're searching. Each scope loads ~240 MB for 20k articles — " +
            "the same scale that worked at 19k articles.",
        fontSize = 13.sp,
        color = androidx.compose.material3.MaterialTheme.colorScheme.onSurfaceVariant,
        lineHeight = 18.sp
    )
    androidx.compose.foundation.layout.Spacer(androidx.compose.ui.Modifier.height(8.dp))

    Text(
        "Semantic search currently has $semanticChunkCount chunks resident in memory. " +
            "Search-scope selection is under Search & Retrieval → Search Scope.",
        fontSize = 12.sp,
        color = androidx.compose.material3.MaterialTheme.colorScheme.onSurfaceVariant,
        lineHeight = 16.sp
    )
    androidx.compose.foundation.layout.Spacer(androidx.compose.ui.Modifier.height(10.dp))
    if (totalPssMb > 0) {
        Text(
            "Current usage:  ${totalPssMb} MB total  (${javaMb} MB heap, ${nativeMb} MB native)",
            fontSize = 12.sp,
            color = androidx.compose.material3.MaterialTheme.colorScheme.onSurfaceVariant,
            fontFamily = androidx.compose.ui.text.font.FontFamily.Monospace
        )
        androidx.compose.foundation.layout.Spacer(
            androidx.compose.ui.Modifier.height(10.dp)
        )
    }
    var feedback by androidx.compose.runtime.remember {
        androidx.compose.runtime.mutableStateOf<String?>(null)
    }
    androidx.compose.material3.OutlinedButton(
        onClick = {
            val before = runCatching {
                val mi = android.os.Debug.MemoryInfo()
                android.os.Debug.getMemoryInfo(mi)
                mi.totalPss / 1024
            }.getOrDefault(0)
            vm.freeMemory()
            // Wait a beat for GC then measure again
            android.os.Handler(android.os.Looper.getMainLooper()).postDelayed({
                val after = runCatching {
                    val mi2 = android.os.Debug.MemoryInfo()
                    android.os.Debug.getMemoryInfo(mi2)
                    mi2.totalPss / 1024
                }.getOrDefault(0)
                val freed = (before - after).coerceAtLeast(0)
                feedback = if (before > 0 && after > 0)
                    "Freed ${freed} MB. Models will reload on next search."
                else
                    "Memory released. Models will reload on next search."
            }, 500L)
        },
        modifier = androidx.compose.ui.Modifier.fillMaxWidth()
    ) {
        Text("\uD83E\uDDF9  Free memory now")
    }
    val fb = feedback
    if (fb != null) {
        androidx.compose.foundation.layout.Spacer(
            androidx.compose.ui.Modifier.height(8.dp)
        )
        Text(
            fb,
            fontSize = 12.sp,
            color = androidx.compose.material3.MaterialTheme.colorScheme.primary
        )
    }
}

/**
 * v5.4.1 — Diagnostics section.
 *
 * Three toggles that let the user narrow down the cause of search-time
 * crashes by disabling individual stages of the pipeline. None of them
 * remove a feature outright; each just changes WHEN or WHETHER that
 * piece runs.
 *
 *   • Live search          — debounced typing fires searches (default)
 *                            vs only the search/submit button does.
 *   • Cancel previous      — new keystroke cancels mid-flight search
 *                            (default) vs runs every search to completion.
 *   • Auto-free memory     — onBackground releases ONNX sessions
 *                            (default) vs models stay resident.
 */
@androidx.compose.runtime.Composable
private fun DiagnosticsSection(vm: com.tebogo.markvault.AppViewModel, nav: androidx.navigation.NavController) {
    val live by vm.liveSearchEnabled.collectAsStateWithLifecycle()
    val cancel by vm.cancelInflightSearch.collectAsStateWithLifecycle()
    val autoFree by vm.autoFreeMemory.collectAsStateWithLifecycle()
    val rerankSubmit by vm.rerankOnSubmitOnly.collectAsStateWithLifecycle()
    Text(
        "\uD83E\uDDEA  Diagnostics (crash-tracking)",
        fontWeight = androidx.compose.ui.text.font.FontWeight.Bold,
        fontSize = 16.sp
    )
    androidx.compose.foundation.layout.Spacer(
        androidx.compose.ui.Modifier.height(6.dp)
    )
    Text(
        "If searching crashes the app, turn these OFF one at a time to " +
            "find which stage is responsible. Defaults match the normal " +
            "fast-search behaviour; everything off = safest mode but " +
            "needs the 🔍 button or Enter key to actually run.",
        fontSize = 13.sp,
        color = androidx.compose.material3.MaterialTheme.colorScheme.onSurfaceVariant,
        lineHeight = 18.sp
    )
    androidx.compose.foundation.layout.Spacer(
        androidx.compose.ui.Modifier.height(12.dp)
    )
    DiagnosticToggle(
        title = "Rerank on submit only",
        subtitle = "ON (default) = cross-encoder runs only when you tap 🔍 " +
            "or press Enter. OFF = rerank fires on every keystroke (high " +
            "crash risk on memory-constrained devices). Keep ON unless " +
            "you have lots of RAM headroom.",
        checked = rerankSubmit,
        onChange = { vm.setRerankOnSubmitOnly(it) }
    )
    androidx.compose.foundation.layout.Spacer(
        androidx.compose.ui.Modifier.height(8.dp)
    )
    DiagnosticToggle(
        title = "Live search",
        subtitle = "Search runs while you type. OFF = only when you tap " +
            "🔍 or press the search key.",
        checked = live,
        onChange = { vm.setLiveSearchEnabled(it) }
    )
    androidx.compose.foundation.layout.Spacer(
        androidx.compose.ui.Modifier.height(8.dp)
    )
    DiagnosticToggle(
        title = "Cancel previous search",
        subtitle = "A new keystroke cancels in-progress search. OFF = " +
            "let every search finish before starting the next.",
        checked = cancel,
        onChange = { vm.setCancelInflightSearch(it) }
    )
    androidx.compose.foundation.layout.Spacer(
        androidx.compose.ui.Modifier.height(8.dp)
    )
    DiagnosticToggle(
        title = "Auto-free memory",
        subtitle = "Release ONNX models when the app goes to background. " +
            "OFF = keep them resident (uses more RAM but no reload cost).",
        checked = autoFree,
        onChange = { vm.setAutoFreeMemory(it) }
    )
    androidx.compose.foundation.layout.Spacer(
        androidx.compose.ui.Modifier.height(8.dp)
    )
    // v5.4.18 — Four new toggles.
    val showRerankPct by vm.showRerankProgress.collectAsStateWithLifecycle()
    val showSemPct by vm.showSemanticProgress.collectAsStateWithLifecycle()
    val fabOn by vm.searchInArticleFab.collectAsStateWithLifecycle()
    val semArtOn by vm.semanticInArticle.collectAsStateWithLifecycle()
    androidx.compose.foundation.layout.Spacer(
        androidx.compose.ui.Modifier.height(8.dp)
    )
    DiagnosticToggle(
        title = "Rerank % indicator",
        subtitle = "ON (default) = shows the % progress ring in the top bar " +
            "during manual rerank. OFF = silent rerank, no visual feedback.",
        checked = showRerankPct,
        onChange = { vm.setShowRerankProgress(it) }
    )
    androidx.compose.foundation.layout.Spacer(
        androidx.compose.ui.Modifier.height(8.dp)
    )
    DiagnosticToggle(
        title = "Semantic % indicator",
        subtitle = "ON (default) = shows model download / index build / " +
            "load progress bars in Settings and the search bar. OFF = " +
            "everything happens silently.",
        checked = showSemPct,
        onChange = { vm.setShowSemanticProgress(it) }
    )
    androidx.compose.foundation.layout.Spacer(
        androidx.compose.ui.Modifier.height(8.dp)
    )
    // v5.4.33 — Search indicator animation style picker
    run {
        val indicStyle by vm.searchIndicatorStyle.collectAsStateWithLifecycle()
        Text(
            "\uD83C\uDFAC Search indicator style",
            fontSize = 14.sp,
            fontWeight = androidx.compose.ui.text.font.FontWeight.Medium
        )
        Text(
            "Choose what animation shows while searching.",
            fontSize = 12.sp,
            color = androidx.compose.material3.MaterialTheme.colorScheme.onSurfaceVariant,
            lineHeight = 16.sp
        )
        androidx.compose.foundation.layout.Spacer(
            androidx.compose.ui.Modifier.height(4.dp)
        )
        Column(
            verticalArrangement = androidx.compose.foundation.layout.Arrangement.spacedBy(6.dp)
        ) {
            Row(
                horizontalArrangement = androidx.compose.foundation.layout.Arrangement.spacedBy(8.dp)
            ) {
                listOf(
                    "percentage" to "\uD83D\uDD03 Percentage",
                    "hourglass" to "\u23F3 Hourglass"
                ).forEach { (key, label) ->
                    androidx.compose.material3.FilterChip(
                        selected = indicStyle == key,
                        onClick = { vm.setSearchIndicatorStyle(key) },
                        label = { Text(label, fontSize = 12.sp) }
                    )
                }
            }
            Row(
                horizontalArrangement = androidx.compose.foundation.layout.Arrangement.spacedBy(8.dp)
            ) {
                listOf(
                    "book" to "\uD83D\uDCD6 Book",
                    "large_percentage" to "\uD83D\uDD04 Large %"
                ).forEach { (key, label) ->
                    androidx.compose.material3.FilterChip(
                        selected = indicStyle == key,
                        onClick = { vm.setSearchIndicatorStyle(key) },
                        label = { Text(label, fontSize = 12.sp) }
                    )
                }
            }
        }
    }
    androidx.compose.foundation.layout.Spacer(
        androidx.compose.ui.Modifier.height(8.dp)
    )
    DiagnosticToggle(
        title = "\uD83D\uDD0D Find-in-article button",
        subtitle = "ON (default) = floating button appears when you open " +
            "an article from a search result. Tap the button and it " +
            "searches inside the article for the same query — quotes " +
            "stripped. Only shows for search-opened articles.",
        checked = fabOn,
        onChange = { vm.setSearchInArticleFab(it) }
    )
    androidx.compose.foundation.layout.Spacer(
        androidx.compose.ui.Modifier.height(8.dp)
    )
    DiagnosticToggle(
        title = "\uD83E\uDDE0 Semantic in-article search",
        subtitle = "OFF (default) = find-in-article uses plain keyword " +
            "match. ON = additionally embeds each paragraph with the " +
            "active embedder, cosine-ranks against the query, and " +
            "re-targets the find to the top-matching paragraph. " +
            "Useful for long articles. Costs cycles.",
        checked = semArtOn,
        onChange = { vm.setSemanticInArticle(it) }
    )
    androidx.compose.foundation.layout.Spacer(
        androidx.compose.ui.Modifier.height(12.dp)
    )
    // v5.4.132cc — Stepper: how many top-rated articles the pumping-
    // heart FAB on the Search screen visits when building the multi-
    // article popup. Range 1..10, default 1.
    val popupTopN by vm.popupArticlesTopN.collectAsStateWithLifecycle()
    androidx.compose.foundation.layout.Row(
        modifier = androidx.compose.ui.Modifier.fillMaxWidth(),
        verticalAlignment = androidx.compose.ui.Alignment.CenterVertically
    ) {
        androidx.compose.foundation.layout.Column(
            modifier = androidx.compose.ui.Modifier.weight(1f)
        ) {
            Text(
                "\uD83D\uDC97 Popup articles (top-N)",
                fontSize = 14.sp,
                fontWeight = androidx.compose.ui.text.font.FontWeight.Medium
            )
            Text(
                "How many top-rated search results the pumping-heart " +
                    "button on the Search screen pulls passages from. " +
                    "1 = just the single best hit; 3\u20135 gives a broader " +
                    "\u201Cwhat does the library say about X\u201D snapshot.",
                fontSize = 12.sp,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                modifier = androidx.compose.ui.Modifier.padding(top = 2.dp)
            )
        }
        androidx.compose.foundation.layout.Spacer(
            androidx.compose.ui.Modifier.width(12.dp)
        )
        androidx.compose.material3.OutlinedButton(
            onClick = {
                if (popupTopN > 1) vm.setPopupArticlesTopN(popupTopN - 1)
            },
            enabled = popupTopN > 1,
            contentPadding = androidx.compose.foundation.layout.PaddingValues(
                horizontal = 12.dp, vertical = 4.dp
            )
        ) { Text("\u2212") }
        Text(
            text = popupTopN.toString(),
            fontSize = 15.sp,
            fontWeight = androidx.compose.ui.text.font.FontWeight.SemiBold,
            modifier = androidx.compose.ui.Modifier
                .padding(horizontal = 10.dp)
                .widthIn(min = 20.dp)
        )
        androidx.compose.material3.OutlinedButton(
            onClick = {
                if (popupTopN < 10) vm.setPopupArticlesTopN(popupTopN + 1)
            },
            enabled = popupTopN < 10,
            contentPadding = androidx.compose.foundation.layout.PaddingValues(
                horizontal = 12.dp, vertical = 4.dp
            )
        ) { Text("+") }
    }
}

@androidx.compose.runtime.Composable
private fun DiagnosticToggle(
    title: String,
    subtitle: String,
    checked: Boolean,
    onChange: (Boolean) -> Unit
) {
    androidx.compose.foundation.layout.Row(
        modifier = androidx.compose.ui.Modifier.fillMaxWidth(),
        verticalAlignment = androidx.compose.ui.Alignment.CenterVertically
    ) {
        androidx.compose.foundation.layout.Column(
            modifier = androidx.compose.ui.Modifier.weight(1f)
        ) {
            Text(title, fontSize = 14.sp,
                fontWeight = androidx.compose.ui.text.font.FontWeight.Medium)
            Text(
                subtitle,
                fontSize = 12.sp,
                color = androidx.compose.material3.MaterialTheme.colorScheme.onSurfaceVariant,
                lineHeight = 16.sp
            )
        }
        androidx.compose.foundation.layout.Spacer(
            androidx.compose.ui.Modifier.width(8.dp)
        )
        androidx.compose.material3.Switch(
            checked = checked,
            onCheckedChange = onChange
        )
    }
}

/**
 * v5.4.9 — Highlight mode picker.
 *
 * Three options for how matching content in an opened article gets
 * highlighted:
 *
 *   • Auto    — follows semantic search. When semantic ON, uses
 *               sentence-level "smart" mode. When semantic OFF,
 *               uses word-level "keyword" mode. The recommended
 *               default; matches the user's intuition that
 *               meaning-based highlight should fire only when
 *               meaning-based search is active.
 *
 *   • Smart   — always sentence-level. Skips headings entirely
 *               (no more yellow titles) and requires 2+ distinct
 *               query terms in a body sentence before wrapping it.
 *               Word-level backfill ensures terms in headings or
 *               weakly-matching sentences still get a small mark.
 *
 *   • Keyword — always word-level only. Just wraps exact term
 *               matches anywhere in the article. Minimal visual
 *               noise; useful when you only want to spot the
 *               query words without yellow blocks.
 */
@androidx.compose.runtime.Composable
private fun HighlightModePicker(vm: com.tebogo.markvault.AppViewModel) {
    val mode by vm.highlightMode.collectAsStateWithLifecycle()
    val options = listOf(
        Triple("auto",    "Auto",
            "Follows semantic search — sentence-level when semantic is on, word-level when off."),
        Triple("smart",   "Smart (sentence)",
            "Highlights body sentences with 2+ query terms. Headings get word-level marks. Always on."),
        Triple("keyword", "Keyword (words only)",
            "Just highlights exact matches of query words. No sentence wrapping. Minimal noise."),
    )
    androidx.compose.foundation.layout.Column(
        modifier = androidx.compose.ui.Modifier.fillMaxWidth()
    ) {
        Text(
            "Highlighting style",
            fontSize = 13.sp,
            fontWeight = androidx.compose.ui.text.font.FontWeight.SemiBold,
            color = androidx.compose.material3.MaterialTheme.colorScheme.onSurface
        )
        androidx.compose.foundation.layout.Spacer(
            androidx.compose.ui.Modifier.height(4.dp)
        )
        for ((id, label, desc) in options) {
            val selected = id == mode
            androidx.compose.foundation.layout.Row(
                modifier = androidx.compose.ui.Modifier
                    .fillMaxWidth()
                    .clickable { vm.setHighlightMode(id) }
                    .padding(vertical = 4.dp),
                verticalAlignment = androidx.compose.ui.Alignment.Top
            ) {
                androidx.compose.material3.RadioButton(
                    selected = selected,
                    onClick = { vm.setHighlightMode(id) }
                )
                androidx.compose.foundation.layout.Spacer(
                    androidx.compose.ui.Modifier.width(4.dp)
                )
                androidx.compose.foundation.layout.Column(
                    modifier = androidx.compose.ui.Modifier
                        .weight(1f)
                        .padding(top = 12.dp)
                ) {
                    Text(
                        label,
                        fontSize = 13.sp,
                        fontWeight = androidx.compose.ui.text.font.FontWeight.Medium,
                        color = androidx.compose.material3.MaterialTheme.colorScheme.onSurface
                    )
                    Text(
                        desc,
                        fontSize = 11.sp,
                        color = androidx.compose.material3.MaterialTheme.colorScheme.onSurfaceVariant,
                        lineHeight = 14.sp
                    )
                }
            }
        }
    }
}

/**
 * v5.4.12 — Collapsible settings category wrapper.
 *
 * Wraps a group of related settings sections in a card with a header
 * that's tappable to expand/collapse. When the user types in the
 * settings search bar above, the category checks if its title /
 * description / [matchTokens] contain the query (case-insensitive).
 * If a match → forced expanded, even if the user had collapsed it.
 * If no match while a query is active → the whole category is hidden,
 * reducing visual clutter to just the matching categories.
 *
 * Collapse state is held in `remember` per category title — survives
 * recomposition but resets when the screen is destroyed (acceptable
 * tradeoff for the simpler implementation).
 */
@androidx.compose.runtime.Composable
private fun CollapsibleCategory(
    emoji: String,
    title: String,
    description: String,
    matchTokens: List<String>,
    searchQuery: String,
    initiallyExpanded: Boolean = false,
    content: @androidx.compose.runtime.Composable () -> Unit
) {
    val queryLower = searchQuery.trim().lowercase()
    val isFiltering = queryLower.isNotEmpty()
    val matchesQuery = !isFiltering || run {
        title.lowercase().contains(queryLower) ||
            description.lowercase().contains(queryLower) ||
            matchTokens.any { it.lowercase().contains(queryLower) }
    }
    // Hide the entire category when the user is filtering and there's
    // no match — that's the whole point of search.
    if (isFiltering && !matchesQuery) return

    var userExpanded by androidx.compose.runtime.remember(title) {
        androidx.compose.runtime.mutableStateOf(initiallyExpanded)
    }
    val effectiveExpanded = if (isFiltering) true else userExpanded

    androidx.compose.material3.Surface(
        color = androidx.compose.material3.MaterialTheme.colorScheme.surfaceVariant,
        shape = androidx.compose.foundation.shape.RoundedCornerShape(14.dp),
        tonalElevation = 1.dp,
        modifier = androidx.compose.ui.Modifier.fillMaxWidth()
    ) {
        androidx.compose.foundation.layout.Column(
            modifier = androidx.compose.ui.Modifier.fillMaxWidth()
        ) {
            androidx.compose.foundation.layout.Row(
                modifier = androidx.compose.ui.Modifier
                    .fillMaxWidth()
                    .clickable {
                        // Tapping the header always toggles. When filtering, the
                        // category stays effectively expanded (matchesQuery is true)
                        // but a tap still flips the underlying state so a clear-
                        // search returns it to user-controlled collapse properly.
                        userExpanded = !userExpanded
                    }
                    .padding(horizontal = 16.dp, vertical = 14.dp),
                verticalAlignment = androidx.compose.ui.Alignment.CenterVertically
            ) {
                Text(emoji, fontSize = 22.sp)
                androidx.compose.foundation.layout.Spacer(
                    androidx.compose.ui.Modifier.width(12.dp)
                )
                androidx.compose.foundation.layout.Column(
                    modifier = androidx.compose.ui.Modifier.weight(1f)
                ) {
                    Text(
                        title,
                        fontSize = 15.sp,
                        fontWeight = androidx.compose.ui.text.font.FontWeight.SemiBold,
                        color = androidx.compose.material3.MaterialTheme.colorScheme.onSurface
                    )
                    if (description.isNotBlank()) {
                        androidx.compose.foundation.layout.Spacer(
                            androidx.compose.ui.Modifier.height(2.dp)
                        )
                        Text(
                            description,
                            fontSize = 11.sp,
                            color = androidx.compose.material3.MaterialTheme.colorScheme.onSurfaceVariant,
                            lineHeight = 14.sp
                        )
                    }
                }
                androidx.compose.foundation.layout.Spacer(
                    androidx.compose.ui.Modifier.width(8.dp)
                )
                Text(
                    if (effectiveExpanded) "\u25BE" else "\u25B8",
                    fontSize = 16.sp,
                    color = androidx.compose.material3.MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
            if (effectiveExpanded) {
                androidx.compose.foundation.layout.Column(
                    modifier = androidx.compose.ui.Modifier
                        .fillMaxWidth()
                        .padding(start = 16.dp, end = 16.dp, bottom = 16.dp)
                ) {
                    content()
                }
            }
        }
    }
}

/**
 * v5.4.111cc — Compact toggle row for a single search-bar chip's
 * visibility. Mirrors the inline Row+Switch pattern used throughout
 * SettingsScreen but factored out because there are five of them.
 */

private const val SETTINGS_SEARCH = "search"
private const val SETTINGS_AI = "ai"
private const val SETTINGS_READING = "reading"
private const val SETTINGS_WEBVIEWER = "webviewer"
private const val SETTINGS_APPEARANCE = "appearance"
private const val SETTINGS_MEDIA = "media"
private const val SETTINGS_LIBRARY = "library"
private const val SETTINGS_ADVANCED = "advanced"

private data class SettingsCategoryItem(
    val id: String,
    val emoji: String,
    val title: String,
    val description: String,
    val keywords: String
)

/**
 * Search-only index entry for an individual setting or settings section.
 * This deliberately contains navigation metadata only: it does not duplicate
 * or own any preference state, so searching Settings cannot change working
 * feature wiring. Selecting a result simply opens the category that already
 * owns the real control.
 */
private data class SettingsSearchItem(
    val title: String,
    val categoryId: String,
    val section: String,
    val keywords: String = ""
)

private val SETTINGS_SEARCH_INDEX = listOf(
    // Search & Retrieval
    SettingsSearchItem("Semantic Search", SETTINGS_SEARCH, "Semantic Search", "semantic vector meaning similarity search enable disable"),
    SettingsSearchItem("Search Scope", SETTINGS_SEARCH, "Search Scope", "scope first 20k second batch dual all articles chunks"),
    SettingsSearchItem("Dual scope search", SETTINGS_SEARCH, "Search Scope", "dual both batches 20k 22k all chunks"),
    SettingsSearchItem("Reranking", SETTINGS_SEARCH, "Reranking", "rerank cross encoder manual reranker results quality"),
    SettingsSearchItem("Search Results", SETTINGS_SEARCH, "Search Results", "results filters snippets chips ranking"),
    SettingsSearchItem("Live search", SETTINGS_ADVANCED, "Diagnostics", "search while typing submit keyboard diagnostic"),
    SettingsSearchItem("Cancel previous search", SETTINGS_ADVANCED, "Diagnostics", "cancel in flight previous query keystroke diagnostic"),
    SettingsSearchItem("Rerank on submit only", SETTINGS_ADVANCED, "Diagnostics", "reranker submit tap search button diagnostic"),
    SettingsSearchItem("Rerank % indicator", SETTINGS_ADVANCED, "Diagnostics", "progress percentage reranking indicator diagnostic"),
    SettingsSearchItem("Semantic % indicator", SETTINGS_ADVANCED, "Diagnostics", "semantic progress percentage indicator model diagnostic"),
    SettingsSearchItem("Search indicator style", SETTINGS_ADVANCED, "Diagnostics", "percentage hourglass book large progress spinner animation"),

    // AI & Models
    SettingsSearchItem("Embeddings & Model Management", SETTINGS_AI, "Embeddings & Model Management", "embedding model download build index model management"),
    SettingsSearchItem("Embedding model", SETTINGS_AI, "Embeddings & Model Management", "semantic embedding selector model"),
    SettingsSearchItem("Build embeddings", SETTINGS_AI, "Embeddings & Model Management", "embed index create embeddings"),
    SettingsSearchItem("Re-embed updated notes", SETTINGS_AI, "Embeddings & Model Management", "reembed changed notes update embeddings"),
    SettingsSearchItem("Clear embeddings", SETTINGS_AI, "Embeddings & Model Management", "delete remove embeddings rebuild"),
    SettingsSearchItem("Check for newer model", SETTINGS_AI, "Embeddings & Model Management", "model update automatic check newer"),
    SettingsSearchItem("T5 expansion", SETTINGS_AI, "T5", "t5 paraphrase query expansion download"),
    SettingsSearchItem("LLM Query Expansion", SETTINGS_AI, "LLM Query Expansion", "llm ai multi query expansion paraphrase"),
    SettingsSearchItem("On-device chat", SETTINGS_AI, "LLM & Model Management", "chat local llm model conversation"),
    SettingsSearchItem("Model management", SETTINGS_AI, "LLM & Model Management", "install delete download ai models"),

    // Reading
    SettingsSearchItem("Reading font size", SETTINGS_APPEARANCE, "Typography", "font text size article markdown html typography"),
    SettingsSearchItem("In-article highlighting", SETTINGS_READING, "Highlighting", "highlight query matches article reader"),
    SettingsSearchItem("Highlight mode", SETTINGS_READING, "Highlighting", "highlight style matches article"),
    SettingsSearchItem("Find-in-article button", SETTINGS_ADVANCED, "Diagnostics", "find article floating button search inside note diagnostic"),
    SettingsSearchItem("Semantic in-article search", SETTINGS_ADVANCED, "Diagnostics", "semantic find inside article keyword diagnostic"),
    SettingsSearchItem("Markdown reader", SETTINGS_READING, "Reading", "markdown article reader rendering"),
    SettingsSearchItem("HTML reader", SETTINGS_READING, "Reading", "html article reader rendering"),
    SettingsSearchItem("Scripture links", SETTINGS_READING, "Reading", "scripture jw bible links popup reader"),
    SettingsSearchItem("Scripture detection", SETTINGS_READING, "Bible & Scripture", "bible scripture references tappable amber offline nwt wol"),
    SettingsSearchItem("Smart styling on all documents", SETTINGS_READING, "Performance", "smart styling colorize numbers references percentages quoted all caps"),
    SettingsSearchItem("Swipe to switch tabs", SETTINGS_READING, "Performance", "markdown reader swipe previous next tabs"),

    // WebViewer
    SettingsSearchItem("WebViewer popup behavior", SETTINGS_WEBVIEWER, "Popup behavior", "floating popup window fullscreen maximize minimize resize move"),
    SettingsSearchItem("Floating link windows", SETTINGS_WEBVIEWER, "Popup behavior", "reuse same popup new popup per link multiple windows"),
    SettingsSearchItem("WebViewer tabs", SETTINGS_WEBVIEWER, "Tabs", "browser tabs persistent tabs orientation"),
    SettingsSearchItem("Save web pages", SETTINGS_WEBVIEWER, "Saving", "save offline html ask unsaved page autosave"),
    SettingsSearchItem("Ask to save unsaved web pages", SETTINGS_WEBVIEWER, "Saving", "not in library save prompt webviewer"),
    SettingsSearchItem("Duplicate detection", SETTINGS_WEBVIEWER, "Duplicate detection", "web saved library url title heading duplicate"),
    SettingsSearchItem("Web imports", SETTINGS_WEBVIEWER, "Saving", "import subfolder web clippings folder"),
    SettingsSearchItem("Web history", SETTINGS_WEBVIEWER, "History", "browser history clear web history"),
    SettingsSearchItem("PDF history", SETTINGS_WEBVIEWER, "History", "pdf history"),

    // Appearance
    SettingsSearchItem("Theme", SETTINGS_APPEARANCE, "Theme", "theme dark light colors 3d glass obsidian crystal"),
    SettingsSearchItem("Theme Creator", SETTINGS_APPEARANCE, "Theme Creator", "custom theme colors palette creator"),
    SettingsSearchItem("Typography", SETTINGS_APPEARANCE, "Typography", "font text typography size"),
    SettingsSearchItem("Motion & animations", SETTINGS_APPEARANCE, "Motion", "motion animation expressive ui transitions"),
    SettingsSearchItem("Home & Workspace", SETTINGS_APPEARANCE, "Home & Workspace", "home workspace recent searches layout scroll"),

    // Media
    SettingsSearchItem("Automatically extract video captions", SETTINGS_MEDIA, "Playback", "captions cc subtitles transcript video searchable"),
    SettingsSearchItem("Continuous play", SETTINGS_MEDIA, "Playback", "continuous autoplay next audio video queue"),
    SettingsSearchItem("Android Auto audio", SETTINGS_MEDIA, "Android Auto", "android auto car audio voice keyboard browse play pause next previous shuffle repeat"),
    SettingsSearchItem("Chromecast", SETTINGS_MEDIA, "Chromecast", "cast tv google cast media"),
    SettingsSearchItem("Playback", SETTINGS_MEDIA, "Playback", "audio video player queue repeat shuffle"),

    // Library
    SettingsSearchItem("Library folder", SETTINGS_LIBRARY, "Library", "change folder storage vault notes"),
    SettingsSearchItem("Re-index library", SETTINGS_LIBRARY, "Indexing", "index reindex scan notes files"),
    SettingsSearchItem("Backup & restore", SETTINGS_LIBRARY, "Backup & restore", "backup restore database settings embeddings"),
    SettingsSearchItem("Duplicate Detector", SETTINGS_LIBRARY, "Duplicates", "duplicate articles exact content copies"),

    // Advanced
    SettingsSearchItem("Memory", SETTINGS_ADVANCED, "Memory", "ram heap oom memory cleanup"),
    SettingsSearchItem("Auto-free memory", SETTINGS_ADVANCED, "Diagnostics", "free memory background unload models ram diagnostic"),
    SettingsSearchItem("Free memory now", SETTINGS_ADVANCED, "Memory", "manual memory cleanup unload"),
    SettingsSearchItem("Diagnostics", SETTINGS_ADVANCED, "Diagnostics", "debug performance diagnostics status"),
    SettingsSearchItem("Activity log", SETTINGS_ADVANCED, "Logs", "activity log events"),
    SettingsSearchItem("Crash logs", SETTINGS_ADVANCED, "Logs", "crash log errors logcat"),
)

@androidx.compose.runtime.Composable
private fun SettingsCategoryHub(
    selectedCategory: String?,
    onSelect: (String) -> Unit
) {
    val items = remember {
        listOf(
            SettingsCategoryItem(SETTINGS_SEARCH, "🔎", "Search & Retrieval",
                "Semantic Search · Reranking · Search Scope · Search Results",
                "semantic reranking reranker scope results keyword filters search chips"),
            SettingsCategoryItem(SETTINGS_AI, "🤖", "AI & Models",
                "Embeddings · T5 · LLM · Model Management",
                "ai models embeddings t5 llm chat rag download model management"),
            SettingsCategoryItem(SETTINGS_READING, "📖", "Reading",
                "Markdown · HTML · Scripture links · Highlighting",
                "reading markdown html scripture links highlighting smart styling tabs"),
            SettingsCategoryItem(SETTINGS_WEBVIEWER, "🌐", "WebViewer",
                "Popup behavior · Tabs · Saving · Duplicate detection",
                "webviewer browser popup tabs saving autosave duplicate history imports"),
            SettingsCategoryItem(SETTINGS_APPEARANCE, "🎨", "Appearance",
                "Theme · Theme Creator · Typography · Motion",
                "appearance theme creator typography font motion animation contrast home workspace"),
            SettingsCategoryItem(SETTINGS_MEDIA, "🎬", "Media",
                "Playback · Chromecast · Continuous play",
                "media playback chromecast cast continuous play audio video queue"),
            SettingsCategoryItem(SETTINGS_LIBRARY, "💾", "Library",
                "Indexing · Backup · Duplicates",
                "library indexing reindex backup restore duplicates folder"),
            SettingsCategoryItem(SETTINGS_ADVANCED, "⚙", "Advanced",
                "Memory · Diagnostics · Logs",
                "advanced memory ram diagnostics logs crash performance"),
        )
    }
    val selected = items.firstOrNull { it.id == selectedCategory }
    if (selected != null) {
        Text("${selected.emoji} ${selected.title}", fontSize = 20.sp, fontWeight = FontWeight.Bold)
        Spacer(Modifier.height(4.dp))
        Text(selected.description, fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
        return
    }

    var query by remember { mutableStateOf("") }
    Text("Settings", fontSize = 22.sp, fontWeight = FontWeight.Bold)
    Spacer(Modifier.height(6.dp))
    Text(
        "Everything is still here — settings are grouped by what they control.",
        fontSize = 12.sp,
        color = MaterialTheme.colorScheme.onSurfaceVariant
    )
    Spacer(Modifier.height(12.dp))
    OutlinedTextField(
        value = query,
        onValueChange = { query = it },
        modifier = Modifier.fillMaxWidth(),
        singleLine = true,
        placeholder = { Text("Search settings…") },
        leadingIcon = { Icon(Icons.Default.Search, contentDescription = null) },
        trailingIcon = {
            if (query.isNotEmpty()) {
                IconButton(onClick = { query = "" }) {
                    Icon(Icons.Default.Close, contentDescription = "Clear settings search")
                }
            }
        }
    )
    Spacer(Modifier.height(12.dp))
    val normalized = query.trim().lowercase()

    if (normalized.isNotBlank()) {
        val categoryById = remember(items) { items.associateBy { it.id } }
        val directMatches = remember(normalized) {
            SETTINGS_SEARCH_INDEX.filter { entry ->
                entry.title.lowercase().contains(normalized) ||
                    entry.section.lowercase().contains(normalized) ||
                    entry.keywords.lowercase().contains(normalized)
            }
        }
        val categoryMatches = items.filter { item ->
            item.title.lowercase().contains(normalized) ||
                item.description.lowercase().contains(normalized) ||
                item.keywords.lowercase().contains(normalized)
        }

        if (directMatches.isEmpty() && categoryMatches.isEmpty()) {
            androidx.compose.material3.Surface(
                modifier = Modifier.fillMaxWidth(),
                shape = androidx.compose.foundation.shape.RoundedCornerShape(16.dp),
                color = MaterialTheme.colorScheme.surfaceVariant
            ) {
                Column(Modifier.padding(16.dp)) {
                    Text("No setting found", fontWeight = FontWeight.SemiBold)
                    Spacer(Modifier.height(4.dp))
                    Text(
                        "Try another word such as Android Auto, popup, captions, memory, theme, reranker, backup, or Chromecast.",
                        fontSize = 12.sp,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }
        } else {
            if (directMatches.isNotEmpty()) {
                Text(
                    "${directMatches.size} matching setting${if (directMatches.size == 1) "" else "s"}",
                    fontSize = 12.sp,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
                Spacer(Modifier.height(4.dp))
                directMatches.forEach { entry ->
                    val category = categoryById[entry.categoryId]
                    androidx.compose.material3.Surface(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(vertical = 4.dp)
                            .clickable { onSelect(entry.categoryId) },
                        shape = androidx.compose.foundation.shape.RoundedCornerShape(14.dp),
                        tonalElevation = 2.dp,
                        color = MaterialTheme.colorScheme.surfaceVariant
                    ) {
                        Row(
                            Modifier.padding(horizontal = 14.dp, vertical = 12.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(category?.emoji ?: "⚙", fontSize = 21.sp)
                            Spacer(Modifier.width(12.dp))
                            Column(Modifier.weight(1f)) {
                                Text(entry.title, fontSize = 15.sp, fontWeight = FontWeight.SemiBold)
                                Text(
                                    "${category?.title ?: "Settings"}  ›  ${entry.section}",
                                    fontSize = 11.sp,
                                    color = MaterialTheme.colorScheme.primary
                                )
                            }
                            Text("›", fontSize = 22.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        }
                    }
                }
            }

            // Keep category-level matches available for broad searches such as
            // "media" or "appearance", but individual setting matches are shown
            // first so users can find a concrete control instead of only a group.
            if (categoryMatches.isNotEmpty()) {
                if (directMatches.isNotEmpty()) Spacer(Modifier.height(10.dp))
                Text("Categories", fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                Spacer(Modifier.height(4.dp))
                categoryMatches.forEach { item ->
                    androidx.compose.material3.Surface(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(vertical = 4.dp)
                            .clickable { onSelect(item.id) },
                        shape = androidx.compose.foundation.shape.RoundedCornerShape(14.dp),
                        tonalElevation = 1.dp,
                        color = MaterialTheme.colorScheme.surfaceVariant
                    ) {
                        Row(
                            Modifier.padding(horizontal = 14.dp, vertical = 11.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(item.emoji, fontSize = 21.sp)
                            Spacer(Modifier.width(12.dp))
                            Column(Modifier.weight(1f)) {
                                Text(item.title, fontSize = 14.sp, fontWeight = FontWeight.SemiBold)
                                Text(item.description, fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                            }
                            Text("›", fontSize = 22.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        }
                    }
                }
            }
        }
        return
    }

    // No query: show the normal eight-category Settings hub.
    items.forEach { item ->
        androidx.compose.material3.Surface(
            modifier = Modifier
                .fillMaxWidth()
                .padding(vertical = 5.dp)
                .clickable { onSelect(item.id) },
            shape = androidx.compose.foundation.shape.RoundedCornerShape(16.dp),
            tonalElevation = 2.dp,
            color = MaterialTheme.colorScheme.surfaceVariant
        ) {
            Row(
                Modifier.padding(horizontal = 16.dp, vertical = 14.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(item.emoji, fontSize = 24.sp)
                Spacer(Modifier.width(14.dp))
                Column(Modifier.weight(1f)) {
                    Text(item.title, fontSize = 16.sp, fontWeight = FontWeight.SemiBold)
                    Text(item.description, fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
                Text("›", fontSize = 24.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
        }
    }
}

@androidx.compose.runtime.Composable
private fun SettingsSubheading(title: String) {
    Text(title, fontSize = 13.sp, fontWeight = FontWeight.SemiBold, color = MaterialTheme.colorScheme.primary)
    Spacer(Modifier.height(8.dp))
}

@androidx.compose.runtime.Composable
private fun ReadingHighlightingSection(vm: com.tebogo.markvault.AppViewModel) {
    val highlight by vm.articleHighlightEnabled.collectAsStateWithLifecycle()
    DiagnosticToggle(
        title = "In-article highlighting",
        subtitle = "Highlight query matches inside opened articles. Turn this off to disable the article text-node highlighting pass.",
        checked = highlight,
        onChange = { vm.setArticleHighlightEnabled(it) }
    )
    if (highlight) {
        Spacer(Modifier.height(10.dp))
        HighlightModePicker(vm)
    }
}

@androidx.compose.runtime.Composable
private fun DuplicateDetectorSection(nav: androidx.navigation.NavController) {
    androidx.compose.material3.Surface(
        color = MaterialTheme.colorScheme.surfaceVariant,
        shape = androidx.compose.foundation.shape.RoundedCornerShape(10.dp),
        modifier = Modifier.fillMaxWidth().clickable { nav.navigate("duplicates") }
    ) {
        Row(Modifier.padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
            Text("🔍", fontSize = 24.sp)
            Spacer(Modifier.width(12.dp))
            Column(Modifier.weight(1f)) {
                Text("Duplicate Detector", fontSize = 14.sp, fontWeight = FontWeight.SemiBold)
                Text(
                    "Scan your vault for exact-content duplicate articles. Compare side-by-side and safely remove copies.",
                    fontSize = 11.sp,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    lineHeight = 15.sp
                )
            }
            Text("▶", fontSize = 14.sp)
        }
    }
}

@androidx.compose.runtime.Composable
private fun MediaSettingsSection(vm: com.tebogo.markvault.AppViewModel) {
    Text("🎬 Media", fontSize = 16.sp, fontWeight = FontWeight.Bold)
    Spacer(Modifier.height(6.dp))
    Text(
        "Playback controls apply to the same player used for local audio/video and Chromecast.",
        fontSize = 12.sp,
        color = MaterialTheme.colorScheme.onSurfaceVariant
    )
    Spacer(Modifier.height(16.dp))
    Text("Playback", fontSize = 13.sp, fontWeight = FontWeight.SemiBold, color = MaterialTheme.colorScheme.primary)
    Spacer(Modifier.height(8.dp))

    // v5.4.288cc — Caption extraction is independent of normal CC display.
    // CC is enabled by default whenever the player has a supported text track;
    // this switch controls only whether the words are cached/searchable.
    val autoCaptions by vm.autoExtractVideoCaptions.collectAsStateWithLifecycle()
    DiagnosticToggle(
        title = "💬 Automatically extract video captions",
        subtitle = "ON (default) = when a played video has an extractable JW.org caption track, cache the complete transcript immediately. If only runtime CC is available, save the captions as they play. Saved transcript text becomes searchable and is linked back to the video and timestamp. OFF = CC can still display, but MarkVault will not build new transcripts.",
        checked = autoCaptions,
        onChange = { vm.setAutoExtractVideoCaptions(it) }
    )
    Spacer(Modifier.height(16.dp))

    // v5.4.255cc — Continuous Play toggle.
    androidx.compose.foundation.layout.Spacer(
        androidx.compose.ui.Modifier.height(16.dp)
    )
    Text(
        "\uD83C\uDFB5 Continuous Play",
        fontWeight = androidx.compose.ui.text.font.FontWeight.Bold,
        fontSize = 14.sp
    )
    Text(
        "When on, tapping media from a browse or search list queues the rest of that list too, so playback continues automatically \u2014 next/previous, shuffle, and repeat all work off this queue, including while casting.",
        fontSize = 12.sp,
        color = androidx.compose.material3.MaterialTheme.colorScheme.onSurfaceVariant,
        lineHeight = 16.sp
    )
    androidx.compose.foundation.layout.Spacer(
        androidx.compose.ui.Modifier.height(10.dp)
    )
    val continuousPlay by vm.continuousPlayEnabled.collectAsStateWithLifecycle()
    androidx.compose.foundation.layout.Row(
        modifier = androidx.compose.ui.Modifier.fillMaxWidth(),
        horizontalArrangement = androidx.compose.foundation.layout.Arrangement.spacedBy(8.dp)
    ) {
        androidx.compose.material3.FilterChip(
            selected = continuousPlay,
            onClick = { vm.setContinuousPlayEnabled(true) },
            label = { Text("\u25B6\uFE0F  On") },
            modifier = androidx.compose.ui.Modifier.weight(1f)
        )
        androidx.compose.material3.FilterChip(
            selected = !continuousPlay,
            onClick = { vm.setContinuousPlayEnabled(false) },
            label = { Text("\u23F9\uFE0F  Off") },
            modifier = androidx.compose.ui.Modifier.weight(1f)
        )
    }


    Spacer(Modifier.height(20.dp))
    Text("Android Auto", fontSize = 13.sp, fontWeight = FontWeight.SemiBold, color = MaterialTheme.colorScheme.primary)
    Spacer(Modifier.height(8.dp))
    val androidAutoEnabled by vm.androidAutoEnabled.collectAsStateWithLifecycle()
    DiagnosticToggle(
        title = "🚘 Android Auto audio",
        subtitle = "Expose the complete JW.org Audio folder to Android Auto for browsing and keyboard/voice search. Playback uses MarkVault's same queue with play, pause, next, previous, shuffle and repeat. Video is never exposed to the driving interface.",
        checked = androidAutoEnabled,
        onChange = { vm.setAndroidAutoEnabled(it) }
    )

    Spacer(Modifier.height(20.dp))
    Text("Chromecast", fontSize = 13.sp, fontWeight = FontWeight.SemiBold, color = MaterialTheme.colorScheme.primary)
    Spacer(Modifier.height(6.dp))
    Text(
        "Casting uses the same playback queue and controls. Connect or disconnect with the Cast button in the media player.",
        fontSize = 12.sp,
        color = MaterialTheme.colorScheme.onSurfaceVariant
    )
}

@androidx.compose.runtime.Composable
private fun SearchScopeSettingsSection(vm: com.tebogo.markvault.AppViewModel) {
    val semanticScope by vm.semanticScope.collectAsStateWithLifecycle()
    val embeddingCount by vm.embeddingCount.collectAsStateWithLifecycle()
    var noteCount by remember { mutableStateOf(0) }
    LaunchedEffect(embeddingCount) { noteCount = vm.distinctEmbeddedNoteCount() }
    val secondCount = maxOf(0, noteCount - 20_000)
    val secondLabel = when {
        secondCount >= 1_000 -> "📚 2nd ${secondCount / 1_000}k"
        secondCount > 0 -> "📚 2nd $secondCount"
        else -> "📚 2nd batch"
    }
    Text(
        "Choose which article scope semantic search reads. Dual/full coverage is preserved; the second scope contains everything after the first 20k.",
        fontSize = 12.sp,
        color = MaterialTheme.colorScheme.onSurfaceVariant
    )
    Spacer(Modifier.height(8.dp))
    Row(
        horizontalArrangement = androidx.compose.foundation.layout.Arrangement.spacedBy(8.dp),
        modifier = Modifier.fillMaxWidth()
    ) {
        listOf(
            "first20k" to "📚 1st 20k",
            "second20k" to secondLabel,
            "all" to "📚 All notes"
        ).forEach { (mode, label) ->
            androidx.compose.material3.FilterChip(
                selected = semanticScope == mode,
                onClick = { vm.setSemanticScope(mode) },
                label = { Text(label, fontSize = 12.sp) },
                modifier = Modifier.weight(1f)
            )
        }
    }
}

@androidx.compose.runtime.Composable
private fun AdvancedLogsSection(nav: androidx.navigation.NavController) {
    OutlinedButton(onClick = { nav.navigate("activity_log") }, modifier = Modifier.fillMaxWidth()) {
        Text("📋 Open activity log")
    }
    Spacer(Modifier.height(8.dp))
    OutlinedButton(onClick = { nav.navigate("crash_logs") }, modifier = Modifier.fillMaxWidth()) {
        Text("🐞 Open crash logs")
    }
}

@androidx.compose.runtime.Composable
private fun SearchChipToggleRow(
    title: String,
    description: String,
    checked: Boolean,
    onCheckedChange: (Boolean) -> Unit
) {
    androidx.compose.foundation.layout.Row(
        androidx.compose.ui.Modifier.fillMaxWidth(),
        verticalAlignment = androidx.compose.ui.Alignment.CenterVertically
    ) {
        androidx.compose.foundation.layout.Column(androidx.compose.ui.Modifier.weight(1f)) {
            androidx.compose.material3.Text(
                title,
                fontSize = 14.sp,
                fontWeight = androidx.compose.ui.text.font.FontWeight.Medium
            )
            androidx.compose.material3.Text(
                description,
                fontSize = 11.sp,
                color = androidx.compose.material3.MaterialTheme.colorScheme.onSurfaceVariant
            )
        }
        androidx.compose.foundation.layout.Spacer(androidx.compose.ui.Modifier.width(12.dp))
        androidx.compose.material3.Switch(
            checked = checked,
            onCheckedChange = onCheckedChange
        )
    }
}
