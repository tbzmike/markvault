package com.tebogo.markvault.ui

import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.Button
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Slider
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.navigation.NavController
import com.tebogo.markvault.AppViewModel

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SettingsScreen(vm: AppViewModel, nav: NavController) {
    val libraryUri by vm.libraryUri.collectAsStateWithLifecycle()
    val notes by vm.notes.collectAsStateWithLifecycle()
    val progress by vm.progress.collectAsStateWithLifecycle()
    val fontScale by vm.fontScale.collectAsStateWithLifecycle()

    val picker = rememberLauncherForActivityResult(
        ActivityResultContracts.OpenDocumentTree()
    ) { uri ->
        if (uri != null) vm.setLibrary(uri)
    }

    Scaffold(
        topBar = { TopAppBar(title = { Text("\u2699\uFE0F Settings") }) },
        bottomBar = {
            MarkVaultBottomBar(
                nav = nav, vm = vm,
                extraActions = {
                    IconButton(onClick = { nav.navigate("search") }) {
                        Icon(Icons.Default.Search, contentDescription = "Search library")
                    }
                }
            )
        }
    ) { pad ->
        Column(
            Modifier
                .padding(pad)
                .fillMaxSize()
                .verticalScroll(rememberScrollState())
                .padding(16.dp)
        ) {
            Text("\uD83D\uDCDA Library", fontWeight = FontWeight.Bold, fontSize = 16.sp)
            Spacer(Modifier.height(8.dp))
            val mdCount = remember(notes) { notes.count { it.fileType != "pdf" } }
            val pdfCount = remember(notes) { notes.count { it.fileType == "pdf" } }
            Text(
                buildString {
                    append("Indexed: ${notes.size} files")
                    if (pdfCount > 0) append("  (\uD83D\uDCC4 $mdCount md · \uD83D\uDCD5 $pdfCount pdf)")
                },
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                fontSize = 13.sp
            )
            if (progress.running) {
                Spacer(Modifier.height(8.dp))
                LinearProgressIndicator(Modifier.fillMaxWidth())
                Text(
                    "\u23F3 ${progress.phase} ${progress.done} / ${progress.total}",
                    fontSize = 12.sp,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
            Spacer(Modifier.height(12.dp))
            Row {
                Button(
                    onClick = { vm.reindex() },
                    enabled = libraryUri != null && !progress.running
                ) { Text("\u21BB  Re-index") }
                Spacer(Modifier.width(12.dp))
                OutlinedButton(
                    onClick = { picker.launch(null) },
                    enabled = !progress.running
                ) { Text("\uD83D\uDCC1 Change folder") }
            }

            Spacer(Modifier.height(28.dp))
            Text("\uD83D\uDD20 Reading font size", fontWeight = FontWeight.Bold, fontSize = 16.sp)
            Slider(
                value = fontScale,
                onValueChange = { vm.setFontScale(it) },
                valueRange = 0.7f..2.0f
            )
            Text("Sample text at current size", fontSize = (16f * fontScale).sp)

            Spacer(Modifier.height(28.dp))
            Text("\uD83C\uDF10 Web imports", fontWeight = FontWeight.Bold, fontSize = 16.sp)
            Spacer(Modifier.height(6.dp))
            Text(
                "When you share a web page to MarkVault, the page is rendered, converted to " +
                    "markdown, and saved to this subfolder of your library. Leave blank to save " +
                    "directly to the library root.",
                fontSize = 12.sp,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
            Spacer(Modifier.height(10.dp))
            val importsSubfolder by vm.importsSubfolder.collectAsStateWithLifecycle()
            var subfolderText by remember(importsSubfolder) {
                mutableStateOf(importsSubfolder)
            }
            OutlinedTextField(
                value = subfolderText,
                onValueChange = { subfolderText = it.filter { ch -> ch != '/' && ch != '\\' } },
                singleLine = true,
                modifier = Modifier.fillMaxWidth(),
                placeholder = { Text("e.g. Web Clippings") },
                label = { Text("Import subfolder") }
            )
            Spacer(Modifier.height(8.dp))
            Row {
                Button(
                    onClick = { vm.setImportsSubfolder(subfolderText.trim()) },
                    enabled = subfolderText != importsSubfolder
                ) { Text("Save folder name") }
                Spacer(Modifier.width(12.dp))
                OutlinedButton(onClick = { picker.launch(null) }) {
                    Text("\uD83D\uDD13 Re-grant library access")
                }
            }
            Spacer(Modifier.height(4.dp))
            Text(
                "If web imports fail with a read-only error, tap " +
                    "\u201CRe-grant library access\u201D and pick the same library folder again \u2014 " +
                    "this upgrades read-only permission to read+write.",
                fontSize = 11.sp,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )

            Spacer(Modifier.height(28.dp))
            Text("\u26A1 Performance", fontWeight = FontWeight.Bold, fontSize = 16.sp)
            Spacer(Modifier.height(6.dp))
            Text(
                "Heavy visual features are off by default for snappy scrolling on every " +
                    "device. If you're on a higher-end phone, switch them on for the full " +
                    "experience.",
                fontSize = 12.sp,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
            Spacer(Modifier.height(14.dp))

            // ── Smart styling on all documents ──
            val smartStylingAllDocs by vm.smartStylingAllDocs.collectAsStateWithLifecycle()
            Row(
                Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column(Modifier.weight(1f)) {
                    Text(
                        "\uD83C\uDFA8 Smart styling on all documents",
                        fontSize = 14.sp, fontWeight = FontWeight.Medium
                    )
                    Text(
                        "Auto-colourize numbers, references, percentages, quoted phrases " +
                            "and ALL-CAPS terms even in very long articles. May make " +
                            "scrolling stutter on 60,000+ character files.",
                        fontSize = 11.sp,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
                Spacer(Modifier.width(12.dp))
                Switch(
                    checked = smartStylingAllDocs,
                    onCheckedChange = { vm.setSmartStylingAllDocs(it) }
                )
            }

            Spacer(Modifier.height(18.dp))

            // ── Swipe to switch tabs ──
            val swipeSwitchTabs by vm.swipeSwitchTabs.collectAsStateWithLifecycle()
            Row(
                Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column(Modifier.weight(1f)) {
                    Text(
                        "\uD83D\uDC48\uD83D\uDC49 Swipe to switch tabs",
                        fontSize = 14.sp, fontWeight = FontWeight.Medium
                    )
                    Text(
                        "Horizontal swipe in the markdown reader jumps to the previous / " +
                            "next open tab. Adds touch-event interception that can mildly " +
                            "slow scrolling. Toolbar \u2190 \u2192 buttons are always available.",
                        fontSize = 11.sp,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
                Spacer(Modifier.width(12.dp))
                Switch(
                    checked = swipeSwitchTabs,
                    onCheckedChange = { vm.setSwipeSwitchTabs(it) }
                )
            }

            Spacer(Modifier.height(28.dp))
            Text("\uD83C\uDFA8 Appearance", fontWeight = FontWeight.Bold, fontSize = 16.sp)
            Spacer(Modifier.height(6.dp))
            Text(
                "Pick the theme that drives both the article viewer and the app chrome.",
                fontSize = 12.sp,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
            Spacer(Modifier.height(10.dp))
            var themePickerOpen by remember { mutableStateOf(false) }
            val currentTheme by vm.theme.collectAsStateWithLifecycle()
            androidx.compose.material3.OutlinedButton(
                onClick = { themePickerOpen = true },
                modifier = Modifier.fillMaxWidth()
            ) {
                val label = when (currentTheme) {
                    "black"             -> "\u26AB AMOLED black"
                    "sepia"             -> "\uD83D\uDCDC Sepia"
                    "light_grey"        -> "\uD83E\uDEA8 Light grey"
                    "light"             -> "\u2600\uFE0F Light"
                    "hicontrast-dark"   -> "\u26A1 High-contrast dark"
                    "hicontrast-light"  -> "\u26A1 High-contrast light"
                    "ocean"             -> "\uD83C\uDF0A Ocean"
                    "forest"            -> "\uD83C\uDF32 Forest"
                    "cream"             -> "\uD83E\uDD5B Cream"
                    else                -> "\uD83C\uDF11 Dark (grey)"
                }
                Text("Theme: $label")
            }
            if (themePickerOpen) {
                ThemePickerDialog(vm, onDismiss = { themePickerOpen = false })
            }

            Spacer(Modifier.height(18.dp))
            // ── Text contrast slider ──
            val contrast by vm.textContrast.collectAsStateWithLifecycle()
            Text(
                "\uD83D\uDD06 Text contrast \u00B7 ${"%.2f".format(contrast)}\u00D7",
                fontSize = 14.sp, fontWeight = FontWeight.Medium
            )
            Text(
                "Boost foreground/background contrast for easier reading, especially in " +
                    "light and sepia themes. 1.0\u00D7 = default, 2.0\u00D7 = maximum.",
                fontSize = 11.sp,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
            androidx.compose.material3.Slider(
                value = contrast,
                onValueChange = { vm.setTextContrast(it) },
                valueRange = 1.0f..2.0f,
                steps = 19   // 0.05 steps
            )

            Spacer(Modifier.height(28.dp))
            Text("\uD83C\uDF10 In-app browser", fontWeight = FontWeight.Bold, fontSize = 16.sp)
            Spacer(Modifier.height(6.dp))
            Text(
                "Settings for the WebView that opens jw.org scriptures.",
                fontSize = 12.sp,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
            Spacer(Modifier.height(10.dp))
            androidx.compose.material3.OutlinedButton(
                onClick = { nav.navigate("webHistory") },
                modifier = Modifier.fillMaxWidth()
            ) { Text("\uD83D\uDD52 Open web history") }
            Spacer(Modifier.height(8.dp))
            androidx.compose.material3.OutlinedButton(
                onClick = { nav.navigate("pdfHistory") },
                modifier = Modifier.fillMaxWidth()
            ) { Text("\uD83D\uDCDC Open PDF history") }
            Spacer(Modifier.height(8.dp))
            var confirmClearWeb by remember { mutableStateOf(false) }
            androidx.compose.material3.OutlinedButton(
                onClick = { confirmClearWeb = true },
                modifier = Modifier.fillMaxWidth()
            ) { Text("\uD83E\uDDF9 Clear all web history") }
            if (confirmClearWeb) {
                androidx.compose.material3.AlertDialog(
                    onDismissRequest = { confirmClearWeb = false },
                    title = { Text("Clear web history?") },
                    text = { Text("This removes every web-history entry. Browser data on the device is not touched.") },
                    confirmButton = {
                        androidx.compose.material3.Button(onClick = {
                            vm.clearWebHistory()
                            confirmClearWeb = false
                        }) { Text("Clear") }
                    },
                    dismissButton = {
                        androidx.compose.material3.TextButton(onClick = { confirmClearWeb = false }) { Text("Cancel") }
                    }
                )
            }

            Spacer(Modifier.height(28.dp))
            // ── v4.8 — Semantic search foundation ──────────────────────────
            // Three-step user journey:
            //   (1) Download the .tflite model (~25MB, one-time)
            //   (2) Build embeddings for every note in the library
            //   (3) Search and ranking integration arrives next iteration
            SemanticSearchSection(vm)
            Spacer(Modifier.height(28.dp))
            HomeScreenSection(vm)
            Spacer(Modifier.height(28.dp))
            // ── v4.23.0 — Reranker (cross-encoder) ────────────────────────
            // Optional second-stage ranker that runs after semantic search
            // to surface the truly relevant articles. 33 MB model.
            RerankerSection(vm)
            Spacer(Modifier.height(28.dp))
            // ── v4.21.0 — On-device chat (RAG) ─────────────────────────────
            // Settings only for now: install/delete the chat LLM, plus
            // three behaviour toggles to revisit later. Chat screen UI
            // lands in v4.22.x.
            OnDeviceChatSection(vm)
            Spacer(Modifier.height(28.dp))
            Text("\u2139\uFE0F About", fontWeight = FontWeight.Bold, fontSize = 16.sp)
            Spacer(Modifier.height(6.dp))
            Text(
                "MarkVault ${com.tebogo.markvault.BuildConfig.VERSION_NAME}\n" +
                    "\u2022 Offline Markdown + PDF knowledge system.\n" +
                    "\u2022 In-app jw.org browser with history.\n" +
                    "\u2022 Auto-grouped topics, dashboard, concept search.\n" +
                    "\u2022 On-device semantic search with switchable models.\n" +
                    "\u2022 Your notes never leave this phone. \uD83D\uDCDA",
                fontSize = 13.sp,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
        }
    }
}

/**
 * Settings UI for the semantic-search foundation. Three controls:
 *
 *   • Status line — "Model not downloaded" / "Downloading…X%" / "Model ready"
 *   • Action button — Download model OR Build embeddings (whichever's next)
 *   • Secondary action — Clear embeddings (only shown when there are any)
 *
 * Kept intentionally self-contained at the bottom of SettingsScreen.kt so it
 * can be moved into its own file later without ceremony. The composable does
 * not depend on any other Settings helpers, only on AppViewModel's public
 * state flows ([modelAvailable], [modelDownloadProgress], [embeddingCount],
 * [embeddingProgress]) and four methods.
 */
@androidx.compose.runtime.Composable
private fun SemanticSearchSection(vm: com.tebogo.markvault.AppViewModel) {
    val modelReady by vm.modelAvailable.collectAsStateWithLifecycle()
    val downloadProgress by vm.modelDownloadProgress.collectAsStateWithLifecycle()
    val embedCount by vm.embeddingCount.collectAsStateWithLifecycle()
    val embedProgress by vm.embeddingProgress.collectAsStateWithLifecycle()
    // v4.9.0 — toggle / active-model / update-check state
    val semanticOn by vm.semanticEnabled.collectAsStateWithLifecycle()
    val autoCheck by vm.autoCheckModelUpdates.collectAsStateWithLifecycle()
    val activeId by vm.activeModelId.collectAsStateWithLifecycle()
    val updateStatus by vm.modelUpdateStatus.collectAsStateWithLifecycle()
    val activeDescriptor = vm.availableModels.firstOrNull { it.id == activeId }
        ?: vm.availableModels.firstOrNull()

    Text(
        "\uD83E\uDDE0 Semantic search (experimental)",
        fontWeight = androidx.compose.ui.text.font.FontWeight.Bold,
        fontSize = 16.sp
    )
    androidx.compose.foundation.layout.Spacer(
        androidx.compose.ui.Modifier.height(6.dp)
    )
    Text(
        "On-device meaning-based ranking. Downloads a ~25MB language model once, " +
            "then embeds every note in your library so similar phrasings match even " +
            "when wording differs. All processing stays on this phone.",
        fontSize = 13.sp,
        color = androidx.compose.material3.MaterialTheme.colorScheme.onSurfaceVariant,
        lineHeight = 18.sp
    )
    androidx.compose.foundation.layout.Spacer(
        androidx.compose.ui.Modifier.height(14.dp)
    )

    // ── v4.9.0 — Master on/off switch ───────────────────────────────────────
    androidx.compose.foundation.layout.Row(
        modifier = androidx.compose.ui.Modifier.fillMaxWidth(),
        verticalAlignment = androidx.compose.ui.Alignment.CenterVertically
    ) {
        androidx.compose.foundation.layout.Column(
            androidx.compose.ui.Modifier.weight(1f)
        ) {
            Text(
                "Use semantic search",
                fontWeight = androidx.compose.ui.text.font.FontWeight.Medium,
                fontSize = 14.sp
            )
            Text(
                "When off, results use only keyword + synonym + fuzzy matching.",
                fontSize = 11.sp,
                color = androidx.compose.material3.MaterialTheme.colorScheme.onSurfaceVariant,
                lineHeight = 15.sp
            )
        }
        androidx.compose.material3.Switch(
            checked = semanticOn,
            onCheckedChange = { vm.setSemanticEnabled(it) }
        )
    }
    androidx.compose.foundation.layout.Spacer(
        androidx.compose.ui.Modifier.height(14.dp)
    )

    // ── v4.9.1 — Models picker ──────────────────────────────────────────────
    // Lists every catalog entry. The currently-active one is highlighted; any
    // other enabled entry is tappable to switch. Disabled entries (e.g.
    // upcoming MiniLM) are rendered greyed out with a "coming soon" tag.
    Text(
        "Models",
        fontWeight = androidx.compose.ui.text.font.FontWeight.Medium,
        fontSize = 14.sp
    )
    androidx.compose.foundation.layout.Spacer(
        androidx.compose.ui.Modifier.height(6.dp)
    )
    for (model in vm.availableModels) {
        val isActive = model.id == activeId
        val isClickable = model.enabled && !isActive
        val rowModifier = if (isClickable) {
            androidx.compose.ui.Modifier
                .fillMaxWidth()
                .clickable(onClick = { vm.setActiveModelId(model.id) })
                .padding(vertical = 6.dp)
        } else {
            androidx.compose.ui.Modifier
                .fillMaxWidth()
                .padding(vertical = 6.dp)
        }
        androidx.compose.foundation.layout.Row(
            modifier = rowModifier,
            verticalAlignment = androidx.compose.ui.Alignment.CenterVertically
        ) {
            // Radio-like marker
            Text(
                when {
                    isActive -> "\uD83D\uDFE2"           // green dot for active
                    !model.enabled -> "\u23F3"           // hourglass for coming-soon
                    else -> "\u26AA"                       // white circle for selectable
                },
                fontSize = 14.sp
            )
            androidx.compose.foundation.layout.Spacer(
                androidx.compose.ui.Modifier.width(10.dp)
            )
            androidx.compose.foundation.layout.Column(
                androidx.compose.ui.Modifier.weight(1f)
            ) {
                val titleColor = when {
                    isActive -> androidx.compose.material3.MaterialTheme.colorScheme.primary
                    !model.enabled -> androidx.compose.material3.MaterialTheme.colorScheme.onSurfaceVariant
                    else -> androidx.compose.material3.MaterialTheme.colorScheme.onSurface
                }
                Text(
                    if (model.enabled) model.displayName
                    else "${model.displayName}  \u2022  coming soon",
                    fontSize = 13.sp,
                    fontWeight = if (isActive) androidx.compose.ui.text.font.FontWeight.SemiBold
                    else androidx.compose.ui.text.font.FontWeight.Normal,
                    color = titleColor
                )
                Text(
                    model.description,
                    fontSize = 11.sp,
                    color = androidx.compose.material3.MaterialTheme.colorScheme.onSurfaceVariant,
                    lineHeight = 15.sp
                )
            }
        }
    }
    androidx.compose.foundation.layout.Spacer(
        androidx.compose.ui.Modifier.height(10.dp)
    )

    // ── v4.9.0 — Check for newer model ──────────────────────────────────────
    androidx.compose.material3.OutlinedButton(
        onClick = { vm.checkForModelUpdates() },
        modifier = androidx.compose.ui.Modifier.fillMaxWidth()
    ) {
        Text("Check for newer model")
    }
    if (!updateStatus.isNullOrBlank()) {
        androidx.compose.foundation.layout.Spacer(
            androidx.compose.ui.Modifier.height(4.dp)
        )
        Text(
            updateStatus ?: "",
            fontSize = 12.sp,
            color = androidx.compose.material3.MaterialTheme.colorScheme.primary
        )
    }
    androidx.compose.foundation.layout.Spacer(
        androidx.compose.ui.Modifier.height(8.dp)
    )

    // Auto-check on launch
    androidx.compose.foundation.layout.Row(
        modifier = androidx.compose.ui.Modifier.fillMaxWidth(),
        verticalAlignment = androidx.compose.ui.Alignment.CenterVertically
    ) {
        androidx.compose.foundation.layout.Column(
            androidx.compose.ui.Modifier.weight(1f)
        ) {
            Text(
                "Check automatically on launch",
                fontWeight = androidx.compose.ui.text.font.FontWeight.Medium,
                fontSize = 14.sp
            )
            Text(
                "Quietly looks for newer models when the app starts.",
                fontSize = 11.sp,
                color = androidx.compose.material3.MaterialTheme.colorScheme.onSurfaceVariant,
                lineHeight = 15.sp
            )
        }
        androidx.compose.material3.Switch(
            checked = autoCheck,
            onCheckedChange = { vm.setAutoCheckModelUpdates(it) }
        )
    }
    androidx.compose.foundation.layout.Spacer(
        androidx.compose.ui.Modifier.height(14.dp)
    )

    // ── Status line ─────────────────────────────────────────────────────
    val statusLine = when {
        downloadProgress != null -> {
            val pct = ((downloadProgress ?: 0f) * 100).toInt()
            "\u23F3 Downloading model\u2026 $pct%"
        }
        embedProgress != null -> {
            val (done, total) = embedProgress!!
            // v4.8.1 — (0, 0) is the "preparing" sentinel emitted before the
            // COUNT query has finished. Avoid the "0 / 0 (0%)" weirdness.
            if (total == 0) "\u23F3 Preparing\u2026 (counting notes)"
            else {
                val pct = (done * 100 / total)
                "\u23F3 Embedding library\u2026 $done / $total ($pct%)"
            }
        }
        !modelReady -> "\u26AB Model not downloaded"
        embedCount == 0 -> "\u2705 Model ready \u2014 no embeddings built yet"
        else -> "\u2705 Model ready \u2014 $embedCount note${if (embedCount == 1) "" else "s"} embedded"
    }
    Text(
        statusLine,
        fontSize = 13.sp,
        fontWeight = androidx.compose.ui.text.font.FontWeight.Medium,
        color = androidx.compose.material3.MaterialTheme.colorScheme.primary
    )

    androidx.compose.foundation.layout.Spacer(
        androidx.compose.ui.Modifier.height(10.dp)
    )

    // ── Primary action button ───────────────────────────────────────────
    when {
        downloadProgress != null || embedProgress != null -> {
            // Show a linear progress bar while either pass is running.
            // v4.8.1 — when embedding progress is the (0, 0) "preparing"
            // sentinel, use an indeterminate (animated) bar so the user sees
            // motion even before the COUNT query has finished.
            val isPreparing = embedProgress?.let { it.second == 0 } == true
            if (isPreparing) {
                androidx.compose.material3.LinearProgressIndicator(
                    modifier = androidx.compose.ui.Modifier.fillMaxWidth()
                )
            } else {
                val frac = downloadProgress
                    ?: (embedProgress?.let {
                        val (d, t) = it; if (t > 0) d.toFloat() / t else 0f
                    } ?: 0f)
                androidx.compose.material3.LinearProgressIndicator(
                    progress = { frac },
                    modifier = androidx.compose.ui.Modifier.fillMaxWidth()
                )
            }
        }
        !modelReady -> {
            // v4.9.1 — single-step install: tap once, the model downloads
            // AND embeddings start automatically when the download finishes.
            // Replaces the two-button "Download" → "Build" workflow.
            androidx.compose.material3.Button(
                onClick = { vm.installModel() },
                modifier = androidx.compose.ui.Modifier.fillMaxWidth()
            ) {
                val mb = activeDescriptor?.approxSizeMb ?: 25
                Text("Install model (~${mb} MB)")
            }
        }
        embedCount == 0 -> {
            // Model is downloaded but no embeddings yet — surface the embed
            // pass directly. Equivalent to the second phase of installModel().
            androidx.compose.material3.Button(
                onClick = { vm.buildAllEmbeddings() },
                modifier = androidx.compose.ui.Modifier.fillMaxWidth()
            ) {
                Text("Build embeddings")
            }
        }
        else -> {
            androidx.compose.material3.Button(
                onClick = { vm.buildAllEmbeddings() },
                modifier = androidx.compose.ui.Modifier.fillMaxWidth()
            ) {
                Text("Re-embed updated notes")
            }
        }
    }

    // ── Secondary action: clear embeddings ──────────────────────────────
    if (embedCount > 0 && embedProgress == null) {
        androidx.compose.foundation.layout.Spacer(
            androidx.compose.ui.Modifier.height(6.dp)
        )
        androidx.compose.material3.OutlinedButton(
            onClick = { vm.clearAllEmbeddings() },
            modifier = androidx.compose.ui.Modifier.fillMaxWidth()
        ) {
            Text("Clear embeddings")
        }
    }

    // ── Footnote ────────────────────────────────────────────────────────
    androidx.compose.foundation.layout.Spacer(
        androidx.compose.ui.Modifier.height(8.dp)
    )
    Text(
        "\u2705 Search integration is active. When you type in the search bar, " +
            "results are ranked using both keyword matches AND meaning-based " +
            "similarity from these embeddings. Try searching with different " +
            "wording than what's in your articles to see it in action.",
        fontSize = 11.sp,
        color = androidx.compose.material3.MaterialTheme.colorScheme.onSurfaceVariant,
        lineHeight = 15.sp
    )
}

/**
 * v4.21.0 — Settings UI for the on-device chat LLM (RAG over your library).
 *
 * Shows:
 *   • A description of what chat does
 *   • Status line — "Not installed" / "Downloading X% (Y / Z MB)" / "Installed"
 *   • Install / Delete / Cancel button depending on state
 *   • Three future-behaviour toggles (install flow, location, history mode)
 *
 * v4.21.0 is Settings-only — the toggles persist but don't yet change
 * behaviour. v4.22.x adds the chat screen UI that consumes them.
 */
@androidx.compose.runtime.Composable
private fun OnDeviceChatSection(vm: com.tebogo.markvault.AppViewModel) {
    val installed by vm.chatModelInstalled.collectAsStateWithLifecycle()
    val progress by vm.chatDownloadProgress.collectAsStateWithLifecycle()
    val running by vm.chatDownloadRunning.collectAsStateWithLifecycle()
    val lastError by vm.chatDownloadError.collectAsStateWithLifecycle()
    val installFlow by vm.chatInstallFlowPref.collectAsStateWithLifecycle()
    val location by vm.chatLocationPref.collectAsStateWithLifecycle()
    val historyMode by vm.chatHistoryModePref.collectAsStateWithLifecycle()
    val loadMode by vm.chatModelLoadModePref.collectAsStateWithLifecycle()
    val activeChatId by vm.chatActiveModelId.collectAsStateWithLifecycle()
    val descriptor = vm.availableChatModels.firstOrNull { it.id == activeChatId }
        ?: vm.availableChatModels.firstOrNull()

    Text(
        "\uD83D\uDCAC On-device chat (preview)",
        fontWeight = androidx.compose.ui.text.font.FontWeight.Bold,
        fontSize = 16.sp
    )
    androidx.compose.foundation.layout.Spacer(
        androidx.compose.ui.Modifier.height(6.dp)
    )
    Text(
        "Ask questions about your library and get a synthesised answer " +
            "with citations to the notes used. Runs entirely on this phone — " +
            "your notes never leave the device. Quality depends on the small " +
            "model used; best for lookup and drafting, not deep reasoning.",
        fontSize = 13.sp,
        color = androidx.compose.material3.MaterialTheme.colorScheme.onSurfaceVariant,
        lineHeight = 18.sp
    )
    androidx.compose.foundation.layout.Spacer(
        androidx.compose.ui.Modifier.height(14.dp)
    )

    // ── Model card ──────────────────────────────────────────────────────
    if (descriptor != null) {
        Text(
            descriptor.displayName,
            fontWeight = androidx.compose.ui.text.font.FontWeight.SemiBold,
            fontSize = 14.sp
        )
        androidx.compose.foundation.layout.Spacer(
            androidx.compose.ui.Modifier.height(4.dp)
        )
        Text(
            descriptor.description,
            fontSize = 12.sp,
            color = androidx.compose.material3.MaterialTheme.colorScheme.onSurfaceVariant,
            lineHeight = 16.sp
        )
        androidx.compose.foundation.layout.Spacer(
            androidx.compose.ui.Modifier.height(6.dp)
        )
        Text(
            "Download: ~${descriptor.approxSizeMb} MB   •   " +
                "RAM when active: ~${descriptor.approxRamMb} MB",
            fontSize = 11.sp,
            color = androidx.compose.material3.MaterialTheme.colorScheme.onSurfaceVariant
        )
    }

    androidx.compose.foundation.layout.Spacer(
        androidx.compose.ui.Modifier.height(12.dp)
    )

    // ── Status line ─────────────────────────────────────────────────────
    val statusText: String = when {
        running && progress != null -> {
            val (doneMb, totalMb) = progress!!
            val pct = if (totalMb > 0) (doneMb * 100 / totalMb).coerceIn(0, 100) else 0
            "Downloading: $doneMb / $totalMb MB  ($pct%)"
        }
        running -> "Connecting…"
        installed -> "\u2705 Installed and ready"
        lastError != null -> "\u26A0\uFE0F  ${lastError}"
        else -> "Not installed"
    }
    Text(
        statusText,
        fontSize = 13.sp,
        color = androidx.compose.material3.MaterialTheme.colorScheme.onSurface
    )
    if (running && progress != null) {
        val (doneMb, totalMb) = progress!!
        androidx.compose.foundation.layout.Spacer(
            androidx.compose.ui.Modifier.height(6.dp)
        )
        androidx.compose.material3.LinearProgressIndicator(
            progress = {
                if (totalMb > 0) (doneMb.toFloat() / totalMb.toFloat()) else 0f
            },
            modifier = androidx.compose.ui.Modifier.fillMaxWidth()
        )
    }
    androidx.compose.foundation.layout.Spacer(
        androidx.compose.ui.Modifier.height(12.dp)
    )

    // ── Primary action ──────────────────────────────────────────────────
    if (running) {
        OutlinedButton(
            onClick = { vm.stopChatModelDownload() },
            modifier = androidx.compose.ui.Modifier.fillMaxWidth()
        ) {
            Text("Cancel download")
        }
    } else if (installed) {
        OutlinedButton(
            onClick = { vm.deleteChatModel() },
            modifier = androidx.compose.ui.Modifier.fillMaxWidth()
        ) {
            Text("Delete model (frees ~${descriptor?.approxSizeMb ?: 0} MB)")
        }
    } else {
        androidx.compose.material3.Button(
            onClick = {
                vm.clearChatDownloadError()
                vm.downloadChatModel()
            },
            modifier = androidx.compose.ui.Modifier.fillMaxWidth()
        ) {
            Text("Install model (~${descriptor?.approxSizeMb ?: 0} MB)")
        }
    }

    if (lastError != null && !running) {
        androidx.compose.foundation.layout.Spacer(
            androidx.compose.ui.Modifier.height(6.dp)
        )
        androidx.compose.material3.TextButton(
            onClick = { vm.clearChatDownloadError() }
        ) {
            Text("Dismiss error")
        }
    }

    androidx.compose.foundation.layout.Spacer(
        androidx.compose.ui.Modifier.height(20.dp)
    )

    // ── Behaviour toggles (stored only in v4.21.0) ─────────────────────
    Text(
        "Behaviour (revisit anytime)",
        fontWeight = androidx.compose.ui.text.font.FontWeight.SemiBold,
        fontSize = 13.sp
    )
    androidx.compose.foundation.layout.Spacer(
        androidx.compose.ui.Modifier.height(4.dp)
    )
    Text(
        "These choose how chat will work once the chat screen lands in a " +
            "later update. They're saved now so you can change your mind " +
            "without losing the model download.",
        fontSize = 11.sp,
        color = androidx.compose.material3.MaterialTheme.colorScheme.onSurfaceVariant,
        lineHeight = 15.sp
    )
    androidx.compose.foundation.layout.Spacer(
        androidx.compose.ui.Modifier.height(10.dp)
    )

    ChatPickerRow(
        label = "Model install",
        current = installFlow,
        options = listOf(
            "opt_in" to "Opt-in (tap Install)",
            "auto_prompt" to "Prompt on first chat"
        ),
        onSelect = { vm.setChatInstallFlowPref(it) }
    )
    androidx.compose.foundation.layout.Spacer(
        androidx.compose.ui.Modifier.height(8.dp)
    )
    ChatPickerRow(
        label = "Where chat lives",
        current = location,
        options = listOf(
            "own_screen" to "Own screen (menu)",
            "in_search" to "Inside Search"
        ),
        onSelect = { vm.setChatLocationPref(it) }
    )
    androidx.compose.foundation.layout.Spacer(
        androidx.compose.ui.Modifier.height(8.dp)
    )
    ChatPickerRow(
        label = "Conversation memory",
        current = historyMode,
        options = listOf(
            "fresh_per_q" to "Fresh each question",
            "multi_turn" to "Multi-turn within session"
        ),
        onSelect = { vm.setChatHistoryModePref(it) }
    )
    androidx.compose.foundation.layout.Spacer(
        androidx.compose.ui.Modifier.height(8.dp)
    )
    ChatPickerRow(
        label = "When to load the model",
        current = loadMode,
        options = listOf(
            "on_open" to "When chat opens (default)",
            "preload" to "Always loaded (more RAM, instant)",
            "on_first_q" to "On first question (input ready early)"
        ),
        onSelect = { vm.setChatModelLoadModePref(it) }
    )
}

/**
 * Small reusable row that opens a dialog with the available options as
 * radio buttons. Used for the three chat behaviour toggles.
 */
@androidx.compose.runtime.Composable
private fun ChatPickerRow(
    label: String,
    current: String,
    options: List<Pair<String, String>>,  // id → display
    onSelect: (String) -> Unit
) {
    var dialogOpen by androidx.compose.runtime.remember { androidx.compose.runtime.mutableStateOf(false) }
    val currentDisplay = options.firstOrNull { it.first == current }?.second
        ?: options.firstOrNull()?.second ?: current
    OutlinedButton(
        onClick = { dialogOpen = true },
        modifier = androidx.compose.ui.Modifier.fillMaxWidth()
    ) {
        androidx.compose.foundation.layout.Column(
            androidx.compose.ui.Modifier.fillMaxWidth()
        ) {
            Text(label, fontSize = 12.sp,
                color = androidx.compose.material3.MaterialTheme.colorScheme.onSurfaceVariant)
            Text(currentDisplay, fontSize = 14.sp,
                fontWeight = androidx.compose.ui.text.font.FontWeight.SemiBold)
        }
    }
    if (dialogOpen) {
        androidx.compose.material3.AlertDialog(
            onDismissRequest = { dialogOpen = false },
            title = { Text(label) },
            text = {
                androidx.compose.foundation.layout.Column {
                    options.forEach { (id, display) ->
                        androidx.compose.foundation.layout.Row(
                            modifier = androidx.compose.ui.Modifier
                                .fillMaxWidth()
                                .padding(vertical = 8.dp),
                            verticalAlignment = androidx.compose.ui.Alignment.CenterVertically
                        ) {
                            androidx.compose.material3.RadioButton(
                                selected = (id == current),
                                onClick = {
                                    onSelect(id)
                                    dialogOpen = false
                                }
                            )
                            androidx.compose.foundation.layout.Spacer(
                                androidx.compose.ui.Modifier.width(8.dp)
                            )
                            Text(display, fontSize = 14.sp)
                        }
                    }
                }
            },
            confirmButton = {
                androidx.compose.material3.TextButton(onClick = { dialogOpen = false }) {
                    Text("Close")
                }
            }
        )
    }
}

/**
 * v4.23.0 — Settings card for the reranker (cross-encoder).
 *
 * Shows:
 *   • Description of what reranking does
 *   • Install / Delete / Cancel button depending on state
 *   • Progress bar during download
 *   • Toggle to enable/disable reranking once installed
 */
@androidx.compose.runtime.Composable
private fun RerankerSection(vm: com.tebogo.markvault.AppViewModel) {
    val installed by vm.rerankerInstalled.collectAsStateWithLifecycle()
    val progress by vm.rerankerDownloadProgress.collectAsStateWithLifecycle()
    val downloading by vm.rerankerDownloading.collectAsStateWithLifecycle()
    val lastError by vm.rerankerDownloadError.collectAsStateWithLifecycle()
    val rerankEnabled by vm.rerankEnabled.collectAsStateWithLifecycle()
    val descriptor = vm.rerankerDescriptor

    Text(
        "\uD83C\uDFAF Smart reranking (recommended)",
        fontWeight = androidx.compose.ui.text.font.FontWeight.Bold,
        fontSize = 16.sp
    )
    androidx.compose.foundation.layout.Spacer(
        androidx.compose.ui.Modifier.height(6.dp)
    )
    Text(
        "Adds a second-stage ranking pass after semantic search. Instead " +
            "of just matching meaning, the cross-encoder reads each candidate " +
            "article alongside your question and judges whether it actually " +
            "ANSWERS the question. The model is small (~33 MB) and runs " +
            "entirely on this phone. Adds 3–5 seconds per search.",
        fontSize = 13.sp,
        color = androidx.compose.material3.MaterialTheme.colorScheme.onSurfaceVariant,
        lineHeight = 18.sp
    )
    androidx.compose.foundation.layout.Spacer(
        androidx.compose.ui.Modifier.height(14.dp)
    )

    Text(
        descriptor.displayName,
        fontWeight = androidx.compose.ui.text.font.FontWeight.SemiBold,
        fontSize = 14.sp
    )
    androidx.compose.foundation.layout.Spacer(
        androidx.compose.ui.Modifier.height(4.dp)
    )
    Text(
        descriptor.description,
        fontSize = 12.sp,
        color = androidx.compose.material3.MaterialTheme.colorScheme.onSurfaceVariant,
        lineHeight = 16.sp
    )
    androidx.compose.foundation.layout.Spacer(
        androidx.compose.ui.Modifier.height(6.dp)
    )
    Text(
        "Download: ~${descriptor.approxSizeMb} MB   •   " +
            "RAM when active: ~${descriptor.approxRamMb} MB",
        fontSize = 11.sp,
        color = androidx.compose.material3.MaterialTheme.colorScheme.onSurfaceVariant
    )
    androidx.compose.foundation.layout.Spacer(
        androidx.compose.ui.Modifier.height(12.dp)
    )

    // Status line
    val statusText: String = when {
        downloading && progress != null -> {
            val mb = (progress!! * descriptor.approxSizeMb).toInt()
            val pct = (progress!! * 100).toInt().coerceIn(0, 100)
            "Downloading: $mb / ${descriptor.approxSizeMb} MB  ($pct%)"
        }
        downloading -> "Connecting…"
        installed -> "\u2705 Installed and ready"
        lastError != null -> "\u26A0\uFE0F  ${lastError}"
        else -> "Not installed"
    }
    Text(
        statusText,
        fontSize = 13.sp,
        color = androidx.compose.material3.MaterialTheme.colorScheme.onSurface
    )
    if (downloading && progress != null) {
        androidx.compose.foundation.layout.Spacer(
            androidx.compose.ui.Modifier.height(6.dp)
        )
        androidx.compose.material3.LinearProgressIndicator(
            progress = { progress!! },
            modifier = androidx.compose.ui.Modifier.fillMaxWidth()
        )
    }
    androidx.compose.foundation.layout.Spacer(
        androidx.compose.ui.Modifier.height(12.dp)
    )

    // Primary action
    if (downloading) {
        OutlinedButton(
            onClick = { vm.stopRerankerDownload() },
            modifier = androidx.compose.ui.Modifier.fillMaxWidth()
        ) { Text("Cancel download") }
    } else if (installed) {
        OutlinedButton(
            onClick = { vm.deleteReranker() },
            modifier = androidx.compose.ui.Modifier.fillMaxWidth()
        ) {
            Text("Delete reranker (frees ~${descriptor.approxSizeMb} MB)")
        }
    } else {
        androidx.compose.material3.Button(
            onClick = {
                vm.clearRerankerError()
                vm.downloadReranker()
            },
            modifier = androidx.compose.ui.Modifier.fillMaxWidth()
        ) {
            Text("Install reranker (~${descriptor.approxSizeMb} MB)")
        }
    }

    if (lastError != null && !downloading) {
        androidx.compose.foundation.layout.Spacer(
            androidx.compose.ui.Modifier.height(6.dp)
        )
        androidx.compose.material3.TextButton(
            onClick = { vm.clearRerankerError() }
        ) { Text("Dismiss error") }
    }

    // Once installed: the on/off toggle
    if (installed) {
        androidx.compose.foundation.layout.Spacer(
            androidx.compose.ui.Modifier.height(14.dp)
        )
        androidx.compose.foundation.layout.Row(
            modifier = androidx.compose.ui.Modifier.fillMaxWidth(),
            verticalAlignment = androidx.compose.ui.Alignment.CenterVertically
        ) {
            androidx.compose.foundation.layout.Column(
                androidx.compose.ui.Modifier.weight(1f)
            ) {
                Text(
                    "Use reranking for searches",
                    fontWeight = androidx.compose.ui.text.font.FontWeight.SemiBold,
                    fontSize = 14.sp
                )
                Text(
                    if (rerankEnabled) "ON — adds 3–5 s per search for better results"
                    else "OFF — fast cosine ranking only",
                    fontSize = 11.sp,
                    color = androidx.compose.material3.MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
            androidx.compose.material3.Switch(
                checked = rerankEnabled,
                onCheckedChange = { vm.setRerankEnabled(it) }
            )
        }
    }
}

/**
 * v5.2.0 — Settings card for Home-screen-specific options.
 *
 * Currently just the recent-searches count (0–20). Slider is overkill
 * for one value, so a row of +/− buttons around the current number is
 * used instead — easier to fine-tune on a phone screen.
 */
@androidx.compose.runtime.Composable
private fun HomeScreenSection(vm: com.tebogo.markvault.AppViewModel) {
    val current by vm.maxRecentSearchesOnHome.collectAsStateWithLifecycle()
    Text(
        "\uD83C\uDFE0  Home screen",
        fontWeight = androidx.compose.ui.text.font.FontWeight.Bold,
        fontSize = 16.sp
    )
    androidx.compose.foundation.layout.Spacer(
        androidx.compose.ui.Modifier.height(6.dp)
    )
    Text(
        "How many recent search queries to show under the home-page search bar. " +
            "Tap one to re-run it. Set to 0 to hide the list entirely.",
        fontSize = 13.sp,
        color = androidx.compose.material3.MaterialTheme.colorScheme.onSurfaceVariant,
        lineHeight = 18.sp
    )
    androidx.compose.foundation.layout.Spacer(
        androidx.compose.ui.Modifier.height(12.dp)
    )
    androidx.compose.foundation.layout.Row(
        modifier = androidx.compose.ui.Modifier.fillMaxWidth(),
        verticalAlignment = androidx.compose.ui.Alignment.CenterVertically
    ) {
        Text(
            "Recent search entries",
            fontSize = 14.sp,
            modifier = androidx.compose.ui.Modifier.weight(1f)
        )
        OutlinedButton(
            onClick = { vm.setMaxRecentSearchesOnHome((current - 1).coerceAtLeast(0)) },
            enabled = current > 0
        ) { Text("\u2212") }
        androidx.compose.foundation.layout.Spacer(
            androidx.compose.ui.Modifier.width(12.dp)
        )
        Text(
            "$current",
            fontSize = 18.sp,
            fontWeight = androidx.compose.ui.text.font.FontWeight.Bold,
            modifier = androidx.compose.ui.Modifier.widthIn(min = 28.dp),
            textAlign = androidx.compose.ui.text.style.TextAlign.Center
        )
        androidx.compose.foundation.layout.Spacer(
            androidx.compose.ui.Modifier.width(12.dp)
        )
        OutlinedButton(
            onClick = { vm.setMaxRecentSearchesOnHome((current + 1).coerceAtMost(20)) },
            enabled = current < 20
        ) { Text("+") }
    }
}
