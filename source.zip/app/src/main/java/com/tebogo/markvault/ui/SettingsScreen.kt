package com.tebogo.markvault.ui

import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.Button
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Slider
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.navigation.NavController
import com.tebogo.markvault.AppViewModel

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SettingsScreen(vm: AppViewModel, nav: NavController) {
    val libraryUri by vm.libraryUri.collectAsStateWithLifecycle()
    val notes by vm.notes.collectAsStateWithLifecycle()
    val progress by vm.progress.collectAsStateWithLifecycle()
    val fontScale by vm.fontScale.collectAsStateWithLifecycle()

    val picker = rememberLauncherForActivityResult(
        ActivityResultContracts.OpenDocumentTree()
    ) { uri ->
        if (uri != null) vm.setLibrary(uri)
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("\u2699\uFE0F Settings") },
                navigationIcon = {
                    IconButton(onClick = { nav.popBackStack() }) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back")
                    }
                },
                actions = {
                    IconButton(onClick = { nav.navigate("search") }) {
                        Icon(Icons.Default.Search, contentDescription = "Search library")
                    }
                    GlobalAppMenu(nav)
                }
            )
        }
    ) { pad ->
        Column(
            Modifier
                .padding(pad)
                .fillMaxSize()
                .verticalScroll(rememberScrollState())
                .padding(16.dp)
        ) {
            Text("\uD83D\uDCDA Library", fontWeight = FontWeight.Bold, fontSize = 16.sp)
            Spacer(Modifier.height(8.dp))
            val mdCount = remember(notes) { notes.count { it.fileType != "pdf" } }
            val pdfCount = remember(notes) { notes.count { it.fileType == "pdf" } }
            Text(
                buildString {
                    append("Indexed: ${notes.size} files")
                    if (pdfCount > 0) append("  (\uD83D\uDCC4 $mdCount md · \uD83D\uDCD5 $pdfCount pdf)")
                },
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                fontSize = 13.sp
            )
            if (progress.running) {
                Spacer(Modifier.height(8.dp))
                LinearProgressIndicator(Modifier.fillMaxWidth())
                Text(
                    "\u23F3 ${progress.phase} ${progress.done} / ${progress.total}",
                    fontSize = 12.sp,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
            Spacer(Modifier.height(12.dp))
            Row {
                Button(
                    onClick = { vm.reindex() },
                    enabled = libraryUri != null && !progress.running
                ) { Text("\u21BB  Re-index") }
                Spacer(Modifier.width(12.dp))
                OutlinedButton(
                    onClick = { picker.launch(null) },
                    enabled = !progress.running
                ) { Text("\uD83D\uDCC1 Change folder") }
            }

            Spacer(Modifier.height(28.dp))
            Text("\uD83D\uDD20 Reading font size", fontWeight = FontWeight.Bold, fontSize = 16.sp)
            Slider(
                value = fontScale,
                onValueChange = { vm.setFontScale(it) },
                valueRange = 0.7f..2.0f
            )
            Text("Sample text at current size", fontSize = (16f * fontScale).sp)

            Spacer(Modifier.height(28.dp))
            Text("\uD83C\uDF10 Web imports", fontWeight = FontWeight.Bold, fontSize = 16.sp)
            Spacer(Modifier.height(6.dp))
            Text(
                "When you share a web page to MarkVault, the page is rendered, converted to " +
                    "markdown, and saved to this subfolder of your library. Leave blank to save " +
                    "directly to the library root.",
                fontSize = 12.sp,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
            Spacer(Modifier.height(10.dp))
            val importsSubfolder by vm.importsSubfolder.collectAsStateWithLifecycle()
            var subfolderText by remember(importsSubfolder) {
                mutableStateOf(importsSubfolder)
            }
            OutlinedTextField(
                value = subfolderText,
                onValueChange = { subfolderText = it.filter { ch -> ch != '/' && ch != '\\' } },
                singleLine = true,
                modifier = Modifier.fillMaxWidth(),
                placeholder = { Text("e.g. Web Clippings") },
                label = { Text("Import subfolder") }
            )
            Spacer(Modifier.height(8.dp))
            Row {
                Button(
                    onClick = { vm.setImportsSubfolder(subfolderText.trim()) },
                    enabled = subfolderText != importsSubfolder
                ) { Text("Save folder name") }
                Spacer(Modifier.width(12.dp))
                OutlinedButton(onClick = { picker.launch(null) }) {
                    Text("\uD83D\uDD13 Re-grant library access")
                }
            }
            Spacer(Modifier.height(4.dp))
            Text(
                "If web imports fail with a read-only error, tap " +
                    "\u201CRe-grant library access\u201D and pick the same library folder again \u2014 " +
                    "this upgrades read-only permission to read+write.",
                fontSize = 11.sp,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )

            Spacer(Modifier.height(28.dp))
            Text("\u26A1 Performance", fontWeight = FontWeight.Bold, fontSize = 16.sp)
            Spacer(Modifier.height(6.dp))
            Text(
                "Heavy visual features are off by default for snappy scrolling on every " +
                    "device. If you're on a higher-end phone, switch them on for the full " +
                    "experience.",
                fontSize = 12.sp,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
            Spacer(Modifier.height(14.dp))

            // ── Smart styling on all documents ──
            val smartStylingAllDocs by vm.smartStylingAllDocs.collectAsStateWithLifecycle()
            Row(
                Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column(Modifier.weight(1f)) {
                    Text(
                        "\uD83C\uDFA8 Smart styling on all documents",
                        fontSize = 14.sp, fontWeight = FontWeight.Medium
                    )
                    Text(
                        "Auto-colourize numbers, references, percentages, quoted phrases " +
                            "and ALL-CAPS terms even in very long articles. May make " +
                            "scrolling stutter on 60,000+ character files.",
                        fontSize = 11.sp,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
                Spacer(Modifier.width(12.dp))
                Switch(
                    checked = smartStylingAllDocs,
                    onCheckedChange = { vm.setSmartStylingAllDocs(it) }
                )
            }

            Spacer(Modifier.height(18.dp))

            // ── Swipe to switch tabs ──
            val swipeSwitchTabs by vm.swipeSwitchTabs.collectAsStateWithLifecycle()
            Row(
                Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column(Modifier.weight(1f)) {
                    Text(
                        "\uD83D\uDC48\uD83D\uDC49 Swipe to switch tabs",
                        fontSize = 14.sp, fontWeight = FontWeight.Medium
                    )
                    Text(
                        "Horizontal swipe in the markdown reader jumps to the previous / " +
                            "next open tab. Adds touch-event interception that can mildly " +
                            "slow scrolling. Toolbar \u2190 \u2192 buttons are always available.",
                        fontSize = 11.sp,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
                Spacer(Modifier.width(12.dp))
                Switch(
                    checked = swipeSwitchTabs,
                    onCheckedChange = { vm.setSwipeSwitchTabs(it) }
                )
            }

            Spacer(Modifier.height(28.dp))
            Text("\u2139\uFE0F About", fontWeight = FontWeight.Bold, fontSize = 16.sp)
            Spacer(Modifier.height(6.dp))
            Text(
                "MarkVault 1.4 \u2014 Topic Intelligence\n" +
                    "Offline Markdown knowledge system.\n" +
                    "Auto-grouped topics \u00B7 dashboard \u00B7 concept search.\n" +
                    "Your notes never leave this phone. \uD83D\uDCDA",
                fontSize = 13.sp,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
        }
    }
}
