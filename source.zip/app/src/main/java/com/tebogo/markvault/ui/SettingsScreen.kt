package com.tebogo.markvault.ui

import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.Button
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Slider
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.navigation.NavController
import com.tebogo.markvault.AppViewModel

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SettingsScreen(vm: AppViewModel, nav: NavController) {
    val libraryUri by vm.libraryUri.collectAsStateWithLifecycle()
    val notes by vm.notes.collectAsStateWithLifecycle()
    val progress by vm.progress.collectAsStateWithLifecycle()
    val fontScale by vm.fontScale.collectAsStateWithLifecycle()

    val picker = rememberLauncherForActivityResult(
        ActivityResultContracts.OpenDocumentTree()
    ) { uri ->
        if (uri != null) vm.setLibrary(uri)
    }

    Scaffold(
        topBar = { TopAppBar(title = { Text("\u2699\uFE0F Settings") }) },
        bottomBar = {
            MarkVaultBottomBar(
                nav = nav, vm = vm,
                extraActions = {
                    IconButton(onClick = { nav.navigate("search") }) {
                        Icon(Icons.Default.Search, contentDescription = "Search library")
                    }
                }
            )
        }
    ) { pad ->
        Column(
            Modifier
                .padding(pad)
                .fillMaxSize()
                .verticalScroll(rememberScrollState())
                .padding(16.dp)
        ) {
            Text("\uD83D\uDCDA Library", fontWeight = FontWeight.Bold, fontSize = 16.sp)
            Spacer(Modifier.height(8.dp))
            val mdCount = remember(notes) { notes.count { it.fileType != "pdf" } }
            val pdfCount = remember(notes) { notes.count { it.fileType == "pdf" } }
            Text(
                buildString {
                    append("Indexed: ${notes.size} files")
                    if (pdfCount > 0) append("  (\uD83D\uDCC4 $mdCount md · \uD83D\uDCD5 $pdfCount pdf)")
                },
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                fontSize = 13.sp
            )
            if (progress.running) {
                Spacer(Modifier.height(8.dp))
                LinearProgressIndicator(Modifier.fillMaxWidth())
                Text(
                    "\u23F3 ${progress.phase} ${progress.done} / ${progress.total}",
                    fontSize = 12.sp,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
            Spacer(Modifier.height(12.dp))
            Row {
                Button(
                    onClick = { vm.reindex() },
                    enabled = libraryUri != null && !progress.running
                ) { Text("\u21BB  Re-index") }
                Spacer(Modifier.width(12.dp))
                OutlinedButton(
                    onClick = { picker.launch(null) },
                    enabled = !progress.running
                ) { Text("\uD83D\uDCC1 Change folder") }
            }

            Spacer(Modifier.height(28.dp))
            Text("\uD83D\uDD20 Reading font size", fontWeight = FontWeight.Bold, fontSize = 16.sp)
            Slider(
                value = fontScale,
                onValueChange = { vm.setFontScale(it) },
                valueRange = 0.7f..2.0f
            )
            Text("Sample text at current size", fontSize = (16f * fontScale).sp)

            Spacer(Modifier.height(28.dp))
            Text("\uD83C\uDF10 Web imports", fontWeight = FontWeight.Bold, fontSize = 16.sp)
            Spacer(Modifier.height(6.dp))
            Text(
                "When you share a web page to MarkVault, the page is rendered, converted to " +
                    "markdown, and saved to this subfolder of your library. Leave blank to save " +
                    "directly to the library root.",
                fontSize = 12.sp,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
            Spacer(Modifier.height(10.dp))
            val importsSubfolder by vm.importsSubfolder.collectAsStateWithLifecycle()
            var subfolderText by remember(importsSubfolder) {
                mutableStateOf(importsSubfolder)
            }
            OutlinedTextField(
                value = subfolderText,
                onValueChange = { subfolderText = it.filter { ch -> ch != '/' && ch != '\\' } },
                singleLine = true,
                modifier = Modifier.fillMaxWidth(),
                placeholder = { Text("e.g. Web Clippings") },
                label = { Text("Import subfolder") }
            )
            Spacer(Modifier.height(8.dp))
            Row {
                Button(
                    onClick = { vm.setImportsSubfolder(subfolderText.trim()) },
                    enabled = subfolderText != importsSubfolder
                ) { Text("Save folder name") }
                Spacer(Modifier.width(12.dp))
                OutlinedButton(onClick = { picker.launch(null) }) {
                    Text("\uD83D\uDD13 Re-grant library access")
                }
            }
            Spacer(Modifier.height(4.dp))
            Text(
                "If web imports fail with a read-only error, tap " +
                    "\u201CRe-grant library access\u201D and pick the same library folder again \u2014 " +
                    "this upgrades read-only permission to read+write.",
                fontSize = 11.sp,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )

            Spacer(Modifier.height(28.dp))
            Text("\u26A1 Performance", fontWeight = FontWeight.Bold, fontSize = 16.sp)
            Spacer(Modifier.height(6.dp))
            Text(
                "Heavy visual features are off by default for snappy scrolling on every " +
                    "device. If you're on a higher-end phone, switch them on for the full " +
                    "experience.",
                fontSize = 12.sp,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
            Spacer(Modifier.height(14.dp))

            // ── Smart styling on all documents ──
            val smartStylingAllDocs by vm.smartStylingAllDocs.collectAsStateWithLifecycle()
            Row(
                Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column(Modifier.weight(1f)) {
                    Text(
                        "\uD83C\uDFA8 Smart styling on all documents",
                        fontSize = 14.sp, fontWeight = FontWeight.Medium
                    )
                    Text(
                        "Auto-colourize numbers, references, percentages, quoted phrases " +
                            "and ALL-CAPS terms even in very long articles. May make " +
                            "scrolling stutter on 60,000+ character files.",
                        fontSize = 11.sp,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
                Spacer(Modifier.width(12.dp))
                Switch(
                    checked = smartStylingAllDocs,
                    onCheckedChange = { vm.setSmartStylingAllDocs(it) }
                )
            }

            Spacer(Modifier.height(18.dp))

            // ── Swipe to switch tabs ──
            val swipeSwitchTabs by vm.swipeSwitchTabs.collectAsStateWithLifecycle()
            Row(
                Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column(Modifier.weight(1f)) {
                    Text(
                        "\uD83D\uDC48\uD83D\uDC49 Swipe to switch tabs",
                        fontSize = 14.sp, fontWeight = FontWeight.Medium
                    )
                    Text(
                        "Horizontal swipe in the markdown reader jumps to the previous / " +
                            "next open tab. Adds touch-event interception that can mildly " +
                            "slow scrolling. Toolbar \u2190 \u2192 buttons are always available.",
                        fontSize = 11.sp,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
                Spacer(Modifier.width(12.dp))
                Switch(
                    checked = swipeSwitchTabs,
                    onCheckedChange = { vm.setSwipeSwitchTabs(it) }
                )
            }

            Spacer(Modifier.height(28.dp))
            Text("\uD83C\uDFA8 Appearance", fontWeight = FontWeight.Bold, fontSize = 16.sp)
            Spacer(Modifier.height(6.dp))
            Text(
                "Pick the theme that drives both the article viewer and the app chrome.",
                fontSize = 12.sp,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
            Spacer(Modifier.height(10.dp))
            var themePickerOpen by remember { mutableStateOf(false) }
            val currentTheme by vm.theme.collectAsStateWithLifecycle()
            androidx.compose.material3.OutlinedButton(
                onClick = { themePickerOpen = true },
                modifier = Modifier.fillMaxWidth()
            ) {
                val label = when (currentTheme) {
                    "black"             -> "\u26AB AMOLED black"
                    "sepia"             -> "\uD83D\uDCDC Sepia"
                    "light"             -> "\u2600\uFE0F Light"
                    "hicontrast-dark"   -> "\u26A1 High-contrast dark"
                    "hicontrast-light"  -> "\u26A1 High-contrast light"
                    "ocean"             -> "\uD83C\uDF0A Ocean"
                    "forest"            -> "\uD83C\uDF32 Forest"
                    "cream"             -> "\uD83E\uDD5B Cream"
                    else                -> "\uD83C\uDF11 Dark (grey)"
                }
                Text("Theme: $label")
            }
            if (themePickerOpen) {
                ThemePickerDialog(vm, onDismiss = { themePickerOpen = false })
            }

            Spacer(Modifier.height(18.dp))
            // ── Text contrast slider ──
            val contrast by vm.textContrast.collectAsStateWithLifecycle()
            Text(
                "\uD83D\uDD06 Text contrast \u00B7 ${"%.2f".format(contrast)}\u00D7",
                fontSize = 14.sp, fontWeight = FontWeight.Medium
            )
            Text(
                "Boost foreground/background contrast for easier reading, especially in " +
                    "light and sepia themes. 1.0\u00D7 = default, 2.0\u00D7 = maximum.",
                fontSize = 11.sp,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
            androidx.compose.material3.Slider(
                value = contrast,
                onValueChange = { vm.setTextContrast(it) },
                valueRange = 1.0f..2.0f,
                steps = 19   // 0.05 steps
            )

            Spacer(Modifier.height(28.dp))
            Text("\uD83C\uDF10 In-app browser", fontWeight = FontWeight.Bold, fontSize = 16.sp)
            Spacer(Modifier.height(6.dp))
            Text(
                "Settings for the WebView that opens jw.org scriptures.",
                fontSize = 12.sp,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
            Spacer(Modifier.height(10.dp))
            androidx.compose.material3.OutlinedButton(
                onClick = { nav.navigate("webHistory") },
                modifier = Modifier.fillMaxWidth()
            ) { Text("\uD83D\uDD52 Open web history") }
            Spacer(Modifier.height(8.dp))
            androidx.compose.material3.OutlinedButton(
                onClick = { nav.navigate("pdfHistory") },
                modifier = Modifier.fillMaxWidth()
            ) { Text("\uD83D\uDCDC Open PDF history") }
            Spacer(Modifier.height(8.dp))
            var confirmClearWeb by remember { mutableStateOf(false) }
            androidx.compose.material3.OutlinedButton(
                onClick = { confirmClearWeb = true },
                modifier = Modifier.fillMaxWidth()
            ) { Text("\uD83E\uDDF9 Clear all web history") }
            if (confirmClearWeb) {
                androidx.compose.material3.AlertDialog(
                    onDismissRequest = { confirmClearWeb = false },
                    title = { Text("Clear web history?") },
                    text = { Text("This removes every web-history entry. Browser data on the device is not touched.") },
                    confirmButton = {
                        androidx.compose.material3.Button(onClick = {
                            vm.clearWebHistory()
                            confirmClearWeb = false
                        }) { Text("Clear") }
                    },
                    dismissButton = {
                        androidx.compose.material3.TextButton(onClick = { confirmClearWeb = false }) { Text("Cancel") }
                    }
                )
            }

            Spacer(Modifier.height(28.dp))
            // ── v4.8 — Semantic search foundation ──────────────────────────
            // Three-step user journey:
            //   (1) Download the .tflite model (~25MB, one-time)
            //   (2) Build embeddings for every note in the library
            //   (3) Search and ranking integration arrives next iteration
            SemanticSearchSection(vm)
            Spacer(Modifier.height(28.dp))
            Text("\u2139\uFE0F About", fontWeight = FontWeight.Bold, fontSize = 16.sp)
            Spacer(Modifier.height(6.dp))
            Text(
                "MarkVault 3.5 \u2014 Browser + History + Themes\n" +
                    "\u2022 Offline Markdown + PDF knowledge system.\n" +
                    "\u2022 In-app jw.org browser with history.\n" +
                    "\u2022 Auto-grouped topics, dashboard, concept search.\n" +
                    "\u2022 Your notes never leave this phone. \uD83D\uDCDA",
                fontSize = 13.sp,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
        }
    }
}

/**
 * Settings UI for the semantic-search foundation. Three controls:
 *
 *   • Status line — "Model not downloaded" / "Downloading…X%" / "Model ready"
 *   • Action button — Download model OR Build embeddings (whichever's next)
 *   • Secondary action — Clear embeddings (only shown when there are any)
 *
 * Kept intentionally self-contained at the bottom of SettingsScreen.kt so it
 * can be moved into its own file later without ceremony. The composable does
 * not depend on any other Settings helpers, only on AppViewModel's public
 * state flows ([modelAvailable], [modelDownloadProgress], [embeddingCount],
 * [embeddingProgress]) and four methods.
 */
@androidx.compose.runtime.Composable
private fun SemanticSearchSection(vm: com.tebogo.markvault.AppViewModel) {
    val modelReady by vm.modelAvailable.collectAsStateWithLifecycle()
    val downloadProgress by vm.modelDownloadProgress.collectAsStateWithLifecycle()
    val embedCount by vm.embeddingCount.collectAsStateWithLifecycle()
    val embedProgress by vm.embeddingProgress.collectAsStateWithLifecycle()

    Text(
        "\uD83E\uDDE0 Semantic search (experimental)",
        fontWeight = androidx.compose.ui.text.font.FontWeight.Bold,
        fontSize = 16.sp
    )
    androidx.compose.foundation.layout.Spacer(
        androidx.compose.ui.Modifier.height(6.dp)
    )
    Text(
        "On-device meaning-based ranking. Downloads a ~25MB language model once, " +
            "then embeds every note in your library so similar phrasings match even " +
            "when wording differs. All processing stays on this phone.",
        fontSize = 13.sp,
        color = androidx.compose.material3.MaterialTheme.colorScheme.onSurfaceVariant,
        lineHeight = 18.sp
    )
    androidx.compose.foundation.layout.Spacer(
        androidx.compose.ui.Modifier.height(10.dp)
    )

    // ── Status line ─────────────────────────────────────────────────────
    val statusLine = when {
        downloadProgress != null -> {
            val pct = ((downloadProgress ?: 0f) * 100).toInt()
            "\u23F3 Downloading model\u2026 $pct%"
        }
        embedProgress != null -> {
            val (done, total) = embedProgress!!
            // v4.8.1 — (0, 0) is the "preparing" sentinel emitted before the
            // COUNT query has finished. Avoid the "0 / 0 (0%)" weirdness.
            if (total == 0) "\u23F3 Preparing\u2026 (counting notes)"
            else {
                val pct = (done * 100 / total)
                "\u23F3 Embedding library\u2026 $done / $total ($pct%)"
            }
        }
        !modelReady -> "\u26AB Model not downloaded"
        embedCount == 0 -> "\u2705 Model ready \u2014 no embeddings built yet"
        else -> "\u2705 Model ready \u2014 $embedCount note${if (embedCount == 1) "" else "s"} embedded"
    }
    Text(
        statusLine,
        fontSize = 13.sp,
        fontWeight = androidx.compose.ui.text.font.FontWeight.Medium,
        color = androidx.compose.material3.MaterialTheme.colorScheme.primary
    )

    androidx.compose.foundation.layout.Spacer(
        androidx.compose.ui.Modifier.height(10.dp)
    )

    // ── Primary action button ───────────────────────────────────────────
    when {
        downloadProgress != null || embedProgress != null -> {
            // Show a linear progress bar while either pass is running.
            // v4.8.1 — when embedding progress is the (0, 0) "preparing"
            // sentinel, use an indeterminate (animated) bar so the user sees
            // motion even before the COUNT query has finished.
            val isPreparing = embedProgress?.let { it.second == 0 } == true
            if (isPreparing) {
                androidx.compose.material3.LinearProgressIndicator(
                    modifier = androidx.compose.ui.Modifier.fillMaxWidth()
                )
            } else {
                val frac = downloadProgress
                    ?: (embedProgress?.let {
                        val (d, t) = it; if (t > 0) d.toFloat() / t else 0f
                    } ?: 0f)
                androidx.compose.material3.LinearProgressIndicator(
                    progress = { frac },
                    modifier = androidx.compose.ui.Modifier.fillMaxWidth()
                )
            }
        }
        !modelReady -> {
            androidx.compose.material3.Button(
                onClick = { vm.downloadEmbeddingModel() },
                modifier = androidx.compose.ui.Modifier.fillMaxWidth()
            ) {
                Text("Download model (~25MB)")
            }
        }
        else -> {
            androidx.compose.material3.Button(
                onClick = { vm.buildAllEmbeddings() },
                modifier = androidx.compose.ui.Modifier.fillMaxWidth()
            ) {
                Text(if (embedCount == 0) "Build embeddings" else "Re-embed updated notes")
            }
        }
    }

    // ── Secondary action: clear embeddings ──────────────────────────────
    if (embedCount > 0 && embedProgress == null) {
        androidx.compose.foundation.layout.Spacer(
            androidx.compose.ui.Modifier.height(6.dp)
        )
        androidx.compose.material3.OutlinedButton(
            onClick = { vm.clearAllEmbeddings() },
            modifier = androidx.compose.ui.Modifier.fillMaxWidth()
        ) {
            Text("Clear embeddings")
        }
    }

    // ── Footnote ────────────────────────────────────────────────────────
    androidx.compose.foundation.layout.Spacer(
        androidx.compose.ui.Modifier.height(8.dp)
    )
    Text(
        "Note: search integration arrives in a follow-up update. Right now this " +
            "section lets you prepare the model and embeddings without touching " +
            "the existing search ranking.",
        fontSize = 11.sp,
        color = androidx.compose.material3.MaterialTheme.colorScheme.onSurfaceVariant,
        lineHeight = 15.sp
    )
}
