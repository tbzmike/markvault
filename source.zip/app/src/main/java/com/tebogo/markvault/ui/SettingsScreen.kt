package com.tebogo.markvault.ui

import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.Button
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Slider
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.navigation.NavController
import com.tebogo.markvault.AppViewModel
import com.tebogo.markvault.ai.T5ExpansionMode
import com.tebogo.markvault.search.isInstalled
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.size

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SettingsScreen(vm: AppViewModel, nav: NavController) {
    val libraryUri by vm.libraryUri.collectAsStateWithLifecycle()
    val notes by vm.notes.collectAsStateWithLifecycle()
    val progress by vm.progress.collectAsStateWithLifecycle()
    val fontScale by vm.fontScale.collectAsStateWithLifecycle()
    // v5.4.121cc — Was `var t5Mode by remember { mutableStateOf(BUILTIN) }`,
    // an ephemeral Compose local with no backing store: it reset to
    // BUILTIN on every recomposition, screen re-entry, and process
    // restart regardless of what the user picked, and switching it never
    // actually changed which engine ran a search. Now reads/writes the
    // persisted selection in the ViewModel (see [AppViewModel.t5ExpansionMode]).
    val t5Mode by vm.t5ExpansionMode.collectAsStateWithLifecycle()
    val t5Installed by vm.t5Installed.collectAsStateWithLifecycle()
    val t5DownloadProgress by vm.t5DownloadProgress.collectAsStateWithLifecycle()
    val t5Error by vm.t5Error.collectAsStateWithLifecycle()
    val picker = rememberLauncherForActivityResult(
        ActivityResultContracts.OpenDocumentTree()
    ) { uri ->
        if (uri != null) vm.setLibrary(uri)
    }

    Scaffold(
        topBar = { TopAppBar(title = { Text("\u2699\uFE0F Settings") }) },
        bottomBar = {
            MarkVaultBottomBar(
                nav = nav, vm = vm,
                extraActions = {
                    IconButton(onClick = { nav.navigate("search") }) {
                        Icon(Icons.Default.Search, contentDescription = "Search library")
                    }
                }
            )
        }
    ) { pad ->
        Column(
            Modifier
                .padding(pad)
                .fillMaxSize()
                .verticalScroll(rememberScrollState())
                .padding(16.dp)
        ) {
            MultiQuerySlider(vm = vm)
            T5ExpansionSettingsCard(
                mode = t5Mode,
                installed = t5Installed,
                downloadProgress = t5DownloadProgress,
                error = t5Error,
                onModeChanged = { vm.setT5ExpansionMode(it) },
                onDownloadClick = { vm.downloadT5Model() }
            )
            Text("\uD83D\uDCDA Library", fontWeight = FontWeight.Bold, fontSize = 16.sp)
            Spacer(Modifier.height(8.dp))
            val mdCount = remember(notes) { notes.count { it.fileType != "pdf" } }
            val pdfCount = remember(notes) { notes.count { it.fileType == "pdf" } }
            Text(
                buildString {
                    append("Indexed: ${notes.size} files")
                    if (pdfCount > 0) append("  (\uD83D\uDCC4 $mdCount md · \uD83D\uDCD5 $pdfCount pdf)")
                },
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                fontSize = 13.sp
            )
            if (progress.running) {
                Spacer(Modifier.height(8.dp))
                LinearProgressIndicator(Modifier.fillMaxWidth())
                Text(
                    "\u23F3 ${progress.phase} ${progress.done} / ${progress.total}",
                    fontSize = 12.sp,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
            Spacer(Modifier.height(12.dp))
            Row {
                Button(
                    onClick = { vm.reindex() },
                    enabled = libraryUri != null && !progress.running
                ) { Text("\u21BB  Re-index") }
                Spacer(Modifier.width(12.dp))
                OutlinedButton(
                    onClick = { picker.launch(null) },
                    enabled = !progress.running
                ) { Text("\uD83D\uDCC1 Change folder") }
            }

            Spacer(Modifier.height(28.dp))
            Text("\uD83D\uDD20 Reading font size", fontWeight = FontWeight.Bold, fontSize = 16.sp)
            Slider(
                value = fontScale,
                onValueChange = { vm.setFontScale(it) },
                valueRange = 0.7f..2.0f
            )
            Text("Sample text at current size", fontSize = (16f * fontScale).sp)

            Spacer(Modifier.height(28.dp))
            Text("\uD83C\uDF10 Web imports", fontWeight = FontWeight.Bold, fontSize = 16.sp)
            Spacer(Modifier.height(6.dp))
            Text(
                "When you share a web page to MarkVault, the page is rendered, converted to " +
                    "markdown, and saved to this subfolder of your library. Leave blank to save " +
                    "directly to the library root.",
                fontSize = 12.sp,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
            Spacer(Modifier.height(10.dp))
            val importsSubfolder by vm.importsSubfolder.collectAsStateWithLifecycle()
            var subfolderText by remember(importsSubfolder) {
                mutableStateOf(importsSubfolder)
            }
            OutlinedTextField(
                value = subfolderText,
                onValueChange = { subfolderText = it.filter { ch -> ch != '/' && ch != '\\' } },
                singleLine = true,
                modifier = Modifier.fillMaxWidth(),
                placeholder = { Text("e.g. Web Clippings") },
                label = { Text("Import subfolder") }
            )
            Spacer(Modifier.height(8.dp))
            Row {
                Button(
                    onClick = { vm.setImportsSubfolder(subfolderText.trim()) },
                    enabled = subfolderText != importsSubfolder
                ) { Text("Save folder name") }
                Spacer(Modifier.width(12.dp))
                OutlinedButton(onClick = { picker.launch(null) }) {
                    Text("\uD83D\uDD13 Re-grant library access")
                }
            }
            Spacer(Modifier.height(4.dp))
            Text(
                "If web imports fail with a read-only error, tap " +
                    "\u201CRe-grant library access\u201D and pick the same library folder again \u2014 " +
                    "this upgrades read-only permission to read+write.",
                fontSize = 11.sp,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )

            // v5.4.109cc — Dedup section. Each signal has its own toggle so
            // the user can diagnose over-eager skipping ("1000 selected,
            // 980 skipped") by flipping one leg off and re-running the
            // batch to see what the URL leg vs the title leg contributes
            // to the skip count.
            Spacer(Modifier.height(28.dp))
            Text(
                "\uD83E\uDDF9 Duplicate detection",
                fontWeight = FontWeight.Bold, fontSize = 16.sp
            )
            Spacer(Modifier.height(6.dp))
            Text(
                "When you batch-save articles from the WebViewer, MarkVault checks whether each " +
                    "one is already in your library and skips duplicates. These toggles control " +
                    "WHICH signals count as a duplicate. Turning either off widens the net — " +
                    "articles that MarkVault would have skipped will be re-fetched and saved as " +
                    "new copies.",
                fontSize = 12.sp,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
            Spacer(Modifier.height(14.dp))

            // ── Toggle 1: URL match ──────────────────────────────────
            val dedupByUrl by vm.dedupByUrl.collectAsStateWithLifecycle()
            Row(
                Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column(Modifier.weight(1f)) {
                    Text(
                        "\uD83D\uDD17 URL match",
                        fontSize = 14.sp, fontWeight = FontWeight.Medium
                    )
                    Text(
                        "Skip an article if its source URL (canonicalised \u2014 " +
                            "fragment stripped, trailing slash trimmed, host lower-cased) " +
                            "matches a URL already stored for a library note. The URL cache " +
                            "is backfilled from every markdown / HTML note on launch, so this " +
                            "catches cross-format duplicates.",
                        fontSize = 11.sp,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
                Spacer(Modifier.width(12.dp))
                Switch(
                    checked = dedupByUrl,
                    onCheckedChange = { vm.setDedupByUrl(it) }
                )
            }

            Spacer(Modifier.height(18.dp))

            // ── Toggle 2: Title / heading match ───────────────────────
            val dedupByTitle by vm.dedupByTitle.collectAsStateWithLifecycle()
            Row(
                Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column(Modifier.weight(1f)) {
                    Text(
                        "\uD83D\uDCDD Title / heading match",
                        fontSize = 14.sp, fontWeight = FontWeight.Medium
                    )
                    Text(
                        "Skip an article if the anchor / heading text captured on the head " +
                            "page (lower-cased, punctuation stripped) exactly matches the " +
                            "title of a note already in the library. Only fires for titles " +
                            "of 15+ normalised characters so generic labels like \u201CRead " +
                            "more\u201D never trigger it. If your \u201C980 of 1000 " +
                            "skipped\u201D count feels wrong, turn this off first \u2014 the " +
                            "URL leg alone is usually enough for jw.org content.",
                        fontSize = 11.sp,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
                Spacer(Modifier.width(12.dp))
                Switch(
                    checked = dedupByTitle,
                    onCheckedChange = { vm.setDedupByTitle(it) }
                )
            }

            Spacer(Modifier.height(12.dp))
            Text(
                "\u2139\uFE0F Both defaults are ON. Filenames are NOT used as a signal " +
                    "\u2014 series like \u201CQuestions From Readers\u201D share a base " +
                    "filename and would false-positive every article after the first.",
                fontSize = 11.sp,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )

            // v5.4.111cc — Search chip visibility. Lets the user hide any
            // of the five chips under the search bar to declutter it.
            Spacer(Modifier.height(28.dp))
            Text(
                "\uD83D\uDD0D Search bar chips",
                fontWeight = FontWeight.Bold, fontSize = 16.sp
            )
            Spacer(Modifier.height(6.dp))
            Text(
                "Choose which quick-toggle chips appear under the search bar. Hiding a chip " +
                    "doesn't change what it did \u2014 it just removes the button. The " +
                    "corresponding setting keeps whatever value it had; you can still change " +
                    "it here or by re-showing the chip.",
                fontSize = 12.sp,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
            Spacer(Modifier.height(14.dp))

            val cSemantic by vm.chipSemantic.collectAsStateWithLifecycle()
            SearchChipToggleRow(
                "\uD83E\uDDE0 Semantic",
                "The semantic search on/off chip.",
                cSemantic
            ) { vm.setChipSemantic(it) }

            Spacer(Modifier.height(14.dp))
            val cRerank by vm.chipRerank.collectAsStateWithLifecycle()
            SearchChipToggleRow(
                "\uD83C\uDFAF Rerank",
                "The reranker on/off chip (or \u201CInstall rerank\u201D when the model " +
                    "isn't downloaded yet).",
                cRerank
            ) { vm.setChipRerank(it) }

            Spacer(Modifier.height(14.dp))
            val cRerankPct by vm.chipRerankPct.collectAsStateWithLifecycle()
            SearchChipToggleRow(
                "Rerank %",
                "The chip that toggles the live reranking-progress percentage indicator.",
                cRerankPct
            ) { vm.setChipRerankPct(it) }

            Spacer(Modifier.height(14.dp))
            val cSemanticPct by vm.chipSemanticPct.collectAsStateWithLifecycle()
            SearchChipToggleRow(
                "Semantic %",
                "The chip that toggles the live semantic-search progress percentage indicator.",
                cSemanticPct
            ) { vm.setChipSemanticPct(it) }

            Spacer(Modifier.height(14.dp))
            val cAccurate by vm.chipAccurate.collectAsStateWithLifecycle()
            SearchChipToggleRow(
                "\u2705 Get accurate results",
                "The exact-phrase chip (renamed \u201CGet accurate results\u201D). Flashes " +
                    "green after each search so you know results are ready.",
                cAccurate
            ) { vm.setChipAccurate(it) }

            Spacer(Modifier.height(28.dp))
            Text("\u26A1 Performance", fontWeight = FontWeight.Bold, fontSize = 16.sp)
            Spacer(Modifier.height(6.dp))
            Text(
                "Heavy visual features are off by default for snappy scrolling on every " +
                    "device. If you're on a higher-end phone, switch them on for the full " +
                    "experience.",
                fontSize = 12.sp,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
            Spacer(Modifier.height(14.dp))

            // ── Smart styling on all documents ──
            val smartStylingAllDocs by vm.smartStylingAllDocs.collectAsStateWithLifecycle()
            Row(
                Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column(Modifier.weight(1f)) {
                    Text(
                        "\uD83C\uDFA8 Smart styling on all documents",
                        fontSize = 14.sp, fontWeight = FontWeight.Medium
                    )
                    Text(
                        "Auto-colourize numbers, references, percentages, quoted phrases " +
                            "and ALL-CAPS terms even in very long articles. May make " +
                            "scrolling stutter on 60,000+ character files.",
                        fontSize = 11.sp,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
                Spacer(Modifier.width(12.dp))
                Switch(
                    checked = smartStylingAllDocs,
                    onCheckedChange = { vm.setSmartStylingAllDocs(it) }
                )
            }

            Spacer(Modifier.height(18.dp))

            // ── Swipe to switch tabs ──
            val swipeSwitchTabs by vm.swipeSwitchTabs.collectAsStateWithLifecycle()
            Row(
                Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column(Modifier.weight(1f)) {
                    Text(
                        "\uD83D\uDC48\uD83D\uDC49 Swipe to switch tabs",
                        fontSize = 14.sp, fontWeight = FontWeight.Medium
                    )
                    Text(
                        "Horizontal swipe in the markdown reader jumps to the previous / " +
                            "next open tab. Adds touch-event interception that can mildly " +
                            "slow scrolling. Toolbar \u2190 \u2192 buttons are always available.",
                        fontSize = 11.sp,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
                Spacer(Modifier.width(12.dp))
                Switch(
                    checked = swipeSwitchTabs,
                    onCheckedChange = { vm.setSwipeSwitchTabs(it) }
                )
            }

            // v5.4.82cc — In-app WebViewer popup master switch.
            // v5.4.83cc — Corrected routing: off means "still in-app
            // WebView, but full-screen instead of bottom sheet" — not
            // "hand to system browser".
            // v5.4.84cc — Description rewritten to reference the
            // sibling full-screen toggle below; both toggles together
            // form a truth table over the two in-app viewer modes.
            Spacer(Modifier.height(14.dp))
            val webPopupOn by vm.webViewerPopupEnabled.collectAsStateWithLifecycle()
            Row(
                Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column(Modifier.weight(1f)) {
                    Text(
                        "\uD83C\uDF10 In-app WebViewer popup",
                        fontSize = 14.sp, fontWeight = FontWeight.Medium
                    )
                    Text(
                        "When on, tapping a link opens the in-app WebView " +
                            "as a bottom-sheet popup that overlays your " +
                            "current article. When off, the popup is " +
                            "skipped and the link goes straight to " +
                            "whatever the full-screen toggle below " +
                            "allows (in-app full-screen if it's on, " +
                            "system browser if it's off).",
                        fontSize = 11.sp,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
                Spacer(Modifier.width(12.dp))
                Switch(
                    checked = webPopupOn,
                    onCheckedChange = { vm.setWebViewerPopupEnabled(it) }
                )
            }

            // v5.4.84cc — Sibling toggle for the in-app WebViewer's
            // full-screen mode. Together with the popup toggle above
            // this gives independent control over both in-app viewer
            // modes; when both are off, tapped links go to the system
            // browser.
            Spacer(Modifier.height(14.dp))
            val webFullScreenOn by vm.webViewerFullScreenEnabled.collectAsStateWithLifecycle()
            Row(
                Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column(Modifier.weight(1f)) {
                    Text(
                        "\uD83D\uDDBC\uFE0F In-app WebViewer full-screen",
                        fontSize = 14.sp, fontWeight = FontWeight.Medium
                    )
                    Text(
                        "When on, the in-app WebView's full-screen mode is " +
                            "available — used directly when the popup " +
                            "toggle above is off, or reached via the " +
                            "\"Full screen\" button inside the popup " +
                            "when it's on. When off, full-screen is " +
                            "disabled: the popup's \"Full screen\" button " +
                            "hands the link to your system browser " +
                            "instead, and if the popup is also off, " +
                            "every link goes straight to the system " +
                            "browser.",
                        fontSize = 11.sp,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
                Spacer(Modifier.width(12.dp))
                Switch(
                    checked = webFullScreenOn,
                    onCheckedChange = { vm.setWebViewerFullScreenEnabled(it) }
                )
            }

            Spacer(Modifier.height(28.dp))
            Text("\uD83C\uDFA8 Appearance", fontWeight = FontWeight.Bold, fontSize = 16.sp)
            Spacer(Modifier.height(6.dp))
            Text(
                "Pick the theme that drives both the article viewer and the app chrome.",
                fontSize = 12.sp,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
            Spacer(Modifier.height(10.dp))
            var themePickerOpen by remember { mutableStateOf(false) }
            val currentTheme by vm.theme.collectAsStateWithLifecycle()
            androidx.compose.material3.OutlinedButton(
                onClick = { themePickerOpen = true },
                modifier = Modifier.fillMaxWidth()
            ) {
                val label = when (currentTheme) {
                    "black"             -> "\u26AB AMOLED black"
                    "sepia"             -> "\uD83D\uDCDC Sepia"
                    "dark_sepia"        -> "\uD83D\uDCDC Dark sepia"
                    "grey"              -> "\u2B1C Grey"
                    "sky_blue"          -> "\uD83C\uDF24 Sky blue"
                    "light_grey"        -> "\uD83E\uDEA8 Light grey"
                    "light"             -> "\u2600\uFE0F Light"
                    "hicontrast-dark"   -> "\u26A1 High-contrast dark"
                    "hicontrast-light"  -> "\u26A1 High-contrast light"
                    "ocean"             -> "\uD83C\uDF0A Ocean"
                    "forest"            -> "\uD83C\uDF32 Forest"
                    "cream"             -> "\uD83E\uDD5B Cream"
                    "expr_indigo"       -> "\uD83D\uDD8B\uFE0F Expressive indigo"
                    "expr_violet"       -> "\uD83D\uDD2E Expressive violet"
                    "expr_ember"        -> "\uD83D\uDD25 Expressive ember"
                    "expr_rose"         -> "\uD83C\uDF39 Expressive rose"
                    else                -> "\uD83C\uDF11 Dark (grey)"
                }
                Text("Theme: $label")
            }
            if (themePickerOpen) {
                ThemePickerDialog(vm, onDismiss = { themePickerOpen = false })
            }

            // ── v5.4.114cc — Expressive motion plugin ──
            Spacer(Modifier.height(18.dp))
            androidx.compose.material3.HorizontalDivider()
            Spacer(Modifier.height(18.dp))
            Text(
                "\u2728 Expressive motion",
                fontWeight = FontWeight.Bold, fontSize = 16.sp
            )
            Spacer(Modifier.height(6.dp))
            Text(
                "Adds spring-based animation to dialogs, menus, and screen changes. " +
                    "Off by default \u2014 turning it off restores the app's normal motion " +
                    "exactly. The Expressive colour themes above work independently of this " +
                    "switch.",
                fontSize = 12.sp,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
            Spacer(Modifier.height(12.dp))
            val motionOn by vm.motionEnabled.collectAsStateWithLifecycle()
            Row(
                Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column(Modifier.weight(1f)) {
                    Text(
                        "Enable expressive motion",
                        fontSize = 14.sp, fontWeight = FontWeight.Medium
                    )
                    Text(
                        if (motionOn) "On \u2014 animated transitions active"
                        else "Off \u2014 default app behaviour",
                        fontSize = 11.sp,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
                Spacer(Modifier.width(12.dp))
                androidx.compose.material3.Switch(
                    checked = motionOn,
                    onCheckedChange = { vm.setMotionEnabled(it) }
                )
            }

            // Profile picker — only meaningful when the plugin is on, so
            // it's disabled (greyed) when off.
            if (motionOn) {
                Spacer(Modifier.height(14.dp))
                val motionProfileName by vm.motionProfile.collectAsStateWithLifecycle()
                Text(
                    "Motion style",
                    fontSize = 13.sp, fontWeight = FontWeight.Medium
                )
                Spacer(Modifier.height(6.dp))
                // Three real profiles (OFF is represented by the master
                // switch, not offered here).
                val profiles = listOf(
                    "EXPRESSIVE" to ("\uD83E\uDD38 Expressive" to "Playful spring with a subtle bounce"),
                    "STANDARD" to ("\u2728 Standard" to "Smooth, clean, no bounce"),
                    "REDUCED" to ("\u26A1 Reduced" to "Near-instant, best for accessibility")
                )
                profiles.forEach { (id, labelPair) ->
                    val (label, desc) = labelPair
                    Row(
                        Modifier.fillMaxWidth()
                            .clickable { vm.setMotionProfile(id) }
                            .padding(vertical = 6.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        androidx.compose.material3.RadioButton(
                            selected = motionProfileName == id,
                            onClick = { vm.setMotionProfile(id) }
                        )
                        Spacer(Modifier.width(8.dp))
                        Column {
                            Text(label, fontSize = 14.sp,
                                fontWeight = if (motionProfileName == id)
                                    FontWeight.SemiBold else FontWeight.Normal)
                            Text(desc, fontSize = 11.sp,
                                color = MaterialTheme.colorScheme.onSurfaceVariant)
                        }
                    }
                }
            }

            Spacer(Modifier.height(18.dp))
            // ── Text contrast slider ──
            val contrast by vm.textContrast.collectAsStateWithLifecycle()
            Text(
                "\uD83D\uDD06 Text contrast \u00B7 ${"%.2f".format(contrast)}\u00D7",
                fontSize = 14.sp, fontWeight = FontWeight.Medium
            )
            Text(
                "Boost foreground/background contrast for easier reading, especially in " +
                    "light and sepia themes. 1.0\u00D7 = default, 2.0\u00D7 = maximum.",
                fontSize = 11.sp,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
            androidx.compose.material3.Slider(
                value = contrast,
                onValueChange = { vm.setTextContrast(it) },
                valueRange = 1.0f..2.0f,
                steps = 19   // 0.05 steps
            )

            Spacer(Modifier.height(28.dp))
            Text("\uD83C\uDF10 In-app browser", fontWeight = FontWeight.Bold, fontSize = 16.sp)
            Spacer(Modifier.height(6.dp))
            Text(
                "Settings for the WebView that opens jw.org scriptures.",
                fontSize = 12.sp,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
            Spacer(Modifier.height(10.dp))
            androidx.compose.material3.OutlinedButton(
                onClick = { nav.navigate("webHistory") },
                modifier = Modifier.fillMaxWidth()
            ) { Text("\uD83D\uDD52 Open web history") }
            Spacer(Modifier.height(8.dp))
            androidx.compose.material3.OutlinedButton(
                onClick = { nav.navigate("pdfHistory") },
                modifier = Modifier.fillMaxWidth()
            ) { Text("\uD83D\uDCDC Open PDF history") }
            Spacer(Modifier.height(8.dp))
            // v5.4.94cc — Activity log link. Sits alongside the two
            // "Open history" buttons above because that's the mental
            // model — it's where all save-related history lives (batch
            // saves, single-page HTML saves, Markdown conversions).
            androidx.compose.material3.OutlinedButton(
                onClick = { nav.navigate("activity_log") },
                modifier = Modifier.fillMaxWidth()
            ) { Text("\uD83D\uDCCB Open activity log") }
            Spacer(Modifier.height(8.dp))
            // v5.4.131cc — Crash-log viewer. Sits with the other
            // history / diagnostic buttons because it's the same
            // mental model — "somewhere I can go and read what
            // happened before." All logs are stored under
            // filesDir/crash_logs/ by [CrashLogger].
            androidx.compose.material3.OutlinedButton(
                onClick = { nav.navigate("crash_logs") },
                modifier = Modifier.fillMaxWidth()
            ) { Text("\uD83D\uDC1E Open crash logs") }
            Spacer(Modifier.height(8.dp))
            var confirmClearWeb by remember { mutableStateOf(false) }
            androidx.compose.material3.OutlinedButton(
                onClick = { confirmClearWeb = true },
                modifier = Modifier.fillMaxWidth()
            ) { Text("\uD83E\uDDF9 Clear all web history") }
            if (confirmClearWeb) {
                androidx.compose.material3.AlertDialog(
                    onDismissRequest = { confirmClearWeb = false },
                    title = { Text("Clear web history?") },
                    text = { Text("This removes every web-history entry. Browser data on the device is not touched.") },
                    confirmButton = {
                        androidx.compose.material3.Button(onClick = {
                            vm.clearWebHistory()
                            confirmClearWeb = false
                        }) { Text("Clear") }
                    },
                    dismissButton = {
                        androidx.compose.material3.TextButton(onClick = { confirmClearWeb = false }) { Text("Cancel") }
                    }
                )
            }

            Spacer(Modifier.height(28.dp))
            // v5.4.12 — Settings search + categorical layout. Each section
            // composable is unchanged; we just wrap them in collapsible
            // category cards and filter visibility by the search query.
            // Sections that don't match the query are hidden; ones that
            // match are auto-expanded.
            var settingsSearch by remember { mutableStateOf("") }
            androidx.compose.material3.OutlinedTextField(
                value = settingsSearch,
                onValueChange = { settingsSearch = it },
                modifier = Modifier.fillMaxWidth(),
                placeholder = { Text("Search settings\u2026") },
                singleLine = true,
                leadingIcon = {
                    Icon(Icons.Default.Search, contentDescription = null)
                },
                trailingIcon = {
                    if (settingsSearch.isNotEmpty()) {
                        IconButton(onClick = { settingsSearch = "" }) {
                            Icon(Icons.Default.Close, contentDescription = "Clear search")
                        }
                    }
                }
            )
            Spacer(Modifier.height(16.dp))

            CollapsibleCategory(
                emoji = "\uD83D\uDD0D",
                title = "Search & retrieval",
                description = "Semantic search, reranker, search filters",
                matchTokens = listOf(
                    "semantic", "embedder", "model", "BGE", "vector",
                    "reranker", "cross-encoder", "rerank", "MiniLM",
                    "filter", "keyword", "quote", "phrase"
                ),
                searchQuery = settingsSearch
            ) {
                SemanticSearchSection(vm)
                Spacer(Modifier.height(28.dp))
                RerankerSection(vm)
                Spacer(Modifier.height(28.dp))
                SearchFiltersSection(vm)
            }
            Spacer(Modifier.height(12.dp))

            CollapsibleCategory(
                emoji = "\uD83C\uDFE0",
                title = "Home & navigation",
                description = "Home screen layout, browser tabs",
                matchTokens = listOf(
                    "home", "dashboard", "topic", "card",
                    "tabs", "preview", "orientation", "browser",
                    "links", "new tab", "same tab", "offline"
                ),
                searchQuery = settingsSearch
            ) {
                HomeScreenSection(vm)
                Spacer(Modifier.height(28.dp))
                BrowserTabsSection(vm)
            }
            Spacer(Modifier.height(12.dp))

            CollapsibleCategory(
                emoji = "\u26A1",
                title = "Performance & diagnostics",
                description = "Memory, live search, crash investigation toggles",
                matchTokens = listOf(
                    "memory", "RAM", "free", "release", "PSS",
                    "diagnostic", "crash", "live search", "submit",
                    "cancel", "highlight", "highlighting", "mode"
                ),
                searchQuery = settingsSearch
            ) {
                MemorySection(vm)
                Spacer(Modifier.height(28.dp))
                DiagnosticsSection(vm, nav)
            }
            Spacer(Modifier.height(12.dp))

            CollapsibleCategory(
                emoji = "\uD83D\uDCAC",
                title = "AI chat (RAG)",
                description = "On-device chat model — opt-in, large download",
                matchTokens = listOf(
                    "chat", "LLM", "RAG", "AI", "assistant",
                    "gemma", "qwen", "llama", "model"
                ),
                searchQuery = settingsSearch
            ) {
                OnDeviceChatSection(vm)
            }
            Spacer(Modifier.height(12.dp))

            CollapsibleCategory(
                emoji = "\u2139\uFE0F",
                title = "About",
                description = "Version & feature summary",
                matchTokens = listOf("about", "version", "info"),
                searchQuery = settingsSearch
            ) {
                Text(
                    "MarkVault ${com.tebogo.markvault.BuildConfig.VERSION_NAME}\n" +
                        "\u2022 Offline Markdown + PDF knowledge system.\n" +
                        "\u2022 In-app jw.org browser with history.\n" +
                        "\u2022 Auto-grouped topics, dashboard, concept search.\n" +
                        "\u2022 On-device semantic search with switchable models.\n" +
                        "\u2022 Your notes never leave this phone. \uD83D\uDCDA",
                    fontSize = 13.sp,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
        }
    }
}

/**
 * Settings UI for the semantic-search foundation. Three controls:
 *
 *   • Status line — "Model not downloaded" / "Downloading…X%" / "Model ready"
 *   • Action button — Download model OR Build embeddings (whichever's next)
 *   • Secondary action — Clear embeddings (only shown when there are any)
 *
 * Kept intentionally self-contained at the bottom of SettingsScreen.kt so it
 * can be moved into its own file later without ceremony. The composable does
 * not depend on any other Settings helpers, only on AppViewModel's public
 * state flows ([modelAvailable], [modelDownloadProgress], [embeddingCount],
 * [embeddingProgress]) and four methods.
 */
@androidx.compose.runtime.Composable
private fun SemanticSearchSection(vm: com.tebogo.markvault.AppViewModel) {
    val modelReady by vm.modelAvailable.collectAsStateWithLifecycle()
    val downloadProgress by vm.modelDownloadProgress.collectAsStateWithLifecycle()
    val embedCount by vm.embeddingCount.collectAsStateWithLifecycle()
    val embedProgress by vm.embeddingProgress.collectAsStateWithLifecycle()
    // v4.9.0 — toggle / active-model / update-check state
    val semanticOn by vm.semanticEnabled.collectAsStateWithLifecycle()
    val autoCheck by vm.autoCheckModelUpdates.collectAsStateWithLifecycle()
    val activeId by vm.activeModelId.collectAsStateWithLifecycle()
    val updateStatus by vm.modelUpdateStatus.collectAsStateWithLifecycle()
    val activeDescriptor = vm.availableModels.firstOrNull { it.id == activeId }
        ?: vm.availableModels.firstOrNull()

    Text(
        "\uD83E\uDDE0 Semantic search (experimental)",
        fontWeight = androidx.compose.ui.text.font.FontWeight.Bold,
        fontSize = 16.sp
    )
    androidx.compose.foundation.layout.Spacer(
        androidx.compose.ui.Modifier.height(6.dp)
    )
    Text(
        "On-device meaning-based ranking. Downloads a ~25MB language model once, " +
            "then embeds every note in your library so similar phrasings match even " +
            "when wording differs. All processing stays on this phone.",
        fontSize = 13.sp,
        color = androidx.compose.material3.MaterialTheme.colorScheme.onSurfaceVariant,
        lineHeight = 18.sp
    )
    androidx.compose.foundation.layout.Spacer(
        androidx.compose.ui.Modifier.height(14.dp)
    )

    // ── v4.9.0 — Master on/off switch ───────────────────────────────────────
    androidx.compose.foundation.layout.Row(
        modifier = androidx.compose.ui.Modifier.fillMaxWidth(),
        verticalAlignment = androidx.compose.ui.Alignment.CenterVertically
    ) {
        androidx.compose.foundation.layout.Column(
            androidx.compose.ui.Modifier.weight(1f)
        ) {
            Text(
                "Use semantic search",
                fontWeight = androidx.compose.ui.text.font.FontWeight.Medium,
                fontSize = 14.sp
            )
            Text(
                "When off, results use only keyword + synonym + fuzzy matching.",
                fontSize = 11.sp,
                color = androidx.compose.material3.MaterialTheme.colorScheme.onSurfaceVariant,
                lineHeight = 15.sp
            )
        }
        androidx.compose.material3.Switch(
            checked = semanticOn,
            onCheckedChange = { vm.setSemanticEnabled(it) }
        )
    }
    androidx.compose.foundation.layout.Spacer(
        androidx.compose.ui.Modifier.height(14.dp)
    )

    // ── v5.4.76cc — AI multi-query retrieval (LLM query expansion) ─────────
    //
    // Off by default. When the user turns this on AND an LLM model is
    // installed (Settings → On-device chat), each *submitted*
    // search runs the query through the LLM to produce a small set of
    // paraphrased sub-queries, folds their hits into the merged result
    // set, and paints an "✨ AI" chip plus lavender highlight on the
    // rows and words the LLM surfaced. Live-typing keystrokes still
    // bypass the model — only submits pay the ~10-15 s cold-load cost,
    // and repeat queries hit the in-memory expansion cache instantly.
    val aiLlmOn by vm.aiLlmSearchEnabled.collectAsStateWithLifecycle()
    androidx.compose.foundation.layout.Row(
        modifier = androidx.compose.ui.Modifier.fillMaxWidth(),
        verticalAlignment = androidx.compose.ui.Alignment.CenterVertically
    ) {
        androidx.compose.foundation.layout.Column(
            androidx.compose.ui.Modifier.weight(1f)
        ) {
            Text(
                "\u2728 AI multi-query retrieval (LLM)",
                fontWeight = androidx.compose.ui.text.font.FontWeight.Medium,
                fontSize = 14.sp
            )
            Text(
                "Uses the on-device LLM to expand your query into " +
                    "paraphrases for broader semantic recall. Adds a light " +
                    "lavender highlight on results and inside articles for " +
                    "words the LLM surfaced. Runs only on submit; live typing " +
                    "stays fast. Requires the model to be installed.",
                fontSize = 11.sp,
                color = androidx.compose.material3.MaterialTheme.colorScheme.onSurfaceVariant,
                lineHeight = 15.sp
            )
        }
        androidx.compose.material3.Switch(
            checked = aiLlmOn,
            onCheckedChange = { vm.setAiLlmSearchEnabled(it) }
        )
    }
    androidx.compose.foundation.layout.Spacer(
        androidx.compose.ui.Modifier.height(10.dp)
    )

    // ── v5.4.79cc — Model picker for LLM query expansion ─────────────────
    //
    // Two-way radio between the safe default (SmolLM2 135M, ~350 MB
    // peak RAM) and the higher-quality option (Qwen3-4B, ~1.6 GB peak
    // RAM). Writes the choice into `chatActiveModelId` — the same
    // preference the download UI and `LlmQueryExpander` read, so
    // switching here immediately routes the next submit through the
    // chosen model. Model still needs to be *installed* separately in
    // the "On-device model" section below.
    val activeIdForPicker by vm.chatActiveModelId.collectAsStateWithLifecycle()
    Text(
        "LLM used for query expansion",
        fontWeight = androidx.compose.ui.text.font.FontWeight.Medium,
        fontSize = 13.sp
    )
    androidx.compose.foundation.layout.Spacer(
        androidx.compose.ui.Modifier.height(6.dp)
    )
    for (model in com.tebogo.markvault.llm.ChatModelCatalog.all) {
        androidx.compose.foundation.layout.Row(
            modifier = androidx.compose.ui.Modifier
                .fillMaxWidth()
                .clickable { vm.setChatActiveModelId(model.id) }
                .padding(vertical = 6.dp),
            verticalAlignment = androidx.compose.ui.Alignment.CenterVertically
        ) {
            androidx.compose.material3.RadioButton(
                selected = activeIdForPicker == model.id,
                onClick = { vm.setChatActiveModelId(model.id) }
            )
            androidx.compose.foundation.layout.Spacer(
                androidx.compose.ui.Modifier.width(6.dp)
            )
            androidx.compose.foundation.layout.Column(
                androidx.compose.ui.Modifier.weight(1f)
            ) {
                Text(
                    model.displayName,
                    fontSize = 13.sp,
                    fontWeight = androidx.compose.ui.text.font.FontWeight.Medium
                )
                Text(
                    "~${model.approxSizeMb} MB on disk   \u2022   ~${model.approxRamMb} MB peak RAM",
                    fontSize = 11.sp,
                    color = androidx.compose.material3.MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
        }
    }
    androidx.compose.foundation.layout.Spacer(
        androidx.compose.ui.Modifier.height(10.dp)
    )

    // ── v5.4.79cc — Memory-safety belt toggle ────────────────────────────
    val memoryOptOn by vm.memoryOptimizedLlm.collectAsStateWithLifecycle()
    androidx.compose.foundation.layout.Row(
        modifier = androidx.compose.ui.Modifier.fillMaxWidth(),
        verticalAlignment = androidx.compose.ui.Alignment.CenterVertically
    ) {
        androidx.compose.foundation.layout.Column(
            androidx.compose.ui.Modifier.weight(1f)
        ) {
            Text(
                "\uD83D\uDEE1\uFE0F Memory optimization",
                fontWeight = androidx.compose.ui.text.font.FontWeight.Medium,
                fontSize = 14.sp
            )
            Text(
                "When on, the expander checks free RAM before loading a " +
                    "model and skips the expansion for a query if the " +
                    "device would run out of headroom. Also uses a " +
                    "tighter 5-second timeout on inference. Prevents the " +
                    "OOM crash that could happen with the heavier " +
                    "Qwen3-4B on lower-RAM devices. Recommended on.",
                fontSize = 11.sp,
                color = androidx.compose.material3.MaterialTheme.colorScheme.onSurfaceVariant,
                lineHeight = 15.sp
            )
        }
        androidx.compose.material3.Switch(
            checked = memoryOptOn,
            onCheckedChange = { vm.setMemoryOptimizedLlm(it) }
        )
    }
    androidx.compose.foundation.layout.Spacer(
        androidx.compose.ui.Modifier.height(14.dp)
    )

    // ── v4.9.1 — Models picker ──────────────────────────────────────────────
    // Lists every catalog entry. The currently-active one is highlighted; any
    // other enabled entry is tappable to switch. Disabled entries (e.g.
    // upcoming MiniLM) are rendered greyed out with a "coming soon" tag.
    Text(
        "Models",
        fontWeight = androidx.compose.ui.text.font.FontWeight.Medium,
        fontSize = 14.sp
    )
    androidx.compose.foundation.layout.Spacer(
        androidx.compose.ui.Modifier.height(6.dp)
    )
    for (model in vm.availableModels) {
        val isActive = model.id == activeId
        val isClickable = model.enabled && !isActive
        val rowModifier = if (isClickable) {
            androidx.compose.ui.Modifier
                .fillMaxWidth()
                .clickable(onClick = { vm.setActiveModelId(model.id) })
                .padding(vertical = 6.dp)
        } else {
            androidx.compose.ui.Modifier
                .fillMaxWidth()
                .padding(vertical = 6.dp)
        }
        androidx.compose.foundation.layout.Row(
            modifier = rowModifier,
            verticalAlignment = androidx.compose.ui.Alignment.CenterVertically
        ) {
            // Radio-like marker
            Text(
                when {
                    isActive -> "\uD83D\uDFE2"           // green dot for active
                    !model.enabled -> "\u23F3"           // hourglass for coming-soon
                    else -> "\u26AA"                       // white circle for selectable
                },
                fontSize = 14.sp
            )
            androidx.compose.foundation.layout.Spacer(
                androidx.compose.ui.Modifier.width(10.dp)
            )
            androidx.compose.foundation.layout.Column(
                androidx.compose.ui.Modifier.weight(1f)
            ) {
                val titleColor = when {
                    isActive -> androidx.compose.material3.MaterialTheme.colorScheme.primary
                    !model.enabled -> androidx.compose.material3.MaterialTheme.colorScheme.onSurfaceVariant
                    else -> androidx.compose.material3.MaterialTheme.colorScheme.onSurface
                }
                Text(
                    if (model.enabled) model.displayName
                    else "${model.displayName}  \u2022  coming soon",
                    fontSize = 13.sp,
                    fontWeight = if (isActive) androidx.compose.ui.text.font.FontWeight.SemiBold
                    else androidx.compose.ui.text.font.FontWeight.Normal,
                    color = titleColor
                )
                Text(
                    model.description,
                    fontSize = 11.sp,
                    color = androidx.compose.material3.MaterialTheme.colorScheme.onSurfaceVariant,
                    lineHeight = 15.sp
                )
            }
        }
    }
    androidx.compose.foundation.layout.Spacer(
        androidx.compose.ui.Modifier.height(10.dp)
    )

    // ── v4.9.0 — Check for newer model ──────────────────────────────────────
    androidx.compose.material3.OutlinedButton(
        onClick = { vm.checkForModelUpdates() },
        modifier = androidx.compose.ui.Modifier.fillMaxWidth()
    ) {
        Text("Check for newer model")
    }
    if (!updateStatus.isNullOrBlank()) {
        androidx.compose.foundation.layout.Spacer(
            androidx.compose.ui.Modifier.height(4.dp)
        )
        Text(
            updateStatus ?: "",
            fontSize = 12.sp,
            color = androidx.compose.material3.MaterialTheme.colorScheme.primary
        )
    }
    androidx.compose.foundation.layout.Spacer(
        androidx.compose.ui.Modifier.height(8.dp)
    )

    // Auto-check on launch
    androidx.compose.foundation.layout.Row(
        modifier = androidx.compose.ui.Modifier.fillMaxWidth(),
        verticalAlignment = androidx.compose.ui.Alignment.CenterVertically
    ) {
        androidx.compose.foundation.layout.Column(
            androidx.compose.ui.Modifier.weight(1f)
        ) {
            Text(
                "Check automatically on launch",
                fontWeight = androidx.compose.ui.text.font.FontWeight.Medium,
                fontSize = 14.sp
            )
            Text(
                "Quietly looks for newer models when the app starts.",
                fontSize = 11.sp,
                color = androidx.compose.material3.MaterialTheme.colorScheme.onSurfaceVariant,
                lineHeight = 15.sp
            )
        }
        androidx.compose.material3.Switch(
            checked = autoCheck,
            onCheckedChange = { vm.setAutoCheckModelUpdates(it) }
        )
    }
    androidx.compose.foundation.layout.Spacer(
        androidx.compose.ui.Modifier.height(14.dp)
    )

    // ── Status line ─────────────────────────────────────────────────────
    val statusLine = when {
        downloadProgress != null -> {
            val pct = ((downloadProgress ?: 0f) * 100).toInt()
            "\u23F3 Downloading model\u2026 $pct%"
        }
        embedProgress != null -> {
            val (done, total) = embedProgress!!
            // v4.8.1 — (0, 0) is the "preparing" sentinel emitted before the
            // COUNT query has finished. Avoid the "0 / 0 (0%)" weirdness.
            if (total == 0) "\u23F3 Preparing\u2026 (counting notes)"
            else {
                val pct = (done * 100 / total)
                "\u23F3 Embedding library\u2026 $done / $total ($pct%)"
            }
        }
        !modelReady -> "\u26AB Model not downloaded"
        embedCount == 0 -> "\u2705 Model ready \u2014 no embeddings built yet"
        else -> "\u2705 Model ready \u2014 $embedCount note${if (embedCount == 1) "" else "s"} embedded"
    }
    Text(
        statusLine,
        fontSize = 13.sp,
        fontWeight = androidx.compose.ui.text.font.FontWeight.Medium,
        color = androidx.compose.material3.MaterialTheme.colorScheme.primary
    )

    androidx.compose.foundation.layout.Spacer(
        androidx.compose.ui.Modifier.height(10.dp)
    )

    // ── Primary action button ───────────────────────────────────────────
    when {
        downloadProgress != null || embedProgress != null -> {
            // Show a linear progress bar while either pass is running.
            // v4.8.1 — when embedding progress is the (0, 0) "preparing"
            // sentinel, use an indeterminate (animated) bar so the user sees
            // motion even before the COUNT query has finished.
            val isPreparing = embedProgress?.let { it.second == 0 } == true
            if (isPreparing) {
                androidx.compose.material3.LinearProgressIndicator(
                    modifier = androidx.compose.ui.Modifier.fillMaxWidth()
                )
            } else {
                val frac = downloadProgress
                    ?: (embedProgress?.let {
                        val (d, t) = it; if (t > 0) d.toFloat() / t else 0f
                    } ?: 0f)
                androidx.compose.material3.LinearProgressIndicator(
                    progress = { frac },
                    modifier = androidx.compose.ui.Modifier.fillMaxWidth()
                )
            }
        }
        !modelReady -> {
            // v4.9.1 — single-step install: tap once, the model downloads
            // AND embeddings start automatically when the download finishes.
            // Replaces the two-button "Download" → "Build" workflow.
            androidx.compose.material3.Button(
                onClick = { vm.installModel() },
                modifier = androidx.compose.ui.Modifier.fillMaxWidth()
            ) {
                val mb = activeDescriptor?.approxSizeMb ?: 25
                Text("Install model (~${mb} MB)")
            }
        }
        embedCount == 0 -> {
            // Model is downloaded but no embeddings yet — surface the embed
            // pass directly. Equivalent to the second phase of installModel().
            androidx.compose.material3.Button(
                onClick = { vm.buildAllEmbeddings() },
                modifier = androidx.compose.ui.Modifier.fillMaxWidth()
            ) {
                Text("Build embeddings")
            }
        }
        else -> {
            androidx.compose.material3.Button(
                onClick = { vm.buildAllEmbeddings() },
                modifier = androidx.compose.ui.Modifier.fillMaxWidth()
            ) {
                Text("Re-embed updated notes")
            }
        }
    }

    // ── Secondary action: clear embeddings ──────────────────────────────
    if (embedCount > 0 && embedProgress == null) {
        androidx.compose.foundation.layout.Spacer(
            androidx.compose.ui.Modifier.height(6.dp)
        )
        androidx.compose.material3.OutlinedButton(
            onClick = { vm.clearAllEmbeddings() },
            modifier = androidx.compose.ui.Modifier.fillMaxWidth()
        ) {
            Text("Clear embeddings")
        }
    }

    // ── Footnote ────────────────────────────────────────────────────────
    androidx.compose.foundation.layout.Spacer(
        androidx.compose.ui.Modifier.height(8.dp)
    )
    Text(
        "\u2705 Search integration is active. When you type in the search bar, " +
            "results are ranked using both keyword matches AND meaning-based " +
            "similarity from these embeddings. Try searching with different " +
            "wording than what's in your articles to see it in action.",
        fontSize = 11.sp,
        color = androidx.compose.material3.MaterialTheme.colorScheme.onSurfaceVariant,
        lineHeight = 15.sp
    )
}

/**
 * v4.21.0 — Settings UI for the on-device chat LLM (RAG over your library).
 *
 * Shows:
 *   • A description of what chat does
 *   • Status line — "Not installed" / "Downloading X% (Y / Z MB)" / "Installed"
 *   • Install / Delete / Cancel button depending on state
 *   • Three future-behaviour toggles (install flow, location, history mode)
 *
 * v4.21.0 is Settings-only — the toggles persist but don't yet change
 * behaviour. v4.22.x adds the chat screen UI that consumes them.
 */
/**
 * v5.4.72 — Settings UI for the on-device chat LLM (RAG over your library).
 *
 * ## Download state machine
 *
 *   IDLE       → Install button
 *   DOWNLOAD   → progress bar + ⏸ Pause   +  ✕ Cancel buttons
 *   PAUSED     → progress bar (frozen) + ▶ Resume + ✕ Cancel buttons
 *   ERROR      → error text + ↩ Retry (auto-resumes .part) + Start fresh link
 *   INSTALLED  → Delete button
 */
@androidx.compose.runtime.Composable
private fun OnDeviceChatSection(vm: com.tebogo.markvault.AppViewModel) {
    val installed   by vm.chatModelInstalled.collectAsStateWithLifecycle()
    val progress    by vm.chatDownloadProgress.collectAsStateWithLifecycle()
    val running     by vm.chatDownloadRunning.collectAsStateWithLifecycle()
    val paused      by vm.chatDownloadPaused.collectAsStateWithLifecycle()
    val lastError   by vm.chatDownloadError.collectAsStateWithLifecycle()
    val installFlow by vm.chatInstallFlowPref.collectAsStateWithLifecycle()
    val location    by vm.chatLocationPref.collectAsStateWithLifecycle()
    val historyMode by vm.chatHistoryModePref.collectAsStateWithLifecycle()
    val loadMode    by vm.chatModelLoadModePref.collectAsStateWithLifecycle()
    val activeChatId by vm.chatActiveModelId.collectAsStateWithLifecycle()
    val descriptor = vm.availableChatModels.firstOrNull { it.id == activeChatId }
        ?: vm.availableChatModels.firstOrNull()

    Text(
        "\uD83D\uDCAC On-device chat (preview)",
        fontWeight = androidx.compose.ui.text.font.FontWeight.Bold,
        fontSize = 16.sp
    )
    androidx.compose.foundation.layout.Spacer(
        androidx.compose.ui.Modifier.height(6.dp)
    )
    Text(
        "Ask questions about your library and get a synthesised answer " +
            "with citations to the notes used. Runs entirely on this phone — " +
            "your notes never leave the device. Quality depends on the small " +
            "model used; best for lookup and drafting, not deep reasoning.",
        fontSize = 13.sp,
        color = androidx.compose.material3.MaterialTheme.colorScheme.onSurfaceVariant,
        lineHeight = 18.sp
    )
    androidx.compose.foundation.layout.Spacer(
        androidx.compose.ui.Modifier.height(14.dp)
    )

    // ── Model card ──────────────────────────────────────────────────────
    if (descriptor != null) {
        Text(
            descriptor.displayName,
            fontWeight = androidx.compose.ui.text.font.FontWeight.SemiBold,
            fontSize = 14.sp
        )
        androidx.compose.foundation.layout.Spacer(
            androidx.compose.ui.Modifier.height(4.dp)
        )
        Text(
            descriptor.description,
            fontSize = 12.sp,
            color = androidx.compose.material3.MaterialTheme.colorScheme.onSurfaceVariant,
            lineHeight = 16.sp
        )
        androidx.compose.foundation.layout.Spacer(
            androidx.compose.ui.Modifier.height(6.dp)
        )
        Text(
            "Download: ~${descriptor.approxSizeMb} MB   •   " +
                "RAM when active: ~${descriptor.approxRamMb} MB",
            fontSize = 11.sp,
            color = androidx.compose.material3.MaterialTheme.colorScheme.onSurfaceVariant
        )
    }

    androidx.compose.foundation.layout.Spacer(
        androidx.compose.ui.Modifier.height(12.dp)
    )

    // ── Status line ─────────────────────────────────────────────────────
    val statusText: String = when {
        running && progress != null -> {
            val (doneMb, totalMb) = progress!!
            val pct = if (totalMb > 0) (doneMb * 100 / totalMb).coerceIn(0, 100) else 0
            "Downloading: $doneMb / $totalMb MB  ($pct%)"
        }
        running  -> "Connecting\u2026"
        paused && progress != null -> {
            val (doneMb, totalMb) = progress!!
            val pct = if (totalMb > 0) (doneMb * 100 / totalMb).coerceIn(0, 100) else 0
            "\u23F8\uFE0F Paused at $doneMb / $totalMb MB ($pct%) \u2014 tap Resume to continue"
        }
        paused   -> "\u23F8\uFE0F Paused \u2014 tap Resume to continue"
        installed -> "\u2705 Installed and ready"
        lastError != null -> "\u26A0\uFE0F  ${lastError}"
        else -> "Not installed"
    }
    Text(
        statusText,
        fontSize = 13.sp,
        color = androidx.compose.material3.MaterialTheme.colorScheme.onSurface
    )

    // Progress bar: visible while downloading OR while paused (frozen).
    val showProgress = (running || paused) && progress != null
    if (showProgress) {
        val (doneMb, totalMb) = progress!!
        androidx.compose.foundation.layout.Spacer(
            androidx.compose.ui.Modifier.height(6.dp)
        )
        androidx.compose.material3.LinearProgressIndicator(
            progress = {
                if (totalMb > 0) (doneMb.toFloat() / totalMb.toFloat()) else 0f
            },
            modifier = androidx.compose.ui.Modifier.fillMaxWidth()
        )
    }
    androidx.compose.foundation.layout.Spacer(
        androidx.compose.ui.Modifier.height(12.dp)
    )

    // ── Primary actions ─────────────────────────────────────────────────
    when {
        running -> {
            // Active download: Pause + Cancel side by side.
            androidx.compose.foundation.layout.Row(
                modifier = androidx.compose.ui.Modifier.fillMaxWidth(),
                horizontalArrangement = androidx.compose.foundation.layout.Arrangement.spacedBy(8.dp)
            ) {
                androidx.compose.material3.Button(
                    onClick  = { vm.pauseChatModelDownload() },
                    modifier = androidx.compose.ui.Modifier.weight(1f)
                ) {
                    Text("\u23F8 Pause")
                }
                OutlinedButton(
                    onClick  = { vm.cancelChatModelDownload() },
                    modifier = androidx.compose.ui.Modifier.weight(1f)
                ) {
                    Text("\u2715 Cancel")
                }
            }
        }

        paused -> {
            // Paused: Resume + Cancel side by side.
            androidx.compose.foundation.layout.Row(
                modifier = androidx.compose.ui.Modifier.fillMaxWidth(),
                horizontalArrangement = androidx.compose.foundation.layout.Arrangement.spacedBy(8.dp)
            ) {
                androidx.compose.material3.Button(
                    onClick = {
                        vm.downloadChatModel()   // auto-resumes via .part file
                    },
                    modifier = androidx.compose.ui.Modifier.weight(1f)
                ) {
                    Text("\u25B6 Resume")
                }
                OutlinedButton(
                    onClick  = { vm.cancelChatModelDownload() },
                    modifier = androidx.compose.ui.Modifier.weight(1f)
                ) {
                    Text("\u2715 Cancel")
                }
            }
        }

        installed -> {
            OutlinedButton(
                onClick  = { vm.deleteChatModel() },
                modifier = androidx.compose.ui.Modifier.fillMaxWidth()
            ) {
                Text("Delete model (frees ~${descriptor?.approxSizeMb ?: 0} MB)")
            }
        }

        lastError != null -> {
            // Error state: Retry (auto-resumes .part) + Start fresh.
            androidx.compose.material3.Button(
                onClick = {
                    vm.clearChatDownloadError()
                    vm.downloadChatModel()   // downloader auto-resumes .part if present
                },
                modifier = androidx.compose.ui.Modifier.fillMaxWidth()
            ) {
                Text("\u21A9 Retry download")
            }
            androidx.compose.foundation.layout.Spacer(
                androidx.compose.ui.Modifier.height(6.dp)
            )
            androidx.compose.material3.TextButton(
                onClick = {
                    vm.clearChatDownloadError()
                    vm.cancelChatModelDownload()   // deletes .part → next retry is fresh
                },
                modifier = androidx.compose.ui.Modifier.fillMaxWidth()
            ) {
                Text("Start fresh (discard partial download)")
            }
        }

        else -> {
            // Idle / not installed.
            androidx.compose.material3.Button(
                onClick = {
                    vm.clearChatDownloadError()
                    vm.downloadChatModel()
                },
                modifier = androidx.compose.ui.Modifier.fillMaxWidth()
            ) {
                Text("Install model (~${descriptor?.approxSizeMb ?: 0} MB)")
            }
        }
    }

    androidx.compose.foundation.layout.Spacer(
        androidx.compose.ui.Modifier.height(20.dp)
    )

    // ── Behaviour toggles (stored only in v4.21.0) ─────────────────────
    Text(
        "Behaviour (revisit anytime)",
        fontWeight = androidx.compose.ui.text.font.FontWeight.SemiBold,
        fontSize = 13.sp
    )
    androidx.compose.foundation.layout.Spacer(
        androidx.compose.ui.Modifier.height(4.dp)
    )
    Text(
        "These choose how chat will work once the chat screen lands in a " +
            "later update. They're saved now so you can change your mind " +
            "without losing the model download.",
        fontSize = 11.sp,
        color = androidx.compose.material3.MaterialTheme.colorScheme.onSurfaceVariant,
        lineHeight = 15.sp
    )
    androidx.compose.foundation.layout.Spacer(
        androidx.compose.ui.Modifier.height(10.dp)
    )

    ChatPickerRow(
        label   = "Model install",
        current = installFlow,
        options = listOf(
            "opt_in"       to "Opt-in (tap Install)",
            "auto_prompt"  to "Prompt on first chat"
        ),
        onSelect = { vm.setChatInstallFlowPref(it) }
    )
    androidx.compose.foundation.layout.Spacer(
        androidx.compose.ui.Modifier.height(8.dp)
    )
    ChatPickerRow(
        label   = "Where chat lives",
        current = location,
        options = listOf(
            "own_screen" to "Own screen (menu)",
            "in_search" to "Inside Search"
        ),
        onSelect = { vm.setChatLocationPref(it) }
    )
    androidx.compose.foundation.layout.Spacer(
        androidx.compose.ui.Modifier.height(8.dp)
    )
    ChatPickerRow(
        label = "Conversation memory",
        current = historyMode,
        options = listOf(
            "fresh_per_q" to "Fresh each question",
            "multi_turn" to "Multi-turn within session"
        ),
        onSelect = { vm.setChatHistoryModePref(it) }
    )
    androidx.compose.foundation.layout.Spacer(
        androidx.compose.ui.Modifier.height(8.dp)
    )
    ChatPickerRow(
        label = "When to load the model",
        current = loadMode,
        options = listOf(
            "on_open" to "When chat opens (default)",
            "preload" to "Always loaded (more RAM, instant)",
            "on_first_q" to "On first question (input ready early)"
        ),
        onSelect = { vm.setChatModelLoadModePref(it) }
    )
}

/**
 * Small reusable row that opens a dialog with the available options as
 * radio buttons. Used for the three chat behaviour toggles.
 */
@androidx.compose.runtime.Composable
private fun ChatPickerRow(
    label: String,
    current: String,
    options: List<Pair<String, String>>,  // id → display
    onSelect: (String) -> Unit
) {
    var dialogOpen by androidx.compose.runtime.remember { androidx.compose.runtime.mutableStateOf(false) }
    val currentDisplay = options.firstOrNull { it.first == current }?.second
        ?: options.firstOrNull()?.second ?: current
    OutlinedButton(
        onClick = { dialogOpen = true },
        modifier = androidx.compose.ui.Modifier.fillMaxWidth()
    ) {
        androidx.compose.foundation.layout.Column(
            androidx.compose.ui.Modifier.fillMaxWidth()
        ) {
            Text(label, fontSize = 12.sp,
                color = androidx.compose.material3.MaterialTheme.colorScheme.onSurfaceVariant)
            Text(currentDisplay, fontSize = 14.sp,
                fontWeight = androidx.compose.ui.text.font.FontWeight.SemiBold)
        }
    }
    if (dialogOpen) {
        androidx.compose.material3.AlertDialog(
            onDismissRequest = { dialogOpen = false },
            title = { Text(label) },
            text = {
                androidx.compose.foundation.layout.Column {
                    options.forEach { (id, display) ->
                        androidx.compose.foundation.layout.Row(
                            modifier = androidx.compose.ui.Modifier
                                .fillMaxWidth()
                                .padding(vertical = 8.dp),
                            verticalAlignment = androidx.compose.ui.Alignment.CenterVertically
                        ) {
                            androidx.compose.material3.RadioButton(
                                selected = (id == current),
                                onClick = {
                                    onSelect(id)
                                    dialogOpen = false
                                }
                            )
                            androidx.compose.foundation.layout.Spacer(
                                androidx.compose.ui.Modifier.width(8.dp)
                            )
                            Text(display, fontSize = 14.sp)
                        }
                    }
                }
            },
            confirmButton = {
                androidx.compose.material3.TextButton(onClick = { dialogOpen = false }) {
                    Text("Close")
                }
            }
        )
    }
}

/**
 * v4.23.0 — Settings card for the reranker (cross-encoder).
 *
 * Shows:
 *   • Description of what reranking does
 *   • Install / Delete / Cancel button depending on state
 *   • Progress bar during download
 *   • Toggle to enable/disable reranking once installed
 */
@androidx.compose.runtime.Composable
private fun RerankerSection(vm: com.tebogo.markvault.AppViewModel) {
    val installed by vm.rerankerInstalled.collectAsStateWithLifecycle()
    val progress by vm.rerankerDownloadProgress.collectAsStateWithLifecycle()
    val downloading by vm.rerankerDownloading.collectAsStateWithLifecycle()
    val lastError by vm.rerankerDownloadError.collectAsStateWithLifecycle()
    val rerankEnabled by vm.rerankEnabled.collectAsStateWithLifecycle()
    val descriptor by vm.rerankerDescriptor.collectAsStateWithLifecycle()
    val selectedModelId by vm.rerankerModelId.collectAsStateWithLifecycle()

    Text(
        "\uD83C\uDFAF Smart reranking (recommended)",
        fontWeight = androidx.compose.ui.text.font.FontWeight.Bold,
        fontSize = 16.sp
    )
    androidx.compose.foundation.layout.Spacer(
        androidx.compose.ui.Modifier.height(6.dp)
    )
    Text(
        "Adds a second-stage ranking pass after semantic search. Instead " +
            "of just matching meaning, the cross-encoder reads each candidate " +
            "article alongside your question and judges whether it actually " +
            "ANSWERS the question. The model runs entirely on this phone.",
        fontSize = 13.sp,
        color = androidx.compose.material3.MaterialTheme.colorScheme.onSurfaceVariant,
        lineHeight = 18.sp
    )
    androidx.compose.foundation.layout.Spacer(
        androidx.compose.ui.Modifier.height(14.dp)
    )

    // v5.4.6 — Model picker. Two options today: L-12 (quality) and
    // L-6 (memory-friendly). User can switch at runtime; selection
    // persists across launches. Each option must be downloaded
    // separately the first time.
    Text(
        "Model",
        fontSize = 12.sp,
        fontWeight = androidx.compose.ui.text.font.FontWeight.SemiBold,
        color = androidx.compose.material3.MaterialTheme.colorScheme.onSurfaceVariant
    )
    androidx.compose.foundation.layout.Spacer(
        androidx.compose.ui.Modifier.height(4.dp)
    )
    androidx.compose.foundation.layout.Column(
        verticalArrangement = androidx.compose.foundation.layout.Arrangement.spacedBy(4.dp)
    ) {
        for (desc in com.tebogo.markvault.search.RerankerCatalog.all) {
            val isSelected = desc.id == selectedModelId
            val isInstalled = desc.isInstalled(
                androidx.compose.ui.platform.LocalContext.current.filesDir
            )
            androidx.compose.foundation.layout.Row(
                modifier = androidx.compose.ui.Modifier
                    .fillMaxWidth()
                    .clickable { vm.setRerankerModelId(desc.id) }
                    .padding(vertical = 4.dp),
                verticalAlignment = androidx.compose.ui.Alignment.CenterVertically
            ) {
                androidx.compose.material3.RadioButton(
                    selected = isSelected,
                    onClick = { vm.setRerankerModelId(desc.id) }
                )
                androidx.compose.foundation.layout.Column(
                    modifier = androidx.compose.ui.Modifier.weight(1f)
                ) {
                    androidx.compose.foundation.layout.Row(
                        verticalAlignment = androidx.compose.ui.Alignment.CenterVertically
                    ) {
                        Text(
                            desc.shortName,
                            fontSize = 13.sp,
                            fontWeight = androidx.compose.ui.text.font.FontWeight.Medium
                        )
                        if (isInstalled) {
                            androidx.compose.foundation.layout.Spacer(
                                androidx.compose.ui.Modifier.width(6.dp)
                            )
                            Text(
                                "✓ installed",
                                fontSize = 10.sp,
                                color = androidx.compose.material3.MaterialTheme.colorScheme.primary
                            )
                        }
                    }
                    Text(
                        "~${desc.approxSizeMb} MB download • ~${desc.approxRamMb} MB RAM",
                        fontSize = 11.sp,
                        color = androidx.compose.material3.MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }
        }
    }
    androidx.compose.foundation.layout.Spacer(
        androidx.compose.ui.Modifier.height(12.dp)
    )

    Text(
        descriptor.displayName,
        fontWeight = androidx.compose.ui.text.font.FontWeight.SemiBold,
        fontSize = 14.sp
    )
    androidx.compose.foundation.layout.Spacer(
        androidx.compose.ui.Modifier.height(4.dp)
    )
    Text(
        descriptor.description,
        fontSize = 12.sp,
        color = androidx.compose.material3.MaterialTheme.colorScheme.onSurfaceVariant,
        lineHeight = 16.sp
    )
    androidx.compose.foundation.layout.Spacer(
        androidx.compose.ui.Modifier.height(6.dp)
    )
    Text(
        "Download: ~${descriptor.approxSizeMb} MB   •   " +
            "RAM when active: ~${descriptor.approxRamMb} MB",
        fontSize = 11.sp,
        color = androidx.compose.material3.MaterialTheme.colorScheme.onSurfaceVariant
    )
    androidx.compose.foundation.layout.Spacer(
        androidx.compose.ui.Modifier.height(12.dp)
    )

    // Status line
    val statusText: String = when {
        downloading && progress != null -> {
            val mb = (progress!! * descriptor.approxSizeMb).toInt()
            val pct = (progress!! * 100).toInt().coerceIn(0, 100)
            "Downloading: $mb / ${descriptor.approxSizeMb} MB  ($pct%)"
        }
        downloading -> "Connecting…"
        installed -> "\u2705 Installed and ready"
        lastError != null -> "\u26A0\uFE0F  ${lastError}"
        else -> "Not installed"
    }
    Text(
        statusText,
        fontSize = 13.sp,
        color = androidx.compose.material3.MaterialTheme.colorScheme.onSurface
    )
    if (downloading && progress != null) {
        androidx.compose.foundation.layout.Spacer(
            androidx.compose.ui.Modifier.height(6.dp)
        )
        androidx.compose.material3.LinearProgressIndicator(
            progress = { progress!! },
            modifier = androidx.compose.ui.Modifier.fillMaxWidth()
        )
    }
    androidx.compose.foundation.layout.Spacer(
        androidx.compose.ui.Modifier.height(12.dp)
    )

    // Primary action
    if (downloading) {
        OutlinedButton(
            onClick = { vm.stopRerankerDownload() },
            modifier = androidx.compose.ui.Modifier.fillMaxWidth()
        ) { Text("Cancel download") }
    } else if (installed) {
        OutlinedButton(
            onClick = { vm.deleteReranker() },
            modifier = androidx.compose.ui.Modifier.fillMaxWidth()
        ) {
            Text("Delete reranker (frees ~${descriptor.approxSizeMb} MB)")
        }
    } else {
        androidx.compose.material3.Button(
            onClick = {
                vm.clearRerankerError()
                vm.downloadReranker()
            },
            modifier = androidx.compose.ui.Modifier.fillMaxWidth()
        ) {
            Text("Install reranker (~${descriptor.approxSizeMb} MB)")
        }
    }

    if (lastError != null && !downloading) {
        androidx.compose.foundation.layout.Spacer(
            androidx.compose.ui.Modifier.height(6.dp)
        )
        androidx.compose.material3.TextButton(
            onClick = { vm.clearRerankerError() }
        ) { Text("Dismiss error") }
    }

    // Once installed: the on/off toggle
    if (installed) {
        androidx.compose.foundation.layout.Spacer(
            androidx.compose.ui.Modifier.height(14.dp)
        )
        androidx.compose.foundation.layout.Row(
            modifier = androidx.compose.ui.Modifier.fillMaxWidth(),
            verticalAlignment = androidx.compose.ui.Alignment.CenterVertically
        ) {
            androidx.compose.foundation.layout.Column(
                androidx.compose.ui.Modifier.weight(1f)
            ) {
                Text(
                    "Use reranking for searches",
                    fontWeight = androidx.compose.ui.text.font.FontWeight.SemiBold,
                    fontSize = 14.sp
                )
                Text(
                    if (rerankEnabled) "ON — adds 3–5 s per search for better results"
                    else "OFF — fast cosine ranking only",
                    fontSize = 11.sp,
                    color = androidx.compose.material3.MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
            androidx.compose.material3.Switch(
                checked = rerankEnabled,
                onCheckedChange = { vm.setRerankEnabled(it) }
            )
        }
    }
}

/**
 * v5.2.0 — Settings card for Home-screen-specific options.
 *
 * Currently just the recent-searches count (0–20). Slider is overkill
 * for one value, so a row of +/− buttons around the current number is
 * used instead — easier to fine-tune on a phone screen.
 */
@androidx.compose.runtime.Composable
private fun HomeScreenSection(vm: com.tebogo.markvault.AppViewModel) {
    val current by vm.maxRecentSearchesOnHome.collectAsStateWithLifecycle()
    Text(
        "\uD83C\uDFE0  Home screen",
        fontWeight = androidx.compose.ui.text.font.FontWeight.Bold,
        fontSize = 16.sp
    )
    androidx.compose.foundation.layout.Spacer(
        androidx.compose.ui.Modifier.height(6.dp)
    )
    Text(
        "How many recent search queries to show under the home-page search bar. " +
            "Tap one to re-run it. Set to 0 to hide the list entirely.",
        fontSize = 13.sp,
        color = androidx.compose.material3.MaterialTheme.colorScheme.onSurfaceVariant,
        lineHeight = 18.sp
    )
    androidx.compose.foundation.layout.Spacer(
        androidx.compose.ui.Modifier.height(12.dp)
    )
    androidx.compose.foundation.layout.Row(
        modifier = androidx.compose.ui.Modifier.fillMaxWidth(),
        verticalAlignment = androidx.compose.ui.Alignment.CenterVertically
    ) {
        Text(
            "Recent search entries",
            fontSize = 14.sp,
            modifier = androidx.compose.ui.Modifier.weight(1f)
        )
        OutlinedButton(
            onClick = { vm.setMaxRecentSearchesOnHome((current - 1).coerceAtLeast(0)) },
            enabled = current > 0
        ) { Text("\u2212") }
        androidx.compose.foundation.layout.Spacer(
            androidx.compose.ui.Modifier.width(12.dp)
        )
        Text(
            "$current",
            fontSize = 18.sp,
            fontWeight = androidx.compose.ui.text.font.FontWeight.Bold,
            modifier = androidx.compose.ui.Modifier.widthIn(min = 28.dp),
            textAlign = androidx.compose.ui.text.style.TextAlign.Center
        )
        androidx.compose.foundation.layout.Spacer(
            androidx.compose.ui.Modifier.width(12.dp)
        )
        OutlinedButton(
            onClick = { vm.setMaxRecentSearchesOnHome((current + 1).coerceAtMost(20)) },
            enabled = current < 20
        ) { Text("+") }
    }

    // v5.4.36 — Home-screen scroll direction toggle.
    androidx.compose.foundation.layout.Spacer(
        androidx.compose.ui.Modifier.height(20.dp)
    )
    androidx.compose.material3.HorizontalDivider()
    androidx.compose.foundation.layout.Spacer(
        androidx.compose.ui.Modifier.height(16.dp)
    )
    Text(
        "Article rows scroll direction",
        fontSize = 14.sp,
        fontWeight = androidx.compose.ui.text.font.FontWeight.SemiBold
    )
    androidx.compose.foundation.layout.Spacer(
        androidx.compose.ui.Modifier.height(4.dp)
    )
    Text(
        "Favourites, Continue reading, New in library, and Suggested " +
            "sections can scroll horizontally (default) or vertically.",
        fontSize = 12.sp,
        color = androidx.compose.material3.MaterialTheme.colorScheme.onSurfaceVariant,
        lineHeight = 16.sp
    )
    androidx.compose.foundation.layout.Spacer(
        androidx.compose.ui.Modifier.height(10.dp)
    )
    val homeVert by vm.homeScrollVertical.collectAsStateWithLifecycle()
    androidx.compose.foundation.layout.Row(
        modifier = androidx.compose.ui.Modifier.fillMaxWidth(),
        horizontalArrangement = androidx.compose.foundation.layout.Arrangement.spacedBy(8.dp)
    ) {
        androidx.compose.material3.FilterChip(
            selected = !homeVert,
            onClick = { vm.setHomeScrollVertical(false) },
            label = { Text("\u2194\uFE0F  Horizontal") },
            modifier = androidx.compose.ui.Modifier.weight(1f)
        )
        androidx.compose.material3.FilterChip(
            selected = homeVert,
            onClick = { vm.setHomeScrollVertical(true) },
            label = { Text("\u2195\uFE0F  Vertical") },
            modifier = androidx.compose.ui.Modifier.weight(1f)
        )
    }

    /**
     * v5.4.20 — UI mode picker. Standard (default) keeps the current
     * minimalist reader look — tab strip only shows when there are 2+
     * open tabs. Workspace makes the tab strip persistent with a "+"
     * button for opening new tabs from any article.
     */
    androidx.compose.foundation.layout.Spacer(
        androidx.compose.ui.Modifier.height(24.dp)
    )
    androidx.compose.material3.HorizontalDivider()
    androidx.compose.foundation.layout.Spacer(
        androidx.compose.ui.Modifier.height(16.dp)
    )
    Text(
        "UI mode",
        fontSize = 14.sp,
        fontWeight = androidx.compose.ui.text.font.FontWeight.SemiBold
    )
    androidx.compose.foundation.layout.Spacer(
        androidx.compose.ui.Modifier.height(4.dp)
    )
    Text(
        "Standard = current minimalist look. Workspace = persistent tab " +
            "strip with a + button for opening new tabs from any reader. " +
            "Every other feature works identically in both modes.",
        fontSize = 12.sp,
        color = androidx.compose.material3.MaterialTheme.colorScheme.onSurfaceVariant,
        lineHeight = 16.sp
    )
    androidx.compose.foundation.layout.Spacer(
        androidx.compose.ui.Modifier.height(10.dp)
    )
    val uiMode by vm.uiMode.collectAsStateWithLifecycle()
    val modeOptions = listOf(
        Triple("standard",  "\uD83D\uDCF1  Standard",
            "Reader is one screen at a time. Tab strip appears only with 2+ open tabs."),
        Triple("workspace", "\uD83E\uDDF0  Workspace",
            "Tab strip always visible with a + button to open new tabs. Everything else unchanged."),
    )
    androidx.compose.foundation.layout.Column(
        modifier = androidx.compose.ui.Modifier.fillMaxWidth()
    ) {
        for ((id, label, desc) in modeOptions) {
            val selected = id == uiMode
            androidx.compose.foundation.layout.Row(
                modifier = androidx.compose.ui.Modifier
                    .fillMaxWidth()
                    .clickable { vm.setUiMode(id) }
                    .padding(vertical = 4.dp),
                verticalAlignment = androidx.compose.ui.Alignment.Top
            ) {
                androidx.compose.material3.RadioButton(
                    selected = selected,
                    onClick = { vm.setUiMode(id) }
                )
                androidx.compose.foundation.layout.Spacer(
                    androidx.compose.ui.Modifier.width(4.dp)
                )
                androidx.compose.foundation.layout.Column(
                    modifier = androidx.compose.ui.Modifier
                        .weight(1f)
                        .padding(top = 12.dp)
                ) {
                    Text(
                        label,
                        fontSize = 13.sp,
                        fontWeight = androidx.compose.ui.text.font.FontWeight.Medium
                    )
                    Text(
                        desc,
                        fontSize = 11.sp,
                        color = androidx.compose.material3.MaterialTheme.colorScheme.onSurfaceVariant,
                        lineHeight = 14.sp
                    )
                }
            }
        }
    }
}

/**
 * v5.3.0 — Settings card for browser-tab preview options.
 *
 * Currently just orientation. "Vertical" (default) shows tab cards in a
 * scrolling 2-column grid — best for many tabs. "Horizontal" shows the
 * cards as a side-swipeable row — best for browsing a few tabs visually.
 */
@androidx.compose.runtime.Composable
private fun BrowserTabsSection(vm: com.tebogo.markvault.AppViewModel) {
    val current by vm.tabsPreviewOrientation.collectAsStateWithLifecycle()
    Text(
        "\uD83D\uDDC2  Browser tabs",
        fontWeight = androidx.compose.ui.text.font.FontWeight.Bold,
        fontSize = 16.sp
    )
    androidx.compose.foundation.layout.Spacer(
        androidx.compose.ui.Modifier.height(6.dp)
    )
    Text(
        "How the floating tabs button shows your open browser tabs when " +
            "you tap it. Vertical lists tabs as a 2-column scrolling grid. " +
            "Horizontal shows one tall card at a time, swipe left/right.",
        fontSize = 13.sp,
        color = androidx.compose.material3.MaterialTheme.colorScheme.onSurfaceVariant,
        lineHeight = 18.sp
    )
    androidx.compose.foundation.layout.Spacer(
        androidx.compose.ui.Modifier.height(12.dp)
    )
    androidx.compose.foundation.layout.Row(
        modifier = androidx.compose.ui.Modifier.fillMaxWidth(),
        horizontalArrangement = androidx.compose.foundation.layout.Arrangement.spacedBy(8.dp)
    ) {
        androidx.compose.material3.FilterChip(
            selected = current == "vertical",
            onClick = { vm.setTabsPreviewOrientation("vertical") },
            label = { Text("\u2630  Vertical grid") },
            modifier = androidx.compose.ui.Modifier.weight(1f)
        )
        androidx.compose.material3.FilterChip(
            selected = current == "horizontal",
            onClick = { vm.setTabsPreviewOrientation("horizontal") },
            label = { Text("\u21E2  Horizontal swipe") },
            modifier = androidx.compose.ui.Modifier.weight(1f)
        )
    }

    // v5.4.13 — Link long-press action picker. Lives here under
    // "Browser tabs" because it only affects the in-app browser's
    // long-press behaviour, never the library-screen long-press
    // (which has its own separate menu).
    androidx.compose.foundation.layout.Spacer(
        androidx.compose.ui.Modifier.height(20.dp)
    )
    androidx.compose.material3.HorizontalDivider()
    androidx.compose.foundation.layout.Spacer(
        androidx.compose.ui.Modifier.height(16.dp)
    )
    Text(
        "Long-press a link in the browser",
        fontSize = 14.sp,
        fontWeight = androidx.compose.ui.text.font.FontWeight.SemiBold
    )
    androidx.compose.foundation.layout.Spacer(
        androidx.compose.ui.Modifier.height(4.dp)
    )
    Text(
        "What happens when you press and hold a link in the in-app " +
            "browser. The library screen's long-press menu is separate.",
        fontSize = 12.sp,
        color = androidx.compose.material3.MaterialTheme.colorScheme.onSurfaceVariant,
        lineHeight = 16.sp
    )
    androidx.compose.foundation.layout.Spacer(
        androidx.compose.ui.Modifier.height(10.dp)
    )
    val lpAction by vm.linkLongPressAction.collectAsStateWithLifecycle()
    val lpOptions = listOf(
        Triple("menu",     "Show menu",
            "Default. Sheet with copy, open in new tab, convert to MD, convert to PDF."),
        Triple("markdown", "Convert to Markdown",
            "Skip the menu. Long-press converts the link to a Markdown article."),
        Triple("pdf",      "Convert to PDF",
            "Skip the menu. Long-press converts the link to a PDF."),
    )
    androidx.compose.foundation.layout.Column(
        modifier = androidx.compose.ui.Modifier.fillMaxWidth()
    ) {
        for ((id, label, desc) in lpOptions) {
            val selected = id == lpAction
            androidx.compose.foundation.layout.Row(
                modifier = androidx.compose.ui.Modifier
                    .fillMaxWidth()
                    .clickable { vm.setLinkLongPressAction(id) }
                    .padding(vertical = 4.dp),
                verticalAlignment = androidx.compose.ui.Alignment.Top
            ) {
                androidx.compose.material3.RadioButton(
                    selected = selected,
                    onClick = { vm.setLinkLongPressAction(id) }
                )
                androidx.compose.foundation.layout.Spacer(
                    androidx.compose.ui.Modifier.width(4.dp)
                )
                androidx.compose.foundation.layout.Column(
                    modifier = androidx.compose.ui.Modifier
                        .weight(1f)
                        .padding(top = 12.dp)
                ) {
                    Text(
                        label,
                        fontSize = 13.sp,
                        fontWeight = androidx.compose.ui.text.font.FontWeight.Medium
                    )
                    Text(
                        desc,
                        fontSize = 11.sp,
                        color = androidx.compose.material3.MaterialTheme.colorScheme.onSurfaceVariant,
                        lineHeight = 14.sp
                    )
                }
            }
        }
    }

    // v5.4.35 — Link-open mode picker: new tab (default) vs same tab.
    // Controls how external links tapped in offline HTML articles open
    // in the in-app browser.
    androidx.compose.foundation.layout.Spacer(
        androidx.compose.ui.Modifier.height(20.dp)
    )
    androidx.compose.material3.HorizontalDivider()
    androidx.compose.foundation.layout.Spacer(
        androidx.compose.ui.Modifier.height(16.dp)
    )
    Text(
        "Links from offline articles",
        fontSize = 14.sp,
        fontWeight = androidx.compose.ui.text.font.FontWeight.SemiBold
    )
    androidx.compose.foundation.layout.Spacer(
        androidx.compose.ui.Modifier.height(4.dp)
    )
    Text(
        "When you tap a scripture or external link in an offline HTML article, " +
            "should it open in a new browser tab or reuse the current tab?",
        fontSize = 12.sp,
        color = androidx.compose.material3.MaterialTheme.colorScheme.onSurfaceVariant,
        lineHeight = 16.sp
    )
    androidx.compose.foundation.layout.Spacer(
        androidx.compose.ui.Modifier.height(10.dp)
    )
    val newTab by vm.openLinksInNewTab.collectAsStateWithLifecycle()
    androidx.compose.foundation.layout.Row(
        modifier = androidx.compose.ui.Modifier.fillMaxWidth(),
        horizontalArrangement = androidx.compose.foundation.layout.Arrangement.spacedBy(8.dp)
    ) {
        androidx.compose.material3.FilterChip(
            selected = newTab,
            onClick = { vm.setOpenLinksInNewTab(true) },
            label = { Text("\uD83D\uDDC2  New tab") },
            modifier = androidx.compose.ui.Modifier.weight(1f)
        )
        androidx.compose.material3.FilterChip(
            selected = !newTab,
            onClick = { vm.setOpenLinksInNewTab(false) },
            label = { Text("\uD83D\uDD04  Same tab") },
            modifier = androidx.compose.ui.Modifier.weight(1f)
        )
    }
}

/**
 * v5.3.1 — Settings card for search-results filtering.
 *
 * Currently just the keyword filter. When ON (default) and the user's
 * query has 2+ meaningful words (i.e. not stopwords), each shown
 * result must contain at least 2 distinct meaningful query words.
 * Cuts noise from single-word matches that happen to share one common
 * term with the query.
 *
 * Turning the filter OFF shows every keyword + semantic hit — useful
 * when the user wants to see semantic-only matches that don't share
 * literal vocabulary with the query.
 */
@androidx.compose.runtime.Composable
private fun SearchFiltersSection(vm: com.tebogo.markvault.AppViewModel) {
    val on by vm.keywordFilterEnabled.collectAsStateWithLifecycle()
    Text(
        "\uD83E\uDDF9  Search filters",
        fontWeight = androidx.compose.ui.text.font.FontWeight.Bold,
        fontSize = 16.sp
    )
    androidx.compose.foundation.layout.Spacer(
        androidx.compose.ui.Modifier.height(6.dp)
    )
    Text(
        "Keyword filter requires search results to contain at least 2 of " +
            "the meaningful words from your query (skipping common words " +
            "like 'the' and 'is'). When OFF, every keyword and semantic " +
            "hit is shown — useful for surfacing semantically-related " +
            "articles that don't share literal vocabulary with the query.",
        fontSize = 13.sp,
        color = androidx.compose.material3.MaterialTheme.colorScheme.onSurfaceVariant,
        lineHeight = 18.sp
    )
    androidx.compose.foundation.layout.Spacer(
        androidx.compose.ui.Modifier.height(12.dp)
    )
    androidx.compose.foundation.layout.Row(
        modifier = androidx.compose.ui.Modifier.fillMaxWidth(),
        verticalAlignment = androidx.compose.ui.Alignment.CenterVertically
    ) {
        Text(
            "Keyword filter",
            fontSize = 14.sp,
            modifier = androidx.compose.ui.Modifier.weight(1f)
        )
        androidx.compose.material3.Switch(
            checked = on,
            onCheckedChange = { vm.setKeywordFilterEnabled(it) }
        )
    }
}

/**
 * v5.4.0 — Memory section.
 *
 * Shows the user a rough estimate of where their RAM is going and
 * gives them a button to release the heaviest holders on demand. The
 * same release happens automatically when the OS signals memory
 * pressure (TRIM_MEMORY_UI_HIDDEN or below); this section is for
 * users who want to free memory explicitly while the app is still in
 * the foreground.
 */
@androidx.compose.runtime.Composable
private fun MemorySection(vm: com.tebogo.markvault.AppViewModel) {
    val ctx = androidx.compose.ui.platform.LocalContext.current
    val rerankerInstalled by vm.rerankerInstalled.collectAsStateWithLifecycle()
    val embeddingCount by vm.embeddingCount.collectAsStateWithLifecycle()
    val semanticEnabled by vm.semanticEnabled.collectAsStateWithLifecycle()

    // Best-effort native + heap estimate. Native ONNX memory isn't
    // reported by Runtime; we estimate based on which models are
    // *loaded* (which we approximate from "installed and toggled on").
    val rt = android.os.Debug.MemoryInfo().also {
        runCatching { android.os.Debug.getMemoryInfo(it) }
    }
    val nativeMb = runCatching { rt.nativePss / 1024 }.getOrDefault(0)
    val javaMb = runCatching { rt.dalvikPss / 1024 }.getOrDefault(0)
    val totalPssMb = runCatching { rt.totalPss / 1024 }.getOrDefault(0)

    Text(
        "\uD83E\uDDE0  Memory",
        fontWeight = androidx.compose.ui.text.font.FontWeight.Bold,
        fontSize = 16.sp
    )
    androidx.compose.foundation.layout.Spacer(
        androidx.compose.ui.Modifier.height(6.dp)
    )
    Text(
        "MarkVault holds the BGE-large embedder (~280 MB native) and " +
            "the cross-encoder reranker (~150 MB native) in RAM while " +
            "you're searching so queries return fast. The semantic " +
            "index of your ${embeddingCount}-note library adds another " +
            "~${(embeddingCount.toLong() * 1024L * 4L / 1024L / 1024L).coerceAtLeast(0L)} MB. " +
            "These models reload lazily on the next search, so freeing " +
            "memory only costs you a slightly slower first query after.",
        fontSize = 13.sp,
        color = androidx.compose.material3.MaterialTheme.colorScheme.onSurfaceVariant,
        lineHeight = 18.sp
    )
    androidx.compose.foundation.layout.Spacer(
        androidx.compose.ui.Modifier.height(12.dp)
    )
    if (totalPssMb > 0) {
        Text(
            "Current usage:  ${totalPssMb} MB total  (${javaMb} MB heap, ${nativeMb} MB native)",
            fontSize = 12.sp,
            color = androidx.compose.material3.MaterialTheme.colorScheme.onSurfaceVariant,
            fontFamily = androidx.compose.ui.text.font.FontFamily.Monospace
        )
        androidx.compose.foundation.layout.Spacer(
            androidx.compose.ui.Modifier.height(10.dp)
        )
    }
    var feedback by androidx.compose.runtime.remember {
        androidx.compose.runtime.mutableStateOf<String?>(null)
    }
    androidx.compose.material3.OutlinedButton(
        onClick = {
            val before = runCatching {
                val mi = android.os.Debug.MemoryInfo()
                android.os.Debug.getMemoryInfo(mi)
                mi.totalPss / 1024
            }.getOrDefault(0)
            vm.freeMemory()
            // Wait a beat for GC then measure again
            android.os.Handler(android.os.Looper.getMainLooper()).postDelayed({
                val after = runCatching {
                    val mi2 = android.os.Debug.MemoryInfo()
                    android.os.Debug.getMemoryInfo(mi2)
                    mi2.totalPss / 1024
                }.getOrDefault(0)
                val freed = (before - after).coerceAtLeast(0)
                feedback = if (before > 0 && after > 0)
                    "Freed ${freed} MB. Models will reload on next search."
                else
                    "Memory released. Models will reload on next search."
            }, 500L)
        },
        modifier = androidx.compose.ui.Modifier.fillMaxWidth()
    ) {
        Text("\uD83E\uDDF9  Free memory now")
    }
    val fb = feedback
    if (fb != null) {
        androidx.compose.foundation.layout.Spacer(
            androidx.compose.ui.Modifier.height(8.dp)
        )
        Text(
            fb,
            fontSize = 12.sp,
            color = androidx.compose.material3.MaterialTheme.colorScheme.primary
        )
    }
}

/**
 * v5.4.1 — Diagnostics section.
 *
 * Three toggles that let the user narrow down the cause of search-time
 * crashes by disabling individual stages of the pipeline. None of them
 * remove a feature outright; each just changes WHEN or WHETHER that
 * piece runs.
 *
 *   • Live search          — debounced typing fires searches (default)
 *                            vs only the search/submit button does.
 *   • Cancel previous      — new keystroke cancels mid-flight search
 *                            (default) vs runs every search to completion.
 *   • Auto-free memory     — onBackground releases ONNX sessions
 *                            (default) vs models stay resident.
 */
@androidx.compose.runtime.Composable
private fun DiagnosticsSection(vm: com.tebogo.markvault.AppViewModel, nav: androidx.navigation.NavController) {
    val live by vm.liveSearchEnabled.collectAsStateWithLifecycle()
    val cancel by vm.cancelInflightSearch.collectAsStateWithLifecycle()
    val autoFree by vm.autoFreeMemory.collectAsStateWithLifecycle()
    val rerankSubmit by vm.rerankOnSubmitOnly.collectAsStateWithLifecycle()
    val highlight by vm.articleHighlightEnabled.collectAsStateWithLifecycle()

    Text(
        "\uD83E\uDDEA  Diagnostics (crash-tracking)",
        fontWeight = androidx.compose.ui.text.font.FontWeight.Bold,
        fontSize = 16.sp
    )
    androidx.compose.foundation.layout.Spacer(
        androidx.compose.ui.Modifier.height(6.dp)
    )
    Text(
        "If searching crashes the app, turn these OFF one at a time to " +
            "find which stage is responsible. Defaults match the normal " +
            "fast-search behaviour; everything off = safest mode but " +
            "needs the 🔍 button or Enter key to actually run.",
        fontSize = 13.sp,
        color = androidx.compose.material3.MaterialTheme.colorScheme.onSurfaceVariant,
        lineHeight = 18.sp
    )
    androidx.compose.foundation.layout.Spacer(
        androidx.compose.ui.Modifier.height(12.dp)
    )
    DiagnosticToggle(
        title = "Rerank on submit only",
        subtitle = "ON (default) = cross-encoder runs only when you tap 🔍 " +
            "or press Enter. OFF = rerank fires on every keystroke (high " +
            "crash risk on memory-constrained devices). Keep ON unless " +
            "you have lots of RAM headroom.",
        checked = rerankSubmit,
        onChange = { vm.setRerankOnSubmitOnly(it) }
    )
    androidx.compose.foundation.layout.Spacer(
        androidx.compose.ui.Modifier.height(8.dp)
    )
    DiagnosticToggle(
        title = "In-article highlighting",
        subtitle = "ON (default) = opened articles highlight sentences " +
            "containing your query terms. OFF = no text-node walking " +
            "runs after you tap a result. Toggle OFF to test if the " +
            "highlight JS is involved in crashes (the walk touches " +
            "every text node in long documents).",
        checked = highlight,
        onChange = { vm.setArticleHighlightEnabled(it) }
    )
    if (highlight) {
        androidx.compose.foundation.layout.Spacer(
            androidx.compose.ui.Modifier.height(10.dp)
        )
        HighlightModePicker(vm)
    }
    androidx.compose.foundation.layout.Spacer(
        androidx.compose.ui.Modifier.height(8.dp)
    )
    DiagnosticToggle(
        title = "Live search",
        subtitle = "Search runs while you type. OFF = only when you tap " +
            "🔍 or press the search key.",
        checked = live,
        onChange = { vm.setLiveSearchEnabled(it) }
    )
    androidx.compose.foundation.layout.Spacer(
        androidx.compose.ui.Modifier.height(8.dp)
    )
    DiagnosticToggle(
        title = "Cancel previous search",
        subtitle = "A new keystroke cancels in-progress search. OFF = " +
            "let every search finish before starting the next.",
        checked = cancel,
        onChange = { vm.setCancelInflightSearch(it) }
    )
    androidx.compose.foundation.layout.Spacer(
        androidx.compose.ui.Modifier.height(8.dp)
    )
    DiagnosticToggle(
        title = "Auto-free memory",
        subtitle = "Release ONNX models when the app goes to background. " +
            "OFF = keep them resident (uses more RAM but no reload cost).",
        checked = autoFree,
        onChange = { vm.setAutoFreeMemory(it) }
    )
    androidx.compose.foundation.layout.Spacer(
        androidx.compose.ui.Modifier.height(8.dp)
    )
    DiagnosticToggle(
        title = "In-article highlighting",
        subtitle = "ON (default) = opened articles highlight sentences " +
            "containing your query terms. OFF = no text-node walk runs " +
            "after navigation. Turn off if you suspect the highlight JS " +
            "is contributing to crashes.",
        checked = highlight,
        onChange = { vm.setArticleHighlightEnabled(it) }
    )
    // v5.4.18 — Four new toggles.
    val showRerankPct by vm.showRerankProgress.collectAsStateWithLifecycle()
    val showSemPct by vm.showSemanticProgress.collectAsStateWithLifecycle()
    val fabOn by vm.searchInArticleFab.collectAsStateWithLifecycle()
    val semArtOn by vm.semanticInArticle.collectAsStateWithLifecycle()
    androidx.compose.foundation.layout.Spacer(
        androidx.compose.ui.Modifier.height(8.dp)
    )
    DiagnosticToggle(
        title = "Rerank % indicator",
        subtitle = "ON (default) = shows the % progress ring in the top bar " +
            "during manual rerank. OFF = silent rerank, no visual feedback.",
        checked = showRerankPct,
        onChange = { vm.setShowRerankProgress(it) }
    )
    androidx.compose.foundation.layout.Spacer(
        androidx.compose.ui.Modifier.height(8.dp)
    )
    DiagnosticToggle(
        title = "Semantic % indicator",
        subtitle = "ON (default) = shows model download / index build / " +
            "load progress bars in Settings and the search bar. OFF = " +
            "everything happens silently.",
        checked = showSemPct,
        onChange = { vm.setShowSemanticProgress(it) }
    )
    androidx.compose.foundation.layout.Spacer(
        androidx.compose.ui.Modifier.height(8.dp)
    )
    // v5.4.33 — Search indicator animation style picker
    run {
        val indicStyle by vm.searchIndicatorStyle.collectAsStateWithLifecycle()
        Text(
            "\uD83C\uDFAC Search indicator style",
            fontSize = 14.sp,
            fontWeight = androidx.compose.ui.text.font.FontWeight.Medium
        )
        Text(
            "Choose what animation shows while searching.",
            fontSize = 12.sp,
            color = androidx.compose.material3.MaterialTheme.colorScheme.onSurfaceVariant,
            lineHeight = 16.sp
        )
        androidx.compose.foundation.layout.Spacer(
            androidx.compose.ui.Modifier.height(4.dp)
        )
        Row(
            horizontalArrangement = androidx.compose.foundation.layout.Arrangement.spacedBy(8.dp)
        ) {
            listOf(
                "percentage" to "\uD83D\uDD03 Percentage",
                "hourglass" to "\u23F3 Hourglass",
                "book" to "\uD83D\uDCD6 Book"
            ).forEach { (key, label) ->
                androidx.compose.material3.FilterChip(
                    selected = indicStyle == key,
                    onClick = { vm.setSearchIndicatorStyle(key) },
                    label = { Text(label, fontSize = 12.sp) }
                )
            }
        }
    }
    androidx.compose.foundation.layout.Spacer(
        androidx.compose.ui.Modifier.height(8.dp)
    )
    DiagnosticToggle(
        title = "\uD83D\uDD0D Find-in-article button",
        subtitle = "ON (default) = floating button appears when you open " +
            "an article from a search result. Tap the button and it " +
            "searches inside the article for the same query — quotes " +
            "stripped. Only shows for search-opened articles.",
        checked = fabOn,
        onChange = { vm.setSearchInArticleFab(it) }
    )
    androidx.compose.foundation.layout.Spacer(
        androidx.compose.ui.Modifier.height(8.dp)
    )
    // v5.4.34 — Duplicate detector link
    androidx.compose.material3.Surface(
        color = androidx.compose.material3.MaterialTheme.colorScheme.surfaceVariant,
        shape = androidx.compose.foundation.shape.RoundedCornerShape(10.dp),
        modifier = Modifier
            .fillMaxWidth()
            .clickable { nav.navigate("duplicates") }
    ) {
        Row(
            Modifier.padding(14.dp),
            verticalAlignment = androidx.compose.ui.Alignment.CenterVertically
        ) {
            Text("\uD83D\uDD0D", fontSize = 24.sp)
            androidx.compose.foundation.layout.Spacer(Modifier.width(12.dp))
            Column(Modifier.weight(1f)) {
                Text(
                    "Duplicate Detector",
                    fontSize = 14.sp,
                    fontWeight = FontWeight.SemiBold
                )
                Text(
                    "Scan your vault for exact-content duplicate articles. " +
                        "Compare side-by-side and safely remove copies.",
                    fontSize = 11.sp,
                    color = androidx.compose.material3.MaterialTheme.colorScheme.onSurfaceVariant,
                    lineHeight = 15.sp
                )
            }
            Text("\u25B6", fontSize = 14.sp)
        }
    }
    androidx.compose.foundation.layout.Spacer(
        androidx.compose.ui.Modifier.height(8.dp)
    )
    DiagnosticToggle(
        title = "\uD83E\uDDE0 Semantic in-article search",
        subtitle = "OFF (default) = find-in-article uses plain keyword " +
            "match. ON = additionally embeds each paragraph with the " +
            "active embedder, cosine-ranks against the query, and " +
            "re-targets the find to the top-matching paragraph. " +
            "Useful for long articles. Costs cycles.",
        checked = semArtOn,
        onChange = { vm.setSemanticInArticle(it) }
    )
    androidx.compose.foundation.layout.Spacer(
        androidx.compose.ui.Modifier.height(12.dp)
    )
    // v5.4.132cc — Stepper: how many top-rated articles the pumping-
    // heart FAB on the Search screen visits when building the multi-
    // article popup. Range 1..10, default 1.
    val popupTopN by vm.popupArticlesTopN.collectAsStateWithLifecycle()
    androidx.compose.foundation.layout.Row(
        modifier = androidx.compose.ui.Modifier.fillMaxWidth(),
        verticalAlignment = androidx.compose.ui.Alignment.CenterVertically
    ) {
        androidx.compose.foundation.layout.Column(
            modifier = androidx.compose.ui.Modifier.weight(1f)
        ) {
            Text(
                "\uD83D\uDC97 Popup articles (top-N)",
                fontSize = 14.sp,
                fontWeight = androidx.compose.ui.text.font.FontWeight.Medium
            )
            Text(
                "How many top-rated search results the pumping-heart " +
                    "button on the Search screen pulls passages from. " +
                    "1 = just the single best hit; 3\u20135 gives a broader " +
                    "\u201Cwhat does the library say about X\u201D snapshot.",
                fontSize = 12.sp,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                modifier = androidx.compose.ui.Modifier.padding(top = 2.dp)
            )
        }
        androidx.compose.foundation.layout.Spacer(
            androidx.compose.ui.Modifier.width(12.dp)
        )
        androidx.compose.material3.OutlinedButton(
            onClick = {
                if (popupTopN > 1) vm.setPopupArticlesTopN(popupTopN - 1)
            },
            enabled = popupTopN > 1,
            contentPadding = androidx.compose.foundation.layout.PaddingValues(
                horizontal = 12.dp, vertical = 4.dp
            )
        ) { Text("\u2212") }
        Text(
            text = popupTopN.toString(),
            fontSize = 15.sp,
            fontWeight = androidx.compose.ui.text.font.FontWeight.SemiBold,
            modifier = androidx.compose.ui.Modifier
                .padding(horizontal = 10.dp)
                .widthIn(min = 20.dp)
        )
        androidx.compose.material3.OutlinedButton(
            onClick = {
                if (popupTopN < 10) vm.setPopupArticlesTopN(popupTopN + 1)
            },
            enabled = popupTopN < 10,
            contentPadding = androidx.compose.foundation.layout.PaddingValues(
                horizontal = 12.dp, vertical = 4.dp
            )
        ) { Text("+") }
    }
}

@androidx.compose.runtime.Composable
private fun DiagnosticToggle(
    title: String,
    subtitle: String,
    checked: Boolean,
    onChange: (Boolean) -> Unit
) {
    androidx.compose.foundation.layout.Row(
        modifier = androidx.compose.ui.Modifier.fillMaxWidth(),
        verticalAlignment = androidx.compose.ui.Alignment.CenterVertically
    ) {
        androidx.compose.foundation.layout.Column(
            modifier = androidx.compose.ui.Modifier.weight(1f)
        ) {
            Text(title, fontSize = 14.sp,
                fontWeight = androidx.compose.ui.text.font.FontWeight.Medium)
            Text(
                subtitle,
                fontSize = 12.sp,
                color = androidx.compose.material3.MaterialTheme.colorScheme.onSurfaceVariant,
                lineHeight = 16.sp
            )
        }
        androidx.compose.foundation.layout.Spacer(
            androidx.compose.ui.Modifier.width(8.dp)
        )
        androidx.compose.material3.Switch(
            checked = checked,
            onCheckedChange = onChange
        )
    }
}

/**
 * v5.4.9 — Highlight mode picker.
 *
 * Three options for how matching content in an opened article gets
 * highlighted:
 *
 *   • Auto    — follows semantic search. When semantic ON, uses
 *               sentence-level "smart" mode. When semantic OFF,
 *               uses word-level "keyword" mode. The recommended
 *               default; matches the user's intuition that
 *               meaning-based highlight should fire only when
 *               meaning-based search is active.
 *
 *   • Smart   — always sentence-level. Skips headings entirely
 *               (no more yellow titles) and requires 2+ distinct
 *               query terms in a body sentence before wrapping it.
 *               Word-level backfill ensures terms in headings or
 *               weakly-matching sentences still get a small mark.
 *
 *   • Keyword — always word-level only. Just wraps exact term
 *               matches anywhere in the article. Minimal visual
 *               noise; useful when you only want to spot the
 *               query words without yellow blocks.
 */
@androidx.compose.runtime.Composable
private fun HighlightModePicker(vm: com.tebogo.markvault.AppViewModel) {
    val mode by vm.highlightMode.collectAsStateWithLifecycle()
    val options = listOf(
        Triple("auto",    "Auto",
            "Follows semantic search — sentence-level when semantic is on, word-level when off."),
        Triple("smart",   "Smart (sentence)",
            "Highlights body sentences with 2+ query terms. Headings get word-level marks. Always on."),
        Triple("keyword", "Keyword (words only)",
            "Just highlights exact matches of query words. No sentence wrapping. Minimal noise."),
    )
    androidx.compose.foundation.layout.Column(
        modifier = androidx.compose.ui.Modifier.fillMaxWidth()
    ) {
        Text(
            "Highlighting style",
            fontSize = 13.sp,
            fontWeight = androidx.compose.ui.text.font.FontWeight.SemiBold,
            color = androidx.compose.material3.MaterialTheme.colorScheme.onSurface
        )
        androidx.compose.foundation.layout.Spacer(
            androidx.compose.ui.Modifier.height(4.dp)
        )
        for ((id, label, desc) in options) {
            val selected = id == mode
            androidx.compose.foundation.layout.Row(
                modifier = androidx.compose.ui.Modifier
                    .fillMaxWidth()
                    .clickable { vm.setHighlightMode(id) }
                    .padding(vertical = 4.dp),
                verticalAlignment = androidx.compose.ui.Alignment.Top
            ) {
                androidx.compose.material3.RadioButton(
                    selected = selected,
                    onClick = { vm.setHighlightMode(id) }
                )
                androidx.compose.foundation.layout.Spacer(
                    androidx.compose.ui.Modifier.width(4.dp)
                )
                androidx.compose.foundation.layout.Column(
                    modifier = androidx.compose.ui.Modifier
                        .weight(1f)
                        .padding(top = 12.dp)
                ) {
                    Text(
                        label,
                        fontSize = 13.sp,
                        fontWeight = androidx.compose.ui.text.font.FontWeight.Medium,
                        color = androidx.compose.material3.MaterialTheme.colorScheme.onSurface
                    )
                    Text(
                        desc,
                        fontSize = 11.sp,
                        color = androidx.compose.material3.MaterialTheme.colorScheme.onSurfaceVariant,
                        lineHeight = 14.sp
                    )
                }
            }
        }
    }
}

/**
 * v5.4.12 — Collapsible settings category wrapper.
 *
 * Wraps a group of related settings sections in a card with a header
 * that's tappable to expand/collapse. When the user types in the
 * settings search bar above, the category checks if its title /
 * description / [matchTokens] contain the query (case-insensitive).
 * If a match → forced expanded, even if the user had collapsed it.
 * If no match while a query is active → the whole category is hidden,
 * reducing visual clutter to just the matching categories.
 *
 * Collapse state is held in `remember` per category title — survives
 * recomposition but resets when the screen is destroyed (acceptable
 * tradeoff for the simpler implementation).
 */
@androidx.compose.runtime.Composable
private fun CollapsibleCategory(
    emoji: String,
    title: String,
    description: String,
    matchTokens: List<String>,
    searchQuery: String,
    initiallyExpanded: Boolean = false,
    content: @androidx.compose.runtime.Composable () -> Unit
) {
    val queryLower = searchQuery.trim().lowercase()
    val isFiltering = queryLower.isNotEmpty()
    val matchesQuery = !isFiltering || run {
        title.lowercase().contains(queryLower) ||
            description.lowercase().contains(queryLower) ||
            matchTokens.any { it.lowercase().contains(queryLower) }
    }
    // Hide the entire category when the user is filtering and there's
    // no match — that's the whole point of search.
    if (isFiltering && !matchesQuery) return

    var userExpanded by androidx.compose.runtime.remember(title) {
        androidx.compose.runtime.mutableStateOf(initiallyExpanded)
    }
    val effectiveExpanded = if (isFiltering) true else userExpanded

    androidx.compose.material3.Surface(
        color = androidx.compose.material3.MaterialTheme.colorScheme.surfaceVariant,
        shape = androidx.compose.foundation.shape.RoundedCornerShape(14.dp),
        tonalElevation = 1.dp,
        modifier = androidx.compose.ui.Modifier.fillMaxWidth()
    ) {
        androidx.compose.foundation.layout.Column(
            modifier = androidx.compose.ui.Modifier.fillMaxWidth()
        ) {
            androidx.compose.foundation.layout.Row(
                modifier = androidx.compose.ui.Modifier
                    .fillMaxWidth()
                    .clickable {
                        // Tapping the header always toggles. When filtering, the
                        // category stays effectively expanded (matchesQuery is true)
                        // but a tap still flips the underlying state so a clear-
                        // search returns it to user-controlled collapse properly.
                        userExpanded = !userExpanded
                    }
                    .padding(horizontal = 16.dp, vertical = 14.dp),
                verticalAlignment = androidx.compose.ui.Alignment.CenterVertically
            ) {
                Text(emoji, fontSize = 22.sp)
                androidx.compose.foundation.layout.Spacer(
                    androidx.compose.ui.Modifier.width(12.dp)
                )
                androidx.compose.foundation.layout.Column(
                    modifier = androidx.compose.ui.Modifier.weight(1f)
                ) {
                    Text(
                        title,
                        fontSize = 15.sp,
                        fontWeight = androidx.compose.ui.text.font.FontWeight.SemiBold,
                        color = androidx.compose.material3.MaterialTheme.colorScheme.onSurface
                    )
                    if (description.isNotBlank()) {
                        androidx.compose.foundation.layout.Spacer(
                            androidx.compose.ui.Modifier.height(2.dp)
                        )
                        Text(
                            description,
                            fontSize = 11.sp,
                            color = androidx.compose.material3.MaterialTheme.colorScheme.onSurfaceVariant,
                            lineHeight = 14.sp
                        )
                    }
                }
                androidx.compose.foundation.layout.Spacer(
                    androidx.compose.ui.Modifier.width(8.dp)
                )
                Text(
                    if (effectiveExpanded) "\u25BE" else "\u25B8",
                    fontSize = 16.sp,
                    color = androidx.compose.material3.MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
            if (effectiveExpanded) {
                androidx.compose.foundation.layout.Column(
                    modifier = androidx.compose.ui.Modifier
                        .fillMaxWidth()
                        .padding(start = 16.dp, end = 16.dp, bottom = 16.dp)
                ) {
                    content()
                }
            }
        }
    }
}

/**
 * v5.4.111cc — Compact toggle row for a single search-bar chip's
 * visibility. Mirrors the inline Row+Switch pattern used throughout
 * SettingsScreen but factored out because there are five of them.
 */
@androidx.compose.runtime.Composable
private fun SearchChipToggleRow(
    title: String,
    description: String,
    checked: Boolean,
    onCheckedChange: (Boolean) -> Unit
) {
    androidx.compose.foundation.layout.Row(
        androidx.compose.ui.Modifier.fillMaxWidth(),
        verticalAlignment = androidx.compose.ui.Alignment.CenterVertically
    ) {
        androidx.compose.foundation.layout.Column(androidx.compose.ui.Modifier.weight(1f)) {
            androidx.compose.material3.Text(
                title,
                fontSize = 14.sp,
                fontWeight = androidx.compose.ui.text.font.FontWeight.Medium
            )
            androidx.compose.material3.Text(
                description,
                fontSize = 11.sp,
                color = androidx.compose.material3.MaterialTheme.colorScheme.onSurfaceVariant
            )
        }
        androidx.compose.foundation.layout.Spacer(androidx.compose.ui.Modifier.width(12.dp))
        androidx.compose.material3.Switch(
            checked = checked,
            onCheckedChange = onCheckedChange
        )
    }
}
