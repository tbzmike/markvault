package com.tebogo.markvault.service

import android.app.PendingIntent
import android.content.Intent
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.session.MediaSession
import androidx.media3.session.MediaSessionService

/**
 * v5.4.233cc — Background media playback service.
 *
 * Hosts the SINGLE shared ExoPlayer instance + MediaSession so that:
 *   • Audio/video keeps playing when MarkVault is minimized or backgrounded
 *     (this is a real foreground Service, independent of any Activity or
 *     Compose screen's lifecycle).
 *   • The system notification shows play/pause/skip controls automatically
 *     — Media3's MediaSession wires these for us; no manual
 *     NotificationCompat / broadcast-receiver wiring needed.
 *   • Every screen that plays media (MediaPlayerScreen, FloatingMediaPopup,
 *     MiniPlayerBar) connects to THIS SAME player via MediaController, so
 *     there is only ever one active playback session — switching screens
 *     never creates duplicate ExoPlayer instances (which was itself an
 *     OOM risk before this change).
 */
class PlaybackService : MediaSessionService() {

    private var mediaSession: MediaSession? = null

    override fun onCreate() {
        super.onCreate()
        val player = ExoPlayer.Builder(this).build()
        val sessionActivityIntent = packageManager
            .getLaunchIntentForPackage(packageName)
            ?.let { launchIntent ->
                PendingIntent.getActivity(
                    this, 0, launchIntent,
                    PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
                )
            }
        val builder = MediaSession.Builder(this, player)
        if (sessionActivityIntent != null) builder.setSessionActivity(sessionActivityIntent)
        mediaSession = builder.build()
    }

    override fun onGetSession(controllerInfo: MediaSession.ControllerInfo): MediaSession? = mediaSession

    /**
     * v5.4.233cc — Only stop the service if playback isn't actually active.
     * Swiping MarkVault away from the recent-apps list fires this — without
     * this guard, audio would stop the moment the user "minimizes" the app
     * via task-swipe, which defeats the whole point of background playback.
     */
    override fun onTaskRemoved(rootIntent: Intent?) {
        val player = mediaSession?.player
        if (player == null || !player.playWhenReady || player.mediaItemCount == 0) {
            stopSelf()
        }
        super.onTaskRemoved(rootIntent)
    }

    override fun onDestroy() {
        mediaSession?.run {
            player.release()
            release()
            mediaSession = null
        }
        super.onDestroy()
    }
}
