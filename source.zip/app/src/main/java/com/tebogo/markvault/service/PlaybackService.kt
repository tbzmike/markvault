package com.tebogo.markvault.service

import android.app.PendingIntent
import android.content.Intent
import androidx.media3.cast.CastPlayer
import androidx.media3.cast.SessionAvailabilityListener
import androidx.media3.common.Player
import androidx.media3.common.C
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.session.MediaLibraryService
import androidx.media3.session.MediaSession
import androidx.media3.session.LibraryResult
import androidx.media3.common.MediaItem
import androidx.media3.common.MediaMetadata
import com.google.common.collect.ImmutableList
import com.google.common.util.concurrent.Futures
import com.google.common.util.concurrent.ListenableFuture
import com.tebogo.markvault.data.Prefs
import com.tebogo.markvault.network.JwMediaApi
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.runBlocking
import kotlinx.coroutines.guava.future
import com.google.android.gms.cast.framework.CastContext
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.launch

/**
 * v5.4.261cc — Hardened Chromecast transfer and failure isolation.
 * v5.4.247cc — Background media playback service with Chromecast support.
 *
 * # v5.4.233cc baseline
 *
 * Hosts the SINGLE shared ExoPlayer instance + MediaSession so that:
 *   • Audio/video keeps playing when MarkVault is minimized or backgrounded
 *     (this is a real foreground Service, independent of any Activity or
 *     Compose screen's lifecycle).
 *   • The system notification shows play/pause/skip controls automatically
 *     — Media3's MediaSession wires these for us; no manual
 *     NotificationCompat / broadcast-receiver wiring needed.
 *   • Every screen that plays media (MediaPlayerScreen, FloatingMediaPopup,
 *     MiniPlayerBar) connects to THIS SAME player via MediaController, so
 *     there is only ever one active playback session — switching screens
 *     never creates duplicate ExoPlayer instances (which was itself an
 *     OOM risk before this change).
 *
 * # v5.4.247cc — Chromecast
 *
 * Adds a CastPlayer alongside the local ExoPlayer. Both implement the
 * same media3 Player interface. When the user taps the Cast button and
 * connects to a Chromecast device:
 *
 *   1. SessionAvailabilityListener.onCastSessionAvailable() fires on the
 *      main thread (called by the Cast SDK).
 *   2. v5.4.255cc — The FULL queue (every item, not just the one
 *      currently playing) transfers from localPlayer → castPlayer, along
 *      with current index, position, and shuffle/repeat mode — so
 *      continuous play / shuffle / repeat keep working identically once
 *      casting starts, not just single-item playback.
 *   3. MediaSession.setPlayer(castPlayer) routes all subsequent
 *      MediaController commands (play/pause/seek/next/previous/shuffle/
 *      repeat from every screen and from the system notification) to the
 *      Chromecast.
 *   4. The local ExoPlayer is paused — the Chromecast is now the
 *      speaker/screen.
 *
 * When the user disconnects (tap Stop on the cast notification, or the
 * Chromecast goes offline):
 *   1. onCastSessionUnavailable() fires.
 *   2. The full queue transfers castPlayer → localPlayer the same way,
 *      local playback resumes from the last known position.
 *   3. MediaSession.setPlayer(localPlayer) restores local routing.
 *
 * CastPlayer is allocated only when CastContext initialises successfully.
 * On devices without Google Play Services (custom ROMs), the runCatching
 * guard keeps the rest of the service fully functional with local-only
 * playback — castPlayer stays null and no Cast button appears.
 */
class PlaybackService : MediaLibraryService() {

    private var mediaSession: MediaLibraryService.MediaLibrarySession? = null

    // Android Auto library caches. They are deliberately service-local and do
    // not touch MarkVault's article/semantic-search pipeline.
    private val autoCategoryCache = java.util.concurrent.ConcurrentHashMap<String, com.tebogo.markvault.network.JwCategory>()
    private val autoMediaCache = java.util.concurrent.ConcurrentHashMap<String, com.tebogo.markvault.data.MediaItem>()
    private val autoSearchCache = java.util.concurrent.ConcurrentHashMap<String, List<com.tebogo.markvault.data.MediaItem>>()
    @Volatile private var autoAudioRoot: com.tebogo.markvault.network.JwCategory? = null
    @Volatile private var autoAllAudio: List<com.tebogo.markvault.data.MediaItem>? = null

    private fun androidAutoEnabled(): Boolean = runCatching {
        runBlocking(Dispatchers.IO) { Prefs(applicationContext).androidAutoEnabled.first() }
    }.getOrDefault(false)

    private suspend fun findAudioRoot(): com.tebogo.markvault.network.JwCategory? {
        autoAudioRoot?.let { return it }
        val root = JwMediaApi.topCategories().firstOrNull { cat ->
            cat.name.trim().equals("Audio", ignoreCase = true) ||
                cat.name.contains("Audio", ignoreCase = true)
        }
        if (root != null) {
            autoAudioRoot = root
            autoCategoryCache[root.key] = root
        }
        return root
    }

    /** Crawl the Audio branch to completion once, then reuse it for keyboard and voice search. */
    private suspend fun entireAudioLibrary(): List<com.tebogo.markvault.data.MediaItem> {
        autoAllAudio?.let { return it }
        val root = findAudioRoot() ?: return emptyList()
        val queue = java.util.ArrayDeque<String>()
        val visited = HashSet<String>()
        val found = LinkedHashMap<String, com.tebogo.markvault.data.MediaItem>()
        queue.add(root.key)
        while (queue.isNotEmpty()) {
            val key = queue.removeFirst()
            if (!visited.add(key)) continue
            val detail = runCatching { JwMediaApi.categoryDetail(key) }.getOrNull() ?: continue
            detail.subcategories.forEach { sub ->
                autoCategoryCache[sub.key] = sub
                if (!visited.contains(sub.key)) queue.addLast(sub.key)
            }
            audioOnly(detail.media).forEach { item ->
                found[item.jwKey.ifBlank { item.title + "|" + item.streamUrl }] = item
            }
        }
        return found.values.toList().also { list ->
            autoAllAudio = list
            list.forEach { autoMediaCache[audioMediaId(it)] = it }
        }
    }

    private suspend fun searchEntireAudio(query: String, limit: Int): List<com.tebogo.markvault.data.MediaItem> {
        val q = query.trim().lowercase()
        if (q.isBlank()) return entireAudioLibrary().take(limit)
        val tokens = q.split(Regex("[^\\p{L}\\p{Nd}]+" )).filter { it.length >= 2 }
        return entireAudioLibrary().mapNotNull { item ->
            val title = item.title.lowercase()
            val desc = item.description.lowercase()
            var score = 0
            if (title.contains(q)) score += 20
            if (desc.contains(q)) score += 6
            tokens.forEach { token ->
                if (title.contains(token)) score += 4
                if (desc.contains(token)) score += 1
            }
            if (score > 0) item to score else null
        }.sortedByDescending { it.second }.take(limit).map { it.first }
    }

    private fun categoryMediaId(key: String) = "markvault:auto:cat:$key"
    private fun audioMediaId(item: com.tebogo.markvault.data.MediaItem): String =
        "markvault:auto:audio:" + item.jwKey.ifBlank { item.id.toString() }.ifBlank { item.title.hashCode().toString() }

    private fun browsableCategory(cat: com.tebogo.markvault.network.JwCategory): MediaItem {
        autoCategoryCache[cat.key] = cat
        return MediaItem.Builder()
            .setMediaId(categoryMediaId(cat.key))
            .setMediaMetadata(MediaMetadata.Builder()
                .setTitle(cat.name)
                .setDescription(cat.description)
                .setIsBrowsable(true)
                .setIsPlayable(false)
                .build())
            .build()
    }

    private fun playableAudio(item: com.tebogo.markvault.data.MediaItem): MediaItem {
        val id = audioMediaId(item)
        autoMediaCache[id] = item
        val uri = item.localPath.ifBlank { item.streamUrl }
        return MediaItem.Builder()
            .setMediaId(id)
            .setUri(uri)
            .apply { if (item.mimeType.isNotBlank()) setMimeType(item.mimeType) }
            .setMediaMetadata(MediaMetadata.Builder()
                .setTitle(item.title)
                .setArtist("JW.org • Audio")
                .setDescription(item.description)
                .setIsBrowsable(false)
                .setIsPlayable(true)
                .apply { if (item.thumbnailUrl.isNotBlank()) setArtworkUri(android.net.Uri.parse(item.thumbnailUrl)) }
                .build())
            .build()
    }

    private fun audioOnly(items: List<com.tebogo.markvault.data.MediaItem>) =
        items.filter { it.mediaType.equals("audio", ignoreCase = true) }

    private val libraryCallback = object : MediaLibraryService.MediaLibrarySession.Callback {
        override fun onGetLibraryRoot(
            session: MediaLibraryService.MediaLibrarySession,
            browser: MediaSession.ControllerInfo,
            params: MediaLibraryService.LibraryParams?
        ): ListenableFuture<LibraryResult<MediaItem>> {
            if (!androidAutoEnabled()) {
                val disabled = MediaItem.Builder().setMediaId("markvault:auto:disabled")
                    .setMediaMetadata(MediaMetadata.Builder()
                        .setTitle("Android Auto is disabled in MarkVault Settings")
                        .setIsBrowsable(true).setIsPlayable(false).build()).build()
                return Futures.immediateFuture(LibraryResult.ofItem(disabled, params))
            }
            val root = MediaItem.Builder().setMediaId("markvault:auto:root")
                .setMediaMetadata(MediaMetadata.Builder()
                    .setTitle("MarkVault Audio")
                    .setIsBrowsable(true).setIsPlayable(false).build()).build()
            return Futures.immediateFuture(LibraryResult.ofItem(root, params))
        }

        override fun onGetChildren(
            session: MediaLibraryService.MediaLibrarySession,
            browser: MediaSession.ControllerInfo,
            parentId: String,
            page: Int,
            pageSize: Int,
            params: MediaLibraryService.LibraryParams?
        ): ListenableFuture<LibraryResult<ImmutableList<MediaItem>>> {
            if (!androidAutoEnabled()) return Futures.immediateFuture(LibraryResult.ofItemList(emptyList(), params))
            return serviceScope.future {
                val all = runCatching {
                    when {
                        parentId == "markvault:auto:root" -> {
                            val audio = findAudioRoot() ?: return@runCatching emptyList()
                            val detail = JwMediaApi.categoryDetail(audio.key)
                            detail.subcategories.map(::browsableCategory) + audioOnly(detail.media).map(::playableAudio)
                        }
                        parentId.startsWith("markvault:auto:cat:") -> {
                            val key = parentId.removePrefix("markvault:auto:cat:")
                            val detail = JwMediaApi.categoryDetail(key)
                            detail.subcategories.map(::browsableCategory) + audioOnly(detail.media).map(::playableAudio)
                        }
                        else -> emptyList()
                    }
                }.getOrElse { emptyList() }
                val from = (page * pageSize).coerceAtMost(all.size)
                val to = (from + pageSize).coerceAtMost(all.size)
                LibraryResult.ofItemList(all.subList(from, to), params)
            }
        }

        override fun onGetItem(
            session: MediaLibraryService.MediaLibrarySession,
            browser: MediaSession.ControllerInfo,
            mediaId: String
        ): ListenableFuture<LibraryResult<MediaItem>> {
            val item = autoMediaCache[mediaId]?.let(::playableAudio)
                ?: if (mediaId.startsWith("markvault:auto:cat:")) {
                    autoCategoryCache[mediaId.removePrefix("markvault:auto:cat:")]?.let(::browsableCategory)
                } else null
            return if (item != null) Futures.immediateFuture(LibraryResult.ofItem(item, null))
            else Futures.immediateFuture(LibraryResult.ofError(LibraryResult.RESULT_ERROR_BAD_VALUE))
        }

        override fun onSearch(
            session: MediaLibraryService.MediaLibrarySession,
            browser: MediaSession.ControllerInfo,
            query: String,
            params: MediaLibraryService.LibraryParams?
        ): ListenableFuture<LibraryResult<Void>> {
            return serviceScope.future {
                val results = if (!androidAutoEnabled() || query.isBlank()) emptyList() else runCatching {
                    searchEntireAudio(query, limit = 100)
                }.getOrElse { emptyList() }
                autoSearchCache[query] = results
                results.forEach { autoMediaCache[audioMediaId(it)] = it }
                session.notifySearchResultChanged(browser, query, results.size, params)
                LibraryResult.ofVoid()
            }
        }

        override fun onGetSearchResult(
            session: MediaLibraryService.MediaLibrarySession,
            browser: MediaSession.ControllerInfo,
            query: String,
            page: Int,
            pageSize: Int,
            params: MediaLibraryService.LibraryParams?
        ): ListenableFuture<LibraryResult<ImmutableList<MediaItem>>> {
            return serviceScope.future {
                val raw = autoSearchCache[query] ?: if (androidAutoEnabled() && query.isNotBlank()) {
                    runCatching {
                        searchEntireAudio(query, limit = 100)
                    }.getOrElse { emptyList() }.also { autoSearchCache[query] = it }
                } else emptyList()
                val results = raw.map(::playableAudio)
                val from = (page * pageSize).coerceAtMost(results.size)
                val to = (from + pageSize).coerceAtMost(results.size)
                LibraryResult.ofItemList(results.subList(from, to), params)
            }
        }

        override fun onAddMediaItems(
            mediaSession: MediaSession,
            controller: MediaSession.ControllerInfo,
            mediaItems: List<MediaItem>
        ): ListenableFuture<List<MediaItem>> {
            // Android Auto / Assistant legacy playFromSearch is bridged by
            // Media3 into one requested MediaItem carrying searchQuery. Resolve
            // it against the SAME complete Audio subtree used by keyboard search.
            val voiceQuery = mediaItems.firstOrNull()?.requestMetadata?.searchQuery?.trim().orEmpty()
            if (voiceQuery.isNotBlank() && androidAutoEnabled()) {
                return serviceScope.future {
                    val voiceResults = runCatching {
                        searchEntireAudio(voiceQuery, limit = 50)
                    }.getOrElse { emptyList() }
                    if (voiceResults.isNotEmpty()) {
                        voiceResults.forEach { autoMediaCache[audioMediaId(it)] = it }
                        voiceResults.map(::playableAudio)
                    } else emptyList()
                }
            }

            val resolved = mediaItems.mapNotNull { requested ->
                val cached = autoMediaCache[requested.mediaId]
                when {
                    requested.localConfiguration != null -> requested
                    cached != null -> playableAudio(cached)
                    else -> null
                }
            }
            return Futures.immediateFuture(resolved)
        }
    }

    /** Local ExoPlayer — always allocated, active when not casting. */
    private var localPlayer: ExoPlayer? = null

    /**
     * CastPlayer — allocated only when GMS / Cast SDK is available.
     * Null on devices without Google Play Services.
     */
    private var castPlayer: CastPlayer? = null

    /** Prevents duplicate availability callbacks from transferring the same queue twice. */
    private var castTransferActive = false

    // Caption cues originate in the real ExoPlayer hosted by this service.
    // MediaController listeners are not a reliable transport for text cues
    // across the MediaSession boundary, so capture them here at the source.
    private val serviceScope = CoroutineScope(SupervisorJob() + Dispatchers.IO)

    override fun onCreate() {
        super.onCreate()

        // ── Local player ────────────────────────────────────────────────
        val exo = ExoPlayer.Builder(this).build().apply {
            // Keep network audio/video streaming alive with the display off.
            // MediaSessionService already keeps playback foreground; WAKE_MODE_NETWORK
            // adds the CPU/Wi-Fi wake handling ExoPlayer needs for remote streams.
            setWakeMode(C.WAKE_MODE_NETWORK)
        }
        localPlayer = exo

        exo.addListener(object : Player.Listener {
            override fun onCues(cueGroup: androidx.media3.common.text.CueGroup) {
                val current = exo.currentMediaItem ?: return
                if (current.mediaMetadata.extras
                        ?.getBoolean("markvault.captureVideoCaptions", false) != true) return
                val mediaId = current.mediaId.toLongOrNull() ?: return
                if (mediaId <= 0L) return
                val text = cueGroup.cues
                    .mapNotNull { it.text?.toString()?.trim() }
                    .filter { it.isNotBlank() }
                    .distinct()
                    .joinToString(" ")
                if (text.isBlank()) return
                val position = exo.currentPosition.coerceAtLeast(0L)
                serviceScope.launch {
                    runCatching {
                        val item = com.tebogo.markvault.data.VaultDb.get(this@PlaybackService)
                            .media().getById(mediaId) ?: return@runCatching
                        com.tebogo.markvault.data.VideoTranscriptStore.appendPlaybackCue(
                            this@PlaybackService, item, position, text
                        )
                    }.onFailure {
                        android.util.Log.w("MarkVaultCaptions", "Unable to persist playback caption", it)
                    }
                }
            }
        })

        // ── Cast player (optional — GMS required) ──────────────────────
        // CastContext.getSharedInstance() must be called on the main thread;
        // onCreate() already is. runCatching keeps the service functional
        // on devices / ROMs that lack Google Play Services.
        val castCtx = runCatching { CastContext.getSharedInstance(this) }.getOrNull()
        var cast: CastPlayer? = null
        if (castCtx != null) {
            cast = CastPlayer(castCtx)
            castPlayer = cast
            cast.setSessionAvailabilityListener(object : SessionAvailabilityListener {
                override fun onCastSessionAvailable()   = transferToCast()
                override fun onCastSessionUnavailable() = transferToLocal()
            })
        }

        // ── MediaSession ───────────────────────────────────────────────
        // If a Cast session is already active when this service starts
        // (user was already casting before opening MarkVault), begin with
        // castPlayer as the active player so MediaController commands from
        // every screen immediately reach the right destination.
        val initialPlayer: Player =
            if (cast != null && cast.isCastSessionAvailable) cast else exo

        val sessionActivityIntent = packageManager
            .getLaunchIntentForPackage(packageName)
            ?.let { launchIntent ->
                PendingIntent.getActivity(
                    this, 0, launchIntent,
                    PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
                )
            }
        val builder = MediaLibraryService.MediaLibrarySession.Builder(this, initialPlayer, libraryCallback)
        if (sessionActivityIntent != null) builder.setSessionActivity(sessionActivityIntent)
        mediaSession = builder.build()
    }

    /**
     * Cast session became available: transfer the FULL queue (every item,
     * not just the one currently playing) from the local ExoPlayer to the
     * CastPlayer, preserving position, current index, and shuffle/repeat
     * mode — so continuous play / shuffle / repeat keep working exactly
     * the same once casting starts. Called on the main thread by the
     * Cast SDK.
     */
    private fun transferToCast() {
        val cast    = castPlayer  ?: return
        val local   = localPlayer ?: return
        val session = mediaSession ?: return

        // Cast availability can be reported more than once while a route is
        // connecting/resuming. Never load the remote queue twice.
        if (castTransferActive || session.player === cast) return
        if (!cast.isCastSessionAvailable) return

        castTransferActive = true
        var localPlayWhenReady = local.playWhenReady
        try {
            val count = local.mediaItemCount
            if (count <= 0) {
                session.setPlayer(cast)
                local.pause()
                return
            }

            val localItems = (0 until count).map { local.getMediaItemAt(it) }
            val currentIndex = local.currentMediaItemIndex.coerceIn(0, count - 1)
            val currentPosition = local.currentPosition.coerceAtLeast(0L)
            localPlayWhenReady = local.playWhenReady
            val playWhenReady = localPlayWhenReady
            val shuffleEnabled = local.shuffleModeEnabled
            val repeatMode = local.repeatMode

            // A Chromecast receiver cannot fetch file:// or content:// URIs
            // from the sender. Only hand the CastPlayer network-reachable
            // HTTP(S) media items. This is especially important when a JW
            // item has been cached locally: local playback prefers localPath,
            // but casting must use the original stream URL.
            val castItems = localItems.filter { item ->
                val scheme = item.localConfiguration?.uri?.scheme?.lowercase()
                scheme == "http" || scheme == "https"
            }
            if (castItems.isEmpty()) {
                return
            }

            val currentLocalItem = localItems[currentIndex]
            val currentRemoteIndex = castItems.indexOfFirst {
                it.mediaId == currentLocalItem.mediaId
            }
            if (currentRemoteIndex < 0) {
                // The currently playing item is local-only. Keep local playback
                // active instead of switching to a Cast session that cannot
                // reproduce the current item.
                return
            }

            cast.setMediaItems(castItems, currentRemoteIndex, currentPosition)
            cast.shuffleModeEnabled = shuffleEnabled
            cast.repeatMode = repeatMode
            cast.prepare()
            cast.playWhenReady = playWhenReady

            // Switch the MediaSession only after the remote queue has been
            // accepted. If any Cast SDK/Media3 operation above throws, the
            // catch block leaves the local player and MediaSession untouched.
            local.pause()
            session.setPlayer(cast)
        } catch (t: Exception) {
            // A Cast connection failure must never become an uncaught exception
            // on the main thread and kill MarkVault. Restore local routing if a
            // partial transfer occurred. The Cast SDK will report the session
            // state separately and the user can retry from the Cast button.
            android.util.Log.e("MarkVaultCast", "Cast transfer failed", t)
            runCatching { cast.stop() }
            runCatching { session.setPlayer(local) }
            runCatching { local.playWhenReady = localPlayWhenReady }
        } finally {
            castTransferActive = false
        }
    }

    /**
     * Cast session ended: transfer the FULL queue back to the local
     * ExoPlayer the same way, resuming from the last known Cast position.
     * Called on the main thread by the Cast SDK.
     */
    private fun transferToLocal() {
        val cast    = castPlayer  ?: return
        val local   = localPlayer ?: return
        val session = mediaSession ?: return

        // If the session ended before the remote player had a usable queue,
        // simply restore local routing. This callback must never crash the
        // playback service during a network disconnect.
        if (session.player === local) return

        try {
            val count = cast.mediaItemCount
            if (count > 0) {
                val items = (0 until count).map { cast.getMediaItemAt(it) }
                val startIndex = cast.currentMediaItemIndex.coerceIn(0, count - 1)
                val position = cast.currentPosition.coerceAtLeast(0L)
                val playWhenReady = cast.playWhenReady
                val shuffleEnabled = cast.shuffleModeEnabled
                val repeatMode = cast.repeatMode

                local.setMediaItems(items, startIndex, position)
                local.shuffleModeEnabled = shuffleEnabled
                local.repeatMode = repeatMode
                local.prepare()
                local.playWhenReady = playWhenReady
            }

            cast.stop()
            session.setPlayer(local)
        } catch (t: Exception) {
            android.util.Log.e("MarkVaultCast", "Cast disconnect transfer failed", t)
            runCatching { session.setPlayer(local) }
        } finally {
            castTransferActive = false
        }
    }

    override fun onGetSession(
        controllerInfo: MediaSession.ControllerInfo
    ): MediaLibraryService.MediaLibrarySession? = mediaSession

    /**
     * v5.4.233cc — Only stop the service if playback isn't actually active.
     * Swiping MarkVault away from the recent-apps list fires this — without
     * this guard, audio would stop the moment the user swipes the app away,
     * defeating the whole point of background playback. Works for both local
     * and cast playback since mediaSession.player reflects whichever player
     * is currently active.
     */
    override fun onTaskRemoved(rootIntent: Intent?) {
        val player = mediaSession?.player
        if (player == null || !player.playWhenReady || player.mediaItemCount == 0) {
            stopSelf()
        }
        super.onTaskRemoved(rootIntent)
    }

    override fun onDestroy() {
        // Clear the cast listener first to prevent callbacks firing during
        // teardown while we're in the middle of releasing things.
        castPlayer?.setSessionAvailabilityListener(null)

        // Restore localPlayer as the active player before releasing through
        // the session — this ensures mediaSession.player.release() always
        // releases the local ExoPlayer exactly once, and castPlayer is
        // released separately below with no double-release risk.
        mediaSession?.run {
            val local = localPlayer
            if (local != null && player !== local) {
                runCatching { setPlayer(local) }
            }
            runCatching { player.release() }
            runCatching { release() }
            mediaSession = null
        }

        // Release cast player independently (not through the session).
        runCatching { castPlayer?.release() }
        castTransferActive = false
        castPlayer = null
        localPlayer = null
        serviceScope.cancel()

        super.onDestroy()
    }
}
