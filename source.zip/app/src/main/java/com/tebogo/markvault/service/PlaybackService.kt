package com.tebogo.markvault.service

import android.app.PendingIntent
import android.content.Intent
import androidx.media3.cast.CastPlayer
import androidx.media3.cast.SessionAvailabilityListener
import androidx.media3.common.Player
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.session.MediaSession
import androidx.media3.session.MediaSessionService
import com.google.android.gms.cast.framework.CastContext

/**
 * v5.4.261cc — Hardened Chromecast transfer and failure isolation.
 * v5.4.247cc — Background media playback service with Chromecast support.
 *
 * # v5.4.233cc baseline
 *
 * Hosts the SINGLE shared ExoPlayer instance + MediaSession so that:
 *   • Audio/video keeps playing when MarkVault is minimized or backgrounded
 *     (this is a real foreground Service, independent of any Activity or
 *     Compose screen's lifecycle).
 *   • The system notification shows play/pause/skip controls automatically
 *     — Media3's MediaSession wires these for us; no manual
 *     NotificationCompat / broadcast-receiver wiring needed.
 *   • Every screen that plays media (MediaPlayerScreen, FloatingMediaPopup,
 *     MiniPlayerBar) connects to THIS SAME player via MediaController, so
 *     there is only ever one active playback session — switching screens
 *     never creates duplicate ExoPlayer instances (which was itself an
 *     OOM risk before this change).
 *
 * # v5.4.247cc — Chromecast
 *
 * Adds a CastPlayer alongside the local ExoPlayer. Both implement the
 * same media3 Player interface. When the user taps the Cast button and
 * connects to a Chromecast device:
 *
 *   1. SessionAvailabilityListener.onCastSessionAvailable() fires on the
 *      main thread (called by the Cast SDK).
 *   2. v5.4.255cc — The FULL queue (every item, not just the one
 *      currently playing) transfers from localPlayer → castPlayer, along
 *      with current index, position, and shuffle/repeat mode — so
 *      continuous play / shuffle / repeat keep working identically once
 *      casting starts, not just single-item playback.
 *   3. MediaSession.setPlayer(castPlayer) routes all subsequent
 *      MediaController commands (play/pause/seek/next/previous/shuffle/
 *      repeat from every screen and from the system notification) to the
 *      Chromecast.
 *   4. The local ExoPlayer is paused — the Chromecast is now the
 *      speaker/screen.
 *
 * When the user disconnects (tap Stop on the cast notification, or the
 * Chromecast goes offline):
 *   1. onCastSessionUnavailable() fires.
 *   2. The full queue transfers castPlayer → localPlayer the same way,
 *      local playback resumes from the last known position.
 *   3. MediaSession.setPlayer(localPlayer) restores local routing.
 *
 * CastPlayer is allocated only when CastContext initialises successfully.
 * On devices without Google Play Services (custom ROMs), the runCatching
 * guard keeps the rest of the service fully functional with local-only
 * playback — castPlayer stays null and no Cast button appears.
 */
class PlaybackService : MediaSessionService() {

    private var mediaSession: MediaSession? = null

    /** Local ExoPlayer — always allocated, active when not casting. */
    private var localPlayer: ExoPlayer? = null

    /**
     * CastPlayer — allocated only when GMS / Cast SDK is available.
     * Null on devices without Google Play Services.
     */
    private var castPlayer: CastPlayer? = null

    /** Prevents duplicate availability callbacks from transferring the same queue twice. */
    private var castTransferActive = false

    override fun onCreate() {
        super.onCreate()

        // ── Local player ────────────────────────────────────────────────
        val exo = ExoPlayer.Builder(this).build()
        localPlayer = exo

        // ── Cast player (optional — GMS required) ──────────────────────
        // CastContext.getSharedInstance() must be called on the main thread;
        // onCreate() already is. runCatching keeps the service functional
        // on devices / ROMs that lack Google Play Services.
        val castCtx = runCatching { CastContext.getSharedInstance(this) }.getOrNull()
        var cast: CastPlayer? = null
        if (castCtx != null) {
            cast = CastPlayer(castCtx)
            castPlayer = cast
            cast.setSessionAvailabilityListener(object : SessionAvailabilityListener {
                override fun onCastSessionAvailable()   = transferToCast()
                override fun onCastSessionUnavailable() = transferToLocal()
            })
        }

        // ── MediaSession ───────────────────────────────────────────────
        // If a Cast session is already active when this service starts
        // (user was already casting before opening MarkVault), begin with
        // castPlayer as the active player so MediaController commands from
        // every screen immediately reach the right destination.
        val initialPlayer: Player =
            if (cast != null && cast.isCastSessionAvailable) cast else exo

        val sessionActivityIntent = packageManager
            .getLaunchIntentForPackage(packageName)
            ?.let { launchIntent ->
                PendingIntent.getActivity(
                    this, 0, launchIntent,
                    PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
                )
            }
        val builder = MediaSession.Builder(this, initialPlayer)
        if (sessionActivityIntent != null) builder.setSessionActivity(sessionActivityIntent)
        mediaSession = builder.build()
    }

    /**
     * Cast session became available: transfer the FULL queue (every item,
     * not just the one currently playing) from the local ExoPlayer to the
     * CastPlayer, preserving position, current index, and shuffle/repeat
     * mode — so continuous play / shuffle / repeat keep working exactly
     * the same once casting starts. Called on the main thread by the
     * Cast SDK.
     */
    private fun transferToCast() {
        val cast    = castPlayer  ?: return
        val local   = localPlayer ?: return
        val session = mediaSession ?: return

        // Cast availability can be reported more than once while a route is
        // connecting/resuming. Never load the remote queue twice.
        if (castTransferActive || session.player === cast) return
        if (!cast.isCastSessionAvailable) return

        castTransferActive = true
        var localPlayWhenReady = local.playWhenReady
        try {
            val count = local.mediaItemCount
            if (count <= 0) {
                session.setPlayer(cast)
                local.pause()
                return
            }

            val localItems = (0 until count).map { local.getMediaItemAt(it) }
            val currentIndex = local.currentMediaItemIndex.coerceIn(0, count - 1)
            val currentPosition = local.currentPosition.coerceAtLeast(0L)
            localPlayWhenReady = local.playWhenReady
            val playWhenReady = localPlayWhenReady
            val shuffleEnabled = local.shuffleModeEnabled
            val repeatMode = local.repeatMode

            // A Chromecast receiver cannot fetch file:// or content:// URIs
            // from the sender. Only hand the CastPlayer network-reachable
            // HTTP(S) media items. This is especially important when a JW
            // item has been cached locally: local playback prefers localPath,
            // but casting must use the original stream URL.
            val castItems = localItems.filter { item ->
                val scheme = item.localConfiguration?.uri?.scheme?.lowercase()
                scheme == "http" || scheme == "https"
            }
            if (castItems.isEmpty()) {
                return
            }

            val currentLocalItem = localItems[currentIndex]
            val currentRemoteIndex = castItems.indexOfFirst {
                it.mediaId == currentLocalItem.mediaId
            }
            if (currentRemoteIndex < 0) {
                // The currently playing item is local-only. Keep local playback
                // active instead of switching to a Cast session that cannot
                // reproduce the current item.
                return
            }

            cast.setMediaItems(castItems, currentRemoteIndex, currentPosition)
            cast.shuffleModeEnabled = shuffleEnabled
            cast.repeatMode = repeatMode
            cast.prepare()
            cast.playWhenReady = playWhenReady

            // Switch the MediaSession only after the remote queue has been
            // accepted. If any Cast SDK/Media3 operation above throws, the
            // catch block leaves the local player and MediaSession untouched.
            local.pause()
            session.setPlayer(cast)
        } catch (t: Exception) {
            // A Cast connection failure must never become an uncaught exception
            // on the main thread and kill MarkVault. Restore local routing if a
            // partial transfer occurred. The Cast SDK will report the session
            // state separately and the user can retry from the Cast button.
            android.util.Log.e("MarkVaultCast", "Cast transfer failed", t)
            runCatching { cast.stop() }
            runCatching { session.setPlayer(local) }
            runCatching { local.playWhenReady = localPlayWhenReady }
        } finally {
            castTransferActive = false
        }
    }

    /**
     * Cast session ended: transfer the FULL queue back to the local
     * ExoPlayer the same way, resuming from the last known Cast position.
     * Called on the main thread by the Cast SDK.
     */
    private fun transferToLocal() {
        val cast    = castPlayer  ?: return
        val local   = localPlayer ?: return
        val session = mediaSession ?: return

        // If the session ended before the remote player had a usable queue,
        // simply restore local routing. This callback must never crash the
        // playback service during a network disconnect.
        if (session.player === local) return

        try {
            val count = cast.mediaItemCount
            if (count > 0) {
                val items = (0 until count).map { cast.getMediaItemAt(it) }
                val startIndex = cast.currentMediaItemIndex.coerceIn(0, count - 1)
                val position = cast.currentPosition.coerceAtLeast(0L)
                val playWhenReady = cast.playWhenReady
                val shuffleEnabled = cast.shuffleModeEnabled
                val repeatMode = cast.repeatMode

                local.setMediaItems(items, startIndex, position)
                local.shuffleModeEnabled = shuffleEnabled
                local.repeatMode = repeatMode
                local.prepare()
                local.playWhenReady = playWhenReady
            }

            cast.stop()
            session.setPlayer(local)
        } catch (t: Exception) {
            android.util.Log.e("MarkVaultCast", "Cast disconnect transfer failed", t)
            runCatching { session.setPlayer(local) }
        } finally {
            castTransferActive = false
        }
    }

    override fun onGetSession(controllerInfo: MediaSession.ControllerInfo): MediaSession? =
        mediaSession

    /**
     * v5.4.233cc — Only stop the service if playback isn't actually active.
     * Swiping MarkVault away from the recent-apps list fires this — without
     * this guard, audio would stop the moment the user swipes the app away,
     * defeating the whole point of background playback. Works for both local
     * and cast playback since mediaSession.player reflects whichever player
     * is currently active.
     */
    override fun onTaskRemoved(rootIntent: Intent?) {
        val player = mediaSession?.player
        if (player == null || !player.playWhenReady || player.mediaItemCount == 0) {
            stopSelf()
        }
        super.onTaskRemoved(rootIntent)
    }

    override fun onDestroy() {
        // Clear the cast listener first to prevent callbacks firing during
        // teardown while we're in the middle of releasing things.
        castPlayer?.setSessionAvailabilityListener(null)

        // Restore localPlayer as the active player before releasing through
        // the session — this ensures mediaSession.player.release() always
        // releases the local ExoPlayer exactly once, and castPlayer is
        // released separately below with no double-release risk.
        mediaSession?.run {
            val local = localPlayer
            if (local != null && player !== local) {
                runCatching { setPlayer(local) }
            }
            runCatching { player.release() }
            runCatching { release() }
            mediaSession = null
        }

        // Release cast player independently (not through the session).
        runCatching { castPlayer?.release() }
        castTransferActive = false
        castPlayer = null
        localPlayer = null

        super.onDestroy()
    }
}
