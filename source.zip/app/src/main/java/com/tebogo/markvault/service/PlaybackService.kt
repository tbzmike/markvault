package com.tebogo.markvault.service

import android.app.PendingIntent
import android.content.Intent
import android.os.Bundle
import androidx.media3.cast.CastPlayer
import androidx.media3.cast.SessionAvailabilityListener
import androidx.media3.common.Player
import androidx.media3.common.C
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.session.MediaLibraryService
import androidx.media3.session.MediaSession
import androidx.media3.session.CommandButton
import androidx.media3.session.SessionCommand
import androidx.media3.session.SessionCommands
import androidx.media3.session.SessionResult
import androidx.media3.session.LibraryResult
import androidx.media3.common.MediaItem
import androidx.media3.common.MediaMetadata
import com.google.common.collect.ImmutableList
import com.google.common.util.concurrent.Futures
import com.google.common.util.concurrent.ListenableFuture
import com.tebogo.markvault.data.Prefs
import com.tebogo.markvault.network.JwMediaApi
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.runBlocking
import kotlinx.coroutines.guava.future
import com.google.android.gms.cast.framework.CastContext
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.launch

/**
 * v5.4.261cc — Hardened Chromecast transfer and failure isolation.
 * v5.4.247cc — Background media playback service with Chromecast support.
 *
 * # v5.4.233cc baseline
 *
 * Hosts the SINGLE shared ExoPlayer instance + MediaSession so that:
 *   • Audio/video keeps playing when MarkVault is minimized or backgrounded
 *     (this is a real foreground Service, independent of any Activity or
 *     Compose screen's lifecycle).
 *   • The system notification shows play/pause/skip controls automatically
 *     — Media3's MediaSession wires these for us; no manual
 *     NotificationCompat / broadcast-receiver wiring needed.
 *   • Every screen that plays media (MediaPlayerScreen, FloatingMediaPopup,
 *     MiniPlayerBar) connects to THIS SAME player via MediaController, so
 *     there is only ever one active playback session — switching screens
 *     never creates duplicate ExoPlayer instances (which was itself an
 *     OOM risk before this change).
 *
 * # v5.4.247cc — Chromecast
 *
 * Adds a CastPlayer alongside the local ExoPlayer. Both implement the
 * same media3 Player interface. When the user taps the Cast button and
 * connects to a Chromecast device:
 *
 *   1. SessionAvailabilityListener.onCastSessionAvailable() fires on the
 *      main thread (called by the Cast SDK).
 *   2. v5.4.255cc — The FULL queue (every item, not just the one
 *      currently playing) transfers from localPlayer → castPlayer, along
 *      with current index, position, and shuffle/repeat mode — so
 *      continuous play / shuffle / repeat keep working identically once
 *      casting starts, not just single-item playback.
 *   3. MediaSession.setPlayer(castPlayer) routes all subsequent
 *      MediaController commands (play/pause/seek/next/previous/shuffle/
 *      repeat from every screen and from the system notification) to the
 *      Chromecast.
 *   4. The local ExoPlayer is paused — the Chromecast is now the
 *      speaker/screen.
 *
 * When the user disconnects (tap Stop on the cast notification, or the
 * Chromecast goes offline):
 *   1. onCastSessionUnavailable() fires.
 *   2. The full queue transfers castPlayer → localPlayer the same way,
 *      local playback resumes from the last known position.
 *   3. MediaSession.setPlayer(localPlayer) restores local routing.
 *
 * CastPlayer is allocated only when CastContext initialises successfully.
 * On devices without Google Play Services (custom ROMs), the runCatching
 * guard keeps the rest of the service fully functional with local-only
 * playback — castPlayer stays null and no Cast button appears.
 */
class PlaybackService : MediaLibraryService() {

    private var mediaSession: MediaLibraryService.MediaLibrarySession? = null

    // Android Auto library caches. They are deliberately service-local and do
    // not touch MarkVault's article/semantic-search pipeline.
    private val autoCategoryCache = java.util.concurrent.ConcurrentHashMap<String, com.tebogo.markvault.network.JwCategory>()
    private val autoMediaCache = java.util.concurrent.ConcurrentHashMap<String, com.tebogo.markvault.data.MediaItem>()
    private val autoSearchCache = java.util.concurrent.ConcurrentHashMap<String, List<com.tebogo.markvault.data.MediaItem>>()
    private val autoFolderMediaCache = java.util.concurrent.ConcurrentHashMap<String, List<com.tebogo.markvault.data.MediaItem>>()
    private val autoParentByMediaId = java.util.concurrent.ConcurrentHashMap<String, String>()
    private val autoParentCategoryByKey = java.util.concurrent.ConcurrentHashMap<String, String>()
    private val autoAudioRoots = java.util.concurrent.ConcurrentHashMap<String, com.tebogo.markvault.network.JwCategory>()
    private val autoLanguageCache = java.util.concurrent.ConcurrentHashMap<String, com.tebogo.markvault.network.JwMediaLanguage>()
    private val autoHomeId = "markvault:auto:home"
    private val autoAllFoldersId = "markvault:auto:all-folders"
    private val autoRecentId = "markvault:auto:recent"
    private val autoFavouritesId = "markvault:auto:favourites"
    private val autoSuggestedId = "markvault:auto:suggested"
    private val autoLanguagePickerId = "markvault:auto:language"
    private val autoLanguageSetPrefix = "markvault:auto:language:set:"
    private val autoFolderLanguagePrefix = "markvault:auto:folder-language:"
    private val autoFolderLanguageSetPrefix = "markvault:auto:folder-language:set:"

    private val autoShuffleCommand = SessionCommand("markvault.auto.SHUFFLE", Bundle.EMPTY)
    private val autoRepeatCommand = SessionCommand("markvault.auto.REPEAT", Bundle.EMPTY)

    @Volatile private var autoAllAudio: List<com.tebogo.markvault.data.MediaItem>? = null
    @Volatile private var autoLanguageStateSignature: String = ""

    private fun androidAutoEnabled(): Boolean = runCatching {
        runBlocking(Dispatchers.IO) { Prefs(applicationContext).androidAutoEnabled.first() }
    }.getOrDefault(false)

    private suspend fun autoLanguageState(): Pair<String, Map<String, String>> {
        val prefs = Prefs(applicationContext)
        val global = prefs.mediaLibraryLanguage.first().ifBlank { "E" }
        val raw = prefs.mediaFolderLanguagesRaw.first()
        val overrides = runCatching {
            val obj = org.json.JSONObject(raw)
            buildMap<String, String> {
                val keys = obj.keys()
                while (keys.hasNext()) {
                    val key = keys.next()
                    obj.optString(key).takeIf { it.isNotBlank() }?.let { put(key, it) }
                }
            }
        }.getOrDefault(emptyMap())
        val signature = "$global|$raw"
        if (signature != autoLanguageStateSignature) {
            autoLanguageStateSignature = signature
            clearAutoLanguageSensitiveCaches()
        }
        return global to overrides
    }

    private fun clearAutoLanguageSensitiveCaches() {
        autoCategoryCache.clear()
        autoMediaCache.clear()
        autoSearchCache.clear()
        autoFolderMediaCache.clear()
        autoParentByMediaId.clear()
        autoAudioRoots.clear()
        autoAllAudio = null
    }

    private suspend fun effectiveAutoLanguage(categoryKey: String? = null): String {
        val (global, overrides) = autoLanguageState()
        var key = categoryKey
        val seen = HashSet<String>()
        while (!key.isNullOrBlank() && seen.add(key)) {
            overrides[key]?.takeIf { it.isNotBlank() }?.let { return it }
            key = autoParentCategoryByKey[key]
        }
        return global
    }

    private suspend fun availableAutoLanguages(): List<com.tebogo.markvault.network.JwMediaLanguage> {
        val global = autoLanguageState().first
        val loaded = runCatching { JwMediaApi.languages(global) }.getOrElse { emptyList() }
        if (loaded.isNotEmpty()) {
            loaded.forEach { autoLanguageCache[it.code] = it }
            return loaded
        }
        return autoLanguageCache.values.sortedBy { it.name.lowercase() }.ifEmpty {
            listOf(com.tebogo.markvault.network.JwMediaLanguage("E", "English", "English"))
        }
    }

    private suspend fun persistGlobalAutoLanguage(language: String) {
        val code = language.ifBlank { "E" }
        Prefs(applicationContext).setMediaLibraryLanguage(code)
        autoLanguageStateSignature = ""
        autoLanguageState()
    }

    private suspend fun persistFolderAutoLanguage(categoryKey: String, language: String?) {
        val prefs = Prefs(applicationContext)
        val raw = prefs.mediaFolderLanguagesRaw.first()
        val obj = runCatching { org.json.JSONObject(raw) }.getOrElse { org.json.JSONObject() }
        if (language.isNullOrBlank()) obj.remove(categoryKey) else obj.put(categoryKey, language)
        prefs.setMediaFolderLanguagesRaw(obj.toString())
        autoLanguageStateSignature = ""
        autoLanguageState()
    }

    private suspend fun findAudioRoot(): com.tebogo.markvault.network.JwCategory? {
        val language = effectiveAutoLanguage()
        autoAudioRoots[language]?.let { return it }
        val root = JwMediaApi.topCategories(language).firstOrNull { cat ->
            cat.key.equals("Audio", ignoreCase = true) ||
                cat.key.contains("Audio", ignoreCase = true) ||
                cat.name.trim().equals("Audio", ignoreCase = true) ||
                cat.name.contains("Audio", ignoreCase = true)
        }
        if (root != null) {
            autoAudioRoots[language] = root
            autoCategoryCache[root.key] = root
        }
        return root
    }

    private fun mediaSongNumber(item: com.tebogo.markvault.data.MediaItem): Int? {
        val combined = listOf(item.title, item.description, item.jwKey).joinToString(" ")
        Regex("(?i)\\bsong\\s*(?:no\\.?\\s*)?(\\d{1,3})\\b").find(combined)
            ?.groupValues?.getOrNull(1)?.toIntOrNull()?.let { return it }
        Regex("^\\s*(\\d{1,3})(?:[.\\s:–—-]|$)").find(item.title)
            ?.groupValues?.getOrNull(1)?.toIntOrNull()?.let { return it }
        return null
    }

    private fun requestedSongNumber(query: String): Int? {
        val q = query.trim()
        if (q.matches(Regex("\\d{1,3}"))) return q.toIntOrNull()
        return Regex("(?i)\\b(?:song\\s*(?:number|no\\.?)?|number)\\s*(\\d{1,3})\\b")
            .find(q)?.groupValues?.getOrNull(1)?.toIntOrNull()
    }

    private fun sortAutoAudio(items: List<com.tebogo.markvault.data.MediaItem>): List<com.tebogo.markvault.data.MediaItem> {
        val hasNumbers = items.any { mediaSongNumber(it) != null }
        return if (hasNumbers) {
            items.sortedWith(compareBy<com.tebogo.markvault.data.MediaItem> { mediaSongNumber(it) ?: Int.MAX_VALUE }
                .thenBy { it.title.lowercase() })
        } else {
            items.sortedBy { it.title.lowercase() }
        }
    }

    private fun registerAutoFolder(
        parentId: String,
        items: List<com.tebogo.markvault.data.MediaItem>,
        overwriteParent: Boolean = true
    ): List<com.tebogo.markvault.data.MediaItem> {
        val sorted = sortAutoAudio(items)
        autoFolderMediaCache[parentId] = sorted
        sorted.forEach { item ->
            val id = audioMediaId(item)
            autoMediaCache[id] = item
            if (overwriteParent) autoParentByMediaId[id] = parentId
            else autoParentByMediaId.putIfAbsent(id, parentId)
        }
        return sorted
    }

    private fun folderQueueFor(item: com.tebogo.markvault.data.MediaItem): Pair<List<com.tebogo.markvault.data.MediaItem>, Int>? {
        val id = audioMediaId(item)
        val parent = autoParentByMediaId[id] ?: return null
        val folder = autoFolderMediaCache[parent].orEmpty()
        val index = folder.indexOfFirst { audioMediaId(it) == id }
        return if (index >= 0) folder to index else null
    }

    private fun displayAudioTitle(item: com.tebogo.markvault.data.MediaItem): String {
        val number = mediaSongNumber(item) ?: return item.title
        val alreadyShowsNumber = Regex("(?i)(^\\s*$number(?:[.\\s:–—-]|$)|\\bsong\\s*(?:no\\.?\\s*)?$number\\b)")
            .containsMatchIn(item.title)
        return if (alreadyShowsNumber) item.title else "$number. ${item.title}"
    }

    private suspend fun recentAutoAudio(limit: Int = 30): List<com.tebogo.markvault.data.MediaItem> {
        val (_, overrides) = autoLanguageState()
        val allowedLanguages = buildSet {
            add(effectiveAutoLanguage())
            overrides.values.filter { it.isNotBlank() }.forEach(::add)
        }
        val items = runCatching {
            com.tebogo.markvault.data.VaultDb.get(applicationContext).media().getRecentlyPlayed(limit * 4)
        }.getOrElse { emptyList() }
        val filtered = audioOnly(items).filter { it.contentLanguage.ifBlank { "E" } in allowedLanguages }.take(limit)
        return registerAutoFolder(autoRecentId, filtered, overwriteParent = false)
    }

    private suspend fun favouriteAutoAudio(limit: Int = 60): List<com.tebogo.markvault.data.MediaItem> {
        val (_, overrides) = autoLanguageState()
        val allowedLanguages = buildSet {
            add(effectiveAutoLanguage())
            overrides.values.filter { it.isNotBlank() }.forEach(::add)
        }
        val items = runCatching {
            com.tebogo.markvault.data.VaultDb.get(applicationContext).media().favourites()
        }.getOrElse { emptyList() }
        val filtered = audioOnly(items)
            .filter { it.contentLanguage.ifBlank { "E" } in allowedLanguages }
            .take(limit)
        return registerAutoFolder(autoFavouritesId, filtered, overwriteParent = false)
    }

    /**
     * Driver-safe deterministic suggestions: prefer unplayed/unfavourited audio
     * from categories the user has recently played or favourited. This uses only
     * MarkVault's existing playback/favourite data and the active multilingual
     * JW Audio catalogue; no hidden recommendation service or guessed metadata.
     */
    private suspend fun suggestedAutoAudio(limit: Int = 40): List<com.tebogo.markvault.data.MediaItem> {
        val recent = recentAutoAudio(40)
        val favourites = favouriteAutoAudio(60)
        val seeds = recent + favourites
        val excluded = seeds.map { audioMediaId(it) }.toHashSet()
        val preferredCategories = seeds.map { it.category }.filter { it.isNotBlank() }.toSet()
        val library = entireAudioLibrary()
        val ranked = library.asSequence()
            .filter { audioMediaId(it) !in excluded }
            .map { item ->
                var score = 0
                if (item.category.isNotBlank() && item.category in preferredCategories) score += 100
                if (item.uploadDate > 0L) score += 5
                item to score
            }
            .sortedWith(compareByDescending<Pair<com.tebogo.markvault.data.MediaItem, Int>> { it.second }
                .thenByDescending { it.first.uploadDate }
                .thenBy { mediaSongNumber(it.first) ?: Int.MAX_VALUE }
                .thenBy { it.first.title.lowercase() })
            .map { it.first }
            .take(limit)
            .toList()
        return registerAutoFolder(autoSuggestedId, ranked, overwriteParent = false)
    }

    private fun browsableAutoItem(id: String, title: String, description: String): MediaItem =
        MediaItem.Builder()
            .setMediaId(id)
            .setMediaMetadata(MediaMetadata.Builder()
                .setTitle(title)
                .setDescription(description)
                .setIsBrowsable(true)
                .setIsPlayable(false)
                .build())
            .build()

    private fun homeButtonItem(): MediaItem = browsableAutoItem(
        autoHomeId,
        "Home • MarkVault Audio",
        "Recently played, favourites, suggested audio, all folders and language"
    )

    private suspend fun autoHomeChildren(): List<MediaItem> {
        availableAutoLanguages()
        return listOf(
            browsableAutoItem(autoAllFoldersId, "All audio folders", "Browse the complete JW.org Audio library"),
            browsableAutoItem(autoRecentId, "Recently played", "Your recently played audio"),
            browsableAutoItem(autoFavouritesId, "Favourites", "Audio you marked as favourite in MarkVault"),
            browsableAutoItem(autoSuggestedId, "Suggested", "Based on your recent and favourite audio categories"),
            globalLanguagePickerItem()
        )
    }

    private fun autoControlLayout(player: Player): List<CommandButton> {
        val repeatLabel = when (player.repeatMode) {
            Player.REPEAT_MODE_ONE -> "Repeat: One"
            Player.REPEAT_MODE_ALL -> "Repeat: All"
            else -> "Repeat: Off"
        }
        return listOf(
            CommandButton.Builder()
                .setSessionCommand(autoShuffleCommand)
                .setDisplayName(if (player.shuffleModeEnabled) "Shuffle: On" else "Shuffle: Off")
                .setIconResId(com.tebogo.markvault.R.drawable.ic_auto_shuffle)
                .setEnabled(true)
                .build(),
            CommandButton.Builder()
                .setSessionCommand(autoRepeatCommand)
                .setDisplayName(repeatLabel)
                .setIconResId(com.tebogo.markvault.R.drawable.ic_auto_repeat)
                .setEnabled(true)
                .build()
        )
    }

    private fun refreshAutoControlLayout() {
        val session = mediaSession ?: return
        runCatching { session.setCustomLayout(autoControlLayout(session.player)) }
    }

    /** Crawl the Audio branch to completion once, honoring global + per-folder language choices. */
    private suspend fun entireAudioLibrary(): List<com.tebogo.markvault.data.MediaItem> {
        autoLanguageState()
        autoAllAudio?.let { return it }
        val root = findAudioRoot() ?: return emptyList()
        val queue = java.util.ArrayDeque<String>()
        val visited = HashSet<String>()
        val found = LinkedHashMap<String, com.tebogo.markvault.data.MediaItem>()
        queue.add(root.key)
        while (queue.isNotEmpty()) {
            val key = queue.removeFirst()
            if (!visited.add(key)) continue
            val language = effectiveAutoLanguage(key)
            val detail = runCatching { JwMediaApi.categoryDetail(key, language) }.getOrNull() ?: continue
            detail.subcategories.forEach { sub ->
                autoCategoryCache[sub.key] = sub
                autoParentCategoryByKey[sub.key] = key
                if (!visited.contains(sub.key)) queue.addLast(sub.key)
            }
            val parentId = categoryMediaId(key)
            val folderAudio = registerAutoFolder(parentId, audioOnly(detail.media))
            folderAudio.forEach { item ->
                val identity = "${item.contentLanguage.ifBlank { language }}|${item.jwKey.ifBlank { item.title + "|" + item.streamUrl }}"
                found[identity] = item
            }
        }
        return found.values.toList().also { list ->
            autoAllAudio = list
            list.forEach { autoMediaCache[audioMediaId(it)] = it }
        }
    }

    private suspend fun searchEntireAudio(query: String, limit: Int): List<com.tebogo.markvault.data.MediaItem> {
        val q = query.trim().lowercase()
        if (q.isBlank()) return entireAudioLibrary().take(limit)
        val requestedNumber = requestedSongNumber(query)
        val stopWords = setOf("play", "please", "song", "number", "no", "markvault", "on", "in", "from", "audio", "the", "a")
        val tokens = q.split(Regex("[^\\p{L}\\p{Nd}]+"))
            .filter { it.length >= 2 && it !in stopWords && it.toIntOrNull() == null }
        return entireAudioLibrary().mapNotNull { item ->
            val title = item.title.lowercase()
            val displayTitle = displayAudioTitle(item).lowercase()
            val desc = item.description.lowercase()
            val category = item.category.lowercase()
            val number = mediaSongNumber(item)
            var score = 0
            if (requestedNumber != null && number == requestedNumber) score += 250
            if (displayTitle.contains(q) || title.contains(q)) score += 30
            if (desc.contains(q)) score += 6
            if (category.contains(q)) score += 10
            tokens.forEach { token ->
                if (displayTitle.contains(token) || title.contains(token)) score += 7
                if (category.contains(token)) score += 3
                if (desc.contains(token)) score += 1
            }
            if (score > 0) item to score else null
        }.sortedWith(compareByDescending<Pair<com.tebogo.markvault.data.MediaItem, Int>> { it.second }
            .thenBy { mediaSongNumber(it.first) ?: Int.MAX_VALUE }
            .thenBy { it.first.title.lowercase() })
            .take(limit)
            .map { it.first }
    }

    private fun categoryMediaId(key: String) = "markvault:auto:cat:$key"
    private fun audioMediaId(item: com.tebogo.markvault.data.MediaItem): String =
        "markvault:auto:audio:${item.contentLanguage.ifBlank { "E" }}:" +
            item.jwKey.ifBlank { item.id.toString() }.ifBlank { item.title.hashCode().toString() }

    private fun browsableCategory(cat: com.tebogo.markvault.network.JwCategory, parentKey: String? = null): MediaItem {
        autoCategoryCache[cat.key] = cat
        if (!parentKey.isNullOrBlank()) autoParentCategoryByKey[cat.key] = parentKey
        return MediaItem.Builder()
            .setMediaId(categoryMediaId(cat.key))
            .setMediaMetadata(MediaMetadata.Builder()
                .setTitle(cat.name)
                .setDescription(cat.description)
                .setIsBrowsable(true)
                .setIsPlayable(false)
                .build())
            .build()
    }

    private suspend fun globalLanguagePickerItem(): MediaItem {
        val current = effectiveAutoLanguage()
        val label = autoLanguageCache[current]?.let { it.nativeName.ifBlank { it.name } } ?: current
        return MediaItem.Builder()
            .setMediaId(autoLanguagePickerId)
            .setMediaMetadata(MediaMetadata.Builder()
                .setTitle("Language: $label")
                .setDescription("Change the JW.org Audio language for MarkVault and Android Auto")
                .setIsBrowsable(true)
                .setIsPlayable(false)
                .build())
            .build()
    }

    private fun languageChoiceItem(language: com.tebogo.markvault.network.JwMediaLanguage, mediaId: String): MediaItem {
        val title = language.nativeName.ifBlank { language.name }.ifBlank { language.code }
        val description = if (language.name.isNotBlank() && !language.name.equals(title, ignoreCase = true)) {
            language.name
        } else {
            "JW.org language ${language.code}"
        }
        return MediaItem.Builder()
            .setMediaId(mediaId)
            .setMediaMetadata(MediaMetadata.Builder()
                .setTitle(title)
                .setDescription(description)
                .setIsBrowsable(true)
                .setIsPlayable(false)
                .build())
            .build()
    }

    private suspend fun folderLanguagePickerItem(categoryKey: String): MediaItem {
        val (_, overrides) = autoLanguageState()
        val current = effectiveAutoLanguage(categoryKey)
        val explicit = overrides[categoryKey]
        val label = autoLanguageCache[current]?.let { it.nativeName.ifBlank { it.name } } ?: current
        val mode = if (explicit == null) "Auto • $label" else label
        return MediaItem.Builder()
            .setMediaId(autoFolderLanguagePrefix + categoryKey)
            .setMediaMetadata(MediaMetadata.Builder()
                .setTitle("Folder language: $mode")
                .setDescription("Choose a language for this folder, or Auto to inherit")
                .setIsBrowsable(true)
                .setIsPlayable(false)
                .build())
            .build()
    }

    private suspend fun categoryChildren(categoryKey: String, parentId: String): List<MediaItem> {
        val language = effectiveAutoLanguage(categoryKey)
        val detail = JwMediaApi.categoryDetail(categoryKey, language)
        val direct = registerAutoFolder(parentId, audioOnly(detail.media))
        val children = detail.subcategories.map { sub -> browsableCategory(sub, categoryKey) }
        return listOf(homeButtonItem(), folderLanguagePickerItem(categoryKey)) + children + direct.map(::playableAudio)
    }

    private fun playableAudio(item: com.tebogo.markvault.data.MediaItem): MediaItem {
        val id = audioMediaId(item)
        autoMediaCache[id] = item
        val uri = item.localPath.ifBlank { item.streamUrl }
        return MediaItem.Builder()
            .setMediaId(id)
            .setUri(uri)
            .apply { if (item.mimeType.isNotBlank()) setMimeType(item.mimeType) }
            .setMediaMetadata(MediaMetadata.Builder()
                .setTitle(displayAudioTitle(item))
                .setArtist("JW.org • Audio")
                .setAlbumTitle(item.category.ifBlank { "JW.org Audio" })
                .setDescription(item.description)
                .setIsBrowsable(false)
                .setIsPlayable(true)
                .apply { if (item.thumbnailUrl.isNotBlank()) setArtworkUri(android.net.Uri.parse(item.thumbnailUrl)) }
                .build())
            .build()
    }

    private fun audioOnly(items: List<com.tebogo.markvault.data.MediaItem>) =
        items.filter { it.mediaType.equals("audio", ignoreCase = true) }

    private val libraryCallback = object : MediaLibraryService.MediaLibrarySession.Callback {
        override fun onConnect(
            session: MediaSession,
            controller: MediaSession.ControllerInfo
        ): MediaSession.ConnectionResult {
            val commands: SessionCommands = MediaSession.ConnectionResult.DEFAULT_SESSION_AND_LIBRARY_COMMANDS
                .buildUpon()
                .add(autoShuffleCommand)
                .add(autoRepeatCommand)
                .build()
            return MediaSession.ConnectionResult.AcceptedResultBuilder(session)
                .setAvailableSessionCommands(commands)
                .setAvailablePlayerCommands(MediaSession.ConnectionResult.DEFAULT_PLAYER_COMMANDS)
                .setCustomLayout(autoControlLayout(session.player))
                .build()
        }

        override fun onCustomCommand(
            session: MediaSession,
            controller: MediaSession.ControllerInfo,
            customCommand: SessionCommand,
            args: Bundle
        ): ListenableFuture<SessionResult> {
            when (customCommand.customAction) {
                autoShuffleCommand.customAction -> {
                    session.player.shuffleModeEnabled = !session.player.shuffleModeEnabled
                    refreshAutoControlLayout()
                    return Futures.immediateFuture(SessionResult(SessionResult.RESULT_SUCCESS))
                }
                autoRepeatCommand.customAction -> {
                    session.player.repeatMode = when (session.player.repeatMode) {
                        Player.REPEAT_MODE_OFF -> Player.REPEAT_MODE_ALL
                        Player.REPEAT_MODE_ALL -> Player.REPEAT_MODE_ONE
                        else -> Player.REPEAT_MODE_OFF
                    }
                    refreshAutoControlLayout()
                    return Futures.immediateFuture(SessionResult(SessionResult.RESULT_SUCCESS))
                }
            }
            return super.onCustomCommand(session, controller, customCommand, args)
        }

        override fun onGetLibraryRoot(
            session: MediaLibraryService.MediaLibrarySession,
            browser: MediaSession.ControllerInfo,
            params: MediaLibraryService.LibraryParams?
        ): ListenableFuture<LibraryResult<MediaItem>> {
            if (!androidAutoEnabled()) {
                val disabled = MediaItem.Builder().setMediaId("markvault:auto:disabled")
                    .setMediaMetadata(MediaMetadata.Builder()
                        .setTitle("Android Auto is disabled in MarkVault Settings")
                        .setIsBrowsable(true).setIsPlayable(false).build()).build()
                return Futures.immediateFuture(LibraryResult.ofItem(disabled, params))
            }
            val root = MediaItem.Builder().setMediaId("markvault:auto:root")
                .setMediaMetadata(MediaMetadata.Builder()
                    .setTitle("MarkVault Audio")
                    .setIsBrowsable(true).setIsPlayable(false).build()).build()
            return Futures.immediateFuture(LibraryResult.ofItem(root, params))
        }

        override fun onGetChildren(
            session: MediaLibraryService.MediaLibrarySession,
            browser: MediaSession.ControllerInfo,
            parentId: String,
            page: Int,
            pageSize: Int,
            params: MediaLibraryService.LibraryParams?
        ): ListenableFuture<LibraryResult<ImmutableList<MediaItem>>> {
            if (!androidAutoEnabled()) return Futures.immediateFuture(LibraryResult.ofItemList(emptyList(), params))
            return serviceScope.future {
                val all = runCatching {
                    autoLanguageState()
                    when {
                        parentId == "markvault:auto:root" || parentId == autoHomeId -> autoHomeChildren()
                        parentId == autoAllFoldersId -> {
                            val audio = findAudioRoot() ?: return@runCatching emptyList()
                            val language = effectiveAutoLanguage(audio.key)
                            val detail = JwMediaApi.categoryDetail(audio.key, language)
                            val direct = registerAutoFolder(categoryMediaId(audio.key), audioOnly(detail.media))
                            listOf(homeButtonItem(), folderLanguagePickerItem(audio.key)) +
                                detail.subcategories.map { sub -> browsableCategory(sub, audio.key) } +
                                direct.map(::playableAudio)
                        }
                        parentId == autoLanguagePickerId -> {
                            val current = effectiveAutoLanguage()
                            listOf(homeButtonItem()) + availableAutoLanguages()
                                .sortedWith(compareByDescending<com.tebogo.markvault.network.JwMediaLanguage> { it.code == current }
                                    .thenBy { it.name.lowercase() })
                                .map { lang -> languageChoiceItem(lang, autoLanguageSetPrefix + lang.code) }
                        }
                        parentId.startsWith(autoLanguageSetPrefix) -> {
                            val language = parentId.removePrefix(autoLanguageSetPrefix).ifBlank { "E" }
                            persistGlobalAutoLanguage(language)
                            autoHomeChildren()
                        }
                        parentId == autoRecentId -> listOf(homeButtonItem()) + recentAutoAudio().map(::playableAudio)
                        parentId == autoFavouritesId -> listOf(homeButtonItem()) + favouriteAutoAudio().map(::playableAudio)
                        parentId == autoSuggestedId -> listOf(homeButtonItem()) + suggestedAutoAudio().map(::playableAudio)
                        parentId.startsWith(autoFolderLanguageSetPrefix) -> {
                            val payload = parentId.removePrefix(autoFolderLanguageSetPrefix)
                            val split = payload.lastIndexOf(':')
                            if (split <= 0 || split >= payload.lastIndex) return@runCatching emptyList()
                            val key = payload.substring(0, split)
                            val language = payload.substring(split + 1)
                            persistFolderAutoLanguage(key, language.takeUnless { it == "AUTO" })
                            categoryChildren(key, categoryMediaId(key))
                        }
                        parentId.startsWith(autoFolderLanguagePrefix) -> {
                            val key = parentId.removePrefix(autoFolderLanguagePrefix)
                            val (_, overrides) = autoLanguageState()
                            val inherited = run {
                                val parentKey = autoParentCategoryByKey[key]
                                effectiveAutoLanguage(parentKey)
                            }
                            val inheritedLabel = autoLanguageCache[inherited]?.let { it.nativeName.ifBlank { it.name } } ?: inherited
                            val autoChoice = MediaItem.Builder()
                                .setMediaId(autoFolderLanguageSetPrefix + key + ":AUTO")
                                .setMediaMetadata(MediaMetadata.Builder()
                                    .setTitle("Auto • $inheritedLabel")
                                    .setDescription(if (overrides[key] == null) "Currently selected • inherit parent/global language" else "Inherit parent/global language")
                                    .setIsBrowsable(true).setIsPlayable(false).build())
                                .build()
                            val current = effectiveAutoLanguage(key)
                            val languages = availableAutoLanguages()
                                .sortedWith(compareByDescending<com.tebogo.markvault.network.JwMediaLanguage> { it.code == current }
                                    .thenBy { it.name.lowercase() })
                                .map { lang -> languageChoiceItem(lang, autoFolderLanguageSetPrefix + key + ":" + lang.code) }
                            listOf(homeButtonItem(), autoChoice) + languages
                        }
                        parentId.startsWith("markvault:auto:cat:") -> {
                            val key = parentId.removePrefix("markvault:auto:cat:")
                            categoryChildren(key, parentId)
                        }
                        else -> emptyList()
                    }
                }.getOrElse { emptyList() }
                val from = (page * pageSize).coerceAtMost(all.size)
                val to = (from + pageSize).coerceAtMost(all.size)
                LibraryResult.ofItemList(all.subList(from, to), params)
            }
        }

        override fun onGetItem(
            session: MediaLibraryService.MediaLibrarySession,
            browser: MediaSession.ControllerInfo,
            mediaId: String
        ): ListenableFuture<LibraryResult<MediaItem>> {
            val item = autoMediaCache[mediaId]?.let(::playableAudio)
                ?: when {
                    mediaId.startsWith("markvault:auto:cat:") ->
                        autoCategoryCache[mediaId.removePrefix("markvault:auto:cat:")]?.let(::browsableCategory)
                    mediaId == autoHomeId -> homeButtonItem()
                    mediaId == autoAllFoldersId -> browsableAutoItem(autoAllFoldersId, "All audio folders", "Browse the complete JW.org Audio library")
                    mediaId == autoRecentId -> browsableAutoItem(autoRecentId, "Recently played", "Your recently played audio")
                    mediaId == autoFavouritesId -> browsableAutoItem(autoFavouritesId, "Favourites", "Audio you marked as favourite in MarkVault")
                    mediaId == autoSuggestedId -> browsableAutoItem(autoSuggestedId, "Suggested", "Based on your recent and favourite audio categories")
                    mediaId == autoLanguagePickerId -> MediaItem.Builder()
                        .setMediaId(autoLanguagePickerId)
                        .setMediaMetadata(MediaMetadata.Builder()
                            .setTitle("Language")
                            .setDescription("Change the JW.org Audio language")
                            .setIsBrowsable(true).setIsPlayable(false).build())
                        .build()
                    mediaId.startsWith(autoLanguageSetPrefix) -> {
                        val code = mediaId.removePrefix(autoLanguageSetPrefix)
                        autoLanguageCache[code]?.let { languageChoiceItem(it, mediaId) }
                    }
                    mediaId.startsWith(autoFolderLanguagePrefix) -> MediaItem.Builder()
                        .setMediaId(mediaId)
                        .setMediaMetadata(MediaMetadata.Builder()
                            .setTitle("Folder language")
                            .setDescription("Change or inherit this folder's JW.org language")
                            .setIsBrowsable(true).setIsPlayable(false).build())
                        .build()
                    else -> null
                }
            return if (item != null) Futures.immediateFuture(LibraryResult.ofItem(item, null))
            else Futures.immediateFuture(LibraryResult.ofError(LibraryResult.RESULT_ERROR_BAD_VALUE))
        }

        override fun onSearch(
            session: MediaLibraryService.MediaLibrarySession,
            browser: MediaSession.ControllerInfo,
            query: String,
            params: MediaLibraryService.LibraryParams?
        ): ListenableFuture<LibraryResult<Void>> {
            return serviceScope.future {
                val results = if (!androidAutoEnabled() || query.isBlank()) emptyList() else runCatching {
                    searchEntireAudio(query, limit = 100)
                }.getOrElse { emptyList() }
                autoSearchCache[query] = results
                results.forEach { autoMediaCache[audioMediaId(it)] = it }
                session.notifySearchResultChanged(browser, query, results.size, params)
                LibraryResult.ofVoid()
            }
        }

        override fun onGetSearchResult(
            session: MediaLibraryService.MediaLibrarySession,
            browser: MediaSession.ControllerInfo,
            query: String,
            page: Int,
            pageSize: Int,
            params: MediaLibraryService.LibraryParams?
        ): ListenableFuture<LibraryResult<ImmutableList<MediaItem>>> {
            return serviceScope.future {
                val raw = autoSearchCache[query] ?: if (androidAutoEnabled() && query.isNotBlank()) {
                    runCatching { searchEntireAudio(query, limit = 100) }.getOrElse { emptyList() }
                        .also { autoSearchCache[query] = it }
                } else emptyList()
                val results = raw.map(::playableAudio)
                val from = (page * pageSize).coerceAtMost(results.size)
                val to = (from + pageSize).coerceAtMost(results.size)
                LibraryResult.ofItemList(results.subList(from, to), params)
            }
        }

        override fun onSetMediaItems(
            mediaSession: MediaSession,
            controller: MediaSession.ControllerInfo,
            mediaItems: List<MediaItem>,
            startIndex: Int,
            startPositionMs: Long
        ): ListenableFuture<MediaSession.MediaItemsWithStartPosition> {
            if (!androidAutoEnabled() || mediaItems.isEmpty()) {
                return super.onSetMediaItems(mediaSession, controller, mediaItems, startIndex, startPositionMs)
            }
            return serviceScope.future {
                val voiceQuery = mediaItems.firstOrNull()?.requestMetadata?.searchQuery?.trim().orEmpty()
                if (voiceQuery.isNotBlank()) {
                    val best = runCatching { searchEntireAudio(voiceQuery, limit = 50) }.getOrElse { emptyList() }
                    if (best.isNotEmpty()) {
                        val selected = best.first()
                        val folder = folderQueueFor(selected)
                        if (folder != null) {
                            val (items, index) = folder
                            return@future MediaSession.MediaItemsWithStartPosition(items.map(::playableAudio), index, 0L)
                        }
                        return@future MediaSession.MediaItemsWithStartPosition(best.map(::playableAudio), 0, 0L)
                    }
                }

                if (mediaItems.size == 1) {
                    val requested = mediaItems.first()
                    val selected = autoMediaCache[requested.mediaId]
                    if (selected != null) {
                        val folder = folderQueueFor(selected)
                        if (folder != null) {
                            val (items, index) = folder
                            return@future MediaSession.MediaItemsWithStartPosition(
                                items.map(::playableAudio), index, startPositionMs.coerceAtLeast(0L)
                            )
                        }
                        return@future MediaSession.MediaItemsWithStartPosition(
                            listOf(playableAudio(selected)), 0, startPositionMs.coerceAtLeast(0L)
                        )
                    }
                }

                val resolved = mediaItems.mapNotNull { requested ->
                    when {
                        requested.localConfiguration != null -> requested
                        autoMediaCache[requested.mediaId] != null -> playableAudio(autoMediaCache[requested.mediaId]!!)
                        else -> null
                    }
                }
                if (resolved.isEmpty()) {
                    MediaSession.MediaItemsWithStartPosition(emptyList(), C.INDEX_UNSET, C.TIME_UNSET)
                } else {
                    MediaSession.MediaItemsWithStartPosition(
                        resolved, startIndex.coerceIn(0, resolved.lastIndex), startPositionMs.coerceAtLeast(0L)
                    )
                }
            }
        }

        override fun onAddMediaItems(
            mediaSession: MediaSession,
            controller: MediaSession.ControllerInfo,
            mediaItems: List<MediaItem>
        ): ListenableFuture<List<MediaItem>> {
            val voiceQuery = mediaItems.firstOrNull()?.requestMetadata?.searchQuery?.trim().orEmpty()
            if (voiceQuery.isNotBlank() && androidAutoEnabled()) {
                return serviceScope.future {
                    runCatching { searchEntireAudio(voiceQuery, limit = 50) }
                        .getOrElse { emptyList() }
                        .map(::playableAudio)
                }
            }
            val resolved = mediaItems.mapNotNull { requested ->
                val cached = autoMediaCache[requested.mediaId]
                when {
                    requested.localConfiguration != null -> requested
                    cached != null -> playableAudio(cached)
                    else -> null
                }
            }
            return Futures.immediateFuture(resolved)
        }
    }

    /** Local ExoPlayer — always allocated, active when not casting. */
    private var localPlayer: ExoPlayer? = null

    /**
     * CastPlayer — allocated only when GMS / Cast SDK is available.
     * Null on devices without Google Play Services.
     */
    private var castPlayer: CastPlayer? = null

    /** Prevents duplicate availability callbacks from transferring the same queue twice. */
    private var castTransferActive = false

    // Caption cues originate in the real ExoPlayer hosted by this service.
    // MediaController listeners are not a reliable transport for text cues
    // across the MediaSession boundary, so capture them here at the source.
    private val serviceScope = CoroutineScope(SupervisorJob() + Dispatchers.IO)

    override fun onCreate() {
        super.onCreate()

        // ── Local player ────────────────────────────────────────────────
        val exo = ExoPlayer.Builder(this).build().apply {
            // Keep network audio/video streaming alive with the display off.
            // MediaSessionService already keeps playback foreground; WAKE_MODE_NETWORK
            // adds the CPU/Wi-Fi wake handling ExoPlayer needs for remote streams.
            setWakeMode(C.WAKE_MODE_NETWORK)
        }
        localPlayer = exo

        exo.addListener(object : Player.Listener {
            override fun onCues(cueGroup: androidx.media3.common.text.CueGroup) {
                val current = exo.currentMediaItem ?: return
                if (current.mediaMetadata.extras
                        ?.getBoolean("markvault.captureVideoCaptions", false) != true) return
                val mediaId = current.mediaId.toLongOrNull() ?: return
                if (mediaId <= 0L) return
                val text = cueGroup.cues
                    .mapNotNull { it.text?.toString()?.trim() }
                    .filter { it.isNotBlank() }
                    .distinct()
                    .joinToString(" ")
                if (text.isBlank()) return
                val position = exo.currentPosition.coerceAtLeast(0L)
                serviceScope.launch {
                    runCatching {
                        val item = com.tebogo.markvault.data.VaultDb.get(this@PlaybackService)
                            .media().getById(mediaId) ?: return@runCatching
                        com.tebogo.markvault.data.VideoTranscriptStore.appendPlaybackCue(
                            this@PlaybackService, item, position, text
                        )
                    }.onFailure {
                        android.util.Log.w("MarkVaultCaptions", "Unable to persist playback caption", it)
                    }
                }
            }


            override fun onMediaItemTransition(mediaItem: MediaItem?, reason: Int) {
                val item = mediaItem?.let { autoMediaCache[it.mediaId] } ?: return
                serviceScope.launch {
                    runCatching {
                        val dao = com.tebogo.markvault.data.VaultDb.get(this@PlaybackService).media()
                        val existing = if (item.jwKey.isNotBlank()) dao.getByJwKeyAndLanguage(item.jwKey, item.contentLanguage.ifBlank { "E" }) else null
                        val rowId = if (existing != null) {
                            dao.upsert(item.copy(id = existing.id, isFavourite = existing.isFavourite, cachedAt = existing.cachedAt))
                        } else {
                            dao.upsert(item.copy(id = 0L))
                        }
                        dao.updatePlayback(rowId, System.currentTimeMillis(), 0L)
                    }.onFailure {
                        android.util.Log.w("MarkVaultAuto", "Unable to update recently played audio", it)
                    }
                }
            }

            override fun onShuffleModeEnabledChanged(shuffleModeEnabled: Boolean) {
                refreshAutoControlLayout()
            }

            override fun onRepeatModeChanged(repeatMode: Int) {
                refreshAutoControlLayout()
            }
        })

        // ── Cast player (optional — GMS required) ──────────────────────
        // CastContext.getSharedInstance() must be called on the main thread;
        // onCreate() already is. runCatching keeps the service functional
        // on devices / ROMs that lack Google Play Services.
        val castCtx = runCatching { CastContext.getSharedInstance(this) }.getOrNull()
        var cast: CastPlayer? = null
        if (castCtx != null) {
            cast = CastPlayer(castCtx)
            castPlayer = cast
            cast.setSessionAvailabilityListener(object : SessionAvailabilityListener {
                override fun onCastSessionAvailable()   = transferToCast()
                override fun onCastSessionUnavailable() = transferToLocal()
            })
        }

        // ── MediaSession ───────────────────────────────────────────────
        // If a Cast session is already active when this service starts
        // (user was already casting before opening MarkVault), begin with
        // castPlayer as the active player so MediaController commands from
        // every screen immediately reach the right destination.
        val initialPlayer: Player =
            if (cast != null && cast.isCastSessionAvailable) cast else exo

        val sessionActivityIntent = packageManager
            .getLaunchIntentForPackage(packageName)
            ?.let { launchIntent ->
                PendingIntent.getActivity(
                    this, 0, launchIntent,
                    PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
                )
            }
        val builder = MediaLibraryService.MediaLibrarySession.Builder(this, initialPlayer, libraryCallback)
            .setCustomLayout(autoControlLayout(initialPlayer))
        if (sessionActivityIntent != null) builder.setSessionActivity(sessionActivityIntent)
        mediaSession = builder.build()
    }

    /**
     * Cast session became available: transfer the FULL queue (every item,
     * not just the one currently playing) from the local ExoPlayer to the
     * CastPlayer, preserving position, current index, and shuffle/repeat
     * mode — so continuous play / shuffle / repeat keep working exactly
     * the same once casting starts. Called on the main thread by the
     * Cast SDK.
     */
    private fun transferToCast() {
        val cast    = castPlayer  ?: return
        val local   = localPlayer ?: return
        val session = mediaSession ?: return

        // Cast availability can be reported more than once while a route is
        // connecting/resuming. Never load the remote queue twice.
        if (castTransferActive || session.player === cast) return
        if (!cast.isCastSessionAvailable) return

        castTransferActive = true
        var localPlayWhenReady = local.playWhenReady
        try {
            val count = local.mediaItemCount
            if (count <= 0) {
                session.setPlayer(cast)
                local.pause()
                return
            }

            val localItems = (0 until count).map { local.getMediaItemAt(it) }
            val currentIndex = local.currentMediaItemIndex.coerceIn(0, count - 1)
            val currentPosition = local.currentPosition.coerceAtLeast(0L)
            localPlayWhenReady = local.playWhenReady
            val playWhenReady = localPlayWhenReady
            val shuffleEnabled = local.shuffleModeEnabled
            val repeatMode = local.repeatMode

            // A Chromecast receiver cannot fetch file:// or content:// URIs
            // from the sender. Only hand the CastPlayer network-reachable
            // HTTP(S) media items. This is especially important when a JW
            // item has been cached locally: local playback prefers localPath,
            // but casting must use the original stream URL.
            val castItems = localItems.filter { item ->
                val scheme = item.localConfiguration?.uri?.scheme?.lowercase()
                scheme == "http" || scheme == "https"
            }
            if (castItems.isEmpty()) {
                return
            }

            val currentLocalItem = localItems[currentIndex]
            val currentRemoteIndex = castItems.indexOfFirst {
                it.mediaId == currentLocalItem.mediaId
            }
            if (currentRemoteIndex < 0) {
                // The currently playing item is local-only. Keep local playback
                // active instead of switching to a Cast session that cannot
                // reproduce the current item.
                return
            }

            cast.setMediaItems(castItems, currentRemoteIndex, currentPosition)
            cast.shuffleModeEnabled = shuffleEnabled
            cast.repeatMode = repeatMode
            cast.prepare()
            cast.playWhenReady = playWhenReady

            // Switch the MediaSession only after the remote queue has been
            // accepted. If any Cast SDK/Media3 operation above throws, the
            // catch block leaves the local player and MediaSession untouched.
            local.pause()
            session.setPlayer(cast)
        } catch (t: Exception) {
            // A Cast connection failure must never become an uncaught exception
            // on the main thread and kill MarkVault. Restore local routing if a
            // partial transfer occurred. The Cast SDK will report the session
            // state separately and the user can retry from the Cast button.
            android.util.Log.e("MarkVaultCast", "Cast transfer failed", t)
            runCatching { cast.stop() }
            runCatching { session.setPlayer(local) }
            runCatching { local.playWhenReady = localPlayWhenReady }
        } finally {
            castTransferActive = false
        }
    }

    /**
     * Cast session ended: transfer the FULL queue back to the local
     * ExoPlayer the same way, resuming from the last known Cast position.
     * Called on the main thread by the Cast SDK.
     */
    private fun transferToLocal() {
        val cast    = castPlayer  ?: return
        val local   = localPlayer ?: return
        val session = mediaSession ?: return

        // If the session ended before the remote player had a usable queue,
        // simply restore local routing. This callback must never crash the
        // playback service during a network disconnect.
        if (session.player === local) return

        try {
            val count = cast.mediaItemCount
            if (count > 0) {
                val items = (0 until count).map { cast.getMediaItemAt(it) }
                val startIndex = cast.currentMediaItemIndex.coerceIn(0, count - 1)
                val position = cast.currentPosition.coerceAtLeast(0L)
                val playWhenReady = cast.playWhenReady
                val shuffleEnabled = cast.shuffleModeEnabled
                val repeatMode = cast.repeatMode

                local.setMediaItems(items, startIndex, position)
                local.shuffleModeEnabled = shuffleEnabled
                local.repeatMode = repeatMode
                local.prepare()
                local.playWhenReady = playWhenReady
            }

            cast.stop()
            session.setPlayer(local)
        } catch (t: Exception) {
            android.util.Log.e("MarkVaultCast", "Cast disconnect transfer failed", t)
            runCatching { session.setPlayer(local) }
        } finally {
            castTransferActive = false
        }
    }

    override fun onGetSession(
        controllerInfo: MediaSession.ControllerInfo
    ): MediaLibraryService.MediaLibrarySession? = mediaSession

    /**
     * v5.4.233cc — Only stop the service if playback isn't actually active.
     * Swiping MarkVault away from the recent-apps list fires this — without
     * this guard, audio would stop the moment the user swipes the app away,
     * defeating the whole point of background playback. Works for both local
     * and cast playback since mediaSession.player reflects whichever player
     * is currently active.
     */
    override fun onTaskRemoved(rootIntent: Intent?) {
        val player = mediaSession?.player
        if (player == null || !player.playWhenReady || player.mediaItemCount == 0) {
            stopSelf()
        }
        super.onTaskRemoved(rootIntent)
    }

    override fun onDestroy() {
        // Clear the cast listener first to prevent callbacks firing during
        // teardown while we're in the middle of releasing things.
        castPlayer?.setSessionAvailabilityListener(null)

        // Restore localPlayer as the active player before releasing through
        // the session — this ensures mediaSession.player.release() always
        // releases the local ExoPlayer exactly once, and castPlayer is
        // released separately below with no double-release risk.
        mediaSession?.run {
            val local = localPlayer
            if (local != null && player !== local) {
                runCatching { setPlayer(local) }
            }
            runCatching { player.release() }
            runCatching { release() }
            mediaSession = null
        }

        // Release cast player independently (not through the session).
        runCatching { castPlayer?.release() }
        castTransferActive = false
        castPlayer = null
        localPlayer = null
        serviceScope.cancel()

        super.onDestroy()
    }
}
