package com.tebogo.markvault.service

import android.app.PendingIntent
import android.content.Intent
import androidx.media3.cast.CastPlayer
import androidx.media3.cast.SessionAvailabilityListener
import androidx.media3.common.Player
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.session.MediaSession
import androidx.media3.session.MediaSessionService
import com.google.android.gms.cast.framework.CastContext

/**
 * v5.4.247cc — Background media playback service with Chromecast support.
 *
 * # v5.4.233cc baseline
 *
 * Hosts the SINGLE shared ExoPlayer instance + MediaSession so that:
 *   • Audio/video keeps playing when MarkVault is minimized or backgrounded
 *     (this is a real foreground Service, independent of any Activity or
 *     Compose screen's lifecycle).
 *   • The system notification shows play/pause/skip controls automatically
 *     — Media3's MediaSession wires these for us; no manual
 *     NotificationCompat / broadcast-receiver wiring needed.
 *   • Every screen that plays media (MediaPlayerScreen, FloatingMediaPopup,
 *     MiniPlayerBar) connects to THIS SAME player via MediaController, so
 *     there is only ever one active playback session — switching screens
 *     never creates duplicate ExoPlayer instances (which was itself an
 *     OOM risk before this change).
 *
 * # v5.4.247cc — Chromecast
 *
 * Adds a CastPlayer alongside the local ExoPlayer. Both implement the
 * same media3 Player interface. When the user taps the Cast button and
 * connects to a Chromecast device:
 *
 *   1. SessionAvailabilityListener.onCastSessionAvailable() fires on the
 *      main thread (called by the Cast SDK).
 *   2. The current MediaItem + playback position transfer from localPlayer
 *      → castPlayer.
 *   3. MediaSession.setPlayer(castPlayer) routes all subsequent
 *      MediaController commands (play/pause/seek from every screen and
 *      from the system notification) to the Chromecast.
 *   4. The local ExoPlayer is paused — the Chromecast is now the
 *      speaker/screen.
 *
 * When the user disconnects (tap Stop on the cast notification, or the
 * Chromecast goes offline):
 *   1. onCastSessionUnavailable() fires.
 *   2. Position transfers castPlayer → localPlayer, local playback resumes.
 *   3. MediaSession.setPlayer(localPlayer) restores local routing.
 *
 * CastPlayer is allocated only when CastContext initialises successfully.
 * On devices without Google Play Services (custom ROMs), the runCatching
 * guard keeps the rest of the service fully functional with local-only
 * playback — castPlayer stays null and no Cast button appears.
 */
class PlaybackService : MediaSessionService() {

    private var mediaSession: MediaSession? = null

    /** Local ExoPlayer — always allocated, active when not casting. */
    private var localPlayer: ExoPlayer? = null

    /**
     * CastPlayer — allocated only when GMS / Cast SDK is available.
     * Null on devices without Google Play Services.
     */
    private var castPlayer: CastPlayer? = null

    override fun onCreate() {
        super.onCreate()

        // ── Local player ────────────────────────────────────────────────
        val exo = ExoPlayer.Builder(this).build()
        localPlayer = exo

        // ── Cast player (optional — GMS required) ──────────────────────
        // CastContext.getSharedInstance() must be called on the main thread;
        // onCreate() already is. runCatching keeps the service functional
        // on devices / ROMs that lack Google Play Services.
        val castCtx = runCatching { CastContext.getSharedInstance(this) }.getOrNull()
        var cast: CastPlayer? = null
        if (castCtx != null) {
            cast = CastPlayer(castCtx)
            castPlayer = cast
            cast.setSessionAvailabilityListener(object : SessionAvailabilityListener {
                override fun onCastSessionAvailable()   = transferToCast()
                override fun onCastSessionUnavailable() = transferToLocal()
            })
        }

        // ── MediaSession ───────────────────────────────────────────────
        // If a Cast session is already active when this service starts
        // (user was already casting before opening MarkVault), begin with
        // castPlayer as the active player so MediaController commands from
        // every screen immediately reach the right destination.
        val initialPlayer: Player =
            if (cast != null && cast.isCastSessionAvailable) cast else exo

        val sessionActivityIntent = packageManager
            .getLaunchIntentForPackage(packageName)
            ?.let { launchIntent ->
                PendingIntent.getActivity(
                    this, 0, launchIntent,
                    PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
                )
            }
        val builder = MediaSession.Builder(this, initialPlayer)
        if (sessionActivityIntent != null) builder.setSessionActivity(sessionActivityIntent)
        mediaSession = builder.build()
    }

    /**
     * Cast session became available: transfer active media from the local
     * ExoPlayer to the CastPlayer, then hand the MediaSession to Cast.
     * Called on the main thread by the Cast SDK.
     */
    private fun transferToCast() {
        val cast    = castPlayer  ?: return
        val local   = localPlayer ?: return
        val session = mediaSession ?: return

        val currentItem   = local.currentMediaItem
        val position      = local.currentPosition.coerceAtLeast(0L)
        val playWhenReady = local.playWhenReady

        if (currentItem != null) {
            cast.setMediaItem(currentItem)
            cast.seekTo(position)
            cast.prepare()
            cast.playWhenReady = playWhenReady
        }

        local.pause()
        session.setPlayer(cast)
    }

    /**
     * Cast session ended: transfer media state back to the local ExoPlayer
     * and resume from the last known Cast position.
     * Called on the main thread by the Cast SDK.
     */
    private fun transferToLocal() {
        val cast    = castPlayer  ?: return
        val local   = localPlayer ?: return
        val session = mediaSession ?: return

        val currentItem   = cast.currentMediaItem
        val position      = cast.currentPosition.coerceAtLeast(0L)
        val playWhenReady = cast.playWhenReady

        if (currentItem != null) {
            local.setMediaItem(currentItem)
            local.seekTo(position)
            local.prepare()
            local.playWhenReady = playWhenReady
        }

        cast.stop()
        session.setPlayer(local)
    }

    override fun onGetSession(controllerInfo: MediaSession.ControllerInfo): MediaSession? =
        mediaSession

    /**
     * v5.4.233cc — Only stop the service if playback isn't actually active.
     * Swiping MarkVault away from the recent-apps list fires this — without
     * this guard, audio would stop the moment the user swipes the app away,
     * defeating the whole point of background playback. Works for both local
     * and cast playback since mediaSession.player reflects whichever player
     * is currently active.
     */
    override fun onTaskRemoved(rootIntent: Intent?) {
        val player = mediaSession?.player
        if (player == null || !player.playWhenReady || player.mediaItemCount == 0) {
            stopSelf()
        }
        super.onTaskRemoved(rootIntent)
    }

    override fun onDestroy() {
        // Clear the cast listener first to prevent callbacks firing during
        // teardown while we're in the middle of releasing things.
        castPlayer?.setSessionAvailabilityListener(null)

        // Restore localPlayer as the active player before releasing through
        // the session — this ensures mediaSession.player.release() always
        // releases the local ExoPlayer exactly once, and castPlayer is
        // released separately below with no double-release risk.
        mediaSession?.run {
            val local = localPlayer
            if (local != null && player !== local) {
                runCatching { setPlayer(local) }
            }
            runCatching { player.release() }
            runCatching { release() }
            mediaSession = null
        }

        // Release cast player independently (not through the session).
        runCatching { castPlayer?.release() }
        castPlayer = null
        localPlayer = null

        super.onDestroy()
    }
}
