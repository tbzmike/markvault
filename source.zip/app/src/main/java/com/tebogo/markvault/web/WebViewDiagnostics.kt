package com.tebogo.markvault.web

import android.webkit.WebView

object WebViewDiagnostics {

    fun provider(webView: WebView): String {
        return WebView.getCurrentWebViewPackage()?.versionName
            ?: "unknown"
    }
}
