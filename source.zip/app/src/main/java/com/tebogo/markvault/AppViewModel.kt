package com.tebogo.markvault

import android.app.Application
import android.content.Intent
import android.net.Uri
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import android.os.Build
import com.tebogo.markvault.data.IndexProgress
import com.tebogo.markvault.data.Indexer
import com.tebogo.markvault.data.LinkedNote
import com.tebogo.markvault.data.Note
import com.tebogo.markvault.data.NoteLink
import com.tebogo.markvault.data.NoteMeta
import com.tebogo.markvault.data.NoteTopic
import com.tebogo.markvault.data.PdfAnnotation
import com.tebogo.markvault.data.PdfHistoryEntry
import com.tebogo.markvault.data.PdfPageText
import com.tebogo.markvault.data.WebBookmark
import com.tebogo.markvault.data.WebHistoryEntry
import com.tebogo.markvault.data.Prefs
import com.tebogo.markvault.data.RecentNote
import com.tebogo.markvault.data.SearchHit
import com.tebogo.markvault.data.TopicCard
import com.tebogo.markvault.data.Topics
import com.tebogo.markvault.data.VaultDb
import com.tebogo.markvault.data.Wikilinks
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.FlowPreview
import kotlinx.coroutines.runBlocking
import kotlinx.coroutines.sync.withLock
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.SharingStarted
import androidx.compose.runtime.getValue
import androidx.compose.runtime.setValue
import com.tebogo.markvault.ui.WebTab
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.debounce
import kotlinx.coroutines.flow.distinctUntilChanged
import kotlinx.coroutines.flow.emptyFlow
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.flatMapLatest
import kotlinx.coroutines.flow.flowOn
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.flow.mapLatest
import kotlinx.coroutines.flow.merge
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

enum class SearchMode { TITLES, CONTENT }

/** Result of saveImportedMarkdown — either success with the new doc URI, or an error. */
sealed class SaveResult {
    data class Ok(val docUri: String, val fileName: String, val subfolder: String) : SaveResult()
    data class Error(val message: String) : SaveResult()
}

/** How an article was opened — used to badge it in the home recents list. */
enum class OpenSource {
    /** Opened from search, browse, recents, favourites, home — the default. */
    DIRECT,
    /** Opened by tapping a `[[wikilink]]` or a markdown link inside another note. */
    LINK,
    /** Opened from the Links & backlinks bottom sheet inside an article. */
    BACKLINK,
    /** Opened from a node in the graph view. */
    GRAPH
}

data class TabInfo(val id: Long, val title: String, val fileType: String = "md")
data class OutlineItem(val level: Int, val title: String, val index: Int)

@OptIn(FlowPreview::class, ExperimentalCoroutinesApi::class)
class AppViewModel(app: Application) : AndroidViewModel(app) {

    private val db = VaultDb.get(app)
    private val dao = db.notes()
    private val prefs = Prefs(app)
    private val indexer = Indexer(app, dao)

    /**
     * v5.4.76cc — Concrete LLM-backed query expander. Cheap to hold
     * (~stateless): the heavyweight [com.tebogo.markvault.llm.LlmManager]
     * engine is loaded and unloaded per call inside the expander, not
     * held resident here. Constructed once so all callers share one
     * expansion cache path through [com.tebogo.markvault.ai.LlmExpansionHistory].
     *
     * v5.4.79cc — Now takes lambda providers instead of a hard-coded
     * descriptor so switching models in Settings takes effect at the
     * very next submit. The lambdas read [chatActiveModelId] and
     * [memoryOptimizedLlm] each call, so nothing has to be reconstructed
     * on toggle.
     */
    private val llmQueryExpander =
        com.tebogo.markvault.llm.LlmQueryExpander(
            appContext = app.applicationContext,
            descriptorProvider = {
                val activeId = runCatching { chatActiveModelId.value }.getOrNull()
                    ?: com.tebogo.markvault.llm.ChatModelCatalog.default.id
                com.tebogo.markvault.llm.ChatModelCatalog.byId(activeId)
                    ?: com.tebogo.markvault.llm.ChatModelCatalog.default
            },
            memoryOptimizedProvider = {
                runCatching { memoryOptimizedLlm.value }.getOrDefault(true)
            },
            countProvider = {
                runCatching { llmParaphraseCount.value }.getOrDefault(
                    com.tebogo.markvault.llm.LlmQueryExpander.DEFAULT_PARAPHRASE_COUNT
                )
            }
        )

    // v4.8 — semantic search foundation. The embedder is constructed eagerly
    // with the default model, then swapped in the init block below based on
    // the user's stored activeModelId preference.
    //
    // v4.9.0 — `embedder` is now a `var` so we can swap it when the user
    // picks a different model in Settings. @Volatile keeps reads from search
    // coroutines coherent with the swap.
    @Volatile
    private var embedder: com.tebogo.markvault.search.Embedder =
        com.tebogo.markvault.search.Embedder(
            app, com.tebogo.markvault.search.ModelCatalog.default
        )

    // v4.23.0 — Cross-encoder reranker for second-stage search ranking.
    // Initialised lazily on first use. Held for the lifetime of the VM
    // so the ONNX session is paid for once and reused.
    private val reranker = com.tebogo.markvault.search.Reranker(app)

    /** True iff the .tflite model has been downloaded and is usable. */
    private val _modelAvailable = MutableStateFlow(embedder.isModelAvailable())
    val modelAvailable: StateFlow<Boolean> = _modelAvailable

    /** Download progress [0.0, 1.0]. Null when not currently downloading. */
    private val _modelDownloadProgress = MutableStateFlow<Float?>(null)
    val modelDownloadProgress: StateFlow<Float?> = _modelDownloadProgress

    /** How many notes have a current embedding under the active model version. */
    private val _embeddingCount = MutableStateFlow(0)
    val embeddingCount: StateFlow<Int> = _embeddingCount

    /** [embedded, total] progress while an embedding pass is running. Null otherwise. */
    /**
     * v4.15.0 — Embedding progress now comes from [EmbeddingProgressBus],
     * which the foreground [EmbeddingService] writes to. The VM just
     * exposes the same flow under the same public name so the Settings UI
     * keeps working without any Composable-side changes.
     */
    val embeddingProgress: StateFlow<Pair<Int, Int>?> =
        com.tebogo.markvault.search.EmbeddingProgressBus.progress

    // v4.9.0 — Semantic search controls. These mirror the corresponding Prefs
    // flows so the UI can observe them as StateFlows with synchronous .value
    // reads (the search ranking inspects semanticEnabled.value on every query).
    val semanticEnabled: StateFlow<Boolean> = prefs.semanticEnabled
        .stateIn(viewModelScope, SharingStarted.Eagerly, true)
    /**
     * v5.4.76cc — Master switch for the on-device LLM multi-query expansion
     * layer. When ON *and* the Phi-4-mini model is installed, submitted
     * searches run through [com.tebogo.markvault.llm.LlmQueryExpander] to
     * produce paraphrased sub-queries whose FTS+semantic hits are folded
     * into the merged result set. Live-typing keystrokes are not
     * LLM-expanded — only explicit submits — so a session's worth of
     * typing does not burn through the model load/unload cycle repeatedly.
     * Default OFF; the toggle lives in Settings.
     */
    val aiLlmSearchEnabled: StateFlow<Boolean> = prefs.aiLlmSearchEnabled
        .stateIn(viewModelScope, SharingStarted.Eagerly, false)
    /**
     * v5.4.79cc — Read-only observation of the LLM memory-safety belt
     * preference. See [Prefs.memoryOptimizedLlm] for what it does. On
     * by default so the fresh-install experience is stable even on the
     * ~6 GB tier where Phi-4-mini would previously OOM.
     */
    val memoryOptimizedLlm: StateFlow<Boolean> = prefs.memoryOptimizedLlm
        .stateIn(viewModelScope, SharingStarted.Eagerly, true)

    /**
     * v5.4.80cc — Slider-driven paraphrase target for the on-device
     * LLM. Range 0..10; 0 means "skip the LLM entirely" (a per-slider
     * off-switch that leaves the master AI toggle in "available"
     * state). Default 3 so users who flip the toggle on and ignore
     * the slider get a working out-of-the-box expansion.
     */
    val llmParaphraseCount: StateFlow<Int> = prefs.llmParaphraseCount
        .stateIn(viewModelScope, SharingStarted.Eagerly, 3)
    /**
     * v5.4.77cc — Side-channel signal from [expandedContentSearch]
     * telling the Search UI which hit ids in the current results
     * appeared *only* through LLM-paraphrased sub-queries, never
     * through the user's original tokens or the Kotlin synonym
     * expander. Replaces v5.4.76cc's `SearchHit.matchedViaLlm` field —
     * moving the flag off the DAO return type keeps [SearchHit] a pure
     * DB projection and dodges Room 2.8.4 KSP strictness around
     * non-null primitives on entities/projections. Emits `emptySet()`
     * whenever the LLM path is off or the search yielded no LLM-only
     * hits; SearchScreen reads it via `hit.id in vm.llmMatchedHitIds`
     * to decide when to render the "✨ AI" chip on a result row.
     */
    private val _llmMatchedHitIds = MutableStateFlow<Set<Long>>(emptySet())
    val llmMatchedHitIds: StateFlow<Set<Long>> = _llmMatchedHitIds.asStateFlow()
    /**
     * v5.4.76cc — Read-only view of every LLM query expansion the current
     * app session has recorded. Long-pressing a recent search on the Home
     * screen reads this map to show *what the LLM did to this query*.
     */
    val llmExpansionHistory: StateFlow<Map<String, com.tebogo.markvault.ai.LlmExpansionRecord>> =
        com.tebogo.markvault.ai.LlmExpansionHistory.entries
    val autoCheckModelUpdates: StateFlow<Boolean> = prefs.autoCheckModelUpdates
        .stateIn(viewModelScope, SharingStarted.Eagerly, false)
    private val _activeModelId = MutableStateFlow(
        com.tebogo.markvault.search.ModelCatalog.default.id
    )
    val activeModelId: StateFlow<String> = _activeModelId

    /** All models from the catalog, exposed for the Settings model-picker UI. */
    val availableModels: List<com.tebogo.markvault.search.ModelDescriptor> =
        com.tebogo.markvault.search.ModelCatalog.all

    // ── v4.21.0 — On-device chat (RAG) state ───────────────────────────────
    //
    // Mirrors the embedding-side state shape so the Settings UI can be
    // built the same way (status line + progress bar + install/delete
    // button). The download itself runs in a foreground service
    // ([ChatModelDownloadService]) which writes progress to
    // [ChatDownloadProgressBus], so the VM just re-exposes those flows.

    /** True iff the active chat model file is present and big enough. */
    private val _chatModelInstalled = MutableStateFlow(currentChatModelInstalled())
    val chatModelInstalled: StateFlow<Boolean> = _chatModelInstalled

    /** Download progress as (doneMb, totalMb). Null = idle. */
    val chatDownloadProgress: StateFlow<Pair<Int, Int>?> =
        com.tebogo.markvault.llm.ChatDownloadProgressBus.progress

    /** True iff the foreground download service is currently working. */
    val chatDownloadRunning: StateFlow<Boolean> =
        com.tebogo.markvault.llm.ChatDownloadProgressBus.isRunning

    /** Last download-failure message; null when none pending. */
    val chatDownloadError: StateFlow<String?> =
        com.tebogo.markvault.llm.ChatDownloadProgressBus.lastError

    /** True iff the user has paused a download in progress. */
    val chatDownloadPaused: StateFlow<Boolean> =
        com.tebogo.markvault.llm.ChatDownloadProgressBus.isPaused

    /**
     * One of "opt_in" (default — user taps Install button) or
     * "auto_prompt" (chat screen prompts on first open).
     * v4.21.0 exposes this toggle but the active code path is always
     * "opt_in" until v4.22.x wires up auto-prompt behaviour.
     */
    val chatInstallFlowPref: StateFlow<String> =
        prefs.chatInstallFlow.stateIn(viewModelScope, SharingStarted.Eagerly, "opt_in")

    /**
     * One of "own_screen" (default — dedicated chat screen via overflow
     * menu) or "in_search" (chat lives inside the Search screen).
     */
    val chatLocationPref: StateFlow<String> =
        prefs.chatLocation.stateIn(viewModelScope, SharingStarted.Eagerly, "own_screen")

    /**
     * One of "fresh_per_q" (default — each question independent) or
     * "multi_turn" (conversation kept within session).
     */
    val chatHistoryModePref: StateFlow<String> =
        prefs.chatHistoryMode.stateIn(viewModelScope, SharingStarted.Eagerly, "fresh_per_q")

    /**
     * One of "on_open" (default — load when chat screen opens), "preload"
     * (load at app start), or "on_first_q" (load on first message tap).
     * v4.21.2 exposes this toggle; v4.22.x consumes it in the chat screen.
     */
    val chatModelLoadModePref: StateFlow<String> =
        prefs.chatModelLoadMode.stateIn(viewModelScope, SharingStarted.Eagerly, "on_open")

    /** ID of the currently selected chat model. */
    val chatActiveModelId: StateFlow<String> =
        prefs.chatActiveModelId.stateIn(
            viewModelScope, SharingStarted.Eagerly,
            com.tebogo.markvault.llm.ChatModelCatalog.default.id
        )

    /** All chat models from the catalog, exposed for future model-picker UI. */
    val availableChatModels: List<com.tebogo.markvault.llm.ChatModelDescriptor> =
        com.tebogo.markvault.llm.ChatModelCatalog.all

    /**
     * Synchronous check of whether the ACTIVE chat model file exists on disk.
     *
     * v5.4.73 fix: previously hardcoded [ChatModelCatalog.default] so the
     * 1.5B model was never recognised as installed — it downloaded fine but
     * the UI looped back to "Not installed" every time.
     *
     * [chatActiveModelId] is declared after [_chatModelInstalled] in this
     * class, so the very first call (from the field initialiser) hits it
     * before it is set. [runCatching] catches the resulting NPE and falls
     * back to the default descriptor — safe for that one cold-start call.
     */
    private fun currentChatModelInstalled(): Boolean {
        val app = getApplication<Application>()
        val activeId = runCatching { chatActiveModelId.value }.getOrNull()
        val descriptor = (if (activeId != null)
            com.tebogo.markvault.llm.ChatModelCatalog.byId(activeId)
        else null) ?: com.tebogo.markvault.llm.ChatModelCatalog.default
        val f = java.io.File(app.filesDir, descriptor.localFilename)
        return f.exists() && f.length() >
            com.tebogo.markvault.llm.ChatModelCatalog.MIN_PLAUSIBLE_MODEL_BYTES
    }

    // ── v4.23.0 — Reranker (cross-encoder) state ────────────────────────────
    //
    // The reranker is a SECOND-STAGE ranking model that runs after the
    // semantic embedder. The embedder produces a rough cosine ranking from
    // 14k notes; the reranker then refines the top ~30 of those for much
    // higher precision. Wraps [com.tebogo.markvault.search.Reranker].

    /** True iff the reranker model + vocab files are installed. */
    private val _rerankerInstalled = MutableStateFlow(reranker.isInstalled())
    val rerankerInstalled: StateFlow<Boolean> = _rerankerInstalled

    /** Download progress 0.0–1.0; null when idle. */
    private val _rerankerDownloadProgress = MutableStateFlow<Float?>(null)
    val rerankerDownloadProgress: StateFlow<Float?> = _rerankerDownloadProgress

    /** True iff a download is currently in flight. */
    private val _rerankerDownloading = MutableStateFlow(false)
    val rerankerDownloading: StateFlow<Boolean> = _rerankerDownloading

    /** Last error message from a failed download. Null when no error pending. */
    private val _rerankerDownloadError = MutableStateFlow<String?>(null)
    val rerankerDownloadError: StateFlow<String?> = _rerankerDownloadError

    /** Whether reranking is on. Reads the persisted preference. */
    val rerankEnabled: StateFlow<Boolean> =
        prefs.rerankEnabled.stateIn(viewModelScope, SharingStarted.Eagerly, false)

    /** v5.2.0 — Maximum recent-search entries to show on the Home screen. */
    val maxRecentSearchesOnHome: StateFlow<Int> =
        prefs.maxRecentSearchesOnHome.stateIn(viewModelScope, SharingStarted.Eagerly, 7)

    fun setMaxRecentSearchesOnHome(v: Int) {
        viewModelScope.launch { prefs.setMaxRecentSearchesOnHome(v) }
    }

    /** v5.3.0 — How the tabs preview is laid out. "vertical" (grid scrolls
     *  vertically, 2 columns) or "horizontal" (cards swipe side to side). */
    val tabsPreviewOrientation: StateFlow<String> =
        prefs.tabsPreviewOrientation.stateIn(viewModelScope, SharingStarted.Eagerly, "vertical")

    fun setTabsPreviewOrientation(v: String) {
        viewModelScope.launch { prefs.setTabsPreviewOrientation(v) }
    }

    /** v5.3.1 — see Prefs.keywordFilterEnabled. */
    val keywordFilterEnabled: StateFlow<Boolean> =
        prefs.keywordFilterEnabled.stateIn(viewModelScope, SharingStarted.Eagerly, true)

    fun setKeywordFilterEnabled(v: Boolean) {
        viewModelScope.launch { prefs.setKeywordFilterEnabled(v) }
    }

    /** v5.4.1 — see Prefs.liveSearchEnabled. */
    val liveSearchEnabled: StateFlow<Boolean> =
        prefs.liveSearchEnabled.stateIn(viewModelScope, SharingStarted.Eagerly, true)
    fun setLiveSearchEnabled(v: Boolean) {
        viewModelScope.launch { prefs.setLiveSearchEnabled(v) }
    }

    /** v5.4.1 — see Prefs.cancelInflightSearch. */
    val cancelInflightSearch: StateFlow<Boolean> =
        prefs.cancelInflightSearch.stateIn(viewModelScope, SharingStarted.Eagerly, true)
    fun setCancelInflightSearch(v: Boolean) {
        viewModelScope.launch { prefs.setCancelInflightSearch(v) }
    }

    /** v5.4.1 — see Prefs.autoFreeMemory. */
    val autoFreeMemory: StateFlow<Boolean> =
        prefs.autoFreeMemory.stateIn(viewModelScope, SharingStarted.Eagerly, true)
    fun setAutoFreeMemory(v: Boolean) {
        viewModelScope.launch { prefs.setAutoFreeMemory(v) }
    }

    /** v5.4.5 — see Prefs.rerankOnSubmitOnly. */
    val rerankOnSubmitOnly: StateFlow<Boolean> =
        prefs.rerankOnSubmitOnly.stateIn(viewModelScope, SharingStarted.Eagerly, true)
    fun setRerankOnSubmitOnly(v: Boolean) {
        viewModelScope.launch { prefs.setRerankOnSubmitOnly(v) }
    }

    // v5.4.6 — Manual rerank trigger. The SearchScreen shows a button
    // above the result list when rerank is installed but the current
    // results haven't been reranked yet (e.g. live-typing results, or
    // when rerank is fully disabled). Tapping the button reranks the
    // current results in place — no full search re-run, just the
    // cross-encoder polish step applied to what's already shown.
    //
    // State auto-invalidates: manualRerankResult carries the query it
    // was computed for; if the user types more, the stored query stops
    // matching the current query and the UI falls back to base results.
    private val _manualRerankResult =
        MutableStateFlow<Pair<String, List<SearchHit>>?>(null)
    val manualRerankResult: StateFlow<Pair<String, List<SearchHit>>?> =
        _manualRerankResult.asStateFlow()

    private val _manualRerankInProgress = MutableStateFlow(false)
    val manualRerankInProgress: StateFlow<Boolean> =
        _manualRerankInProgress.asStateFlow()

    fun manuallyRerankCurrentResults() {
        if (_manualRerankInProgress.value) return
        val q = query.value.trim()
        val current = results.value
        if (q.length < 2 || current.isEmpty() || !_rerankerInstalled.value) return

        viewModelScope.launch(Dispatchers.IO) {
            _manualRerankInProgress.value = true
            try {
                // Synthetic descending scores so applyRerank's "tail
                // beyond maxToRerank" preservation works correctly.
                val candidates = current.take(20).mapIndexed { i, hit ->
                    hit.id to (1f - i / 20f)
                }
                val reranked = applyRerank(q, candidates, maxToRerank = 8)
                val byId = current.associateBy { it.id }
                val rerankedTop = reranked.mapNotNull { (id, _) -> byId[id] }
                val seenIds = rerankedTop.map { it.id }.toSet()
                val rest = current.filter { it.id !in seenIds }
                _manualRerankResult.value = q to (rerankedTop + rest)
            } catch (t: Throwable) {
                android.util.Log.e("MarkVault", "Manual rerank failed", t)
            } finally {
                _manualRerankInProgress.value = false
            }
        }
    }

    /** v5.4.6 — see Prefs.rerankerModelId. */
    val rerankerModelId: StateFlow<String> =
        prefs.rerankerModelId.stateIn(viewModelScope, SharingStarted.Eagerly, "ms-marco-minilm-l12-v2")
    fun setRerankerModelId(id: String) {
        viewModelScope.launch {
            prefs.setRerankerModelId(id)
            // Apply right away so subsequent searches use the new model.
            val desc = com.tebogo.markvault.search.RerankerCatalog.byId(id)
                ?: com.tebogo.markvault.search.RerankerCatalog.default
            reranker.setDescriptor(desc)
            // Refresh installed flag — different model = different file.
            _rerankerInstalled.value = reranker.isInstalled()
        }
    }

    /** v5.4.6 — see Prefs.articleHighlightEnabled. */
    val articleHighlightEnabled: StateFlow<Boolean> =
        prefs.articleHighlightEnabled.stateIn(viewModelScope, SharingStarted.Eagerly, true)
    fun setArticleHighlightEnabled(v: Boolean) {
        viewModelScope.launch { prefs.setArticleHighlightEnabled(v) }
    }

    /** v5.4.9 — see Prefs.highlightMode. Raw pref ("auto"/"smart"/"keyword"). */
    val highlightMode: StateFlow<String> =
        prefs.highlightMode.stateIn(viewModelScope, SharingStarted.Eagerly, "auto")
    fun setHighlightMode(v: String) {
        viewModelScope.launch { prefs.setHighlightMode(v) }
    }

    /** v5.4.13 — see Prefs.linkLongPressAction. */
    val linkLongPressAction: StateFlow<String> =
        prefs.linkLongPressAction.stateIn(viewModelScope, SharingStarted.Eagerly, "menu")
    fun setLinkLongPressAction(v: String) {
        viewModelScope.launch { prefs.setLinkLongPressAction(v) }
    }

    /** v5.4.35 — Open links from offline articles in new tab vs same tab. */
    val openLinksInNewTab: StateFlow<Boolean> =
        prefs.openLinksInNewTab.stateIn(viewModelScope, SharingStarted.Eagerly, true)
    fun setOpenLinksInNewTab(v: Boolean) {
        viewModelScope.launch { prefs.setOpenLinksInNewTab(v) }
    }

    /** v5.4.36 — Vertical scroll for home-screen article rows. */
    val homeScrollVertical: StateFlow<Boolean> =
        prefs.homeScrollVertical.stateIn(viewModelScope, SharingStarted.Eagerly, false)
    fun setHomeScrollVertical(v: Boolean) {
        viewModelScope.launch { prefs.setHomeScrollVertical(v) }
    }

    /** v5.4.18 — Progress-indicator + FAB toggles. See Prefs. */
    val showRerankProgress: StateFlow<Boolean> =
        prefs.showRerankProgress.stateIn(viewModelScope, SharingStarted.Eagerly, true)
    fun setShowRerankProgress(v: Boolean) {
        viewModelScope.launch { prefs.setShowRerankProgress(v) }
    }

    val showSemanticProgress: StateFlow<Boolean> =
        prefs.showSemanticProgress.stateIn(viewModelScope, SharingStarted.Eagerly, true)
    fun setShowSemanticProgress(v: Boolean) {
        viewModelScope.launch { prefs.setShowSemanticProgress(v) }
    }

    val searchInArticleFab: StateFlow<Boolean> =
        prefs.searchInArticleFab.stateIn(viewModelScope, SharingStarted.Eagerly, true)
    fun setSearchInArticleFab(v: Boolean) {
        viewModelScope.launch { prefs.setSearchInArticleFab(v) }
    }

    val semanticInArticle: StateFlow<Boolean> =
        prefs.semanticInArticle.stateIn(viewModelScope, SharingStarted.Eagerly, false)
    fun setSemanticInArticle(v: Boolean) {
        viewModelScope.launch { prefs.setSemanticInArticle(v) }
    }

    /** v5.4.33 — Search busy flag. Set true when a search starts, false when results arrive. */
    private val _searchBusy = MutableStateFlow(false)
    val searchBusy: StateFlow<Boolean> = _searchBusy

    /** v5.4.33 — Search indicator animation style. */
    val searchIndicatorStyle: StateFlow<String> =
        prefs.searchIndicatorStyle.stateIn(viewModelScope, SharingStarted.Eagerly, "percentage")
    fun setSearchIndicatorStyle(v: String) {
        viewModelScope.launch { prefs.setSearchIndicatorStyle(v) }
    }

    // ── v5.4.34 — Duplicate detection ────────────────────────────
    /** Hashed password for duplicate deletion. Empty = not set yet. */
    val duplicateDeletePassword: StateFlow<String> =
        prefs.duplicateDeletePassword.stateIn(viewModelScope, SharingStarted.Eagerly, "")

    fun setDuplicateDeletePassword(plainText: String) {
        viewModelScope.launch {
            prefs.setDuplicateDeletePassword(hashPassword(plainText))
        }
    }

    fun verifyDuplicatePassword(plainText: String): Boolean {
        return hashPassword(plainText) == duplicateDeletePassword.value
    }

    private fun hashPassword(plain: String): String {
        val md = java.security.MessageDigest.getInstance("SHA-256")
        return md.digest(plain.toByteArray()).joinToString("") { "%02x".format(it) }
    }

    /** Data class for a group of exact duplicates. */
    data class DuplicateGroup(
        val hash: String,
        val size: Long,
        val notes: List<NoteMeta>,
        val reason: String
    )

    /**
     * Scan for exact-content duplicates. Strategy:
     * 1. Group notes by file size (different sizes = not duplicates).
     * 2. For same-size groups, compute SHA-256 of full content.
     * 3. Only groups where ≥2 notes share the same hash are reported.
     * This avoids hashing all 16k+ files — only size-matched candidates.
     */
    suspend fun findDuplicates(): List<DuplicateGroup> = kotlinx.coroutines.withContext(
        kotlinx.coroutines.Dispatchers.IO
    ) {
        val candidates = dao.duplicateCandidatesBySize()
        val bySize = candidates.groupBy { it.size }
        val result = mutableListOf<DuplicateGroup>()
        val md = java.security.MessageDigest.getInstance("SHA-256")

        for (entry in bySize) {
            val sz = entry.key
            val notes = entry.value
            if (notes.size < 2) continue
            // Compute content hash for each note in this size group
            val hashToNotes = mutableMapOf<String, MutableList<NoteMeta>>()
            for (n in notes) {
                val content = dao.contentById(n.id) ?: continue
                md.reset()
                val hash = md.digest(content.toByteArray()).joinToString("") { "%02x".format(it) }
                hashToNotes.getOrPut(hash) { mutableListOf() }.add(n)
            }
            for (hashEntry in hashToNotes) {
                val hash = hashEntry.key
                val group = hashEntry.value
                if (group.size >= 2) {
                    result.add(DuplicateGroup(
                        hash = hash.take(12),
                        size = sz,
                        notes = group,
                        reason = "Identical content — SHA-256 hash match, " +
                            "file size: ${formatFileSize(sz)}, " +
                            "${group.size} copies found"
                    ))
                }
            }
        }
        result.sortedByDescending { it.notes.size }
    }

    private fun formatFileSize(bytes: Long): String = when {
        bytes < 1024 -> "$bytes B"
        bytes < 1024 * 1024 -> "${bytes / 1024} KB"
        else -> "${"%.1f".format(bytes.toDouble() / (1024 * 1024))} MB"
    }

    /** Delete notes by IDs (used by duplicate deletion). */
    fun deleteNotesByIds(ids: List<Long>) {
        viewModelScope.launch(kotlinx.coroutines.Dispatchers.IO) {
            dao.deleteByIds(ids)
        }
    }

    /** Get raw content for split-screen comparison. */
    suspend fun getContentForComparison(id: Long): String? =
        kotlinx.coroutines.withContext(kotlinx.coroutines.Dispatchers.IO) {
            dao.contentById(id)
        }

    /** v5.4.20 — see Prefs.uiMode. */
    val uiMode: StateFlow<String> =
        prefs.uiMode.stateIn(viewModelScope, SharingStarted.Eagerly, "standard")
    fun setUiMode(v: String) {
        viewModelScope.launch { prefs.setUiMode(v) }
    }

    /**
     * v5.4.18 — True when the currently-opened article was navigated to from
     * a search-result tap. Drives visibility of the "search in article" FAB
     * so it doesn't clutter the reader when browsing normally.
     *
     * Set to true by SearchScreen when a result row is clicked; reset to
     * false in the reader's LaunchedEffect after the FAB has consumed it,
     * so navigating away and re-opening from Browse hides the FAB.
     */
    private val _openedFromSearch = MutableStateFlow(false)
    val openedFromSearch: StateFlow<Boolean> = _openedFromSearch.asStateFlow()
    fun markOpenedFromSearch() { _openedFromSearch.value = true }
    fun clearOpenedFromSearch() { _openedFromSearch.value = false }

    /**
     * v5.4.18 — Semantic in-article search. Splits the article by paragraph,
     * embeds each with the active embedder, computes cosine similarity to
     * the query embedding, and returns the top paragraph's leading phrase
     * (first ~40 chars) so the reader can scroll/find to it.
     *
     * Returns null if the embedder isn't available, if the article has too
     * few embeddable paragraphs, or if any step fails. All failures are
     * silent — the caller falls back to keyword find. Runs on Dispatchers.IO
     * because embedding a page's worth of paragraphs can take a few seconds
     * on 6 GB devices.
     */
    suspend fun semanticInArticleFindTopSnippet(
        articleText: String, query: String
    ): String? = withContext(Dispatchers.IO) {
        try {
            val q = query.trim().removeSurrounding("\"").trim()
            if (q.length < 2 || articleText.isBlank()) return@withContext null
            // Simple paragraph split. Keep paragraphs of at least 40 chars
            // — anything shorter is noise (headings, single-line captions).
            val paragraphs = articleText
                .split(Regex("\\n\\s*\\n"))
                .map { it.trim() }
                .filter { it.length >= 40 }
                .take(80)  // cap so embedding stays snappy on long articles
            if (paragraphs.size < 2) return@withContext null

            // Use the same embedder the global semantic index uses.
            val queryVec = embedText(q) ?: return@withContext null
            var bestIdx = -1
            var bestScore = Float.NEGATIVE_INFINITY
            for ((i, p) in paragraphs.withIndex()) {
                val v = embedText(p) ?: continue
                val s = cosineSimilarity(queryVec, v)
                if (s > bestScore) { bestScore = s; bestIdx = i }
            }
            if (bestIdx < 0) return@withContext null
            // Return the first sentence-ish chunk of the winning paragraph
            // — long enough to be a unique WebView find target but short
            // enough that partial rendering artifacts don't break it.
            val winning = paragraphs[bestIdx]
            val firstSentence = winning
                .split(Regex("(?<=[.!?])\\s+"))
                .firstOrNull { it.length >= 20 }
                ?: winning
            firstSentence.take(60).trim()
        } catch (t: Throwable) {
            android.util.Log.e("MarkVault", "semanticInArticleFindTopSnippet failed", t)
            null
        }
    }

    /**
     * v5.4.18 — Embed a single text using the active embedder. Wraps the
     * existing embedder instance the semantic index already uses.
     * Returns null if no embedder is loaded or embedding fails.
     */
    private suspend fun embedText(text: String): FloatArray? = withContext(Dispatchers.IO) {
        try {
            embedder.embed(text)
        } catch (t: Throwable) {
            null
        }
    }

    /** Cosine similarity of two equal-length FloatArrays. Returns -1 on mismatch. */
    private fun cosineSimilarity(a: FloatArray, b: FloatArray): Float {
        if (a.size != b.size || a.isEmpty()) return -1f
        var dot = 0f; var na = 0f; var nb = 0f
        for (i in a.indices) {
            dot += a[i] * b[i]
            na += a[i] * a[i]
            nb += b[i] * b[i]
        }
        val denom = kotlin.math.sqrt(na) * kotlin.math.sqrt(nb)
        return if (denom > 0f) dot / denom else 0f
    }

    /** v5.4.9 — Resolved highlight mode that the reader actually uses.
     *  "auto" → follows semanticEnabled: smart when ON, keyword when OFF.
     *  "smart" / "keyword" → returned as-is.
     *  Readers should consult this property (not [highlightMode]) so the
     *  "auto" decision lives in one place. */
    fun effectiveHighlightMode(): String {
        val mode = highlightMode.value
        if (mode == "smart" || mode == "keyword") return mode
        // "auto" — tie to semantic search state
        return if (semanticEnabled.value) "smart" else "keyword"
    }

    /** v5.4.1 — Manually triggered search submit. Used when liveSearch
     *  is disabled so the user can fire a search via Enter / submit
     *  button without typing causing live updates. */
    private val _searchTrigger = MutableStateFlow(0L)
    fun submitSearch() {
        _searchTrigger.value = System.nanoTime()
    }

    /** Reranker descriptor, exposed for the Settings card.
     *  v5.4.6 — Now a StateFlow tied to the user's persisted model
     *  choice, so when they switch between L-12 and L-6 the UI
     *  re-renders with the right name / sizes / description. */
    val rerankerDescriptor: StateFlow<com.tebogo.markvault.search.RerankerDescriptor> =
        prefs.rerankerModelId
            .map { id ->
                com.tebogo.markvault.search.RerankerCatalog.byId(id)
                    ?: com.tebogo.markvault.search.RerankerCatalog.default
            }
            .stateIn(
                viewModelScope,
                SharingStarted.Eagerly,
                com.tebogo.markvault.search.RerankerCatalog.default
            )

    /**
     * True while a search is currently in its rerank phase. The Search
     * screen can show a small "Reranking…" indicator. Independent from
     * [rerankerDownloading] (which is for the one-time install).
     */
    private val _rerankActive = MutableStateFlow(false)
    val rerankActive: StateFlow<Boolean> = _rerankActive

    /**
     * v4.24.0 — Fine-grained rerank progress, 0.0–1.0. Updated as each
     * candidate doc is scored by the cross-encoder so the SearchScreen
     * can show a live percentage indicator in the top corner. Null when
     * no rerank is in flight.
     */
    private val _rerankProgress = MutableStateFlow<Float?>(null)
    val rerankProgress: StateFlow<Float?> = _rerankProgress

    private var rerankerDownloadJob: kotlinx.coroutines.Job? = null

    /** Trigger the reranker model download. Re-entry safe. */
    fun downloadReranker() {
        if (_rerankerDownloading.value) return
        if (rerankerDownloadJob?.isActive == true) return
        _rerankerDownloading.value = true
        _rerankerDownloadProgress.value = 0f
        _rerankerDownloadError.value = null
        rerankerDownloadJob = viewModelScope.launch(Dispatchers.IO) {
            val result = reranker.download { fraction ->
                _rerankerDownloadProgress.value = fraction
            }
            if (result.isSuccess) {
                _rerankerInstalled.value = true
            } else {
                val err = result.exceptionOrNull()
                if (err !is kotlinx.coroutines.CancellationException) {
                    _rerankerDownloadError.value =
                        err?.message ?: "Reranker download failed"
                }
            }
            _rerankerDownloading.value = false
            _rerankerDownloadProgress.value = null
        }
    }

    /** Stop an in-flight reranker download. */
    fun stopRerankerDownload() {
        rerankerDownloadJob?.cancel()
        rerankerDownloadJob = null
    }

    /** Delete the reranker model files, freeing ~33 MB. */
    fun deleteReranker() {
        stopRerankerDownload()
        viewModelScope.launch(Dispatchers.IO) {
            reranker.deleteFiles()
            _rerankerInstalled.value = false
            // Also turn the rerank toggle off — model is gone so there's
            // nothing to enable.
            if (rerankEnabled.value) prefs.setRerankEnabled(false)
        }
    }

    /** Dismiss the last error message. */
    fun clearRerankerError() {
        _rerankerDownloadError.value = null
    }

    /** Toggle reranking on/off (persists to prefs). */
    fun setRerankEnabled(v: Boolean) {
        viewModelScope.launch { prefs.setRerankEnabled(v) }
    }

    /**
     * Rerank a list of (noteId, cosineScore) candidates against [query]
     * using the cross-encoder. Returns the same list sorted by reranker
     * score descending. Falls back to the input order if the reranker
     * is unavailable or any sub-step fails — caller doesn't need to
     * check, the worst case is "we returned the cosine ranking".
     *
     * Only the top [maxToRerank] candidates are re-scored (default 25);
     * the rest are appended in original cosine order. This keeps latency
     * bounded — 25 docs × ~150 ms each on the user's S732G ≈ 3–4 s.
     */
    private suspend fun applyRerank(
        query: String,
        candidates: List<Pair<Long, Float>>,
        maxToRerank: Int = 8
    ): List<Pair<Long, Float>> {
        if (candidates.isEmpty()) return candidates
        if (!reranker.isInstalled()) return candidates

        // v5.3.0 — Top-level defensive wrapper. See semanticSearch.
        return runCatching {
            applyRerankInner(query, candidates, maxToRerank)
        }.getOrElse {
            _rerankActive.value = false
            _rerankProgress.value = null
            candidates
        }
    }

    private suspend fun applyRerankInner(
        query: String,
        candidates: List<Pair<Long, Float>>,
        maxToRerank: Int
    ): List<Pair<Long, Float>> {
        val top = candidates.take(maxToRerank)
        val tail = candidates.drop(maxToRerank)

        _rerankActive.value = true
        _rerankProgress.value = 0f
        val scores = FloatArray(top.size) { Float.NaN }
        // v5.4.3 — Track consecutive failures. If TWO in a row come
        // back null, the session is probably corrupted; unload+reload
        // to get a fresh native state for the remaining candidates.
        var consecutiveFailures = 0
        try {
            for ((i, pair) in top.withIndex()) {
                val (id, _) = pair
                val n = runCatching { dao.byId(id) }.getOrNull()
                // v5.4.3 — Shorter doc snippet (600 vs 1200). Halves
                // per-inference peak memory. Cross-encoders attend
                // primarily to early tokens anyway; the accuracy loss
                // is small and is more than paid for by no longer
                // crashing.
                val doc = n?.content?.take(600) ?: ""
                val s = runCatching {
                    reranker.score(query, doc)
                }.getOrNull()
                if (s != null) {
                    scores[i] = s
                    consecutiveFailures = 0
                } else {
                    consecutiveFailures++
                    // After two in a row, recover by recreating the
                    // session before the next iteration. This is
                    // ~200 ms slower but prevents the corruption from
                    // cascading into a full crash.
                    if (consecutiveFailures >= 2) {
                        android.util.Log.w(
                            "MarkVault",
                            "Reranker: $consecutiveFailures consecutive failures, recreating session"
                        )
                        runCatching { reranker.unload() }
                        consecutiveFailures = 0
                    }
                }
                _rerankProgress.value = ((i + 1).toFloat() / top.size.toFloat())
            }
        } finally {
            _rerankActive.value = false
            _rerankProgress.value = null
        }

        // Convert raw logits → sigmoid probability [0, 1].
        val reranked = top.mapIndexed { i, (id, _) ->
            val raw = scores[i]
            val prob = if (raw.isNaN()) 0f
                else (1f / (1f + kotlin.math.exp(-raw.toDouble()).toFloat()))
            id to prob
        }.sortedByDescending { it.second }

        return reranked + tail
    }

    /** Last "check for updates" status message. Null = never checked. */
    private val _modelUpdateStatus = MutableStateFlow<String?>(null)
    val modelUpdateStatus: StateFlow<String?> = _modelUpdateStatus

    // ── v4.8.2 — In-memory semantic index ───────────────────────────────────
    // Holds every embedding row as a parallel-array structure for fast cosine
    // scoring. Loaded lazily on the first semantic query and invalidated when
    // the user re-embeds or clears the table.
    //
    // Memory cost for a 14k library at 100 dims: 14k * 100 * 4B = ~5.6 MB.
    // Per-query cost: 14k dot products of 100 floats ≈ 5-15ms on a mid-range
    // phone, plus a single ~50-200ms MediaPipe call to embed the query.
    private data class SemanticIndex(
        val noteIds: LongArray,
        val vectors: Array<FloatArray>,
        val dim: Int
    )

    private val embeddingCacheMutex = kotlinx.coroutines.sync.Mutex()
    @Volatile
    private var semanticIndex: SemanticIndex? = null

    /**
     * Load every stored embedding into the in-memory [SemanticIndex] for fast
     * cosine scoring. Idempotent — safe to call concurrently from many search
     * coroutines because the work runs inside a mutex. Returns null when no
     * embeddings exist yet (the model hasn't been used, or the table is empty),
     * so callers can fall back cleanly to keyword-only ranking.
     */
    private suspend fun ensureSemanticIndex(): SemanticIndex? {
        semanticIndex?.let { return it }
        return embeddingCacheMutex.withLock {
            semanticIndex?.let { return@withLock it }
            if (!embedder.isModelAvailable()) return@withLock null
            val rows = runCatching {
                dao.loadAllEmbeddings(embedder.modelVersion)
            }.getOrElse { return@withLock null }
            if (rows.isEmpty()) return@withLock null
            val ids = LongArray(rows.size)
            val vecs = Array(rows.size) { i ->
                ids[i] = rows[i].noteId
                com.tebogo.markvault.search.bytesToFloatArray(rows[i].vector)
            }
            SemanticIndex(ids, vecs, rows[0].dim).also { semanticIndex = it }
        }
    }

    /** Drop the cached index so the next semantic query reloads from the DB. */
    private fun invalidateSemanticIndex() { semanticIndex = null }

    /**
     * Semantic similarity search. Embeds [query] with the on-device model, then
     * computes cosine similarity against every cached vector and returns the
     * top-[topK] `(noteId, score)` pairs, sorted by descending score.
     *
     * MediaPipe L2-normalises its embeddings, so cosine reduces to a dot
     * product — we still use the full [cosineSimilarity] helper for defensive
     * correctness, but the inner loop is the cheap path in practice.
     *
     * Returns empty list (NOT null, NOT an exception) on any soft failure:
     * model not loaded, no embeddings, embedding the query fails, etc. The
     * search pipeline blends in zero contribution and the user still gets
     * keyword + synonym + fuzzy results.
     */
    suspend fun semanticSearch(
        query: String,
        topK: Int = 200,
        allowRerank: Boolean = true
    ): List<Pair<Long, Float>> {
        if (query.isBlank()) return emptyList()
        // v5.3.1 — Defensive: every step inside can OOM or crash natively.
        return try {
            semanticSearchInner(query, topK, allowRerank)
        } catch (t: Throwable) {
            android.util.Log.e("MarkVault", "semanticSearch failed for query=\"$query\"", t)
            if (t is OutOfMemoryError) runCatching { System.gc() }
            emptyList()
        }
    }

    private suspend fun semanticSearchInner(
        query: String,
        topK: Int,
        allowRerank: Boolean
    ): List<Pair<Long, Float>> {
        val idx = ensureSemanticIndex() ?: return emptyList()
        val qVec = embedder.embed(query) ?: return emptyList()
        if (qVec.size != idx.dim) return emptyList()
        // One pass: compute (noteId, score) for every cached vector.
        val scores = FloatArray(idx.vectors.size)
        for (i in idx.vectors.indices) {
            scores[i] = com.tebogo.markvault.search.cosineSimilarity(qVec, idx.vectors[i])
        }
        // Partial top-K: sort indices by score descending, keep top K.
        // For 14k items this is cheap (~1-2ms). Skip a heap for simplicity.
        val order = (0 until scores.size).sortedByDescending { scores[it] }
        val take = order.take(topK)
        val cosineRanking = take.map { idx.noteIds[it] to scores[it] }

        // v4.23.0 — Optionally apply cross-encoder rerank as second stage.
        // v5.4.5 — Caller can suppress rerank via allowRerank=false (used
        // by the live-typing path so rerank only runs on explicit submit).
        return if (allowRerank && rerankEnabled.value && _rerankerInstalled.value) {
            applyRerank(query, cosineRanking)
        } else {
            cosineRanking
        }
    }

    init {
        // v5.4.0 — Make ourselves reachable from the Application's
        // memory-pressure callbacks. The Application holds a weak-ish
        // reference (volatile var) and only uses it to invoke
        // freeMemory() when the OS signals memory tightness.
        runCatching { (app as? MarkVaultApp)?.sharedVm = this }
        // v5.4.6 — Apply persisted reranker model id at startup so the
        // user's L-12-vs-L-6 choice survives process restart.
        viewModelScope.launch {
            val id = prefs.rerankerModelId.first()
            val desc = com.tebogo.markvault.search.RerankerCatalog.byId(id)
            if (desc != null && desc.id != reranker.currentDescriptor().id) {
                reranker.setDescriptor(desc)
                _rerankerInstalled.value = reranker.isInstalled()
            }
        }
        viewModelScope.launch(Dispatchers.IO) {
            // v5.4.37 — Prune orphaned embedding rows on startup.
            // INSERT OR REPLACE in the indexer changes note ids,
            // leaving old embeddings keyed to dead noteIds. Without
            // this, the count doubles after every full re-index.
            runCatching { dao.pruneOrphanEmbeddings() }
            _embeddingCount.value = runCatching {
                dao.embeddingCount(embedder.modelVersion)
            }.getOrElse { 0 }
        }
        // v4.21.0 — re-check chat-model installation whenever the
        // download service finishes (success or cancel).
        observeChatDownloadCompletion()
        // v4.22.0 — if user picked "preload" mode, load the LLM in the
        // background after app start. No-op for default "on_open" mode.
        maybePreloadChatModel()
        // v4.9.0 — listen for active-model preference changes (including the
        // initial value at startup) and swap the embedder when the preferred
        // model differs from the one currently loaded. Each swap closes the
        // old embedder, refreshes the model-availability + embedding-count
        // state flows, and invalidates the semantic index so the next search
        // reloads under the new model's vectors.
        viewModelScope.launch {
            prefs.activeModelId.collect { id ->
                val descriptor = com.tebogo.markvault.search.ModelCatalog.byId(id)
                    ?: com.tebogo.markvault.search.ModelCatalog.default
                if (descriptor.id != embedder.descriptor.id) {
                    val old = embedder
                    embedder = com.tebogo.markvault.search.Embedder(
                        getApplication(), descriptor
                    )
                    runCatching { old.close() }
                    _modelAvailable.value = embedder.isModelAvailable()
                    _embeddingCount.value = runCatching {
                        dao.embeddingCount(embedder.modelVersion)
                    }.getOrElse { 0 }
                    invalidateSemanticIndex()
                }
                _activeModelId.value = descriptor.id
            }
        }

        // v4.15.0 — When the foreground embedding service finishes (whether
        // by completing the pass, being cancelled by the user, or being
        // killed by the OS), refresh our local cached count and drop the
        // semantic index so the next search reloads vectors from the DB.
        // The collect fires on every isRunning transition including the
        // initial `false` at app launch — that's harmless because the count
        // refresh is idempotent.
        viewModelScope.launch {
            com.tebogo.markvault.search.EmbeddingProgressBus.isRunning.collect { running ->
                if (!running) {
                    _embeddingCount.value = runCatching {
                        dao.embeddingCount(embedder.modelVersion)
                    }.getOrElse { _embeddingCount.value }
                    invalidateSemanticIndex()
                }
            }
        }
    }

    val libraryUri: StateFlow<String?> =
        prefs.libraryUri.stateIn(viewModelScope, SharingStarted.Eagerly, null)
    val fontScale: StateFlow<Float> =
        prefs.fontScale.stateIn(viewModelScope, SharingStarted.Eagerly, 1.0f)
    val theme: StateFlow<String> =
        prefs.theme.stateIn(viewModelScope, SharingStarted.Eagerly, "dark")
    // Performance/feature toggles — let the user opt in to heavier features.
    val smartStylingAllDocs: StateFlow<Boolean> =
        prefs.smartStylingAllDocs.stateIn(viewModelScope, SharingStarted.Eagerly, false)
    val swipeSwitchTabs: StateFlow<Boolean> =
        prefs.swipeSwitchTabs.stateIn(viewModelScope, SharingStarted.Eagerly, false)
    val textContrast: StateFlow<Float> =
        prefs.textContrast.stateIn(viewModelScope, SharingStarted.Eagerly, 1.0f)

    private val _progress = MutableStateFlow(IndexProgress())
    val progress: StateFlow<IndexProgress> = _progress

    private val _notes = MutableStateFlow<List<NoteMeta>>(emptyList())
    val notes: StateFlow<List<NoteMeta>> = _notes

    private val _recent = MutableStateFlow<List<RecentNote>>(emptyList())
    val recent: StateFlow<List<RecentNote>> = _recent

    private val _topics = MutableStateFlow<List<TopicCard>>(emptyList())
    val topics: StateFlow<List<TopicCard>> = _topics

    /** Notes added to the library since the last manual re-index (empty until first reindex). */
    private val _newNotes = MutableStateFlow<List<NoteMeta>>(emptyList())
    val newNotes: StateFlow<List<NoteMeta>> = _newNotes

    /** IDs of notes the user has starred as favourites. */
    private val _favouriteIds = MutableStateFlow<Set<Long>>(emptySet())
    val favouriteIds: StateFlow<Set<Long>> = _favouriteIds

    /** Starred notes as NoteMeta list for the home screen. */
    private val _favouriteNotes = MutableStateFlow<List<NoteMeta>>(emptyList())
    val favouriteNotes: StateFlow<List<NoteMeta>> = _favouriteNotes

    /** Notes recommended to the user — based on topic overlap with what they've been reading. */
    private val _suggested = MutableStateFlow<List<NoteMeta>>(emptyList())
    val suggested: StateFlow<List<NoteMeta>> = _suggested

    // ---- Recent search clicks (persisted, capped at 20) ----
    private val _recentSearches = MutableStateFlow<List<RecentSearch>>(emptyList())
    val recentSearches: StateFlow<List<RecentSearch>> = _recentSearches
    private val maxRecentSearches = 20

    /** Called when the user taps a search result. Stores the query + the note it led to. */
    fun recordSearchClick(query: String, noteId: Long, title: String, relPath: String) {
        val q = query.trim()
        if (q.isEmpty()) return
        val now = System.currentTimeMillis()
        val entry = RecentSearch(query = q, noteId = noteId, title = title, relPath = relPath, ts = now)
        // Dedup: drop any existing entry for the same (query, noteId), then prepend the fresh one
        val cur = _recentSearches.value
        val deduped = cur.filterNot { it.noteId == noteId && it.query.equals(q, ignoreCase = true) }
        val updated = (listOf(entry) + deduped).take(maxRecentSearches)
        _recentSearches.value = updated
        viewModelScope.launch(Dispatchers.IO) { runCatching { prefs.setRecentSearchesRaw(encodeRecents(updated)) } }
    }

    fun clearRecentSearches() {
        _recentSearches.value = emptyList()
        viewModelScope.launch(Dispatchers.IO) { runCatching { prefs.setRecentSearchesRaw("") } }
    }

    // ---- Open article tabs ----
    private val _tabs = MutableStateFlow<List<TabInfo>>(emptyList())
    val tabs: StateFlow<List<TabInfo>> = _tabs
    private val _activeTab = MutableStateFlow<Long?>(null)
    val activeTab: StateFlow<Long?> = _activeTab
    private val maxTabs = 8

    /**
     * In-Reader navigation history (tab IDs visited, oldest → newest).
     * Lets the system Back button return through previously-viewed tabs (e.g. after tapping a
     * backlink) instead of immediately exiting the Reader.
     */
    private val _tabHistory = MutableStateFlow<List<Long>>(emptyList())
    val tabHistory: StateFlow<List<Long>> = _tabHistory
    private val maxHistory = 50

    private fun pushHistory(id: Long) {
        val cur = _tabHistory.value
        if (cur.lastOrNull() == id) return // dedupe consecutive
        val updated = (cur + id)
        _tabHistory.value = if (updated.size > maxHistory) updated.takeLast(maxHistory) else updated
    }

    /**
     * Pop the current tab off history and activate the previous one.
     * Returns true if we moved back inside the Reader; false if there's nowhere to go back to
     * (caller should let the system Back press exit the Reader).
     */
    fun goBackInTabs(): Boolean {
        val cur = _tabHistory.value
        if (cur.size < 2) return false
        val updated = cur.dropLast(1)
        _tabHistory.value = updated
        _activeTab.value = updated.last()
        return true
    }

    /**
     * Switch to the next / previous tab in the open tabs list (not history).
     * Used by swipe-left / swipe-right gestures inside the Reader.
     * Returns true if it switched, false if there's only one tab.
     */
    fun switchTabByDirection(forward: Boolean): Boolean {
        val list = _tabs.value
        if (list.size < 2) return false
        val curId = _activeTab.value ?: list.first().id
        val idx = list.indexOfFirst { it.id == curId }
        if (idx < 0) return false
        val next = if (forward) (idx + 1) % list.size else (idx - 1 + list.size) % list.size
        val newId = list[next].id
        _activeTab.value = newId
        pushHistory(newId)
        return true
    }

    /** Clear the tab visit history. Called when the Reader exits to home / search etc. */
    fun clearTabHistory() { _tabHistory.value = emptyList() }

    val query = MutableStateFlow("")
    val mode = MutableStateFlow(SearchMode.CONTENT)
    /**
     * When ON, wraps the user's query in quotes before searching so FTS treats it
     * as an exact phrase. Only meaningful for SearchMode.CONTENT (the UI hides the
     * toggle in TITLES mode where it has no effect).
     */
    val quotePhrase = MutableStateFlow(false)

    val results: StateFlow<List<SearchHit>> = run {
        // v5.4.5 — Each search emission carries a flag indicating whether
        // it came from live debounced typing or an explicit submit. The
        // mapper uses this flag (combined with rerankOnSubmitOnly) to
        // decide whether to apply the cross-encoder.
        data class SearchReq(
            val q: String,
            val m: SearchMode,
            val qp: Boolean,
            val isSubmit: Boolean
        )

        // Live debounced stream — only flows when liveSearchEnabled.
        val liveStream: Flow<SearchReq> = liveSearchEnabled.flatMapLatest { live ->
            if (live) {
                combine(
                    query.debounce(220).map { it.trim() }.distinctUntilChanged(),
                    mode, quotePhrase
                ) { q, m, qp -> SearchReq(q, m, qp, isSubmit = false) }
            } else {
                emptyFlow()
            }
        }

        // Explicit submit stream — always flows regardless of live setting.
        val submitStream: Flow<SearchReq> = _searchTrigger.map {
            SearchReq(query.value.trim(), mode.value, quotePhrase.value, isSubmit = true)
        }

        val merged: Flow<SearchReq> = merge(liveStream, submitStream)

        val mapper: suspend (SearchReq) -> List<SearchHit> = { req ->
            _searchBusy.value = true
            try {
                // v5.4.5 — Rerank gate. When rerankOnSubmitOnly is ON
                // (default), only submit emissions get the cross-encoder.
                // Live-typing emissions return cosine-ranked results
                // immediately, which is fast and crash-proof. When OFF,
                // rerank runs everywhere (old behaviour).
                val rerankAllowed = req.isSubmit || !rerankOnSubmitOnly.value
                // v5.4.14 — Strip surrounding quotes from the typed query
                // before anything else. The exact-phrase toggle auto-wraps
                // the visible query string in quotes (for UI clarity), but
                // the search backend doesn't want them embedded — it adds
                // its own quotes via the [exactPhrase] flag. If we let the
                // quotes through, expand() tokenizes ['"abraham',
                // 'covenant"'] and the per-variant wrap re-adds quotes,
                // producing the invalid FTS '""abraham""' '""covenant""'
                // which silently returns no results. Strip once, here,
                // everything downstream gets the clean form.
                val rawCleaned = req.q.trim().removeSurrounding("\"").trim()
                when {
                    rawCleaned.length < 2 -> emptyList()
                    req.m == SearchMode.TITLES -> runCatching {
                        // v5.4.14 — Obsidian-style title search: tokenize,
                        // AND-match every word in the title (any order,
                        // case-insensitive). NO synonym expansion, NO
                        // semantic blend, NO rerank — the user wants the
                        // simple file-name search behaviour, identical to
                        // Obsidian's quick-switcher.
                        titleSearch(rawCleaned)
                    }.getOrElse { emptyList() }
                    else -> {
                        val effective = if (req.qp) "\"$rawCleaned\"" else rawCleaned
                        runCatching {
                            expandedContentSearch(
                                effective,
                                originalRaw = rawCleaned,
                                exactPhrase = req.qp,
                                allowRerank = rerankAllowed,
                                isSubmit = req.isSubmit
                            )
                        }.getOrElse { emptyList() }
                    }
                }
            } catch (t: Throwable) {
                android.util.Log.e(
                    "MarkVault",
                    "Search pipeline failed for query=\"${req.q}\" mode=${req.m} submit=${req.isSubmit}",
                    t
                )
                if (t is OutOfMemoryError) runCatching { System.gc() }
                emptyList()
            } finally {
                _searchBusy.value = false
            }
        }

        cancelInflightSearch.flatMapLatest { cancelEnabled ->
            if (cancelEnabled) {
                merged.mapLatest(mapper)
            } else {
                merged.map(mapper)
            }
        }.flowOn(Dispatchers.IO)
            .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())
    }

    /**
     * v4.7.7 — title search with synonym expansion + fuzzy re-ranking.
     * Strategy: run `titleSearch` against each variant from [QueryExpander.expand],
     * union the result IDs (de-duping by id), then re-rank using a fuzzy boost
     * computed against the original query tokens. Backward compatible: when
     * the query produces no expansion (no synonym matches), the output equals
     * the old direct `titleSearch(q)`.
     */
    private suspend fun expandedTitleSearch(raw: String, allowRerank: Boolean = true): List<SearchHit> {
        // v5.4.10 — Perf fast path. When semantic search is OFF, every
        // extra synonym variant is another FTS query and another round
        // trip through ranking; the user reports this got slow over the
        // last few versions. Cap variants tightly in semantic-off mode
        // (just the original — 1× FTS instead of up to 8× FTS). Keep
        // the full expansion when semantic is ON since variants
        // genuinely help recall on the keyword side of the blend.
        val maxVariants = if (semanticEnabled.value) 8 else 1
        val variants = com.tebogo.markvault.search.QueryExpander.expand(raw, maxVariants)
        val keywordHits = LinkedHashMap<Long, SearchHit>()
        for (v in variants) {
            val hits = runCatching { titleSearch(v) }.getOrElse { emptyList() }
            for (h in hits) keywordHits.putIfAbsent(h.id, h)
        }
        return blendSemanticAndKeyword(
            keywordHits = keywordHits,
            originalRaw = raw,
            scoreSource = { hit -> hit.title + " " + hit.relPath },
            allowRerank = allowRerank
        )
    }

    /**
     * v4.7.7 — full-text content search with synonym expansion. Same approach
     * as [expandedTitleSearch], but with one safety: in exact-phrase mode we
     * still run every expanded variant as an exact phrase, so the user's
     * intent ("phrase match") is preserved on each variant individually. If
     * any single variant matches, the user gets results.
     *
     * v5.4.5 — Takes [allowRerank] so the live-typing path can suppress
     * the expensive cross-encoder while the submit path still applies it.
     *
     * v5.4.10 — Caps variants to 1 when semantic search is OFF, restoring
     * the snappy keyword-only search performance that regressed.
     */
    private suspend fun expandedContentSearch(
        effective: String, originalRaw: String, exactPhrase: Boolean,
        allowRerank: Boolean = true,
        isSubmit: Boolean = false
    ): List<SearchHit> {
        // ── v5.4.81cc — LLM expansion is now decoupled from semantic ─────────
        //
        // Previously the semantic-OFF branch bailed to a single-query
        // FTS call and skipped the LLM entirely. That contradicted the
        // "LLM multi-query retrieval works even without vector
        // embeddings" intent — a well-designed retrieval pipeline can
        // absolutely stand on LLM-generated keyword paraphrases alone,
        // fused across queries with Reciprocal Rank Fusion. v5.4.81cc
        // computes the LLM paraphrases once at the top of the function
        // and hands them to whichever downstream merge path the user's
        // semantic-search setting selects.
        //
        // Fires only when *every* condition is met:
        //   1. `aiLlmSearchEnabled` is ON in Settings.
        //   2. `llmParaphraseCount > 0` on the slider.
        //   3. Either the user pressed submit, or we already have a
        //      cached expansion for this query.
        //   4. The active model's file is on disk and larger than the
        //      plausibility floor.
        val llmParaphrases: List<String> =
            if (aiLlmSearchEnabled.value &&
                llmParaphraseCount.value > 0 &&
                isLlmModelInstalledFast()
            ) {
                val cached = com.tebogo.markvault.ai.LlmExpansionHistory.get(originalRaw)
                if (cached != null) cached.paraphrases
                else if (isSubmit) {
                    runCatching { llmQueryExpander.expandQuery(originalRaw) }
                        .getOrElse { emptyList() }
                }
                else emptyList()
            } else emptyList()

        val llmVariantsLower: Set<String> = llmParaphrases
            .map { it.trim().lowercase() }
            .filter { it.isNotEmpty() }
            .toHashSet()

        // v5.4.14 — When semantic search is OFF, the user wants pure
        // literal keyword search. Previously this bailed immediately
        // with a single FTS call.
        //
        // v5.4.81cc — When LLM is on and produced paraphrases, we now
        // run FTS on each paraphrase alongside the original query and
        // merge with Reciprocal Rank Fusion. This gives the "LLM
        // multi-query retrieval without semantic" pipeline the user
        // asked for: no vector embeddings involved, just the LLM's
        // ability to phrase the same intent multiple ways and let each
        // rephrasing surface FTS hits the others would miss.
        if (!semanticEnabled.value) {
            if (llmParaphrases.isEmpty()) {
                // No LLM paraphrases → preserve the pre-v5.4.81cc
                // behaviour exactly: single FTS call, no expansion, no
                // blend. This keeps semantic-off + LLM-off users on the
                // bit-identical path they had before.
                _llmMatchedHitIds.value = emptySet()
                return runCatching {
                    rankedContentSearch(effective, originalRaw = originalRaw)
                }.getOrElse { emptyList() }
            }
            // Multi-query FTS across the original + paraphrases.
            val queries = listOf(originalRaw) + llmParaphrases
            val perQueryHits: List<List<SearchHit>> = queries.map { q ->
                val eff = if (exactPhrase) "\"$q\"" else q
                runCatching {
                    rankedContentSearch(eff, originalRaw = q)
                }.getOrElse { emptyList() }
            }
            // Track which hit ids appeared *only* through an LLM
            // paraphrase — same signal we use in the semantic-ON path.
            // Query index 0 is the original.
            val originalHitIds: Set<Long> =
                perQueryHits.firstOrNull()?.map { it.id }?.toHashSet().orEmpty()
            val allHitIds: HashSet<Long> = HashSet()
            for (list in perQueryHits) for (h in list) allHitIds.add(h.id)
            _llmMatchedHitIds.value = allHitIds - originalHitIds

            // RRF fuse.
            val fused = reciprocalRankFusion(perQueryHits, k = RRF_K)

            // Optional cross-encoder rerank on top — the "Retrieve-then-
            // Refine" pipeline. Reranker is orthogonal to semantic
            // search; when installed and enabled it strictly improves
            // ordering regardless of how the candidates were retrieved.
            return maybeRerank(fused, originalRaw, allowRerank)
        }

        // ── Semantic ON path ────────────────────────────────────────────────
        val variants = com.tebogo.markvault.search.QueryExpander.expand(originalRaw, 8)

        val allVariants: List<String> =
            (variants + llmParaphrases)
                .map { it.trim() }
                .filter { it.isNotEmpty() }
                .distinctBy { it.lowercase() }

        val keywordHits = LinkedHashMap<Long, SearchHit>()
        val nonLlmHitIds = HashSet<Long>()
        for (v in allVariants) {
            val effv = if (exactPhrase) "\"$v\"" else v
            val hits = runCatching {
                rankedContentSearch(effv, originalRaw = v)
            }.getOrElse { emptyList() }
            val fromLlmOnly = v.lowercase() in llmVariantsLower
            for (h in hits) {
                keywordHits.putIfAbsent(h.id, h)
                if (!fromLlmOnly) nonLlmHitIds.add(h.id)
            }
        }
        val llmOnlyHitIds: Set<Long> = keywordHits.keys - nonLlmHitIds
        _llmMatchedHitIds.value = llmOnlyHitIds

        val blended = blendSemanticAndKeyword(
            keywordHits = keywordHits,
            originalRaw = originalRaw,
            scoreSource = { hit -> hit.title + " " + hit.snippet },
            allowRerank = allowRerank
        )
        return blended
    }

    /**
     * v5.4.81cc — Reciprocal Rank Fusion. Given the ranked FTS hits
     * from each of several paraphrased sub-queries, produce a single
     * ranked list where each hit's score is the sum of `1 / (k + rank)`
     * contributions from every query that surfaced it.
     *
     * `k` (default 60 per the classic RRF paper) softens the impact of
     * being ranked #1 vs #10 in any single query — a hit that appears
     * at rank 5 in three different paraphrases beats a hit that
     * appears at rank 1 in only one, which is exactly the "surfaced
     * consistently across rewrites → probably relevant" signal
     * multi-query retrieval is trying to capture.
     *
     * Hit metadata (title, snippet, fileType) is preserved from the
     * first query that saw it — good enough for display; the FTS
     * snippet is per-query anyway so there's no globally "correct"
     * choice. Score field left as null: RRF scores are on a different
     * scale than the semantic 0..1 confidence and mixing them in the
     * UI's percentage chip would mislead.
     */
    private fun reciprocalRankFusion(
        perQueryHits: List<List<SearchHit>>,
        k: Int = 60
    ): List<SearchHit> {
        val firstSeen = LinkedHashMap<Long, SearchHit>()
        val scores = HashMap<Long, Double>()
        for (queryHits in perQueryHits) {
            for ((rankZeroBased, hit) in queryHits.withIndex()) {
                firstSeen.putIfAbsent(hit.id, hit)
                val contrib = 1.0 / (k + rankZeroBased + 1)  // RRF is 1-indexed
                scores.merge(hit.id, contrib) { a, b -> a + b }
            }
        }
        return firstSeen.entries
            .sortedByDescending { scores[it.key] ?: 0.0 }
            .map { it.value }
    }

    /**
     * v5.4.81cc — Optional cross-encoder rerank pass, factored out so
     * the RRF path can share it with the semantic-ON blend. When the
     * reranker is installed and (rerank pref is on OR `allowRerank` is
     * forced true), reorder the top slice with the cross-encoder and
     * return the reranked list; otherwise return the input unchanged.
     *
     * Fails gracefully — any reranker error falls back to the input
     * ordering rather than failing the search.
     *
     * ## Adapting SearchHit to applyRerank's Pair-based API
     *
     * [applyRerank] wants `List<Pair<Long, Float>>` where the Float is
     * an existing cosine score. RRF scores aren't cosines — they're on
     * a different scale — but the cross-encoder only uses this Float
     * for tie-breaking below its own logit and for the "candidates
     * below top-K stay in input order" tail. Feeding it a synthetic
     * strictly-decreasing pseudo-score preserves both properties:
     *   1. Ties within RRF map to distinct pseudo-scores, so no rerank
     *      ordering gets clobbered.
     *   2. The tail after top-K keeps our RRF ordering.
     */
    private suspend fun maybeRerank(
        hits: List<SearchHit>,
        originalRaw: String,
        allowRerank: Boolean
    ): List<SearchHit> {
        if (!allowRerank) return hits
        if (!rerankEnabled.value) return hits
        if (!rerankerInstalled.value) return hits
        if (hits.isEmpty()) return hits
        val candidates: List<Pair<Long, Float>> = hits.mapIndexed { idx, hit ->
            // Strictly decreasing pseudo-score so applyRerank's stable
            // sort behaves. 1.0 down to ~0.0 across the input length.
            val pseudo = 1f - (idx.toFloat() / hits.size.coerceAtLeast(1))
            hit.id to pseudo
        }
        val reranked = runCatching {
            applyRerank(originalRaw, candidates)
        }.getOrElse { return hits }
        // Map back to SearchHit order.
        val byId = hits.associateBy { it.id }
        return reranked.mapNotNull { (id, _) -> byId[id] }
    }

    /**
     * v5.4.76cc — Fast synchronous check for "is the currently active
     * LLM model file on disk and plausibly complete". Used inside the
     * search hot path to gate LLM expansion without paying for a full
     * descriptor lookup. Cheap: two virtual-filesystem calls (exists,
     * length).
     *
     * v5.4.80cc — Fixed a critical bug: the check previously used
     * `ChatModelCatalog.default`, which after v5.4.79cc changed to
     * SmolLM2. That meant Phi-4-mini users whose SmolLM2 wasn't
     * installed had the LLM path silently skipped even though their
     * *chosen* model was ready to go. Now honours [chatActiveModelId].
     */
    private fun isLlmModelInstalledFast(): Boolean {
        val activeId = runCatching { chatActiveModelId.value }.getOrNull()
            ?: com.tebogo.markvault.llm.ChatModelCatalog.default.id
        val desc = com.tebogo.markvault.llm.ChatModelCatalog.byId(activeId)
            ?: com.tebogo.markvault.llm.ChatModelCatalog.default
        val f = java.io.File(getApplication<Application>().filesDir, desc.localFilename)
        return f.exists() &&
            f.length() > com.tebogo.markvault.llm.ChatModelCatalog.MIN_PLAUSIBLE_MODEL_BYTES
    }

    /**
     * v4.8.2 — final ranking stage shared by both expanded* functions.
     *
     * Combines three signals into a single blended score:
     *
     *   1. **Keyword hit bonus** — if the note appeared in any keyword/synonym
     *      result set, it gets a flat +5000 boost. This anchors literal matches
     *      at the top so a user searching "Abraham" still sees the Abraham
     *      article first even if some other article is semantically closer.
     *
     *   2. **Semantic similarity** — cosine vs query embedding, mapped from
     *      `[-1, 1]` to `[0, 5000]` via `cos * 5000`. A near-perfect semantic
     *      match (cos ≈ 1.0) earns about the same as a keyword hit, so pure
     *      semantic matches surface alongside literal matches when they're
     *      strongly related but use different vocabulary.
     *
     *   3. **Fuzzy boost** — small additive for typos / inflectional variants
     *      (~10-30 each). Mostly tiebreaker.
     *
     * The blend is intentionally additive (not multiplicative) so a single
     * strong signal alone is enough to surface a result. The score is then
     * sorted descending and the top 400 returned.
     *
     * Pure-semantic candidates (semantic hit but no keyword hit) have their
     * `SearchHit` rows lazily constructed from `dao.byId(id)` since the
     * keyword path didn't produce one. Their `snippet` is empty — that's
     * fine; the result row falls back to the title + path + context preview.
     */
    private suspend fun blendSemanticAndKeyword(
        keywordHits: LinkedHashMap<Long, SearchHit>,
        originalRaw: String,
        scoreSource: (SearchHit) -> String,
        allowRerank: Boolean = true
    ): List<SearchHit> {
        // v4.9.0 — gate the semantic step on the user's toggle. When the
        // switch is off in Settings, we skip the query-embedding call and
        // the cosine scan entirely; the pipeline falls back to pure keyword
        // + synonym + fuzzy ranking. Cheap (no MediaPipe call, no 14k
        // dot products) and gives the user A/B-comparison capability.
        val useSemantic = semanticEnabled.value
        val semantic = if (useSemantic) {
            runCatching {
                semanticSearch(originalRaw, topK = 200, allowRerank = allowRerank)
            }.getOrElse { emptyList() }
        } else emptyList()
        val semanticScores: Map<Long, Float> = semantic.toMap()

        // Union of all candidate IDs.
        val allIds: Set<Long> = LinkedHashSet<Long>().apply {
            addAll(keywordHits.keys)
            for (s in semantic) add(s.first)
        }
        if (allIds.isEmpty()) return emptyList()

        val originalTokens = originalRaw.split(Regex("\\s+")).filter { it.isNotEmpty() }
        val scored = ArrayList<Pair<SearchHit, Int>>(allIds.size)

        for (id in allIds) {
            // Prefer the keyword-side SearchHit (already has snippet); fall
            // back to fabricating a hit from the Note row for semantic-only IDs.
            val baseHit = keywordHits[id] ?: run {
                val n = runCatching { dao.byId(id) }.getOrNull()
                    ?: return@run null
                SearchHit(
                    id = n.id, relPath = n.relPath, title = n.title,
                    snippet = "", fileType = n.fileType
                )
            } ?: continue

            val keywordBonus = if (id in keywordHits) 5000 else 0
            val semScore = semanticScores[id]   // null when not in semantic set
            val semBoost = ((semScore ?: 0f) * 5000f).toInt()
            val fuzzyBoost = com.tebogo.markvault.search.QueryExpander.fuzzyBoost(
                scoreSource(baseHit), originalTokens
            )
            // v4.24.0 — Attach the semantic relevance score onto the hit
            // so the UI can render a percentage chip. When the reranker
            // is on, this is a sigmoid-of-logit probability; when only
            // cosine is used, this is the raw BGE-large cosine value.
            // Both are 0–1 and directly usable as a percentage.
            val hit = if (semScore != null) baseHit.copy(score = semScore)
                      else baseHit
            scored.add(hit to (keywordBonus + semBoost + fuzzyBoost))
        }
        return scored
            .sortedByDescending { it.second }
            .map { it.first }
            .take(400)
    }

    /**
     * Content search with smarter ranking. Prefers, in order:
     *  1. Exact phrase appearing in the title
     *  2. Exact phrase appearing in the content
     *  3. All query words appearing in the title (any order)
     *  4. All query words appearing in the content
     *  5. Most query words appearing somewhere (last resort — filtered if too sparse)
     *
     * Adds bonuses for: word-adjacency in the snippet, multiple matches in one
     * document, and matches at word boundaries.
     */
    private suspend fun rankedContentSearch(ftsQuery: String, originalRaw: String): List<SearchHit> {
        val ftsHits = dao.search(Topics.expandQuery(ftsQuery))
        if (ftsHits.isEmpty()) return emptyList()

        // The original (un-quoted) phrase from the user, used for scoring + display.
        val phrase = originalRaw.trim()
            .removeSurrounding("\"")
            .lowercase()
        val tokens = phrase.split(Regex("\\s+"))
            .map { it.replace(Regex("[^\\p{L}\\p{N}]"), "") }
            .filter { it.length >= 2 }
        val tokensLower = tokens.toSet()
        val isMultiWord = tokensLower.size > 1

        data class Scored(val hit: SearchHit, val score: Int)
        val scored = ftsHits.mapNotNull { h ->
            val title = h.title.lowercase()
            val snippet = h.snippet.lowercase()

            // Match-marker count tells us how many distinct hits appeared in the snippet
            // (the FTS snippet() function wraps each match in ⟦…⟧).
            val markerCount = h.snippet.count { it == '\u27E6' }

            val titleHasPhrase = title.contains(phrase)
            val snippetHasPhrase = snippet.contains(phrase)
            val titleTokenHits = tokensLower.count { title.contains(it) }
            val snippetTokenHits = tokensLower.count { snippet.contains(it) }

            // Adjacency: are all the query tokens within a ~10-word window of each other?
            val adjacencyBonus = if (isMultiWord && snippetTokenHits == tokensLower.size) {
                val words = snippet.split(Regex("\\s+"))
                var found = false
                if (words.size >= tokensLower.size) {
                    for (i in 0..(words.size - tokensLower.size)) {
                        val end = minOf(i + 10, words.size)
                        val window = words.subList(i, end).joinToString(" ")
                        if (tokensLower.all { window.contains(it) }) { found = true; break }
                    }
                }
                if (found) 800 else 0
            } else 0

            // Word boundary bonus: phrase appears at a word boundary in the title
            val titleBoundaryBonus = if (isMultiWord && phrase.length >= 3 &&
                Regex("\\b" + Regex.escape(phrase) + "\\b").containsMatchIn(title)) 2_000 else 0

            val score = when {
                titleHasPhrase -> 10_000 + titleBoundaryBonus + markerCount * 50
                snippetHasPhrase -> 5_000 + titleTokenHits * 200 + markerCount * 100 + adjacencyBonus
                isMultiWord && titleTokenHits == tokensLower.size -> 3_500 + adjacencyBonus + markerCount * 50
                isMultiWord && snippetTokenHits == tokensLower.size -> 1_800 + adjacencyBonus + titleTokenHits * 150 + markerCount * 30
                else -> {
                    val total = titleTokenHits + snippetTokenHits
                    // Discard sparse matches — e.g. "ar" matching "art history" when only
                    // one of two query tokens appears.
                    if (isMultiWord && total < (tokensLower.size + 1) / 2) return@mapNotNull null
                    100 + titleTokenHits * 40 + snippetTokenHits * 10 + markerCount * 5
                }
            }
            Scored(h, score)
        }
        return scored
            .sortedByDescending { it.score }
            .take(150)
            .map { it.hit }
    }

    /**
     * Obsidian-style title search: every word in the query must appear somewhere in the
     * title / file name / path, in any order. Exact-phrase matches in the title rank highest.
     */
    private suspend fun titleSearch(raw: String): List<SearchHit> {
        val tokens = raw.split(Regex("\\s+"))
            .map { it.trim() }
            .filter { it.isNotEmpty() }
            .take(6)
        if (tokens.isEmpty()) return emptyList()
        // Pad up to 6 LIKE slots; "%%" matches anything so unused slots are no-ops.
        val pats = (0 until 6).map { i ->
            if (i < tokens.size) "%${tokens[i]}%" else "%%"
        }
        val rows = dao.searchTitlesAllWords(
            pats[0], pats[1], pats[2], pats[3], pats[4], pats[5]
        )
        val phrase = raw.lowercase()
        val tokensLower = tokens.map { it.lowercase() }
        // Score each hit: prefer exact phrase, then more tokens in title vs path
        return rows.asSequence()
            .map { n ->
                val titleLower = n.title.lowercase()
                val pathLower = n.relPath.lowercase()
                val score = when {
                    titleLower.contains(phrase) -> 1_000
                    pathLower.contains(phrase) -> 800
                    else -> {
                        val titleHits = tokensLower.count { titleLower.contains(it) }
                        val pathHits = tokensLower.count { pathLower.contains(it) }
                        titleHits * 10 + pathHits
                    }
                }
                n to score
            }
            .sortedWith(
                compareByDescending<Pair<NoteMeta, Int>> { it.second }
                    .thenBy { it.first.title.lowercase() }
            )
            .take(200)
            .map { (n, _) -> SearchHit(n.id, n.relPath, n.title, "", n.fileType) }
            .toList()
    }

    /** Topic cards whose vocabulary matches the current query (shown above results). */
    val topicMatches: StateFlow<List<TopicCard>> =
        combine(query.debounce(220).map { it.trim() }.distinctUntilChanged(), _topics) { q, topics ->
            if (q.length < 2) emptyList()
            else {
                val keys = Topics.matchQuery(q).toSet()
                topics.filter { it.key in keys }
            }
        }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    init {
        viewModelScope.launch {
            refreshNotes()
            refreshRecent()
            refreshTopics()
            refreshFavourites(); refreshSuggested()
            runCatching { _recentSearches.value = decodeRecents(prefs.recentSearchesRaw.first()) }
            val uri = prefs.libraryUri.first()
            val storedTopicVersion = prefs.topicVersion.first()
            val storedLinksVersion = prefs.linksVersion.first()
            when {
                uri != null && _notes.value.isEmpty() -> startSync(uri)
                _notes.value.isNotEmpty() -> {
                    if (storedTopicVersion != Topics.VERSION) {
                        reclassifyTopics()
                        prefs.setTopicVersion(Topics.VERSION)
                    }
                    if (storedLinksVersion != Wikilinks.VERSION) {
                        reextractLinks()
                        prefs.setLinksVersion(Wikilinks.VERSION)
                    }
                }
            }
        }
    }

    fun setLibrary(uri: Uri) {
        val app = getApplication<Application>()
        try {
            // Request BOTH read and write so we can save imported markdown files
            // back into the library. WRITE is needed by saveImportedMarkdown().
            app.contentResolver.takePersistableUriPermission(
                uri,
                Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_WRITE_URI_PERMISSION
            )
        } catch (_: Exception) {
        }
        viewModelScope.launch(Dispatchers.IO) {
            dao.clearAll()
            runCatching { dao.clearTopics() }
            runCatching { dao.clearLinks() }
            prefs.setLibraryUri(uri.toString())
            _tabs.value = emptyList(); _activeTab.value = null
            _newNotes.value = emptyList()
            refreshNotes(); refreshRecent(); refreshTopics(); refreshFavourites(); refreshSuggested()
            startSync(uri.toString(), trackNewNotes = false)
        }
    }

    fun reindex() {
        val uri = libraryUri.value ?: return
        startSync(uri, trackNewNotes = true)
    }

    private fun startSync(uri: String, trackNewNotes: Boolean = false) {
        if (_progress.value.running) return
        _progress.value = IndexProgress(true, "Starting\u2026", 0, 0)
        viewModelScope.launch(Dispatchers.IO) {
            var syncError: Throwable? = null
            try {
                val beforeRelPaths = if (trackNewNotes)
                    runCatching { dao.allMeta().map { it.relPath }.toSet() }.getOrElse { emptySet() }
                else emptySet()
                indexer.sync(uri) { p -> _progress.value = p }
                if (trackNewNotes) {
                    val afterAll = runCatching { dao.allMeta() }.getOrElse { emptyList() }
                    _newNotes.value = afterAll.filter { it.relPath !in beforeRelPaths }.take(30)
                }
            } catch (e: Exception) {
                syncError = e
                _progress.value = IndexProgress(false, "Error: ${e.message}", 0, 0)
            }
            refreshNotes(); refreshRecent(); refreshTopics(); refreshFavourites(); refreshSuggested()
            runCatching { prefs.setTopicVersion(Topics.VERSION) }
            runCatching { prefs.setLinksVersion(Wikilinks.VERSION) }

            // v5.4.92cc — Auto-run the embedding pass after every
            // successful index sync so semantic search stays in step with
            // the FTS index. Without this, the WebViewer batch save (or
            // any other flow that appends new notes) refreshes the FTS
            // rows but leaves the vectors table stale — meaning fresh
            // articles show up in Titles/Content search but not in AI
            // search until the user manually taps "Build embeddings" in
            // Settings. Auto-embed respects three guards:
            //
            //   1. Sync itself must have succeeded — never chase an
            //      error with an embed pass.
            //   2. The active embedding model must be installed — no
            //      point kicking off a service that will immediately
            //      no-op inside buildAllEmbeddings().
            //   3. The embedding service mustn't already be running —
            //      buildAllEmbeddings() has this guard internally, but
            //      short-circuiting here avoids the extra Intent hop.
            //
            // The service itself detects already-embedded rows (via
            // modelVersion match) and only processes the delta, so
            // triggering it on every sync is cheap — most of the time
            // it finishes in seconds.
            if (syncError == null &&
                embedder.isModelAvailable() &&
                !com.tebogo.markvault.search.EmbeddingProgressBus.isRunning.value
            ) {
                // Fine to fire from Dispatchers.IO — startForegroundService
                // is thread-safe. The 5-second startForeground deadline
                // starts when EmbeddingService's onCreate lands on Main,
                // not when we post the Intent from here.
                buildAllEmbeddings()
                logActivity(
                    com.tebogo.markvault.data.ActivityLog.Category.EMBED,
                    "Auto-embed triggered after index sync",
                    emptyMap()
                )
            }
            // v5.4.94cc — Log the completion of the index sync itself
            // regardless of whether it triggered an embed pass.
            if (syncError == null) {
                logActivity(
                    com.tebogo.markvault.data.ActivityLog.Category.INDEX_SYNC,
                    "Index sync completed",
                    emptyMap()
                )
                // v5.4.100cc — Refresh the URL cache from the freshly
                // indexed content. Newly imported markdown/HTML notes
                // land in the DB after sync; harvesting them here
                // means their source URLs are already in the dedup
                // cache before the user's next batch save runs.
                backfillSavedUrlsFromLibrary()
                // v5.4.102cc — Same reasoning for title/filename
                // caches: any new files that landed during the sync
                // need to be in the dedup pools before the user's
                // next batch save fires.
                backfillTitlesFromLibrary()
            } else {
                logActivity(
                    com.tebogo.markvault.data.ActivityLog.Category.INDEX_SYNC,
                    "Index sync failed",
                    mapOf("error" to (syncError.message ?: "unknown"))
                )
            }
        }
    }

    /** Re-tag every already-indexed note using the current lexicon (no file re-scan). */
    private suspend fun reclassifyTopics() {
        val total = runCatching { dao.countNotes() }.getOrElse { 0 }
        if (total == 0) return
        _progress.value = IndexProgress(true, "Updating topics\u2026", 0, total)
        runCatching { dao.clearTopics() }
        val pageSize = 300
        var offset = 0
        var done = 0
        while (offset < total) {
            val page = runCatching { dao.notesTextPage(pageSize, offset) }.getOrElse { emptyList() }
            if (page.isEmpty()) break
            for (nt in page) {
                val topics = runCatching { Topics.classify(nt.title, nt.content) }.getOrElse { emptyList() }
                if (topics.isNotEmpty()) {
                    runCatching { dao.insertTopics(topics.map { NoteTopic(nt.id, it.first, it.second) }) }
                }
                done++
            }
            offset += pageSize
            _progress.value = IndexProgress(true, "Updating topics\u2026", done, total)
        }
        _progress.value = IndexProgress(false, "Done", total, total)
        refreshTopics()
    }

    /**
     * Re-run the wikilink/markdown-link extractor across every note's stored content.
     * Used after the extractor version bumps (e.g. when markdown-style `[label](file.md)` support
     * is added) so existing notes get the new edges without forcing a full file re-read.
     */
    private suspend fun reextractLinks() {
        val total = runCatching { dao.countNotes() }.getOrElse { 0 }
        if (total == 0) return
        _progress.value = IndexProgress(true, "Updating links\u2026", 0, total)
        runCatching { dao.clearLinks() }
        val pageSize = 300
        var offset = 0
        var done = 0
        while (offset < total) {
            val page = runCatching { dao.notesTextPage(pageSize, offset) }.getOrElse { emptyList() }
            if (page.isEmpty()) break
            for (nt in page) {
                val targets = runCatching { Wikilinks.extract(nt.content) }.getOrElse { emptyList() }
                if (targets.isNotEmpty()) {
                    val rows = targets.map { NoteLink(nt.id, it, Wikilinks.normalize(it)) }
                    runCatching { dao.insertLinks(rows) }
                }
                done++
            }
            offset += pageSize
            _progress.value = IndexProgress(true, "Updating links\u2026", done, total)
        }
        _progress.value = IndexProgress(false, "Done", total, total)
    }

    private suspend fun refreshNotes() {
        _notes.value = runCatching { dao.allMeta() }.getOrElse { emptyList() }
    }

    private suspend fun refreshRecent() {
        _recent.value = runCatching { dao.recentNotes() }.getOrElse { emptyList() }
    }

    private suspend fun refreshTopics() {
        val counts = runCatching { dao.topicCounts() }.getOrElse { emptyList() }
            .associate { it.topic to it.cnt }
        _topics.value = Topics.ALL.mapNotNull { d ->
            val c = counts[d.key] ?: 0
            if (c > 0) TopicCard(d.key, d.emoji, d.label, c) else null
        }.sortedByDescending { it.count }
    }

    private suspend fun refreshFavourites() {
        val favs = runCatching { dao.favouriteNotes() }.getOrElse { emptyList() }
        _favouriteIds.value = favs.map { it.id }.toSet()
        _favouriteNotes.value = favs
    }

    private suspend fun refreshSuggested() {
        // Hide notes opened in the last ~3 weeks; if the user has no reading history
        // (or no topic overlap), fall back to random unopened notes.
        val cutoff = System.currentTimeMillis() - 21L * 24L * 60L * 60L * 1000L
        val topicBased = runCatching { dao.suggestedNotes(cutoff, 25) }.getOrElse { emptyList() }
        _suggested.value = if (topicBased.size >= 6) topicBased
        else runCatching { dao.randomUnopened(25) }.getOrElse { topicBased }
    }

    fun toggleFavourite(id: Long) {
        viewModelScope.launch(Dispatchers.IO) {
            val isCurrentlyFav = _favouriteIds.value.contains(id)
            runCatching { dao.setFavourite(id, if (isCurrentlyFav) 0 else 1) }
            refreshFavourites(); refreshSuggested()
        }
    }

    suspend fun loadTopicNotes(key: String): List<NoteMeta> =
        runCatching { dao.notesInTopic(key) }.getOrElse { emptyList() }

    /** Resolve an Obsidian-style `[[target]]` to a note in the library, or null if not found. */
    suspend fun resolveWikilink(target: String): LinkedNote? {
        val norm = Wikilinks.normalize(target)
        if (norm.isEmpty()) return null
        return runCatching { dao.resolveLink(norm, Wikilinks.withMd(norm)) }.getOrNull()
    }

    /** Notes whose body contains `[[<this note>]]` — i.e. backlinks. */
    suspend fun loadBacklinks(noteId: Long): List<LinkedNote> {
        val n = runCatching { dao.byId(noteId) }.getOrNull() ?: return emptyList()
        // A backlink could write the target as the title, the file name (with or without .md), or the relPath
        val candidates = LinkedHashSet<String>()
        candidates.add(Wikilinks.normalize(n.title))
        candidates.add(Wikilinks.normalize(n.name))
        candidates.add(Wikilinks.normalize(n.name.removeSuffix(".md").removeSuffix(".MD")
            .removeSuffix(".markdown").removeSuffix(".MARKDOWN")))
        candidates.add(Wikilinks.normalize(n.relPath))
        val list = candidates.filter { it.isNotEmpty() }
        if (list.isEmpty()) return emptyList()
        return runCatching { dao.backlinksFor(list) }.getOrElse { emptyList() }
            .filter { it.id != noteId }
    }

    /** Outgoing wikilinks from this note that point to existing notes. */
    suspend fun loadForwardLinks(noteId: Long): List<LinkedNote> =
        runCatching { dao.forwardLinksFor(noteId) }.getOrElse { emptyList() }
            .filter { it.id != noteId }

    /**
     * Fast count of total connections (forward links + backlinks) for a note.
     * Used to badge the Reader header so the user sees how connected the article is at a glance.
     */
    suspend fun connectionCount(noteId: Long): Int {
        val n = runCatching { dao.byId(noteId) }.getOrNull() ?: return 0
        val candidates = LinkedHashSet<String>().apply {
            add(Wikilinks.normalize(n.title))
            add(Wikilinks.normalize(n.name))
            add(Wikilinks.normalize(n.name.removeSuffix(".md").removeSuffix(".MD")
                .removeSuffix(".markdown").removeSuffix(".MARKDOWN")))
            add(Wikilinks.normalize(n.relPath))
        }.filter { it.isNotEmpty() }
        val forwards = runCatching { dao.forwardLinkCount(noteId) }.getOrElse { 0 }
        val backs = if (candidates.isEmpty()) 0
            else runCatching { dao.backlinkCount(candidates, noteId) }.getOrElse { 0 }
        return forwards + backs
    }

    /** The note with the most total connections in the library (best starting anchor for the graph). */
    suspend fun mostConnectedNote(): LinkedNote? =
        runCatching { dao.mostConnectedNote() }.getOrNull()

    /**
     * Build a 2-degree connection graph around [centerId]. Returns the focus note, its 1st-degree
     * neighbours (capped), and 2nd-degree neighbours (capped). Connection direction is preserved
     * so the UI can draw incoming vs outgoing edges differently.
     */
    suspend fun buildFocusGraph(centerId: Long): FocusGraph? {
        val centerNote = runCatching { dao.byId(centerId) }.getOrNull() ?: return null
        val center = LinkedNote(centerNote.id, centerNote.title, centerNote.folder)

        val forwards = loadForwardLinks(centerId)
        val backs = loadBacklinks(centerId)

        // Combined first-ring nodes (uniqued by id), with link direction tagged.
        // outgoing = center -> node, incoming = node -> center, both = bidirectional.
        val firstRingMap = LinkedHashMap<Long, GraphNeighbour>()
        for (f in forwards) firstRingMap[f.id] = GraphNeighbour(f, LinkDir.OUTGOING)
        for (b in backs) {
            val existing = firstRingMap[b.id]
            firstRingMap[b.id] = if (existing != null) existing.copy(dir = LinkDir.BOTH)
            else GraphNeighbour(b, LinkDir.INCOMING)
        }
        val firstRing = firstRingMap.values.toList().take(MAX_FIRST_RING)
        val firstRingIds = firstRing.map { it.note.id }.toSet() + centerId

        // Second-ring nodes: anything 1° neighbours link to/from, minus already-shown nodes.
        val secondRingMap = LinkedHashMap<Long, GraphEdge>()
        for (n in firstRing) {
            val ff = loadForwardLinks(n.note.id)
            val bb = loadBacklinks(n.note.id)
            for (x in ff) {
                if (x.id in firstRingIds) continue
                if (secondRingMap.size >= MAX_SECOND_RING && x.id !in secondRingMap) continue
                if (x.id !in secondRingMap) secondRingMap[x.id] = GraphEdge(x, n.note.id)
            }
            for (x in bb) {
                if (x.id in firstRingIds) continue
                if (secondRingMap.size >= MAX_SECOND_RING && x.id !in secondRingMap) continue
                if (x.id !in secondRingMap) secondRingMap[x.id] = GraphEdge(x, n.note.id)
            }
        }
        val secondRing = secondRingMap.values.toList()

        return FocusGraph(
            center = center,
            firstRing = firstRing,
            secondRing = secondRing,
            firstRingTotal = firstRingMap.size,
            secondRingTotal = -1 // unknown without re-counting; UI can show "+more" if needed
        )
    }

    /** Open an article in a tab (reusing it if already open) and make it active. */
    /** How an article was last opened — drives the small badge on the recents/history list. */
    private val _recentOpenSources = MutableStateFlow<Map<Long, OpenSource>>(emptyMap())
    val recentOpenSources: StateFlow<Map<Long, OpenSource>> = _recentOpenSources

    /**
     * Open an article in a tab (reusing it if already open) and make it active.
     * [source] records WHY we're opening it (e.g. from a wikilink) so the home screen can
     * badge it in the recently-opened list.
     */
    fun openArticle(id: Long, title: String, source: OpenSource = OpenSource.DIRECT, fileType: String = "md") {
        val list = _tabs.value.toMutableList()
        val existing = list.indexOfFirst { it.id == id }
        if (existing < 0) {
            list.add(TabInfo(id, title, fileType))
            while (list.size > maxTabs) {
                val drop = list.firstOrNull { it.id != id }
                if (drop != null) {
                    list.remove(drop)
                    // Also strip the dropped tab from the visit history so back doesn't try to return there
                    _tabHistory.value = _tabHistory.value.filter { it != drop.id }
                } else break
            }
            _tabs.value = list
        }
        _activeTab.value = id
        pushHistory(id)
        // Update source map: keep a small rolling window so it doesn't grow without bound
        val cur = _recentOpenSources.value.toMutableMap()
        cur[id] = source
        if (cur.size > 60) {
            // Trim oldest by recents ordering would be ideal but we don't have timestamps here;
            // simple cap keeps memory bounded.
            val drop = cur.keys.first()
            cur.remove(drop)
        }
        _recentOpenSources.value = cur
        viewModelScope.launch { refreshRecent() }
    }

    fun setActiveTab(id: Long) {
        _activeTab.value = id
        pushHistory(id)
    }

    fun closeTab(id: Long) {
        val list = _tabs.value.toMutableList()
        val idx = list.indexOfFirst { it.id == id }
        if (idx < 0) return
        list.removeAt(idx)
        _tabs.value = list
        // Drop every occurrence of the closed tab from history
        _tabHistory.value = _tabHistory.value.filter { it != id }
        if (_activeTab.value == id) {
            val newActive = list.getOrNull(idx.coerceAtMost(list.size - 1))?.id
            _activeTab.value = newActive
            if (newActive != null) pushHistory(newActive)
        }
    }

    /** Close every open tab. Used by the tab-management bottom sheet. */
    fun closeAllTabs() {
        _tabs.value = emptyList()
        _tabHistory.value = emptyList()
        _activeTab.value = null
    }

    /** Close every tab except the given one. Convenient when the user picks one in the grid. */
    fun closeOtherTabs(keepId: Long) {
        val keep = _tabs.value.firstOrNull { it.id == keepId } ?: return
        _tabs.value = listOf(keep)
        _tabHistory.value = listOf(keepId)
        _activeTab.value = keepId
    }

    suspend fun loadNote(id: Long): Note? {
        val n = dao.byId(id)
        if (n != null) {
            runCatching { dao.touch(id, System.currentTimeMillis()) }
            refreshRecent()
        }
        return n
    }

    /**
     * Return the SAF content URI string for a PDF note so the PdfReaderScreen can open it.
     * Also touches the "lastOpened" timestamp so it appears in recents.
     */
    suspend fun loadPdfUri(id: Long): String? {
        val n = dao.byId(id) ?: return null
        if (n.fileType != "pdf") return null
        runCatching { dao.touch(id, System.currentTimeMillis()) }
        refreshRecent()
        return n.uri
    }

    /** Look up the fileType for a note ID — used to decide which viewer to open. */
    suspend fun fileTypeOf(id: Long): String =
        runCatching { dao.byId(id)?.fileType }.getOrNull() ?: "md"

    /* ──────────────────────────────────────────────────────────────────────
     *  PDF text cache (per page) — used by in-PDF search for instant queries
     *  on second/third open. Re-extracted whenever the source file changes.
     * ────────────────────────────────────────────────────────────────────── */

    /** Returns cached page text iff it matches the source file's current lastModified. */
    suspend fun cachedPdfPageText(noteId: Long): Map<Int, String>? {
        val note = runCatching { dao.byId(noteId) }.getOrNull() ?: return null
        val stamp = runCatching { dao.pdfPageTextStamp(noteId) }.getOrNull() ?: return null
        if (stamp != note.lastModified) return null
        val rows = runCatching { dao.loadPdfPageText(noteId) }.getOrNull() ?: return null
        if (rows.isEmpty()) return null
        return rows.associate { it.pageIndex to it.text }
    }

    /** Persists the extracted text so future opens skip extraction. */
    suspend fun savePdfPageText(noteId: Long, pages: Map<Int, String>) {
        val note = runCatching { dao.byId(noteId) }.getOrNull() ?: return
        val rows = pages.entries.map { (i, t) ->
            PdfPageText(noteId, i, t, note.lastModified)
        }
        runCatching {
            dao.clearPdfPageText(noteId)
            dao.savePdfPageText(rows)
        }
    }

    /* ── PDF annotations ── */

    suspend fun loadAnnotation(noteId: Long, page: Int): String? =
        runCatching { dao.loadAnnotation(noteId, page)?.paths }.getOrNull()

    suspend fun loadAllAnnotations(noteId: Long): Map<Int, String> =
        runCatching {
            dao.loadAnnotationsForNote(noteId).associate { it.pageIndex to it.paths }
        }.getOrElse { emptyMap() }

    suspend fun saveAnnotation(noteId: Long, page: Int, pathsJson: String) {
        runCatching {
            if (pathsJson.isBlank() || pathsJson == "[]") dao.deleteAnnotation(noteId, page)
            else dao.saveAnnotation(PdfAnnotation(noteId, page, pathsJson))
        }
    }

    suspend fun clearAllAnnotations(noteId: Long) {
        runCatching { dao.deleteAllAnnotationsForNote(noteId) }
    }

    /* ── PDF view history (internal + external) ── */

    /** Record that a PDF was opened. Called on every PDF open from any path. */
    fun recordPdfView(uri: String, title: String, noteId: Long, isExternal: Boolean) {
        viewModelScope.launch(Dispatchers.IO) {
            runCatching {
                dao.deletePdfHistoryByUri(uri)
                dao.insertPdfHistory(PdfHistoryEntry(
                    uri = uri, title = title, noteId = noteId, isExternal = isExternal
                ))
            }
        }
    }

    suspend fun loadPdfHistory(limit: Int = 100): List<PdfHistoryEntry> =
        runCatching { dao.recentPdfHistory(limit) }.getOrElse { emptyList() }

    fun deletePdfHistoryEntry(id: Long) {
        viewModelScope.launch(Dispatchers.IO) { runCatching { dao.deletePdfHistory(id) } }
    }

    fun clearPdfHistory() {
        viewModelScope.launch(Dispatchers.IO) { runCatching { dao.clearPdfHistory() } }
    }

    /* ── Web history (in-app browser visits) ── */

    fun recordWebVisit(url: String, title: String) {
        if (url.isBlank()) return
        viewModelScope.launch(Dispatchers.IO) {
            runCatching {
                val host = runCatching { android.net.Uri.parse(url).host ?: "" }.getOrElse { "" }
                dao.deleteWebHistoryByUrl(url)   // dedupe by URL — keep newest only
                dao.insertWebHistory(WebHistoryEntry(
                    url = url, title = title.ifBlank { url }, host = host
                ))
            }
        }
    }

    suspend fun loadWebHistory(limit: Int = 200): List<WebHistoryEntry> =
        runCatching { dao.recentWebHistory(limit) }.getOrElse { emptyList() }

    fun deleteWebHistoryEntry(id: Long) {
        viewModelScope.launch(Dispatchers.IO) { runCatching { dao.deleteWebHistory(id) } }
    }

    fun clearWebHistory() {
        viewModelScope.launch(Dispatchers.IO) { runCatching { dao.clearWebHistory() } }
    }

    /* ── Persistent in-app browser session (TASK 4) ──
     * The tab list lives here on the VM so when the user navigates away to read
     * a markdown note or a PDF and comes back to the browser, their tabs are
     * still there. The WebView itself is recreated each time (Compose can't
     * persist a native view across screen changes without a custom host), but
     * the URLs + titles + which tab was active are preserved verbatim.
     */
    val webTabs: androidx.compose.runtime.snapshots.SnapshotStateList<com.tebogo.markvault.ui.WebTab> =
        androidx.compose.runtime.mutableStateListOf()
    var webActiveTabIdx: Int by androidx.compose.runtime.mutableStateOf(0)
        private set

    /**
     * v5.3.1 — Thumbnail cache for the tabs preview overlay (Chrome-style).
     *
     * Keyed by [WebTab.id]. Each value is a downscaled JPEG so the
     * memory footprint stays modest (~50–150 KB per tab × ~10 tabs).
     * Captured lazily on `onPageFinished` and any time the user switches
     * away from a tab. Cleared automatically when a tab is closed.
     *
     * Backed by SnapshotStateMap so [TabPreviewCard] recomposes
     * automatically when a fresh thumbnail lands.
     */
    val webTabThumbnails: androidx.compose.runtime.snapshots.SnapshotStateMap<Long, ByteArray> =
        androidx.compose.runtime.mutableStateMapOf()

    /**
     * Capture [view] (typically the active WebView) into a downscaled
     * JPEG and store it under [tabId]. Safe to call on any thread; the
     * actual draw call is bounced onto the main thread because WebView
     * draws must happen on the UI thread.
     */
    fun saveWebTabThumbnail(tabId: Long, view: android.view.View) {
        if (view.width <= 0 || view.height <= 0) return
        try {
            // Downsample to ~360 px wide. Preserves aspect ratio.
            val targetW = 360
            val scale = targetW.toFloat() / view.width.toFloat()
            val targetH = (view.height * scale).toInt().coerceAtLeast(1)
            val bmp = android.graphics.Bitmap.createBitmap(
                targetW, targetH, android.graphics.Bitmap.Config.RGB_565
            )
            val canvas = android.graphics.Canvas(bmp)
            canvas.scale(scale, scale)
            view.draw(canvas)
            val baos = java.io.ByteArrayOutputStream()
            bmp.compress(android.graphics.Bitmap.CompressFormat.JPEG, 70, baos)
            webTabThumbnails[tabId] = baos.toByteArray()
            bmp.recycle()
        } catch (t: Throwable) {
            // Thumbnail capture should never crash anything else.
        }
    }

    /**
     * Ensure the browser has at least one tab loaded with [initialUrl].
     *
     * v5.4.35 — Previous implementation silently ignored the URL when
     * tabs already existed. This was the root cause of the "stuck first
     * link" bug: clicking a second scripture from an offline HTML article
     * navigated to the browser but the old tab stayed active. Now we
     * always route the requested URL through [openInBrowser] so a tab
     * matching it is activated (or a new one created).
     */
    fun ensureBrowserSession(initialUrl: String, initialLabel: String = "jw.org") {
        if (webTabs.isEmpty()) {
            webTabs.add(WebTab(System.currentTimeMillis(), initialUrl, initialLabel))
            webActiveTabIdx = 0
        } else {
            // Tabs exist — honour the user's preference.
            val newTab = runBlocking { prefs.openLinksInNewTab.first() }
            if (newTab) {
                openInBrowser(initialUrl, initialLabel)
            } else {
                // Same-tab mode: update the active tab's URL in place so the
                // WebView in WebSearchScreen picks it up on recomposition.
                val idx = webActiveTabIdx.coerceIn(webTabs.indices)
                webTabs[idx] = webTabs[idx].copy(url = initialUrl, title = initialLabel)
            }
        }
    }

    // ── v4.12.0 — Pending web-open ──────────────────────────────────────────
    //
    // Before v4.12, tapping a row in Web History navigated to the browser
    // route, but [ensureBrowserSession] silently did nothing when tabs were
    // already open — so the requested URL was effectively ignored and the
    // user was returned to whatever tab they had last. The "history is not
    // clickable" bug the user reported.
    //
    // The fix decouples the URL from the navigation route: history (or any
    // other caller) writes the target into [pendingWebOpen], navigates to the
    // browser, and the browser consumes the pending request on first
    // composition. [openInBrowser] either switches to an existing tab that
    // already shows the URL or opens it in a new tab.

    private val _pendingWebOpen =
        MutableStateFlow<Pair<String, String>?>(null)
    /** A `(url, label)` pair set by callers (e.g. Web History) that want the browser to open a specific page. */
    val pendingWebOpen: StateFlow<Pair<String, String>?> = _pendingWebOpen

    /** Request that the browser open [url] with display [label] on its next composition. */
    fun requestWebOpen(url: String, label: String) {
        _pendingWebOpen.value = url to label
    }

    /**
     * Read and clear the pending web-open request, if any. Returns null when
     * nothing was pending. Called by [WebSearchScreen] in its
     * `LaunchedEffect(Unit)` to honour any history tap that triggered the
     * navigation.
     */
    fun consumePendingWebOpen(): Pair<String, String>? {
        val v = _pendingWebOpen.value
        if (v != null) _pendingWebOpen.value = null
        return v
    }

    /**
     * Open [url] in the browser. If a tab already shows it, switch to that
     * tab (preserves its back/forward stack and scroll position); otherwise
     * append a fresh tab. Either way the new active index is updated so the
     * UI rerenders to the right page.
     */
    fun openInBrowser(url: String, label: String) {
        val existingIdx = webTabs.indexOfFirst { it.url == url }
        if (existingIdx >= 0) {
            webActiveTabIdx = existingIdx
            return
        }
        webTabs.add(WebTab(System.currentTimeMillis(), url, label))
        webActiveTabIdx = webTabs.size - 1
    }

    fun setWebActiveTab(idx: Int) {
        if (idx in webTabs.indices) webActiveTabIdx = idx
    }

    fun addBrowserTab(url: String = "https://www.jw.org/en/", title: String = "New tab") {
        webTabs.add(WebTab(System.currentTimeMillis(), url, title))
        webActiveTabIdx = webTabs.size - 1
    }

    /** Returns true if the caller should also pop back (last tab was closed). */
    fun closeBrowserTab(idx: Int): Boolean {
        if (idx !in webTabs.indices) return false
        // v4.13.0 — also drop the persistent WebView for this tab, so memory
        // isn't held forever for tabs the user explicitly closes.
        val closedId = webTabs[idx].id
        destroyWebViewSession("tab_$closedId")
        // v5.3.1 — drop the cached thumbnail too.
        webTabThumbnails.remove(closedId)
        if (webTabs.size == 1) { webTabs.clear(); webActiveTabIdx = 0; return true }
        webTabs.removeAt(idx)
        webActiveTabIdx = when {
            webActiveTabIdx >= webTabs.size -> webTabs.size - 1
            webActiveTabIdx > idx -> webActiveTabIdx - 1
            else -> webActiveTabIdx
        }
        return false
    }

    /** v5.4.35 — Close ALL browser tabs at once. Destroys every
     *  persistent WebView session and clears thumbnails. Returns true
     *  so the caller knows to pop back to the previous screen. */
    fun closeAllBrowserTabs(): Boolean {
        for (tab in webTabs.toList()) {
            destroyWebViewSession("tab_${tab.id}")
            webTabThumbnails.remove(tab.id)
        }
        webTabs.clear()
        webActiveTabIdx = 0
        return true
    }

    // ── v4.13.0 — Persistent WebView session pool ───────────────────────────
    //
    // Goal: scroll position, form inputs, and JavaScript state SURVIVE
    //   • popup ↔ full-screen-popup toggling
    //   • bottom-bar browser-icon taps after navigating away and back
    //   • Compose-level navigation in general
    //
    // Mechanism: WebView instances are owned by the VM (lifetime = VM lifetime),
    // looked up by a stable session ID. Composables call
    // [getOrCreateWebViewSession] in their AndroidView `factory` lambda,
    // detach from any prior parent with `(view.parent as? ViewGroup)?.removeView`,
    // and attach to the new ViewGroup. The next time the screen mounts, the
    // SAME WebView is returned and re-attached — its state is intact.
    //
    // Session IDs:
    //   - "popup"       — the link-popup browser (one WebView, shared between
    //                     WebPopupSheet and WebPopupFullScreen)
    //   - "tab_{tabId}" — each tabbed-browser tab in WebSearchScreen
    //
    // Context-leak note: WebView captures the Activity context. For this app
    // the VM is bound to MainActivity, and [onCleared] destroys every WebView
    // when the VM goes away. Configuration changes (rotation) can produce a
    // brief leak window in theory; not a real issue in practice for this app.

    private val webViewSessions =
        mutableMapOf<String, com.tebogo.markvault.ui.SelectionWebView>()

    /**
     * v5.3.1 — Return the currently-active browser tab's WebView, if it
     * exists in the session pool. Used by the tabs preview overlay to
     * grab a fresh thumbnail of the page right before showing the grid
     * (so the active card isn't stale). Returns null when there's no
     * active tab or its session hasn't been created yet.
     */
    fun peekActiveWebView(): com.tebogo.markvault.ui.SelectionWebView? {
        val activeId = webTabs.getOrNull(webActiveTabIdx)?.id ?: return null
        return webViewSessions["tab_$activeId"]
    }

    /**
     * Look up an existing WebView for [sessionId], creating one if needed.
     * The returned WebView is bare — callers wire up `webViewClient`,
     * settings, and selection-menu callbacks themselves on every mount
     * because those references close over Composable state that goes stale
     * across recompositions.
     *
     * @param context Activity context (LocalContext.current from a Composable).
     */
    fun getOrCreateWebViewSession(
        sessionId: String,
        context: android.content.Context
    ): com.tebogo.markvault.ui.SelectionWebView {
        webViewSessions[sessionId]?.let { return it }
        val webView = com.tebogo.markvault.ui.SelectionWebView(context)
        webViewSessions[sessionId] = webView
        return webView
    }

    /**
     * Destroy a specific session's WebView. Use when the corresponding logical
     * thing (e.g. a browser tab) is closed by the user. Detaches from any
     * parent and frees native resources.
     */
    fun destroyWebViewSession(sessionId: String) {
        val w = webViewSessions.remove(sessionId) ?: return
        (w.parent as? android.view.ViewGroup)?.removeView(w)
        runCatching { w.destroy() }
    }

    /** Destroy every WebView in the pool. Called automatically on VM clear. */
    private fun destroyAllWebViewSessions() {
        for (w in webViewSessions.values) {
            (w.parent as? android.view.ViewGroup)?.removeView(w)
            runCatching { w.destroy() }
        }
        webViewSessions.clear()
    }

    /** Update tab URL/title after a page finishes loading. */
    fun updateBrowserTab(idx: Int, url: String? = null, title: String? = null) {
        if (idx !in webTabs.indices) return
        val cur = webTabs[idx]
        webTabs[idx] = cur.copy(
            url = url ?: cur.url,
            title = (title?.takeIf { it.isNotBlank() } ?: cur.title)
        )
    }

    /* ── TASK 5: pending search query channel ──
     * When the user taps "Search in MarkVault" in the browser's text-selection
     * menu, we push the selected text here and navigate to the Search screen,
     * which consumes the value on first composition and clears it.
     */
    private val _pendingSearch = MutableStateFlow<String?>(null)
    val pendingSearch: StateFlow<String?> = _pendingSearch.asStateFlow()
    fun requestPendingSearch(q: String) { _pendingSearch.value = q }
    fun consumePendingSearch(): String? {
        val q = _pendingSearch.value
        _pendingSearch.value = null
        return q
    }

    /* ── Web bookmarks (user-saved jw.org pages) ── */

    suspend fun isBookmarked(url: String): Boolean =
        runCatching { dao.isBookmarked(url) }.getOrElse { false }

    fun addBookmark(url: String, title: String) {
        if (url.isBlank()) return
        viewModelScope.launch(Dispatchers.IO) {
            runCatching {
                val host = runCatching { android.net.Uri.parse(url).host ?: "" }.getOrElse { "" }
                dao.insertBookmark(WebBookmark(url = url, title = title.ifBlank { url }, host = host))
            }
        }
    }

    fun removeBookmark(url: String) {
        viewModelScope.launch(Dispatchers.IO) { runCatching { dao.deleteBookmarkByUrl(url) } }
    }

    suspend fun loadBookmarks(): List<WebBookmark> =
        runCatching { dao.allBookmarks() }.getOrElse { emptyList() }

    fun deleteBookmarkEntry(id: Long) {
        viewModelScope.launch(Dispatchers.IO) { runCatching { dao.deleteBookmark(id) } }
    }

    /** First ~600 chars of the note body, used for the home-screen suggestion previews. */
    suspend fun previewOf(id: Long): String? =
        runCatching { dao.previewOf(id) }.getOrNull()

    fun saveScroll(id: Long, scroll: Int) {
        if (scroll < 0) return
        viewModelScope.launch(Dispatchers.IO) { runCatching { dao.setScroll(id, scroll) } }
    }

    /** Term to flash-highlight in the reader after opening a full-text search result (one-shot). */
    /**
     * v5.4.37 — Pending highlight payload, expanded with the search
     * result snippet. Carries four pieces of information so the JS
     * highlighter can run a multi-strategy cascade:
     *
     *   1. [snippet] — the FTS snippet (with ⟦⟧ markers stripped) that
     *      appeared in the search result card. This is the most precise
     *      needle: it's literal text from the article that the search
     *      engine already matched. First strategy: search for this exact
     *      substring in the article DOM.
     *   2. [query] — the user's search query. Second strategy: phrase
     *      match on the full query string.
     *   3. [isPhrase] — whether the query was in exact-phrase mode.
     *   4. (implicit) individual terms extracted from query — last-resort
     *      fallback when nothing else matches.
     *
     * The snippet may be empty for pure-semantic results (no FTS hit).
     * In that case the JS falls through from strategy 1 to 2/3/4.
     */
    data class PendingHighlight(
        val query: String,
        val isPhrase: Boolean,
        val snippet: String = "",
        /**
         * v5.4.76cc — Paraphrases produced by the Phi-4-mini expander
         * for this query, if any. Passed through to the WebView-based
         * readers (Markdown and HTML) so they can apply the softer
         * lavender `.llm-hit` highlight on top of the existing yellow
         * `.term-hit` for the original query terms. Empty when the LLM
         * toggle is off, the model isn't installed, or the query wasn't
         * expanded (short/live-typing/etc).
         */
        val llmTerms: List<String> = emptyList()
    )

    var pendingHighlight: PendingHighlight? = null
    fun consumePendingHighlight(): PendingHighlight? {
        val v = pendingHighlight
        pendingHighlight = null
        return v
    }

    /** v5.4.37 — Convenience setter. Captures exact-phrase state and
     *  optionally the FTS snippet so the reader highlight cascade
     *  starts with the most precise needle available.
     *
     *  v5.4.76cc — Also looks the query up in
     *  [com.tebogo.markvault.ai.LlmExpansionHistory] and passes any
     *  recorded paraphrases through so the reader can paint the
     *  lavender AI-trace highlight on the words the LLM contributed. */
    fun setPendingHighlight(
        query: String,
        isPhrase: Boolean? = null,
        snippet: String = ""
    ) {
        val cleaned = query.trim().removeSurrounding("\"")
        if (cleaned.isEmpty()) {
            pendingHighlight = null
            return
        }
        val phrase = isPhrase ?: quotePhrase.value
        // Strip FTS match markers (⟦ ⟧) and ellipsis (…) from snippet
        val cleanSnippet = snippet
            .replace("\u27E6", "").replace("\u27E7", "")
            .replace(" \u2026 ", " ").replace("\u2026", "")
            .trim()
        val llmTerms = com.tebogo.markvault.ai.LlmExpansionHistory
            .get(cleaned)?.paraphrases.orEmpty()
        pendingHighlight = PendingHighlight(cleaned, phrase, cleanSnippet, llmTerms)
    }

    /**
     * v4.7 — synchronous loadNote convenience for UI handlers that need it
     * outside a coroutine context. Returns null if not found. Safe to call
     * from the main thread because Room DAOs are designed for that on simple
     * queries with @WorkerThread enforcement turned off in this app.
     */
    fun openSync(id: Long): Note? {
        return runCatching {
            kotlinx.coroutines.runBlocking(Dispatchers.IO) { loadNote(id) }
        }.getOrNull()
    }

    /**
     * v4.7 — convert a note from one file type to another and save the result
     * into the library as a new file. Sourcetype detection: the caller passes
     * the source's known type; targetType is what they picked from the dialog.
     *
     * Supported pairs:
     *   md → html   :  full markdown-it render (via simple in-Kotlin pipeline)
     *   md → pdf    :  markdown → HTML → PDF (delegated to converter)
     *   html → md   :  HTML cleanup via simpleHtmlToMarkdown
     *   html → pdf  :  HTML → PDF
     *   pdf → md    :  PDF text extraction → markdown
     *   pdf → html  :  PDF text extraction → minimal HTML
     *
     * Currently the md→html, html→md, and pdf→md/html paths are wired and
     * functional via the existing converters. md→pdf and html→pdf are stubbed
     * with a friendly error so the UI flow is complete and the implementer can
     * fill them in without re-doing the dialog plumbing.
     */
    suspend fun convertNote(
        sourceId: Long, sourceType: String, targetType: String
    ): SaveResult = withContext(Dispatchers.IO) {
        val note = loadNote(sourceId)
            ?: return@withContext SaveResult.Error("Source note not found.")
        when (sourceType to targetType) {
            "md" to "html" -> {
                // Markdown → HTML: wrap content in minimal HTML, escape MD as
                // pre-rendered text. For a richer render the next iteration
                // can hook into the in-app markdown-it engine via a hidden WebView.
                val htmlBody = note.content
                    .replace("&", "&amp;")
                    .replace("<", "&lt;").replace(">", "&gt;")
                val wrapped = """
                    |<!DOCTYPE html>
                    |<meta charset="utf-8">
                    |<title>${note.title}</title>
                    |<pre style="white-space: pre-wrap; font: 14px/1.5 system-ui;">$htmlBody</pre>
                """.trimMargin()
                writeHtmlToLibrary(note.title, wrapped, note.uri)
            }
            "html" to "md", "mhtml" to "md" -> {
                val bytes = getApplication<Application>().contentResolver
                    .openInputStream(Uri.parse(note.uri))?.use { it.readBytes() }
                    ?: return@withContext SaveResult.Error("Could not read source file.")
                val htmlText = if (sourceType == "mhtml") {
                    com.tebogo.markvault.util.MhtmlParser.extractHtmlContent(bytes)
                        ?: return@withContext SaveResult.Error("MHTML parse failed.")
                } else {
                    String(bytes, Charsets.UTF_8)
                }
                val md = "# ${note.title}\n\n" + simpleHtmlToMarkdown(htmlText)
                saveImportedMarkdown(note.title, md, importsSubfolder.value)
            }
            "pdf" to "md" -> {
                // PDF → MD: use the cached page text we already extracted at
                // index time. Returns null when the source hasn't been viewed
                // yet (extraction is lazy on first open).
                val pages = cachedPdfPageText(sourceId)
                if (pages.isNullOrEmpty()) {
                    return@withContext SaveResult.Error(
                        "PDF text isn't extracted yet. Open the PDF once to cache it."
                    )
                }
                val md = buildString {
                    append("# ").append(note.title).append("\n\n")
                    pages.entries.sortedBy { it.key }.forEach { (idx, text) ->
                        append("## Page ").append(idx + 1).append("\n\n")
                        append(text.trim()).append("\n\n")
                    }
                }
                saveImportedMarkdown(note.title, md, importsSubfolder.value)
            }
            "pdf" to "html" -> {
                val pages = cachedPdfPageText(sourceId)
                if (pages.isNullOrEmpty()) {
                    return@withContext SaveResult.Error(
                        "PDF text isn't extracted yet. Open the PDF once to cache it."
                    )
                }
                val sb = StringBuilder()
                sb.append("<!DOCTYPE html><meta charset=\"utf-8\"><title>")
                    .append(note.title).append("</title><body>")
                pages.entries.sortedBy { it.key }.forEach { (idx, text) ->
                    sb.append("<h2>Page ").append(idx + 1).append("</h2><pre>")
                        .append(text.replace("<", "&lt;").replace(">", "&gt;"))
                        .append("</pre>")
                }
                sb.append("</body>")
                writeHtmlToLibrary(note.title, sb.toString(), note.uri)
            }
            else -> SaveResult.Error(
                "Conversion from $sourceType to $targetType isn't supported yet."
            )
        }.also { result ->
            if (result is SaveResult.Ok) {
                // Auto-reindex so the converted file is immediately searchable.
                reindex()
            }
        }
    }

    /** Write an HTML payload into the library as a `.html` file. */
    private suspend fun writeHtmlToLibrary(
        title: String, html: String, sourceUri: String
    ): SaveResult = withContext(Dispatchers.IO) {
        val libUri = libraryUri.value
            ?: return@withContext SaveResult.Error("No library set.")
        val treeUri = runCatching { Uri.parse(libUri) }.getOrNull()
            ?: return@withContext SaveResult.Error("Library URI invalid.")
        val cr = getApplication<Application>().contentResolver
        try {
            val subfolder = importsSubfolder.value
            val rootId = android.provider.DocumentsContract.getTreeDocumentId(treeUri)
            val rootDocUri = android.provider.DocumentsContract.buildDocumentUriUsingTree(
                treeUri, rootId
            )
            val parentUri = if (subfolder.isBlank()) rootDocUri else
                findOrCreateFolder(cr, treeUri, rootId, subfolder)
                    ?: return@withContext SaveResult.Error("Could not create subfolder.")
            val safeBase = sanitizeFilename(title).removeSuffix(".md")
            val fileName = ensureUniqueAnyExt(cr, treeUri, parentUri, safeBase, ".html")
            val newDoc = android.provider.DocumentsContract.createDocument(
                cr, parentUri, "text/html", fileName
            ) ?: return@withContext SaveResult.Error("Failed to create file.")
            cr.openOutputStream(newDoc, "w")?.use { out ->
                out.write(html.toByteArray(Charsets.UTF_8))
            } ?: return@withContext SaveResult.Error("Could not write file.")
            SaveResult.Ok(newDoc.toString(), fileName, subfolder)
        } catch (e: Exception) {
            SaveResult.Error("Write failed: ${e.message ?: e.javaClass.simpleName}")
        }
    }

    /**
     * Stash a WebView state bundle so popup → full-screen (or back) doesn't reload the page.
     * The receiving screen consumes this immediately; missing/expired = falls back to URL load.
     */
    var webStateBundle: android.os.Bundle? = null
    fun consumeWebState(): android.os.Bundle? {
        val v = webStateBundle
        webStateBundle = null
        return v
    }

    /**
     * Web popup font scaling — separate from reader font scaling, persisted in-memory only.
     * Values are textZoom percentages: 100 = default; min 70, max 200.
     */
    private val _webPopupTextZoom = MutableStateFlow(100)
    val webPopupTextZoom: StateFlow<Int> = _webPopupTextZoom
    fun setWebPopupTextZoom(v: Int) {
        _webPopupTextZoom.value = v.coerceIn(70, 200)
    }

    /** Dark-mode toggle for the in-app WebView popup (persisted in-memory only). */
    private val _webPopupDarkMode = MutableStateFlow(true)
    val webPopupDarkMode: StateFlow<Boolean> = _webPopupDarkMode
    fun setWebPopupDarkMode(v: Boolean) { _webPopupDarkMode.value = v }

    /**
     * Global request to open the in-app WebView popup. Any screen can call [requestWebPopup]
     * and the popup will overlay it (because MainActivity collects this and renders the sheet
     * outside the NavHost). [clearWebPopup] dismisses it.
     *
     * v5.4.82cc — Gated on [webViewerPopupEnabled]. See MainActivity's
     * `popupUrl` collector for the routing decision.
     *
     * v5.4.83cc — Corrected the routing: when the toggle is OFF the
     * URL now goes to the in-app full-screen WebView
     * (`web_popup_full/{url}/{label}`), **not** the system browser.
     * The bottom sheet is the only thing being disabled; the in-app
     * WebViewer chrome is preserved either way. That decision lives
     * in MainActivity (where the NavController is); the ViewModel
     * just publishes the URL and the flag.
     */
    private val _webPopupRequest = MutableStateFlow<String?>(null)
    val webPopupRequest: StateFlow<String?> = _webPopupRequest

    /**
     * v5.4.82cc — Read-only observation of the WebViewer popup master
     * switch. Default `true` so the existing bottom-sheet behaviour is
     * preserved for anyone who never opens Settings.
     */
    val webViewerPopupEnabled: StateFlow<Boolean> = prefs.webViewerPopupEnabled
        .stateIn(viewModelScope, SharingStarted.Eagerly, true)

    /**
     * v5.4.84cc — Independent switch for the in-app WebView's
     * full-screen mode. When *both* this and [webViewerPopupEnabled]
     * are off, tapped links go to the system browser. See [Prefs.webViewerFullScreenEnabled]
     * for the full truth table.
     */
    val webViewerFullScreenEnabled: StateFlow<Boolean> = prefs.webViewerFullScreenEnabled
        .stateIn(viewModelScope, SharingStarted.Eagerly, true)

    fun requestWebPopup(url: String) { _webPopupRequest.value = url }
    fun clearWebPopup() { _webPopupRequest.value = null }

    /**
     * v5.4.82cc — Persist the WebViewer popup master switch. Effect is
     * immediate on the next call to [requestWebPopup]; any popup
     * already on screen when the toggle is flipped stays open until
     * the user dismisses it.
     */
    fun setWebViewerPopupEnabled(enabled: Boolean) {
        viewModelScope.launch { prefs.setWebViewerPopupEnabled(enabled) }
    }

    /** v5.4.94cc — Convenience accessor to the app-wide activity log. */
    fun logActivity(
        category: com.tebogo.markvault.data.ActivityLog.Category,
        message: String,
        metadata: Map<String, String> = emptyMap()
    ) {
        runCatching {
            (getApplication<Application>() as? MarkVaultApp)
                ?.activityLog?.log(category, message, metadata)
        }
    }

    /** v5.4.84cc — Persist the WebViewer full-screen master switch. */
    fun setWebViewerFullScreenEnabled(enabled: Boolean) {
        viewModelScope.launch { prefs.setWebViewerFullScreenEnabled(enabled) }
    }

    // ────────────────────────────────────────────────────────────────────
    // v5.4.88cc — WebViewer Multi-Selection Mode
    //
    // A curated, user-driven alternative to the (removed) auto-detection
    // FAB. Flow:
    //
    //   1. User enables "Selection mode" from the WebViewer menu.
    //   2. Every long-press on an anchor inside the WebView is intercepted
    //      (in WebPopup / WebSearchScreen — see webSelectionMode below):
    //      the tapped link is toggled in [webSelectionItems] and the
    //      matching DOM node gets an `.mv-selected` outline injected by JS.
    //      The normal long-press action sheet is skipped while mode is on.
    //   3. When the user taps "Save selected" on the FAB, [startBatchSave]
    //      publishes the selection as [batchSaveRequest]. The
    //      composable-hosted `HiddenBatchSaver` watches that flow,
    //      navigates a 1dp off-screen WebView to each URL, waits for
    //      onPageFinished, extracts `document.documentElement.outerHTML`,
    //      then calls [saveBatchItem] to persist it.
    //   4. On completion the saver calls [finishBatchSave]; a Toast fired
    //      from the composable reports saved/failed counts and the FTS
    //      index is rebuilt so the fresh files show up in search
    //      immediately.
    //
    // Design notes:
    //   - Selection state lives on the VM (not the composable) so it
    //     survives switching between popup ↔ full-screen ↔ tabbed browser.
    //   - v5.4.88cc tried HttpURLConnection. Cloudflare (jw.org's edge)
    //     blocked the plain requests with challenge pages and every URL
    //     failed. v5.4.89cc switched to a hidden WebView so the batch
    //     shares Chromium's TLS session and cookie jar with the visible
    //     tab — anything the user can load manually is reachable here too.
    //   - Failures per URL are counted but do not abort the batch — one
    //     bad link shouldn't sabotage the other 5.
    // ────────────────────────────────────────────────────────────────────

    /**
     * A single URL queued in the WebViewer multi-select basket.
     *
     * v5.4.99cc — `expanded` flag added: `true` for items that were
     * collected via Multi Selection Mode's head-expansion (long-press a
     * listing page → auto-collect every article link inside it). The
     * batch saver applies a 10KB minimum size filter to expanded items
     * so nav-page shortcuts and stub pages get skipped instead of
     * saved. Non-expanded items (manually picked in normal Selection
     * Mode) bypass the filter and are always saved.
     */
    data class WebSelectionItem(
        val url: String,
        val title: String,
        val expanded: Boolean = false
    )

    private val _webSelectionMode = MutableStateFlow(false)
    /** True whenever the WebViewer is in "long-press-to-select" mode. */
    val webSelectionMode: StateFlow<Boolean> = _webSelectionMode.asStateFlow()

    private val _webSelectionItems = MutableStateFlow<List<WebSelectionItem>>(emptyList())
    /** URLs the user has picked but not yet saved. Order is selection order. */
    val webSelectionItems: StateFlow<List<WebSelectionItem>> = _webSelectionItems.asStateFlow()

    /**
     * Live progress of an in-flight batch save, as (done, total). Both zero
     * when idle — the FAB reads this to switch between "Save selected (n)"
     * and "Saving x/y…" states.
     */
    private val _webSelectionSaving = MutableStateFlow(0 to 0)
    val webSelectionSaving: StateFlow<Pair<Int, Int>> = _webSelectionSaving.asStateFlow()

    /**
     * v5.4.104cc — Number of items the current (or most recent) batch
     * save skipped as "already in library". Set once by
     * [HiddenBatchSaver] right after it runs its dedup filter and
     * before the fetch loop starts; consumed by the top-right
     * "N skipped" pill in the WebViewer (see the WebSearchScreen
     * overlay). Reset to 0 by [finishBatchSave] so the pill
     * disappears when the next batch begins.
     */
    private val _webSelectionSkippedDupes = MutableStateFlow(0)
    val webSelectionSkippedDupes: StateFlow<Int> =
        _webSelectionSkippedDupes.asStateFlow()

    fun setWebSelectionSkippedDupes(count: Int) {
        _webSelectionSkippedDupes.value = count.coerceAtLeast(0)
    }

    /**
     * Enable or disable selection mode. Disabling also clears the current
     * basket — otherwise stale items linger and re-appear the next time the
     * user turns mode back on, which is confusing.
     *
     * v5.4.99cc — Also flips Multi Selection Mode off when this one is
     * turned on. The two modes are mutually exclusive: a single
     * long-press can either add one link or expand a whole head, not
     * both. See [setWebMultiSelectionMode] for the other direction.
     */
    fun setWebSelectionMode(enabled: Boolean) {
        _webSelectionMode.value = enabled
        if (enabled) {
            // Mutually exclusive with Multi Selection Mode
            _webMultiSelectionMode.value = false
            _webMultiExpandingHeads.value = 0
            _headExpansionQueue.value = emptyList()
        }
        if (!enabled) _webSelectionItems.value = emptyList()
    }

    /**
     * Toggle a URL in/out of the basket. Returns `true` if the URL was
     * added (caller then applies the highlight class), `false` if removed
     * (caller removes the class).
     */
    fun toggleWebSelection(url: String, title: String): Boolean {
        val cur = _webSelectionItems.value
        val existing = cur.firstOrNull { it.url == url }
        return if (existing != null) {
            _webSelectionItems.value = cur - existing
            false
        } else {
            _webSelectionItems.value = cur + WebSelectionItem(url, title.ifBlank { url })
            true
        }
    }

    fun clearWebSelection() { _webSelectionItems.value = emptyList() }

    // ────────────────────────────────────────────────────────────────────
    // v5.4.99cc — WebViewer MULTI Selection Mode (head expansion)
    //
    // A companion to plain Selection Mode. Instead of adding ONE link
    // per long-press, a long-press on a "head" link (like a monthly
    // Watchtower listing, or a publication's chapter index) fires off a
    // background page-load of that head, then automatically adds every
    // article link inside it to the batch basket. The user can then
    // long-press more heads to grow the basket further, or long-press +
    // drag to sweep across several adjacent heads. Save button then
    // downloads all collected body articles in one go.
    //
    // Design mirrors the batch-save architecture (see HiddenBatchSaver
    // in WebViewerArticleSaver.kt):
    //   - Head loads happen on a hidden 1dp WebView (HiddenHeadExpander,
    //     see MultiSelectionExpander.kt) so Chromium's TLS session +
    //     cookie jar are shared with the visible tab. Same reason
    //     v5.4.89cc switched batch saves off HttpURLConnection —
    //     Cloudflare's bot heuristics on jw.org reject unshared plain
    //     requests. The expander is hoisted to MainActivity level so
    //     it survives navigating between screens mid-expansion.
    //   - Head expansions are queued via [enqueueHeadExpansion]; the
    //     HiddenHeadExpander composable processes them one at a time
    //     (serial) and reports back via [onHeadExpansionCompleted] /
    //     [onHeadExpansionFailed].
    //   - Body articles arrive via [addWebSelectionsBulk] with
    //     `expanded = true` on each item. That flag tells the
    //     HiddenBatchSaver to apply the 10KB minimum size filter — see
    //     [WebSelectionItem].
    //   - Multi Mode and plain Selection Mode are mutually exclusive to
    //     keep the long-press semantics unambiguous.
    // ────────────────────────────────────────────────────────────────────

    /**
     * One pending head expansion, queued by [enqueueHeadExpansion] and
     * drained by the HiddenHeadExpander composable. The `id` is a
     * monotonic nanoTime stamp so two enqueue calls for the same URL
     * (rare, but possible if the user long-presses twice) produce
     * distinct queue entries that both get processed.
     */
    data class HeadExpansionRequest(
        val url: String,
        val text: String,
        val id: Long = System.nanoTime()
    )

    private val _webMultiSelectionMode = MutableStateFlow(false)
    /** True whenever the WebViewer is in "long-press-to-expand" mode. */
    val webMultiSelectionMode: StateFlow<Boolean> =
        _webMultiSelectionMode.asStateFlow()

    private val _webMultiExpandingHeads = MutableStateFlow(0)
    /**
     * Live count of head-expansion loads that are currently in flight.
     * The FAB shows an "Expanding N heads…" pill when this is > 0 so
     * the user knows their long-press is being worked on (jw.org's
     * listing pages can take a few seconds to load + parse).
     */
    val webMultiExpandingHeads: StateFlow<Int> =
        _webMultiExpandingHeads.asStateFlow()

    private val _headExpansionQueue =
        MutableStateFlow<List<HeadExpansionRequest>>(emptyList())
    /**
     * FIFO queue of head URLs waiting to be expanded. The
     * HiddenHeadExpander composable observes this and processes the
     * front item at a time on a shared hidden WebView.
     */
    val headExpansionQueue: StateFlow<List<HeadExpansionRequest>> =
        _headExpansionQueue.asStateFlow()

    /**
     * Enable or disable Multi Selection Mode. Flips plain Selection
     * Mode off if it was on (mutually exclusive), and clears any
     * lingering expansion queue + basket so a subsequent enable starts
     * with a clean slate.
     */
    fun setWebMultiSelectionMode(enabled: Boolean) {
        _webMultiSelectionMode.value = enabled
        if (enabled) {
            _webSelectionMode.value = false
        }
        if (!enabled) {
            _webSelectionItems.value = emptyList()
            _webMultiExpandingHeads.value = 0
            _headExpansionQueue.value = emptyList()
        }
    }

    /**
     * Queue a head URL for background expansion. No-op if Multi Mode
     * is off (guards against a stale long-press callback firing after
     * mode was toggled off). Increments the "expanding" counter
     * immediately so the FAB reflects the pending work; the counter is
     * decremented in [onHeadExpansionCompleted] / [onHeadExpansionFailed].
     */
    fun enqueueHeadExpansion(url: String, text: String) {
        if (!_webMultiSelectionMode.value) return
        if (url.isBlank()) return
        val request = HeadExpansionRequest(url, text)
        _headExpansionQueue.value = _headExpansionQueue.value + request
        _webMultiExpandingHeads.value = _webMultiExpandingHeads.value + 1
    }

    /**
     * Add many URLs to the basket in one shot (from head expansion).
     * Already-basketed URLs and duplicates within [items] are filtered
     * out so the count stays truthful. Returns the number of NEW items
     * actually added — callers use this for the activity-log summary.
     */
    fun addWebSelectionsBulk(items: List<WebSelectionItem>): Int {
        if (items.isEmpty()) return 0
        val cur = _webSelectionItems.value
        val existingUrls = HashSet<String>(cur.size).apply {
            for (it in cur) add(it.url)
        }
        val seenInBatch = HashSet<String>()
        val toAdd = ArrayList<WebSelectionItem>()
        for (item in items) {
            if (item.url.isBlank()) continue
            if (item.url in existingUrls) continue
            if (!seenInBatch.add(item.url)) continue
            toAdd.add(item)
        }
        if (toAdd.isEmpty()) return 0
        _webSelectionItems.value = cur + toAdd
        return toAdd.size
    }

    /**
     * Called by HiddenHeadExpander once a head's body links have been
     * extracted. Adds them to the basket (deduped), removes the head
     * from the expansion queue, decrements the "expanding" counter,
     * and logs an activity-log entry.
     */
    fun onHeadExpansionCompleted(
        request: HeadExpansionRequest,
        bodyLinks: List<WebSelectionItem>
    ) {
        _headExpansionQueue.value =
            _headExpansionQueue.value.filter { it.id != request.id }
        val added = addWebSelectionsBulk(bodyLinks)
        _webMultiExpandingHeads.value =
            (_webMultiExpandingHeads.value - 1).coerceAtLeast(0)
        logActivity(
            com.tebogo.markvault.data.ActivityLog.Category.BATCH_SAVE,
            "Multi-select head expanded",
            mapOf(
                "head" to request.text.take(80),
                "url" to request.url.take(200),
                "found" to bodyLinks.size.toString(),
                "added" to added.toString()
            )
        )
    }

    /** Called by HiddenHeadExpander on timeout / network error. */
    fun onHeadExpansionFailed(
        request: HeadExpansionRequest,
        error: String
    ) {
        _headExpansionQueue.value =
            _headExpansionQueue.value.filter { it.id != request.id }
        _webMultiExpandingHeads.value =
            (_webMultiExpandingHeads.value - 1).coerceAtLeast(0)
        logActivity(
            com.tebogo.markvault.data.ActivityLog.Category.BATCH_SAVE,
            "Multi-select head expansion failed",
            mapOf(
                "head" to request.text.take(80),
                "url" to request.url.take(200),
                "error" to error
            )
        )
    }

    // ────────────────────────────────────────────────────────────────────
    // v5.4.89cc — Batch save orchestration
    //
    // The v5.4.88cc implementation tried plain HttpURLConnection GETs from
    // the IO dispatcher. That failed on the primary target site (jw.org)
    // because Cloudflare's bot heuristics returned challenge pages instead
    // of the real HTML — every URL in the batch ended up with a non-2xx
    // response or a challenge stub, and the user saw "couldn't save any
    // selected articles". Even with cookies mirrored from the WebView's
    // CookieManager, the request signature didn't look like a real browser
    // hitting from the same TLS session.
    //
    // Fix: mirror what UrlImportScreen already does successfully — a
    // hidden WebView (1dp, off-screen but attached) that navigates to each
    // URL, waits for onPageFinished, extracts document.documentElement.
    // outerHTML, and hands the result to [saveBatchItem] below. The
    // WebView shares Chromium's session, TLS state, and cookie jar with
    // the visible tab, so any page the user could load manually is
    // reachable here too.
    //
    // The VM only orchestrates: [batchSaveRequest] is the queue the
    // composable-hosted saver watches; when it flips from empty to
    // non-empty, the saver starts loading URLs. Progress and completion
    // are pushed back into the VM so the FAB and the coaching pill can
    // reflect state across recompositions and viewer swaps.
    // ────────────────────────────────────────────────────────────────────

    /** Immutable snapshot of items to save, published to the hidden saver. */
    private val _batchSaveRequest = MutableStateFlow<List<WebSelectionItem>>(emptyList())
    val batchSaveRequest: StateFlow<List<WebSelectionItem>> = _batchSaveRequest.asStateFlow()

    /**
     * Kick off a batch save: publish the current selection as the request
     * queue and reset progress. The composable-hosted [HiddenBatchSaver]
     * observes [batchSaveRequest] and does the actual work.
     */
    fun startBatchSave() {
        val items = _webSelectionItems.value
        if (items.isEmpty()) return
        // Guard against overlapping saves — bail if a batch is already
        // in flight (the request queue is non-empty).
        if (_batchSaveRequest.value.isNotEmpty()) return
        _webSelectionSaving.value = 0 to items.size
        _batchSaveRequest.value = items
        logActivity(
            com.tebogo.markvault.data.ActivityLog.Category.BATCH_SAVE,
            "Batch save started",
            mapOf("count" to items.size.toString())
        )
    }

    /** Called by the saver as each URL completes (success or failure). */
    fun updateBatchSaveProgress(done: Int, total: Int) {
        _webSelectionSaving.value = done to total
    }

    /**
     * Save one loaded page. Called by the hidden WebView saver after
     * `document.documentElement.outerHTML` has been extracted for a URL.
     * Prefers the freshly-loaded page's own `<title>` (via the `pageTitle`
     * arg, which the caller pulls from `WebView.title`); falls back to the
     * HTML's inline title tag, then to the anchor text the user tapped.
     */
    suspend fun saveBatchItem(
        item: WebSelectionItem,
        html: String,
        pageTitle: String?
    ): SaveResult {
        val title = pageTitle?.takeIf { it.isNotBlank() }
            ?: extractHtmlTitle(html)
            ?: item.title
        val res = runCatching {
            saveOfflineHtmlPage(item.url, title, html)
        }.getOrElse { SaveResult.Error(it.message ?: "unknown") }
        // v5.4.90cc — Record the URL in the saved-URLs cache so the next
        // time the user visits a listing page containing this article, the
        // "already saved" highlight kicks in and the dedup filter skips it.
        if (res is SaveResult.Ok) {
            markUrlAsSaved(item.url)
            // v5.4.102cc — Also mark the title + filename so
            // multi-signal dedup catches this article on the next
            // batch even if the URL was blank or differed.
            markTitleAsSaved(title)
        }
        return res
    }

    /**
     * Called by the saver once the queue is drained. Resets all selection
     * state, clears the batch queue, and triggers a reindex so the fresh
     * files show up in search immediately.
     */
    fun finishBatchSave() {
        viewModelScope.launch { runCatching { reindex() } }
        _webSelectionSaving.value = 0 to 0
        _webSelectionItems.value = emptyList()
        _webSelectionMode.value = false
        _batchSaveRequest.value = emptyList()
        // v5.4.104cc — Clear the skipped-dupe counter so the
        // top-right pill disappears once the batch is done.
        _webSelectionSkippedDupes.value = 0
        // v5.4.99cc — Also reset multi-select state so the next batch
        // starts clean regardless of which mode produced this one.
        _webMultiSelectionMode.value = false
        _webMultiExpandingHeads.value = 0
        _headExpansionQueue.value = emptyList()
    }

    // ────────────────────────────────────────────────────────────────────
    // v5.4.90cc — Saved-URL cache for duplicate prevention + "already
    // saved" highlight.
    //
    // Backed by Prefs.savedOfflineUrls (a newline-separated string) so it
    // survives process death, but read into an in-memory Set on VM init
    // for O(1) lookups from the JS highlighter and the batch dedup
    // filter. Updates go through [markUrlAsSaved] which patches both the
    // in-memory Set and DataStore in a single suspend hop.
    // ────────────────────────────────────────────────────────────────────

    private val _savedOfflineUrls = MutableStateFlow<Set<String>>(emptySet())
    /**
     * URLs the user has previously saved as offline HTML. Consulted by the
     * WebViewer selection flow to (a) skip re-saving them in a batch and
     * (b) paint a distinct "already saved" highlight so the user knows
     * they're already in the library.
     */
    val savedOfflineUrls: StateFlow<Set<String>> = _savedOfflineUrls.asStateFlow()

    init {
        // Load the saved-URL cache from DataStore once at VM init. Keeps
        // the runtime lookup path allocation-free.
        viewModelScope.launch {
            val raw = prefs.savedOfflineUrlsRaw.first()
            _savedOfflineUrls.value = raw
                .split('\n')
                .filter { it.isNotBlank() }
                .toCollection(LinkedHashSet())
            // v5.4.100cc — Kick off the library-wide URL harvest after
            // the cache is warmed. Runs on Dispatchers.IO inside
            // [backfillSavedUrlsFromLibrary], so this init block
            // doesn't block anything user-visible. Every launch
            // top-ups the cache; new library files added since last
            // launch get picked up here.
            backfillSavedUrlsFromLibrary()
            // v5.4.102cc — Parallel backfill for the title/filename
            // caches. Both are needed for the multi-signal dedup in
            // HiddenBatchSaver ("URL → title → filename" try-in-order).
            backfillTitlesFromLibrary()
        }
    }

    /**
     * v5.4.100cc — Canonicalise a URL for cache comparisons.
     *
     * We keep this deliberately conservative: strip fragment,
     * trim trailing slash on non-root paths, and lowercase the
     * scheme + host. We do NOT strip query parameters — jw.org's
     * `finder?bible=...` etc. carry meaningful state, and we'd risk
     * false-positive dedup by dropping them. Called by both
     * [markUrlAsSaved] (write path) and [isUrlAlreadySaved] /
     * [urlsAlreadySaved] (read path) so the cache always compares
     * canonical against canonical.
     */
    private fun canonicalizeUrl(url: String): String {
        if (url.isBlank()) return url
        var s = url.trim()
        val hashIdx = s.indexOf('#')
        if (hashIdx >= 0) s = s.substring(0, hashIdx)
        // Case-insensitive scheme + host. Only touch the "scheme://host"
        // prefix; everything after must stay case-preserving because
        // some sites treat path/query as case-sensitive.
        val schemeSep = s.indexOf("://")
        if (schemeSep > 0) {
            val afterScheme = schemeSep + 3
            val pathStart = s.indexOf('/', afterScheme).let {
                if (it < 0) s.length else it
            }
            val schemeAndHost = s.substring(0, pathStart).lowercase()
            val rest = if (pathStart < s.length) s.substring(pathStart) else ""
            s = schemeAndHost + rest
        }
        // Trailing slash on non-root paths only.
        if (s.endsWith('/')) {
            val slashes = s.count { it == '/' }
            // "https://host/" has exactly 3 slashes — keep those alone;
            // "https://host/foo/" has 4+ — trim.
            if (slashes > 3) s = s.trimEnd('/')
        }
        return s
    }

    /**
     * v5.4.100cc — Fast O(1) check for whether a URL is already in the
     * library. Canonicalises the query URL first so trailing-slash /
     * fragment / mixed-case variants of the same URL all match.
     */
    fun isUrlAlreadySaved(url: String): Boolean {
        if (url.isBlank()) return false
        val cache = _savedOfflineUrls.value
        if (url in cache) return true
        val canonical = canonicalizeUrl(url)
        if (canonical in cache) return true
        return false
    }

    /**
     * v5.4.100cc — Bulk variant of [isUrlAlreadySaved]. Given a list
     * of candidate URLs, returns the subset that are already known to
     * the library. Used by the batch-save dedup filter in
     * `HiddenBatchSaver` so it does one cache read per batch instead
     * of one per URL.
     */
    fun urlsAlreadySaved(urls: List<String>): Set<String> {
        if (urls.isEmpty()) return emptySet()
        val cache = _savedOfflineUrls.value
        if (cache.isEmpty()) return emptySet()
        val out = HashSet<String>()
        for (u in urls) {
            if (u.isBlank()) continue
            if (u in cache) {
                out.add(u)
                continue
            }
            val canonical = canonicalizeUrl(u)
            if (canonical in cache) out.add(u)
        }
        return out
    }

    /**
     * Record that a URL has been saved. Called from [saveBatchItem] after
     * every successful save and from [saveOfflineHtmlPage]-adjacent flows.
     * Patches the in-memory Set first (so UI updates immediately), then
     * fires a background write to DataStore.
     *
     * v5.4.100cc — Now stores the canonicalised URL so downstream
     * `contains` checks work regardless of trailing-slash / fragment
     * differences between the save-time URL and the check-time URL.
     */
    fun markUrlAsSaved(url: String) {
        if (url.isBlank()) return
        val canonical = canonicalizeUrl(url)
        val cur = _savedOfflineUrls.value
        if (canonical in cur) return
        // LinkedHashSet insertion-order preservation is what the Prefs LRU
        // cap relies on — always add at the end.
        val next = LinkedHashSet(cur).apply { add(canonical) }
        _savedOfflineUrls.value = next
        viewModelScope.launch { runCatching { prefs.setSavedOfflineUrls(next) } }
    }

    /**
     * v5.4.100cc — Bulk mark-as-saved for the library backfill. Adds
     * every URL in [urls] to the in-memory cache (deduped +
     * canonicalised), then writes the union to DataStore in a single
     * transaction. Much cheaper than N × [markUrlAsSaved] for 10K+
     * URL harvests.
     */
    fun markUrlsAsSavedBulk(urls: Collection<String>) {
        if (urls.isEmpty()) return
        val cur = _savedOfflineUrls.value
        val next = LinkedHashSet(cur)
        var added = 0
        for (raw in urls) {
            if (raw.isBlank()) continue
            val canonical = canonicalizeUrl(raw)
            if (canonical.isBlank()) continue
            if (next.add(canonical)) added++
        }
        if (added == 0) return
        _savedOfflineUrls.value = next
        viewModelScope.launch { runCatching { prefs.setSavedOfflineUrls(next) } }
    }

    /**
     * v5.4.100cc — Harvest source URLs from every note in the library
     * and add them to [savedOfflineUrls]. Runs in the background on VM
     * init and after every reindex, so the URL cache reflects the
     * actual library state — not just URLs saved during the current
     * session.
     *
     * Runs in two phases:
     *
     *   • **Phase 1 — DB content extraction (fast).** Reads the
     *     `content` field of every markdown/HTML/MHTML note that
     *     plausibly carries a source URL. Markdown notes hit here
     *     because YAML frontmatter (`source: <url>`) survives
     *     indexing intact. HTML notes indexed by v5.4.100cc or later
     *     hit here because [stripHtmlForIndex] now prepends
     *     `source: <url>` to the FTS content.
     *
     *   • **Phase 2 — raw-file fallback (legacy HTML).** For every
     *     HTML/MHTML note whose Phase 1 content DIDN'T carry a
     *     `source:` prefix — meaning it was indexed by an older
     *     MarkVault where `stripHtmlForIndex` destroyed the URL — we
     *     open the raw file via ContentResolver, read the first
     *     16 KB, and pull the URL from the envelope comment /
     *     `<base href>` / `<link rel="canonical">` / `<meta og:url>`
     *     via [extractSourceUrlFromRawHtml]. This catches every
     *     legacy HTML file WITHOUT requiring a full reindex, which
     *     was the pain point in v5.4.100cc first-run: "many html
     *     duplicates" would otherwise slip through the batch dedup
     *     until the user manually reindexed.
     *
     * Idempotent — the bulk-mark path skips duplicates. Safe to call
     * repeatedly.
     */
    fun backfillSavedUrlsFromLibrary() {
        viewModelScope.launch(Dispatchers.IO) {
            val rows = runCatching { dao.notesForUrlHarvest() }.getOrElse { return@launch }
            if (rows.isEmpty()) return@launch
            val collected = HashSet<String>()

            // Phase 1: content-based extraction (fast, DB-backed).
            for (row in rows) {
                extractUrlsFromNoteContent(row.content, collected)
            }
            val phase1Count = collected.size

            // Phase 2: raw-file fallback for legacy HTML/MHTML files
            // whose Phase 1 content was stripped of its source URL by
            // an older `stripHtmlForIndex`. We identify these by the
            // absence of a `source:` prefix in their content (Phase 1
            // depends on that prefix; if it's missing, Phase 1 found
            // nothing).
            var rawScanned = 0
            var rawExtracted = 0
            for (row in rows) {
                val ft = row.fileType.lowercase()
                val isHtmlish = ft == "html" || ft == "htm" ||
                    ft == "mhtml" || ft == "mht"
                if (!isHtmlish) continue
                // Cheap skip: if content already carries `source:`,
                // Phase 1 handled it.
                if (row.content.contains("source:", ignoreCase = true)) continue
                if (row.uri.isBlank()) continue
                val raw = readHtmlFileHead(row.uri) ?: continue
                rawScanned++
                val url = com.tebogo.markvault.data.extractSourceUrlFromRawHtml(raw)
                    ?: continue
                val before = collected.size
                addUrlIfHttp(url, collected)
                if (collected.size > before) rawExtracted++
            }

            if (collected.isNotEmpty()) {
                withContext(Dispatchers.Main) {
                    markUrlsAsSavedBulk(collected)
                }
                logActivity(
                    com.tebogo.markvault.data.ActivityLog.Category.BATCH_SAVE,
                    "URL cache backfill completed",
                    mapOf(
                        "scanned" to rows.size.toString(),
                        "urls_found" to collected.size.toString(),
                        "phase1_urls" to phase1Count.toString(),
                        "html_raw_scanned" to rawScanned.toString(),
                        "html_raw_added" to rawExtracted.toString()
                    )
                )
            }
        }
    }

    /**
     * v5.4.100cc — Read the first [maxBytes] of an HTML/MHTML file
     * from a content URI. Used by the Phase 2 legacy-HTML backfill
     * pass in [backfillSavedUrlsFromLibrary].
     *
     * We deliberately read a bounded prefix (16 KB by default)
     * instead of the whole file. The envelope comment, base href,
     * canonical link, and og:url meta all live in the document head
     * — a fully-saved jw.org article can be 500 KB+, and reading all
     * of it through SAF's ContentResolver would turn the backfill
     * pass into a multi-minute wait on a 14K-note library. 16 KB is
     * roomy enough for any realistic document head.
     */
    private fun readHtmlFileHead(uriString: String, maxBytes: Int = 16 * 1024): String? {
        return runCatching {
            val ctx = getApplication<Application>()
            val uri = android.net.Uri.parse(uriString)
            ctx.contentResolver.openInputStream(uri)?.use { input ->
                val buf = ByteArray(maxBytes)
                var offset = 0
                while (offset < maxBytes) {
                    val read = input.read(buf, offset, maxBytes - offset)
                    if (read <= 0) break
                    offset += read
                }
                String(buf, 0, offset, Charsets.UTF_8)
            }
        }.getOrNull()
    }

    /**
     * v5.4.100cc — Extract every plausible source-URL string from a
     * note's content and add canonical forms to [out]. Handles:
     *   • YAML frontmatter `source: <url>` (and `source: "<url>"`)
     *   • Body-line `> Source: <<url>>` / `*Source: <url>*`
     *   • Inline `source: <url>` prefix injected by
     *     v5.4.100cc's stripHtmlForIndex for HTML/MHTML notes.
     * Non-http(s) URLs are dropped so mailto:/ file:/ don't pollute
     * the cache.
     */
    private fun extractUrlsFromNoteContent(
        content: String,
        out: MutableSet<String>
    ) {
        if (content.isBlank()) return
        // Look at just the first 4KB — frontmatter and envelope
        // comments always live near the head. Cheaper than regexing
        // 500KB pages.
        val head = if (content.length > 4096) content.substring(0, 4096) else content
        // 1. YAML/body `source:` prefix
        val sourceLine = Regex(
            """(?im)^\s*[>*\s]*source\s*[:=]\s*[<"']?(https?://\S+?)[>"'\s]*$""",
        )
        for (m in sourceLine.findAll(head)) {
            val raw = m.groupValues.getOrNull(1) ?: continue
            addUrlIfHttp(raw, out)
        }
        // 2. `Source: <URL>` on any line
        val sourceInline = Regex(
            """(?i)Source:\s*[<"']?(https?://\S+?)[>"'\s\)*]""",
        )
        for (m in sourceInline.findAll(head)) {
            val raw = m.groupValues.getOrNull(1) ?: continue
            addUrlIfHttp(raw, out)
        }
    }

    private fun addUrlIfHttp(raw: String, out: MutableSet<String>) {
        val trimmed = raw.trim().trimEnd('>', '"', '\'', ')', ',', '.', ';')
        if (trimmed.length < 10) return
        if (!trimmed.startsWith("http://") && !trimmed.startsWith("https://")) return
        val canonical = canonicalizeUrl(trimmed)
        if (canonical.isNotBlank()) out.add(canonical)
    }

    // ────────────────────────────────────────────────────────────────────
    // v5.4.102cc — Multi-signal dedup (URL + title)
    //
    // The URL cache (v5.4.100cc) catches every article whose source URL
    // MarkVault knows about. But two remaining gaps produce duplicates:
    //
    //   1. A URL variant that canonicalisation can't fold — e.g. mobile
    //      vs desktop sub-domain, a redirect chain that never resolves
    //      to the same href, or a shared link with tracking params we
    //      chose not to strip.
    //   2. A hand-crafted markdown note whose article title matches an
    //      article MarkVault is about to batch-save from the web — no
    //      source URL exists to compare, so URL dedup is blind to it.
    //
    // To close both gaps we build an in-memory Set of every note's
    // normalised title, and layer the check: URL match wins, then
    // title match. Any hit stops the save. Cache is rebuilt from
    // `dao.allMeta()` on VM init and after every reindex; NOT persisted
    // to DataStore because the rebuild is a single indexed SQLite scan
    // (<200ms even on 14K notes), cheaper than serialising the
    // normalised strings through DataStore on every launch.
    //
    // v5.4.103cc — Filename matching removed. Series like "Questions
    // From Readers" ship many articles under the same base filename;
    // the collision-suffix stripper in `normalizeFileName` would fold
    // them all onto one cache key and false-positive every entry in
    // the series after the first. Titles carry the article-specific
    // subtitle and stay unique, so title-based dedup catches the real
    // duplicates without the false positives.
    // ────────────────────────────────────────────────────────────────────

    private val _savedTitles = MutableStateFlow<Set<String>>(emptySet())
    /** Normalised titles of every note in the library. Rebuilt after
     *  every reindex by [backfillTitlesFromLibrary]. */
    val savedTitles: StateFlow<Set<String>> = _savedTitles.asStateFlow()

    /**
     * v5.4.102cc — Normalise a title or heading string for match
     * comparison. Aggressive lowercase-and-strip-punctuation so
     * "The Watchtower — 2024" and "the watchtower 2024" both fold to
     * the same key. Uses `\p{IsLatin}` alongside `[a-z0-9]` so Sepedi
     * diacritics survive normalisation instead of getting dropped as
     * "punctuation". Blank strings pass through unchanged.
     */
    private fun normalizeTitle(raw: String): String {
        if (raw.isBlank()) return ""
        val lower = raw.trim().lowercase()
        val stripped = lower.replace(Regex("[^\\p{IsLatin}0-9\\s]+"), " ")
        return stripped.replace(Regex("\\s+"), " ").trim()
    }

    /**
     * v5.4.102cc — Add a title to the cache. Called from every
     * successful save site ([saveBatchItem], [saveOfflineHtmlPage],
     * [saveConvertedMarkdown]) so the cache stays in step with the
     * library without needing a reindex. Silently no-ops on blank
     * input.
     *
     * v5.4.103cc — Renamed from `markTitleAndFileNameAsSaved`; only
     * the title is tracked now (see class-header note).
     */
    fun markTitleAsSaved(title: String) {
        val nt = normalizeTitle(title)
        if (nt.isBlank()) return
        val cur = _savedTitles.value
        if (nt in cur) return
        _savedTitles.value = cur + nt
    }

    /**
     * v5.4.102cc — Rebuild the title cache from `dao.allMeta()`.
     * Fired from VM init and after every successful reindex, so
     * newly imported files land in the cache without requiring an
     * app restart.
     *
     * Runs on Dispatchers.IO to avoid stalling the main thread during
     * the SQLite scan; publishes to the StateFlow via Dispatchers.Main
     * so downstream observers (batch dedup filter, prompt bar, etc.)
     * see the update on the UI thread.
     */
    fun backfillTitlesFromLibrary() {
        viewModelScope.launch(Dispatchers.IO) {
            val meta = runCatching { dao.allMeta() }.getOrElse { return@launch }
            if (meta.isEmpty()) return@launch
            val titles = HashSet<String>()
            for (m in meta) {
                val nt = normalizeTitle(m.title)
                if (nt.isNotBlank()) titles.add(nt)
            }
            withContext(Dispatchers.Main) {
                _savedTitles.value = titles
            }
            logActivity(
                com.tebogo.markvault.data.ActivityLog.Category.BATCH_SAVE,
                "Title cache rebuilt",
                mapOf(
                    "notes" to meta.size.toString(),
                    "titles" to titles.size.toString()
                )
            )
        }
    }

    /**
     * v5.4.104cc — Standalone title-only dedup check for callers that
     * don't have a full [WebSelectionItem] on hand — the [SavePromptBar]
     * uses this to hide the "This article isn't saved" pill when the
     * current page's `<title>` matches something already in the library
     * (typical case: user saved the article as markdown a while back,
     * the URL was blank / different, but the title is stable).
     *
     * Same ≥15-char guard as [isBatchItemAlreadySaved] so generic
     * page titles like "Home" / "Search" don't produce false
     * positives.
     */
    fun isTitleAlreadySaved(title: String): Boolean {
        val nt = normalizeTitle(title)
        if (nt.length < 15) return false
        return nt in _savedTitles.value
    }

    /**
     * v5.4.102cc — Multi-signal dedup check for a single batch item.
     * Returns true if EITHER of the following match a note already in
     * the library:
     *
     *   1. **URL** — canonicalised (see [isUrlAlreadySaved]).
     *   2. **Title** — the anchor text captured on the head page
     *      (`item.title`), normalised, matched against every library
     *      note's normalised title.
     *
     * Guard: title leg is skipped for very short strings (< 15 chars)
     * to avoid false positives from generic anchor text like "Read
     * more", "View", "Previous", etc. URL match still applies at any
     * length.
     *
     * v5.4.103cc — Filename leg removed (see class-header note).
     */
    fun isBatchItemAlreadySaved(item: WebSelectionItem): Boolean {
        if (isUrlAlreadySaved(item.url)) return true
        val nt = normalizeTitle(item.title)
        if (nt.length < 15) return false
        if (nt in _savedTitles.value) return true
        return false
    }

    /**
     * v5.4.102cc — Bulk variant of [isBatchItemAlreadySaved]. Returns
     * the URLs of items already in the library. Used by
     * [HiddenBatchSaver]'s dedup filter so the batch save shows
     * accurate "already saved" counts BEFORE the network fetch
     * starts.
     */
    fun batchItemsAlreadySaved(items: List<WebSelectionItem>): Set<String> {
        if (items.isEmpty()) return emptySet()
        val out = HashSet<String>()
        for (item in items) {
            if (isBatchItemAlreadySaved(item)) out.add(item.url)
        }
        return out
    }

    /**
     * Start the [BatchSaveService] foreground service so the batch save
     * gets a persistent notification with a progress bar, a wake lock
     * keeping the CPU alive with the screen off, and elevated process
     * priority so backgrounding / multitasking within MarkVault doesn't
     * kill the in-flight WebView loads. Idempotent — a duplicate start
     * just refreshes the notification.
     *
     * The service observes [webSelectionSaving] to update the notification
     * and stops itself when progress returns to (0, 0). See
     * [BatchSaveService] for the full contract.
     */
    fun startBatchSaveService(ctx: android.content.Context) {
        val intent = android.content.Intent(
            ctx.applicationContext,
            com.tebogo.markvault.ui.BatchSaveService::class.java
        )
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            ctx.applicationContext.startForegroundService(intent)
        } else {
            ctx.applicationContext.startService(intent)
        }
    }

    fun stopBatchSaveService(ctx: android.content.Context) {
        val intent = android.content.Intent(
            ctx.applicationContext,
            com.tebogo.markvault.ui.BatchSaveService::class.java
        )
        runCatching { ctx.applicationContext.stopService(intent) }
    }

    /**
     * Pull the `<title>` out of a raw HTML string. Regex-based rather than
     * DOM-parse-based because we're on the IO dispatcher and don't want to
     * spin up Jsoup for a one-line extraction. Handles attributes on the
     * title tag and leading/trailing whitespace; anything else falls
     * through and the caller uses the anchor's text as a fallback.
     */
    private fun extractHtmlTitle(html: String): String? {
        val re = Regex("<title[^>]*>([\\s\\S]*?)</title>", RegexOption.IGNORE_CASE)
        val raw = re.find(html)?.groupValues?.getOrNull(1)?.trim() ?: return null
        // Basic HTML-entity decoding for the handful of characters that
        // commonly appear in page titles.
        val decoded = raw
            .replace("&amp;", "&")
            .replace("&lt;", "<")
            .replace("&gt;", ">")
            .replace("&quot;", "\"")
            .replace("&#39;", "'")
            .replace(Regex("\\s+"), " ")
            .trim()
        return decoded.takeIf { it.isNotBlank() }
    }

    fun setFontScale(v: Float) { viewModelScope.launch { prefs.setFontScale(v) } }
    fun setTheme(name: String) { viewModelScope.launch { prefs.setTheme(name) } }
    fun setSmartStylingAllDocs(v: Boolean) { viewModelScope.launch { prefs.setSmartStylingAllDocs(v) } }
    fun setSwipeSwitchTabs(v: Boolean) { viewModelScope.launch { prefs.setSwipeSwitchTabs(v) } }
    fun setTextContrast(v: Float) { viewModelScope.launch { prefs.setTextContrast(v) } }

    val importsSubfolder: StateFlow<String> = prefs.importsSubfolder
        .stateIn(viewModelScope, SharingStarted.Eagerly, "")
    fun setImportsSubfolder(name: String) {
        viewModelScope.launch { prefs.setImportsSubfolder(name) }
    }

    // Web-import include toggles (front-matter / URL / excerpt / body).
    val includeFrontmatter: StateFlow<Boolean> = prefs.includeFrontmatter
        .stateIn(viewModelScope, SharingStarted.Eagerly, true)
    val includeUrl: StateFlow<Boolean> = prefs.includeUrl
        .stateIn(viewModelScope, SharingStarted.Eagerly, true)
    val includeExcerpt: StateFlow<Boolean> = prefs.includeExcerpt
        .stateIn(viewModelScope, SharingStarted.Eagerly, true)
    val includeBody: StateFlow<Boolean> = prefs.includeBody
        .stateIn(viewModelScope, SharingStarted.Eagerly, true)
    fun setIncludeFrontmatter(v: Boolean) { viewModelScope.launch { prefs.setIncludeFrontmatter(v) } }
    fun setIncludeUrl(v: Boolean)         { viewModelScope.launch { prefs.setIncludeUrl(v) } }
    fun setIncludeExcerpt(v: Boolean)     { viewModelScope.launch { prefs.setIncludeExcerpt(v) } }
    fun setIncludeBody(v: Boolean)        { viewModelScope.launch { prefs.setIncludeBody(v) } }

    /**
     * v5.4.10 — Save a PDF file (typically from URL → PDF conversion)
     * into the user's library. Returns the new file's display URI on
     * success, or null on failure. Uses the same library scheme as
     * [saveImportedMarkdown] but with application/pdf mimetype and
     * the bytes copied directly from the temp file.
     */
    suspend fun saveSharedPdfToLibrary(
        tempPdf: java.io.File, fileName: String
    ): String? = withContext(Dispatchers.IO) {
        val libUri = libraryUri.value ?: return@withContext null
        val treeUri = runCatching { Uri.parse(libUri) }.getOrNull() ?: return@withContext null
        val cr = getApplication<Application>().contentResolver
        val hasWrite = cr.persistedUriPermissions.any {
            it.uri == treeUri && it.isWritePermission
        }
        if (!hasWrite) return@withContext null
        try {
            val rootId = android.provider.DocumentsContract.getTreeDocumentId(treeUri)
            val rootDocUri = android.provider.DocumentsContract.buildDocumentUriUsingTree(treeUri, rootId)
            val sub = importsSubfolder.value
            val parentUri = if (sub.isBlank()) rootDocUri else
                findOrCreateFolder(cr, treeUri, rootId, sub) ?: return@withContext null
            val safeName = sanitizeFilename(fileName.removeSuffix(".pdf")) + ".pdf"
            val uniqueName = ensureUnique(cr, treeUri, parentUri, safeName)
            val newDoc = android.provider.DocumentsContract.createDocument(
                cr, parentUri, "application/pdf", uniqueName
            ) ?: return@withContext null
            cr.openOutputStream(newDoc, "w")?.use { out ->
                tempPdf.inputStream().use { input -> input.copyTo(out) }
            } ?: return@withContext null
            viewModelScope.launch { refreshNotes() }
            newDoc.toString()
        } catch (t: Throwable) {
            android.util.Log.e("MarkVault", "saveSharedPdfToLibrary failed", t)
            null
        }
    }

    /**
     * Save a markdown string into the library, inside the configured subfolder.
     * Creates the subfolder lazily if it doesn't exist yet.
     *
     * @param title      base filename (no extension); will be sanitized
     * @param markdown   file body (UTF-8)
     * @param subfolder  subfolder name; empty string = library root
     * @return SaveResult with the new file's display URI on success, or an error message
     */
    suspend fun saveImportedMarkdown(
        title: String, markdown: String, subfolder: String
    ): SaveResult = withContext(Dispatchers.IO) {
        val libUri = libraryUri.value
            ?: return@withContext SaveResult.Error("No library is set. Pick one in Settings first.")
        val treeUri = runCatching { Uri.parse(libUri) }.getOrNull()
            ?: return@withContext SaveResult.Error("Library URI is invalid. Re-pick the library folder.")
        val cr = getApplication<Application>().contentResolver
        // Verify we have write permission persisted; if not, surface a clear error.
        val hasWrite = cr.persistedUriPermissions.any {
            it.uri == treeUri && it.isWritePermission
        }
        if (!hasWrite) {
            return@withContext SaveResult.Error(
                "Library is read-only. Open Settings and tap \u201CRe-grant library access\u201D."
            )
        }
        try {
            val rootId = android.provider.DocumentsContract.getTreeDocumentId(treeUri)
            val rootDocUri = android.provider.DocumentsContract.buildDocumentUriUsingTree(treeUri, rootId)
            val parentUri = if (subfolder.isBlank()) rootDocUri else
                findOrCreateFolder(cr, treeUri, rootId, subfolder)
                    ?: return@withContext SaveResult.Error("Could not create subfolder \"$subfolder\".")

            val safeName = sanitizeFilename(title)
            val fileName = ensureUnique(cr, treeUri, parentUri, safeName)
            val newDoc = android.provider.DocumentsContract.createDocument(
                cr, parentUri, "text/markdown", fileName
            ) ?: return@withContext SaveResult.Error("Failed to create the file.")
            cr.openOutputStream(newDoc, "w")?.use {
                it.write(markdown.toByteArray(Charsets.UTF_8))
            } ?: return@withContext SaveResult.Error("Could not open the new file for writing.")
            // Trigger a quick library refresh so the new note appears
            val cur = libUri
            if (cur != null) viewModelScope.launch { /* lazy reindex hint */ refreshNotes() }
            SaveResult.Ok(newDoc.toString(), fileName, subfolder)
        } catch (e: SecurityException) {
            SaveResult.Error("Permission denied: ${e.message}")
        } catch (e: Exception) {
            SaveResult.Error("Save failed: ${e.message ?: e.javaClass.simpleName}")
        }
    }

    /** Walk the library root, find a folder by name, or create it. Returns the folder doc URI. */
    private fun findOrCreateFolder(
        cr: android.content.ContentResolver, treeUri: Uri, rootId: String, name: String
    ): Uri? {
        val children = android.provider.DocumentsContract.buildChildDocumentsUriUsingTree(treeUri, rootId)
        val proj = arrayOf(
            android.provider.DocumentsContract.Document.COLUMN_DOCUMENT_ID,
            android.provider.DocumentsContract.Document.COLUMN_DISPLAY_NAME,
            android.provider.DocumentsContract.Document.COLUMN_MIME_TYPE
        )
        cr.query(children, proj, null, null, null)?.use { cur ->
            while (cur.moveToNext()) {
                val n = cur.getString(1) ?: continue
                val m = cur.getString(2) ?: ""
                if (n.equals(name, ignoreCase = true) &&
                    m == android.provider.DocumentsContract.Document.MIME_TYPE_DIR) {
                    val did = cur.getString(0)
                    return android.provider.DocumentsContract.buildDocumentUriUsingTree(treeUri, did)
                }
            }
        }
        // Not found — create it
        val rootDocUri = android.provider.DocumentsContract.buildDocumentUriUsingTree(treeUri, rootId)
        return android.provider.DocumentsContract.createDocument(
            cr, rootDocUri, android.provider.DocumentsContract.Document.MIME_TYPE_DIR, name
        )
    }

    /**
     * TASK 2 (v4.4 rewrite): Save the current web page as a real `.html` file.
     *
     * The previous implementation used `WebView.saveWebArchive()`, which only
     * produces `.mhtml` regardless of file extension — the user reported this
     * as "doesn't save offline html, it saves in mhtml". This version takes the
     * page's rendered HTML (already pulled via `document.documentElement.outerHTML`
     * by the caller) and writes it as a self-describing `.html` document with
     * a `<base href>` so relative URLs still resolve to the original site when
     * online. Images/CSS aren't inlined — for fully self-contained archives use
     * MHTML, but the menu label said HTML so HTML is what we save.
     */
    suspend fun saveOfflineHtmlPage(
        sourceUrl: String, title: String, html: String
    ): SaveResult = withContext(Dispatchers.IO) {
        val libUri = libraryUri.value
            ?: return@withContext SaveResult.Error("No library is set. Pick one in Settings first.")
        val treeUri = runCatching { Uri.parse(libUri) }.getOrNull()
            ?: return@withContext SaveResult.Error("Library URI is invalid.")
        val cr = getApplication<Application>().contentResolver
        val hasWrite = cr.persistedUriPermissions.any {
            it.uri == treeUri && it.isWritePermission
        }
        if (!hasWrite) {
            return@withContext SaveResult.Error("Library is read-only. Re-grant access in Settings.")
        }
        try {
            val subfolder = importsSubfolder.value
            val rootId = android.provider.DocumentsContract.getTreeDocumentId(treeUri)
            val rootDocUri = android.provider.DocumentsContract.buildDocumentUriUsingTree(treeUri, rootId)
            val parentUri = if (subfolder.isBlank()) rootDocUri else
                findOrCreateFolder(cr, treeUri, rootId, subfolder)
                    ?: return@withContext SaveResult.Error("Could not create subfolder.")

            val safeBase = sanitizeFilename(title).removeSuffix(".md")
            val fileName = ensureUniqueAnyExt(cr, treeUri, parentUri, safeBase, ".html")

            // Wrap the page's outerHTML with a clean envelope. If the source
            // already declared `<!DOCTYPE html>` we keep ours anyway — duplicates
            // are harmless and the browser picks the first one.
            val wrappedHtml = buildHtmlEnvelope(sourceUrl, title, html)

            val newDoc = android.provider.DocumentsContract.createDocument(
                cr, parentUri, "text/html", fileName
            ) ?: return@withContext SaveResult.Error("Failed to create HTML file.")
            cr.openOutputStream(newDoc, "w")?.use { out ->
                out.write(wrappedHtml.toByteArray(Charsets.UTF_8))
            } ?: return@withContext SaveResult.Error("Could not write file.")
            // v5.4.93cc — Mark the source URL as saved so the WebViewer
            // "already saved" highlight and the "This isn't saved" prompt
            // both stay in sync with actual writes. Covers the batch flow
            // (which used to mark URLs in saveBatchItem — now redundant),
            // the single-page "Save as Offline HTML" menu item, and any
            // future entry point that reaches this function.
            markUrlAsSaved(sourceUrl)
            // v5.4.102cc — Also mark title + filename for the
            // multi-signal dedup path.
            markTitleAsSaved(title)
            // v5.4.94cc — Activity log entry so the "Saved articles"
            // history in Settings can render the who/what/when.
            logActivity(
                com.tebogo.markvault.data.ActivityLog.Category.SAVED_ARTICLE,
                "Saved offline HTML: $title",
                mapOf(
                    "url" to sourceUrl,
                    "site" to (runCatching { java.net.URI(sourceUrl).host.orEmpty() }
                        .getOrElse { "" }),
                    "format" to "HTML",
                    "file" to fileName
                )
            )
            SaveResult.Ok(newDoc.toString(), fileName, subfolder)
        } catch (e: Exception) {
            SaveResult.Error("Save failed: ${e.message ?: e.javaClass.simpleName}")
        }
    }

    /**
     * Wrap a page's outerHTML with a minimal envelope: DOCTYPE, UTF-8 meta,
     * title, `<base href>` so the page's relative links still resolve to the
     * original site, plus a comment header marking it as MarkVault-saved.
     *
     * If the input already looks like a full document we keep it intact but
     * inject the base href and meta charset if missing.
     */
    private fun buildHtmlEnvelope(sourceUrl: String, title: String, raw: String): String {
        val savedAt = java.text.SimpleDateFormat(
            "yyyy-MM-dd HH:mm", java.util.Locale.US
        ).format(java.util.Date())
        val escapedTitle = title.replace("&", "&amp;")
            .replace("<", "&lt;").replace(">", "&gt;").replace("\"", "&quot;")
        val escapedUrl = sourceUrl.replace("&", "&amp;").replace("\"", "&quot;")
        val preamble = """
            |<!DOCTYPE html>
            |<!-- Saved by MarkVault on $savedAt from $sourceUrl -->
            |<meta charset="utf-8">
            |<base href="$escapedUrl">
            |<title>$escapedTitle</title>
            |
            """.trimMargin()
        return preamble + raw
    }

    /**
     * Legacy MHTML archive save (kept for any future menu item that wants the
     * true offline-binary format). Not currently wired to a UI button — the
     * Save as Offline HTML button uses saveOfflineHtmlPage above.
     */
    suspend fun saveOfflineHtmlArchive(
        cacheFile: java.io.File, title: String
    ): SaveResult = withContext(Dispatchers.IO) {
        val libUri = libraryUri.value
            ?: return@withContext SaveResult.Error("No library is set. Pick one in Settings first.")
        val treeUri = runCatching { Uri.parse(libUri) }.getOrNull()
            ?: return@withContext SaveResult.Error("Library URI is invalid.")
        val cr = getApplication<Application>().contentResolver
        val hasWrite = cr.persistedUriPermissions.any {
            it.uri == treeUri && it.isWritePermission
        }
        if (!hasWrite) {
            return@withContext SaveResult.Error("Library is read-only. Re-grant access in Settings.")
        }
        try {
            val subfolder = importsSubfolder.value
            val rootId = android.provider.DocumentsContract.getTreeDocumentId(treeUri)
            val rootDocUri = android.provider.DocumentsContract.buildDocumentUriUsingTree(treeUri, rootId)
            val parentUri = if (subfolder.isBlank()) rootDocUri else
                findOrCreateFolder(cr, treeUri, rootId, subfolder)
                    ?: return@withContext SaveResult.Error("Could not create subfolder.")

            val safeBase = sanitizeFilename(title).removeSuffix(".md")
            val fileName = ensureUniqueAnyExt(cr, treeUri, parentUri, safeBase, ".mhtml")
            val newDoc = android.provider.DocumentsContract.createDocument(
                cr, parentUri, "application/x-mimearchive", fileName
            ) ?: return@withContext SaveResult.Error("Failed to create archive file.")
            cr.openOutputStream(newDoc, "w")?.use { out ->
                cacheFile.inputStream().use { it.copyTo(out) }
            } ?: return@withContext SaveResult.Error("Could not write archive.")
            runCatching { cacheFile.delete() }
            SaveResult.Ok(newDoc.toString(), fileName, subfolder)
        } catch (e: Exception) {
            SaveResult.Error("Archive save failed: ${e.message ?: e.javaClass.simpleName}")
        }
    }

    /**
     * TASK 3: Convert an HTML string into a lightweight Markdown body and save
     * it as a `.md` file in the library's imports subfolder. The converter is
     * deliberately minimal — it strips scripts/styles, converts headings,
     * paragraphs, lists, links, images, and inline formatting. Power users
     * who need a perfect conversion can still use the URL Import flow.
     */
    suspend fun saveConvertedMarkdown(
        sourceUrl: String, pageTitle: String, html: String
    ): SaveResult {
        val markdown = buildString {
            append("---\n")
            append("source: ").append(sourceUrl).append('\n')
            append("title: ").append(pageTitle.ifBlank { "Web page" }).append('\n')
            append("imported: ").append(java.text.SimpleDateFormat(
                "yyyy-MM-dd HH:mm", java.util.Locale.US
            ).format(java.util.Date())).append('\n')
            append("---\n\n")
            append("# ").append(pageTitle.ifBlank { "Web page" }).append("\n\n")
            append("> Source: <").append(sourceUrl).append(">\n\n")
            append(simpleHtmlToMarkdown(html))
        }
        val res = saveImportedMarkdown(
            title = pageTitle.ifBlank { "Web page" },
            markdown = markdown,
            subfolder = importsSubfolder.value
        )
        // v5.4.93cc — Register the URL against the saved-URL set for the
        // WebViewer's dedup + prompt flow. A page that's been converted to
        // Markdown is, from the user's POV, "already saved" — no point
        // asking again.
        if (res is SaveResult.Ok) {
            if (sourceUrl.isNotBlank()) markUrlAsSaved(sourceUrl)
            // v5.4.102cc — Even without a source URL (share-sheet
            // import etc.), mark the title + filename so the next
            // batch save can detect the dupe.
            markTitleAsSaved(pageTitle)
            logActivity(
                com.tebogo.markvault.data.ActivityLog.Category.SAVED_ARTICLE,
                "Saved as Markdown: $pageTitle",
                mapOf(
                    "url" to sourceUrl,
                    "site" to (runCatching { java.net.URI(sourceUrl).host.orEmpty() }
                        .getOrElse { "" }),
                    "format" to "Markdown",
                    "file" to res.fileName
                )
            )
        }
        return res
    }

    /**
     * Quick-and-dirty HTML → Markdown converter. Handles the structural elements
     * (headings, paragraphs, lists, links, images, code, blockquotes, line
     * breaks) and discards scripts, styles, and ARIA noise. Good enough for
     * a "save this web page to my vault" feature; not a replacement for the
     * full URL-import pipeline which does real DOM parsing on the server side.
     */
    private fun simpleHtmlToMarkdown(html: String): String {
        if (html.isBlank()) return ""
        var s = html
        // Remove scripts/styles/noscript blocks
        s = s.replace(Regex("(?is)<script[^>]*>.*?</script>"), "")
        s = s.replace(Regex("(?is)<style[^>]*>.*?</style>"), "")
        s = s.replace(Regex("(?is)<noscript[^>]*>.*?</noscript>"), "")
        // Comments
        s = s.replace(Regex("(?s)<!--.*?-->"), "")
        // Images → ![alt](src)
        s = s.replace(Regex("(?is)<img[^>]*?alt=\"([^\"]*)\"[^>]*?src=\"([^\"]+)\"[^>]*>")) {
            "![${it.groupValues[1]}](${it.groupValues[2]})"
        }
        s = s.replace(Regex("(?is)<img[^>]*?src=\"([^\"]+)\"[^>]*>")) {
            "![](${it.groupValues[1]})"
        }
        // Links → [text](href)
        s = s.replace(Regex("(?is)<a[^>]*?href=\"([^\"]+)\"[^>]*>(.*?)</a>")) {
            val href = it.groupValues[1]
            val text = stripInline(it.groupValues[2]).trim()
            if (text.isBlank()) "<$href>" else "[$text]($href)"
        }
        // Headings
        for (n in 1..6) {
            val hashes = "#".repeat(n)
            s = s.replace(Regex("(?is)<h$n[^>]*>(.*?)</h$n>")) {
                "\n\n$hashes ${stripInline(it.groupValues[1]).trim()}\n\n"
            }
        }
        // Blockquote
        s = s.replace(Regex("(?is)<blockquote[^>]*>(.*?)</blockquote>")) {
            it.groupValues[1].lines().joinToString("\n") { line -> "> ${line.trim()}" }
        }
        // Lists
        s = s.replace(Regex("(?is)<li[^>]*>(.*?)</li>")) {
            "- ${stripInline(it.groupValues[1]).trim()}\n"
        }
        s = s.replace(Regex("(?is)</?ul[^>]*>|</?ol[^>]*>"), "\n")
        // Code blocks
        s = s.replace(Regex("(?is)<pre[^>]*><code[^>]*>(.*?)</code></pre>")) {
            "\n```\n${it.groupValues[1]}\n```\n"
        }
        s = s.replace(Regex("(?is)<code[^>]*>(.*?)</code>")) {
            "`${stripInline(it.groupValues[1])}`"
        }
        // Inline emphasis
        s = s.replace(Regex("(?is)<(?:b|strong)[^>]*>(.*?)</(?:b|strong)>")) { "**${it.groupValues[1]}**" }
        s = s.replace(Regex("(?is)<(?:i|em)[^>]*>(.*?)</(?:i|em)>")) { "*${it.groupValues[1]}*" }
        // Paragraphs + breaks
        s = s.replace(Regex("(?is)<p[^>]*>(.*?)</p>")) {
            "\n\n${stripInline(it.groupValues[1]).trim()}\n\n"
        }
        s = s.replace(Regex("(?is)<br[^>]*/?>"), "  \n")
        s = s.replace(Regex("(?is)<hr[^>]*/?>"), "\n\n---\n\n")
        // Strip any remaining tags
        s = s.replace(Regex("(?is)<[^>]+>"), "")
        // Decode common HTML entities
        s = s.replace("&nbsp;", " ")
            .replace("&amp;", "&")
            .replace("&lt;", "<")
            .replace("&gt;", ">")
            .replace("&quot;", "\"")
            .replace("&#39;", "'")
            .replace("&apos;", "'")
        // Collapse 3+ blank lines into 2
        s = s.replace(Regex("\n{3,}"), "\n\n")
        return s.trim()
    }

    private fun stripInline(html: String): String {
        return html.replace(Regex("(?is)<[^>]+>"), "")
            .replace("&nbsp;", " ")
            .replace(Regex("\\s+"), " ")
    }

    /** Like ensureUnique but for arbitrary file extension. */
    private fun ensureUniqueAnyExt(
        cr: android.content.ContentResolver,
        treeUri: Uri,
        parentUri: Uri,
        baseName: String,
        extWithDot: String
    ): String {
        var candidate = "$baseName$extWithDot"
        val parentId = android.provider.DocumentsContract.getDocumentId(parentUri)
        val children = android.provider.DocumentsContract.buildChildDocumentsUriUsingTree(treeUri, parentId)
        val existing = HashSet<String>()
        cr.query(
            children,
            arrayOf(android.provider.DocumentsContract.Document.COLUMN_DISPLAY_NAME),
            null, null, null
        )?.use { cur ->
            while (cur.moveToNext()) cur.getString(0)?.let { existing.add(it.lowercase()) }
        }
        var n = 2
        while (existing.contains(candidate.lowercase())) {
            candidate = "$baseName-$n$extWithDot"
            n++
        }
        return candidate
    }

    /** Avoid overwriting an existing file by adding a numeric suffix. */
    private fun ensureUnique(
        cr: android.content.ContentResolver, treeUri: Uri, parentUri: Uri, baseName: String
    ): String {
        val base = baseName.removeSuffix(".md")
        var candidate = "$base.md"
        val parentId = android.provider.DocumentsContract.getDocumentId(parentUri)
        val children = android.provider.DocumentsContract.buildChildDocumentsUriUsingTree(treeUri, parentId)
        val existing = HashSet<String>()
        cr.query(
            children,
            arrayOf(android.provider.DocumentsContract.Document.COLUMN_DISPLAY_NAME),
            null, null, null
        )?.use { cur ->
            while (cur.moveToNext()) cur.getString(0)?.let { existing.add(it.lowercase()) }
        }
        var n = 2
        while (existing.contains(candidate.lowercase())) {
            candidate = "$base ($n).md"
            n++
        }
        return candidate
    }

    private fun sanitizeFilename(title: String): String {
        val cleaned = title
            .replace(Regex("[\\\\/:*?\"<>|\\r\\n]+"), " ")
            .replace(Regex("\\s+"), " ")
            .trim()
        val capped = if (cleaned.length > 80) cleaned.take(80).trim() else cleaned
        return capped.ifBlank { "Web import" }
    }

    fun libraryName(): String {
        val uri = libraryUri.value ?: return "Library"
        val seg = Uri.decode(uri).substringAfterLast(':', "").substringAfterLast('/')
        return if (seg.isBlank()) "Library" else seg
    }

    companion object {
        /** Focus-graph rendering caps to keep the view readable on a phone. */
        const val MAX_FIRST_RING = 16
        const val MAX_SECOND_RING = 30

        /**
         * v5.4.81cc — RRF's `k` parameter. 60 is the value from the
         * original Cormack/Clarke/Buettcher RRF paper and what every
         * modern hybrid-search implementation defaults to.
         */
        const val RRF_K = 60

        /** Parse top-level markdown headings (outside fenced code) into an outline. */
        fun parseOutline(content: String): List<OutlineItem> {
            val out = ArrayList<OutlineItem>()
            var inFence = false
            var fence = ""
            var idx = 0
            for (raw in content.lineSequence()) {
                val line = raw.trimEnd()
                val t = line.trimStart()
                if (inFence) {
                    if (t.startsWith(fence)) inFence = false
                    continue
                }
                if (t.startsWith("```") || t.startsWith("~~~")) {
                    inFence = true; fence = t.take(3); continue
                }
                val m = Regex("^(#{1,6})\\s+(.*)$").find(line) ?: continue
                val level = m.groupValues[1].length
                val title = cleanHeading(m.groupValues[2])
                if (title.isNotBlank()) out.add(OutlineItem(level, title, idx))
                idx++
            }
            return out
        }

        private fun cleanHeading(s: String): String {
            var x = s
            x = Regex("\\[([^\\]]+)\\]\\([^)]*\\)").replace(x) { it.groupValues[1] } // links -> text
            x = x.replace(Regex("[*_`~]"), "")
            x = Regex("<[^>]+>").replace(x, "")
            return x.trim()
        }
    }

    // ── Semantic search orchestration (v4.8 foundation) ─────────────────────

    /**
     * Download the .tflite embedding model on user opt-in. Idempotent — calling
     * twice is safe. Updates [modelDownloadProgress] as a fraction in `[0, 1]`.
     * On success, [modelAvailable] flips to true.
     */
    fun downloadEmbeddingModel() {
        if (_modelDownloadProgress.value != null) return  // already running
        viewModelScope.launch(Dispatchers.IO) {
            _modelDownloadProgress.value = 0f
            val result = embedder.downloadModel { p ->
                _modelDownloadProgress.value = p
            }
            _modelDownloadProgress.value = null
            _modelAvailable.value = embedder.isModelAvailable()
            if (result.isFailure) {
                // No-op for the UI — the user can retry. The Settings screen
                // can detect the still-unavailable state via modelAvailable.
            }
        }
    }

    /**
     * Embed every note in the library that doesn't yet have a current embedding
     * for the active model. Reports progress via [embeddingProgress] as a
     * `(embedded, total)` pair. The pass is resumable: if interrupted, the
     * next call picks up exactly where it left off because we re-query the
     * targets at the start.
     *
     * v4.8.1 — three changes to fix the "tapped Build embeddings but nothing
     * happens" stall on large libraries:
     *
     *   1. **Immediate UI feedback.** We set [embeddingProgress] to a
     *      "preparing" sentinel (0, 0) BEFORE running any database queries, so
     *      the status line flips to "⏳ Preparing…" the moment the user taps.
     *      Previously the user saw no change for the entire duration of the
     *      first DAO query.
     *
     *   2. **Lightweight projection.** We use `targetsNeedingEmbedding` which
     *      returns only `(id, lastModified)` pairs instead of full Note rows.
     *      For a 14k-note library that's a few hundred KB instead of 100+ MB
     *      of allocations. Note content is fetched one row at a time via
     *      `dao.byId(id)` inside the embed loop.
     *
     *   3. **Frequent progress updates.** Updates every embedding instead of
     *      every 5 — the throttling was making the UI look frozen on slower
     *      phones where each embedding takes ~1-2 seconds.
     *
     * Throttled internally — no need for the caller to debounce. Calling twice
     * concurrently is a no-op (the second call returns immediately).
     */
    /**
     * v4.15.0 — Kick off the embedding pass via the foreground service.
     *
     * Before v4.15.0 this ran inline in `viewModelScope` and died the
     * moment the user backgrounded the app or the OS killed the
     * activity. With `bge-large-en-v1.5` taking 3–4 hours on a 14k
     * library, that wasn't workable. Embedding now lives in
     * [com.tebogo.markvault.search.EmbeddingService], which:
     *   - shows a persistent progress notification
     *   - holds a partial wake lock so CPU doesn't sleep
     *   - writes progress to [EmbeddingProgressBus] which this VM's
     *     `embeddingProgress` flow delegates to
     *
     * The service's re-entry guard prevents two concurrent passes, so
     * calling this method while one is running is a no-op.
     */
    fun buildAllEmbeddings() {
        if (com.tebogo.markvault.search.EmbeddingProgressBus.isRunning.value) return
        if (!embedder.isModelAvailable()) return
        val app = getApplication<Application>()
        val intent = android.content.Intent(
            app, com.tebogo.markvault.search.EmbeddingService::class.java
        )
        // startForegroundService is required from background contexts on
        // Android 8+; ContextCompat handles the version branching.
        androidx.core.content.ContextCompat.startForegroundService(app, intent)
    }

    /**
     * v4.15.0 — Stop a running embedding pass. Used by:
     *   - explicit "Cancel" buttons in the Settings UI (future)
     *   - [clearAllEmbeddings], which needs to stop writes before truncating the table
     */
    fun stopEmbeddingService() {
        val app = getApplication<Application>()
        val intent = android.content.Intent(
            app, com.tebogo.markvault.search.EmbeddingService::class.java
        )
        runCatching { app.stopService(intent) }
    }

    /** Wipe every embedding row. Useful when switching models or freeing space. */
    fun clearAllEmbeddings() {
        // v4.15.0 — stop the foreground service first, otherwise it would
        // keep upserting into the same table we're about to truncate.
        stopEmbeddingService()
        viewModelScope.launch(Dispatchers.IO) {
            runCatching { dao.clearAllEmbeddings() }
            _embeddingCount.value = 0
            invalidateSemanticIndex()
        }
    }

    // ── v4.21.0 — On-device chat (RAG) actions ──────────────────────────────
    //
    // The Settings UI calls these to install / delete the chat model and
    // flip the three behaviour toggles. The download itself runs in a
    // foreground service so it survives backgrounding and screen-off; the
    // VM just dispatches the intent and observes the progress bus.

    /**
     * Start downloading the active chat model in the foreground service.
     * Mirrors [buildAllEmbeddings]. Re-entry guard: if a download is
     * already running, this is a no-op.
     */
    fun downloadChatModel() {
        if (com.tebogo.markvault.llm.ChatDownloadProgressBus.isRunning.value) return
        val app = getApplication<Application>()
        val intent = android.content.Intent(
            app, com.tebogo.markvault.llm.ChatModelDownloadService::class.java
        )
        androidx.core.content.ContextCompat.startForegroundService(app, intent)
        // Optimistically refresh the installed flag after the service
        // (eventually) completes. The bus's isRunning flow drives the
        // re-check below via the init-time observer.
    }

    /**
     * Pause the in-progress download. The .part file is kept so the
     * next [downloadChatModel] call auto-resumes via HTTP Range.
     */
    fun pauseChatModelDownload() {
        val app = getApplication<Application>()
        val intent = android.content.Intent(
            app, com.tebogo.markvault.llm.ChatModelDownloadService::class.java
        ).setAction(com.tebogo.markvault.llm.ChatModelDownloadService.ACTION_PAUSE)
        runCatching { app.startService(intent) }
    }

    /**
     * Cancel the download and discard the .part file so the next
     * "Install" starts fresh. Works whether the service is running
     * (active download) or stopped (paused state).
     */
    fun cancelChatModelDownload() {
        val app = getApplication<Application>()
        // Stop the service if it is currently running.
        runCatching {
            app.stopService(
                android.content.Intent(
                    app, com.tebogo.markvault.llm.ChatModelDownloadService::class.java
                )
            )
        }
        // Reset bus (clears paused state too).
        com.tebogo.markvault.llm.ChatDownloadProgressBus.idle()
        // Delete the .part file so next install starts from zero.
        viewModelScope.launch(kotlinx.coroutines.Dispatchers.IO) {
            val activeId = runCatching {
                com.tebogo.markvault.data.Prefs(app).chatActiveModelId.first()
            }.getOrDefault(com.tebogo.markvault.llm.ChatModelCatalog.default.id)
            val descriptor = com.tebogo.markvault.llm.ChatModelCatalog.byId(activeId)
                ?: com.tebogo.markvault.llm.ChatModelCatalog.default
            com.tebogo.markvault.llm.ChatModelDownloader.deletePart(app, descriptor)
        }
    }

    /** Kept for internal callers (deleteChatModel). */
    private fun stopChatModelDownload() = cancelChatModelDownload()

    /**
     * Delete the installed chat model file. Frees ~530 MB of storage.
     * Stops any in-flight download first (we don't want to delete a
     * partially-written file out from under the writer).
     */
    fun deleteChatModel() {
        stopChatModelDownload()
        viewModelScope.launch(Dispatchers.IO) {
            val app = getApplication<Application>()
            // v5.4.73: delete whichever model is currently selected, not
            // always the default. Same runCatching guard as above.
            val activeId = runCatching { chatActiveModelId.value }.getOrNull()
            val descriptor = (if (activeId != null)
                com.tebogo.markvault.llm.ChatModelCatalog.byId(activeId)
            else null) ?: com.tebogo.markvault.llm.ChatModelCatalog.default
            com.tebogo.markvault.llm.ChatModelDownloader.delete(app, descriptor)
            _chatModelInstalled.value = false
        }
    }

    /** Dismiss the last download-error message from the bus. */
    fun clearChatDownloadError() {
        com.tebogo.markvault.llm.ChatDownloadProgressBus.clearError()
    }

    /** Toggle: "opt_in" or "auto_prompt". v4.21.0 stores only — no behaviour change yet. */
    fun setChatInstallFlowPref(v: String) {
        viewModelScope.launch { prefs.setChatInstallFlow(v) }
    }

    /** Toggle: "own_screen" or "in_search". v4.21.0 stores only — no behaviour change yet. */
    fun setChatLocationPref(v: String) {
        viewModelScope.launch { prefs.setChatLocation(v) }
    }

    /** Toggle: "fresh_per_q" or "multi_turn". v4.21.0 stores only — no behaviour change yet. */
    fun setChatHistoryModePref(v: String) {
        viewModelScope.launch { prefs.setChatHistoryMode(v) }
    }

    /** Toggle: "on_open", "preload", or "on_first_q". v4.21.2 stores only — Stage 5b consumes it. */
    fun setChatModelLoadModePref(v: String) {
        viewModelScope.launch { prefs.setChatModelLoadMode(v) }
    }

    /**
     * Internal: observe the chat download bus and re-check installed
     * status whenever a download finishes. Called from the init block.
     */
    private fun observeChatDownloadCompletion() {
        viewModelScope.launch {
            com.tebogo.markvault.llm.ChatDownloadProgressBus.isRunning.collect { running ->
                if (!running) {
                    // Re-check the file. If a download just completed
                    // successfully, this flips installed → true.
                    _chatModelInstalled.value = currentChatModelInstalled()
                }
            }
        }
    }

    // ── v4.22.0 — On-device chat (RAG) runtime state ────────────────────────
    //
    // Stage 5b wires the chat UI into the engine plumbing built in 5a.
    // Three moving parts:
    //   1. messages — the conversation, with one currently-streaming
    //      assistant message during generation.
    //   2. isModelLoading / isGenerating — independent busy flags. The UI
    //      uses them to disable the input field and show a loading banner.
    //   3. modelLoadError — surfaces a friendly message when load fails
    //      (model not installed, file corrupted, OOM, etc.).

    enum class ChatRole { USER, ASSISTANT }

    /** One message in the chat conversation. */
    data class ChatMessage(
        val id: String,
        val role: ChatRole,
        val content: String,
        val citations: List<com.tebogo.markvault.llm.RagCitation> = emptyList(),
        val isStreaming: Boolean = false,
        val isError: Boolean = false
    )

    private val _chatMessages = MutableStateFlow<List<ChatMessage>>(emptyList())
    val chatMessages: StateFlow<List<ChatMessage>> = _chatMessages

    private val _chatIsModelLoading = MutableStateFlow(false)
    val chatIsModelLoading: StateFlow<Boolean> = _chatIsModelLoading

    private val _chatIsGenerating = MutableStateFlow(false)
    val chatIsGenerating: StateFlow<Boolean> = _chatIsGenerating

    private val _chatModelLoadError = MutableStateFlow<String?>(null)
    val chatModelLoadError: StateFlow<String?> = _chatModelLoadError

    private var chatGenerationJob: kotlinx.coroutines.Job? = null

    /**
     * Ensure the LLM is loaded into RAM, idempotent. Reads the active
     * model from [com.tebogo.markvault.llm.ChatModelCatalog] and the
     * file from the app's filesDir.
     *
     * Sets [chatModelLoadError] on failure; the UI shows it as a banner.
     */
    suspend fun ensureChatModelLoaded() {
        if (com.tebogo.markvault.llm.LlmManager.isLoaded) return
        if (_chatIsModelLoading.value) return
        val app = getApplication<Application>()
        val descriptor = com.tebogo.markvault.llm.ChatModelCatalog.default
        val file = java.io.File(app.filesDir, descriptor.localFilename)
        if (!file.exists() ||
            file.length() <= com.tebogo.markvault.llm.ChatModelCatalog.MIN_PLAUSIBLE_MODEL_BYTES
        ) {
            _chatModelLoadError.value =
                "Chat model not installed. Open Settings → On-device chat to install."
            return
        }
        _chatIsModelLoading.value = true
        _chatModelLoadError.value = null
        try {
            com.tebogo.markvault.llm.LlmManager.load(file.absolutePath)
        } catch (e: Throwable) {
            _chatModelLoadError.value =
                e.message ?: "Failed to load chat model into memory."
        } finally {
            _chatIsModelLoading.value = false
        }
    }

    /**
     * Send a user message and generate a streaming assistant reply.
     *
     * Pipeline:
     *   1. Append user message + empty streaming placeholder to messages
     *   2. Ensure model loaded (handles "on_first_q" mode lazily)
     *   3. RagPromptBuilder.build → prompt + citations
     *   4. Update placeholder with citations
     *   5. LlmManager.generate → collect tokens, update content
     *   6. Mark streaming complete
     *
     * If anything throws, the placeholder becomes an error message.
     * If the user cancels via [stopChatGeneration], the partial output
     * stays in place with a "[stopped]" suffix.
     */
    fun sendChatMessage(text: String) {
        val trimmed = text.trim()
        if (trimmed.isEmpty()) return
        if (_chatIsGenerating.value) return

        val userMsg = ChatMessage(
            id = java.util.UUID.randomUUID().toString(),
            role = ChatRole.USER,
            content = trimmed
        )
        val placeholder = ChatMessage(
            id = java.util.UUID.randomUUID().toString(),
            role = ChatRole.ASSISTANT,
            content = "",
            isStreaming = true
        )
        _chatMessages.value = _chatMessages.value + userMsg + placeholder
        _chatIsGenerating.value = true

        chatGenerationJob = viewModelScope.launch(Dispatchers.IO) {
            try {
                // Handle "on_first_q" load mode: model not yet loaded.
                if (!com.tebogo.markvault.llm.LlmManager.isLoaded) {
                    ensureChatModelLoaded()
                    if (!com.tebogo.markvault.llm.LlmManager.isLoaded) {
                        // ensureChatModelLoaded set the error; surface it.
                        setChatAssistantError(
                            placeholder.id,
                            _chatModelLoadError.value ?: "Model not loaded"
                        )
                        return@launch
                    }
                }

                // Build the RAG prompt.
                val rag = com.tebogo.markvault.llm.RagPromptBuilder.build(
                    userQuery = trimmed,
                    topK = 6,
                    semanticSearch = { q, k -> semanticSearch(q, k) },
                    dao = dao,
                    embedder = embedder
                )

                // Update the placeholder with citations so the chips
                // appear immediately, before any tokens stream in.
                _chatMessages.value = _chatMessages.value.map { msg ->
                    if (msg.id == placeholder.id) {
                        msg.copy(citations = rag.citations)
                    } else msg
                }

                // Stream tokens into the placeholder's content.
                val sb = StringBuilder()
                com.tebogo.markvault.llm.LlmManager.generate(rag.prompt).collect { chunk ->
                    sb.append(chunk)
                    val text = sb.toString()
                    _chatMessages.value = _chatMessages.value.map { msg ->
                        if (msg.id == placeholder.id) msg.copy(content = text)
                        else msg
                    }
                }

                // Mark streaming complete.
                _chatMessages.value = _chatMessages.value.map { msg ->
                    if (msg.id == placeholder.id) msg.copy(isStreaming = false)
                    else msg
                }
            } catch (ce: kotlinx.coroutines.CancellationException) {
                // User-initiated stop — keep partial output.
                _chatMessages.value = _chatMessages.value.map { msg ->
                    if (msg.id == placeholder.id)
                        msg.copy(isStreaming = false,
                            content = msg.content + "  [stopped]")
                    else msg
                }
                throw ce  // re-throw so coroutine cancellation propagates
            } catch (e: Throwable) {
                setChatAssistantError(placeholder.id,
                    e.message ?: "Generation failed unexpectedly")
            } finally {
                _chatIsGenerating.value = false
            }
        }
    }

    /** Mark a particular assistant message as an error. */
    private fun setChatAssistantError(messageId: String, errorMsg: String) {
        _chatMessages.value = _chatMessages.value.map { msg ->
            if (msg.id == messageId) {
                msg.copy(
                    content = "⚠️  $errorMsg",
                    isStreaming = false,
                    isError = true
                )
            } else msg
        }
    }

    /** Cancel the in-flight chat generation, if any. */
    fun stopChatGeneration() {
        chatGenerationJob?.cancel()
        chatGenerationJob = null
    }

    /** Clear all chat messages. Cancels any in-flight generation first. */
    fun clearChatMessages() {
        stopChatGeneration()
        _chatMessages.value = emptyList()
    }

    /** Dismiss a stale load-error banner. */
    fun clearChatModelLoadError() {
        _chatModelLoadError.value = null
    }

    /** Release the LLM from memory. Called on chat-screen dispose. */
    fun unloadChatModel() {
        viewModelScope.launch(Dispatchers.IO) {
            com.tebogo.markvault.llm.LlmManager.unload()
        }
    }

    /**
     * v4.22.1 — Trigger a "Summarise this article" generation for the
     * note with [noteId]. Called from the reader screens (MD / HTML /
     * PDF) when the user taps the ✨ Summarise button.
     *
     * Adds a user message ("Summarise: <title>") and a streaming
     * assistant message to the chat conversation, then starts
     * generating. The caller (the reader screen) is responsible for
     * navigating to the chat screen so the user can watch it stream.
     *
     * For PDF notes, aggregates extracted page text via
     * [dao.loadPdfPageText]. For MD / HTML, uses the note's raw
     * [Note.content] field directly.
     */
    fun summarizeNote(noteId: Long, fileType: String = "md") {
        if (_chatIsGenerating.value) return
        chatGenerationJob = viewModelScope.launch(Dispatchers.IO) {
            val note = runCatching { dao.byId(noteId) }.getOrNull() ?: return@launch

            val content = when (fileType.lowercase()) {
                "pdf" -> {
                    val pages = runCatching { dao.loadPdfPageText(noteId) }.getOrNull()
                    if (pages.isNullOrEmpty()) {
                        // The PDF text-extraction pass hasn't run yet for this
                        // file. We still produce a (very short) summary based
                        // on title + any note metadata content.
                        note.content + "\n\n[Note: this PDF has no extracted " +
                            "text yet. Open it in the PDF reader once to " +
                            "trigger extraction, then summarise again.]"
                    } else {
                        pages.joinToString("\n\n") { p ->
                            "[Page ${p.pageIndex + 1}]\n${p.text}"
                        }
                    }
                }
                else -> note.content
            }

            val rag = com.tebogo.markvault.llm.RagPromptBuilder.buildSummarize(
                noteId = noteId,
                title = note.title,
                content = content
            )
            streamChatGeneration(
                displayText = "Summarise: ${note.title}",
                prompt = rag.prompt,
                citations = rag.citations
            )
        }
    }

    /**
     * Shared helper: appends a user message + streaming assistant
     * placeholder to [_chatMessages], ensures the LLM is loaded, then
     * collects tokens from [LlmManager.generate] into the placeholder.
     *
     * Used by [summarizeNote]. [sendChatMessage] also follows this same
     * shape inline (not yet refactored to call this — keeping that path
     * unchanged to minimise risk of regressing already-working chat).
     */
    private suspend fun streamChatGeneration(
        displayText: String,
        prompt: String,
        citations: List<com.tebogo.markvault.llm.RagCitation>
    ) {
        val userMsg = ChatMessage(
            id = java.util.UUID.randomUUID().toString(),
            role = ChatRole.USER,
            content = displayText
        )
        val placeholder = ChatMessage(
            id = java.util.UUID.randomUUID().toString(),
            role = ChatRole.ASSISTANT,
            content = "",
            isStreaming = true,
            citations = citations
        )
        _chatMessages.value = _chatMessages.value + userMsg + placeholder
        _chatIsGenerating.value = true

        try {
            if (!com.tebogo.markvault.llm.LlmManager.isLoaded) {
                ensureChatModelLoaded()
                if (!com.tebogo.markvault.llm.LlmManager.isLoaded) {
                    setChatAssistantError(
                        placeholder.id,
                        _chatModelLoadError.value ?: "Model not loaded"
                    )
                    return
                }
            }
            val sb = StringBuilder()
            com.tebogo.markvault.llm.LlmManager.generate(prompt).collect { chunk ->
                sb.append(chunk)
                val text = sb.toString()
                _chatMessages.value = _chatMessages.value.map { msg ->
                    if (msg.id == placeholder.id) msg.copy(content = text) else msg
                }
            }
            _chatMessages.value = _chatMessages.value.map { msg ->
                if (msg.id == placeholder.id) msg.copy(isStreaming = false) else msg
            }
        } catch (ce: kotlinx.coroutines.CancellationException) {
            _chatMessages.value = _chatMessages.value.map { msg ->
                if (msg.id == placeholder.id)
                    msg.copy(isStreaming = false,
                        content = msg.content + "  [stopped]")
                else msg
            }
            throw ce
        } catch (e: Throwable) {
            setChatAssistantError(placeholder.id,
                e.message ?: "Generation failed unexpectedly")
        } finally {
            _chatIsGenerating.value = false
        }
    }

    /**
     * Preload the LLM at app start when the user has selected
     * "preload" mode. Called from init after a short delay so the
     * app-launch path isn't slowed by a ~5–10s model init.
     */
    private fun maybePreloadChatModel() {
        viewModelScope.launch(Dispatchers.IO) {
            val mode = runCatching { prefs.chatModelLoadMode.first() }
                .getOrDefault("on_open")
            if (mode != "preload") return@launch
            if (!currentChatModelInstalled()) return@launch
            kotlinx.coroutines.delay(2000)   // let UI finish settling
            ensureChatModelLoaded()
        }
    }

    // ── v4.9.0 — Semantic search toggles & model management ─────────────────

    /** Flip the master semantic-search switch. Effect is immediate on next query. */
    fun setSemanticEnabled(enabled: Boolean) {
        viewModelScope.launch { prefs.setSemanticEnabled(enabled) }
    }

    /**
     * v5.4.76cc — Flip the master LLM multi-query-retrieval switch.
     * Effect is immediate on the next *submitted* search; live-typing
     * during a session never triggers the model.
     */
    fun setAiLlmSearchEnabled(enabled: Boolean) {
        viewModelScope.launch { prefs.setAiLlmSearchEnabled(enabled) }
    }

    /**
     * v5.4.79cc — Flip the LLM memory-safety belt. When on, the
     * expander refuses to load a model that wouldn't fit in the
     * current free-RAM headroom and uses a tighter 5-second generate
     * timeout. Effect is immediate on the next submitted search.
     */
    fun setMemoryOptimizedLlm(enabled: Boolean) {
        viewModelScope.launch { prefs.setMemoryOptimizedLlm(enabled) }
    }

    /**
     * v5.4.80cc — Slider-driven paraphrase count. Coerced 0..10 on
     * write. Effect is immediate on the next submitted search.
     */
    fun setLlmParaphraseCount(count: Int) {
        viewModelScope.launch { prefs.setLlmParaphraseCount(count) }
    }

    /**
     * v5.4.79cc — Pick which catalog model the LLM query expander uses.
     * Writes into [Prefs.chatActiveModelId]; the expander's
     * `descriptorProvider` lambda reads this on the next submit, so the
     * change is effective immediately without restart. The Settings
     * screen and the download UI both read the same preference, so the
     * chosen model becomes the one whose install / progress / delete
     * buttons are shown.
     */
    fun setChatActiveModelId(id: String) {
        viewModelScope.launch { prefs.setChatActiveModelId(id) }
    }

    /** Whether to automatically check for newer models when the app launches. */
    fun setAutoCheckModelUpdates(enabled: Boolean) {
        viewModelScope.launch { prefs.setAutoCheckModelUpdates(enabled) }
    }

    /**
     * Switch to a different model in the catalog. The init-block listener
     * picks up the preference change, closes the current embedder, builds a
     * fresh one for the new descriptor, and refreshes the model-availability
     * + embedding-count state flows. The user will likely need to:
     *
     *   1. Download the new model (its file isn't on disk yet)
     *   2. Build embeddings (the DB rows are keyed by model id, so the new
     *      model has zero embeddings to start)
     *
     * Both are surfaced via the existing UI in Settings.
     *
     * v4.9.1 — also rejects models marked `enabled = false`, which is how the
     * catalog surfaces "coming soon" entries (e.g. MiniLM before its ONNX
     * backend lands). The UI greys those rows out, but this guard is the
     * authoritative check.
     */
    fun setActiveModelId(id: String) {
        val target = com.tebogo.markvault.search.ModelCatalog.byId(id) ?: return
        if (!target.enabled) return
        viewModelScope.launch { prefs.setActiveModelId(id) }
    }

    /**
     * v4.9.1 — Single-step install: download the active model's file, then
     * automatically start the embedding pass once the download finishes.
     * Combines the two previously-separate buttons into one user action.
     *
     * No-op when the model is already downloaded AND embeddings exist for it
     * (i.e. nothing to install). When the model is downloaded but no
     * embeddings exist yet, this method skips the download and runs only the
     * embedding pass — the same behaviour the standalone "Build embeddings"
     * button would have provided.
     *
     * Safe to call while another install is in progress: the download path
     * is idempotent (returns immediately if the file is already valid) and
     * the embed path guards against re-entry via [EmbeddingProgressBus].isRunning.
     */
    fun installModel() {
        viewModelScope.launch(Dispatchers.IO) {
            // Phase 1: download (no-op if already present).
            if (!embedder.isModelAvailable()) {
                val result = embedder.downloadModel { p ->
                    _modelDownloadProgress.value = p
                }
                _modelDownloadProgress.value = null
                _modelAvailable.value = embedder.isModelAvailable()
                if (result.isFailure || !embedder.isModelAvailable()) return@launch
            }
            // Phase 2: embed any notes that need it. buildAllEmbeddings
            // launches its own coroutine on viewModelScope; calling it here
            // is fine — it has its own re-entry guard.
            buildAllEmbeddings()
        }
    }

    /**
     * Check whether the in-app catalog lists any model the user could switch
     * to. Honest scope: this is a LOCAL check against the bundled catalog —
     * there's no remote manifest endpoint yet. Future iterations may merge in
     * results from a remote JSON manifest; for now, new models arrive via
     * app updates and this method surfaces them once installed.
     *
     * The result is written to [modelUpdateStatus] so the UI can render it
     * below the button without any string-passing coupling.
     */
    fun checkForModelUpdates() {
        viewModelScope.launch {
            _modelUpdateStatus.value = "\u23F3 Checking\u2026"
            kotlinx.coroutines.delay(400)  // tiny pause so the user sees feedback
            val activeId = embedder.descriptor.id
            val otherModels = com.tebogo.markvault.search.ModelCatalog.all
                .filter { it.id != activeId }
            _modelUpdateStatus.value = if (otherModels.isEmpty()) {
                "\u2705 Up to date. \"${embedder.descriptor.displayName}\" is the latest available model."
            } else {
                val names = otherModels.joinToString { it.displayName }
                "\uD83D\uDCE6 Other model(s) available: $names"
            }
        }
    }

    /**
     * v5.4.0 — Best-effort memory reclamation. Unconditional — releases
     * even if autoFreeMemory is OFF. Use this for the Settings "Free
     * memory now" button.
     *
     * Releases the three heaviest memory holders without losing user
     * data:
     *   • Embedder ONNX session  (~280 MB native, BGE-large)
     *   • Reranker ONNX session  (~150 MB native, MS-MARCO MiniLM-L-12)
     *   • In-heap semantic index (~58 MB on a 14k-note library)
     *
     * All three are recreated lazily on the next search, so the only
     * cost of calling this is a slightly slower first-query after the
     * call. Total freed: ~490 MB on a fully-warm app.
     */
    fun freeMemory() {
        runCatching { embedder.close() }
        runCatching { reranker.unload() }
        invalidateSemanticIndex()
        webTabThumbnails.clear()
        runCatching { System.gc() }
    }

    /**
     * v5.4.1 — Auto-release entry point, called by [MarkVaultApp] when
     * the OS signals memory pressure. Respects the [autoFreeMemory]
     * preference so a user investigating crashes can disable the
     * auto-release behaviour.
     */
    fun freeMemoryAuto() {
        if (autoFreeMemory.value) freeMemory()
    }

    override fun onCleared() {
        super.onCleared()
        runCatching { embedder.close() }
        // v4.13.0 — release every persistent WebView so we don't hold native
        // resources after the VM is gone.
        destroyAllWebViewSessions()
    }
}

/** Direction of a wikilink relative to the focused note. */
enum class LinkDir { OUTGOING, INCOMING, BOTH }

/** A 1°-ring neighbour: a directly linked note + which way the link goes. */
data class GraphNeighbour(val note: com.tebogo.markvault.data.LinkedNote, val dir: LinkDir)

/** A 2°-ring node: linked via [viaNoteId] which is one of the 1°-ring nodes. */
data class GraphEdge(val note: com.tebogo.markvault.data.LinkedNote, val viaNoteId: Long)

/** Result of expanding a focus note out to two degrees of connection. */
data class FocusGraph(
    val center: com.tebogo.markvault.data.LinkedNote,
    val firstRing: List<GraphNeighbour>,
    val secondRing: List<GraphEdge>,
    /** How many 1°-ring neighbours we found in total — UI can show "+N more" if greater than [firstRing.size]. */
    val firstRingTotal: Int,
    val secondRingTotal: Int
)

/** One persisted recent-search click: the query the user typed, and the note they ended up opening. */
data class RecentSearch(
    val query: String,
    val noteId: Long,
    val title: String,
    val relPath: String,
    val ts: Long
)

/**
 * Tab-separated, line-per-entry, with `\u0001` as field separator (any char that's vanishingly
 * unlikely in titles). Lightweight enough that we don't need a JSON library.
 */
private const val FIELD_SEP = "\u0001"

internal fun encodeRecents(list: List<RecentSearch>): String =
    list.joinToString("\n") { r ->
        // Defensively scrub any stray separator chars from user-controlled fields
        listOf(
            r.query.replace("\n", " ").replace(FIELD_SEP, " "),
            r.noteId.toString(),
            r.title.replace("\n", " ").replace(FIELD_SEP, " "),
            r.relPath.replace("\n", " ").replace(FIELD_SEP, " "),
            r.ts.toString()
        ).joinToString(FIELD_SEP)
    }

internal fun decodeRecents(raw: String): List<RecentSearch> {
    if (raw.isBlank()) return emptyList()
    return raw.split("\n").mapNotNull { line ->
        val parts = line.split(FIELD_SEP)
        if (parts.size < 5) return@mapNotNull null
        val id = parts[1].toLongOrNull() ?: return@mapNotNull null
        val ts = parts[4].toLongOrNull() ?: return@mapNotNull null
        RecentSearch(query = parts[0], noteId = id, title = parts[2], relPath = parts[3], ts = ts)
    }
}
