package com.tebogo.markvault

import android.app.Application
import android.content.Intent
import android.net.Uri
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.tebogo.markvault.data.IndexProgress
import com.tebogo.markvault.data.Indexer
import com.tebogo.markvault.data.LinkedNote
import com.tebogo.markvault.data.Note
import com.tebogo.markvault.data.NoteMeta
import com.tebogo.markvault.data.NoteTopic
import com.tebogo.markvault.data.Prefs
import com.tebogo.markvault.data.RecentNote
import com.tebogo.markvault.data.SearchHit
import com.tebogo.markvault.data.TopicCard
import com.tebogo.markvault.data.Topics
import com.tebogo.markvault.data.VaultDb
import com.tebogo.markvault.data.Wikilinks
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.FlowPreview
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.debounce
import kotlinx.coroutines.flow.distinctUntilChanged
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.flowOn
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

enum class SearchMode { TITLES, CONTENT }

data class TabInfo(val id: Long, val title: String)
data class OutlineItem(val level: Int, val title: String, val index: Int)

@OptIn(FlowPreview::class)
class AppViewModel(app: Application) : AndroidViewModel(app) {

    private val db = VaultDb.get(app)
    private val dao = db.notes()
    private val prefs = Prefs(app)
    private val indexer = Indexer(app, dao)

    val libraryUri: StateFlow<String?> =
        prefs.libraryUri.stateIn(viewModelScope, SharingStarted.Eagerly, null)
    val fontScale: StateFlow<Float> =
        prefs.fontScale.stateIn(viewModelScope, SharingStarted.Eagerly, 1.0f)
    val theme: StateFlow<String> =
        prefs.theme.stateIn(viewModelScope, SharingStarted.Eagerly, "dark")

    private val _progress = MutableStateFlow(IndexProgress())
    val progress: StateFlow<IndexProgress> = _progress

    private val _notes = MutableStateFlow<List<NoteMeta>>(emptyList())
    val notes: StateFlow<List<NoteMeta>> = _notes

    private val _recent = MutableStateFlow<List<RecentNote>>(emptyList())
    val recent: StateFlow<List<RecentNote>> = _recent

    private val _topics = MutableStateFlow<List<TopicCard>>(emptyList())
    val topics: StateFlow<List<TopicCard>> = _topics

    /** Notes added to the library since the last manual re-index (empty until first reindex). */
    private val _newNotes = MutableStateFlow<List<NoteMeta>>(emptyList())
    val newNotes: StateFlow<List<NoteMeta>> = _newNotes

    /** IDs of notes the user has starred as favourites. */
    private val _favouriteIds = MutableStateFlow<Set<Long>>(emptySet())
    val favouriteIds: StateFlow<Set<Long>> = _favouriteIds

    /** Starred notes as NoteMeta list for the home screen. */
    private val _favouriteNotes = MutableStateFlow<List<NoteMeta>>(emptyList())
    val favouriteNotes: StateFlow<List<NoteMeta>> = _favouriteNotes

    // ---- Open article tabs ----
    private val _tabs = MutableStateFlow<List<TabInfo>>(emptyList())
    val tabs: StateFlow<List<TabInfo>> = _tabs
    private val _activeTab = MutableStateFlow<Long?>(null)
    val activeTab: StateFlow<Long?> = _activeTab
    private val maxTabs = 8

    /**
     * In-Reader navigation history (tab IDs visited, oldest → newest).
     * Lets the system Back button return through previously-viewed tabs (e.g. after tapping a
     * backlink) instead of immediately exiting the Reader.
     */
    private val _tabHistory = MutableStateFlow<List<Long>>(emptyList())
    val tabHistory: StateFlow<List<Long>> = _tabHistory
    private val maxHistory = 50

    private fun pushHistory(id: Long) {
        val cur = _tabHistory.value
        if (cur.lastOrNull() == id) return // dedupe consecutive
        val updated = (cur + id)
        _tabHistory.value = if (updated.size > maxHistory) updated.takeLast(maxHistory) else updated
    }

    /**
     * Pop the current tab off history and activate the previous one.
     * Returns true if we moved back inside the Reader; false if there's nowhere to go back to
     * (caller should let the system Back press exit the Reader).
     */
    fun goBackInTabs(): Boolean {
        val cur = _tabHistory.value
        if (cur.size < 2) return false
        val updated = cur.dropLast(1)
        _tabHistory.value = updated
        _activeTab.value = updated.last()
        return true
    }

    /** Clear the tab visit history. Called when the Reader exits to home / search etc. */
    fun clearTabHistory() { _tabHistory.value = emptyList() }

    val query = MutableStateFlow("")
    val mode = MutableStateFlow(SearchMode.CONTENT)

    val results: StateFlow<List<SearchHit>> =
        combine(query.debounce(220).map { it.trim() }.distinctUntilChanged(), mode) { q, m -> q to m }
            .map { (q, m) ->
                when {
                    q.length < 2 -> emptyList()
                    m == SearchMode.TITLES -> runCatching {
                        dao.searchTitles("%$q%").map { SearchHit(it.id, it.relPath, it.title, "") }
                    }.getOrElse { emptyList() }
                    else -> runCatching { dao.search(Topics.expandQuery(q)) }.getOrElse { emptyList() }
                }
            }.flowOn(Dispatchers.IO)
            .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    /** Topic cards whose vocabulary matches the current query (shown above results). */
    val topicMatches: StateFlow<List<TopicCard>> =
        combine(query.debounce(220).map { it.trim() }.distinctUntilChanged(), _topics) { q, topics ->
            if (q.length < 2) emptyList()
            else {
                val keys = Topics.matchQuery(q).toSet()
                topics.filter { it.key in keys }
            }
        }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    init {
        viewModelScope.launch {
            refreshNotes()
            refreshRecent()
            refreshTopics()
            refreshFavourites()
            val uri = prefs.libraryUri.first()
            val storedTopicVersion = prefs.topicVersion.first()
            when {
                uri != null && _notes.value.isEmpty() -> startSync(uri)
                _notes.value.isNotEmpty() && storedTopicVersion != Topics.VERSION -> {
                    reclassifyTopics()
                    prefs.setTopicVersion(Topics.VERSION)
                }
            }
        }
    }

    fun setLibrary(uri: Uri) {
        val app = getApplication<Application>()
        try {
            app.contentResolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION)
        } catch (_: Exception) {
        }
        viewModelScope.launch(Dispatchers.IO) {
            dao.clearAll()
            runCatching { dao.clearTopics() }
            runCatching { dao.clearLinks() }
            prefs.setLibraryUri(uri.toString())
            _tabs.value = emptyList(); _activeTab.value = null
            _newNotes.value = emptyList()
            refreshNotes(); refreshRecent(); refreshTopics(); refreshFavourites()
            startSync(uri.toString(), trackNewNotes = false)
        }
    }

    fun reindex() {
        val uri = libraryUri.value ?: return
        startSync(uri, trackNewNotes = true)
    }

    private fun startSync(uri: String, trackNewNotes: Boolean = false) {
        if (_progress.value.running) return
        _progress.value = IndexProgress(true, "Starting\u2026", 0, 0)
        viewModelScope.launch(Dispatchers.IO) {
            try {
                val beforeRelPaths = if (trackNewNotes)
                    runCatching { dao.allMeta().map { it.relPath }.toSet() }.getOrElse { emptySet() }
                else emptySet()
                indexer.sync(uri) { p -> _progress.value = p }
                if (trackNewNotes) {
                    val afterAll = runCatching { dao.allMeta() }.getOrElse { emptyList() }
                    _newNotes.value = afterAll.filter { it.relPath !in beforeRelPaths }.take(30)
                }
            } catch (e: Exception) {
                _progress.value = IndexProgress(false, "Error: ${e.message}", 0, 0)
            }
            refreshNotes(); refreshRecent(); refreshTopics(); refreshFavourites()
            runCatching { prefs.setTopicVersion(Topics.VERSION) }
        }
    }

    /** Re-tag every already-indexed note using the current lexicon (no file re-scan). */
    private suspend fun reclassifyTopics() {
        val total = runCatching { dao.countNotes() }.getOrElse { 0 }
        if (total == 0) return
        _progress.value = IndexProgress(true, "Updating topics\u2026", 0, total)
        runCatching { dao.clearTopics() }
        val pageSize = 300
        var offset = 0
        var done = 0
        while (offset < total) {
            val page = runCatching { dao.notesTextPage(pageSize, offset) }.getOrElse { emptyList() }
            if (page.isEmpty()) break
            for (nt in page) {
                val topics = runCatching { Topics.classify(nt.title, nt.content) }.getOrElse { emptyList() }
                if (topics.isNotEmpty()) {
                    runCatching { dao.insertTopics(topics.map { NoteTopic(nt.id, it.first, it.second) }) }
                }
                done++
            }
            offset += pageSize
            _progress.value = IndexProgress(true, "Updating topics\u2026", done, total)
        }
        _progress.value = IndexProgress(false, "Done", total, total)
        refreshTopics()
    }

    private suspend fun refreshNotes() {
        _notes.value = runCatching { dao.allMeta() }.getOrElse { emptyList() }
    }

    private suspend fun refreshRecent() {
        _recent.value = runCatching { dao.recentNotes() }.getOrElse { emptyList() }
    }

    private suspend fun refreshTopics() {
        val counts = runCatching { dao.topicCounts() }.getOrElse { emptyList() }
            .associate { it.topic to it.cnt }
        _topics.value = Topics.ALL.mapNotNull { d ->
            val c = counts[d.key] ?: 0
            if (c > 0) TopicCard(d.key, d.emoji, d.label, c) else null
        }.sortedByDescending { it.count }
    }

    private suspend fun refreshFavourites() {
        val favs = runCatching { dao.favouriteNotes() }.getOrElse { emptyList() }
        _favouriteIds.value = favs.map { it.id }.toSet()
        _favouriteNotes.value = favs
    }

    fun toggleFavourite(id: Long) {
        viewModelScope.launch(Dispatchers.IO) {
            val isCurrentlyFav = _favouriteIds.value.contains(id)
            runCatching { dao.setFavourite(id, if (isCurrentlyFav) 0 else 1) }
            refreshFavourites()
        }
    }

    suspend fun loadTopicNotes(key: String): List<NoteMeta> =
        runCatching { dao.notesInTopic(key) }.getOrElse { emptyList() }

    /** Resolve an Obsidian-style `[[target]]` to a note in the library, or null if not found. */
    suspend fun resolveWikilink(target: String): LinkedNote? {
        val norm = Wikilinks.normalize(target)
        if (norm.isEmpty()) return null
        return runCatching { dao.resolveLink(norm, Wikilinks.withMd(norm)) }.getOrNull()
    }

    /** Notes whose body contains `[[<this note>]]` — i.e. backlinks. */
    suspend fun loadBacklinks(noteId: Long): List<LinkedNote> {
        val n = runCatching { dao.byId(noteId) }.getOrNull() ?: return emptyList()
        // A backlink could write the target as the title, the file name (with or without .md), or the relPath
        val candidates = LinkedHashSet<String>()
        candidates.add(Wikilinks.normalize(n.title))
        candidates.add(Wikilinks.normalize(n.name))
        candidates.add(Wikilinks.normalize(n.name.removeSuffix(".md").removeSuffix(".MD")
            .removeSuffix(".markdown").removeSuffix(".MARKDOWN")))
        candidates.add(Wikilinks.normalize(n.relPath))
        val list = candidates.filter { it.isNotEmpty() }
        if (list.isEmpty()) return emptyList()
        return runCatching { dao.backlinksFor(list) }.getOrElse { emptyList() }
            .filter { it.id != noteId }
    }

    /** Outgoing wikilinks from this note that point to existing notes. */
    suspend fun loadForwardLinks(noteId: Long): List<LinkedNote> =
        runCatching { dao.forwardLinksFor(noteId) }.getOrElse { emptyList() }
            .filter { it.id != noteId }

    /** Open an article in a tab (reusing it if already open) and make it active. */
    fun openArticle(id: Long, title: String) {
        val list = _tabs.value.toMutableList()
        val existing = list.indexOfFirst { it.id == id }
        if (existing < 0) {
            list.add(TabInfo(id, title))
            while (list.size > maxTabs) {
                val drop = list.firstOrNull { it.id != id }
                if (drop != null) {
                    list.remove(drop)
                    // Also strip the dropped tab from the visit history so back doesn't try to return there
                    _tabHistory.value = _tabHistory.value.filter { it != drop.id }
                } else break
            }
            _tabs.value = list
        }
        _activeTab.value = id
        pushHistory(id)
        viewModelScope.launch { refreshRecent() }
    }

    fun setActiveTab(id: Long) {
        _activeTab.value = id
        pushHistory(id)
    }

    fun closeTab(id: Long) {
        val list = _tabs.value.toMutableList()
        val idx = list.indexOfFirst { it.id == id }
        if (idx < 0) return
        list.removeAt(idx)
        _tabs.value = list
        // Drop every occurrence of the closed tab from history
        _tabHistory.value = _tabHistory.value.filter { it != id }
        if (_activeTab.value == id) {
            val newActive = list.getOrNull(idx.coerceAtMost(list.size - 1))?.id
            _activeTab.value = newActive
            if (newActive != null) pushHistory(newActive)
        }
    }

    suspend fun loadNote(id: Long): Note? {
        val n = dao.byId(id)
        if (n != null) {
            runCatching { dao.touch(id, System.currentTimeMillis()) }
            refreshRecent()
        }
        return n
    }

    fun saveScroll(id: Long, scroll: Int) {
        if (scroll < 0) return
        viewModelScope.launch(Dispatchers.IO) { runCatching { dao.setScroll(id, scroll) } }
    }

    /** Term to flash-highlight in the reader after opening a full-text search result (one-shot). */
    var pendingHighlight: String? = null
    fun consumePendingHighlight(): String? {
        val v = pendingHighlight
        pendingHighlight = null
        return v
    }

    fun setFontScale(v: Float) { viewModelScope.launch { prefs.setFontScale(v) } }
    fun setTheme(name: String) { viewModelScope.launch { prefs.setTheme(name) } }

    fun libraryName(): String {
        val uri = libraryUri.value ?: return "Library"
        val seg = Uri.decode(uri).substringAfterLast(':', "").substringAfterLast('/')
        return if (seg.isBlank()) "Library" else seg
    }

    companion object {
        /** Parse top-level markdown headings (outside fenced code) into an outline. */
        fun parseOutline(content: String): List<OutlineItem> {
            val out = ArrayList<OutlineItem>()
            var inFence = false
            var fence = ""
            var idx = 0
            for (raw in content.lineSequence()) {
                val line = raw.trimEnd()
                val t = line.trimStart()
                if (inFence) {
                    if (t.startsWith(fence)) inFence = false
                    continue
                }
                if (t.startsWith("```") || t.startsWith("~~~")) {
                    inFence = true; fence = t.take(3); continue
                }
                val m = Regex("^(#{1,6})\\s+(.*)$").find(line) ?: continue
                val level = m.groupValues[1].length
                val title = cleanHeading(m.groupValues[2])
                if (title.isNotBlank()) out.add(OutlineItem(level, title, idx))
                idx++
            }
            return out
        }

        private fun cleanHeading(s: String): String {
            var x = s
            x = Regex("\\[([^\\]]+)\\]\\([^)]*\\)").replace(x) { it.groupValues[1] } // links -> text
            x = x.replace(Regex("[*_`~]"), "")
            x = Regex("<[^>]+>").replace(x, "")
            return x.trim()
        }
    }
}
