package com.tebogo.markvault

import android.app.Application
import android.content.Intent
import android.net.Uri
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.tebogo.markvault.data.IndexProgress
import com.tebogo.markvault.data.Indexer
import com.tebogo.markvault.data.LinkedNote
import com.tebogo.markvault.data.Note
import com.tebogo.markvault.data.NoteLink
import com.tebogo.markvault.data.NoteMeta
import com.tebogo.markvault.data.NoteTopic
import com.tebogo.markvault.data.PdfAnnotation
import com.tebogo.markvault.data.PdfHistoryEntry
import com.tebogo.markvault.data.PdfPageText
import com.tebogo.markvault.data.Prefs
import com.tebogo.markvault.data.RecentNote
import com.tebogo.markvault.data.SearchHit
import com.tebogo.markvault.data.TopicCard
import com.tebogo.markvault.data.Topics
import com.tebogo.markvault.data.VaultDb
import com.tebogo.markvault.data.Wikilinks
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.FlowPreview
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.debounce
import kotlinx.coroutines.flow.distinctUntilChanged
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.flowOn
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

enum class SearchMode { TITLES, CONTENT }

/** Result of saveImportedMarkdown — either success with the new doc URI, or an error. */
sealed class SaveResult {
    data class Ok(val docUri: String, val fileName: String, val subfolder: String) : SaveResult()
    data class Error(val message: String) : SaveResult()
}

/** How an article was opened — used to badge it in the home recents list. */
enum class OpenSource {
    /** Opened from search, browse, recents, favourites, home — the default. */
    DIRECT,
    /** Opened by tapping a `[[wikilink]]` or a markdown link inside another note. */
    LINK,
    /** Opened from the Links & backlinks bottom sheet inside an article. */
    BACKLINK,
    /** Opened from a node in the graph view. */
    GRAPH
}

data class TabInfo(val id: Long, val title: String, val fileType: String = "md")
data class OutlineItem(val level: Int, val title: String, val index: Int)

@OptIn(FlowPreview::class)
class AppViewModel(app: Application) : AndroidViewModel(app) {

    private val db = VaultDb.get(app)
    private val dao = db.notes()
    private val prefs = Prefs(app)
    private val indexer = Indexer(app, dao)

    val libraryUri: StateFlow<String?> =
        prefs.libraryUri.stateIn(viewModelScope, SharingStarted.Eagerly, null)
    val fontScale: StateFlow<Float> =
        prefs.fontScale.stateIn(viewModelScope, SharingStarted.Eagerly, 1.0f)
    val theme: StateFlow<String> =
        prefs.theme.stateIn(viewModelScope, SharingStarted.Eagerly, "dark")
    // Performance/feature toggles — let the user opt in to heavier features.
    val smartStylingAllDocs: StateFlow<Boolean> =
        prefs.smartStylingAllDocs.stateIn(viewModelScope, SharingStarted.Eagerly, false)
    val swipeSwitchTabs: StateFlow<Boolean> =
        prefs.swipeSwitchTabs.stateIn(viewModelScope, SharingStarted.Eagerly, false)

    private val _progress = MutableStateFlow(IndexProgress())
    val progress: StateFlow<IndexProgress> = _progress

    private val _notes = MutableStateFlow<List<NoteMeta>>(emptyList())
    val notes: StateFlow<List<NoteMeta>> = _notes

    private val _recent = MutableStateFlow<List<RecentNote>>(emptyList())
    val recent: StateFlow<List<RecentNote>> = _recent

    private val _topics = MutableStateFlow<List<TopicCard>>(emptyList())
    val topics: StateFlow<List<TopicCard>> = _topics

    /** Notes added to the library since the last manual re-index (empty until first reindex). */
    private val _newNotes = MutableStateFlow<List<NoteMeta>>(emptyList())
    val newNotes: StateFlow<List<NoteMeta>> = _newNotes

    /** IDs of notes the user has starred as favourites. */
    private val _favouriteIds = MutableStateFlow<Set<Long>>(emptySet())
    val favouriteIds: StateFlow<Set<Long>> = _favouriteIds

    /** Starred notes as NoteMeta list for the home screen. */
    private val _favouriteNotes = MutableStateFlow<List<NoteMeta>>(emptyList())
    val favouriteNotes: StateFlow<List<NoteMeta>> = _favouriteNotes

    /** Notes recommended to the user — based on topic overlap with what they've been reading. */
    private val _suggested = MutableStateFlow<List<NoteMeta>>(emptyList())
    val suggested: StateFlow<List<NoteMeta>> = _suggested

    // ---- Recent search clicks (persisted, capped at 20) ----
    private val _recentSearches = MutableStateFlow<List<RecentSearch>>(emptyList())
    val recentSearches: StateFlow<List<RecentSearch>> = _recentSearches
    private val maxRecentSearches = 20

    /** Called when the user taps a search result. Stores the query + the note it led to. */
    fun recordSearchClick(query: String, noteId: Long, title: String, relPath: String) {
        val q = query.trim()
        if (q.isEmpty()) return
        val now = System.currentTimeMillis()
        val entry = RecentSearch(query = q, noteId = noteId, title = title, relPath = relPath, ts = now)
        // Dedup: drop any existing entry for the same (query, noteId), then prepend the fresh one
        val cur = _recentSearches.value
        val deduped = cur.filterNot { it.noteId == noteId && it.query.equals(q, ignoreCase = true) }
        val updated = (listOf(entry) + deduped).take(maxRecentSearches)
        _recentSearches.value = updated
        viewModelScope.launch(Dispatchers.IO) { runCatching { prefs.setRecentSearchesRaw(encodeRecents(updated)) } }
    }

    fun clearRecentSearches() {
        _recentSearches.value = emptyList()
        viewModelScope.launch(Dispatchers.IO) { runCatching { prefs.setRecentSearchesRaw("") } }
    }

    // ---- Open article tabs ----
    private val _tabs = MutableStateFlow<List<TabInfo>>(emptyList())
    val tabs: StateFlow<List<TabInfo>> = _tabs
    private val _activeTab = MutableStateFlow<Long?>(null)
    val activeTab: StateFlow<Long?> = _activeTab
    private val maxTabs = 8

    /**
     * In-Reader navigation history (tab IDs visited, oldest → newest).
     * Lets the system Back button return through previously-viewed tabs (e.g. after tapping a
     * backlink) instead of immediately exiting the Reader.
     */
    private val _tabHistory = MutableStateFlow<List<Long>>(emptyList())
    val tabHistory: StateFlow<List<Long>> = _tabHistory
    private val maxHistory = 50

    private fun pushHistory(id: Long) {
        val cur = _tabHistory.value
        if (cur.lastOrNull() == id) return // dedupe consecutive
        val updated = (cur + id)
        _tabHistory.value = if (updated.size > maxHistory) updated.takeLast(maxHistory) else updated
    }

    /**
     * Pop the current tab off history and activate the previous one.
     * Returns true if we moved back inside the Reader; false if there's nowhere to go back to
     * (caller should let the system Back press exit the Reader).
     */
    fun goBackInTabs(): Boolean {
        val cur = _tabHistory.value
        if (cur.size < 2) return false
        val updated = cur.dropLast(1)
        _tabHistory.value = updated
        _activeTab.value = updated.last()
        return true
    }

    /**
     * Switch to the next / previous tab in the open tabs list (not history).
     * Used by swipe-left / swipe-right gestures inside the Reader.
     * Returns true if it switched, false if there's only one tab.
     */
    fun switchTabByDirection(forward: Boolean): Boolean {
        val list = _tabs.value
        if (list.size < 2) return false
        val curId = _activeTab.value ?: list.first().id
        val idx = list.indexOfFirst { it.id == curId }
        if (idx < 0) return false
        val next = if (forward) (idx + 1) % list.size else (idx - 1 + list.size) % list.size
        val newId = list[next].id
        _activeTab.value = newId
        pushHistory(newId)
        return true
    }

    /** Clear the tab visit history. Called when the Reader exits to home / search etc. */
    fun clearTabHistory() { _tabHistory.value = emptyList() }

    val query = MutableStateFlow("")
    val mode = MutableStateFlow(SearchMode.CONTENT)
    /**
     * When ON, wraps the user's query in quotes before searching so FTS treats it
     * as an exact phrase. Only meaningful for SearchMode.CONTENT (the UI hides the
     * toggle in TITLES mode where it has no effect).
     */
    val quotePhrase = MutableStateFlow(false)

    val results: StateFlow<List<SearchHit>> =
        combine(
            query.debounce(220).map { it.trim() }.distinctUntilChanged(),
            mode,
            quotePhrase
        ) { q, m, qp -> Triple(q, m, qp) }
            .map { (q, m, qp) ->
                when {
                    q.length < 2 -> emptyList()
                    m == SearchMode.TITLES -> runCatching { titleSearch(q) }.getOrElse { emptyList() }
                    else -> {
                        val effective = if (qp && !(q.startsWith("\"") && q.endsWith("\""))) "\"$q\"" else q
                        runCatching { rankedContentSearch(effective, originalRaw = q) }.getOrElse { emptyList() }
                    }
                }
            }.flowOn(Dispatchers.IO)
            .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    /**
     * Content search with smarter ranking. Prefers, in order:
     *  1. Exact phrase appearing in the title
     *  2. Exact phrase appearing in the content
     *  3. All query words appearing in the title (any order)
     *  4. All query words appearing in the content
     *  5. Most query words appearing somewhere (last resort — filtered if too sparse)
     *
     * Adds bonuses for: word-adjacency in the snippet, multiple matches in one
     * document, and matches at word boundaries.
     */
    private suspend fun rankedContentSearch(ftsQuery: String, originalRaw: String): List<SearchHit> {
        val ftsHits = dao.search(Topics.expandQuery(ftsQuery))
        if (ftsHits.isEmpty()) return emptyList()

        // The original (un-quoted) phrase from the user, used for scoring + display.
        val phrase = originalRaw.trim()
            .removeSurrounding("\"")
            .lowercase()
        val tokens = phrase.split(Regex("\\s+"))
            .map { it.replace(Regex("[^\\p{L}\\p{N}]"), "") }
            .filter { it.length >= 2 }
        val tokensLower = tokens.toSet()
        val isMultiWord = tokensLower.size > 1

        data class Scored(val hit: SearchHit, val score: Int)
        val scored = ftsHits.mapNotNull { h ->
            val title = h.title.lowercase()
            val snippet = h.snippet.lowercase()

            // Match-marker count tells us how many distinct hits appeared in the snippet
            // (the FTS snippet() function wraps each match in ⟦…⟧).
            val markerCount = h.snippet.count { it == '\u27E6' }

            val titleHasPhrase = title.contains(phrase)
            val snippetHasPhrase = snippet.contains(phrase)
            val titleTokenHits = tokensLower.count { title.contains(it) }
            val snippetTokenHits = tokensLower.count { snippet.contains(it) }

            // Adjacency: are all the query tokens within a ~10-word window of each other?
            val adjacencyBonus = if (isMultiWord && snippetTokenHits == tokensLower.size) {
                val words = snippet.split(Regex("\\s+"))
                var found = false
                if (words.size >= tokensLower.size) {
                    for (i in 0..(words.size - tokensLower.size)) {
                        val end = minOf(i + 10, words.size)
                        val window = words.subList(i, end).joinToString(" ")
                        if (tokensLower.all { window.contains(it) }) { found = true; break }
                    }
                }
                if (found) 800 else 0
            } else 0

            // Word boundary bonus: phrase appears at a word boundary in the title
            val titleBoundaryBonus = if (isMultiWord && phrase.length >= 3 &&
                Regex("\\b" + Regex.escape(phrase) + "\\b").containsMatchIn(title)) 2_000 else 0

            val score = when {
                titleHasPhrase -> 10_000 + titleBoundaryBonus + markerCount * 50
                snippetHasPhrase -> 5_000 + titleTokenHits * 200 + markerCount * 100 + adjacencyBonus
                isMultiWord && titleTokenHits == tokensLower.size -> 3_500 + adjacencyBonus + markerCount * 50
                isMultiWord && snippetTokenHits == tokensLower.size -> 1_800 + adjacencyBonus + titleTokenHits * 150 + markerCount * 30
                else -> {
                    val total = titleTokenHits + snippetTokenHits
                    // Discard sparse matches — e.g. "ar" matching "art history" when only
                    // one of two query tokens appears.
                    if (isMultiWord && total < (tokensLower.size + 1) / 2) return@mapNotNull null
                    100 + titleTokenHits * 40 + snippetTokenHits * 10 + markerCount * 5
                }
            }
            Scored(h, score)
        }
        return scored
            .sortedByDescending { it.score }
            .take(150)
            .map { it.hit }
    }

    /**
     * Obsidian-style title search: every word in the query must appear somewhere in the
     * title / file name / path, in any order. Exact-phrase matches in the title rank highest.
     */
    private suspend fun titleSearch(raw: String): List<SearchHit> {
        val tokens = raw.split(Regex("\\s+"))
            .map { it.trim() }
            .filter { it.isNotEmpty() }
            .take(6)
        if (tokens.isEmpty()) return emptyList()
        // Pad up to 6 LIKE slots; "%%" matches anything so unused slots are no-ops.
        val pats = (0 until 6).map { i ->
            if (i < tokens.size) "%${tokens[i]}%" else "%%"
        }
        val rows = dao.searchTitlesAllWords(
            pats[0], pats[1], pats[2], pats[3], pats[4], pats[5]
        )
        val phrase = raw.lowercase()
        val tokensLower = tokens.map { it.lowercase() }
        // Score each hit: prefer exact phrase, then more tokens in title vs path
        return rows.asSequence()
            .map { n ->
                val titleLower = n.title.lowercase()
                val pathLower = n.relPath.lowercase()
                val score = when {
                    titleLower.contains(phrase) -> 1_000
                    pathLower.contains(phrase) -> 800
                    else -> {
                        val titleHits = tokensLower.count { titleLower.contains(it) }
                        val pathHits = tokensLower.count { pathLower.contains(it) }
                        titleHits * 10 + pathHits
                    }
                }
                n to score
            }
            .sortedWith(
                compareByDescending<Pair<NoteMeta, Int>> { it.second }
                    .thenBy { it.first.title.lowercase() }
            )
            .take(200)
            .map { (n, _) -> SearchHit(n.id, n.relPath, n.title, "", n.fileType) }
            .toList()
    }

    /** Topic cards whose vocabulary matches the current query (shown above results). */
    val topicMatches: StateFlow<List<TopicCard>> =
        combine(query.debounce(220).map { it.trim() }.distinctUntilChanged(), _topics) { q, topics ->
            if (q.length < 2) emptyList()
            else {
                val keys = Topics.matchQuery(q).toSet()
                topics.filter { it.key in keys }
            }
        }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    init {
        viewModelScope.launch {
            refreshNotes()
            refreshRecent()
            refreshTopics()
            refreshFavourites(); refreshSuggested()
            runCatching { _recentSearches.value = decodeRecents(prefs.recentSearchesRaw.first()) }
            val uri = prefs.libraryUri.first()
            val storedTopicVersion = prefs.topicVersion.first()
            val storedLinksVersion = prefs.linksVersion.first()
            when {
                uri != null && _notes.value.isEmpty() -> startSync(uri)
                _notes.value.isNotEmpty() -> {
                    if (storedTopicVersion != Topics.VERSION) {
                        reclassifyTopics()
                        prefs.setTopicVersion(Topics.VERSION)
                    }
                    if (storedLinksVersion != Wikilinks.VERSION) {
                        reextractLinks()
                        prefs.setLinksVersion(Wikilinks.VERSION)
                    }
                }
            }
        }
    }

    fun setLibrary(uri: Uri) {
        val app = getApplication<Application>()
        try {
            // Request BOTH read and write so we can save imported markdown files
            // back into the library. WRITE is needed by saveImportedMarkdown().
            app.contentResolver.takePersistableUriPermission(
                uri,
                Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_WRITE_URI_PERMISSION
            )
        } catch (_: Exception) {
        }
        viewModelScope.launch(Dispatchers.IO) {
            dao.clearAll()
            runCatching { dao.clearTopics() }
            runCatching { dao.clearLinks() }
            prefs.setLibraryUri(uri.toString())
            _tabs.value = emptyList(); _activeTab.value = null
            _newNotes.value = emptyList()
            refreshNotes(); refreshRecent(); refreshTopics(); refreshFavourites(); refreshSuggested()
            startSync(uri.toString(), trackNewNotes = false)
        }
    }

    fun reindex() {
        val uri = libraryUri.value ?: return
        startSync(uri, trackNewNotes = true)
    }

    private fun startSync(uri: String, trackNewNotes: Boolean = false) {
        if (_progress.value.running) return
        _progress.value = IndexProgress(true, "Starting\u2026", 0, 0)
        viewModelScope.launch(Dispatchers.IO) {
            try {
                val beforeRelPaths = if (trackNewNotes)
                    runCatching { dao.allMeta().map { it.relPath }.toSet() }.getOrElse { emptySet() }
                else emptySet()
                indexer.sync(uri) { p -> _progress.value = p }
                if (trackNewNotes) {
                    val afterAll = runCatching { dao.allMeta() }.getOrElse { emptyList() }
                    _newNotes.value = afterAll.filter { it.relPath !in beforeRelPaths }.take(30)
                }
            } catch (e: Exception) {
                _progress.value = IndexProgress(false, "Error: ${e.message}", 0, 0)
            }
            refreshNotes(); refreshRecent(); refreshTopics(); refreshFavourites(); refreshSuggested()
            runCatching { prefs.setTopicVersion(Topics.VERSION) }
            runCatching { prefs.setLinksVersion(Wikilinks.VERSION) }
        }
    }

    /** Re-tag every already-indexed note using the current lexicon (no file re-scan). */
    private suspend fun reclassifyTopics() {
        val total = runCatching { dao.countNotes() }.getOrElse { 0 }
        if (total == 0) return
        _progress.value = IndexProgress(true, "Updating topics\u2026", 0, total)
        runCatching { dao.clearTopics() }
        val pageSize = 300
        var offset = 0
        var done = 0
        while (offset < total) {
            val page = runCatching { dao.notesTextPage(pageSize, offset) }.getOrElse { emptyList() }
            if (page.isEmpty()) break
            for (nt in page) {
                val topics = runCatching { Topics.classify(nt.title, nt.content) }.getOrElse { emptyList() }
                if (topics.isNotEmpty()) {
                    runCatching { dao.insertTopics(topics.map { NoteTopic(nt.id, it.first, it.second) }) }
                }
                done++
            }
            offset += pageSize
            _progress.value = IndexProgress(true, "Updating topics\u2026", done, total)
        }
        _progress.value = IndexProgress(false, "Done", total, total)
        refreshTopics()
    }

    /**
     * Re-run the wikilink/markdown-link extractor across every note's stored content.
     * Used after the extractor version bumps (e.g. when markdown-style `[label](file.md)` support
     * is added) so existing notes get the new edges without forcing a full file re-read.
     */
    private suspend fun reextractLinks() {
        val total = runCatching { dao.countNotes() }.getOrElse { 0 }
        if (total == 0) return
        _progress.value = IndexProgress(true, "Updating links\u2026", 0, total)
        runCatching { dao.clearLinks() }
        val pageSize = 300
        var offset = 0
        var done = 0
        while (offset < total) {
            val page = runCatching { dao.notesTextPage(pageSize, offset) }.getOrElse { emptyList() }
            if (page.isEmpty()) break
            for (nt in page) {
                val targets = runCatching { Wikilinks.extract(nt.content) }.getOrElse { emptyList() }
                if (targets.isNotEmpty()) {
                    val rows = targets.map { NoteLink(nt.id, it, Wikilinks.normalize(it)) }
                    runCatching { dao.insertLinks(rows) }
                }
                done++
            }
            offset += pageSize
            _progress.value = IndexProgress(true, "Updating links\u2026", done, total)
        }
        _progress.value = IndexProgress(false, "Done", total, total)
    }

    private suspend fun refreshNotes() {
        _notes.value = runCatching { dao.allMeta() }.getOrElse { emptyList() }
    }

    private suspend fun refreshRecent() {
        _recent.value = runCatching { dao.recentNotes() }.getOrElse { emptyList() }
    }

    private suspend fun refreshTopics() {
        val counts = runCatching { dao.topicCounts() }.getOrElse { emptyList() }
            .associate { it.topic to it.cnt }
        _topics.value = Topics.ALL.mapNotNull { d ->
            val c = counts[d.key] ?: 0
            if (c > 0) TopicCard(d.key, d.emoji, d.label, c) else null
        }.sortedByDescending { it.count }
    }

    private suspend fun refreshFavourites() {
        val favs = runCatching { dao.favouriteNotes() }.getOrElse { emptyList() }
        _favouriteIds.value = favs.map { it.id }.toSet()
        _favouriteNotes.value = favs
    }

    private suspend fun refreshSuggested() {
        // Hide notes opened in the last ~3 weeks; if the user has no reading history
        // (or no topic overlap), fall back to random unopened notes.
        val cutoff = System.currentTimeMillis() - 21L * 24L * 60L * 60L * 1000L
        val topicBased = runCatching { dao.suggestedNotes(cutoff, 25) }.getOrElse { emptyList() }
        _suggested.value = if (topicBased.size >= 6) topicBased
        else runCatching { dao.randomUnopened(25) }.getOrElse { topicBased }
    }

    fun toggleFavourite(id: Long) {
        viewModelScope.launch(Dispatchers.IO) {
            val isCurrentlyFav = _favouriteIds.value.contains(id)
            runCatching { dao.setFavourite(id, if (isCurrentlyFav) 0 else 1) }
            refreshFavourites(); refreshSuggested()
        }
    }

    suspend fun loadTopicNotes(key: String): List<NoteMeta> =
        runCatching { dao.notesInTopic(key) }.getOrElse { emptyList() }

    /** Resolve an Obsidian-style `[[target]]` to a note in the library, or null if not found. */
    suspend fun resolveWikilink(target: String): LinkedNote? {
        val norm = Wikilinks.normalize(target)
        if (norm.isEmpty()) return null
        return runCatching { dao.resolveLink(norm, Wikilinks.withMd(norm)) }.getOrNull()
    }

    /** Notes whose body contains `[[<this note>]]` — i.e. backlinks. */
    suspend fun loadBacklinks(noteId: Long): List<LinkedNote> {
        val n = runCatching { dao.byId(noteId) }.getOrNull() ?: return emptyList()
        // A backlink could write the target as the title, the file name (with or without .md), or the relPath
        val candidates = LinkedHashSet<String>()
        candidates.add(Wikilinks.normalize(n.title))
        candidates.add(Wikilinks.normalize(n.name))
        candidates.add(Wikilinks.normalize(n.name.removeSuffix(".md").removeSuffix(".MD")
            .removeSuffix(".markdown").removeSuffix(".MARKDOWN")))
        candidates.add(Wikilinks.normalize(n.relPath))
        val list = candidates.filter { it.isNotEmpty() }
        if (list.isEmpty()) return emptyList()
        return runCatching { dao.backlinksFor(list) }.getOrElse { emptyList() }
            .filter { it.id != noteId }
    }

    /** Outgoing wikilinks from this note that point to existing notes. */
    suspend fun loadForwardLinks(noteId: Long): List<LinkedNote> =
        runCatching { dao.forwardLinksFor(noteId) }.getOrElse { emptyList() }
            .filter { it.id != noteId }

    /**
     * Fast count of total connections (forward links + backlinks) for a note.
     * Used to badge the Reader header so the user sees how connected the article is at a glance.
     */
    suspend fun connectionCount(noteId: Long): Int {
        val n = runCatching { dao.byId(noteId) }.getOrNull() ?: return 0
        val candidates = LinkedHashSet<String>().apply {
            add(Wikilinks.normalize(n.title))
            add(Wikilinks.normalize(n.name))
            add(Wikilinks.normalize(n.name.removeSuffix(".md").removeSuffix(".MD")
                .removeSuffix(".markdown").removeSuffix(".MARKDOWN")))
            add(Wikilinks.normalize(n.relPath))
        }.filter { it.isNotEmpty() }
        val forwards = runCatching { dao.forwardLinkCount(noteId) }.getOrElse { 0 }
        val backs = if (candidates.isEmpty()) 0
            else runCatching { dao.backlinkCount(candidates, noteId) }.getOrElse { 0 }
        return forwards + backs
    }

    /** The note with the most total connections in the library (best starting anchor for the graph). */
    suspend fun mostConnectedNote(): LinkedNote? =
        runCatching { dao.mostConnectedNote() }.getOrNull()

    /**
     * Build a 2-degree connection graph around [centerId]. Returns the focus note, its 1st-degree
     * neighbours (capped), and 2nd-degree neighbours (capped). Connection direction is preserved
     * so the UI can draw incoming vs outgoing edges differently.
     */
    suspend fun buildFocusGraph(centerId: Long): FocusGraph? {
        val centerNote = runCatching { dao.byId(centerId) }.getOrNull() ?: return null
        val center = LinkedNote(centerNote.id, centerNote.title, centerNote.folder)

        val forwards = loadForwardLinks(centerId)
        val backs = loadBacklinks(centerId)

        // Combined first-ring nodes (uniqued by id), with link direction tagged.
        // outgoing = center -> node, incoming = node -> center, both = bidirectional.
        val firstRingMap = LinkedHashMap<Long, GraphNeighbour>()
        for (f in forwards) firstRingMap[f.id] = GraphNeighbour(f, LinkDir.OUTGOING)
        for (b in backs) {
            val existing = firstRingMap[b.id]
            firstRingMap[b.id] = if (existing != null) existing.copy(dir = LinkDir.BOTH)
            else GraphNeighbour(b, LinkDir.INCOMING)
        }
        val firstRing = firstRingMap.values.toList().take(MAX_FIRST_RING)
        val firstRingIds = firstRing.map { it.note.id }.toSet() + centerId

        // Second-ring nodes: anything 1° neighbours link to/from, minus already-shown nodes.
        val secondRingMap = LinkedHashMap<Long, GraphEdge>()
        for (n in firstRing) {
            val ff = loadForwardLinks(n.note.id)
            val bb = loadBacklinks(n.note.id)
            for (x in ff) {
                if (x.id in firstRingIds) continue
                if (secondRingMap.size >= MAX_SECOND_RING && x.id !in secondRingMap) continue
                if (x.id !in secondRingMap) secondRingMap[x.id] = GraphEdge(x, n.note.id)
            }
            for (x in bb) {
                if (x.id in firstRingIds) continue
                if (secondRingMap.size >= MAX_SECOND_RING && x.id !in secondRingMap) continue
                if (x.id !in secondRingMap) secondRingMap[x.id] = GraphEdge(x, n.note.id)
            }
        }
        val secondRing = secondRingMap.values.toList()

        return FocusGraph(
            center = center,
            firstRing = firstRing,
            secondRing = secondRing,
            firstRingTotal = firstRingMap.size,
            secondRingTotal = -1 // unknown without re-counting; UI can show "+more" if needed
        )
    }

    /** Open an article in a tab (reusing it if already open) and make it active. */
    /** How an article was last opened — drives the small badge on the recents/history list. */
    private val _recentOpenSources = MutableStateFlow<Map<Long, OpenSource>>(emptyMap())
    val recentOpenSources: StateFlow<Map<Long, OpenSource>> = _recentOpenSources

    /**
     * Open an article in a tab (reusing it if already open) and make it active.
     * [source] records WHY we're opening it (e.g. from a wikilink) so the home screen can
     * badge it in the recently-opened list.
     */
    fun openArticle(id: Long, title: String, source: OpenSource = OpenSource.DIRECT, fileType: String = "md") {
        val list = _tabs.value.toMutableList()
        val existing = list.indexOfFirst { it.id == id }
        if (existing < 0) {
            list.add(TabInfo(id, title, fileType))
            while (list.size > maxTabs) {
                val drop = list.firstOrNull { it.id != id }
                if (drop != null) {
                    list.remove(drop)
                    // Also strip the dropped tab from the visit history so back doesn't try to return there
                    _tabHistory.value = _tabHistory.value.filter { it != drop.id }
                } else break
            }
            _tabs.value = list
        }
        _activeTab.value = id
        pushHistory(id)
        // Update source map: keep a small rolling window so it doesn't grow without bound
        val cur = _recentOpenSources.value.toMutableMap()
        cur[id] = source
        if (cur.size > 60) {
            // Trim oldest by recents ordering would be ideal but we don't have timestamps here;
            // simple cap keeps memory bounded.
            val drop = cur.keys.first()
            cur.remove(drop)
        }
        _recentOpenSources.value = cur
        viewModelScope.launch { refreshRecent() }
    }

    fun setActiveTab(id: Long) {
        _activeTab.value = id
        pushHistory(id)
    }

    fun closeTab(id: Long) {
        val list = _tabs.value.toMutableList()
        val idx = list.indexOfFirst { it.id == id }
        if (idx < 0) return
        list.removeAt(idx)
        _tabs.value = list
        // Drop every occurrence of the closed tab from history
        _tabHistory.value = _tabHistory.value.filter { it != id }
        if (_activeTab.value == id) {
            val newActive = list.getOrNull(idx.coerceAtMost(list.size - 1))?.id
            _activeTab.value = newActive
            if (newActive != null) pushHistory(newActive)
        }
    }

    /** Close every open tab. Used by the tab-management bottom sheet. */
    fun closeAllTabs() {
        _tabs.value = emptyList()
        _tabHistory.value = emptyList()
        _activeTab.value = null
    }

    /** Close every tab except the given one. Convenient when the user picks one in the grid. */
    fun closeOtherTabs(keepId: Long) {
        val keep = _tabs.value.firstOrNull { it.id == keepId } ?: return
        _tabs.value = listOf(keep)
        _tabHistory.value = listOf(keepId)
        _activeTab.value = keepId
    }

    suspend fun loadNote(id: Long): Note? {
        val n = dao.byId(id)
        if (n != null) {
            runCatching { dao.touch(id, System.currentTimeMillis()) }
            refreshRecent()
        }
        return n
    }

    /**
     * Return the SAF content URI string for a PDF note so the PdfReaderScreen can open it.
     * Also touches the "lastOpened" timestamp so it appears in recents.
     */
    suspend fun loadPdfUri(id: Long): String? {
        val n = dao.byId(id) ?: return null
        if (n.fileType != "pdf") return null
        runCatching { dao.touch(id, System.currentTimeMillis()) }
        refreshRecent()
        return n.uri
    }

    /** Look up the fileType for a note ID — used to decide which viewer to open. */
    suspend fun fileTypeOf(id: Long): String =
        runCatching { dao.byId(id)?.fileType }.getOrNull() ?: "md"

    /* ──────────────────────────────────────────────────────────────────────
     *  PDF text cache (per page) — used by in-PDF search for instant queries
     *  on second/third open. Re-extracted whenever the source file changes.
     * ────────────────────────────────────────────────────────────────────── */

    /** Returns cached page text iff it matches the source file's current lastModified. */
    suspend fun cachedPdfPageText(noteId: Long): Map<Int, String>? {
        val note = runCatching { dao.byId(noteId) }.getOrNull() ?: return null
        val stamp = runCatching { dao.pdfPageTextStamp(noteId) }.getOrNull() ?: return null
        if (stamp != note.lastModified) return null
        val rows = runCatching { dao.loadPdfPageText(noteId) }.getOrNull() ?: return null
        if (rows.isEmpty()) return null
        return rows.associate { it.pageIndex to it.text }
    }

    /** Persists the extracted text so future opens skip extraction. */
    suspend fun savePdfPageText(noteId: Long, pages: Map<Int, String>) {
        val note = runCatching { dao.byId(noteId) }.getOrNull() ?: return
        val rows = pages.entries.map { (i, t) ->
            PdfPageText(noteId, i, t, note.lastModified)
        }
        runCatching {
            dao.clearPdfPageText(noteId)
            dao.savePdfPageText(rows)
        }
    }

    /* ── PDF annotations ── */

    suspend fun loadAnnotation(noteId: Long, page: Int): String? =
        runCatching { dao.loadAnnotation(noteId, page)?.paths }.getOrNull()

    suspend fun loadAllAnnotations(noteId: Long): Map<Int, String> =
        runCatching {
            dao.loadAnnotationsForNote(noteId).associate { it.pageIndex to it.paths }
        }.getOrElse { emptyMap() }

    suspend fun saveAnnotation(noteId: Long, page: Int, pathsJson: String) {
        runCatching {
            if (pathsJson.isBlank() || pathsJson == "[]") dao.deleteAnnotation(noteId, page)
            else dao.saveAnnotation(PdfAnnotation(noteId, page, pathsJson))
        }
    }

    suspend fun clearAllAnnotations(noteId: Long) {
        runCatching { dao.deleteAllAnnotationsForNote(noteId) }
    }

    /* ── PDF view history (internal + external) ── */

    /** Record that a PDF was opened. Called on every PDF open from any path. */
    fun recordPdfView(uri: String, title: String, noteId: Long, isExternal: Boolean) {
        viewModelScope.launch(Dispatchers.IO) {
            runCatching {
                dao.deletePdfHistoryByUri(uri)
                dao.insertPdfHistory(PdfHistoryEntry(
                    uri = uri, title = title, noteId = noteId, isExternal = isExternal
                ))
            }
        }
    }

    suspend fun loadPdfHistory(limit: Int = 100): List<PdfHistoryEntry> =
        runCatching { dao.recentPdfHistory(limit) }.getOrElse { emptyList() }

    fun deletePdfHistoryEntry(id: Long) {
        viewModelScope.launch(Dispatchers.IO) { runCatching { dao.deletePdfHistory(id) } }
    }

    fun clearPdfHistory() {
        viewModelScope.launch(Dispatchers.IO) { runCatching { dao.clearPdfHistory() } }
    }

    /** First ~600 chars of the note body, used for the home-screen suggestion previews. */
    suspend fun previewOf(id: Long): String? =
        runCatching { dao.previewOf(id) }.getOrNull()

    fun saveScroll(id: Long, scroll: Int) {
        if (scroll < 0) return
        viewModelScope.launch(Dispatchers.IO) { runCatching { dao.setScroll(id, scroll) } }
    }

    /** Term to flash-highlight in the reader after opening a full-text search result (one-shot). */
    var pendingHighlight: String? = null
    fun consumePendingHighlight(): String? {
        val v = pendingHighlight
        pendingHighlight = null
        return v
    }

    /**
     * Stash a WebView state bundle so popup → full-screen (or back) doesn't reload the page.
     * The receiving screen consumes this immediately; missing/expired = falls back to URL load.
     */
    var webStateBundle: android.os.Bundle? = null
    fun consumeWebState(): android.os.Bundle? {
        val v = webStateBundle
        webStateBundle = null
        return v
    }

    /**
     * Web popup font scaling — separate from reader font scaling, persisted in-memory only.
     * Values are textZoom percentages: 100 = default; min 70, max 200.
     */
    private val _webPopupTextZoom = MutableStateFlow(100)
    val webPopupTextZoom: StateFlow<Int> = _webPopupTextZoom
    fun setWebPopupTextZoom(v: Int) {
        _webPopupTextZoom.value = v.coerceIn(70, 200)
    }

    /** Dark-mode toggle for the in-app WebView popup (persisted in-memory only). */
    private val _webPopupDarkMode = MutableStateFlow(true)
    val webPopupDarkMode: StateFlow<Boolean> = _webPopupDarkMode
    fun setWebPopupDarkMode(v: Boolean) { _webPopupDarkMode.value = v }

    /**
     * Global request to open the in-app WebView popup. Any screen can call [requestWebPopup]
     * and the popup will overlay it (because MainActivity collects this and renders the sheet
     * outside the NavHost). [clearWebPopup] dismisses it.
     */
    private val _webPopupRequest = MutableStateFlow<String?>(null)
    val webPopupRequest: StateFlow<String?> = _webPopupRequest
    fun requestWebPopup(url: String) { _webPopupRequest.value = url }
    fun clearWebPopup() { _webPopupRequest.value = null }

    fun setFontScale(v: Float) { viewModelScope.launch { prefs.setFontScale(v) } }
    fun setTheme(name: String) { viewModelScope.launch { prefs.setTheme(name) } }
    fun setSmartStylingAllDocs(v: Boolean) { viewModelScope.launch { prefs.setSmartStylingAllDocs(v) } }
    fun setSwipeSwitchTabs(v: Boolean) { viewModelScope.launch { prefs.setSwipeSwitchTabs(v) } }

    val importsSubfolder: StateFlow<String> = prefs.importsSubfolder
        .stateIn(viewModelScope, SharingStarted.Eagerly, "")
    fun setImportsSubfolder(name: String) {
        viewModelScope.launch { prefs.setImportsSubfolder(name) }
    }

    // Web-import include toggles (front-matter / URL / excerpt / body).
    val includeFrontmatter: StateFlow<Boolean> = prefs.includeFrontmatter
        .stateIn(viewModelScope, SharingStarted.Eagerly, true)
    val includeUrl: StateFlow<Boolean> = prefs.includeUrl
        .stateIn(viewModelScope, SharingStarted.Eagerly, true)
    val includeExcerpt: StateFlow<Boolean> = prefs.includeExcerpt
        .stateIn(viewModelScope, SharingStarted.Eagerly, true)
    val includeBody: StateFlow<Boolean> = prefs.includeBody
        .stateIn(viewModelScope, SharingStarted.Eagerly, true)
    fun setIncludeFrontmatter(v: Boolean) { viewModelScope.launch { prefs.setIncludeFrontmatter(v) } }
    fun setIncludeUrl(v: Boolean)         { viewModelScope.launch { prefs.setIncludeUrl(v) } }
    fun setIncludeExcerpt(v: Boolean)     { viewModelScope.launch { prefs.setIncludeExcerpt(v) } }
    fun setIncludeBody(v: Boolean)        { viewModelScope.launch { prefs.setIncludeBody(v) } }

    /**
     * Save a markdown string into the library, inside the configured subfolder.
     * Creates the subfolder lazily if it doesn't exist yet.
     *
     * @param title      base filename (no extension); will be sanitized
     * @param markdown   file body (UTF-8)
     * @param subfolder  subfolder name; empty string = library root
     * @return SaveResult with the new file's display URI on success, or an error message
     */
    suspend fun saveImportedMarkdown(
        title: String, markdown: String, subfolder: String
    ): SaveResult = withContext(Dispatchers.IO) {
        val libUri = libraryUri.value
            ?: return@withContext SaveResult.Error("No library is set. Pick one in Settings first.")
        val treeUri = runCatching { Uri.parse(libUri) }.getOrNull()
            ?: return@withContext SaveResult.Error("Library URI is invalid. Re-pick the library folder.")
        val cr = getApplication<Application>().contentResolver
        // Verify we have write permission persisted; if not, surface a clear error.
        val hasWrite = cr.persistedUriPermissions.any {
            it.uri == treeUri && it.isWritePermission
        }
        if (!hasWrite) {
            return@withContext SaveResult.Error(
                "Library is read-only. Open Settings and tap \u201CRe-grant library access\u201D."
            )
        }
        try {
            val rootId = android.provider.DocumentsContract.getTreeDocumentId(treeUri)
            val rootDocUri = android.provider.DocumentsContract.buildDocumentUriUsingTree(treeUri, rootId)
            val parentUri = if (subfolder.isBlank()) rootDocUri else
                findOrCreateFolder(cr, treeUri, rootId, subfolder)
                    ?: return@withContext SaveResult.Error("Could not create subfolder \"$subfolder\".")

            val safeName = sanitizeFilename(title)
            val fileName = ensureUnique(cr, treeUri, parentUri, safeName)
            val newDoc = android.provider.DocumentsContract.createDocument(
                cr, parentUri, "text/markdown", fileName
            ) ?: return@withContext SaveResult.Error("Failed to create the file.")
            cr.openOutputStream(newDoc, "w")?.use {
                it.write(markdown.toByteArray(Charsets.UTF_8))
            } ?: return@withContext SaveResult.Error("Could not open the new file for writing.")
            // Trigger a quick library refresh so the new note appears
            val cur = libUri
            if (cur != null) viewModelScope.launch { /* lazy reindex hint */ refreshNotes() }
            SaveResult.Ok(newDoc.toString(), fileName, subfolder)
        } catch (e: SecurityException) {
            SaveResult.Error("Permission denied: ${e.message}")
        } catch (e: Exception) {
            SaveResult.Error("Save failed: ${e.message ?: e.javaClass.simpleName}")
        }
    }

    /** Walk the library root, find a folder by name, or create it. Returns the folder doc URI. */
    private fun findOrCreateFolder(
        cr: android.content.ContentResolver, treeUri: Uri, rootId: String, name: String
    ): Uri? {
        val children = android.provider.DocumentsContract.buildChildDocumentsUriUsingTree(treeUri, rootId)
        val proj = arrayOf(
            android.provider.DocumentsContract.Document.COLUMN_DOCUMENT_ID,
            android.provider.DocumentsContract.Document.COLUMN_DISPLAY_NAME,
            android.provider.DocumentsContract.Document.COLUMN_MIME_TYPE
        )
        cr.query(children, proj, null, null, null)?.use { cur ->
            while (cur.moveToNext()) {
                val n = cur.getString(1) ?: continue
                val m = cur.getString(2) ?: ""
                if (n.equals(name, ignoreCase = true) &&
                    m == android.provider.DocumentsContract.Document.MIME_TYPE_DIR) {
                    val did = cur.getString(0)
                    return android.provider.DocumentsContract.buildDocumentUriUsingTree(treeUri, did)
                }
            }
        }
        // Not found — create it
        val rootDocUri = android.provider.DocumentsContract.buildDocumentUriUsingTree(treeUri, rootId)
        return android.provider.DocumentsContract.createDocument(
            cr, rootDocUri, android.provider.DocumentsContract.Document.MIME_TYPE_DIR, name
        )
    }

    /** Avoid overwriting an existing file by adding a numeric suffix. */
    private fun ensureUnique(
        cr: android.content.ContentResolver, treeUri: Uri, parentUri: Uri, baseName: String
    ): String {
        val base = baseName.removeSuffix(".md")
        var candidate = "$base.md"
        val parentId = android.provider.DocumentsContract.getDocumentId(parentUri)
        val children = android.provider.DocumentsContract.buildChildDocumentsUriUsingTree(treeUri, parentId)
        val existing = HashSet<String>()
        cr.query(
            children,
            arrayOf(android.provider.DocumentsContract.Document.COLUMN_DISPLAY_NAME),
            null, null, null
        )?.use { cur ->
            while (cur.moveToNext()) cur.getString(0)?.let { existing.add(it.lowercase()) }
        }
        var n = 2
        while (existing.contains(candidate.lowercase())) {
            candidate = "$base ($n).md"
            n++
        }
        return candidate
    }

    private fun sanitizeFilename(title: String): String {
        val cleaned = title
            .replace(Regex("[\\\\/:*?\"<>|\\r\\n]+"), " ")
            .replace(Regex("\\s+"), " ")
            .trim()
        val capped = if (cleaned.length > 80) cleaned.take(80).trim() else cleaned
        return capped.ifBlank { "Web import" }
    }

    fun libraryName(): String {
        val uri = libraryUri.value ?: return "Library"
        val seg = Uri.decode(uri).substringAfterLast(':', "").substringAfterLast('/')
        return if (seg.isBlank()) "Library" else seg
    }

    companion object {
        /** Focus-graph rendering caps to keep the view readable on a phone. */
        const val MAX_FIRST_RING = 16
        const val MAX_SECOND_RING = 30

        /** Parse top-level markdown headings (outside fenced code) into an outline. */
        fun parseOutline(content: String): List<OutlineItem> {
            val out = ArrayList<OutlineItem>()
            var inFence = false
            var fence = ""
            var idx = 0
            for (raw in content.lineSequence()) {
                val line = raw.trimEnd()
                val t = line.trimStart()
                if (inFence) {
                    if (t.startsWith(fence)) inFence = false
                    continue
                }
                if (t.startsWith("```") || t.startsWith("~~~")) {
                    inFence = true; fence = t.take(3); continue
                }
                val m = Regex("^(#{1,6})\\s+(.*)$").find(line) ?: continue
                val level = m.groupValues[1].length
                val title = cleanHeading(m.groupValues[2])
                if (title.isNotBlank()) out.add(OutlineItem(level, title, idx))
                idx++
            }
            return out
        }

        private fun cleanHeading(s: String): String {
            var x = s
            x = Regex("\\[([^\\]]+)\\]\\([^)]*\\)").replace(x) { it.groupValues[1] } // links -> text
            x = x.replace(Regex("[*_`~]"), "")
            x = Regex("<[^>]+>").replace(x, "")
            return x.trim()
        }
    }
}

/** Direction of a wikilink relative to the focused note. */
enum class LinkDir { OUTGOING, INCOMING, BOTH }

/** A 1°-ring neighbour: a directly linked note + which way the link goes. */
data class GraphNeighbour(val note: com.tebogo.markvault.data.LinkedNote, val dir: LinkDir)

/** A 2°-ring node: linked via [viaNoteId] which is one of the 1°-ring nodes. */
data class GraphEdge(val note: com.tebogo.markvault.data.LinkedNote, val viaNoteId: Long)

/** Result of expanding a focus note out to two degrees of connection. */
data class FocusGraph(
    val center: com.tebogo.markvault.data.LinkedNote,
    val firstRing: List<GraphNeighbour>,
    val secondRing: List<GraphEdge>,
    /** How many 1°-ring neighbours we found in total — UI can show "+N more" if greater than [firstRing.size]. */
    val firstRingTotal: Int,
    val secondRingTotal: Int
)

/** One persisted recent-search click: the query the user typed, and the note they ended up opening. */
data class RecentSearch(
    val query: String,
    val noteId: Long,
    val title: String,
    val relPath: String,
    val ts: Long
)

/**
 * Tab-separated, line-per-entry, with `\u0001` as field separator (any char that's vanishingly
 * unlikely in titles). Lightweight enough that we don't need a JSON library.
 */
private const val FIELD_SEP = "\u0001"

internal fun encodeRecents(list: List<RecentSearch>): String =
    list.joinToString("\n") { r ->
        // Defensively scrub any stray separator chars from user-controlled fields
        listOf(
            r.query.replace("\n", " ").replace(FIELD_SEP, " "),
            r.noteId.toString(),
            r.title.replace("\n", " ").replace(FIELD_SEP, " "),
            r.relPath.replace("\n", " ").replace(FIELD_SEP, " "),
            r.ts.toString()
        ).joinToString(FIELD_SEP)
    }

internal fun decodeRecents(raw: String): List<RecentSearch> {
    if (raw.isBlank()) return emptyList()
    return raw.split("\n").mapNotNull { line ->
        val parts = line.split(FIELD_SEP)
        if (parts.size < 5) return@mapNotNull null
        val id = parts[1].toLongOrNull() ?: return@mapNotNull null
        val ts = parts[4].toLongOrNull() ?: return@mapNotNull null
        RecentSearch(query = parts[0], noteId = id, title = parts[2], relPath = parts[3], ts = ts)
    }
}
