package com.tebogo.markvault

import android.app.Application
import android.app.ActivityManager
import android.content.Intent
import android.os.BatteryManager
import android.os.PowerManager
import android.net.Uri
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import android.os.Build
import com.tebogo.markvault.data.IndexProgress
import com.tebogo.markvault.data.Indexer
import com.tebogo.markvault.data.LinkedNote
import com.tebogo.markvault.data.Note
import com.tebogo.markvault.data.NoteLink
import com.tebogo.markvault.data.NoteMeta
import com.tebogo.markvault.data.NoteTopic
import com.tebogo.markvault.data.PdfAnnotation
import com.tebogo.markvault.data.PdfHistoryEntry
import com.tebogo.markvault.data.PdfPageText
import com.tebogo.markvault.data.WebBookmark
import com.tebogo.markvault.data.WebHistoryEntry
import com.tebogo.markvault.data.Prefs
import com.tebogo.markvault.data.RecentNote
import com.tebogo.markvault.data.SearchHit
import com.tebogo.markvault.data.TopicCard
import com.tebogo.markvault.data.Topics
import com.tebogo.markvault.data.VaultDb
import com.tebogo.markvault.data.Wikilinks
import com.tebogo.markvault.search.QueryContribution
import com.tebogo.markvault.search.ResultQueryProvenance
import com.tebogo.markvault.search.ResultQuerySource
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.FlowPreview
import kotlinx.coroutines.delay
import kotlinx.coroutines.runBlocking
import kotlinx.coroutines.sync.withLock
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.SharingStarted
import androidx.compose.runtime.getValue
import androidx.compose.runtime.setValue
import com.tebogo.markvault.ui.WebTab
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.debounce
import kotlinx.coroutines.flow.distinctUntilChanged
import kotlinx.coroutines.flow.emptyFlow
import kotlinx.coroutines.flow.filter
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.flatMapLatest
import kotlinx.coroutines.flow.flowOn
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.flow.mapLatest
import kotlinx.coroutines.flow.merge
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import kotlinx.coroutines.CoroutineStart
import kotlinx.coroutines.Job
import kotlinx.coroutines.currentCoroutineContext
import kotlinx.coroutines.ensureActive
import kotlinx.coroutines.cancelAndJoin
import kotlinx.coroutines.withContext
import kotlinx.coroutines.withTimeout
import kotlinx.coroutines.suspendCancellableCoroutine
import java.util.Locale
import java.security.MessageDigest
import org.json.JSONObject
import kotlin.coroutines.resume

data class BulkCaptionDownloadState(
    val running: Boolean = false,
    val language: String = "E",
    val visitedCategories: Int = 0,
    val discoveredVideos: Int = 0,
    val processedVideos: Int = 0,
    val downloaded: Int = 0,
    val skippedExisting: Int = 0,
    val noCaptionAvailable: Int = 0,
    val failed: Int = 0,
    val currentTitle: String = "",
    val message: String = ""
)

data class CacheDeleteProgress(
    val running: Boolean = false,
    val completed: Int = 0,
    val total: Int = 0,
    val message: String = "",
    val finished: Boolean = false
) {
    val fraction: Float get() = if (total <= 0) 0f else (completed.toFloat() / total.toFloat()).coerceIn(0f, 1f)
}

enum class SearchMode { TITLES, CONTENT }

/** Result of saveImportedMarkdown — either success with the new doc URI, or an error. */
sealed class SaveResult {
    data class Ok(val docUri: String, val fileName: String, val subfolder: String) : SaveResult()
    data class Error(val message: String) : SaveResult()
}

/** v5.5.7 — Lifecycle-safe progress for one WebViewer → offline HTML save. */
enum class OfflineHtmlSavePhase { IDLE, CAPTURING, WRITING, INDEXING, SUCCESS, ERROR }

data class OfflineHtmlSaveState(
    val operationId: Long = 0L,
    val phase: OfflineHtmlSavePhase = OfflineHtmlSavePhase.IDLE,
    val sourceUrl: String = "",
    val title: String = "",
    val message: String = "",
    val done: Int = 0,
    val total: Int = 0,
    val fileName: String = ""
) {
    val running: Boolean
        get() = phase == OfflineHtmlSavePhase.CAPTURING ||
            phase == OfflineHtmlSavePhase.WRITING ||
            phase == OfflineHtmlSavePhase.INDEXING
}

/** How an article was opened — used to badge it in the home recents list. */
enum class OpenSource {
    /** Opened from search, browse, recents, favourites, home — the default. */
    DIRECT,
    /** Opened by tapping a `[[wikilink]]` or a markdown link inside another note. */
    LINK,
    /** Opened from the Links & backlinks bottom sheet inside an article. */
    BACKLINK,
    /** Opened from a node in the graph view. */
    GRAPH
}

data class WorkspaceTag(val name: String, val noteIds: List<Long>)
data class TabInfo(val id: Long, val title: String, val fileType: String = "md")
data class OutlineItem(val level: Int, val title: String, val index: Int)
data class WorkspaceOutlineJumpRequest(val noteId: Long, val headingIndex: Int)

private const val POST_SEARCH_CLEANUP_DELAY_MS = 1_500L
private const val MEDIA_SEMANTIC_INDEX_BATCH_SIZE = 25
private const val MEDIA_SEMANTIC_INDEX_NEXT_BATCH_DELAY_MS = 30_000L
private const val HTML_CAPTURE_CHUNK_CHARS = 48 * 1024
private const val MAX_CAPTURE_CHARS = 32 * 1024 * 1024
private const val JS_CAPTURE_TIMEOUT_MS = 15_000L
private const val JS_CHUNK_TIMEOUT_MS = 10_000L

@OptIn(FlowPreview::class, ExperimentalCoroutinesApi::class)
class AppViewModel(app: Application) : AndroidViewModel(app) {

    // v5.4.402cc — Durable GitHub Release updater state. The transfer itself is
    // owned by a foreground service; the ViewModel only exposes user actions/UI state.
    val appUpdateState: StateFlow<com.tebogo.markvault.update.AppUpdateState> =
        com.tebogo.markvault.update.AppUpdateManager.state

    private val db = VaultDb.get(app)
    private val dao      = db.notes()
    private val mediaDao = db.media()
    // v5.4.255cc — Playlist persistence (see data/Playlist.kt).
    private val playlistDao = db.playlists()

    // v5.4.212cc — Media playback state
    private val _nowPlayingMedia = MutableStateFlow<com.tebogo.markvault.data.MediaItem?>(null)
    val nowPlayingMedia: StateFlow<com.tebogo.markvault.data.MediaItem?> = _nowPlayingMedia
    /** True while an Android Auto media browser is connected to PlaybackService. */
    val androidAutoConnected: StateFlow<Boolean> = com.tebogo.markvault.data.PlaybackRouteState.androidAutoConnected
    private val _mediaSearchResults = MutableStateFlow<List<com.tebogo.markvault.data.MediaItem>>(emptyList())
    val mediaSearchResults: StateFlow<List<com.tebogo.markvault.data.MediaItem>> = _mediaSearchResults
    private val _jwSearchResults = MutableStateFlow<List<com.tebogo.markvault.data.MediaItem>>(emptyList())
    val jwSearchResults: StateFlow<List<com.tebogo.markvault.data.MediaItem>> = _jwSearchResults
    // v5.4.389cc — Caption hits have their own state/pipeline. They are never
    // merged into mediaSearchResults, semanticMediaResults, notes, chunks, or
    // embeddings; SearchScreen combines them only for presentation.
    private val _captionVideoResults = MutableStateFlow<List<com.tebogo.markvault.data.MediaItem>>(emptyList())
    val captionVideoResults: StateFlow<List<com.tebogo.markvault.data.MediaItem>> = _captionVideoResults
    private var mediaSearchJob: Job? = null
    private var captionSearchJob: Job? = null
    private val _jwCategories = MutableStateFlow<List<com.tebogo.markvault.network.JwCategory>>(emptyList())
    val jwCategories: StateFlow<List<com.tebogo.markvault.network.JwCategory>> = _jwCategories
    private val _mediaSearchBusy = MutableStateFlow(false)
    val mediaSearchBusy: StateFlow<Boolean> = _mediaSearchBusy

    private val _semanticMediaResults = MutableStateFlow<List<com.tebogo.markvault.data.MediaItem>>(emptyList())
    private var _semanticMediaQuery: String = ""
    private var mediaSemanticIndexJob: Job? = null
    // v5.4.252cc — "Recently searched" media for HomeScreen: sourced from
    // the offline media cache (media_items, cachedAt-sorted) that
    // SearchScreen/JwVideoBrowseScreen already feed via searchMedia()/
    // cacheMediaItems() — every video/audio item the user has recently
    // come across via search or folder browsing, regardless of whether
    // they played it. Distinct from recentlyPlayedMedia below
    // (lastPlayedAt-sorted — playback history only).
    private val _recentMediaDiscovered = MutableStateFlow<List<com.tebogo.markvault.data.MediaItem>>(emptyList())
    val recentMediaDiscovered: StateFlow<List<com.tebogo.markvault.data.MediaItem>> = _recentMediaDiscovered
    // v5.4.254cc — Favourited media (video/audio), mirroring how notes
    // already have their own favouriteNotes StateFlow.
    private val _favouriteMedia = MutableStateFlow<List<com.tebogo.markvault.data.MediaItem>>(emptyList())
    val favouriteMedia: StateFlow<List<com.tebogo.markvault.data.MediaItem>> = _favouriteMedia

    // v5.4.255cc — Playback queue state ("Now Playing Queue"). _currentQueue
    // is the app-level list in the order it was loaded (NOT re-sorted by
    // shuffle — shuffle changes PLAYBACK order via the Player itself;
    // this list stays in its original order so the queue UI reads like a
    // normal playlist with a "now playing" marker, same as most media
    // players present it). _currentQueueIndex is kept in sync by the
    // Player.Listener registered in ensureMediaControllerConnecting().
    private val _currentQueue = MutableStateFlow<List<com.tebogo.markvault.data.MediaItem>>(emptyList())
    val currentQueue: StateFlow<List<com.tebogo.markvault.data.MediaItem>> = _currentQueue
    private val _currentQueueIndex = MutableStateFlow(0)
    val currentQueueIndex: StateFlow<Int> = _currentQueueIndex
    private val _shuffleEnabled = MutableStateFlow(false)
    val shuffleEnabled: StateFlow<Boolean> = _shuffleEnabled
    private val _repeatMode = MutableStateFlow(androidx.media3.common.Player.REPEAT_MODE_OFF)
    val repeatMode: StateFlow<Int> = _repeatMode

    // v5.4.396cc — Transient true-immersive media fullscreen state. This is
    // deliberately not persisted: it exists only to let outer UI shells hide
    // themselves while MediaPlayerScreen owns the complete display.
    private val _mediaPlayerFullscreen = MutableStateFlow(false)
    val mediaPlayerFullscreen: StateFlow<Boolean> = _mediaPlayerFullscreen.asStateFlow()
    fun setMediaPlayerFullscreen(fullscreen: Boolean) {
        _mediaPlayerFullscreen.value = fullscreen
    }

    // v5.4.255cc — Named, persisted playlists (see data/Playlist.kt).
    private val _playlists = MutableStateFlow<List<com.tebogo.markvault.data.Playlist>>(emptyList())
    val playlists: StateFlow<List<com.tebogo.markvault.data.Playlist>> = _playlists

    fun setNowPlayingMedia(item: com.tebogo.markvault.data.MediaItem?) {
        _nowPlayingMedia.value = item
    }

    // v5.4.233cc — Shared MediaController connected to PlaybackService.
    // ALL playback (browse screen, search-result badges, mini-player)
    // routes through this single controller so there is only ever one
    // active ExoPlayer instance, living in a real foreground Service that
    // survives the app being minimized/backgrounded.
    @Volatile private var mediaController: androidx.media3.session.MediaController? = null
    @Volatile private var controllerFuture:
        com.google.common.util.concurrent.ListenableFuture<androidx.media3.session.MediaController>? = null

    // v5.4.288cc — Caption defaults/transcript capture are isolated from the
    // article search pipeline. One attempt per playing video avoids re-enabling
    // CC after the user explicitly turns it off from the track dialog.
    private val captionDefaultAttempted = mutableSetOf<String>()
    private val transcriptExtractionJobs = java.util.concurrent.ConcurrentHashMap<String, Job>()
    private var bulkCaptionDownloadJob: Job? = null
    private val _bulkCaptionDownloadState = MutableStateFlow(BulkCaptionDownloadState())
    val bulkCaptionDownloadState: StateFlow<BulkCaptionDownloadState> = _bulkCaptionDownloadState.asStateFlow()

    private var deleteCcJob: Job? = null
    private val _deleteCcProgress = MutableStateFlow(CacheDeleteProgress())
    val deleteCcProgress: StateFlow<CacheDeleteProgress> = _deleteCcProgress.asStateFlow()

    private var clearMediaCacheJob: Job? = null
    private val _clearMediaCacheProgress = MutableStateFlow(CacheDeleteProgress())
    val clearMediaCacheProgress: StateFlow<CacheDeleteProgress> = _clearMediaCacheProgress.asStateFlow()

    private val _recentlyPlayedMedia = MutableStateFlow<List<com.tebogo.markvault.data.MediaItem>>(emptyList())
    val recentlyPlayedMedia: StateFlow<List<com.tebogo.markvault.data.MediaItem>> = _recentlyPlayedMedia

    /** Kick off (idempotent) the async connection to PlaybackService. */
    private fun ensureMediaControllerConnecting() {
        if (mediaController != null || controllerFuture != null) return
        val context = getApplication<Application>()
        val sessionToken = androidx.media3.session.SessionToken(
            context,
            android.content.ComponentName(context, com.tebogo.markvault.service.PlaybackService::class.java)
        )
        val future = androidx.media3.session.MediaController.Builder(context, sessionToken).buildAsync()
        controllerFuture = future
        future.addListener(
            {
                mediaController = runCatching { future.get() }.getOrNull()
                // v5.4.255cc — Keep queue state in sync with whatever the
                // player is actually doing: auto-advance to the next
                // queued item, a manual next/previous, or shuffle
                // reordering all land here. Registered once per
                // controller connection (this callback only fires once).
                mediaController?.addListener(object : androidx.media3.common.Player.Listener {
                    override fun onMediaItemTransition(
                        mediaItem: androidx.media3.common.MediaItem?,
                        reason: Int
                    ) {
                        syncQueuePositionFromController()
                        ensureDefaultCaptionTrack()
                    }
                    override fun onTracksChanged(tracks: androidx.media3.common.Tracks) {
                        ensureDefaultCaptionTrack(tracks)
                    }
                    override fun onCues(cueGroup: androidx.media3.common.text.CueGroup) {
                        capturePlayingCaptionCue(cueGroup)
                    }
                    override fun onShuffleModeEnabledChanged(shuffleModeEnabled: Boolean) {
                        _shuffleEnabled.value = shuffleModeEnabled
                    }
                    override fun onRepeatModeChanged(repeatMode: Int) {
                        _repeatMode.value = repeatMode
                    }
                })
                // If Android Auto started playback before the phone UI connected,
                // there may be no transition callback after this listener is
                // attached. Synchronize the already-current session item now.
                syncQueuePositionFromController()
                ensureDefaultCaptionTrack()
            },
            com.google.common.util.concurrent.MoreExecutors.directExecutor()
        )
    }

    /**
     * v5.4.255cc — Reads the controller's current queue index and looks
     * up the matching app-level MediaItem from _currentQueue (already
     * populated when the queue was loaded) — no DB hit needed on every
     * track change, just an index lookup into an already-known list.
     */
    private fun syncQueuePositionFromController() {
        val controller = mediaController ?: return
        val idx = controller.currentMediaItemIndex
        _currentQueueIndex.value = idx
        val current = _currentQueue.value.getOrNull(idx)
            ?: controller.currentMediaItem?.let(::mediaItemFromSessionMetadata)
            ?: return
        _nowPlayingMedia.value = current
        maybeExtractVideoTranscript(current)
        if (current.id > 0L) {
            viewModelScope.launch(Dispatchers.IO) {
                runCatching {
                    mediaDao.updatePlayback(current.id, System.currentTimeMillis(), 0L)
                }
            }
        }
    }

    /**
     * Rebuild MarkVault's rich MediaItem when playback was initiated by Android
     * Auto instead of by a phone-side queue. PlaybackService embeds these
     * fields in MediaMetadata.extras specifically so the phone player can show
     * the correct artwork, language, lyrics and transcript for car-started
     * playback without guessing from a title or waiting for a database race.
     */
    private fun mediaItemFromSessionMetadata(
        sessionItem: androidx.media3.common.MediaItem
    ): com.tebogo.markvault.data.MediaItem? {
        val extras = sessionItem.mediaMetadata.extras ?: return null
        val jwKey = extras.getString("markvault.jwKey").orEmpty()
        val title = extras.getString("markvault.title").orEmpty()
            .ifBlank { sessionItem.mediaMetadata.title?.toString().orEmpty() }
        if (jwKey.isBlank() && title.isBlank()) return null
        return com.tebogo.markvault.data.MediaItem(
            id = extras.getLong("markvault.id", 0L),
            title = title,
            description = extras.getString("markvault.description").orEmpty(),
            durationMs = extras.getLong("markvault.durationMs", 0L),
            thumbnailUrl = extras.getString("markvault.thumbnailUrl").orEmpty(),
            streamUrl = extras.getString("markvault.streamUrl").orEmpty(),
            localPath = extras.getString("markvault.localPath").orEmpty(),
            mediaType = extras.getString("markvault.mediaType").orEmpty().ifBlank { "audio" },
            mimeType = extras.getString("markvault.mimeType").orEmpty(),
            jwKey = jwKey,
            scriptureRefs = extras.getString("markvault.scriptureRefs").orEmpty(),
            category = extras.getString("markvault.category").orEmpty(),
            subtitleUrl = extras.getString("markvault.subtitleUrl").orEmpty(),
            subtitleLanguage = extras.getString("markvault.subtitleLanguage").orEmpty().ifBlank { "E" },
            contentLanguage = extras.getString("markvault.contentLanguage").orEmpty().ifBlank { "E" }
        )
    }

    /** v5.4.288cc — Enable the first supported caption track once per video. */
    private fun ensureDefaultCaptionTrack(
        suppliedTracks: androidx.media3.common.Tracks? = null
    ) {
        val controller = mediaController ?: return
        val current = _nowPlayingMedia.value ?: return
        if (!current.mediaType.equals("video", ignoreCase = true)) return
        val identity = current.jwKey.ifBlank { current.id.toString() }
        if (identity in captionDefaultAttempted) return

        val tracks = suppliedTracks ?: controller.currentTracks
        val textGroups = tracks.groups.filter {
            it.type == androidx.media3.common.C.TRACK_TYPE_TEXT && it.isSupported
        }
        if (textGroups.isEmpty()) return
        if (textGroups.any { g -> (0 until g.length).any { g.isTrackSelected(it) } }) {
            captionDefaultAttempted += identity
            return
        }

        val group = textGroups.firstOrNull { it.length > 0 } ?: return
        captionDefaultAttempted += identity
        runCatching {
            controller.trackSelectionParameters = controller.trackSelectionParameters.buildUpon()
                .setTrackTypeDisabled(androidx.media3.common.C.TRACK_TYPE_TEXT, false)
                .setOverrideForType(
                    androidx.media3.common.TrackSelectionOverride(group.mediaTrackGroup, listOf(0))
                )
                .build()
        }.onFailure {
            android.util.Log.w("MarkVault", "Unable to enable default video captions", it)
        }
    }

    /** Capture Media3-rendered cues when a complete caption file was unavailable. */
    private fun capturePlayingCaptionCue(cueGroup: androidx.media3.common.text.CueGroup) {
        if (!autoExtractVideoCaptions.value) return
        val current = _nowPlayingMedia.value ?: return
        if (!current.mediaType.equals("video", ignoreCase = true)) return
        val text = cueGroup.cues.mapNotNull { it.text?.toString()?.trim() }
            .filter { it.isNotBlank() }
            .distinct()
            .joinToString(" ")
        if (text.isBlank()) return
        val position = mediaController?.currentPosition?.coerceAtLeast(0L) ?: 0L
        val context = getApplication<Application>()
        viewModelScope.launch(Dispatchers.IO) {
            runCatching {
                com.tebogo.markvault.data.VideoTranscriptStore.appendPlaybackCue(
                    context, current, position, text
                )
            }
        }
    }

    /**
     * Fetch an advertised JW.org VTT track once, immediately after playback
     * starts. This runs independently of playback and article search.
     */
    private fun maybeExtractVideoTranscript(item: com.tebogo.markvault.data.MediaItem) {
        if (!autoExtractVideoCaptions.value) return
        if (!item.mediaType.equals("video", ignoreCase = true)) return
        if (item.subtitleUrl.isBlank()) return
        val identity = item.jwKey.ifBlank { item.id.toString() }
        if (transcriptExtractionJobs[identity]?.isActive == true) return

        transcriptExtractionJobs[identity] = viewModelScope.launch(Dispatchers.IO) {
            val context = getApplication<Application>()
            val token = "video-caption-$identity"
            try {
                if (com.tebogo.markvault.data.VideoTranscriptStore.hasComplete(context, item)) return@launch
                startProtectedTask(token, "Caching captions • ${item.title.take(40)}")
                com.tebogo.markvault.data.VideoTranscriptStore.fetchComplete(context, item)
            } catch (t: Throwable) {
                if (t !is kotlinx.coroutines.CancellationException) {
                    android.util.Log.w("MarkVault", "Video caption extraction failed: ${item.title}", t)
                }
            } finally {
                stopProtectedTask(token)
                transcriptExtractionJobs.remove(identity)
            }
        }
    }

    /** Suspends briefly (up to 3s) for the controller to connect, then returns it (or null). */
    private suspend fun awaitMediaController(): androidx.media3.session.MediaController? {
        ensureMediaControllerConnecting()
        var waited = 0
        while (mediaController == null && waited < 3000) {
            kotlinx.coroutines.delay(50L)
            waited += 50
        }
        return mediaController
    }

    /** Exposed for screens (MediaPlayerScreen, FloatingMediaPopup) that need to attach a PlayerView. */
    fun getMediaController(): androidx.media3.session.MediaController? {
        ensureMediaControllerConnecting()
        return mediaController
    }

    private data class VideoQualityVariant(val height: Int, val url: String)

    /** Parse the exact "label\turl" representation produced by JwMediaApi. */
    private fun videoQualityVariants(m: com.tebogo.markvault.data.MediaItem): List<VideoQualityVariant> =
        m.qualityOptions.lineSequence().mapNotNull { line ->
            val parts = line.split("\t", limit = 2)
            if (parts.size != 2 || parts[1].isBlank()) return@mapNotNull null
            val height = Regex("(\\d+)").find(parts[0])?.groupValues?.getOrNull(1)?.toIntOrNull() ?: 0
            VideoQualityVariant(height = height, url = parts[1])
        }.toList()

    /**
     * v5.4.401cc — Resolve the actual URL used by every phone/TV/fullscreen/Cast
     * playback entry point. Universal mode only affects streamed videos that
     * advertise alternate renditions; local files and audio are never replaced
     * with a network URL. For a missing exact target, prefer the highest quality
     * not exceeding it; if none exists, use the lowest available quality above it.
     */
    private fun resolvePlaybackUrl(
        m: com.tebogo.markvault.data.MediaItem,
        universalEnabled: Boolean = universalVideoResolutionEnabled.value,
        universalTarget: String = universalVideoResolution.value
    ): String {
        if (m.localPath.isNotBlank()) return m.localPath
        if (!m.mediaType.equals("video", ignoreCase = true) || !universalEnabled) return m.streamUrl
        val variants = videoQualityVariants(m)
        if (variants.isEmpty()) return m.streamUrl
        if (universalTarget == "best") {
            return variants.maxWithOrNull(compareBy<VideoQualityVariant> { it.height }.thenBy { it.url.length })?.url ?: m.streamUrl
        }
        val target = universalTarget.toIntOrNull() ?: 720
        variants.firstOrNull { it.height == target }?.let { return it.url }
        variants.filter { it.height in 1..target }.maxByOrNull { it.height }?.let { return it.url }
        variants.filter { it.height > target }.minByOrNull { it.height }?.let { return it.url }
        return variants.firstOrNull()?.url ?: m.streamUrl
    }

    /** v5.4.255cc — Shared Media3 MediaItem builder, used by playMedia and playQueue alike. */
    private fun buildExoMediaItem(
        m: com.tebogo.markvault.data.MediaItem,
        universalEnabled: Boolean = universalVideoResolutionEnabled.value,
        universalTarget: String = universalVideoResolution.value
    ): androidx.media3.common.MediaItem {
        val playUrl = resolvePlaybackUrl(m, universalEnabled, universalTarget)
        return androidx.media3.common.MediaItem.Builder()
            .setUri(playUrl)
            .apply {
                if (m.mimeType.isNotBlank()) setMimeType(m.mimeType)
                if (m.subtitleUrl.isNotBlank() && m.mediaType.equals("video", ignoreCase = true)) {
                    val subtitle = androidx.media3.common.MediaItem.SubtitleConfiguration.Builder(
                        android.net.Uri.parse(m.subtitleUrl)
                    )
                        .setMimeType(androidx.media3.common.MimeTypes.TEXT_VTT)
                        .setSelectionFlags(androidx.media3.common.C.SELECTION_FLAG_DEFAULT)
                        .build()
                    setSubtitleConfigurations(listOf(subtitle))
                }
            }
            .setMediaId(m.id.toString())
            .setMediaMetadata(
                androidx.media3.common.MediaMetadata.Builder()
                    .setTitle(m.title)
                    .setArtist(
                        if (m.mediaType == "audio") "MarkVault \u2022 Audio"
                        else "MarkVault \u2022 Video"
                    )
                    .setExtras(android.os.Bundle().apply {
                        // The PlaybackService owns the actual ExoPlayer. Put the
                        // capture preference on the MediaItem so caption cues can
                        // be persisted at the source instead of relying on
                        // MediaController IPC to forward onCues callbacks.
                        putBoolean("markvault.captureVideoCaptions", autoExtractVideoCaptions.value)
                    })
                    .apply {
                        if (m.thumbnailUrl.isNotBlank())
                            setArtworkUri(android.net.Uri.parse(m.thumbnailUrl))
                    }
                    .build()
            )
            .build()
    }

    /**
     * v5.4.288cc — Legacy cached media rows pre-date subtitleUrl. Resolve the
     * exact JW natural key only when needed, then persist the caption metadata.
     * This is media-only I/O and never touches note/article embeddings.
     */
    private suspend fun enrichVideoCaptionMetadata(
        item: com.tebogo.markvault.data.MediaItem
    ): com.tebogo.markvault.data.MediaItem = withContext(Dispatchers.IO) {
        if (!item.mediaType.equals("video", ignoreCase = true) || item.jwKey.isBlank()) return@withContext item
        val needsSubtitle = item.subtitleUrl.isBlank()
        val needsQualities = item.qualityOptions.isBlank()
        if (!needsSubtitle && !needsQualities) return@withContext item

        val resolved = runCatching {
            com.tebogo.markvault.network.JwMediaApi.mediaByNaturalKey(
                item.jwKey,
                item.subtitleLanguage.ifBlank { "E" }
            )
        }.getOrNull() ?: return@withContext item

        val enriched = item.copy(
            subtitleUrl = if (needsSubtitle && resolved.subtitleUrl.isNotBlank()) resolved.subtitleUrl else item.subtitleUrl,
            subtitleLanguage = if (needsSubtitle && resolved.subtitleUrl.isNotBlank()) resolved.subtitleLanguage.ifBlank { item.subtitleLanguage } else item.subtitleLanguage,
            qualityOptions = if (needsQualities && resolved.qualityOptions.isNotBlank()) resolved.qualityOptions else item.qualityOptions
        )
        if (enriched != item) runCatching { mediaDao.upsert(enriched) }
        enriched
    }

    /**
     * v5.4.233cc — Canonical playback start. Routes through the shared
     * PlaybackService/MediaController so audio/video keeps playing when
     * MarkVault is backgrounded, and records the play in history the
     * moment it starts (not just on exit), so "recently played" is
     * accurate even for a play that gets interrupted quickly.
     *
     * v5.4.255cc — Single-item plays still work exactly as before (share
     * links, the chooser screen, favouriting a currently-playing item,
     * etc. all still call this unchanged) — it just also sets the queue
     * state to a "queue of one" so the Now Playing Queue screen reads
     * sensibly rather than showing stale data from a previous queue.
     */
    fun playMedia(item: com.tebogo.markvault.data.MediaItem) {
        viewModelScope.launch {
            val requestedTranscriptStart = if (
                item.description.startsWith(com.tebogo.markvault.data.VideoTranscriptStore.RESULT_PREFIX)
            ) item.resumePositionMs.coerceAtLeast(0L) else -1L
            val saved = enrichVideoCaptionMetadata(findOrSaveMedia(item))
            val playUrl = saved.localPath.ifBlank { saved.streamUrl }
            if (playUrl.isBlank()) return@launch
            val controller = awaitMediaController() ?: return@launch
            val startAt = if (requestedTranscriptStart >= 0L) requestedTranscriptStart else saved.resumePositionMs
            controller.setMediaItem(buildExoMediaItem(saved), startAt)
            controller.prepare()
            controller.play()
            maybeExtractVideoTranscript(saved)
            _currentQueue.value = listOf(saved)
            _currentQueueIndex.value = 0
            _nowPlayingMedia.value = saved
            runCatching {
                mediaDao.updatePlayback(saved.id, System.currentTimeMillis(), saved.resumePositionMs)
            }
            loadRecentlyPlayed()
        }
    }

    /**
     * v5.4.297cc — Hand HTML5 media from WebViewer to the shared player at
     * the WebView's current playback position. Kept separate from playMedia()
     * so normal library resume/transcript semantics remain untouched.
     */
    fun playWebMedia(item: com.tebogo.markvault.data.MediaItem, startPositionMs: Long) {
        viewModelScope.launch {
            val saved = enrichVideoCaptionMetadata(findOrSaveMedia(item))
            val playUrl = saved.localPath.ifBlank { saved.streamUrl }
            if (playUrl.isBlank()) return@launch
            val controller = awaitMediaController() ?: return@launch
            controller.setMediaItem(buildExoMediaItem(saved), startPositionMs.coerceAtLeast(0L))
            controller.prepare()
            controller.play()
            maybeExtractVideoTranscript(saved)
            _currentQueue.value = listOf(saved)
            _currentQueueIndex.value = 0
            _nowPlayingMedia.value = saved
            runCatching { mediaDao.updatePlayback(saved.id, System.currentTimeMillis(), startPositionMs.coerceAtLeast(0L)) }
            loadRecentlyPlayed()
        }
    }

    /**
     * v5.4.255cc — Load a full queue: every item in [items] becomes
     * playable in order starting at [startIndex], and — since Media3's
     * Player naturally advances through a multi-item queue on its own —
     * playback continues automatically from one to the next without any
     * extra "detect finished, load next" logic needed on MarkVault's
     * side. Shuffle/repeat (set separately via toggleShuffle/
     * cycleRepeatMode) apply to whatever queue is loaded here. Works
     * identically whether the active player is local ExoPlayer or
     * Chromecast's CastPlayer — both implement the same Player interface
     * PlaybackService routes through, and transferToCast/transferToLocal
     * carry the whole queue across when casting starts/stops.
     */
    fun playQueue(items: List<com.tebogo.markvault.data.MediaItem>, startIndex: Int = 0) {
        if (items.isEmpty()) return
        viewModelScope.launch {
            val saved = items.map { findOrSaveMedia(it) }
            // Queue playback previously skipped legacy caption enrichment.
            // Enrich videos before they enter ExoPlayer so CC/full-transcript
            // extraction works identically for single-item and queue playback.
            val captionReady = saved.map { enrichVideoCaptionMetadata(it) }
            val playable = captionReady.filter { it.localPath.isNotBlank() || it.streamUrl.isNotBlank() }
            if (playable.isEmpty()) return@launch
            val clampedStart = startIndex.coerceIn(0, playable.size - 1)
            val controller = awaitMediaController() ?: return@launch
            val exoItems = playable.map { buildExoMediaItem(it) }
            controller.setMediaItems(exoItems, clampedStart, playable[clampedStart].resumePositionMs)
            controller.prepare()
            controller.play()
            _currentQueue.value = playable
            _currentQueueIndex.value = clampedStart
            _nowPlayingMedia.value = playable[clampedStart]
            maybeExtractVideoTranscript(playable[clampedStart])
            runCatching {
                mediaDao.updatePlayback(
                    playable[clampedStart].id, System.currentTimeMillis(), playable[clampedStart].resumePositionMs
                )
            }
            loadRecentlyPlayed()
        }
    }

    /**
     * v5.4.255cc — What every browse/search list's "tap to play" should
     * call: if Continuous Play is on, queues the REST of [contextList]
     * too (starting at [item]) so playback continues through the list
     * automatically — traditional MP3-player behavior. If off, plays
     * just [item] via the existing single-item path.
     */
    fun playMediaFromList(item: com.tebogo.markvault.data.MediaItem, contextList: List<com.tebogo.markvault.data.MediaItem>) {
        // Transcript hits carry a precise caption timestamp in resumePositionMs.
        // Route them through single-item playback so Continuous Play cannot
        // replace that search-hit timestamp with the video's ordinary resume point.
        if (item.description.startsWith(com.tebogo.markvault.data.VideoTranscriptStore.RESULT_PREFIX) ||
            !continuousPlayEnabled.value || contextList.size <= 1) {
            playMedia(item)
            return
        }
        val idx = contextList.indexOfFirst {
            (it.jwKey.isNotBlank() && it.jwKey == item.jwKey) || (it.id != 0L && it.id == item.id) || it === item
        }
        playQueue(contextList, if (idx >= 0) idx else 0)
    }

    /** v5.4.255cc — Toggle shuffle for whichever player is currently active (local or cast). */
    fun toggleShuffle() {
        viewModelScope.launch {
            val controller = awaitMediaController() ?: return@launch
            controller.shuffleModeEnabled = !controller.shuffleModeEnabled
            _shuffleEnabled.value = controller.shuffleModeEnabled
        }
    }

    /** v5.4.255cc — Cycle OFF → ALL → ONE → OFF, same order most media players use. */
    fun cycleRepeatMode() {
        viewModelScope.launch {
            val controller = awaitMediaController() ?: return@launch
            val next = when (controller.repeatMode) {
                androidx.media3.common.Player.REPEAT_MODE_OFF -> androidx.media3.common.Player.REPEAT_MODE_ALL
                androidx.media3.common.Player.REPEAT_MODE_ALL -> androidx.media3.common.Player.REPEAT_MODE_ONE
                else -> androidx.media3.common.Player.REPEAT_MODE_OFF
            }
            controller.repeatMode = next
            _repeatMode.value = next
        }
    }

    fun playNextInQueue() {
        viewModelScope.launch {
            val controller = awaitMediaController() ?: return@launch
            if (controller.hasNextMediaItem()) controller.seekToNext()
        }
    }

    fun playPreviousInQueue() {
        viewModelScope.launch {
            val controller = awaitMediaController() ?: return@launch
            if (controller.hasPreviousMediaItem()) controller.seekToPrevious()
        }
    }

    /** v5.4.255cc — Jump directly to a specific queue position (tap an item in the Now Playing Queue screen). */
    fun seekToQueueIndex(index: Int) {
        viewModelScope.launch {
            val controller = awaitMediaController() ?: return@launch
            if (index in 0 until controller.mediaItemCount) controller.seekTo(index, 0L)
        }
    }

    // ── Playlists ────────────────────────────────────────────────────────

    /** v5.4.255cc — Load (or refresh) the playlists list. */
    fun loadPlaylists() {
        viewModelScope.launch(Dispatchers.IO) {
            _playlists.value = runCatching { playlistDao.getAll() }.getOrElse { emptyList() }
        }
    }

    /** Create a new playlist, optionally seeded with items (e.g. from a multi-select "add to playlist"). */
    fun createPlaylist(name: String, initialItems: List<com.tebogo.markvault.data.MediaItem> = emptyList()) {
        viewModelScope.launch(Dispatchers.IO) {
            val saved = initialItems.map { findOrSaveMedia(it) }
            val pl = com.tebogo.markvault.data.Playlist(
                name = name.ifBlank { "Untitled Playlist" },
                mediaIds = com.tebogo.markvault.data.Playlist.joinIds(saved.map { it.id })
            )
            runCatching { playlistDao.upsert(pl) }
            _playlists.value = runCatching { playlistDao.getAll() }.getOrElse { _playlists.value }
        }
    }

    /** Append items to an existing playlist (deduplicated). */
    fun addToPlaylist(playlistId: Long, items: List<com.tebogo.markvault.data.MediaItem>) {
        viewModelScope.launch(Dispatchers.IO) {
            val saved = items.map { findOrSaveMedia(it) }
            val existing = runCatching { playlistDao.getById(playlistId) }.getOrNull() ?: return@launch
            val merged = (existing.idList() + saved.map { it.id }).distinct()
            runCatching {
                playlistDao.upsert(existing.copy(mediaIds = com.tebogo.markvault.data.Playlist.joinIds(merged)))
            }
            _playlists.value = runCatching { playlistDao.getAll() }.getOrElse { _playlists.value }
        }
    }

    fun removeFromPlaylist(playlistId: Long, mediaId: Long) {
        viewModelScope.launch(Dispatchers.IO) {
            val existing = runCatching { playlistDao.getById(playlistId) }.getOrNull() ?: return@launch
            val updated = existing.idList().filter { it != mediaId }
            runCatching {
                playlistDao.upsert(existing.copy(mediaIds = com.tebogo.markvault.data.Playlist.joinIds(updated)))
            }
            _playlists.value = runCatching { playlistDao.getAll() }.getOrElse { _playlists.value }
        }
    }

    fun deletePlaylist(id: Long) {
        viewModelScope.launch(Dispatchers.IO) {
            runCatching { playlistDao.delete(id) }
            _playlists.value = runCatching { playlistDao.getAll() }.getOrElse { _playlists.value }
        }
    }

    /** Resolve a playlist's stored IDs into full MediaItem rows, in playlist order. */
    suspend fun getPlaylistContents(playlist: com.tebogo.markvault.data.Playlist): List<com.tebogo.markvault.data.MediaItem> =
        kotlinx.coroutines.withContext(Dispatchers.IO) {
            playlist.idList().mapNotNull { runCatching { mediaDao.getById(it) }.getOrNull() }
        }

    /** Load a whole playlist as the current queue and start playing it. */
    fun playPlaylist(playlist: com.tebogo.markvault.data.Playlist, startIndex: Int = 0) {
        viewModelScope.launch {
            val items = getPlaylistContents(playlist)
            if (items.isNotEmpty()) playQueue(items, startIndex)
        }
    }

    /** Load (or refresh) the playback history list. */
    fun loadRecentlyPlayed() {
        viewModelScope.launch(Dispatchers.IO) {
            _recentlyPlayedMedia.value = runCatching { mediaDao.getRecentlyPlayed(20) }.getOrElse { emptyList() }
        }
    }

    /**
     * v5.4.252cc — Load (or refresh) the "recently searched" media list
     * for HomeScreen — the offline media cache's own recency order
     * (cachedAt DESC), not tied to playback at all.
     */
    fun loadRecentMediaDiscovered() {
        viewModelScope.launch(Dispatchers.IO) {
            _recentMediaDiscovered.value = runCatching { mediaDao.getRecent(20) }.getOrElse { emptyList() }
        }
    }

    /** v5.4.254cc — Load (or refresh) the favourited media list. */
    fun loadFavouriteMedia() {
        viewModelScope.launch(Dispatchers.IO) {
            _favouriteMedia.value = runCatching { mediaDao.favourites() }.getOrElse { emptyList() }
        }
    }

    /**
     * v5.4.254cc — Toggle a media item's favourite flag and refresh both
     * the favourites list and any other already-loaded media lists that
     * might contain this same item (recently played / recently searched
     * / current search results) so a star toggled on one screen shows
     * correctly updated everywhere else too, without a full app restart.
     */
    fun toggleMediaFavourite(item: com.tebogo.markvault.data.MediaItem) {
        val newFav = if (item.isFavourite == 1) 0 else 1
        viewModelScope.launch(Dispatchers.IO) {
            if (item.id != 0L) {
                runCatching { mediaDao.setFavourite(item.id, newFav) }
            }
            _favouriteMedia.value = runCatching { mediaDao.favourites() }.getOrElse { emptyList() }
            _recentlyPlayedMedia.value = runCatching { mediaDao.getRecentlyPlayed(20) }.getOrElse { _recentlyPlayedMedia.value }
            _recentMediaDiscovered.value = runCatching { mediaDao.getRecent(20) }.getOrElse { _recentMediaDiscovered.value }
            val updated = if (item.id != 0L) runCatching { mediaDao.getById(item.id) }.getOrNull() else null
            if (updated != null && _nowPlayingMedia.value?.id == updated.id) {
                _nowPlayingMedia.value = updated
            }
        }
    }

    /**
     * v5.4.253cc — Single-key offline cache lookup, exposed for
     * UrlShareChooserScreen's hidden-WebView fallback: once real JS
     * execution on a shared page reveals a JW.org natural key in the
     * hydrated DOM (a data-mediaid/data-video-mediaid attribute that
     * wasn't present in the raw server HTML, and wasn't in the share
     * URL's own query string either — a genuinely new signal, not a
     * repeat of resolveMediaInfoOnly()'s own cache check), this looks it
     * up the same way findOrSaveMedia()/resolveMediaInfoOnly() already do.
     */
    suspend fun lookupCachedMediaByKey(key: String): com.tebogo.markvault.data.MediaItem? =
        kotlinx.coroutines.withContext(kotlinx.coroutines.Dispatchers.IO) {
            runCatching { mediaDao.getByJwKey(key) }.getOrNull()
        }

    /**
     * v5.4.234cc — When an incoming link (shared into MarkVault, or opened
     * via ACTION_VIEW) is a video/audio link, load and play it instead of
     * falling through to the browser or URL-import chooser. Returns true
     * if playback was started (caller navigates to the player), false if
     * the URL isn't a recognized media link (caller's existing behavior
     * runs unchanged — this never silently swallows a non-media link).
     *
     * Two cases, handled at different confidence levels:
     *   1. Direct file URL (.mp4/.mp3/etc.) — played immediately via
     *      ExoPlayer streaming the URL directly. No API lookup needed;
     *      100% reliable, zero guessing.
     *   2. JW.org video/audio PAGE URL — there is no verified JW.org
     *      endpoint for resolving one item by its internal key (only the
     *      category-listing endpoint is confirmed working), so rather
     *      than invent an unverified API call, the URL's readable path
     *      slug is converted into a search phrase and run through the
     *      already-verified fuzzy search(). Plays the best match if one
     *      is found; otherwise returns false so the caller's existing,
     *      safe behavior (open in browser) still runs.
     */
    /**
     * v5.4.235cc — Resolve a URL to playable media info WITHOUT starting
     * playback or touching the DB. Used by the share chooser to show a
     * "Play Video" option with real title/thumbnail/duration BEFORE the
     * user commits to anything — separated from [tryPlayIncomingVideoLink]
     * (which calls this, then plays) so the chooser can show info-only.
     *
     * Returns null if [url] isn't a recognized video/audio link.
     */
    suspend fun resolveMediaInfoOnly(url: String): com.tebogo.markvault.data.MediaItem? {
        val kind = com.tebogo.markvault.util.MediaLinkDetector.classifySingleUrl(url) ?: return null

        if (com.tebogo.markvault.util.MediaLinkDetector.isDirectFileUrl(url)) {
            val title = runCatching { android.net.Uri.parse(url).lastPathSegment }
                .getOrNull()
                ?.substringBeforeLast('.')
                ?.replace(Regex("[-_]+"), " ")
                ?.trim()
                ?.ifBlank { null } ?: "Shared media"
            return com.tebogo.markvault.data.MediaItem(title = title, streamUrl = url, mediaType = kind)
        }

        // v5.4.244cc — PRIMARY: fetch the actual shared page and find the
        // real embedded video/audio in it (native <video>/<audio> tags,
        // JW.org's data-json-src manifest, or a raw media URL sitting in
        // the page's HTML). This is what "the page has a playable link in
        // it, find it" actually means — not a guess.
        runCatching {
            com.tebogo.markvault.network.PageMediaResolver.resolve(url)
        }.getOrNull()?.let { return it }

        // v5.4.252cc — JW.org "finder" deep links (jw.org/finder?...&
        // lank=pub-XXX_NNN_VIDEO) carry the real identifier as a QUERY
        // PARAMETER, not the URL path — confirmed by fetching an actual
        // finder URL and observing its redirect target, which lands on a
        // JS-rendered library shell with no extractable <video>/<audio>
        // markup in its server HTML (why PageMediaResolver above finds
        // nothing for these links). The path-slug fallback further below
        // never looked at query params at all, so a finder link always
        // fell through to searching the bare word "finder" — nothing
        // useful, silently. That was the actual root cause of shared
        // finder links producing no result.
        //
        // Fix: extract the key from lank/item/docid and check the LOCAL
        // OFFLINE CACHE for an exact match first — instant, free, and
        // grows over time as this key gets encountered elsewhere in the
        // app (browsing, searching), same table cacheMediaItems()/
        // searchMedia() already feed.
        val naturalKey = com.tebogo.markvault.util.MediaLinkDetector.extractNaturalKey(url)
        if (naturalKey != null) {
            val cached = kotlinx.coroutines.withContext(kotlinx.coroutines.Dispatchers.IO) {
                mediaDao.getByJwKey(naturalKey)
            }
            if (cached != null) return cached
        }

        // FALLBACK: if the page genuinely has no extractable media (e.g.
        // it lazy-loads the player via JS the raw HTML fetch can't see),
        // fall back to the slug-based fuzzy search as a last resort —
        // better than nothing, but the page-scan above is what should
        // normally succeed.
        val uri = runCatching { android.net.Uri.parse(url) }.getOrNull() ?: return null
        val pathSlug = uri.lastPathSegment?.replace(Regex("[-_]+"), " ")?.trim()
        val fragSlug = uri.fragment?.substringAfterLast('/')?.replace(Regex("[-_]+"), " ")?.trim()
        val slug = listOfNotNull(pathSlug, fragSlug)
            .filter { it.length >= 3 && !it.startsWith("pub-", ignoreCase = true) && !it.matches(Regex("^[a-z]{1,3}$")) }
            .maxByOrNull { s -> s.count { it.isLetter() } }
        if (slug.isNullOrBlank()) return null

        val results = runCatching {
            com.tebogo.markvault.network.JwMediaApi.search(slug, limit = 5)
        }.getOrElse { emptyList() }
        val best = results.firstOrNull() ?: return null
        // v5.4.252cc — When a natural key was found but wasn't cached, the
        // key's own _VIDEO/_AUDIO suffix is an authoritative signal for
        // media type — correct the fuzzy search's best guess with it
        // rather than trusting whatever type that unrelated guess carries.
        val keyType = naturalKey?.let { com.tebogo.markvault.util.MediaLinkDetector.mediaTypeFromKey(it) }
        return if (keyType != null && keyType != best.mediaType) best.copy(mediaType = keyType) else best
    }

    /**
     * v5.4.234cc — When an incoming link (opened via ACTION_VIEW) is a
     * video/audio link, load and play it directly. Returns true if
     * playback started (caller navigates to the player), false otherwise.
     */
    suspend fun tryPlayIncomingVideoLink(url: String): Boolean {
        val info = resolveMediaInfoOnly(url) ?: return false
        playMedia(info)
        return true
    }

    // v5.4.228cc — Floating popup player state (for in-search article media badges)
    data class MediaPopupRequest(val title: String, val url: String, val mediaType: String)
    private val _mediaPopupRequest = MutableStateFlow<MediaPopupRequest?>(null)
    val mediaPopupRequest: StateFlow<MediaPopupRequest?> = _mediaPopupRequest
    fun requestMediaPopup(title: String, url: String, mediaType: String) {
        // v5.4.233cc — Route through the canonical playMedia() path so
        // article-embedded video/audio badges ALSO survive backgrounding,
        // show notification controls, and count toward playback history —
        // not just JW.org browse-screen items.
        playMedia(
            com.tebogo.markvault.data.MediaItem(
                title = title, streamUrl = url, mediaType = mediaType
            )
        )
        _mediaPopupRequest.value = MediaPopupRequest(title, url, mediaType)
    }
    /**
     * v5.4.250cc — Overload for callers that already have a full,
     * DB/API-sourced [com.tebogo.markvault.data.MediaItem] (search
     * results, category browse cards) rather than just a bare title/url/
     * type extracted from note text. Routing the FULL item through
     * playMedia() (instead of rebuilding a bare one, as the 3-arg
     * overload above does) preserves jwKey — so findOrSaveMedia() can
     * match it against the existing cached row instead of inserting a
     * near-duplicate — plus thumbnailUrl, durationMs, qualityOptions,
     * and any resumePositionMs already recorded for it.
     */
    fun requestMediaPopup(item: com.tebogo.markvault.data.MediaItem) {
        playMedia(item)
        _mediaPopupRequest.value = MediaPopupRequest(item.title, item.streamUrl, item.mediaType)
    }
    fun dismissMediaPopup() { _mediaPopupRequest.value = null }

    /**
     * v5.4.226cc — Find or save a media item, returning the DB-assigned ID.
     * Called when a video from JW.org needs to be opened in the player.
     * If the item already exists in cache (matched by jwKey), returns it
     * unchanged. Otherwise inserts and returns a copy with the new ID.
     */
    suspend fun findOrSaveMedia(item: com.tebogo.markvault.data.MediaItem): com.tebogo.markvault.data.MediaItem =
        kotlinx.coroutines.withContext(kotlinx.coroutines.Dispatchers.IO) {
            if (item.jwKey.isNotBlank()) {
                val existing = mediaDao.getByJwKeyAndLanguage(item.jwKey, item.contentLanguage.ifBlank { "E" })
                if (existing != null) {
                    val subtitleChanged = item.subtitleUrl.isNotBlank() && existing.subtitleUrl != item.subtitleUrl
                    val qualitiesChanged = item.qualityOptions.isNotBlank() && existing.qualityOptions != item.qualityOptions
                    if (subtitleChanged || qualitiesChanged) {
                        val refreshed = existing.copy(
                            subtitleUrl = if (subtitleChanged) item.subtitleUrl else existing.subtitleUrl,
                            subtitleLanguage = if (subtitleChanged) item.subtitleLanguage.ifBlank { existing.subtitleLanguage } else existing.subtitleLanguage,
                            qualityOptions = if (qualitiesChanged) item.qualityOptions else existing.qualityOptions
                        )
                        mediaDao.upsert(refreshed)
                        return@withContext refreshed
                    }
                    return@withContext existing
                }
            }
            val newId = mediaDao.upsert(item)
            scheduleMediaSemanticIndexing()
            item.copy(id = newId)
        }

    /** v5.4.300cc — Contextual related-content discovery. Cached media is returned
     * first; the caller can then request the online-enriched pass. This deliberately
     * does not touch the main article semantic-search pipeline. */
    suspend fun findRelatedVideos(title: String, body: String = "", includeOnline: Boolean = true): List<com.tebogo.markvault.data.RelatedVideoMatch> = withContext(Dispatchers.IO) {
        val seed = (title + " " + body.take(1200)).lowercase()
        val stop = setOf("the","and","for","that","with","from","this","you","your","are","was","were","have","has","not","but","into","about","what","when","where","who","why","how")
        val terms = Regex("[\\p{L}\\p{N}]{3,}").findAll(seed).map { it.value }.filterNot { it in stop }.distinct().take(18).toList()
        fun score(m: com.tebogo.markvault.data.MediaItem): Pair<Int,String> {
            val hay = (m.title + " " + m.description + " " + m.scriptureRefs + " " + m.category).lowercase()
            val hits = terms.filter { hay.contains(it) }
            val titleHits = terms.count { m.title.lowercase().contains(it) }
            val first = hits.firstOrNull()
            val bodyIndex = first?.let { body.lowercase().indexOf(it) } ?: -1
            val excerpt = if (bodyIndex >= 0) {
                val start = (bodyIndex - 90).coerceAtLeast(0)
                val end = (bodyIndex + 220).coerceAtMost(body.length)
                body.substring(start, end).replace(Regex("\\s+"), " ").trim()
            } else title
            return (hits.size + titleHits * 2) to excerpt
        }
        fun mediaIdentity(m: com.tebogo.markvault.data.MediaItem): String = when {
            m.jwKey.isNotBlank() -> "jw:${m.jwKey.trim().lowercase()}"
            m.streamUrl.isNotBlank() -> "url:${m.streamUrl.trim()}"
            m.id > 0L -> "id:${m.id}"
            else -> "fallback:${m.title.trim().lowercase()}|${m.category.trim().lowercase()}"
        }
        val cachedMap = LinkedHashMap<String, com.tebogo.markvault.data.RelatedVideoMatch>()
        runCatching { mediaDao.getRecent(250) }.getOrElse { emptyList() }
            .asSequence().filter { it.mediaType == "video" }.map { it to score(it) }
            .filter { it.second.first > 0 }.sortedByDescending { it.second.first }.take(24)
            .map { com.tebogo.markvault.data.RelatedVideoMatch(it.first, it.second.second, true) }
            .forEach { cachedMap.putIfAbsent(mediaIdentity(it.item), it) }
        val cached = cachedMap.values.take(12)
        if (!includeOnline) return@withContext cached
        val q = title.trim().ifBlank { terms.take(6).joinToString(" ") }.take(160)
        val online = runCatching { com.tebogo.markvault.network.JwMediaApi.search(q, limit = 20) }.getOrElse { emptyList() }
            .filter { it.mediaType == "video" }.map { it to score(it) }.filter { it.second.first > 0 }
            .sortedByDescending { it.second.first }.take(12)
            .map { com.tebogo.markvault.data.RelatedVideoMatch(it.first, it.second.second, false) }
        val merged = LinkedHashMap<String, com.tebogo.markvault.data.RelatedVideoMatch>()
        (cached + online).forEach { merged.putIfAbsent(mediaIdentity(it.item), it) }
        merged.values.take(18)
    }

    suspend fun findRelatedArticles(media: com.tebogo.markvault.data.MediaItem): List<com.tebogo.markvault.data.RelatedArticleMatch> = withContext(Dispatchers.IO) {
        val seed = (media.title + " " + media.description + " " + media.scriptureRefs).lowercase()
        val terms = Regex("[\\p{L}\\p{N}]{3,}").findAll(seed).map { it.value }.distinct().take(10).toList()
        val fts = terms.take(6).joinToString(" OR ") { "\"${it.replace("\"", "")}\"" }
        if (fts.isBlank()) return@withContext emptyList()
        val hits = runCatching { dao.search(fts) }.getOrElse { emptyList() }.take(30)
        hits.mapNotNull { h ->
            val n = runCatching { dao.byId(h.id) }.getOrNull() ?: return@mapNotNull null
            val hay = (n.title + " " + n.content.take(2000)).lowercase()
            val matched = terms.filter { hay.contains(it) }.take(6)
            if (matched.isEmpty()) null else {
                val idx = n.content.lowercase().indexOf(matched.first())
                val excerpt = if (idx >= 0) {
                    val start = (idx - 90).coerceAtLeast(0)
                    val end = (idx + 260).coerceAtMost(n.content.length)
                    n.content.substring(start, end).replace(Regex("\\s+"), " ").trim()
                } else n.title
                com.tebogo.markvault.data.RelatedArticleMatch(n, excerpt)
            }
        }.sortedByDescending { r -> terms.count { (r.note.title + " " + r.note.content.take(1000)).lowercase().contains(it) } }.take(18)
    }

    private fun formatTranscriptTime(ms: Long): String {
        val total = (ms.coerceAtLeast(0L) / 1000L)
        val h = total / 3600L
        val m = (total % 3600L) / 60L
        val sec = total % 60L
        return if (h > 0L) "%d:%02d:%02d".format(h, m, sec) else "%d:%02d".format(m, sec)
    }

    /**
     * v5.4.387cc — Read-only caption search adapter. Caption text remains in
     * VideoTranscriptStore's JSON files and is never inserted into notes,
     * note_embeddings, media_embeddings, FTS, or the article chunk pipeline.
     * The Room lookup here only resolves a transcript hit back to its cached
     * MediaItem so existing player/navigation code can open the exact timestamp.
     */
    suspend fun searchVideoTranscripts(
        query: String,
        language: String? = null,
        limit: Int = 20
    ): List<com.tebogo.markvault.data.MediaItem> = withContext(Dispatchers.IO) {
        val matches = runCatching {
            com.tebogo.markvault.data.VideoTranscriptStore.search(
                getApplication<Application>(), query, limit = limit, language = language
            )
        }.getOrElse { emptyList() }
        if (matches.isEmpty()) return@withContext emptyList()

        // Resolve the common bulk-downloaded case in ONE Room query instead of
        // one DB lookup per caption hit. Fallback key lookups are only needed for
        // legacy transcripts whose mediaId is missing/stale.
        val ids = matches.map { it.mediaId }.filter { it > 0L }.distinct()
        val byId = if (ids.isNotEmpty()) {
            runCatching { mediaDao.getByIds(ids) }.getOrElse { emptyList() }.associateBy { it.id }
        } else emptyMap()

        matches.mapNotNull { match ->
            var base = byId[match.mediaId]?.takeIf { cached ->
                match.language.isBlank() ||
                    cached.contentLanguage.equals(match.language, ignoreCase = true) ||
                    cached.subtitleLanguage.equals(match.language, ignoreCase = true)
            }
            if (base == null && match.jwKey.isNotBlank() && match.language.isNotBlank()) {
                base = mediaDao.getByJwKeyAndLanguage(match.jwKey, match.language)
            }
            if (base == null && match.jwKey.isNotBlank() && match.language.isBlank()) {
                base = mediaDao.getByJwKey(match.jwKey)
            }
            val resolved = base ?: return@mapNotNull null
            if (!resolved.mediaType.equals("video", ignoreCase = true)) return@mapNotNull null
            resolved.copy(
                description = com.tebogo.markvault.data.VideoTranscriptStore.RESULT_PREFIX +
                    " • ${formatTranscriptTime(match.startMs)}\n" + match.snippet,
                resumePositionMs = match.startMs
            )
        }
    }

    /**
     * v5.4.389cc — Caption lookup is a completely separate, cancellable job.
     * Global article/thesis search and ordinary media metadata search never wait
     * for this job. Its only output is [captionVideoResults].
     */
    fun searchCaptionVideos(query: String, language: String? = null) {
        captionSearchJob?.cancel()
        val trimmed = query.trim()
        if (trimmed.length < 2) {
            _captionVideoResults.value = emptyList()
            return
        }
        captionSearchJob = viewModelScope.launch(Dispatchers.IO) {
            val results = searchVideoTranscripts(trimmed, language = language, limit = 16)
            currentCoroutineContext().ensureActive()
            _captionVideoResults.value = results
        }
    }

    /** Search local media DB + JW.org. Semantic media ranking is supplied by
     * the main semantic search, which already owns the active query embedding. */
    fun searchMedia(query: String) {
        mediaSearchJob?.cancel()
        val trimmed = query.trim()
        if (trimmed.isBlank()) {
            _mediaSearchResults.value = emptyList()
            _semanticMediaResults.value = emptyList()
            _semanticMediaQuery = ""
            _jwSearchResults.value = emptyList()
            _mediaSearchBusy.value = false
            return
        }
        _mediaSearchBusy.value = true
        mediaSearchJob = viewModelScope.launch(Dispatchers.IO) {
            if (_semanticMediaQuery != trimmed) {
                _semanticMediaResults.value = emptyList()
                _mediaSearchResults.value = emptyList()
            }
            _semanticMediaQuery = trimmed

            // Publish cached video/audio metadata BEFORE any potentially slow
            // cleanup/network work, so ordinary media matches remain immediate.
            // No caption files are touched here.
            val localResults = runCatching { mediaDao.searchLocal(trimmed, limit = 24) }.getOrElse { emptyList() }
            currentCoroutineContext().ensureActive()
            val mergedLocal = LinkedHashMap<String, com.tebogo.markvault.data.MediaItem>()
            _semanticMediaResults.value.forEach { item ->
                mergedLocal[item.jwKey.ifBlank { "id:${item.id}" }] = item
            }
            localResults.forEach { item ->
                mergedLocal.putIfAbsent(item.jwKey.ifBlank { "id:${item.id}" }, item)
            }
            _mediaSearchResults.value = mergedLocal.values.take(30)

            // Protect the user's foreground article semantic search from the
            // separate background MEDIA embedding maintenance job. Do this only
            // after local media has already been published.
            mediaSemanticIndexJob?.cancelAndJoin()
            mediaSemanticIndexJob = null
            currentCoroutineContext().ensureActive()

            // Online JW metadata search remains media-only. Because this entire
            // job is cancellable, stale typed queries cannot keep dozens of
            // category crawls running in the background.
            val jwResults = runCatching {
                com.tebogo.markvault.network.JwMediaApi.search(trimmed, limit = 24)
            }.getOrElse { emptyList() }
            currentCoroutineContext().ensureActive()
            if (jwResults.isNotEmpty()) {
                runCatching { mediaDao.upsertAll(jwResults) }
                // Defer media-only embedding maintenance so it does not compete
                // with an active thesis/article search immediately afterwards.
                scheduleMediaSemanticIndexing(delayMs = 30_000L)
            }
            _jwSearchResults.value = jwResults
            _mediaSearchBusy.value = false
        }
    }



    /**
     * v5.4.266cc — Build a compact, stable semantic document from metadata already
     * stored in media_items. Captions/transcripts are intentionally excluded.
     */
    private fun mediaSemanticText(item: com.tebogo.markvault.data.MediaItem): String = buildString {
        append("Title: ").append(item.title).append('\n')
        if (item.description.isNotBlank()) append("Description: ").append(item.description).append('\n')
        if (item.scriptureRefs.isNotBlank()) append("Scripture references: ").append(item.scriptureRefs).append('\n')
        if (item.category.isNotBlank()) append("Category: ").append(item.category).append('\n')
        if (item.mediaType.isNotBlank()) append("Media type: ").append(item.mediaType)
    }

    private fun mediaSemanticFingerprint(item: com.tebogo.markvault.data.MediaItem): String {
        val digest = MessageDigest.getInstance("SHA-256")
            .digest(mediaSemanticText(item).toByteArray(Charsets.UTF_8))
        return digest.joinToString("") { "%02x".format(it) }
    }

    /**
     * v5.4.270cc — Battery-safe incremental media semantic indexing.
     *
     * The previous implementation scanned the complete media table and could
     * embed every pending item from a ViewModel coroutine after startup, search,
     * playback, or memory cleanup. That work could continue after the activity
     * moved to the background and could immediately reload the embedding model
     * that post-search cleanup had just released.
     *
     * This implementation is deliberately bounded:
     *  - only rows that do not yet have an embedding for the active model are
     *    fetched from Room; already-indexed media is never rescanned;
     *  - at most MEDIA_SEMANTIC_INDEX_BATCH_SIZE rows are embedded per run;
     *  - every row re-checks battery/foreground/idle eligibility;
     *  - additional backlog is scheduled as another delayed batch rather than a
     *    long-running loop.
     *
     * Returns true when another missing row exists after this batch.
     */
    private suspend fun indexPendingMediaSemanticEmbeddingsBatch(): Boolean = withContext(Dispatchers.IO) {
        if (!_modelAvailable.value || !canRunMediaSemanticIndexingNow()) return@withContext false
        if (usedHeapBytes() >= memoryPauseThresholdBytes()) {
            android.util.Log.w("MarkVault", "Media semantic indexing skipped at 95% heap pressure")
            return@withContext false
        }

        val candidates = runCatching {
            mediaDao.mediaMissingEmbeddingPage(
                embedder.modelVersion,
                MEDIA_SEMANTIC_INDEX_BATCH_SIZE + 1
            )
        }.getOrElse {
            android.util.Log.e("MarkVault", "Media embedding candidate query failed", it)
            return@withContext false
        }
        if (candidates.isEmpty()) {
            runCatching { mediaDao.pruneOrphanMediaEmbeddings() }
            return@withContext false
        }

        val batch = candidates.take(MEDIA_SEMANTIC_INDEX_BATCH_SIZE)
        for (item in batch) {
            currentCoroutineContext().ensureActive()
            if (!canRunMediaSemanticIndexingNow()) {
                android.util.Log.i("MarkVault", "Media semantic indexing stopped: device/app no longer eligible")
                return@withContext false
            }
            if (usedHeapBytes() >= memoryPauseThresholdBytes()) {
                android.util.Log.w("MarkVault", "Media semantic indexing stopped at 95% heap pressure")
                return@withContext false
            }

            val fingerprint = mediaSemanticFingerprint(item)
            val vector = runCatching { embedder.embed(mediaSemanticText(item)) }.getOrNull()
                ?: continue
            val bytes = com.tebogo.markvault.search.floatArrayToBytes(vector)
            runCatching {
                mediaDao.upsertMediaEmbedding(
                    com.tebogo.markvault.data.MediaEmbedding(
                        mediaId = item.id,
                        modelVersion = embedder.modelVersion,
                        dim = vector.size,
                        vector = bytes,
                        sourceFingerprint = fingerprint,
                        createdAt = System.currentTimeMillis()
                    )
                )
            }.onFailure {
                android.util.Log.w("MarkVault", "Media embedding write failed id=${item.id}", it)
            }
        }

        runCatching { mediaDao.pruneOrphanMediaEmbeddings() }
        candidates.size > MEDIA_SEMANTIC_INDEX_BATCH_SIZE
    }

    /**
     * v5.4.270cc — Media metadata embedding is maintenance work, not user-visible
     * foreground work. It is allowed only while the app is visible, the screen is
     * interactive, battery saver is off, and the device is charging/full. This
     * prevents the semantic-media feature from consuming battery in the background
     * or competing with normal foreground use.
     */
    private fun canRunMediaSemanticIndexingNow(): Boolean {
        if (_searchBusy.value || _mediaSearchBusy.value) return false

        val context = getApplication<Application>()
        val battery = context.getSystemService(BatteryManager::class.java) ?: return false
        if (!battery.isCharging) return false

        val power = context.getSystemService(PowerManager::class.java) ?: return false
        if (!power.isInteractive || power.isPowerSaveMode) return false

        val process = ActivityManager.RunningAppProcessInfo()
        ActivityManager.getMyMemoryState(process)
        return process.importance <= ActivityManager.RunningAppProcessInfo.IMPORTANCE_VISIBLE
    }

    /** v5.4.268cc — Cancel background media metadata indexing before any user
     * search or forced cleanup. */
    private suspend fun cancelMediaSemanticIndexing() {
        mediaSemanticIndexJob?.cancelAndJoin()
        mediaSemanticIndexJob = null
    }

    /**
     * v5.4.270cc — Schedule one small, battery-safe media indexing batch.
     * No heavy work starts when the device is on battery or MarkVault is not
     * visible; a later startup/media-cache event can try again. While charging
     * and visible, backlog is processed as small batches separated by a long
     * delay, with eligibility re-checked before every batch and every item.
     */
    private fun scheduleMediaSemanticIndexing(delayMs: Long = 5_000L) {
        val previous = mediaSemanticIndexJob
        previous?.cancel()
        mediaSemanticIndexJob = viewModelScope.launch(Dispatchers.IO) {
            runCatching { previous?.join() }
            delay(delayMs)

            while (canRunMediaSemanticIndexingNow()) {
                currentCoroutineContext().ensureActive()
                val hasMore = runCatching { indexPendingMediaSemanticEmbeddingsBatch() }
                    .onFailure {
                        if (it !is kotlinx.coroutines.CancellationException) {
                            android.util.Log.w("MarkVault", "Media semantic indexing stopped", it)
                        }
                    }
                    .getOrDefault(false)

                if (!hasMore) break
                delay(MEDIA_SEMANTIC_INDEX_NEXT_BATCH_DELAY_MS)
            }
        }
    }

    /** v5.4.268cc — Semantic search over already-indexed cached media metadata. */
    private suspend fun semanticMediaSearch(
        qVec: FloatArray,
        modelVersion: String,
        limit: Int
    ): List<com.tebogo.markvault.data.MediaItem> = withContext(Dispatchers.IO) {
        val scored = mutableListOf<Pair<Long, Float>>()
        val pageSize = 100
        var offset = 0
        while (true) {
            currentCoroutineContext().ensureActive()
            val page = runCatching { mediaDao.mediaEmbeddingPage(modelVersion, pageSize, offset) }.getOrElse { return@withContext emptyList() }
            if (page.isEmpty()) break
            for (row in page) {
                // v5.5.9 — Media embeddings and query embeddings are already
                // L2-normalised. Score the packed BLOB directly instead of
                // allocating a FloatArray and recomputing both norms per row.
                if (row.vector.size != qVec.size * 4) continue
                scored += row.mediaId to normalizedEmbeddingDot(qVec, row.vector)
            }
            if (page.size < pageSize) break
            offset += pageSize
        }
        val best = scored.sortedByDescending { it.second }.take(limit)
        if (best.isEmpty()) return@withContext emptyList()
        val byId = mediaDao.getByIds(best.map { it.first }).associateBy { it.id }
        best.mapNotNull { byId[it.first] }
    }

    /**
     * v5.4.250cc — Upsert a batch of media items into the offline cache
     * without touching playback or popup state. Used by
     * JwVideoBrowseScreen's folder-scoped search so results found while
     * browsing a category also become findable later by MarkVault's
     * global search (which reads this same table via searchMedia()'s
     * local-cache lookup) — one shared offline index, fed from every
     * place media gets searched, not a separate parallel cache.
     */
    fun cacheMediaItems(items: List<com.tebogo.markvault.data.MediaItem>) {
        if (items.isEmpty()) return
        viewModelScope.launch(Dispatchers.IO) {
            runCatching { mediaDao.upsertAll(items) }
            scheduleMediaSemanticIndexing()
        }
    }

    /** Fetch JW.org top-level categories (for browse screen). */
    fun loadJwCategories() {
        viewModelScope.launch {
            val cats = runCatching {
                com.tebogo.markvault.network.JwMediaApi.topCategories()
            }.getOrElse { emptyList() }
            _jwCategories.value = cats
        }
    }

    /** Update playback position for resume. */
    fun updateMediaPlayback(id: Long, positionMs: Long) {
        viewModelScope.launch(Dispatchers.IO) {
            runCatching { mediaDao.updatePlayback(id, System.currentTimeMillis(), positionMs) }
        }
    }
    private val prefs = Prefs(app)
    private val obsidianThemeManager = com.tebogo.markvault.data.ObsidianThemeManager(app)
    private val indexer = Indexer(app, dao)

    /**
     * v5.4.175cc — The real note count behind the semantic index, as
     * opposed to [embeddingCount] (chunk/passage count, used for memory
     * estimates). See Db.kt's distinctEmbeddedNoteCount doc comment.
     */
    suspend fun distinctEmbeddedNoteCount(): Int =
        runCatching { dao.distinctEmbeddedNoteCount(embedder.modelVersion) }.getOrElse { 0 }

    /**
     * v5.4.76cc — Concrete LLM-backed query expander. Cheap to hold
     * (~stateless): the heavyweight [com.tebogo.markvault.llm.LlmManager]
     * engine is loaded and unloaded per call inside the expander, not
     * held resident here. Constructed once so all callers share one
     * expansion cache path through [com.tebogo.markvault.ai.LlmExpansionHistory].
     *
     * v5.4.79cc — Now takes lambda providers instead of a hard-coded
     * descriptor so switching models in Settings takes effect at the
     * very next submit. The lambdas read [chatActiveModelId] and
     * [memoryOptimizedLlm] each call, so nothing has to be reconstructed
     * on toggle.
     */
    private val llmQueryExpander =
        com.tebogo.markvault.llm.LlmQueryExpander(
            appContext = app.applicationContext,
            descriptorProvider = {
                val activeId = runCatching { chatActiveModelId.value }.getOrNull()
                    ?: com.tebogo.markvault.llm.ChatModelCatalog.default.id
                com.tebogo.markvault.llm.ChatModelCatalog.byId(activeId)
                    ?: com.tebogo.markvault.llm.ChatModelCatalog.default
            },
            memoryOptimizedProvider = {
                // v5.4.137cc — Default flipped false: see
                // [Prefs.memoryOptimizedLlm] for why. This getOrDefault
                // only fires in the vanishing window before the
                // DataStore flow has resolved on cold start; using
                // false here matches the new pref default so the LLM
                // isn't restrictively gated during that first moment
                // either.
                runCatching { memoryOptimizedLlm.value }.getOrDefault(false)
            },
            countProvider = {
                runCatching { effectiveExpansionBudget() }.getOrDefault(
                    com.tebogo.markvault.llm.LlmQueryExpander.DEFAULT_PARAPHRASE_COUNT
                )
            }
        )

    // v4.8 — semantic search foundation. The embedder is constructed eagerly
    // with the default model, then swapped in the init block below based on
    // the user's stored activeModelId preference.
    //
    // v4.9.0 — `embedder` is now a `var` so we can swap it when the user
    // picks a different model in Settings. @Volatile keeps reads from search
    // coroutines coherent with the swap.
    @Volatile
    private var embedder: com.tebogo.markvault.search.Embedder =
        com.tebogo.markvault.search.Embedder(
            app, com.tebogo.markvault.search.ModelCatalog.default
        )

    // v4.23.0 — Cross-encoder reranker for second-stage search ranking.
    // Initialised lazily on first use. Held for the lifetime of the VM
    // so the ONNX session is paid for once and reused.
    private val reranker = com.tebogo.markvault.search.Reranker(app)

    // ── v5.5.0 — ANN fast-search index ──────────────────────────────
    val annIndex = com.tebogo.markvault.search.AnnIndex(app)
    val hnswIndex = com.tebogo.markvault.search.HnswIndex(app)
    val hnswSearchEnabled: StateFlow<Boolean> = prefs.hnswSearchEnabled
        .stateIn(viewModelScope, SharingStarted.Eagerly, false)
    val hnswAutoBuild: StateFlow<Boolean> = prefs.hnswAutoBuild
        .stateIn(viewModelScope, SharingStarted.Eagerly, false)
    private val _hnswBuilding = MutableStateFlow(false)
    val hnswBuilding: StateFlow<Boolean> = _hnswBuilding
    private val _hnswBuildProgress = MutableStateFlow<Float?>(null)
    val hnswBuildProgress: StateFlow<Float?> = _hnswBuildProgress
    private val _hnswBuildStage = MutableStateFlow("")
    val hnswBuildStage: StateFlow<String> = _hnswBuildStage
    private val _hnswBuildError = MutableStateFlow<String?>(null)
    val hnswBuildError: StateFlow<String?> = _hnswBuildError
    private val _hnswRevision = MutableStateFlow(0)
    val hnswRevision: StateFlow<Int> = _hnswRevision
    private var hnswBuildJob: kotlinx.coroutines.Job? = null

    fun setHnswSearchEnabled(enabled: Boolean) {
        viewModelScope.launch {
            if (enabled) {
                prefs.setHnswModelExcluded(embedder.modelVersion, false)
                prefs.setHnswAutoBuild(true)
            }
            prefs.setHnswSearchEnabled(enabled)
            if (enabled && !isHnswIndexAvailable()) buildAllEmbeddings()
        }
    }

    fun setHnswAutoBuild(enabled: Boolean) {
        viewModelScope.launch {
            prefs.setHnswAutoBuild(enabled)
            if (enabled) {
                prefs.setHnswModelExcluded(embedder.modelVersion, false)
                buildAllEmbeddings()
            }
        }
    }

    fun isHnswIndexAvailable() = hnswIndex.isAvailable(embedder.modelVersion)
    fun hnswIndexStats() = hnswIndex.stats(embedder.modelVersion)

    fun buildHnswIndex() {
        if (_hnswBuilding.value || _annBuilding.value) return
        val model = embedder.modelVersion
        val dim = embedder.descriptor.embeddingDim
        _hnswBuilding.value = true
        _hnswBuildError.value = null
        hnswBuildJob = viewModelScope.launch(Dispatchers.IO) {
            startProtectedTask("hnsw_build", "Building blue HNSW index…")
            try {
                hnswIndex.synchronizeModel(dao, model, dim, rebuild = true) { fraction, stage ->
                    _hnswBuildProgress.value = fraction
                    _hnswBuildStage.value = stage
                }
                prefs.setHnswModelExcluded(model, false)
                prefs.setHnswAutoBuild(true)
                logActivity(com.tebogo.markvault.data.ActivityLog.Category.FAST_SEARCH,
                    "HNSW index built", mapOf("model" to model))
                // Other installed models receive their own graph after their delta embedding pass.
                buildAllEmbeddings()
            } catch (error: kotlinx.coroutines.CancellationException) {
                throw error
            } catch (error: Exception) {
                _hnswBuildError.value = error.message ?: "HNSW build failed"
                android.util.Log.e("MarkVault", "HNSW build failed", error)
            } finally {
                _hnswBuilding.value = false
                _hnswBuildProgress.value = null
                _hnswBuildStage.value = ""
                _hnswRevision.value += 1
                stopProtectedTask("hnsw_build")
            }
        }
    }

    fun cancelHnswBuild() { hnswBuildJob?.cancel() }
    fun deleteHnswIndex() {
        val model = embedder.modelVersion
        viewModelScope.launch(Dispatchers.IO) {
            try {
                prefs.setHnswModelExcluded(model, true)
                prefs.setHnswSearchEnabled(false)
                hnswIndex.delete(model)
                _hnswRevision.value += 1
            } catch (error: Exception) { _hnswBuildError.value = error.message }
        }
    }

    val annSearchEnabled: StateFlow<Boolean> = prefs.annSearchEnabled
        .stateIn(viewModelScope, SharingStarted.Eagerly, false)

    /** True while the ANN index build is running. Observable for Compose. */
    private val _annBuilding = MutableStateFlow(false)
    val annBuilding: StateFlow<Boolean> = _annBuilding

    /** Build progress 0.0–1.0. Null when not building. */
    private val _annBuildProgress = MutableStateFlow<Float?>(null)
    val annBuildProgress: StateFlow<Float?> = _annBuildProgress

    private val _annBuildStage = MutableStateFlow("")
    val annBuildStage: StateFlow<String> = _annBuildStage

    private val _annBuildError = MutableStateFlow<String?>(null)
    val annBuildError: StateFlow<String?> = _annBuildError

    fun setAnnSearchEnabled(v: Boolean) {
        viewModelScope.launch { prefs.setAnnSearchEnabled(v) }
    }

    private var annBuildJob: kotlinx.coroutines.Job? = null

    /** Trigger ANN index build from Settings. Protected by BackgroundWorkService. */
    fun buildAnnIndex() {
        if (annIndex.isBuilding || _annBuilding.value || _hnswBuilding.value) return
        if (annBuildJob?.isActive == true) return
        _annBuildError.value = null
        _annBuildProgress.value = 0f
        _annBuildStage.value = "Starting…"
        _annBuilding.value = true
        startProtectedTask("ann_build", "Building search index…")
        annBuildJob = viewModelScope.launch(Dispatchers.IO) {
            try {
                val mv = embedder.modelVersion
                val dim = embedder.descriptor.embeddingDim
                val total = runCatching { dao.embeddingCount(mv) }.getOrElse { 0 }

                val result = annIndex.build(
                    loadPage = { limit, offset ->
                        runCatching {
                            dao.loadEmbeddingVectorsPage(mv, limit, offset)
                                .map { it.noteId to it.vector }
                        }.getOrElse { emptyList() }
                    },
                    modelVersion = mv,
                    dim = dim,
                    totalVectors = total,
                    onProgress = { frac, stage ->
                        _annBuildProgress.value = frac
                        _annBuildStage.value = stage
                    }
                )
                if (result.isFailure) {
                    val err = result.exceptionOrNull()
                    if (err !is kotlinx.coroutines.CancellationException) {
                        _annBuildError.value = err?.message ?: "Build failed"
                        android.util.Log.e("MarkVault", "ANN build failed", err)
                        runCatching {
                            logActivity(
                                com.tebogo.markvault.data.ActivityLog.Category.FAST_SEARCH,
                                "Index build failed: ${err?.message ?: "unknown error"}",
                                emptyMap()
                            )
                        }
                    }
                } else {
                    val stats = annIndex.stats()
                    runCatching {
                        logActivity(
                            com.tebogo.markvault.data.ActivityLog.Category.FAST_SEARCH,
                            "Index built successfully",
                            mapOf(
                                "clusters" to "${stats?.numClusters ?: "?"}",
                                "vectors" to "${stats?.numVectors ?: "?"}",
                                "model" to (stats?.modelVersion ?: "?")
                            )
                        )
                    }
                }
            } finally {
                _annBuilding.value = false
                _annBuildProgress.value = null
                _annBuildStage.value = ""
                stopProtectedTask("ann_build")
            }
        }
    }

    fun cancelAnnBuild() {
        annBuildJob?.cancel()
        annBuildJob = null
        stopProtectedTask("ann_build")
    }

    fun deleteAnnIndex() {
        annIndex.delete(embedder.modelVersion)
    }

    /** v5.5.0 — Whether the ANN index is built and ready for the current model. */
    fun isAnnIndexAvailable(): Boolean = annIndex.isAvailable(embedder.modelVersion)

    /**
     * v5.5.8 — Stats belong to the currently-selected embedding model.
     * Reading the model-specific header prevents a BGE-large cache from being
     * displayed after the user switches to MiniLM/BGE-base (or vice versa).
     */
    fun annIndexStats(): com.tebogo.markvault.search.AnnIndex.IndexStats? =
        annIndex.stats(embedder.modelVersion)

    // v5.5.8 — ANN incremental maintenance moved into EmbeddingService,
    // where it can update EVERY installed model that already owns an ANN
    // index, even while a different model is active in the UI. Keeping this
    // work in the foreground service also means it survives Activity/ViewModel
    // recreation and no longer depends on the global Fast Search toggle.
    // ── end ANN ─────────────────────────────────────────────────────

    /** True iff the .tflite model has been downloaded and is usable. */
    private val _modelAvailable = MutableStateFlow(embedder.isModelAvailable())
    val modelAvailable: StateFlow<Boolean> = _modelAvailable

    /** Download progress [0.0, 1.0]. Null when not currently downloading. */
    private val _modelDownloadProgress = MutableStateFlow<Float?>(null)
    val modelDownloadProgress: StateFlow<Float?> = _modelDownloadProgress

    /**
     * T5-base paraphrase model (query expansion) install state.
     *
     * [T5ModelManager.isInstalled] is an in-memory-only flag that resets to
     * false on every process start, so it can't be trusted at app launch
     * even if the files are already on disk from a previous session. We
     * check the real files via [com.tebogo.markvault.ai.T5ArtifactLoader]
     * once at init below and seed both this flow and [T5ModelManager] from
     * that, then keep them in sync afterwards.
     */
    private val _t5DownloadProgress = MutableStateFlow<Float?>(null)
    val t5DownloadProgress: StateFlow<Float?> = _t5DownloadProgress
    private val _t5Installed = MutableStateFlow(
        com.tebogo.markvault.ai.T5ArtifactLoader(app).verifyInstalledFiles()
    )
    val t5Installed: StateFlow<Boolean> = _t5Installed
    private val _t5Error = MutableStateFlow<String?>(null)
    val t5Error: StateFlow<String?> = _t5Error
    init {
        com.tebogo.markvault.update.AppUpdateManager.initialize(app)
        com.tebogo.markvault.ai.T5ModelManager.setInstalled(_t5Installed.value)
        // v5.4.191cc — Sync both the volatile field and the MutableStateFlow
        // from the persisted preference so the correct scope is used from the
        // very first search and the chip highlight is correct on app start.
        viewModelScope.launch {
            val saved = prefs.semanticScope.first()
            currentScope = saved
            _semanticScopeFlow.value = saved
            _semanticDualModeFlow.value = prefs.semanticDualMode.first()
        }
        // v5.4.390cc — IMPORTANT: caption FTS is NOT rebuilt at app startup.
        // A full downloaded CC library can be very large; rebuilding it here competes
        // for storage/CPU with the foreground 20k article embedding scan. New/updated
        // transcripts maintain the sidecar at write time instead.
    }

    fun checkForAppUpdate() {
        viewModelScope.launch {
            com.tebogo.markvault.update.AppUpdateManager.checkForUpdate(getApplication())
        }
    }

    fun downloadAppUpdate() {
        com.tebogo.markvault.update.AppUpdateManager.startDownload(getApplication())
    }

    fun cancelAppUpdate() {
        com.tebogo.markvault.update.AppUpdateManager.cancelDownload(getApplication())
    }

    fun resumePendingAppUpdate() {
        com.tebogo.markvault.update.AppUpdateManager.resumePendingDownload(getApplication())
    }

    /** How many notes have a current embedding under the active model version. */
    private val _embeddingCount = MutableStateFlow(0)
    val embeddingCount: StateFlow<Int> = _embeddingCount

    /**
     * v5.4.183cc — How many CHUNKS (not notes) are in the in-memory semantic
     * index. Updated every time the index is (re)built. Exposed to Settings
     * so the user can see why searches are slow and decide on a chunk limit.
     */
    private val _semanticChunkCount = MutableStateFlow(0)
    val semanticChunkCount: StateFlow<Int> = _semanticChunkCount

    /** v5.4.198cc — Per-scope chunk counts so the dual button can show e.g. "82k · 19k". */
    private val _firstScopeChunks  = MutableStateFlow(0)
    val firstScopeChunks: StateFlow<Int>  = _firstScopeChunks
    private val _secondScopeChunks = MutableStateFlow(0)
    val secondScopeChunks: StateFlow<Int> = _secondScopeChunks

    /**
     * v5.4.199cc — Which scope is currently loading ("first20k" | "second20k" | "all" | null).
     * Drives the live per-row loading indicators in the dual LED panel.
     */
    private val _loadingScopeFlow = MutableStateFlow<String?>(null)
    val loadingScope: StateFlow<String?> = _loadingScopeFlow

    /**
     * v5.4.183cc — True while the semantic index is being built in the
     * background (pre-warm at startup, or on first search if pre-warm
     * lost the race). SearchScreen shows a non-blocking hint so the
     * user knows the engine is warming up, not stuck.
     */
    private val _semanticIndexWarming = MutableStateFlow(false)
    val semanticIndexWarming: StateFlow<Boolean> = _semanticIndexWarming

    /** v5.4.208cc — Load status for the current scope. Values: "" | "loading" | "loaded:N". */
    private val _scopeLoadStatus = MutableStateFlow("")
    val scopeLoadStatus: StateFlow<String> = _scopeLoadStatus

    /**
     * v5.4.209cc — Brief message shown after dual search offloads memory.
     * v5.4.241cc — REMOVED: replaced by showMemoryClearedToast() everywhere,
     * so there's one real, measured confirmation mechanism, not a static
     * banner on just this one path.
     */

    /**
     * v5.4.194cc — Scope StateFlow backed by a MutableStateFlow so the chip
     * highlight updates INSTANTLY on tap (no DataStore async lag). DataStore
     * is still written for persistence across restarts but never drives the UI.
     */
    private val _semanticScopeFlow = MutableStateFlow("first20k")
    val semanticScope: StateFlow<String> = _semanticScopeFlow.asStateFlow()

    /**
     * v5.4.191cc — Volatile shadow for semanticSearchInner to avoid the
     * DataStore async gap. Now also mirrors _semanticScopeFlow exactly.
     */
    @Volatile private var currentScope: String = "first20k"

    /**
     * v5.4.194cc — Epoch counter. Incremented every time invalidateSemanticIndex()
     * is called (i.e. every scope switch). Any ensureScopeIndex() that was
     * mid-load when the switch happened checks the epoch on completion and
     * discards its result if the epoch moved — preventing the old scope from
     * repopulating its cache after it was cleared.
     */
    @Volatile private var scopeEpoch: Int = 0

    /** v5.4.196cc — Dual search mode. Instant toggle; DataStore write is async for persistence. */
    private val _semanticDualModeFlow = MutableStateFlow(false)
    val semanticDualMode: StateFlow<Boolean> = _semanticDualModeFlow.asStateFlow()
    fun setSemanticDualMode(v: Boolean) {
        _semanticDualModeFlow.value = v          // instant toggle
        viewModelScope.launch { prefs.setSemanticDualMode(v) }
    }

    /**
     * v5.4.190cc — Which half of the library to include in semantic search.
     *   "first20k"  = most recently modified 20 000 articles (default — fast).
     *   "second20k" = ALL articles beyond first 20k (excludes first 20k).
     *   "all"       = entire library with no limit.
     * Chip highlight is instant; DataStore persistence is async.
     */
    fun setSemanticScope(v: String) {
        currentScope = v                    // immediate — no DataStore delay
        _semanticScopeFlow.value = v        // immediate chip visual update
        _scopeLoadStatus.value = ""         // reset status for new scope
        invalidateSemanticIndex()           // synchronous cache + epoch bump
        viewModelScope.launch { prefs.setSemanticScope(v) }  // persist async
    }

    /** [embedded, total] progress while an embedding pass is running. Null otherwise. */
    /**
     * v4.15.0 — Embedding progress now comes from [EmbeddingProgressBus],
     * which the foreground [EmbeddingService] writes to. The VM just
     * exposes the same flow under the same public name so the Settings UI
     * keeps working without any Composable-side changes.
     */
    val embeddingProgress: StateFlow<Pair<Int, Int>?> =
        com.tebogo.markvault.search.EmbeddingProgressBus.progress

    // v4.9.0 — Semantic search controls. These mirror the corresponding Prefs
    // flows so the UI can observe them as StateFlows with synchronous .value
    // reads (the search ranking inspects semanticEnabled.value on every query).
    val semanticEnabled: StateFlow<Boolean> = prefs.semanticEnabled
        .stateIn(viewModelScope, SharingStarted.Eagerly, true)
    /** v5.5.14 — Model-independent question detection + answer-oriented retrieval. */
    val questionAwarenessEnabled: StateFlow<Boolean> = prefs.questionAwarenessEnabled
        .stateIn(viewModelScope, SharingStarted.Eagerly, true)
    /**
     * v5.4.76cc/v5.5.24 — Master switch for on-device model-based
     * multi-query expansion. When OFF, neither the catalog LLM nor T5-base
     * may run or reuse a cached expansion. Offline synonym expansion remains
     * controlled by the expansion-count slider. Live-typing keystrokes do not
     * start a model; only explicit submits do. Default OFF.
     */
    val aiLlmSearchEnabled: StateFlow<Boolean> = prefs.aiLlmSearchEnabled
        .stateIn(viewModelScope, SharingStarted.Eagerly, false)
    /**
     * v5.4.79cc — Read-only observation of the LLM memory-safety belt
     * preference. See [Prefs.memoryOptimizedLlm] for what it does.
     *
     * v5.4.137cc — Default flipped from ON to OFF. The old ON-by-
     * default was too aggressive: the free-RAM precheck refused to
     * load Phi-4-mini or even Qwen 3 0.6B on any device with < ~3 GB
     * free RAM (very common on a 6 GB tier with WebViews, Room, and
     * BGE-large embedder already resident), which meant the LLM
     * toggle appeared to work but every single expansion attempt got
     * skipped with `ram_skip`. Now off by default: LLM gets the full
     * 45 s load + 30 s generate budget and skips the precheck. If a
     * user hits an OS low-memory kill during LLM load, they can opt
     * IN to memory-optimised mode in Settings.
     */
    val memoryOptimizedLlm: StateFlow<Boolean> = prefs.memoryOptimizedLlm
        .stateIn(viewModelScope, SharingStarted.Eagerly, false)

    /**
     * v5.4.80cc/v5.5.24 — Shared expansion budget. Range 0..10; 0 is a
     * hard boundary that permits only the original query: no implicit topic
     * ORs, Question Awareness queries, synonyms, T5, LLM, or cached model
     * expansions. Default 3 preserves the existing out-of-box behaviour.
     */
    val llmParaphraseCount: StateFlow<Int> = prefs.llmParaphraseCount
        .stateIn(viewModelScope, SharingStarted.Eagerly, 3)

    // v5.5.24 — DataStore writes are asynchronous. Without these immediate
    // request-side values, tapping Search directly after moving the slider to
    // 0 or switching model expansion OFF could still execute one search with
    // the previous persisted value. The latest UI action is authoritative for
    // the next search; DataStore remains the durable source after restart.
    @Volatile private var requestedAiLlmSearchEnabled: Boolean? = null
    @Volatile private var requestedExpansionBudget: Int? = null

    private fun effectiveAiLlmSearchEnabled(): Boolean =
        requestedAiLlmSearchEnabled ?: aiLlmSearchEnabled.value

    private fun effectiveExpansionBudget(): Int =
        (requestedExpansionBudget ?: llmParaphraseCount.value).coerceIn(0, 10)

    /**
     * v5.4.121cc — Persisted choice of query-expansion engine: BUILTIN
     * (Phi-4-mini via [llmQueryExpander]) or T5_BASE (on-device T5-base
     * ONNX paraphraser). Previously the Settings screen tracked this in
     * a Compose `remember {}` with no backing store, so it silently
     * reverted to BUILTIN on every screen re-entry or process restart —
     * the "moves back to default" bug. Now backed by [Prefs.t5ExpansionMode]
     * so it sticks until the user changes it, and read directly by
     * [expandedContentSearch] so the selection actually changes which
     * model runs, not just what the Settings UI displays.
     */
    val t5ExpansionMode: StateFlow<com.tebogo.markvault.ai.T5ExpansionMode> =
        prefs.t5ExpansionMode
            .map {
                if (it == "t5_base") com.tebogo.markvault.ai.T5ExpansionMode.T5_BASE
                else com.tebogo.markvault.ai.T5ExpansionMode.BUILTIN
            }
            .stateIn(viewModelScope, SharingStarted.Eagerly, com.tebogo.markvault.ai.T5ExpansionMode.BUILTIN)

    /**
     * v5.4.121cc — Persist and apply a new expansion-engine choice. If
     * T5_BASE is requested but the model isn't actually installed yet,
     * we quietly keep/store BUILTIN instead of letting the UI show a
     * selection that can't do anything — the previous dead stub chain
     * ([T5SelectionController] etc.) tried to do this in memory only,
     * which didn't survive restarts either.
     */
    fun setT5ExpansionMode(mode: com.tebogo.markvault.ai.T5ExpansionMode) {
        val effective =
            if (mode == com.tebogo.markvault.ai.T5ExpansionMode.T5_BASE && !_t5Installed.value) {
                com.tebogo.markvault.ai.T5ExpansionMode.BUILTIN
            } else mode
        viewModelScope.launch {
            runCatching {
                prefs.setT5ExpansionMode(
                    if (effective == com.tebogo.markvault.ai.T5ExpansionMode.T5_BASE) "t5_base" else "builtin"
                )
            }
            // v5.5.24 — Selecting an engine never changes the master model-
            // expansion switch. T5_BASE is merely the selected engine; it can
            // run only while aiLlmSearchEnabled is explicitly ON.
        }
    }

    @Volatile private var t5Engine: com.tebogo.markvault.ai.T5InferenceEngine? = null
    @Volatile private var t5EngineLoadAttempted = false

    /**
     * v5.4.122cc — Load/generate timeout budget for the T5 path,
     * mirroring [com.tebogo.markvault.llm.LlmQueryExpander]'s
     * SHORT/LONG timeout constants. Added after a real-device report of
     * the app going to "Not Responding" with T5 selected: the T5-base
     * decoder here is the plain (non-KV-cached) graph, which recomputes
     * attention over the whole generated-so-far sequence on every one
     * of up to 64 steps — with no cap that run had no way to end.
     */
    private val T5_LOAD_TIMEOUT_MS = 20_000L
    private val T5_GENERATE_TIMEOUT_MS = 25_000L
    // v5.4.123cc -- generateMany()'s cost scales with the requested
    // paraphrase count (each additional paraphrase is a full decode
    // pass), so a fixed 25s budget silently truncated results as soon
    // as the slider went above ~1. The per-request timeout now scales
    // with targetCount, capped here so a slider value of 10 can't hang
    // a search indefinitely on a slow device.
    private val T5_GENERATE_TIMEOUT_MS_CEILING = 90_000L

    /**
     * v5.4.121cc — Lazily loads the T5-base ONNX encoder/decoder
     * sessions on first use (mirrors how [embedder] and [reranker] are
     * held for the VM's lifetime) and caches them. Load is attempted at
     * most once per process — if it fails (missing files, corrupt
     * artifact, OOM, or exceeds [T5_LOAD_TIMEOUT_MS]) we fall back to
     * the builtin/LLM path for the rest of the session rather than
     * retrying expensive disk/ONNX work on every search.
     *
     * v5.4.122cc — Wrapped the load call in [withTimeoutOrNull]. Note
     * this is a best-effort guard, not a hard kill: if the native ONNX
     * session-creation call is truly wedged (not honouring cancellation,
     * same caveat [com.tebogo.markvault.llm.LlmQueryExpander] documents
     * for its own load/generate calls), the coroutine still returns to
     * the caller so the UI stops appearing frozen, even though the
     * underlying IO-dispatcher thread may keep running in the
     * background until it eventually finishes or the process is killed.
     */
    private suspend fun t5ExpansionProviderOrNull(): com.tebogo.markvault.ai.T5QueryExpansionProvider? {
        t5Engine?.let { return com.tebogo.markvault.ai.T5QueryExpansionProvider(it) }
        if (t5EngineLoadAttempted) return null
        return withContext(Dispatchers.IO) {
            if (t5Engine == null && !t5EngineLoadAttempted) {
                t5EngineLoadAttempted = true
                t5Engine = runCatching {
                    kotlinx.coroutines.withTimeoutOrNull(T5_LOAD_TIMEOUT_MS) {
                        com.tebogo.markvault.ai.T5InferenceEngine.loadFrom(getApplication())
                    }
                }.getOrNull()
            }
            t5Engine?.let { com.tebogo.markvault.ai.T5QueryExpansionProvider(it) }
        }
    }

    /**
     * v5.4.121cc — T5-base counterpart to [llmQueryExpander]. Runs the
     * cached ONNX engine (loaded via [t5ExpansionProviderOrNull]), caps
     * the output at the paraphrase-count slider exactly like the Phi-4
     * path does, and records into the same
     * [com.tebogo.markvault.ai.LlmExpansionHistory] store — tagged with
     * `modelName = "T5-base"` — so the Home-screen long-press dialog
     * shows a T5 run the same way it shows a Phi-4 run. Never throws:
     * any failure (missing files, ONNX error, OOM, timeout) degrades to
     * an empty list and the search falls back to synonym expansion
     * alone, same as the Phi-4 path's failure behaviour.
     *
     * v5.4.122cc — Wrapped generation in [T5_GENERATE_TIMEOUT_MS]. This
     * was the actual cause of the reported "app not responding": the
     * previous version awaited [T5QueryExpansionProvider.expandQuery]
     * with no bound at all, so a slow/hung decode loop hung the whole
     * search indefinitely instead of degrading gracefully.
     */
    private suspend fun runT5Expansion(query: String, targetCount: Int): List<String> {
        val trimmed = query.trim()
        if (trimmed.isEmpty()) return emptyList()
        val safeTargetCount = targetCount.coerceIn(0, 10)
        if (safeTargetCount == 0 || !effectiveAiLlmSearchEnabled()) return emptyList()
        val provider = t5ExpansionProviderOrNull() ?: return emptyList()
        val startNs = System.nanoTime()
        val raw = runCatching {
            val scaledTimeoutMs = (T5_GENERATE_TIMEOUT_MS * safeTargetCount).coerceIn(
                T5_GENERATE_TIMEOUT_MS,
                T5_GENERATE_TIMEOUT_MS_CEILING
            )
            kotlinx.coroutines.withTimeoutOrNull(scaledTimeoutMs) {
                provider.expandQuery(trimmed, safeTargetCount)
            }
        }.getOrNull() ?: emptyList()
        val paraphrases = raw
            .filter { it.isNotBlank() && it.trim().lowercase() != trimmed.lowercase() }
            .distinct()
            .take(safeTargetCount)
        val durationMs = (System.nanoTime() - startNs) / 1_000_000L
        com.tebogo.markvault.ai.LlmExpansionHistory.record(
            com.tebogo.markvault.ai.LlmExpansionRecord(
                query = trimmed,
                paraphrases = paraphrases,
                timestampMs = System.currentTimeMillis(),
                durationMs = durationMs,
                cached = false,
                modelName = "T5-base"
            )
        )
        return paraphrases
    }
    /**
     * v5.4.77cc — Side-channel signal from [expandedContentSearch]
     * telling the Search UI which hit ids in the current results
     * appeared *only* through LLM-paraphrased sub-queries, never
     * through the user's original tokens or the Kotlin synonym
     * expander. Replaces v5.4.76cc's `SearchHit.matchedViaLlm` field —
     * moving the flag off the DAO return type keeps [SearchHit] a pure
     * DB projection and dodges Room 2.8.4 KSP strictness around
     * non-null primitives on entities/projections. Emits `emptySet()`
     * whenever the LLM path is off or the search yielded no LLM-only
     * hits; SearchScreen reads it via `hit.id in vm.llmMatchedHitIds`
     * to decide when to render the "✨ AI" chip on a result row.
     */
    private val _llmMatchedHitIds = MutableStateFlow<Set<Long>>(emptySet())
    val llmMatchedHitIds: StateFlow<Set<Long>> = _llmMatchedHitIds.asStateFlow()
    /**
     * v5.4.76cc — Read-only view of every LLM query expansion the current
     * app session has recorded. Long-pressing a recent search on the Home
     * screen reads this map to show *what the LLM did to this query*.
     */
    val llmExpansionHistory: StateFlow<Map<String, com.tebogo.markvault.ai.LlmExpansionRecord>> =
        com.tebogo.markvault.ai.LlmExpansionHistory.entries
    val autoCheckModelUpdates: StateFlow<Boolean> = prefs.autoCheckModelUpdates
        .stateIn(viewModelScope, SharingStarted.Eagerly, false)
    private val _activeModelId = MutableStateFlow(
        com.tebogo.markvault.search.ModelCatalog.default.id
    )
    val activeModelId: StateFlow<String> = _activeModelId

    /** All models from the catalog, exposed for the Settings model-picker UI. */
    val availableModels: List<com.tebogo.markvault.search.ModelDescriptor> =
        com.tebogo.markvault.search.ModelCatalog.all

    // ── v4.21.0 — On-device chat (RAG) state ───────────────────────────────
    //
    // Mirrors the embedding-side state shape so the Settings UI can be
    // built the same way (status line + progress bar + install/delete
    // button). The download itself runs in a foreground service
    // ([ChatModelDownloadService]) which writes progress to
    // [ChatDownloadProgressBus], so the VM just re-exposes those flows.

    /** ID of the currently selected chat model. */
    val chatActiveModelId: StateFlow<String> =
        prefs.chatActiveModelId.stateIn(
            viewModelScope, SharingStarted.Eagerly,
            com.tebogo.markvault.llm.ChatModelCatalog.default.id
        )

    /**
     * True iff the active chat model file is present and big enough.
     *
     * v5.4.256cc fix: this used to be declared BEFORE [chatActiveModelId]
     * in this class, so the very first evaluation — which runs as this
     * property's OWN field initializer, at ViewModel construction time —
     * called [currentChatModelInstalled] before [chatActiveModelId] had
     * been assigned. Kotlin initializes class properties in textual
     * order; reading a not-yet-initialized StateFlow property from an
     * earlier property's initializer throws, which the old code's
     * runCatching silently caught and treated as "use the default model
     * instead" — meaning the very first installed-check after every cold
     * start (app relaunch, process restart) checked whether
     * ChatModelCatalog.default (SmolLM2 135M) was installed, not whichever
     * model the user actually had active. For anyone who installed Gemma
     * 4 E2B (not the default), this made the Settings screen show
     * "Install model (~2650 MB)" on every single app restart even though
     * the 2.6 GB file was genuinely already on disk — and tapping that
     * button re-downloaded from scratch, and ChatModelDownloader's
     * finalize step (`if (finalFile.exists()) finalFile.delete()`) then
     * deleted the perfectly good existing file to make room for the
     * redundant new one. That's the actual mechanism behind "the model
     * deletes itself on app exit" — the file was never touched while the
     * app was running; it only ever got deleted as a side effect of a
     * REDUNDANT re-download the app itself wrongly prompted for on the
     * next launch, silently discarding the previous (unnecessary)
     * download in the process.
     *
     * Fix: chatActiveModelId is now declared directly above, so by the
     * time this initializer runs, it's already fully assigned — no
     * ordering hazard, no fallback-to-default-model misdirection.
     */
    private val _chatModelInstalled = MutableStateFlow(currentChatModelInstalled())
    val chatModelInstalled: StateFlow<Boolean> = _chatModelInstalled

    /** Download progress as (doneMb, totalMb). Null = idle. */
    val chatDownloadProgress: StateFlow<Pair<Int, Int>?> =
        com.tebogo.markvault.llm.ChatDownloadProgressBus.progress

    /** True iff the foreground download service is currently working. */
    val chatDownloadRunning: StateFlow<Boolean> =
        com.tebogo.markvault.llm.ChatDownloadProgressBus.isRunning

    /** Last download-failure message; null when none pending. */
    val chatDownloadError: StateFlow<String?> =
        com.tebogo.markvault.llm.ChatDownloadProgressBus.lastError

    /** True iff the user has paused a download in progress. */
    val chatDownloadPaused: StateFlow<Boolean> =
        com.tebogo.markvault.llm.ChatDownloadProgressBus.isPaused

    /**
     * One of "opt_in" (default — user taps Install button) or
     * "auto_prompt" (chat screen prompts on first open).
     * v4.21.0 exposes this toggle but the active code path is always
     * "opt_in" until v4.22.x wires up auto-prompt behaviour.
     */
    val chatInstallFlowPref: StateFlow<String> =
        prefs.chatInstallFlow.stateIn(viewModelScope, SharingStarted.Eagerly, "opt_in")

    /**
     * One of "own_screen" (default — dedicated chat screen via overflow
     * menu) or "in_search" (chat lives inside the Search screen).
     */
    val chatLocationPref: StateFlow<String> =
        prefs.chatLocation.stateIn(viewModelScope, SharingStarted.Eagerly, "own_screen")

    /**
     * One of "fresh_per_q" (default — each question independent) or
     * "multi_turn" (conversation kept within session).
     */
    val chatHistoryModePref: StateFlow<String> =
        prefs.chatHistoryMode.stateIn(viewModelScope, SharingStarted.Eagerly, "fresh_per_q")

    /**
     * One of "on_open" (default — load when chat screen opens), "preload"
     * (load at app start), or "on_first_q" (load on first message tap).
     * v4.21.2 exposes this toggle; v4.22.x consumes it in the chat screen.
     */
    val chatModelLoadModePref: StateFlow<String> =
        prefs.chatModelLoadMode.stateIn(viewModelScope, SharingStarted.Eagerly, "on_open")

    /** All chat models from the catalog, exposed for future model-picker UI. */
    val availableChatModels: List<com.tebogo.markvault.llm.ChatModelDescriptor> =
        com.tebogo.markvault.llm.ChatModelCatalog.all

    /**
     * Synchronous check of whether the ACTIVE chat model file exists on disk.
     *
     * v5.4.73 fix: previously hardcoded [ChatModelCatalog.default] so the
     * 1.5B model was never recognised as installed — it downloaded fine but
     * the UI looped back to "Not installed" every time.
     *
     * v5.4.256cc: the runCatching fallback this comment used to describe
     * is no longer reachable in normal operation — chatActiveModelId is
     * now declared before _chatModelInstalled (see that property's doc
     * comment for the full story), so chatActiveModelId.value is always
     * already assigned by the time this runs, including the very first
     * cold-start call. runCatching stays as defense-in-depth only.
     */
    private fun currentChatModelInstalled(): Boolean {
        val app = getApplication<Application>()
        val activeId = runCatching { chatActiveModelId.value }.getOrNull()
        val descriptor = (if (activeId != null)
            com.tebogo.markvault.llm.ChatModelCatalog.byId(activeId)
        else null) ?: com.tebogo.markvault.llm.ChatModelCatalog.default
        val f = java.io.File(app.filesDir, descriptor.localFilename)
        return f.exists() && f.length() >
            com.tebogo.markvault.llm.ChatModelCatalog.MIN_PLAUSIBLE_MODEL_BYTES
    }

    // ── v4.23.0 — Reranker (cross-encoder) state ────────────────────────────
    //
    // The reranker is a SECOND-STAGE ranking model that runs after the
    // semantic embedder. The embedder produces a rough cosine ranking from
    // 14k notes; the reranker then refines the top ~30 of those for much
    // higher precision. Wraps [com.tebogo.markvault.search.Reranker].

    /** True iff the reranker model + vocab files are installed. */
    private val _rerankerInstalled = MutableStateFlow(reranker.isInstalled())
    val rerankerInstalled: StateFlow<Boolean> = _rerankerInstalled

    /** Download progress 0.0–1.0; null when idle. */
    private val _rerankerDownloadProgress = MutableStateFlow<Float?>(null)
    val rerankerDownloadProgress: StateFlow<Float?> = _rerankerDownloadProgress

    /** True iff a download is currently in flight. */
    private val _rerankerDownloading = MutableStateFlow(false)
    val rerankerDownloading: StateFlow<Boolean> = _rerankerDownloading

    /** Last error message from a failed download. Null when no error pending. */
    private val _rerankerDownloadError = MutableStateFlow<String?>(null)
    val rerankerDownloadError: StateFlow<String?> = _rerankerDownloadError

    /** Whether reranking is on. Reads the persisted preference. */
    val rerankEnabled: StateFlow<Boolean> =
        prefs.rerankEnabled.stateIn(viewModelScope, SharingStarted.Eagerly, false)

    /** v5.2.0 — Maximum recent-search entries to show on the Home screen. */
    val maxRecentSearchesOnHome: StateFlow<Int> =
        prefs.maxRecentSearchesOnHome.stateIn(viewModelScope, SharingStarted.Eagerly, 7)

    val maxSavedSearchSessions: StateFlow<Int> =
        prefs.maxSavedSearchSessions.stateIn(viewModelScope, SharingStarted.Eagerly, 50)

    fun setMaxSavedSearchSessions(v: Int) {
        val clamped = v.coerceIn(1, 50)
        viewModelScope.launch {
            prefs.setMaxSavedSearchSessions(clamped)
            // v5.5.11 — This setting is an in-memory/recent-navigation window only.
            // Never delete durable SavedSearchStore history when it changes.
            _savedSearchSessions.value = com.tebogo.markvault.search.SavedSearchStore.list(getApplication(), clamped)
        }
    }

    /** v5.5.2 — Persisted view mode for SavedSearchesScreen: "list" or "calendar". */
    val savedSearchViewMode: StateFlow<String> =
        prefs.savedSearchViewMode.stateIn(viewModelScope, SharingStarted.Eagerly, "list")

    fun setSavedSearchViewMode(mode: String) {
        viewModelScope.launch { prefs.setSavedSearchViewMode(mode) }
    }

    /** v5.5.2 — Lightweight metadata for all sessions within 6-month retention. */
    private val _savedSearchMeta = MutableStateFlow<List<com.tebogo.markvault.search.SessionMeta>>(emptyList())
    val savedSearchMeta: StateFlow<List<com.tebogo.markvault.search.SessionMeta>> = _savedSearchMeta.asStateFlow()

    fun refreshSavedSearchMeta() {
        viewModelScope.launch(Dispatchers.IO) {
            _savedSearchMeta.value = com.tebogo.markvault.search.SavedSearchStore.listMeta(getApplication())
        }
    }

    /** v5.5.2 — Load all sessions (full decode) for list view. */
    private val _allSavedSessions = MutableStateFlow<List<com.tebogo.markvault.search.SavedSearchSession>>(emptyList())
    val allSavedSessions: StateFlow<List<com.tebogo.markvault.search.SavedSearchSession>> = _allSavedSessions.asStateFlow()

    fun refreshAllSavedSessions() {
        viewModelScope.launch(Dispatchers.IO) {
            _allSavedSessions.value = com.tebogo.markvault.search.SavedSearchStore.listAll(getApplication())
        }
    }

    /** v5.5.2 — Load sessions for a specific day. */
    fun loadSessionsForDay(startOfDayMs: Long, endOfDayMs: Long, onResult: (List<com.tebogo.markvault.search.SavedSearchSession>) -> Unit) {
        viewModelScope.launch(Dispatchers.IO) {
            val all = com.tebogo.markvault.search.SavedSearchStore.listAll(getApplication())
            val filtered = all.filter { it.createdAt in startOfDayMs until endOfDayMs }
            kotlinx.coroutines.withContext(Dispatchers.Main) { onResult(filtered) }
        }
    }

    fun setMaxRecentSearchesOnHome(v: Int) {
        viewModelScope.launch { prefs.setMaxRecentSearchesOnHome(v) }
    }

    /** v5.3.0 — How the tabs preview is laid out. "vertical" (grid scrolls
     *  vertically, 2 columns) or "horizontal" (cards swipe side to side). */
    val tabsPreviewOrientation: StateFlow<String> =
        prefs.tabsPreviewOrientation.stateIn(viewModelScope, SharingStarted.Eagerly, "vertical")

    fun setTabsPreviewOrientation(v: String) {
        viewModelScope.launch { prefs.setTabsPreviewOrientation(v) }
    }

    /** v5.3.1 — see Prefs.keywordFilterEnabled. */
    val keywordFilterEnabled: StateFlow<Boolean> =
        prefs.keywordFilterEnabled.stateIn(viewModelScope, SharingStarted.Eagerly, true)

    fun setKeywordFilterEnabled(v: Boolean) {
        viewModelScope.launch { prefs.setKeywordFilterEnabled(v) }
    }

    /** v5.4.1 — see Prefs.liveSearchEnabled. */
    val liveSearchEnabled: StateFlow<Boolean> =
        prefs.liveSearchEnabled.stateIn(viewModelScope, SharingStarted.Eagerly, true)
    fun setLiveSearchEnabled(v: Boolean) {
        viewModelScope.launch { prefs.setLiveSearchEnabled(v) }
    }

    /** v5.4.1 — see Prefs.cancelInflightSearch. */
    val cancelInflightSearch: StateFlow<Boolean> =
        prefs.cancelInflightSearch.stateIn(viewModelScope, SharingStarted.Eagerly, true)
    fun setCancelInflightSearch(v: Boolean) {
        viewModelScope.launch { prefs.setCancelInflightSearch(v) }
    }

    /** v5.4.1 — see Prefs.autoFreeMemory. */
    val autoFreeMemory: StateFlow<Boolean> =
        prefs.autoFreeMemory.stateIn(viewModelScope, SharingStarted.Eagerly, true)
    fun setAutoFreeMemory(v: Boolean) {
        viewModelScope.launch { prefs.setAutoFreeMemory(v) }
    }

    /** v5.4.5 — see Prefs.rerankOnSubmitOnly. */
    val rerankOnSubmitOnly: StateFlow<Boolean> =
        prefs.rerankOnSubmitOnly.stateIn(viewModelScope, SharingStarted.Eagerly, true)
    fun setRerankOnSubmitOnly(v: Boolean) {
        viewModelScope.launch { prefs.setRerankOnSubmitOnly(v) }
    }

    // v5.4.6 — Manual rerank trigger. The SearchScreen shows a button
    // above the result list when rerank is installed but the current
    // results haven't been reranked yet (e.g. live-typing results, or
    // when rerank is fully disabled). Tapping the button reranks the
    // current results in place — no full search re-run, just the
    // cross-encoder polish step applied to what's already shown.
    //
    // State auto-invalidates: manualRerankResult carries the query it
    // was computed for; if the user types more, the stored query stops
    // matching the current query and the UI falls back to base results.
    private val _manualRerankResult =
        MutableStateFlow<Pair<String, List<SearchHit>>?>(null)
    val manualRerankResult: StateFlow<Pair<String, List<SearchHit>>?> =
        _manualRerankResult.asStateFlow()

    private val _manualRerankInProgress = MutableStateFlow(false)
    val manualRerankInProgress: StateFlow<Boolean> =
        _manualRerankInProgress.asStateFlow()

    fun manuallyRerankCurrentResults() {
        if (_manualRerankInProgress.value) return
        val q = query.value.trim()
        val current = results.value
        if (q.length < 2 || current.isEmpty() || !_rerankerInstalled.value) return

        viewModelScope.launch(Dispatchers.IO) {
            _manualRerankInProgress.value = true
            try {
                // v5.5.12 — Accuracy-first manual rerank window: take the
                // displayed top 30 and let the cross-encoder judge all 30.
                // The older 20-document cap could never rescue a genuinely
                // relevant result sitting at positions 21–30. The window is
                // still bounded so manual rerank remains practical on-device.
                // v5.5.10 — Feed the reranker the CURRENT comparable display
                // scores when available. They are already monotonic in result order;
                // a synthetic rank slot is only a fallback for legacy/null rows.
                val candidates = current.take(30).mapIndexed { i, hit ->
                    val fallback = 1f - (i.toFloat() / 30f)
                    hit.id to (hit.score ?: fallback)
                }
                // v5.5.12 — Manual rerank now uses the same semantic-passage
                // evidence as automatic hybrid reranking. Previously it fell back
                // to title + leading content, so a relevant paragraph deep in an
                // article could be missed only because the user tapped Rerank.
                var manualQueryVector: FloatArray? = null
                var manualModelVersion: String? = null
                if (semanticEnabled.value) {
                    val searchEmbedder = embedder
                    val descriptor = searchEmbedder.descriptor
                    val modelVersion = searchEmbedder.modelVersion
                    val qForEmbedding = if (
                        descriptor.poolingStrategy == com.tebogo.markvault.search.PoolingStrategy.CLS
                    ) "Represent this sentence for searching relevant passages: $q" else q
                    val vec = runCatching { searchEmbedder.embed(qForEmbedding) }.getOrNull()
                    if (vec != null && vec.size == descriptor.embeddingDim) {
                        manualQueryVector = vec
                        manualModelVersion = modelVersion
                    }
                    if (descriptor.approxSizeMb > 32) {
                        runCatching { searchEmbedder.close() }
                        runCatching { System.gc() }
                    }
                }
                val reranked = applyRerank(
                    query = q,
                    candidates = candidates,
                    maxToRerank = ACCURACY_RERANK_WINDOW,
                    semanticQueryVector = manualQueryVector,
                    semanticModelVersion = manualModelVersion
                )
                val byId = current.associateBy { it.id }

                // applyRerank now rank-calibrates the cross-encoder order back
                // onto the input score slots. Map that order directly; DO NOT
                // globally re-sort mixed score sources again. That global sort
                // was the v5.5.5 accuracy regression this release repairs.
                val rerankedWindow = reranked.mapNotNull { (id, score) ->
                    byId[id]?.copy(score = score)
                }
                val seenIds = rerankedWindow.asSequence().map { it.id }.toSet()
                val rest = current.filter { it.id !in seenIds }
                _manualRerankResult.value = q to (rerankedWindow + rest)
            } catch (t: Throwable) {
                android.util.Log.e("MarkVault", "Manual rerank failed", t)
            } finally {
                _manualRerankInProgress.value = false
                // v5.4.240cc — FOUND: manual rerank loaded the reranker
                // (and possibly the embedder, via applyRerank) but never
                // scheduled ANY cleanup afterward — it stayed loaded
                // indefinitely until some UNRELATED later search happened
                // to trigger schedulePostSearchCleanup(). Now it's
                // scheduled here too, in finally so it fires whether the
                // rerank succeeded or failed.
                schedulePostSearchCleanup()
            }
        }
    }

    /** v5.4.6 — see Prefs.rerankerModelId. */
    val rerankerModelId: StateFlow<String> =
        prefs.rerankerModelId.stateIn(viewModelScope, SharingStarted.Eagerly, "ms-marco-minilm-l12-v2")
    fun setRerankerModelId(id: String) {
        viewModelScope.launch {
            prefs.setRerankerModelId(id)
            // Apply right away so subsequent searches use the new model.
            val desc = com.tebogo.markvault.search.RerankerCatalog.byId(id)
                ?: com.tebogo.markvault.search.RerankerCatalog.default
            reranker.setDescriptor(desc)
            // Refresh installed flag — different model = different file.
            _rerankerInstalled.value = reranker.isInstalled()
        }
    }

    /** v5.4.6 — see Prefs.articleHighlightEnabled. */
    val articleHighlightEnabled: StateFlow<Boolean> =
        prefs.articleHighlightEnabled.stateIn(viewModelScope, SharingStarted.Eagerly, true)
    fun setArticleHighlightEnabled(v: Boolean) {
        viewModelScope.launch { prefs.setArticleHighlightEnabled(v) }
    }

    /** v5.4.9 — see Prefs.highlightMode. Raw pref ("auto"/"smart"/"keyword"). */
    val highlightMode: StateFlow<String> =
        prefs.highlightMode.stateIn(viewModelScope, SharingStarted.Eagerly, "auto")
    fun setHighlightMode(v: String) {
        viewModelScope.launch { prefs.setHighlightMode(v) }
    }

    /** v5.4.13 — see Prefs.linkLongPressAction. */
    val linkLongPressAction: StateFlow<String> =
        prefs.linkLongPressAction.stateIn(viewModelScope, SharingStarted.Eagerly, "menu")
    fun setLinkLongPressAction(v: String) {
        viewModelScope.launch { prefs.setLinkLongPressAction(v) }
    }

    /** v5.4.35 — Open links from offline articles in new tab vs same tab. */
    val openLinksInNewTab: StateFlow<Boolean> =
        prefs.openLinksInNewTab.stateIn(viewModelScope, SharingStarted.Eagerly, true)
    fun setOpenLinksInNewTab(v: Boolean) {
        viewModelScope.launch { prefs.setOpenLinksInNewTab(v) }
    }

    /** v5.4.36 — Vertical scroll for home-screen article rows. */
    val homeScrollVertical: StateFlow<Boolean> =
        prefs.homeScrollVertical.stateIn(viewModelScope, SharingStarted.Eagerly, false)
    fun setHomeScrollVertical(v: Boolean) {
        viewModelScope.launch { prefs.setHomeScrollVertical(v) }
    }

    /** v5.4.255cc — Continuous Play setting: see Prefs.continuousPlayEnabled's doc comment. */
    val continuousPlayEnabled: StateFlow<Boolean> =
        prefs.continuousPlayEnabled.stateIn(viewModelScope, SharingStarted.Eagerly, true)
    fun setContinuousPlayEnabled(v: Boolean) {
        viewModelScope.launch { prefs.setContinuousPlayEnabled(v) }
    }

    /** v5.4.288cc — Auto-cache played video captions/transcripts. */
    val autoExtractVideoCaptions: StateFlow<Boolean> =
        prefs.autoExtractVideoCaptions.stateIn(viewModelScope, SharingStarted.Eagerly, true)
    fun setAutoExtractVideoCaptions(v: Boolean) {
        if (!v) {
            transcriptExtractionJobs.values.forEach { it.cancel() }
            transcriptExtractionJobs.clear()
        }
        viewModelScope.launch { prefs.setAutoExtractVideoCaptions(v) }
    }

    val mediaSearchAsYouType: StateFlow<Boolean> =
        prefs.mediaSearchAsYouType.stateIn(viewModelScope, SharingStarted.Eagerly, true)
    fun setMediaSearchAsYouType(v: Boolean) {
        viewModelScope.launch { prefs.setMediaSearchAsYouType(v) }
    }

    /** v5.4.395cc — User override for the landscape Android TV media UI. */
    val forceAndroidTvUi: StateFlow<Boolean> =
        prefs.forceAndroidTvUi.stateIn(viewModelScope, SharingStarted.Eagerly, false)
    fun setForceAndroidTvUi(v: Boolean) {
        viewModelScope.launch { prefs.setForceAndroidTvUi(v) }
    }

    /** v5.4.401cc — Global video-quality override, persisted independently of per-video controls. */
    val universalVideoResolutionEnabled: StateFlow<Boolean> =
        prefs.universalVideoResolutionEnabled.stateIn(viewModelScope, SharingStarted.Eagerly, false)
    val universalVideoResolution: StateFlow<String> =
        prefs.universalVideoResolution.stateIn(viewModelScope, SharingStarted.Eagerly, "720")

    fun setUniversalVideoResolutionEnabled(enabled: Boolean) {
        viewModelScope.launch {
            prefs.setUniversalVideoResolutionEnabled(enabled)
            rebuildVideoQueueForResolution(enabled, universalVideoResolution.value)
        }
    }

    fun setUniversalVideoResolution(target: String) {
        val normalized = target.lowercase().takeIf { it == "best" || it.toIntOrNull()?.let { n -> n in setOf(240, 360, 480, 720, 1080) } == true } ?: "720"
        viewModelScope.launch {
            prefs.setUniversalVideoResolution(normalized)
            if (universalVideoResolutionEnabled.value) {
                rebuildVideoQueueForResolution(true, normalized)
            }
        }
    }

    /**
     * Rebuild the active Media3 queue at the same index/position when the global
     * quality policy changes. This updates both the current video and every future
     * queued video without touching app-level queue metadata, history, captions,
     * shuffle/repeat state, or audio URLs.
     */
    private suspend fun rebuildVideoQueueForResolution(enabled: Boolean, target: String) {
        val controller = awaitMediaController() ?: return
        val queue = _currentQueue.value
        val current = _nowPlayingMedia.value
        if (queue.isEmpty() && current == null) return
        val position = controller.currentPosition.coerceAtLeast(0L)
        val wasPlaying = controller.playWhenReady
        val index = if (queue.isNotEmpty()) controller.currentMediaItemIndex.coerceIn(0, queue.lastIndex) else 0
        val originalQueue = if (queue.isNotEmpty()) queue else listOfNotNull(current)
        val logicalQueue = if (enabled) {
            originalQueue.map { media ->
                if (media.mediaType.equals("video", ignoreCase = true) && media.qualityOptions.isBlank())
                    enrichVideoCaptionMetadata(media)
                else media
            }
        } else originalQueue
        if (logicalQueue.none { it.mediaType.equals("video", ignoreCase = true) && it.qualityOptions.isNotBlank() }) return
        if (queue.isNotEmpty() && logicalQueue != queue) {
            _currentQueue.value = logicalQueue
            _nowPlayingMedia.value = logicalQueue.getOrNull(index) ?: _nowPlayingMedia.value
        } else if (queue.isEmpty() && logicalQueue.firstOrNull() != current) {
            _nowPlayingMedia.value = logicalQueue.firstOrNull()
        }
        val rebuilt = logicalQueue.map { buildExoMediaItem(it, enabled, target) }
        controller.setMediaItems(rebuilt, index.coerceIn(0, rebuilt.lastIndex), position)
        controller.prepare()
        controller.playWhenReady = wasPlaying
    }


    /** v5.4.386cc — Bulk-download every available video caption track in the
     * currently selected Media Library language. Existing complete transcripts
     * are skipped; unavailable-caption videos are counted separately from true
     * network/parse failures. */
    fun downloadAllVideoCaptions() {
        if (bulkCaptionDownloadJob?.isActive == true) return
        bulkCaptionDownloadJob = viewModelScope.launch(Dispatchers.IO) {
            val context = getApplication<Application>()
            val language = runCatching { prefs.mediaLibraryLanguage.first() }.getOrDefault("E").ifBlank { "E" }
            val token = "video-caption-bulk"
            var downloaded = 0
            var skipped = 0
            var noCaption = 0
            var failed = 0
            var processed = 0
            try {
                _bulkCaptionDownloadState.value = BulkCaptionDownloadState(
                    running = true, language = language, message = "Scanning complete video library…"
                )
                startProtectedTask(token, "Downloading all video captions")
                val videos = com.tebogo.markvault.network.JwMediaApi.allVideos(language) { categories, found ->
                    val old = _bulkCaptionDownloadState.value
                    _bulkCaptionDownloadState.value = old.copy(
                        running = true,
                        visitedCategories = categories,
                        discoveredVideos = found,
                        message = "Scanning library • $categories folders • $found videos"
                    )
                }
                for ((index, rawItem) in videos.withIndex()) {
                    currentCoroutineContext().ensureActive()
                    // v5.4.390cc — Foreground article/thesis search always wins.
                    // Bulk caption network/file/FTS work pauses between videos while
                    // the semantic pipeline owns the embedding model/storage path.
                    while (_searchBusy.value) {
                        delay(250L)
                        currentCoroutineContext().ensureActive()
                    }
                    val cached = runCatching {
                        mediaDao.getByJwKeyAndLanguage(rawItem.jwKey, language)
                    }.getOrNull()
                    var item = if (cached != null) {
                        rawItem.copy(
                            id = cached.id,
                            localPath = cached.localPath,
                            cachedAt = cached.cachedAt,
                            lastPlayedAt = cached.lastPlayedAt,
                            resumePositionMs = cached.resumePositionMs,
                            isFavourite = cached.isFavourite
                        ).also { refreshed -> runCatching { mediaDao.upsert(refreshed) } }
                    } else {
                        val newId = runCatching { mediaDao.upsert(rawItem) }.getOrDefault(0L)
                        rawItem.copy(id = newId)
                    }
                    val old = _bulkCaptionDownloadState.value
                    _bulkCaptionDownloadState.value = old.copy(
                        running = true,
                        discoveredVideos = videos.size,
                        processedVideos = processed,
                        currentTitle = item.title,
                        message = "Downloading captions ${index + 1} / ${videos.size}"
                    )

                    if (com.tebogo.markvault.data.VideoTranscriptStore.hasComplete(context, item)) {
                        skipped++
                        processed++
                    } else {
                        if (item.subtitleUrl.isBlank() && item.jwKey.isNotBlank()) {
                            val resolved = runCatching {
                                com.tebogo.markvault.network.JwMediaApi.mediaByNaturalKey(item.jwKey, language)
                            }.getOrNull()
                            if (resolved != null && resolved.subtitleUrl.isNotBlank()) {
                                item = item.copy(
                                    subtitleUrl = resolved.subtitleUrl,
                                    subtitleLanguage = resolved.subtitleLanguage.ifBlank { language },
                                    contentLanguage = resolved.contentLanguage.ifBlank { language }
                                )
                                runCatching { mediaDao.upsert(item) }
                            }
                        }

                        if (item.subtitleUrl.isBlank()) {
                            noCaption++
                            processed++
                        } else {
                            val result = runCatching {
                                com.tebogo.markvault.data.VideoTranscriptStore.fetchComplete(context, item)
                            }.getOrNull()
                            if (result != null) downloaded++ else failed++
                            processed++
                        }
                    }

                    _bulkCaptionDownloadState.value = _bulkCaptionDownloadState.value.copy(
                        running = true,
                        processedVideos = processed,
                        downloaded = downloaded,
                        skippedExisting = skipped,
                        noCaptionAvailable = noCaption,
                        failed = failed
                    )
                }

                _bulkCaptionDownloadState.value = _bulkCaptionDownloadState.value.copy(
                    running = false,
                    currentTitle = "",
                    processedVideos = processed,
                    downloaded = downloaded,
                    skippedExisting = skipped,
                    noCaptionAvailable = noCaption,
                    failed = failed,
                    message = "Finished • $downloaded downloaded • $skipped already saved • $noCaption without CC • $failed failed"
                )
            } catch (cancelled: kotlinx.coroutines.CancellationException) {
                _bulkCaptionDownloadState.value = _bulkCaptionDownloadState.value.copy(
                    running = false, currentTitle = "", message = "Caption download cancelled"
                )
                throw cancelled
            } catch (t: Throwable) {
                android.util.Log.e("MarkVault", "Bulk caption download failed", t)
                _bulkCaptionDownloadState.value = _bulkCaptionDownloadState.value.copy(
                    running = false, currentTitle = "", message = "Caption download stopped: ${t.message ?: "unknown error"}"
                )
            } finally {
                stopProtectedTask(token)
                bulkCaptionDownloadJob = null
            }
        }
    }

    fun cancelAllVideoCaptionDownload() {
        bulkCaptionDownloadJob?.cancel()
    }

    /** v5.4.391cc — Remove downloaded/captured CC and its sidecar only. */
    fun deleteDownloadedVideoCaptions() {
        if (deleteCcJob?.isActive == true) return
        deleteCcJob = viewModelScope.launch(Dispatchers.IO) {
            val context = getApplication<Application>()
            try {
                // Stop every writer/reader first so files cannot be recreated in
                // the middle of deletion.
                bulkCaptionDownloadJob?.cancelAndJoin()
                transcriptExtractionJobs.values.toList().forEach { it.cancelAndJoin() }
                transcriptExtractionJobs.clear()
                captionSearchJob?.cancelAndJoin()
                _captionVideoResults.value = emptyList()
                _deleteCcProgress.value = CacheDeleteProgress(running = true, message = "Preparing caption deletion…")
                com.tebogo.markvault.data.VideoTranscriptStore.deleteAll(context) { done, total, current ->
                    _deleteCcProgress.value = CacheDeleteProgress(
                        running = true, completed = done, total = total,
                        message = if (total == 0) "No downloaded CC found" else "Deleting CC $done / $total • ${current.take(52)}"
                    )
                }
                _deleteCcProgress.value = _deleteCcProgress.value.copy(
                    running = false, completed = _deleteCcProgress.value.total,
                    message = "Downloaded CC deleted", finished = true
                )
            } catch (t: Throwable) {
                if (t is kotlinx.coroutines.CancellationException) throw t
                _deleteCcProgress.value = _deleteCcProgress.value.copy(running = false, message = "CC deletion failed: ${t.message ?: "unknown error"}")
            } finally { deleteCcJob = null }
        }
    }

    /**
     * v5.4.391cc — Clear rebuildable MEDIA cache without touching notes,
     * article embeddings/chunks, playlists, favourites, local media or playback
     * history/resume rows. Caption files are intentionally a separate action.
     */
    fun clearAllMediaCache() {
        if (clearMediaCacheJob?.isActive == true) return
        clearMediaCacheJob = viewModelScope.launch(Dispatchers.IO) {
            try {
                cancelMediaSemanticIndexing()
                val protectedIds = LinkedHashSet<Long>()
                runCatching { playlistDao.getAll() }.getOrDefault(emptyList()).forEach { protectedIds.addAll(it.idList()) }

                val all = ArrayList<com.tebogo.markvault.data.MediaItem>()
                var offset = 0
                while (true) {
                    val page = mediaDao.mediaPage(500, offset)
                    if (page.isEmpty()) break
                    all.addAll(page)
                    offset += page.size
                }
                val removable = all.filter { item ->
                    item.id !in protectedIds && item.isFavourite == 0 && item.lastPlayedAt <= 0L &&
                        item.resumePositionMs <= 0L && item.localPath.isBlank()
                }
                val embeddingCount = runCatching { mediaDao.mediaEmbeddingCount() }.getOrDefault(0)
                val total = removable.size + embeddingCount + 2 // + image memory + disk cache steps
                var done = 0
                _clearMediaCacheProgress.value = CacheDeleteProgress(running = true, total = total, message = "Preparing media cache deletion…")

                // Derived media embeddings are cache only; clear them first in one
                // transaction-equivalent DAO operation, but advance the visible
                // progress by their actual row count.
                runCatching { mediaDao.clearAllMediaEmbeddings() }
                done += embeddingCount
                _clearMediaCacheProgress.value = CacheDeleteProgress(true, done, total, "Cleared $embeddingCount derived media embeddings")

                for (item in removable) {
                    currentCoroutineContext().ensureActive()
                    mediaDao.delete(item.id)
                    done++
                    _clearMediaCacheProgress.value = CacheDeleteProgress(true, done, total, "Clearing media metadata $done / $total • ${item.title.take(48)}")
                }

                val imageLoader = coil.Coil.imageLoader(getApplication())
                runCatching { imageLoader.memoryCache?.clear() }
                done++
                _clearMediaCacheProgress.value = CacheDeleteProgress(true, done, total, "Cleared image memory cache")
                runCatching { imageLoader.diskCache?.clear() }
                done++
                _captionVideoResults.value = emptyList()
                _clearMediaCacheProgress.value = CacheDeleteProgress(false, done, total, "Media cache cleared • user media state preserved", true)
            } catch (t: Throwable) {
                if (t is kotlinx.coroutines.CancellationException) throw t
                _clearMediaCacheProgress.value = _clearMediaCacheProgress.value.copy(running = false, message = "Media cache deletion failed: ${t.message ?: "unknown error"}")
            } finally { clearMediaCacheJob = null }
        }
    }

    /** v5.4.292cc — Android Auto audio-library exposure toggle. */
    val androidAutoEnabled: StateFlow<Boolean> =
        prefs.androidAutoEnabled.stateIn(viewModelScope, SharingStarted.Eagerly, false)
    fun setAndroidAutoEnabled(v: Boolean) {
        viewModelScope.launch { prefs.setAndroidAutoEnabled(v) }
    }

    /** v5.4.18 — Progress-indicator + FAB toggles. See Prefs. */
    val showRerankProgress: StateFlow<Boolean> =
        prefs.showRerankProgress.stateIn(viewModelScope, SharingStarted.Eagerly, true)
    fun setShowRerankProgress(v: Boolean) {
        viewModelScope.launch { prefs.setShowRerankProgress(v) }
    }

    val showSemanticProgress: StateFlow<Boolean> =
        prefs.showSemanticProgress.stateIn(viewModelScope, SharingStarted.Eagerly, true)
    fun setShowSemanticProgress(v: Boolean) {
        viewModelScope.launch { prefs.setShowSemanticProgress(v) }
    }

    val searchInArticleFab: StateFlow<Boolean> =
        prefs.searchInArticleFab.stateIn(viewModelScope, SharingStarted.Eagerly, true)
    fun setSearchInArticleFab(v: Boolean) {
        viewModelScope.launch { prefs.setSearchInArticleFab(v) }
    }

    val semanticInArticle: StateFlow<Boolean> =
        prefs.semanticInArticle.stateIn(viewModelScope, SharingStarted.Eagerly, false)
    fun setSemanticInArticle(v: Boolean) {
        viewModelScope.launch { prefs.setSemanticInArticle(v) }
    }

    /** v5.4.33 — Search busy flag. Set true when a search starts, false when results arrive. */
    private val _searchBusy = MutableStateFlow(false)
    val searchBusy: StateFlow<Boolean> = _searchBusy

    /**
     * v5.4.371cc — Wall-clock duration of the most recently completed real search,
     * measured with SystemClock.elapsedRealtime() from pipeline start until the
     * result list is ready. Post-search memory cleanup is intentionally excluded.
     */
    private val _lastSearchDurationMs = MutableStateFlow<Long?>(null)
    val lastSearchDurationMs: StateFlow<Long?> = _lastSearchDurationMs.asStateFlow()

    // v5.4.286cc — Real search-work progress for the optional Large % indicator.
    // Unlike rerankProgress (which only measures the final cross-encoder pass),
    // these values are driven by the actual semantic scan: streamed article
    // pages or cached embedding vectors. This lets the UI show whether the
    // search is advancing quickly or slowly instead of displaying an
    // indeterminate spinner until reranking starts.
    private val _searchWorkProgress = MutableStateFlow<Float?>(null)
    val searchWorkProgress: StateFlow<Float?> = _searchWorkProgress
    private val _searchWorkDone = MutableStateFlow(0)
    val searchWorkDone: StateFlow<Int> = _searchWorkDone
    private val _searchWorkTotal = MutableStateFlow(0)
    val searchWorkTotal: StateFlow<Int> = _searchWorkTotal
    private val _searchWorkRate = MutableStateFlow(0f)
    val searchWorkRate: StateFlow<Float> = _searchWorkRate
    private val _searchWorkUnit = MutableStateFlow("items")
    val searchWorkUnit: StateFlow<String> = _searchWorkUnit
    private val _searchWorkStage = MutableStateFlow("Preparing search…")
    val searchWorkStage: StateFlow<String> = _searchWorkStage
    @Volatile private var searchWorkStartedAtMs: Long = 0L

    /**
     * v5.5.14 — Per-submit execution trace used by durable saved-search metadata
     * and graceful Stop Search. A user stop is intentionally NOT coroutine
     * cancellation: retrieval stops at the next safe page/chunk boundary, then
     * the already-found candidates continue through fusion, reranking and save.
     * Query-edit cancellation still uses the old hard-cancel flow.
     */
    private class SearchExecutionTrace(
        val semanticEnabled: Boolean,
        val accurateSearchUsed: Boolean,
        val annEnabled: Boolean,
        val hnswEnabled: Boolean,
        val scope: String,
        val dualMode: Boolean,
        val scopeNoteCount: Int,
        val totalNoteCount: Int,
        val questionAwarenessEnabled: Boolean,
        val queryDetectedAsQuestion: Boolean,
        val questionType: String
    ) {
        @Volatile var gracefulStopRequested: Boolean = false
        val timings = com.tebogo.markvault.search.SearchTimings()
        @Volatile var stoppedAtPercent: Int? = null
        @Volatile var stoppedAtDone: Int = 0
        @Volatile var stoppedAtTotal: Int = 0
        @Volatile var annUsed: Boolean = false
        @Volatile var hnswUsed: Boolean = false
        @Volatile var rerankApplied: Boolean = false
        @Volatile var questionAwarenessUsed: Boolean = false
        @Volatile var questionAwareQueries: List<String> = emptyList()
        /**
         * v5.5.23 — Retrieval/fusion provenance, collected while each ranked
         * query list is still available. It is intentionally captured here,
         * before reranking, because reconstructing it from final snippets or
         * scores would be guesswork.
         */
        val provenanceByHit = LinkedHashMap<Long, LinkedHashMap<String, QueryContribution>>()
    }

    /** One query as it was actually issued during this search execution. */
    private data class IssuedRetrievalQuery(
        val queryId: String,
        val text: String,
        val source: ResultQuerySource,
        val expansionNumber: Int?,
        val weight: Double
    )

    @Volatile private var activeSearchTrace: SearchExecutionTrace? = null

    private fun gracefulSearchStopRequested(): Boolean =
        activeSearchTrace?.gracefulStopRequested == true

    private fun markCurrentSearchAnnUsed(hnsw: Boolean = false) {
        activeSearchTrace?.let { if (hnsw) it.hnswUsed = true else it.annUsed = true }
    }

    private fun markCurrentSearchRerankApplied() {
        activeSearchTrace?.rerankApplied = true
    }

    private fun markQuestionAwarenessUsed(analysis: com.tebogo.markvault.search.QuestionAwareness.Analysis) {
        if (!analysis.usedSuccessfully) return
        activeSearchTrace?.let { trace ->
            // v5.5.16 — Do not let a detector result alone mark a saved search as
            // "Question Awareness used". The feature must have been enabled for
            // this execution and the start-of-search detector must agree.
            if (!trace.questionAwarenessEnabled || !trace.queryDetectedAsQuestion) return@let
            val queries = analysis.answerQueries.map { it.text.trim() }.filter { it.isNotBlank() }
            if (queries.isEmpty()) return@let
            trace.questionAwarenessUsed = true
            trace.questionAwareQueries = queries
        }
    }

    private fun com.tebogo.markvault.ai.QuerySource.toResultQuerySource(): ResultQuerySource =
        when (this) {
            com.tebogo.markvault.ai.QuerySource.ORIGINAL -> ResultQuerySource.ORIGINAL
            com.tebogo.markvault.ai.QuerySource.QUESTION_AWARENESS -> ResultQuerySource.QUESTION_AWARENESS
            com.tebogo.markvault.ai.QuerySource.SYNONYM -> ResultQuerySource.SYNONYM
            com.tebogo.markvault.ai.QuerySource.LLM -> ResultQuerySource.LLM
            com.tebogo.markvault.ai.QuerySource.T5 -> ResultQuerySource.T5
        }

    /**
     * Assign stable, user-facing expansion numbers in the same order queries
     * were issued. The original query never consumes an expansion number.
     */
    private fun issuedRetrievalQueries(
        texts: List<String>,
        sources: List<com.tebogo.markvault.ai.QuerySource>,
        weights: List<Double>
    ): List<IssuedRetrievalQuery> {
        var nextExpansion = 0
        val seen = HashSet<String>()
        return buildList {
            texts.forEachIndexed { index, rawText ->
                val text = rawText.trim()
                if (text.isEmpty()) return@forEachIndexed
                val source = sources.getOrElse(index) {
                    if (index == 0) com.tebogo.markvault.ai.QuerySource.ORIGINAL
                    else com.tebogo.markvault.ai.QuerySource.SYNONYM
                }.toResultQuerySource()
                val dedupeKey = "${source.name}:${text.lowercase()}"
                if (!seen.add(dedupeKey)) return@forEachIndexed
                val expansionNumber = if (source == ResultQuerySource.ORIGINAL) {
                    null
                } else {
                    nextExpansion += 1
                    nextExpansion
                }
                add(
                    IssuedRetrievalQuery(
                        queryId = expansionNumber?.let { "expansion:$it" } ?: "original",
                        text = text,
                        source = source,
                        expansionNumber = expansionNumber,
                        weight = weights.getOrElse(index) { 1.0 }.coerceAtLeast(0.0)
                    )
                )
            }
        }
    }

    private fun originalIssuedQuery(text: String): IssuedRetrievalQuery =
        IssuedRetrievalQuery(
            queryId = "original",
            text = text.trim(),
            source = ResultQuerySource.ORIGINAL,
            expansionNumber = null,
            weight = 1.0
        )

    private fun mergeResultQueryContribution(hitId: Long, incoming: QueryContribution) {
        val trace = activeSearchTrace ?: return
        val byQuery = trace.provenanceByHit.getOrPut(hitId) { LinkedHashMap() }
        val previous = byQuery[incoming.queryId]
        byQuery[incoming.queryId] = if (previous == null) {
            incoming.copy(contribution = incoming.contribution.coerceIn(0.0, 1.0))
        } else {
            // Mirrors the independent-evidence combination used by hybrid fusion.
            val combined = 1.0 -
                (1.0 - previous.contribution.coerceIn(0.0, 1.0)) *
                (1.0 - incoming.contribution.coerceIn(0.0, 1.0))
            previous.copy(
                keyword = previous.keyword || incoming.keyword,
                semantic = previous.semantic || incoming.semantic,
                contribution = combined.coerceIn(0.0, 1.0),
                queryWeight = maxOf(previous.queryWeight, incoming.queryWeight),
                keywordRank = listOfNotNull(previous.keywordRank, incoming.keywordRank).minOrNull(),
                semanticRank = listOfNotNull(previous.semanticRank, incoming.semanticRank).minOrNull()
            )
        }
    }

    /** Capture every keyword list membership and its real weighted-RRF influence. */
    private fun recordKeywordQueryProvenance(
        queries: List<IssuedRetrievalQuery>,
        perQueryHits: List<List<SearchHit>>,
        k: Int = RRF_K
    ) {
        val safeK = k.coerceAtLeast(1)
        perQueryHits.forEachIndexed { queryIndex, hits ->
            val query = queries.getOrNull(queryIndex) ?: return@forEachIndexed
            hits.forEachIndexed { rankZeroBased, hit ->
                val rank = rankZeroBased + 1
                val strength = (query.weight * (safeK + 1.0) / (safeK + rank.toDouble()))
                    .coerceIn(0.0, 1.0)
                mergeResultQueryContribution(
                    hit.id,
                    QueryContribution(
                        queryId = query.queryId,
                        queryText = query.text,
                        source = query.source,
                        expansionNumber = query.expansionNumber,
                        keyword = true,
                        semantic = false,
                        contribution = strength,
                        queryWeight = query.weight,
                        keywordRank = rank
                    )
                )
            }
        }
    }

    /** Capture semantic membership while its ranked list is still in scope. */
    private fun recordSemanticQueryProvenance(
        query: IssuedRetrievalQuery,
        ranking: List<Pair<Long, Float>>,
        semanticSignals: Map<Long, Double>
    ) {
        ranking.forEachIndexed { rankZeroBased, (hitId, _) ->
            mergeResultQueryContribution(
                hitId,
                QueryContribution(
                    queryId = query.queryId,
                    queryText = query.text,
                    source = query.source,
                    expansionNumber = query.expansionNumber,
                    keyword = false,
                    semantic = true,
                    contribution = (semanticSignals[hitId] ?: 0.0).coerceIn(0.0, 1.0),
                    queryWeight = query.weight,
                    semanticRank = rankZeroBased + 1
                )
            )
        }
    }

    /** Freeze provenance for final hits only; reranking has no authority to alter it. */
    private fun snapshotResultQueryProvenance(
        trace: SearchExecutionTrace,
        finalHitIds: Set<Long>
    ): Map<Long, ResultQueryProvenance> = buildMap {
        for ((hitId, byQuery) in trace.provenanceByHit) {
            if (hitId !in finalHitIds || byQuery.isEmpty()) continue
            val contributions = byQuery.values.toList()
            val primary = contributions.maxWithOrNull(
                compareBy<QueryContribution> { it.contribution }
                    .thenBy { it.retrievalPathCount }
                    .thenBy { it.queryWeight }
                    .thenBy { if (it.isOriginal) 1 else 0 }
            ) ?: continue
            put(
                hitId,
                ResultQueryProvenance(
                    primaryQueryId = primary.queryId,
                    contributions = contributions
                )
            )
        }
    }

    private fun stoppedSearchStage(trace: SearchExecutionTrace, finalized: Boolean = false): String {
        val pct = trace.stoppedAtPercent ?: 0
        if (!finalized) return "Stopped at $pct% · reranking found results…"
        val resultState = if (trace.rerankApplied) "found results reranked + saved" else "found results finalized + saved"
        return "Stopped at $pct% · $resultState"
    }

    private fun resetSearchWorkProgress(stage: String = "Preparing search…") {
        searchWorkStartedAtMs = android.os.SystemClock.elapsedRealtime()
        _searchWorkProgress.value = null
        _searchWorkDone.value = 0
        _searchWorkTotal.value = 0
        _searchWorkRate.value = 0f
        _searchWorkUnit.value = "items"
        _searchWorkStage.value = stage
    }

    private fun beginSearchWork(total: Int, unit: String, stage: String) {
        if (searchWorkStartedAtMs <= 0L) {
            searchWorkStartedAtMs = android.os.SystemClock.elapsedRealtime()
        }
        _searchWorkDone.value = 0
        _searchWorkTotal.value = total.coerceAtLeast(0)
        _searchWorkUnit.value = unit
        _searchWorkStage.value = stage
        _searchWorkRate.value = 0f
        _searchWorkProgress.value = if (total > 0) 0f else null
    }

    private fun updateSearchWork(done: Int, total: Int, stage: String? = null) {
        val safeTotal = total.coerceAtLeast(0)
        val safeDone = if (safeTotal > 0) done.coerceIn(0, safeTotal) else done.coerceAtLeast(0)
        _searchWorkDone.value = safeDone
        _searchWorkTotal.value = safeTotal
        stage?.let { _searchWorkStage.value = it }
        if (safeTotal > 0) {
            _searchWorkProgress.value = safeDone.toFloat() / safeTotal.toFloat()
        }
        val elapsedMs = (android.os.SystemClock.elapsedRealtime() - searchWorkStartedAtMs).coerceAtLeast(1L)
        _searchWorkRate.value = safeDone.toFloat() * 1000f / elapsedMs.toFloat()
    }

    private fun completeSearchWork(stage: String = "Finalizing results…") {
        val total = _searchWorkTotal.value
        if (total > 0) {
            updateSearchWork(total, total, stage)
        } else {
            _searchWorkProgress.value = 1f
            _searchWorkStage.value = stage
        }
    }

    /** v5.4.33 — Search indicator animation style. */
    val searchIndicatorStyle: StateFlow<String> =
        prefs.searchIndicatorStyle.stateIn(viewModelScope, SharingStarted.Eagerly, "percentage")
    fun setSearchIndicatorStyle(v: String) {
        viewModelScope.launch { prefs.setSearchIndicatorStyle(v) }
    }

    // ── v5.4.34 — Duplicate detection ────────────────────────────
    /** Hashed password for duplicate deletion. Empty = not set yet. */
    val duplicateDeletePassword: StateFlow<String> =
        prefs.duplicateDeletePassword.stateIn(viewModelScope, SharingStarted.Eagerly, "")

    fun setDuplicateDeletePassword(plainText: String) {
        viewModelScope.launch {
            prefs.setDuplicateDeletePassword(hashPassword(plainText))
        }
    }

    fun verifyDuplicatePassword(plainText: String): Boolean {
        return hashPassword(plainText) == duplicateDeletePassword.value
    }

    private fun hashPassword(plain: String): String {
        val md = java.security.MessageDigest.getInstance("SHA-256")
        return md.digest(plain.toByteArray()).joinToString("") { "%02x".format(it) }
    }

    /** Data class for a group of exact duplicates. */
    data class DuplicateGroup(
        val hash: String,
        val size: Long,
        val notes: List<NoteMeta>,
        val reason: String
    )

    /**
     * Scan for exact-content duplicates. Strategy:
     * 1. Group notes by file size (different sizes = not duplicates).
     * 2. For same-size groups, compute SHA-256 of full content.
     * 3. Only groups where ≥2 notes share the same hash are reported.
     * This avoids hashing all 16k+ files — only size-matched candidates.
     */
    suspend fun findDuplicates(): List<DuplicateGroup> = kotlinx.coroutines.withContext(
        kotlinx.coroutines.Dispatchers.IO
    ) {
        val candidates = dao.duplicateCandidatesBySize()
        val bySize = candidates.groupBy { it.size }
        val result = mutableListOf<DuplicateGroup>()
        val md = java.security.MessageDigest.getInstance("SHA-256")

        for (entry in bySize) {
            val sz = entry.key
            val notes = entry.value
            if (notes.size < 2) continue
            // Compute content hash for each note in this size group
            val hashToNotes = mutableMapOf<String, MutableList<NoteMeta>>()
            for (n in notes) {
                val content = dao.contentById(n.id) ?: continue
                md.reset()
                val hash = md.digest(content.toByteArray()).joinToString("") { "%02x".format(it) }
                hashToNotes.getOrPut(hash) { mutableListOf() }.add(n)
            }
            for (hashEntry in hashToNotes) {
                val hash = hashEntry.key
                val group = hashEntry.value
                if (group.size >= 2) {
                    result.add(DuplicateGroup(
                        hash = hash.take(12),
                        size = sz,
                        notes = group,
                        reason = "Identical content — SHA-256 hash match, " +
                            "file size: ${formatFileSize(sz)}, " +
                            "${group.size} copies found"
                    ))
                }
            }
        }
        result.sortedByDescending { it.notes.size }
    }

    private fun formatFileSize(bytes: Long): String = when {
        bytes < 1024 -> "$bytes B"
        bytes < 1024 * 1024 -> "${bytes / 1024} KB"
        else -> "${"%.1f".format(bytes.toDouble() / (1024 * 1024))} MB"
    }

    /** Delete notes by IDs (used by duplicate deletion). */
    fun deleteNotesByIds(ids: List<Long>) {
        viewModelScope.launch(kotlinx.coroutines.Dispatchers.IO) {
            dao.deleteByIds(ids)
        }
    }

    /** Get raw content for split-screen comparison. */
    suspend fun getContentForComparison(id: Long): String? =
        kotlinx.coroutines.withContext(kotlinx.coroutines.Dispatchers.IO) {
            dao.contentById(id)
        }

    /** v5.4.20 — see Prefs.uiMode. */
    val uiMode: StateFlow<String> =
        prefs.uiMode.stateIn(viewModelScope, SharingStarted.Eagerly, "standard")
    val forceWorkspaceTabletUi: StateFlow<Boolean> =
        prefs.forceWorkspaceTabletUi.stateIn(viewModelScope, SharingStarted.Eagerly, false)
    fun setForceWorkspaceTabletUi(v: Boolean) {
        viewModelScope.launch { prefs.setForceWorkspaceTabletUi(v) }
    }
    fun setUiMode(v: String) {
        viewModelScope.launch { prefs.setUiMode(v) }
    }

    // v5.4.314cc — Persist Workspace shell state without changing Standard mode.
    val workspaceNavOpen: StateFlow<Boolean> =
        prefs.workspaceNavOpen.stateIn(viewModelScope, SharingStarted.Eagerly, false)
    fun setWorkspaceNavOpen(v: Boolean) {
        viewModelScope.launch { prefs.setWorkspaceNavOpen(v) }
    }
    val workspaceNavSection: StateFlow<String> =
        prefs.workspaceNavSection.stateIn(viewModelScope, SharingStarted.Eagerly, "files")
    fun setWorkspaceNavSection(v: String) {
        viewModelScope.launch { prefs.setWorkspaceNavSection(v) }
    }
    val workspaceCompact: StateFlow<Boolean> =
        prefs.workspaceCompact.stateIn(viewModelScope, SharingStarted.Eagerly, true)
    fun setWorkspaceCompact(v: Boolean) {
        viewModelScope.launch { prefs.setWorkspaceCompact(v) }
    }
    val workspaceSplitRatio: StateFlow<Float> =
        prefs.workspaceSplitRatio.stateIn(viewModelScope, SharingStarted.Eagerly, 0.5f)
    fun setWorkspaceSplitRatio(v: Float) {
        viewModelScope.launch { prefs.setWorkspaceSplitRatio(v) }
    }
    val workspaceNavWidth: StateFlow<Float> =
        prefs.workspaceNavWidth.stateIn(viewModelScope, SharingStarted.Eagerly, 420f)
    fun setWorkspaceNavWidth(v: Float) {
        viewModelScope.launch { prefs.setWorkspaceNavWidth(v) }
    }
    val workspaceInspectorWidth: StateFlow<Float> =
        prefs.workspaceInspectorWidth.stateIn(viewModelScope, SharingStarted.Eagerly, 440f)
    fun setWorkspaceInspectorWidth(v: Float) {
        viewModelScope.launch { prefs.setWorkspaceInspectorWidth(v) }
    }
    val workspaceInspectorOpen: StateFlow<Boolean> =
        prefs.workspaceInspectorOpen.stateIn(viewModelScope, SharingStarted.Eagerly, false)
    fun setWorkspaceInspectorOpen(v: Boolean) {
        viewModelScope.launch { prefs.setWorkspaceInspectorOpen(v) }
    }
    val workspaceBoldText: StateFlow<Boolean> =
        prefs.workspaceBoldText.stateIn(viewModelScope, SharingStarted.Eagerly, false)
    fun setWorkspaceBoldText(v: Boolean) {
        viewModelScope.launch { prefs.setWorkspaceBoldText(v) }
    }
    // v5.4.348cc — Slider-backed Workspace text weight for the top-bar B control.
    val workspaceTextWeight: StateFlow<Int> =
        prefs.workspaceTextWeight.stateIn(viewModelScope, SharingStarted.Eagerly, 400)
    fun setWorkspaceTextWeight(v: Int) {
        viewModelScope.launch { prefs.setWorkspaceTextWeight(v) }
    }

    val workspacePaneLayoutA: StateFlow<String> = prefs.workspacePaneLayoutA.stateIn(viewModelScope, SharingStarted.Eagerly, "")
    val workspacePaneLayoutB: StateFlow<String> = prefs.workspacePaneLayoutB.stateIn(viewModelScope, SharingStarted.Eagerly, "")
    val workspacePaneLayoutC: StateFlow<String> = prefs.workspacePaneLayoutC.stateIn(viewModelScope, SharingStarted.Eagerly, "")
    // Sentinel distinguishes DataStore still loading from a legitimately empty saved workspace.
    val workspacePaneCurrent: StateFlow<String> = prefs.workspacePaneCurrent.stateIn(viewModelScope, SharingStarted.Eagerly, "__loading__")
    fun setWorkspacePaneLayoutA(v: String) { viewModelScope.launch { prefs.setWorkspacePaneLayoutA(v) } }
    fun setWorkspacePaneLayoutB(v: String) { viewModelScope.launch { prefs.setWorkspacePaneLayoutB(v) } }
    fun setWorkspacePaneLayoutC(v: String) { viewModelScope.launch { prefs.setWorkspacePaneLayoutC(v) } }
    fun setWorkspacePaneCurrent(v: String) { viewModelScope.launch { prefs.setWorkspacePaneCurrent(v) } }
    val workspaceNamedLayouts: StateFlow<String> = prefs.workspaceNamedLayouts.stateIn(viewModelScope, SharingStarted.Eagerly, "")
    val workspaceBookmarks: StateFlow<String> = prefs.workspaceBookmarks.stateIn(viewModelScope, SharingStarted.Eagerly, "")
    fun setWorkspaceNamedLayouts(v: String) { viewModelScope.launch { prefs.setWorkspaceNamedLayouts(v) } }
    fun setWorkspaceBookmarks(v: String) { viewModelScope.launch { prefs.setWorkspaceBookmarks(v) } }

    val workspaceGraphDepth: StateFlow<Int> =
        prefs.workspaceGraphDepth.stateIn(viewModelScope, SharingStarted.Eagerly, 2)
    val workspaceGraphLayout: StateFlow<String> =
        prefs.workspaceGraphLayout.stateIn(viewModelScope, SharingStarted.Eagerly, "tree")
    val workspaceGraphDirection: StateFlow<String> =
        prefs.workspaceGraphDirection.stateIn(viewModelScope, SharingStarted.Eagerly, "all")
    val workspaceGraphFolder: StateFlow<String> =
        prefs.workspaceGraphFolder.stateIn(viewModelScope, SharingStarted.Eagerly, "")
    val workspaceGraphTag: StateFlow<String> =
        prefs.workspaceGraphTag.stateIn(viewModelScope, SharingStarted.Eagerly, "")
    val workspaceGraphCenterId: StateFlow<Long?> =
        prefs.workspaceGraphCenterId.stateIn(viewModelScope, SharingStarted.Eagerly, null)
    val workspaceGraphScope: StateFlow<String> =
        prefs.workspaceGraphScope.stateIn(viewModelScope, SharingStarted.Eagerly, "5k")
    val workspaceGraphGroupIndex: StateFlow<Int> =
        prefs.workspaceGraphGroupIndex.stateIn(viewModelScope, SharingStarted.Eagerly, 0)
    val workspaceToolbarAutoMove: StateFlow<Boolean> =
        prefs.workspaceToolbarAutoMove.stateIn(viewModelScope, SharingStarted.Eagerly, true)
    val workspaceRibbonCollapsed: StateFlow<Boolean> =
        prefs.workspaceRibbonCollapsed.stateIn(viewModelScope, SharingStarted.Eagerly, false)
    val bottomToolbarAutoMove: StateFlow<Boolean> =
        prefs.bottomToolbarAutoMove.stateIn(viewModelScope, SharingStarted.Eagerly, true)

    fun setWorkspaceGraphDepth(v: Int) { viewModelScope.launch { prefs.setWorkspaceGraphDepth(v) } }
    fun setWorkspaceGraphLayout(v: String) { viewModelScope.launch { prefs.setWorkspaceGraphLayout(v) } }
    fun setWorkspaceGraphDirection(v: String) { viewModelScope.launch { prefs.setWorkspaceGraphDirection(v) } }
    fun setWorkspaceGraphFolder(v: String) { viewModelScope.launch { prefs.setWorkspaceGraphFolder(v) } }
    fun setWorkspaceGraphTag(v: String) { viewModelScope.launch { prefs.setWorkspaceGraphTag(v) } }
    fun setWorkspaceGraphCenterId(v: Long?) { viewModelScope.launch { prefs.setWorkspaceGraphCenterId(v) } }
    fun setWorkspaceGraphScope(v: String) { viewModelScope.launch { prefs.setWorkspaceGraphScope(v) } }
    fun setWorkspaceGraphGroupIndex(v: Int) { viewModelScope.launch { prefs.setWorkspaceGraphGroupIndex(v) } }
    fun setWorkspaceToolbarAutoMove(enabled: Boolean) { viewModelScope.launch { prefs.setWorkspaceToolbarAutoMove(enabled) } }
    fun setWorkspaceRibbonCollapsed(collapsed: Boolean) { viewModelScope.launch { prefs.setWorkspaceRibbonCollapsed(collapsed) } }
    fun setBottomToolbarAutoMove(enabled: Boolean) { viewModelScope.launch { prefs.setBottomToolbarAutoMove(enabled) } }

    suspend fun graphArticleCount(): Int = withContext(Dispatchers.IO) { dao.countNotes() }
    suspend fun graphGroupIds(groupSize: Int, groupIndex: Int): Set<Long> = withContext(Dispatchers.IO) {
        val safeSize = groupSize.coerceIn(1, 10_000)
        val safeIndex = groupIndex.coerceAtLeast(0)
        dao.graphGroupIds(safeSize, safeIndex * safeSize).toHashSet()
    }
    suspend fun graphGroupFirst(groupSize: Int, groupIndex: Int): com.tebogo.markvault.data.LinkedNote? =
        withContext(Dispatchers.IO) {
            val safeSize = groupSize.coerceIn(1, 10_000)
            dao.graphGroupFirst(groupIndex.coerceAtLeast(0) * safeSize)
        }

    /** Materialize the complete selected 5K/10K graph window for rendering only. */
    suspend fun buildGraphGroup(groupSize: Int, groupIndex: Int): GroupGraph = withContext(Dispatchers.IO) {
        val safeSize = groupSize.coerceIn(1, 10_000)
        val safeIndex = groupIndex.coerceAtLeast(0)
        val offset = safeIndex * safeSize
        resolveGraphRows(
            dao.graphGroupNotes(safeSize, offset),
            dao.graphGroupLinks(safeSize, offset)
        )
    }

    /** Explicit heavy option requested by the user: complete library graph. */
    suspend fun buildAllArticleGraph(): GroupGraph = withContext(Dispatchers.IO) {
        resolveGraphRows(dao.graphAllNotes(), dao.graphAllLinks())
    }

    /**
     * Resolve raw targetNorm strings in O(nodes + links), avoiding the old SQL text join that
     * would compare every link against thousands of destination rows on mobile hardware.
     */
    private fun resolveGraphRows(
        rows: List<com.tebogo.markvault.data.GraphGroupNodeRow>,
        rawLinks: List<com.tebogo.markvault.data.GraphGroupRawLink>
    ): GroupGraph {
        val nodes = rows.map { com.tebogo.markvault.data.LinkedNote(it.id, it.title, it.folder) }
        if (rows.isEmpty()) return GroupGraph(emptyList(), emptyList())
        val aliasToId = HashMap<String, Long>(rows.size * 4)
        fun putAlias(raw: String, id: Long) {
            val key = raw.trim().lowercase(Locale.ROOT)
            if (key.isNotEmpty()) aliasToId.putIfAbsent(key, id)
        }
        for (row in rows) {
            putAlias(row.title, row.id)
            putAlias(row.name, row.id)
            putAlias(row.name.removeSuffix(".md").removeSuffix(".MD")
                .removeSuffix(".markdown").removeSuffix(".MARKDOWN"), row.id)
            putAlias(row.relPath, row.id)
        }
        val edges = ArrayList<GroupGraphEdge>(rawLinks.size)
        val seen = HashSet<GroupGraphEdge>(rawLinks.size.coerceAtLeast(16))
        for (link in rawLinks) {
            val toId = aliasToId[link.targetNorm.trim().lowercase(Locale.ROOT)] ?: continue
            if (toId == link.fromId) continue
            val edge = GroupGraphEdge(link.fromId, toId)
            if (seen.add(edge)) edges.add(edge)
        }
        return GroupGraph(nodes, edges)
    }

    suspend fun graphGroupIndexForNote(noteId: Long, groupSize: Int): Int = withContext(Dispatchers.IO) {
        val safeSize = groupSize.coerceIn(1, 10_000)
        dao.graphPositionBefore(noteId) / safeSize
    }

    suspend fun tagsForNotes(ids: Collection<Long>): Map<Long, List<String>> =
        withContext(Dispatchers.IO) {
            val wanted = ids.toSet()
            if (wanted.isEmpty()) return@withContext emptyMap()
            val byNote = linkedMapOf<Long, MutableList<String>>()
            for (tag in workspaceTagIndex()) {
                for (id in tag.noteIds) {
                    if (id in wanted) byNote.getOrPut(id) { mutableListOf() }.add(tag.name)
                }
            }
            byNote.mapValues { (_, tags) -> tags.distinct().sorted().take(100) }
        }

    val immersiveViewEnabled: StateFlow<Boolean> =
        prefs.immersiveViewEnabled.stateIn(viewModelScope, SharingStarted.Eagerly, false)
    fun setImmersiveViewEnabled(v: Boolean) {
        viewModelScope.launch { prefs.setImmersiveViewEnabled(v) }
    }
    val workspacePinnedTabIds: StateFlow<Set<Long>> =
        prefs.workspacePinnedTabIds
            .map { raw -> raw.split('\u0000').mapNotNull { it.toLongOrNull() }.toSet() }
            .stateIn(viewModelScope, SharingStarted.Eagerly, emptySet())

    fun toggleWorkspaceTabPinned(id: Long) {
        val tab = _tabs.value.firstOrNull { it.id == id } ?: return
        val currentPins = workspacePinnedTabIds.value
        val pinning = id !in currentPins
        val next = currentPins.toMutableSet().apply {
            if (pinning) add(id) else remove(id)
        }
        if (pinning) {
            val reordered = _tabs.value.toMutableList()
            reordered.removeAll { it.id == id }
            val pinnedPrefixSize = reordered.takeWhile { it.id in currentPins }.size
            reordered.add(pinnedPrefixSize, tab)
            _tabs.value = reordered
            persistReaderTabsSession()
        }
        viewModelScope.launch { prefs.setWorkspacePinnedTabIds(next) }
    }

    /** Build the read-only Tags pane on demand; no vault content is modified. */
    suspend fun workspaceTagIndex(): List<WorkspaceTag> = withContext(Dispatchers.IO) {
        val rows = runCatching { dao.tagSourceRows() }.getOrElse { emptyList() }
        val byTag = linkedMapOf<String, MutableSet<Long>>()
        val inline = Regex("""(?<![\w/])#([\p{L}\p{N}_/-]+)""")
        for (row in rows) {
            val content = row.content
            val yaml = if (content.startsWith("---")) {
                content.substringAfter("---").substringBefore("---")
            } else ""
            val frontmatterTags = yaml.lineSequence()
                .firstOrNull { it.trimStart().startsWith("tags:", ignoreCase = true) }
                ?.substringAfter(':').orEmpty()
                .removePrefix("[").removeSuffix("]")
                .split(',', ' ', '\n')
                .asSequence()
                .map { it.trim().trimStart('#').trim('"', '\'') }
                .filter { it.isNotBlank() }
            val inlineTags = inline.findAll(content).map { it.groupValues[1] }.take(500)
            for (tag in frontmatterTags + inlineTags) {
                val normalized = tag.trim().trim('/').lowercase()
                if (normalized.isBlank() || normalized.length > 120) continue
                byTag.getOrPut(normalized) { linkedSetOf() }.add(row.id)
            }
        }
        byTag.entries
            .map { WorkspaceTag(it.key, it.value.toList()) }
            .sortedWith(compareByDescending<WorkspaceTag> { it.noteIds.size }.thenBy { it.name })
    }

    /**
     * v5.4.18 — True when the currently-opened article was navigated to from
     * a search-result tap. Drives visibility of the "search in article" FAB
     * so it doesn't clutter the reader when browsing normally.
     *
     * Set to true by SearchScreen when a result row is clicked; reset to
     * false in the reader's LaunchedEffect after the FAB has consumed it,
     * so navigating away and re-opening from Browse hides the FAB.
     */
    private val _openedFromSearch = MutableStateFlow(false)
    val openedFromSearch: StateFlow<Boolean> = _openedFromSearch.asStateFlow()
    fun markOpenedFromSearch() { _openedFromSearch.value = true }
    fun clearOpenedFromSearch() { _openedFromSearch.value = false }

    /**
     * v5.4.18 — Semantic in-article search. Splits the article by paragraph,
     * embeds each with the active embedder, computes cosine similarity to
     * the query embedding, and returns the top paragraph's leading phrase
     * (first ~40 chars) so the reader can scroll/find to it.
     *
     * Returns null if the embedder isn't available, if the article has too
     * few embeddable paragraphs, or if any step fails. All failures are
     * silent — the caller falls back to keyword find. Runs on Dispatchers.IO
     * because embedding a page's worth of paragraphs can take a few seconds
     * on 6 GB devices.
     */
    suspend fun semanticInArticleFindTopSnippet(
        articleText: String, query: String
    ): String? = withContext(Dispatchers.IO) {
        try {
            val q = query.trim().removeSurrounding("\"").trim()
            if (q.length < 2 || articleText.isBlank()) return@withContext null
            // Simple paragraph split. Keep paragraphs of at least 40 chars
            // — anything shorter is noise (headings, single-line captions).
            val paragraphs = articleText
                .split(Regex("\\n\\s*\\n"))
                .map { it.trim() }
                .filter { it.length >= 40 }
                .take(80)  // cap so embedding stays snappy on long articles
            if (paragraphs.size < 2) return@withContext null

            // Use the same embedder the global semantic index uses.
            // v5.4.172cc — Same conditional BGE query prefix as
            // semanticSearchInner; see that function's comment for why.
            val queryForEmbedding = if (embedder.descriptor.poolingStrategy == com.tebogo.markvault.search.PoolingStrategy.CLS) {
                "Represent this sentence for searching relevant passages: $q"
            } else {
                q
            }
            val queryVec = embedText(queryForEmbedding) ?: return@withContext null
            var bestIdx = -1
            var bestScore = Float.NEGATIVE_INFINITY
            for ((i, p) in paragraphs.withIndex()) {
                val v = embedText(p) ?: continue
                val s = cosineSimilarity(queryVec, v)
                if (s > bestScore) { bestScore = s; bestIdx = i }
            }
            if (bestIdx < 0) return@withContext null
            // Return the first sentence-ish chunk of the winning paragraph
            // — long enough to be a unique WebView find target but short
            // enough that partial rendering artifacts don't break it.
            val winning = paragraphs[bestIdx]
            val firstSentence = winning
                .split(Regex("(?<=[.!?])\\s+"))
                .firstOrNull { it.length >= 20 }
                ?: winning
            firstSentence.take(60).trim()
        } catch (t: Throwable) {
            android.util.Log.e("MarkVault", "semanticInArticleFindTopSnippet failed", t)
            null
        }
    }

    /**
     * v5.4.18 — Embed a single text using the active embedder. Wraps the
     * existing embedder instance the semantic index already uses.
     * Returns null if no embedder is loaded or embedding fails.
     */
    private suspend fun embedText(text: String): FloatArray? = withContext(Dispatchers.IO) {
        try {
            embedder.embed(text)
        } catch (t: Throwable) {
            null
        }
    }

    // ────────────────────────────────────────────────────────────────
    // v5.4.129cc — In-article semantic-search popup state machine.
    //
    // The reader's 🧠 button calls [findAndShowArticlePassages], which
    // splits the article into paragraphs, embeds each, ranks by cosine
    // similarity to the query, and populates [articlePopupState] with
    // the top passages. The popup UI ([ArticlePopupOverlay]) observes
    // this state and renders / types / hides itself accordingly.
    //
    // States:
    //   • Hidden   — no popup shown (initial + after close)
    //   • Loading  — embedding in progress (usually <1 s)
    //   • Empty    — search ran but nothing cleared the threshold
    //   • Visible  — passages ready; may be minimized to a pill
    //
    // The state resets to Hidden whenever the active article changes,
    // so switching notes never leaves a stale popup on screen.
    // ────────────────────────────────────────────────────────────────

    /** Similarity floor for passages returned in the popup. Values from
     *  the L2-normalised BGE-large output typically land 0.30–0.70 on
     *  strong hits, 0.20–0.30 on weak, <0.20 on unrelated content. */
    private val ARTICLE_POPUP_SIM_THRESHOLD: Float = 0.32f

    /** How many top passages to include in the popup, at most. */
    private val ARTICLE_POPUP_TOP_K: Int = 4

    /**
     * v5.4.141cc — Which content the in-article popup displays.
     *
     *   HIGHLIGHTS  — semantic passage search (existing behaviour): the
     *                 embedder ranks chunks by cosine similarity and the
     *                 top-K appear in the popup, matching the yellow
     *                 highlights in the article body.
     *   LLM_SUMMARY — the selected on-device LLM reads the article and
     *                 produces ≤6 key-point bullet lines. Nothing is
     *                 re-embedded; only the LLM runs.
     */
    enum class ArticlePopupMode { HIGHLIGHTS, LLM_SUMMARY }

    sealed class ArticlePopupState {
        object Hidden : ArticlePopupState()
        data class Loading(val noteId: Long, val query: String) : ArticlePopupState()
        data class Empty(val noteId: Long, val query: String) : ArticlePopupState()
        data class Visible(
            val noteId: Long,
            val query: String,
            /** Passages in the order they appear in the article
             *  (not by descending score) so reading them top-to-bottom
             *  in the popup mirrors reading the article top-to-bottom. */
            val passages: List<String>,
            val minimized: Boolean,
            /**
             * v5.4.135cc — File type of the article whose "📖 Open"
             * button the popup should route to. NULL for the readers'
             * single-article popup (the article is already open — no
             * button shown). NON-NULL for the SearchScreen multi-
             * article popup (opens the highest-rated article via the
             * appropriate reader route: reader / htmlReader / pdfReader).
             */
            val openableFileType: String? = null,
            /** v5.4.141cc — Which mode produced this content. */
            val mode: ArticlePopupMode = ArticlePopupMode.HIGHLIGHTS
        ) : ArticlePopupState()
    }

    private val _articlePopupState =
        MutableStateFlow<ArticlePopupState>(ArticlePopupState.Hidden)
    val articlePopupState: StateFlow<ArticlePopupState> = _articlePopupState

    /**
     * v5.4.142cc — Persists the user's chosen popup mode across open/close
     * cycles within a session. Resets to HIGHLIGHTS on cold start.
     */
    private val _articlePopupMode = MutableStateFlow(ArticlePopupMode.HIGHLIGHTS)
    val articlePopupMode: StateFlow<ArticlePopupMode> = _articlePopupMode

    /**
     * v5.4.150cc — Cache of the article text most recently passed to
     * [findAndShowArticlePassages]. Needed so SearchScreen can call
     * [toggleArticlePopupMode] without re-loading the article — the
     * SearchScreen popup doesn't hold a reference to the full article body,
     * but the ViewModel already read it while building the passages.
     * Volatile string — no DataStore persistence needed; a process restart
     * also closes any open popup, so the cached value is never stale.
     */
    @Volatile
    private var _cachedArticleTextForPopup: String = ""
    val cachedArticleTextForPopup: String get() = _cachedArticleTextForPopup

    /**
     * v5.4.150cc — Popup typewriter speed backed by DataStore so the
     * slider value survives app exit. Exposed as a StateFlow so Compose
     * screens can collectAsStateWithLifecycle() and pass it down.
     */
    val popupTypingSpeed: StateFlow<Float> = prefs.popupTypingSpeed
        .stateIn(viewModelScope, kotlinx.coroutines.flow.SharingStarted.Eagerly, 1.0f)

    fun setPopupTypingSpeed(v: Float) {
        viewModelScope.launch { prefs.setPopupTypingSpeed(v) }
    }

    /**
     * v5.4.142cc — A popup that has been collapsed to a draggable floating
     * bubble. Multiple bubbles from different articles can exist at once.
     * Tapping a bubble restores it to a full popup window; dragging it to
     * the bottom of the screen and tapping a close target removes it.
     */
    data class PopupBubble(
        val id: String,
        val noteId: Long,
        val query: String,
        val passages: List<String>,
        val mode: ArticlePopupMode,
        val openableFileType: String? = null
    )

    private val _popupBubbles = MutableStateFlow<List<PopupBubble>>(emptyList())
    val popupBubbles: StateFlow<List<PopupBubble>> = _popupBubbles

    /**
     * v5.4.129cc — Run a passage-level semantic search inside the
     * currently-open article and push the results into the popup state.
     *
     * The embedder loads on first call and stays loaded until
     * [freeMemory] is invoked, so subsequent invocations for the same
     * article are limited by embedding cost (roughly linear in the
     * article length, ~50 ms per paragraph on a Snapdragon 732G).
     *
     * A previous [findAndShowArticlePassages] call for a different
     * (noteId, query) is superseded by mapLatest — no leftover
     * embedding work continues after a new tap.
     */
    fun findAndShowArticlePassages(
        noteId: Long, articleText: String, rawQuery: String
    ) {
        val q = rawQuery.trim().removeSurrounding("\"").trim()
        if (q.length < 2 || articleText.isBlank()) {
            _articlePopupState.value = ArticlePopupState.Hidden
            return
        }
        // v5.4.150cc — Cache so SearchScreen's onToggleMode can call
        // toggleArticlePopupMode without needing its own copy of the text.
        _cachedArticleTextForPopup = articleText
        // v5.4.142cc — If a full popup is visible for a DIFFERENT article,
        // collapse it to a bubble before loading this one so the user
        // doesn't lose their previous findings.
        val cur = _articlePopupState.value
        if (cur is ArticlePopupState.Visible && cur.noteId != noteId) {
            minimizeCurrentPopupToBubble()
        }
        _articlePopupState.value = ArticlePopupState.Loading(noteId, q)
        viewModelScope.launch(Dispatchers.IO) {
            val passages = runCatching {
                findArticlePassages(articleText, q)
            }.getOrElse { emptyList() }
            // If the state has been changed to Hidden or superseded by
            // a newer request in the meantime, don't clobber it.
            val cur = _articlePopupState.value
            val stillOurs = (cur is ArticlePopupState.Loading &&
                cur.noteId == noteId && cur.query == q)
            if (!stillOurs) return@launch
            _articlePopupState.value = if (passages.isEmpty()) {
                ArticlePopupState.Empty(noteId, q)
            } else {
                ArticlePopupState.Visible(
                    noteId = noteId,
                    query = q,
                    passages = passages,
                    minimized = false
                )
            }
        }
    }

    /**
     * Core passage-ranking routine. Reused by both the popup (which
     * wants full passage text) and [semanticInArticleFindTopSnippet]
     * (which wants a short WebView-findable string). Returns top-K
     * passages above [ARTICLE_POPUP_SIM_THRESHOLD], ordered by their
     * position in the article (so the popup reads top-to-bottom).
     *
     * v5.4.135cc — SWITCHED from paragraph-based ranking to
     * fixed-size overlapping-chunk ranking, as requested.
     *
     * The old paragraph-based flow lost context at paragraph
     * boundaries: a query about "condition of the dead" might match
     * paragraph N loosely and paragraph N+1 loosely, but the concept
     * really lives in the OVERLAP between them. Fixed-size sliding
     * windows fix this — every point in the document appears in at
     * least one chunk with the context around it.
     *
     * Chunk parameters:
     *   • Target size : ~180 words per chunk (~900–1100 chars, well
     *                   under the embedder's 1500-char slice limit).
     *   • Overlap     :  45 words (25%) — the tail of chunk N is the
     *                    head of chunk N+1, so a sentence that spans
     *                    them is embedded in both with full context
     *                    either side.
     *   • Minimum     :  30 words — anything smaller becomes its own
     *                    chunk without splitting.
     *
     * De-overlap of top-K: if two winning chunks come from adjacent
     * windows (their starts differ by < half the chunk size), we keep
     * the higher-scoring one only. Otherwise the popup shows the same
     * text twice.
     */
    private suspend fun findArticlePassages(
        articleText: String, query: String
    ): List<String> = withContext(Dispatchers.IO) {
        val q = query.trim()
        if (q.isEmpty() || articleText.isBlank()) return@withContext emptyList()

        // HTML detection + strip stays the same — chunking still
        // benefits from clean plain text without markup contamination.
        val processedText: String = if (looksLikeFullHtml(articleText)) {
            stripHtmlToPlainText(articleText)
        } else {
            articleText
        }
        if (processedText.isBlank()) return@withContext emptyList()

        val chunks: List<com.tebogo.markvault.search.TextChunk> = com.tebogo.markvault.search.buildOverlappingChunks(
            processedText,
            targetWords = 180,
            overlapWords = 45,
            minWords = 30
        )
        if (chunks.isEmpty()) return@withContext emptyList()

        // v5.4.172cc — Same conditional BGE query prefix as
        // semanticSearchInner; see that function's comment for why.
        val queryForEmbedding = if (embedder.descriptor.poolingStrategy == com.tebogo.markvault.search.PoolingStrategy.CLS) {
            "Represent this sentence for searching relevant passages: $q"
        } else {
            q
        }
        val queryVec: FloatArray = embedText(queryForEmbedding) ?: return@withContext emptyList()

        data class Scored(
            val startWord: Int,
            val text: String,
            val score: Float
        )
        val scored: MutableList<Scored> = mutableListOf()
        for (chunk in chunks) {
            val v: FloatArray = embedText(chunk.text) ?: continue
            val s: Float = com.tebogo.markvault.search.cosineSimilarity(queryVec, v)
            if (s >= ARTICLE_POPUP_SIM_THRESHOLD) {
                scored.add(Scored(chunk.startWordIdx, chunk.text, s))
            }
        }
        if (scored.isEmpty()) return@withContext emptyList()

        // Top-K by score, then de-overlap so the popup doesn't show
        // near-identical windows one after the other.
        val topBy: List<Scored> = scored.sortedByDescending { it.score }
        val kept: MutableList<Scored> = mutableListOf()
        val dedupWindow: Int = 90   // half the target chunk size (180 words)
        for (candidate in topBy) {
            val clashes: Boolean = kept.any { existing ->
                kotlin.math.abs(existing.startWord - candidate.startWord) < dedupWindow
            }
            if (!clashes) kept.add(candidate)
            if (kept.size >= ARTICLE_POPUP_TOP_K) break
        }
        // Present in document order so the popup reads top-to-bottom.
        kept.sortedBy { it.startWord }.map { it.text }
    }

    /**
     * v5.5.6 — Semantic article-highlighting fallback.
     *
     * Search-result snippets are unavailable for pure semantic/reranked
     * hits, so the normal lexical highlighter can legitimately find no
     * literal query words even though the article ranked highly. This
     * routine uses the same BGE embedding path as the article passage
     * ranker, but reduces the winning semantic chunks to their strongest
     * individual sentences. The returned strings are literal article text
     * so the WebView readers can highlight the actual semantically relevant
     * passages instead of inventing keywords.
     */
    suspend fun findArticleSemanticHighlightSentences(
        noteId: Long,
        articleText: String,
        query: String,
        searchSnippet: String = ""
    ): List<String> = withContext(Dispatchers.IO) {
        val q = query.trim().removeSurrounding("\"").trim()
        if (q.length < 2 || articleText.isBlank() || !semanticEnabled.value) {
            return@withContext emptyList()
        }
        // v5.5.16 — When Question Awareness is enabled, semantic in-article
        // highlighting follows the same answer-oriented intent as retrieval.
        // This affects only which literal article sentences are highlighted; it
        // never changes candidate retrieval, scores, or reranker ordering.
        val questionAnalysis = com.tebogo.markvault.search.QuestionAwareness.analyze(q)
        val semanticHighlightQuery = if (questionAwarenessEnabled.value && questionAnalysis.usedSuccessfully) {
            questionAnalysis.primarySemanticQuery ?: q
        } else q
        val articleIsHtml = looksLikeFullHtml(articleText)
        val processedText = if (articleIsHtml) {
            stripHtmlToPlainText(articleText)
        } else {
            // v5.5.16 — Semantic highlights must be selected from the text the
            // reader actually displays. Raw Markdown can contain link URLs,
            // emphasis markers and wikilink syntax that do not exist in the
            // rendered DOM, making an otherwise-correct semantic sentence
            // impossible to highlight. Strip only presentation markup here;
            // search retrieval/ranking continues to use its existing pipeline.
            stripMarkdownForSemanticHighlight(articleText)
        }
        if (processedText.isBlank()) return@withContext emptyList()

        // v5.5.20 — Long-article highlighting used to re-embed EVERY 180-word
        // window in the article after the user tapped a result. On large notes
        // this repeated work already performed by the semantic index and made
        // the loading indicator sit for many seconds. Reuse the CURRENT model's
        // persisted per-note embeddings first. Those are the same 350/70 chunks
        // that semantic retrieval/reranking use, so this removes redundant
        // inference without relaxing any relevance threshold or changing search
        // scores. We then re-embed only a tiny local 180-word neighbourhood and
        // its sentences to keep the final highlight precise.
        val modelVersion = embedder.modelVersion
        val queryForEmbedding = if (
            embedder.descriptor.poolingStrategy == com.tebogo.markvault.search.PoolingStrategy.CLS
        ) {
            "Represent this sentence for searching relevant passages: $semanticHighlightQuery"
        } else semanticHighlightQuery
        val queryVec = embedText(queryForEmbedding) ?: return@withContext emptyList()

        data class ChunkScore(val start: Int, val text: String, val score: Float)

        fun cleanCandidateText(raw: String): String {
            return if (articleIsHtml || looksLikeFullHtml(raw)) {
                stripHtmlToPlainText(raw)
            } else {
                stripMarkdownForSemanticHighlight(raw)
            }.replace(Regex("\\s+"), " ").trim()
        }

        fun anchorAppearsInArticle(candidate: String): Boolean {
            val words = candidate.lowercase()
                .replace(Regex("[^\\p{L}\\p{N}]+"), " ")
                .trim()
                .split(Regex("\\s+"))
                .filter { it.isNotBlank() }
            if (words.size < 6) return candidate.length >= 20 &&
                processedText.contains(candidate, ignoreCase = true)
            val articleNorm = processedText.lowercase()
                .replace(Regex("[^\\p{L}\\p{N}]+"), " ")
                .replace(Regex("\\s+"), " ")
            val probes = listOf(0, (words.size / 2 - 4).coerceAtLeast(0), (words.size - 8).coerceAtLeast(0))
                .distinct()
            return probes.any { startWord ->
                val endWord = (startWord + 8).coerceAtMost(words.size)
                val anchor = words.subList(startWord, endWord).joinToString(" ")
                anchor.length >= 24 && articleNorm.contains(anchor)
            }
        }

        suspend fun indexedLocalCandidates(): List<ChunkScore> {
            if (noteId <= 0L) return emptyList()
            val note = runCatching { dao.byId(noteId) }.getOrNull() ?: return emptyList()
            if (note.content.isBlank()) return emptyList()

            val sourceChunks = com.tebogo.markvault.search.buildOverlappingChunks(
                note.content,
                targetWords = 350,
                overlapWords = 70,
                minWords = 30
            ).ifEmpty {
                listOf(com.tebogo.markvault.search.TextChunk(note.content, 0))
            }
            if (sourceChunks.isEmpty()) return emptyList()

            val rows = runCatching {
                dao.loadEmbeddingsForNotes(modelVersion, listOf(noteId))
            }.getOrElse { emptyList() }
            if (rows.isEmpty()) return emptyList()

            // Reject stale rows. This is a reader optimisation only; if the
            // index does not exactly belong to the current note revision we
            // fall back to the original full-text computation below.
            val scoredBroad = rows.asSequence()
                .filter { row ->
                    row.sourceLastModified == note.lastModified &&
                        row.chunkIndex in sourceChunks.indices &&
                        row.vector.size == queryVec.size * 4
                }
                .mapNotNull { row ->
                    val score = normalizedEmbeddingDot(queryVec, row.vector)
                    if (!score.isFinite()) null else Triple(row.chunkIndex, score, sourceChunks[row.chunkIndex])
                }
                .sortedByDescending { it.second }
                .take(3)
                .toList()
            if (scoredBroad.isEmpty()) return emptyList()

            // Map stored source chunks back to display text. This validation is
            // especially important for offline HTML, where an older library row
            // may contain only metadata while the reader has the full file body.
            val broadTexts = scoredBroad.mapNotNull { (_, _, chunk) ->
                val cleaned = cleanCandidateText(chunk.text)
                cleaned.takeIf { it.length >= 24 && anchorAppearsInArticle(it) }
            }.distinct()
            if (broadTexts.isEmpty()) return emptyList()

            // Precision refinement is deliberately local and bounded. A 350-word
            // indexed chunk expands to at most three 180-word windows, so even a
            // 50,000-word article now needs only a handful of fresh embeddings.
            val localScores = ArrayList<ChunkScore>(8)
            for (broad in broadTexts.take(2)) {
                val localChunks = com.tebogo.markvault.search.buildOverlappingChunks(
                    broad,
                    targetWords = 180,
                    overlapWords = 45,
                    minWords = 30
                ).ifEmpty {
                    listOf(com.tebogo.markvault.search.TextChunk(broad, 0))
                }
                for (chunk in localChunks) {
                    val vec = embedText(chunk.text) ?: continue
                    val score = com.tebogo.markvault.search.cosineSimilarity(queryVec, vec)
                    if (score.isFinite()) {
                        localScores += ChunkScore(chunk.startWordIdx, chunk.text, score)
                    }
                }
            }
            return localScores
                .distinctBy { it.text.lowercase() }
                .sortedByDescending { it.score }
                .take(2)
        }

        var topChunks: List<ChunkScore> = indexedLocalCandidates()

        if (topChunks.isEmpty()) {
            // v5.5.20 — If this is a keyword/hybrid result whose semantic index
            // is unavailable, an exact FTS snippet gives us a trustworthy local
            // starting point. Restrict the expensive fallback to that surrounding
            // context. Pure-semantic hits normally take the indexed path above;
            // if neither signal is available we preserve the old full-document
            // scan below rather than trading accuracy for speed.
            val snippet = searchSnippet.trim()
            val localText = if (snippet.length >= 12) {
                val at = processedText.indexOf(snippet, ignoreCase = true)
                if (at >= 0) {
                    val from = (at - 6_000).coerceAtLeast(0)
                    val to = (at + snippet.length + 6_000).coerceAtMost(processedText.length)
                    processedText.substring(from, to)
                } else null
            } else null

            val scanText = localText ?: processedText
            val chunks = com.tebogo.markvault.search.buildOverlappingChunks(
                scanText,
                targetWords = 180,
                overlapWords = 45,
                minWords = 30
            )
            if (chunks.isEmpty()) return@withContext emptyList()

            val scoredChunks = chunks.mapNotNull { chunk ->
                val vec = embedText(chunk.text) ?: return@mapNotNull null
                val score = com.tebogo.markvault.search.cosineSimilarity(queryVec, vec)
                if (!score.isFinite()) return@mapNotNull null
                ChunkScore(chunk.startWordIdx, chunk.text, score)
            }.sortedByDescending { it.score }

            topChunks = scoredChunks.filter { it.score >= ARTICLE_POPUP_SIM_THRESHOLD }
                .take(4)
                .ifEmpty { scoredChunks.take(2) }
        }

        if (topChunks.isEmpty()) return@withContext emptyList()

        data class SentenceScore(val text: String, val score: Float)
        val candidates = LinkedHashMap<String, SentenceScore>()
        for (chunk in topChunks) {
            val sentences = chunk.text
                .replace(Regex("\\s+"), " ")
                .trim()
                .split(Regex("(?<=[.!?])\\s+"))
                .map { it.trim() }
                .filter { it.length >= 24 }
            for (sentence in sentences) {
                val vec = embedText(sentence) ?: continue
                val score = com.tebogo.markvault.search.cosineSimilarity(queryVec, vec)
                if (score.isFinite()) {
                    val key = sentence.lowercase()
                    val old = candidates[key]
                    if (old == null || score > old.score) {
                        candidates[key] = SentenceScore(sentence, score)
                    }
                }
            }
        }

        val orderedSentences = candidates.values.sortedByDescending { it.score }
        orderedSentences.filter { it.score >= ARTICLE_POPUP_SIM_THRESHOLD }
            .take(6)
            .ifEmpty { orderedSentences.take(3) }
            .map { it.text }
    }

    /** Internal chunk record — see [findArticlePassages]. */
    // v5.4.174cc — buildOverlappingChunks/ArticleChunk moved to the shared
    // com.tebogo.markvault.search.TextChunker.kt (as buildOverlappingChunks/
    // TextChunk) so the main embedding index can reuse the exact same,
    // already-proven splitting logic instead of a second copy.

    /**
     * v5.4.133cc — True only for content that looks like a real HTML
     * document (not markdown with a few HTML tags sprinkled in).
     *
     * Fires on structural tags (`<html>`, `<body>`, `<!doctype>`) or
     * on three-plus `<p ...>` opens in the first 3 kB. Three is the
     * threshold because well-formed articles have many paragraphs
     * whereas a stray HTML embed in markdown might have one or two.
     */
    private fun looksLikeFullHtml(text: String): Boolean {
        val sample: String = text.take(3000).lowercase()
        if (sample.contains("<!doctype html")) return true
        if (sample.contains("<html")) return true
        if (sample.contains("<body")) return true
        val pOpens: Int = Regex("<p[\\s>]").findAll(sample).take(3).count()
        return pOpens >= 3
    }

    /**
     * v5.5.16 — Minimal Markdown-to-visible-text cleanup for semantic
     * in-article highlighting. It intentionally does not participate in
     * indexing or search scoring; its only job is to make the sentence strings
     * returned to WebView resemble the rendered article text closely enough to
     * be highlighted reliably (especially around Markdown links/wikilinks).
     */
    private fun stripMarkdownForSemanticHighlight(markdown: String): String {
        var text = markdown
        if (text.startsWith("---")) {
            val end = text.indexOf("\n---", startIndex = 3)
            if (end >= 0) text = text.substring(end + 4)
        }
        text = text
            .replace(Regex("!\\[([^\\]]*)]\\([^)]*\\)"), "$1")
            .replace(Regex("\\[([^\\]]+)]\\([^)]*\\)"), "$1")
            .replace(Regex("\\[\\[([^\\[\\]|#^\\n]+)(?:#[^\\[\\]|\\n]*)?(?:\\^[^\\[\\]|\\n]*)?(?:\\|([^\\[\\]\\n]+))?]]")) { m ->
                m.groupValues[2].ifBlank { m.groupValues[1] }
            }
            .replace(Regex("^#{1,6}\\s+", RegexOption.MULTILINE), "")
            .replace(Regex("^>+\\s?", RegexOption.MULTILINE), "")
            .replace(Regex("^\\s*[-*+]\\s+", RegexOption.MULTILINE), "")
            .replace(Regex("^\\s*\\d+[.)]\\s+", RegexOption.MULTILINE), "")
            .replace(Regex("\\*\\*([^*]+)\\*\\*"), "$1")
            .replace(Regex("__([^_]+)__"), "$1")
            .replace(Regex("~~([^~]+)~~"), "$1")
            .replace(Regex("`([^`]+)`"), "$1")
            .replace(Regex("(?<!\\*)\\*([^*\\n]+)\\*(?!\\*)"), "$1")
            .replace(Regex("(?<!_)_([^_\\n]+)_(?!_)"), "$1")
            .replace(Regex("<[^>]+>"), " ")
            .replace("&nbsp;", " ")
            .replace("&amp;", "&")
            .replace("&lt;", "<")
            .replace("&gt;", ">")
            .replace("&quot;", "\"")
            .replace("&#39;", "'")
            .replace(Regex("[ \\t]+"), " ")
            .replace(Regex(" ?\\n ?"), "\n")
            .replace(Regex("\\n{3,}"), "\n\n")
        return text.trim()
    }

    /**
     * v5.4.133cc — Convert HTML source to plain text with paragraph
     * boundaries preserved as double-newlines so the downstream split
     * on `\n\s*\n` produces sensible chunks.
     *
     * Order of operations matters:
     *   1. Rip out `<script>` / `<style>` blocks (their contents are
     *      JS / CSS, not article text).
     *   2. Strip HTML comments.
     *   3. Turn block-close tags (`</p>`, `</div>`, `</h1..6>` etc.)
     *      into double-newlines — this is what creates paragraph
     *      boundaries.
     *   4. Turn `<br>` into single newlines.
     *   5. Strip all remaining tags (inline formatting).
     *   6. Decode the common HTML entities.
     *   7. Normalize whitespace.
     */
    private fun stripHtmlToPlainText(html: String): String {
        var text: String = html
        // <script>…</script>
        text = text.replace(
            Regex("<script[^>]*>[\\s\\S]*?</script>", RegexOption.IGNORE_CASE),
            " "
        )
        // <style>…</style>
        text = text.replace(
            Regex("<style[^>]*>[\\s\\S]*?</style>", RegexOption.IGNORE_CASE),
            " "
        )
        // <!-- comments -->
        text = text.replace(Regex("<!--[\\s\\S]*?-->"), " ")
        // Block-close tags → double newline (creates paragraph breaks)
        text = text.replace(
            Regex(
                "</(p|div|h[1-6]|section|article|blockquote|li|tr|td|th|figure|figcaption|main|header|footer|aside|nav)\\s*>",
                RegexOption.IGNORE_CASE
            ),
            "\n\n"
        )
        // Also treat opening headings as break points (they usually
        // start a new logical section)
        text = text.replace(
            Regex("<h[1-6][^>]*>", RegexOption.IGNORE_CASE),
            "\n\n"
        )
        // <br> variants → single newline
        text = text.replace(
            Regex("<br\\s*/?>", RegexOption.IGNORE_CASE),
            "\n"
        )
        // Strip all remaining tags (inline formatting we don't need
        // for embedding). Passages will be plain text.
        text = text.replace(Regex("<[^>]+>"), " ")
        // Common HTML entities
        text = text
            .replace("&nbsp;", " ")
            .replace("&amp;", "&")
            .replace("&lt;", "<")
            .replace("&gt;", ">")
            .replace("&quot;", "\"")
            .replace("&#39;", "'")
            .replace("&apos;", "'")
            .replace("&ldquo;", "\u201C")
            .replace("&rdquo;", "\u201D")
            .replace("&lsquo;", "\u2018")
            .replace("&rsquo;", "\u2019")
            .replace("&hellip;", "\u2026")
            .replace("&mdash;", "\u2014")
            .replace("&ndash;", "\u2013")
            .replace("&copy;", "\u00A9")
            .replace("&reg;", "\u00AE")
        // Also decode numeric character refs like &#8220;
        text = text.replace(Regex("&#(\\d+);")) { m ->
            runCatching {
                val code: Int = m.groupValues[1].toInt()
                if (code in 32..1114111) code.toChar().toString() else " "
            }.getOrDefault(" ")
        }
        // Normalize whitespace: collapse runs of spaces/tabs, collapse
        // 3+ newlines to 2, trim leading/trailing whitespace on lines.
        text = text.replace(Regex("[ \\t]+"), " ")
        text = text.replace(Regex(" ?\\n ?"), "\n")
        text = text.replace(Regex("\\n{3,}"), "\n\n")
        return text.trim()
    }

    /** Collapse the popup to a bottom-of-screen pill. No-op unless the
     *  current state is Visible. */
    fun minimizeArticlePopup() {
        val cur = _articlePopupState.value
        if (cur is ArticlePopupState.Visible && !cur.minimized) {
            _articlePopupState.value = cur.copy(minimized = true)
        }
    }

    /** Expand the popup back to full size. No-op unless it's Visible
     *  and currently minimized. Also used by the brain button to bring
     *  a minimized popup back into view. */
    fun maximizeArticlePopup() {
        val cur = _articlePopupState.value
        if (cur is ArticlePopupState.Visible && cur.minimized) {
            _articlePopupState.value = cur.copy(minimized = false)
        }
    }

    /** Dismiss the popup entirely. From any state. */
    fun closeArticlePopup() {
        _articlePopupState.value = ArticlePopupState.Hidden
    }

    /**
     * v5.4.144cc — Set the popup to the Loading state so the spinner
     * shows immediately while the caller extracts highlighted passages
     * from the WebView via evaluateJavascript.
     */
    fun setArticlePopupLoading(noteId: Long, query: String) {
        val q = query.trim()
        if (q.isBlank()) return
        _articlePopupState.value = ArticlePopupState.Loading(noteId, q)
    }

    /**
     * v5.4.144cc — Populate the popup with a pre-built list of passages
     * (extracted from yellow <mark.mv-hl> / .term-hit elements in the
     * WebView's DOM). Transitions to Empty when [passages] is empty,
     * so "no yellow highlights in the article → popup shows nothing".
     */
    fun showArticlePopupWithPassages(noteId: Long, query: String, passages: List<String>) {
        val q = query.trim()
        if (q.isBlank()) return
        _articlePopupState.value = if (passages.isEmpty()) {
            ArticlePopupState.Empty(noteId, q)
        } else {
            ArticlePopupState.Visible(
                noteId = noteId,
                query = q,
                passages = passages,
                minimized = false
            )
        }
    }

    // ── v5.4.142cc — Multi-popup bubble system ──────────────────────────────

    /**
     * Collapse the current full popup to a draggable floating bubble so a
     * new popup can open without losing the existing content. The bubble
     * persists in [popupBubbles] until the user explicitly closes it.
     *
     * No-op when no Visible popup exists.
     */
    fun minimizeCurrentPopupToBubble() {
        val cur = _articlePopupState.value as? ArticlePopupState.Visible ?: return
        val bubble = PopupBubble(
            id = java.util.UUID.randomUUID().toString(),
            noteId = cur.noteId,
            query = cur.query,
            passages = cur.passages,
            mode = cur.mode,
            openableFileType = cur.openableFileType
        )
        _popupBubbles.value = _popupBubbles.value + bubble
        _articlePopupState.value = ArticlePopupState.Hidden
    }

    /**
     * Restore a bubble to a full popup window.
     * If a full popup is already showing, it becomes a bubble first so
     * no content is lost. The restored bubble is removed from [popupBubbles].
     */
    fun restoreBubble(bubbleId: String) {
        val bubble = _popupBubbles.value.find { it.id == bubbleId } ?: return
        // If another popup is currently showing, fold it into bubbles.
        val cur = _articlePopupState.value
        if (cur is ArticlePopupState.Visible) {
            val existing = PopupBubble(
                id = java.util.UUID.randomUUID().toString(),
                noteId = cur.noteId,
                query = cur.query,
                passages = cur.passages,
                mode = cur.mode,
                openableFileType = cur.openableFileType
            )
            _popupBubbles.value = _popupBubbles.value
                .filter { it.id != bubbleId } + existing
        } else {
            _popupBubbles.value = _popupBubbles.value.filter { it.id != bubbleId }
        }
        _articlePopupState.value = ArticlePopupState.Visible(
            noteId = bubble.noteId,
            query = bubble.query,
            passages = bubble.passages,
            minimized = false,
            openableFileType = bubble.openableFileType,
            mode = bubble.mode
        )
    }

    /** Remove one bubble by its unique ID. */
    fun closeBubble(bubbleId: String) {
        _popupBubbles.value = _popupBubbles.value.filter { it.id != bubbleId }
    }

    /** Close every bubble AND dismiss the current full popup. */
    fun closeAllPopupsAndBubbles() {
        _popupBubbles.value = emptyList()
        _articlePopupState.value = ArticlePopupState.Hidden
    }

    /**
     * v5.4.141cc — Toggle between HIGHLIGHTS and LLM_SUMMARY mode and
     * immediately re-run the appropriate backend so the popup refreshes.
     *
     * Called by the mode-toggle chips inside [ArticlePopupOverlay].
     * Safe to call from the main thread — both backends dispatch to IO.
     */
    fun toggleArticlePopupMode(
        noteId: Long,
        articleText: String,
        rawQuery: String
    ) {
        val next = if (_articlePopupMode.value == ArticlePopupMode.HIGHLIGHTS)
            ArticlePopupMode.LLM_SUMMARY
        else
            ArticlePopupMode.HIGHLIGHTS
        _articlePopupMode.value = next
        when (next) {
            ArticlePopupMode.HIGHLIGHTS ->
                findAndShowArticlePassages(noteId, articleText, rawQuery)
            ArticlePopupMode.LLM_SUMMARY ->
                generateArticlePopupSummary(noteId, articleText, rawQuery)
        }
    }

    /**
     * v5.4.141cc — Generate an LLM key-point summary of the current article
     * and push the result into [articlePopupState] as a Visible state
     * (Mode B). Does NOT route through [_chatMessages] — the popup is
     * self-contained and must not disturb the chat history.
     *
     * Falls back gracefully: if the LLM is not installed or generation
     * fails, emits an Empty state so the popup shows "nothing found"
     * rather than crashing, and resets the mode to HIGHLIGHTS.
     */
    fun generateArticlePopupSummary(
        noteId: Long,
        articleText: String,
        rawQuery: String
    ) {
        val q = rawQuery.trim().removeSurrounding("\"").trim().ifBlank { "Summary" }
        // v5.4.142cc — Auto-bubble any existing full popup for a different article.
        val curState = _articlePopupState.value
        if (curState is ArticlePopupState.Visible && curState.noteId != noteId) {
            minimizeCurrentPopupToBubble()
        }
        _articlePopupState.value = ArticlePopupState.Loading(noteId, q)
        viewModelScope.launch(Dispatchers.IO) {
            val points: List<String> = runCatching {
                summariseArticleIntoKeyPoints(articleText)
            }.getOrElse { emptyList() }

            val cur = _articlePopupState.value
            val stillOurs = cur is ArticlePopupState.Loading &&
                cur.noteId == noteId && cur.query == q
            if (!stillOurs) return@launch

            _articlePopupState.value = if (points.isEmpty()) {
                // LLM unavailable or empty output — revert mode so the
                // next brain-tap defaults back to semantic passages.
                _articlePopupMode.value = ArticlePopupMode.HIGHLIGHTS
                ArticlePopupState.Empty(noteId, q)
            } else {
                ArticlePopupState.Visible(
                    noteId = noteId,
                    query = q,
                    passages = points,
                    minimized = false,
                    mode = ArticlePopupMode.LLM_SUMMARY
                )
            }
        }
    }

    /**
     * v5.4.141cc — Call the active on-device LLM and collect its output
     * as a list of ≤6 key-point strings (one per list item).
     *
     * The prompt asks explicitly for a numbered list of self-contained
     * bullet points — NOT a full rewrite. This keeps the popup compact
     * and avoids the LLM reproducing the entire article.
     *
     * Returns an empty list when the LLM is not installed, load fails,
     * or generation produces only blank lines.
     */
    private suspend fun summariseArticleIntoKeyPoints(
        articleText: String
    ): List<String> = withContext(Dispatchers.IO) {
        if (!isLlmModelInstalledFast()) return@withContext emptyList()
        ensureChatModelLoaded()
        if (!com.tebogo.markvault.llm.LlmManager.isLoaded) return@withContext emptyList()

        // Strip HTML if the article is an HTML file; chunking benefits
        // from clean plain text without markup contamination.
        val processedText: String = if (looksLikeFullHtml(articleText)) {
            stripHtmlToPlainText(articleText)
        } else {
            articleText
        }
        // ~800 tokens — keeps single-inference latency under ~6 s on S732G
        // while covering most article bodies fully.
        val excerpt = processedText.trim().take(3200)

        val prompt = buildString {
            appendLine("You are a Bible-study research assistant helping one of Jehovah's Witnesses.")
            appendLine("Use NWT terminology. Never say 'cross' — always say 'torture stake'.")
            appendLine("Do not speculate beyond the text provided.")
            appendLine()
            appendLine("ARTICLE:")
            appendLine(excerpt)
            appendLine()
            appendLine("TASK: List ONLY the most important key points from the article above.")
            appendLine("Rules:")
            appendLine("  • Output a numbered list with at most 6 items, one per line.")
            appendLine("  • Each item must be brief and self-contained (one sentence max).")
            appendLine("  • Do NOT reproduce full paragraphs or quote verbatim.")
            appendLine("  • Do NOT add any introduction, heading, or closing remark.")
            appendLine()
            append("KEY POINTS:")
        }

        val sb = StringBuilder()
        runCatching {
            com.tebogo.markvault.llm.LlmManager.generate(prompt).collect { chunk ->
                sb.append(chunk)
            }
        }

        val raw = sb.toString().trim()
        if (raw.isBlank()) return@withContext emptyList()

        // Split on newlines, filter blank or trivially short lines, cap at 6.
        raw.split(Regex("\\n+"))
            .map { it.trim() }
            .filter { it.length > 4 }
            .take(6)
    }

    /**
     * v5.4.130cc — Article-body blur level for when the popup is
     * showing. Cycles through 0 (off) → 6 → 12 → 20 dp. Readers
     * observe this state and apply Modifier.blur(radius = level.dp)
     * to the article content when the popup is Visible.
     *
     * Blur has visible effect on API 31+ (Android 12+); older devices
     * silently no-op — no crash, just no blur.
     */
    private val _articlePopupBlur = MutableStateFlow(12)
    val articlePopupBlur: StateFlow<Int> = _articlePopupBlur

    private val ARTICLE_POPUP_BLUR_STEPS: IntArray = intArrayOf(0, 6, 12, 20)

    fun cycleArticlePopupBlur() {
        val cur: Int = _articlePopupBlur.value
        val idx: Int = ARTICLE_POPUP_BLUR_STEPS.indexOf(cur).takeIf { it >= 0 } ?: 2
        val next: Int = ARTICLE_POPUP_BLUR_STEPS[(idx + 1) % ARTICLE_POPUP_BLUR_STEPS.size]
        _articlePopupBlur.value = next
    }

    /**
     * v5.4.132cc — How many top-rated search results the multi-article
     * popup pulls passages from. Default 1 (the single best hit); range
     * 1..10. Exposed as StateFlow for both the SearchScreen FAB and the
     * Settings-screen stepper.
     */
    val popupArticlesTopN: StateFlow<Int> =
        prefs.popupArticlesTopN.stateIn(viewModelScope, SharingStarted.Eagerly, 1)

    fun setPopupArticlesTopN(v: Int) {
        viewModelScope.launch { prefs.setPopupArticlesTopN(v) }
    }

    /**
     * v5.4.139cc — see [Prefs.llmFallbackToSynonym]. Default FALSE so
     * LLM-on = LLM-only (no silent synonym replacement when the LLM
     * fails). Users can opt IN via Settings.
     */
    val llmFallbackToSynonym: StateFlow<Boolean> =
        prefs.llmFallbackToSynonym.stateIn(viewModelScope, SharingStarted.Eagerly, false)

    fun setLlmFallbackToSynonym(v: Boolean) {
        viewModelScope.launch { prefs.setLlmFallbackToSynonym(v) }
    }

    /**
     * v5.4.132cc — Cross-screen "please open the popup once this article
     * loads" trigger. Set by SearchScreen's long-press menu when the
     * user picks "Search in article"; consumed by the reader screens'
     * LaunchedEffect once the note content is available. One-shot: the
     * flow resets to null immediately after read to avoid retriggering
     * on subsequent article opens.
     */
    private val _pendingPopupQuery = MutableStateFlow<String?>(null)
    val pendingPopupQuery: StateFlow<String?> = _pendingPopupQuery

    fun setPendingPopupQuery(query: String?) {
        _pendingPopupQuery.value = query
    }

    fun consumePendingPopupQuery(): String? {
        val q: String? = _pendingPopupQuery.value
        _pendingPopupQuery.value = null
        return q
    }

    /**
     * v5.4.132cc — Multi-article popup builder.
     *
     * Called from the SearchScreen pumping-heart FAB. Takes the top
     * [topN] search results (by their existing display order — the
     * results are already sorted by relevance), loads each note's
     * content, runs the paragraph-level semantic ranker on each, and
     * merges the best passages from each into a single popup state.
     *
     * Article titles are prepended to their passages as `### heading`
     * markdown so the popup's [PopupMarkdownRenderer] renders them as
     * visible dividers between excerpts.
     *
     * @param query        the user's search query — also used as the
     *                     query for the in-article ranker
     * @param resultHits   the current search results, in display order
     * @param topN         cap on how many articles to visit (already
     *                     resolved from [popupArticlesTopN] by the
     *                     caller)
     */
    fun findAndShowMultiArticlePopup(
        query: String,
        resultHits: List<com.tebogo.markvault.data.SearchHit>,
        topN: Int
    ) {
        val q: String = query.trim().removeSurrounding("\"").trim()
        if (q.length < 2 || resultHits.isEmpty() || topN <= 0) {
            _articlePopupState.value = ArticlePopupState.Hidden
            return
        }
        val take: Int = topN.coerceAtLeast(1).coerceAtMost(resultHits.size)
        val chosen: List<com.tebogo.markvault.data.SearchHit> =
            resultHits.take(take)
        // Use noteId of the FIRST article as the popup's associated
        // noteId — used for popup-state uniqueness (not for navigation).
        val firstNoteId: Long = chosen.first().id
        _articlePopupState.value = ArticlePopupState.Loading(firstNoteId, q)

        viewModelScope.launch(Dispatchers.IO) {
            val merged: MutableList<String> = mutableListOf()
            for (hit in chosen) {
                val note: com.tebogo.markvault.data.Note =
                    runCatching { loadNote(hit.id) }.getOrNull() ?: continue
                val content: String = note.content
                if (content.isBlank()) continue
                val passages: List<String> = runCatching {
                    findArticlePassages(content, q)
                }.getOrElse { emptyList() }
                if (passages.isEmpty()) continue
                // Title heading for this article — the popup's markdown
                // renderer turns `### text` into a bold heading, giving
                // each article's passages a clear visual separator.
                val title: String = hit.title.ifBlank {
                    hit.relPath.substringAfterLast('/', hit.relPath)
                }
                merged.add("### " + title)
                // Take up to 2 passages per article so the popup stays
                // readable when topN is 3+.
                merged.addAll(passages.take(2))
            }
            // Verify our request hasn't been superseded before publishing.
            val cur = _articlePopupState.value
            val stillOurs: Boolean = (cur is ArticlePopupState.Loading &&
                cur.noteId == firstNoteId && cur.query == q)
            if (!stillOurs) return@launch
            _articlePopupState.value = if (merged.isEmpty()) {
                ArticlePopupState.Empty(firstNoteId, q)
            } else {
                ArticlePopupState.Visible(
                    noteId = firstNoteId,
                    query = q,
                    passages = merged,
                    minimized = false,
                    // v5.4.135cc — carry the fileType of the primary
                    // (highest-scored) hit so the popup's "📖 Open"
                    // button routes to the right reader.
                    openableFileType = chosen.first().fileType
                )
            }
        }
    }


    /**
     * v5.5.9 — Fast dot product against the packed little-endian embedding BLOB.
     * Every embedding backend normalises vectors before persistence, and the query
     * vector is normalised by the same backend, so cosine similarity is exactly the
     * dot product. Reading floats directly from the BLOB avoids one FloatArray
     * allocation plus two norm scans and a sqrt for every candidate chunk.
     */
    private fun normalizedEmbeddingDot(queryVector: FloatArray, vectorBytes: ByteArray): Float {
        if (queryVector.isEmpty() || vectorBytes.size != queryVector.size * 4) return -1f
        var dot = 0f
        var byteIndex = 0
        for (value in queryVector) {
            // floatArrayToBytes() persists IEEE-754 values little-endian. Decode
            // directly from the backing BLOB so the hot candidate loop creates
            // neither a ByteBuffer nor a temporary FloatArray per embedding.
            val bits =
                (vectorBytes[byteIndex].toInt() and 0xff) or
                    ((vectorBytes[byteIndex + 1].toInt() and 0xff) shl 8) or
                    ((vectorBytes[byteIndex + 2].toInt() and 0xff) shl 16) or
                    ((vectorBytes[byteIndex + 3].toInt() and 0xff) shl 24)
            dot += value * Float.fromBits(bits)
            byteIndex += 4
        }
        return dot.coerceIn(-1f, 1f)
    }

    /** Cosine similarity of two equal-length FloatArrays. Returns -1 on mismatch. */
    private fun cosineSimilarity(a: FloatArray, b: FloatArray): Float {
        if (a.size != b.size || a.isEmpty()) return -1f
        var dot = 0f; var na = 0f; var nb = 0f
        for (i in a.indices) {
            dot += a[i] * b[i]
            na += a[i] * a[i]
            nb += b[i] * b[i]
        }
        val denom = kotlin.math.sqrt(na) * kotlin.math.sqrt(nb)
        return if (denom > 0f) dot / denom else 0f
    }

    /** v5.4.9 — Resolved highlight mode that the reader actually uses.
     *  "auto" → follows semanticEnabled: smart when ON, keyword when OFF.
     *  "smart" / "keyword" → returned as-is.
     *  Readers should consult this property (not [highlightMode]) so the
     *  "auto" decision lives in one place. */
    fun effectiveHighlightMode(): String {
        val mode = highlightMode.value
        if (mode == "smart" || mode == "keyword") return mode
        // "auto" — tie to semantic search state
        return if (semanticEnabled.value) "smart" else "keyword"
    }

    /** v5.4.1 — Manually triggered search submit. Used when liveSearch
     *  is disabled so the user can fire a search via Enter / submit
     *  button without typing causing live updates.
     *
     *  v5.4.146cc — Changed from MutableStateFlow<Long> to
     *  MutableSharedFlow<Unit>. MutableStateFlow replays its last
     *  value to every new subscriber, which caused the results flow
     *  (WhileSubscribed) to re-run the previous search every time the
     *  user navigated back to SearchScreen after 5 s. SharedFlow with
     *  extraBufferCapacity=1 fires once per tryEmit and never replays. */
    // v5.4.356cc — One-shot Workspace Inspector outline navigation. SharedFlow
    // avoids replaying an old heading jump when ReaderScreen is recreated.
    private val _workspaceOutlineJump = MutableSharedFlow<WorkspaceOutlineJumpRequest>(extraBufferCapacity = 8)
    val workspaceOutlineJump: kotlinx.coroutines.flow.SharedFlow<WorkspaceOutlineJumpRequest> = _workspaceOutlineJump

    fun requestWorkspaceOutlineJump(noteId: Long, headingIndex: Int) {
        if (headingIndex < 0) return
        _workspaceOutlineJump.tryEmit(WorkspaceOutlineJumpRequest(noteId, headingIndex))
    }

    private val _searchTrigger = MutableSharedFlow<Unit>(extraBufferCapacity = 1)

    // v5.5.11 — Completed search sessions survive process death. Durable store history
    // is retained for six months; only the recent in-memory navigation window is bounded.
    // Restoring a session feeds the exact saved SearchHit order back through the existing
    // results StateFlow without re-running embeddings or the reranker.
    private val _savedSearchRestore = MutableSharedFlow<com.tebogo.markvault.search.SavedSearchSession>(extraBufferCapacity = 1)
    private val _savedSearchSessions = MutableStateFlow<List<com.tebogo.markvault.search.SavedSearchSession>>(emptyList())
    val savedSearchSessions: StateFlow<List<com.tebogo.markvault.search.SavedSearchSession>> = _savedSearchSessions.asStateFlow()
    private val _lastSavedSearchSessionId = MutableStateFlow<String?>(null)
    val lastSavedSearchSessionId: StateFlow<String?> = _lastSavedSearchSessionId.asStateFlow()
    private val _activeSavedSearchSessionId = MutableStateFlow<String?>(null)
    val activeSavedSearchSessionId: StateFlow<String?> = _activeSavedSearchSessionId.asStateFlow()
    private val _resultScopeById = MutableStateFlow<Map<Long, String>>(emptyMap())
    val resultScopeById: StateFlow<Map<Long, String>> = _resultScopeById.asStateFlow()
    // v5.5.23 — Per-result retrieval provenance lives beside (not inside)
    // SearchHit so the Room projection remains schema-pure.
    private val _resultQueryProvenance =
        MutableStateFlow<Map<Long, ResultQueryProvenance>>(emptyMap())
    val resultQueryProvenance: StateFlow<Map<Long, ResultQueryProvenance>> =
        _resultQueryProvenance.asStateFlow()

    init { refreshSavedSearchSessions() }

    fun refreshSavedSearchSessions() {
        viewModelScope.launch(Dispatchers.IO) {
            _savedSearchSessions.value = com.tebogo.markvault.search.SavedSearchStore.list(getApplication(), maxSavedSearchSessions.value)
        }
    }

    /**
     * v5.4.381cc — Ordinary Search entry points must never inherit saved-search
     * viewing mode.  Clear only the transient restored-session state and visible
     * query so SearchScreen falls back to its existing Recent searches view.
     * Persisted saved sessions are not deleted or modified.
     */
    fun enterNormalSearchPage() {
        _activeSavedSearchSessionId.value = null
        _resultScopeById.value = emptyMap()
        _resultQueryProvenance.value = emptyMap()
        _llmMatchedHitIds.value = emptySet()
        _lastSubmittedQuery = ""
        _lastSearchDurationMs.value = null
        query.value = ""
    }

    fun restoreSavedSearchSession(id: String) {
        if (id.isBlank()) return
        viewModelScope.launch(Dispatchers.IO) {
            restoreSavedSearchSessionInternal(id)
        }
    }

    /**
     * v5.4.403cc — Notification/deep-link restore must finish loading the durable
     * session before MainActivity navigates to Search. The old fire-and-forget
     * method could navigate first, race the result-flow restore, and resume while
     * post-search native cleanup was still executing.
     */
    suspend fun restoreSavedSearchSessionAwait(id: String): Boolean =
        kotlinx.coroutines.withContext(Dispatchers.IO) {
            restoreSavedSearchSessionInternal(id)
        }

    private suspend fun restoreSavedSearchSessionInternal(id: String): Boolean {
        if (id.isBlank()) return false
        val session = com.tebogo.markvault.search.SavedSearchStore.load(getApplication(), id)
            ?: return false
        // Prevent live-search debounce from immediately re-running the saved
        // query and overwriting the restored result set.
        _lastSubmittedQuery = session.query.trim()
        query.value = session.query
        _lastSearchDurationMs.value = session.durationMs
        _lastKnownResults = session.hits
        _resultScopeById.value = session.hitScopes
        _resultQueryProvenance.value = session.hitProvenance
        _llmMatchedHitIds.value = session.hitProvenance
            .filterValues { provenance ->
                val contributions = provenance.contributions
                contributions.any {
                    it.source == ResultQuerySource.LLM || it.source == ResultQuerySource.T5
                } && contributions.none {
                    it.source == ResultQuerySource.ORIGINAL ||
                        it.source == ResultQuerySource.QUESTION_AWARENESS ||
                        it.source == ResultQuerySource.SYNONYM
                }
            }
            .keys
        _activeSavedSearchSessionId.value = session.id
        _savedSearchRestore.emit(session)
        return true
    }

    fun deleteSavedSearchSession(id: String) {
        if (id.isBlank()) return
        viewModelScope.launch(Dispatchers.IO) {
            com.tebogo.markvault.search.SavedSearchStore.delete(getApplication(), id)
            _savedSearchSessions.value = com.tebogo.markvault.search.SavedSearchStore.list(getApplication(), maxSavedSearchSessions.value)
        }
    }

    /**
     * v5.4.146cc — Emitting here makes mapLatest cancel the currently
     * running search coroutine immediately (on keystroke, when live
     * search is OFF). The cancel handler in the mapper returns the
     * last known result set so the screen does not go blank.
     */
    private val _cancelSignal = MutableSharedFlow<Unit>(extraBufferCapacity = 1)

    /**
     * v5.4.127cc — Tracks the last query that was explicitly submitted so
     * the live-typing stream can suppress re-emissions of that same query.
     *
     * Problem: HomeScreen navigates to SearchScreen with a pre-filled query
     * AND fires submitSearch(). The live debounce fires 220 ms later with
     * isSubmit=false, cancelling the in-flight AI expansion (mapLatest).
     * By recording what was just submitted, the live stream can filter out
     * that query and let the submit search run to completion.
     *
     * The field is @Volatile (not StateFlow) to keep it off the hot
     * combine() path — the filter reads it synchronously per emission.
     * Reset to "" when the user types something different, so live search
     * resumes the moment the query diverges from the submitted form.
     */
    @Volatile private var _lastSubmittedQuery: String = ""

    private fun startProtectedSearch(queryText: String) {
        if (queryText.isBlank()) return
        val app = getApplication<Application>()
        val intent = android.content.Intent(
            app, com.tebogo.markvault.service.BackgroundWorkService::class.java
        ).apply {
            action = com.tebogo.markvault.service.BackgroundWorkService.ACTION_START_SEARCH
            putExtra(com.tebogo.markvault.service.BackgroundWorkService.EXTRA_QUERY, queryText)
        }
        runCatching { androidx.core.content.ContextCompat.startForegroundService(app, intent) }
            .onFailure { android.util.Log.w("MarkVault", "Unable to start protected search service", it) }
    }

    private fun cancelProtectedSearch() {
        val app = getApplication<Application>()
        val intent = android.content.Intent(
            app, com.tebogo.markvault.service.BackgroundWorkService::class.java
        ).apply { action = com.tebogo.markvault.service.BackgroundWorkService.ACTION_ABORT_SEARCH }
        runCatching { androidx.core.content.ContextCompat.startForegroundService(app, intent) }
    }

    private fun requestProtectedGracefulSearchStop() {
        val app = getApplication<Application>()
        val intent = android.content.Intent(
            app, com.tebogo.markvault.service.BackgroundWorkService::class.java
        ).apply {
            action = com.tebogo.markvault.service.BackgroundWorkService.ACTION_CANCEL_SEARCH
            putExtra(com.tebogo.markvault.service.BackgroundWorkService.EXTRA_QUERY, query.value.trim())
        }
        runCatching { androidx.core.content.ContextCompat.startForegroundService(app, intent) }
    }

    private fun startProtectedTask(token: String, label: String) {
        val app = getApplication<Application>()
        val intent = android.content.Intent(
            app, com.tebogo.markvault.service.BackgroundWorkService::class.java
        ).apply {
            action = com.tebogo.markvault.service.BackgroundWorkService.ACTION_START_TASK
            putExtra(com.tebogo.markvault.service.BackgroundWorkService.EXTRA_TOKEN, token)
            putExtra(com.tebogo.markvault.service.BackgroundWorkService.EXTRA_LABEL, label)
        }
        runCatching { androidx.core.content.ContextCompat.startForegroundService(app, intent) }
            .onFailure { android.util.Log.w("MarkVault", "Unable to protect background task $token", it) }
    }

    private fun stopProtectedTask(token: String) {
        val app = getApplication<Application>()
        val intent = android.content.Intent(
            app, com.tebogo.markvault.service.BackgroundWorkService::class.java
        ).apply {
            action = com.tebogo.markvault.service.BackgroundWorkService.ACTION_STOP_TASK
            putExtra(com.tebogo.markvault.service.BackgroundWorkService.EXTRA_TOKEN, token)
        }
        runCatching { androidx.core.content.ContextCompat.startForegroundService(app, intent) }
    }

    fun submitSearch() {
        _lastSubmittedQuery = query.value.trim()
        startProtectedSearch(_lastSubmittedQuery)
        _searchTrigger.tryEmit(Unit)
    }

    /**
     * v5.4.146cc — Cancel any in-flight search immediately without
     * clearing the displayed results. Emitting to [_cancelSignal]
     * causes [mapLatest] to cancel the current mapper coroutine; the
     * cancel branch in the mapper returns [_lastKnownResults] so the
     * UI stays populated while the user continues typing.
     *
     * Called from SearchScreen's onValueChange when live search is OFF.
     */
    fun cancelCurrentSearch() {
        // Hard cancellation is reserved for query edits / obsolete work.
        // User-facing Stop Search uses [stopCurrentSearchGracefully] instead.
        cancelProtectedSearch()
        _cancelSignal.tryEmit(Unit)
    }

    /**
     * v5.5.14 — User-facing Stop Search. Capture the visible progress exactly
     * once, stop retrieval at the next safe page/chunk boundary, then keep the
     * current coroutine alive for final fusion, reranking and durable save.
     */
    fun stopCurrentSearchGracefully() {
        requestGracefulSearchStopOnly()
        requestProtectedGracefulSearchStop()
    }

    /** Service-side half of graceful Stop Search; does not send another intent. */
    fun requestGracefulSearchStopOnly() {
        if (!_searchBusy.value) return
        val trace = activeSearchTrace ?: return
        if (trace.gracefulStopRequested) return

        // A stopped live search may not have gone through the normal submit
        // initialization that clears the previous completion target. Clear it
        // before finalization so a failed partial save can never leave the
        // notification pointing at an older saved-search session.
        _lastSavedSearchSessionId.value = null

        val done = _searchWorkDone.value.coerceAtLeast(0)
        val total = _searchWorkTotal.value.coerceAtLeast(0)
        val pct = _searchWorkProgress.value
            ?.let { (it * 100f).toInt().coerceIn(0, 100) }
            ?: if (total > 0) ((done.toDouble() / total.toDouble()) * 100.0).toInt().coerceIn(0, 100) else 0

        trace.stoppedAtPercent = pct
        trace.stoppedAtDone = done
        trace.stoppedAtTotal = total
        // Volatile write last: scan loops that observe true also observe snapshot fields.
        trace.gracefulStopRequested = true
        _searchWorkStage.value = stoppedSearchStage(trace)
    }

    /**
     * Hard-cancel helper used only when old work is obsolete (for example the
     * user edits the query). Unlike graceful Stop, this never saves a partial run.
     */
    fun cancelSearchCoroutineOnly() {
        _cancelSignal.tryEmit(Unit)
    }

    /** Reranker descriptor, exposed for the Settings card.
     *  v5.4.6 — Now a StateFlow tied to the user's persisted model
     *  choice, so when they switch between L-12 and L-6 the UI
     *  re-renders with the right name / sizes / description. */
    val rerankerDescriptor: StateFlow<com.tebogo.markvault.search.RerankerDescriptor> =
        prefs.rerankerModelId
            .map { id ->
                com.tebogo.markvault.search.RerankerCatalog.byId(id)
                    ?: com.tebogo.markvault.search.RerankerCatalog.default
            }
            .stateIn(
                viewModelScope,
                SharingStarted.Eagerly,
                com.tebogo.markvault.search.RerankerCatalog.default
            )

    /**
     * True while a search is currently in its rerank phase. The Search
     * screen can show a small "Reranking…" indicator. Independent from
     * [rerankerDownloading] (which is for the one-time install).
     */
    private val _rerankActive = MutableStateFlow(false)
    val rerankActive: StateFlow<Boolean> = _rerankActive

    /**
     * v4.24.0 — Fine-grained rerank progress, 0.0–1.0. Updated as each
     * candidate doc is scored by the cross-encoder so the SearchScreen
     * can show a live percentage indicator in the top corner. Null when
     * no rerank is in flight.
     */
    private val _rerankProgress = MutableStateFlow<Float?>(null)
    val rerankProgress: StateFlow<Float?> = _rerankProgress

    private var rerankerDownloadJob: kotlinx.coroutines.Job? = null

    /** Trigger the reranker model download. Re-entry safe. */
    fun downloadReranker() {
        if (_rerankerDownloading.value) return
        if (rerankerDownloadJob?.isActive == true) return
        _rerankerDownloading.value = true
        _rerankerDownloadProgress.value = 0f
        _rerankerDownloadError.value = null
        startProtectedTask("reranker_download", "Downloading reranker…")
        rerankerDownloadJob = viewModelScope.launch(Dispatchers.IO) {
            val result = reranker.download { fraction ->
                _rerankerDownloadProgress.value = fraction
            }
            if (result.isSuccess) {
                _rerankerInstalled.value = true
            } else {
                val err = result.exceptionOrNull()
                if (err !is kotlinx.coroutines.CancellationException) {
                    _rerankerDownloadError.value =
                        err?.message ?: "Reranker download failed"
                }
            }
            _rerankerDownloading.value = false
            _rerankerDownloadProgress.value = null
            stopProtectedTask("reranker_download")
        }
    }

    /** Stop an in-flight reranker download. */
    fun stopRerankerDownload() {
        rerankerDownloadJob?.cancel()
        rerankerDownloadJob = null
        stopProtectedTask("reranker_download")
    }

    /** Delete the reranker model files, freeing ~33 MB. */
    fun deleteReranker() {
        stopRerankerDownload()
        viewModelScope.launch(Dispatchers.IO) {
            reranker.deleteFiles()
            _rerankerInstalled.value = false
            // Also turn the rerank toggle off — model is gone so there's
            // nothing to enable.
            if (rerankEnabled.value) prefs.setRerankEnabled(false)
        }
    }

    /** Dismiss the last error message. */
    fun clearRerankerError() {
        _rerankerDownloadError.value = null
    }

    /** Toggle reranking on/off (persists to prefs). */
    fun setRerankEnabled(v: Boolean) {
        viewModelScope.launch { prefs.setRerankEnabled(v) }
    }

    /**
     * Rerank a list of (noteId, stageOneScore) candidates against [query]
     * using the cross-encoder. The cross-encoder determines the ORDER of the
     * bounded top window, while the returned numeric scores are calibrated
     * back onto the original stage-one score slots. This keeps one comparable
     * score scale across reranked and untouched candidates.
     *
     * Falls back to the input order if the reranker is unavailable or any
     * bounded inference fails — accuracy is preferred over a partial rerank.
     *
     * Only the top [maxToRerank] candidates are re-scored (default 20);
     * the rest are appended in original cosine order. This keeps latency
     * bounded — 20 docs × ~150 ms each on the user's S732G ≈ 3 s.
     *
     * v5.4.141cc — Raised default from 8 → 20. With only 8 candidates
     * being scored, the most relevant article often sat just outside the
     * reranked window (at cosine rank 9–15) and was never promoted. 20
     * candidates gives the cross-encoder enough coverage to surface the
     * right article reliably while staying within the latency budget.
     */
    private suspend fun applyRerank(
        query: String,
        candidates: List<Pair<Long, Float>>,
        maxToRerank: Int = 20,
        /**
         * v5.5.10 — Optional query embedding from the semantic retrieval stage.
         * When supplied, the reranker is given the article passage whose stored
         * embedding was actually closest to the query, rather than blindly
         * judging the first characters of the article.
         */
        semanticQueryVector: FloatArray? = null,
        semanticModelVersion: String? = null
    ): List<Pair<Long, Float>> {
        if (candidates.isEmpty()) return candidates
        if (!reranker.isInstalled()) return candidates

        // v5.3.0 — Top-level defensive wrapper. See semanticSearch.
        val timingTrace = activeSearchTrace
        val started = android.os.SystemClock.elapsedRealtime()
        return try {
            runCatching {
                applyRerankInner(
                    query = query,
                    candidates = candidates,
                    maxToRerank = maxToRerank,
                    semanticQueryVector = semanticQueryVector,
                    semanticModelVersion = semanticModelVersion
                )
            }.getOrElse {
                if (it is kotlinx.coroutines.CancellationException) throw it
                _rerankActive.value = false
                _rerankProgress.value = null
                candidates
            }
        } finally {
            timingTrace?.timings?.add("Reranking", android.os.SystemClock.elapsedRealtime() - started)
        }
    }

    /**
     * v5.5.10 — Reconstruct the exact broad chunking used by EmbeddingService
     * and choose, for each rerank candidate, the chunk whose STORED embedding
     * is closest to the already-computed query vector. This costs only a small
     * DB read for the bounded rerank window; it does not run the embedder again.
     *
     * The previous reranker always used `content.take(600)`. For long articles
     * that meant a correct semantic hit on paragraph 20 could be judged only on
     * the introduction and incorrectly demoted. Keeping the title plus the
     * winning semantic chunk makes the second-stage model evaluate the same
     * evidence that caused stage one to retrieve the article.
     */
    /**
     * v5.5.12 — Content words used to judge whether evidence is coherent in
     * one local passage. Question/auxiliary words are intentionally excluded;
     * intent words (for example "how many") are evaluated separately below.
     */
    private fun informativeQueryTerms(query: String): Set<String> = query
        .lowercase()
        .split(Regex("[^\\p{L}\\p{N}]+"))
        .map { it.trim() }
        .filter { token ->
            token.length >= 3 &&
                !com.tebogo.markvault.search.QueryExpander.isFunctionWord(token) &&
                token !in setOf("many", "much", "number", "total")
        }
        .toSet()

    private fun isCountIntent(query: String): Boolean {
        val q = query.lowercase().replace(Regex("\\s+"), " ").trim()
        return Regex("\\bhow\\s+(many|much)\\b").containsMatchIn(q) ||
            Regex("\\b(number|total)\\s+of\\b").containsMatchIn(q)
    }


    /** v5.5.12 — The thing being counted, not every proper noun in the query. */
    private fun countTargetTerms(query: String): Set<String> {
        val tokens = query.lowercase()
            .split(Regex("[^\\p{L}\\p{N}]+"))
            .filter { it.isNotBlank() }
        if (tokens.isEmpty()) return emptySet()

        var start = -1
        for (i in 0 until tokens.lastIndex) {
            if (tokens[i] == "how" && (tokens[i + 1] == "many" || tokens[i + 1] == "much")) {
                start = i + 2
                break
            }
            if ((tokens[i] == "number" || tokens[i] == "total") && tokens[i + 1] == "of") {
                start = i + 2
                break
            }
        }
        if (start !in tokens.indices) return emptySet()

        val hardStops = setOf(
            "do", "does", "did", "is", "are", "was", "were", "be", "been",
            "have", "has", "had", "can", "could", "will", "would", "shall",
            "should", "may", "might", "must", "who", "which", "where", "when",
            "why", "that", "from", "with", "into", "about"
        )
        val out = LinkedHashSet<String>()
        for (i in start until tokens.size) {
            val token = tokens[i]
            if (token in hardStops) break
            if (token in setOf("and", "or", "the", "a", "an")) continue
            if (token.length >= 2) out += token
            if (out.size >= 3) break
        }
        return out
    }

    /**
     * v5.5.12 — Does this LOCAL passage actually contain evidence capable of
     * answering a count question? This deliberately does not treat an arbitrary
     * number anywhere in a long article as evidence: old Watchtower text often
     * begins paragraphs with numbers ("17", "18"), which was one reason a
     * passage about "how many branch offices" + "Adam and Eve ... children"
     * could fool the old document-level fusion.
     */
    private fun countAnswerStrength(query: String, rawText: String): Float {
        if (!isCountIntent(query)) return 1f
        if (rawText.isBlank()) return 0.35f

        val text = rawText
            .replace(Regex("(?m)^\\s*\\d{1,3}[.)]?\\s+"), " ")
            .replace(Regex("\\s+"), " ")
            .lowercase()

        // Explicit "unknown / not stated" answers are fully responsive to a
        // how-many question even though they contain no numerical quantity.
        val unknownAnswer = listOf(
            "does not say how many", "doesn't say how many", "do not know how many",
            "don't know how many", "number is not stated", "number was not stated",
            "exact number is not", "exact number was not", "not recorded how many",
            "not reveal how many", "does not reveal how many", "scriptures do not say",
            "bible does not say", "bible doesn't say", "no exact number"
        ).any { it in text }
        if (unknownAnswer) return 1f

        val terms = informativeQueryTerms(query)
        val targets = countTargetTerms(query)
        val countNouns = buildSet {
            addAll(targets)
            // Family-count synonyms are useful only when the requested target
            // is itself a child/descendant term; do not let an unrelated number
            // next to "Adam" (for example his age) masquerade as child-count evidence.
            if (targets.any { it in setOf("child", "children", "son", "sons", "daughter", "daughters", "offspring") }) {
                addAll(listOf("child", "children", "son", "sons", "daughter", "daughters", "offspring"))
            }
        }
        val nounPattern = countNouns
            .filter { it.length >= 3 }
            .sortedByDescending { it.length }
            .joinToString("|") { Regex.escape(it) }

        val numberWord = "(?:zero|one|two|three|four|five|six|seven|eight|nine|ten|eleven|twelve|" +
            "thirteen|fourteen|fifteen|sixteen|seventeen|eighteen|nineteen|twenty|thirty|forty|" +
            "fifty|sixty|seventy|eighty|ninety|hundred|thousand|dozen|\\d{1,4})"
        if (nounPattern.isNotBlank()) {
            val quantityNearNoun = Regex(
                "\\b$numberWord\\b(?:\\s+\\w+){0,3}\\s+\\b(?:$nounPattern)\\b"
            ).containsMatchIn(text) || Regex(
                "\\b(?:$nounPattern)\\b(?:\\s+\\w+){0,4}\\s+\\b$numberWord\\b"
            ).containsMatchIn(text)
            if (quantityNearNoun) return 1f
        }

        // Strong non-numeric quantity wording. Keep family-specific phrases
        // gated to family-count questions so "sons and daughters" cannot satisfy
        // an unrelated query such as "how many branch offices".
        val familyTarget = targets.any {
            it in setOf("child", "children", "son", "sons", "daughter", "daughters", "offspring")
        }
        if (familyTarget) {
            val quantifiedFamily = listOf(
                "sons and daughters", "other sons and daughters", "other children",
                "many children", "several children", "numerous children", "few children",
                "number of children", "total number", "how many children"
            ).any { it in text }
            if (quantifiedFamily) return 0.88f
        }
        if (nounPattern.isNotBlank()) {
            val genericQuantifier = Regex(
                "\\b(?:many|several|numerous|few|some|dozens? of)\\b(?:\\s+\\w+){0,2}\\s+\\b(?:$nounPattern)\\b"
            ).containsMatchIn(text)
            if (genericQuantifier) return 0.82f
        }

        // A local how-many formulation that also contains the query's content
        // terms is responsive, but weaker than an actual answer statement.
        val coverage = if (terms.isEmpty()) 0f else {
            terms.count { Regex("\\b${Regex.escape(it)}\\w*\\b").containsMatchIn(text) }
                .toFloat() / terms.size.toFloat()
        }
        if (Regex("\\bhow\\s+(many|much)\\b").containsMatchIn(text) && coverage >= 0.5f) {
            return 0.72f
        }

        // It may mention the right people/topic but it does not answer the count
        // intent. Keep it eligible (semantic models can still know synonyms),
        // but make the stronger reranker prefer genuinely answer-bearing text.
        return if (coverage >= 0.75f) 0.42f else 0.32f
    }

    /**
     * v5.5.12 — Select a compact, coherent local window from the semantically
     * winning 350-word chunk before cross-encoder inference. The reranker is
     * capped at 256 tokens; feeding a whole 350-word chunk could truncate away
     * the actual matching sentence and let unrelated terms elsewhere in the
     * chunk dominate. Two/three-sentence windows keep subject + answer context
     * together while remaining comfortably inside the model's token budget.
     */
    private fun selectCoherentRerankPassage(query: String, rawPassage: String): String {
        val passage = rawPassage.trim()
        if (passage.isBlank()) return ""

        val sentences = passage
            .split(Regex("(?<=[.!?])\\s+|[\\r\\n]+"))
            .map { it.trim() }
            .filter { it.isNotBlank() }
        if (sentences.size <= 1) return passage.take(1_800)

        val terms = informativeQueryTerms(query)
        val countIntent = isCountIntent(query)
        val normalizedQuery = query.lowercase().replace(Regex("\\s+"), " ").trim()

        data class Window(val text: String, val score: Double)
        var best: Window? = null
        for (start in sentences.indices) {
            for (width in 1..3) {
                val end = (start + width).coerceAtMost(sentences.size)
                if (end <= start) continue
                val text = sentences.subList(start, end).joinToString(" ").take(1_800)
                val lower = text.lowercase().replace(Regex("\\s+"), " ")
                val words = lower.split(Regex("\\s+")).filter { it.isNotBlank() }
                if (words.isEmpty()) continue

                val covered = if (terms.isEmpty()) 0 else terms.count { term ->
                    Regex("\\b${Regex.escape(term)}\\w*\\b").containsMatchIn(lower)
                }
                val coverage = if (terms.isEmpty()) 0.0 else covered.toDouble() / terms.size.toDouble()
                val exactPhrase = normalizedQuery.isNotBlank() && normalizedQuery in lower
                val intent = if (countIntent) countAnswerStrength(query, text).toDouble() else 1.0
                val density = covered.toDouble() / words.size.coerceAtLeast(1).toDouble()

                // Coverage dominates; answer intent breaks the exact failure in
                // which "how many" occurred in one sentence and Adam/Eve/children
                // occurred in another unrelated sentence of the same big chunk.
                val score = coverage * 8.0 + intent * (if (countIntent) 3.0 else 0.5) +
                    density * 3.0 + if (exactPhrase) 2.5 else 0.0
                if (best == null || score > best!!.score) best = Window(text, score)
            }
        }
        return (best?.text ?: passage).take(1_800)
    }

    private fun answerIntentMultiplier(query: String, doc: String): Float {
        return if (isCountIntent(query)) countAnswerStrength(query, doc).coerceIn(0.35f, 1f) else 1f
    }

    private suspend fun buildSemanticRerankDocuments(
        topIds: List<Long>,
        noteTextsById: Map<Long, com.tebogo.markvault.data.NoteText>,
        queryVector: FloatArray,
        modelVersion: String,
        query: String
    ): Map<Long, String> {
        if (topIds.isEmpty() || queryVector.isEmpty()) return emptyMap()

        val bestChunkByNote = HashMap<Long, Pair<Int, Float>>(topIds.size * 2)
        val rows = runCatching {
            dao.loadEmbeddingsForNotes(modelVersion, topIds)
        }.getOrElse {
            android.util.Log.w("MarkVaultAccuracy", "Unable to load rerank passage embeddings", it)
            emptyList()
        }

        for (row in rows) {
            if (row.vector.size != queryVector.size * 4) continue
            val score = normalizedEmbeddingDot(queryVector, row.vector)
            val old = bestChunkByNote[row.noteId]
            if (old == null || score > old.second) {
                bestChunkByNote[row.noteId] = row.chunkIndex to score
            }
        }

        val out = HashMap<Long, String>(topIds.size * 2)
        for (id in topIds) {
            val note = noteTextsById[id] ?: continue
            val chunks = com.tebogo.markvault.search.buildOverlappingChunks(
                note.content,
                targetWords = 350,
                overlapWords = 70,
                minWords = 30
            )
            val bestIndex = bestChunkByNote[id]?.first ?: 0
            val broadPassage = when {
                chunks.isNotEmpty() && bestIndex in chunks.indices -> chunks[bestIndex].text
                note.content.isNotBlank() -> note.content
                else -> ""
            }
            val passage = selectCoherentRerankPassage(query, broadPassage)
            val doc = buildString {
                if (note.title.isNotBlank()) append(note.title.trim())
                if (passage.isNotBlank()) {
                    if (isNotEmpty()) append("\n\n")
                    append(passage)
                }
            }
            if (doc.isNotBlank()) out[id] = doc
        }
        return out
    }

    private suspend fun applyRerankInner(
        query: String,
        candidates: List<Pair<Long, Float>>,
        maxToRerank: Int,
        semanticQueryVector: FloatArray?,
        semanticModelVersion: String?
    ): List<Pair<Long, Float>> {
        val top = candidates.take(maxToRerank)
        val tail = candidates.drop(maxToRerank)
        if (top.isEmpty()) return candidates

        _rerankActive.value = true
        _rerankProgress.value = 0f
        val logits = FloatArray(top.size) { Float.NaN }

        // v5.5.9 — Load the rerank window in ONE Room query. The previous
        // dao.byId() inside this loop performed up to 20 identical SQLite
        // round trips for every embedding model.
        val rerankDocsById = runCatching {
            dao.noteTextsByIds(top.map { it.first }).associateBy { it.id }
        }.getOrElse { emptyMap() }

        // v5.5.10 — For semantic retrieval, evaluate the semantically winning
        // passage rather than the beginning of the article. Non-semantic/RRF
        // callers keep a safe title + leading-content fallback.
        val semanticDocs = if (semanticQueryVector != null && semanticModelVersion != null) {
            buildSemanticRerankDocuments(
                topIds = top.map { it.first },
                noteTextsById = rerankDocsById,
                queryVector = semanticQueryVector,
                modelVersion = semanticModelVersion,
                query = query
            )
        } else emptyMap()

        // Build the exact documents once and reuse them for both cross-encoder
        // inference and intent/coherence validation below. Non-semantic callers
        // get the same bounded title + leading-content fallback as before.
        val rerankDocuments = top.map { (id, _) ->
            val note = rerankDocsById[id]
            semanticDocs[id] ?: buildString {
                val title = note?.title.orEmpty().trim()
                val content = note?.content.orEmpty()
                if (title.isNotBlank()) append(title)
                if (content.isNotBlank()) {
                    if (isNotEmpty()) append("\n\n")
                    append(selectCoherentRerankPassage(query, content.take(4_000)))
                }
            }
        }

        // v5.4.3 — Track consecutive failures. If TWO in a row come
        // back null, the session is probably corrupted; unload+reload
        // to get a fresh native state for the remaining candidates.
        var consecutiveFailures = 0
        try {
            for ((i, pair) in top.withIndex()) {
                currentCoroutineContext().ensureActive()
                val doc = rerankDocuments[i]
                val raw = runCatching { reranker.score(query, doc) }.getOrNull()
                if (raw != null) {
                    logits[i] = raw
                    consecutiveFailures = 0
                } else {
                    consecutiveFailures++
                    if (consecutiveFailures >= 2) {
                        android.util.Log.w(
                            "MarkVault",
                            "Reranker: $consecutiveFailures consecutive failures, recreating session"
                        )
                        runCatching { reranker.unload() }
                        consecutiveFailures = 0
                    }
                }
                _rerankProgress.value = ((i + 1).toFloat() / top.size.toFloat())
            }
        } finally {
            _rerankActive.value = false
            _rerankProgress.value = null
        }

        // v5.5.10 — Accuracy first: never turn a failed cross-encoder call into
        // an artificial 0% relevance score. The old NaN -> 0 conversion could
        // bury a genuinely strong semantic result and then the v5.5.5 global
        // score sort amplified the damage. If any bounded rerank candidate
        // cannot be scored, preserve the complete stage-one ordering instead.
        if (logits.any { it.isNaN() }) {
            android.util.Log.w(
                "MarkVaultAccuracy",
                "Reranker pass incomplete (${logits.count { it.isNaN() }} failures); preserving semantic order"
            )
            return candidates
        }

        // Cross-encoder logits are useful for ORDERING the bounded window, but
        // their numeric scale is NOT comparable with embedding/fusion scores.
        // Convert logits only to a monotonic 0..1 sigmoid for internal ordering,
        // then apply a query-intent gate to the SAME compact passage the model
        // saw. This fixes a concrete false-positive class: a document containing
        // "how many" in one unrelated sentence and "Adam/Eve/children" elsewhere
        // can no longer outrank a passage that actually answers the count intent.
        // The final visible score still comes from the stage-one relevance slots,
        // so incompatible model score scales are never mixed in the UI.
        fun sigmoid(x: Float): Double {
            val clamped = x.toDouble().coerceIn(-20.0, 20.0)
            return 1.0 / (1.0 + kotlin.math.exp(-clamped))
        }
        val rerankedIds = top.indices
            .sortedByDescending { i ->
                val crossEncoderSignal = sigmoid(logits[i])
                val intent = answerIntentMultiplier(query, rerankDocuments[i]).toDouble()
                crossEncoderSignal * intent
            }
            .map { top[it].first }

        // Rank calibration preserves one homogeneous score scale across the
        // reranked top window and untouched tail. Unlike v5.5.10/5.5.11, the
        // incoming stage-one slots are now absolute evidence strengths rather
        // than "best result = 100%" query-relative normalisation.
        val scoreSlots = top.map { it.second }.sortedDescending()
        val reranked = rerankedIds.mapIndexed { rank, id -> id to scoreSlots[rank] }
        // v5.5.14 — Persist whether a cross-encoder pass actually completed,
        // not merely whether the rerank setting was enabled.
        markCurrentSearchRerankApplied()

        return reranked + tail
    }

    /** Last "check for updates" status message. Null = never checked. */
    private val _modelUpdateStatus = MutableStateFlow<String?>(null)
    val modelUpdateStatus: StateFlow<String?> = _modelUpdateStatus

    // ── v4.8.2 — In-memory semantic index ───────────────────────────────────
    // Holds every embedding row as a parallel-array structure for fast cosine
    // scoring. Loaded lazily on the first semantic query and invalidated when
    // the user re-embeds or clears the table.
    //
    // Memory cost for a 14k library at 100 dims: 14k * 100 * 4B = ~5.6 MB.
    // Per-query cost: 14k dot products of 100 floats ≈ 5-15ms on a mid-range
    // phone, plus a single ~50-200ms MediaPipe call to embed the query.
    private data class SemanticIndex(
        val noteIds: LongArray,
        val vectors: Array<FloatArray>,
        val dim: Int
    )

    // v5.4.190cc — Three independent scope caches, each with its own mutex.
    // "first20k"  = most recently modified 20 000 articles (LIMIT 20k OFFSET 0).
    // "second20k" = next 20 000 articles             (LIMIT 20k OFFSET 20k).
    // "all"       = entire unfiltered library         (loadAllEmbeddings — no LIMIT).
    //
    // Switching scope calls invalidateSemanticIndex() which clears ALL three caches,
    // so at most ONE cache is populated at any time — avoiding duplicate RAM usage.
    // Each slice is ~20k articles × ~4 chunks = ~80k vectors ≈ 240 MB, matching
    // the scale that worked historically at 19k articles.
    @Volatile private var semanticIndexFirst:  SemanticIndex? = null
    @Volatile private var semanticIndexSecond: SemanticIndex? = null
    @Volatile private var semanticIndexAll:    SemanticIndex? = null
    private val mutexFirst  = kotlinx.coroutines.sync.Mutex()
    private val mutexSecond = kotlinx.coroutines.sync.Mutex()
    private val mutexAll    = kotlinx.coroutines.sync.Mutex()

    /** Fixed slice size: 20 000 articles per scope. */
    private val SCOPE_SLICE = 20_000

    /**
     * v5.4.383cc — Resolve the exact article IDs that belong to one selected
     * single-search partition. `null` means no filtering (Dual or All notes).
     *
     * Deep search blends FTS/keyword candidates with semantic candidates. The
     * scope selector must constrain BOTH sides of that blend; otherwise whole-
     * library FTS hits can leak 1st-20K articles into a 2nd-22K search and make
     * the two scopes appear identical even though the vector scan itself used
     * the correct OFFSET.
     */
    private suspend fun scopeMembershipIds(
        scope: String,
        dualMode: Boolean
    ): Set<Long>? {
        if (dualMode || scope == "all") return null
        val (limit, offset) = when (scope) {
            "first20k" -> SCOPE_SLICE to 0
            "second20k" -> Int.MAX_VALUE to SCOPE_SLICE
            else -> return null
        }
        return runCatching {
            dao.getSearchScopeNoteIdPage(limit, offset).toHashSet()
        }.getOrElse { error ->
            android.util.Log.e(
                "MarkVault",
                "Failed to resolve semantic scope membership: scope=$scope offset=$offset",
                error
            )
            // Fail closed. Returning an empty set is safer than silently
            // searching the whole library under a selected partition label.
            emptySet()
        }
    }

    /**
     * Load embedding rows for the given scope from the DB.
     *   "first20k"  → most recent 20k articles (OFFSET 0)
     *   "second20k" → next 20k articles         (OFFSET 20k)
     *   "all"       → truly every row in note_embeddings (no LIMIT)
     *
     * For sliced scopes, note IDs are fetched ordered by lastModified DESC then
     * loaded via loadEmbeddingsForNotes() in 900-item batches to respect
     * SQLite's 999-variable IN-clause limit.
     */
    private suspend fun buildScopeRows(
        scope: String
    ): List<com.tebogo.markvault.data.NoteEmbedding> {
        return when (scope) {
            "first20k" -> {
                val noteIds = dao.getEmbeddedNoteIdPage(
                    embedder.modelVersion, SCOPE_SLICE, 0
                )
                if (noteIds.isEmpty()) return emptyList()
                noteIds.chunked(900).flatMap { batch ->
                    dao.loadEmbeddingsForNotes(embedder.modelVersion, batch)
                }
            }
            "second20k" -> {
                // v5.4.193cc — Load EVERYTHING beyond the first 20k slice.
                // Using Int.MAX_VALUE as the limit means "no upper cap" —
                // so if the library grows to 50k articles, this scope covers
                // all 30k articles from position 20 001 onwards.
                val noteIds = dao.getEmbeddedNoteIdPage(
                    embedder.modelVersion, Int.MAX_VALUE, SCOPE_SLICE
                )
                if (noteIds.isEmpty()) return emptyList()
                noteIds.chunked(900).flatMap { batch ->
                    dao.loadEmbeddingsForNotes(embedder.modelVersion, batch)
                }
            }
            else -> {
                // "all" — no filter, no limit. User explicitly chose this.
                // Will load every chunk row regardless of count (~42k articles
                // once fully embedded). Slow on first call; cached thereafter.
                dao.loadAllEmbeddings(embedder.modelVersion)
            }
        }
    }

    /**
     * v5.4.372cc — Result of one short-lived streamed semantic page.
     *
     * The heavy Room entities/BLOBs and temporary FloatArrays never escape
     * [scoreStreamPage]. This is intentional: a memory-pressure cleanup must
     * run only AFTER that helper has returned, otherwise the suspended
     * coroutine frame can keep the page strongly reachable while GC runs.
     */
    private data class StreamPageResult(
        val noteCount: Int,
        val rowCount: Int
    )

    private suspend fun scoreStreamPage(
        scope: String,
        qVec: FloatArray,
        modelVersion: String,
        pageSize: Int,
        offset: Int,
        scores: HashMap<Long, Float>
    ): StreamPageResult? {
        val noteIds = runCatching {
            dao.getSearchScopeNoteIdPage(pageSize, offset)
        }.getOrElse {
            android.util.Log.e(
                "MarkVault",
                "Streaming semantic scope page failed: scope=$scope offset=$offset",
                it
            )
            return null
        }
        if (noteIds.isEmpty()) return StreamPageResult(0, 0)

        val rows = runCatching {
            // v5.5.9 — semantic scoring only needs noteId + vector.
            dao.loadEmbeddingVectorsForNotes(modelVersion, noteIds)
        }.getOrElse {
            android.util.Log.e(
                "MarkVault",
                "Streaming semantic embeddings failed: scope=$scope offset=$offset",
                it
            )
            return null
        }

        for (row in rows) {
            if (row.vector.size != qVec.size * 4) continue
            val score = normalizedEmbeddingDot(qVec, row.vector)
            val existing = scores[row.noteId]
            if (existing == null || score > existing) scores[row.noteId] = score
        }
        return StreamPageResult(noteIds.size, rows.size)
    }

    /**
     * v5.4.265cc/v5.4.372cc — Memory-bounded semantic scoring for large
     * scopes. The search keeps only one short-lived DB page plus the compact
     * best-score map resident; the query vector is already computed before the
     * scan begins, so emergency cleanup may safely unload the embedder.
     */
    private suspend fun streamScopeScores(
        scope: String,
        qVec: FloatArray,
        modelVersion: String,
        progressBase: Int = 0,
        progressTotal: Int = 0
    ): HashMap<Long, Float> {
        val scores = HashMap<Long, Float>()
        // v5.4.372cc — Smaller page than the old 500-note batch. Some long
        // articles have many passage embeddings, so a 500-note page can expand
        // into a much larger BLOB set than its note count suggests. 160 keeps
        // the transient Room/FloatArray working set comfortably bounded while
        // retaining batched DB access.
        val pageSize = 160
        var offset = if (scope == "second20k") SCOPE_SLICE else 0
        var totalRows = 0
        _loadingScopeFlow.value = scope
        _scopeLoadStatus.value = "loading"

        while (true) {
            // v5.5.14 — Graceful Stop Search never cancels this coroutine. Stop
            // before loading the next heavy page and keep everything scored so far
            // for final fusion/reranking/persistence.
            if (gracefulSearchStopRequested()) break

            // Heavy page objects live only inside scoreStreamPage(). By the time
            // this call returns, its coroutine frame is gone and the page BLOBs
            // and temporary vectors are collectible BEFORE the pressure check.
            val page = scoreStreamPage(scope, qVec, modelVersion, pageSize, offset, scores) ?: break
            if (page.noteCount == 0) break

            totalRows += page.rowCount
            _scopeLoadStatus.value = "scored:${scores.size}"
            if (progressTotal > 0) {
                updateSearchWork(
                    done = progressBase + page.noteCount +
                        (offset - if (scope == "second20k") SCOPE_SLICE else 0),
                    total = progressTotal,
                    stage = if (scope == "second20k") "Searching remaining library…" else "Searching library…"
                )
            }

            // v5.4.372cc — Cleanup is deliberately AFTER scoreStreamPage has
            // returned. This makes an automatic 95% cleanup capable of
            // reclaiming the page that actually caused the pressure.
            checkMemoryPressureAndPause(abortOnPersistentPressure = false)

            // The stop may have been requested while this page was being scored.
            // Include this completed page, then freeze retrieval at this boundary.
            if (gracefulSearchStopRequested()) break
            if (page.noteCount < pageSize) break
            offset += pageSize
            if (scope == "first20k" && offset >= SCOPE_SLICE) break
        }

        when (scope) {
            "first20k" -> _firstScopeChunks.value = totalRows
            "second20k" -> _secondScopeChunks.value = totalRows
        }
        _scopeLoadStatus.value = if (gracefulSearchStopRequested())
            "stopped:${scores.size}" else "loaded:${scores.size}"
        _loadingScopeFlow.value = null
        android.util.Log.i(
            "MarkVault",
            "Streaming semantic scope ${if (gracefulSearchStopRequested()) "stopped" else "complete"}: " +
                "scope=$scope chunks=$totalRows notes=${scores.size}"
        )
        return scores
    }

    /**
     * Ensure the index for [scope] is loaded and return it.
     * Idempotent — concurrent callers for the same scope serialise on that
     * scope's own mutex; different scopes never block each other.
     */
    private suspend fun ensureScopeIndex(scope: String): SemanticIndex? {
        val cached = when (scope) {
            "first20k"  -> semanticIndexFirst
            "second20k" -> semanticIndexSecond
            else        -> semanticIndexAll
        }
        cached?.let { return it }

        val mutex = when (scope) {
            "first20k"  -> mutexFirst
            "second20k" -> mutexSecond
            else        -> mutexAll
        }

        return mutex.withLock {
            val cached2 = when (scope) {
                "first20k"  -> semanticIndexFirst
                "second20k" -> semanticIndexSecond
                else        -> semanticIndexAll
            }
            cached2?.let { return@withLock it }
            if (!embedder.isModelAvailable()) return@withLock null
            // Capture epoch before the slow DB load. If scope changes while
            // we are loading, scopeEpoch will have incremented and we discard.
            val epochSnapshot = scopeEpoch
            _semanticIndexWarming.value = true
            _loadingScopeFlow.value = scope          // v5.4.199cc — live scope indicator
            _scopeLoadStatus.value = "loading"
            val rows = runCatching { buildScopeRows(scope) }.getOrElse {
                _semanticIndexWarming.value = false
                _scopeLoadStatus.value = ""
                return@withLock null
            }
            // Epoch check — scope changed while we were loading, discard result.
            if (scopeEpoch != epochSnapshot) {
                _semanticIndexWarming.value = false
                _loadingScopeFlow.value = null
                _scopeLoadStatus.value = ""
                return@withLock null
            }
            if (rows.isEmpty()) {
                _semanticIndexWarming.value = false
                _loadingScopeFlow.value = null
                _scopeLoadStatus.value = ""
                return@withLock null
            }
            val ids  = LongArray(rows.size)
            val vecs = Array(rows.size) { FloatArray(0) }   // placeholder, filled below
            for (i in rows.indices) {
                ids[i]  = rows[i].noteId
                vecs[i] = com.tebogo.markvault.search.bytesToFloatArray(rows[i].vector)
                // v5.4.230cc — Proactive OOM check every 100 vectors while
                // building the full Array<FloatArray> (the largest single
                // allocation in the app — the "All notes" scope in particular).
                // v5.4.245cc — If the circuit breaker signals abort, stop
                // immediately and return null rather than continue — vecs
                // would otherwise contain trailing empty placeholder
                // entries mixed with real ones, corrupting the index.
                if (checkMemoryPressureAndPause()) {
                    _semanticIndexWarming.value = false
                    _loadingScopeFlow.value = null
                    _scopeLoadStatus.value = ""
                    return@withLock null
                }
            }
            val newIdx = SemanticIndex(ids, vecs, rows[0].dim)
            when (scope) {
                "first20k"  -> { semanticIndexFirst  = newIdx; _firstScopeChunks.value  = rows.size }
                "second20k" -> { semanticIndexSecond = newIdx; _secondScopeChunks.value = rows.size }
                else        -> { semanticIndexAll    = newIdx }  // "all"
            }
            // Total across all cached scopes (only one is non-null at a time).
            val total = (semanticIndexFirst?.noteIds?.size  ?: 0) +
                        (semanticIndexSecond?.noteIds?.size ?: 0) +
                        (semanticIndexAll?.noteIds?.size    ?: 0)
            _semanticChunkCount.value = total
            _loadingScopeFlow.value = null              // loading done
            _scopeLoadStatus.value = "loaded:$total"
            _semanticIndexWarming.value = false
            newIdx
        }
    }

    /** Clear all scope caches. Called when scope changes or embeddings are rebuilt. */
    private fun invalidateSemanticIndex() {
        scopeEpoch++
        semanticIndexFirst  = null
        semanticIndexSecond = null
        semanticIndexAll    = null
        _semanticChunkCount.value = 0
        _firstScopeChunks.value   = 0
        _secondScopeChunks.value  = 0
        _loadingScopeFlow.value   = null
        _scopeLoadStatus.value    = ""
    }

    // v5.4.238cc — FIXED: the threshold used to be a hardcoded 1400L,
    // assuming the device's heap ceiling was actually 1536 MB. Evidence
    // (the in-app RAM overlay, and OOM crash logs earlier in this app's
    // history showing "target footprint 805306368" = exactly 768 MB)
    // confirms the REAL ceiling on this device is 768 MB regardless of
    // what dalvik.vm.heapsize/heapgrowthlimit are set to via Magisk — a
    // hardcoded 1400 MB threshold would NEVER fire before the real OOM
    // crash at ~768 MB. The threshold is now computed from whatever
    // Runtime.getRuntime().maxMemory() ACTUALLY reports for the current
    // process, every time it's checked — so the safety margin is always
    // correct regardless of what the true ceiling turns out to be (768 MB
    // today, or 1536 MB automatically once the device-side Zygote/heap
    // issue is actually resolved — no code change needed either way).
    private val _memoryPauseActive = MutableStateFlow(false)
    val memoryPauseActive: StateFlow<Boolean> = _memoryPauseActive

    /**
     * v5.4.260cc — Exact 95% circuit-breaker in BYTES, not rounded MB.
     * Using MB integers could move the trigger by almost 1 MB on either side
     * of the intended boundary. The actual comparison is now exactly:
     * usedHeapBytes >= maxHeapBytes * 0.95.
     */
    private fun memoryPauseThresholdBytes(): Long {
        val maxBytes = Runtime.getRuntime().maxMemory()
        return (maxBytes * 95L) / 100L
    }

    /** v5.4.372cc — Hysteresis target after a 95% emergency cleanup. Resume
     * only after enough headroom exists that the very next DB page cannot
     * immediately retrigger the breaker. */
    private fun memoryResumeThresholdBytes(): Long {
        val maxBytes = Runtime.getRuntime().maxMemory()
        return (maxBytes * 85L) / 100L
    }

    private fun usedHeapBytes(): Long {
        val rt = Runtime.getRuntime()
        return rt.totalMemory() - rt.freeMemory()
    }

    private fun usedHeapMB(): Long = usedHeapBytes() / (1024 * 1024)

    private fun memoryPressureRatio(): Double {
        val maxBytes = Runtime.getRuntime().maxMemory().coerceAtLeast(1L)
        return usedHeapBytes().toDouble() / maxBytes.toDouble()
    }

    /**
     * v5.5.9 — MiniLM/USE are small enough to coexist with the reranker.
     * BGE-base/BGE-large are deliberately excluded so their previous memory
     * safety behaviour is preserved. The 85% guard means even a lightweight
     * model is not kept warm when the Java heap is already under pressure.
     */
    private fun canKeepLightweightSearchStackWarm(): Boolean {
        val descriptor = embedder.descriptor
        return descriptor.approxSizeMb <= 32 &&
            usedHeapBytes() < memoryResumeThresholdBytes()
    }

    /**
     * v5.4.242cc — Native heap usage (malloc'd C++ memory). Where ONNX
     * Runtime's model weights typically live — the OrtSession object on
     * the Kotlin side is a thin handle into native memory.
     */
    private fun usedNativeMB(): Long =
        android.os.Debug.getNativeHeapAllocatedSize() / (1024 * 1024)

    /**
     * v5.4.245cc — True total PSS (Proportional Set Size) via
     * ActivityManager, replacing the earlier Java-heap + native-malloc-heap
     * sum. That combination still couldn't fully explain a persistent
     * ~100 MB gap after cleanup — one real possibility: if ONNX Runtime
     * loads model weights via memory-mapped file I/O (common for large
     * model files, to avoid a full read-into-heap copy), that memory is
     * file-backed, not malloc'd — it wouldn't show up in
     * getNativeHeapAllocatedSize() OR the Java heap. PSS is Android's
     * complete, authoritative per-process memory accounting: Java heap,
     * native heap, AND memory-mapped files, graphics, everything. If
     * something is hiding from the other two measurements, this is the
     * one number it cannot hide from. More expensive (binder IPC to
     * system_server), so used for the occasional before/after cleanup
     * measurement, not the continuous 1-second overlay tick.
     */
    private fun usedPssMB(): Long = runCatching {
        val am = getApplication<Application>()
            .getSystemService(android.content.Context.ACTIVITY_SERVICE) as android.app.ActivityManager
        val info = am.getProcessMemoryInfo(intArrayOf(android.os.Process.myPid()))
        (info.firstOrNull()?.totalPss ?: 0) / 1024L
    }.getOrDefault(0L)

    /** The number that actually reflects whether closing a model released
     *  real memory, including anything neither Java nor native-malloc
     *  heap measurements alone could see. */
    private fun usedTotalMB(): Long = usedPssMB()

    /**
     * v5.4.241cc — Clear Coil's image memory cache. Coil is a completely
     * separate singleton from everything else this ViewModel manages —
     * closing the embedder/reranker/T5/LLM/semantic-index and calling
     * System.gc() does NOTHING to it. This is the one explicit call that
     * actually reaches it. Called from every memory-cleanup path below.
     */
    /**
     * v5.4.246cc — True while a background operation the user explicitly
     * wants protected from aggressive cleanup is active: re-embedding /
     * library indexing (EmbeddingProgressBus, the foreground service that
     * generates embeddings for the vault), any model/reranker download,
     * or media currently associated with the player (streaming or
     * paused — the user still intends to return to it).
     *
     * Session closing itself (embedder/reranker/T5/LLM/index/Coil) is
     * NOT skipped when this is true — EmbeddingService uses its own,
     * completely separate Embedder instance (confirmed by reading its
     * source), so closing AppViewModel's copy doesn't touch it, and
     * downloads/playback don't hold ONNX sessions at all. What DOES get
     * skipped: SQLite's page cache release (the embedding service writes
     * to the DB continuously while running — evicting that cache mid-pass
     * is unnecessary friction) and the aggressive multi-pass GC-with-
     * delays settle (real stutter risk while a background job is
     * actively using the CPU).
     */
    private fun backgroundWorkProtected(): Boolean {
        if (_hnswBuilding.value || _annBuilding.value) return true
        if (com.tebogo.markvault.search.EmbeddingProgressBus.progress.value != null) return true
        if (_modelDownloadProgress.value != null) return true
        if (_t5DownloadProgress.value != null) return true
        if (_rerankerDownloadProgress.value != null) return true
        if (com.tebogo.markvault.llm.ChatDownloadProgressBus.progress.value != null) return true
        if (_nowPlayingMedia.value != null) return true
        return false
    }

    private fun clearImageCache() {
        runCatching {
            coil.Coil.imageLoader(getApplication()).memoryCache?.clear()
        }
    }

    /**
     * v5.4.243cc — Search runs FTS5 queries across the whole library, and
     * manual rerank does up to 20 individual dao.byId() calls fetching
     * full note content — none of that goes through anything closed
     * above. SQLite maintains its own internal page cache underneath
     * Room, entirely separate from Java/native-heap-via-ONNX. This is
     * the documented, official Android API for releasing it.
     */
    private fun releaseSqliteCache() {
        runCatching { android.database.sqlite.SQLiteDatabase.releaseMemory() }
    }

    /**
     * v5.4.243cc — Settle + double-GC before measuring "after". A single
     * System.gc() call, measured 150ms later, may not give ART enough
     * time to fully reclaim a complex object graph in one pass — this
     * runs GC, waits, runs it again, then waits once more before the
     * caller measures. Used by every cleanup path's before/after Toast.
     */
    private suspend fun settleAndDoubleGc() {
        runCatching { System.gc() }
        kotlinx.coroutines.delay(200L)
        runCatching { System.gc() }
        kotlinx.coroutines.delay(250L)
    }

    /**
     * v5.4.372cc — Emergency Java-heap settling used by automatic search
     * cleanup. Unlike a blind pair of GC requests, this verifies the actual
     * heap after every pass and stops as soon as there is safe headroom.
     *
     * This is intentionally used only in the pressure/post-search path, not in
     * normal UI work. runFinalization() gives native/AutoCloseable wrappers
     * whose Java peers became unreachable a chance to finish teardown before
     * the next GC measurement.
     */
    private suspend fun settleHeapUntilSafe(maxPasses: Int = 4): Long {
        var used = usedHeapBytes()
        var pass = 0
        while (used >= memoryResumeThresholdBytes() && pass < maxPasses) {
            runCatching { System.gc() }
            runCatching { System.runFinalization() }
            kotlinx.coroutines.delay(150L)
            used = usedHeapBytes()
            pass++
        }
        return used
    }

    /** v5.4.238cc — Live diagnostic: what heap ceiling is this process ACTUALLY bound by right now. */
    fun currentMaxHeapMB(): Long = Runtime.getRuntime().maxMemory() / (1024 * 1024)

    /**
     * v5.4.236cc — Main-thread-safe Toast showing how much heap was freed
     * by a cleanup pass. Uses getApplication() directly (no Activity
     * needed — Toast only requires a Context).
     */
    private fun showMemoryClearedToast(freedMb: Long) {
        val ctx = getApplication<Application>()
        android.os.Handler(android.os.Looper.getMainLooper()).post {
            val msg = if (freedMb > 0) "Memory Cleared: Freed ${freedMb} MB" else "Memory Cleared"
            android.widget.Toast.makeText(ctx, msg, android.widget.Toast.LENGTH_SHORT).show()
        }
    }

    /** v5.4.372cc — Do not claim success when an automatic cleanup did not
     * actually create Java-heap headroom. */
    private fun showMemoryStillHighToast(usedMb: Long, maxMb: Long) {
        val ctx = getApplication<Application>()
        android.os.Handler(android.os.Looper.getMainLooper()).post {
            android.widget.Toast.makeText(
                ctx,
                "Memory still high: ${usedMb} / ${maxMb} MB — waiting for release",
                android.widget.Toast.LENGTH_SHORT
            ).show()
        }
    }

    /**
     * v5.4.236cc — Thorough reset specifically for returning to the
     * Homepage. Goes further than [scheduleMemoryClearAfterNavigation]
     * (which only clears the semantic index/embedder/reranker): this also
     * clears the search query and held result lists, since Home is where
     * the user expects a genuinely fresh start, not just a lighter heap.
     *
     * query.value = "" cascades through the reactive `results` StateFlow
     * (built via flatMapLatest) and naturally empties it — results isn't
     * a plain field that can be nulled directly, since it's derived.
     */
    fun resetHomeState() {
        val before = usedTotalMB()
        mediaSearchJob?.cancel()
        captionSearchJob?.cancel()
        query.value = ""
        _manualRerankResult.value = null
        _lastKnownResults = emptyList()
        _semanticMediaResults.value = emptyList()
        _semanticMediaQuery = ""
        _captionVideoResults.value = emptyList()
        _idleCleanupJob?.cancel()
        viewModelScope.launch(Dispatchers.IO) {
            // v5.4.269cc — The Home reset must wait for the background media
            // indexer to leave any native embed() call before closing the
            // shared TextEmbedder. A cancellation request without join can
            // otherwise race TextEmbedder.close() and crash in native code.
            cancelMediaSemanticIndexing()
            runCatching { reranker.unload() }
            runCatching { embedder.close() }
            runCatching { t5Engine?.close() }
            t5Engine = null
            t5EngineLoadAttempted = false
            runCatching { com.tebogo.markvault.llm.LlmManager.unload() }
            invalidateSemanticIndex()
            webTabThumbnails.clear()
            clearImageCache()
            val protectedNow = backgroundWorkProtected()
            if (!protectedNow) releaseSqliteCache()
            if (!protectedNow) settleAndDoubleGc() else runCatching { System.gc() }
            val after = usedTotalMB()
            val freed = (before - after).coerceAtLeast(0L)
            showMemoryClearedToast(freed)
        }
    }

    /**
     * Call on every row inside the large search/index loops. The 95% guard is
     * cheap while memory is below the threshold, and checking every row removes
     * the previous sampling window in which a large allocation could cross 95%
     * before the next checkpoint.
     * v5.4.245cc/v5.4.266cc — Returns Boolean for callers that are building
     * a monolithic semantic index and therefore cannot safely continue after
     * persistent pressure. Streamed semantic search passes
     * abortOnPersistentPressure=false because its working set is bounded and
     * truncating a streamed scope would silently make the user's 42k-article
     * dual search incomplete.
     */
    @Volatile private var consecutivePauseCount = 0

    private suspend fun checkMemoryPressureAndPause(
        abortOnPersistentPressure: Boolean = true
    ): Boolean {
        // v5.4.242cc — Deliberately Java-heap-only here, NOT usedTotalMB().
        // memoryPauseThresholdBytes() is exactly 95% of Runtime.getRuntime().maxMemory()
        // — the Java heap ceiling specifically — and every OOM crash actually
        // observed in this app's history has been a Dalvik/ART
        // OutOfMemoryError (Java heap exhaustion), not a native allocation
        // failure. Comparing a Java-heap-calibrated threshold against a
        // Java+native combined total would trigger the safety pause too
        // early, inconsistent with what it's actually protecting against.
        // Exact byte comparison prevents rounding drift and makes the 95%
        // threshold deterministic on small heaps such as 768 MB.
        if (usedHeapBytes() < memoryPauseThresholdBytes()) {
            consecutivePauseCount = 0
            return false
        }
        consecutivePauseCount++
        android.util.Log.w(
            "MarkVault",
            "95% memory circuit breaker: heap=${usedHeapMB()}MB / max=${Runtime.getRuntime().maxMemory() / (1024 * 1024)}MB " +
                "(${(memoryPressureRatio() * 100.0).coerceAtMost(999.0)}%), pass=$consecutivePauseCount"
        )
        if (consecutivePauseCount > 3) {
            consecutivePauseCount = 0
            _memoryPauseActive.value = false
            if (abortOnPersistentPressure) {
                _scopeLoadStatus.value = ""
                return true   // index construction cannot safely continue
            }
            // v5.4.266cc — Streamed semantic search has a bounded working set
            // and must cover every article/chunk. Persistent pressure therefore
            // cannot be allowed to truncate the scope. The caller continues to
            // the next page; the current page is released by normal scope exit.
            android.util.Log.w(
                "MarkVault",
                "95% pressure persisted during streamed search; continuing full scope " +
                    "scope-safe after bounded-page cleanup"
            )
        }
        _memoryPauseActive.value = true
        val prevStatus = _scopeLoadStatus.value
        _scopeLoadStatus.value = "\u23F8\uFE0F High memory \u2014 clearing\u2026"
        // v5.4.264cc — The 95% circuit breaker uses the exact same exhaustive
        // release routine as post-search cleanup. This means the threshold does
        // not merely set a pause flag or close one model: it immediately drops
        // every resource in the release list and waits for native teardown +
        // two GC passes before allowing the caller to continue.
        var afterHeap = forceReleaseSearchMemory()
        // v5.4.372cc — If ART has not yet returned enough headroom, do not
        // immediately allocate the next Room/BLOB page. Give the collector a
        // short bounded settle window while the search remains visibly paused.
        // This prevents the old clear -> allocate -> clear oscillation that
        // eventually ended in OOM.
        var waitPass = 0
        while (afterHeap >= memoryResumeThresholdBytes() && waitPass < 6) {
            _scopeLoadStatus.value = "⏸️ High memory — waiting for release…"
            kotlinx.coroutines.delay(250L)
            runCatching { System.gc() }
            runCatching { System.runFinalization() }
            afterHeap = usedHeapBytes()
            waitPass++
        }
        _scopeLoadStatus.value = prevStatus
        _memoryPauseActive.value = false
        return abortOnPersistentPressure && afterHeap >= memoryPauseThresholdBytes()
    }

    /**
     * v5.4.230cc — Full memory reset, triggered by long-pressing the Dual
     * strip. Clears every semantic index scope, closes the embedder and
     * reranker (native ONNX sessions), forces GC — restoring the app to the
     * same memory footprint as a fresh launch. The next search lazy-reloads
     * whatever it needs.
     */
    fun hardResetMemory() {
        val before = usedTotalMB()
        viewModelScope.launch(Dispatchers.IO) {
            // v5.4.269cc — Wait for any in-flight media embed to finish before
            // closing the shared native embedder.
            cancelMediaSemanticIndexing()
            invalidateSemanticIndex()
            runCatching { reranker.unload() }
            runCatching { embedder.close() }
            // v5.4.241cc — Was missing T5/LLM release and image cache clear,
            // same gap as the other cleanup paths. "On all instances" now
            // means all of them actually match.
            runCatching { t5Engine?.close() }
            t5Engine = null
            t5EngineLoadAttempted = false
            viewModelScope.launch(Dispatchers.IO) {
                runCatching { com.tebogo.markvault.llm.LlmManager.unload() }
            }
            clearImageCache()
            webTabThumbnails.clear()
            val protectedNow = backgroundWorkProtected()
            if (!protectedNow) releaseSqliteCache()
            viewModelScope.launch(Dispatchers.Default) {
                if (!protectedNow) settleAndDoubleGc() else runCatching { System.gc() }
                val after = usedTotalMB()
                showMemoryClearedToast((before - after).coerceAtLeast(0L))
            }
        }
    }

    /**
     * v5.4.225cc — Release semantic index + embedder + reranker before
     * navigating to a heavy screen (JW Videos, media player, etc.).
     * The semantic index can hold 240 MB+ of float arrays. Navigating to a
     * new Compose screen while the heap is 97% full causes OOM at allocation.
     */
    private var navMemoryClearJob: kotlinx.coroutines.Job? = null

    /**
     * v5.4.233cc — Called on EVERY navigation destination change (wired in
     * MainActivity). A short debounced delay, then a full memory clear —
     * "any new window opened... after a few ms the ram must be cleared,
     * so the heap ram does not stay full, always prioritize new app
     * state." Debounced (cancels a pending clear if navigation happens
     * again quickly) so rapid back-and-forth doesn't thrash GC.
     */
    fun scheduleMemoryClearAfterNavigation() {
        navMemoryClearJob?.cancel()
        navMemoryClearJob = viewModelScope.launch(Dispatchers.IO) {
            kotlinx.coroutines.delay(400L)
            freeMemoryForNavigationInternal()
        }
    }

    private suspend fun freeMemoryForNavigationInternal() {
        // v5.4.403cc — Never run a second model teardown while a search is
        // active or its post-search cleanup job is still running. Notification
        // resume can navigate at exactly this boundary; double-closing native
        // sessions is both wasted work and a crash risk.
        if (_searchBusy.value || _rerankActive.value || _idleCleanupJob?.isActive == true) return
        // v5.4.269cc — Cancellation must be joined before closing the shared
        // native embedder. Navigation can occur while the idle media indexer
        // is inside an embed() call; closing first is unsafe.
        cancelMediaSemanticIndexing()
        invalidateSemanticIndex()
        runCatching { reranker.unload() }
        runCatching { embedder.close() }
        runCatching { System.gc() }
    }

    fun freeMemoryForNavigation() {
        viewModelScope.launch(Dispatchers.IO) {
            freeMemoryForNavigationInternal()
        }
    }

    /**
     * v5.4.185cc — Two-stage semantic scoring: given a set of note IDs that
     * FTS5 already found, load ONLY those notes' chunk embeddings from DB.
     * Scales to any library size; never touches the scope caches.
     */
    private suspend fun semanticRerankCandidates(
        qVec: FloatArray,
        candidateIds: Collection<Long>,
        topK: Int,
        modelVersion: String
    ): List<Pair<Long, Float>> {
        if (candidateIds.isEmpty() || qVec.isEmpty()) return emptyList()
        return try {
            // v5.5.9 — The query was already embedded before ANN cluster probing.
            // The old ANN path embedded the SAME query a second time here, which
            // doubled ONNX query inference and disproportionately hurt BGE models.
            // Reuse qVec and stream lightweight DB projections page-by-page instead.
            val bestScore = HashMap<Long, Float>(candidateIds.size)
            for (chunk in candidateIds.toList().chunked(900)) {
                currentCoroutineContext().ensureActive()
                // v5.5.14 — After Stop Search, finish no new ANN vector batch;
                // whatever has already been rescored proceeds to final reranking.
                if (gracefulSearchStopRequested() && bestScore.isNotEmpty()) break
                val rows = try {
                    dao.loadEmbeddingVectorsForNotes(modelVersion, chunk)
                } catch (ce: kotlinx.coroutines.CancellationException) {
                    throw ce
                } catch (_: Throwable) {
                    emptyList()
                }
                for (row in rows) {
                    if (row.vector.size != qVec.size * 4) continue
                    val score = normalizedEmbeddingDot(qVec, row.vector)
                    val existing = bestScore[row.noteId]
                    if (existing == null || score > existing) bestScore[row.noteId] = score
                }
                if (gracefulSearchStopRequested()) break
            }
            bestScore.entries.sortedByDescending { it.value }.take(topK)
                .map { it.key to it.value }
        } catch (t: Throwable) {
            if (t is kotlinx.coroutines.CancellationException) throw t
            android.util.Log.e("MarkVault", "semanticRerankCandidates failed", t)
            emptyList()
        }
    }

    /**
     * v5.5.12 — The semantic retrieval result plus the exact query-vector/model
     * identity that produced it. Hybrid search needs this evidence AFTER keyword
     * fusion so the cross-encoder can rerank the final candidate set (including
     * keyword-only candidates) without embedding the query a second time.
     */
    private data class SemanticSearchOutcome(
        val ranking: List<Pair<Long, Float>>,
        val queryVector: FloatArray? = null,
        val modelVersion: String? = null,
        val modelApproxSizeMb: Int = 0
    )

    /** Outer defensive wrapper. Returns empty list on any soft failure. */
    suspend fun semanticSearch(
        query: String,
        topK: Int = 200,
        allowRerank: Boolean = true
    ): List<Pair<Long, Float>> {
        if (query.isBlank()) return emptyList()
        // v5.4.383cc — Snapshot the selected partition at invocation time.
        // A scope-chip tap while an expensive embedding/search is already in
        // flight must affect the NEXT search, never move this search to another
        // partition halfway through its scan.
        val scopeAtStart = currentScope
        val dualAtStart = _semanticDualModeFlow.value
        return semanticSearchForScope(query, topK, allowRerank, scopeAtStart, dualAtStart)
    }

    private suspend fun semanticSearchForScope(
        query: String,
        topK: Int,
        allowRerank: Boolean,
        scopeAtStart: String,
        dualAtStart: Boolean
    ): List<Pair<Long, Float>> = semanticSearchOutcomeForScope(
        query = query,
        topK = topK,
        allowRerank = allowRerank,
        scopeAtStart = scopeAtStart,
        dualAtStart = dualAtStart
    ).ranking

    private suspend fun semanticSearchOutcomeForScope(
        query: String,
        topK: Int,
        allowRerank: Boolean,
        scopeAtStart: String,
        dualAtStart: Boolean
    ): SemanticSearchOutcome {
        if (query.isBlank()) return SemanticSearchOutcome(emptyList())
        return try {
            semanticSearchInner(query, topK, allowRerank, scopeAtStart, dualAtStart)
        } catch (t: Throwable) {
            if (t is kotlinx.coroutines.CancellationException) throw t
            android.util.Log.e(
                "MarkVault",
                "semanticSearch failed for query=\"$query\" scope=$scopeAtStart dual=$dualAtStart",
                t
            )
            if (t is OutOfMemoryError) runCatching { System.gc() }
            SemanticSearchOutcome(emptyList())
        }
    }

    private suspend fun semanticSearchInner(
        query: String,
        topK: Int,
        allowRerank: Boolean,
        scopeAtStart: String,
        dualAtStart: Boolean
    ): SemanticSearchOutcome {
        val perfSearchStarted = android.os.SystemClock.elapsedRealtime()
        val timingTrace = activeSearchTrace

        // v5.5.12 — Freeze one exact embedder/model identity for the complete
        // retrieval. Older code repeatedly read the volatile global `embedder`
        // after query inference; a model switch at just the wrong boundary could
        // pair model-A's query vector with model-B's stored vectors. A single
        // request now stays in one vector space from query -> ANN -> DB scoring ->
        // rerank-passage selection.
        val searchEmbedder = embedder
        val searchDescriptor = searchEmbedder.descriptor
        val modelVersionAtStart = searchEmbedder.modelVersion
        val queryForEmbedding = if (
            searchDescriptor.poolingStrategy == com.tebogo.markvault.search.PoolingStrategy.CLS
        ) "Represent this sentence for searching relevant passages: $query" else query

        cancelMediaSemanticIndexing()
        _searchWorkStage.value = "Understanding query…"
        val embedStarted = android.os.SystemClock.elapsedRealtime()
        val qVec = searchEmbedder.embed(queryForEmbedding)
            ?: return SemanticSearchOutcome(emptyList())
        val queryEmbedMs = android.os.SystemClock.elapsedRealtime() - embedStarted
        timingTrace?.timings?.add("Query embedding", queryEmbedMs)

        // A descriptor/vector mismatch means either a corrupt model asset or an
        // incompatible runtime output. Never compare that vector with DB rows.
        if (qVec.size != searchDescriptor.embeddingDim) {
            android.util.Log.e(
                "MarkVaultAccuracy",
                "Query vector dimension ${qVec.size} != expected ${searchDescriptor.embeddingDim} " +
                    "for $modelVersionAtStart; semantic search aborted"
            )
            return SemanticSearchOutcome(emptyList())
        }

        val baseOutcome = SemanticSearchOutcome(
            ranking = emptyList(),
            queryVector = qVec,
            modelVersion = modelVersionAtStart,
            modelApproxSizeMb = searchDescriptor.approxSizeMb
        )

        val normalizedMediaQuery = query.trim().removeSurrounding("\"").trim()
        var mediaSearchMs = 0L
        if (normalizedMediaQuery.isNotBlank()) {
            val mediaStarted = android.os.SystemClock.elapsedRealtime()
            val mediaResults = runCatching {
                semanticMediaSearch(qVec, modelVersionAtStart, limit = 20)
            }.getOrElse {
                android.util.Log.w("MarkVault", "Semantic media search skipped", it)
                emptyList()
            }
            mediaSearchMs = android.os.SystemClock.elapsedRealtime() - mediaStarted
            if (_semanticMediaQuery == normalizedMediaQuery) {
                _semanticMediaResults.value = mediaResults
                val merged = LinkedHashMap<String, com.tebogo.markvault.data.MediaItem>()
                mediaResults.forEach { item -> merged[item.jwKey.ifBlank { "id:${item.id}" }] = item }
                _mediaSearchResults.value.forEach { item ->
                    merged.putIfAbsent(item.jwKey.ifBlank { "id:${item.id}" }, item)
                }
                _mediaSearchResults.value = merged.values.take(30)
            }
        }

        var annProbeMs = 0L
        var annScopeFilterMs = 0L
        var annVectorScoreMs = 0L
        var annCandidatesForLog: Set<Long>? = null
        var hnswRecoveryComplete = false

        // v5.5.12 — Exact fallback used whenever ANN is unavailable, stale,
        // dimension-incompatible, unexpectedly empty, or leaves too few scoped
        // candidates to support the requested top-K. Accuracy wins over silently
        // accepting a suspicious approximate candidate set.
        suspend fun exactRanking(): List<Pair<Long, Float>> {
            val started = android.os.SystemClock.elapsedRealtime()
            return try { if (dualAtStart) {
                val totalArticles = runCatching { dao.countNotes() }.getOrElse { 0 }
                beginSearchWork(totalArticles, "articles", "Searching first 20k…")
                val firstTarget = minOf(SCOPE_SLICE, totalArticles)
                val firstScores = streamScopeScores(
                    "first20k", qVec, modelVersionAtStart,
                    progressBase = 0, progressTotal = totalArticles
                )
                runCatching { System.gc() }
                val secondScores = if (gracefulSearchStopRequested()) {
                    emptyMap<Long, Float>()
                } else {
                    streamScopeScores(
                        "second20k", qVec, modelVersionAtStart,
                        progressBase = firstTarget, progressTotal = totalArticles
                    )
                }
                runCatching { System.gc() }
                if (!gracefulSearchStopRequested()) completeSearchWork("Ranking matches…")
                else activeSearchTrace?.let { _searchWorkStage.value = stoppedSearchStage(it) }

                val merged = HashMap<Long, Float>(firstScores.size + secondScores.size)
                merged.putAll(firstScores)
                for ((n, score) in secondScores) {
                    val old = merged[n]
                    if (old == null || score > old) merged[n] = score
                }
                merged.entries
                    .sortedByDescending { it.value }
                    .take(topK)
                    .map { it.key to it.value }
            } else {
                val totalArticles = runCatching { dao.countNotes() }.getOrElse { 0 }
                val scopeTotal = when (scopeAtStart) {
                    "first20k" -> minOf(SCOPE_SLICE, totalArticles)
                    "second20k" -> (totalArticles - SCOPE_SLICE).coerceAtLeast(0)
                    else -> totalArticles
                }
                val stage = when (scopeAtStart) {
                    "first20k" -> "Searching first 20k…"
                    "second20k" -> "Searching remaining library…"
                    else -> "Searching entire library…"
                }
                beginSearchWork(scopeTotal, "articles", stage)
                val streamed = streamScopeScores(
                    scopeAtStart, qVec, modelVersionAtStart,
                    progressBase = 0, progressTotal = scopeTotal
                )
                if (!gracefulSearchStopRequested()) completeSearchWork("Ranking matches…")
                else activeSearchTrace?.let { _searchWorkStage.value = stoppedSearchStage(it) }
                streamed.entries
                    .sortedByDescending { it.value }
                    .take(topK)
                    .map { it.key to it.value }
            } } finally {
                timingTrace?.timings?.add("Full vector scan", android.os.SystemClock.elapsedRealtime() - started)
            }
        }

        // ── ANN accuracy-first fast path ──────────────────────────────────
        // IVF candidate generation remains approximate, but every returned
        // candidate is re-scored with its exact stored vector. Before trusting
        // the index, verify that its persisted vector count exactly matches the
        // current model's embedding table. A stale index must never silently
        // hide newly embedded/changed content.
        val useHnsw = activeSearchTrace?.hnswEnabled ?: hnswSearchEnabled.value
        val useIvf = (activeSearchTrace?.annEnabled ?: annSearchEnabled.value) && !useHnsw
        val annCandidates: Set<Long>? = if (useHnsw && hnswIndex.isAvailable(modelVersionAtStart)) {
            val stats = hnswIndex.stats(modelVersionAtStart)
            val count = dao.embeddingCount(modelVersionAtStart)
            val newest = dao.latestEmbeddingCreatedAt(modelVersionAtStart)
            if (stats == null || stats.dim != qVec.size || stats.embeddingCountAtBuild != count ||
                stats.embeddingWatermark < newest) {
                android.util.Log.w("MarkVaultAccuracy", "HNSW stale for $modelVersionAtStart; using exact scan")
                null
            } else {
                _searchWorkStage.value = "Searching blue HNSW index…"
                val started = android.os.SystemClock.elapsedRealtime()
                val allowed = if (!dualAtStart && scopeAtStart != "all")
                    scopeMembershipIds(scopeAtStart, false).orEmpty() else null
                val found = hnswIndex.findCandidatesDetailed(qVec, modelVersionAtStart,
                    articleLimit = (topK * 3).coerceIn(400, 1200), allowed = allowed)
                annProbeMs = android.os.SystemClock.elapsedRealtime() - started
                hnswRecoveryComplete = found?.exhaustiveRecovery == true
                found?.let {
                    android.util.Log.i("MarkVaultPerf", "HNSW model=${searchDescriptor.id} " +
                        "lookup=${it.elapsedMs}ms frontier=${it.passageFrontier} " +
                        "scored=${it.scoredVectors} nativeRecovery=${it.exhaustiveRecovery} " +
                        "articles=${it.ids.size}")
                    it.ids.also { ids -> annCandidatesForLog = ids }
                }
            }
        } else if (
            useIvf && annIndex.isAvailable(modelVersionAtStart)
        ) {
            val stats = runCatching { annIndex.stats(modelVersionAtStart) }.getOrNull()
            val dbCount = if (stats != null) {
                runCatching { dao.embeddingCount(modelVersionAtStart) }.getOrNull()
            } else null
            val latestEmbeddingAt = if (stats != null) {
                runCatching { dao.latestEmbeddingCreatedAt(modelVersionAtStart) }.getOrNull()
            } else null
            val fresh = stats != null && dbCount != null && latestEmbeddingAt != null &&
                stats.dim == qVec.size &&
                stats.embeddingCountAtBuild == dbCount &&
                stats.buildTimestamp >= latestEmbeddingAt

            if (!fresh) {
                android.util.Log.w(
                    "MarkVaultAccuracy",
                    "ANN bypassed for $modelVersionAtStart: " +
                        "indexCount=${stats?.embeddingCountAtBuild} dbCount=$dbCount " +
                        "indexDim=${stats?.dim} queryDim=${qVec.size} " +
                        "indexSyncedAt=${stats?.buildTimestamp} latestEmbeddingAt=$latestEmbeddingAt; " +
                        "using exact scan"
                )
                null
            } else {
                _searchWorkStage.value = "Searching index…"
                val annStarted = android.os.SystemClock.elapsedRealtime()
                val nprobe = annIndex.recommendedAccuracyNprobe(modelVersionAtStart)
                val found = annIndex.findCandidates(qVec, modelVersionAtStart, nprobe = nprobe)
                annProbeMs = android.os.SystemClock.elapsedRealtime() - annStarted
                if (found.isNullOrEmpty()) {
                    android.util.Log.w(
                        "MarkVaultAccuracy",
                        "ANN returned no candidates for $modelVersionAtStart (nprobe=$nprobe); using exact scan"
                    )
                    null
                } else {
                    annCandidatesForLog = found
                    found
                }
            }
        } else null

        val cosineRanking: List<Pair<Long, Float>> = if (annCandidates != null) {
            val scopeFilterStarted = android.os.SystemClock.elapsedRealtime()
            val scoped: Set<Long> = if (!dualAtStart && scopeAtStart != "all") {
                val allowed = scopeMembershipIds(scopeAtStart, false).orEmpty()
                annCandidates.filterTo(HashSet()) { it in allowed }
            } else {
                annCandidates
            }
            annScopeFilterMs = android.os.SystemClock.elapsedRealtime() - scopeFilterStarted

            // A tiny post-scope ANN pool is a recall warning. Exact scan rather
            // than returning fewer candidates simply because approximate cluster
            // probing missed most of the selected partition.
            val minimumUsefulCandidates = minOf(topK.coerceAtLeast(1), 200)
            if (scoped.size < minimumUsefulCandidates && !hnswRecoveryComplete) {
                android.util.Log.w(
                    "MarkVaultAccuracy",
                    "ANN scoped candidate pool too small (${scoped.size} < $minimumUsefulCandidates); " +
                        "using exact scan for scope=$scopeAtStart dual=$dualAtStart"
                )
                annCandidatesForLog = null
                exactRanking()
            } else {
                beginSearchWork(scoped.size, "candidates", "Scoring ${scoped.size} matches…")
                val vectorScoreStarted = android.os.SystemClock.elapsedRealtime()
                val ranked = semanticRerankCandidates(
                    qVec, scoped, topK, modelVersionAtStart
                )
                annVectorScoreMs = android.os.SystemClock.elapsedRealtime() - vectorScoreStarted
                if (!gracefulSearchStopRequested()) completeSearchWork("Ranking matches…")
                else activeSearchTrace?.let { _searchWorkStage.value = stoppedSearchStage(it) }
                if (ranked.isEmpty() && scoped.isNotEmpty()) {
                    android.util.Log.w(
                        "MarkVaultAccuracy",
                        "ANN candidates produced no compatible vectors; using exact scan"
                    )
                    annCandidatesForLog = null
                    exactRanking()
                } else {
                    // v5.5.14 — Record actual ANN use only when ANN candidates
                    // survived scope filtering and exact-vector rescoring.
                    markCurrentSearchAnnUsed(hnsw = useHnsw)
                    ranked
                }
            }
        } else {
            exactRanking()
        }

        timingTrace?.timings?.add("Media search", mediaSearchMs)
        timingTrace?.timings?.add("ANN lookup", annProbeMs + annScopeFilterMs)
        timingTrace?.timings?.add("Vector scoring", annVectorScoreMs)
        if (cosineRanking.isEmpty()) return baseOutcome
        currentCoroutineContext().ensureActive()

        val finalRanking = if (allowRerank && rerankEnabled.value && _rerankerInstalled.value) {
            // Keep lightweight models warm, but release BGE-scale native weights
            // before loading the cross-encoder. Use the frozen descriptor/model
            // identity, never whichever model happens to be globally active now.
            val keepWarm = searchDescriptor.approxSizeMb <= 32 &&
                usedHeapBytes() < memoryResumeThresholdBytes()
            if (!keepWarm) {
                runCatching { searchEmbedder.close() }
                runCatching { System.gc() }
            }
            val rerankStarted = android.os.SystemClock.elapsedRealtime()
            val reranked = applyRerank(
                query = query,
                candidates = cosineRanking,
                maxToRerank = ACCURACY_RERANK_WINDOW,
                semanticQueryVector = qVec,
                semanticModelVersion = modelVersionAtStart
            )
            val rerankMs = android.os.SystemClock.elapsedRealtime() - rerankStarted
            annCandidatesForLog?.let { candidates ->
                android.util.Log.i(
                    "MarkVaultPerf",
                    "ANN search engine=${if (useHnsw) "HNSW" else "IVF"} model=${searchDescriptor.id} " +
                        "embed=${queryEmbedMs}ms media=${mediaSearchMs}ms " +
                        "probe=${annProbeMs}ms scope=${annScopeFilterMs}ms " +
                        "vectors=${annVectorScoreMs}ms rerank=${rerankMs}ms " +
                        "candidates=${candidates.size} total=" +
                        "${android.os.SystemClock.elapsedRealtime() - perfSearchStarted}ms"
                )
            }
            reranked
        } else {
            annCandidatesForLog?.let { candidates ->
                android.util.Log.i(
                    "MarkVaultPerf",
                    "ANN search engine=${if (useHnsw) "HNSW" else "IVF"} model=${searchDescriptor.id} " +
                        "embed=${queryEmbedMs}ms media=${mediaSearchMs}ms " +
                        "probe=${annProbeMs}ms scope=${annScopeFilterMs}ms " +
                        "vectors=${annVectorScoreMs}ms rerank=off candidates=${candidates.size} " +
                        "total=${android.os.SystemClock.elapsedRealtime() - perfSearchStarted}ms"
                )
            }
            cosineRanking
        }

        return baseOutcome.copy(ranking = finalRanking)
    }

    init {
        // v5.4.0 — Make ourselves reachable from the Application's
        // memory-pressure callbacks. The Application holds a weak-ish
        // reference (volatile var) and only uses it to invoke
        // freeMemory() when the OS signals memory tightness.
        runCatching { (app as? MarkVaultApp)?.sharedVm = this }
        // v5.4.105cc — Load the last-session snapshot and expose it via
        // [pendingRestoredRoute] / [pendingRestoredWebTabs]. The nav
        // graph consults these on first composition (see MainActivity).
        //
        // v5.4.107cc — MUST run on Dispatchers.IO, not the default
        // Main.immediate, and MUST be wrapped in runCatching. Reason:
        // the referenced `_pendingRestored*` state flows are declared
        // LATER in the class body (session-state block near line
        // 3200+); property initializers run in source order, so at the
        // moment this init block executes, those fields are still null.
        // With Main.immediate, launch{} can start executing
        // synchronously on the constructing thread — a fast-returning
        // Flow.first() would then hit the null field before the
        // constructor finishes and crash the app on launch. IO
        // dispatch guarantees the block runs on a background thread
        // AFTER construction completes; the runCatching is a
        // belt-and-braces against any DataStore hiccup that could
        // leave the app stranded on the splash screen.
        viewModelScope.launch(Dispatchers.IO) {
            runCatching {
                val route = prefs.lastRoute.first()
                val urlsBlob = prefs.webTabsUrls.first()
                val titlesBlob = prefs.webTabsTitles.first()
                val activeIdx = prefs.webActiveTabIdx.first()
                val urls = if (urlsBlob.isBlank()) emptyList()
                    else urlsBlob.split('\u0000').filter { it.isNotBlank() }
                val titles = if (titlesBlob.isBlank()) emptyList()
                    else titlesBlob.split('\u0000')
                val webTabsSnap = urls.mapIndexed { i, u ->
                    RestoredWebTab(u, titles.getOrNull(i).orEmpty())
                }
                // v5.4.106cc — Reader (article) tabs snapshot. Same
                // rationale as above; reads happen off-Main.
                val readerIdsBlob = prefs.readerTabIds.first()
                val readerTitlesBlob = prefs.readerTabTitles.first()
                val readerTypesBlob = prefs.readerTabTypes.first()
                val activeReaderId = prefs.readerActiveId.first()
                val readerIds = if (readerIdsBlob.isBlank()) emptyList()
                    else readerIdsBlob.split('\u0000')
                        .mapNotNull { it.toLongOrNull() }
                val readerTitles = if (readerTitlesBlob.isBlank()) emptyList()
                    else readerTitlesBlob.split('\u0000')
                val readerTypes = if (readerTypesBlob.isBlank()) emptyList()
                    else readerTypesBlob.split('\u0000')
                val readerTabsSnap = readerIds.mapIndexed { i, id ->
                    RestoredReaderTab(
                        id = id,
                        title = readerTitles.getOrNull(i).orEmpty(),
                        fileType = readerTypes.getOrNull(i) ?: "md"
                    )
                }
                // v5.4.108cc — In-flight batch save resume snapshot.
                // If a previous session died mid-batch (RAM-kill of
                // the foreground service), the payload will list every
                // item that hadn't landed on disk yet. Parse it here;
                // MainActivity/the WebViewer offers/re-fires the
                // resume batch.
                val batchBlob = prefs.batchSaveQueue.first()
                val resumeItems = if (batchBlob.isBlank()) emptyList()
                else batchBlob.split('\u0000').mapNotNull { entry ->
                    if (entry.isBlank()) return@mapNotNull null
                    val parts = entry.split('\u0001')
                    if (parts.size < 2) return@mapNotNull null
                    val u = parts[0]
                    if (u.isBlank()) return@mapNotNull null
                    WebSelectionItem(
                        url = u,
                        title = parts[1],
                        expanded = parts.getOrNull(2) == "1"
                    )
                }
                // v5.4.115cc — In-flight head-expansion resume snapshot.
                // Same shape as the batch queue: each entry is
                // `url\u0001text`. Heads that hadn't finished expanding
                // when the process died are re-queued rather than lost.
                val expansionBlob = prefs.headExpansionQueue.first()
                val resumeExpansion = if (expansionBlob.isBlank()) emptyList()
                else expansionBlob.split('\u0000').mapNotNull { entry ->
                    if (entry.isBlank()) return@mapNotNull null
                    val parts = entry.split('\u0001')
                    if (parts.size < 2) return@mapNotNull null
                    val u = parts[0]
                    if (u.isBlank()) return@mapNotNull null
                    HeadExpansionRequest(url = u, text = parts[1])
                }
                // v5.4.109cc — Load dedup toggle values.
                val urlDedup = prefs.dedupByUrl.first()
                val titleDedup = prefs.dedupByTitle.first()
                // Assignments happen last, once all reads are done, so
                // if one branch throws the flows stay at their initial
                // empty state instead of being left half-populated.
                _pendingRestoredRoute.value = route
                _pendingRestoredWebTabs.value = webTabsSnap
                _pendingRestoredWebActiveIdx.value = activeIdx
                _pendingRestoredReaderTabs.value = readerTabsSnap
                _pendingRestoredReaderActiveId.value = activeReaderId
                _pendingResumeBatch.value = resumeItems
                _pendingResumeExpansion.value = resumeExpansion
                _dedupByUrl.value = urlDedup
                _dedupByTitle.value = titleDedup
            }
        }
        // v5.4.6 — Apply persisted reranker model id at startup so the
        // user's L-12-vs-L-6 choice survives process restart.
        viewModelScope.launch {
            val id = prefs.rerankerModelId.first()
            val desc = com.tebogo.markvault.search.RerankerCatalog.byId(id)
            if (desc != null && desc.id != reranker.currentDescriptor().id) {
                reranker.setDescriptor(desc)
                _rerankerInstalled.value = reranker.isInstalled()
            }
        }
        viewModelScope.launch(Dispatchers.IO) {
            // v5.4.37 — Prune orphaned embedding rows on startup.
            // INSERT OR REPLACE in the indexer changes note ids,
            // leaving old embeddings keyed to dead noteIds. Without
            // this, the count doubles after every full re-index.
            runCatching { dao.pruneOrphanEmbeddings() }
            _embeddingCount.value = runCatching {
                dao.embeddingCount(embedder.modelVersion)
            }.getOrElse { 0 }
        }
        // v4.21.0 — re-check chat-model installation whenever the
        // download service finishes (success or cancel).
        observeChatDownloadCompletion()
        // v5.4.257cc — re-check chat-model installation whenever the
        // ACTIVE model id itself changes/loads — see that function's
        // doc comment for the async-DataStore-read race this closes,
        // which observeChatDownloadCompletion() alone did not cover.
        observeActiveChatModelChanges()
        // v5.4.257cc — sweep any orphaned chat-model files left over
        // from catalog entries removed in earlier versions.
        cleanupOrphanedChatModelFiles()
        // v4.22.0 — if user picked "preload" mode, load the LLM in the
        // background after app start. No-op for default "on_open" mode.
        maybePreloadChatModel()
        // v4.9.0 — listen for active-model preference changes (including the
        // initial value at startup) and swap the embedder when the preferred
        // model differs from the one currently loaded. Each swap closes the
        // old embedder, refreshes the model-availability + embedding-count
        // state flows, and invalidates the semantic index so the next search
        // reloads under the new model's vectors.
        viewModelScope.launch {
            prefs.activeModelId.collect { id ->
                cancelMediaSemanticIndexing()
                val descriptor = com.tebogo.markvault.search.ModelCatalog.byId(id)
                    ?: com.tebogo.markvault.search.ModelCatalog.default
                if (descriptor.id != embedder.descriptor.id) {
                    val old = embedder
                    embedder = com.tebogo.markvault.search.Embedder(
                        getApplication(), descriptor
                    )
                    runCatching { old.close() }
                    // v5.5.9 — MiniLM may intentionally keep the reranker warm
                    // between searches. When switching into BGE-base/large, drop
                    // that warm reranker first so the heavy embedder never has to
                    // cold-load alongside a leftover cross-encoder session.
                    if (descriptor.approxSizeMb > 32 && reranker.isLoaded) {
                        runCatching { reranker.unload() }
                    }
                    _modelAvailable.value = embedder.isModelAvailable()
                    _embeddingCount.value = runCatching {
                        dao.embeddingCount(embedder.modelVersion)
                    }.getOrElse { 0 }
                    invalidateSemanticIndex()
                    // v5.5.8 — ANN centroids/memberships are model-specific.
                    // Drop the previous model's RAM cache immediately; the
                    // selected model will lazily load its own file on search.
                    annIndex.unload()
                    hnswIndex.unload()
                    _hnswRevision.value += 1

                }

                // v5.5.12 — Check ANN self-heal for the resolved active
                // model even when no embedder swap was necessary (for example
                // the default USE model on cold start). Start the foreground
                // embedding service only when the persisted index is actually
                // stale, so a healthy app does not flash a pointless service
                // notification on every launch.
                if (_modelAvailable.value && annIndex.isAvailable(embedder.modelVersion)) {
                    val mv = embedder.modelVersion
                    val stats = annIndex.stats(mv)
                    val currentCount = runCatching { dao.embeddingCount(mv) }.getOrElse { -1 }
                    val latestEmbeddingAt = runCatching {
                        dao.latestEmbeddingCreatedAt(mv)
                    }.getOrElse { Long.MAX_VALUE }
                    val needsSelfHeal = stats == null ||
                        currentCount < 0 ||
                        stats.embeddingCountAtBuild != currentCount ||
                        stats.numVectors != currentCount ||
                        stats.buildTimestamp < latestEmbeddingAt
                    if (needsSelfHeal) buildAllEmbeddings()
                }

                _activeModelId.value = descriptor.id
                if (_modelAvailable.value && hnswIndex.isAvailable(embedder.modelVersion)) {
                    val mv = embedder.modelVersion
                    val stats = hnswIndex.stats(mv)
                    if (stats == null || stats.embeddingCountAtBuild != dao.embeddingCount(mv) ||
                        stats.embeddingWatermark < dao.latestEmbeddingCreatedAt(mv)) buildAllEmbeddings()
                }
            }
        }

        // v4.15.0 — When the foreground embedding service finishes (whether
        // by completing the pass, being cancelled by the user, or being
        // killed by the OS), refresh our local cached count and drop the
        // semantic index so the next search reloads vectors from the DB.
        // The collect fires on every isRunning transition including the
        // initial `false` at app launch — that's harmless because the count
        // refresh is idempotent.
        viewModelScope.launch {
            com.tebogo.markvault.search.EmbeddingProgressBus.isRunning.collect { running ->
                if (!running) {
                    _embeddingCount.value = runCatching {
                        dao.embeddingCount(embedder.modelVersion)
                    }.getOrElse { _embeddingCount.value }
                    invalidateSemanticIndex()

                    // v5.5.8 — EmbeddingService now synchronizes every
                    // model-specific ANN index itself (active + other installed
                    // models that already have ANN files). Its AnnIndex instance
                    // writes the files on disk, so discard this VM's cached
                    // centroids/memberships; the next search loads the freshly
                    // synchronized index for whichever model is active.
                    annIndex.unload()
                    hnswIndex.unload()
                    _hnswRevision.value += 1
                }
            }
        }
        // Resume interrupted automatic HNSW builds for any installed model.
        // Healthy snapshots avoid starting a foreground service on every launch.
        viewModelScope.launch(Dispatchers.IO) {
            if (prefs.hnswAutoBuild.first() && hnswIndex.nativeAvailable()) {
                val excluded = prefs.hnswExcludedModels.first()
                for (descriptor in com.tebogo.markvault.search.ModelCatalog.all.filter { it.enabled }) {
                    val probe = com.tebogo.markvault.search.Embedder(app, descriptor)
                    val mv = probe.modelVersion
                    val installed = runCatching { probe.isModelAvailable() }.getOrDefault(false)
                    runCatching { probe.close() }
                    if (!installed || mv in excluded) continue
                    val count = dao.embeddingCount(mv)
                    val stats = hnswIndex.stats(mv)
                    if (dao.countNotesNeedingEmbedding(mv) > 0 || (count >= 500 &&
                        (stats == null || stats.embeddingCountAtBuild != count ||
                            stats.embeddingWatermark < dao.latestEmbeddingCreatedAt(mv)))) {
                        buildAllEmbeddings()
                        break
                    }
                }
            }
        }
        // v5.4.270cc — Existing cached media is indexed only in small batches
        // while MarkVault is visible and the device is charging. The scheduler
        // returns immediately on battery/background use, preventing startup
        // media maintenance from becoming a foreground/background battery drain.
        scheduleMediaSemanticIndexing(10_000L)
    }

    val libraryUri: StateFlow<String?> =
        prefs.libraryUri.stateIn(viewModelScope, SharingStarted.Eagerly, null)
    val fontScale: StateFlow<Float> =
        prefs.fontScale.stateIn(viewModelScope, SharingStarted.Eagerly, 1.0f)
    val theme: StateFlow<String> =
        prefs.theme.stateIn(viewModelScope, SharingStarted.Eagerly, "dark")
    val appAppearanceMode: StateFlow<String> =
        prefs.appAppearanceMode.stateIn(viewModelScope, SharingStarted.Eagerly, "system")
    val customThemeJson: StateFlow<String> =
        prefs.customThemeJson.stateIn(viewModelScope, SharingStarted.Eagerly, "")
    val obsidianThemeId: StateFlow<String> =
        prefs.obsidianThemeId.stateIn(viewModelScope, SharingStarted.Eagerly, "")
    val obsidianThemeOverridesRaw: StateFlow<String> =
        prefs.obsidianThemeOverridesRaw.stateIn(viewModelScope, SharingStarted.Eagerly, "{}")
    private val _installedObsidianThemes = MutableStateFlow(obsidianThemeManager.listInstalled())
    val installedObsidianThemes: StateFlow<List<com.tebogo.markvault.data.ObsidianThemeInfo>> = _installedObsidianThemes
    private val _activeObsidianTheme = MutableStateFlow<com.tebogo.markvault.data.ObsidianThemePayload?>(null)
    val activeObsidianTheme: StateFlow<com.tebogo.markvault.data.ObsidianThemePayload?> = _activeObsidianTheme
    private val _activeObsidianOverrides = MutableStateFlow<Map<String, String>>(emptyMap())
    val activeObsidianOverrides: StateFlow<Map<String, String>> = _activeObsidianOverrides.asStateFlow()
    private val _activeObsidianAppearanceMode = MutableStateFlow("system")
    val activeObsidianAppearanceMode: StateFlow<String> = _activeObsidianAppearanceMode.asStateFlow()
    private val _obsidianPreviewPayload = MutableStateFlow<com.tebogo.markvault.data.ObsidianThemePayload?>(null)
    val obsidianPreviewPayload: StateFlow<com.tebogo.markvault.data.ObsidianThemePayload?> = _obsidianPreviewPayload.asStateFlow()
    private val _obsidianThemeStatus = MutableStateFlow<String?>(null)
    val obsidianThemeStatus: StateFlow<String?> = _obsidianThemeStatus
    private val _obsidianCompatibilityReport = MutableStateFlow<com.tebogo.markvault.data.ObsidianCompatibilityReport?>(null)
    val obsidianCompatibilityReport: StateFlow<com.tebogo.markvault.data.ObsidianCompatibilityReport?> = _obsidianCompatibilityReport.asStateFlow()
    private var obsidianPreviewJob: Job? = null
    private val _obsidianCommunityThemes = MutableStateFlow<List<com.tebogo.markvault.data.ObsidianCommunityTheme>>(emptyList())
    val obsidianCommunityThemes: StateFlow<List<com.tebogo.markvault.data.ObsidianCommunityTheme>> = _obsidianCommunityThemes
    private val _obsidianCommunityLoading = MutableStateFlow(false)
    val obsidianCommunityLoading: StateFlow<Boolean> = _obsidianCommunityLoading
    private val _obsidianCommunityInstallingRepo = MutableStateFlow<String?>(null)
    val obsidianCommunityInstallingRepo: StateFlow<String?> = _obsidianCommunityInstallingRepo.asStateFlow()

    init {
        viewModelScope.launch {
            combine(obsidianThemeId, obsidianThemeOverridesRaw) { id, raw -> id to raw }
                .collect { (id, raw) ->
                    val persisted = parseObsidianOverridesForTheme(raw, id)
                    _activeObsidianOverrides.value = persisted
                    _activeObsidianAppearanceMode.value = parseObsidianAppearanceForTheme(raw, id)
                    _activeObsidianTheme.value = withContext(Dispatchers.IO) {
                        obsidianThemeManager.applyOverrides(
                            obsidianThemeManager.load(id.takeIf { it.isNotBlank() }),
                            persisted
                        )
                    }
                }
        }
    }
    // Performance/feature toggles — let the user opt in to heavier features.
    val smartStylingAllDocs: StateFlow<Boolean> =
        prefs.smartStylingAllDocs.stateIn(viewModelScope, SharingStarted.Eagerly, false)
    val swipeSwitchTabs: StateFlow<Boolean> =
        prefs.swipeSwitchTabs.stateIn(viewModelScope, SharingStarted.Eagerly, false)
    val textContrast: StateFlow<Float> =
        prefs.textContrast.stateIn(viewModelScope, SharingStarted.Eagerly, 1.0f)

    // v5.4.145cc — New UI toggle StateFlows
    val hideWebSearchButtons: StateFlow<Boolean> =
        prefs.hideWebSearchButtons.stateIn(viewModelScope, SharingStarted.Eagerly, false)
    val hideSearchChips: StateFlow<Boolean> =
        prefs.hideSearchChips.stateIn(viewModelScope, SharingStarted.Eagerly, false)
    val hideEmbeddingSelector: StateFlow<Boolean> =
        prefs.hideEmbeddingSelector.stateIn(viewModelScope, SharingStarted.Eagerly, false)
    val hideSearchBarOnScroll: StateFlow<Boolean> =
        prefs.hideSearchBarOnScroll.stateIn(viewModelScope, SharingStarted.Eagerly, false)
    val enableFullscreenMode: StateFlow<Boolean> =
        prefs.enableFullscreenMode.stateIn(viewModelScope, SharingStarted.Eagerly, false)
    val enableWebAutosave: StateFlow<Boolean> =
        prefs.enableWebAutosave.stateIn(viewModelScope, SharingStarted.Eagerly, false)
    val showJwSearchButton: StateFlow<Boolean> =
        prefs.showJwSearchButton.stateIn(viewModelScope, SharingStarted.Eagerly, true)

    // v5.4.182cc — Scripture detection: tappable amber links in article WebViews
    // that open the matching offline NWT chapter at the exact verse anchor.
    val scriptureDetectionEnabled: StateFlow<Boolean> =
        prefs.scriptureDetectionEnabled.stateIn(viewModelScope, SharingStarted.Eagerly, true)
    fun setScriptureDetectionEnabled(v: Boolean) {
        viewModelScope.launch { prefs.setScriptureDetectionEnabled(v) }
    }

    /**
     * v5.4.182cc — Holds the WOL verse anchor id (e.g. "v40-23-8-1") to scroll-to
     * after navigating to an offline NWT chapter file via a scripture link tap.
     * Consumed ONCE by HtmlReaderScreen's onPageFinished so it doesn't re-fire on
     * subsequent same-page navigations.
     */
    private val _pendingScriptureAnchor = MutableStateFlow<String?>(null)
    val pendingScriptureAnchor: StateFlow<String?> = _pendingScriptureAnchor.asStateFlow()
    fun setPendingScriptureAnchor(anchor: String?) { _pendingScriptureAnchor.value = anchor }
    fun consumePendingScriptureAnchor(): String? {
        val v = _pendingScriptureAnchor.value
        _pendingScriptureAnchor.value = null
        return v
    }

    /**
     * v5.4.182cc — Search the indexed note list for an offline NWT HTML file that
     * matches the given book number and chapter.  The expected filename prefix is:
     *   `{BookName}_{chapter}___Watchtower_ONLINE_LIBRARY`
     * e.g. for Matthew 23 → "Matthew_23___Watchtower_ONLINE_LIBRARY"
     *
     * Returns the note ID if found, null otherwise.  The caller sets the pending
     * verse anchor via [setPendingScriptureAnchor] before navigating so the reader
     * can scroll to the exact verse once the page loads.
     */
    suspend fun findNwtNoteId(bookNum: Int, chapter: Int): Long? =
        kotlinx.coroutines.withContext(kotlinx.coroutines.Dispatchers.IO) {
            val bookName = com.tebogo.markvault.util.ScriptureDetector
                .BOOK_NAME_FOR_NUMBER[bookNum] ?: return@withContext null
            val prefix = com.tebogo.markvault.util.ScriptureDetector
                .buildNwtFileName(bookName, chapter).lowercase()
            notes.value.firstOrNull { note ->
                (note.fileType == "html" || note.fileType == "htm") &&
                    note.name.lowercase().startsWith(prefix)
            }?.id
        }

    private val _progress = MutableStateFlow(IndexProgress())
    val progress: StateFlow<IndexProgress> = _progress

    private val _notes = MutableStateFlow<List<NoteMeta>>(emptyList())
    val notes: StateFlow<List<NoteMeta>> = _notes

    // v5.4.358cc — True only after the initial Room metadata read completes
    // successfully. The launch welcome uses this as its real readiness gate,
    // so the app chrome/index text can never bleed through before the library
    // state is available. A genuinely empty library still counts as loaded.
    private val _libraryReady = MutableStateFlow(false)
    val libraryReady: StateFlow<Boolean> = _libraryReady

    private val _recent = MutableStateFlow<List<RecentNote>>(emptyList())
    val recent: StateFlow<List<RecentNote>> = _recent

    private val _topics = MutableStateFlow<List<TopicCard>>(emptyList())
    val topics: StateFlow<List<TopicCard>> = _topics

    /** Notes added to the library since the last manual re-index (empty until first reindex). */
    private val _newNotes = MutableStateFlow<List<NoteMeta>>(emptyList())
    val newNotes: StateFlow<List<NoteMeta>> = _newNotes

    /** IDs of notes the user has starred as favourites. */
    private val _favouriteIds = MutableStateFlow<Set<Long>>(emptySet())
    val favouriteIds: StateFlow<Set<Long>> = _favouriteIds

    /** Starred notes as NoteMeta list for the home screen. */
    private val _favouriteNotes = MutableStateFlow<List<NoteMeta>>(emptyList())
    val favouriteNotes: StateFlow<List<NoteMeta>> = _favouriteNotes

    /** Notes recommended to the user — based on topic overlap with what they've been reading. */
    private val _suggested = MutableStateFlow<List<NoteMeta>>(emptyList())
    val suggested: StateFlow<List<NoteMeta>> = _suggested

    // ---- Recent search clicks (persisted, capped at 20) ----
    private val _recentSearches = MutableStateFlow<List<RecentSearch>>(emptyList())
    val recentSearches: StateFlow<List<RecentSearch>> = _recentSearches
    private val maxRecentSearches = 20

    /** Called when the user taps a search result. Stores the query + the note it led to. */
    fun recordSearchClick(query: String, noteId: Long, title: String, relPath: String) {
        val q = query.trim()
        if (q.isEmpty()) return
        val now = System.currentTimeMillis()
        // Preserve the elapsed time recorded when this query completed. A later
        // click upgrades the query-only history row into an article row; it must
        // not throw away the search-duration evidence in the process.
        val durationMs = _recentSearches.value
            .firstOrNull { it.query.equals(q, ignoreCase = true) }
            ?.durationMs ?: 0L
        val entry = RecentSearch(
            query = q, noteId = noteId, title = title, relPath = relPath, ts = now,
            durationMs = durationMs
        )
        // Dedup: drop any existing entry for the same (query, noteId), then prepend the fresh one
        val cur = _recentSearches.value
        val deduped = cur.filterNot { it.noteId == noteId && it.query.equals(q, ignoreCase = true) }
        val updated = (listOf(entry) + deduped).take(maxRecentSearches)
        _recentSearches.value = updated
        viewModelScope.launch(Dispatchers.IO) { runCatching { prefs.setRecentSearchesRaw(encodeRecents(updated)) } }
    }

    /**
     * v5.4.126cc — Records every submitted search query so it appears in
     * HomeScreen's recent-query chips regardless of whether the user clicked
     * any result.
     *
     * Uses noteId = -1L as a sentinel ("query-only, no linked article").
     * HomeScreen's recentQueries reads only .query so these entries surface
     * there normally. SearchScreen's article-card recents list filters out
     * noteId < 0 entries to avoid navigating to a non-existent note.
     *
     * Deduplicates by query text (case-insensitive) so searching the same
     * phrase twice just refreshes its timestamp rather than adding duplicates.
     */
    fun recordSubmittedQuery(query: String, durationMs: Long = 0L) {
        val q = query.trim()
        if (q.isEmpty()) return
        val now = System.currentTimeMillis()
        val entry = RecentSearch(
            query = q, noteId = -1L, title = "", relPath = "", ts = now,
            durationMs = durationMs.coerceAtLeast(0L)
        )
        val cur = _recentSearches.value
        // Drop any prior entry (query-only OR clicked-result) for this query text,
        // then prepend the fresh query-only record. A later recordSearchClick for
        // the same query will upgrade it to a full entry with a real noteId.
        val deduped = cur.filterNot { it.query.equals(q, ignoreCase = true) }
        val updated = (listOf(entry) + deduped).take(maxRecentSearches)
        _recentSearches.value = updated
        viewModelScope.launch(Dispatchers.IO) { runCatching { prefs.setRecentSearchesRaw(encodeRecents(updated)) } }
    }

    fun clearRecentSearches() {
        _recentSearches.value = emptyList()
        viewModelScope.launch(Dispatchers.IO) { runCatching { prefs.setRecentSearchesRaw("") } }
    }

    // ---- Open article tabs ----
    private val _tabs = MutableStateFlow<List<TabInfo>>(emptyList())
    val tabs: StateFlow<List<TabInfo>> = _tabs
    private val _activeTab = MutableStateFlow<Long?>(null)
    val activeTab: StateFlow<Long?> = _activeTab
    private val maxTabs = 8
    private val _recentlyClosedTabs = MutableStateFlow<List<TabInfo>>(emptyList())
    val recentlyClosedTabs: StateFlow<List<TabInfo>> = _recentlyClosedTabs
    private val maxRecentlyClosedTabs = 12

    private fun rememberClosedTab(tab: TabInfo) {
        _recentlyClosedTabs.value =
            (listOf(tab) + _recentlyClosedTabs.value.filterNot { it.id == tab.id })
                .take(maxRecentlyClosedTabs)
    }

    /**
     * In-Reader navigation history (tab IDs visited, oldest → newest).
     * Lets the system Back button return through previously-viewed tabs (e.g. after tapping a
     * backlink) instead of immediately exiting the Reader.
     */
    private val _tabHistory = MutableStateFlow<List<Long>>(emptyList())
    val tabHistory: StateFlow<List<Long>> = _tabHistory
    private val maxHistory = 50

    private fun pushHistory(id: Long) {
        val cur = _tabHistory.value
        if (cur.lastOrNull() == id) return // dedupe consecutive
        val updated = (cur + id)
        _tabHistory.value = if (updated.size > maxHistory) updated.takeLast(maxHistory) else updated
    }

    /**
     * Pop the current tab off history and activate the previous one.
     * Returns true if we moved back inside the Reader; false if there's nowhere to go back to
     * (caller should let the system Back press exit the Reader).
     */
    fun goBackInTabs(): Boolean {
        val cur = _tabHistory.value
        if (cur.size < 2) return false
        val updated = cur.dropLast(1)
        _tabHistory.value = updated
        _activeTab.value = updated.last()
        return true
    }

    /**
     * Switch to the next / previous tab in the open tabs list (not history).
     * Used by swipe-left / swipe-right gestures inside the Reader.
     * Returns true if it switched, false if there's only one tab.
     */
    fun switchTabByDirection(forward: Boolean): Boolean {
        val list = _tabs.value
        if (list.size < 2) return false
        val curId = _activeTab.value ?: list.first().id
        val idx = list.indexOfFirst { it.id == curId }
        if (idx < 0) return false
        val next = if (forward) (idx + 1) % list.size else (idx - 1 + list.size) % list.size
        val newId = list[next].id
        _activeTab.value = newId
        pushHistory(newId)
        return true
    }

    /** Clear the tab visit history. Called when the Reader exits to home / search etc. */
    fun clearTabHistory() { _tabHistory.value = emptyList() }

    val query = MutableStateFlow("")
    val mode = MutableStateFlow(SearchMode.CONTENT)
    /**
     * When ON, wraps the user's query in quotes before searching so FTS treats it
     * as an exact phrase. Only meaningful for SearchMode.CONTENT (the UI hides the
     * toggle in TITLES mode where it has no effect).
     */
    val quotePhrase = MutableStateFlow(false)

    /**
     * v5.4.146cc — Last result set produced by a completed (non-cancelled)
     * search. The cancel handler returns this so the UI stays populated
     * when the user types mid-search and the in-flight job is stopped.
     * Only updated when a search returns a non-empty list.
     */
    @Volatile private var _lastKnownResults: List<SearchHit> = emptyList()

    /**
     * Active immediate post-search cleanup. A single job is kept so a new
     * search can cancel a cleanup that has not yet released resources, while
     * cleanup itself is idempotent and safe to run again after the next result.
     */
    private var _idleCleanupJob: kotlinx.coroutines.Job? = null

    /**
     * v5.4.264cc — SINGLE, unified post-search cleanup. Fires after EVERY
     * completed search path — dual, single-scope, live-typing or explicit
     * submit. The 1.5-second grace period is intentional: it gives the UI
     * time to receive and render the result list, but once that period expires
     * the cleanup starts immediately and is not allowed to be cancelled while
     * the actual release sequence is running.
     *
     * v5.5.9 — Cleanup is now model-aware. Heavy BGE models retain the old
     * exhaustive teardown, while MiniLM/USE may keep their small embedder +
     * reranker sessions warm when heap headroom is safe. The compact ANN
     * directory is retained only on that lightweight warm path. Emergency 95%
     * cleanup, explicit Free Memory, Home reset and hard reset still release
     * everything. This preserves the crash/OOM safeguards without forcing the
     * lightweight model through a cold ONNX load on every normal query.
     */
    private fun schedulePostSearchCleanup() {
        _idleCleanupJob?.cancel()
        _idleCleanupJob = viewModelScope.launch(
            Dispatchers.IO,
            start = CoroutineStart.DEFAULT
        ) {
            // v5.4.264cc — Restore the previous 1.5-second grace period.
            // This is the ONLY intentional delay in post-search cleanup.
            // Once it expires, the release block below is NonCancellable.
            kotlinx.coroutines.delay(POST_SEARCH_CLEANUP_DELAY_MS)
            kotlinx.coroutines.withContext(kotlinx.coroutines.NonCancellable) {
                cancelMediaSemanticIndexing()
                // v5.5.9 — Normal completed searches may retain the tiny ANN
                // directory and lightweight MiniLM/USE + reranker sessions.
                // Emergency 95% cleanup still calls the exhaustive default path.
                forceReleaseSearchMemory(preserveFastSearchWarmState = true)
            }
        }
    }


    /**
     * v5.4.403cc — BackgroundWorkService keeps its foreground priority and
     * partial wake lock until the submitted search's aggressive native/GC
     * cleanup is complete. This prevents the completion notification from
     * becoming tappable while the app is still tearing down search resources.
     */
    suspend fun awaitSearchPostCleanup() {
        val cleanup = _idleCleanupJob ?: return
        runCatching { cleanup.join() }
    }

    /**
     * v5.4.264cc/v5.5.9 — Shared search-memory release. With
     * [preserveFastSearchWarmState] false (the emergency/default path) this
     * remains exhaustive. Ordinary post-search cleanup passes true so only the
     * lightweight search stack may stay warm; it automatically falls back to
     * exhaustive teardown if the heap does not settle below the 85% resume line.
     */
    private suspend fun forceReleaseSearchMemory(
        preserveFastSearchWarmState: Boolean = false
    ): Long {
        val beforePss = usedTotalMB()
        val beforeHeap = usedHeapMB()
        val keepLightweightWarm = preserveFastSearchWarmState &&
            canKeepLightweightSearchStackWarm()

        // Drop the large legacy semantic scope arrays first. ANN keeps only
        // centroids + cluster membership and is cheap enough to stay resident
        // after an ordinary search, but emergency cleanup still drops it.
        invalidateSemanticIndex()
        webTabThumbnails.clear()

        // v5.5.9 — A single cleanup policy was making MiniLM behave like a
        // heavyweight BGE model: every search unloaded MiniLM and the reranker,
        // guaranteeing expensive session recreation on the next query. Preserve
        // the small stack only after a normal completed search. BGE-base/large,
        // emergency cleanup, explicit Free Memory, and hard reset remain exhaustive.
        if (!keepLightweightWarm) {
            runCatching { reranker.unload() }
            runCatching { embedder.close() }
        }
        if (!keepLightweightWarm) {
            // Heavy BGE models and every exhaustive/emergency path retain the
            // pre-5.5.9 behaviour: release ANN RAM too. Only the deliberately
            // warm MiniLM/USE normal-search path keeps its small ANN directory.
            runCatching { annIndex.unload() }
        }
        // Keep the read-only mmap warm across ordinary searches for every model.
        if (!preserveFastSearchWarmState) runCatching { hnswIndex.unload() }
        runCatching { t5Engine?.close() }
        t5Engine = null
        t5EngineLoadAttempted = false
        runCatching { com.tebogo.markvault.llm.LlmManager.unload() }

        var afterHeapBytes: Long
        if (keepLightweightWarm) {
            // v5.5.9 — Do NOT defeat the lightweight warm-search path by
            // immediately evicting SQLite's page cache and forcing two GCs.
            // Those operations are useful for BGE/emergency teardown, but on
            // MiniLM/USE they make the next ANN search cold even though the
            // embedder and reranker sessions were intentionally preserved.
            // Read the heap first; the safety fallback below still performs
            // the full release if we are at/above the 85% resume line.
            afterHeapBytes = usedHeapBytes()
        } else {
            clearImageCache()
            releaseSqliteCache()
            settleAndDoubleGc()
            afterHeapBytes = settleHeapUntilSafe()
        }


        // Memory safety wins over warm reuse. If the normal lightweight path
        // still cannot get below the 85% resume line, immediately fall back to
        // the exact exhaustive teardown used by the 95% circuit breaker.
        if (keepLightweightWarm && afterHeapBytes >= memoryResumeThresholdBytes()) {
            runCatching { reranker.unload() }
            runCatching { embedder.close() }
            runCatching { annIndex.unload() }
            runCatching { hnswIndex.unload() }
            clearImageCache()
            releaseSqliteCache()
            settleAndDoubleGc()
            afterHeapBytes = settleHeapUntilSafe()
        }

        val afterHeap = afterHeapBytes / (1024 * 1024)
        val afterPss = usedTotalMB()
        val freed = (beforePss - afterPss).coerceAtLeast(0L)
        val maxHeap = Runtime.getRuntime().maxMemory() / (1024 * 1024)
        val safe = afterHeapBytes < memoryResumeThresholdBytes()

        android.util.Log.i(
            "MarkVault",
            "Search memory release: heap ${beforeHeap}MB -> ${afterHeap}MB / ${maxHeap}MB, " +
                "PSS ${beforePss}MB -> ${afterPss}MB, freedPss=${freed}MB, safe=$safe, " +
                "warmFastSearch=${keepLightweightWarm && safe}"
        )
        if (safe) showMemoryClearedToast(freed)
        else showMemoryStillHighToast(afterHeap, maxHeap)
        return afterHeapBytes
    }

    val results: StateFlow<List<SearchHit>> = run {
        // v5.4.5 — Each search emission carries a flag indicating whether
        // it came from live debounced typing or an explicit submit. The
        // mapper uses this flag (combined with rerankOnSubmitOnly) to
        // decide whether to apply the cross-encoder.
        data class SearchReq(
            val q: String,
            val m: SearchMode,
            val qp: Boolean,
            val isSubmit: Boolean,
            // v5.4.146cc — true when the request originated from
            // _cancelSignal (keystroke while search running, live OFF).
            // The mapper returns _lastKnownResults immediately without
            // touching _searchBusy or running any pipeline.
            val isCancel: Boolean = false,
            // v5.4.384cc — immutable scope snapshot captured when this request
            // is created. A running search never re-reads mutable chip state.
            val scope: String,
            val dualMode: Boolean,
            // v5.4.373cc — a persisted completed session. No search work is
            // performed; its exact saved order/scores are restored directly.
            val restoredSession: com.tebogo.markvault.search.SavedSearchSession? = null
        )

        // Live debounced stream — only flows when liveSearchEnabled.
        val liveStream: Flow<SearchReq> = liveSearchEnabled.flatMapLatest { live ->
            if (live) {
                // v5.4.127cc — Assign the combine result to an explicitly-typed
                // local val before chaining .filter. Kotlin 2.x K2 compiler
                // fails to infer the lambda parameter type when .filter{} is
                // chained directly on a combine{trailing-lambda} expression:
                //   "Unresolved reference 'filter'" / "Cannot infer type for
                //    this parameter. Specify it explicitly."
                // Breaking the chain into two statements with an explicit
                // Flow<SearchReq> annotation resolves the ambiguity.
                val rawLiveFlow: Flow<SearchReq> = combine(
                    query.debounce(220).map { it.trim() }.distinctUntilChanged(),
                    mode, quotePhrase
                ) { q, m, qp ->
                    SearchReq(
                        q, m, qp, isSubmit = false,
                        scope = currentScope, dualMode = _semanticDualModeFlow.value
                    )
                }
                // Suppress live re-emission of a query that was just explicitly
                // submitted. Without this guard, the 220ms debounce fires AFTER
                // the submit stream starts AI expansion, and mapLatest cancels
                // it mid-flight. Guard clears automatically when the user types
                // something different, so live-as-you-type resumes normally.
                rawLiveFlow.filter { req: SearchReq ->
                    req.q.lowercase() != _lastSubmittedQuery.lowercase()
                }
            } else {
                emptyFlow()
            }
        }

        // Explicit submit stream — always flows regardless of live setting.
        val submitStream: Flow<SearchReq> = _searchTrigger.map {
            SearchReq(
                query.value.trim(), mode.value, quotePhrase.value, isSubmit = true,
                scope = currentScope, dualMode = _semanticDualModeFlow.value
            )
        }

        // v5.4.146cc — Cancel stream. Emitted by cancelCurrentSearch()
        // when the user types while a submit-driven search is running
        // (live search OFF). mapLatest cancels the in-flight mapper
        // coroutine; the cancel branch returns _lastKnownResults.
        val cancelStream: Flow<SearchReq> = _cancelSignal.map {
            SearchReq(
                "", mode.value, false, isSubmit = false, isCancel = true,
                scope = currentScope, dualMode = _semanticDualModeFlow.value
            )
        }
        val savedRestoreStream: Flow<SearchReq> = _savedSearchRestore.map { session ->
            SearchReq(
                q = session.query,
                m = mode.value,
                qp = false,
                isSubmit = false,
                scope = session.scope,
                dualMode = session.dualMode,
                restoredSession = session
            )
        }

        val merged: Flow<SearchReq> = merge(liveStream, submitStream, cancelStream, savedRestoreStream)

        val mapper: suspend (SearchReq) -> List<SearchHit> = { req ->
            if (req.restoredSession != null) {
                _searchBusy.value = false
                _lastSearchDurationMs.value = req.restoredSession.durationMs
                _lastKnownResults = req.restoredSession.hits
                _resultScopeById.value = req.restoredSession.hitScopes
                _resultQueryProvenance.value = req.restoredSession.hitProvenance
                req.restoredSession.hits
            } else if (req.isCancel) {
                // v5.4.146cc — Cancel path: the in-flight search coroutine
                // was already cancelled by mapLatest before this handler runs.
                // Clear the busy indicator and return the last successful
                // result set so the list stays populated.
                _searchBusy.value = false
                _lastKnownResults
            } else {
                val searchStartedAtMs = android.os.SystemClock.elapsedRealtime()
                cancelMediaSemanticIndexing()
                // A new submitted search must never let a completion notification
                // accidentally point at the previous saved session if persistence
                // fails for this run. The successful save below assigns the fresh id.
                if (req.isSubmit) { _lastSavedSearchSessionId.value = null; _activeSavedSearchSessionId.value = null; _resultScopeById.value = emptyMap() }
                // New search starting — abort any pending idle model-release
                // so the already-loaded sessions are reused immediately.
                _idleCleanupJob?.cancel()
                _idleCleanupJob = null
                _searchBusy.value = true
                resetSearchWorkProgress()
                val totalNotesAtStart = runCatching { dao.countNotes() }.getOrElse { 0 }
                // v5.5.14 — Saved metadata records what the search ACTUALLY used,
                // not merely the state of unrelated toggles. Scope/ANN only affect
                // Deep semantic retrieval; keyword-only and Shallow searches query
                // the full notes table.
                val semanticUsedAtStart = req.m == SearchMode.CONTENT && semanticEnabled.value
                val effectiveDualAtStart = semanticUsedAtStart && req.dualMode
                val effectiveScopeAtStart = if (semanticUsedAtStart) req.scope else "all"
                val scopeNoteCountAtStart = when {
                    effectiveDualAtStart || effectiveScopeAtStart == "all" -> totalNotesAtStart
                    effectiveScopeAtStart == "first20k" -> minOf(SCOPE_SLICE, totalNotesAtStart)
                    effectiveScopeAtStart == "second20k" -> (totalNotesAtStart - SCOPE_SLICE).coerceAtLeast(0)
                    else -> totalNotesAtStart
                }
                val questionAnalysisAtStart = com.tebogo.markvault.search.QuestionAwareness.analyze(req.q.trim().removeSurrounding("\"").trim())
                val questionAwarenessEnabledAtStart = req.m == SearchMode.CONTENT && questionAwarenessEnabled.value
                val executionTrace = SearchExecutionTrace(
                    semanticEnabled = semanticUsedAtStart,
                    accurateSearchUsed = req.m == SearchMode.CONTENT && req.qp,
                    annEnabled = semanticUsedAtStart && annSearchEnabled.value && !hnswSearchEnabled.value,
                    hnswEnabled = semanticUsedAtStart && hnswSearchEnabled.value,
                    scope = effectiveScopeAtStart,
                    dualMode = effectiveDualAtStart,
                    scopeNoteCount = scopeNoteCountAtStart,
                    totalNoteCount = totalNotesAtStart,
                    questionAwarenessEnabled = questionAwarenessEnabledAtStart,
                    queryDetectedAsQuestion = questionAnalysisAtStart.isQuestion,
                    questionType = questionAnalysisAtStart.type?.label.orEmpty()
                )
                activeSearchTrace = executionTrace
                var completedSearchElapsedMs = 0L
                var hardCancelled = false
                val searchLease = com.tebogo.markvault.search.SearchWorkPriority.begin()
                val output: List<SearchHit> = try {
                    // v5.4.5 — Rerank gate. When rerankOnSubmitOnly is ON
                    // (default), only submit emissions get the cross-encoder.
                    // Live-typing emissions return cosine-ranked results
                    // immediately, which is fast and crash-proof. When OFF,
                    // rerank runs everywhere (old behaviour).
                    val rerankAllowed = req.isSubmit || !rerankOnSubmitOnly.value
                    // v5.4.14 — Strip surrounding quotes from the typed query
                    // before anything else. The exact-phrase toggle auto-wraps
                    // the visible query string in quotes (for UI clarity), but
                    // the search backend doesn't want them embedded — it adds
                    // its own quotes via the [exactPhrase] flag. If we let the
                    // quotes through, expand() tokenizes ['"abraham',
                    // 'covenant"'] and the per-variant wrap re-adds quotes,
                    // producing the invalid FTS '""abraham""' '""covenant""' 
                    // which silently returns no results. Strip once, here,
                    // everything downstream gets the clean form.
                    val rawCleaned = req.q.trim().removeSurrounding("\"").trim()
                    // v5.5.14 — CancellationException still propagates for HARD
                    // cancellation (query edits / obsolete work). User-facing Stop
                    // is now graceful and never cancels this coroutine, allowing the
                    // partial candidate set to continue through rerank + durable save.
                    val producedRaw = when {
                        rawCleaned.length < 2 -> emptyList()
                        req.m == SearchMode.TITLES -> try {
                            _llmMatchedHitIds.value = emptySet()
                            // Title search never expands. Replace any older
                            // plan for the same text so saved/history metadata
                            // cannot inherit a prior content-search LLM run.
                            recordOriginalOnlyQueryPlan(
                                originalRaw = rawCleaned,
                                semanticOn = false,
                                budget = effectiveExpansionBudget()
                            )
                            val titleHits = titleSearch(rawCleaned)
                            recordKeywordQueryProvenance(
                                queries = listOf(originalIssuedQuery(rawCleaned)),
                                perQueryHits = listOf(titleHits)
                            )
                            if (gracefulSearchStopRequested()) {
                                maybeRerank(titleHits, rawCleaned, allowRerank = true)
                            } else titleHits
                        } catch (ce: kotlinx.coroutines.CancellationException) {
                            throw ce
                        } catch (_: Throwable) { emptyList() }
                        else -> {
                            val effective = if (req.qp) "\"$rawCleaned\"" else rawCleaned
                            try {
                                expandedContentSearch(
                                    effective,
                                    originalRaw = rawCleaned,
                                    exactPhrase = req.qp,
                                    allowRerank = rerankAllowed,
                                    isSubmit = req.isSubmit,
                                    scopeAtStart = req.scope,
                                    dualAtStart = req.dualMode
                                )
                            } catch (ce: kotlinx.coroutines.CancellationException) {
                                throw ce
                            } catch (_: Throwable) { emptyList() }
                        }
                    }
                    // v5.4.384cc — Last-boundary scope invariant. Retrieval, blend and
                    // rerank are already scope-aware, but a single-scope Deep search is
                    // validated once more immediately before UI/persistence. This makes it
                    // impossible for a wrong-half SearchHit to be displayed under a selected
                    // 1st/2nd partition even if another retrieval path regresses later.
                    val produced = if (
                        req.m == SearchMode.CONTENT && semanticEnabled.value &&
                        !req.dualMode && req.scope != "all"
                    ) {
                        val allowedFinalIds = scopeMembershipIds(req.scope, false).orEmpty()
                        val filtered = producedRaw.filter { it.id in allowedFinalIds }
                        if (filtered.size != producedRaw.size) {
                            android.util.Log.w(
                                "MarkVault",
                                "Scope invariant removed ${producedRaw.size - filtered.size} " +
                                    "wrong-partition results for scope=${req.scope}"
                            )
                        }
                        filtered
                    } else producedRaw

                    // v5.5.23 — Freeze only the provenance belonging to final
                    // in-scope hits. The optional reranker has already changed
                    // order if enabled, but cannot change which retrieval query
                    // contributed or the keyword/semantic path that found it.
                    val hitProvenanceForSave = snapshotResultQueryProvenance(
                        executionTrace,
                        produced.mapTo(LinkedHashSet()) { it.id }
                    )
                    _resultQueryProvenance.value = hitProvenanceForSave

                    // v5.4.375cc — Resolve every result to the library half used by
                    // the semantic scope without changing the Room SearchHit projection.
                    val firstScopeIdsForBadges = runCatching {
                        dao.getSearchScopeNoteIdPage(SCOPE_SLICE, 0).toHashSet()
                    }.getOrElse { emptySet<Long>() }
                    val hitScopesForSave = produced.associate { hit ->
                        hit.id to if (hit.id in firstScopeIdsForBadges) "first20k" else "second20k"
                    }
                    _resultScopeById.value = hitScopesForSave

                    // v5.4.373cc — Persist the FINAL result order before the
                    // finally block schedules model/buffer cleanup. This is the
                    // critical ordering for background searches: once a search
                    // and reranker finish, the result set is durable on storage
                    // before aggressive memory release or process death can occur.
                    if ((req.isSubmit || executionTrace.gracefulStopRequested) && rawCleaned.isNotBlank()) {
                        val elapsedForSave = (android.os.SystemClock.elapsedRealtime() - searchStartedAtMs)
                            .coerceAtLeast(0L)
                        completedSearchElapsedMs = elapsedForSave
                        val saved = runCatching {
                            val expansionRecord = com.tebogo.markvault.ai.LlmExpansionHistory.get(rawCleaned)
                            val queryPlan = com.tebogo.markvault.ai.QueryPlanHistory.get(rawCleaned)
                            // v5.5.16 — Question Awareness has its own saved-search
                            // audit field. Do not also label its deterministic answer
                            // queries as generic/LLM expansion in the saved report.
                            val issuedExpansions = queryPlan?.generated
                                ?.filter {
                                    it.source != com.tebogo.markvault.ai.QuerySource.ORIGINAL &&
                                        it.source != com.tebogo.markvault.ai.QuerySource.QUESTION_AWARENESS
                                }
                                ?.map { it.text }
                                ?.distinct()
                                ?: emptyList()
                            // v5.5.14 — "LLM used" means at least one LLM-generated
                            // query actually entered the retrieval plan, not merely that the
                            // engine was attempted and failed/timed out.
                            val llmWasUsed = queryPlan?.generated?.any {
                                it.source == com.tebogo.markvault.ai.QuerySource.LLM
                            } == true
                            com.tebogo.markvault.search.SavedSearchStore.save(
                                context = getApplication(),
                                query = req.q,
                                durationMs = elapsedForSave,
                                scope = executionTrace.scope,
                                dualMode = executionTrace.dualMode,
                                rerankEnabled = (rerankAllowed || executionTrace.gracefulStopRequested) && rerankEnabled.value,
                                searchType = if (req.m == SearchMode.TITLES) "Shallow" else "Deep",
                                llmUsed = llmWasUsed,
                                llmEngine = if (llmWasUsed) expansionRecord?.modelName.orEmpty() else "",
                                expansions = issuedExpansions,
                                hitScopes = hitScopesForSave,
                                hitProvenance = hitProvenanceForSave,
                                stopped = executionTrace.gracefulStopRequested,
                                stoppedAtPercent = executionTrace.stoppedAtPercent,
                                stoppedAtDone = executionTrace.stoppedAtDone,
                                stoppedAtTotal = executionTrace.stoppedAtTotal,
                                semanticEnabled = executionTrace.semanticEnabled,
                                accurateSearchUsed = executionTrace.accurateSearchUsed,
                                annEnabled = executionTrace.annEnabled,
                                annUsed = executionTrace.annUsed,
                                hnswEnabled = executionTrace.hnswEnabled,
                                hnswUsed = executionTrace.hnswUsed,
                                timingSummary = executionTrace.timings.summary(elapsedForSave),
                                rerankApplied = executionTrace.rerankApplied,
                                rerankerEngine = if ((rerankAllowed || executionTrace.gracefulStopRequested) && rerankEnabled.value && _rerankerInstalled.value)
                                    rerankerDescriptor.value.shortName else "",
                                scopeNoteCount = executionTrace.scopeNoteCount,
                                totalNoteCount = executionTrace.totalNoteCount,
                                questionAwarenessEnabled = executionTrace.questionAwarenessEnabled,
                                queryDetectedAsQuestion = executionTrace.queryDetectedAsQuestion,
                                questionAwarenessUsed = executionTrace.questionAwarenessUsed,
                                questionType = executionTrace.questionType,
                                questionAwareQueries = executionTrace.questionAwareQueries,
                                hits = produced
                            )
                        }.getOrNull()
                        if (saved != null) {
                            _lastSavedSearchSessionId.value = saved.id
                            // v5.4.403cc — The just-saved session is already fully
                            // decoded in memory. Do not immediately reread/decode all
                            // saved result files from disk a second time at the most
                            // latency-sensitive end of a background search.
                            _savedSearchSessions.value = buildList {
                                add(saved)
                                addAll(_savedSearchSessions.value.filterNot { it.id == saved.id })
                            }.sortedByDescending { it.createdAt }
                                .take(maxSavedSearchSessions.value.coerceIn(1, 50))
                        }
                    }
                    if (completedSearchElapsedMs <= 0L) {
                        completedSearchElapsedMs = (android.os.SystemClock.elapsedRealtime() - searchStartedAtMs)
                            .coerceAtLeast(0L)
                    }
                    produced
                } catch (t: Throwable) {
                    if (t is kotlinx.coroutines.CancellationException) {
                        hardCancelled = true
                        throw t
                    }
                    android.util.Log.e(
                        "MarkVault",
                        "Search pipeline failed for query=\"${req.q}\" mode=${req.m} submit=${req.isSubmit}",
                        t
                    )
                    _resultQueryProvenance.value = emptyMap()
                    if (t is OutOfMemoryError) runCatching { System.gc() }
                    emptyList()
                } finally {
                    searchLease.close()
                    // v5.5.14 — A graceful stop preserves the exact percentage at
                    // which Stop was pressed. Do not overwrite it with a synthetic
                    // 100% just because fusion/reranking has now completed.
                    when {
                        hardCancelled -> _searchWorkStage.value = "Search cancelled"
                        executionTrace.gracefulStopRequested ->
                            _searchWorkStage.value = stoppedSearchStage(executionTrace, finalized = true)
                        _searchWorkTotal.value > 0 -> completeSearchWork()
                        else -> _searchWorkStage.value = "Finalizing results…"
                    }
                    val elapsedMs = completedSearchElapsedMs.takeIf { it > 0L }
                        ?: (android.os.SystemClock.elapsedRealtime() - searchStartedAtMs).coerceAtLeast(0L)
                    _lastSearchDurationMs.value = elapsedMs
                    // v5.4.403cc — Register the cleanup job BEFORE publishing
                    // searchBusy=false. BackgroundWorkService observes that edge
                    // and then joins this exact job, keeping foreground priority
                    // and the wake lock until teardown/GC has safely completed.
                    schedulePostSearchCleanup()
                    _searchBusy.value = false
                    if (activeSearchTrace === executionTrace) activeSearchTrace = null
                    if (!hardCancelled && req.isSubmit && req.q.isNotBlank()) {
                        // v5.4.126cc — Log every submitted query so it appears in
                        // HomeScreen's recent-query history even when the user
                        // doesn't tap any result.
                        recordSubmittedQuery(req.q, elapsedMs)
                    }
                }
                // Cache non-empty results for the cancel handler so the
                // list stays populated when the user types mid-search.
                if (output.isNotEmpty()) _lastKnownResults = output
                output
            }
        }

        // v5.4.146cc — SharingStarted.Eagerly replaces WhileSubscribed(5000).
        // WhileSubscribed restarts the upstream after 5 s with no subscribers,
        // which caused _searchTrigger (was MutableStateFlow) to replay its
        // last value and re-run the previous search when the user navigated
        // back from an article. Eagerly keeps the flow alive for the full
        // ViewModel lifetime — no restart, no replay, no accidental re-search.
        cancelInflightSearch.flatMapLatest { cancelEnabled ->
            if (cancelEnabled) {
                merged.mapLatest(mapper)
            } else {
                merged.map(mapper)
            }
        }.flowOn(Dispatchers.IO)
            .stateIn(viewModelScope, SharingStarted.Eagerly, emptyList())
    }

    /**
     * v4.7.7 — title search with synonym expansion + fuzzy re-ranking.
     * Strategy: run `titleSearch` against each variant from [QueryExpander.expand],
     * union the result IDs (de-duping by id), then re-rank using a fuzzy boost
     * computed against the original query tokens. Backward compatible: when
     * the query produces no expansion (no synonym matches), the output equals
     * the old direct `titleSearch(q)`.
     */
    private suspend fun expandedTitleSearch(raw: String, allowRerank: Boolean = true): List<SearchHit> {
        // v5.4.10 — Perf fast path. When semantic search is OFF, every
        // extra synonym variant is another FTS query and another round
        // trip through ranking; the user reports this got slow over the
        // last few versions. Cap variants tightly in semantic-off mode
        // (just the original — 1× FTS instead of up to 8× FTS). Keep
        // the full expansion when semantic is ON since variants
        // genuinely help recall on the keyword side of the blend.
        val maxVariants = if (semanticEnabled.value) 8 else 1
        val variants = com.tebogo.markvault.search.QueryExpander.expand(raw, maxVariants)
        val keywordHits = LinkedHashMap<Long, SearchHit>()
        val perVariantHits = ArrayList<List<SearchHit>>(variants.size)
        for (v in variants) {
            val hits = runCatching { titleSearch(v) }.getOrElse { emptyList() }
            perVariantHits += hits
            for (h in hits) keywordHits.putIfAbsent(h.id, h)
        }
        val issuedQueries = issuedRetrievalQueries(
            texts = variants,
            sources = List(variants.size) { index ->
                if (index == 0) com.tebogo.markvault.ai.QuerySource.ORIGINAL
                else com.tebogo.markvault.ai.QuerySource.SYNONYM
            },
            weights = List(variants.size) { 1.0 }
        )
        recordKeywordQueryProvenance(issuedQueries, perVariantHits)
        return blendSemanticAndKeyword(
            keywordHits = keywordHits,
            originalRaw = raw,
            scoreSource = { hit -> hit.title + " " + hit.relPath },
            allowRerank = allowRerank,
            semanticProvenanceQuery = originalIssuedQuery(raw)
        )
    }

    /**
     * v4.7.7 — full-text content search with synonym expansion. Same approach
     * as [expandedTitleSearch], but with one safety: in exact-phrase mode we
     * still run every expanded variant as an exact phrase, so the user's
     * intent ("phrase match") is preserved on each variant individually. If
     * any single variant matches, the user gets results.
     *
     * v5.4.5 — Takes [allowRerank] so the live-typing path can suppress
     * the expensive cross-encoder while the submit path still applies it.
     *
     * v5.4.10 — Caps variants to 1 when semantic search is OFF, restoring
     * the snappy keyword-only search performance that regressed.
     */
    private suspend fun expandedContentSearch(
        effective: String, originalRaw: String, exactPhrase: Boolean,
        allowRerank: Boolean = true,
        isSubmit: Boolean = false,
        scopeAtStart: String = currentScope,
        dualAtStart: Boolean = _semanticDualModeFlow.value
    ): List<SearchHit> {
        // v5.5.24 — Snapshot both controls once at the retrieval boundary.
        // Budget 0 is a universal hard stop for every expansion source. The
        // model switch is a second hard gate for both LLM and T5, including
        // cache reuse. This keeps semantic-ON and semantic-OFF searches under
        // the same policy and prevents asynchronous preference writes from
        // leaking the previous setting into the next submitted search.
        val expansionBudget = effectiveExpansionBudget()
        val modelExpansionEnabled = effectiveAiLlmSearchEnabled()
        val useT5 = modelExpansionEnabled && expansionBudget > 0 &&
            t5ExpansionMode.value == com.tebogo.markvault.ai.T5ExpansionMode.T5_BASE &&
            _t5Installed.value
        val activeEngine: com.tebogo.markvault.ai.QuerySource? = when {
            expansionBudget == 0 || !modelExpansionEnabled -> null
            useT5 -> com.tebogo.markvault.ai.QuerySource.T5
            isLlmModelInstalledFast() -> com.tebogo.markvault.ai.QuerySource.LLM
            else -> null
        }
        val expansionSource = activeEngine ?: com.tebogo.markvault.ai.QuerySource.LLM

        // Model output is computed once and then supplied to either the pure
        // keyword or hybrid semantic path. OFF means no invocation and no
        // cached paraphrase reuse.
        val llmParaphrases: List<String> = when (activeEngine) {
            com.tebogo.markvault.ai.QuerySource.T5 -> {
                val cached = com.tebogo.markvault.ai.LlmExpansionHistory.get(originalRaw)
                    ?.takeIf { it.modelName == "T5-base" }
                when {
                    cached != null -> cached.paraphrases
                    isSubmit -> runCatching {
                        runT5Expansion(originalRaw, expansionBudget)
                    }.getOrElse { emptyList() }
                    else -> emptyList()
                }
            }
            com.tebogo.markvault.ai.QuerySource.LLM -> {
                val expectedModelName =
                    runCatching { chatActiveModelId.value }.getOrNull()
                        ?.let { com.tebogo.markvault.llm.ChatModelCatalog.byId(it)?.displayName }
                        ?: com.tebogo.markvault.llm.ChatModelCatalog.default.displayName
                val cached = com.tebogo.markvault.ai.LlmExpansionHistory.get(originalRaw)
                    ?.takeIf { it.modelName == expectedModelName }
                when {
                    cached != null -> cached.paraphrases
                    isSubmit -> runCatching { llmQueryExpander.expandQuery(originalRaw) }.getOrElse { emptyList() }
                    else -> emptyList()
                }
            }
            else -> emptyList()
        }

        // Question Awareness remains a distinct provenance source, but it is
        // still query expansion. Therefore budget 0 must skip even analysis/
        // generation and issue only the exact original query.
        val questionAnalysis = if (expansionBudget > 0) {
            com.tebogo.markvault.search.QuestionAwareness.analyze(originalRaw)
        } else null
        val questionAwarenessEnabledForThisSearch =
            activeSearchTrace?.questionAwarenessEnabled ?: questionAwarenessEnabled.value
        val questionAwareQueries = if (
            questionAwarenessEnabledForThisSearch &&
            questionAnalysis != null &&
            questionAnalysis.usedSuccessfully
        ) {
            markQuestionAwarenessUsed(questionAnalysis)
            questionAnalysis.answerQueries
        } else emptyList()
        val questionAwarePrimarySemantic = questionAwareQueries.firstOrNull()?.text
        val questionAwareOriginalWeight = if (questionAwareQueries.isNotEmpty()) 0.72 else 1.0

        val llmVariantsLower: Set<String> = llmParaphrases
            .map { it.trim().lowercase() }
            .filter { it.isNotEmpty() }
            .toHashSet()

        // v5.4.14 — When semantic search is OFF, the user wants pure
        // literal keyword search. Previously this bailed immediately
        // with a single FTS call.
        //
        // v5.4.81cc — When LLM is on and produced paraphrases, we now
        // run FTS on each paraphrase alongside the original query and
        // merge with Reciprocal Rank Fusion. This gives the "LLM
        // multi-query retrieval without semantic" pipeline the user
        // asked for: no vector embeddings involved, just the LLM's
        // ability to phrase the same intent multiple ways and let each
        // rephrasing surface FTS hits the others would miss.
        if (!semanticEnabled.value) {
            _llmMatchedHitIds.value = emptySet()
            if (llmParaphrases.isEmpty() && questionAwareQueries.isEmpty()) {
                // v5.4.127cc — When BUILTIN (synonym) is the active expander
                // and the slider is above zero, run synonym FTS expansion even
                // in semantic-OFF mode. Previously this path returned
                // immediately with a single FTS call, skipping expansion
                // entirely for users with semantic search disabled. T5/LLM
                // failures (useT5=true but model produced nothing, or LLM
                // timed out) still fall through to single FTS — that is a
                // model failure, not a policy choice, so no synonym backfill.
                val isBuiltinActive = activeEngine == null
                // v5.4.139cc — Also honor the opt-in LLM-fallback-to-synonym
                // toggle here. When BUILTIN is active, synonym expansion is
                // the primary engine (unconditional). When AI is active but
                // produced nothing AND the fallback toggle is on, synonym
                // still runs as an explicit fallback. Otherwise strict mode:
                // AI failure is visible as zero expansion.
                val useSynonymFallback = activeEngine != null &&
                    llmFallbackToSynonym.value
                if ((isBuiltinActive || useSynonymFallback) && expansionBudget > 0) {
                    val synonymExpansions = com.tebogo.markvault.search.QueryExpander
                        .expandWeighted(originalRaw, expansionBudget + 1)
                        .filter { it.text.trim().lowercase() != originalRaw.trim().lowercase() }
                        .take(expansionBudget)
                    if (synonymExpansions.isNotEmpty()) {
                        val allQueries = listOf(originalRaw) +
                            synonymExpansions.map { it.text.trim() }
                        val allWeights = listOf(1.0) +
                            synonymExpansions.map { it.weight }
                        // Record plan for history dialog
                        val casing = HashMap<String, String>()
                        val weightsByKey = LinkedHashMap<String, Double>()
                        val sources = LinkedHashMap<String,
                            com.tebogo.markvault.ai.QuerySource>()
                        for ((i, q) in allQueries.withIndex()) {
                            val key = q.trim().lowercase()
                            casing.putIfAbsent(key, q.trim())
                            if (!weightsByKey.containsKey(key)) {
                                weightsByKey[key] = allWeights.getOrElse(i) { 1.0 }
                                sources[key] = if (i == 0)
                                    com.tebogo.markvault.ai.QuerySource.ORIGINAL
                                else com.tebogo.markvault.ai.QuerySource.SYNONYM
                            }
                        }
                        recordQueryPlan(
                            originalRaw = originalRaw,
                            keys = weightsByKey.keys.toList(),
                            casingByKey = casing,
                            mergedWeights = weightsByKey,
                            sourceByKey = sources,
                            semanticOn = false,
                            budget = expansionBudget,
                            attemptedSource = com.tebogo.markvault.ai.QuerySource.SYNONYM
                        )
                        val perQueryHits = ArrayList<List<SearchHit>>(allQueries.size)
                        for (q in allQueries) {
                            // v5.5.14 — Finish the current cheap FTS query, then stop
                            // issuing further expansion queries so reranking can start.
                            if (gracefulSearchStopRequested() && perQueryHits.isNotEmpty()) break
                            val eff = if (exactPhrase) "\"$q\"" else q
                            perQueryHits += runCatching {
                                rankedContentSearch(
                                    eff,
                                    originalRaw = q,
                                    allowImplicitTopicExpansion = false
                                )
                            }.getOrElse { emptyList() }
                        }
                        val issuedQueries = issuedRetrievalQueries(
                            texts = allQueries,
                            sources = List(allQueries.size) { index ->
                                if (index == 0) com.tebogo.markvault.ai.QuerySource.ORIGINAL
                                else com.tebogo.markvault.ai.QuerySource.SYNONYM
                            },
                            weights = allWeights
                        )
                        recordKeywordQueryProvenance(
                            queries = issuedQueries.take(perQueryHits.size),
                            perQueryHits = perQueryHits
                        )
                        return maybeRerank(
                            reciprocalRankFusion(
                                perQueryHits, k = RRF_K, weights = allWeights.take(perQueryHits.size)
                            ),
                            originalRaw, allowRerank
                        )
                    }
                }

                // Slider=0, a model failed, or no synonym variants were found:
                // issue the original query literally. In particular, do not
                // call Topics.expandQuery here; that hidden OR expansion was
                // the remaining way a zero-budget search still expanded.
                recordOriginalOnlyQueryPlan(
                    originalRaw = originalRaw,
                    semanticOn = false,
                    budget = expansionBudget,
                    attemptedSource = activeEngine ?: if (expansionBudget > 0) {
                        com.tebogo.markvault.ai.QuerySource.SYNONYM
                    } else null
                )
                val directHits = runCatching {
                    rankedContentSearch(
                        effective,
                        originalRaw = originalRaw,
                        allowImplicitTopicExpansion = false
                    )
                }.getOrElse { emptyList() }
                recordKeywordQueryProvenance(
                    queries = listOf(originalIssuedQuery(originalRaw)),
                    perQueryHits = listOf(directHits)
                )
                return if (gracefulSearchStopRequested()) {
                    maybeRerank(directHits, originalRaw, allowRerank = true)
                } else directHits
            }
            // v5.5.14 — Multi-query FTS across answer-oriented Question
            // Awareness queries + the original + optional LLM/T5 paraphrases.
            // When Question Awareness actually produced answer queries, those are
            // primary retrieval evidence and the literal question is secondary.
            val queries = buildList {
                questionAwareQueries.forEach { add(it.text) }
                add(originalRaw)
                addAll(llmParaphrases)
            }.distinctBy { it.trim().lowercase() }
            val questionWeightByKey = questionAwareQueries.associate { it.text.trim().lowercase() to it.weight }
            val llmKeys = llmParaphrases.map { it.trim().lowercase() }.toSet()
            val queryWeights: List<Double> = queries.map { q ->
                val key = q.trim().lowercase()
                when {
                    key in questionWeightByKey -> questionWeightByKey[key] ?: 1.0
                    key == originalRaw.trim().lowercase() -> questionAwareOriginalWeight
                    key in llmKeys -> LLM_PARAPHRASE_WEIGHT
                    else -> 1.0
                }
            }
            run {
                val casing = HashMap<String, String>()
                val weightsByKey = LinkedHashMap<String, Double>()
                val sources = LinkedHashMap<String, com.tebogo.markvault.ai.QuerySource>()
                for ((i, q) in queries.withIndex()) {
                    val key = q.trim().lowercase()
                    casing.putIfAbsent(key, q.trim())
                    if (!weightsByKey.containsKey(key)) {
                        weightsByKey[key] = queryWeights.getOrElse(i) { 1.0 }
                        sources[key] = when {
                            key in questionWeightByKey -> com.tebogo.markvault.ai.QuerySource.QUESTION_AWARENESS
                            key == originalRaw.trim().lowercase() -> com.tebogo.markvault.ai.QuerySource.ORIGINAL
                            else -> expansionSource
                        }
                    }
                }
                recordQueryPlan(
                    originalRaw = originalRaw,
                    keys = weightsByKey.keys.toList(),
                    casingByKey = casing,
                    mergedWeights = weightsByKey,
                    sourceByKey = sources,
                    semanticOn = false,
                    budget = expansionBudget,
                    attemptedSource = if (llmParaphrases.isNotEmpty()) expansionSource else null
                )
            }
            val perQueryHits = ArrayList<List<SearchHit>>(queries.size)
            for (q in queries) {
                if (gracefulSearchStopRequested() && perQueryHits.isNotEmpty()) break
                val eff = if (exactPhrase) "\"$q\"" else q
                perQueryHits += runCatching {
                    rankedContentSearch(
                        eff,
                        originalRaw = q,
                        allowImplicitTopicExpansion = false
                    )
                }.getOrElse { emptyList() }
            }
            val issuedQueries = issuedRetrievalQueries(
                texts = queries,
                sources = queries.map { q ->
                    val key = q.trim().lowercase()
                    when {
                        key in questionWeightByKey -> com.tebogo.markvault.ai.QuerySource.QUESTION_AWARENESS
                        key == originalRaw.trim().lowercase() -> com.tebogo.markvault.ai.QuerySource.ORIGINAL
                        else -> expansionSource
                    }
                },
                weights = queryWeights
            )
            recordKeywordQueryProvenance(
                queries = issuedQueries.take(perQueryHits.size),
                perQueryHits = perQueryHits
            )
            // Track hits that appeared only through LLM/T5 paraphrases. Question
            // Awareness is deterministic, so its hits are NOT painted as "AI".
            val allHitIds: HashSet<Long> = HashSet()
            val nonLlmHitIds: HashSet<Long> = HashSet()
            for ((index, list) in perQueryHits.withIndex()) {
                val qKey = queries.getOrNull(index)?.trim()?.lowercase().orEmpty()
                val isLlmQuery = qKey in llmKeys
                for (h in list) {
                    allHitIds.add(h.id)
                    if (!isLlmQuery) nonLlmHitIds.add(h.id)
                }
            }
            _llmMatchedHitIds.value = allHitIds - nonLlmHitIds

            // RRF fuse, weighted by per-query trust.
            val fused = reciprocalRankFusion(
                perQueryHits, k = RRF_K, weights = queryWeights.take(perQueryHits.size)
            )

            // Optional cross-encoder rerank on top — the "Retrieve-then-
            // Refine" pipeline. Reranker is orthogonal to semantic
            // search; when installed and enabled it strictly improves
            // ordering regardless of how the candidates were retrieved.
            return maybeRerank(fused, originalRaw, allowRerank)
        }

        // ── Semantic ON path ────────────────────────────────────────────────
        //
        // v5.4.115cc — This path used to collapse every sub-query's
        // results into a LinkedHashMap with `putIfAbsent`, then hand
        // the bare key set to the blend, which awarded a *flat* keyword
        // bonus to every id. Two documents were therefore scored
        // identically whether one was ranked #1 by six different
        // variants or the other was ranked #90 by a single weak
        // synonym swap. All of the multi-query evidence — rank, and
        // agreement across rewordings — was computed and then thrown
        // away.
        //
        // Now each variant carries a trust weight, we fuse with
        // weighted RRF, and the normalised fusion score is passed into
        // the blend as a *graded* keyword signal.
        // v5.4.115cc — The multi-query slider is a single, literal
        // budget: its value is exactly how many EXTRA queries get
        // generated. 0 = no expansion (your words only), 1 = one
        // expansion query, 2 = two, and so on. Total queries issued is
        // always `1 + budget`.
        //
        // v5.4.124cc — STRICT MUTUAL EXCLUSION. Exactly one expansion
        // source ever contributes sub-queries for a given search:
        //
        //   • model switch ON + T5 installed/selected -> QuerySource.T5 only
        //   • model switch ON + catalog LLM installed -> QuerySource.LLM only
        //   • model switch OFF + budget above 0       -> QuerySource.SYNONYM
        //   • budget 0                                 -> original query only
        //
        // The previous version drew candidates from the AI pool AND the
        // offline synonym pool on every search, interleaving them to
        // fill the budget -- so picking T5-base still silently blended
        // in synonym substitutions (and vice versa), and a slow/failed
        // AI run got backfilled by synonyms instead of just contributing
        // fewer sub-queries. That's the bug: the Settings selection was
        // advisory, not a hard router. `activeEngine` above is that hard
        // router -- the other two sources are never invoked, never
        // queried, and never appear in the recorded plan.
        val originalKey = originalRaw.trim().lowercase()

        // v5.4.127cc — Engine pool construction.
        //
        // When an AI engine (T5 or LLM) is selected AND has produced
        // paraphrases → use those paraphrases exclusively (one-expander rule).
        //
        // When an AI engine is selected BUT produced ZERO paraphrases
        // (live-typing path where isSubmit=false so the heavy model wasn't
        // invoked, OR model timed out / failed) → fall back to the synonym
        // expander so expansion NEVER produces zero results when slider > 0.
        // This satisfies the hard requirement: "query expansion must not be
        // skipped as long as the slider is above zero." The synonym fallback
        // is transparent — it doesn't interfere with the next submit which
        // will re-run the real AI engine.
        //
        // When no AI engine is active (BUILTIN) → synonym expander is the
        // sole source, same as before.
        val synonymPool: List<Pair<String, Double>> =
            if (expansionBudget == 0) emptyList()
            else com.tebogo.markvault.search.QueryExpander
                .expandWeighted(originalRaw, expansionBudget + 1)
                .filter { it.text.trim().lowercase() != originalKey }
                .take(expansionBudget)
                .map { it.text.trim() to it.weight }

        val enginePool: List<Pair<String, Double>> = when (activeEngine) {
            com.tebogo.markvault.ai.QuerySource.T5,
            com.tebogo.markvault.ai.QuerySource.LLM -> {
                val aiPool = llmParaphrases
                    .map { it.trim() }
                    .filter { it.isNotEmpty() && it.lowercase() != originalKey }
                    .distinct()
                    .take(expansionBudget)
                    .map { it to LLM_PARAPHRASE_WEIGHT }
                // v5.4.139cc — Strict-mode fallback policy.
                //
                // Previously (v5.4.127cc–v5.4.138cc): if the AI engine
                // produced no paraphrases (live-typing before submit,
                // model timeout, engine error, or every candidate line
                // rejected by the relevance gate), we SILENTLY fell
                // back to the synonym expander. That was well-meaning
                // — "expansion must never produce zero results when
                // slider > 0" — but it hid the LLM's actual behaviour
                // from the user, who had turned the LLM toggle on
                // precisely to see the LLM working.
                //
                // Now: if AI is the active engine and the AI pool is
                // empty, honour the strict default (return empty,
                // making the LLM's failure visible in the plan
                // history) UNLESS the user has explicitly opted into
                // synonym fallback via Settings. The synonym pool
                // still runs when the ACTIVE ENGINE ITSELF is
                // BUILTIN — that's not a fallback, it's the primary.
                if (aiPool.isNotEmpty()) aiPool
                else if (llmFallbackToSynonym.value) synonymPool
                else emptyList()
            }
            else -> synonymPool
        }

        val mergedWeights = LinkedHashMap<String, Double>()
        val sourceByKey = LinkedHashMap<String, com.tebogo.markvault.ai.QuerySource>()
        val casingByKey = HashMap<String, String>()

        // v5.5.14 — The user's words always run. For a successfully recognized
        // question, answer-shaped retrieval is primary and the literal question is
        // intentionally secondary; otherwise the historical full-trust 1.0 applies.
        mergedWeights[originalKey] = questionAwareOriginalWeight
        sourceByKey[originalKey] = com.tebogo.markvault.ai.QuerySource.ORIGINAL
        casingByKey[originalKey] = originalRaw.trim()
        for (qa in questionAwareQueries) {
            val text = qa.text.trim()
            val key = text.lowercase()
            if (text.isNotEmpty() && !mergedWeights.containsKey(key)) {
                mergedWeights[key] = qa.weight
                sourceByKey[key] = com.tebogo.markvault.ai.QuerySource.QUESTION_AWARENESS
                casingByKey[key] = text
            }
        }

        // v5.4.127cc — poolSource reflects what actually filled enginePool:
        // if an AI engine was active but produced nothing (live-typing
        // fallback), enginePool was filled by synonyms, so label them SYNONYM.
        val aiProducedResults = activeEngine != null && llmParaphrases.isNotEmpty()
        val poolSource = when {
            aiProducedResults -> activeEngine!!
            else -> com.tebogo.markvault.ai.QuerySource.SYNONYM
        }
        for ((rawText, weight) in enginePool) {
            val text = rawText.trim()
            val key = text.lowercase()
            if (text.isNotEmpty() && !mergedWeights.containsKey(key)) {
                mergedWeights[key] = weight
                sourceByKey[key] = poolSource
                casingByKey[key] = text
            }
        }

        val allVariants: List<String> = mergedWeights.keys.map { casingByKey[it] ?: it }
        val variantWeights: List<Double> = mergedWeights.keys.map { mergedWeights[it] ?: 1.0 }
        val issuedVariantQueries = issuedRetrievalQueries(
            texts = allVariants,
            sources = mergedWeights.keys.map { key ->
                sourceByKey[key] ?: com.tebogo.markvault.ai.QuerySource.SYNONYM
            },
            weights = variantWeights
        )

        // v5.4.115cc — Record the full plan so the history dialog can
        // show exactly which sub-queries ran, from which expander.
        recordQueryPlan(
            originalRaw = originalRaw,
            keys = mergedWeights.keys.toList(),
            casingByKey = casingByKey,
            mergedWeights = mergedWeights,
            sourceByKey = sourceByKey,
            semanticOn = true,
            budget = expansionBudget,
            attemptedSource = activeEngine ?: (
                if (expansionBudget > 0) com.tebogo.markvault.ai.QuerySource.SYNONYM else null
            )
        )

        val keywordHits = LinkedHashMap<Long, SearchHit>()
        val nonLlmHitIds = HashSet<Long>()
        val perVariantHits = ArrayList<List<SearchHit>>(allVariants.size)
        for (v in allVariants) {
            // v5.5.14 — A stopped search freezes the keyword candidate pool at
            // the next completed variant; final hybrid fusion/reranking still runs.
            if (gracefulSearchStopRequested() && perVariantHits.isNotEmpty()) break
            val effv = if (exactPhrase) "\"$v\"" else v
            val hits = runCatching {
                rankedContentSearch(
                    effv,
                    originalRaw = v,
                    allowImplicitTopicExpansion = false
                )
            }.getOrElse { emptyList() }
            perVariantHits.add(hits)
            val fromLlmOnly = v.lowercase() in llmVariantsLower
            for (h in hits) {
                keywordHits.putIfAbsent(h.id, h)
                if (!fromLlmOnly) nonLlmHitIds.add(h.id)
            }
        }
        recordKeywordQueryProvenance(
            queries = issuedVariantQueries.take(perVariantHits.size),
            perQueryHits = perVariantHits
        )
        val llmOnlyHitIds: Set<Long> = keywordHits.keys - nonLlmHitIds
        _llmMatchedHitIds.value = llmOnlyHitIds

        // v5.5.12 — Preserve expansion trust when converting weighted RRF to
        // a 0..1 fusion signal. Normalising by the strongest *observed* hit
        // made a lone weak LLM/synonym result become 1.0 and erased the very
        // trust weights weightedRrfScores() computed. The helper anchors the
        // user's original query at full trust and normalises every weighted
        // contribution against one full-trust rank-1 RRF contribution.
        val rrfRaw = weightedRrfScores(perVariantHits, RRF_K, variantWeights.take(perVariantHits.size))
        val keywordRankScores = keywordFusionSignals(
            perQueryHits = perVariantHits,
            rrfRaw = rrfRaw,
            k = RRF_K
        )

        val blended = blendSemanticAndKeyword(
            keywordHits = keywordHits,
            originalRaw = originalRaw,
            scoreSource = { hit -> hit.title + " " + hit.snippet },
            allowRerank = allowRerank,
            keywordRankScores = keywordRankScores,
            scopeAtStart = scopeAtStart,
            dualAtStart = dualAtStart,
            // Exact phrase means exactly that: semantic similarity is allowed
            // to rank matching articles, never to bypass the phrase filter.
            requireKeywordCandidate = exactPhrase,
            semanticQueryOverride = questionAwarePrimarySemantic,
            semanticProvenanceQuery = issuedVariantQueries.firstOrNull { issued ->
                issued.text.equals(
                    questionAwarePrimarySemantic?.takeIf { it.isNotBlank() } ?: originalRaw,
                    ignoreCase = true
                )
            } ?: originalIssuedQuery(originalRaw)
        )
        return blended
    }

    /**
     * v5.4.81cc — Reciprocal Rank Fusion. Given the ranked FTS hits
     * from each of several paraphrased sub-queries, produce a single
     * ranked list where each hit's score is the sum of `1 / (k + rank)`
     * contributions from every query that surfaced it.
     *
     * `k` (default 60 per the classic RRF paper) softens the impact of
     * being ranked #1 vs #10 in any single query — a hit that appears
     * at rank 5 in three different paraphrases beats a hit that
     * appears at rank 1 in only one, which is exactly the "surfaced
     * consistently across rewrites → probably relevant" signal
     * multi-query retrieval is trying to capture.
     *
     * Hit metadata (title, snippet, fileType) is preserved from the
     * first query that saw it — good enough for display; the FTS
     * snippet is per-query anyway so there's no globally "correct"
     * choice. Score field left as null: RRF scores are on a different
     * scale than the semantic 0..1 confidence and mixing them in the
     * UI's percentage chip would mislead.
     */
    /**
     * v5.4.115cc — Persist the query plan for the history dialog.
     *
     * Called from both retrieval paths so the dialog can show the full
     * fan-out — original, synonym variants, LLM paraphrases — with the
     * fusion weight each one carried.
     */
    private fun recordOriginalOnlyQueryPlan(
        originalRaw: String,
        semanticOn: Boolean,
        budget: Int,
        attemptedSource: com.tebogo.markvault.ai.QuerySource? = null
    ) {
        val text = originalRaw.trim()
        val key = text.lowercase()
        recordQueryPlan(
            originalRaw = originalRaw,
            keys = listOf(key),
            casingByKey = mapOf(key to text),
            mergedWeights = mapOf(key to 1.0),
            sourceByKey = mapOf(key to com.tebogo.markvault.ai.QuerySource.ORIGINAL),
            semanticOn = semanticOn,
            budget = budget.coerceIn(0, 10),
            attemptedSource = attemptedSource
        )
    }

    private fun recordQueryPlan(
        originalRaw: String,
        keys: List<String>,
        casingByKey: Map<String, String>,
        mergedWeights: Map<String, Double>,
        sourceByKey: Map<String, com.tebogo.markvault.ai.QuerySource>,
        semanticOn: Boolean,
        budget: Int,
        attemptedSource: com.tebogo.markvault.ai.QuerySource? = null
    ) {
        runCatching {
            val generated = keys.map { key ->
                com.tebogo.markvault.ai.GeneratedQuery(
                    text = casingByKey[key] ?: key,
                    source = sourceByKey[key]
                        ?: com.tebogo.markvault.ai.QuerySource.SYNONYM,
                    weight = mergedWeights[key] ?: 1.0
                )
            }
            com.tebogo.markvault.ai.QueryPlanHistory.record(
                com.tebogo.markvault.ai.QueryPlanRecord(
                    query = originalRaw,
                    generated = generated,
                    timestampMs = System.currentTimeMillis(),
                    semanticOn = semanticOn,
                    budget = budget,
                    attemptedSource = attemptedSource
                )
            )
        }
    }

    private fun reciprocalRankFusion(
        perQueryHits: List<List<SearchHit>>,
        k: Int = 60,
        weights: List<Double> = emptyList()
    ): List<SearchHit> {
        val firstSeen = LinkedHashMap<Long, SearchHit>()
        val scores = weightedRrfScores(perQueryHits, k, weights, firstSeen)
        return firstSeen.entries
            .sortedByDescending { scores[it.key] ?: 0.0 }
            .map { it.value }
    }

    /**
     * v5.4.115cc — The scoring half of [reciprocalRankFusion], split out
     * so the semantic path can consume the per-document scores directly
     * instead of only a re-ordered list.
     *
     * ## Why weighting matters
     *
     * Classic RRF assumes every ranked list is an equally credible
     * opinion. That holds for an ensemble of comparable retrievers; it
     * does *not* hold here. Our lists come from:
     *   • the user's literal query — the ground truth of their intent,
     *   • synonym substitutions — our guess,
     *   • paraphrases from a 135M-parameter model — a weaker guess.
     *
     * Unweighted, a document ranked #1 by a drifted LLM paraphrase
     * contributed exactly as much as a document ranked #1 by the user's
     * own words. Per-list weights make a sub-query's influence
     * proportional to how much we trust it, which is the single
     * highest-leverage accuracy fix in the fusion layer.
     *
     * Missing or short [weights] default to 1.0 so existing callers
     * keep classic RRF behaviour.
     */
    private fun weightedRrfScores(
        perQueryHits: List<List<SearchHit>>,
        k: Int,
        weights: List<Double>,
        firstSeenOut: LinkedHashMap<Long, SearchHit>? = null
    ): Map<Long, Double> {
        val scores = HashMap<Long, Double>()
        for ((queryIdx, queryHits) in perQueryHits.withIndex()) {
            val w = weights.getOrElse(queryIdx) { 1.0 }
            if (w <= 0.0) continue
            for ((rankZeroBased, hit) in queryHits.withIndex()) {
                firstSeenOut?.putIfAbsent(hit.id, hit)
                // RRF is 1-indexed on rank.
                val contrib = w / (k + rankZeroBased + 1)
                scores.merge(hit.id, contrib) { a, b -> a + b }
            }
        }
        return scores
    }


    /**
     * v5.5.12 — Convert weighted RRF evidence into a stable 0..1 keyword
     * signal without destroying the trust weights of generated queries.
     *
     * The old `score / maxObservedScore` normalisation was query-set relative:
     * when only a weak 0.6-weight LLM paraphrase found anything, its top result
     * became 1.0 — indistinguishable from a top hit produced by the user's own
     * words. Here one full-trust rank-1 result defines 1.0; generated query
     * weights therefore remain meaningful (0.8 stays 0.8, 0.6 stays 0.6),
     * while agreement across variants can accumulate toward 1.0. Empty variants
     * do not dilute a valid hit. The original query's own rank signal is also
     * preserved directly.
     */
    private fun keywordFusionSignals(
        perQueryHits: List<List<SearchHit>>,
        rrfRaw: Map<Long, Double>,
        k: Int
    ): Map<Long, Double> {
        if (perQueryHits.isEmpty() || rrfRaw.isEmpty()) return emptyMap()
        val safeK = k.coerceAtLeast(1)

        // v5.5.12 — Normalise against ONE full-trust query ranked #1, not
        // against the sum of every issued query's theoretical maximum.
        //
        // Why: if seven optional expansions returned nothing and one good
        // synonym (weight 0.8) found the right article, dividing by all eight
        // theoretical lists crushed that valid signal to ~0.1. Conversely,
        // normalising by the strongest observed hit erased trust weights.
        //
        // With this anchor:
        //   original top hit      -> 1.00
        //   synonym top, w=0.8   -> 0.80
        //   LLM top, w=0.6       -> 0.60
        //   agreement across several variants accumulates toward 1.00.
        // Empty variants neither promote nor unfairly punish a candidate.
        val fullTrustTop = 1.0 / (safeK + 1.0)

        val originalSignal = HashMap<Long, Double>()
        perQueryHits.firstOrNull().orEmpty().forEachIndexed { rank, hit ->
            // Top original-query hit = 1.0; lower original ranks decay gently
            // using the same RRF geometry rather than an arbitrary linear falloff.
            originalSignal[hit.id] = ((safeK + 1.0) / (safeK + rank + 1.0))
                .coerceIn(0.0, 1.0)
        }

        val ids = LinkedHashSet<Long>()
        ids.addAll(rrfRaw.keys)
        ids.addAll(originalSignal.keys)
        return ids.associateWith { id ->
            val consensus = ((rrfRaw[id] ?: 0.0) / fullTrustTop).coerceIn(0.0, 1.0)
            maxOf(originalSignal[id] ?: 0.0, consensus)
        }
    }

    /**
     * v5.4.81cc — Optional cross-encoder rerank pass, factored out so
     * the RRF path can share it with the semantic-ON blend. When the
     * reranker is installed and (rerank pref is on OR `allowRerank` is
     * forced true), reorder the top slice with the cross-encoder and
     * return the reranked list; otherwise return the input unchanged.
     *
     * Fails gracefully — any reranker error falls back to the input
     * ordering rather than failing the search.
     *
     * ## Adapting SearchHit to applyRerank's Pair-based API
     *
     * [applyRerank] accepts a stage-one score scale. RRF does not have a
     * natural 0..1 confidence score, so this adapter supplies strictly
     * decreasing rank slots. v5.5.10 keeps those slots as the returned score
     * scale while allowing the cross-encoder to reassign which candidate owns
     * each top slot. The untouched tail therefore keeps the original RRF order
     * and no incompatible score magnitudes are compared.
     */
    private suspend fun maybeRerank(
        hits: List<SearchHit>,
        originalRaw: String,
        allowRerank: Boolean
    ): List<SearchHit> {
        if (!allowRerank && !gracefulSearchStopRequested()) return hits
        if (!rerankEnabled.value) return hits
        if (!rerankerInstalled.value) return hits
        if (hits.isEmpty()) return hits
        val candidates: List<Pair<Long, Float>> = hits.mapIndexed { idx, hit ->
            // Strictly decreasing pseudo-score so applyRerank's stable
            // sort behaves. 1.0 down to ~0.0 across the input length.
            val pseudo = 1f - (idx.toFloat() / hits.size.coerceAtLeast(1))
            hit.id to pseudo
        }
        val reranked = runCatching {
            applyRerank(originalRaw, candidates)
        }.getOrElse { return hits }
        // v5.5.10 — applyRerank returns a rank-calibrated score for every
        // candidate on the same input scale. Map it onto every row so the
        // displayed percentages remain monotonic without a second global sort.
        val byId = hits.associateBy { it.id }
        return reranked.mapNotNull { (id, score) ->
            byId[id]?.copy(score = score)
        }
    }

    /**
     * v5.4.76cc — Fast synchronous check for "is the currently active
     * LLM model file on disk and plausibly complete". Used inside the
     * search hot path to gate LLM expansion without paying for a full
     * descriptor lookup. Cheap: two virtual-filesystem calls (exists,
     * length).
     *
     * v5.4.80cc — Fixed a critical bug: the check previously used
     * `ChatModelCatalog.default`, which after v5.4.79cc changed to
     * SmolLM2. That meant Phi-4-mini users whose SmolLM2 wasn't
     * installed had the LLM path silently skipped even though their
     * *chosen* model was ready to go. Now honours [chatActiveModelId].
     */
    private fun isLlmModelInstalledFast(): Boolean {
        val activeId = runCatching { chatActiveModelId.value }.getOrNull()
            ?: com.tebogo.markvault.llm.ChatModelCatalog.default.id
        val desc = com.tebogo.markvault.llm.ChatModelCatalog.byId(activeId)
            ?: com.tebogo.markvault.llm.ChatModelCatalog.default
        val f = java.io.File(getApplication<Application>().filesDir, desc.localFilename)
        return f.exists() &&
            f.length() > com.tebogo.markvault.llm.ChatModelCatalog.MIN_PLAUSIBLE_MODEL_BYTES
    }

    /**
     * Hybrid-search helpers. v5.5.12 replaces the older flat keyword bonus +
     * raw-cosine blend because raw cosine scales are model-dependent and the
     * final cross-encoder must judge the already-fused candidate set.
     */
    /**
     * v5.5.12 — Model-independent semantic fusion signal.
     *
     * MiniLM and BGE cosine distributions are not calibrated probabilities and
     * are not directly comparable. A raw `0.62` from one model can be a stronger
     * retrieval than `0.78` from another. Hybrid ranking therefore uses the
     * within-query semantic ORDER as the primary signal and only a smaller
     * normalised cosine-margin component as a tiebreaker. This preserves the
     * embedding model's judgement while making fusion behaviour stable when the
     * user switches models.
     */
    private fun semanticFusionSignals(
        semantic: List<Pair<Long, Float>>
    ): Map<Long, Double> {
        if (semantic.isEmpty()) return emptyMap()
        val maxRaw = semantic.maxOf { it.second.toDouble() }
        val minRaw = semantic.minOf { it.second.toDouble() }
        val range = maxRaw - minRaw
        return semantic.mapIndexed { rank, (id, raw) ->
            // Rank 0 = 1.0; rank 25 ~= 0.5; rank 100 ~= 0.2. This gives
            // useful headroom to the strong semantic neighbourhood without
            // pretending rank 200 is nearly as strong as rank 1.
            val rankSignal = 1.0 / (1.0 + rank.toDouble() / 25.0)
            val marginSignal = if (range > 1e-9) {
                ((raw.toDouble() - minRaw) / range).coerceIn(0.0, 1.0)
            } else rankSignal
            id to (0.70 * rankSignal + 0.30 * marginSignal).coerceIn(0.0, 1.0)
        }.toMap()
    }

    /**
     * v5.5.12 — Accuracy-first hybrid ranking.
     *
     * Retrieval and final judgement now happen in the correct order:
     *   1. keyword / multi-query candidates
     *   2. semantic candidates (ANN or exact, exact-vector rescored)
     *   3. model-independent fusion of those two evidence streams
     *   4. ONE cross-encoder pass over the FINAL top candidate window
     *
     * v5.5.10 reranked the semantic list before keyword/RRF fusion. That meant a
     * keyword-expanded document could enter or jump to the top only *after* the
     * cross-encoder had finished, so the strongest model never judged the final
     * ordering. v5.5.12 deliberately disables the semantic-stage rerank here and
     * applies the same reranker once, after fusion. This improves accuracy without
     * paying for two cross-encoder passes.
     */
    private suspend fun blendSemanticAndKeyword(
        keywordHits: LinkedHashMap<Long, SearchHit>,
        originalRaw: String,
        scoreSource: (SearchHit) -> String,
        allowRerank: Boolean = true,
        keywordRankScores: Map<Long, Double> = emptyMap(),
        scopeAtStart: String = currentScope,
        dualAtStart: Boolean = _semanticDualModeFlow.value,
        requireKeywordCandidate: Boolean = false,
        semanticQueryOverride: String? = null,
        semanticProvenanceQuery: IssuedRetrievalQuery? = null
    ): List<SearchHit> {
        val useSemantic = semanticEnabled.value
        val allowedScopeIds: Set<Long>? = if (useSemantic) {
            scopeMembershipIds(scopeAtStart, dualAtStart)
        } else null
        val scopedKeywordHits: LinkedHashMap<Long, SearchHit> = if (allowedScopeIds == null) {
            keywordHits
        } else {
            LinkedHashMap<Long, SearchHit>().apply {
                for ((id, hit) in keywordHits) {
                    if (id in allowedScopeIds) put(id, hit)
                }
            }
        }

        val semanticOutcome = if (useSemantic) {
            runCatching {
                semanticSearchOutcomeForScope(
                    query = semanticQueryOverride?.takeIf { it.isNotBlank() } ?: originalRaw,
                    topK = SEMANTIC_FUSION_CANDIDATES,
                    // Important: the final hybrid set is reranked below. Running
                    // a semantic-only rerank here would double latency and still
                    // fail to judge keyword-only candidates introduced by fusion.
                    allowRerank = false,
                    scopeAtStart = scopeAtStart,
                    dualAtStart = dualAtStart
                )
            }.getOrElse {
                if (it is kotlinx.coroutines.CancellationException) throw it
                android.util.Log.w("MarkVaultAccuracy", "Semantic side of hybrid search failed", it)
                SemanticSearchOutcome(emptyList())
            }
        } else SemanticSearchOutcome(emptyList())

        val semantic = semanticOutcome.ranking
        val semanticSignals = semanticFusionSignals(semantic)
        if (useSemantic && semantic.isNotEmpty()) {
            recordSemanticQueryProvenance(
                query = semanticProvenanceQuery ?: originalIssuedQuery(
                    semanticQueryOverride?.takeIf { it.isNotBlank() } ?: originalRaw
                ),
                ranking = semantic,
                semanticSignals = semanticSignals
            )
        }

        // Exact-phrase mode is a hard retrieval constraint: semantic evidence
        // may improve the ordering of phrase matches, but it must never inject
        // an article that does not satisfy the requested phrase. For ordinary
        // Deep search, keep the normal keyword ∪ semantic recall union.
        val allIds: Set<Long> = LinkedHashSet<Long>().apply {
            addAll(scopedKeywordHits.keys)
            if (!requireKeywordCandidate) {
                semantic.forEach { add(it.first) }
            }
        }
        if (allIds.isEmpty()) return emptyList()

        val originalTokens = originalRaw.split(Regex("\\s+")).filter { it.isNotEmpty() }
        val scored = ArrayList<Pair<SearchHit, Double>>(allIds.size)

        for (id in allIds) {
            val baseHit = scopedKeywordHits[id] ?: run {
                val n = runCatching { dao.byId(id) }.getOrNull() ?: return@run null
                SearchHit(
                    id = n.id,
                    relPath = n.relPath,
                    title = n.title,
                    snippet = "",
                    fileType = n.fileType
                )
            } ?: continue

            // Original-query / trusted multi-query keyword evidence lives on a
            // true 0..1 scale. If this caller did not provide graded evidence,
            // a literal hit is treated as full-trust keyword evidence.
            val rawKeywordSignal = if (id in scopedKeywordHits) {
                keywordRankScores[id]?.coerceIn(0.0, 1.0) ?: 1.0
            } else 0.0
            val semanticSignal = semanticSignals[id] ?: 0.0
            val fuzzyBoost = com.tebogo.markvault.search.QueryExpander.fuzzyBoost(
                scoreSource(baseHit), originalTokens
            ).toDouble()

            // v5.5.12 — For count questions, keyword evidence is slightly
            // discounted when the LOCAL title/snippet contains the topic words
            // but no count-answer evidence. This is intentionally only a mild
            // first-stage adjustment because FTS snippets are cropped; the
            // cross-encoder below performs the decisive coherent-passage check.
            val keywordIntentFactor = if (rawKeywordSignal > 0.0 && isCountIntent(originalRaw)) {
                val local = baseHit.title + "\n" + baseHit.snippet
                val strength = countAnswerStrength(originalRaw, local).toDouble()
                0.65 + 0.35 * strength
            } else 1.0
            val keywordSignal = (rawKeywordSignal * keywordIntentFactor).coerceIn(0.0, 1.0)

            // Absolute evidence strength, NOT query-relative max normalisation.
            // A single semantic signal tops out below 100%; independent keyword
            // agreement raises confidence, and a small fuzzy component only
            // breaks near-ties. This prevents "best of a weak set = 100%".
            val semanticEvidence = (semanticSignal * SEMANTIC_EVIDENCE_MAX).coerceIn(0.0, 0.99)
            val keywordEvidence = (keywordSignal * KEYWORD_EVIDENCE_MAX).coerceIn(0.0, 0.99)
            val combinedEvidence = 1.0 - (1.0 - semanticEvidence) * (1.0 - keywordEvidence)
            val fuzzyDenom = (originalTokens.count { it.length >= 3 }.coerceAtLeast(1) * 30.0)
            val fuzzySignal = (fuzzyBoost / fuzzyDenom).coerceIn(0.0, 1.0)
            val relevance = (combinedEvidence + fuzzySignal * FUZZY_EVIDENCE_MAX)
                .coerceIn(0.0, 0.98)
            scored.add(baseHit to relevance)
        }

        if (scored.isEmpty()) return emptyList()

        val ordered = scored.sortedByDescending { it.second }.take(MAX_HYBRID_RESULTS)
        val stageOneHits = ordered.map { (hit, relevance) ->
            hit.copy(score = relevance.toFloat().coerceIn(0f, 0.98f))
        }

        // Cross-encoder judgement belongs here, after ALL retrieval signals have
        // produced the real final candidate set. Reuse the already-computed query
        // vector so passage selection remains aligned with the active embedding
        // model and no second query inference is needed.
        if ((!allowRerank && !gracefulSearchStopRequested()) || !rerankEnabled.value || !_rerankerInstalled.value) {
            return stageOneHits
        }

        currentCoroutineContext().ensureActive()

        // BGE-scale models consume substantial native memory. Release them only
        // if this is still the same globally active model; a concurrent model
        // switch must never cause us to close the newly-selected model instead.
        if (
            semanticOutcome.queryVector != null &&
            semanticOutcome.modelApproxSizeMb > 32 &&
            semanticOutcome.modelVersion != null &&
            embedder.modelVersion == semanticOutcome.modelVersion
        ) {
            runCatching { embedder.close() }
            runCatching { System.gc() }
        }

        val candidates = stageOneHits.mapIndexed { index, hit ->
            val fallback = 1f - (index.toFloat() / stageOneHits.size.coerceAtLeast(1))
            hit.id to (hit.score ?: fallback)
        }
        val reranked = applyRerank(
            query = originalRaw,
            candidates = candidates,
            maxToRerank = ACCURACY_RERANK_WINDOW,
            semanticQueryVector = semanticOutcome.queryVector,
            semanticModelVersion = semanticOutcome.modelVersion
        )
        val byId = stageOneHits.associateBy { it.id }
        return reranked.mapNotNull { (id, score) ->
            byId[id]?.copy(score = score)
        }
    }

    /**
     * Content search with smarter ranking. Prefers, in order:
     *  1. Exact phrase appearing in the title
     *  2. Exact phrase appearing in the content
     *  3. All query words appearing in the title (any order)
     *  4. All query words appearing in the content
     *  5. Most query words appearing somewhere (last resort — filtered if too sparse)
     *
     * Adds bonuses for: word-adjacency in the snippet, multiple matches in one
     * document, and matches at word boundaries.
     */
    private suspend fun rankedContentSearch(
        ftsQuery: String,
        originalRaw: String,
        allowImplicitTopicExpansion: Boolean = true
    ): List<SearchHit> {
        // v5.5.12 — Explicit multi-query variants must stay explicit.
        // Otherwise Topics.expandQuery() expands every variant AGAIN and a
        // synonym can masquerade inside the full-trust original-query list.
        // Keep prefix matching either way; only the hidden synonym ORs differ.
        val dbQuery = if (allowImplicitTopicExpansion) {
            Topics.expandQuery(ftsQuery)
        } else {
            Topics.literalPrefixQuery(ftsQuery)
        }
        val ftsHits = dao.search(dbQuery)
        if (ftsHits.isEmpty()) return emptyList()

        // The original (un-quoted) phrase from the user, used for scoring + display.
        val phrase = originalRaw.trim()
            .removeSurrounding("\"")
            .lowercase()
        val tokens = phrase.split(Regex("\\s+"))
            .map { it.replace(Regex("[^\\p{L}\\p{N}]"), "") }
            .filter { it.length >= 2 }
        val tokensLower = tokens.toSet()
        val isMultiWord = tokensLower.size > 1

        data class Scored(val hit: SearchHit, val score: Int)
        val scored = ftsHits.mapNotNull { h ->
            val title = h.title.lowercase()
            val snippet = h.snippet.lowercase()

            // Match-marker count tells us how many distinct hits appeared in the snippet
            // (the FTS snippet() function wraps each match in ⟦…⟧).
            val markerCount = h.snippet.count { it == '\u27E6' }

            val titleHasPhrase = title.contains(phrase)
            val snippetHasPhrase = snippet.contains(phrase)
            val titleTokenHits = tokensLower.count { title.contains(it) }
            val snippetTokenHits = tokensLower.count { snippet.contains(it) }

            // Adjacency: are all the query tokens within a ~10-word window of each other?
            val adjacencyBonus = if (isMultiWord && snippetTokenHits == tokensLower.size) {
                val words = snippet.split(Regex("\\s+"))
                var found = false
                if (words.size >= tokensLower.size) {
                    for (i in 0..(words.size - tokensLower.size)) {
                        val end = minOf(i + 10, words.size)
                        val window = words.subList(i, end).joinToString(" ")
                        if (tokensLower.all { window.contains(it) }) { found = true; break }
                    }
                }
                if (found) 800 else 0
            } else 0

            // Word boundary bonus: phrase appears at a word boundary in the title
            val titleBoundaryBonus = if (isMultiWord && phrase.length >= 3 &&
                Regex("\\b" + Regex.escape(phrase) + "\\b").containsMatchIn(title)) 2_000 else 0

            val score = when {
                titleHasPhrase -> 10_000 + titleBoundaryBonus + markerCount * 50
                snippetHasPhrase -> 5_000 + titleTokenHits * 200 + markerCount * 100 + adjacencyBonus
                isMultiWord && titleTokenHits == tokensLower.size -> 3_500 + adjacencyBonus + markerCount * 50
                isMultiWord && snippetTokenHits == tokensLower.size -> 1_800 + adjacencyBonus + titleTokenHits * 150 + markerCount * 30
                else -> {
                    val total = titleTokenHits + snippetTokenHits
                    // Discard sparse matches — e.g. "ar" matching "art history" when only
                    // one of two query tokens appears.
                    if (isMultiWord && total < (tokensLower.size + 1) / 2) return@mapNotNull null
                    100 + titleTokenHits * 40 + snippetTokenHits * 10 + markerCount * 5
                }
            }
            Scored(h, score)
        }
        return scored
            .sortedByDescending { it.score }
            .take(150)
            .map { it.hit }
    }

    /**
     * Obsidian-style title search: every word in the query must appear somewhere in the
     * title / file name / path, in any order. Exact-phrase matches in the title rank highest.
     */
    private suspend fun titleSearch(raw: String): List<SearchHit> {
        val tokens = raw.split(Regex("\\s+"))
            .map { it.trim() }
            .filter { it.isNotEmpty() }
            .take(6)
        if (tokens.isEmpty()) return emptyList()
        // Pad up to 6 LIKE slots; "%%" matches anything so unused slots are no-ops.
        val pats = (0 until 6).map { i ->
            if (i < tokens.size) "%${tokens[i]}%" else "%%"
        }
        val rows = dao.searchTitlesAllWords(
            pats[0], pats[1], pats[2], pats[3], pats[4], pats[5]
        )
        val phrase = raw.lowercase()
        val tokensLower = tokens.map { it.lowercase() }
        // Score each hit: prefer exact phrase, then more tokens in title vs path
        return rows.asSequence()
            .map { n ->
                val titleLower = n.title.lowercase()
                val pathLower = n.relPath.lowercase()
                val score = when {
                    titleLower.contains(phrase) -> 1_000
                    pathLower.contains(phrase) -> 800
                    else -> {
                        val titleHits = tokensLower.count { titleLower.contains(it) }
                        val pathHits = tokensLower.count { pathLower.contains(it) }
                        titleHits * 10 + pathHits
                    }
                }
                n to score
            }
            .sortedWith(
                compareByDescending<Pair<NoteMeta, Int>> { it.second }
                    .thenBy { it.first.title.lowercase() }
            )
            .take(200)
            .map { (n, _) -> SearchHit(n.id, n.relPath, n.title, "", n.fileType) }
            .toList()
    }

    /** Topic cards whose vocabulary matches the current query (shown above results). */
    val topicMatches: StateFlow<List<TopicCard>> =
        combine(query.debounce(220).map { it.trim() }.distinctUntilChanged(), _topics) { q, topics ->
            if (q.length < 2) emptyList()
            else {
                val keys = Topics.matchQuery(q).toSet()
                topics.filter { it.key in keys }
            }
        }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    init {
        viewModelScope.launch {
            refreshNotes(markLibraryReady = true)
            refreshRecent()
            refreshTopics()
            refreshFavourites(); refreshSuggested()
            runCatching { _recentSearches.value = decodeRecents(prefs.recentSearchesRaw.first()) }
            val uri = prefs.libraryUri.first()
            val storedTopicVersion = prefs.topicVersion.first()
            val storedLinksVersion = prefs.linksVersion.first()
            // v5.4.124cc — Was `_notes.value.isEmpty()`, which conflates two
            // very different situations: "the database genuinely has zero
            // notes" (first-time setup -- a full sync is correct) vs. "the
            // refreshNotes() read above happened to fail/return empty on a
            // transient hiccup" (a full library reindex should NOT be the
            // response to that). A direct count query removes the ambiguity
            // and means the app never auto-triggers a full reindex on start
            // just because an in-memory read glitched.
            val dbNoteCount = runCatching { dao.countNotes() }.getOrElse { -1 }
            when {
                uri != null && dbNoteCount == 0 -> startSync(uri)
                dbNoteCount > 0 -> {
                    if (storedTopicVersion != Topics.VERSION) {
                        reclassifyTopics()
                        prefs.setTopicVersion(Topics.VERSION)
                    }
                    if (storedLinksVersion != Wikilinks.VERSION) {
                        reextractLinks()
                        prefs.setLinksVersion(Wikilinks.VERSION)
                    }
                }
                // dbNoteCount == -1: the count query itself failed. Do
                // nothing rather than guess -- definitely don't kick off a
                // full library reindex on the back of a failed DB read.
            }
        }
    }

    fun setLibrary(uri: Uri) {
        val app = getApplication<Application>()
        try {
            // Request BOTH read and write so we can save imported markdown files
            // back into the library. WRITE is needed by saveImportedMarkdown().
            app.contentResolver.takePersistableUriPermission(
                uri,
                Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_WRITE_URI_PERMISSION
            )
        } catch (_: Exception) {
        }
        viewModelScope.launch(Dispatchers.IO) {
            dao.clearAll()
            runCatching { dao.clearTopics() }
            runCatching { dao.clearLinks() }
            prefs.setLibraryUri(uri.toString())
            _tabs.value = emptyList(); _activeTab.value = null
            _newNotes.value = emptyList()
            refreshNotes(); refreshRecent(); refreshTopics(); refreshFavourites(); refreshSuggested()
            startSync(uri.toString(), trackNewNotes = false)
        }
    }

    fun reindex() {
        val uri = libraryUri.value ?: return
        // forceReconcile = true: this is an explicit, user-initiated
        // "Reindex Library" action, so it's allowed to clean up notes for
        // files that are genuinely gone -- unlike the automatic paths
        // (app start, indexNewFile after a save), which never delete
        // anything. Even here, sync() still refuses to delete if the scan
        // itself hit errors; forceReconcile only overrides the "count
        // dropped a lot" heuristic, not the hard error guard.
        startSync(uri, trackNewNotes = true, forceReconcile = true)
    }

    /**
     * Indexes exactly one newly-saved/imported file, without touching or
     * reconciling any other row in the database. Use this instead of
     * [reindex] whenever the exact file that changed is already known
     * (e.g. right after "Save as Offline HTML" or "Convert to Markdown")
     * -- a full [reindex] rescans and reconciles the WHOLE library, which
     * is both slower and was the trigger for a real data-loss bug (see
     * Indexer.sync's scan-trustworthiness guard). Indexing one known file
     * can never delete or otherwise touch anything else.
     */
    fun indexNewFile(docUri: String, relPath: String) {
        viewModelScope.launch(Dispatchers.IO) {
            val ok = runCatching { indexer.indexSingleFile(docUri, relPath) }.getOrElse { false }
            refreshNotes(); refreshRecent(); refreshTopics(); refreshFavourites(); refreshSuggested()
            runCatching { backfillSavedUrlsFromLibrary() }
            runCatching { backfillTitlesFromLibrary() }
            // v5.5.8 — Every successful targeted index event is forwarded
            // to EmbeddingService. It updates the active model plus every other
            // installed model that already has an ANN index. If a pass is
            // already running, the service coalesces this into one follow-up
            // delta pass rather than dropping the new article.
            if (ok) {
                buildAllEmbeddings()
            }
            runCatching {
                logActivity(
                    com.tebogo.markvault.data.ActivityLog.Category.INDEX_SYNC,
                    if (ok) "Indexed new file: $relPath" else "Failed to index new file: $relPath",
                    emptyMap()
                )
            }
        }
    }

    private fun startSync(uri: String, trackNewNotes: Boolean = false, forceReconcile: Boolean = false) {
        if (_progress.value.running) return
        _progress.value = IndexProgress(true, "Starting\u2026", 0, 0)
        startProtectedTask("library_index", "Indexing library…")
        viewModelScope.launch(Dispatchers.IO) {
            var syncError: Throwable? = null
            try {
                val beforeRelPaths = if (trackNewNotes)
                    runCatching { dao.allMeta().map { it.relPath }.toSet() }.getOrElse { emptySet() }
                else emptySet()
                indexer.sync(uri, forceReconcile = forceReconcile) { p -> _progress.value = p }
                if (trackNewNotes) {
                    val afterAll = runCatching { dao.allMeta() }.getOrElse { emptyList() }
                    _newNotes.value = afterAll.filter { it.relPath !in beforeRelPaths }.take(30)
                }
            } catch (e: Exception) {
                syncError = e
                _progress.value = IndexProgress(false, "Error: ${e.message}", 0, 0)
            }
            refreshNotes(); refreshRecent(); refreshTopics(); refreshFavourites(); refreshSuggested()
            runCatching { prefs.setTopicVersion(Topics.VERSION) }
            runCatching { prefs.setLinksVersion(Wikilinks.VERSION) }

            // v5.5.8 — After every successful library sync, ask the
            // foreground service to synchronize embeddings. The service owns
            // the model routing: active model + all other installed models
            // with an already-built ANN index. Repeated requests while a pass
            // is running are coalesced into one follow-up delta pass, so batch
            // WebViewer saves cannot silently miss later articles.
            if (syncError == null) {
                // Fine to fire from Dispatchers.IO — startForegroundService
                // is thread-safe. The 5-second startForeground deadline
                // starts when EmbeddingService's onCreate lands on Main,
                // not when we post the Intent from here.
                buildAllEmbeddings()
                logActivity(
                    com.tebogo.markvault.data.ActivityLog.Category.EMBED,
                    "Auto-embed/model-index sync triggered after library sync",
                    emptyMap()
                )
            }
            // v5.4.94cc — Log the completion of the index sync itself
            // regardless of whether it triggered an embed pass.
            if (syncError == null) {
                logActivity(
                    com.tebogo.markvault.data.ActivityLog.Category.INDEX_SYNC,
                    "Index sync completed",
                    emptyMap()
                )
                // v5.4.100cc — Refresh the URL cache from the freshly
                // indexed content. Newly imported markdown/HTML notes
                // land in the DB after sync; harvesting them here
                // means their source URLs are already in the dedup
                // cache before the user's next batch save runs.
                backfillSavedUrlsFromLibrary()
                // v5.4.102cc — Same reasoning for title/filename
                // caches: any new files that landed during the sync
                // need to be in the dedup pools before the user's
                // next batch save fires.
                backfillTitlesFromLibrary()
            } else {
                logActivity(
                    com.tebogo.markvault.data.ActivityLog.Category.INDEX_SYNC,
                    "Index sync failed",
                    mapOf("error" to (syncError.message ?: "unknown"))
                )
            }
            stopProtectedTask("library_index")
        }
    }

    /** Re-tag every already-indexed note using the current lexicon (no file re-scan). */
    private suspend fun reclassifyTopics() {
        val total = runCatching { dao.countNotes() }.getOrElse { 0 }
        if (total == 0) return
        _progress.value = IndexProgress(true, "Updating topics\u2026", 0, total)
        runCatching { dao.clearTopics() }
        val pageSize = 300
        var offset = 0
        var done = 0
        while (offset < total) {
            val page = runCatching { dao.notesTextPage(pageSize, offset) }.getOrElse { emptyList() }
            if (page.isEmpty()) break
            for (nt in page) {
                val topics = runCatching { Topics.classify(nt.title, nt.content) }.getOrElse { emptyList() }
                if (topics.isNotEmpty()) {
                    runCatching { dao.insertTopics(topics.map { NoteTopic(nt.id, it.first, it.second) }) }
                }
                done++
            }
            offset += pageSize
            _progress.value = IndexProgress(true, "Updating topics\u2026", done, total)
        }
        _progress.value = IndexProgress(false, "Done", total, total)
        refreshTopics()
    }

    /**
     * Re-run the wikilink/markdown-link extractor across every note's stored content.
     * Used after the extractor version bumps (e.g. when markdown-style `[label](file.md)` support
     * is added) so existing notes get the new edges without forcing a full file re-read.
     */
    private suspend fun reextractLinks() {
        val total = runCatching { dao.countNotes() }.getOrElse { 0 }
        if (total == 0) return
        _progress.value = IndexProgress(true, "Updating links\u2026", 0, total)
        runCatching { dao.clearLinks() }
        val pageSize = 300
        var offset = 0
        var done = 0
        while (offset < total) {
            val page = runCatching { dao.notesTextPage(pageSize, offset) }.getOrElse { emptyList() }
            if (page.isEmpty()) break
            for (nt in page) {
                val targets = runCatching { Wikilinks.extract(nt.content) }.getOrElse { emptyList() }
                if (targets.isNotEmpty()) {
                    val rows = targets.map { NoteLink(nt.id, it, Wikilinks.normalize(it)) }
                    runCatching { dao.insertLinks(rows) }
                }
                done++
            }
            offset += pageSize
            _progress.value = IndexProgress(true, "Updating links\u2026", done, total)
        }
        _progress.value = IndexProgress(false, "Done", total, total)
    }

    private suspend fun refreshNotes(markLibraryReady: Boolean = false) {
        val loaded = runCatching { dao.allMeta() }
        loaded.onSuccess { rows ->
            _notes.value = rows
            if (markLibraryReady) _libraryReady.value = true
        }
    }

    private suspend fun refreshRecent() {
        _recent.value = runCatching { dao.recentNotes() }.getOrElse { emptyList() }
    }

    private suspend fun refreshTopics() {
        val counts = runCatching { dao.topicCounts() }.getOrElse { emptyList() }
            .associate { it.topic to it.cnt }
        _topics.value = Topics.ALL.mapNotNull { d ->
            val c = counts[d.key] ?: 0
            if (c > 0) TopicCard(d.key, d.emoji, d.label, c) else null
        }.sortedByDescending { it.count }
    }

    private suspend fun refreshFavourites() {
        val favs = runCatching { dao.favouriteNotes() }.getOrElse { emptyList() }
        _favouriteIds.value = favs.map { it.id }.toSet()
        _favouriteNotes.value = favs
    }

    private suspend fun refreshSuggested() {
        // Hide notes opened in the last ~3 weeks; if the user has no reading history
        // (or no topic overlap), fall back to random unopened notes.
        val cutoff = System.currentTimeMillis() - 21L * 24L * 60L * 60L * 1000L
        val topicBased = runCatching { dao.suggestedNotes(cutoff, 25) }.getOrElse { emptyList() }
        _suggested.value = if (topicBased.size >= 6) topicBased
        else runCatching { dao.randomUnopened(25) }.getOrElse { topicBased }
    }

    fun toggleFavourite(id: Long) {
        viewModelScope.launch(Dispatchers.IO) {
            val isCurrentlyFav = _favouriteIds.value.contains(id)
            runCatching { dao.setFavourite(id, if (isCurrentlyFav) 0 else 1) }
            refreshFavourites(); refreshSuggested()
        }
    }

    suspend fun loadTopicNotes(key: String): List<NoteMeta> =
        runCatching { dao.notesInTopic(key) }.getOrElse { emptyList() }

    /** Resolve an Obsidian-style `[[target]]` to a note in the library, or null if not found. */
    suspend fun resolveWikilink(target: String): LinkedNote? {
        val norm = Wikilinks.normalize(target)
        if (norm.isEmpty()) return null
        return runCatching { dao.resolveLink(norm, Wikilinks.withMd(norm)) }.getOrNull()
    }

    /**
     * Resolves an `![[Note]]` embed target to that note's full raw
     * content, for [com.tebogo.markvault.markdown.MarkdownEngine]'s embed
     * expansion. Reuses [resolveWikilink]'s title/filename/relPath
     * matching, then fetches the full row since resolveWikilink only
     * returns a lightweight id/title projection.
     */
    suspend fun resolveEmbedContent(target: String): String? {
        val hit = resolveWikilink(target) ?: return null
        return runCatching { dao.byId(hit.id)?.content }.getOrNull()
    }

    /** Notes whose body contains `[[<this note>]]` — i.e. backlinks. */
    suspend fun loadBacklinks(noteId: Long): List<LinkedNote> {
        val n = runCatching { dao.byId(noteId) }.getOrNull() ?: return emptyList()
        // A backlink could write the target as the title, the file name (with or without .md), or the relPath
        val candidates = LinkedHashSet<String>()
        candidates.add(Wikilinks.normalize(n.title))
        candidates.add(Wikilinks.normalize(n.name))
        candidates.add(Wikilinks.normalize(n.name.removeSuffix(".md").removeSuffix(".MD")
            .removeSuffix(".markdown").removeSuffix(".MARKDOWN")))
        candidates.add(Wikilinks.normalize(n.relPath))
        val list = candidates.filter { it.isNotEmpty() }
        if (list.isEmpty()) return emptyList()
        return runCatching { dao.backlinksFor(list) }.getOrElse { emptyList() }
            .filter { it.id != noteId }
    }

    /** Outgoing wikilinks from this note that point to existing notes. */
    suspend fun loadForwardLinks(noteId: Long): List<LinkedNote> =
        runCatching { dao.forwardLinksFor(noteId) }.getOrElse { emptyList() }
            .filter { it.id != noteId }

    /**
     * Fast count of total connections (forward links + backlinks) for a note.
     * Used to badge the Reader header so the user sees how connected the article is at a glance.
     */
    suspend fun connectionCount(noteId: Long): Int {
        val n = runCatching { dao.byId(noteId) }.getOrNull() ?: return 0
        val candidates = LinkedHashSet<String>().apply {
            add(Wikilinks.normalize(n.title))
            add(Wikilinks.normalize(n.name))
            add(Wikilinks.normalize(n.name.removeSuffix(".md").removeSuffix(".MD")
                .removeSuffix(".markdown").removeSuffix(".MARKDOWN")))
            add(Wikilinks.normalize(n.relPath))
        }.filter { it.isNotEmpty() }
        val forwards = runCatching { dao.forwardLinkCount(noteId) }.getOrElse { 0 }
        val backs = if (candidates.isEmpty()) 0
            else runCatching { dao.backlinkCount(candidates, noteId) }.getOrElse { 0 }
        return forwards + backs
    }

    /** The note with the most total connections in the library (best starting anchor for the graph). */
    suspend fun mostConnectedNote(): LinkedNote? =
        runCatching { dao.mostConnectedNote() }.getOrNull()

    /**
     * Build a 2-degree connection graph around [centerId]. Returns the focus note, its 1st-degree
     * neighbours (capped), and 2nd-degree neighbours (capped). Connection direction is preserved
     * so the UI can draw incoming vs outgoing edges differently.
     */
    suspend fun buildFocusGraph(centerId: Long, allowedIds: Set<Long>? = null): FocusGraph? {
        if (allowedIds != null && centerId !in allowedIds) return null
        val centerNote = runCatching { dao.byId(centerId) }.getOrNull() ?: return null
        val center = LinkedNote(centerNote.id, centerNote.title, centerNote.folder)

        // Graph-only group filtering. The note/link index itself is never changed.
        val forwards = loadForwardLinks(centerId).filter { allowedIds == null || it.id in allowedIds }
        val backs = loadBacklinks(centerId).filter { allowedIds == null || it.id in allowedIds }

        // Combined first-ring nodes (uniqued by id), with link direction tagged.
        // outgoing = center -> node, incoming = node -> center, both = bidirectional.
        val firstRingMap = LinkedHashMap<Long, GraphNeighbour>()
        for (f in forwards) firstRingMap[f.id] = GraphNeighbour(f, LinkDir.OUTGOING)
        for (b in backs) {
            val existing = firstRingMap[b.id]
            firstRingMap[b.id] = if (existing != null) existing.copy(dir = LinkDir.BOTH)
            else GraphNeighbour(b, LinkDir.INCOMING)
        }
        val firstRing = firstRingMap.values.toList().take(MAX_FIRST_RING)
        val firstRingIds = firstRing.map { it.note.id }.toSet() + centerId

        // Second-ring nodes: anything 1° neighbours link to/from, minus already-shown nodes.
        val secondRingMap = LinkedHashMap<Long, GraphEdge>()
        for (n in firstRing) {
            val ff = loadForwardLinks(n.note.id).filter { allowedIds == null || it.id in allowedIds }
            val bb = loadBacklinks(n.note.id).filter { allowedIds == null || it.id in allowedIds }
            for (x in ff) {
                if (x.id in firstRingIds) continue
                if (secondRingMap.size >= MAX_SECOND_RING && x.id !in secondRingMap) continue
                if (x.id !in secondRingMap) secondRingMap[x.id] = GraphEdge(x, n.note.id)
            }
            for (x in bb) {
                if (x.id in firstRingIds) continue
                if (secondRingMap.size >= MAX_SECOND_RING && x.id !in secondRingMap) continue
                if (x.id !in secondRingMap) secondRingMap[x.id] = GraphEdge(x, n.note.id)
            }
        }
        val secondRing = secondRingMap.values.toList()

        return FocusGraph(
            center = center,
            firstRing = firstRing,
            secondRing = secondRing,
            firstRingTotal = firstRingMap.size,
            secondRingTotal = -1 // unknown without re-counting; UI can show "+more" if needed
        )
    }

    /** Open an article in a tab (reusing it if already open) and make it active. */
    /** How an article was last opened — drives the small badge on the recents/history list. */
    private val _recentOpenSources = MutableStateFlow<Map<Long, OpenSource>>(emptyMap())
    val recentOpenSources: StateFlow<Map<Long, OpenSource>> = _recentOpenSources

    /**
     * Open an article in a tab (reusing it if already open) and make it active.
     * [source] records WHY we're opening it (e.g. from a wikilink) so the home screen can
     * badge it in the recently-opened list.
     */
    fun openArticle(id: Long, title: String, source: OpenSource = OpenSource.DIRECT, fileType: String = "md") {
        // v5.4.205cc — Auto-highlight verse(s) when opening an HTML article from
        // search results whose query is a scripture reference. Supports ranges
        // (24:7-9 → 3 anchors) and lists (23:8,10 → 2 anchors). All matched
        // verses are highlighted permanently in the opened article.
        if (fileType.equals("html", ignoreCase = true) ||
            fileType.equals("mhtml", ignoreCase = true)) {
            val parsed = com.tebogo.markvault.util.ScriptureDetector
                .parseQueryAsScripture(query.value)
            if (parsed != null) {
                val (bn, ch, verseRef) = parsed
                val anchors = com.tebogo.markvault.util.ScriptureDetector
                    .buildVerseAnchors(bn, ch, verseRef)
                if (anchors.isNotEmpty()) {
                    setPendingScriptureAnchor(anchors.joinToString(","))
                }
            }
        }
        val list = _tabs.value.toMutableList()
        val existing = list.indexOfFirst { it.id == id }
        if (existing < 0) {
            list.add(TabInfo(id, title, fileType))
            while (list.size > maxTabs) {
                val drop = list.firstOrNull { it.id != id && it.id !in workspacePinnedTabIds.value }
                    ?: list.firstOrNull { it.id != id }
                if (drop != null) {
                    list.remove(drop)
                    // Also strip the dropped tab from the visit history so back doesn't try to return there
                    _tabHistory.value = _tabHistory.value.filter { it != drop.id }
                } else break
            }
            _tabs.value = list
        }
        _activeTab.value = id
        pushHistory(id)
        // Update source map: keep a small rolling window so it doesn't grow without bound
        val cur = _recentOpenSources.value.toMutableMap()
        cur[id] = source
        if (cur.size > 60) {
            // Trim oldest by recents ordering would be ideal but we don't have timestamps here;
            // simple cap keeps memory bounded.
            val drop = cur.keys.first()
            cur.remove(drop)
        }
        _recentOpenSources.value = cur
        viewModelScope.launch { refreshRecent() }
    }

    fun setActiveTab(id: Long) {
        _activeTab.value = id
        pushHistory(id)
    }

    fun closeTab(id: Long) {
        val list = _tabs.value.toMutableList()
        val idx = list.indexOfFirst { it.id == id }
        if (idx < 0) return
        val closed = list.removeAt(idx)
        rememberClosedTab(closed)
        _tabs.value = list
        // Drop every occurrence of the closed tab from history
        _tabHistory.value = _tabHistory.value.filter { it != id }
        if (_activeTab.value == id) {
            val newActive = list.getOrNull(idx.coerceAtMost(list.size - 1))?.id
            _activeTab.value = newActive
            if (newActive != null) pushHistory(newActive)
        }
        persistReaderTabsSession()
    }

    /** Move an open reader tab by one slot. Used by long-press drag and the tab menu. */
    fun moveTab(id: Long, direction: Int) {
        if (direction == 0) return
        val list = _tabs.value.toMutableList()
        val from = list.indexOfFirst { it.id == id }
        if (from < 0) return
        val step = if (direction > 0) 1 else -1
        val to = (from + step).coerceIn(0, list.lastIndex)
        if (to == from) return
        val tab = list.removeAt(from)
        list.add(to, tab)
        _tabs.value = list
        persistReaderTabsSession()
    }

    /** Restore a recently-closed article tab and focus it. */
    fun reopenClosedTab(id: Long) {
        val tab = _recentlyClosedTabs.value.firstOrNull { it.id == id } ?: return
        _recentlyClosedTabs.value = _recentlyClosedTabs.value.filterNot { it.id == id }
        openArticle(tab.id, tab.title, fileType = tab.fileType)
        persistReaderTabsSession()
    }

    /** Close every tab to the right of [id], preserving [id] and everything before it. */
    fun closeTabsToRight(id: Long) {
        val list = _tabs.value
        val idx = list.indexOfFirst { it.id == id }
        if (idx < 0 || idx >= list.lastIndex) return
        list.drop(idx + 1).forEach(::rememberClosedTab)
        val kept = list.take(idx + 1)
        _tabs.value = kept
        val keptIds = kept.mapTo(mutableSetOf()) { it.id }
        _tabHistory.value = _tabHistory.value.filter { it in keptIds }
        if (_activeTab.value !in keptIds) {
            _activeTab.value = id
            pushHistory(id)
        }
        persistReaderTabsSession()
    }

    /** Close every open tab. Used by the tab-management bottom sheet. */
    fun closeAllTabs() {
        _tabs.value.asReversed().forEach(::rememberClosedTab)
        _tabs.value = emptyList()
        _tabHistory.value = emptyList()
        _activeTab.value = null
        persistReaderTabsSession()
    }

    /** Close every tab except the given one. Convenient when the user picks one in the grid. */
    fun closeOtherTabs(keepId: Long) {
        val keep = _tabs.value.firstOrNull { it.id == keepId } ?: return
        _tabs.value.filterNot { it.id == keepId }.asReversed().forEach(::rememberClosedTab)
        _tabs.value = listOf(keep)
        _tabHistory.value = listOf(keepId)
        _activeTab.value = keepId
        persistReaderTabsSession()
    }

    suspend fun loadNote(id: Long): Note? {
        val n = dao.byId(id)
        if (n != null) {
            runCatching { dao.touch(id, System.currentTimeMillis()) }
            refreshRecent()
        }
        return n
    }

    /**
     * Return the SAF content URI string for a PDF note so the PdfReaderScreen can open it.
     * Also touches the "lastOpened" timestamp so it appears in recents.
     */
    suspend fun loadPdfUri(id: Long): String? {
        val n = dao.byId(id) ?: return null
        if (n.fileType != "pdf") return null
        runCatching { dao.touch(id, System.currentTimeMillis()) }
        refreshRecent()
        return n.uri
    }

    /** Look up the fileType for a note ID — used to decide which viewer to open. */
    suspend fun fileTypeOf(id: Long): String =
        runCatching { dao.byId(id)?.fileType }.getOrNull() ?: "md"

    /* ──────────────────────────────────────────────────────────────────────
     *  PDF text cache (per page) — used by in-PDF search for instant queries
     *  on second/third open. Re-extracted whenever the source file changes.
     * ────────────────────────────────────────────────────────────────────── */

    /** Returns cached page text iff it matches the source file's current lastModified. */
    suspend fun cachedPdfPageText(noteId: Long): Map<Int, String>? {
        val note = runCatching { dao.byId(noteId) }.getOrNull() ?: return null
        val stamp = runCatching { dao.pdfPageTextStamp(noteId) }.getOrNull() ?: return null
        if (stamp != note.lastModified) return null
        val rows = runCatching { dao.loadPdfPageText(noteId) }.getOrNull() ?: return null
        if (rows.isEmpty()) return null
        return rows.associate { it.pageIndex to it.text }
    }

    /** Persists the extracted text so future opens skip extraction. */
    suspend fun savePdfPageText(noteId: Long, pages: Map<Int, String>) {
        val note = runCatching { dao.byId(noteId) }.getOrNull() ?: return
        val rows = pages.entries.map { (i, t) ->
            PdfPageText(noteId, i, t, note.lastModified)
        }
        runCatching {
            dao.clearPdfPageText(noteId)
            dao.savePdfPageText(rows)
        }
    }

    /* ── PDF annotations ── */

    suspend fun loadAnnotation(noteId: Long, page: Int): String? =
        runCatching { dao.loadAnnotation(noteId, page)?.paths }.getOrNull()

    suspend fun loadAllAnnotations(noteId: Long): Map<Int, String> =
        runCatching {
            dao.loadAnnotationsForNote(noteId).associate { it.pageIndex to it.paths }
        }.getOrElse { emptyMap() }

    suspend fun saveAnnotation(noteId: Long, page: Int, pathsJson: String) {
        runCatching {
            if (pathsJson.isBlank() || pathsJson == "[]") dao.deleteAnnotation(noteId, page)
            else dao.saveAnnotation(PdfAnnotation(noteId, page, pathsJson))
        }
    }

    suspend fun clearAllAnnotations(noteId: Long) {
        runCatching { dao.deleteAllAnnotationsForNote(noteId) }
    }

    /* ── PDF view history (internal + external) ── */

    /** Record that a PDF was opened. Called on every PDF open from any path. */
    fun recordPdfView(uri: String, title: String, noteId: Long, isExternal: Boolean) {
        viewModelScope.launch(Dispatchers.IO) {
            runCatching {
                dao.deletePdfHistoryByUri(uri)
                dao.insertPdfHistory(PdfHistoryEntry(
                    uri = uri, title = title, noteId = noteId, isExternal = isExternal
                ))
            }
        }
    }

    suspend fun loadPdfHistory(limit: Int = 100): List<PdfHistoryEntry> =
        runCatching { dao.recentPdfHistory(limit) }.getOrElse { emptyList() }

    fun deletePdfHistoryEntry(id: Long) {
        viewModelScope.launch(Dispatchers.IO) { runCatching { dao.deletePdfHistory(id) } }
    }

    fun clearPdfHistory() {
        viewModelScope.launch(Dispatchers.IO) { runCatching { dao.clearPdfHistory() } }
    }

    /* ── Web history (in-app browser visits) ── */

    fun recordWebVisit(url: String, title: String) {
        if (url.isBlank()) return
        viewModelScope.launch(Dispatchers.IO) {
            runCatching {
                val host = runCatching { android.net.Uri.parse(url).host ?: "" }.getOrElse { "" }
                dao.deleteWebHistoryByUrl(url)   // dedupe by URL — keep newest only
                dao.insertWebHistory(WebHistoryEntry(
                    url = url, title = title.ifBlank { url }, host = host
                ))
            }
        }
    }

    suspend fun loadWebHistory(limit: Int = 200): List<WebHistoryEntry> =
        runCatching { dao.recentWebHistory(limit) }.getOrElse { emptyList() }

    fun deleteWebHistoryEntry(id: Long) {
        viewModelScope.launch(Dispatchers.IO) { runCatching { dao.deleteWebHistory(id) } }
    }

    fun clearWebHistory() {
        viewModelScope.launch(Dispatchers.IO) { runCatching { dao.clearWebHistory() } }
    }

    /* ── Persistent in-app browser session (TASK 4) ──
     * The tab list lives here on the VM so when the user navigates away to read
     * a markdown note or a PDF and comes back to the browser, their tabs are
     * still there. The WebView itself is recreated each time (Compose can't
     * persist a native view across screen changes without a custom host), but
     * the URLs + titles + which tab was active are preserved verbatim.
     */
    val webTabs: androidx.compose.runtime.snapshots.SnapshotStateList<com.tebogo.markvault.ui.WebTab> =
        androidx.compose.runtime.mutableStateListOf()
    var webActiveTabIdx: Int by androidx.compose.runtime.mutableStateOf(0)
        private set

    /**
     * v5.3.1 — Thumbnail cache for the tabs preview overlay (Chrome-style).
     *
     * Keyed by [WebTab.id]. Each value is a downscaled JPEG so the
     * memory footprint stays modest (~50–150 KB per tab × ~10 tabs).
     * Captured lazily on `onPageFinished` and any time the user switches
     * away from a tab. Cleared automatically when a tab is closed.
     *
     * Backed by SnapshotStateMap so [TabPreviewCard] recomposes
     * automatically when a fresh thumbnail lands.
     */
    val webTabThumbnails: androidx.compose.runtime.snapshots.SnapshotStateMap<Long, ByteArray> =
        androidx.compose.runtime.mutableStateMapOf()

    /**
     * Capture [view] (typically the active WebView) into a downscaled
     * JPEG and store it under [tabId]. Safe to call on any thread; the
     * actual draw call is bounced onto the main thread because WebView
     * draws must happen on the UI thread.
     */
    fun saveWebTabThumbnail(tabId: Long, view: android.view.View) {
        if (view.width <= 0 || view.height <= 0) return
        try {
            // Downsample to ~360 px wide. Preserves aspect ratio.
            val targetW = 360
            val scale = targetW.toFloat() / view.width.toFloat()
            val targetH = (view.height * scale).toInt().coerceAtLeast(1)
            val bmp = android.graphics.Bitmap.createBitmap(
                targetW, targetH, android.graphics.Bitmap.Config.RGB_565
            )
            val canvas = android.graphics.Canvas(bmp)
            canvas.scale(scale, scale)
            view.draw(canvas)
            val baos = java.io.ByteArrayOutputStream()
            bmp.compress(android.graphics.Bitmap.CompressFormat.JPEG, 70, baos)
            webTabThumbnails[tabId] = baos.toByteArray()
            bmp.recycle()
        } catch (t: Throwable) {
            // Thumbnail capture should never crash anything else.
        }
    }

    /**
     * Ensure the browser has at least one tab loaded with [initialUrl].
     *
     * v5.4.35 — Previous implementation silently ignored the URL when
     * tabs already existed. This was the root cause of the "stuck first
     * link" bug: clicking a second scripture from an offline HTML article
     * navigated to the browser but the old tab stayed active. Now we
     * always route the requested URL through [openInBrowser] so a tab
     * matching it is activated (or a new one created).
     */
    fun ensureBrowserSession(initialUrl: String, initialLabel: String = "jw.org") {
        if (webTabs.isEmpty()) {
            // v5.4.105cc — Restore the persisted tab list first. If a
            // previous session left tabs, re-open them and switch to
            // whatever was active. The incoming initialUrl is
            // routed through openInBrowser so it either activates a
            // matching restored tab or opens as a new one — matches
            // the "already have tabs" branch below.
            val restored = pendingRestoredWebTabs.value
            if (restored.isNotEmpty()) {
                for (r in restored) {
                    if (r.url.isBlank()) continue
                    webTabs.add(
                        WebTab(System.currentTimeMillis() + webTabs.size, r.url, r.title)
                    )
                }
                if (webTabs.isNotEmpty()) {
                    val savedIdx = pendingRestoredWebActiveIdx.value
                    webActiveTabIdx = savedIdx.coerceIn(0, webTabs.lastIndex)
                }
                consumeRestoredWebTabs()
                // v5.4.113cc — If the incoming URL is the same as the
                // restored active tab (the cold-start resume case,
                // where we navigate in with the active tab's own URL
                // precisely to trigger this restore), do NOT re-open
                // it — that would either duplicate the tab (new-tab
                // mode) or clobber the tab's title (same-tab mode).
                // Only treat the incoming URL as a real navigation if
                // it differs from the active tab, which happens when
                // the user taps a NEW link that lands here while tabs
                // were somehow empty.
                val activeUrl = webTabs.getOrNull(webActiveTabIdx)?.url
                val incomingIsActive = initialUrl.isNotBlank() &&
                    activeUrl != null &&
                    canonicalizeUrl(initialUrl) == canonicalizeUrl(activeUrl)
                if (initialUrl.isNotBlank() && !incomingIsActive) {
                    val newTab = runBlocking { prefs.openLinksInNewTab.first() }
                    if (newTab) {
                        openInBrowser(initialUrl, initialLabel)
                    } else {
                        val idx = webActiveTabIdx.coerceIn(webTabs.indices)
                        webTabs[idx] = webTabs[idx].copy(
                            url = initialUrl, title = initialLabel
                        )
                    }
                }
                return
            }
            webTabs.add(WebTab(System.currentTimeMillis(), initialUrl, initialLabel))
            webActiveTabIdx = 0
            persistWebTabsSession()
        } else {
            // Tabs exist — honour the user's preference.
            val newTab = runBlocking { prefs.openLinksInNewTab.first() }
            if (newTab) {
                openInBrowser(initialUrl, initialLabel)
            } else {
                // Same-tab mode: update the active tab's URL in place so the
                // WebView in WebSearchScreen picks it up on recomposition.
                val idx = webActiveTabIdx.coerceIn(webTabs.indices)
                webTabs[idx] = webTabs[idx].copy(url = initialUrl, title = initialLabel)
                persistWebTabsSession()
            }
        }
    }

    // ── v4.12.0 — Pending web-open ──────────────────────────────────────────
    //
    // Before v4.12, tapping a row in Web History navigated to the browser
    // route, but [ensureBrowserSession] silently did nothing when tabs were
    // already open — so the requested URL was effectively ignored and the
    // user was returned to whatever tab they had last. The "history is not
    // clickable" bug the user reported.
    //
    // The fix decouples the URL from the navigation route: history (or any
    // other caller) writes the target into [pendingWebOpen], navigates to the
    // browser, and the browser consumes the pending request on first
    // composition. [openInBrowser] either switches to an existing tab that
    // already shows the URL or opens it in a new tab.

    private val _pendingWebOpen =
        MutableStateFlow<Pair<String, String>?>(null)
    /** A `(url, label)` pair set by callers (e.g. Web History) that want the browser to open a specific page. */
    val pendingWebOpen: StateFlow<Pair<String, String>?> = _pendingWebOpen

    /** Request that the browser open [url] with display [label] on its next composition. */
    fun requestWebOpen(url: String, label: String) {
        _pendingWebOpen.value = url to label
    }

    /**
     * Read and clear the pending web-open request, if any. Returns null when
     * nothing was pending. Called by [WebSearchScreen] in its
     * `LaunchedEffect(Unit)` to honour any history tap that triggered the
     * navigation.
     */
    fun consumePendingWebOpen(): Pair<String, String>? {
        val v = _pendingWebOpen.value
        if (v != null) _pendingWebOpen.value = null
        return v
    }

    /**
     * Open [url] in the browser. If a tab already shows it, switch to that
     * tab (preserves its back/forward stack and scroll position); otherwise
     * append a fresh tab. Either way the new active index is updated so the
     * UI rerenders to the right page.
     */
    fun openInBrowser(url: String, label: String) {
        val existingIdx = webTabs.indexOfFirst { it.url == url }
        if (existingIdx >= 0) {
            webActiveTabIdx = existingIdx
            persistWebTabsSession()
            return
        }
        webTabs.add(WebTab(System.currentTimeMillis(), url, label))
        webActiveTabIdx = webTabs.size - 1
        persistWebTabsSession()
    }

    fun setWebActiveTab(idx: Int) {
        if (idx in webTabs.indices) {
            webActiveTabIdx = idx
            persistWebTabsSession()
        }
    }

    fun addBrowserTab(url: String = "https://www.jw.org/en/", title: String = "New tab") {
        webTabs.add(WebTab(System.currentTimeMillis(), url, title))
        webActiveTabIdx = webTabs.size - 1
        persistWebTabsSession()
    }

    /** Returns true if the caller should also pop back (last tab was closed). */
    fun closeBrowserTab(idx: Int): Boolean {
        if (idx !in webTabs.indices) return false
        val closedId = webTabs[idx].id

        // v5.4.278cc — Make the logical tab disappear FIRST. WebView.destroy()
        // can take a noticeable amount of time on the UI thread while Chromium
        // tears down a busy page. Removing the tab before native teardown makes
        // the close button respond immediately, then the detached WebView is
        // destroyed on the next main-loop turn.
        webTabs.removeAt(idx)
        webTabThumbnails.remove(closedId)
        val lastClosed = webTabs.isEmpty()
        webActiveTabIdx = when {
            lastClosed -> 0
            webActiveTabIdx >= webTabs.size -> webTabs.size - 1
            webActiveTabIdx > idx -> webActiveTabIdx - 1
            else -> webActiveTabIdx
        }
        persistWebTabsSession()
        destroyWebViewSessionDeferred("tab_$closedId")
        return lastClosed
    }

    /** v5.4.35 — Close ALL browser tabs at once. Destroys every
     *  persistent WebView session and clears thumbnails. Returns true
     *  so the caller knows to pop back to the previous screen. */
    fun closeAllBrowserTabs(): Boolean {
        val ids = webTabs.map { it.id }
        webTabs.clear()
        webTabThumbnails.clear()
        webActiveTabIdx = 0
        persistWebTabsSession()
        // Same immediate-UI rule as single-tab close: logical state is already
        // empty before Chromium teardown begins.
        ids.forEach { destroyWebViewSessionDeferred("tab_$it") }
        return true
    }

    // ── v4.13.0 — Persistent WebView session pool ───────────────────────────
    //
    // Goal: scroll position, form inputs, and JavaScript state SURVIVE
    //   • popup ↔ full-screen-popup toggling
    //   • bottom-bar browser-icon taps after navigating away and back
    //   • Compose-level navigation in general
    //
    // Mechanism: WebView instances are owned by the VM (lifetime = VM lifetime),
    // looked up by a stable session ID. Composables call
    // [getOrCreateWebViewSession] in their AndroidView `factory` lambda,
    // detach from any prior parent with `(view.parent as? ViewGroup)?.removeView`,
    // and attach to the new ViewGroup. The next time the screen mounts, the
    // SAME WebView is returned and re-attached — its state is intact.
    //
    // Session IDs:
    //   - "popup"       — the link-popup browser (one WebView, shared between
    //                     WebPopupSheet and WebPopupFullScreen)
    //   - "tab_{tabId}" — each tabbed-browser tab in WebSearchScreen
    //
    // Context-leak note: WebView captures the Activity context. For this app
    // the VM is bound to MainActivity, and [onCleared] destroys every WebView
    // when the VM goes away. Configuration changes (rotation) can produce a
    // brief leak window in theory; not a real issue in practice for this app.

    private val webViewSessions =
        mutableMapOf<String, com.tebogo.markvault.ui.SelectionWebView>()

    // Tracks the most recent explicit navigation serial handled by persistent
    // floating-popup sessions. A serial changes only when the user/app requests
    // a NEW link; resize/minimize/maximize/remount does not change it.
    private val webViewSessionNavigationSerials = mutableMapOf<String, Long>()

    /**
     * v5.3.1 — Return the currently-active browser tab's WebView, if it
     * exists in the session pool. Used by the tabs preview overlay to
     * grab a fresh thumbnail of the page right before showing the grid
     * (so the active card isn't stale). Returns null when there's no
     * active tab or its session hasn't been created yet.
     */
    fun peekActiveWebView(): com.tebogo.markvault.ui.SelectionWebView? {
        val activeId = webTabs.getOrNull(webActiveTabIdx)?.id ?: return null
        return webViewSessions["tab_$activeId"]
    }

    /**
     * Look up an existing WebView for [sessionId], creating one if needed.
     * The returned WebView is bare — callers wire up `webViewClient`,
     * settings, and selection-menu callbacks themselves on every mount
     * because those references close over Composable state that goes stale
     * across recompositions.
     *
     * @param context Activity context (LocalContext.current from a Composable).
     */
    fun getOrCreateWebViewSession(
        sessionId: String,
        context: android.content.Context
    ): com.tebogo.markvault.ui.SelectionWebView {
        webViewSessions[sessionId]?.let { return it }
        val webView = com.tebogo.markvault.ui.SelectionWebView(context)
        webViewSessions[sessionId] = webView
        return webView
    }

    /** v5.4.272cc — Non-creating lookup used by floating-popup Back handling. */
    fun peekWebViewSession(sessionId: String): com.tebogo.markvault.ui.SelectionWebView? =
        webViewSessions[sessionId]

    /**
     * Returns true exactly once for each new floating-popup navigation serial.
     * This keeps WebView redirects independent from Compose remount decisions.
     */
    fun shouldHandleWebViewNavigationSerial(sessionId: String, serial: Long): Boolean {
        val previous = webViewSessionNavigationSerials.put(sessionId, serial)
        return previous != serial
    }

    /**
     * Destroy a specific session's WebView. Use when the corresponding logical
     * thing (e.g. a browser tab) is closed by the user. Detaches from any
     * parent and frees native resources.
     *
     * v5.4.236cc — Thorough cleanup sequence before destroy(): stopLoading
     * halts any in-flight network/JS activity, loadUrl("about:blank")
     * releases the current page's DOM/JS heap before the WebView itself
     * goes away, clearHistory drops the back/forward stack. This is
     * intentionally scoped to explicit tab-close (and destroyAllWebViewSessions
     * below) — NOT to every screen dispose, which would destroy the
     * persistent WebView pool this app deliberately built so tabs survive
     * navigating away and back.
     */
    fun destroyWebViewSession(sessionId: String) {
        webViewSessionNavigationSerials.remove(sessionId)
        val w = webViewSessions.remove(sessionId) ?: return
        runCatching {
            w.stopLoading()
            w.loadUrl("about:blank")
            w.clearHistory()
        }
        (w.parent as? android.view.ViewGroup)?.removeView(w)
        runCatching { w.removeAllViews() }
        runCatching { w.destroy() }
    }

    /**
     * v5.4.278cc — Remove a session from MarkVault immediately, then destroy
     * its Chromium resources on the next main-loop turn. This is used only for
     * explicit tab closes, where UI responsiveness is more important than
     * synchronously waiting for WebView.destroy().
     */
    private fun destroyWebViewSessionDeferred(sessionId: String) {
        webViewSessionNavigationSerials.remove(sessionId)
        val w = webViewSessions.remove(sessionId) ?: return
        (w.parent as? android.view.ViewGroup)?.removeView(w)
        android.os.Handler(android.os.Looper.getMainLooper()).post {
            runCatching { w.stopLoading() }
            runCatching { w.loadUrl("about:blank") }
            runCatching { w.clearHistory() }
            runCatching { w.removeAllViews() }
            runCatching { w.destroy() }
        }
    }

    /** Destroy every WebView in the pool. Called automatically on VM clear. */
    private fun destroyAllWebViewSessions() {
        for (w in webViewSessions.values) {
            runCatching {
                w.stopLoading()
                w.loadUrl("about:blank")
                w.clearHistory()
            }
            (w.parent as? android.view.ViewGroup)?.removeView(w)
            runCatching { w.removeAllViews() }
            runCatching { w.destroy() }
        }
        webViewSessions.clear()
        webViewSessionNavigationSerials.clear()
    }

    /** Update tab URL/title after a page finishes loading. */
    fun updateBrowserTab(idx: Int, url: String? = null, title: String? = null) {
        if (idx !in webTabs.indices) return
        val cur = webTabs[idx]
        webTabs[idx] = cur.copy(
            url = url ?: cur.url,
            title = (title?.takeIf { it.isNotBlank() } ?: cur.title)
        )
    }

    /** Update a browser tab by stable id, safe even if the user switches tabs mid-load. */
    fun updateBrowserTabById(tabId: Long, url: String? = null, title: String? = null) {
        val idx = webTabs.indexOfFirst { it.id == tabId }
        if (idx < 0) return
        updateBrowserTab(idx, url, title)
    }

    /* ── TASK 5: pending search query channel ──
     * When the user taps "Search in MarkVault" in the browser's text-selection
     * menu, we push the selected text here and navigate to the Search screen,
     * which consumes the value on first composition and clears it.
     */
    private val _pendingSearch = MutableStateFlow<String?>(null)
    val pendingSearch: StateFlow<String?> = _pendingSearch.asStateFlow()
    fun requestPendingSearch(q: String) { _pendingSearch.value = q }
    fun consumePendingSearch(): String? {
        val q = _pendingSearch.value
        _pendingSearch.value = null
        return q
    }

    /* ── Web bookmarks (user-saved jw.org pages) ── */

    suspend fun isBookmarked(url: String): Boolean =
        runCatching { dao.isBookmarked(url) }.getOrElse { false }

    fun addBookmark(url: String, title: String) {
        if (url.isBlank()) return
        viewModelScope.launch(Dispatchers.IO) {
            runCatching {
                val host = runCatching { android.net.Uri.parse(url).host ?: "" }.getOrElse { "" }
                dao.insertBookmark(WebBookmark(url = url, title = title.ifBlank { url }, host = host))
            }
        }
    }

    fun removeBookmark(url: String) {
        viewModelScope.launch(Dispatchers.IO) { runCatching { dao.deleteBookmarkByUrl(url) } }
    }

    suspend fun loadBookmarks(): List<WebBookmark> =
        runCatching { dao.allBookmarks() }.getOrElse { emptyList() }

    fun deleteBookmarkEntry(id: Long) {
        viewModelScope.launch(Dispatchers.IO) { runCatching { dao.deleteBookmark(id) } }
    }

    /** First ~600 chars of the note body, used for the home-screen suggestion previews. */
    suspend fun previewOf(id: Long): String? =
        runCatching { dao.previewOf(id) }.getOrNull()

    fun saveScroll(id: Long, scroll: Int) {
        if (scroll < 0) return
        viewModelScope.launch(Dispatchers.IO) { runCatching { dao.setScroll(id, scroll) } }
    }

    /** Term to flash-highlight in the reader after opening a full-text search result (one-shot). */
    /**
     * v5.4.37 — Pending highlight payload, expanded with the search
     * result snippet. Carries four pieces of information so the JS
     * highlighter can run a multi-strategy cascade:
     *
     *   1. [snippet] — the FTS snippet (with ⟦⟧ markers stripped) that
     *      appeared in the search result card. This is the most precise
     *      needle: it's literal text from the article that the search
     *      engine already matched. First strategy: search for this exact
     *      substring in the article DOM.
     *   2. [query] — the user's search query. Second strategy: phrase
     *      match on the full query string.
     *   3. [isPhrase] — whether the query was in exact-phrase mode.
     *   4. (implicit) individual terms extracted from query — last-resort
     *      fallback when nothing else matches.
     *
     * The snippet may be empty for pure-semantic results (no FTS hit).
     * In that case the JS falls through from strategy 1 to 2/3/4.
     */
    data class PendingHighlight(
        val query: String,
        val isPhrase: Boolean,
        val snippet: String = "",
        /**
         * v5.4.76cc — Paraphrases produced by the Phi-4-mini expander
         * for this query, if any. Passed through to the WebView-based
         * readers (Markdown and HTML) so they can apply the softer
         * lavender `.llm-hit` highlight on top of the existing yellow
         * `.term-hit` for the original query terms. Empty when the LLM
         * toggle is off, the model isn't installed, or the query wasn't
         * expanded (short/live-typing/etc).
         */
        val llmTerms: List<String> = emptyList()
    )

    var pendingHighlight: PendingHighlight? = null
    fun consumePendingHighlight(): PendingHighlight? {
        val v = pendingHighlight
        pendingHighlight = null
        return v
    }

    /** v5.4.37 — Convenience setter. Captures exact-phrase state and
     *  optionally the FTS snippet so the reader highlight cascade
     *  starts with the most precise needle available.
     *
     *  v5.4.76cc/v5.5.24 — Also reads the latest actually-issued model
     *  queries from [com.tebogo.markvault.ai.QueryPlanHistory] so the reader
     *  can paint the lavender AI trace without reviving a stale cache entry. */
    fun setPendingHighlight(
        query: String,
        isPhrase: Boolean? = null,
        snippet: String = ""
    ) {
        val cleaned = query.trim().removeSurrounding("\"")
        if (cleaned.isEmpty()) {
            pendingHighlight = null
            return
        }
        val phrase = isPhrase ?: quotePhrase.value
        // Strip FTS match markers (⟦ ⟧) and ellipsis (…) from snippet
        val cleanSnippet = snippet
            .replace("\u27E6", "").replace("\u27E7", "")
            .replace(" \u2026 ", " ").replace("\u2026", "")
            .trim()
        // v5.4.143cc — Build the LLM highlight term list.
        //
        // The LLM expansion history stores WHOLE PARAPHRASE STRINGS such as
        // "children born to Moses in the wilderness". These rarely appear
        // verbatim in articles, so the old code (passing them directly to
        // highlightLlmTerms) produced highlights that almost never fired.
        //
        // Fix: tokenise each paraphrase on non-word boundaries and keep every
        // token of ≥ 4 characters. These are the same words FTS actually
        // matched to surface the article, so they DO appear in the article
        // body and the pink flash will be visible.
        //
        // Both the full phrases (for the rare verbatim match) and individual
        // words are included. The JS sorts longest-first, so if a phrase
        // does match verbatim it wins before its constituent words.
        //
        // Words that are already in the user's original query are excluded:
        // they will be yellow (.term-hit), and the skip-inside-term-hit guard
        // in the JS means adding them to llmTerms just wastes work.
        // v5.5.24 — Use only model queries that the latest recorded plan
        // actually issued. LlmExpansionHistory is deliberately retained as a
        // reusable cache, so reading it directly here could paint stale LLM
        // terms after the same query was re-run with the model switch OFF or
        // the expansion slider at 0.
        val rawParaphrases = com.tebogo.markvault.ai.QueryPlanHistory
            .get(cleaned)?.aiQueries?.map { it.text }.orEmpty()
        val originalWords: Set<String> = cleaned
            .split(Regex("[^\\p{L}\\p{N}]+"))
            .map { it.trim().lowercase() }
            .filter { it.length >= 4 }
            .toHashSet()
        val llmTerms: List<String> = (rawParaphrases +
            rawParaphrases.flatMap { phrase ->
                phrase.split(Regex("[^\\p{L}\\p{N}]+"))
                    .map { it.trim() }
                    .filter { it.length >= 4 }
            })
            .filter { it.isNotBlank() && it.lowercase() !in originalWords }
            .distinctBy { it.lowercase() }
        pendingHighlight = PendingHighlight(cleaned, phrase, cleanSnippet, llmTerms)
    }

    /**
     * v4.7 — synchronous loadNote convenience for UI handlers that need it
     * outside a coroutine context. Returns null if not found. Safe to call
     * from the main thread because Room DAOs are designed for that on simple
     * queries with @WorkerThread enforcement turned off in this app.
     */
    fun openSync(id: Long): Note? {
        return runCatching {
            kotlinx.coroutines.runBlocking(Dispatchers.IO) { loadNote(id) }
        }.getOrNull()
    }

    /**
     * v4.7 — convert a note from one file type to another and save the result
     * into the library as a new file. Sourcetype detection: the caller passes
     * the source's known type; targetType is what they picked from the dialog.
     *
     * Supported pairs:
     *   md → html   :  full markdown-it render (via simple in-Kotlin pipeline)
     *   md → pdf    :  markdown → HTML → PDF (delegated to converter)
     *   html → md   :  HTML cleanup via simpleHtmlToMarkdown
     *   html → pdf  :  HTML → PDF
     *   pdf → md    :  PDF text extraction → markdown
     *   pdf → html  :  PDF text extraction → minimal HTML
     *
     * Currently the md→html, html→md, and pdf→md/html paths are wired and
     * functional via the existing converters. md→pdf and html→pdf are stubbed
     * with a friendly error so the UI flow is complete and the implementer can
     * fill them in without re-doing the dialog plumbing.
     */
    suspend fun convertNote(
        sourceId: Long, sourceType: String, targetType: String
    ): SaveResult = withContext(Dispatchers.IO) {
        val note = loadNote(sourceId)
            ?: return@withContext SaveResult.Error("Source note not found.")
        when (sourceType to targetType) {
            "md" to "html" -> {
                // Markdown → HTML: wrap content in minimal HTML, escape MD as
                // pre-rendered text. For a richer render the next iteration
                // can hook into the in-app markdown-it engine via a hidden WebView.
                val htmlBody = note.content
                    .replace("&", "&amp;")
                    .replace("<", "&lt;").replace(">", "&gt;")
                val wrapped = """
                    |<!DOCTYPE html>
                    |<meta charset="utf-8">
                    |<title>${note.title}</title>
                    |<pre style="white-space: pre-wrap; font: 14px/1.5 system-ui;">$htmlBody</pre>
                """.trimMargin()
                writeHtmlToLibrary(note.title, wrapped, note.uri)
            }
            "html" to "md", "mhtml" to "md" -> {
                val bytes = getApplication<Application>().contentResolver
                    .openInputStream(Uri.parse(note.uri))?.use { it.readBytes() }
                    ?: return@withContext SaveResult.Error("Could not read source file.")
                val htmlText = if (sourceType == "mhtml") {
                    com.tebogo.markvault.util.MhtmlParser.extractHtmlContent(bytes)
                        ?: return@withContext SaveResult.Error("MHTML parse failed.")
                } else {
                    String(bytes, Charsets.UTF_8)
                }
                val md = "# ${note.title}\n\n" + simpleHtmlToMarkdown(htmlText)
                saveImportedMarkdown(note.title, md, importsSubfolder.value)
            }
            "pdf" to "md" -> {
                // PDF → MD: use the cached page text we already extracted at
                // index time. Returns null when the source hasn't been viewed
                // yet (extraction is lazy on first open).
                val pages = cachedPdfPageText(sourceId)
                if (pages.isNullOrEmpty()) {
                    return@withContext SaveResult.Error(
                        "PDF text isn't extracted yet. Open the PDF once to cache it."
                    )
                }
                val md = buildString {
                    append("# ").append(note.title).append("\n\n")
                    pages.entries.sortedBy { it.key }.forEach { (idx, text) ->
                        append("## Page ").append(idx + 1).append("\n\n")
                        append(text.trim()).append("\n\n")
                    }
                }
                saveImportedMarkdown(note.title, md, importsSubfolder.value)
            }
            "pdf" to "html" -> {
                val pages = cachedPdfPageText(sourceId)
                if (pages.isNullOrEmpty()) {
                    return@withContext SaveResult.Error(
                        "PDF text isn't extracted yet. Open the PDF once to cache it."
                    )
                }
                val sb = StringBuilder()
                sb.append("<!DOCTYPE html><meta charset=\"utf-8\"><title>")
                    .append(note.title).append("</title><body>")
                pages.entries.sortedBy { it.key }.forEach { (idx, text) ->
                    sb.append("<h2>Page ").append(idx + 1).append("</h2><pre>")
                        .append(text.replace("<", "&lt;").replace(">", "&gt;"))
                        .append("</pre>")
                }
                sb.append("</body>")
                writeHtmlToLibrary(note.title, sb.toString(), note.uri)
            }
            else -> SaveResult.Error(
                "Conversion from $sourceType to $targetType isn't supported yet."
            )
        }.also { result ->
            if (result is SaveResult.Ok) {
                // Auto-reindex so the converted file is immediately searchable.
                reindex()
            }
        }
    }

    /** Write an HTML payload into the library as a `.html` file. */
    private suspend fun writeHtmlToLibrary(
        title: String, html: String, sourceUri: String
    ): SaveResult = withContext(Dispatchers.IO) {
        val libUri = libraryUri.value
            ?: return@withContext SaveResult.Error("No library set.")
        val treeUri = runCatching { Uri.parse(libUri) }.getOrNull()
            ?: return@withContext SaveResult.Error("Library URI invalid.")
        val cr = getApplication<Application>().contentResolver
        try {
            val subfolder = importsSubfolder.value
            val rootId = android.provider.DocumentsContract.getTreeDocumentId(treeUri)
            val rootDocUri = android.provider.DocumentsContract.buildDocumentUriUsingTree(
                treeUri, rootId
            )
            val parentUri = if (subfolder.isBlank()) rootDocUri else
                findOrCreateFolder(cr, treeUri, rootId, subfolder)
                    ?: return@withContext SaveResult.Error("Could not create subfolder.")
            val safeBase = sanitizeFilename(title).removeSuffix(".md")
            val fileName = ensureUniqueAnyExt(cr, treeUri, parentUri, safeBase, ".html")
            val newDoc = android.provider.DocumentsContract.createDocument(
                cr, parentUri, "text/html", fileName
            ) ?: return@withContext SaveResult.Error("Failed to create file.")
            cr.openOutputStream(newDoc, "w")?.use { out ->
                out.write(html.toByteArray(Charsets.UTF_8))
            } ?: return@withContext SaveResult.Error("Could not write file.")
            SaveResult.Ok(newDoc.toString(), fileName, subfolder)
        } catch (e: Exception) {
            SaveResult.Error("Write failed: ${e.message ?: e.javaClass.simpleName}")
        }
    }

    /**
     * Stash a WebView state bundle so popup → full-screen (or back) doesn't reload the page.
     * The receiving screen consumes this immediately; missing/expired = falls back to URL load.
     */
    var webStateBundle: android.os.Bundle? = null
    fun consumeWebState(): android.os.Bundle? {
        val v = webStateBundle
        webStateBundle = null
        return v
    }

    /**
     * Web popup font scaling — separate from reader font scaling, persisted in-memory only.
     * Values are textZoom percentages: 100 = default; min 70, max 200.
     */
    private val _webPopupTextZoom = MutableStateFlow(100)
    val webPopupTextZoom: StateFlow<Int> = _webPopupTextZoom
    fun setWebPopupTextZoom(v: Int) {
        _webPopupTextZoom.value = v.coerceIn(70, 200)
    }

    /** Dark-mode toggle for the in-app WebView popup (persisted in-memory only). */

    /**
     * Global request to open WebViewer content. Any screen can call [requestWebPopup].
     * MainActivity owns the presentation decision: floating popup when popup mode is
     * enabled, direct in-app full-screen when only full-screen mode is enabled, or the
     * system browser when both WebViewer presentation modes are disabled.
     * [clearWebPopup] consumes the pending request after routing it.
     */
    private val _webPopupRequest = MutableStateFlow<String?>(null)
    val webPopupRequest: StateFlow<String?> = _webPopupRequest

    /**
     * Read-only observation of the WebViewer floating-popup master switch.
     * Default `true` preserves in-app popup handling for existing installs.
     */
    val webViewerPopupEnabled: StateFlow<Boolean> = prefs.webViewerPopupEnabled
        .stateIn(viewModelScope, SharingStarted.Eagerly, true)

    /**
     * v5.4.84cc — Independent switch for the in-app WebView's
     * full-screen mode. When *both* this and [webViewerPopupEnabled]
     * are off, tapped links go to the system browser. See [Prefs.webViewerFullScreenEnabled]
     * for the full truth table.
     */
    val webViewerFullScreenEnabled: StateFlow<Boolean> = prefs.webViewerFullScreenEnabled
        .stateIn(viewModelScope, SharingStarted.Eagerly, true)

    /** v5.4.272cc — Whether each requested link gets its own floating popup. */
    val webPopupMultipleWindows: StateFlow<Boolean> = prefs.webPopupMultipleWindows
        .stateIn(viewModelScope, SharingStarted.Eagerly, false)

    /** v5.4.275cc — Controls the dismissible "Not in library / Save" WebViewer prompt. */
    val webSavePromptEnabled: StateFlow<Boolean> = prefs.webSavePromptEnabled
        .stateIn(viewModelScope, SharingStarted.Eagerly, true)

    fun setWebSavePromptEnabled(enabled: Boolean) {
        viewModelScope.launch { prefs.setWebSavePromptEnabled(enabled) }
    }

    /**
     * v5.4.272cc — Logical floating WebViewer windows. The native WebView is
     * still owned by [webViewSessions] under a stable session id, so moving,
     * resizing, minimizing and maximizing never replace the browser engine.
     */
    data class FloatingWebWindow(
        val id: Long,
        val url: String,
        val minimized: Boolean = false,
        val maximized: Boolean = false,
        // Incremented only for a new link request into a reused popup.
        val navigationSerial: Long = 0L
    )

    val webPopupWindows = androidx.compose.runtime.mutableStateListOf<FloatingWebWindow>()
    private var nextWebPopupWindowId: Long = 1L

    fun requestWebPopup(url: String) { _webPopupRequest.value = url }
    fun clearWebPopup() { _webPopupRequest.value = null }

    /** Open or reuse a floating popup according to [webPopupMultipleWindows]. */
    fun openWebPopupWindow(url: String) {
        if (url.isBlank()) return
        if (!webPopupMultipleWindows.value && webPopupWindows.isNotEmpty()) {
            val idx = webPopupWindows.lastIndex
            val cur = webPopupWindows[idx]
            webPopupWindows[idx] = cur.copy(
                url = url,
                minimized = false,
                navigationSerial = cur.navigationSerial + 1L
            )
            bringWebPopupWindowToFront(cur.id)
            return
        }
        val id = nextWebPopupWindowId++
        webPopupWindows.add(FloatingWebWindow(id = id, url = url))
    }

    fun bringWebPopupWindowToFront(id: Long) {
        val idx = webPopupWindows.indexOfFirst { it.id == id }
        if (idx < 0 || idx == webPopupWindows.lastIndex) return
        val item = webPopupWindows.removeAt(idx)
        webPopupWindows.add(item)
    }

    fun setWebPopupWindowMinimized(id: Long, minimized: Boolean) {
        val idx = webPopupWindows.indexOfFirst { it.id == id }
        if (idx < 0) return
        webPopupWindows[idx] = webPopupWindows[idx].copy(
            minimized = minimized,
            maximized = if (minimized) false else webPopupWindows[idx].maximized
        )
        if (!minimized) bringWebPopupWindowToFront(id)
    }

    fun setWebPopupWindowMaximized(id: Long, maximized: Boolean) {
        val idx = webPopupWindows.indexOfFirst { it.id == id }
        if (idx < 0) return
        webPopupWindows[idx] = webPopupWindows[idx].copy(
            maximized = maximized, minimized = false
        )
        bringWebPopupWindowToFront(id)
    }

    fun closeWebPopupWindow(id: Long) {
        val idx = webPopupWindows.indexOfFirst { it.id == id }
        if (idx < 0) return
        webPopupWindows.removeAt(idx)
        destroyWebViewSession("floating_popup_$id")
    }

    /** Top-most popup handles Android Back: WebView history first, then close. */
    fun handleFloatingWebBack(): Boolean {
        val top = webPopupWindows.lastOrNull() ?: return false
        val web = peekWebViewSession("floating_popup_${top.id}")
        if (web?.canGoBack() == true) {
            if (top.minimized) setWebPopupWindowMinimized(top.id, false)
            web.goBack()
        } else {
            closeWebPopupWindow(top.id)
        }
        return true
    }

    /**
     * v5.4.82cc — Persist the WebViewer popup master switch. Effect is
     * immediate on the next call to [requestWebPopup]; any popup
     * already on screen when the toggle is flipped stays open until
     * the user dismisses it.
     */
    fun setWebViewerPopupEnabled(enabled: Boolean) {
        viewModelScope.launch { prefs.setWebViewerPopupEnabled(enabled) }
    }

    /** v5.4.272cc — Reuse one floating window or create one per requested link. */
    fun setWebPopupMultipleWindows(enabled: Boolean) {
        viewModelScope.launch { prefs.setWebPopupMultipleWindows(enabled) }
    }

    /** v5.4.94cc — Convenience accessor to the app-wide activity log. */
    fun logActivity(
        category: com.tebogo.markvault.data.ActivityLog.Category,
        message: String,
        metadata: Map<String, String> = emptyMap()
    ) {
        runCatching {
            (getApplication<Application>() as? MarkVaultApp)
                ?.activityLog?.log(category, message, metadata)
        }
    }

    /** v5.4.84cc — Persist the WebViewer full-screen master switch. */
    fun setWebViewerFullScreenEnabled(enabled: Boolean) {
        viewModelScope.launch { prefs.setWebViewerFullScreenEnabled(enabled) }
    }

    // ────────────────────────────────────────────────────────────────────
    // v5.4.88cc — WebViewer Multi-Selection Mode
    //
    // A curated, user-driven alternative to the (removed) auto-detection
    // FAB. Flow:
    //
    //   1. User enables "Selection mode" from the WebViewer menu.
    //   2. Every long-press on an anchor inside the WebView is intercepted
    //      (in WebPopup / WebSearchScreen — see webSelectionMode below):
    //      the tapped link is toggled in [webSelectionItems] and the
    //      matching DOM node gets an `.mv-selected` outline injected by JS.
    //      The normal long-press action sheet is skipped while mode is on.
    //   3. When the user taps "Save selected" on the FAB, [startBatchSave]
    //      publishes the selection as [batchSaveRequest]. The
    //      composable-hosted `HiddenBatchSaver` watches that flow,
    //      navigates a 1dp off-screen WebView to each URL, waits for
    //      onPageFinished, extracts `document.documentElement.outerHTML`,
    //      then calls [saveBatchItem] to persist it.
    //   4. On completion the saver calls [finishBatchSave]; a Toast fired
    //      from the composable reports saved/failed counts and the FTS
    //      index is rebuilt so the fresh files show up in search
    //      immediately.
    //
    // Design notes:
    //   - Selection state lives on the VM (not the composable) so it
    //     survives switching between popup ↔ full-screen ↔ tabbed browser.
    //   - v5.4.88cc tried HttpURLConnection. Cloudflare (jw.org's edge)
    //     blocked the plain requests with challenge pages and every URL
    //     failed. v5.4.89cc switched to a hidden WebView so the batch
    //     shares Chromium's TLS session and cookie jar with the visible
    //     tab — anything the user can load manually is reachable here too.
    //   - Failures per URL are counted but do not abort the batch — one
    //     bad link shouldn't sabotage the other 5.
    // ────────────────────────────────────────────────────────────────────

    /**
     * A single URL queued in the WebViewer multi-select basket.
     *
     * v5.4.99cc — `expanded` flag added: `true` for items that were
     * collected via Multi Selection Mode's head-expansion (long-press a
     * listing page → auto-collect every article link inside it). The
     * batch saver applies a 10KB minimum size filter to expanded items
     * so nav-page shortcuts and stub pages get skipped instead of
     * saved. Non-expanded items (manually picked in normal Selection
     * Mode) bypass the filter and are always saved.
     */
    data class WebSelectionItem(
        val url: String,
        val title: String,
        val expanded: Boolean = false
    )

    private val _webSelectionMode = MutableStateFlow(false)
    /** True whenever the WebViewer is in "long-press-to-select" mode. */
    val webSelectionMode: StateFlow<Boolean> = _webSelectionMode.asStateFlow()

    private val _webSelectionItems = MutableStateFlow<List<WebSelectionItem>>(emptyList())
    /** URLs the user has picked but not yet saved. Order is selection order. */
    val webSelectionItems: StateFlow<List<WebSelectionItem>> = _webSelectionItems.asStateFlow()

    /**
     * Live progress of an in-flight batch save, as (done, total). Both zero
     * when idle — the FAB reads this to switch between "Save selected (n)"
     * and "Saving x/y…" states.
     */
    private val _webSelectionSaving = MutableStateFlow(0 to 0)
    val webSelectionSaving: StateFlow<Pair<Int, Int>> = _webSelectionSaving.asStateFlow()

    /**
     * v5.4.104cc — Number of items the current (or most recent) batch
     * save skipped as "already in library". Set once by
     * [HiddenBatchSaver] right after it runs its dedup filter and
     * before the fetch loop starts; consumed by the top-right
     * "N skipped" pill in the WebViewer (see the WebSearchScreen
     * overlay). Reset to 0 by [finishBatchSave] so the pill
     * disappears when the next batch begins.
     */
    private val _webSelectionSkippedDupes = MutableStateFlow(0)
    val webSelectionSkippedDupes: StateFlow<Int> =
        _webSelectionSkippedDupes.asStateFlow()

    fun setWebSelectionSkippedDupes(count: Int) {
        _webSelectionSkippedDupes.value = count.coerceAtLeast(0)
    }

    /**
     * v5.4.106cc — Public accessor for [com.tebogo.markvault.data.NoteDao.byId]
     * so composables outside the AppViewModel package can load a note by
     * id without needing to reach into the private [dao] field. Used by
     * [com.tebogo.markvault.ui.WebSplitScreen] to hydrate the library
     * pane on the split view. Runs on whatever dispatcher the caller
     * invokes it from — [dao.byId] is a Room suspend function that
     * handles its own thread routing.
     */
    /** Workspace: notes that mention this title in text but do not already backlink to it. */
    suspend fun findUnlinkedMentions(noteId: Long): List<com.tebogo.markvault.data.SearchHit> = withContext(Dispatchers.IO) {
        val target = dao.byId(noteId) ?: return@withContext emptyList()
        val title = target.title.trim()
        if (title.length < 3) return@withContext emptyList()
        val linkedIds = runCatching { loadBacklinks(noteId).map { it.id }.toSet() }.getOrDefault(emptySet())
        val phrase = "\"${title.replace("\"", "\"\"")}\""
        runCatching { dao.search(phrase) }.getOrDefault(emptyList())
            .filter { it.id != noteId && it.id !in linkedIds }
            .take(60)
    }

    /** Workspace Properties editor: rewrite only YAML/frontmatter and preserve the note body. */
    suspend fun updateMarkdownFrontmatter(noteId: Long, properties: List<Pair<String, String>>): String? = withContext(Dispatchers.IO) {
        val note = dao.byId(noteId) ?: return@withContext "Note not found."
        if (note.fileType.lowercase() !in setOf("md", "markdown")) return@withContext "Properties can only be edited on Markdown notes."
        val lines = note.content.split('\n')
        val hasFrontmatter = lines.firstOrNull()?.trim() == "---"
        val closing = if (hasFrontmatter) lines.drop(1).indexOfFirst { it.trim() == "---" } else -1
        val bodyStart = if (hasFrontmatter && closing >= 0) closing + 2 else 0
        val body = lines.drop(bodyStart).joinToString("\n").trimStart('\n')
        val cleanProps = properties
            .map { it.first.trim() to it.second.replace('\n', ' ').replace('\r', ' ').trim() }
            .filter { it.first.isNotBlank() }
            .distinctBy { it.first.lowercase() }
        val updated = buildString {
            if (cleanProps.isNotEmpty()) {
                append("---\n")
                cleanProps.forEach { (k, v) -> append(k).append(": ").append(v).append('\n') }
                append("---\n")
            }
            append(body)
        }
        val bytes = updated.toByteArray(Charsets.UTF_8)
        val cr = getApplication<Application>().contentResolver
        val uri = runCatching { Uri.parse(note.uri) }.getOrNull() ?: return@withContext "Invalid note URI."
        try {
            cr.openOutputStream(uri, "w")?.use { it.write(bytes) } ?: return@withContext "Could not open note for writing."
            dao.upsert(note.copy(content = updated, lastModified = System.currentTimeMillis(), size = bytes.size.toLong()))
            // v5.5.8 — This path edits the indexed note directly instead of
            // going through Indexer.indexSingleFile(), so explicitly schedule
            // embedding/ANN maintenance for every maintained model as well.
            buildAllEmbeddings()
            null
        } catch (t: Throwable) {
            "Save failed: ${t.message ?: t.javaClass.simpleName}"
        }
    }

    suspend fun noteById(id: Long): com.tebogo.markvault.data.Note? = dao.byId(id)

    // ────────────────────────────────────────────────────────────────
    // v5.4.105cc — Global session-state persistence.
    //
    // The app writes the current nav route + WebViewer tab list to
    // DataStore whenever they change (see [persistLastRoute],
    // [persistWebTabsSession]). On next launch the values are
    // re-loaded into the [pendingRestoredRoute] / [pendingRestoredWebTabs]
    // StateFlows, and MainActivity's nav graph consumes them once on
    // first composition to jump the user back to where they were.
    //
    // Scope of what's restored:
    //   • The top-level route (home / webSearch / activity_log / …)
    //   • The WebViewer tab list (URLs + titles) and active tab index
    //
    // Not restored (out of scope for this pass): scroll positions in
    // markdown/HTML readers (already handled via `lastScroll` on the
    // Note entity), unsent search queries in the search bar,
    // in-flight batch save progress. Those either recover themselves
    // (batch save is a foreground service that survives process
    // death) or would need per-screen `SavedStateHandle` plumbing to
    // do right.
    // ────────────────────────────────────────────────────────────────

    /** One entry in the restored WebViewer tab list. */
    data class RestoredWebTab(val url: String, val title: String)

    private val _pendingRestoredRoute = MutableStateFlow("")
    /** The last-known route from the previous session. Consumed once by
     *  MainActivity's nav graph on first composition, then cleared via
     *  [consumeRestoredRoute]. */
    val pendingRestoredRoute: StateFlow<String> =
        _pendingRestoredRoute.asStateFlow()
    fun consumeRestoredRoute() { _pendingRestoredRoute.value = "" }

    private val _pendingRestoredWebTabs =
        MutableStateFlow<List<RestoredWebTab>>(emptyList())
    val pendingRestoredWebTabs: StateFlow<List<RestoredWebTab>> =
        _pendingRestoredWebTabs.asStateFlow()
    fun consumeRestoredWebTabs() { _pendingRestoredWebTabs.value = emptyList() }

    private val _pendingRestoredWebActiveIdx = MutableStateFlow(0)
    val pendingRestoredWebActiveIdx: StateFlow<Int> =
        _pendingRestoredWebActiveIdx.asStateFlow()

    /**
     * Persist [route] as the last-known top-level nav destination.
     * Fired whenever the nav controller lands on a new destination,
     * so RAM-kill / crash still leaves an up-to-date snapshot.
     */
    fun persistLastRoute(route: String) {
        if (route.isBlank()) return
        viewModelScope.launch { runCatching { prefs.setLastRoute(route) } }
    }

    /**
     * Snapshot the current WebViewer tab list into DataStore. Called
     * on tab add / remove / active-idx change AND from
     * `MainActivity.onStop` so backgrounding the app also flushes the
     * latest state.
     */
    fun persistWebTabsSession() {
        val snapshotUrls = webTabs.map { it.url }
        val snapshotTitles = webTabs.map { it.title }
        val idx = webActiveTabIdx
        viewModelScope.launch {
            runCatching {
                prefs.setWebTabsSession(snapshotUrls, snapshotTitles, idx)
            }
        }
    }

    // v5.4.106cc — Reader (article) tab session parallel to the
    // WebViewer session above. Same lifecycle: MainActivity.onStop
    // fires [persistReaderTabsSession]; the restore payload is
    // exposed via [pendingRestoredReaderTabs] and consumed by
    // ReaderScreen on first mount.

    data class RestoredReaderTab(
        val id: Long,
        val title: String,
        val fileType: String
    )

    private val _pendingRestoredReaderTabs =
        MutableStateFlow<List<RestoredReaderTab>>(emptyList())
    val pendingRestoredReaderTabs: StateFlow<List<RestoredReaderTab>> =
        _pendingRestoredReaderTabs.asStateFlow()

    private val _pendingRestoredReaderActiveId =
        MutableStateFlow<Long?>(null)
    val pendingRestoredReaderActiveId: StateFlow<Long?> =
        _pendingRestoredReaderActiveId.asStateFlow()

    /**
     * Called by ReaderScreen on first mount. Re-opens every restored
     * tab whose note id still resolves in the DB; skips missing ids
     * silently (reindex can rewrite ids). Switches to the previously
     * active id if it's still present, otherwise leaves the active
     * tab as whatever ended up on top.
     *
     * The restore is a no-op after the first call (guarded via
     * [_pendingRestoredReaderTabs] being cleared) so a config change
     * doesn't re-open tabs the user closed.
     */
    fun consumeRestoredReaderTabs() {
        val pending = _pendingRestoredReaderTabs.value
        if (pending.isEmpty()) return
        val activeId = _pendingRestoredReaderActiveId.value
        _pendingRestoredReaderTabs.value = emptyList()
        _pendingRestoredReaderActiveId.value = null
        // Kick off in the VM scope so DB checks don't block the
        // caller (a composable on the main thread).
        viewModelScope.launch(Dispatchers.IO) {
            val existing = LinkedHashMap<Long, RestoredReaderTab>()
            for (t in pending) {
                if (t.id <= 0L) continue
                val n = runCatching { dao.byId(t.id) }.getOrNull()
                if (n != null) existing[t.id] = t
            }
            if (existing.isEmpty()) return@launch
            withContext(Dispatchers.Main) {
                for (t in existing.values) {
                    openArticle(
                        id = t.id,
                        title = t.title,
                        fileType = t.fileType
                    )
                }
                if (activeId != null && activeId in existing.keys) {
                    _activeTab.value = activeId
                }
            }
        }
    }

    /**
     * Snapshot the reader tab list into DataStore. Fired from
     * MainActivity.onStop. Idempotent — writing the same content
     * twice is fine.
     */
    fun persistReaderTabsSession() {
        val snapshot = _tabs.value
        val ids = snapshot.map { it.id }
        val titles = snapshot.map { it.title }
        val types = snapshot.map { it.fileType }
        val active = _activeTab.value
        viewModelScope.launch {
            runCatching {
                prefs.setReaderTabsSession(ids, titles, types, active)
            }
        }
    }

    /**
     * Enable or disable selection mode. Disabling also clears the current
     * basket — otherwise stale items linger and re-appear the next time the
     * user turns mode back on, which is confusing.
     *
     * v5.4.99cc — Also flips Multi Selection Mode off when this one is
     * turned on. The two modes are mutually exclusive: a single
     * long-press can either add one link or expand a whole head, not
     * both. See [setWebMultiSelectionMode] for the other direction.
     */
    fun setWebSelectionMode(enabled: Boolean) {
        _webSelectionMode.value = enabled
        if (enabled) {
            // Mutually exclusive with Multi Selection Mode
            _webMultiSelectionMode.value = false
            _webMultiExpandingHeads.value = 0
            _headExpansionQueue.value = emptyList()
            // v5.4.115cc — Drop the on-disk snapshot too, else a mode
            // switch would leave a stale queue that resurrects on the
            // next cold start.
            persistHeadExpansionQueue()
        }
        if (!enabled) _webSelectionItems.value = emptyList()
    }

    /**
     * Toggle a URL in/out of the basket. Returns `true` if the URL was
     * added (caller then applies the highlight class), `false` if removed
     * (caller removes the class).
     */
    fun toggleWebSelection(url: String, title: String): Boolean {
        val cur = _webSelectionItems.value
        val existing = cur.firstOrNull { it.url == url }
        return if (existing != null) {
            _webSelectionItems.value = cur - existing
            false
        } else {
            _webSelectionItems.value = cur + WebSelectionItem(url, title.ifBlank { url })
            true
        }
    }

    fun clearWebSelection() { _webSelectionItems.value = emptyList() }

    // ────────────────────────────────────────────────────────────────────
    // v5.4.99cc — WebViewer MULTI Selection Mode (head expansion)
    //
    // A companion to plain Selection Mode. Instead of adding ONE link
    // per long-press, a long-press on a "head" link (like a monthly
    // Watchtower listing, or a publication's chapter index) fires off a
    // background page-load of that head, then automatically adds every
    // article link inside it to the batch basket. The user can then
    // long-press more heads to grow the basket further, or long-press +
    // drag to sweep across several adjacent heads. Save button then
    // downloads all collected body articles in one go.
    //
    // Design mirrors the batch-save architecture (see HiddenBatchSaver
    // in WebViewerArticleSaver.kt):
    //   - Head loads happen on a hidden 1dp WebView (HiddenHeadExpander,
    //     see MultiSelectionExpander.kt) so Chromium's TLS session +
    //     cookie jar are shared with the visible tab. Same reason
    //     v5.4.89cc switched batch saves off HttpURLConnection —
    //     Cloudflare's bot heuristics on jw.org reject unshared plain
    //     requests. The expander is hoisted to MainActivity level so
    //     it survives navigating between screens mid-expansion.
    //   - Head expansions are queued via [enqueueHeadExpansion]; the
    //     HiddenHeadExpander composable processes them one at a time
    //     (serial) and reports back via [onHeadExpansionCompleted] /
    //     [onHeadExpansionFailed].
    //   - Body articles arrive via [addWebSelectionsBulk] with
    //     `expanded = true` on each item. That flag tells the
    //     HiddenBatchSaver to apply the 10KB minimum size filter — see
    //     [WebSelectionItem].
    //   - Multi Mode and plain Selection Mode are mutually exclusive to
    //     keep the long-press semantics unambiguous.
    // ────────────────────────────────────────────────────────────────────

    /**
     * One pending head expansion, queued by [enqueueHeadExpansion] and
     * drained by the HiddenHeadExpander composable. The `id` is a
     * monotonic nanoTime stamp so two enqueue calls for the same URL
     * (rare, but possible if the user long-presses twice) produce
     * distinct queue entries that both get processed.
     */
    data class HeadExpansionRequest(
        val url: String,
        val text: String,
        val id: Long = System.nanoTime()
    )

    private val _webMultiSelectionMode = MutableStateFlow(false)
    /** True whenever the WebViewer is in "long-press-to-expand" mode. */
    val webMultiSelectionMode: StateFlow<Boolean> =
        _webMultiSelectionMode.asStateFlow()

    private val _webMultiExpandingHeads = MutableStateFlow(0)
    /**
     * Live count of head-expansion loads that are currently in flight.
     * The FAB shows an "Expanding N heads…" pill when this is > 0 so
     * the user knows their long-press is being worked on (jw.org's
     * listing pages can take a few seconds to load + parse).
     */
    val webMultiExpandingHeads: StateFlow<Int> =
        _webMultiExpandingHeads.asStateFlow()

    private val _headExpansionQueue =
        MutableStateFlow<List<HeadExpansionRequest>>(emptyList())
    /**
     * FIFO queue of head URLs waiting to be expanded. The
     * HiddenHeadExpander composable observes this and processes the
     * front item at a time on a shared hidden WebView.
     */
    val headExpansionQueue: StateFlow<List<HeadExpansionRequest>> =
        _headExpansionQueue.asStateFlow()

    /**
     * Enable or disable Multi Selection Mode. Flips plain Selection
     * Mode off if it was on (mutually exclusive), and clears any
     * lingering expansion queue + basket so a subsequent enable starts
     * with a clean slate.
     */
    fun setWebMultiSelectionMode(enabled: Boolean) {
        _webMultiSelectionMode.value = enabled
        if (enabled) {
            _webSelectionMode.value = false
        }
        if (!enabled) {
            _webSelectionItems.value = emptyList()
            _webMultiExpandingHeads.value = 0
            _headExpansionQueue.value = emptyList()
            // v5.4.115cc — Keep the snapshot in step with the live queue.
            persistHeadExpansionQueue()
        }
    }

    /**
     * Queue a head URL for background expansion. No-op if Multi Mode
     * is off (guards against a stale long-press callback firing after
     * mode was toggled off). Increments the "expanding" counter
     * immediately so the FAB reflects the pending work; the counter is
     * decremented in [onHeadExpansionCompleted] / [onHeadExpansionFailed].
     */
    fun enqueueHeadExpansion(url: String, text: String) {
        if (!_webMultiSelectionMode.value) return
        if (url.isBlank()) return
        val request = HeadExpansionRequest(url, text)
        _headExpansionQueue.value = _headExpansionQueue.value + request
        _webMultiExpandingHeads.value = _webMultiExpandingHeads.value + 1
        // v5.4.115cc — Snapshot the queue so a RAM-kill mid-expansion
        // can pick up the un-expanded heads on next launch instead of
        // losing them entirely.
        persistHeadExpansionQueue()
        // v5.4.112cc — Surface expansion in the notification shade
        // immediately so the user sees work happening even if they
        // background the app right after long-pressing.
        publishExpansionProgress()
    }

    /**
     * Add many URLs to the basket in one shot (from head expansion).
     * Already-basketed URLs and duplicates within [items] are filtered
     * out so the count stays truthful. Returns the number of NEW items
     * actually added — callers use this for the activity-log summary.
     */
    fun addWebSelectionsBulk(items: List<WebSelectionItem>): Int {
        if (items.isEmpty()) return 0
        val cur = _webSelectionItems.value
        val existingUrls = HashSet<String>(cur.size).apply {
            for (it in cur) add(it.url)
        }
        val seenInBatch = HashSet<String>()
        val toAdd = ArrayList<WebSelectionItem>()
        for (item in items) {
            if (item.url.isBlank()) continue
            if (item.url in existingUrls) continue
            if (!seenInBatch.add(item.url)) continue
            toAdd.add(item)
        }
        if (toAdd.isEmpty()) return 0
        _webSelectionItems.value = cur + toAdd
        return toAdd.size
    }

    /**
     * Called by HiddenHeadExpander once a head's body links have been
     * extracted. Adds them to the basket (deduped), removes the head
     * from the expansion queue, decrements the "expanding" counter,
     * and logs an activity-log entry.
     */
    fun onHeadExpansionCompleted(
        request: HeadExpansionRequest,
        bodyLinks: List<WebSelectionItem>
    ) {
        _headExpansionQueue.value =
            _headExpansionQueue.value.filter { it.id != request.id }
        // v5.4.115cc — Queue shrank; update the on-disk snapshot so a
        // resume doesn't re-expand a head we already finished.
        persistHeadExpansionQueue()
        val added = addWebSelectionsBulk(bodyLinks)
        _webMultiExpandingHeads.value =
            (_webMultiExpandingHeads.value - 1).coerceAtLeast(0)
        logActivity(
            com.tebogo.markvault.data.ActivityLog.Category.BATCH_SAVE,
            "Multi-select head expanded",
            mapOf(
                "head" to request.text.take(80),
                "url" to request.url.take(200),
                "found" to bodyLinks.size.toString(),
                "added" to added.toString()
            )
        )
        // v5.4.112cc — Live expansion progress in the notification +
        // dashboard. Also emit a HEAD_EXPAND telemetry event so — if
        // a batch dashboard is already open (or opened later) — the
        // expansion shows in the same timeline.
        publishExpansionProgress()
        recordBatchEvent(
            BatchEvent(
                timestampMs = System.currentTimeMillis(),
                kind = BatchEventKind.HEAD_EXPAND,
                url = request.url,
                title = request.text,
                message = "Expanded: found ${bodyLinks.size}, added $added"
            )
        )
    }

    /** Called by HiddenHeadExpander on timeout / network error. */
    fun onHeadExpansionFailed(
        request: HeadExpansionRequest,
        error: String
    ) {
        _headExpansionQueue.value =
            _headExpansionQueue.value.filter { it.id != request.id }
        // v5.4.115cc — A failed head is removed from the snapshot too.
        // Retrying it forever across relaunches would wedge the resume.
        persistHeadExpansionQueue()
        _webMultiExpandingHeads.value =
            (_webMultiExpandingHeads.value - 1).coerceAtLeast(0)
        logActivity(
            com.tebogo.markvault.data.ActivityLog.Category.BATCH_SAVE,
            "Multi-select head expansion failed",
            mapOf(
                "head" to request.text.take(80),
                "url" to request.url.take(200),
                "error" to error
            )
        )
        publishExpansionProgress()
        recordBatchEvent(
            BatchEvent(
                timestampMs = System.currentTimeMillis(),
                kind = BatchEventKind.HEAD_EXPAND,
                url = request.url,
                title = request.text,
                message = "Expansion failed: $error"
            )
        )
    }

    /**
     * v5.4.112cc — Push the current expansion state into the general
     * progress notification. When the last head settles (`expanding`
     * hits 0), clear the op-progress line so the notification shows
     * the batch-save progress (which auto-starts after expansion) or
     * nothing.
     */
    private fun publishExpansionProgress() {
        val expanding = _webMultiExpandingHeads.value
        val collected = _webSelectionItems.value.size
        if (expanding > 0) {
            postOpProgress(
                OpProgress(
                    title = "Expanding selections\u2026",
                    text = "$expanding head" +
                        (if (expanding == 1) "" else "s") +
                        " loading \u00B7 $collected articles found",
                    indeterminate = true
                )
            )
        } else {
            // Expansion done. Leave a brief "collected N" line; the
            // auto-save will replace it with save progress shortly.
            if (collected > 0) {
                postOpProgress(
                    OpProgress(
                        title = "Selections ready",
                        text = "$collected articles collected \u2014 starting save\u2026",
                        indeterminate = true
                    )
                )
            } else {
                clearOpProgress()
            }
        }
    }

    // ────────────────────────────────────────────────────────────────────
    // v5.4.89cc — Batch save orchestration
    //
    // The v5.4.88cc implementation tried plain HttpURLConnection GETs from
    // the IO dispatcher. That failed on the primary target site (jw.org)
    // because Cloudflare's bot heuristics returned challenge pages instead
    // of the real HTML — every URL in the batch ended up with a non-2xx
    // response or a challenge stub, and the user saw "couldn't save any
    // selected articles". Even with cookies mirrored from the WebView's
    // CookieManager, the request signature didn't look like a real browser
    // hitting from the same TLS session.
    //
    // Fix: mirror what UrlImportScreen already does successfully — a
    // hidden WebView (1dp, off-screen but attached) that navigates to each
    // URL, waits for onPageFinished, extracts document.documentElement.
    // outerHTML, and hands the result to [saveBatchItem] below. The
    // WebView shares Chromium's session, TLS state, and cookie jar with
    // the visible tab, so any page the user could load manually is
    // reachable here too.
    //
    // The VM only orchestrates: [batchSaveRequest] is the queue the
    // composable-hosted saver watches; when it flips from empty to
    // non-empty, the saver starts loading URLs. Progress and completion
    // are pushed back into the VM so the FAB and the coaching pill can
    // reflect state across recompositions and viewer swaps.
    // ────────────────────────────────────────────────────────────────────

    /** Immutable snapshot of items to save, published to the hidden saver. */
    private val _batchSaveRequest = MutableStateFlow<List<WebSelectionItem>>(emptyList())
    val batchSaveRequest: StateFlow<List<WebSelectionItem>> = _batchSaveRequest.asStateFlow()

    /**
     * Kick off a batch save: publish the current selection as the request
     * queue and reset progress. The composable-hosted [HiddenBatchSaver]
     * observes [batchSaveRequest] and does the actual work.
     */
    fun startBatchSave() {
        val items = _webSelectionItems.value
        if (items.isEmpty()) return
        // Guard against overlapping saves — bail if a batch is already
        // in flight (the request queue is non-empty).
        if (_batchSaveRequest.value.isNotEmpty()) return
        _webSelectionSaving.value = 0 to items.size
        _batchSaveRequest.value = items
        // v5.4.115cc — New batch → clear completions carried over from
        // any previous batch, otherwise the snapshot would start out
        // already-shrunk and resume would skip un-saved items.
        resetCompletedBatchUrls()
        // v5.4.108cc — Persist the initial queue so a RAM-kill mid-
        // batch has a snapshot to resume from on next launch.
        persistBatchSaveQueue(items)
        logActivity(
            com.tebogo.markvault.data.ActivityLog.Category.BATCH_SAVE,
            "Batch save started",
            mapOf("count" to items.size.toString())
        )
    }

    /**
     * v5.4.108cc — Persist the current batch queue to DataStore.
     * Format: each item `url\u0001title\u0001expanded01`,
     * items joined with `\u0000`. Fires on batch start and again
     * every time the queue shrinks by a successfully-saved item —
     * the shrinking snapshot means a RAM-kill mid-batch only
     * re-fetches items that hadn't landed on disk yet.
     */
    fun persistBatchSaveQueue(items: List<WebSelectionItem>) {
        val payload = if (items.isEmpty()) "" else items.joinToString("\u0000") { it ->
            val expanded = if (it.expanded) "1" else "0"
            "${it.url}\u0001${it.title}\u0001$expanded"
        }
        viewModelScope.launch { runCatching { prefs.setBatchSaveQueue(payload) } }
    }

    /**
     * v5.4.115cc — Cumulative set of URLs that have finished in the
     * CURRENT batch. Thread-safe because the 3 parallel save workers
     * all report completions concurrently.
     *
     * This exists to fix the resume bug in v5.4.108cc–v5.4.114cc:
     * [removeBatchQueueItem] used to compute `_batchSaveRequest - {url}`
     * on every call. Because `_batchSaveRequest` deliberately never
     * shrinks during a batch (it's the composable's iteration state),
     * every call overwrote the snapshot with "the full list minus the
     * single most recent save". Saving A, then B, then C persisted
     * [B,C,D,E], then [A,C,D,E], then [A,B,D,E] — A and B reappeared.
     * The on-disk queue therefore always held ~the whole batch, and a
     * cold-start resume restarted from the beginning.
     *
     * Accumulating completions here and persisting
     * `_batchSaveRequest - completed` makes the snapshot monotonically
     * shrink, which is what resume needs.
     */
    private val completedBatchUrls: MutableSet<String> =
        java.util.concurrent.ConcurrentHashMap.newKeySet()

    /**
     * v5.4.108cc — Remove one item (by URL) from the persisted queue
     * snapshot. Called from [saveBatchItem] on successful save so the
     * on-disk queue tracks real progress.
     *
     * v5.4.115cc — Now accumulates into [completedBatchUrls] so the
     * persisted snapshot shrinks across the whole batch instead of
     * being recomputed from the pristine request each time. Failures
     * deliberately do NOT call this: an item that errored stays in the
     * snapshot so a resume retries it.
     */
    fun removeBatchQueueItem(url: String) {
        completedBatchUrls.add(url)
        val next = _batchSaveRequest.value.filter { it.url !in completedBatchUrls }
        // Note: we don't touch _batchSaveRequest itself — the in-flight
        // queue is the composable's iteration state. Only the persisted
        // snapshot is updated so a resume after crash picks up from the
        // right place.
        persistBatchSaveQueue(next)
    }

    /**
     * v5.4.115cc — Reset the completed-URL accumulator. Called whenever
     * a new batch begins (fresh start or resume) and whenever one ends,
     * so completions from a previous batch can't suppress items in the
     * next one.
     */
    private fun resetCompletedBatchUrls() {
        completedBatchUrls.clear()
    }

    /** Called by the saver as each URL completes (success or failure). */
    fun updateBatchSaveProgress(done: Int, total: Int) {
        _webSelectionSaving.value = done to total
    }

    /**
     * Save one loaded page. Called by the hidden WebView saver after
     * `document.documentElement.outerHTML` has been extracted for a URL.
     * Prefers the freshly-loaded page's own `<title>` (via the `pageTitle`
     * arg, which the caller pulls from `WebView.title`); falls back to the
     * HTML's inline title tag, then to the anchor text the user tapped.
     */
    suspend fun saveBatchItem(
        item: WebSelectionItem,
        html: String,
        pageTitle: String?
    ): SaveResult {
        val title = pageTitle?.takeIf { it.isNotBlank() }
            ?: extractHtmlTitle(html)
            ?: item.title
        val res = runCatching {
            saveOfflineHtmlPage(item.url, title, html)
        }.getOrElse { SaveResult.Error(it.message ?: "unknown") }
        // v5.4.90cc — Record the URL in the saved-URLs cache so the next
        // time the user visits a listing page containing this article, the
        // "already saved" highlight kicks in and the dedup filter skips it.
        if (res is SaveResult.Ok) {
            markUrlAsSaved(item.url)
            // v5.4.102cc — Also mark the title + filename so
            // multi-signal dedup catches this article on the next
            // batch even if the URL was blank or differed.
            markTitleAsSaved(title)
            // v5.4.108cc — Persist queue shrinkage so a mid-batch
            // RAM-kill doesn't re-fetch this item on resume.
            removeBatchQueueItem(item.url)
        }
        return res
    }

    /**
     * v5.4.109cc — User-initiated cancel for an in-flight batch save.
     * Called from the WebViewer's stop-save button and from the
     * notification's "Stop" action (see BatchSaveService). Wipes the
     * queue and progress state so HiddenBatchSaver's `for (item in
     * channel)` loop sees an empty queue and exits between items —
     * items already fetched by an in-flight worker still complete
     * their write (avoiding partial-file corruption), but no NEW
     * fetches start.
     *
     * Reuses [finishBatchSave] so the cleanup steps are identical to
     * a natural completion: reindex fires, selection state resets,
     * the on-disk resume snapshot clears.
     */
    fun cancelBatchSave() {
        if (_batchSaveRequest.value.isEmpty()) return
        logActivity(
            com.tebogo.markvault.data.ActivityLog.Category.BATCH_SAVE,
            "Batch save cancelled by user",
            mapOf(
                "done" to _webSelectionSaving.value.first.toString(),
                "total" to _webSelectionSaving.value.second.toString()
            )
        )
        finishBatchSave()
    }

    /**
     * Called by the saver once the queue is drained. Resets all selection
     * state, clears the batch queue, and triggers a reindex so the fresh
     * files show up in search immediately.
     */
    fun finishBatchSave() {
        viewModelScope.launch { runCatching { reindex() } }
        _webSelectionSaving.value = 0 to 0
        _webSelectionItems.value = emptyList()
        _webSelectionMode.value = false
        _batchSaveRequest.value = emptyList()
        // v5.4.104cc — Clear the skipped-dupe counter so the
        // top-right pill disappears once the batch is done.
        _webSelectionSkippedDupes.value = 0
        // v5.4.99cc — Also reset multi-select state so the next batch
        // starts clean regardless of which mode produced this one.
        _webMultiSelectionMode.value = false
        _webMultiExpandingHeads.value = 0
        _headExpansionQueue.value = emptyList()
        // v5.4.115cc — Expansion snapshot cleared alongside the batch
        // snapshot so a completed run leaves nothing to resume.
        persistHeadExpansionQueue()
        // v5.4.108cc — Clear the on-disk resume snapshot too.
        persistBatchSaveQueue(emptyList())
        // v5.4.115cc — Batch over; drop the completion accumulator so
        // the next batch starts from a clean slate.
        resetCompletedBatchUrls()
        // v5.4.112cc — Clear the general op-progress line so the
        // notification service can go idle and stop. Without this,
        // a stale "starting save…" op line would keep the service
        // alive after the batch finished.
        clearOpProgress()
        // v5.4.110cc — Don't clear telemetry here — let the dashboard
        // see the final numbers. A subsequent startBatchSave() will
        // overwrite the state via startBatchTelemetry.
    }

    // v5.4.108cc — Resume state for batch save. Set on VM init from
    // DataStore. MainActivity checks this on cold start and, if
    // non-empty, offers/re-fires the resume batch after a brief delay.

    private val _pendingResumeBatch =
        MutableStateFlow<List<WebSelectionItem>>(emptyList())
    val pendingResumeBatch: StateFlow<List<WebSelectionItem>> =
        _pendingResumeBatch.asStateFlow()

    /**
     * Fire the resume: seed the WebViewer basket + push the request
     * queue so HiddenBatchSaver picks it up on next composition.
     * Also logs an activity-log entry so the user can trace why the
     * app "just started saving" without an explicit action.
     */
    fun resumePendingBatchSave() {
        val items = _pendingResumeBatch.value
        if (items.isEmpty()) return
        _pendingResumeBatch.value = emptyList()
        _webSelectionItems.value = items
        _webSelectionSaving.value = 0 to items.size
        _batchSaveRequest.value = items
        // v5.4.115cc — The resumed queue is now the authoritative
        // request; completions accumulate fresh against it.
        resetCompletedBatchUrls()
        logActivity(
            com.tebogo.markvault.data.ActivityLog.Category.BATCH_SAVE,
            "Batch save resumed after cold start",
            mapOf("count" to items.size.toString())
        )
    }

    /** Called from MainActivity if the user dismisses the resume offer. */
    fun dismissPendingBatchResume() {
        _pendingResumeBatch.value = emptyList()
        viewModelScope.launch { runCatching { prefs.setBatchSaveQueue("") } }
    }

    // ────────────────────────────────────────────────────────────────
    // v5.4.115cc — Head-expansion resume
    //
    // Before this version nothing persisted the expansion queue, so a
    // crash or RAM-kill during multi-select head expansion lost every
    // pending head and the user had to re-select them by hand. The
    // batch-save queue had a snapshot; expansion didn't. Now both do.
    // ────────────────────────────────────────────────────────────────

    /**
     * Serialise the live expansion queue to DataStore. Format matches
     * the batch queue's convention: `url\u0001text` per entry, entries
     * joined with `\u0000`.
     */
    private fun persistHeadExpansionQueue() {
        val items = _headExpansionQueue.value
        val payload = if (items.isEmpty()) "" else items.joinToString("\u0000") {
            "${it.url}\u0001${it.text}"
        }
        viewModelScope.launch { runCatching { prefs.setHeadExpansionQueue(payload) } }
    }

    private val _pendingResumeExpansion =
        MutableStateFlow<List<HeadExpansionRequest>>(emptyList())
    val pendingResumeExpansion: StateFlow<List<HeadExpansionRequest>> =
        _pendingResumeExpansion.asStateFlow()

    /**
     * Re-arm the expansion queue from the restored snapshot.
     *
     * Deliberately bypasses the multi-selection-mode guard in
     * [enqueueHeadExpansion]: on a cold start the user is not in
     * multi-select mode yet, but the heads they'd already queued are
     * still legitimate work. [HiddenHeadExpander] is mounted
     * unconditionally in MainActivity and drains whatever is in the
     * queue, so repopulating the flow is sufficient — and we turn
     * multi-selection mode back on so the articles the expansion finds
     * land in the basket exactly as they would have.
     */
    fun resumePendingHeadExpansion() {
        val items = _pendingResumeExpansion.value
        if (items.isEmpty()) return
        _pendingResumeExpansion.value = emptyList()
        _webMultiSelectionMode.value = true
        _headExpansionQueue.value = items
        _webMultiExpandingHeads.value = items.size
        persistHeadExpansionQueue()
        publishExpansionProgress()
        logActivity(
            com.tebogo.markvault.data.ActivityLog.Category.BATCH_SAVE,
            "Head expansion resumed after cold start",
            mapOf("count" to items.size.toString())
        )
    }

    /** Called if the user declines the expansion resume. */
    fun dismissPendingExpansionResume() {
        _pendingResumeExpansion.value = emptyList()
        viewModelScope.launch { runCatching { prefs.setHeadExpansionQueue("") } }
    }

    // ────────────────────────────────────────────────────────────────
    // v5.4.110cc — Live batch save telemetry
    //
    // A dashboard-friendly view of everything happening in the batch
    // save right now. Populated by HiddenBatchSaver as items go
    // through the workers; consumed by BatchSaveDashboardScreen (a
    // new full-screen composable) and by the notification-tap
    // target. Not persisted — telemetry only lives for the duration
    // of a batch, then resets.
    //
    // Design principles:
    //   • Everything is a StateFlow so the dashboard can render
    //     without polling.
    //   • Event history is capped at 200 entries (LRU by insertion)
    //     to prevent unbounded memory growth on 5000+ URL batches.
    //   • Per-worker state is a fixed-size list matching
    //     PARALLEL_WORKERS in HiddenBatchSaver.
    //   • Speed metrics (articles/sec, bytes/sec) are computed on
    //     the read side, from the (started, ok, bytesFetched) tuple
    //     and current wall clock — so we don't need a ticker.
    // ────────────────────────────────────────────────────────────────

    enum class BatchEventKind {
        FETCH_START, SAVE_OK, SAVE_FAIL, SKIP_DUPE, SKIP_SMALL, HEAD_EXPAND
    }

    data class BatchEvent(
        val timestampMs: Long,
        val kind: BatchEventKind,
        val url: String,
        val title: String,
        val message: String,
        val bytes: Long = 0L,
        val workerIdx: Int = -1,
        val durationMs: Long = 0L
    )

    data class BatchTelemetry(
        val startedAtMs: Long,
        val total: Int,
        val ok: Int = 0,
        val failed: Int = 0,
        val skippedDupes: Int = 0,
        val skippedSmall: Int = 0,
        val bytesFetched: Long = 0L,
        val workerActivity: List<String?> = emptyList(),
        val events: List<BatchEvent> = emptyList()
    ) {
        val done: Int get() = ok + failed + skippedDupes + skippedSmall
        val remaining: Int get() = (total - done).coerceAtLeast(0)
    }

    private val _batchTelemetry = MutableStateFlow<BatchTelemetry?>(null)
    val batchTelemetry: StateFlow<BatchTelemetry?> = _batchTelemetry.asStateFlow()

    /** Called by HiddenBatchSaver once dedup has been applied and the
     *  final fetch queue is known. Seeds the telemetry with total +
     *  the initial skippedDupes count so the dashboard's totals add up. */
    fun startBatchTelemetry(total: Int, workerCount: Int, initialSkippedDupes: Int) {
        _batchTelemetry.value = BatchTelemetry(
            startedAtMs = System.currentTimeMillis(),
            total = total,
            skippedDupes = initialSkippedDupes,
            workerActivity = List(workerCount) { null },
            events = emptyList()
        )
    }

    /** Update a single worker's current activity. `url = null` means idle. */
    fun updateBatchWorker(workerIdx: Int, url: String?) {
        val cur = _batchTelemetry.value ?: return
        if (workerIdx < 0 || workerIdx >= cur.workerActivity.size) return
        val next = cur.workerActivity.toMutableList().apply { this[workerIdx] = url }
        _batchTelemetry.value = cur.copy(workerActivity = next)
    }

    /** Append an event + bump the matching counter. Called once per
     *  batch item completion. */
    fun recordBatchEvent(event: BatchEvent) {
        val cur = _batchTelemetry.value ?: return
        val trimmed = (cur.events + event).takeLast(200)
        _batchTelemetry.value = when (event.kind) {
            BatchEventKind.SAVE_OK -> cur.copy(
                events = trimmed,
                ok = cur.ok + 1,
                bytesFetched = cur.bytesFetched + event.bytes
            )
            BatchEventKind.SAVE_FAIL -> cur.copy(
                events = trimmed,
                failed = cur.failed + 1,
                bytesFetched = cur.bytesFetched + event.bytes
            )
            BatchEventKind.SKIP_DUPE -> cur.copy(
                events = trimmed,
                skippedDupes = cur.skippedDupes + 1
            )
            BatchEventKind.SKIP_SMALL -> cur.copy(
                events = trimmed,
                skippedSmall = cur.skippedSmall + 1,
                bytesFetched = cur.bytesFetched + event.bytes
            )
            BatchEventKind.FETCH_START,
            BatchEventKind.HEAD_EXPAND -> cur.copy(events = trimmed)
        }
    }

    /** Clear telemetry between batches. Called from [finishBatchSave]. */
    fun clearBatchTelemetry() {
        _batchTelemetry.value = null
    }

    // ────────────────────────────────────────────────────────────────
    // v5.4.112cc — General-purpose progress notifications.
    //
    // Any long-running / background operation can publish a progress
    // line here; BatchSaveService (renamed conceptually to a general
    // "operation progress" service) mirrors it into the notification
    // shade. Covers:
    //   • Multi-select head expansion (live count of heads loading +
    //     articles collected so far)
    //   • Search-in-progress + search-ready
    //   • Batch save (existing path, now unified)
    //
    // Search completion notifications are owned by BackgroundWorkService,
    // which waits for post-search cleanup before posting the durable
    // "results ready" notification.
    // ────────────────────────────────────────────────────────────────

    data class OpProgress(
        val title: String,
        val text: String,
        val done: Int = 0,
        val total: Int = 0,
        val indeterminate: Boolean = false
    )

    private val _opProgress = MutableStateFlow<OpProgress?>(null)
    val opProgress: StateFlow<OpProgress?> = _opProgress.asStateFlow()

    fun postOpProgress(op: OpProgress) { _opProgress.value = op }
    fun clearOpProgress() { _opProgress.value = null }

    // ────────────────────────────────────────────────────────────────────
    // v5.4.90cc — Saved-URL cache for duplicate prevention + "already
    // saved" highlight.
    //
    // Backed by Prefs.savedOfflineUrls (a newline-separated string) so it
    // survives process death, but read into an in-memory Set on VM init
    // for O(1) lookups from the JS highlighter and the batch dedup
    // filter. Updates go through [markUrlAsSaved] which patches both the
    // in-memory Set and DataStore in a single suspend hop.
    // ────────────────────────────────────────────────────────────────────

    private val _savedOfflineUrls = MutableStateFlow<Set<String>>(emptySet())
    /**
     * URLs the user has previously saved as offline HTML. Consulted by the
     * WebViewer selection flow to (a) skip re-saving them in a batch and
     * (b) paint a distinct "already saved" highlight so the user knows
     * they're already in the library.
     */
    val savedOfflineUrls: StateFlow<Set<String>> = _savedOfflineUrls.asStateFlow()

    init {
        // Load the saved-URL cache from DataStore once at VM init. Keeps
        // the runtime lookup path allocation-free.
        viewModelScope.launch {
            val raw = prefs.savedOfflineUrlsRaw.first()
            _savedOfflineUrls.value = raw
                .split('\n')
                .filter { it.isNotBlank() }
                .toCollection(LinkedHashSet())
            // v5.4.100cc — Kick off the library-wide URL harvest after
            // the cache is warmed. Runs on Dispatchers.IO inside
            // [backfillSavedUrlsFromLibrary], so this init block
            // doesn't block anything user-visible. Every launch
            // top-ups the cache; new library files added since last
            // launch get picked up here.
            // v5.4.144cc — OPTIMIZATION: Only run Phase 1 (content-based
            // extraction) on startup. Phase 2 (raw HTML file scanning)
            // is deferred to a lazy background task triggered on first
            // WebViewer usage. This speeds up app launch from 3-4s to
            // <1s on a 14K library.
            backfillSavedUrlsFromLibraryPhase1Only()
            // v5.4.102cc — Parallel backfill for the title/filename
            // caches. Both are needed for the multi-signal dedup in
            // HiddenBatchSaver ("URL → title → filename" try-in-order).
            backfillTitlesFromLibrary()
        }
    }

    /**
     * v5.4.100cc — Canonicalise a URL for cache comparisons.
     *
     * We keep this deliberately conservative: strip fragment,
     * trim trailing slash on non-root paths, and lowercase the
     * scheme + host. We do NOT strip query parameters — jw.org's
     * `finder?bible=...` etc. carry meaningful state, and we'd risk
     * false-positive dedup by dropping them. Called by both
     * [markUrlAsSaved] (write path) and [isUrlAlreadySaved] /
     * [urlsAlreadySaved] (read path) so the cache always compares
     * canonical against canonical.
     */
    private fun canonicalizeUrl(url: String): String {
        if (url.isBlank()) return url
        var s = url.trim()
        val hashIdx = s.indexOf('#')
        if (hashIdx >= 0) s = s.substring(0, hashIdx)
        // Case-insensitive scheme + host. Only touch the "scheme://host"
        // prefix; everything after must stay case-preserving because
        // some sites treat path/query as case-sensitive.
        val schemeSep = s.indexOf("://")
        if (schemeSep > 0) {
            val afterScheme = schemeSep + 3
            val pathStart = s.indexOf('/', afterScheme).let {
                if (it < 0) s.length else it
            }
            val schemeAndHost = s.substring(0, pathStart).lowercase()
            val rest = if (pathStart < s.length) s.substring(pathStart) else ""
            s = schemeAndHost + rest
        }
        // Trailing slash on non-root paths only.
        if (s.endsWith('/')) {
            val slashes = s.count { it == '/' }
            // "https://host/" has exactly 3 slashes — keep those alone;
            // "https://host/foo/" has 4+ — trim.
            if (slashes > 3) s = s.trimEnd('/')
        }
        return s
    }

    /**
     * v5.4.100cc — Fast O(1) check for whether a URL is already in the
     * library. Canonicalises the query URL first so trailing-slash /
     * fragment / mixed-case variants of the same URL all match.
     */
    fun isUrlAlreadySaved(url: String): Boolean {
        if (url.isBlank()) return false
        val cache = _savedOfflineUrls.value
        if (url in cache) return true
        val canonical = canonicalizeUrl(url)
        if (canonical in cache) return true
        return false
    }

    /**
     * v5.4.100cc — Bulk variant of [isUrlAlreadySaved]. Given a list
     * of candidate URLs, returns the subset that are already known to
     * the library. Used by the batch-save dedup filter in
     * `HiddenBatchSaver` so it does one cache read per batch instead
     * of one per URL.
     */
    fun urlsAlreadySaved(urls: List<String>): Set<String> {
        if (urls.isEmpty()) return emptySet()
        val cache = _savedOfflineUrls.value
        if (cache.isEmpty()) return emptySet()
        val out = HashSet<String>()
        for (u in urls) {
            if (u.isBlank()) continue
            if (u in cache) {
                out.add(u)
                continue
            }
            val canonical = canonicalizeUrl(u)
            if (canonical in cache) out.add(u)
        }
        return out
    }

    /**
     * Record that a URL has been saved. Called from [saveBatchItem] after
     * every successful save and from [saveOfflineHtmlPage]-adjacent flows.
     * Patches the in-memory Set first (so UI updates immediately), then
     * fires a background write to DataStore.
     *
     * v5.4.100cc — Now stores the canonicalised URL so downstream
     * `contains` checks work regardless of trailing-slash / fragment
     * differences between the save-time URL and the check-time URL.
     */
    fun markUrlAsSaved(url: String) {
        if (url.isBlank()) return
        val canonical = canonicalizeUrl(url)
        val cur = _savedOfflineUrls.value
        if (canonical in cur) return
        // LinkedHashSet insertion-order preservation is what the Prefs LRU
        // cap relies on — always add at the end.
        val next = LinkedHashSet(cur).apply { add(canonical) }
        _savedOfflineUrls.value = next
        viewModelScope.launch { runCatching { prefs.setSavedOfflineUrls(next) } }
    }

    /**
     * v5.4.100cc — Bulk mark-as-saved for the library backfill. Adds
     * every URL in [urls] to the in-memory cache (deduped +
     * canonicalised), then writes the union to DataStore in a single
     * transaction. Much cheaper than N × [markUrlAsSaved] for 10K+
     * URL harvests.
     */
    fun markUrlsAsSavedBulk(urls: Collection<String>) {
        if (urls.isEmpty()) return
        val cur = _savedOfflineUrls.value
        val next = LinkedHashSet(cur)
        var added = 0
        for (raw in urls) {
            if (raw.isBlank()) continue
            val canonical = canonicalizeUrl(raw)
            if (canonical.isBlank()) continue
            if (next.add(canonical)) added++
        }
        if (added == 0) return
        _savedOfflineUrls.value = next
        viewModelScope.launch { runCatching { prefs.setSavedOfflineUrls(next) } }
    }

    /**
     * v5.4.100cc — Harvest source URLs from every note in the library
     * and add them to [savedOfflineUrls]. Runs in the background on VM
     * init and after every reindex, so the URL cache reflects the
     * actual library state — not just URLs saved during the current
     * session.
     *
     * Runs in two phases:
     *
     *   • **Phase 1 — DB content extraction (fast).** Reads the
     *     `content` field of every markdown/HTML/MHTML note that
     *     plausibly carries a source URL. Markdown notes hit here
     *     because YAML frontmatter (`source: <url>`) survives
     *     indexing intact. HTML notes indexed by v5.4.100cc or later
     *     hit here because [stripHtmlForIndex] now prepends
     *     `source: <url>` to the FTS content.
     *
     *   • **Phase 2 — raw-file fallback (legacy HTML).** For every
     *     HTML/MHTML note whose Phase 1 content DIDN'T carry a
     *     `source:` prefix — meaning it was indexed by an older
     *     MarkVault where `stripHtmlForIndex` destroyed the URL — we
     *     open the raw file via ContentResolver, read the first
     *     16 KB, and pull the URL from the envelope comment /
     *     `<base href>` / `<link rel="canonical">` / `<meta og:url>`
     *     via [extractSourceUrlFromRawHtml]. This catches every
     *     legacy HTML file WITHOUT requiring a full reindex, which
     *     was the pain point in v5.4.100cc first-run: "many html
     *     duplicates" would otherwise slip through the batch dedup
     *     until the user manually reindexed.
     *
     * Idempotent — the bulk-mark path skips duplicates. Safe to call
     * repeatedly.
     */
    /**
     * v5.4.144cc — Fast Phase 1 only: extract URLs from DB records'
     * content field (which carries the `source:` prefix for all modern
     * saves). Completes in ~200ms even for 14K libraries. Phase 2
     * (raw HTML scanning) is deferred to [backfillSavedUrlsFromLibraryPhase2].
     *
     * Called on app startup for snappy library load.
     */
    fun backfillSavedUrlsFromLibraryPhase1Only() {
        viewModelScope.launch(Dispatchers.IO) {
            val rows = runCatching { dao.notesForUrlHarvest() }.getOrElse { return@launch }
            if (rows.isEmpty()) return@launch
            val collected = HashSet<String>()

            // Phase 1: content-based extraction (fast, DB-backed).
            for (row in rows) {
                extractUrlsFromNoteContent(row.content, collected)
            }

            if (collected.isNotEmpty()) {
                withContext(Dispatchers.Main) {
                    markUrlsAsSavedBulk(collected)
                }
            }
        }
    }

    /**
     * v5.4.144cc — Lazy Phase 2 backfill. Scans raw HTML/MHTML files
     * for URLs if Phase 1 didn't find them. Runs in background after
     * Phase 1 completes. Called lazily on first WebViewer usage to keep
     * app startup fast.
     */
    fun backfillSavedUrlsFromLibraryPhase2() {
        viewModelScope.launch(Dispatchers.IO) {
            val rows = runCatching { dao.notesForUrlHarvest() }.getOrElse { return@launch }
            if (rows.isEmpty()) return@launch
            val collected = HashSet<String>()

            // Phase 2: raw-file fallback for legacy HTML/MHTML files
            // whose Phase 1 content was stripped of its source URL by
            // an older `stripHtmlForIndex`. We identify these by the
            // absence of a `source:` prefix in their content (Phase 1
            // depends on that prefix; if it's missing, Phase 1 found
            // nothing).
            var rawScanned = 0
            var rawExtracted = 0
            for (row in rows) {
                val ft = row.fileType.lowercase()
                val isHtmlish = ft == "html" || ft == "htm" ||
                    ft == "mhtml" || ft == "mht"
                if (!isHtmlish) continue
                // Cheap skip: if content already carries `source:`,
                // Phase 1 handled it.
                if (row.content.contains("source:", ignoreCase = true)) continue
                if (row.uri.isBlank()) continue
                val raw = readHtmlFileHead(row.uri) ?: continue
                rawScanned++
                val url = com.tebogo.markvault.data.extractSourceUrlFromRawHtml(raw)
                    ?: continue
                val before = collected.size
                addUrlIfHttp(url, collected)
                if (collected.size > before) rawExtracted++
            }

            if (collected.isNotEmpty()) {
                withContext(Dispatchers.Main) {
                    markUrlsAsSavedBulk(collected)
                }
            }
        }
    }

    /**
     * v5.4.144cc — Composite backfill. Runs Phase 1 only on startup,
     * then Phase 2 when needed. Kept for compatibility; use the split
     * [backfillSavedUrlsFromLibraryPhase1Only] / [backfillSavedUrlsFromLibraryPhase2]
     * on new call sites.
     */
    fun backfillSavedUrlsFromLibrary() {
        viewModelScope.launch(Dispatchers.IO) {
            val rows = runCatching { dao.notesForUrlHarvest() }.getOrElse { return@launch }
            if (rows.isEmpty()) return@launch
            val collected = HashSet<String>()

            // Phase 1: content-based extraction (fast, DB-backed).
            for (row in rows) {
                extractUrlsFromNoteContent(row.content, collected)
            }
            val phase1Count = collected.size

            // Phase 2: raw-file fallback for legacy HTML/MHTML files
            // whose Phase 1 content was stripped of its source URL by
            // an older `stripHtmlForIndex`. We identify these by the
            // absence of a `source:` prefix in their content (Phase 1
            // depends on that prefix; if it's missing, Phase 1 found
            // nothing).
            var rawScanned = 0
            var rawExtracted = 0
            for (row in rows) {
                val ft = row.fileType.lowercase()
                val isHtmlish = ft == "html" || ft == "htm" ||
                    ft == "mhtml" || ft == "mht"
                if (!isHtmlish) continue
                // Cheap skip: if content already carries `source:`,
                // Phase 1 handled it.
                if (row.content.contains("source:", ignoreCase = true)) continue
                if (row.uri.isBlank()) continue
                val raw = readHtmlFileHead(row.uri) ?: continue
                rawScanned++
                val url = com.tebogo.markvault.data.extractSourceUrlFromRawHtml(raw)
                    ?: continue
                val before = collected.size
                addUrlIfHttp(url, collected)
                if (collected.size > before) rawExtracted++
            }

            if (collected.isNotEmpty()) {
                withContext(Dispatchers.Main) {
                    markUrlsAsSavedBulk(collected)
                }
                logActivity(
                    com.tebogo.markvault.data.ActivityLog.Category.BATCH_SAVE,
                    "URL cache backfill completed",
                    mapOf(
                        "scanned" to rows.size.toString(),
                        "urls_found" to collected.size.toString(),
                        "phase1_urls" to phase1Count.toString(),
                        "html_raw_scanned" to rawScanned.toString(),
                        "html_raw_added" to rawExtracted.toString()
                    )
                )
            }
        }
    }

    /**
     * v5.4.100cc — Read the first [maxBytes] of an HTML/MHTML file
     * from a content URI. Used by the Phase 2 legacy-HTML backfill
     * pass in [backfillSavedUrlsFromLibrary].
     *
     * We deliberately read a bounded prefix (16 KB by default)
     * instead of the whole file. The envelope comment, base href,
     * canonical link, and og:url meta all live in the document head
     * — a fully-saved jw.org article can be 500 KB+, and reading all
     * of it through SAF's ContentResolver would turn the backfill
     * pass into a multi-minute wait on a 14K-note library. 16 KB is
     * roomy enough for any realistic document head.
     */
    private fun readHtmlFileHead(uriString: String, maxBytes: Int = 16 * 1024): String? {
        return runCatching {
            val ctx = getApplication<Application>()
            val uri = android.net.Uri.parse(uriString)
            ctx.contentResolver.openInputStream(uri)?.use { input ->
                val buf = ByteArray(maxBytes)
                var offset = 0
                while (offset < maxBytes) {
                    val read = input.read(buf, offset, maxBytes - offset)
                    if (read <= 0) break
                    offset += read
                }
                String(buf, 0, offset, Charsets.UTF_8)
            }
        }.getOrNull()
    }

    /**
     * v5.4.100cc — Extract every plausible source-URL string from a
     * note's content and add canonical forms to [out]. Handles:
     *   • YAML frontmatter `source: <url>` (and `source: "<url>"`)
     *   • Body-line `> Source: <<url>>` / `*Source: <url>*`
     *   • Inline `source: <url>` prefix injected by
     *     v5.4.100cc's stripHtmlForIndex for HTML/MHTML notes.
     * Non-http(s) URLs are dropped so mailto:/ file:/ don't pollute
     * the cache.
     */
    private fun extractUrlsFromNoteContent(
        content: String,
        out: MutableSet<String>
    ) {
        if (content.isBlank()) return
        // Look at just the first 4KB — frontmatter and envelope
        // comments always live near the head. Cheaper than regexing
        // 500KB pages.
        val head = if (content.length > 4096) content.substring(0, 4096) else content
        // 1. YAML/body `source:` prefix
        val sourceLine = Regex(
            """(?im)^\s*[>*\s]*source\s*[:=]\s*[<"']?(https?://\S+?)[>"'\s]*$""",
        )
        for (m in sourceLine.findAll(head)) {
            val raw = m.groupValues.getOrNull(1) ?: continue
            addUrlIfHttp(raw, out)
        }
        // 2. `Source: <URL>` on any line
        val sourceInline = Regex(
            """(?i)Source:\s*[<"']?(https?://\S+?)[>"'\s\)*]""",
        )
        for (m in sourceInline.findAll(head)) {
            val raw = m.groupValues.getOrNull(1) ?: continue
            addUrlIfHttp(raw, out)
        }
    }

    private fun addUrlIfHttp(raw: String, out: MutableSet<String>) {
        val trimmed = raw.trim().trimEnd('>', '"', '\'', ')', ',', '.', ';')
        if (trimmed.length < 10) return
        if (!trimmed.startsWith("http://") && !trimmed.startsWith("https://")) return
        // v5.4.113cc — Reject section/index URLs (e.g. a jw.org
        // listing page's .../all-publications/awake) so a poisoned
        // note doesn't seed the dedup cache with a URL that matches
        // every sibling article. This also cleans up the ALREADY
        // poisoned cache on the next reindex: the bad URL was baked
        // into a note's `source:` line during a prior strip, but this
        // guard now drops it when the harvest re-reads that note.
        if (!com.tebogo.markvault.data.looksLikeArticleUrl(trimmed)) return
        val canonical = canonicalizeUrl(trimmed)
        if (canonical.isNotBlank()) out.add(canonical)
    }

    // ────────────────────────────────────────────────────────────────────
    // v5.4.102cc — Multi-signal dedup (URL + title)
    //
    // The URL cache (v5.4.100cc) catches every article whose source URL
    // MarkVault knows about. But two remaining gaps produce duplicates:
    //
    //   1. A URL variant that canonicalisation can't fold — e.g. mobile
    //      vs desktop sub-domain, a redirect chain that never resolves
    //      to the same href, or a shared link with tracking params we
    //      chose not to strip.
    //   2. A hand-crafted markdown note whose article title matches an
    //      article MarkVault is about to batch-save from the web — no
    //      source URL exists to compare, so URL dedup is blind to it.
    //
    // To close both gaps we build an in-memory Set of every note's
    // normalised title, and layer the check: URL match wins, then
    // title match. Any hit stops the save. Cache is rebuilt from
    // `dao.allMeta()` on VM init and after every reindex; NOT persisted
    // to DataStore because the rebuild is a single indexed SQLite scan
    // (<200ms even on 14K notes), cheaper than serialising the
    // normalised strings through DataStore on every launch.
    //
    // v5.4.103cc — Filename matching removed. Series like "Questions
    // From Readers" ship many articles under the same base filename;
    // the collision-suffix stripper in `normalizeFileName` would fold
    // them all onto one cache key and false-positive every entry in
    // the series after the first. Titles carry the article-specific
    // subtitle and stay unique, so title-based dedup catches the real
    // duplicates without the false positives.
    // ────────────────────────────────────────────────────────────────────

    private val _savedTitles = MutableStateFlow<Set<String>>(emptySet())
    /** Normalised titles of every note in the library. Rebuilt after
     *  every reindex by [backfillTitlesFromLibrary]. */
    val savedTitles: StateFlow<Set<String>> = _savedTitles.asStateFlow()
    // v5.4.275cc — SavePromptBar must not decide "not saved" while the
    // asynchronous 42K-note title cache is still being rebuilt.
    private val _savedTitlesReady = MutableStateFlow(false)
    val savedTitlesReady: StateFlow<Boolean> = _savedTitlesReady.asStateFlow()

    /**
     * v5.4.102cc — Normalise a title or heading string for match
     * comparison. Aggressive lowercase-and-strip-punctuation so
     * "The Watchtower — 2024" and "the watchtower 2024" both fold to
     * the same key. Uses `\p{IsLatin}` alongside `[a-z0-9]` so Sepedi
     * diacritics survive normalisation instead of getting dropped as
     * "punctuation". Blank strings pass through unchanged.
     */
    private fun normalizeTitle(raw: String): String {
        if (raw.isBlank()) return ""
        val lower = raw.trim().lowercase()
        val stripped = lower.replace(Regex("[^\\p{IsLatin}0-9\\s]+"), " ")
        var normalized = stripped.replace(Regex("\\s+"), " ").trim()
        // Browser <title> values often append a site label that is absent from
        // the saved Markdown heading. Remove only known site suffixes; never
        // truncate arbitrary article subtitles.
        val suffixes = listOf(
            " watchtower online library",
            " wol jw org",
            " jw org"
        )
        for (suffix in suffixes) {
            if (normalized.endsWith(suffix) && normalized.length - suffix.length >= 15) {
                normalized = normalized.removeSuffix(suffix).trim()
                break
            }
        }
        return normalized
    }

    /**
     * v5.4.102cc — Add a title to the cache. Called from every
     * successful save site ([saveBatchItem], [saveOfflineHtmlPage],
     * [saveConvertedMarkdown]) so the cache stays in step with the
     * library without needing a reindex. Silently no-ops on blank
     * input.
     *
     * v5.4.103cc — Renamed from `markTitleAndFileNameAsSaved`; only
     * the title is tracked now (see class-header note).
     */
    fun markTitleAsSaved(title: String) {
        val nt = normalizeTitle(title)
        if (nt.isBlank()) return
        val cur = _savedTitles.value
        if (nt in cur) return
        _savedTitles.value = cur + nt
    }

    /**
     * v5.4.102cc — Rebuild the title cache from `dao.allMeta()`.
     * Fired from VM init and after every successful reindex, so
     * newly imported files land in the cache without requiring an
     * app restart.
     *
     * Runs on Dispatchers.IO to avoid stalling the main thread during
     * the SQLite scan; publishes to the StateFlow via Dispatchers.Main
     * so downstream observers (batch dedup filter, prompt bar, etc.)
     * see the update on the UI thread.
     */
    fun backfillTitlesFromLibrary() {
        _savedTitlesReady.value = false
        viewModelScope.launch(Dispatchers.IO) {
            val meta = runCatching { dao.allMeta() }.getOrElse {
                withContext(Dispatchers.Main) { _savedTitlesReady.value = true }
                return@launch
            }
            if (meta.isEmpty()) {
                withContext(Dispatchers.Main) { _savedTitlesReady.value = true }
                return@launch
            }
            val titles = HashSet<String>()
            for (m in meta) {
                val nt = normalizeTitle(m.title)
                if (nt.isNotBlank()) titles.add(nt)
            }
            withContext(Dispatchers.Main) {
                _savedTitles.value = titles
                _savedTitlesReady.value = true
            }
            logActivity(
                com.tebogo.markvault.data.ActivityLog.Category.BATCH_SAVE,
                "Title cache rebuilt",
                mapOf(
                    "notes" to meta.size.toString(),
                    "titles" to titles.size.toString()
                )
            )
        }
    }

    /**
     * v5.4.104cc — Standalone title-only dedup check for callers that
     * don't have a full [WebSelectionItem] on hand — the [SavePromptBar]
     * uses this to hide the "This article isn't saved" pill when the
     * current page's `<title>` matches something already in the library
     * (typical case: user saved the article as markdown a while back,
     * the URL was blank / different, but the title is stable).
     *
     * Same ≥15-char guard as [isBatchItemAlreadySaved] so generic
     * page titles like "Home" / "Search" don't produce false
     * positives.
     */
    fun isTitleAlreadySaved(title: String): Boolean {
        if (!_dedupByTitle.value) return false
        val nt = normalizeTitle(title)
        if (nt.length < 15) return false
        return nt in _savedTitles.value
    }

    /**
     * Unified WebViewer duplicate check. URL is authoritative when enabled; title/heading
     * is the cross-format fallback that lets an online article match a Markdown copy.
     */
    fun isWebPageAlreadySaved(url: String, title: String): Boolean {
        if (_dedupByUrl.value && isUrlAlreadySaved(url)) return true
        if (_dedupByTitle.value && isTitleAlreadySaved(title)) return true
        return false
    }

    // v5.4.109cc — Dedup-signal toggles. Cached as StateFlows so
    // isBatchItemAlreadySaved can read them synchronously without
    // suspending. Backed by DataStore prefs; the Settings screen
    // exposes the toggles to the user.
    private val _dedupByUrl = MutableStateFlow(true)
    val dedupByUrl: StateFlow<Boolean> = _dedupByUrl.asStateFlow()
    private val _dedupByTitle = MutableStateFlow(true)
    val dedupByTitle: StateFlow<Boolean> = _dedupByTitle.asStateFlow()

    fun setDedupByUrl(v: Boolean) {
        _dedupByUrl.value = v
        viewModelScope.launch { runCatching { prefs.setDedupByUrl(v) } }
    }
    fun setDedupByTitle(v: Boolean) {
        _dedupByTitle.value = v
        viewModelScope.launch { runCatching { prefs.setDedupByTitle(v) } }
    }

    // v5.4.111cc — Search-chip visibility toggles. All default true so the
    // Search screen is unchanged until the user hides chips in Settings.
    // Backed by DataStore; exposed as StateFlows so the Search screen's
    // chip row can read them synchronously via collectAsStateWithLifecycle.
    val chipSemantic: StateFlow<Boolean> =
        prefs.chipSemantic.stateIn(viewModelScope, SharingStarted.Eagerly, true)
    val chipRerank: StateFlow<Boolean> =
        prefs.chipRerank.stateIn(viewModelScope, SharingStarted.Eagerly, true)
    val chipRerankPct: StateFlow<Boolean> =
        prefs.chipRerankPct.stateIn(viewModelScope, SharingStarted.Eagerly, true)
    val chipSemanticPct: StateFlow<Boolean> =
        prefs.chipSemanticPct.stateIn(viewModelScope, SharingStarted.Eagerly, true)
    val chipAccurate: StateFlow<Boolean> =
        prefs.chipAccurate.stateIn(viewModelScope, SharingStarted.Eagerly, true)

    fun setChipSemantic(v: Boolean) { viewModelScope.launch { runCatching { prefs.setChipSemantic(v) } } }
    fun setChipRerank(v: Boolean) { viewModelScope.launch { runCatching { prefs.setChipRerank(v) } } }
    fun setChipRerankPct(v: Boolean) { viewModelScope.launch { runCatching { prefs.setChipRerankPct(v) } } }
    fun setChipSemanticPct(v: Boolean) { viewModelScope.launch { runCatching { prefs.setChipSemanticPct(v) } } }
    fun setChipAccurate(v: Boolean) { viewModelScope.launch { runCatching { prefs.setChipAccurate(v) } } }

    // v5.4.114cc — Expressive motion plugin. Master toggle + profile.
    // Both drive MarkVaultTheme (see MainActivity). Default OFF so the
    // app is unchanged until the user opts in.
    val motionEnabled: StateFlow<Boolean> =
        prefs.motionEnabled.stateIn(viewModelScope, SharingStarted.Eagerly, false)
    val motionProfile: StateFlow<String> =
        prefs.motionProfile.stateIn(viewModelScope, SharingStarted.Eagerly, "EXPRESSIVE")
    fun setMotionEnabled(v: Boolean) { viewModelScope.launch { runCatching { prefs.setMotionEnabled(v) } } }
    fun setMotionProfile(name: String) { viewModelScope.launch { runCatching { prefs.setMotionProfile(name) } } }

    // v5.4.162cc — UI Animations master toggle + speed multiplier.
    // Separate system from Expressive motion above (see Prefs.kt
    // comment) — this one is ON by default and governs the v5.4.157cc
    // through v5.4.161cc animation work (search stagger, FAB bounce,
    // tab slide, shimmer, parallax, swipe-dismiss, typewriter, foldable
    // callouts, theme-color transition).
    val uiAnimEnabled: StateFlow<Boolean> =
        prefs.uiAnimEnabled.stateIn(viewModelScope, SharingStarted.Eagerly, true)
    val uiAnimSpeed: StateFlow<Float> =
        prefs.uiAnimSpeed.stateIn(viewModelScope, SharingStarted.Eagerly, 1.0f)
    fun setUiAnimEnabled(v: Boolean) { viewModelScope.launch { runCatching { prefs.setUiAnimEnabled(v) } } }
    fun setUiAnimSpeed(v: Float) { viewModelScope.launch { runCatching { prefs.setUiAnimSpeed(v) } } }
    // v5.4.164cc — Animation style pick ("BOUNCE", "ZOOM", "WIGGLE",
    // "SPIN", "FLIP", or "RANDOM_MIX"). Default matches Prefs' default.
    val uiAnimStyle: StateFlow<String> =
        prefs.uiAnimStyle.stateIn(viewModelScope, SharingStarted.Eagerly, "BOUNCE")
    fun setUiAnimStyle(name: String) { viewModelScope.launch { runCatching { prefs.setUiAnimStyle(name) } } }

    // ────────────────────────────────────────────────────────────────────
    // v5.4.105cc — "Is this article in my library?" WebViewer check.
    //
    // Fires from the WebViewer's overflow menu. Given the current page's
    // URL and <title>, finds every library note that matches EITHER
    // signal so the user can open the actual file(s) to verify. The
    // check is asynchronous — a small loading pill shows in the top-
    // left while the DB scan runs (usually <150 ms on 14K notes), then
    // a toast reports the result and a dialog offers an open action.
    // ────────────────────────────────────────────────────────────────────

    /**
     * Result state for the "Check in library" flow. Consumed by
     * [WebSearchScreen] and [WebPopup] to render the loading pill and
     * the follow-up dialog.
     */
    sealed class LibraryCheckState {
        data object Idle : LibraryCheckState()
        data object AutoSaveNotification : LibraryCheckState()  // v5.4.146cc — 2-second auto-save notification
        data class Loading(val url: String, val title: String) : LibraryCheckState()
        data class Result(
            val url: String,
            val title: String,
            val matches: List<com.tebogo.markvault.data.NoteMeta>
        ) : LibraryCheckState()
    }

    private val _libraryCheckState =
        MutableStateFlow<LibraryCheckState>(LibraryCheckState.Idle)
    val libraryCheckState: StateFlow<LibraryCheckState> =
        _libraryCheckState.asStateFlow()

    fun dismissLibraryCheck() {
        _libraryCheckState.value = LibraryCheckState.Idle
    }

    /**
     * Kick off the check. Sets state to [LibraryCheckState.Loading]
     * (drives the top-left pill), runs the DB scan on Dispatchers.IO,
     * then publishes [LibraryCheckState.Result] which is picked up
     * by the WebViewer's toast + dialog logic.
     *
     * Search strategy — three parallel branches, results deduped by
     * note id at the end:
     *   1. Canonical URL match against every note carrying a
     *      `source:` prefix in its content (fast LIKE on the FTS
     *      column). Uses [notesForUrlHarvest] then filters in-memory
     *      by canonical form so trailing-slash / fragment / mixed-
     *      case differences don't miss.
     *   2. Fuzzy title match via [dao.searchTitles] using the
     *      normalised title. Returns everything with a matching
     *      substring so "The 2024 Watchtower — Study" catches
     *      "2024 Watchtower Study Edition" too.
     *   3. If no matches yet, a broader FTS scan over the full
     *      content for the normalised title tokens. Catches notes
     *      that reference the article but don't carry its title in
     *      the metadata (rare — usually re-shares or citations).
     */
    fun checkArticleInLibrary(url: String, title: String, pageHtml: String = "") {
        if (url.isBlank() && title.isBlank()) {
            _libraryCheckState.value = LibraryCheckState.Idle
            return
        }
        _libraryCheckState.value = LibraryCheckState.Loading(url, title)
        viewModelScope.launch(Dispatchers.IO) {
            // First check if auto-save is enabled
            val autoSaveEnabled = enableWebAutosave.value
            var matches = LinkedHashMap<Long, com.tebogo.markvault.data.NoteMeta>()

            // Branch 1 — URL match. Only if we have a URL.
            if (url.isNotBlank()) {
                val canonical = canonicalizeUrl(url)
                runCatching {
                    val rows = dao.notesForUrlHarvest()
                    val collected = HashSet<String>()
                    val idByUrl = HashMap<String, MutableList<Long>>()
                    for (row in rows) {
                        val urls = HashSet<String>()
                        extractUrlsFromNoteContent(row.content, urls)
                        for (u in urls) {
                            idByUrl.getOrPut(u) { mutableListOf() }.add(row.id)
                            collected.add(u)
                        }
                    }
                    val hitIds = idByUrl[canonical] ?: emptyList()
                    if (hitIds.isNotEmpty()) {
                        val meta = dao.allMeta().associateBy { it.id }
                        for (id in hitIds) meta[id]?.let { matches[it.id] = it }
                    }
                }
            }

            // Branch 2 — Fuzzy title match (case-insensitive). Only if we have a title >= 8 chars
            if (title.isNotBlank() && title.length >= 8) {
                runCatching {
                    val like = "%${title.trim().replace("'", "''")}%"
                    val rows = dao.searchTitles(like)
                    // Case-insensitive matching
                    for (m in rows) {
                        if (m.title.equals(title, ignoreCase = true)) {
                            matches[m.id] = m
                        }
                    }
                }
            }

            // Branch 3 — Fallback FTS on normalized title tokens
            if (matches.isEmpty() && title.isNotBlank()) {
                val nt = normalizeTitle(title)
                if (nt.length >= 15) {
                    val tokens = nt.split(" ")
                        .filter { it.length >= 4 }
                        .sortedByDescending { it.length }
                        .take(3)
                    if (tokens.isNotEmpty()) {
                        val q = tokens.joinToString(" ")
                        runCatching {
                            val rows = dao.search(q)
                            val meta = dao.allMeta().associateBy { it.id }
                            for (r in rows.take(10)) {
                                meta[r.id]?.let { matches[it.id] = it }
                            }
                        }
                    }
                }
            }

            // v5.4.147cc — Auto-save logic with improved feedback
            if (matches.isEmpty() && autoSaveEnabled) {
                // Article not in library and auto-save is ON
                if (pageHtml.isNotBlank()) {
                    // Have HTML - proceed with save
                    val saveResult = saveOfflineHtmlPage(url, title, pageHtml)
                    withContext(Dispatchers.Main) {
                        if (saveResult is SaveResult.Ok) {
                            // Show success notification
                            _libraryCheckState.value = LibraryCheckState.AutoSaveNotification
                            viewModelScope.launch {
                                delay(3500)  // v5.4.147cc — Extended to 3.5 seconds for better visibility
                                _libraryCheckState.value = LibraryCheckState.Idle
                            }
                        } else {
                            // Save failed, show error
                            _libraryCheckState.value = LibraryCheckState.Result(
                                url = url,
                                title = title,
                                matches = emptyList()
                            )
                        }
                    }
                } else {
                    // No HTML available - still try to save with URL/title
                    // (This handles cases where HTML extraction failed but user wants to save)
                    val saveResult = saveOfflineHtmlPage(url, title, "<!-- Auto-saved via URL --><html><head><title>$title</title></head><body><p>Saved from: $url</p></body></html>")
                    withContext(Dispatchers.Main) {
                        if (saveResult is SaveResult.Ok) {
                            _libraryCheckState.value = LibraryCheckState.AutoSaveNotification
                            viewModelScope.launch {
                                delay(3500)
                                _libraryCheckState.value = LibraryCheckState.Idle
                            }
                        } else {
                            // Fallback: show normal result if auto-save failed
                            _libraryCheckState.value = LibraryCheckState.Result(
                                url = url,
                                title = title,
                                matches = emptyList()
                            )
                        }
                    }
                }
            } else {
                withContext(Dispatchers.Main) {
                    _libraryCheckState.value = LibraryCheckState.Result(
                        url = url,
                        title = title,
                        matches = matches.values.toList()
                    )
                }
            }
        }
    }

    /**
     * v5.4.102cc — Multi-signal dedup check for a single batch item.
     * Returns true if EITHER of the following match a note already in
     * the library:
     *
     *   1. **URL** — canonicalised (see [isUrlAlreadySaved]).
     *   2. **Title** — the anchor text captured on the head page
     *      (`item.title`), normalised, matched against every library
     *      note's normalised title.
     *
     * Guard: title leg is skipped for very short strings (< 15 chars)
     * to avoid false positives from generic anchor text like "Read
     * more", "View", "Previous", etc. URL match still applies at any
     * length.
     *
     * v5.4.103cc — Filename leg removed (see class-header note).
     *
     * v5.4.109cc — Each leg is now gated on a user toggle
     * ([dedupByUrl] / [dedupByTitle]). Both default ON so behaviour
     * is unchanged unless the user opts out; turning either off is
     * useful for diagnosing "why is 980 of 1000 skipped?" — flip title
     * matching off to see if URL matches account for the skip count on
     * their own.
     */
    fun isBatchItemAlreadySaved(item: WebSelectionItem): Boolean {
        if (_dedupByUrl.value && isUrlAlreadySaved(item.url)) return true
        if (!_dedupByTitle.value) return false
        val nt = normalizeTitle(item.title)
        if (nt.length < 15) return false
        if (nt in _savedTitles.value) return true
        return false
    }

    /**
     * v5.4.102cc — Bulk variant of [isBatchItemAlreadySaved]. Returns
     * the URLs of items already in the library. Used by
     * [HiddenBatchSaver]'s dedup filter so the batch save shows
     * accurate "already saved" counts BEFORE the network fetch
     * starts.
     */
    fun batchItemsAlreadySaved(items: List<WebSelectionItem>): Set<String> {
        if (items.isEmpty()) return emptySet()
        val out = HashSet<String>()
        for (item in items) {
            if (isBatchItemAlreadySaved(item)) out.add(item.url)
        }
        return out
    }

    /** v5.4.112cc — Per-item dedup detail so the dashboard can show
     *  WHICH files were skipped and WHY. */
    data class DupeDetail(val title: String, val reason: String)

    /**
     * v5.4.112cc — Like [batchItemsAlreadySaved] but returns a map of
     * url→[DupeDetail] carrying the human-readable reason each item was
     * flagged as a duplicate ("URL match" or "title match"). Powers the
     * dashboard's transparent skip list. Respects the same
     * [dedupByUrl] / [dedupByTitle] toggles as the single-item check.
     */
    fun batchDupeDetails(items: List<WebSelectionItem>): Map<String, DupeDetail> {
        if (items.isEmpty()) return emptyMap()
        val out = LinkedHashMap<String, DupeDetail>()
        for (item in items) {
            val reason = when {
                _dedupByUrl.value && isUrlAlreadySaved(item.url) -> "URL match"
                _dedupByTitle.value && run {
                    val nt = normalizeTitle(item.title)
                    nt.length >= 15 && nt in _savedTitles.value
                } -> "title match"
                else -> null
            }
            if (reason != null) {
                out[item.url] = DupeDetail(item.title, reason)
            }
        }
        return out
    }

    /**
     * Start the [BatchSaveService] foreground service so the batch save
     * gets a persistent notification with a progress bar, a wake lock
     * keeping the CPU alive with the screen off, and elevated process
     * priority so backgrounding / multitasking within MarkVault doesn't
     * kill the in-flight WebView loads. Idempotent — a duplicate start
     * just refreshes the notification.
     *
     * The service observes [webSelectionSaving] to update the notification
     * and stops itself when progress returns to (0, 0). See
     * [BatchSaveService] for the full contract.
     */
    fun startBatchSaveService(ctx: android.content.Context) {
        val intent = android.content.Intent(
            ctx.applicationContext,
            com.tebogo.markvault.ui.BatchSaveService::class.java
        )
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            ctx.applicationContext.startForegroundService(intent)
        } else {
            ctx.applicationContext.startService(intent)
        }
    }

    fun stopBatchSaveService(ctx: android.content.Context) {
        val intent = android.content.Intent(
            ctx.applicationContext,
            com.tebogo.markvault.ui.BatchSaveService::class.java
        )
        runCatching { ctx.applicationContext.stopService(intent) }
    }

    /**
     * Pull the `<title>` out of a raw HTML string. Regex-based rather than
     * DOM-parse-based because we're on the IO dispatcher and don't want to
     * spin up Jsoup for a one-line extraction. Handles attributes on the
     * title tag and leading/trailing whitespace; anything else falls
     * through and the caller uses the anchor's text as a fallback.
     */
    private fun extractHtmlTitle(html: String): String? {
        val re = Regex("<title[^>]*>([\\s\\S]*?)</title>", RegexOption.IGNORE_CASE)
        val raw = re.find(html)?.groupValues?.getOrNull(1)?.trim() ?: return null
        // Basic HTML-entity decoding for the handful of characters that
        // commonly appear in page titles.
        val decoded = raw
            .replace("&amp;", "&")
            .replace("&lt;", "<")
            .replace("&gt;", ">")
            .replace("&quot;", "\"")
            .replace("&#39;", "'")
            .replace(Regex("\\s+"), " ")
            .trim()
        return decoded.takeIf { it.isNotBlank() }
    }

    fun setFontScale(v: Float) { viewModelScope.launch { prefs.setFontScale(v) } }
    fun setTheme(name: String) { viewModelScope.launch { prefs.setTheme(name) } }
    fun setAppAppearanceMode(mode: String) { viewModelScope.launch { prefs.setAppAppearanceMode(mode) } }
    fun setCustomThemeJson(json: String) { viewModelScope.launch { prefs.setCustomThemeJson(json) } }
    private fun parseObsidianOverridesForTheme(raw: String, themeId: String): Map<String, String> {
        if (themeId.isBlank()) return emptyMap()
        val root = runCatching { JSONObject(raw) }.getOrNull() ?: return emptyMap()
        val obj = root.optJSONObject(themeId) ?: return emptyMap()
        val out = linkedMapOf<String, String>()
        val keys = obj.keys()
        while (keys.hasNext()) {
            val key = keys.next()
            val value = obj.optString(key)
            if (key.startsWith("--") && value.isNotBlank()) out[key] = value
        }
        return out
    }

    private fun parseObsidianAppearanceForTheme(raw: String, themeId: String): String {
        if (themeId.isBlank()) return "system"
        val mode = runCatching { JSONObject(raw).optJSONObject(themeId)?.optString("__appearance") }.getOrNull()
            ?.lowercase()
        return if (mode == "light" || mode == "dark") mode else "system"
    }

    fun obsidianAppearanceModeForTheme(themeId: String): String =
        parseObsidianAppearanceForTheme(obsidianThemeOverridesRaw.value, themeId)

    private fun replaceObsidianAppearanceForTheme(raw: String, themeId: String, mode: String): String {
        if (themeId.isBlank()) return raw
        val root = runCatching { JSONObject(raw) }.getOrElse { JSONObject() }
        val obj = root.optJSONObject(themeId) ?: JSONObject()
        val safeMode = if (mode == "light" || mode == "dark") mode else "system"
        obj.put("__appearance", safeMode)
        root.put(themeId, obj)
        return root.toString()
    }

    private fun removeObsidianProfileForTheme(raw: String, themeId: String): String {
        val root = runCatching { JSONObject(raw) }.getOrElse { JSONObject() }
        root.remove(themeId)
        return root.toString()
    }

    private fun replaceObsidianOverridesForTheme(raw: String, themeId: String, values: Map<String, String>): String {
        val root = runCatching { JSONObject(raw) }.getOrElse { JSONObject() }
        val existingMode = parseObsidianAppearanceForTheme(raw, themeId)
        val obj = JSONObject()
        values.toSortedMap().forEach { (key, value) ->
            if (key.startsWith("--") && value.isNotBlank()) obj.put(key, value)
        }
        obj.put("__appearance", existingMode)
        root.put(themeId, obj)
        return root.toString()
    }

    /** Preview is in-memory only: original theme files and the vault are untouched. */
    fun previewObsidianThemeOverrides(values: Map<String, String>) {
        val id = obsidianThemeId.value
        if (id.isBlank()) return
        obsidianPreviewJob?.cancel()
        obsidianPreviewJob = viewModelScope.launch {
            val preview = withContext(Dispatchers.IO) {
                obsidianThemeManager.applyOverrides(obsidianThemeManager.load(id), values)
            }
            if (obsidianThemeId.value == id) _activeObsidianTheme.value = preview
        }
    }

    fun cancelObsidianThemePreview() {
        obsidianPreviewJob?.cancel()
        obsidianPreviewJob = null
        val id = obsidianThemeId.value
        val persisted = parseObsidianOverridesForTheme(obsidianThemeOverridesRaw.value, id)
        _activeObsidianOverrides.value = persisted
        _activeObsidianAppearanceMode.value = parseObsidianAppearanceForTheme(obsidianThemeOverridesRaw.value, id)
        viewModelScope.launch {
            _activeObsidianTheme.value = withContext(Dispatchers.IO) {
                obsidianThemeManager.applyOverrides(obsidianThemeManager.load(id), persisted)
            }
        }
    }

    fun saveObsidianThemeOverrides(values: Map<String, String>) {
        obsidianPreviewJob?.cancel()
        obsidianPreviewJob = null
        val id = obsidianThemeId.value
        if (id.isBlank()) return
        viewModelScope.launch {
            val newRaw = replaceObsidianOverridesForTheme(obsidianThemeOverridesRaw.value, id, values)
            prefs.setObsidianThemeOverridesRaw(newRaw)
            _activeObsidianOverrides.value = values.toMap()
            _obsidianThemeStatus.value = if (values.isEmpty()) "Theme customizations reset." else "Theme customizations saved."
        }
    }

    fun previewObsidianAppearanceMode(mode: String) {
        _activeObsidianAppearanceMode.value = if (mode == "light" || mode == "dark") mode else "system"
    }

    fun saveObsidianThemeProfile(values: Map<String, String>, mode: String) {
        obsidianPreviewJob?.cancel()
        obsidianPreviewJob = null
        val id = obsidianThemeId.value
        if (id.isBlank()) return
        val safeMode = if (mode == "light" || mode == "dark") mode else "system"
        viewModelScope.launch {
            val withOverrides = replaceObsidianOverridesForTheme(obsidianThemeOverridesRaw.value, id, values)
            val combined = replaceObsidianAppearanceForTheme(withOverrides, id, safeMode)
            prefs.setObsidianThemeOverridesRaw(combined)
            _activeObsidianOverrides.value = values.toMap()
            _activeObsidianAppearanceMode.value = safeMode
            _obsidianThemeStatus.value = "Theme customizations saved."
        }
    }

    fun saveObsidianAppearanceMode(mode: String) {
        val id = obsidianThemeId.value
        if (id.isBlank()) return
        val safe = if (mode == "light" || mode == "dark") mode else "system"
        viewModelScope.launch {
            prefs.setObsidianThemeOverridesRaw(
                replaceObsidianAppearanceForTheme(obsidianThemeOverridesRaw.value, id, safe)
            )
            _activeObsidianAppearanceMode.value = safe
            _obsidianThemeStatus.value = "Theme appearance set to ${safe.replaceFirstChar { it.uppercase() }}."
        }
    }

    fun loadObsidianThemePreview(id: String) {
        _obsidianPreviewPayload.value = null
        viewModelScope.launch {
            val payload = withContext(Dispatchers.IO) {
                val overrides = parseObsidianOverridesForTheme(obsidianThemeOverridesRaw.value, id)
                obsidianThemeManager.applyOverrides(obsidianThemeManager.load(id), overrides)
            }
            _obsidianPreviewPayload.value = payload
            if (payload == null) _obsidianThemeStatus.value = "Theme preview could not be loaded."
        }
    }

    fun clearObsidianThemePreview() { _obsidianPreviewPayload.value = null }

    fun exportObsidianThemeProfiles(uri: Uri) {
        viewModelScope.launch(Dispatchers.IO) {
            runCatching {
                val root = JSONObject().apply {
                    put("format", "markvault-obsidian-theme-profiles")
                    put("version", 1)
                    put("profiles", JSONObject(obsidianThemeOverridesRaw.value))
                }
                getApplication<Application>().contentResolver.openOutputStream(uri, "w")?.use { out ->
                    out.writer(Charsets.UTF_8).use { it.write(root.toString(2)) }
                } ?: error("Could not open export destination.")
            }.onSuccess {
                _obsidianThemeStatus.value = "Theme profiles exported."
            }.onFailure { error ->
                _obsidianThemeStatus.value = "Theme profile export failed: ${error.message ?: "Unknown error"}"
            }
        }
    }

    fun importObsidianThemeProfiles(uri: Uri) {
        viewModelScope.launch(Dispatchers.IO) {
            runCatching {
                val text = getApplication<Application>().contentResolver.openInputStream(uri)?.use { input ->
                    input.bufferedReader().readText()
                } ?: error("Could not read profile file.")
                require(text.length <= 1_000_000) { "Theme profile file is too large." }
                val outer = JSONObject(text)
                val profiles = if (outer.optString("format") == "markvault-obsidian-theme-profiles") {
                    outer.optJSONObject("profiles") ?: JSONObject()
                } else outer
                // Merge imported profiles into existing MarkVault profiles so importing
                // one backup never erases customizations for themes not present in it.
                val cleanRoot = runCatching { JSONObject(obsidianThemeOverridesRaw.value) }.getOrElse { JSONObject() }
                val themeKeys = profiles.keys()
                while (themeKeys.hasNext()) {
                    val themeId = themeKeys.next()
                    if (themeId.isBlank() || themeId.contains('/') || themeId.contains('\\') || themeId.contains("..")) continue
                    val source = profiles.optJSONObject(themeId) ?: continue
                    val clean = JSONObject()
                    val appearance = source.optString("__appearance").lowercase()
                    clean.put("__appearance", if (appearance == "light" || appearance == "dark") appearance else "system")
                    val keys = source.keys()
                    while (keys.hasNext()) {
                        val key = keys.next()
                        if (!key.matches(Regex("^--[A-Za-z0-9_-]+$"))) continue
                        val value = source.optString(key).trim().take(220)
                        val lower = value.lowercase()
                        if (value.isBlank() || value.contains(';') || value.contains('{') || value.contains('}') ||
                            lower.contains("javascript:") || lower.contains("expression(") || lower.contains("@import") || lower.contains("url(")) continue
                        clean.put(key, value)
                    }
                    cleanRoot.put(themeId, clean)
                }
                prefs.setObsidianThemeOverridesRaw(cleanRoot.toString())
            }.onSuccess {
                _obsidianThemeStatus.value = "Theme profiles imported."
            }.onFailure { error ->
                _obsidianThemeStatus.value = "Theme profile import failed: ${error.message ?: "Unknown error"}"
            }
        }
    }

    fun analyzeObsidianThemeCompatibility(id: String) {
        viewModelScope.launch {
            _obsidianCompatibilityReport.value = null
            _obsidianThemeStatus.value = "Analyzing theme compatibility…"
            val report = withContext(Dispatchers.IO) { obsidianThemeManager.compatibilityReport(id) }
            _obsidianCompatibilityReport.value = report
            _obsidianThemeStatus.value = if (report == null) "Theme could not be analyzed." else "Compatibility analysis complete."
        }
    }

    fun clearObsidianCompatibilityReport() {
        _obsidianCompatibilityReport.value = null
    }

    fun importObsidianTheme(uri: Uri) {
        viewModelScope.launch {
            _obsidianThemeStatus.value = "Importing Obsidian theme…"
            val result = withContext(Dispatchers.IO) { obsidianThemeManager.importTheme(uri) }
            result.onSuccess { info ->
                _installedObsidianThemes.value = withContext(Dispatchers.IO) { obsidianThemeManager.listInstalled() }
                prefs.setObsidianThemeId(info.id)
                prefs.setTheme("obsidian_imported")
                val persistedOverrides = parseObsidianOverridesForTheme(obsidianThemeOverridesRaw.value, info.id)
                _activeObsidianOverrides.value = persistedOverrides
                _activeObsidianAppearanceMode.value = parseObsidianAppearanceForTheme(obsidianThemeOverridesRaw.value, info.id)
                _activeObsidianTheme.value = withContext(Dispatchers.IO) {
                    obsidianThemeManager.applyOverrides(obsidianThemeManager.load(info.id), persistedOverrides)
                }
                _obsidianThemeStatus.value = "Installed ${info.name}"
            }.onFailure { error ->
                _obsidianThemeStatus.value = "Theme import failed: ${error.message ?: "Unknown error"}"
            }
        }
    }

    fun activateObsidianTheme(id: String) {
        viewModelScope.launch {
            val payload = withContext(Dispatchers.IO) { obsidianThemeManager.load(id) }
            if (payload == null) {
                _obsidianThemeStatus.value = "Theme could not be loaded."
                return@launch
            }
            prefs.setObsidianThemeId(id)
            prefs.setTheme("obsidian_imported")
            val persistedOverrides = parseObsidianOverridesForTheme(obsidianThemeOverridesRaw.value, id)
            _activeObsidianOverrides.value = persistedOverrides
            _activeObsidianAppearanceMode.value = parseObsidianAppearanceForTheme(obsidianThemeOverridesRaw.value, id)
            _activeObsidianTheme.value = withContext(Dispatchers.IO) {
                obsidianThemeManager.applyOverrides(payload, persistedOverrides)
            }
            _obsidianThemeStatus.value = "Applied ${payload.info.name}"
        }
    }

    fun loadObsidianCommunityThemes(force: Boolean = false) {
        if (_obsidianCommunityLoading.value) return
        if (!force && _obsidianCommunityThemes.value.isNotEmpty()) return
        viewModelScope.launch {
            _obsidianCommunityLoading.value = true
            _obsidianThemeStatus.value = "Loading official Obsidian community themes…"
            val result = withContext(Dispatchers.IO) { obsidianThemeManager.fetchCommunityCatalog() }
            result.onSuccess { themes ->
                _obsidianCommunityThemes.value = themes
                _obsidianThemeStatus.value = "Loaded ${themes.size} community themes."
            }.onFailure { error ->
                _obsidianThemeStatus.value = "Community theme list failed: ${error.message ?: "Unknown error"}"
            }
            _obsidianCommunityLoading.value = false
        }
    }

    fun installObsidianCommunityTheme(entry: com.tebogo.markvault.data.ObsidianCommunityTheme) {
        if (_obsidianCommunityInstallingRepo.value != null) return
        viewModelScope.launch {
            _obsidianCommunityInstallingRepo.value = entry.repo
            _obsidianThemeStatus.value = "Installing ${entry.name}…"
            val result = try {
                withContext(Dispatchers.IO) { obsidianThemeManager.installCommunityTheme(entry) }
            } catch (t: Throwable) {
                Result.failure(t)
            }
            result.onSuccess { info ->
                val persistedOverrides = parseObsidianOverridesForTheme(obsidianThemeOverridesRaw.value, info.id)
                val effectivePayload = withContext(Dispatchers.IO) {
                    obsidianThemeManager.applyOverrides(obsidianThemeManager.load(info.id), persistedOverrides)
                }
                if (effectivePayload == null || effectivePayload.css.isBlank()) {
                    _obsidianThemeStatus.value = "Theme downloaded but could not be applied safely."
                } else {
                    _installedObsidianThemes.value = withContext(Dispatchers.IO) { obsidianThemeManager.listInstalled() }
                    _activeObsidianOverrides.value = persistedOverrides
                    _activeObsidianAppearanceMode.value = parseObsidianAppearanceForTheme(obsidianThemeOverridesRaw.value, info.id)
                    _activeObsidianTheme.value = effectivePayload
                    prefs.setObsidianThemeId(info.id)
                    prefs.setTheme("obsidian_imported")
                    _obsidianThemeStatus.value = "Installed and applied ${info.name}."
                }
            }.onFailure { error ->
                _obsidianThemeStatus.value = "Theme install failed: ${error.message ?: "Unknown error"}"
            }
            _obsidianCommunityInstallingRepo.value = null
        }
    }

    fun updateObsidianTheme(id: String) {
        viewModelScope.launch {
            val current = _installedObsidianThemes.value.firstOrNull { it.id == id }
            _obsidianThemeStatus.value = "Updating ${current?.name ?: "theme"}…"
            val result = withContext(Dispatchers.IO) { obsidianThemeManager.updateCommunityTheme(id) }
            result.onSuccess { info ->
                _installedObsidianThemes.value = withContext(Dispatchers.IO) { obsidianThemeManager.listInstalled() }
                if (obsidianThemeId.value == id) {
                    val persistedOverrides = parseObsidianOverridesForTheme(obsidianThemeOverridesRaw.value, id)
                    _activeObsidianOverrides.value = persistedOverrides
                    _activeObsidianAppearanceMode.value = parseObsidianAppearanceForTheme(obsidianThemeOverridesRaw.value, id)
                    _activeObsidianTheme.value = withContext(Dispatchers.IO) {
                        obsidianThemeManager.applyOverrides(obsidianThemeManager.load(id), persistedOverrides)
                    }
                }
                _obsidianThemeStatus.value = "Updated ${info.name}."
            }.onFailure { error ->
                _obsidianThemeStatus.value = "Theme update failed: ${error.message ?: "Unknown error"}"
            }
        }
    }

    fun deleteObsidianTheme(id: String) {
        viewModelScope.launch {
            val wasSelectedId = obsidianThemeId.value == id
            val wasApplied = wasSelectedId && theme.value == "obsidian_imported"
            val deleted = withContext(Dispatchers.IO) { obsidianThemeManager.delete(id) }
            _installedObsidianThemes.value = withContext(Dispatchers.IO) { obsidianThemeManager.listInstalled() }
            if (deleted) {
                val cleanedProfiles = removeObsidianProfileForTheme(obsidianThemeOverridesRaw.value, id)
                prefs.setObsidianThemeOverridesRaw(cleanedProfiles)
            }
            if (deleted && wasSelectedId) {
                prefs.setObsidianThemeId("")
                if (wasApplied) prefs.setTheme("dark")
                _activeObsidianOverrides.value = emptyMap()
                _activeObsidianAppearanceMode.value = "system"
                _activeObsidianTheme.value = null
            }
            _obsidianThemeStatus.value = if (deleted) "Theme removed." else "Theme could not be removed."
        }
    }

    fun clearObsidianThemeStatus() { _obsidianThemeStatus.value = null }
    fun setSmartStylingAllDocs(v: Boolean) { viewModelScope.launch { prefs.setSmartStylingAllDocs(v) } }
    fun setSwipeSwitchTabs(v: Boolean) { viewModelScope.launch { prefs.setSwipeSwitchTabs(v) } }
    fun setTextContrast(v: Float) { viewModelScope.launch { prefs.setTextContrast(v) } }

    // v5.4.145cc — New UI toggle setter functions
    fun setHideWebSearchButtons(v: Boolean) { viewModelScope.launch { prefs.setHideWebSearchButtons(v) } }
    fun setHideSearchChips(v: Boolean) { viewModelScope.launch { prefs.setHideSearchChips(v) } }
    fun setHideEmbeddingSelector(v: Boolean) { viewModelScope.launch { prefs.setHideEmbeddingSelector(v) } }
    fun setHideSearchBarOnScroll(v: Boolean) { viewModelScope.launch { prefs.setHideSearchBarOnScroll(v) } }
    fun setEnableFullscreenMode(v: Boolean) { viewModelScope.launch { prefs.setEnableFullscreenMode(v) } }
    fun setEnableWebAutosave(v: Boolean) { viewModelScope.launch { prefs.setEnableWebAutosave(v) } }
    fun setShowJwSearchButton(v: Boolean) { viewModelScope.launch { prefs.setShowJwSearchButton(v) } }

    val importsSubfolder: StateFlow<String> = prefs.importsSubfolder
        .stateIn(viewModelScope, SharingStarted.Eagerly, "")
    fun setImportsSubfolder(name: String) {
        viewModelScope.launch { prefs.setImportsSubfolder(name) }
    }

    // Web-import include toggles (front-matter / URL / excerpt / body).
    val includeFrontmatter: StateFlow<Boolean> = prefs.includeFrontmatter
        .stateIn(viewModelScope, SharingStarted.Eagerly, true)
    val includeUrl: StateFlow<Boolean> = prefs.includeUrl
        .stateIn(viewModelScope, SharingStarted.Eagerly, true)
    val includeExcerpt: StateFlow<Boolean> = prefs.includeExcerpt
        .stateIn(viewModelScope, SharingStarted.Eagerly, true)
    val includeBody: StateFlow<Boolean> = prefs.includeBody
        .stateIn(viewModelScope, SharingStarted.Eagerly, true)
    fun setIncludeFrontmatter(v: Boolean) { viewModelScope.launch { prefs.setIncludeFrontmatter(v) } }
    fun setIncludeUrl(v: Boolean)         { viewModelScope.launch { prefs.setIncludeUrl(v) } }
    fun setIncludeExcerpt(v: Boolean)     { viewModelScope.launch { prefs.setIncludeExcerpt(v) } }
    fun setIncludeBody(v: Boolean)        { viewModelScope.launch { prefs.setIncludeBody(v) } }

    /**
     * v5.4.10 — Save a PDF file (typically from URL → PDF conversion)
     * into the user's library. Returns the new file's display URI on
     * success, or null on failure. Uses the same library scheme as
     * [saveImportedMarkdown] but with application/pdf mimetype and
     * the bytes copied directly from the temp file.
     */
    suspend fun saveSharedPdfToLibrary(
        tempPdf: java.io.File, fileName: String
    ): String? = withContext(Dispatchers.IO) {
        val libUri = libraryUri.value ?: return@withContext null
        val treeUri = runCatching { Uri.parse(libUri) }.getOrNull() ?: return@withContext null
        val cr = getApplication<Application>().contentResolver
        val hasWrite = cr.persistedUriPermissions.any {
            it.uri == treeUri && it.isWritePermission
        }
        if (!hasWrite) return@withContext null
        try {
            val rootId = android.provider.DocumentsContract.getTreeDocumentId(treeUri)
            val rootDocUri = android.provider.DocumentsContract.buildDocumentUriUsingTree(treeUri, rootId)
            val sub = importsSubfolder.value
            val parentUri = if (sub.isBlank()) rootDocUri else
                findOrCreateFolder(cr, treeUri, rootId, sub) ?: return@withContext null
            val safeName = sanitizeFilename(fileName.removeSuffix(".pdf")) + ".pdf"
            val uniqueName = ensureUnique(cr, treeUri, parentUri, safeName)
            val newDoc = android.provider.DocumentsContract.createDocument(
                cr, parentUri, "application/pdf", uniqueName
            ) ?: return@withContext null
            cr.openOutputStream(newDoc, "w")?.use { out ->
                tempPdf.inputStream().use { input -> input.copyTo(out) }
            } ?: return@withContext null
            viewModelScope.launch { refreshNotes() }
            newDoc.toString()
        } catch (t: Throwable) {
            android.util.Log.e("MarkVault", "saveSharedPdfToLibrary failed", t)
            null
        }
    }

    /**
     * Save a markdown string into the library, inside the configured subfolder.
     * Creates the subfolder lazily if it doesn't exist yet.
     *
     * @param title      base filename (no extension); will be sanitized
     * @param markdown   file body (UTF-8)
     * @param subfolder  subfolder name; empty string = library root
     * @return SaveResult with the new file's display URI on success, or an error message
     */
    suspend fun saveImportedMarkdown(
        title: String, markdown: String, subfolder: String
    ): SaveResult = withContext(Dispatchers.IO) {
        val libUri = libraryUri.value
            ?: return@withContext SaveResult.Error("No library is set. Pick one in Settings first.")
        val treeUri = runCatching { Uri.parse(libUri) }.getOrNull()
            ?: return@withContext SaveResult.Error("Library URI is invalid. Re-pick the library folder.")
        val cr = getApplication<Application>().contentResolver
        // Verify we have write permission persisted; if not, surface a clear error.
        val hasWrite = cr.persistedUriPermissions.any {
            it.uri == treeUri && it.isWritePermission
        }
        if (!hasWrite) {
            return@withContext SaveResult.Error(
                "Library is read-only. Open Settings and tap \u201CRe-grant library access\u201D."
            )
        }
        try {
            val rootId = android.provider.DocumentsContract.getTreeDocumentId(treeUri)
            val rootDocUri = android.provider.DocumentsContract.buildDocumentUriUsingTree(treeUri, rootId)
            val parentUri = if (subfolder.isBlank()) rootDocUri else
                findOrCreateFolder(cr, treeUri, rootId, subfolder)
                    ?: return@withContext SaveResult.Error("Could not create subfolder \"$subfolder\".")

            val safeName = sanitizeFilename(title)
            val fileName = ensureUnique(cr, treeUri, parentUri, safeName)
            val newDoc = android.provider.DocumentsContract.createDocument(
                cr, parentUri, "text/markdown", fileName
            ) ?: return@withContext SaveResult.Error("Failed to create the file.")
            cr.openOutputStream(newDoc, "w")?.use {
                it.write(markdown.toByteArray(Charsets.UTF_8))
            } ?: return@withContext SaveResult.Error("Could not open the new file for writing.")
            // Trigger a quick library refresh so the new note appears
            val cur = libUri
            if (cur != null) viewModelScope.launch { /* lazy reindex hint */ refreshNotes() }
            SaveResult.Ok(newDoc.toString(), fileName, subfolder)
        } catch (e: SecurityException) {
            SaveResult.Error("Permission denied: ${e.message}")
        } catch (e: Exception) {
            SaveResult.Error("Save failed: ${e.message ?: e.javaClass.simpleName}")
        }
    }

    /** Walk the library root, find a folder by name, or create it. Returns the folder doc URI. */
    private fun findOrCreateFolder(
        cr: android.content.ContentResolver, treeUri: Uri, rootId: String, name: String
    ): Uri? {
        val children = android.provider.DocumentsContract.buildChildDocumentsUriUsingTree(treeUri, rootId)
        val proj = arrayOf(
            android.provider.DocumentsContract.Document.COLUMN_DOCUMENT_ID,
            android.provider.DocumentsContract.Document.COLUMN_DISPLAY_NAME,
            android.provider.DocumentsContract.Document.COLUMN_MIME_TYPE
        )
        cr.query(children, proj, null, null, null)?.use { cur ->
            while (cur.moveToNext()) {
                val n = cur.getString(1) ?: continue
                val m = cur.getString(2) ?: ""
                if (n.equals(name, ignoreCase = true) &&
                    m == android.provider.DocumentsContract.Document.MIME_TYPE_DIR) {
                    val did = cur.getString(0)
                    return android.provider.DocumentsContract.buildDocumentUriUsingTree(treeUri, did)
                }
            }
        }
        // Not found — create it
        val rootDocUri = android.provider.DocumentsContract.buildDocumentUriUsingTree(treeUri, rootId)
        return android.provider.DocumentsContract.createDocument(
            cr, rootDocUri, android.provider.DocumentsContract.Document.MIME_TYPE_DIR, name
        )
    }

    /**
     * TASK 2 (v4.4 rewrite): Save the current web page as a real `.html` file.
     *
     * The previous implementation used `WebView.saveWebArchive()`, which only
     * produces `.mhtml` regardless of file extension — the user reported this
     * as "doesn't save offline html, it saves in mhtml". This version takes the
     * page's rendered HTML (already pulled via `document.documentElement.outerHTML`
     * by the caller) and writes it as a self-describing `.html` document with
     * a `<base href>` so relative URLs still resolve to the original site when
     * online. Images/CSS aren't inlined — for fully self-contained archives use
     * MHTML, but the menu label said HTML so HTML is what we save.
     */
    suspend fun autoSaveWebArticle(url: String, title: String, html: String): SaveResult = withContext(Dispatchers.IO) {
        // v5.4.146cc — Auto-save web articles if not in library
        
        // Check if article already in library (case-insensitive)
        var isInLibrary = false
        
        // URL match
        if (url.isNotBlank()) {
            val canonical = canonicalizeUrl(url)
            runCatching {
                val rows = dao.notesForUrlHarvest()
                val idByUrl = HashMap<String, MutableList<Long>>()
                for (row in rows) {
                    val urls = HashSet<String>()
                    extractUrlsFromNoteContent(row.content, urls)
                    for (u in urls) {
                        idByUrl.getOrPut(u) { mutableListOf() }.add(row.id)
                    }
                }
                if ((idByUrl[canonical] ?: emptyList()).isNotEmpty()) {
                    isInLibrary = true
                    return@runCatching
                }
            }
        }
        
        // Title match (case-insensitive)
        if (!isInLibrary && title.isNotBlank() && title.length >= 8) {
            runCatching {
                val like = "%${title.trim().replace("'", "''")}%"
                val rows = dao.searchTitles(like)
                for (row in rows) {
                    if (row.title.equals(title, ignoreCase = true)) {
                        isInLibrary = true
                        break
                    }
                }
            }
        }
        
        if (!isInLibrary) {
            // Not in library — save it
            saveOfflineHtmlPage(url, title, html)
        } else {
            SaveResult.Ok("", "", "")  // Already in library, no action needed
        }
    }

    suspend fun saveOfflineHtmlPage(
        sourceUrl: String, title: String, html: String
    ): SaveResult = withContext(Dispatchers.IO) {
        val libUri = libraryUri.value
            ?: return@withContext SaveResult.Error("No library is set. Pick one in Settings first.")
        val treeUri = runCatching { Uri.parse(libUri) }.getOrNull()
            ?: return@withContext SaveResult.Error("Library URI is invalid.")
        val cr = getApplication<Application>().contentResolver
        val hasWrite = cr.persistedUriPermissions.any {
            it.uri == treeUri && it.isWritePermission
        }
        if (!hasWrite) {
            return@withContext SaveResult.Error("Library is read-only. Re-grant access in Settings.")
        }
        try {
            val subfolder = importsSubfolder.value
            val rootId = android.provider.DocumentsContract.getTreeDocumentId(treeUri)
            val rootDocUri = android.provider.DocumentsContract.buildDocumentUriUsingTree(treeUri, rootId)
            val parentUri = if (subfolder.isBlank()) rootDocUri else
                findOrCreateFolder(cr, treeUri, rootId, subfolder)
                    ?: return@withContext SaveResult.Error("Could not create subfolder.")

            val safeBase = sanitizeFilename(title).removeSuffix(".md")
            val fileName = ensureUniqueAnyExt(cr, treeUri, parentUri, safeBase, ".html")

            // Wrap the page's outerHTML with a clean envelope. If the source
            // already declared `<!DOCTYPE html>` we keep ours anyway — duplicates
            // are harmless and the browser picks the first one.
            val wrappedHtml = buildHtmlEnvelope(sourceUrl, title, html)

            val newDoc = android.provider.DocumentsContract.createDocument(
                cr, parentUri, "text/html", fileName
            ) ?: return@withContext SaveResult.Error("Failed to create HTML file.")
            // v5.5.7 — Do not leave a zero-byte/partial .html behind if the
            // provider refuses the stream or the write fails midway.
            try {
                val out = cr.openOutputStream(newDoc, "w")
                    ?: run {
                        runCatching { android.provider.DocumentsContract.deleteDocument(cr, newDoc) }
                        return@withContext SaveResult.Error("Could not write file.")
                    }
                out.use { stream ->
                    stream.write(wrappedHtml.toByteArray(Charsets.UTF_8))
                    stream.flush()
                }
            } catch (writeError: Exception) {
                runCatching { android.provider.DocumentsContract.deleteDocument(cr, newDoc) }
                return@withContext SaveResult.Error(
                    "Could not write file: ${writeError.message ?: writeError.javaClass.simpleName}"
                )
            }
            // v5.4.93cc — Mark the source URL as saved so the WebViewer
            // "already saved" highlight and the "This isn't saved" prompt
            // both stay in sync with actual writes. Covers the batch flow
            // (which used to mark URLs in saveBatchItem — now redundant),
            // the single-page "Save as Offline HTML" menu item, and any
            // future entry point that reaches this function.
            markUrlAsSaved(sourceUrl)
            // v5.4.102cc — Also mark title + filename for the
            // multi-signal dedup path.
            markTitleAsSaved(title)
            // v5.4.94cc — Activity log entry so the "Saved articles"
            // history in Settings can render the who/what/when.
            logActivity(
                com.tebogo.markvault.data.ActivityLog.Category.SAVED_ARTICLE,
                "Saved offline HTML: $title",
                mapOf(
                    "url" to sourceUrl,
                    "site" to (runCatching { java.net.URI(sourceUrl).host.orEmpty() }
                        .getOrElse { "" }),
                    "format" to "HTML",
                    "file" to fileName
                )
            )
            SaveResult.Ok(newDoc.toString(), fileName, subfolder)
        } catch (e: Exception) {
            SaveResult.Error("Save failed: ${e.message ?: e.javaClass.simpleName}")
        }
    }


    // ────────────────────────────────────────────────────────────────────
    // v5.5.7 — Reliable single-page WebViewer offline-HTML save.
    //
    // Previous UI call sites requested document.documentElement.outerHTML
    // in ONE evaluateJavascript callback, then launched the disk write from
    // a composable scope. Large/dynamic pages could stall that giant JS
    // result, producing no UI feedback at all; leaving the screen could also
    // cancel the composable coroutine before the write/index completed.
    //
    // The new path:
    //   1. Publishes progress immediately (in-app + foreground notification).
    //   2. Snapshots the DOM in WebView, then retrieves it in bounded chunks.
    //   3. Owns capture/write/index orchestration in viewModelScope so a
    //      recomposition/navigation does not silently cancel the save.
    //   4. Reuses the existing saveOfflineHtmlPage + indexNewFile functions,
    //      so filename rules, SAF permissions, saved-URL tracking and indexing
    //      semantics stay unchanged.
    // ────────────────────────────────────────────────────────────────────

    private val _offlineHtmlSaveState = MutableStateFlow(OfflineHtmlSaveState())
    val offlineHtmlSaveState: StateFlow<OfflineHtmlSaveState> =
        _offlineHtmlSaveState.asStateFlow()

    /**
     * Starts saving the currently-rendered WebView page. Returns false only
     * when another single-page save is already running.
     */
    fun saveCurrentWebPageAsOfflineHtml(
        webView: android.webkit.WebView,
        sourceUrl: String,
        title: String
    ): Boolean {
        if (_offlineHtmlSaveState.value.running) return false

        val safeUrl = sourceUrl.ifBlank { webView.url.orEmpty() }
        val safeTitle = title.trim().ifBlank { webView.title.orEmpty().ifBlank { "Web article" } }
        val operationId = android.os.SystemClock.elapsedRealtimeNanos()
        _offlineHtmlSaveState.value = OfflineHtmlSaveState(
            operationId = operationId,
            phase = OfflineHtmlSavePhase.CAPTURING,
            sourceUrl = safeUrl,
            title = safeTitle,
            message = "Capturing the rendered page…"
        )

        val app = getApplication<Application>()
        runCatching {
            val intent = android.content.Intent(
                app,
                com.tebogo.markvault.ui.OfflineHtmlSaveService::class.java
            )
            androidx.core.content.ContextCompat.startForegroundService(app, intent)
        }

        viewModelScope.launch {
            try {
                val html = captureRenderedHtmlInChunks(webView, operationId)
                if (html.isBlank()) {
                    finishOfflineHtmlSaveError(operationId, "The page returned no HTML to save.")
                    return@launch
                }

                updateOfflineHtmlSaveState(
                    operationId,
                    OfflineHtmlSavePhase.WRITING,
                    "Writing ${String.format(java.util.Locale.US, "%,d", html.length)} characters to your library…"
                )
                when (val result = saveOfflineHtmlPage(safeUrl, safeTitle, html)) {
                    is SaveResult.Ok -> {
                        val relPath = if (result.subfolder.isBlank()) result.fileName
                        else "${result.subfolder}/${result.fileName}"
                        updateOfflineHtmlSaveState(
                            operationId,
                            OfflineHtmlSavePhase.INDEXING,
                            "Saved ${result.fileName}; adding it to MarkVault search…",
                            fileName = result.fileName
                        )
                        // Intentionally reuse the existing targeted index path. It
                        // never reconciles/deletes unrelated library rows.
                        indexNewFile(result.docUri, relPath)
                        _offlineHtmlSaveState.value = OfflineHtmlSaveState(
                            operationId = operationId,
                            phase = OfflineHtmlSavePhase.SUCCESS,
                            sourceUrl = safeUrl,
                            title = safeTitle,
                            message = "Saved to your library: ${result.fileName}",
                            fileName = result.fileName
                        )
                        clearOfflineHtmlSaveStateLater(operationId)
                    }
                    is SaveResult.Error -> finishOfflineHtmlSaveError(operationId, result.message)
                }
            } catch (timeout: kotlinx.coroutines.TimeoutCancellationException) {
                finishOfflineHtmlSaveError(
                    operationId,
                    "WebView timed out while capturing the page. Please try again after it finishes loading."
                )
            } catch (cancelled: kotlinx.coroutines.CancellationException) {
                throw cancelled
            } catch (t: Throwable) {
                finishOfflineHtmlSaveError(
                    operationId,
                    t.message?.takeIf { it.isNotBlank() }
                        ?: "Save failed: ${t.javaClass.simpleName}"
                )
            } finally {
                // Drop the JS snapshot even after a timeout/error/cancellation so
                // a multi-MB DOM string cannot stay pinned in the page's JS heap.
                withContext(kotlinx.coroutines.NonCancellable + Dispatchers.Main.immediate) {
                    runCatching {
                        webView.evaluateJavascript(
                            "try{delete window.__markVaultOfflineHtml;}catch(e){};null;",
                            null
                        )
                    }
                }
            }
        }
        return true
    }

    private fun updateOfflineHtmlSaveState(
        operationId: Long,
        phase: OfflineHtmlSavePhase,
        message: String,
        done: Int = _offlineHtmlSaveState.value.done,
        total: Int = _offlineHtmlSaveState.value.total,
        fileName: String = _offlineHtmlSaveState.value.fileName
    ) {
        val cur = _offlineHtmlSaveState.value
        if (cur.operationId != operationId) return
        _offlineHtmlSaveState.value = cur.copy(
            phase = phase,
            message = message,
            done = done,
            total = total,
            fileName = fileName
        )
    }

    private fun finishOfflineHtmlSaveError(operationId: Long, message: String) {
        val cur = _offlineHtmlSaveState.value
        if (cur.operationId != operationId) return
        _offlineHtmlSaveState.value = cur.copy(
            phase = OfflineHtmlSavePhase.ERROR,
            message = message,
            done = 0,
            total = 0
        )
        clearOfflineHtmlSaveStateLater(operationId)
    }

    private fun clearOfflineHtmlSaveStateLater(operationId: Long) {
        viewModelScope.launch {
            delay(5_000L)
            if (_offlineHtmlSaveState.value.operationId == operationId &&
                !_offlineHtmlSaveState.value.running
            ) {
                _offlineHtmlSaveState.value = OfflineHtmlSaveState()
            }
        }
    }

    /**
     * Capture the DOM without asking Chromium/Android to marshal one giant
     * JavaScript callback. We snapshot once in-page, learn its length, then
     * request fixed-size substrings. This avoids the silent/fragile large-result
     * path that caused Save as Offline HTML to appear dead on heavier pages.
     */
    private suspend fun captureRenderedHtmlInChunks(
        webView: android.webkit.WebView,
        operationId: Long
    ): String = withContext(Dispatchers.Main.immediate) {
        // If Save is tapped while navigation is still completing, wait briefly
        // instead of snapshotting a half-built page. Progress remains visible.
        var readyChecks = 0
        while (webView.progress < 90 && readyChecks < 20) {
            currentCoroutineContext().ensureActive()
            updateOfflineHtmlSaveState(
                operationId,
                OfflineHtmlSavePhase.CAPTURING,
                "Waiting for the page to finish loading…"
            )
            delay(250L)
            readyChecks++
        }

        val lengthRaw = evaluateJavascriptAwait(
            webView,
            "(function(){try{" +
                "var r=document.documentElement;if(!r)return -1;" +
                "window.__markVaultOfflineHtml=r.outerHTML||'';" +
                "return window.__markVaultOfflineHtml.length;" +
                "}catch(e){return -2;}})();",
            JS_CAPTURE_TIMEOUT_MS
        )
        val length = lengthRaw?.trim()?.trim('\"')?.toIntOrNull() ?: -1
        if (length <= 0) {
            throw IllegalStateException("Couldn't capture the rendered page HTML.")
        }
        if (length > MAX_CAPTURE_CHARS) {
            throw IllegalStateException(
                "This page is too large to save safely (${formatByteCount(length.toLong() * 2L)} rendered)."
            )
        }

        val totalChunks = (length + HTML_CAPTURE_CHUNK_CHARS - 1) / HTML_CAPTURE_CHUNK_CHARS
        updateOfflineHtmlSaveState(
            operationId,
            OfflineHtmlSavePhase.CAPTURING,
            "Capturing page… 0 / $totalChunks",
            done = 0,
            total = totalChunks
        )

        val out = StringBuilder(length)
        var start = 0
        var chunkNo = 0
        while (start < length) {
            currentCoroutineContext().ensureActive()
            val end = minOf(start + HTML_CAPTURE_CHUNK_CHARS, length)
            val raw = evaluateJavascriptAwait(
                webView,
                "(function(){try{var s=window.__markVaultOfflineHtml||'';" +
                    "return s.substring($start,$end);" +
                    "}catch(e){return '';}})();",
                JS_CHUNK_TIMEOUT_MS
            )
            val chunk = decodeWebViewJavascriptString(raw)
            if (chunk.isEmpty() && end > start) {
                throw IllegalStateException("WebView stopped returning page data during capture.")
            }
            out.append(chunk)
            start = end
            chunkNo++
            updateOfflineHtmlSaveState(
                operationId,
                OfflineHtmlSavePhase.CAPTURING,
                "Capturing page… $chunkNo / $totalChunks",
                done = chunkNo,
                total = totalChunks
            )
        }
        out.toString()
    }

    private suspend fun evaluateJavascriptAwait(
        webView: android.webkit.WebView,
        script: String,
        timeoutMs: Long
    ): String? = withTimeout(timeoutMs) {
        suspendCancellableCoroutine { continuation ->
            try {
                webView.evaluateJavascript(script) { value ->
                    if (continuation.isActive) continuation.resume(value)
                }
            } catch (t: Throwable) {
                if (continuation.isActive) continuation.cancel(t)
            }
        }
    }

    private fun decodeWebViewJavascriptString(value: String?): String {
        if (value.isNullOrBlank() || value == "null") return ""
        return runCatching {
            (org.json.JSONTokener(value).nextValue() as? String).orEmpty()
        }.getOrElse { "" }
    }

    private fun formatByteCount(bytes: Long): String {
        if (bytes < 1024L) return "$bytes B"
        val kb = bytes / 1024.0
        if (kb < 1024.0) return String.format(java.util.Locale.US, "%.1f KB", kb)
        return String.format(java.util.Locale.US, "%.1f MB", kb / 1024.0)
    }


    /**
     * Wrap a page's outerHTML with a minimal envelope: DOCTYPE, UTF-8 meta,
     * title, `<base href>` so the page's relative links still resolve to the
     * original site, plus a comment header marking it as MarkVault-saved.
     *
     * If the input already looks like a full document we keep it intact but
     * inject the base href and meta charset if missing.
     */
    private fun buildHtmlEnvelope(sourceUrl: String, title: String, raw: String): String {
        val savedAt = java.text.SimpleDateFormat(
            "yyyy-MM-dd HH:mm", java.util.Locale.US
        ).format(java.util.Date())
        val escapedTitle = title.replace("&", "&amp;")
            .replace("<", "&lt;").replace(">", "&gt;").replace("\"", "&quot;")
        val escapedUrl = sourceUrl.replace("&", "&amp;").replace("\"", "&quot;")
        val preamble = """
            |<!DOCTYPE html>
            |<!-- Saved by MarkVault on $savedAt from $sourceUrl -->
            |<meta charset="utf-8">
            |<base href="$escapedUrl">
            |<title>$escapedTitle</title>
            |
            """.trimMargin()
        return preamble + raw
    }

    /**
     * Legacy MHTML archive save (kept for any future menu item that wants the
     * true offline-binary format). Not currently wired to a UI button — the
     * Save as Offline HTML button uses saveOfflineHtmlPage above.
     */
    suspend fun saveOfflineHtmlArchive(
        cacheFile: java.io.File, title: String
    ): SaveResult = withContext(Dispatchers.IO) {
        val libUri = libraryUri.value
            ?: return@withContext SaveResult.Error("No library is set. Pick one in Settings first.")
        val treeUri = runCatching { Uri.parse(libUri) }.getOrNull()
            ?: return@withContext SaveResult.Error("Library URI is invalid.")
        val cr = getApplication<Application>().contentResolver
        val hasWrite = cr.persistedUriPermissions.any {
            it.uri == treeUri && it.isWritePermission
        }
        if (!hasWrite) {
            return@withContext SaveResult.Error("Library is read-only. Re-grant access in Settings.")
        }
        try {
            val subfolder = importsSubfolder.value
            val rootId = android.provider.DocumentsContract.getTreeDocumentId(treeUri)
            val rootDocUri = android.provider.DocumentsContract.buildDocumentUriUsingTree(treeUri, rootId)
            val parentUri = if (subfolder.isBlank()) rootDocUri else
                findOrCreateFolder(cr, treeUri, rootId, subfolder)
                    ?: return@withContext SaveResult.Error("Could not create subfolder.")

            val safeBase = sanitizeFilename(title).removeSuffix(".md")
            val fileName = ensureUniqueAnyExt(cr, treeUri, parentUri, safeBase, ".mhtml")
            val newDoc = android.provider.DocumentsContract.createDocument(
                cr, parentUri, "application/x-mimearchive", fileName
            ) ?: return@withContext SaveResult.Error("Failed to create archive file.")
            cr.openOutputStream(newDoc, "w")?.use { out ->
                cacheFile.inputStream().use { it.copyTo(out) }
            } ?: return@withContext SaveResult.Error("Could not write archive.")
            runCatching { cacheFile.delete() }
            SaveResult.Ok(newDoc.toString(), fileName, subfolder)
        } catch (e: Exception) {
            SaveResult.Error("Archive save failed: ${e.message ?: e.javaClass.simpleName}")
        }
    }

    /**
     * TASK 3: Convert an HTML string into a lightweight Markdown body and save
     * it as a `.md` file in the library's imports subfolder. The converter is
     * deliberately minimal — it strips scripts/styles, converts headings,
     * paragraphs, lists, links, images, and inline formatting. Power users
     * who need a perfect conversion can still use the URL Import flow.
     */
    suspend fun saveConvertedMarkdown(
        sourceUrl: String, pageTitle: String, html: String
    ): SaveResult {
        val markdown = buildString {
            append("---\n")
            append("source: ").append(sourceUrl).append('\n')
            append("title: ").append(pageTitle.ifBlank { "Web page" }).append('\n')
            append("imported: ").append(java.text.SimpleDateFormat(
                "yyyy-MM-dd HH:mm", java.util.Locale.US
            ).format(java.util.Date())).append('\n')
            append("---\n\n")
            append("# ").append(pageTitle.ifBlank { "Web page" }).append("\n\n")
            append("> Source: <").append(sourceUrl).append(">\n\n")
            append(simpleHtmlToMarkdown(html))
        }
        val res = saveImportedMarkdown(
            title = pageTitle.ifBlank { "Web page" },
            markdown = markdown,
            subfolder = importsSubfolder.value
        )
        // v5.4.93cc — Register the URL against the saved-URL set for the
        // WebViewer's dedup + prompt flow. A page that's been converted to
        // Markdown is, from the user's POV, "already saved" — no point
        // asking again.
        if (res is SaveResult.Ok) {
            if (sourceUrl.isNotBlank()) markUrlAsSaved(sourceUrl)
            // v5.4.102cc — Even without a source URL (share-sheet
            // import etc.), mark the title + filename so the next
            // batch save can detect the dupe.
            markTitleAsSaved(pageTitle)
            logActivity(
                com.tebogo.markvault.data.ActivityLog.Category.SAVED_ARTICLE,
                "Saved as Markdown: $pageTitle",
                mapOf(
                    "url" to sourceUrl,
                    "site" to (runCatching { java.net.URI(sourceUrl).host.orEmpty() }
                        .getOrElse { "" }),
                    "format" to "Markdown",
                    "file" to res.fileName
                )
            )
        }
        return res
    }

    /**
     * Quick-and-dirty HTML → Markdown converter. Handles the structural elements
     * (headings, paragraphs, lists, links, images, code, blockquotes, line
     * breaks) and discards scripts, styles, and ARIA noise. Good enough for
     * a "save this web page to my vault" feature; not a replacement for the
     * full URL-import pipeline which does real DOM parsing on the server side.
     */
    private fun simpleHtmlToMarkdown(html: String): String {
        if (html.isBlank()) return ""
        var s = html
        // Remove scripts/styles/noscript blocks
        s = s.replace(Regex("(?is)<script[^>]*>.*?</script>"), "")
        s = s.replace(Regex("(?is)<style[^>]*>.*?</style>"), "")
        s = s.replace(Regex("(?is)<noscript[^>]*>.*?</noscript>"), "")
        // Comments
        s = s.replace(Regex("(?s)<!--.*?-->"), "")
        // Images → ![alt](src)
        s = s.replace(Regex("(?is)<img[^>]*?alt=\"([^\"]*)\"[^>]*?src=\"([^\"]+)\"[^>]*>")) {
            "![${it.groupValues[1]}](${it.groupValues[2]})"
        }
        s = s.replace(Regex("(?is)<img[^>]*?src=\"([^\"]+)\"[^>]*>")) {
            "![](${it.groupValues[1]})"
        }
        // Links → [text](href)
        s = s.replace(Regex("(?is)<a[^>]*?href=\"([^\"]+)\"[^>]*>(.*?)</a>")) {
            val href = it.groupValues[1]
            val text = stripInline(it.groupValues[2]).trim()
            if (text.isBlank()) "<$href>" else "[$text]($href)"
        }
        // Headings
        for (n in 1..6) {
            val hashes = "#".repeat(n)
            s = s.replace(Regex("(?is)<h$n[^>]*>(.*?)</h$n>")) {
                "\n\n$hashes ${stripInline(it.groupValues[1]).trim()}\n\n"
            }
        }
        // Blockquote
        s = s.replace(Regex("(?is)<blockquote[^>]*>(.*?)</blockquote>")) {
            it.groupValues[1].lines().joinToString("\n") { line -> "> ${line.trim()}" }
        }
        // Lists
        s = s.replace(Regex("(?is)<li[^>]*>(.*?)</li>")) {
            "- ${stripInline(it.groupValues[1]).trim()}\n"
        }
        s = s.replace(Regex("(?is)</?ul[^>]*>|</?ol[^>]*>"), "\n")
        // Code blocks
        s = s.replace(Regex("(?is)<pre[^>]*><code[^>]*>(.*?)</code></pre>")) {
            "\n```\n${it.groupValues[1]}\n```\n"
        }
        s = s.replace(Regex("(?is)<code[^>]*>(.*?)</code>")) {
            "`${stripInline(it.groupValues[1])}`"
        }
        // Inline emphasis
        s = s.replace(Regex("(?is)<(?:b|strong)[^>]*>(.*?)</(?:b|strong)>")) { "**${it.groupValues[1]}**" }
        s = s.replace(Regex("(?is)<(?:i|em)[^>]*>(.*?)</(?:i|em)>")) { "*${it.groupValues[1]}*" }
        // Paragraphs + breaks
        s = s.replace(Regex("(?is)<p[^>]*>(.*?)</p>")) {
            "\n\n${stripInline(it.groupValues[1]).trim()}\n\n"
        }
        s = s.replace(Regex("(?is)<br[^>]*/?>"), "  \n")
        s = s.replace(Regex("(?is)<hr[^>]*/?>"), "\n\n---\n\n")
        // Strip any remaining tags
        s = s.replace(Regex("(?is)<[^>]+>"), "")
        // Decode common HTML entities
        s = s.replace("&nbsp;", " ")
            .replace("&amp;", "&")
            .replace("&lt;", "<")
            .replace("&gt;", ">")
            .replace("&quot;", "\"")
            .replace("&#39;", "'")
            .replace("&apos;", "'")
        // Collapse 3+ blank lines into 2
        s = s.replace(Regex("\n{3,}"), "\n\n")
        return s.trim()
    }

    private fun stripInline(html: String): String {
        return html.replace(Regex("(?is)<[^>]+>"), "")
            .replace("&nbsp;", " ")
            .replace(Regex("\\s+"), " ")
    }

    /** Like ensureUnique but for arbitrary file extension. */
    private fun ensureUniqueAnyExt(
        cr: android.content.ContentResolver,
        treeUri: Uri,
        parentUri: Uri,
        baseName: String,
        extWithDot: String
    ): String {
        var candidate = "$baseName$extWithDot"
        val parentId = android.provider.DocumentsContract.getDocumentId(parentUri)
        val children = android.provider.DocumentsContract.buildChildDocumentsUriUsingTree(treeUri, parentId)
        val existing = HashSet<String>()
        cr.query(
            children,
            arrayOf(android.provider.DocumentsContract.Document.COLUMN_DISPLAY_NAME),
            null, null, null
        )?.use { cur ->
            while (cur.moveToNext()) cur.getString(0)?.let { existing.add(it.lowercase()) }
        }
        var n = 2
        while (existing.contains(candidate.lowercase())) {
            candidate = "$baseName-$n$extWithDot"
            n++
        }
        return candidate
    }

    /** Avoid overwriting an existing file by adding a numeric suffix. */
    private fun ensureUnique(
        cr: android.content.ContentResolver, treeUri: Uri, parentUri: Uri, baseName: String
    ): String {
        val base = baseName.removeSuffix(".md")
        var candidate = "$base.md"
        val parentId = android.provider.DocumentsContract.getDocumentId(parentUri)
        val children = android.provider.DocumentsContract.buildChildDocumentsUriUsingTree(treeUri, parentId)
        val existing = HashSet<String>()
        cr.query(
            children,
            arrayOf(android.provider.DocumentsContract.Document.COLUMN_DISPLAY_NAME),
            null, null, null
        )?.use { cur ->
            while (cur.moveToNext()) cur.getString(0)?.let { existing.add(it.lowercase()) }
        }
        var n = 2
        while (existing.contains(candidate.lowercase())) {
            candidate = "$base ($n).md"
            n++
        }
        return candidate
    }

    private fun sanitizeFilename(title: String): String {
        val cleaned = title
            .replace(Regex("[\\\\/:*?\"<>|\\r\\n]+"), " ")
            .replace(Regex("\\s+"), " ")
            .trim()
        val capped = if (cleaned.length > 80) cleaned.take(80).trim() else cleaned
        return capped.ifBlank { "Web import" }
    }

    fun libraryName(): String {
        val uri = libraryUri.value ?: return "Library"
        val seg = Uri.decode(uri).substringAfterLast(':', "").substringAfterLast('/')
        return if (seg.isBlank()) "Library" else seg
    }

    companion object {
        /** Focus-graph rendering caps to keep the view readable on a phone. */
        const val MAX_FIRST_RING = 16
        const val MAX_SECOND_RING = 30

        /**
         * v5.4.81cc — RRF's `k` parameter. 60 is the value from the
         * original Cormack/Clarke/Buettcher RRF paper and what every
         * modern hybrid-search implementation defaults to.
         */
        const val RRF_K = 60

        /**
         * v5.4.115cc — Trust weight applied to an LLM-generated
         * paraphrase in the fusion, relative to the user's own query
         * at 1.0.
         *
         * Set at 0.6 deliberately: high enough that a good paraphrase
         * can still surface a document the literal query missed (the
         * entire point of multi-query retrieval), low enough that a
         * paraphrase from a 135M model cannot outvote the user's real
         * words. Synonym variants carry their own graded weights from
         * [com.tebogo.markvault.search.QueryExpander.expandWeighted].
         */
        const val LLM_PARAPHRASE_WEIGHT = 0.6

        /**
         * v5.5.12 — Accuracy-first hybrid fusion. Semantic retrieval is the
         * primary evidence stream; literal/multi-query keyword evidence remains
         * strong enough to anchor exact wording, but no generated keyword query
         * can overwhelm a strong semantic neighbourhood merely because of an
         * uncalibrated score scale.
         */
        // v5.5.12 — Maximum independent evidence strengths used by the
        // absolute relevance display. They intentionally do not sum linearly:
        // fusion uses probabilistic-OR so two independent signals reinforce one
        // another without forcing the winner of every query to 100%.
        const val SEMANTIC_EVIDENCE_MAX = 0.82
        const val KEYWORD_EVIDENCE_MAX = 0.70
        const val FUZZY_EVIDENCE_MAX = 0.04
        const val SEMANTIC_FUSION_CANDIDATES = 200
        const val MAX_HYBRID_RESULTS = 400

        /**
         * One cross-encoder pass over the FINAL fused candidate window. 30 is a
         * deliberate accuracy/speed compromise: wider than the old 20-result
         * semantic-only window, but still bounded so submit searches do not turn
         * into full-list reranking.
         */
        const val ACCURACY_RERANK_WINDOW = 30

        /** Parse top-level markdown headings (outside fenced code) into an outline. */
        fun parseOutline(content: String): List<OutlineItem> {
            val out = ArrayList<OutlineItem>()
            var inFence = false
            var fence = ""
            var idx = 0
            for (raw in content.lineSequence()) {
                val line = raw.trimEnd()
                val t = line.trimStart()
                if (inFence) {
                    if (t.startsWith(fence)) inFence = false
                    continue
                }
                if (t.startsWith("```") || t.startsWith("~~~")) {
                    inFence = true; fence = t.take(3); continue
                }
                val m = Regex("^(#{1,6})\\s+(.*)$").find(line) ?: continue
                val level = m.groupValues[1].length
                val title = cleanHeading(m.groupValues[2])
                if (title.isNotBlank()) out.add(OutlineItem(level, title, idx))
                idx++
            }
            return out
        }

        private fun cleanHeading(s: String): String {
            var x = s
            x = Regex("\\[([^\\]]+)\\]\\([^)]*\\)").replace(x) { it.groupValues[1] } // links -> text
            x = x.replace(Regex("[*_`~]"), "")
            x = Regex("<[^>]+>").replace(x, "")
            return x.trim()
        }
    }

    // ── Semantic search orchestration (v4.8 foundation) ─────────────────────

    /**
     * Download the .tflite embedding model on user opt-in. Idempotent — calling
     * twice is safe. Updates [modelDownloadProgress] as a fraction in `[0, 1]`.
     * On success, [modelAvailable] flips to true.
     */
    fun downloadEmbeddingModel() {
        if (_modelDownloadProgress.value != null) return  // already running
        startProtectedTask("embedding_model_download", "Downloading embedding model…")
        viewModelScope.launch(Dispatchers.IO) {
            _modelDownloadProgress.value = 0f
            val result = embedder.downloadModel { p ->
                _modelDownloadProgress.value = p
            }
            _modelDownloadProgress.value = null
            _modelAvailable.value = embedder.isModelAvailable()
            if (result.isFailure) {
                // No-op for the UI — the user can retry. The Settings screen
                // can detect the still-unavailable state via modelAvailable.
            } else if (prefs.hnswAutoBuild.first()) {
                buildAllEmbeddings()
            }
            stopProtectedTask("embedding_model_download")
        }
    }

    /**
     * Downloads and installs the T5-base paraphrase model
     * ([com.tebogo.markvault.ai.T5ModelCatalog]) used by
     * [com.tebogo.markvault.ai.T5ExpansionMode.T5_BASE] query expansion.
     * Idempotent — a no-op while already downloading or once installed.
     * Updates [t5DownloadProgress] as a fraction in `[0, 1]` while running
     * and [t5Installed] / [t5Error] once it finishes.
     */
    fun downloadT5Model() {
        if (_t5DownloadProgress.value != null || _t5Installed.value) return
        startProtectedTask("t5_download", "Downloading T5 model…")
        viewModelScope.launch(Dispatchers.IO) {
            _t5Error.value = null
            _t5DownloadProgress.value = 0f
            val app = getApplication<Application>()
            val service = com.tebogo.markvault.ai.T5ModelDownloadService(app)
            val descriptor = com.tebogo.markvault.ai.T5DownloadDescriptor()
            val succeeded = try {
                service.install(descriptor) { percent ->
                    _t5DownloadProgress.value = percent / 100f
                }
            } catch (e: Exception) {
                _t5Error.value = e.message ?: "T5 model download failed."
                false
            }
            _t5DownloadProgress.value = null
            // Re-check real files on disk rather than trusting the return
            // value alone — this is what verifyInstalledFiles() is for.
            val nowInstalled = com.tebogo.markvault.ai.T5ArtifactLoader(app).verifyInstalledFiles()
            com.tebogo.markvault.ai.T5ModelManager.setInstalled(nowInstalled)
            _t5Installed.value = nowInstalled
            if (!succeeded && !nowInstalled && _t5Error.value == null) {
                _t5Error.value = "Download failed — check your connection and try again."
            }
            stopProtectedTask("t5_download")
        }
    }

    /**
     * Embed every note in the library that doesn't yet have a current embedding
     * for the active model. Reports progress via [embeddingProgress] as a
     * `(embedded, total)` pair. The pass is resumable: if interrupted, the
     * next call picks up exactly where it left off because we re-query the
     * targets at the start.
     *
     * v4.8.1 — three changes to fix the "tapped Build embeddings but nothing
     * happens" stall on large libraries:
     *
     *   1. **Immediate UI feedback.** We set [embeddingProgress] to a
     *      "preparing" sentinel (0, 0) BEFORE running any database queries, so
     *      the status line flips to "⏳ Preparing…" the moment the user taps.
     *      Previously the user saw no change for the entire duration of the
     *      first DAO query.
     *
     *   2. **Lightweight projection.** We use `targetsNeedingEmbedding` which
     *      returns only `(id, lastModified)` pairs instead of full Note rows.
     *      For a 14k-note library that's a few hundred KB instead of 100+ MB
     *      of allocations. Note content is fetched one row at a time via
     *      `dao.byId(id)` inside the embed loop.
     *
     *   3. **Frequent progress updates.** Updates every embedding instead of
     *      every 5 — the throttling was making the UI look frozen on slower
     *      phones where each embedding takes ~1-2 seconds.
     *
     * Throttled internally — no need for the caller to debounce. Since v5.5.8,
     * a request that arrives while the service is busy is coalesced into one
     * follow-up delta pass so newly-indexed articles are not skipped.
     */
    /**
     * v4.15.0 — Kick off the embedding pass via the foreground service.
     *
     * Before v4.15.0 this ran inline in `viewModelScope` and died the
     * moment the user backgrounded the app or the OS killed the
     * activity. With `bge-large-en-v1.5` taking 3–4 hours on a 14k
     * library, that wasn't workable. Embedding now lives in
     * [com.tebogo.markvault.search.EmbeddingService], which:
     *   - shows a persistent progress notification
     *   - holds a partial wake lock so CPU doesn't sleep
     *   - writes progress to [EmbeddingProgressBus] which this VM's
     *     `embeddingProgress` flow delegates to
     *
     * The service's re-entry guard still prevents concurrent passes; since
     * v5.5.8, a repeated request while one is running schedules one follow-up
     * delta pass instead of being discarded.
     */
    fun buildAllEmbeddings() {
        val app = getApplication<Application>()
        val intent = android.content.Intent(
            app, com.tebogo.markvault.search.EmbeddingService::class.java
        )
        // v5.5.8 — Always deliver the request to the service, even when it is
        // already running. A duplicate start is coalesced into one follow-up
        // delta pass, which prevents articles saved mid-pass from being lost.
        // The service itself decides which installed models need maintenance:
        // every installed embedding model, active model first.
        androidx.core.content.ContextCompat.startForegroundService(app, intent)
    }

    /**
     * v4.15.0 — Stop a running embedding pass. Used by:
     *   - explicit "Cancel" buttons in the Settings UI (future)
     *   - [clearAllEmbeddings], which needs to stop writes before truncating the table
     */
    fun stopEmbeddingService() {
        val app = getApplication<Application>()
        val intent = android.content.Intent(
            app, com.tebogo.markvault.search.EmbeddingService::class.java
        )
        runCatching { app.stopService(intent) }
    }

    /** Wipe every embedding row. Useful when switching models or freeing space. */
    fun clearAllEmbeddings() {
        // v4.15.0 — stop the foreground service first, otherwise it would
        // keep upserting into the same table we're about to truncate.
        stopEmbeddingService()
        viewModelScope.launch(Dispatchers.IO) {
            runCatching { dao.clearAllEmbeddings() }
            _embeddingCount.value = 0
            invalidateSemanticIndex()
            hnswBuildJob?.cancelAndJoin()
            hnswIndex.unload()
            getApplication<Application>().filesDir.listFiles()?.filter {
                it.isFile && it.name.startsWith("ann_hnsw_") && it.name.endsWith(".bin")
            }?.forEach { snapshot ->
                val stats = com.tebogo.markvault.search.HnswIndex.readStatsFile(snapshot)
                if (stats != null) hnswIndex.delete(stats.modelVersion) else snapshot.delete()
            }
            _hnswRevision.value += 1
        }
    }

    // ── v4.21.0 — On-device chat (RAG) actions ──────────────────────────────
    //
    // The Settings UI calls these to install / delete the chat model and
    // flip the three behaviour toggles. The download itself runs in a
    // foreground service so it survives backgrounding and screen-off; the
    // VM just dispatches the intent and observes the progress bus.

    /**
     * Start downloading the active chat model in the foreground service.
     * Mirrors [buildAllEmbeddings]. Re-entry guard: if a download is
     * already running, this is a no-op.
     */
    fun downloadChatModel() {
        if (com.tebogo.markvault.llm.ChatDownloadProgressBus.isRunning.value) return
        val app = getApplication<Application>()
        val intent = android.content.Intent(
            app, com.tebogo.markvault.llm.ChatModelDownloadService::class.java
        )
        androidx.core.content.ContextCompat.startForegroundService(app, intent)
        // Optimistically refresh the installed flag after the service
        // (eventually) completes. The bus's isRunning flow drives the
        // re-check below via the init-time observer.
    }

    /**
     * Pause the in-progress download. The .part file is kept so the
     * next [downloadChatModel] call auto-resumes via HTTP Range.
     */
    fun pauseChatModelDownload() {
        val app = getApplication<Application>()
        val intent = android.content.Intent(
            app, com.tebogo.markvault.llm.ChatModelDownloadService::class.java
        ).setAction(com.tebogo.markvault.llm.ChatModelDownloadService.ACTION_PAUSE)
        runCatching { app.startService(intent) }
    }

    /**
     * Cancel the download and discard the .part file so the next
     * "Install" starts fresh. Works whether the service is running
     * (active download) or stopped (paused state).
     */
    fun cancelChatModelDownload() {
        val app = getApplication<Application>()
        // Stop the service if it is currently running.
        runCatching {
            app.stopService(
                android.content.Intent(
                    app, com.tebogo.markvault.llm.ChatModelDownloadService::class.java
                )
            )
        }
        // Reset bus (clears paused state too).
        com.tebogo.markvault.llm.ChatDownloadProgressBus.idle()
        // Delete the .part file so next install starts from zero.
        viewModelScope.launch(kotlinx.coroutines.Dispatchers.IO) {
            val activeId = runCatching {
                com.tebogo.markvault.data.Prefs(app).chatActiveModelId.first()
            }.getOrDefault(com.tebogo.markvault.llm.ChatModelCatalog.default.id)
            val descriptor = com.tebogo.markvault.llm.ChatModelCatalog.byId(activeId)
                ?: com.tebogo.markvault.llm.ChatModelCatalog.default
            com.tebogo.markvault.llm.ChatModelDownloader.deletePart(app, descriptor)
        }
    }

    /** Kept for internal callers (deleteChatModel). */
    private fun stopChatModelDownload() = cancelChatModelDownload()

    /**
     * Delete the installed chat model file. Frees ~530 MB of storage.
     * Stops any in-flight download first (we don't want to delete a
     * partially-written file out from under the writer).
     */
    fun deleteChatModel() {
        stopChatModelDownload()
        viewModelScope.launch(Dispatchers.IO) {
            val app = getApplication<Application>()
            // v5.4.73: delete whichever model is currently selected, not
            // always the default. Same runCatching guard as above.
            val activeId = runCatching { chatActiveModelId.value }.getOrNull()
            val descriptor = (if (activeId != null)
                com.tebogo.markvault.llm.ChatModelCatalog.byId(activeId)
            else null) ?: com.tebogo.markvault.llm.ChatModelCatalog.default
            com.tebogo.markvault.llm.ChatModelDownloader.delete(app, descriptor)
            _chatModelInstalled.value = false
        }
    }

    /** Dismiss the last download-error message from the bus. */
    fun clearChatDownloadError() {
        com.tebogo.markvault.llm.ChatDownloadProgressBus.clearError()
    }

    /** Toggle: "opt_in" or "auto_prompt". v4.21.0 stores only — no behaviour change yet. */
    fun setChatInstallFlowPref(v: String) {
        viewModelScope.launch { prefs.setChatInstallFlow(v) }
    }

    /** Toggle: "own_screen" or "in_search". v4.21.0 stores only — no behaviour change yet. */
    fun setChatLocationPref(v: String) {
        viewModelScope.launch { prefs.setChatLocation(v) }
    }

    /** Toggle: "fresh_per_q" or "multi_turn". v4.21.0 stores only — no behaviour change yet. */
    fun setChatHistoryModePref(v: String) {
        viewModelScope.launch { prefs.setChatHistoryMode(v) }
    }

    /** Toggle: "on_open", "preload", or "on_first_q". v4.21.2 stores only — Stage 5b consumes it. */
    fun setChatModelLoadModePref(v: String) {
        viewModelScope.launch { prefs.setChatModelLoadMode(v) }
    }

    /**
     * Internal: observe the chat download bus and re-check installed
     * status whenever a download finishes. Called from the init block.
     */
    private fun observeChatDownloadCompletion() {
        viewModelScope.launch {
            com.tebogo.markvault.llm.ChatDownloadProgressBus.isRunning.collect { running ->
                if (!running) {
                    // Re-check the file. If a download just completed
                    // successfully, this flips installed → true.
                    _chatModelInstalled.value = currentChatModelInstalled()
                }
            }
        }
    }

    /**
     * v5.4.257cc — THE REAL FIX for "model shows Not Installed after a
     * completed download, every time the app restarts."
     *
     * v5.4.256cc fixed a real bug — chatActiveModelId used to be declared
     * AFTER _chatModelInstalled, so reading chatActiveModelId.value from
     * _chatModelInstalled's field initializer threw and silently fell
     * back to the default model (SmolLM2), not whichever model the user
     * actually had active. Reordering the declarations fixed that crash
     * path — but it did NOT fix the actual reported symptom, because the
     * real problem is a race, not just an ordering mistake:
     *
     * chatActiveModelId is `prefs.chatActiveModelId.stateIn(viewModelScope,
     * SharingStarted.Eagerly, ChatModelCatalog.default.id)`. DataStore
     * reads are inherently ASYNCHRONOUS — even with Eagerly sharing, the
     * StateFlow's value is the DEFAULT id until the underlying DataStore
     * file read actually completes on a coroutine dispatch, which cannot
     * happen before the NEXT line of a class's property initializers
     * runs (property initializers execute synchronously, back to back,
     * with no yield point). So _chatModelInstalled's field initializer —
     * regardless of which property is declared first — was ALWAYS
     * reading chatActiveModelId.value while it still held the default
     * ("smollm2-135m-instruct-q8"), never the real persisted value
     * ("gemma-4-e2b-it") — every single cold start, no matter which
     * model the user actually has downloaded and selected. That's an
     * async-timing race, which reordering two property declarations
     * cannot fix — only actually waiting for the real value can.
     *
     * The fix: collect chatActiveModelId itself (not just isRunning) and
     * re-check installed status on every emission. The FIRST emission is
     * still the default (same race as before, harmless — the collector
     * runs it again a moment later) but the SECOND emission, once
     * DataStore's real read completes, carries the actual persisted
     * model id — Gemma, in this app's case — and this collector then
     * correctly finds its file and flips chatModelInstalled to true.
     * Also correctly re-checks whenever the user switches models via the
     * Settings radio picker, which the old code never did either.
     */
    private fun observeActiveChatModelChanges() {
        viewModelScope.launch {
            chatActiveModelId.collect {
                _chatModelInstalled.value = currentChatModelInstalled()
            }
        }
    }

    /**
     * v5.4.257cc — One-time-per-launch cleanup of orphaned chat-model
     * files: .litertlm files left over from models that used to be in
     * ChatModelCatalog but were later removed (Phi-4-mini ~3.9 GB,
     * Qwen 3 0.6B — see ChatModelCatalog.kt's history doc comments for
     * why they were dropped). Removing a catalog ENTRY never deleted an
     * already-downloaded FILE, so anyone who tried either of those
     * earlier models during development still has them silently taking
     * up multiple GB of storage. Only ever deletes .litertlm files whose
     * name doesn't match one of the CURRENT catalog's two localFilename
     * values (or their .part in-progress variant) — every other model
     * type in this app (T5 .tflite, reranker/embedder .onnx) uses a
     * different extension entirely, confirmed by reading their own
     * catalogs, so this cannot collide with an unrelated file. Cheap
     * enough (one directory listing + string comparisons) to just run
     * unconditionally on every launch rather than track "already done"
     * in a preference — idempotent, near-instant no-op once clean.
     */
    private fun cleanupOrphanedChatModelFiles() {
        viewModelScope.launch(Dispatchers.IO) {
            runCatching {
                val app = getApplication<Application>()
                val knownNames = com.tebogo.markvault.llm.ChatModelCatalog.all
                    .map { it.localFilename }
                    .toSet()
                app.filesDir.listFiles()?.forEach { f ->
                    val name = f.name
                    if (name.endsWith(".litertlm") || name.endsWith(".litertlm.part")) {
                        val baseName = name.removeSuffix(".part")
                        if (baseName !in knownNames) {
                            runCatching { f.delete() }
                        }
                    }
                }
            }
        }
    }

    // ── v4.22.0 — On-device chat (RAG) runtime state ────────────────────────
    //
    // Stage 5b wires the chat UI into the engine plumbing built in 5a.
    // Three moving parts:
    //   1. messages — the conversation, with one currently-streaming
    //      assistant message during generation.
    //   2. isModelLoading / isGenerating — independent busy flags. The UI
    //      uses them to disable the input field and show a loading banner.
    //   3. modelLoadError — surfaces a friendly message when load fails
    //      (model not installed, file corrupted, OOM, etc.).

    enum class ChatRole { USER, ASSISTANT }

    /** One message in the chat conversation. */
    data class ChatMessage(
        val id: String,
        val role: ChatRole,
        val content: String,
        val citations: List<com.tebogo.markvault.llm.RagCitation> = emptyList(),
        val isStreaming: Boolean = false,
        val isError: Boolean = false
    )

    private val _chatMessages = MutableStateFlow<List<ChatMessage>>(emptyList())
    val chatMessages: StateFlow<List<ChatMessage>> = _chatMessages

    private val _chatIsModelLoading = MutableStateFlow(false)
    val chatIsModelLoading: StateFlow<Boolean> = _chatIsModelLoading

    private val _chatIsGenerating = MutableStateFlow(false)
    val chatIsGenerating: StateFlow<Boolean> = _chatIsGenerating

    private val _chatModelLoadError = MutableStateFlow<String?>(null)
    val chatModelLoadError: StateFlow<String?> = _chatModelLoadError

    private var chatGenerationJob: kotlinx.coroutines.Job? = null

    /**
     * v5.4.141cc — The descriptor the chat feature should actually use:
     * whichever model [chatActiveModelId] currently points to, falling
     * back to the catalog default only when the saved id is unknown.
     * Same resolution pattern already used by [isLlmModelInstalledFast]
     * and [currentChatModelInstalled].
     *
     * Previously [ensureChatModelLoaded] hard-coded
     * [com.tebogo.markvault.llm.ChatModelCatalog.default] (SmolLM2),
     * so picking Gemma 4 E2B in Settings — which the catalog's own doc
     * comment advertises as also backing on-device chat — never
     * actually loaded Gemma for a chat turn; chat silently kept running
     * SmolLM2's smaller context window regardless of the picker. Also
     * the direct cause of RAG prompt budgets being computed against the
     * wrong model: [sendChatMessage] and [summarizeNote] now read
     * [activeChatDescriptor] so [com.tebogo.markvault.llm.RagPromptBuilder]
     * sizes its notes budget against the model that will really run.
     */
    private fun activeChatDescriptor(): com.tebogo.markvault.llm.ChatModelDescriptor {
        val activeId = runCatching { chatActiveModelId.value }.getOrNull()
        return (if (activeId != null)
            com.tebogo.markvault.llm.ChatModelCatalog.byId(activeId)
        else null) ?: com.tebogo.markvault.llm.ChatModelCatalog.default
    }

    /**
     * Ensure the LLM is loaded into RAM, idempotent. Reads the active
     * model via [activeChatDescriptor] and the file from the app's
     * filesDir.
     *
     * Sets [chatModelLoadError] on failure; the UI shows it as a banner.
     */
    suspend fun ensureChatModelLoaded() {
        if (com.tebogo.markvault.llm.LlmManager.isLoaded) return
        if (_chatIsModelLoading.value) return
        val app = getApplication<Application>()
        val descriptor = activeChatDescriptor()
        val file = java.io.File(app.filesDir, descriptor.localFilename)
        if (!file.exists() ||
            file.length() <= com.tebogo.markvault.llm.ChatModelCatalog.MIN_PLAUSIBLE_MODEL_BYTES
        ) {
            _chatModelLoadError.value =
                "Chat model not installed. Open Settings → On-device chat to install."
            return
        }
        _chatIsModelLoading.value = true
        _chatModelLoadError.value = null
        try {
            com.tebogo.markvault.llm.LlmManager.load(file.absolutePath)
        } catch (e: Throwable) {
            _chatModelLoadError.value =
                e.message ?: "Failed to load chat model into memory."
        } finally {
            _chatIsModelLoading.value = false
        }
    }

    /**
     * Send a user message and generate a streaming assistant reply.
     *
     * Pipeline:
     *   1. Append user message + empty streaming placeholder to messages
     *   2. Ensure model loaded (handles "on_first_q" mode lazily)
     *   3. RagPromptBuilder.build → prompt + citations
     *   4. Update placeholder with citations
     *   5. LlmManager.generate → collect tokens, update content
     *   6. Mark streaming complete
     *
     * If anything throws, the placeholder becomes an error message.
     * If the user cancels via [stopChatGeneration], the partial output
     * stays in place with a "[stopped]" suffix.
     */
    fun sendChatMessage(text: String) {
        val trimmed = text.trim()
        if (trimmed.isEmpty()) return
        if (_chatIsGenerating.value) return

        val userMsg = ChatMessage(
            id = java.util.UUID.randomUUID().toString(),
            role = ChatRole.USER,
            content = trimmed
        )
        val placeholder = ChatMessage(
            id = java.util.UUID.randomUUID().toString(),
            role = ChatRole.ASSISTANT,
            content = "",
            isStreaming = true
        )
        _chatMessages.value = _chatMessages.value + userMsg + placeholder
        _chatIsGenerating.value = true

        chatGenerationJob = viewModelScope.launch(Dispatchers.IO) {
            try {
                // Handle "on_first_q" load mode: model not yet loaded.
                if (!com.tebogo.markvault.llm.LlmManager.isLoaded) {
                    ensureChatModelLoaded()
                    if (!com.tebogo.markvault.llm.LlmManager.isLoaded) {
                        // ensureChatModelLoaded set the error; surface it.
                        setChatAssistantError(
                            placeholder.id,
                            _chatModelLoadError.value ?: "Model not loaded"
                        )
                        return@launch
                    }
                }

                // Build the RAG prompt. maxContextTokens comes from the
                // model that's actually loaded above — see
                // [activeChatDescriptor]'s doc for why this must match
                // reality rather than assuming a fixed model.
                val rag = com.tebogo.markvault.llm.RagPromptBuilder.build(
                    userQuery = trimmed,
                    topK = 6,
                    maxContextTokens = activeChatDescriptor().contextTokens,
                    semanticSearch = { q, k -> semanticSearch(q, k) },
                    dao = dao,
                    embedder = embedder
                )

                // Update the placeholder with citations so the chips
                // appear immediately, before any tokens stream in.
                _chatMessages.value = _chatMessages.value.map { msg ->
                    if (msg.id == placeholder.id) {
                        msg.copy(citations = rag.citations)
                    } else msg
                }

                // Stream tokens into the placeholder's content.
                val sb = StringBuilder()
                com.tebogo.markvault.llm.LlmManager.generate(rag.prompt).collect { chunk ->
                    sb.append(chunk)
                    val text = sb.toString()
                    _chatMessages.value = _chatMessages.value.map { msg ->
                        if (msg.id == placeholder.id) msg.copy(content = text)
                        else msg
                    }
                }

                // Mark streaming complete.
                _chatMessages.value = _chatMessages.value.map { msg ->
                    if (msg.id == placeholder.id) msg.copy(isStreaming = false)
                    else msg
                }
            } catch (ce: kotlinx.coroutines.CancellationException) {
                // User-initiated stop — keep partial output.
                _chatMessages.value = _chatMessages.value.map { msg ->
                    if (msg.id == placeholder.id)
                        msg.copy(isStreaming = false,
                            content = msg.content + "  [stopped]")
                    else msg
                }
                throw ce  // re-throw so coroutine cancellation propagates
            } catch (e: Throwable) {
                setChatAssistantError(placeholder.id,
                    e.message ?: "Generation failed unexpectedly")
            } finally {
                _chatIsGenerating.value = false
            }
        }
    }

    /** Mark a particular assistant message as an error. */
    private fun setChatAssistantError(messageId: String, errorMsg: String) {
        _chatMessages.value = _chatMessages.value.map { msg ->
            if (msg.id == messageId) {
                msg.copy(
                    content = "⚠️  $errorMsg",
                    isStreaming = false,
                    isError = true
                )
            } else msg
        }
    }

    /** Cancel the in-flight chat generation, if any. */
    fun stopChatGeneration() {
        chatGenerationJob?.cancel()
        chatGenerationJob = null
    }

    /** Clear all chat messages. Cancels any in-flight generation first. */
    fun clearChatMessages() {
        stopChatGeneration()
        _chatMessages.value = emptyList()
    }

    /** Dismiss a stale load-error banner. */
    fun clearChatModelLoadError() {
        _chatModelLoadError.value = null
    }

    /** Release the LLM from memory. Called on chat-screen dispose. */
    fun unloadChatModel() {
        viewModelScope.launch(Dispatchers.IO) {
            com.tebogo.markvault.llm.LlmManager.unload()
        }
    }

    /**
     * v4.22.1 — Trigger a "Summarise this article" generation for the
     * note with [noteId]. Called from the reader screens (MD / HTML /
     * PDF) when the user taps the ✨ Summarise button.
     *
     * Adds a user message ("Summarise: <title>") and a streaming
     * assistant message to the chat conversation, then starts
     * generating. The caller (the reader screen) is responsible for
     * navigating to the chat screen so the user can watch it stream.
     *
     * For PDF notes, aggregates extracted page text via
     * [dao.loadPdfPageText]. For MD / HTML, uses the note's raw
     * [Note.content] field directly.
     */
    fun summarizeNote(noteId: Long, fileType: String = "md") {
        if (_chatIsGenerating.value) return
        chatGenerationJob = viewModelScope.launch(Dispatchers.IO) {
            val note = runCatching { dao.byId(noteId) }.getOrNull() ?: return@launch

            val content = when (fileType.lowercase()) {
                "pdf" -> {
                    val pages = runCatching { dao.loadPdfPageText(noteId) }.getOrNull()
                    if (pages.isNullOrEmpty()) {
                        // The PDF text-extraction pass hasn't run yet for this
                        // file. We still produce a (very short) summary based
                        // on title + any note metadata content.
                        note.content + "\n\n[Note: this PDF has no extracted " +
                            "text yet. Open it in the PDF reader once to " +
                            "trigger extraction, then summarise again.]"
                    } else {
                        pages.joinToString("\n\n") { p ->
                            "[Page ${p.pageIndex + 1}]\n${p.text}"
                        }
                    }
                }
                else -> note.content
            }

            val rag = com.tebogo.markvault.llm.RagPromptBuilder.buildSummarize(
                noteId = noteId,
                title = note.title,
                content = content,
                maxContextTokens = activeChatDescriptor().contextTokens
            )
            streamChatGeneration(
                displayText = "Summarise: ${note.title}",
                prompt = rag.prompt,
                citations = rag.citations
            )
        }
    }

    /**
     * Shared helper: appends a user message + streaming assistant
     * placeholder to [_chatMessages], ensures the LLM is loaded, then
     * collects tokens from [LlmManager.generate] into the placeholder.
     *
     * Used by [summarizeNote]. [sendChatMessage] also follows this same
     * shape inline (not yet refactored to call this — keeping that path
     * unchanged to minimise risk of regressing already-working chat).
     */
    private suspend fun streamChatGeneration(
        displayText: String,
        prompt: String,
        citations: List<com.tebogo.markvault.llm.RagCitation>
    ) {
        val userMsg = ChatMessage(
            id = java.util.UUID.randomUUID().toString(),
            role = ChatRole.USER,
            content = displayText
        )
        val placeholder = ChatMessage(
            id = java.util.UUID.randomUUID().toString(),
            role = ChatRole.ASSISTANT,
            content = "",
            isStreaming = true,
            citations = citations
        )
        _chatMessages.value = _chatMessages.value + userMsg + placeholder
        _chatIsGenerating.value = true

        try {
            if (!com.tebogo.markvault.llm.LlmManager.isLoaded) {
                ensureChatModelLoaded()
                if (!com.tebogo.markvault.llm.LlmManager.isLoaded) {
                    setChatAssistantError(
                        placeholder.id,
                        _chatModelLoadError.value ?: "Model not loaded"
                    )
                    return
                }
            }
            val sb = StringBuilder()
            com.tebogo.markvault.llm.LlmManager.generate(prompt).collect { chunk ->
                sb.append(chunk)
                val text = sb.toString()
                _chatMessages.value = _chatMessages.value.map { msg ->
                    if (msg.id == placeholder.id) msg.copy(content = text) else msg
                }
            }
            _chatMessages.value = _chatMessages.value.map { msg ->
                if (msg.id == placeholder.id) msg.copy(isStreaming = false) else msg
            }
        } catch (ce: kotlinx.coroutines.CancellationException) {
            _chatMessages.value = _chatMessages.value.map { msg ->
                if (msg.id == placeholder.id)
                    msg.copy(isStreaming = false,
                        content = msg.content + "  [stopped]")
                else msg
            }
            throw ce
        } catch (e: Throwable) {
            setChatAssistantError(placeholder.id,
                e.message ?: "Generation failed unexpectedly")
        } finally {
            _chatIsGenerating.value = false
        }
    }

    /**
     * Preload the LLM at app start when the user has selected
     * "preload" mode. Called from init after a short delay so the
     * app-launch path isn't slowed by a ~5–10s model init.
     */
    private fun maybePreloadChatModel() {
        viewModelScope.launch(Dispatchers.IO) {
            val mode = runCatching { prefs.chatModelLoadMode.first() }
                .getOrDefault("on_open")
            if (mode != "preload") return@launch
            if (!currentChatModelInstalled()) return@launch
            kotlinx.coroutines.delay(2000)   // let UI finish settling
            ensureChatModelLoaded()
        }
    }

    // ── v4.9.0 — Semantic search toggles & model management ─────────────────

    /** Flip the master semantic-search switch. Effect is immediate on next query. */
    fun setSemanticEnabled(enabled: Boolean) {
        viewModelScope.launch { prefs.setSemanticEnabled(enabled) }
    }

    /** v5.5.14 — Persist the Question Awareness toggle shown under the search bar. */
    fun setQuestionAwarenessEnabled(enabled: Boolean) {
        viewModelScope.launch { prefs.setQuestionAwarenessEnabled(enabled) }
    }

    /**
     * v5.4.76cc/v5.5.24 — Flip the master model-expansion switch. The
     * in-memory request value changes synchronously so a submit immediately
     * after switching OFF cannot race the asynchronous DataStore write.
     */
    fun setAiLlmSearchEnabled(enabled: Boolean) {
        requestedAiLlmSearchEnabled = enabled
        viewModelScope.launch { prefs.setAiLlmSearchEnabled(enabled) }
    }

    /**
     * v5.4.79cc — Flip the LLM memory-safety belt. When on, the
     * expander refuses to load a model that wouldn't fit in the
     * current free-RAM headroom and uses a tighter 5-second generate
     * timeout. Effect is immediate on the next submitted search.
     */
    fun setMemoryOptimizedLlm(enabled: Boolean) {
        viewModelScope.launch { prefs.setMemoryOptimizedLlm(enabled) }
    }

    /**
     * v5.4.80cc/v5.5.24 — Shared expansion count. Coerced 0..10 and
     * applied synchronously to the next request before it is persisted.
     */
    fun setLlmParaphraseCount(count: Int) {
        val safeCount = count.coerceIn(0, 10)
        requestedExpansionBudget = safeCount
        viewModelScope.launch { prefs.setLlmParaphraseCount(safeCount) }
    }

    /**
     * v5.4.79cc — Pick which catalog model the LLM query expander uses.
     * Writes into [Prefs.chatActiveModelId]; the expander's
     * `descriptorProvider` lambda reads this on the next submit, so the
     * change is effective immediately without restart. The Settings
     * screen and the download UI both read the same preference, so the
     * chosen model becomes the one whose install / progress / delete
     * buttons are shown.
     */
    fun setChatActiveModelId(id: String) {
        viewModelScope.launch { prefs.setChatActiveModelId(id) }
    }

    /** Whether to automatically check for newer models when the app launches. */
    fun setAutoCheckModelUpdates(enabled: Boolean) {
        viewModelScope.launch { prefs.setAutoCheckModelUpdates(enabled) }
    }

    /**
     * Switch to a different model in the catalog. The init-block listener
     * picks up the preference change, closes the current embedder, builds a
     * fresh one for the new descriptor, and refreshes the model-availability
     * + embedding-count state flows. The user will likely need to:
     *
     *   1. Download the new model (its file isn't on disk yet)
     *   2. Build embeddings (the DB rows are keyed by model id, so the new
     *      model has zero embeddings to start)
     *
     * Both are surfaced via the existing UI in Settings.
     *
     * v4.9.1 — also rejects models marked `enabled = false`, which is how the
     * catalog surfaces "coming soon" entries (e.g. MiniLM before its ONNX
     * backend lands). The UI greys those rows out, but this guard is the
     * authoritative check.
     */
    /**
     * v5.4.236cc — Explicitly unload the CURRENT embedding model before
     * switching. Previously this just wrote the new model id to prefs and
     * returned — the old embedder's ONNX session (and the semantic index
     * built from its embedding space, which is invalid for a different
     * model anyway) stayed allocated until something else happened to
     * release them. Now the switch is deterministic: close now, not
     * "eventually, maybe."
     */
    fun setActiveModelId(id: String) {
        val target = com.tebogo.markvault.search.ModelCatalog.byId(id) ?: return
        if (!target.enabled) return
        val before = usedTotalMB()
        viewModelScope.launch(Dispatchers.IO) {
            // v5.4.269cc — Serialize model switching with the background
            // media embedder. The native session is closed only after the
            // media indexing job has fully stopped.
            cancelMediaSemanticIndexing()
            runCatching { embedder.close() }
            invalidateSemanticIndex()
            prefs.setActiveModelId(id)
            runCatching { System.gc() }
            kotlinx.coroutines.delay(150L)
            val after = usedTotalMB()
            showMemoryClearedToast((before - after).coerceAtLeast(0L))
        }
    }

    /**
     * v4.9.1 — Single-step install: download the active model's file, then
     * automatically start the embedding pass once the download finishes.
     * Combines the two previously-separate buttons into one user action.
     *
     * No-op when the model is already downloaded AND embeddings exist for it
     * (i.e. nothing to install). When the model is downloaded but no
     * embeddings exist yet, this method skips the download and runs only the
     * embedding pass — the same behaviour the standalone "Build embeddings"
     * button would have provided.
     *
     * Safe to call while another install is in progress: the download path
     * is idempotent (returns immediately if the file is already valid) and
     * the embed path is safely coalesced by EmbeddingService when another
     * model/index synchronization pass is already running.
     */
    fun installModel() {
        viewModelScope.launch(Dispatchers.IO) {
            // Phase 1: download (no-op if already present).
            if (!embedder.isModelAvailable()) {
                val result = embedder.downloadModel { p ->
                    _modelDownloadProgress.value = p
                }
                _modelDownloadProgress.value = null
                _modelAvailable.value = embedder.isModelAvailable()
                if (result.isFailure || !embedder.isModelAvailable()) return@launch
            }
            // Phase 2: embed any notes that need it. buildAllEmbeddings
            // launches its own coroutine on viewModelScope; calling it here
            // is fine — it has its own re-entry guard.
            buildAllEmbeddings()
        }
    }

    /**
     * Check whether the in-app catalog lists any model the user could switch
     * to. Honest scope: this is a LOCAL check against the bundled catalog —
     * there's no remote manifest endpoint yet. Future iterations may merge in
     * results from a remote JSON manifest; for now, new models arrive via
     * app updates and this method surfaces them once installed.
     *
     * The result is written to [modelUpdateStatus] so the UI can render it
     * below the button without any string-passing coupling.
     */
    fun checkForModelUpdates() {
        viewModelScope.launch {
            _modelUpdateStatus.value = "\u23F3 Checking\u2026"
            kotlinx.coroutines.delay(400)  // tiny pause so the user sees feedback
            val activeId = embedder.descriptor.id
            val otherModels = com.tebogo.markvault.search.ModelCatalog.all
                .filter { it.id != activeId }
            _modelUpdateStatus.value = if (otherModels.isEmpty()) {
                "\u2705 Up to date. \"${embedder.descriptor.displayName}\" is the latest available model."
            } else {
                val names = otherModels.joinToString { it.displayName }
                "\uD83D\uDCE6 Other model(s) available: $names"
            }
        }
    }

    /**
     * v5.4.0 — Best-effort memory reclamation. Unconditional — releases
     * even if autoFreeMemory is OFF. Use this for the Settings "Free
     * memory now" button.
     *
     * Releases the four heaviest memory holders without losing user
     * data:
     *   • Embedder ONNX session   (~280 MB native, BGE-large)
     *   • Reranker ONNX session   (~150 MB native, MS-MARCO MiniLM-L-12)
     *   • T5-base encoder/decoder (~200+ MB native, query expansion)
     *   • In-heap semantic index  (~58 MB on a 14k-note library)
     *
     * All four are recreated lazily on next use, so the only cost of
     * calling this is a slightly slower first query/expansion after
     * the call. Total freed: ~690 MB on a fully-warm app.
     *
     * v5.4.126cc — Was leaking the T5 engine: [t5Engine] was closed
     * neither here nor in [onCleared], so once a T5-based search ran
     * once, the encoder+decoder sessions stayed resident for the rest
     * of the process's life, including through onTrimMemory/onLowMemory
     * (which route here via [freeMemoryAuto]) — defeating the whole
     * point of this reclamation path and pushing memory-constrained
     * devices closer to an OOM kill. [t5EngineLoadAttempted] is reset
     * too so the next T5 expansion attempts a fresh load instead of
     * staying permanently short-circuited by the earlier attempt.
     */
    fun freeMemory() {
        // v5.4.269cc — Run native teardown only after the media indexer has
        // actually stopped. cancel() alone can leave an in-flight MediaPipe
        // embed() executing while embedder.close() destroys its native state.
        viewModelScope.launch(Dispatchers.IO) {
            cancelMediaSemanticIndexing()
            runCatching { embedder.close() }
            runCatching { reranker.unload() }
            runCatching { t5Engine?.close() }
            t5Engine = null
            t5EngineLoadAttempted = false
            // v5.4.128cc — CRITICAL: release the LLM too. Previously this
            // method released embedder + reranker + T5 but LEFT THE LLM
            // LOADED, defeating the whole point on onTrimMemory /
            // onLowMemory signals.
            runCatching { com.tebogo.markvault.llm.LlmManager.unload() }
            invalidateSemanticIndex()
            webTabThumbnails.clear()
            clearImageCache()
            runCatching { hnswIndex.unload() }
            if (!backgroundWorkProtected()) releaseSqliteCache()
            runCatching { System.gc() }
            runCatching { System.gc() }
        }
    }

    /**
     * v5.5.0 — Auto-release entry point, called by [MarkVaultApp] when
     * the OS signals genuine memory pressure (TRIM_MEMORY_MODERATE or
     * higher). Performs LIGHTWEIGHT cleanup only: expendable image and
     * thumbnail caches, SQLite page cache, and GC. Does NOT close the
     * embedder, reranker, T5, LLM, or invalidate the semantic index —
     * those heavyweight teardowns are reserved for explicit manual
     * action via [hardResetMemory] (long-press on the dual bar).
     *
     * This prevents the library from being offloaded every time the
     * screen turns off or Android reclaims background processes.
     */
    fun freeMemoryAuto() {
        if (_searchBusy.value || _rerankActive.value) return
        if (!autoFreeMemory.value) return
        viewModelScope.launch(Dispatchers.IO) {
            webTabThumbnails.clear()
            clearImageCache()
            runCatching { hnswIndex.unload() }
            if (!backgroundWorkProtected()) releaseSqliteCache()
            runCatching { System.gc() }
        }
    }

    override fun onCleared() {
        super.onCleared()
        // v5.4.269cc — Wait for any in-flight native media embedding to finish
        // before destroying the shared embedder during VM teardown.
        runCatching { runBlocking { cancelMediaSemanticIndexing() } }
        // v5.4.233cc — Release the MediaController connection. Does NOT
        // stop playback — the ExoPlayer lives in PlaybackService, a
        // separate foreground Service, and keeps playing independent of
        // this ViewModel's lifecycle.
        runCatching { mediaController?.release() }
        mediaController = null
        runCatching { embedder.close() }
        runCatching { hnswIndex.unload() }
        // v5.4.128cc — Parity with freeMemory: also release the
        // reranker, LLM, and thumbnail cache here so the VM leaves
        // nothing dangling in native or heap memory when it dies.
        // viewModelScope is already cancelled by the time onCleared
        // runs, so LLM release uses runBlocking (LlmManager.unload
        // includes a ~50 ms delay to let the native callback_thread
        // drain — safe to block on main here since the Activity is
        // being torn down anyway).
        runCatching { reranker.unload() }
        runCatching {
            runBlocking { com.tebogo.markvault.llm.LlmManager.unload() }
        }
        // v5.4.126cc — was never released here (or anywhere else); see
        // the freeMemory() doc comment above for the full story.
        runCatching { t5Engine?.close() }
        t5Engine = null
        t5EngineLoadAttempted = false
        webTabThumbnails.clear()
        // v4.13.0 — release every persistent WebView so we don't hold native
        // resources after the VM is gone.
        destroyAllWebViewSessions()
    }
}

/** Direction of a wikilink relative to the focused note. */
enum class LinkDir { OUTGOING, INCOMING, BOTH }

/** A 1°-ring neighbour: a directly linked note + which way the link goes. */
data class GraphNeighbour(val note: com.tebogo.markvault.data.LinkedNote, val dir: LinkDir)

/** A 2°-ring node: linked via [viaNoteId] which is one of the 1°-ring nodes. */
data class GraphEdge(val note: com.tebogo.markvault.data.LinkedNote, val viaNoteId: Long)

/** Result of expanding a focus note out to two degrees of connection. */
data class GroupGraphEdge(val fromId: Long, val toId: Long)
data class GroupGraph(
    val nodes: List<com.tebogo.markvault.data.LinkedNote>,
    val edges: List<GroupGraphEdge>
)

data class FocusGraph(
    val center: com.tebogo.markvault.data.LinkedNote,
    val firstRing: List<GraphNeighbour>,
    val secondRing: List<GraphEdge>,
    /** How many 1°-ring neighbours we found in total — UI can show "+N more" if greater than [firstRing.size]. */
    val firstRingTotal: Int,
    val secondRingTotal: Int
)

/** One persisted recent-search click: the query the user typed, and the note they ended up opening. */
data class RecentSearch(
    val query: String,
    val noteId: Long,
    val title: String,
    val relPath: String,
    val ts: Long,
    /** End-to-end search time until results were ready; 0 for legacy records. */
    val durationMs: Long = 0L
)

/**
 * Tab-separated, line-per-entry, with `\u0001` as field separator (any char that's vanishingly
 * unlikely in titles). Lightweight enough that we don't need a JSON library.
 */
private const val FIELD_SEP = "\u0001"

internal fun encodeRecents(list: List<RecentSearch>): String =
    list.joinToString("\n") { r ->
        // Defensively scrub any stray separator chars from user-controlled fields
        listOf(
            r.query.replace("\n", " ").replace(FIELD_SEP, " "),
            r.noteId.toString(),
            r.title.replace("\n", " ").replace(FIELD_SEP, " "),
            r.relPath.replace("\n", " ").replace(FIELD_SEP, " "),
            r.ts.toString(),
            r.durationMs.coerceAtLeast(0L).toString()
        ).joinToString(FIELD_SEP)
    }

internal fun decodeRecents(raw: String): List<RecentSearch> {
    if (raw.isBlank()) return emptyList()
    return raw.split("\n").mapNotNull { line ->
        val parts = line.split(FIELD_SEP)
        if (parts.size < 5) return@mapNotNull null
        val id = parts[1].toLongOrNull() ?: return@mapNotNull null
        val ts = parts[4].toLongOrNull() ?: return@mapNotNull null
        // Backward compatible with the five-field history rows written by all
        // builds before v5.4.371cc.
        val durationMs = parts.getOrNull(5)?.toLongOrNull()?.coerceAtLeast(0L) ?: 0L
        RecentSearch(
            query = parts[0], noteId = id, title = parts[2], relPath = parts[3],
            ts = ts, durationMs = durationMs
        )
    }
}
