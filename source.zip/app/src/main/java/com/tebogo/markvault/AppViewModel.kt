package com.tebogo.markvault

import android.app.Application
import android.content.Intent
import android.net.Uri
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.tebogo.markvault.data.IndexProgress
import com.tebogo.markvault.data.Indexer
import com.tebogo.markvault.data.Note
import com.tebogo.markvault.data.NoteMeta
import com.tebogo.markvault.data.Prefs
import com.tebogo.markvault.data.SearchHit
import com.tebogo.markvault.data.VaultDb
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.FlowPreview
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.debounce
import kotlinx.coroutines.flow.distinctUntilChanged
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.flowOn
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

enum class SearchMode { TITLES, CONTENT }

@OptIn(FlowPreview::class)
class AppViewModel(app: Application) : AndroidViewModel(app) {

    private val db = VaultDb.get(app)
    private val dao = db.notes()
    private val prefs = Prefs(app)
    private val indexer = Indexer(app, dao)

    val libraryUri: StateFlow<String?> =
        prefs.libraryUri.stateIn(viewModelScope, SharingStarted.Eagerly, null)

    val fontScale: StateFlow<Float> =
        prefs.fontScale.stateIn(viewModelScope, SharingStarted.Eagerly, 1.0f)

    private val _progress = MutableStateFlow(IndexProgress())
    val progress: StateFlow<IndexProgress> = _progress

    private val _notes = MutableStateFlow<List<NoteMeta>>(emptyList())
    val notes: StateFlow<List<NoteMeta>> = _notes

    val query = MutableStateFlow("")
    val mode = MutableStateFlow(SearchMode.CONTENT)

    val results: StateFlow<List<SearchHit>> =
        combine(query.debounce(220).map { it.trim() }.distinctUntilChanged(), mode) { q, m ->
            q to m
        }.map { (q, m) ->
            when {
                q.length < 2 -> emptyList()
                m == SearchMode.TITLES -> runCatching {
                    dao.searchTitles("%$q%").map {
                        SearchHit(it.id, it.relPath, it.title, "")
                    }
                }.getOrElse { emptyList() }
                else -> runCatching { dao.search(toMatch(q)) }.getOrElse { emptyList() }
            }
        }.flowOn(Dispatchers.IO)
            .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    init {
        viewModelScope.launch {
            refreshNotes()
            // IMPORTANT: do NOT re-index on every launch. Only auto-index the very
            // first time (library set but nothing indexed yet, e.g. right after first
            // setup or after an update wiped the index). Otherwise the saved database
            // loads instantly and the user refreshes manually via the Sync button.
            val uri = prefs.libraryUri.first()
            if (uri != null && _notes.value.isEmpty()) startSync(uri)
        }
    }

    fun setLibrary(uri: Uri) {
        val app = getApplication<Application>()
        try {
            app.contentResolver.takePersistableUriPermission(
                uri,
                Intent.FLAG_GRANT_READ_URI_PERMISSION
            )
        } catch (_: Exception) {
        }
        viewModelScope.launch(Dispatchers.IO) {
            dao.clearAll()
            prefs.setLibraryUri(uri.toString())
            refreshNotes()
            startSync(uri.toString())
        }
    }

    fun reindex() {
        val uri = libraryUri.value ?: return
        startSync(uri)
    }

    private fun startSync(uri: String) {
        if (_progress.value.running) return
        _progress.value = IndexProgress(true, "Starting\u2026", 0, 0)
        viewModelScope.launch(Dispatchers.IO) {
            try {
                indexer.sync(uri) { p -> _progress.value = p }
            } catch (e: Exception) {
                _progress.value = IndexProgress(false, "Error: ${e.message}", 0, 0)
            }
            refreshNotes()
        }
    }

    private suspend fun refreshNotes() {
        _notes.value = runCatching { dao.allMeta() }.getOrElse { emptyList() }
    }

    suspend fun loadNote(id: Long): Note? {
        val n = dao.byId(id)
        if (n != null) runCatching { dao.touch(id, System.currentTimeMillis()) }
        return n
    }

    fun setFontScale(v: Float) {
        viewModelScope.launch { prefs.setFontScale(v) }
    }

    fun libraryName(): String {
        val uri = libraryUri.value ?: return "Library"
        val decoded = Uri.decode(uri)
        val seg = decoded.substringAfterLast(':', "").substringAfterLast('/')
        return if (seg.isBlank()) "Library" else seg
    }

    companion object {
        /**
         * Turn what the user typed into a safe FTS MATCH expression.
         *  - "quoted phrase"  -> exact phrase search
         *  - several words    -> all words required, each prefix-matched (word-level)
         */
        fun toMatch(raw: String): String {
            val trimmed = raw.trim()
            if (trimmed.startsWith("\"") && trimmed.endsWith("\"") && trimmed.length >= 2) {
                return trimmed
            }
            val cleaned = trimmed.replace(Regex("[^\\p{L}\\p{N}\\s]"), " ")
            val tokens = cleaned.split(Regex("\\s+")).filter { it.isNotBlank() }
            if (tokens.isEmpty()) return "\"\""
            return tokens.joinToString(" ") { "$it*" }
        }
    }
}
