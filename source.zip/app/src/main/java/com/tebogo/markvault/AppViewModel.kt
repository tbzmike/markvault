package com.tebogo.markvault

import android.app.Application
import android.content.Intent
import android.net.Uri
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.tebogo.markvault.data.IndexProgress
import com.tebogo.markvault.data.Indexer
import com.tebogo.markvault.data.LinkedNote
import com.tebogo.markvault.data.Note
import com.tebogo.markvault.data.NoteLink
import com.tebogo.markvault.data.NoteMeta
import com.tebogo.markvault.data.NoteTopic
import com.tebogo.markvault.data.PdfAnnotation
import com.tebogo.markvault.data.PdfHistoryEntry
import com.tebogo.markvault.data.PdfPageText
import com.tebogo.markvault.data.WebBookmark
import com.tebogo.markvault.data.WebHistoryEntry
import com.tebogo.markvault.data.Prefs
import com.tebogo.markvault.data.RecentNote
import com.tebogo.markvault.data.SearchHit
import com.tebogo.markvault.data.TopicCard
import com.tebogo.markvault.data.Topics
import com.tebogo.markvault.data.VaultDb
import com.tebogo.markvault.data.Wikilinks
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.FlowPreview
import kotlinx.coroutines.sync.withLock
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.SharingStarted
import androidx.compose.runtime.getValue
import androidx.compose.runtime.setValue
import com.tebogo.markvault.ui.WebTab
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.debounce
import kotlinx.coroutines.flow.distinctUntilChanged
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.flowOn
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

enum class SearchMode { TITLES, CONTENT }

/** Result of saveImportedMarkdown — either success with the new doc URI, or an error. */
sealed class SaveResult {
    data class Ok(val docUri: String, val fileName: String, val subfolder: String) : SaveResult()
    data class Error(val message: String) : SaveResult()
}

/** How an article was opened — used to badge it in the home recents list. */
enum class OpenSource {
    /** Opened from search, browse, recents, favourites, home — the default. */
    DIRECT,
    /** Opened by tapping a `[[wikilink]]` or a markdown link inside another note. */
    LINK,
    /** Opened from the Links & backlinks bottom sheet inside an article. */
    BACKLINK,
    /** Opened from a node in the graph view. */
    GRAPH
}

data class TabInfo(val id: Long, val title: String, val fileType: String = "md")
data class OutlineItem(val level: Int, val title: String, val index: Int)

@OptIn(FlowPreview::class)
class AppViewModel(app: Application) : AndroidViewModel(app) {

    private val db = VaultDb.get(app)
    private val dao = db.notes()
    private val prefs = Prefs(app)
    private val indexer = Indexer(app, dao)

    // v4.8 — semantic search foundation. The embedder is constructed eagerly
    // with the default model, then swapped in the init block below based on
    // the user's stored activeModelId preference.
    //
    // v4.9.0 — `embedder` is now a `var` so we can swap it when the user
    // picks a different model in Settings. @Volatile keeps reads from search
    // coroutines coherent with the swap.
    @Volatile
    private var embedder: com.tebogo.markvault.search.Embedder =
        com.tebogo.markvault.search.Embedder(
            app, com.tebogo.markvault.search.ModelCatalog.default
        )

    /** True iff the .tflite model has been downloaded and is usable. */
    private val _modelAvailable = MutableStateFlow(embedder.isModelAvailable())
    val modelAvailable: StateFlow<Boolean> = _modelAvailable

    /** Download progress [0.0, 1.0]. Null when not currently downloading. */
    private val _modelDownloadProgress = MutableStateFlow<Float?>(null)
    val modelDownloadProgress: StateFlow<Float?> = _modelDownloadProgress

    /** How many notes have a current embedding under the active model version. */
    private val _embeddingCount = MutableStateFlow(0)
    val embeddingCount: StateFlow<Int> = _embeddingCount

    /** [embedded, total] progress while an embedding pass is running. Null otherwise. */
    private val _embeddingProgress = MutableStateFlow<Pair<Int, Int>?>(null)
    val embeddingProgress: StateFlow<Pair<Int, Int>?> = _embeddingProgress

    // v4.9.0 — Semantic search controls. These mirror the corresponding Prefs
    // flows so the UI can observe them as StateFlows with synchronous .value
    // reads (the search ranking inspects semanticEnabled.value on every query).
    val semanticEnabled: StateFlow<Boolean> = prefs.semanticEnabled
        .stateIn(viewModelScope, SharingStarted.Eagerly, true)
    val autoCheckModelUpdates: StateFlow<Boolean> = prefs.autoCheckModelUpdates
        .stateIn(viewModelScope, SharingStarted.Eagerly, false)
    private val _activeModelId = MutableStateFlow(
        com.tebogo.markvault.search.ModelCatalog.default.id
    )
    val activeModelId: StateFlow<String> = _activeModelId

    /** All models from the catalog, exposed for the Settings model-picker UI. */
    val availableModels: List<com.tebogo.markvault.search.ModelDescriptor> =
        com.tebogo.markvault.search.ModelCatalog.all

    /** Last "check for updates" status message. Null = never checked. */
    private val _modelUpdateStatus = MutableStateFlow<String?>(null)
    val modelUpdateStatus: StateFlow<String?> = _modelUpdateStatus

    // ── v4.8.2 — In-memory semantic index ───────────────────────────────────
    // Holds every embedding row as a parallel-array structure for fast cosine
    // scoring. Loaded lazily on the first semantic query and invalidated when
    // the user re-embeds or clears the table.
    //
    // Memory cost for a 14k library at 100 dims: 14k * 100 * 4B = ~5.6 MB.
    // Per-query cost: 14k dot products of 100 floats ≈ 5-15ms on a mid-range
    // phone, plus a single ~50-200ms MediaPipe call to embed the query.
    private data class SemanticIndex(
        val noteIds: LongArray,
        val vectors: Array<FloatArray>,
        val dim: Int
    )

    private val embeddingCacheMutex = kotlinx.coroutines.sync.Mutex()
    @Volatile
    private var semanticIndex: SemanticIndex? = null

    /**
     * Load every stored embedding into the in-memory [SemanticIndex] for fast
     * cosine scoring. Idempotent — safe to call concurrently from many search
     * coroutines because the work runs inside a mutex. Returns null when no
     * embeddings exist yet (the model hasn't been used, or the table is empty),
     * so callers can fall back cleanly to keyword-only ranking.
     */
    private suspend fun ensureSemanticIndex(): SemanticIndex? {
        semanticIndex?.let { return it }
        return embeddingCacheMutex.withLock {
            semanticIndex?.let { return@withLock it }
            if (!embedder.isModelAvailable()) return@withLock null
            val rows = runCatching {
                dao.loadAllEmbeddings(embedder.modelVersion)
            }.getOrElse { return@withLock null }
            if (rows.isEmpty()) return@withLock null
            val ids = LongArray(rows.size)
            val vecs = Array(rows.size) { i ->
                ids[i] = rows[i].noteId
                com.tebogo.markvault.search.bytesToFloatArray(rows[i].vector)
            }
            SemanticIndex(ids, vecs, rows[0].dim).also { semanticIndex = it }
        }
    }

    /** Drop the cached index so the next semantic query reloads from the DB. */
    private fun invalidateSemanticIndex() { semanticIndex = null }

    /**
     * Semantic similarity search. Embeds [query] with the on-device model, then
     * computes cosine similarity against every cached vector and returns the
     * top-[topK] `(noteId, score)` pairs, sorted by descending score.
     *
     * MediaPipe L2-normalises its embeddings, so cosine reduces to a dot
     * product — we still use the full [cosineSimilarity] helper for defensive
     * correctness, but the inner loop is the cheap path in practice.
     *
     * Returns empty list (NOT null, NOT an exception) on any soft failure:
     * model not loaded, no embeddings, embedding the query fails, etc. The
     * search pipeline blends in zero contribution and the user still gets
     * keyword + synonym + fuzzy results.
     */
    suspend fun semanticSearch(query: String, topK: Int = 200): List<Pair<Long, Float>> {
        if (query.isBlank()) return emptyList()
        val idx = ensureSemanticIndex() ?: return emptyList()
        val qVec = embedder.embed(query) ?: return emptyList()
        if (qVec.size != idx.dim) return emptyList()
        // One pass: compute (noteId, score) for every cached vector.
        val scores = FloatArray(idx.vectors.size)
        for (i in idx.vectors.indices) {
            scores[i] = com.tebogo.markvault.search.cosineSimilarity(qVec, idx.vectors[i])
        }
        // Partial top-K: sort indices by score descending, keep top K.
        // For 14k items this is cheap (~1-2ms). Skip a heap for simplicity.
        val order = (0 until scores.size).sortedByDescending { scores[it] }
        val take = order.take(topK)
        return take.map { idx.noteIds[it] to scores[it] }
    }

    init {
        viewModelScope.launch(Dispatchers.IO) {
            _embeddingCount.value = runCatching {
                dao.embeddingCount(embedder.modelVersion)
            }.getOrElse { 0 }
        }
        // v4.9.0 — listen for active-model preference changes (including the
        // initial value at startup) and swap the embedder when the preferred
        // model differs from the one currently loaded. Each swap closes the
        // old embedder, refreshes the model-availability + embedding-count
        // state flows, and invalidates the semantic index so the next search
        // reloads under the new model's vectors.
        viewModelScope.launch {
            prefs.activeModelId.collect { id ->
                val descriptor = com.tebogo.markvault.search.ModelCatalog.byId(id)
                    ?: com.tebogo.markvault.search.ModelCatalog.default
                if (descriptor.id != embedder.descriptor.id) {
                    val old = embedder
                    embedder = com.tebogo.markvault.search.Embedder(
                        getApplication(), descriptor
                    )
                    runCatching { old.close() }
                    _modelAvailable.value = embedder.isModelAvailable()
                    _embeddingCount.value = runCatching {
                        dao.embeddingCount(embedder.modelVersion)
                    }.getOrElse { 0 }
                    invalidateSemanticIndex()
                }
                _activeModelId.value = descriptor.id
            }
        }
    }

    val libraryUri: StateFlow<String?> =
        prefs.libraryUri.stateIn(viewModelScope, SharingStarted.Eagerly, null)
    val fontScale: StateFlow<Float> =
        prefs.fontScale.stateIn(viewModelScope, SharingStarted.Eagerly, 1.0f)
    val theme: StateFlow<String> =
        prefs.theme.stateIn(viewModelScope, SharingStarted.Eagerly, "dark")
    // Performance/feature toggles — let the user opt in to heavier features.
    val smartStylingAllDocs: StateFlow<Boolean> =
        prefs.smartStylingAllDocs.stateIn(viewModelScope, SharingStarted.Eagerly, false)
    val swipeSwitchTabs: StateFlow<Boolean> =
        prefs.swipeSwitchTabs.stateIn(viewModelScope, SharingStarted.Eagerly, false)
    val textContrast: StateFlow<Float> =
        prefs.textContrast.stateIn(viewModelScope, SharingStarted.Eagerly, 1.0f)

    private val _progress = MutableStateFlow(IndexProgress())
    val progress: StateFlow<IndexProgress> = _progress

    private val _notes = MutableStateFlow<List<NoteMeta>>(emptyList())
    val notes: StateFlow<List<NoteMeta>> = _notes

    private val _recent = MutableStateFlow<List<RecentNote>>(emptyList())
    val recent: StateFlow<List<RecentNote>> = _recent

    private val _topics = MutableStateFlow<List<TopicCard>>(emptyList())
    val topics: StateFlow<List<TopicCard>> = _topics

    /** Notes added to the library since the last manual re-index (empty until first reindex). */
    private val _newNotes = MutableStateFlow<List<NoteMeta>>(emptyList())
    val newNotes: StateFlow<List<NoteMeta>> = _newNotes

    /** IDs of notes the user has starred as favourites. */
    private val _favouriteIds = MutableStateFlow<Set<Long>>(emptySet())
    val favouriteIds: StateFlow<Set<Long>> = _favouriteIds

    /** Starred notes as NoteMeta list for the home screen. */
    private val _favouriteNotes = MutableStateFlow<List<NoteMeta>>(emptyList())
    val favouriteNotes: StateFlow<List<NoteMeta>> = _favouriteNotes

    /** Notes recommended to the user — based on topic overlap with what they've been reading. */
    private val _suggested = MutableStateFlow<List<NoteMeta>>(emptyList())
    val suggested: StateFlow<List<NoteMeta>> = _suggested

    // ---- Recent search clicks (persisted, capped at 20) ----
    private val _recentSearches = MutableStateFlow<List<RecentSearch>>(emptyList())
    val recentSearches: StateFlow<List<RecentSearch>> = _recentSearches
    private val maxRecentSearches = 20

    /** Called when the user taps a search result. Stores the query + the note it led to. */
    fun recordSearchClick(query: String, noteId: Long, title: String, relPath: String) {
        val q = query.trim()
        if (q.isEmpty()) return
        val now = System.currentTimeMillis()
        val entry = RecentSearch(query = q, noteId = noteId, title = title, relPath = relPath, ts = now)
        // Dedup: drop any existing entry for the same (query, noteId), then prepend the fresh one
        val cur = _recentSearches.value
        val deduped = cur.filterNot { it.noteId == noteId && it.query.equals(q, ignoreCase = true) }
        val updated = (listOf(entry) + deduped).take(maxRecentSearches)
        _recentSearches.value = updated
        viewModelScope.launch(Dispatchers.IO) { runCatching { prefs.setRecentSearchesRaw(encodeRecents(updated)) } }
    }

    fun clearRecentSearches() {
        _recentSearches.value = emptyList()
        viewModelScope.launch(Dispatchers.IO) { runCatching { prefs.setRecentSearchesRaw("") } }
    }

    // ---- Open article tabs ----
    private val _tabs = MutableStateFlow<List<TabInfo>>(emptyList())
    val tabs: StateFlow<List<TabInfo>> = _tabs
    private val _activeTab = MutableStateFlow<Long?>(null)
    val activeTab: StateFlow<Long?> = _activeTab
    private val maxTabs = 8

    /**
     * In-Reader navigation history (tab IDs visited, oldest → newest).
     * Lets the system Back button return through previously-viewed tabs (e.g. after tapping a
     * backlink) instead of immediately exiting the Reader.
     */
    private val _tabHistory = MutableStateFlow<List<Long>>(emptyList())
    val tabHistory: StateFlow<List<Long>> = _tabHistory
    private val maxHistory = 50

    private fun pushHistory(id: Long) {
        val cur = _tabHistory.value
        if (cur.lastOrNull() == id) return // dedupe consecutive
        val updated = (cur + id)
        _tabHistory.value = if (updated.size > maxHistory) updated.takeLast(maxHistory) else updated
    }

    /**
     * Pop the current tab off history and activate the previous one.
     * Returns true if we moved back inside the Reader; false if there's nowhere to go back to
     * (caller should let the system Back press exit the Reader).
     */
    fun goBackInTabs(): Boolean {
        val cur = _tabHistory.value
        if (cur.size < 2) return false
        val updated = cur.dropLast(1)
        _tabHistory.value = updated
        _activeTab.value = updated.last()
        return true
    }

    /**
     * Switch to the next / previous tab in the open tabs list (not history).
     * Used by swipe-left / swipe-right gestures inside the Reader.
     * Returns true if it switched, false if there's only one tab.
     */
    fun switchTabByDirection(forward: Boolean): Boolean {
        val list = _tabs.value
        if (list.size < 2) return false
        val curId = _activeTab.value ?: list.first().id
        val idx = list.indexOfFirst { it.id == curId }
        if (idx < 0) return false
        val next = if (forward) (idx + 1) % list.size else (idx - 1 + list.size) % list.size
        val newId = list[next].id
        _activeTab.value = newId
        pushHistory(newId)
        return true
    }

    /** Clear the tab visit history. Called when the Reader exits to home / search etc. */
    fun clearTabHistory() { _tabHistory.value = emptyList() }

    val query = MutableStateFlow("")
    val mode = MutableStateFlow(SearchMode.CONTENT)
    /**
     * When ON, wraps the user's query in quotes before searching so FTS treats it
     * as an exact phrase. Only meaningful for SearchMode.CONTENT (the UI hides the
     * toggle in TITLES mode where it has no effect).
     */
    val quotePhrase = MutableStateFlow(false)

    val results: StateFlow<List<SearchHit>> =
        combine(
            query.debounce(220).map { it.trim() }.distinctUntilChanged(),
            mode,
            quotePhrase
        ) { q, m, qp -> Triple(q, m, qp) }
            .map { (q, m, qp) ->
                when {
                    q.length < 2 -> emptyList()
                    m == SearchMode.TITLES -> runCatching {
                        // v4.7.7 — query expansion layer. The original query is
                        // always run first; expanded variants are unioned in
                        // and the combined set is re-ranked with a fuzzy boost.
                        // If expansion produces no extra variants, the result
                        // is identical to the old code path.
                        expandedTitleSearch(q)
                    }.getOrElse { emptyList() }
                    else -> {
                        val effective = if (qp && !(q.startsWith("\"") && q.endsWith("\""))) "\"$q\"" else q
                        runCatching {
                            expandedContentSearch(effective, originalRaw = q, exactPhrase = qp)
                        }.getOrElse { emptyList() }
                    }
                }
            }.flowOn(Dispatchers.IO)
            .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    /**
     * v4.7.7 — title search with synonym expansion + fuzzy re-ranking.
     * Strategy: run `titleSearch` against each variant from [QueryExpander.expand],
     * union the result IDs (de-duping by id), then re-rank using a fuzzy boost
     * computed against the original query tokens. Backward compatible: when
     * the query produces no expansion (no synonym matches), the output equals
     * the old direct `titleSearch(q)`.
     */
    private suspend fun expandedTitleSearch(raw: String): List<SearchHit> {
        val variants = com.tebogo.markvault.search.QueryExpander.expand(raw)
        // v4.8.2 — even with only one variant we still want to run the
        // semantic side, so don't short-circuit anymore. The old fast path
        // skipped expansion AND semantic, regressing search quality. Now we
        // always do the full blend.
        val keywordHits = LinkedHashMap<Long, SearchHit>()
        for (v in variants) {
            val hits = runCatching { titleSearch(v) }.getOrElse { emptyList() }
            for (h in hits) keywordHits.putIfAbsent(h.id, h)
        }
        return blendSemanticAndKeyword(
            keywordHits = keywordHits,
            originalRaw = raw,
            scoreSource = { hit -> hit.title + " " + hit.relPath }
        )
    }

    /**
     * v4.7.7 — full-text content search with synonym expansion. Same approach
     * as [expandedTitleSearch], but with one safety: in exact-phrase mode we
     * still run every expanded variant as an exact phrase, so the user's
     * intent ("phrase match") is preserved on each variant individually. If
     * any single variant matches, the user gets results.
     */
    private suspend fun expandedContentSearch(
        effective: String, originalRaw: String, exactPhrase: Boolean
    ): List<SearchHit> {
        val variants = com.tebogo.markvault.search.QueryExpander.expand(originalRaw)
        val keywordHits = LinkedHashMap<Long, SearchHit>()
        for (v in variants) {
            val effv = if (exactPhrase) "\"$v\"" else v
            val hits = runCatching {
                rankedContentSearch(effv, originalRaw = v)
            }.getOrElse { emptyList() }
            for (h in hits) keywordHits.putIfAbsent(h.id, h)
        }
        return blendSemanticAndKeyword(
            keywordHits = keywordHits,
            originalRaw = originalRaw,
            scoreSource = { hit -> hit.title + " " + hit.snippet }
        )
    }

    /**
     * v4.8.2 — final ranking stage shared by both expanded* functions.
     *
     * Combines three signals into a single blended score:
     *
     *   1. **Keyword hit bonus** — if the note appeared in any keyword/synonym
     *      result set, it gets a flat +5000 boost. This anchors literal matches
     *      at the top so a user searching "Abraham" still sees the Abraham
     *      article first even if some other article is semantically closer.
     *
     *   2. **Semantic similarity** — cosine vs query embedding, mapped from
     *      `[-1, 1]` to `[0, 5000]` via `cos * 5000`. A near-perfect semantic
     *      match (cos ≈ 1.0) earns about the same as a keyword hit, so pure
     *      semantic matches surface alongside literal matches when they're
     *      strongly related but use different vocabulary.
     *
     *   3. **Fuzzy boost** — small additive for typos / inflectional variants
     *      (~10-30 each). Mostly tiebreaker.
     *
     * The blend is intentionally additive (not multiplicative) so a single
     * strong signal alone is enough to surface a result. The score is then
     * sorted descending and the top 400 returned.
     *
     * Pure-semantic candidates (semantic hit but no keyword hit) have their
     * `SearchHit` rows lazily constructed from `dao.byId(id)` since the
     * keyword path didn't produce one. Their `snippet` is empty — that's
     * fine; the result row falls back to the title + path + context preview.
     */
    private suspend fun blendSemanticAndKeyword(
        keywordHits: LinkedHashMap<Long, SearchHit>,
        originalRaw: String,
        scoreSource: (SearchHit) -> String
    ): List<SearchHit> {
        // v4.9.0 — gate the semantic step on the user's toggle. When the
        // switch is off in Settings, we skip the query-embedding call and
        // the cosine scan entirely; the pipeline falls back to pure keyword
        // + synonym + fuzzy ranking. Cheap (no MediaPipe call, no 14k
        // dot products) and gives the user A/B-comparison capability.
        val useSemantic = semanticEnabled.value
        val semantic = if (useSemantic) {
            runCatching {
                semanticSearch(originalRaw, topK = 200)
            }.getOrElse { emptyList() }
        } else emptyList()
        val semanticScores: Map<Long, Float> = semantic.toMap()

        // Union of all candidate IDs.
        val allIds: Set<Long> = LinkedHashSet<Long>().apply {
            addAll(keywordHits.keys)
            for (s in semantic) add(s.first)
        }
        if (allIds.isEmpty()) return emptyList()

        val originalTokens = originalRaw.split(Regex("\\s+")).filter { it.isNotEmpty() }
        val scored = ArrayList<Pair<SearchHit, Int>>(allIds.size)

        for (id in allIds) {
            // Prefer the keyword-side SearchHit (already has snippet); fall
            // back to fabricating a hit from the Note row for semantic-only IDs.
            val hit = keywordHits[id] ?: run {
                val n = runCatching { dao.byId(id) }.getOrNull()
                    ?: return@run null
                SearchHit(
                    id = n.id, relPath = n.relPath, title = n.title,
                    snippet = "", fileType = n.fileType
                )
            } ?: continue

            val keywordBonus = if (id in keywordHits) 5000 else 0
            val semBoost = ((semanticScores[id] ?: 0f) * 5000f).toInt()
            val fuzzyBoost = com.tebogo.markvault.search.QueryExpander.fuzzyBoost(
                scoreSource(hit), originalTokens
            )
            scored.add(hit to (keywordBonus + semBoost + fuzzyBoost))
        }
        return scored
            .sortedByDescending { it.second }
            .map { it.first }
            .take(400)
    }

    /**
     * Content search with smarter ranking. Prefers, in order:
     *  1. Exact phrase appearing in the title
     *  2. Exact phrase appearing in the content
     *  3. All query words appearing in the title (any order)
     *  4. All query words appearing in the content
     *  5. Most query words appearing somewhere (last resort — filtered if too sparse)
     *
     * Adds bonuses for: word-adjacency in the snippet, multiple matches in one
     * document, and matches at word boundaries.
     */
    private suspend fun rankedContentSearch(ftsQuery: String, originalRaw: String): List<SearchHit> {
        val ftsHits = dao.search(Topics.expandQuery(ftsQuery))
        if (ftsHits.isEmpty()) return emptyList()

        // The original (un-quoted) phrase from the user, used for scoring + display.
        val phrase = originalRaw.trim()
            .removeSurrounding("\"")
            .lowercase()
        val tokens = phrase.split(Regex("\\s+"))
            .map { it.replace(Regex("[^\\p{L}\\p{N}]"), "") }
            .filter { it.length >= 2 }
        val tokensLower = tokens.toSet()
        val isMultiWord = tokensLower.size > 1

        data class Scored(val hit: SearchHit, val score: Int)
        val scored = ftsHits.mapNotNull { h ->
            val title = h.title.lowercase()
            val snippet = h.snippet.lowercase()

            // Match-marker count tells us how many distinct hits appeared in the snippet
            // (the FTS snippet() function wraps each match in ⟦…⟧).
            val markerCount = h.snippet.count { it == '\u27E6' }

            val titleHasPhrase = title.contains(phrase)
            val snippetHasPhrase = snippet.contains(phrase)
            val titleTokenHits = tokensLower.count { title.contains(it) }
            val snippetTokenHits = tokensLower.count { snippet.contains(it) }

            // Adjacency: are all the query tokens within a ~10-word window of each other?
            val adjacencyBonus = if (isMultiWord && snippetTokenHits == tokensLower.size) {
                val words = snippet.split(Regex("\\s+"))
                var found = false
                if (words.size >= tokensLower.size) {
                    for (i in 0..(words.size - tokensLower.size)) {
                        val end = minOf(i + 10, words.size)
                        val window = words.subList(i, end).joinToString(" ")
                        if (tokensLower.all { window.contains(it) }) { found = true; break }
                    }
                }
                if (found) 800 else 0
            } else 0

            // Word boundary bonus: phrase appears at a word boundary in the title
            val titleBoundaryBonus = if (isMultiWord && phrase.length >= 3 &&
                Regex("\\b" + Regex.escape(phrase) + "\\b").containsMatchIn(title)) 2_000 else 0

            val score = when {
                titleHasPhrase -> 10_000 + titleBoundaryBonus + markerCount * 50
                snippetHasPhrase -> 5_000 + titleTokenHits * 200 + markerCount * 100 + adjacencyBonus
                isMultiWord && titleTokenHits == tokensLower.size -> 3_500 + adjacencyBonus + markerCount * 50
                isMultiWord && snippetTokenHits == tokensLower.size -> 1_800 + adjacencyBonus + titleTokenHits * 150 + markerCount * 30
                else -> {
                    val total = titleTokenHits + snippetTokenHits
                    // Discard sparse matches — e.g. "ar" matching "art history" when only
                    // one of two query tokens appears.
                    if (isMultiWord && total < (tokensLower.size + 1) / 2) return@mapNotNull null
                    100 + titleTokenHits * 40 + snippetTokenHits * 10 + markerCount * 5
                }
            }
            Scored(h, score)
        }
        return scored
            .sortedByDescending { it.score }
            .take(150)
            .map { it.hit }
    }

    /**
     * Obsidian-style title search: every word in the query must appear somewhere in the
     * title / file name / path, in any order. Exact-phrase matches in the title rank highest.
     */
    private suspend fun titleSearch(raw: String): List<SearchHit> {
        val tokens = raw.split(Regex("\\s+"))
            .map { it.trim() }
            .filter { it.isNotEmpty() }
            .take(6)
        if (tokens.isEmpty()) return emptyList()
        // Pad up to 6 LIKE slots; "%%" matches anything so unused slots are no-ops.
        val pats = (0 until 6).map { i ->
            if (i < tokens.size) "%${tokens[i]}%" else "%%"
        }
        val rows = dao.searchTitlesAllWords(
            pats[0], pats[1], pats[2], pats[3], pats[4], pats[5]
        )
        val phrase = raw.lowercase()
        val tokensLower = tokens.map { it.lowercase() }
        // Score each hit: prefer exact phrase, then more tokens in title vs path
        return rows.asSequence()
            .map { n ->
                val titleLower = n.title.lowercase()
                val pathLower = n.relPath.lowercase()
                val score = when {
                    titleLower.contains(phrase) -> 1_000
                    pathLower.contains(phrase) -> 800
                    else -> {
                        val titleHits = tokensLower.count { titleLower.contains(it) }
                        val pathHits = tokensLower.count { pathLower.contains(it) }
                        titleHits * 10 + pathHits
                    }
                }
                n to score
            }
            .sortedWith(
                compareByDescending<Pair<NoteMeta, Int>> { it.second }
                    .thenBy { it.first.title.lowercase() }
            )
            .take(200)
            .map { (n, _) -> SearchHit(n.id, n.relPath, n.title, "", n.fileType) }
            .toList()
    }

    /** Topic cards whose vocabulary matches the current query (shown above results). */
    val topicMatches: StateFlow<List<TopicCard>> =
        combine(query.debounce(220).map { it.trim() }.distinctUntilChanged(), _topics) { q, topics ->
            if (q.length < 2) emptyList()
            else {
                val keys = Topics.matchQuery(q).toSet()
                topics.filter { it.key in keys }
            }
        }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    init {
        viewModelScope.launch {
            refreshNotes()
            refreshRecent()
            refreshTopics()
            refreshFavourites(); refreshSuggested()
            runCatching { _recentSearches.value = decodeRecents(prefs.recentSearchesRaw.first()) }
            val uri = prefs.libraryUri.first()
            val storedTopicVersion = prefs.topicVersion.first()
            val storedLinksVersion = prefs.linksVersion.first()
            when {
                uri != null && _notes.value.isEmpty() -> startSync(uri)
                _notes.value.isNotEmpty() -> {
                    if (storedTopicVersion != Topics.VERSION) {
                        reclassifyTopics()
                        prefs.setTopicVersion(Topics.VERSION)
                    }
                    if (storedLinksVersion != Wikilinks.VERSION) {
                        reextractLinks()
                        prefs.setLinksVersion(Wikilinks.VERSION)
                    }
                }
            }
        }
    }

    fun setLibrary(uri: Uri) {
        val app = getApplication<Application>()
        try {
            // Request BOTH read and write so we can save imported markdown files
            // back into the library. WRITE is needed by saveImportedMarkdown().
            app.contentResolver.takePersistableUriPermission(
                uri,
                Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_WRITE_URI_PERMISSION
            )
        } catch (_: Exception) {
        }
        viewModelScope.launch(Dispatchers.IO) {
            dao.clearAll()
            runCatching { dao.clearTopics() }
            runCatching { dao.clearLinks() }
            prefs.setLibraryUri(uri.toString())
            _tabs.value = emptyList(); _activeTab.value = null
            _newNotes.value = emptyList()
            refreshNotes(); refreshRecent(); refreshTopics(); refreshFavourites(); refreshSuggested()
            startSync(uri.toString(), trackNewNotes = false)
        }
    }

    fun reindex() {
        val uri = libraryUri.value ?: return
        startSync(uri, trackNewNotes = true)
    }

    private fun startSync(uri: String, trackNewNotes: Boolean = false) {
        if (_progress.value.running) return
        _progress.value = IndexProgress(true, "Starting\u2026", 0, 0)
        viewModelScope.launch(Dispatchers.IO) {
            try {
                val beforeRelPaths = if (trackNewNotes)
                    runCatching { dao.allMeta().map { it.relPath }.toSet() }.getOrElse { emptySet() }
                else emptySet()
                indexer.sync(uri) { p -> _progress.value = p }
                if (trackNewNotes) {
                    val afterAll = runCatching { dao.allMeta() }.getOrElse { emptyList() }
                    _newNotes.value = afterAll.filter { it.relPath !in beforeRelPaths }.take(30)
                }
            } catch (e: Exception) {
                _progress.value = IndexProgress(false, "Error: ${e.message}", 0, 0)
            }
            refreshNotes(); refreshRecent(); refreshTopics(); refreshFavourites(); refreshSuggested()
            runCatching { prefs.setTopicVersion(Topics.VERSION) }
            runCatching { prefs.setLinksVersion(Wikilinks.VERSION) }
        }
    }

    /** Re-tag every already-indexed note using the current lexicon (no file re-scan). */
    private suspend fun reclassifyTopics() {
        val total = runCatching { dao.countNotes() }.getOrElse { 0 }
        if (total == 0) return
        _progress.value = IndexProgress(true, "Updating topics\u2026", 0, total)
        runCatching { dao.clearTopics() }
        val pageSize = 300
        var offset = 0
        var done = 0
        while (offset < total) {
            val page = runCatching { dao.notesTextPage(pageSize, offset) }.getOrElse { emptyList() }
            if (page.isEmpty()) break
            for (nt in page) {
                val topics = runCatching { Topics.classify(nt.title, nt.content) }.getOrElse { emptyList() }
                if (topics.isNotEmpty()) {
                    runCatching { dao.insertTopics(topics.map { NoteTopic(nt.id, it.first, it.second) }) }
                }
                done++
            }
            offset += pageSize
            _progress.value = IndexProgress(true, "Updating topics\u2026", done, total)
        }
        _progress.value = IndexProgress(false, "Done", total, total)
        refreshTopics()
    }

    /**
     * Re-run the wikilink/markdown-link extractor across every note's stored content.
     * Used after the extractor version bumps (e.g. when markdown-style `[label](file.md)` support
     * is added) so existing notes get the new edges without forcing a full file re-read.
     */
    private suspend fun reextractLinks() {
        val total = runCatching { dao.countNotes() }.getOrElse { 0 }
        if (total == 0) return
        _progress.value = IndexProgress(true, "Updating links\u2026", 0, total)
        runCatching { dao.clearLinks() }
        val pageSize = 300
        var offset = 0
        var done = 0
        while (offset < total) {
            val page = runCatching { dao.notesTextPage(pageSize, offset) }.getOrElse { emptyList() }
            if (page.isEmpty()) break
            for (nt in page) {
                val targets = runCatching { Wikilinks.extract(nt.content) }.getOrElse { emptyList() }
                if (targets.isNotEmpty()) {
                    val rows = targets.map { NoteLink(nt.id, it, Wikilinks.normalize(it)) }
                    runCatching { dao.insertLinks(rows) }
                }
                done++
            }
            offset += pageSize
            _progress.value = IndexProgress(true, "Updating links\u2026", done, total)
        }
        _progress.value = IndexProgress(false, "Done", total, total)
    }

    private suspend fun refreshNotes() {
        _notes.value = runCatching { dao.allMeta() }.getOrElse { emptyList() }
    }

    private suspend fun refreshRecent() {
        _recent.value = runCatching { dao.recentNotes() }.getOrElse { emptyList() }
    }

    private suspend fun refreshTopics() {
        val counts = runCatching { dao.topicCounts() }.getOrElse { emptyList() }
            .associate { it.topic to it.cnt }
        _topics.value = Topics.ALL.mapNotNull { d ->
            val c = counts[d.key] ?: 0
            if (c > 0) TopicCard(d.key, d.emoji, d.label, c) else null
        }.sortedByDescending { it.count }
    }

    private suspend fun refreshFavourites() {
        val favs = runCatching { dao.favouriteNotes() }.getOrElse { emptyList() }
        _favouriteIds.value = favs.map { it.id }.toSet()
        _favouriteNotes.value = favs
    }

    private suspend fun refreshSuggested() {
        // Hide notes opened in the last ~3 weeks; if the user has no reading history
        // (or no topic overlap), fall back to random unopened notes.
        val cutoff = System.currentTimeMillis() - 21L * 24L * 60L * 60L * 1000L
        val topicBased = runCatching { dao.suggestedNotes(cutoff, 25) }.getOrElse { emptyList() }
        _suggested.value = if (topicBased.size >= 6) topicBased
        else runCatching { dao.randomUnopened(25) }.getOrElse { topicBased }
    }

    fun toggleFavourite(id: Long) {
        viewModelScope.launch(Dispatchers.IO) {
            val isCurrentlyFav = _favouriteIds.value.contains(id)
            runCatching { dao.setFavourite(id, if (isCurrentlyFav) 0 else 1) }
            refreshFavourites(); refreshSuggested()
        }
    }

    suspend fun loadTopicNotes(key: String): List<NoteMeta> =
        runCatching { dao.notesInTopic(key) }.getOrElse { emptyList() }

    /** Resolve an Obsidian-style `[[target]]` to a note in the library, or null if not found. */
    suspend fun resolveWikilink(target: String): LinkedNote? {
        val norm = Wikilinks.normalize(target)
        if (norm.isEmpty()) return null
        return runCatching { dao.resolveLink(norm, Wikilinks.withMd(norm)) }.getOrNull()
    }

    /** Notes whose body contains `[[<this note>]]` — i.e. backlinks. */
    suspend fun loadBacklinks(noteId: Long): List<LinkedNote> {
        val n = runCatching { dao.byId(noteId) }.getOrNull() ?: return emptyList()
        // A backlink could write the target as the title, the file name (with or without .md), or the relPath
        val candidates = LinkedHashSet<String>()
        candidates.add(Wikilinks.normalize(n.title))
        candidates.add(Wikilinks.normalize(n.name))
        candidates.add(Wikilinks.normalize(n.name.removeSuffix(".md").removeSuffix(".MD")
            .removeSuffix(".markdown").removeSuffix(".MARKDOWN")))
        candidates.add(Wikilinks.normalize(n.relPath))
        val list = candidates.filter { it.isNotEmpty() }
        if (list.isEmpty()) return emptyList()
        return runCatching { dao.backlinksFor(list) }.getOrElse { emptyList() }
            .filter { it.id != noteId }
    }

    /** Outgoing wikilinks from this note that point to existing notes. */
    suspend fun loadForwardLinks(noteId: Long): List<LinkedNote> =
        runCatching { dao.forwardLinksFor(noteId) }.getOrElse { emptyList() }
            .filter { it.id != noteId }

    /**
     * Fast count of total connections (forward links + backlinks) for a note.
     * Used to badge the Reader header so the user sees how connected the article is at a glance.
     */
    suspend fun connectionCount(noteId: Long): Int {
        val n = runCatching { dao.byId(noteId) }.getOrNull() ?: return 0
        val candidates = LinkedHashSet<String>().apply {
            add(Wikilinks.normalize(n.title))
            add(Wikilinks.normalize(n.name))
            add(Wikilinks.normalize(n.name.removeSuffix(".md").removeSuffix(".MD")
                .removeSuffix(".markdown").removeSuffix(".MARKDOWN")))
            add(Wikilinks.normalize(n.relPath))
        }.filter { it.isNotEmpty() }
        val forwards = runCatching { dao.forwardLinkCount(noteId) }.getOrElse { 0 }
        val backs = if (candidates.isEmpty()) 0
            else runCatching { dao.backlinkCount(candidates, noteId) }.getOrElse { 0 }
        return forwards + backs
    }

    /** The note with the most total connections in the library (best starting anchor for the graph). */
    suspend fun mostConnectedNote(): LinkedNote? =
        runCatching { dao.mostConnectedNote() }.getOrNull()

    /**
     * Build a 2-degree connection graph around [centerId]. Returns the focus note, its 1st-degree
     * neighbours (capped), and 2nd-degree neighbours (capped). Connection direction is preserved
     * so the UI can draw incoming vs outgoing edges differently.
     */
    suspend fun buildFocusGraph(centerId: Long): FocusGraph? {
        val centerNote = runCatching { dao.byId(centerId) }.getOrNull() ?: return null
        val center = LinkedNote(centerNote.id, centerNote.title, centerNote.folder)

        val forwards = loadForwardLinks(centerId)
        val backs = loadBacklinks(centerId)

        // Combined first-ring nodes (uniqued by id), with link direction tagged.
        // outgoing = center -> node, incoming = node -> center, both = bidirectional.
        val firstRingMap = LinkedHashMap<Long, GraphNeighbour>()
        for (f in forwards) firstRingMap[f.id] = GraphNeighbour(f, LinkDir.OUTGOING)
        for (b in backs) {
            val existing = firstRingMap[b.id]
            firstRingMap[b.id] = if (existing != null) existing.copy(dir = LinkDir.BOTH)
            else GraphNeighbour(b, LinkDir.INCOMING)
        }
        val firstRing = firstRingMap.values.toList().take(MAX_FIRST_RING)
        val firstRingIds = firstRing.map { it.note.id }.toSet() + centerId

        // Second-ring nodes: anything 1° neighbours link to/from, minus already-shown nodes.
        val secondRingMap = LinkedHashMap<Long, GraphEdge>()
        for (n in firstRing) {
            val ff = loadForwardLinks(n.note.id)
            val bb = loadBacklinks(n.note.id)
            for (x in ff) {
                if (x.id in firstRingIds) continue
                if (secondRingMap.size >= MAX_SECOND_RING && x.id !in secondRingMap) continue
                if (x.id !in secondRingMap) secondRingMap[x.id] = GraphEdge(x, n.note.id)
            }
            for (x in bb) {
                if (x.id in firstRingIds) continue
                if (secondRingMap.size >= MAX_SECOND_RING && x.id !in secondRingMap) continue
                if (x.id !in secondRingMap) secondRingMap[x.id] = GraphEdge(x, n.note.id)
            }
        }
        val secondRing = secondRingMap.values.toList()

        return FocusGraph(
            center = center,
            firstRing = firstRing,
            secondRing = secondRing,
            firstRingTotal = firstRingMap.size,
            secondRingTotal = -1 // unknown without re-counting; UI can show "+more" if needed
        )
    }

    /** Open an article in a tab (reusing it if already open) and make it active. */
    /** How an article was last opened — drives the small badge on the recents/history list. */
    private val _recentOpenSources = MutableStateFlow<Map<Long, OpenSource>>(emptyMap())
    val recentOpenSources: StateFlow<Map<Long, OpenSource>> = _recentOpenSources

    /**
     * Open an article in a tab (reusing it if already open) and make it active.
     * [source] records WHY we're opening it (e.g. from a wikilink) so the home screen can
     * badge it in the recently-opened list.
     */
    fun openArticle(id: Long, title: String, source: OpenSource = OpenSource.DIRECT, fileType: String = "md") {
        val list = _tabs.value.toMutableList()
        val existing = list.indexOfFirst { it.id == id }
        if (existing < 0) {
            list.add(TabInfo(id, title, fileType))
            while (list.size > maxTabs) {
                val drop = list.firstOrNull { it.id != id }
                if (drop != null) {
                    list.remove(drop)
                    // Also strip the dropped tab from the visit history so back doesn't try to return there
                    _tabHistory.value = _tabHistory.value.filter { it != drop.id }
                } else break
            }
            _tabs.value = list
        }
        _activeTab.value = id
        pushHistory(id)
        // Update source map: keep a small rolling window so it doesn't grow without bound
        val cur = _recentOpenSources.value.toMutableMap()
        cur[id] = source
        if (cur.size > 60) {
            // Trim oldest by recents ordering would be ideal but we don't have timestamps here;
            // simple cap keeps memory bounded.
            val drop = cur.keys.first()
            cur.remove(drop)
        }
        _recentOpenSources.value = cur
        viewModelScope.launch { refreshRecent() }
    }

    fun setActiveTab(id: Long) {
        _activeTab.value = id
        pushHistory(id)
    }

    fun closeTab(id: Long) {
        val list = _tabs.value.toMutableList()
        val idx = list.indexOfFirst { it.id == id }
        if (idx < 0) return
        list.removeAt(idx)
        _tabs.value = list
        // Drop every occurrence of the closed tab from history
        _tabHistory.value = _tabHistory.value.filter { it != id }
        if (_activeTab.value == id) {
            val newActive = list.getOrNull(idx.coerceAtMost(list.size - 1))?.id
            _activeTab.value = newActive
            if (newActive != null) pushHistory(newActive)
        }
    }

    /** Close every open tab. Used by the tab-management bottom sheet. */
    fun closeAllTabs() {
        _tabs.value = emptyList()
        _tabHistory.value = emptyList()
        _activeTab.value = null
    }

    /** Close every tab except the given one. Convenient when the user picks one in the grid. */
    fun closeOtherTabs(keepId: Long) {
        val keep = _tabs.value.firstOrNull { it.id == keepId } ?: return
        _tabs.value = listOf(keep)
        _tabHistory.value = listOf(keepId)
        _activeTab.value = keepId
    }

    suspend fun loadNote(id: Long): Note? {
        val n = dao.byId(id)
        if (n != null) {
            runCatching { dao.touch(id, System.currentTimeMillis()) }
            refreshRecent()
        }
        return n
    }

    /**
     * Return the SAF content URI string for a PDF note so the PdfReaderScreen can open it.
     * Also touches the "lastOpened" timestamp so it appears in recents.
     */
    suspend fun loadPdfUri(id: Long): String? {
        val n = dao.byId(id) ?: return null
        if (n.fileType != "pdf") return null
        runCatching { dao.touch(id, System.currentTimeMillis()) }
        refreshRecent()
        return n.uri
    }

    /** Look up the fileType for a note ID — used to decide which viewer to open. */
    suspend fun fileTypeOf(id: Long): String =
        runCatching { dao.byId(id)?.fileType }.getOrNull() ?: "md"

    /* ──────────────────────────────────────────────────────────────────────
     *  PDF text cache (per page) — used by in-PDF search for instant queries
     *  on second/third open. Re-extracted whenever the source file changes.
     * ────────────────────────────────────────────────────────────────────── */

    /** Returns cached page text iff it matches the source file's current lastModified. */
    suspend fun cachedPdfPageText(noteId: Long): Map<Int, String>? {
        val note = runCatching { dao.byId(noteId) }.getOrNull() ?: return null
        val stamp = runCatching { dao.pdfPageTextStamp(noteId) }.getOrNull() ?: return null
        if (stamp != note.lastModified) return null
        val rows = runCatching { dao.loadPdfPageText(noteId) }.getOrNull() ?: return null
        if (rows.isEmpty()) return null
        return rows.associate { it.pageIndex to it.text }
    }

    /** Persists the extracted text so future opens skip extraction. */
    suspend fun savePdfPageText(noteId: Long, pages: Map<Int, String>) {
        val note = runCatching { dao.byId(noteId) }.getOrNull() ?: return
        val rows = pages.entries.map { (i, t) ->
            PdfPageText(noteId, i, t, note.lastModified)
        }
        runCatching {
            dao.clearPdfPageText(noteId)
            dao.savePdfPageText(rows)
        }
    }

    /* ── PDF annotations ── */

    suspend fun loadAnnotation(noteId: Long, page: Int): String? =
        runCatching { dao.loadAnnotation(noteId, page)?.paths }.getOrNull()

    suspend fun loadAllAnnotations(noteId: Long): Map<Int, String> =
        runCatching {
            dao.loadAnnotationsForNote(noteId).associate { it.pageIndex to it.paths }
        }.getOrElse { emptyMap() }

    suspend fun saveAnnotation(noteId: Long, page: Int, pathsJson: String) {
        runCatching {
            if (pathsJson.isBlank() || pathsJson == "[]") dao.deleteAnnotation(noteId, page)
            else dao.saveAnnotation(PdfAnnotation(noteId, page, pathsJson))
        }
    }

    suspend fun clearAllAnnotations(noteId: Long) {
        runCatching { dao.deleteAllAnnotationsForNote(noteId) }
    }

    /* ── PDF view history (internal + external) ── */

    /** Record that a PDF was opened. Called on every PDF open from any path. */
    fun recordPdfView(uri: String, title: String, noteId: Long, isExternal: Boolean) {
        viewModelScope.launch(Dispatchers.IO) {
            runCatching {
                dao.deletePdfHistoryByUri(uri)
                dao.insertPdfHistory(PdfHistoryEntry(
                    uri = uri, title = title, noteId = noteId, isExternal = isExternal
                ))
            }
        }
    }

    suspend fun loadPdfHistory(limit: Int = 100): List<PdfHistoryEntry> =
        runCatching { dao.recentPdfHistory(limit) }.getOrElse { emptyList() }

    fun deletePdfHistoryEntry(id: Long) {
        viewModelScope.launch(Dispatchers.IO) { runCatching { dao.deletePdfHistory(id) } }
    }

    fun clearPdfHistory() {
        viewModelScope.launch(Dispatchers.IO) { runCatching { dao.clearPdfHistory() } }
    }

    /* ── Web history (in-app browser visits) ── */

    fun recordWebVisit(url: String, title: String) {
        if (url.isBlank()) return
        viewModelScope.launch(Dispatchers.IO) {
            runCatching {
                val host = runCatching { android.net.Uri.parse(url).host ?: "" }.getOrElse { "" }
                dao.deleteWebHistoryByUrl(url)   // dedupe by URL — keep newest only
                dao.insertWebHistory(WebHistoryEntry(
                    url = url, title = title.ifBlank { url }, host = host
                ))
            }
        }
    }

    suspend fun loadWebHistory(limit: Int = 200): List<WebHistoryEntry> =
        runCatching { dao.recentWebHistory(limit) }.getOrElse { emptyList() }

    fun deleteWebHistoryEntry(id: Long) {
        viewModelScope.launch(Dispatchers.IO) { runCatching { dao.deleteWebHistory(id) } }
    }

    fun clearWebHistory() {
        viewModelScope.launch(Dispatchers.IO) { runCatching { dao.clearWebHistory() } }
    }

    /* ── Persistent in-app browser session (TASK 4) ──
     * The tab list lives here on the VM so when the user navigates away to read
     * a markdown note or a PDF and comes back to the browser, their tabs are
     * still there. The WebView itself is recreated each time (Compose can't
     * persist a native view across screen changes without a custom host), but
     * the URLs + titles + which tab was active are preserved verbatim.
     */
    val webTabs: androidx.compose.runtime.snapshots.SnapshotStateList<com.tebogo.markvault.ui.WebTab> =
        androidx.compose.runtime.mutableStateListOf()
    var webActiveTabIdx: Int by androidx.compose.runtime.mutableStateOf(0)
        private set

    /**
     * Ensure the browser has at least one tab loaded with [initialUrl].
     * Idempotent — if the user is reopening the browser, the existing tabs are
     * preserved untouched.
     */
    fun ensureBrowserSession(initialUrl: String, initialLabel: String = "jw.org") {
        if (webTabs.isEmpty()) {
            webTabs.add(WebTab(System.currentTimeMillis(), initialUrl, initialLabel))
            webActiveTabIdx = 0
        }
    }

    // ── v4.12.0 — Pending web-open ──────────────────────────────────────────
    //
    // Before v4.12, tapping a row in Web History navigated to the browser
    // route, but [ensureBrowserSession] silently did nothing when tabs were
    // already open — so the requested URL was effectively ignored and the
    // user was returned to whatever tab they had last. The "history is not
    // clickable" bug the user reported.
    //
    // The fix decouples the URL from the navigation route: history (or any
    // other caller) writes the target into [pendingWebOpen], navigates to the
    // browser, and the browser consumes the pending request on first
    // composition. [openInBrowser] either switches to an existing tab that
    // already shows the URL or opens it in a new tab.

    private val _pendingWebOpen =
        MutableStateFlow<Pair<String, String>?>(null)
    /** A `(url, label)` pair set by callers (e.g. Web History) that want the browser to open a specific page. */
    val pendingWebOpen: StateFlow<Pair<String, String>?> = _pendingWebOpen

    /** Request that the browser open [url] with display [label] on its next composition. */
    fun requestWebOpen(url: String, label: String) {
        _pendingWebOpen.value = url to label
    }

    /**
     * Read and clear the pending web-open request, if any. Returns null when
     * nothing was pending. Called by [WebSearchScreen] in its
     * `LaunchedEffect(Unit)` to honour any history tap that triggered the
     * navigation.
     */
    fun consumePendingWebOpen(): Pair<String, String>? {
        val v = _pendingWebOpen.value
        if (v != null) _pendingWebOpen.value = null
        return v
    }

    /**
     * Open [url] in the browser. If a tab already shows it, switch to that
     * tab (preserves its back/forward stack and scroll position); otherwise
     * append a fresh tab. Either way the new active index is updated so the
     * UI rerenders to the right page.
     */
    fun openInBrowser(url: String, label: String) {
        val existingIdx = webTabs.indexOfFirst { it.url == url }
        if (existingIdx >= 0) {
            webActiveTabIdx = existingIdx
            return
        }
        webTabs.add(WebTab(System.currentTimeMillis(), url, label))
        webActiveTabIdx = webTabs.size - 1
    }

    fun setWebActiveTab(idx: Int) {
        if (idx in webTabs.indices) webActiveTabIdx = idx
    }

    fun addBrowserTab(url: String = "https://www.jw.org/en/", title: String = "New tab") {
        webTabs.add(WebTab(System.currentTimeMillis(), url, title))
        webActiveTabIdx = webTabs.size - 1
    }

    /** Returns true if the caller should also pop back (last tab was closed). */
    fun closeBrowserTab(idx: Int): Boolean {
        if (idx !in webTabs.indices) return false
        // v4.13.0 — also drop the persistent WebView for this tab, so memory
        // isn't held forever for tabs the user explicitly closes.
        val closedId = webTabs[idx].id
        destroyWebViewSession("tab_$closedId")
        if (webTabs.size == 1) { webTabs.clear(); webActiveTabIdx = 0; return true }
        webTabs.removeAt(idx)
        webActiveTabIdx = when {
            webActiveTabIdx >= webTabs.size -> webTabs.size - 1
            webActiveTabIdx > idx -> webActiveTabIdx - 1
            else -> webActiveTabIdx
        }
        return false
    }

    // ── v4.13.0 — Persistent WebView session pool ───────────────────────────
    //
    // Goal: scroll position, form inputs, and JavaScript state SURVIVE
    //   • popup ↔ full-screen-popup toggling
    //   • bottom-bar browser-icon taps after navigating away and back
    //   • Compose-level navigation in general
    //
    // Mechanism: WebView instances are owned by the VM (lifetime = VM lifetime),
    // looked up by a stable session ID. Composables call
    // [getOrCreateWebViewSession] in their AndroidView `factory` lambda,
    // detach from any prior parent with `(view.parent as? ViewGroup)?.removeView`,
    // and attach to the new ViewGroup. The next time the screen mounts, the
    // SAME WebView is returned and re-attached — its state is intact.
    //
    // Session IDs:
    //   - "popup"       — the link-popup browser (one WebView, shared between
    //                     WebPopupSheet and WebPopupFullScreen)
    //   - "tab_{tabId}" — each tabbed-browser tab in WebSearchScreen
    //
    // Context-leak note: WebView captures the Activity context. For this app
    // the VM is bound to MainActivity, and [onCleared] destroys every WebView
    // when the VM goes away. Configuration changes (rotation) can produce a
    // brief leak window in theory; not a real issue in practice for this app.

    private val webViewSessions =
        mutableMapOf<String, com.tebogo.markvault.ui.SelectionWebView>()

    /**
     * Look up an existing WebView for [sessionId], creating one if needed.
     * The returned WebView is bare — callers wire up `webViewClient`,
     * settings, and selection-menu callbacks themselves on every mount
     * because those references close over Composable state that goes stale
     * across recompositions.
     *
     * @param context Activity context (LocalContext.current from a Composable).
     */
    fun getOrCreateWebViewSession(
        sessionId: String,
        context: android.content.Context
    ): com.tebogo.markvault.ui.SelectionWebView {
        webViewSessions[sessionId]?.let { return it }
        val webView = com.tebogo.markvault.ui.SelectionWebView(context)
        webViewSessions[sessionId] = webView
        return webView
    }

    /**
     * Destroy a specific session's WebView. Use when the corresponding logical
     * thing (e.g. a browser tab) is closed by the user. Detaches from any
     * parent and frees native resources.
     */
    fun destroyWebViewSession(sessionId: String) {
        val w = webViewSessions.remove(sessionId) ?: return
        (w.parent as? android.view.ViewGroup)?.removeView(w)
        runCatching { w.destroy() }
    }

    /** Destroy every WebView in the pool. Called automatically on VM clear. */
    private fun destroyAllWebViewSessions() {
        for (w in webViewSessions.values) {
            (w.parent as? android.view.ViewGroup)?.removeView(w)
            runCatching { w.destroy() }
        }
        webViewSessions.clear()
    }

    /** Update tab URL/title after a page finishes loading. */
    fun updateBrowserTab(idx: Int, url: String? = null, title: String? = null) {
        if (idx !in webTabs.indices) return
        val cur = webTabs[idx]
        webTabs[idx] = cur.copy(
            url = url ?: cur.url,
            title = (title?.takeIf { it.isNotBlank() } ?: cur.title)
        )
    }

    /* ── TASK 5: pending search query channel ──
     * When the user taps "Search in MarkVault" in the browser's text-selection
     * menu, we push the selected text here and navigate to the Search screen,
     * which consumes the value on first composition and clears it.
     */
    private val _pendingSearch = MutableStateFlow<String?>(null)
    val pendingSearch: StateFlow<String?> = _pendingSearch.asStateFlow()
    fun requestPendingSearch(q: String) { _pendingSearch.value = q }
    fun consumePendingSearch(): String? {
        val q = _pendingSearch.value
        _pendingSearch.value = null
        return q
    }

    /* ── Web bookmarks (user-saved jw.org pages) ── */

    suspend fun isBookmarked(url: String): Boolean =
        runCatching { dao.isBookmarked(url) }.getOrElse { false }

    fun addBookmark(url: String, title: String) {
        if (url.isBlank()) return
        viewModelScope.launch(Dispatchers.IO) {
            runCatching {
                val host = runCatching { android.net.Uri.parse(url).host ?: "" }.getOrElse { "" }
                dao.insertBookmark(WebBookmark(url = url, title = title.ifBlank { url }, host = host))
            }
        }
    }

    fun removeBookmark(url: String) {
        viewModelScope.launch(Dispatchers.IO) { runCatching { dao.deleteBookmarkByUrl(url) } }
    }

    suspend fun loadBookmarks(): List<WebBookmark> =
        runCatching { dao.allBookmarks() }.getOrElse { emptyList() }

    fun deleteBookmarkEntry(id: Long) {
        viewModelScope.launch(Dispatchers.IO) { runCatching { dao.deleteBookmark(id) } }
    }

    /** First ~600 chars of the note body, used for the home-screen suggestion previews. */
    suspend fun previewOf(id: Long): String? =
        runCatching { dao.previewOf(id) }.getOrNull()

    fun saveScroll(id: Long, scroll: Int) {
        if (scroll < 0) return
        viewModelScope.launch(Dispatchers.IO) { runCatching { dao.setScroll(id, scroll) } }
    }

    /** Term to flash-highlight in the reader after opening a full-text search result (one-shot). */
    var pendingHighlight: String? = null
    fun consumePendingHighlight(): String? {
        val v = pendingHighlight
        pendingHighlight = null
        return v
    }

    /**
     * v4.7 — synchronous loadNote convenience for UI handlers that need it
     * outside a coroutine context. Returns null if not found. Safe to call
     * from the main thread because Room DAOs are designed for that on simple
     * queries with @WorkerThread enforcement turned off in this app.
     */
    fun openSync(id: Long): Note? {
        return runCatching {
            kotlinx.coroutines.runBlocking(Dispatchers.IO) { loadNote(id) }
        }.getOrNull()
    }

    /**
     * v4.7 — convert a note from one file type to another and save the result
     * into the library as a new file. Sourcetype detection: the caller passes
     * the source's known type; targetType is what they picked from the dialog.
     *
     * Supported pairs:
     *   md → html   :  full markdown-it render (via simple in-Kotlin pipeline)
     *   md → pdf    :  markdown → HTML → PDF (delegated to converter)
     *   html → md   :  HTML cleanup via simpleHtmlToMarkdown
     *   html → pdf  :  HTML → PDF
     *   pdf → md    :  PDF text extraction → markdown
     *   pdf → html  :  PDF text extraction → minimal HTML
     *
     * Currently the md→html, html→md, and pdf→md/html paths are wired and
     * functional via the existing converters. md→pdf and html→pdf are stubbed
     * with a friendly error so the UI flow is complete and the implementer can
     * fill them in without re-doing the dialog plumbing.
     */
    suspend fun convertNote(
        sourceId: Long, sourceType: String, targetType: String
    ): SaveResult = withContext(Dispatchers.IO) {
        val note = loadNote(sourceId)
            ?: return@withContext SaveResult.Error("Source note not found.")
        when (sourceType to targetType) {
            "md" to "html" -> {
                // Markdown → HTML: wrap content in minimal HTML, escape MD as
                // pre-rendered text. For a richer render the next iteration
                // can hook into the in-app markdown-it engine via a hidden WebView.
                val htmlBody = note.content
                    .replace("&", "&amp;")
                    .replace("<", "&lt;").replace(">", "&gt;")
                val wrapped = """
                    |<!DOCTYPE html>
                    |<meta charset="utf-8">
                    |<title>${note.title}</title>
                    |<pre style="white-space: pre-wrap; font: 14px/1.5 system-ui;">$htmlBody</pre>
                """.trimMargin()
                writeHtmlToLibrary(note.title, wrapped, note.uri)
            }
            "html" to "md", "mhtml" to "md" -> {
                val bytes = getApplication<Application>().contentResolver
                    .openInputStream(Uri.parse(note.uri))?.use { it.readBytes() }
                    ?: return@withContext SaveResult.Error("Could not read source file.")
                val htmlText = if (sourceType == "mhtml") {
                    com.tebogo.markvault.util.MhtmlParser.extractHtmlContent(bytes)
                        ?: return@withContext SaveResult.Error("MHTML parse failed.")
                } else {
                    String(bytes, Charsets.UTF_8)
                }
                val md = "# ${note.title}\n\n" + simpleHtmlToMarkdown(htmlText)
                saveImportedMarkdown(note.title, md, importsSubfolder.value)
            }
            "pdf" to "md" -> {
                // PDF → MD: use the cached page text we already extracted at
                // index time. Returns null when the source hasn't been viewed
                // yet (extraction is lazy on first open).
                val pages = cachedPdfPageText(sourceId)
                if (pages.isNullOrEmpty()) {
                    return@withContext SaveResult.Error(
                        "PDF text isn't extracted yet. Open the PDF once to cache it."
                    )
                }
                val md = buildString {
                    append("# ").append(note.title).append("\n\n")
                    pages.entries.sortedBy { it.key }.forEach { (idx, text) ->
                        append("## Page ").append(idx + 1).append("\n\n")
                        append(text.trim()).append("\n\n")
                    }
                }
                saveImportedMarkdown(note.title, md, importsSubfolder.value)
            }
            "pdf" to "html" -> {
                val pages = cachedPdfPageText(sourceId)
                if (pages.isNullOrEmpty()) {
                    return@withContext SaveResult.Error(
                        "PDF text isn't extracted yet. Open the PDF once to cache it."
                    )
                }
                val sb = StringBuilder()
                sb.append("<!DOCTYPE html><meta charset=\"utf-8\"><title>")
                    .append(note.title).append("</title><body>")
                pages.entries.sortedBy { it.key }.forEach { (idx, text) ->
                    sb.append("<h2>Page ").append(idx + 1).append("</h2><pre>")
                        .append(text.replace("<", "&lt;").replace(">", "&gt;"))
                        .append("</pre>")
                }
                sb.append("</body>")
                writeHtmlToLibrary(note.title, sb.toString(), note.uri)
            }
            else -> SaveResult.Error(
                "Conversion from $sourceType to $targetType isn't supported yet."
            )
        }.also { result ->
            if (result is SaveResult.Ok) {
                // Auto-reindex so the converted file is immediately searchable.
                reindex()
            }
        }
    }

    /** Write an HTML payload into the library as a `.html` file. */
    private suspend fun writeHtmlToLibrary(
        title: String, html: String, sourceUri: String
    ): SaveResult = withContext(Dispatchers.IO) {
        val libUri = libraryUri.value
            ?: return@withContext SaveResult.Error("No library set.")
        val treeUri = runCatching { Uri.parse(libUri) }.getOrNull()
            ?: return@withContext SaveResult.Error("Library URI invalid.")
        val cr = getApplication<Application>().contentResolver
        try {
            val subfolder = importsSubfolder.value
            val rootId = android.provider.DocumentsContract.getTreeDocumentId(treeUri)
            val rootDocUri = android.provider.DocumentsContract.buildDocumentUriUsingTree(
                treeUri, rootId
            )
            val parentUri = if (subfolder.isBlank()) rootDocUri else
                findOrCreateFolder(cr, treeUri, rootId, subfolder)
                    ?: return@withContext SaveResult.Error("Could not create subfolder.")
            val safeBase = sanitizeFilename(title).removeSuffix(".md")
            val fileName = ensureUniqueAnyExt(cr, treeUri, parentUri, safeBase, ".html")
            val newDoc = android.provider.DocumentsContract.createDocument(
                cr, parentUri, "text/html", fileName
            ) ?: return@withContext SaveResult.Error("Failed to create file.")
            cr.openOutputStream(newDoc, "w")?.use { out ->
                out.write(html.toByteArray(Charsets.UTF_8))
            } ?: return@withContext SaveResult.Error("Could not write file.")
            SaveResult.Ok(newDoc.toString(), fileName, subfolder)
        } catch (e: Exception) {
            SaveResult.Error("Write failed: ${e.message ?: e.javaClass.simpleName}")
        }
    }

    /**
     * Stash a WebView state bundle so popup → full-screen (or back) doesn't reload the page.
     * The receiving screen consumes this immediately; missing/expired = falls back to URL load.
     */
    var webStateBundle: android.os.Bundle? = null
    fun consumeWebState(): android.os.Bundle? {
        val v = webStateBundle
        webStateBundle = null
        return v
    }

    /**
     * Web popup font scaling — separate from reader font scaling, persisted in-memory only.
     * Values are textZoom percentages: 100 = default; min 70, max 200.
     */
    private val _webPopupTextZoom = MutableStateFlow(100)
    val webPopupTextZoom: StateFlow<Int> = _webPopupTextZoom
    fun setWebPopupTextZoom(v: Int) {
        _webPopupTextZoom.value = v.coerceIn(70, 200)
    }

    /** Dark-mode toggle for the in-app WebView popup (persisted in-memory only). */
    private val _webPopupDarkMode = MutableStateFlow(true)
    val webPopupDarkMode: StateFlow<Boolean> = _webPopupDarkMode
    fun setWebPopupDarkMode(v: Boolean) { _webPopupDarkMode.value = v }

    /**
     * Global request to open the in-app WebView popup. Any screen can call [requestWebPopup]
     * and the popup will overlay it (because MainActivity collects this and renders the sheet
     * outside the NavHost). [clearWebPopup] dismisses it.
     */
    private val _webPopupRequest = MutableStateFlow<String?>(null)
    val webPopupRequest: StateFlow<String?> = _webPopupRequest
    fun requestWebPopup(url: String) { _webPopupRequest.value = url }
    fun clearWebPopup() { _webPopupRequest.value = null }

    fun setFontScale(v: Float) { viewModelScope.launch { prefs.setFontScale(v) } }
    fun setTheme(name: String) { viewModelScope.launch { prefs.setTheme(name) } }
    fun setSmartStylingAllDocs(v: Boolean) { viewModelScope.launch { prefs.setSmartStylingAllDocs(v) } }
    fun setSwipeSwitchTabs(v: Boolean) { viewModelScope.launch { prefs.setSwipeSwitchTabs(v) } }
    fun setTextContrast(v: Float) { viewModelScope.launch { prefs.setTextContrast(v) } }

    val importsSubfolder: StateFlow<String> = prefs.importsSubfolder
        .stateIn(viewModelScope, SharingStarted.Eagerly, "")
    fun setImportsSubfolder(name: String) {
        viewModelScope.launch { prefs.setImportsSubfolder(name) }
    }

    // Web-import include toggles (front-matter / URL / excerpt / body).
    val includeFrontmatter: StateFlow<Boolean> = prefs.includeFrontmatter
        .stateIn(viewModelScope, SharingStarted.Eagerly, true)
    val includeUrl: StateFlow<Boolean> = prefs.includeUrl
        .stateIn(viewModelScope, SharingStarted.Eagerly, true)
    val includeExcerpt: StateFlow<Boolean> = prefs.includeExcerpt
        .stateIn(viewModelScope, SharingStarted.Eagerly, true)
    val includeBody: StateFlow<Boolean> = prefs.includeBody
        .stateIn(viewModelScope, SharingStarted.Eagerly, true)
    fun setIncludeFrontmatter(v: Boolean) { viewModelScope.launch { prefs.setIncludeFrontmatter(v) } }
    fun setIncludeUrl(v: Boolean)         { viewModelScope.launch { prefs.setIncludeUrl(v) } }
    fun setIncludeExcerpt(v: Boolean)     { viewModelScope.launch { prefs.setIncludeExcerpt(v) } }
    fun setIncludeBody(v: Boolean)        { viewModelScope.launch { prefs.setIncludeBody(v) } }

    /**
     * Save a markdown string into the library, inside the configured subfolder.
     * Creates the subfolder lazily if it doesn't exist yet.
     *
     * @param title      base filename (no extension); will be sanitized
     * @param markdown   file body (UTF-8)
     * @param subfolder  subfolder name; empty string = library root
     * @return SaveResult with the new file's display URI on success, or an error message
     */
    suspend fun saveImportedMarkdown(
        title: String, markdown: String, subfolder: String
    ): SaveResult = withContext(Dispatchers.IO) {
        val libUri = libraryUri.value
            ?: return@withContext SaveResult.Error("No library is set. Pick one in Settings first.")
        val treeUri = runCatching { Uri.parse(libUri) }.getOrNull()
            ?: return@withContext SaveResult.Error("Library URI is invalid. Re-pick the library folder.")
        val cr = getApplication<Application>().contentResolver
        // Verify we have write permission persisted; if not, surface a clear error.
        val hasWrite = cr.persistedUriPermissions.any {
            it.uri == treeUri && it.isWritePermission
        }
        if (!hasWrite) {
            return@withContext SaveResult.Error(
                "Library is read-only. Open Settings and tap \u201CRe-grant library access\u201D."
            )
        }
        try {
            val rootId = android.provider.DocumentsContract.getTreeDocumentId(treeUri)
            val rootDocUri = android.provider.DocumentsContract.buildDocumentUriUsingTree(treeUri, rootId)
            val parentUri = if (subfolder.isBlank()) rootDocUri else
                findOrCreateFolder(cr, treeUri, rootId, subfolder)
                    ?: return@withContext SaveResult.Error("Could not create subfolder \"$subfolder\".")

            val safeName = sanitizeFilename(title)
            val fileName = ensureUnique(cr, treeUri, parentUri, safeName)
            val newDoc = android.provider.DocumentsContract.createDocument(
                cr, parentUri, "text/markdown", fileName
            ) ?: return@withContext SaveResult.Error("Failed to create the file.")
            cr.openOutputStream(newDoc, "w")?.use {
                it.write(markdown.toByteArray(Charsets.UTF_8))
            } ?: return@withContext SaveResult.Error("Could not open the new file for writing.")
            // Trigger a quick library refresh so the new note appears
            val cur = libUri
            if (cur != null) viewModelScope.launch { /* lazy reindex hint */ refreshNotes() }
            SaveResult.Ok(newDoc.toString(), fileName, subfolder)
        } catch (e: SecurityException) {
            SaveResult.Error("Permission denied: ${e.message}")
        } catch (e: Exception) {
            SaveResult.Error("Save failed: ${e.message ?: e.javaClass.simpleName}")
        }
    }

    /** Walk the library root, find a folder by name, or create it. Returns the folder doc URI. */
    private fun findOrCreateFolder(
        cr: android.content.ContentResolver, treeUri: Uri, rootId: String, name: String
    ): Uri? {
        val children = android.provider.DocumentsContract.buildChildDocumentsUriUsingTree(treeUri, rootId)
        val proj = arrayOf(
            android.provider.DocumentsContract.Document.COLUMN_DOCUMENT_ID,
            android.provider.DocumentsContract.Document.COLUMN_DISPLAY_NAME,
            android.provider.DocumentsContract.Document.COLUMN_MIME_TYPE
        )
        cr.query(children, proj, null, null, null)?.use { cur ->
            while (cur.moveToNext()) {
                val n = cur.getString(1) ?: continue
                val m = cur.getString(2) ?: ""
                if (n.equals(name, ignoreCase = true) &&
                    m == android.provider.DocumentsContract.Document.MIME_TYPE_DIR) {
                    val did = cur.getString(0)
                    return android.provider.DocumentsContract.buildDocumentUriUsingTree(treeUri, did)
                }
            }
        }
        // Not found — create it
        val rootDocUri = android.provider.DocumentsContract.buildDocumentUriUsingTree(treeUri, rootId)
        return android.provider.DocumentsContract.createDocument(
            cr, rootDocUri, android.provider.DocumentsContract.Document.MIME_TYPE_DIR, name
        )
    }

    /**
     * TASK 2 (v4.4 rewrite): Save the current web page as a real `.html` file.
     *
     * The previous implementation used `WebView.saveWebArchive()`, which only
     * produces `.mhtml` regardless of file extension — the user reported this
     * as "doesn't save offline html, it saves in mhtml". This version takes the
     * page's rendered HTML (already pulled via `document.documentElement.outerHTML`
     * by the caller) and writes it as a self-describing `.html` document with
     * a `<base href>` so relative URLs still resolve to the original site when
     * online. Images/CSS aren't inlined — for fully self-contained archives use
     * MHTML, but the menu label said HTML so HTML is what we save.
     */
    suspend fun saveOfflineHtmlPage(
        sourceUrl: String, title: String, html: String
    ): SaveResult = withContext(Dispatchers.IO) {
        val libUri = libraryUri.value
            ?: return@withContext SaveResult.Error("No library is set. Pick one in Settings first.")
        val treeUri = runCatching { Uri.parse(libUri) }.getOrNull()
            ?: return@withContext SaveResult.Error("Library URI is invalid.")
        val cr = getApplication<Application>().contentResolver
        val hasWrite = cr.persistedUriPermissions.any {
            it.uri == treeUri && it.isWritePermission
        }
        if (!hasWrite) {
            return@withContext SaveResult.Error("Library is read-only. Re-grant access in Settings.")
        }
        try {
            val subfolder = importsSubfolder.value
            val rootId = android.provider.DocumentsContract.getTreeDocumentId(treeUri)
            val rootDocUri = android.provider.DocumentsContract.buildDocumentUriUsingTree(treeUri, rootId)
            val parentUri = if (subfolder.isBlank()) rootDocUri else
                findOrCreateFolder(cr, treeUri, rootId, subfolder)
                    ?: return@withContext SaveResult.Error("Could not create subfolder.")

            val safeBase = sanitizeFilename(title).removeSuffix(".md")
            val fileName = ensureUniqueAnyExt(cr, treeUri, parentUri, safeBase, ".html")

            // Wrap the page's outerHTML with a clean envelope. If the source
            // already declared `<!DOCTYPE html>` we keep ours anyway — duplicates
            // are harmless and the browser picks the first one.
            val wrappedHtml = buildHtmlEnvelope(sourceUrl, title, html)

            val newDoc = android.provider.DocumentsContract.createDocument(
                cr, parentUri, "text/html", fileName
            ) ?: return@withContext SaveResult.Error("Failed to create HTML file.")
            cr.openOutputStream(newDoc, "w")?.use { out ->
                out.write(wrappedHtml.toByteArray(Charsets.UTF_8))
            } ?: return@withContext SaveResult.Error("Could not write file.")
            SaveResult.Ok(newDoc.toString(), fileName, subfolder)
        } catch (e: Exception) {
            SaveResult.Error("Save failed: ${e.message ?: e.javaClass.simpleName}")
        }
    }

    /**
     * Wrap a page's outerHTML with a minimal envelope: DOCTYPE, UTF-8 meta,
     * title, `<base href>` so the page's relative links still resolve to the
     * original site, plus a comment header marking it as MarkVault-saved.
     *
     * If the input already looks like a full document we keep it intact but
     * inject the base href and meta charset if missing.
     */
    private fun buildHtmlEnvelope(sourceUrl: String, title: String, raw: String): String {
        val savedAt = java.text.SimpleDateFormat(
            "yyyy-MM-dd HH:mm", java.util.Locale.US
        ).format(java.util.Date())
        val escapedTitle = title.replace("&", "&amp;")
            .replace("<", "&lt;").replace(">", "&gt;").replace("\"", "&quot;")
        val escapedUrl = sourceUrl.replace("&", "&amp;").replace("\"", "&quot;")
        val preamble = """
            |<!DOCTYPE html>
            |<!-- Saved by MarkVault on $savedAt from $sourceUrl -->
            |<meta charset="utf-8">
            |<base href="$escapedUrl">
            |<title>$escapedTitle</title>
            |
            """.trimMargin()
        return preamble + raw
    }

    /**
     * Legacy MHTML archive save (kept for any future menu item that wants the
     * true offline-binary format). Not currently wired to a UI button — the
     * Save as Offline HTML button uses saveOfflineHtmlPage above.
     */
    suspend fun saveOfflineHtmlArchive(
        cacheFile: java.io.File, title: String
    ): SaveResult = withContext(Dispatchers.IO) {
        val libUri = libraryUri.value
            ?: return@withContext SaveResult.Error("No library is set. Pick one in Settings first.")
        val treeUri = runCatching { Uri.parse(libUri) }.getOrNull()
            ?: return@withContext SaveResult.Error("Library URI is invalid.")
        val cr = getApplication<Application>().contentResolver
        val hasWrite = cr.persistedUriPermissions.any {
            it.uri == treeUri && it.isWritePermission
        }
        if (!hasWrite) {
            return@withContext SaveResult.Error("Library is read-only. Re-grant access in Settings.")
        }
        try {
            val subfolder = importsSubfolder.value
            val rootId = android.provider.DocumentsContract.getTreeDocumentId(treeUri)
            val rootDocUri = android.provider.DocumentsContract.buildDocumentUriUsingTree(treeUri, rootId)
            val parentUri = if (subfolder.isBlank()) rootDocUri else
                findOrCreateFolder(cr, treeUri, rootId, subfolder)
                    ?: return@withContext SaveResult.Error("Could not create subfolder.")

            val safeBase = sanitizeFilename(title).removeSuffix(".md")
            val fileName = ensureUniqueAnyExt(cr, treeUri, parentUri, safeBase, ".mhtml")
            val newDoc = android.provider.DocumentsContract.createDocument(
                cr, parentUri, "application/x-mimearchive", fileName
            ) ?: return@withContext SaveResult.Error("Failed to create archive file.")
            cr.openOutputStream(newDoc, "w")?.use { out ->
                cacheFile.inputStream().use { it.copyTo(out) }
            } ?: return@withContext SaveResult.Error("Could not write archive.")
            runCatching { cacheFile.delete() }
            SaveResult.Ok(newDoc.toString(), fileName, subfolder)
        } catch (e: Exception) {
            SaveResult.Error("Archive save failed: ${e.message ?: e.javaClass.simpleName}")
        }
    }

    /**
     * TASK 3: Convert an HTML string into a lightweight Markdown body and save
     * it as a `.md` file in the library's imports subfolder. The converter is
     * deliberately minimal — it strips scripts/styles, converts headings,
     * paragraphs, lists, links, images, and inline formatting. Power users
     * who need a perfect conversion can still use the URL Import flow.
     */
    suspend fun saveConvertedMarkdown(
        sourceUrl: String, pageTitle: String, html: String
    ): SaveResult {
        val markdown = buildString {
            append("---\n")
            append("source: ").append(sourceUrl).append('\n')
            append("title: ").append(pageTitle.ifBlank { "Web page" }).append('\n')
            append("imported: ").append(java.text.SimpleDateFormat(
                "yyyy-MM-dd HH:mm", java.util.Locale.US
            ).format(java.util.Date())).append('\n')
            append("---\n\n")
            append("# ").append(pageTitle.ifBlank { "Web page" }).append("\n\n")
            append("> Source: <").append(sourceUrl).append(">\n\n")
            append(simpleHtmlToMarkdown(html))
        }
        return saveImportedMarkdown(
            title = pageTitle.ifBlank { "Web page" },
            markdown = markdown,
            subfolder = importsSubfolder.value
        )
    }

    /**
     * Quick-and-dirty HTML → Markdown converter. Handles the structural elements
     * (headings, paragraphs, lists, links, images, code, blockquotes, line
     * breaks) and discards scripts, styles, and ARIA noise. Good enough for
     * a "save this web page to my vault" feature; not a replacement for the
     * full URL-import pipeline which does real DOM parsing on the server side.
     */
    private fun simpleHtmlToMarkdown(html: String): String {
        if (html.isBlank()) return ""
        var s = html
        // Remove scripts/styles/noscript blocks
        s = s.replace(Regex("(?is)<script[^>]*>.*?</script>"), "")
        s = s.replace(Regex("(?is)<style[^>]*>.*?</style>"), "")
        s = s.replace(Regex("(?is)<noscript[^>]*>.*?</noscript>"), "")
        // Comments
        s = s.replace(Regex("(?s)<!--.*?-->"), "")
        // Images → ![alt](src)
        s = s.replace(Regex("(?is)<img[^>]*?alt=\"([^\"]*)\"[^>]*?src=\"([^\"]+)\"[^>]*>")) {
            "![${it.groupValues[1]}](${it.groupValues[2]})"
        }
        s = s.replace(Regex("(?is)<img[^>]*?src=\"([^\"]+)\"[^>]*>")) {
            "![](${it.groupValues[1]})"
        }
        // Links → [text](href)
        s = s.replace(Regex("(?is)<a[^>]*?href=\"([^\"]+)\"[^>]*>(.*?)</a>")) {
            val href = it.groupValues[1]
            val text = stripInline(it.groupValues[2]).trim()
            if (text.isBlank()) "<$href>" else "[$text]($href)"
        }
        // Headings
        for (n in 1..6) {
            val hashes = "#".repeat(n)
            s = s.replace(Regex("(?is)<h$n[^>]*>(.*?)</h$n>")) {
                "\n\n$hashes ${stripInline(it.groupValues[1]).trim()}\n\n"
            }
        }
        // Blockquote
        s = s.replace(Regex("(?is)<blockquote[^>]*>(.*?)</blockquote>")) {
            it.groupValues[1].lines().joinToString("\n") { line -> "> ${line.trim()}" }
        }
        // Lists
        s = s.replace(Regex("(?is)<li[^>]*>(.*?)</li>")) {
            "- ${stripInline(it.groupValues[1]).trim()}\n"
        }
        s = s.replace(Regex("(?is)</?ul[^>]*>|</?ol[^>]*>"), "\n")
        // Code blocks
        s = s.replace(Regex("(?is)<pre[^>]*><code[^>]*>(.*?)</code></pre>")) {
            "\n```\n${it.groupValues[1]}\n```\n"
        }
        s = s.replace(Regex("(?is)<code[^>]*>(.*?)</code>")) {
            "`${stripInline(it.groupValues[1])}`"
        }
        // Inline emphasis
        s = s.replace(Regex("(?is)<(?:b|strong)[^>]*>(.*?)</(?:b|strong)>")) { "**${it.groupValues[1]}**" }
        s = s.replace(Regex("(?is)<(?:i|em)[^>]*>(.*?)</(?:i|em)>")) { "*${it.groupValues[1]}*" }
        // Paragraphs + breaks
        s = s.replace(Regex("(?is)<p[^>]*>(.*?)</p>")) {
            "\n\n${stripInline(it.groupValues[1]).trim()}\n\n"
        }
        s = s.replace(Regex("(?is)<br[^>]*/?>"), "  \n")
        s = s.replace(Regex("(?is)<hr[^>]*/?>"), "\n\n---\n\n")
        // Strip any remaining tags
        s = s.replace(Regex("(?is)<[^>]+>"), "")
        // Decode common HTML entities
        s = s.replace("&nbsp;", " ")
            .replace("&amp;", "&")
            .replace("&lt;", "<")
            .replace("&gt;", ">")
            .replace("&quot;", "\"")
            .replace("&#39;", "'")
            .replace("&apos;", "'")
        // Collapse 3+ blank lines into 2
        s = s.replace(Regex("\n{3,}"), "\n\n")
        return s.trim()
    }

    private fun stripInline(html: String): String {
        return html.replace(Regex("(?is)<[^>]+>"), "")
            .replace("&nbsp;", " ")
            .replace(Regex("\\s+"), " ")
    }

    /** Like ensureUnique but for arbitrary file extension. */
    private fun ensureUniqueAnyExt(
        cr: android.content.ContentResolver,
        treeUri: Uri,
        parentUri: Uri,
        baseName: String,
        extWithDot: String
    ): String {
        var candidate = "$baseName$extWithDot"
        val parentId = android.provider.DocumentsContract.getDocumentId(parentUri)
        val children = android.provider.DocumentsContract.buildChildDocumentsUriUsingTree(treeUri, parentId)
        val existing = HashSet<String>()
        cr.query(
            children,
            arrayOf(android.provider.DocumentsContract.Document.COLUMN_DISPLAY_NAME),
            null, null, null
        )?.use { cur ->
            while (cur.moveToNext()) cur.getString(0)?.let { existing.add(it.lowercase()) }
        }
        var n = 2
        while (existing.contains(candidate.lowercase())) {
            candidate = "$baseName-$n$extWithDot"
            n++
        }
        return candidate
    }

    /** Avoid overwriting an existing file by adding a numeric suffix. */
    private fun ensureUnique(
        cr: android.content.ContentResolver, treeUri: Uri, parentUri: Uri, baseName: String
    ): String {
        val base = baseName.removeSuffix(".md")
        var candidate = "$base.md"
        val parentId = android.provider.DocumentsContract.getDocumentId(parentUri)
        val children = android.provider.DocumentsContract.buildChildDocumentsUriUsingTree(treeUri, parentId)
        val existing = HashSet<String>()
        cr.query(
            children,
            arrayOf(android.provider.DocumentsContract.Document.COLUMN_DISPLAY_NAME),
            null, null, null
        )?.use { cur ->
            while (cur.moveToNext()) cur.getString(0)?.let { existing.add(it.lowercase()) }
        }
        var n = 2
        while (existing.contains(candidate.lowercase())) {
            candidate = "$base ($n).md"
            n++
        }
        return candidate
    }

    private fun sanitizeFilename(title: String): String {
        val cleaned = title
            .replace(Regex("[\\\\/:*?\"<>|\\r\\n]+"), " ")
            .replace(Regex("\\s+"), " ")
            .trim()
        val capped = if (cleaned.length > 80) cleaned.take(80).trim() else cleaned
        return capped.ifBlank { "Web import" }
    }

    fun libraryName(): String {
        val uri = libraryUri.value ?: return "Library"
        val seg = Uri.decode(uri).substringAfterLast(':', "").substringAfterLast('/')
        return if (seg.isBlank()) "Library" else seg
    }

    companion object {
        /** Focus-graph rendering caps to keep the view readable on a phone. */
        const val MAX_FIRST_RING = 16
        const val MAX_SECOND_RING = 30

        /** Parse top-level markdown headings (outside fenced code) into an outline. */
        fun parseOutline(content: String): List<OutlineItem> {
            val out = ArrayList<OutlineItem>()
            var inFence = false
            var fence = ""
            var idx = 0
            for (raw in content.lineSequence()) {
                val line = raw.trimEnd()
                val t = line.trimStart()
                if (inFence) {
                    if (t.startsWith(fence)) inFence = false
                    continue
                }
                if (t.startsWith("```") || t.startsWith("~~~")) {
                    inFence = true; fence = t.take(3); continue
                }
                val m = Regex("^(#{1,6})\\s+(.*)$").find(line) ?: continue
                val level = m.groupValues[1].length
                val title = cleanHeading(m.groupValues[2])
                if (title.isNotBlank()) out.add(OutlineItem(level, title, idx))
                idx++
            }
            return out
        }

        private fun cleanHeading(s: String): String {
            var x = s
            x = Regex("\\[([^\\]]+)\\]\\([^)]*\\)").replace(x) { it.groupValues[1] } // links -> text
            x = x.replace(Regex("[*_`~]"), "")
            x = Regex("<[^>]+>").replace(x, "")
            return x.trim()
        }
    }

    // ── Semantic search orchestration (v4.8 foundation) ─────────────────────

    /**
     * Download the .tflite embedding model on user opt-in. Idempotent — calling
     * twice is safe. Updates [modelDownloadProgress] as a fraction in `[0, 1]`.
     * On success, [modelAvailable] flips to true.
     */
    fun downloadEmbeddingModel() {
        if (_modelDownloadProgress.value != null) return  // already running
        viewModelScope.launch(Dispatchers.IO) {
            _modelDownloadProgress.value = 0f
            val result = embedder.downloadModel { p ->
                _modelDownloadProgress.value = p
            }
            _modelDownloadProgress.value = null
            _modelAvailable.value = embedder.isModelAvailable()
            if (result.isFailure) {
                // No-op for the UI — the user can retry. The Settings screen
                // can detect the still-unavailable state via modelAvailable.
            }
        }
    }

    /**
     * Embed every note in the library that doesn't yet have a current embedding
     * for the active model. Reports progress via [embeddingProgress] as a
     * `(embedded, total)` pair. The pass is resumable: if interrupted, the
     * next call picks up exactly where it left off because we re-query the
     * targets at the start.
     *
     * v4.8.1 — three changes to fix the "tapped Build embeddings but nothing
     * happens" stall on large libraries:
     *
     *   1. **Immediate UI feedback.** We set [embeddingProgress] to a
     *      "preparing" sentinel (0, 0) BEFORE running any database queries, so
     *      the status line flips to "⏳ Preparing…" the moment the user taps.
     *      Previously the user saw no change for the entire duration of the
     *      first DAO query.
     *
     *   2. **Lightweight projection.** We use `targetsNeedingEmbedding` which
     *      returns only `(id, lastModified)` pairs instead of full Note rows.
     *      For a 14k-note library that's a few hundred KB instead of 100+ MB
     *      of allocations. Note content is fetched one row at a time via
     *      `dao.byId(id)` inside the embed loop.
     *
     *   3. **Frequent progress updates.** Updates every embedding instead of
     *      every 5 — the throttling was making the UI look frozen on slower
     *      phones where each embedding takes ~1-2 seconds.
     *
     * Throttled internally — no need for the caller to debounce. Calling twice
     * concurrently is a no-op (the second call returns immediately).
     */
    fun buildAllEmbeddings() {
        if (_embeddingProgress.value != null) return
        if (!embedder.isModelAvailable()) return
        // Flip the UI to a "preparing" state IMMEDIATELY. Even if the COUNT
        // query takes several seconds on a huge library, the user sees that
        // something is happening within a single frame.
        _embeddingProgress.value = 0 to 0
        viewModelScope.launch(Dispatchers.IO) {
            // Pre-flight: cheap COUNT query so we know the denominator upfront.
            val total = runCatching {
                dao.countNotesNeedingEmbedding(embedder.modelVersion)
            }.getOrElse { 0 }
            if (total == 0) {
                _embeddingProgress.value = null
                return@launch
            }
            // Promote the UI from "Preparing…" to actual progress immediately.
            _embeddingProgress.value = 0 to total

            // Now fetch the lightweight target list — just (id, lastModified)
            // for every note that needs embedding. For 14k notes this is a
            // few hundred KB of allocations, not the hundreds of MB the old
            // path used.
            val targets = runCatching {
                dao.targetsNeedingEmbedding(embedder.modelVersion)
            }.getOrElse { emptyList() }

            var done = 0
            for (target in targets) {
                // Fetch ONE note's full row at a time. Content is loaded
                // here and discarded after embedding — memory stays bounded.
                val note = runCatching { dao.byId(target.id) }.getOrNull()
                    ?: continue
                val text = buildString {
                    append(note.title).append("\n\n").append(note.content)
                }
                val vec = embedder.embed(text)
                if (vec != null) {
                    runCatching {
                        dao.upsertEmbedding(
                            com.tebogo.markvault.data.NoteEmbedding(
                                noteId = note.id,
                                modelVersion = embedder.modelVersion,
                                dim = vec.size,
                                vector = com.tebogo.markvault.search.floatArrayToBytes(vec),
                                sourceLastModified = note.lastModified,
                                createdAt = System.currentTimeMillis()
                            )
                        )
                    }
                }
                done++
                // Update on every embedding — the StateFlow is conflated by
                // collectors anyway, so we won't actually hammer the UI on a
                // slow phone, but on a fast phone the user sees smooth motion.
                _embeddingProgress.value = done to total
            }
            _embeddingProgress.value = null
            _embeddingCount.value = runCatching {
                dao.embeddingCount(embedder.modelVersion)
            }.getOrElse { 0 }
            // v4.8.2 — drop the cached vector index so the next semantic
            // search reloads from the DB. Important when the pass added new
            // rows or refreshed stale ones.
            invalidateSemanticIndex()
        }
    }

    /** Wipe every embedding row. Useful when switching models or freeing space. */
    fun clearAllEmbeddings() {
        viewModelScope.launch(Dispatchers.IO) {
            runCatching { dao.clearAllEmbeddings() }
            _embeddingCount.value = 0
            invalidateSemanticIndex()
        }
    }

    // ── v4.9.0 — Semantic search toggles & model management ─────────────────

    /** Flip the master semantic-search switch. Effect is immediate on next query. */
    fun setSemanticEnabled(enabled: Boolean) {
        viewModelScope.launch { prefs.setSemanticEnabled(enabled) }
    }

    /** Whether to automatically check for newer models when the app launches. */
    fun setAutoCheckModelUpdates(enabled: Boolean) {
        viewModelScope.launch { prefs.setAutoCheckModelUpdates(enabled) }
    }

    /**
     * Switch to a different model in the catalog. The init-block listener
     * picks up the preference change, closes the current embedder, builds a
     * fresh one for the new descriptor, and refreshes the model-availability
     * + embedding-count state flows. The user will likely need to:
     *
     *   1. Download the new model (its file isn't on disk yet)
     *   2. Build embeddings (the DB rows are keyed by model id, so the new
     *      model has zero embeddings to start)
     *
     * Both are surfaced via the existing UI in Settings.
     *
     * v4.9.1 — also rejects models marked `enabled = false`, which is how the
     * catalog surfaces "coming soon" entries (e.g. MiniLM before its ONNX
     * backend lands). The UI greys those rows out, but this guard is the
     * authoritative check.
     */
    fun setActiveModelId(id: String) {
        val target = com.tebogo.markvault.search.ModelCatalog.byId(id) ?: return
        if (!target.enabled) return
        viewModelScope.launch { prefs.setActiveModelId(id) }
    }

    /**
     * v4.9.1 — Single-step install: download the active model's file, then
     * automatically start the embedding pass once the download finishes.
     * Combines the two previously-separate buttons into one user action.
     *
     * No-op when the model is already downloaded AND embeddings exist for it
     * (i.e. nothing to install). When the model is downloaded but no
     * embeddings exist yet, this method skips the download and runs only the
     * embedding pass — the same behaviour the standalone "Build embeddings"
     * button would have provided.
     *
     * Safe to call while another install is in progress: the download path
     * is idempotent (returns immediately if the file is already valid) and
     * the embed path guards against re-entry via `_embeddingProgress`.
     */
    fun installModel() {
        viewModelScope.launch(Dispatchers.IO) {
            // Phase 1: download (no-op if already present).
            if (!embedder.isModelAvailable()) {
                val result = embedder.downloadModel { p ->
                    _modelDownloadProgress.value = p
                }
                _modelDownloadProgress.value = null
                _modelAvailable.value = embedder.isModelAvailable()
                if (result.isFailure || !embedder.isModelAvailable()) return@launch
            }
            // Phase 2: embed any notes that need it. buildAllEmbeddings
            // launches its own coroutine on viewModelScope; calling it here
            // is fine — it has its own re-entry guard.
            buildAllEmbeddings()
        }
    }

    /**
     * Check whether the in-app catalog lists any model the user could switch
     * to. Honest scope: this is a LOCAL check against the bundled catalog —
     * there's no remote manifest endpoint yet. Future iterations may merge in
     * results from a remote JSON manifest; for now, new models arrive via
     * app updates and this method surfaces them once installed.
     *
     * The result is written to [modelUpdateStatus] so the UI can render it
     * below the button without any string-passing coupling.
     */
    fun checkForModelUpdates() {
        viewModelScope.launch {
            _modelUpdateStatus.value = "\u23F3 Checking\u2026"
            kotlinx.coroutines.delay(400)  // tiny pause so the user sees feedback
            val activeId = embedder.descriptor.id
            val otherModels = com.tebogo.markvault.search.ModelCatalog.all
                .filter { it.id != activeId }
            _modelUpdateStatus.value = if (otherModels.isEmpty()) {
                "\u2705 Up to date. \"${embedder.descriptor.displayName}\" is the latest available model."
            } else {
                val names = otherModels.joinToString { it.displayName }
                "\uD83D\uDCE6 Other model(s) available: $names"
            }
        }
    }

    override fun onCleared() {
        super.onCleared()
        runCatching { embedder.close() }
        // v4.13.0 — release every persistent WebView so we don't hold native
        // resources after the VM is gone.
        destroyAllWebViewSessions()
    }
}

/** Direction of a wikilink relative to the focused note. */
enum class LinkDir { OUTGOING, INCOMING, BOTH }

/** A 1°-ring neighbour: a directly linked note + which way the link goes. */
data class GraphNeighbour(val note: com.tebogo.markvault.data.LinkedNote, val dir: LinkDir)

/** A 2°-ring node: linked via [viaNoteId] which is one of the 1°-ring nodes. */
data class GraphEdge(val note: com.tebogo.markvault.data.LinkedNote, val viaNoteId: Long)

/** Result of expanding a focus note out to two degrees of connection. */
data class FocusGraph(
    val center: com.tebogo.markvault.data.LinkedNote,
    val firstRing: List<GraphNeighbour>,
    val secondRing: List<GraphEdge>,
    /** How many 1°-ring neighbours we found in total — UI can show "+N more" if greater than [firstRing.size]. */
    val firstRingTotal: Int,
    val secondRingTotal: Int
)

/** One persisted recent-search click: the query the user typed, and the note they ended up opening. */
data class RecentSearch(
    val query: String,
    val noteId: Long,
    val title: String,
    val relPath: String,
    val ts: Long
)

/**
 * Tab-separated, line-per-entry, with `\u0001` as field separator (any char that's vanishingly
 * unlikely in titles). Lightweight enough that we don't need a JSON library.
 */
private const val FIELD_SEP = "\u0001"

internal fun encodeRecents(list: List<RecentSearch>): String =
    list.joinToString("\n") { r ->
        // Defensively scrub any stray separator chars from user-controlled fields
        listOf(
            r.query.replace("\n", " ").replace(FIELD_SEP, " "),
            r.noteId.toString(),
            r.title.replace("\n", " ").replace(FIELD_SEP, " "),
            r.relPath.replace("\n", " ").replace(FIELD_SEP, " "),
            r.ts.toString()
        ).joinToString(FIELD_SEP)
    }

internal fun decodeRecents(raw: String): List<RecentSearch> {
    if (raw.isBlank()) return emptyList()
    return raw.split("\n").mapNotNull { line ->
        val parts = line.split(FIELD_SEP)
        if (parts.size < 5) return@mapNotNull null
        val id = parts[1].toLongOrNull() ?: return@mapNotNull null
        val ts = parts[4].toLongOrNull() ?: return@mapNotNull null
        RecentSearch(query = parts[0], noteId = id, title = parts[2], relPath = parts[3], ts = ts)
    }
}
