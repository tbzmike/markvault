#pragma once
#include "hnsw_core.hpp"
#include "vendor/sqlite/sqlite3.h"
#include <memory>
#include <unordered_map>
#include <cstring>
#include <string>

namespace markvault {
struct StoredScore { std::int64_t id; int chunk; float score; };

/** A short-lived read-only WAL snapshot. No vector BLOB crosses JNI or the Java heap. */
inline std::vector<StoredScore> score_stored_vectors(char const* path, char const* model,
        float const* query, std::size_t dim, std::vector<std::int64_t> const& ids) {
    if (!path || !*path || !model || dim < 1 || dim > 2048 || ids.size() > 900)
        throw std::invalid_argument("Invalid stored-vector request");
    for (std::size_t i=0;i<dim;++i) if (!std::isfinite(query[i])) throw std::invalid_argument("Non-finite query");
    if (ids.empty()) return {};
    sqlite3* raw = nullptr;
    int opened = sqlite3_open_v2(path, &raw, SQLITE_OPEN_READONLY | SQLITE_OPEN_NOMUTEX, nullptr);
    std::unique_ptr<sqlite3, decltype(&sqlite3_close)> db(raw, sqlite3_close);
    if (opened != SQLITE_OK) throw std::runtime_error("Read-only vector database unavailable");
    sqlite3_busy_timeout(db.get(), 100);
    std::string sql = "SELECT noteId, chunkIndex, vector FROM note_embeddings WHERE modelVersion = ? AND noteId IN (";
    for (std::size_t i=0;i<ids.size();++i) { if (i) sql += ','; sql += '?'; }
    sql += ')';
    sqlite3_stmt* statement = nullptr;
    if (sqlite3_prepare_v2(db.get(), sql.c_str(), -1, &statement, nullptr) != SQLITE_OK)
        throw std::runtime_error("Stored-vector query unavailable");
    std::unique_ptr<sqlite3_stmt, decltype(&sqlite3_finalize)> stmt(statement, sqlite3_finalize);
    if (sqlite3_bind_text(stmt.get(), 1, model, -1, SQLITE_TRANSIENT) != SQLITE_OK)
        throw std::runtime_error("Unable to bind model");
    for (std::size_t i=0;i<ids.size();++i)
        if (sqlite3_bind_int64(stmt.get(), static_cast<int>(i)+2, ids[i]) != SQLITE_OK)
            throw std::runtime_error("Unable to bind candidate");
    std::vector<StoredScore> scores;
    std::unordered_map<std::int64_t,std::size_t> positions;
    std::array<float,2048> vector{};
    int status;
    while ((status=sqlite3_step(stmt.get())) == SQLITE_ROW) {
        if (sqlite3_column_bytes(stmt.get(), 2) != static_cast<int>(dim*sizeof(float))) continue;
        auto blob=sqlite3_column_blob(stmt.get(),2);
        if (!blob) continue;
        // BLOB storage need not be aligned for NEON. Copy once into a fixed native buffer.
        std::memcpy(vector.data(),blob,dim*sizeof(float));
        float score=std::clamp(exact_dot(query,vector.data(),dim),-1.f,1.f);
        auto id=sqlite3_column_int64(stmt.get(),0);
        int chunk=sqlite3_column_int(stmt.get(),1);
        auto found=positions.find(id);
        if (found==positions.end()) { positions.emplace(id,scores.size()); scores.push_back({id,chunk,score}); }
        else if (score>scores[found->second].score) scores[found->second]={id,chunk,score};
    }
    if (status != SQLITE_DONE) throw std::runtime_error("Stored-vector read interrupted");
    return scores;
}
}
