#pragma once

// Included inside markvault. This immutable overlay reuses the persisted
// passage edges and SQ8 rows; it neither replaces embeddings nor saves a new
// index format. A live vertex represents all chunks of one article. Deleted
// passage vertices remain available for routing but never become candidates.
class ArticleGraph {
    struct Node { std::uint64_t article; std::uint32_t first, end, level; bool live; };
    using Candidate = std::pair<float, std::uint32_t>;
    struct MinDistance { bool operator()(Candidate const& a, Candidate const& b) const { return a > b; } };
    std::vector<Node> nodes_;
    std::vector<std::uint32_t> rows_, offsets_, edges_, visits_, expanded_;
    std::vector<float> distances_;
    std::vector<Candidate> frontier_, best_, observed_;
    std::uint32_t epoch_ = 0, entry_ = 0;
    std::size_t levels_ = 0;
    std::size_t dim_ = 0;
    sq8::Scalar const* matrix_ = nullptr;
    float const* inverses_ = nullptr;

    float measure(std::uint32_t node, sq8::Scalar const* query, float inverse, std::size_t& scored) const {
        auto const& member = nodes_[node];
        float best = 2.f;
        std::uint32_t row = member.first;
        for (; member.end - row >= 4; row += 4) {
            sq8::Scalar const* vectors[4]; float norms[4], dots[4], values[4]; std::int32_t integers[4];
            for (int i=0; i<4; ++i) {
                auto slot = rows_[row+i]; vectors[i] = matrix_ + std::size_t(slot)*dim_; norms[i] = inverses_[slot];
            }
            sq8::dot4(query, vectors, dim_, integers);
            for (int i=0; i<4; ++i) dots[i] = float(integers[i]);
            sq8::finish_inverse4(inverse, norms, dots, values);
            for (auto value : values) best = std::min(best, value);
        }
        for (; row < member.end; ++row) {
            auto slot = rows_[row]; auto norm = inverses_[slot];
            float value = !inverse || !norm ? (inverse == norm ? 0.f : 1.f)
                : std::clamp(1.f - (float(sq8::dot(query, matrix_ + std::size_t(slot)*dim_, dim_))*inverse)*norm, 0.f, 2.f);
            best = std::min(best, value);
        }
        scored += member.end - member.first;
        return best;
    }
    std::pair<std::uint32_t, std::uint32_t> neighbors(std::uint32_t node, std::size_t level) const {
        auto at = std::size_t(node)*levels_ + level;
        return {offsets_[at], offsets_[at+1]};
    }

public:
    explicit ArticleGraph(us::index_dense_t const& index, VectorNorms const& norms) {
        dim_ = index.dimensions(); matrix_ = reinterpret_cast<sq8::Scalar const*>(norms.base);
        inverses_ = norms.values.data();
        auto first = index.cbegin(); auto count = std::size_t(get_slot(index.cend()));
        if (!count || count > UINT32_MAX || norms.values.size() != count || !norms.inverse || !matrix_)
            throw std::invalid_argument("Invalid article graph matrix");
        std::vector<std::pair<std::uint64_t, std::uint32_t>> ordered;
        std::vector<std::uint32_t> deleted, groups(count);
        ordered.reserve(count);
        for (auto it=first; it!=index.cend(); ++it) {
            auto slot = std::uint32_t(get_slot(it)); auto key = std::uint64_t((*it).key);
            if (key == index.free_key()) deleted.push_back(slot);
            else ordered.emplace_back(key, slot);
        }
        std::sort(ordered.begin(), ordered.end()); rows_.reserve(count);
        auto append = [&](std::uint64_t article, bool live, std::uint32_t slot) {
            if (nodes_.empty() || !live || !nodes_.back().live || nodes_.back().article != article)
                nodes_.push_back({article, std::uint32_t(rows_.size()), std::uint32_t(rows_.size()), 0, live});
            auto& node = nodes_.back();
            auto member = first + slot;
            node.level = std::max(node.level, std::uint32_t(index.level_at(member)));
            groups[slot] = std::uint32_t(nodes_.size()-1); rows_.push_back(slot); ++node.end;
        };
        for (auto item : ordered) append(item.first >> 32, true, item.second);
        for (auto slot : deleted) append(0, false, slot);
        auto max_level = std::size_t(0);
        for (std::uint32_t n=0; n<nodes_.size(); ++n)
            if (nodes_[n].level >= max_level) { max_level=nodes_[n].level; entry_=n; }
        levels_ = max_level+1;
        if (nodes_.size() > (std::size_t(UINT32_MAX)-1)/levels_) throw std::overflow_error("Article graph is too large");
        offsets_.reserve(nodes_.size()*levels_+1); offsets_.push_back(0);
        std::vector<std::uint32_t> neighbors;
        for (std::uint32_t n=0; n<nodes_.size(); ++n) {
            auto const& node = nodes_[n];
            for (std::size_t level=0; level<levels_; ++level) {
                neighbors.clear();
                if (level <= node.level)
                    for (auto row=node.first; row<node.end; ++row)
                        for (auto member : index.neighbors_at(first + rows_[row], level)) {
                            auto slot = std::size_t(member.slot);
                            if (slot >= groups.size()) throw std::runtime_error("Invalid article graph edge");
                            auto group = groups[slot]; if (group != n) neighbors.push_back(group);
                        }
                std::sort(neighbors.begin(), neighbors.end());
                neighbors.erase(std::unique(neighbors.begin(), neighbors.end()), neighbors.end());
                if (neighbors.size() > UINT32_MAX-edges_.size()) throw std::overflow_error("Article graph has too many edges");
                edges_.insert(edges_.end(), neighbors.begin(), neighbors.end()); offsets_.push_back(std::uint32_t(edges_.size()));
            }
        }
        visits_.resize(nodes_.size()); expanded_.resize(nodes_.size()); distances_.resize(nodes_.size());
        frontier_.reserve(nodes_.size()); best_.reserve(nodes_.size()); observed_.reserve(nodes_.size());
    }
    std::size_t memory_usage() const {
        return nodes_.capacity()*sizeof(Node) + rows_.capacity()*sizeof(std::uint32_t)
            + (offsets_.capacity()+edges_.capacity()+visits_.capacity()+expanded_.capacity())*sizeof(std::uint32_t)
            + distances_.capacity()*sizeof(float) + (frontier_.capacity()+best_.capacity()+observed_.capacity())*sizeof(Candidate);
    }
    template <typename Accept> std::size_t search(sq8::Scalar const* query, float inverse, ArticleScope const& scope,
            std::size_t beam, Accept&& accept, std::size_t& scored) {
        if (++epoch_ == 0) {
            std::fill(visits_.begin(), visits_.end(), 0); std::fill(expanded_.begin(), expanded_.end(), 0); epoch_=1;
        }
        frontier_.clear(); best_.clear(); observed_.clear();
        auto distance = [&](std::uint32_t n) {
            if (visits_[n] != epoch_) {
                visits_[n]=epoch_; distances_[n]=measure(n, query, inverse, scored);
                if (nodes_[n].live && scope.contains(nodes_[n].article)) observed_.emplace_back(distances_[n], n);
            }
            return distances_[n];
        };
        auto start = entry_; auto closest = distance(start);
        for (std::size_t level=levels_-1; level>0; --level) {
            bool improved = true;
            while (improved) {
                improved=false; auto range=neighbors(start,level);
                for (auto edge=range.first; edge<range.second; ++edge) {
                    auto n=edges_[edge]; auto d=distance(n);
                    if (d < closest) { start=n; closest=d; improved=true; }
                }
            }
        }
        auto push = [&](std::uint32_t n, float d) {
            frontier_.emplace_back(d,n); std::push_heap(frontier_.begin(),frontier_.end(),MinDistance{});
            if (nodes_[n].live && scope.contains(nodes_[n].article)) {
                best_.emplace_back(d,n); std::push_heap(best_.begin(),best_.end());
                if (best_.size()>beam) { std::pop_heap(best_.begin(),best_.end()); best_.pop_back(); }
            }
        };
        // Upper-level measurements remain candidates, but must still be
        // expanded at level zero when rediscovered from a base neighbor.
        expanded_[start]=epoch_; push(start, closest);
        while (!frontier_.empty()) {
            auto candidate=frontier_.front();
            if (best_.size() == beam && candidate.first > best_.front().first) break;
            std::pop_heap(frontier_.begin(),frontier_.end(),MinDistance{}); frontier_.pop_back();
            auto range=neighbors(candidate.second,0);
            for (auto edge=range.first; edge<range.second; ++edge) {
                auto n=edges_[edge]; if (expanded_[n] == epoch_) continue;
                expanded_[n]=epoch_;
                auto d=distance(n);
                if (best_.size()<beam || d<best_.front().first) push(n,d);
            }
        }
        for (auto item : observed_) accept(nodes_[item.second].article, item.first);
        return observed_.size();
    }
};
