#include "hnsw_core.hpp"
#include <jni.h>
#include <cstring>
#include <limits>
#include "stored_vectors.hpp"

namespace {
void fail(JNIEnv* env, char const* message) {
    if (!env->ExceptionCheck()) env->ThrowNew(env->FindClass("java/lang/IllegalStateException"), message);
}
markvault::Hnsw& index(jlong handle) {
    if (!handle) throw std::invalid_argument("Closed HNSW index");
    return *reinterpret_cast<markvault::Hnsw*>(handle);
}
struct Utf {
    JNIEnv* env; jstring text; char const* bytes;
    Utf(JNIEnv* e, jstring s) : env(e), text(s), bytes(e->GetStringUTFChars(s, nullptr)) {
        if (!bytes) throw std::bad_alloc();
    }
    ~Utf() { env->ReleaseStringUTFChars(text, bytes); }
};
jlongArray javaKeys(JNIEnv* env, std::vector<std::uint64_t> const& keys) {
    std::vector<jlong> converted(keys.begin(), keys.end());
    auto result = env->NewLongArray(converted.size());
    if (result) env->SetLongArrayRegion(result, 0, converted.size(), converted.data());
    return result;
}
}

#define JNI_METHOD(name) Java_com_tebogo_markvault_search_NativeHnswBridge_##name
#define HANDLE_ERRORS catch (std::exception const& e) { fail(env, e.what()); } catch (...) { fail(env, "Native HNSW failure"); }

extern "C" JNIEXPORT jlongArray JNICALL JNI_METHOD(scoreStoredVectors)(JNIEnv* env, jobject,
        jstring path, jstring model, jfloatArray queryArray, jlongArray idsArray) {
    try {
        Utf database(env,path), version(env,model);
        std::vector<float> query(env->GetArrayLength(queryArray));
        env->GetFloatArrayRegion(queryArray,0,query.size(),query.data());
        std::vector<jlong> input(env->GetArrayLength(idsArray));
        env->GetLongArrayRegion(idsArray,0,input.size(),input.data());
        if (env->ExceptionCheck()) return nullptr;
        std::vector<std::int64_t> ids(input.begin(),input.end());
        auto scores=markvault::score_stored_vectors(database.bytes,version.bytes,query.data(),query.size(),ids);
        std::vector<jlong> packet{1};
        for (auto const& score:scores) {
            std::uint32_t bits; std::memcpy(&bits,&score.score,sizeof(bits));
            packet.insert(packet.end(),{score.id,score.chunk,static_cast<jlong>(bits)});
        }
        auto result=env->NewLongArray(packet.size());
        if (result) env->SetLongArrayRegion(result,0,packet.size(),packet.data());
        return result;
    } HANDLE_ERRORS
    return nullptr;
}

extern "C" JNIEXPORT jlong JNICALL JNI_METHOD(create)(JNIEnv* env, jobject, jint dim, jint capacity, jboolean mutableIndex) {
    try {
        if (capacity < 0) throw std::invalid_argument("Negative capacity");
        return reinterpret_cast<jlong>(new markvault::Hnsw(dim, capacity, mutableIndex));
    } HANDLE_ERRORS
    return 0;
}
extern "C" JNIEXPORT void JNICALL JNI_METHOD(close)(JNIEnv*, jobject, jlong handle) {
    delete reinterpret_cast<markvault::Hnsw*>(handle);
}
extern "C" JNIEXPORT void JNICALL JNI_METHOD(open)(JNIEnv* env, jobject, jlong handle, jstring path, jlong offset, jboolean mutableIndex) {
    try { Utf p(env, path); if (offset < 0) throw std::invalid_argument("Negative offset"); index(handle).open(p.bytes, offset, mutableIndex); } HANDLE_ERRORS
}
extern "C" JNIEXPORT void JNICALL JNI_METHOD(reserve)(JNIEnv* env, jobject, jlong handle, jint capacity) {
    try { if (capacity < 0) throw std::invalid_argument("Negative capacity"); index(handle).reserve(capacity); } HANDLE_ERRORS
}
extern "C" JNIEXPORT void JNICALL JNI_METHOD(add)(JNIEnv* env, jobject, jlong handle, jlong key, jbyteArray blob) {
    try {
        auto& h = index(handle);
        jsize bytes = env->GetArrayLength(blob);
        if (bytes != static_cast<jsize>(h.dimensions() * sizeof(float))) throw std::invalid_argument("Invalid embedding BLOB length");
        // Android ABIs are little endian, matching the persisted embedding format.
        std::vector<float> vector(h.dimensions());
        env->GetByteArrayRegion(blob, 0, bytes, reinterpret_cast<jbyte*>(vector.data()));
        if (env->ExceptionCheck()) return;
        h.add(static_cast<std::uint64_t>(key), vector.data(), vector.size());
    } HANDLE_ERRORS
}
extern "C" JNIEXPORT void JNICALL JNI_METHOD(remove)(JNIEnv* env, jobject, jlong handle, jlong key) {
    try { index(handle).remove(static_cast<std::uint64_t>(key)); } HANDLE_ERRORS
}
extern "C" JNIEXPORT jlong JNICALL JNI_METHOD(size)(JNIEnv* env, jobject, jlong handle) {
    try { return index(handle).size(); } HANDLE_ERRORS
    return 0;
}
extern "C" JNIEXPORT jlong JNICALL JNI_METHOD(serializedLength)(JNIEnv* env, jobject, jlong handle) {
    try { return index(handle).serialized_length(); } HANDLE_ERRORS
    return 0;
}
extern "C" JNIEXPORT void JNICALL JNI_METHOD(append)(JNIEnv* env, jobject, jlong handle, jstring path) {
    try { Utf p(env, path); index(handle).append(p.bytes); } HANDLE_ERRORS
}
extern "C" JNIEXPORT jlongArray JNICALL JNI_METHOD(keys)(JNIEnv* env, jobject, jlong handle) {
    try {
        auto keys = index(handle).keys();
        return javaKeys(env, keys);
    } HANDLE_ERRORS
    return nullptr;
}
extern "C" JNIEXPORT jlongArray JNICALL JNI_METHOD(search)(JNIEnv* env, jobject, jlong handle, jfloatArray vector, jint wanted, jlongArray allowedIds) {
    try {
        if (wanted < 1 || wanted > 10000) throw std::invalid_argument("Invalid candidate limit");
        std::vector<float> query(env->GetArrayLength(vector));
        env->GetFloatArrayRegion(vector, 0, query.size(), query.data());
        std::vector<std::uint64_t> allowed;
        if (allowedIds) {
            std::vector<jlong> converted(env->GetArrayLength(allowedIds));
            env->GetLongArrayRegion(allowedIds, 0, converted.size(), converted.data());
            allowed.assign(converted.begin(), converted.end());
            std::sort(allowed.begin(), allowed.end());
        }
        if (env->ExceptionCheck()) return nullptr;
        auto keys = index(handle).search(query.data(), query.size(), wanted, allowedIds ? &allowed : nullptr);
        return javaKeys(env, keys);
    } HANDLE_ERRORS
    return nullptr;
}

extern "C" JNIEXPORT jlongArray JNICALL JNI_METHOD(findArticles)(JNIEnv* env, jobject, jlong handle,
        jfloatArray vector, jint wanted, jint minimum, jlongArray allowedIds) {
    try {
        if (wanted < 1 || wanted > 1200 || minimum < 0 || minimum > wanted)
            throw std::invalid_argument("Invalid article candidate limit");
        std::vector<float> query(env->GetArrayLength(vector));
        env->GetFloatArrayRegion(vector, 0, query.size(), query.data());
        std::vector<std::uint64_t> allowed;
        if (allowedIds) {
            std::vector<jlong> input(env->GetArrayLength(allowedIds));
            env->GetLongArrayRegion(allowedIds, 0, input.size(), input.data());
            allowed.assign(input.begin(), input.end());
            std::sort(allowed.begin(), allowed.end());
        }
        if (env->ExceptionCheck()) return nullptr;
        auto candidates = index(handle).article_candidates(query.data(), query.size(), wanted, minimum,
            allowedIds ? &allowed : nullptr);
        // Version, exhaustive recovery flag, passage frontier, measured vectors,
        // followed by ranked unique article IDs. This is NOT a passage-key list.
        std::vector<std::uint64_t> packet{1, candidates.exhaustive ? 1u : 0u,
            candidates.passages, candidates.scored};
        packet.insert(packet.end(), candidates.articles.begin(), candidates.articles.end());
        return javaKeys(env, packet);
    } HANDLE_ERRORS
    return nullptr;
}

extern "C" JNIEXPORT jfloatArray JNICALL JNI_METHOD(scoreVectors)(JNIEnv* env, jobject,
        jfloatArray queryArray, jobjectArray vectors) {
    try {
        auto dim = env->GetArrayLength(queryArray);
        if (dim < 1 || dim > 2048) throw std::invalid_argument("Invalid exact scoring dimension");
        auto count = env->GetArrayLength(vectors);
        std::array<float, 2048> query{}, vector{};
        env->GetFloatArrayRegion(queryArray, 0, dim, query.data());
        if (env->ExceptionCheck()) return nullptr;
        for (int i = 0; i < dim; ++i)
            if (!std::isfinite(query[i])) throw std::invalid_argument("Non-finite scoring query");
        std::vector<float> scores(count, std::numeric_limits<float>::quiet_NaN());
        for (int i = 0; i < count; ++i) {
            auto blob = static_cast<jbyteArray>(env->GetObjectArrayElement(vectors, i));
            if (env->ExceptionCheck()) return nullptr;
            if (blob && env->GetArrayLength(blob) == dim * static_cast<int>(sizeof(float))) {
                env->GetByteArrayRegion(blob, 0, dim * sizeof(float), reinterpret_cast<jbyte*>(vector.data()));
                if (env->ExceptionCheck()) { env->DeleteLocalRef(blob); return nullptr; }
                scores[i] = std::clamp(markvault::exact_dot(query.data(), vector.data(), dim), -1.f, 1.f);
            }
            if (blob) env->DeleteLocalRef(blob);
        }
        auto result = env->NewFloatArray(count);
        if (result) env->SetFloatArrayRegion(result, 0, count, scores.data());
        return result;
    } HANDLE_ERRORS
    return nullptr;
}
