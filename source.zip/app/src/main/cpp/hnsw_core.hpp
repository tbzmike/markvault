#pragma once

#include <usearch/index_dense.hpp>
#include <algorithm>
#include <array>
#include <cmath>
#include <cstdio>
#include <chrono>
#include <cstring>
#include <ctime>
#include <memory>
#include <stdexcept>
#include <unordered_map>
#include <vector>
#if defined(__aarch64__)
#include <arm_neon.h>
#endif
#if (defined(__x86_64__) || defined(__i386__)) && (defined(__GNUC__) || defined(__clang__))
#include <immintrin.h>
#include <cpuid.h>
#define MARKVAULT_F16C 1
#else
#define MARKVAULT_F16C 0
#endif

namespace markvault {
namespace us = unum::usearch;

// Snapshot payloads may start at an odd byte offset. memcpy keeps scalar tails
// valid on every ABI and lets the compiler emit an unaligned half-word load.
inline float load_half(us::f16_t const* source) noexcept {
    us::f16_t value;
    std::memcpy(&value, source, sizeof(value));
    return float(value);
}

// CPU time distinguishes arithmetic from scheduling and mapped-page waits.
inline std::uint64_t thread_cpu_nanos() noexcept {
#if defined(CLOCK_THREAD_CPUTIME_ID)
    timespec value{};
    if (::clock_gettime(CLOCK_THREAD_CPUTIME_ID, &value) == 0)
        return std::uint64_t(value.tv_sec) * 1'000'000'000u + std::uint64_t(value.tv_nsec);
#endif
    return 0;
}

// Preserve the persisted FP32 scoring order. Four products are computed at
// once on ARM, then added in the same order as the Kotlin scalar reference.
inline float exact_dot(float const* query, float const* vector, std::size_t dim) {
    float score = 0;
    std::size_t i = 0;
#if defined(__aarch64__)
    for (; i + 4 <= dim; i += 4) {
        auto products = vmulq_f32(vld1q_f32(query + i), vld1q_f32(vector + i));
        score += vgetq_lane_f32(products, 0);
        score += vgetq_lane_f32(products, 1);
        score += vgetq_lane_f32(products, 2);
        score += vgetq_lane_f32(products, 3);
    }
#endif
    for (; i < dim; ++i) score += query[i] * vector[i];
    return score;
}

// Only attached to a validated, immutable, contiguous mapped vector matrix.
// Norms use the same accumulation order as the query metric on each ABI.
struct VectorNorms {
    std::uintptr_t base = 0;
    std::size_t stride = 0;
    std::vector<float> values;
    bool find(void const* vector, std::size_t dim, float& norm) const {
        auto address = reinterpret_cast<std::uintptr_t>(vector);
        if (!base || stride != dim * sizeof(us::f16_t) || address < base) return false;
        auto offset = address - base;
        auto slot = offset / stride;
        if (offset % stride || slot >= values.size()) return false;
        norm = values[slot];
        return true;
    }
};

#if MARKVAULT_F16C
inline bool has_f16c() {
    static bool const available = [] {
        unsigned a = 0, b = 0, c = 0, d = 0;
        // Clang's feature-string list omits f16c. Test its CPUID bit directly;
        // the AVX runtime check also verifies the OS saves the extended state.
        return __get_cpuid(1, &a, &b, &c, &d) && (c & (1u << 29)) && __builtin_cpu_supports("avx");
    }();
    return available;
}
__attribute__((target("avx,f16c")))
inline void half8(us::f16_t const* input, float* output) {
    _mm256_storeu_ps(output, _mm256_cvtph_ps(_mm_loadu_si128(reinterpret_cast<__m128i const*>(input))));
}
#endif

inline float half_norm(us::f16_t const* vector, std::size_t dim) {
    float norm = 0;
    std::size_t i = 0;
#if defined(__aarch64__)
    float32x4_t sum = vdupq_n_f32(0);
    for (; i + 4 <= dim; i += 4) {
        auto v = vcvt_f32_f16(vreinterpret_f16_u16(vld1_u16(reinterpret_cast<std::uint16_t const*>(vector + i))));
        sum = vfmaq_f32(sum, v, v);
    }
    norm = vaddvq_f32(sum);
#elif MARKVAULT_F16C
    if (has_f16c()) {
        float values[8];
        for (; i + 8 <= dim; i += 8) {
            half8(vector + i, values);
            for (float v : values) norm += v * v;
        }
    }
#endif
    for (; i < dim; ++i) { float v = load_half(vector + i); norm += v * v; }
    return norm;
}

struct QueryMetricCache {
    bool active = false;
    void const* query = nullptr;
    std::size_t dim = 0;
    alignas(16) float values[2048];
    float norm = 0;
    void const* last_vector = nullptr;
    float last_distance = 0;
    std::uint64_t measurements = 0;
    VectorNorms const* norms = nullptr;
    std::array<void const*, 64> batch_vectors{};
    std::array<float, 64> batch_distances{};
    std::size_t batch_size = 0;
    std::size_t batch_next = 0;
};
inline thread_local QueryMetricCache query_metric_cache;

class QueryMetricGuard {
public:
    explicit QueryMetricGuard(VectorNorms const* norms = nullptr) {
        if (query_metric_cache.active) throw std::logic_error("Nested HNSW query");
        query_metric_cache.active = true;
        query_metric_cache.query = nullptr;
        query_metric_cache.norms = norms;
        query_metric_cache.batch_size = 0;
    }
    ~QueryMetricGuard() { query_metric_cache.active = false; query_metric_cache.norms = nullptr; }
};

inline void prepare_half_query(us::f16_t const* query, std::size_t dim) {
    auto& cache = query_metric_cache;
    if (cache.query == query && cache.dim == dim) return;
    cache.query = query; cache.dim = dim; cache.norm = 0;
    std::size_t i = 0;
#if defined(__aarch64__)
    float32x4_t norm = vdupq_n_f32(0);
    for (; i + 4 <= dim; i += 4) {
        auto q = vcvt_f32_f16(vreinterpret_f16_u16(vld1_u16(reinterpret_cast<std::uint16_t const*>(query + i))));
        vst1q_f32(cache.values + i, q);
        norm = vfmaq_f32(norm, q, q);
    }
    cache.norm = vaddvq_f32(norm);
#elif MARKVAULT_F16C
    if (has_f16c()) {
        for (; i + 8 <= dim; i += 8) half8(query + i, cache.values + i);
        for (; i < dim; ++i) cache.values[i] = load_half(query + i);
        cache.norm = half_norm(query, dim);
        return;
    }
#endif
    for (; i < dim; ++i) { float q = load_half(query + i); cache.values[i] = q; cache.norm += q * q; }
}

#if MARKVAULT_F16C
// Conversion and multiplication use SIMD. The additions deliberately retain
// the original x86 scalar order, including tails and zero-vector behavior.
__attribute__((target("avx,f16c")))
inline float cosine_half_f16c(us::f16_t const* a, us::f16_t const* b, std::size_t dim, bool cached) {
    auto& cache = query_metric_cache;
    if (cached) prepare_half_query(a, dim);
    float ab = 0, aa = cached ? cache.norm : 0, bb = 0;
    bool known_norm = cached && cache.norms && cache.norms->find(b, dim, bb);
    std::size_t i = 0;
    alignas(32) float products[8], squares_a[8], squares_b[8];
    for (; i + 8 <= dim; i += 8) {
        auto av = cached ? _mm256_loadu_ps(cache.values + i) :
            _mm256_cvtph_ps(_mm_loadu_si128(reinterpret_cast<__m128i const*>(a + i)));
        auto bv = _mm256_cvtph_ps(_mm_loadu_si128(reinterpret_cast<__m128i const*>(b + i)));
        _mm256_store_ps(products, _mm256_mul_ps(av, bv));
        if (!cached) _mm256_store_ps(squares_a, _mm256_mul_ps(av, av));
        if (!known_norm) _mm256_store_ps(squares_b, _mm256_mul_ps(bv, bv));
        for (std::size_t lane = 0; lane < 8; ++lane) {
            ab += products[lane];
            if (!cached) aa += squares_a[lane];
            if (!known_norm) bb += squares_b[lane];
        }
    }
    for (; i < dim; ++i) {
        float av = cached ? cache.values[i] : load_half(a + i), bv = load_half(b + i);
        ab += av * bv; if (!cached) aa += av * av; if (!known_norm) bb += bv * bv;
    }
    float distance = aa == 0 || bb == 0 ? (aa == bb ? 0.0f : 1.0f) :
        std::max(0.0f, std::min(2.0f, 1.0f - ab / std::sqrt(aa * bb)));
    if (cached) { cache.last_vector = b; cache.last_distance = distance; ++cache.measurements; }
    return distance;
}
#endif

// ARMv8-A FP16 conversion + FP32 accumulation; no ARMv8.2-only instructions.
inline float cosine_half(void const* a_ptr, void const* b_ptr, std::size_t dim) {
    auto a = static_cast<us::f16_t const*>(a_ptr);
    auto b = static_cast<us::f16_t const*>(b_ptr);
    auto& cache = query_metric_cache;
    bool cached = cache.active && dim <= 2048;
    if (cached && cache.query == a_ptr && cache.dim == dim && cache.batch_size) {
        auto at = cache.batch_next;
        if (at >= cache.batch_size || cache.batch_vectors[at] != b_ptr) {
            for (at = 0; at < cache.batch_size && cache.batch_vectors[at] != b_ptr; ++at) {}
        }
        if (at < cache.batch_size) {
            cache.batch_next = at + 1;
            cache.last_vector = b_ptr;
            cache.last_distance = cache.batch_distances[at];
            ++cache.measurements;
            return cache.last_distance;
        }
    }
#if MARKVAULT_F16C
    if (has_f16c()) return cosine_half_f16c(a, b, dim, cached);
#endif
    if (cached) prepare_half_query(a, dim);
    float ab = 0, aa = cached ? cache.norm : 0, bb = 0;
    bool known_norm = cached && cache.norms && cache.norms->find(b_ptr, dim, bb);
    std::size_t i = 0;
#if defined(__aarch64__)
    float32x4_t vab = vdupq_n_f32(0), vaa = vab, vbb = vab;
    for (; i + 4 <= dim; i += 4) {
        auto av = cached ? vld1q_f32(cache.values + i) :
            vcvt_f32_f16(vreinterpret_f16_u16(vld1_u16(reinterpret_cast<std::uint16_t const*>(a + i))));
        auto bv = vcvt_f32_f16(vreinterpret_f16_u16(vld1_u16(reinterpret_cast<std::uint16_t const*>(b + i))));
        vab = vfmaq_f32(vab, av, bv);
        if (!cached) vaa = vfmaq_f32(vaa, av, av);
        if (!known_norm) vbb = vfmaq_f32(vbb, bv, bv);
    }
    ab = vaddvq_f32(vab); if (!cached) aa = vaddvq_f32(vaa); if (!known_norm) bb = vaddvq_f32(vbb);
#endif
    for (; i < dim; ++i) {
        float av = cached ? cache.values[i] : load_half(a + i), bv = load_half(b + i);
        ab += av * bv; if (!cached) aa += av * av; if (!known_norm) bb += bv * bv;
    }
    float distance = aa == 0 || bb == 0 ? (aa == bb ? 0.0f : 1.0f) :
        std::max(0.0f, std::min(2.0f, 1.0f - ab / std::sqrt(aa * bb)));
    if (cached) { cache.last_vector = b_ptr; cache.last_distance = distance; ++cache.measurements; }
    return distance;
}

#if MARKVAULT_F16C
__attribute__((target("avx,f16c")))
inline void dot_half4_f16c(float const* query, us::f16_t const* const* vectors, std::size_t dim, float* dots) {
    std::size_t i = 0;
    auto sums = _mm_loadu_ps(dots);
    for (; i + 8 <= dim; i += 8) {
        auto q = _mm256_loadu_ps(query + i);
        auto p0 = _mm256_mul_ps(q, _mm256_cvtph_ps(_mm_loadu_si128(reinterpret_cast<__m128i const*>(vectors[0] + i))));
        auto p1 = _mm256_mul_ps(q, _mm256_cvtph_ps(_mm_loadu_si128(reinterpret_cast<__m128i const*>(vectors[1] + i))));
        auto p2 = _mm256_mul_ps(q, _mm256_cvtph_ps(_mm_loadu_si128(reinterpret_cast<__m128i const*>(vectors[2] + i))));
        auto p3 = _mm256_mul_ps(q, _mm256_cvtph_ps(_mm_loadu_si128(reinterpret_cast<__m128i const*>(vectors[3] + i))));
        // Each lane accumulates one sibling in its original scalar order.
        // Transpose in registers instead of spilling all 32 products to memory.
        auto a = _mm256_castps256_ps128(p0), b = _mm256_castps256_ps128(p1);
        auto c = _mm256_castps256_ps128(p2), d = _mm256_castps256_ps128(p3);
        _MM_TRANSPOSE4_PS(a, b, c, d);
        sums = _mm_add_ps(sums, a); sums = _mm_add_ps(sums, b);
        sums = _mm_add_ps(sums, c); sums = _mm_add_ps(sums, d);
        a = _mm256_extractf128_ps(p0, 1); b = _mm256_extractf128_ps(p1, 1);
        c = _mm256_extractf128_ps(p2, 1); d = _mm256_extractf128_ps(p3, 1);
        _MM_TRANSPOSE4_PS(a, b, c, d);
        sums = _mm_add_ps(sums, a); sums = _mm_add_ps(sums, b);
        sums = _mm_add_ps(sums, c); sums = _mm_add_ps(sums, d);
    }
    _mm_storeu_ps(dots, sums);
    for (; i < dim; ++i) for (std::size_t row = 0; row < 4; ++row)
        dots[row] += query[i] * load_half(vectors[row] + i);
}
#endif

// Normalize four siblings together, preserving the scalar zero/NaN clamp.
inline void finish_cosine4(float aa, float const* norms, float const* dots, float* output) {
#if defined(__aarch64__)
    auto zero = vdupq_n_f32(0), one = vdupq_n_f32(1), two = vdupq_n_f32(2);
    auto a = vdupq_n_f32(aa), b = vld1q_f32(norms);
    auto empty = vorrq_u32(vceqq_f32(a, zero), vceqq_f32(b, zero));
    auto denominator = vsqrtq_f32(vmulq_f32(vbslq_f32(empty, one, a), vbslq_f32(empty, one, b)));
    auto distance = vsubq_f32(one, vdivq_f32(vbslq_f32(empty, zero, vld1q_f32(dots)), denominator));
    distance = vbslq_f32(vcltq_f32(distance, two), distance, two);
    distance = vbslq_f32(vcltq_f32(zero, distance), distance, zero);
    vst1q_f32(output, vbslq_f32(empty, vbslq_f32(vceqq_f32(a, b), zero, one), distance));
#elif defined(__SSE2__) && MARKVAULT_F16C
    auto select = [](__m128 mask, __m128 yes, __m128 no) {
        return _mm_or_ps(_mm_and_ps(mask, yes), _mm_andnot_ps(mask, no));
    };
    auto zero = _mm_setzero_ps(), one = _mm_set1_ps(1), two = _mm_set1_ps(2);
    auto a = _mm_set1_ps(aa), b = _mm_loadu_ps(norms);
    auto empty = _mm_or_ps(_mm_cmpeq_ps(a, zero), _mm_cmpeq_ps(b, zero));
    auto denominator = _mm_sqrt_ps(_mm_mul_ps(select(empty, one, a), select(empty, one, b)));
    auto distance = _mm_sub_ps(one, _mm_div_ps(select(empty, zero, _mm_loadu_ps(dots)), denominator));
    distance = select(_mm_cmplt_ps(distance, two), distance, two);
    distance = select(_mm_cmplt_ps(zero, distance), distance, zero);
    _mm_storeu_ps(output, select(empty, select(_mm_cmpeq_ps(a, b), zero, one), distance));
#else
    for (std::size_t row = 0; row < 4; ++row) {
        auto bb = norms[row];
        output[row] = aa == 0 || bb == 0 ? (aa == bb ? 0.0f : 1.0f) :
            std::max(0.0f, std::min(2.0f, 1.0f - dots[row] / std::sqrt(aa * bb)));
    }
#endif
}

// Calculate sibling distances four at a time, ahead of their unchanged
// sequential admission. No graph edge, visit, radius or scope order changes.
inline void precompute_cosine_half(void const* query, void const* const* vectors,
                                   std::size_t count, std::size_t dim) {
    auto& cache = query_metric_cache;
    cache.batch_size = 0; cache.batch_next = 0;
    if (!cache.active || !cache.norms || dim > 2048 || count < 4 || count > 64) return;
#if !defined(__aarch64__)
#if MARKVAULT_F16C
    if (!has_f16c()) return;
#else
    return;
#endif
#endif
    float norms[64];
    for (std::size_t i = 0; i < count; ++i)
        if (!cache.norms->find(vectors[i], dim, norms[i])) return;
    prepare_half_query(static_cast<us::f16_t const*>(query), dim);
    for (std::size_t base = 0; base < count; base += 4) {
        us::f16_t const* batch[4];
        for (std::size_t row = 0; row < 4; ++row)
            batch[row] = static_cast<us::f16_t const*>(vectors[std::min(base + row, count - 1)]);
        float dots[4]{};
#if defined(__aarch64__)
        float32x4_t sums[4]{vdupq_n_f32(0), vdupq_n_f32(0), vdupq_n_f32(0), vdupq_n_f32(0)};
        std::size_t i = 0;
        // Load eight FP16 values at once, retaining each lane's FMA sequence.
        for (; i + 8 <= dim; i += 8) {
            auto q0 = vld1q_f32(cache.values + i), q1 = vld1q_f32(cache.values + i + 4);
            float16x8_t values[4];
            for (std::size_t row = 0; row < 4; ++row)
                values[row] = vreinterpretq_f16_u16(vld1q_u16(reinterpret_cast<std::uint16_t const*>(batch[row] + i)));
            for (std::size_t row = 0; row < 4; ++row)
                sums[row] = vfmaq_f32(sums[row], q0, vcvt_f32_f16(vget_low_f16(values[row])));
            for (std::size_t row = 0; row < 4; ++row)
                sums[row] = vfmaq_f32(sums[row], q1, vcvt_f32_f16(vget_high_f16(values[row])));
        }
        for (; i + 4 <= dim; i += 4) {
            auto q = vld1q_f32(cache.values + i);
            for (std::size_t row = 0; row < 4; ++row) {
                auto v = vcvt_f32_f16(vreinterpret_f16_u16(vld1_u16(reinterpret_cast<std::uint16_t const*>(batch[row] + i))));
                sums[row] = vfmaq_f32(sums[row], q, v);
            }
        }
        for (std::size_t row = 0; row < 4; ++row) dots[row] = vaddvq_f32(sums[row]);
        for (; i < dim; ++i) for (std::size_t row = 0; row < 4; ++row)
            dots[row] += cache.values[i] * load_half(batch[row] + i);
#elif MARKVAULT_F16C
        dot_half4_f16c(cache.values, batch, dim, dots);
#endif
        float row_norms[4], distances[4];
        for (std::size_t row = 0; row < 4; ++row)
            row_norms[row] = norms[std::min(base + row, count - 1)];
        finish_cosine4(cache.norm, row_norms, dots, distances);
        for (std::size_t row = 0; row < 4 && base + row < count; ++row) {
            auto at = base + row;
            cache.batch_vectors[at] = vectors[at];
            cache.batch_distances[at] = distances[row];
        }
    }
    cache.batch_size = count;
}

inline us::metric_punned_t metric(std::size_t dim) {
    return {dim, reinterpret_cast<std::uintptr_t>(&cosine_half),
            us::metric_punned_signature_t::array_array_size_k,
            us::metric_kind_t::cos_k, us::scalar_kind_t::f16_k};
}

template <typename Result> inline void checked(Result& result) {
    if (!result) throw std::runtime_error(result.error.release());
}

// Compress sorted scope membership without admitting a single extra article.
// First/remaining-library scopes commonly become one range instead of a
// binary search through tens of thousands of IDs for every visited passage.
class ArticleScope {
    bool unrestricted_;
    std::vector<std::pair<std::uint64_t, std::uint64_t>> ranges_;
public:
    explicit ArticleScope(std::vector<std::uint64_t> const* allowed) : unrestricted_(!allowed) {
        if (!allowed) return;
        for (auto note : *allowed) {
            if (!ranges_.empty() && (note == ranges_.back().second ||
                (ranges_.back().second != UINT64_MAX && note == ranges_.back().second + 1)))
                ranges_.back().second = note;
            else ranges_.emplace_back(note, note);
        }
    }
    bool contains(std::uint64_t note) const {
        if (unrestricted_) return true;
        auto it = std::lower_bound(ranges_.begin(), ranges_.end(), note,
            [](auto const& range, std::uint64_t value) { return range.second < value; });
        return it != ranges_.end() && it->first <= note;
    }
};

class Hnsw {
    us::index_dense_t index_;
    using QueryVector = std::pair<std::uint64_t, us::f16_t const*>;
    std::vector<QueryVector> query_vectors_;
    VectorNorms vector_norms_;
    struct Observed { std::uint64_t key; float distance; };
    struct MeasuredArticle { float distance; std::uint64_t epoch; };
    std::vector<Observed> observed_;
    std::unordered_map<std::uint64_t, MeasuredArticle> best_;
    std::vector<std::uint64_t> active_articles_;
    std::vector<std::pair<float, std::uint64_t>> ranked_;
    std::uint64_t epoch_ = 0;

    void invalidate_query_data() {
        query_vectors_.clear();
        vector_norms_.base = 0;
        vector_norms_.values.clear();
        best_.clear();
    }

    void prepare_mapped_queries() {
        // Validate every address before enabling direct slot lookup. Mutable
        // loads use separately allocated tapes and retain the original metric.
        us::index_dense_t::values_proxy_t values(index_);
        auto first = index_.cbegin(), end = index_.cend();
        if (first == end) return;
        auto base = reinterpret_cast<std::uintptr_t>(values[first]);
        auto stride = dimensions() * sizeof(us::f16_t);
        std::size_t count = 0;
        for (auto it = first; it != end; ++it, ++count)
            if (reinterpret_cast<std::uintptr_t>(values[it]) != base + count * stride) return;
        vector_norms_.values.resize(count);
        count = 0;
        for (auto it = first; it != end; ++it, ++count)
            vector_norms_.values[count] = half_norm(reinterpret_cast<us::f16_t const*>(values[it]), dimensions());
        vector_norms_.stride = stride;
        vector_norms_.base = base;
        observed_.reserve(size());
        best_.reserve(std::min<std::size_t>(size(), 4800));
        active_articles_.reserve(std::min<std::size_t>(size(), 4800));
        ranked_.reserve(std::min<std::size_t>(size(), 4800));
        prepare_query_vectors();
    }

    void begin_articles() {
        if (++epoch_ == 0) { best_.clear(); epoch_ = 1; }
        active_articles_.clear();
    }
    void admit_article(std::uint64_t note, float distance) {
        auto at = best_.find(note);
        if (at == best_.end()) at = best_.emplace(note, MeasuredArticle{distance, 0}).first;
        if (at->second.epoch != epoch_) {
            at->second = {distance, epoch_};
            active_articles_.push_back(note);
        } else at->second.distance = std::min(at->second.distance, distance);
    }

    void prepare_query_vectors() {
        if (!query_vectors_.empty()) return;
        us::index_dense_t::values_proxy_t values(index_);
        query_vectors_.reserve(size());
        for (auto it = index_.cbegin(); it != index_.cend(); ++it) {
            auto key = static_cast<std::uint64_t>((*it).key);
            if (key != index_.free_key())
                query_vectors_.emplace_back(key, reinterpret_cast<us::f16_t const*>(values[it]));
        }
        std::sort(query_vectors_.begin(), query_vectors_.end(),
                  [](QueryVector const& a, QueryVector const& b) { return a.first < b.first; });
    }

    // Candidate selection still uses quantized vectors. Final article scoring
    // uses the existing full precision Room vectors in AppViewModel.
    float query_distance(float const* query, us::f16_t const* vector,
                         std::size_t dim, float query_norm) const {
        float dot = 0, norm = 0;
        bool known_norm = vector_norms_.find(vector, dim, norm);
        std::size_t i = 0;
#if defined(__aarch64__)
        float32x4_t dots = vdupq_n_f32(0), norms = dots;
        for (; i + 4 <= dim; i += 4) {
            auto v = vcvt_f32_f16(vreinterpret_f16_u16(vld1_u16(reinterpret_cast<std::uint16_t const*>(vector + i))));
            dots = vfmaq_f32(dots, vld1q_f32(query + i), v);
            if (!known_norm) norms = vfmaq_f32(norms, v, v);
        }
        dot = vaddvq_f32(dots); if (!known_norm) norm = vaddvq_f32(norms);
#elif MARKVAULT_F16C
        if (has_f16c()) {
            float values[8];
            for (; i + 8 <= dim; i += 8) {
                half8(vector + i, values);
                for (std::size_t lane = 0; lane < 8; ++lane) {
                    dot += query[i + lane] * values[lane];
                    if (!known_norm) norm += values[lane] * values[lane];
                }
            }
        }
#endif
        for (; i < dim; ++i) { float v = load_half(vector + i); dot += query[i] * v; if (!known_norm) norm += v * v; }
        if (query_norm == 0 || norm == 0) return query_norm == norm ? 0.0f : 1.0f;
        return std::max(0.0f, std::min(2.0f, 1.0f - dot / std::sqrt(query_norm * norm)));
    }
public:
    struct ArticleCandidates {
        std::vector<std::uint64_t> articles;
        bool exhaustive = false;
        std::size_t passages = 0;
        std::size_t scored = 0;
        std::uint64_t graph_ns = 0;
        std::uint64_t graph_cpu_ns = 0;
        std::uint64_t recovery_ns = 0;
    };
    Hnsw(int dim, std::size_t capacity, bool lookups = true) {
        if (dim < 1 || dim > 2048) throw std::invalid_argument("Invalid vector dimension");
        us::index_dense_config_t config;
        config.connectivity = 16;
        config.expansion_add = 128;
        config.expansion_search = 256;
        config.enable_key_lookups = lookups;
        auto made = us::index_dense_t::make(metric(dim), config,
            us::default_free_value<us::index_dense_t::vector_key_t>(), us::index_limits_t(capacity, 1));
        checked(made);
        index_ = std::move(made.index);
    }
    std::size_t size() const { return index_.size(); }
    std::size_t dimensions() const { return index_.dimensions(); }
    std::size_t serialized_length() const { return index_.serialized_length(); }
    void reserve(std::size_t capacity) {
        if (!index_.try_reserve(us::index_limits_t(capacity, 1))) throw std::bad_alloc();
    }
    void add(std::uint64_t key, float const* vector, std::size_t dim) {
        if (dim != dimensions()) throw std::invalid_argument("Vector dimension mismatch");
        for (std::size_t i = 0; i < dim; ++i)
            if (!std::isfinite(vector[i])) throw std::invalid_argument("Non-finite embedding");
        auto result = index_.add(key, vector);
        checked(result);
        invalidate_query_data();
    }
    void remove(std::uint64_t key) {
        auto result = index_.remove(key);
        checked(result);
        invalidate_query_data();
    }
    std::vector<std::uint64_t> keys() const {
        std::vector<std::uint64_t> result(size());
        index_.export_keys(result.data(), 0, result.size());
        return result;
    }
    void open(char const* path, std::size_t offset, bool mutable_index) {
        invalidate_query_data();
        auto result = mutable_index
            ? index_.load(us::memory_mapped_file_t(path), offset)
            : index_.view(us::memory_mapped_file_t(path), offset);
        checked(result);
        if (dimensions() < 1 || dimensions() > 2048 || index_.scalar_kind() != us::scalar_kind_t::f16_k)
            throw std::runtime_error("Incompatible HNSW vector format");
        index_.change_metric(metric(dimensions()));
        reserve(index_.capacity());
        if (!mutable_index) prepare_mapped_queries();
    }
    void append(char const* path) const {
        std::unique_ptr<std::FILE, decltype(&std::fclose)> file(std::fopen(path, "ab"), &std::fclose);
        if (!file) throw std::runtime_error("Could not open HNSW snapshot");
        auto result = index_.save_to_stream([&](void const* data, std::size_t size) {
            return std::fwrite(data, 1, size, file.get()) == size;
        });
        checked(result);
        if (std::fflush(file.get()) != 0) throw std::runtime_error("Could not flush HNSW snapshot");
    }
    std::vector<std::uint64_t> search(float const* query, std::size_t dim, std::size_t wanted,
                                    std::vector<std::uint64_t> const* allowed = nullptr) {
        if (dim != dimensions()) throw std::invalid_argument("Query dimension mismatch");
        for (std::size_t i = 0; i < dim; ++i)
            if (!std::isfinite(query[i])) throw std::invalid_argument("Non-finite query");
        wanted = std::min(wanted, size());
        if (!wanted) return {};
        // Returning hundreds of unique articles requires a wider frontier than top-10 search.
        index_.change_expansion_search(std::max<std::size_t>(256, wanted));
        auto result = index_.filtered_search(query, wanted, [&](std::uint64_t key) {
            return !allowed || std::binary_search(allowed->begin(), allowed->end(), key >> 32);
        });
        checked(result);
        std::vector<std::uint64_t> keys;
        keys.reserve(result.size());
        for (std::size_t i = 0; i < result.size(); ++i) keys.push_back(result.at(i).member.key);
        return keys;
    }

    ArticleCandidates article_candidates(float const* query, std::size_t dim, std::size_t article_limit,
                                         std::size_t minimum_articles,
                                         std::vector<std::uint64_t> const* allowed = nullptr) {
        if (dim != dimensions()) throw std::invalid_argument("Query dimension mismatch");
        if (!article_limit || article_limit > 1200 || minimum_articles > article_limit)
            throw std::invalid_argument("Invalid article candidate limit");
        float query_norm = 0;
        for (std::size_t i = 0; i < dim; ++i) {
            if (!std::isfinite(query[i])) throw std::invalid_argument("Non-finite query");
            query_norm += query[i] * query[i];
        }
        ArticleCandidates output;
        if (!size() || (allowed && allowed->empty())) { output.exhaustive = true; return output; }
        ArticleScope scope(allowed);
        begin_articles();
        auto accept = [&](QueryVector const& item, float const* measured = nullptr) {
            auto note = item.first >> 32;
            if (!scope.contains(note)) return;
            float distance = measured ? *measured : query_distance(query, item.second, dim, query_norm);
            if (!measured) ++output.scored;
            admit_article(note, distance);
        };
        // One traversal replaces the old 1,200 -> 2,400 -> 4,800 retries.
        // Keep the original scope predicate: post-filtering an unrestricted
        // graph walk loses strong matches in a distant selected partition.
        // Retain every admitted article, including passages evicted from top-K.
        auto coverage = article_limit;
        {
            constexpr std::size_t budget = 4800;
            // The pinned graph visits each slot at most once. Allocate outside
            // its noexcept predicate so allocation failure remains catchable.
            observed_.clear();
            observed_.reserve(size());
            output.passages = std::min(budget, size());
            index_.change_expansion_search(output.passages);
            bool measured = true;
            {
                QueryMetricGuard guard(&vector_norms_);
                auto last_measurement = query_metric_cache.measurements;
                auto graph_started = std::chrono::steady_clock::now();
                auto cpu_started = thread_cpu_nanos();
                auto result = index_.filtered_search(query, output.passages, [&](std::uint64_t key) {
                    // Pinned USearch measures each candidate immediately before
                    // its predicate. Validate that a new measurement occurred.
                    auto& cache = query_metric_cache;
                    measured = measured && cache.measurements != last_measurement &&
                        cache.last_vector && cache.query && cache.dim == dim;
                    last_measurement = cache.measurements;
                    if (!scope.contains(key >> 32))
                        return false;
                    if (observed_.size() < observed_.capacity())
                        observed_.push_back({key, cache.last_distance});
                    return true;
                }, us::index_dense_t::any_thread(), false, true, &precompute_cosine_half);
                checked(result);
                auto cpu_finished = thread_cpu_nanos();
                if (cpu_started && cpu_finished >= cpu_started) output.graph_cpu_ns = cpu_finished - cpu_started;
                output.graph_ns = std::chrono::duration_cast<std::chrono::nanoseconds>(
                    std::chrono::steady_clock::now() - graph_started).count();
                output.scored += result.computed_distances;
            }
            if (!measured) throw std::runtime_error("HNSW metric/predicate binding mismatch");
            for (auto const& item : observed_) admit_article(item.key >> 32, item.distance);
        }
        if (active_articles_.size() < coverage) {
            // Sparse/diverse scopes recover through a contiguous native FP16
            // candidate scan, rather than streaming 200k full precision BLOBs
            // through Room/ART. Every selected article is still rescored from
            // ALL of its full precision persisted chunks afterwards.
            output.exhaustive = true;
            auto recovery_started = std::chrono::steady_clock::now();
            begin_articles();
            prepare_query_vectors();
            for (auto const& item : query_vectors_) accept(item);
            output.recovery_ns = std::chrono::duration_cast<std::chrono::nanoseconds>(
                std::chrono::steady_clock::now() - recovery_started).count();
        }
        ranked_.clear();
        ranked_.reserve(active_articles_.size());
        for (auto note : active_articles_) ranked_.emplace_back(best_.at(note).distance, note);
        auto wanted = std::min(article_limit, ranked_.size());
        std::partial_sort(ranked_.begin(), ranked_.begin() + wanted, ranked_.end());
        output.articles.reserve(wanted);
        for (std::size_t i = 0; i < wanted; ++i) output.articles.push_back(ranked_[i].second);
        return output;
    }
};
}
