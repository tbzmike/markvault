#pragma once

#include <usearch/index_dense.hpp>
#include <algorithm>
#include <cmath>
#include <cstdio>
#include <memory>
#include <stdexcept>
#include <vector>
#if defined(__aarch64__)
#include <arm_neon.h>
#endif

namespace markvault {
namespace us = unum::usearch;

// ARMv8-A FP16 conversion + FP32 accumulation; no ARMv8.2-only instructions.
inline float cosine_half(void const* a_ptr, void const* b_ptr, std::size_t dim) {
    auto a = static_cast<us::f16_t const*>(a_ptr);
    auto b = static_cast<us::f16_t const*>(b_ptr);
    float ab = 0, aa = 0, bb = 0;
    std::size_t i = 0;
#if defined(__aarch64__)
    float32x4_t vab = vdupq_n_f32(0), vaa = vab, vbb = vab;
    for (; i + 4 <= dim; i += 4) {
        auto av = vcvt_f32_f16(vreinterpret_f16_u16(vld1_u16(reinterpret_cast<std::uint16_t const*>(a + i))));
        auto bv = vcvt_f32_f16(vreinterpret_f16_u16(vld1_u16(reinterpret_cast<std::uint16_t const*>(b + i))));
        vab = vfmaq_f32(vab, av, bv);
        vaa = vfmaq_f32(vaa, av, av);
        vbb = vfmaq_f32(vbb, bv, bv);
    }
    ab = vaddvq_f32(vab); aa = vaddvq_f32(vaa); bb = vaddvq_f32(vbb);
#endif
    for (; i < dim; ++i) {
        float av = float(a[i]), bv = float(b[i]);
        ab += av * bv; aa += av * av; bb += bv * bv;
    }
    if (aa == 0 || bb == 0) return aa == bb ? 0.0f : 1.0f;
    return std::max(0.0f, std::min(2.0f, 1.0f - ab / std::sqrt(aa * bb)));
}

inline us::metric_punned_t metric(std::size_t dim) {
    return {dim, reinterpret_cast<std::uintptr_t>(&cosine_half),
            us::metric_punned_signature_t::array_array_size_k,
            us::metric_kind_t::cos_k, us::scalar_kind_t::f16_k};
}

template <typename Result> inline void checked(Result& result) {
    if (!result) throw std::runtime_error(result.error.release());
}

class Hnsw {
    us::index_dense_t index_;
public:
    Hnsw(int dim, std::size_t capacity, bool lookups = true) {
        if (dim < 1 || dim > 2048) throw std::invalid_argument("Invalid vector dimension");
        us::index_dense_config_t config;
        config.connectivity = 16;
        config.expansion_add = 128;
        config.expansion_search = 256;
        config.enable_key_lookups = lookups;
        auto made = us::index_dense_t::make(metric(dim), config,
            us::default_free_value<us::index_dense_t::vector_key_t>(), us::index_limits_t(capacity, 1));
        checked(made);
        index_ = std::move(made.index);
    }
    std::size_t size() const { return index_.size(); }
    std::size_t dimensions() const { return index_.dimensions(); }
    std::size_t serialized_length() const { return index_.serialized_length(); }
    void reserve(std::size_t capacity) {
        if (!index_.try_reserve(us::index_limits_t(capacity, 1))) throw std::bad_alloc();
    }
    void add(std::uint64_t key, float const* vector, std::size_t dim) {
        if (dim != dimensions()) throw std::invalid_argument("Vector dimension mismatch");
        for (std::size_t i = 0; i < dim; ++i)
            if (!std::isfinite(vector[i])) throw std::invalid_argument("Non-finite embedding");
        auto result = index_.add(key, vector);
        checked(result);
    }
    void remove(std::uint64_t key) {
        auto result = index_.remove(key);
        checked(result);
    }
    std::vector<std::uint64_t> keys() const {
        std::vector<std::uint64_t> result(size());
        index_.export_keys(result.data(), 0, result.size());
        return result;
    }
    void open(char const* path, std::size_t offset, bool mutable_index) {
        auto result = mutable_index
            ? index_.load(us::memory_mapped_file_t(path), offset)
            : index_.view(us::memory_mapped_file_t(path), offset);
        checked(result);
        index_.change_metric(metric(dimensions()));
        reserve(index_.capacity());
    }
    void append(char const* path) const {
        std::unique_ptr<std::FILE, decltype(&std::fclose)> file(std::fopen(path, "ab"), &std::fclose);
        if (!file) throw std::runtime_error("Could not open HNSW snapshot");
        auto result = index_.save_to_stream([&](void const* data, std::size_t size) {
            return std::fwrite(data, 1, size, file.get()) == size;
        });
        checked(result);
        if (std::fflush(file.get()) != 0) throw std::runtime_error("Could not flush HNSW snapshot");
    }
    std::vector<std::uint64_t> search(float const* query, std::size_t dim, std::size_t wanted,
                                    std::vector<std::uint64_t> const* allowed = nullptr) {
        if (dim != dimensions()) throw std::invalid_argument("Query dimension mismatch");
        for (std::size_t i = 0; i < dim; ++i)
            if (!std::isfinite(query[i])) throw std::invalid_argument("Non-finite query");
        wanted = std::min(wanted, size());
        if (!wanted) return {};
        // Returning hundreds of unique articles requires a wider frontier than top-10 search.
        index_.change_expansion_search(std::max<std::size_t>(256, wanted));
        auto result = index_.filtered_search(query, wanted, [&](std::uint64_t key) {
            return !allowed || std::binary_search(allowed->begin(), allowed->end(), key >> 32);
        });
        checked(result);
        std::vector<std::uint64_t> keys;
        keys.reserve(result.size());
        for (std::size_t i = 0; i < result.size(); ++i) keys.push_back(result.at(i).member.key);
        return keys;
    }
};
}
