#pragma once

// Included inside markvault after the original FP16 metric and shared query guard.
namespace sq8 {
using Scalar = std::int8_t;

template <typename Input> inline void quantize(Input const* input, Scalar* output, std::size_t dim) {
    double maximum = 0;
    for (std::size_t i = 0; i < dim; ++i) {
        double value = double(input[i]);
        if (!std::isfinite(value)) throw std::invalid_argument("Non-finite SQ8 input");
        maximum = std::max(maximum, std::abs(value));
    }
    if (!maximum) { std::fill(output, output + dim, Scalar{0}); return; }
    for (std::size_t i = 0; i < dim; ++i)
        output[i] = static_cast<Scalar>(std::round(double(input[i]) / maximum * 127.0));
}

inline std::int32_t norm(Scalar const* vector, std::size_t dim) {
    std::int32_t value = 0;
    for (std::size_t i = 0; i < dim; ++i) value += std::int32_t(vector[i]) * vector[i];
    return value;
}
inline std::int32_t scalar_dot(Scalar const* a, Scalar const* b, std::size_t dim) {
    std::int32_t value = 0;
    for (std::size_t i = 0; i < dim; ++i) value += std::int32_t(a[i]) * b[i];
    return value;
}

#if defined(__aarch64__) && defined(HWCAP_ASIMDDP) && defined(__clang__)
inline bool has_dotprod() {
    static bool const available = (::getauxval(AT_HWCAP) & HWCAP_ASIMDDP) != 0;
    return available;
}
__attribute__((target("dotprod"), noinline))
inline std::int32_t dot_sdot(Scalar const* a, Scalar const* b, std::size_t dim) {
    auto sum = vdupq_n_s32(0);
    std::size_t i = 0;
    for (; i + 16 <= dim; i += 16) sum = vdotq_s32(sum, vld1q_s8(a + i), vld1q_s8(b + i));
    auto result = vaddvq_s32(sum);
    for (; i < dim; ++i) result += std::int32_t(a[i]) * b[i];
    return result;
}
__attribute__((target("dotprod"), noinline))
inline void dot4_sdot(Scalar const* query, Scalar const* const* rows, std::size_t dim, std::int32_t* dots) {
    int32x4_t sums[4]{vdupq_n_s32(0),vdupq_n_s32(0),vdupq_n_s32(0),vdupq_n_s32(0)};
    std::size_t i = 0;
    for (; i + 16 <= dim; i += 16) {
        auto q = vld1q_s8(query + i);
        for (std::size_t row = 0; row < 4; ++row)
            sums[row] = vdotq_s32(sums[row], q, vld1q_s8(rows[row] + i));
    }
    for (std::size_t row = 0; row < 4; ++row) dots[row] = vaddvq_s32(sums[row]);
    for (; i < dim; ++i) for (std::size_t row = 0; row < 4; ++row)
        dots[row] += std::int32_t(query[i]) * rows[row][i];
}
#else
inline bool has_dotprod() { return false; }
#endif

inline int kernel() {
#if defined(__aarch64__)
    return has_dotprod() ? 2 : 1;
#elif defined(__SSE2__)
    return 3;
#else
    return 0;
#endif
}

inline std::int32_t dot(Scalar const* a, Scalar const* b, std::size_t dim) {
#if defined(__aarch64__) && defined(HWCAP_ASIMDDP) && defined(__clang__)
    if (has_dotprod()) return dot_sdot(a, b, dim);
#endif
    std::size_t i = 0;
    std::int32_t result = 0;
#if defined(__aarch64__)
    auto sum = vdupq_n_s32(0);
    for (; i + 16 <= dim; i += 16) {
        auto av = vld1q_s8(a + i), bv = vld1q_s8(b + i);
        sum = vpadalq_s16(sum, vmull_s8(vget_low_s8(av), vget_low_s8(bv)));
        sum = vpadalq_s16(sum, vmull_s8(vget_high_s8(av), vget_high_s8(bv)));
    }
    result = vaddvq_s32(sum);
#elif defined(__SSE2__)
    auto sum = _mm_setzero_si128(), zero = _mm_setzero_si128();
    for (; i + 16 <= dim; i += 16) {
        auto av = _mm_loadu_si128(reinterpret_cast<__m128i const*>(a + i));
        auto bv = _mm_loadu_si128(reinterpret_cast<__m128i const*>(b + i));
        auto as = _mm_cmpgt_epi8(zero, av), bs = _mm_cmpgt_epi8(zero, bv);
        sum = _mm_add_epi32(sum, _mm_madd_epi16(_mm_unpacklo_epi8(av, as), _mm_unpacklo_epi8(bv, bs)));
        sum = _mm_add_epi32(sum, _mm_madd_epi16(_mm_unpackhi_epi8(av, as), _mm_unpackhi_epi8(bv, bs)));
    }
    alignas(16) std::int32_t lanes[4]; _mm_store_si128(reinterpret_cast<__m128i*>(lanes), sum);
    result = lanes[0] + lanes[1] + lanes[2] + lanes[3];
#endif
    for (; i < dim; ++i) result += std::int32_t(a[i]) * b[i];
    return result;
}

inline void dot4(Scalar const* query, Scalar const* const* rows, std::size_t dim, std::int32_t* dots) {
#if defined(__aarch64__) && defined(HWCAP_ASIMDDP) && defined(__clang__)
    if (has_dotprod()) { dot4_sdot(query, rows, dim, dots); return; }
#endif
    std::size_t i = 0;
    std::fill(dots, dots + 4, 0);
#if defined(__aarch64__)
    int32x4_t sums[4]{vdupq_n_s32(0),vdupq_n_s32(0),vdupq_n_s32(0),vdupq_n_s32(0)};
    for (; i + 16 <= dim; i += 16) {
        auto q = vld1q_s8(query + i);
        for (std::size_t row = 0; row < 4; ++row) {
            auto v = vld1q_s8(rows[row] + i);
            sums[row] = vpadalq_s16(sums[row], vmull_s8(vget_low_s8(q), vget_low_s8(v)));
            sums[row] = vpadalq_s16(sums[row], vmull_s8(vget_high_s8(q), vget_high_s8(v)));
        }
    }
    for (std::size_t row = 0; row < 4; ++row) dots[row] = vaddvq_s32(sums[row]);
#elif defined(__SSE2__)
    __m128i sums[4]{_mm_setzero_si128(),_mm_setzero_si128(),_mm_setzero_si128(),_mm_setzero_si128()};
    auto zero = _mm_setzero_si128();
    for (; i + 16 <= dim; i += 16) {
        auto q = _mm_loadu_si128(reinterpret_cast<__m128i const*>(query + i));
        auto sign_q = _mm_cmpgt_epi8(zero, q);
        auto q0 = _mm_unpacklo_epi8(q, sign_q), q1 = _mm_unpackhi_epi8(q, sign_q);
        for (std::size_t row = 0; row < 4; ++row) {
            auto v = _mm_loadu_si128(reinterpret_cast<__m128i const*>(rows[row] + i));
            auto sign_v = _mm_cmpgt_epi8(zero, v);
            sums[row] = _mm_add_epi32(sums[row], _mm_madd_epi16(q0, _mm_unpacklo_epi8(v, sign_v)));
            sums[row] = _mm_add_epi32(sums[row], _mm_madd_epi16(q1, _mm_unpackhi_epi8(v, sign_v)));
        }
    }
    for (std::size_t row = 0; row < 4; ++row) {
        alignas(16) std::int32_t lanes[4]; _mm_store_si128(reinterpret_cast<__m128i*>(lanes), sums[row]);
        dots[row] = lanes[0] + lanes[1] + lanes[2] + lanes[3];
    }
#endif
    for (; i < dim; ++i) for (std::size_t row = 0; row < 4; ++row)
        dots[row] += std::int32_t(query[i]) * rows[row][i];
}

inline float inverse_norm(float squared) { return squared ? 1.f / std::sqrt(squared) : 0.f; }

inline float distance_inverse(Scalar const* query, Scalar const* vector, std::size_t dim, float query_inverse,
                              VectorNorms const* norms = nullptr) {
    float vector_inverse = 0;
    if (!norms || !norms->find(vector, dim, vector_inverse)) vector_inverse = inverse_norm(float(norm(vector, dim)));
    else if (!norms->inverse) vector_inverse = inverse_norm(vector_inverse);
    if (!query_inverse || !vector_inverse) return query_inverse == vector_inverse ? 0.f : 1.f;
    return std::clamp(1.f - (float(dot(query, vector, dim)) * query_inverse) * vector_inverse, 0.f, 2.f);
}
inline float distance(Scalar const* query, Scalar const* vector, std::size_t dim, float query_norm,
                      VectorNorms const* norms = nullptr) {
    return distance_inverse(query, vector, dim, inverse_norm(query_norm), norms);
}

inline void finish_inverse4(float query_inverse, float const* vector_inverse, float const* dots, float* output) {
#if defined(__aarch64__)
    auto cosines = vmulq_f32(vmulq_f32(vld1q_f32(dots), vdupq_n_f32(query_inverse)), vld1q_f32(vector_inverse));
    vst1q_f32(output, vminq_f32(vdupq_n_f32(2), vmaxq_f32(vdupq_n_f32(0), vsubq_f32(vdupq_n_f32(1), cosines))));
#elif defined(__SSE2__)
    auto cosines = _mm_mul_ps(_mm_mul_ps(_mm_loadu_ps(dots), _mm_set1_ps(query_inverse)), _mm_loadu_ps(vector_inverse));
    _mm_storeu_ps(output, _mm_min_ps(_mm_set1_ps(2), _mm_max_ps(_mm_set1_ps(0), _mm_sub_ps(_mm_set1_ps(1), cosines))));
#else
    for (std::size_t i=0; i<4; ++i) output[i] = std::clamp(1.f - (dots[i]*query_inverse)*vector_inverse[i], 0.f, 2.f);
#endif
    for (std::size_t i=0; i<4; ++i)
        if (!query_inverse || !vector_inverse[i]) output[i] = query_inverse == vector_inverse[i] ? 0.f : 1.f;
}

inline void prepare_query(void const* query, std::size_t dim) {
    auto& cache = query_metric_cache;
    if (cache.query == query && cache.dim == dim) return;
    cache.query = query; cache.dim = dim;
    cache.norm = float(norm(static_cast<Scalar const*>(query), dim));
    cache.inverse_norm = inverse_norm(cache.norm);
}

inline float cosine(void const* query, void const* vector, std::size_t dim) {
    auto& cache = query_metric_cache;
    if (cache.active) {
        if (cache.query == query && cache.dim == dim && cache.batch_size) {
            auto at = cache.batch_next;
            if (at >= cache.batch_size || cache.batch_vectors[at] != vector)
                for (at = 0; at < cache.batch_size && cache.batch_vectors[at] != vector; ++at) {}
            if (at < cache.batch_size) {
                cache.batch_next = at + 1; cache.last_vector = vector;
                cache.last_distance = cache.batch_distances[at]; ++cache.measurements;
                return cache.last_distance;
            }
        }
        prepare_query(query, dim);
    }
    auto q = static_cast<Scalar const*>(query), v = static_cast<Scalar const*>(vector);
    auto value = distance_inverse(q, v, dim, cache.active ? cache.inverse_norm : inverse_norm(float(norm(q, dim))),
                                  cache.active ? cache.norms : nullptr);
    if (cache.active) { cache.last_vector = vector; cache.last_distance = value; ++cache.measurements; }
    return value;
}

inline void precompute(void const* query, void const* const* vectors, std::size_t count, std::size_t dim) {
    auto& cache = query_metric_cache;
    cache.batch_size = 0; cache.batch_next = 0;
    if (!cache.active || !cache.norms || !cache.norms->inverse || dim > 2048 || count < 4 || count > 64) return;
    float norms[64];
    for (std::size_t i = 0; i < count; ++i) if (!cache.norms->find(vectors[i], dim, norms[i])) return;
    prepare_query(query, dim);
    for (std::size_t base = 0; base < count; base += 4) {
        Scalar const* rows[4]; float row_norms[4], dots[4], distances[4]; std::int32_t integer_dots[4];
        for (std::size_t row = 0; row < 4; ++row) {
            rows[row] = static_cast<Scalar const*>(vectors[std::min(base + row, count - 1)]);
            row_norms[row] = norms[std::min(base + row, count - 1)];
        }
        dot4(static_cast<Scalar const*>(query), rows, dim, integer_dots);
        for (std::size_t row = 0; row < 4; ++row) dots[row] = float(integer_dots[row]);
        finish_inverse4(cache.inverse_norm, row_norms, dots, distances);
        for (std::size_t row = 0; row < 4 && base + row < count; ++row) {
            cache.batch_vectors[base + row] = vectors[base + row];
            cache.batch_distances[base + row] = distances[row];
        }
    }
    cache.batch_size = count;
}

inline us::metric_punned_t metric(std::size_t dim) {
    return {dim,reinterpret_cast<std::uintptr_t>(&cosine),us::metric_punned_signature_t::array_array_size_k,
            us::metric_kind_t::cos_k,us::scalar_kind_t::i8_k};
}
} // namespace sq8
