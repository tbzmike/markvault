plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
    id("org.jetbrains.kotlin.plugin.compose")
    id("com.google.devtools.ksp")
}

android {
    namespace = "com.tebogo.markvault"
    compileSdk = 35

    defaultConfig {
        applicationId = "com.tebogo.markvault"
        minSdk = 26
        targetSdk = 35
        versionCode = 462
        versionName = "5.5.13"
    }

    signingConfigs {
        create("release") {
            storeFile = rootProject.file("signing/markvault.jks")
            storePassword = "markvault123"
            keyAlias = "markvault"
            keyPassword = "markvault123"
        }
    }

    buildTypes {
        release {
            isMinifyEnabled = false
            signingConfig = signingConfigs.getByName("release")
        }
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions {
        jvmTarget = "17"
    }
    buildFeatures {
        compose = true
        buildConfig = true
    }
    lint {
        checkReleaseBuilds = false
        abortOnError = false
    }
    packaging {
        resources.excludes += "/META-INF/{AL2.0,LGPL2.1}"
    }
}

dependencies {
    val composeBom = platform("androidx.compose:compose-bom:2024.09.03")
    implementation(composeBom)
    implementation("androidx.compose.ui:ui")
    implementation("androidx.compose.material3:material3")
    implementation("androidx.activity:activity-compose:1.9.2")
    // v5.4.261cc — MediaRouter's official Cast button requires a FragmentActivity.
    // MainActivity remains Compose-first; FragmentActivity is only the hosting base
    // needed by MediaRouteButton so the Cast framework can own discovery/dialogs.
    implementation("androidx.fragment:fragment-ktx:1.8.9")
    implementation("androidx.navigation:navigation-compose:2.8.1")
    implementation("androidx.lifecycle:lifecycle-viewmodel-compose:2.8.6")
    implementation("androidx.lifecycle:lifecycle-runtime-compose:2.8.6")

    // v4.19.1 — Room 2.6.1 → 2.8.4.
    //
    // The Kotlin 2.0.20 → 2.2.0 bump in v4.19.0 (required by LiteRT-LM)
    // exposed a known KSP2 Analysis API bug in Room ≤ 2.6.x: when KSP2
    // processes Room's suspend DAO methods that return Unit (which is
    // most of our INSERT / UPDATE / DELETE DAO entries — upsertEmbedding,
    // recordWebVisit, savePdfPageText, etc.), it throws
    //   java.lang.IllegalStateException: unexpected jvm signature V
    // during `kspReleaseKotlin`, blocking the entire build.
    //
    // Room 2.7.0 fixed the underlying bug in their KSP processor (see
    // google/ksp#2957). 2.8.4 is the latest stable patch in the 2.x line
    // (the team moved Room 2.x to maintenance-mode after Room 3.0 alpha,
    // which is a breaking package change we are NOT taking on right now).
    //
    // 2.x → 2.x bump is source-compatible; no DAO / Entity / schema
    // changes required.
    implementation("androidx.room:room-runtime:2.8.4")
    implementation("androidx.room:room-ktx:2.8.4")
    ksp("androidx.room:room-compiler:2.8.4")

    implementation("androidx.datastore:datastore-preferences:1.1.1")
    implementation("org.jetbrains.kotlinx:kotlinx-coroutines-android:1.8.1")
    implementation("org.jetbrains.kotlinx:kotlinx-coroutines-guava:1.8.1")
    // WebView dark mode + safer browsing utilities
    implementation("androidx.webkit:webkit:1.12.1")
    // PDF text extraction for in-document search (rendering uses native PdfRenderer)
    implementation("com.tom-roush:pdfbox-android:2.0.27.0")
    // v4.8 — MediaPipe Tasks Text Embedder for semantic search. Provides a
    // TFLite-backed on-device text-embedding API; we ship the model file at
    // runtime (downloaded on first opt-in) so the APK stays slim.
    implementation("com.google.mediapipe:tasks-text:0.10.14")
    // v4.10 — ONNX Runtime Android for stronger transformer embedding models
    // (all-MiniLM-L6-v2 and friends). Adds ~12 MB to the APK; only used when
    // the user opts into an ONNX-backed model in Settings.
    implementation("com.microsoft.onnxruntime:onnxruntime-android:1.19.2")

    // v4.18.0 — flexmark-java: native Kotlin/Java markdown engine replacing the
    // JS-based markdown-it pipeline. Same engine Markor uses. 0.64.x is the
    // current stable line; 0.64.8 is the latest tag in that series.
    //
    // Extensions enabled:
    //   - tables                 — GFM pipe tables (already widely used)
    //   - gfm-tasklist           — `- [ ]` and `- [x]` task checkboxes
    //   - autolink               — auto-detect bare URLs in text
    //   - gfm-strikethrough      — `~~strike~~`
    //   - typographic            — smart quotes, em-dash, ellipsis
    // Wikilinks `[[Note]]` are NOT handled via the wikilink extension because
    // we need a specific `mv://wiki/<encoded>` URL scheme that ReaderScreen
    // intercepts. They are pre-processed in Kotlin (see MarkdownEngine.kt)
    // for exact control over the produced href.
    implementation("com.vladsch.flexmark:flexmark:0.64.8")
    implementation("com.vladsch.flexmark:flexmark-util-data:0.64.8")
    implementation("com.vladsch.flexmark:flexmark-ext-tables:0.64.8")
    implementation("com.vladsch.flexmark:flexmark-ext-gfm-tasklist:0.64.8")
    implementation("com.vladsch.flexmark:flexmark-ext-autolink:0.64.8")
    implementation("com.vladsch.flexmark:flexmark-ext-gfm-strikethrough:0.64.8")
    implementation("com.vladsch.flexmark:flexmark-ext-typographic:0.64.8")
    // NOTE: flexmark-ext-footnotes is NOT a separate published artifact in 0.64.x.
    // Footnotes are handled by the Kotlin two-pass preprocessFootnotes() in
    // MarkdownEngine.kt (v5.4.154cc) — no external dep required.

    // v4.19.0 — Stage 1 of the on-device chat LLM project. LiteRT-LM is
    // Google's current (2026) Kotlin API for running LLMs on-device,
    // replacing the now-deprecated MediaPipe LLM Inference API.
    //
    // Pinned to a real, verified-published version (0.13.1) rather than
    // the dynamic "latest.release" selector Google's docs show — dynamic
    // versions sacrifice CI reproducibility, which matters more here given
    // limited CI credits and the "must compile first try" constraint.
    //
    // This dependency is NOT yet wired into any UI. See LlmManager.kt for
    // the Stage 1 compile-only skeleton. Stages 2–5 (model download, RAG
    // prompt builder, chat screen) follow once this is confirmed to build.
    implementation("com.google.ai.edge.litertlm:litertlm-android:0.13.1")
    // v5.4.225cc — Media3/ExoPlayer + Coil
    implementation("androidx.media3:media3-exoplayer:1.3.1")
    implementation("androidx.media3:media3-exoplayer-hls:1.3.1")
    implementation("androidx.media3:media3-ui:1.3.1")
    implementation("androidx.media3:media3-session:1.3.1")
    implementation("io.coil-kt:coil-compose:2.6.0")
    // v5.4.247cc — Chromecast support. media3-cast provides CastPlayer which
    // implements the same Player interface as ExoPlayer — PlaybackService
    // switches between the two via MediaSession.setPlayer() when a Cast
    // session becomes available or ends. Version must match the existing
    // media3 deps above (1.3.1).
    //
    // v5.4.261cc — The Cast button now uses Google's official
    // CastButtonFactory + MediaRouteButton path. The standard MediaRouter
    // chooser/controller is AppCompat-backed, so keep AppCompat explicitly
    // present and host the Compose UI in a FragmentActivity. This removes
    // MarkVault's previous custom discovery/dialog implementation and lets
    // CastContext own discovery and SessionManager own route lifecycle.
    implementation("androidx.appcompat:appcompat:1.7.1")
    implementation("androidx.media3:media3-cast:1.3.1")
    implementation("com.google.android.gms:play-services-cast-framework:21.4.0")
}
