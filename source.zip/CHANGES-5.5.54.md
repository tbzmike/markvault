# MarkVault 5.5.54 (503)

Baseline: 5.5.53. Portable backup v7 / database schema 24 retained.

## Shared-vault restoration
- Identical destination documents are reused by SHA-256. Different existing files are not overwritten. Incoming conflicting files receive stable, content-hash-derived names; `.obsidian` conflicts are kept in a separate `.markvault-restore-conflicts` recovery tree so the destination's live Obsidian settings remain intact.
- Restore records the actual destination SAF document ID for every archive path, and binds restored indexed rows to the correct restored document. Paths and metadata reflect the destination; note IDs and stored vectors are preserved.
- Newly created files and directories are rolled back if the library-file pass fails. Retry can reuse identical content. A structural file/folder conflict or storage/provider failure can still stop restoration. Renaming conflicting files can affect relative links, so an empty folder is still recommended for an exact original layout.
- The restore dialog lets the user change the destination even when an existing vault is selected. Progress and conflict summary use the existing operation flow.

## Maximum lossless ZIP compression
- Change the single backup ZIP stream from `Deflater.BEST_SPEED` (1) to `Deflater.BEST_COMPRESSION` (9). Applies to all archive entries without dropping or changing data. Standard DEFLATE and the existing v7 checksums/restore format are unchanged. Previously generated backups remain readable.
- Settings describe the higher CPU/time cost during a user-initiated backup. Dense model weights and embeddings may compress only slightly; no promised savings on any specific library.
- No new service, scheduler, timer or permanent worker. The existing 5.5.50 highlight/idle and other search features are untouched.
