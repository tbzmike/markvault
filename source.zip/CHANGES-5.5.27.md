# MarkVault 5.5.27 (version code 476)

This update removes repeated work and overlaps independent stages of the blue HNSW search. It keeps the original IVF engine, all installed embedding models, automatic indexing/synchronisation, the exclusive blue search toggle, and the 5.5.24 expansion controls.

## Changes

- Run semantic retrieval alongside keyword retrieval on the blue content-search path. Run media retrieval alongside article ANN retrieval and exact rescoring. Both jobs belong to the search coroutine and finish or cancel with it.
- Cache exact query embeddings and exact query/document reranker scores for up to three minutes, with bounded LRU storage. Keys include model identity, model-file revision and exact input. Query vectors are copied; cancelled, failed, missing or invalidated computations do not populate the cache.
- Retain blue-search inference sessions after normal searches when measured available memory, process PSS and heap headroom permit. Keep the original IVF memory policy and the emergency/free-memory teardown and 85%/95% safeguards.
- Batch semantic-only hit metadata instead of fetching up to 200 complete articles individually. Full article/passages remain available for reranking and the reader.
- Replace repeated media OFFSET scans with indexed 1,024-row keyset pages on the blue path. Search the same model-specific media rows and produce the same scores and ranking.
- Score persisted FP32 vectors in a native batch, with the existing ordered FP32 accumulation, [-1, 1] clamping and Kotlin fallback. ARM uses vector multiplication with ordered lane accumulation; floating-point contraction is disabled.
- Remove the graph-wide key/pointer sort from ordinary HNSW candidate lookup. Reuse the distance immediately preceding each predicate in the pinned USearch version, with a runtime binding check and the existing recovery path.
- Account for overlapping stages in the saved search timing report.

No reduction to the existing ANN candidate frontier, expansion budget, full-precision candidate rescoring, exact-phrase constraints, coherent passage selection or 30-document rerank window.

## Verification

- Original IVF engine is byte-identical to 5.5.24. Actual Kotlin tests pass for build/search, accuracy probes, same-count edits, insertion/deletion, per-model separation, reopen, and failed/cancelled atomic rebuilds.
- 268 original files are byte-identical to 5.5.24, including Markdown components and assets. Source guards verify 563 unchanged ViewModel method/policy blocks, including the complete expansion-policy prefix, and 106 original DAO queries. 298 source files are unchanged from 5.5.26.
- HNSW manager/JNI tests pass for model isolation, partition filtering, sync, same-count replacement, deletion, priority, cancellation and atomic snapshot retention.
- On a synthetic 42,000-article / 210,000-chunk / 768-dimension graph, all 80 candidate lists exactly match 5.5.26 across all, first-20K, remaining-22K, sparse and empty scopes. Host candidate median in that comparison: 34.81 -> 32.43 ms.
- 7,872 JNI scores are bit-identical to the existing packed Kotlin scorer across dimensions 1, 4, 100, 103, 384, 768, 1024 and 2048. Invalid dimensions/queries, malformed rows, empty batches and score clamping are checked.
- Actual SQLite queries return identical metadata and identical model-specific media rows. On 200,000 synthetic media rows, host paging time falls from 7,239 ms with the existing 100-row OFFSET queries to 88 ms with keyset pages. This measures paging only; it is not the user's article-search timing.
- Exact-input cache TTL/LRU/revision/copy/coalescing/failure/cancellation checks, per-request scope snapshots, parallel execution/ownership, memory-policy boundaries and overlapping timing checks pass. Saved timing metadata round-trip and prior-format compatibility pass.
- Source ZIP uses fixed past timestamps and preserves executable permissions to prevent future-dated CMake inputs and Ninja's repeated-regeneration failure.

Host timings are not Android end-to-end timings. No Android SDK/NDK or phone is available in this environment, so a complete APK build, device/UI regression run, and subsecond finished phone searches have not been verified. The update preserves the existing Android build configuration; standalone native/JNI, Kotlin search components and AArch64 compilation are checked separately.

## Use

Install the APK built from this source and keep the existing blue HNSW toggle selected. Existing 5.5.26 graphs and embeddings remain compatible; no re-embedding or mandatory rebuild is needed. The first search can still load models; subsequent searches can reuse inference sessions and identical inputs when memory permits. Existing expansion and reranker settings remain effective.

Run `bash tools/run-hnsw-checks.sh` for native/SQLite/source checks. Set `MARKVAULT_JNI_INCLUDE`, `MARKVAULT_KOTLIN_COMPILER_CP` and optionally `MARKVAULT_JSON_CP` to also compile and execute the Kotlin/JNI and saved-search checks. The host Kotlin checks use language version 2.2.
