# MarkVault 5.5.34 final verification

- Source version: 5.5.34; version code: 483.
- Build: :app:assembleDebug and :app:assembleRelease — BUILD SUCCESSFUL in 4m 5s.
- Toolchain: Gradle 8.7, Java 17, Android SDK 35, NDK 27.2.12479018, CMake 3.22.1.
- Both APKs: version and signature verified; arm64-v8a, armeabi-v7a, x86 and x86_64 native libraries; 13 expected JNI exports per library; all native LOAD segments aligned to at least 16 KiB. APKs are build verification artifacts and are excluded from source.zip.
- Native kernel SHA-256: af386b3a3556361a7468bddc0355ce1cc0a14b8799b0ca9d8794737e271bc7ae.
- Complete native/source/Kotlin/JNI/IVF/UI/Room/saved-search suite: PASS.
- ARM64 Android static binary under QEMU and x86 without AVX/F16C: PASS, including all 324 edge cases and 22,720 distance comparisons.
- AddressSanitizer/UndefinedBehaviorSanitizer: PASS on odd-offset 500-vector/103-dimension snapshot, including updates/deletion/persistence. LeakSanitizer inspection disabled.
- Source preservation: PASS for all previous layers and the five exact reviewed 5.5.33 deltas. Production Kotlin, JNI, IVF, database, Markdown and UI files unchanged.
- Archive behavior: reproducible ZIP bytes, fixed past timestamps across time zones, executable permissions and cache exclusion fixture: PASS. Final packaging checks every archive member against the source and tests ZIP integrity; the extracted archive reruns the preservation guard.
- Phone performance and real embedding/reranker model inference were not measured in this update. The existing inference code is unchanged. No claim of a 10 ms phone search or one-second total search is made.

Warm host benchmark, full-size synthetic graph (not phone timings):

```
Fixture=42000 articles/210000 chunks/768 dimensions; prep=209.631 -> 203.93ms
360 exact candidate/coverage/frontier/distance-count comparisons=PASS
5.5.33 full-library lookup min=6.14155 median=9.05477 p95=11.1248 max=12.3742ms
5.5.34 full-library lookup min=6.69846 median=8.1735 p95=10.7598 max=13.5923ms
5.5.33 full-library graph min=5.91331 median=8.74855 p95=10.6579 max=11.8023ms
5.5.34 full-library graph min=6.44675 median=7.89712 p95=10.3382 max=13.1428ms
5.5.33 partition lookup min=5.51255 median=16.1884 p95=33.939 max=40.4944ms
5.5.34 partition lookup min=5.72961 median=15.3303 p95=32.0443 max=37.6759ms
```

See CHANGES-5.5.34.md for the kernel changes, compatibility and test scope.
