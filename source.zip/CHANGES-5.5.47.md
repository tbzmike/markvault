# MarkVault 5.5.47 — Chunk integrity, score readability, backup safety, CPU hygiene

Baseline: corrected MarkVault 5.5.46 source that produced a successful GitHub Actions build on October 27, 2026. Version code **496**.

## Changes

1. **Search relevance percentages** — Green (75–100%) and blue (55–74%) rating chips now use fully opaque saturated backgrounds and white lettering, independent of dark/light/AMOLED card backgrounds. Labels increased from 11 to 12 sp. Measured contrast: 6.57:1 green and 7.08:1 blue against white, above WCAG AA normal-text threshold.
2. **Chunking and embedding integrity** — Original 350-word/70-overlap article chunking and 180-word/45-overlap in-article passages are unchanged, including `(noteId, modelVersion, chunkIndex)` storage and `::chunked-v1` identifiers. A cached regular expression avoids recompilation per article. **Fix:** if any chunk inference returns null or an incorrect dimension, the service no longer transactionally replaces the prior complete chunk set with partial vectors; it retains the old rows for a later retry. Successful full-note writes retain the original Room transaction.
3. **ANN restore failure safety** — Verify all incoming IVF/HNSW files before altering the live set; rename existing files into a rollback folder, publish new files, validate the results, and roll back old filenames if publication fails. In the rare event rollback itself fails, preserve remaining old files in the staging directory and surface the failure. A malformed ANN snapshot is excluded from backup rather than making the backed-up semantic vectors unusable at restore time.
4. **Battery-conscious indexing** — Avoid forcing a full Java GC after each model pass when the Java heap is healthy. Keep model-closing and the existing explicit memory-pressure cleanup intact; conserve existing thermal/battery/charging safeguards. No automatic model synchronization rule is disabled or changed.

## Deliberately unchanged

- Existing chunk sizes, boundaries and overlap; no forced re-embedding or index version change.
- Enabled-model synchronization and disabled-model exclusion, Pause/Resume/Stop and Delete controls.
- Search result ordering, ranking, HNSW/IVF engines, result-card borders, expansion provenance and colors, Question Awareness 2.0, saved searches.
- Backup's data selection: note index, model-specific chunked vectors, settings preferences and IVF/HNSW final snapshots. Restore settings remain cold-start staged and device-specific library URI is preserved.

## Limitations

- The 350-word limit is a *word count*, not an exact tokenizer limit. Particularly long titles or long-word passages can still be truncated by the embedder's 3,000-character/512-token input limits. Altering chunk boundaries would require reindexing; this release intentionally preserves compatibility.
- A source-level review and standalone JVM tests cannot prove backups/restores on a live device, measured phone battery consumption, or a green Android build. Confirm on GitHub and test a backup/restore with a copy of your library before relying on it.
- Backups taken concurrently with ongoing embedding/index writes can still be sensitive to timing. For a critical backup, stop synchronization first, then back up after it is idle.
