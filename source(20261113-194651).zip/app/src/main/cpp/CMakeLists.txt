cmake_minimum_required(VERSION 3.22.1)
project(markvault_hnsw LANGUAGES CXX)
add_library(markvault_hnsw SHARED hnsw_jni.cpp)
target_include_directories(markvault_hnsw PRIVATE vendor/include)
target_compile_features(markvault_hnsw PRIVATE cxx_std_17)
target_compile_definitions(markvault_hnsw PRIVATE USEARCH_USE_NUMKONG=0 USEARCH_USE_OPENMP=0)
target_compile_options(markvault_hnsw PRIVATE -O3 -fvisibility=hidden -ffp-contract=off)
# Compatible ELF alignment for Android devices with 16 KB memory pages.
target_link_options(markvault_hnsw PRIVATE "-Wl,-z,max-page-size=16384")
