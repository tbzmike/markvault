#!/usr/bin/env python3
"""v5.5.50: Executable DOM navigation model + cancellation and source guards."""
import json
import re
import subprocess
from pathlib import Path

root = Path(__file__).resolve().parents[2]
ui = root / 'app/src/main/java/com/tebogo/markvault/ui'
shared = (ui / 'ArticleHighlightNavigation.kt').read_text()
markdown = (ui / 'ReaderScreen.kt').read_text()
html = (ui / 'HtmlReaderScreen.kt').read_text()
render = (root / 'app/src/main/assets/render.js').read_text()
build = (root / 'app/build.gradle.kts').read_text()
assert 'versionCode = 499' in build and 'versionName = "5.5.50"' in build

for src in (markdown, html):
    assert 'highlightController.cancel(' in src
    assert 'highlightController.track(' in src
    assert 'if (highlightController.cancelled) return@launch' in src
    assert 'if (highlightController.cancelled) return@postDelayed' in src
    assert 'HighlightLoadingIndicator(' in src and 'onCancel = {' in src
    assert '.align(Alignment.Center)' in src
    assert 'articleHighlightNavigateJs(' in src
    assert 'articleHighlightCountJs(' in src
assert 'Color(0xFF162D47)' in shared and 'Color.White' in shared
assert 'Cancel loading highlights' in shared
assert 'Please be patient/wait 🙏' in shared
assert shared.count('semanticJob?.cancel()') == 2 and 'window.__mvHighlightCancelled=true' in shared
assert 'window.__mvHighlightNavManual=true' in shared
assert 'window.__mvHighlightNavManual' in html and 'window.__mvHighlightNavManual' in render
vm = (root / 'app/src/main/java/com/tebogo/markvault/AppViewModel.kt').read_text()
semantic = vm[vm.index('suspend fun findArticleSemanticHighlightSentences('):vm.index('/** Internal chunk record', vm.index('suspend fun findArticleSemanticHighlightSentences('))]
assert semantic.count('currentCoroutineContext().ensureActive()') >= 7
assert 'window.__mvHighlightNavTarget = first' in html and render
assert 'if (window.__mvHighlightCancelled) return false;' in render
assert 'if (window.__mvHighlightCancelled) return;' in render
assert 'if (window.__mvHighlightCancelled || window.__mvHighlightNavManual) return;' in render
# Both JS highlighters honor cancellation in the initial attempt and retries.
assert 'if (window.__mvHighlightCancelled) return;' in html
assert html.count('if (window.__mvHighlightCancelled) return;') >= 3

helper = re.search(r'private fun highlightNodesJs\(safeSelector: String\): String = """(.*?)"""\.trimIndent\(\)',shared,re.S)
assert helper
nodes = helper.group(1).replace('$safeSelector',json.dumps('mark.hit, .passage'))

def get_script(function: str, direction=1):
    regex = rf'internal fun {function}\(.*?return """(.*?)"""\.trimIndent\(\)'
    match = re.search(regex, shared, re.S)
    assert match, function
    script = match.group(1)
    script = script.replace('${highlightNodesJs(safeSelector)}',nodes)
    script = script.replace('$step',str(direction))
    return script

countjs = get_script('articleHighlightCountJs')
nextjs = get_script('articleHighlightNavigateJs',1)
prevjs = get_script('articleHighlightNavigateJs',-1)
# Mimic a WebView DOM with five highlighted nodes, one nested lexical mark
# that should not be counted as an additional highlighted PASSAGE.
runtime = '''
const vm = require('vm');
const assert = require('assert');
const calls = [];
const window = { innerHeight: 800, pageYOffset: 0, scrollTo: (x) => calls.push(x) };
const document = { documentElement: { scrollTop: 0 }, querySelectorAll: () => nodes };
function hit(n, parent=null, visible=true) {
  const classes = new Set();
  return { label:n, isConnected:true, parentElement:parent,
    matches: () => !!parent && false,
    getClientRects: () => visible?[{}]:[],
    getBoundingClientRect: () => ({top: 100*n, height:25}),
    classList: { add: x=>classes.add(x), remove:x=>classes.delete(x) },
  };
}
const a = hit(1), b = hit(2), nested = hit(99,b), c = hit(3), d=hit(4), hidden=hit(5,null,false);
b.matches=()=>true;
const nodes=[a,b,nested,c,d,hidden];
const ctx=vm.createContext({window,document,setTimeout:()=>{},Array,Number,isFinite,Math});
function run(js) { return vm.runInContext(js,ctx); }
assert.equal(run(COUNT),4);
assert.equal(window.__mvHighlightNavIndex,0);
assert.equal(run(NEXT),4);
assert.equal(window.__mvHighlightNavTarget,b);
assert.equal(window.__mvHighlightNavIndex,1);
assert.equal(run(COUNT),4); // probing MUST NOT reset navigation
assert.equal(window.__mvHighlightNavIndex,1);
assert.equal(run(NEXT),4);
assert.equal(window.__mvHighlightNavTarget,c); // exactly ONE match, nested skipped
assert.equal(run(NEXT),4);
assert.equal(window.__mvHighlightNavTarget,d);
assert.equal(run(NEXT),4);
assert.equal(window.__mvHighlightNavTarget,a); // wrap
assert.equal(run(PREV),4);
assert.equal(window.__mvHighlightNavTarget,d);
assert(calls.length === 5, 'one scroll per button event');
assert(calls.every(x=>x.behavior==='instant'));
assert.equal(window.__mvHighlightNavManual,true);
// The initial auto-scroll might land on the THIRD mark; next must go to fourth.
window.__mvHighlightNavTarget = c;
assert.equal(run(COUNT),4);
assert.equal(window.__mvHighlightNavIndex,2);
run(NEXT);
assert.equal(window.__mvHighlightNavTarget,d);
// X cancels future navigation and DOM probes.
window.__mvHighlightCancelled=true;
const before=calls.length;
assert.equal(run(NEXT),0);
assert.equal(run(COUNT),0);
assert.equal(calls.length,before);
console.log('PASS JS DOM: one press -> one highlight; nested/hidden excluded; index stable; previous, wrap, initial target and cancel');
'''
for name, js in (('COUNT',countjs),('NEXT',nextjs),('PREV',prevjs)):
    runtime=runtime.replace(name,json.dumps(js)) if False else runtime
runtime=runtime.replace('run(COUNT)','run(COUNT)').replace('run(NEXT)','run(NEXT)')
runtime='const COUNT='+json.dumps(countjs)+';\nconst NEXT='+json.dumps(nextjs)+';\nconst PREV='+json.dumps(prevjs)+';\n'+runtime
runner=subprocess.run(['node','-e',runtime],capture_output=True,text=True,timeout=15)
if runner.returncode: raise AssertionError(runner.stderr)
print(runner.stdout.strip())
print('PASS v5.5.50: centered high-contrast overlay, X job cancellation, callback guards, auto-scroll suppression, both readers')
