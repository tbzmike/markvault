#!/usr/bin/env python3
"""Compile and exercise the 5.5.50 cancellation controller with small JVM stubs.
This is NOT an Android Compose or Gradle build.
"""
import pathlib, re, subprocess, tempfile
root=pathlib.Path(__file__).resolve().parents[2]
src=(root/'app/src/main/java/com/tebogo/markvault/ui/ArticleHighlightNavigation.kt').read_text()
match=re.search(r'internal class ArticleHighlightLoadController \{.*?\n\}\n',src,re.S)
assert match, 'controller missing'
with tempfile.TemporaryDirectory(prefix='mv-550-') as tmp:
    tmp=pathlib.Path(tmp)
    (tmp/'Controller.kt').write_text('package com.tebogo.markvault.ui\nimport kotlinx.coroutines.Job\nimport android.webkit.WebView\n'+match.group())
    (tmp/'Job.kt').write_text('package kotlinx.coroutines\nclass Job { var cancelled=false; fun cancel(){cancelled=true} }')
    (tmp/'WebView.kt').write_text('package android.webkit\nclass WebView { var command=""; fun evaluateJavascript(script:String, callback:Any?){command=script} }')
    (tmp/'Main.kt').write_text('''package com.tebogo.markvault.ui
import kotlinx.coroutines.Job
import android.webkit.WebView
fun main(){
  val c=ArticleHighlightLoadController()
  val j1=Job(); c.track(j1); check(!j1.cancelled)
  val j2=Job(); c.track(j2); check(j1.cancelled && !j2.cancelled)
  val view=WebView(); c.cancel(view)
  check(c.cancelled && j2.cancelled)
  check("window.__mvHighlightCancelled=true" in view.command)
  check("window.__mvHighlightNavManual=true" in view.command)
  val j3=Job(); c.track(j3); check(j3.cancelled)
  println("PASS Kotlin cancellation controller: one active job; replacement stops old; X cancels; no restart after cancel")
}''')
    cmd=['kotlinc',str(tmp/'Controller.kt'),str(tmp/'Job.kt'),str(tmp/'WebView.kt'),str(tmp/'Main.kt'),'-include-runtime','-d',str(tmp/'test.jar')]
    r=subprocess.run(cmd,capture_output=True,text=True,timeout=40)
    if r.returncode: raise AssertionError(r.stderr)
    r=subprocess.run(['java','-jar',str(tmp/'test.jar')],capture_output=True,text=True,timeout=10)
    if r.returncode: raise AssertionError(r.stderr)
    print(r.stdout.strip())
