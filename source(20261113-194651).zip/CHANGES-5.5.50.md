# MarkVault 5.5.50 — Highlight Navigation and Loading UX

## Baseline
Source for 5.5.49 (versionCode 498), whose prior GitHub build succeeded. Version 5.5.50 uses code 499. All previous source files are retained.

## Behavior
- In both Markdown ReaderScreen and offline-HTML HtmlReaderScreen, the small top loading badge becomes a centered, opaque navy dialog with large white text: “Loading highlights” / “Please be patient/wait 🙏”, a clear spinner and X close control.
- The X **cancels** the tracked semantic highlight coroutine, suppresses delayed WebView callbacks, and signals `window.__mvHighlightCancelled` to prevent pending highlight JS from completing or auto-scrolling. It does not close the article or delete content.
- Highlight-sentence embedding now includes additional coroutine cancellation checkpoints between chunks and sentences, to stop subsequent inference promptly after X (a native inference call already in progress may need to finish first).
- Arrow presses now advance exactly one *visible primary highlight* in DOM order. Nested highlights are counted as a single primary passage, and hidden nodes are excluded.
- Navigation remembers the actual highlighted element, does not reset its index upon later count probes, and never carries numeric indices across a re-rendered DOM.
- Manual arrow navigation uses immediate scrolling and prevents previously scheduled first-match smooth scrolling from overriding the selected highlight.
- A rerender cancels any previous semantic highlight job for that article.

## Unchanged
- Search ranking, Question Awareness 2.0, exact match, keyword recall/Esau fix, semantic/HNSW/IVF selection, expansions, reranking, model management, embedding synchronization, chunking, backup/restore, score contrasts, search cards, memory maintenance.
- In-article lexical/semantic highlight strategy and the navigation arrow positions remain unchanged.

## Limitations
- Android compilation and real-device scrolling/cancellation still require the project's GitHub Actions build and an installed APK; Android SDK and Gradle are not available in this verification runtime.
- Cancellation is cooperative: an already-running native embedding inference call may take time to return, but the result is ignored after cancellation and no further chunks/sentences are processed.
