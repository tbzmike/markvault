# MarkVault 5.5.50 — Verification

## Source preservation
- Baseline files: 436.
- Retained baseline files: 436/436.
- Baseline files byte-identical: 430.
- Existing files changed: 6: app/build.gradle.kts, app/src/main/assets/render.js, app/src/main/java/com/tebogo/markvault/AppViewModel.kt, app/src/main/java/com/tebogo/markvault/ui/ArticleHighlightNavigation.kt, app/src/main/java/com/tebogo/markvault/ui/HtmlReaderScreen.kt, app/src/main/java/com/tebogo/markvault/ui/ReaderScreen.kt.
- Baseline files removed: 0.
- New test files: 2. New reports: 2.

## Tests completed
- `tools/tests/highlight_navigation_5_5_50_test.py`: PASS, runs actual generated JavaScript against simulated DOM, checks next/previous/wrap/nested hits/hidden hits/initial selection/index stability/cancel.
- `tools/tests/highlight_controller_5_5_50_test.py`: PASS, compiles the Kotlin controller with JVM test stubs; exercises coroutine-job replacement, cancellation, and no restart.
- Isolated `kotlinc` compile of generated count/navigation JS functions: PASS.
- `node --check app/src/main/assets/render.js`: PASS.
- `tools/tests/search_accuracy_5_5_48_sql_test.py`: PASS.
- `tools/tests/model_isolation_5_5_46_test.py`: PASS.
- `tools/tests/hnsw_sql_test.py`: PASS.
- `tools/tests/search_result_card_separation_test.py`: PASS.
- `tools/tests/search_result_card_visual_test.py`: PASS.
- `tools/tests/query_embedding_preservation_test.py`: PASS.
- The old `tools/tests/search_lifecycle_5_5_43_test.py` fails an outdated assertion about a 350ms delay; later 5.5.49 deliberately changed that delay. This is a known historical-source assertion, **not** counted as passed.

## Not verified
- Complete Gradle `assembleRelease` or Android APK installation: not run; Android SDK/Gradle not installed here.
- Actual on-device JavaScript/WebView layout and touch interactions; production cancellation timing and battery draw.

## Recommended Android smoke test
1. Open a result in Smart Semantic mode; verify centered dialog while loading, X cancels and the article remains usable.
2. Open again, allow five distinct highlights; verify one down tap advances to the next highlighted passage and one up tap returns to the preceding passage, without skipping.
3. Repeat for both Markdown and offline HTML documents, and verify first-match scroll does not override navigation.
4. Verify regular searches, exact-match, HNSW, manual embedding synchronization, and existing saved results.
